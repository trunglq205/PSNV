import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/features/home/data/datasources/home_local_data_source.dart';
import 'package:swms_finish_goods/features/home/data/datasources/home_remote_data_source.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';
import 'package:swms_finish_goods/features/home/domain/home_repository.dart';
import 'package:swms_finish_goods/features/home/domain/scan_result.dart';

/// Assignments + phân loại mã quét lấy remote; danh sách ghim lưu cục bộ.
/// Tách nguồn nhưng cùng một interface để presentation không phải biết.
class HomeRepositoryImpl implements HomeRepository {
  final HomeRemoteDataSource _remote;
  final HomeLocalDataSource _local;

  const HomeRepositoryImpl(this._remote, this._local);

  @override
  Future<List<AssignmentData>> getAssignments() async {
    // ── MOCK TẠM (backend chưa sẵn sàng) ──────────────────
    // Giả lập độ trễ mạng cho ra trạng thái loading thật.
    await Future.delayed(const Duration(milliseconds: 2000), () {});
    return _mockAssignments;

    // ── BẬT LẠI khi có API ────────────────────────────────
    // final models = await _remote.fetchAssignments();
    // return models.map((m) => m.toEntity()).toList();
  }

  @override
  Future<Set<String>> getPinnedGroups() => _local.readPinned();

  @override
  Future<void> savePinnedGroups(Set<String> keys) => _local.writePinned(keys);

  @override
  Future<ScanResult> resolveScan(String code) async {
    final res = await _remote.resolveScan(code.trim());
    return res.toEntity();
  }

  // ── Dữ liệu mẫu ─────────────────────────────────────────
  static final List<AssignmentData> _mockAssignments = [
    const AssignmentData(
      id: 'SI-2026-0506-018',
      labelKey: LocaleKeys.home_task_picking,
      icon: Icons.outbox_outlined,
      code: 'SI-2026-0506-018',
      subKey: LocaleKeys.home_task_picking_sub,
      subArgs: ['Jakarta', 'A', '10'],
      deadlineText: '15:30 · còn 58′',
      urgent: true,
      done: 18,
      total: 45,
      unitKey: LocaleKeys.home_unit_box,
      tone: Color(0xFFF57C00),
      toneBg: Color(0xFFFFF3E0),
    ),
    const AssignmentData(
      id: 'ST-2026-0522-M',
      labelKey: LocaleKeys.home_task_stocktake_morning,
      icon: Icons.schedule,
      code: 'ST-2026-0522-M',
      subKey: LocaleKeys.home_task_stocktake_sub,
      subArgs: ['11', '5'],
      deadlineText: '10:00 · còn 3h 28′',
      done: 4,
      total: 11,
      unitKey: LocaleKeys.home_unit_location,
      tone: Color(0xFF2E7D32),
      toneBg: Color(0xFFE8F5E9),
    ),
  ];
}
