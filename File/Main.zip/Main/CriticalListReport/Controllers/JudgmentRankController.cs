﻿using ClosedXML.Excel;
using CriticalListReport.Helpers;
using CriticalListReport.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Globalization;

namespace CriticalListReport.Controllers
{
    [Authorize]
    [Authorize(Roles = "Admin,User")]
    public class JudgmentRankController : Controller
    {
        private readonly ILogger<JudgmentRankController> _logger;
        private readonly AppDbContext _context;
        private const string _errorExcep = "Có lỗi xảy ra. Kiểm tra lại format hoặc liên hệ quản trị viên!";

        public JudgmentRankController(
            ILogger<JudgmentRankController> logger,
            AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        #region Judgment Rank PO (Vendor Confirm)

        public IActionResult JudgmentRankPO()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetJudgmentRankPOData()
        {
            try
            {
                var draw = Request.Form["draw"].FirstOrDefault();
                var start = Request.Form["start"].FirstOrDefault();
                var length = Request.Form["length"].FirstOrDefault();
                var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;

                // Filter parameters
                var dataSourceFilter = Request.Form["dataSourceFilter"].FirstOrDefault();
                var plantFilter = Request.Form["plantFilter"].FirstOrDefault();
                var rankFilter = Request.Form["rankFilter"].FirstOrDefault();
                var vendorFilter = Request.Form["vendorFilter"].FirstOrDefault();
                var materialFilter = Request.Form["materialFilter"].FirstOrDefault();

                var fromDateStr = Request.Form["fromDate"].FirstOrDefault();
                var toDateStr = Request.Form["toDate"].FirstOrDefault();

                DateTime? from = string.IsNullOrEmpty(fromDateStr)
                ? (DateTime?)null
                : DateTime.Parse(fromDateStr).Date;

                DateTime? to = string.IsNullOrEmpty(toDateStr)
                    ? (DateTime?)null
                    : DateTime.Parse(toDateStr).Date;

                var query = _context.JudgmentRankPOs.AsQueryable();

                // Apply DataSource filter (required)
                if (!string.IsNullOrEmpty(dataSourceFilter))
                {
                    var ds = byte.Parse(dataSourceFilter);
                    query = query.Where(x => x.DataSource == ds);
                }
                else
                {
                    // Default to SAP (0)
                    query = query.Where(x => x.DataSource == 0);
                }

                // Apply filters chỉ khi có giá trị
                if (from.HasValue && to.HasValue)
                {
                    query = query.Where(x => x.NECDate >= from.Value && x.NECDate <= to.Value);
                }
                else if (from.HasValue)
                {
                    query = query.Where(x => x.NECDate >= from.Value);
                }
                else if (to.HasValue)
                {
                    query = query.Where(x => x.NECDate <= to.Value);
                }

                if (!string.IsNullOrEmpty(plantFilter))
                    query = query.Where(x => x.Plant == plantFilter);

                if (!string.IsNullOrEmpty(rankFilter))
                    query = query.Where(x => x.JudgmentRank == rankFilter);

                if (!string.IsNullOrEmpty(vendorFilter))
                    query = query.Where(x => x.Vendor == vendorFilter);

                // Material filter - support multiple values separated by comma or space
                if (!string.IsNullOrEmpty(materialFilter))
                {
                    var materials = materialFilter
                        .Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(m => m.Trim())
                        .Where(m => !string.IsNullOrEmpty(m))
                        .ToList();

                    if (materials.Count > 0)
                    {
                        query = query.Where(x => materials.Contains(x.Material!));
                    }
                }

                int recordsTotal = await query.CountAsync();

                // Sorting
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    query = sortColumnDirection.ToLower() == "asc"
                        ? query.OrderBy(x => EF.Property<object>(x, sortColumn))
                        : query.OrderByDescending(x => EF.Property<object>(x, sortColumn));
                }
                else
                {
                    query = query.OrderBy(x => x.Id);
                }

                var data = await query.Skip(skip).Take(pageSize).ToListAsync();

                return Json(new
                {
                    draw = draw,
                    recordsFiltered = recordsTotal,
                    recordsTotal = recordsTotal,
                    data = data
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetJudgmentRankPOData");
                return Json(new { error = _errorExcep });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetPOFilterOptions()
        {
            var plants = await _context.JudgmentRankPOs.Select(x => x.Plant).Distinct().Where(x => x != null).ToListAsync();
            var ranks = await _context.JudgmentRankPOs.Select(x => x.JudgmentRank).Distinct().Where(x => x != null).ToListAsync();
            var vendors = await _context.JudgmentRankPOs.Select(x => x.Vendor).Distinct().Where(x => x != null).ToListAsync();

            return Json(new { plants, ranks, vendors });
        }
        #endregion
        #region Judgment Rank PR (Requirement)

        public IActionResult JudgmentRankPR()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> GetJudgmentRankPRData()
        {
            try
            {
                var draw = Request.Form["draw"].FirstOrDefault();
                var start = Request.Form["start"].FirstOrDefault();
                var length = Request.Form["length"].FirstOrDefault();
                var sortColumn = Request.Form["columns[" + Request.Form["order[0][column]"].FirstOrDefault() + "][name]"].FirstOrDefault();
                var sortColumnDirection = Request.Form["order[0][dir]"].FirstOrDefault();

                int pageSize = length != null ? Convert.ToInt32(length) : 0;
                int skip = start != null ? Convert.ToInt32(start) : 0;

                // Filter parameters
                var dataSourceFilter = Request.Form["dataSourceFilter"].FirstOrDefault();
                var plantFilter = Request.Form["plantFilter"].FirstOrDefault();
                var rankFilter = Request.Form["rankFilter"].FirstOrDefault();
                var vendorFilter = Request.Form["vendorFilter"].FirstOrDefault();
                var materialFilter = Request.Form["materialFilter"].FirstOrDefault();

                var fromDateStr = Request.Form["fromDate"].FirstOrDefault();
                var toDateStr = Request.Form["toDate"].FirstOrDefault();

                DateTime? from = string.IsNullOrEmpty(fromDateStr)
                ? (DateTime?)null
                : DateTime.Parse(fromDateStr).Date;

                DateTime? to = string.IsNullOrEmpty(toDateStr)
                    ? (DateTime?)null
                    : DateTime.Parse(toDateStr).Date;

                var query = _context.JudgmentRankPRs.AsQueryable();

                // Apply DataSource filter (required)
                if (!string.IsNullOrEmpty(dataSourceFilter))
                {
                    var ds = byte.Parse(dataSourceFilter);
                    query = query.Where(x => x.DataSource == ds);
                }
                else
                {
                    // Default to SAP (0)
                    query = query.Where(x => x.DataSource == 0);
                }

                // Apply other filters
                // Apply filters chỉ khi có giá trị
                if (from.HasValue && to.HasValue)
                {
                    query = query.Where(x => x.DelivDate >= from.Value && x.DelivDate <= to.Value);
                }
                else if (from.HasValue)
                {
                    query = query.Where(x => x.DelivDate >= from.Value);
                }
                else if (to.HasValue)
                {
                    query = query.Where(x => x.DelivDate <= to.Value);
                }

                if (!string.IsNullOrEmpty(plantFilter))
                    query = query.Where(x => x.Plant == plantFilter);

                if (!string.IsNullOrEmpty(rankFilter))
                    query = query.Where(x => x.JudgmentRank == rankFilter);

                if (!string.IsNullOrEmpty(vendorFilter))
                    query = query.Where(x => x.FixVendor == vendorFilter);

                // Material filter - support multiple values separated by comma or space
                if (!string.IsNullOrEmpty(materialFilter))
                {
                    var materials = materialFilter
                        .Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(m => m.Trim())
                        .Where(m => !string.IsNullOrEmpty(m))
                        .ToList();

                    if (materials.Count > 0)
                    {
                        query = query.Where(x => materials.Contains(x.Material!));
                    }
                }

                int recordsTotal = await query.CountAsync();

                // Sorting
                if (!string.IsNullOrEmpty(sortColumn) && !string.IsNullOrEmpty(sortColumnDirection))
                {
                    query = sortColumnDirection.ToLower() == "asc"
                        ? query.OrderBy(x => EF.Property<object>(x, sortColumn))
                        : query.OrderByDescending(x => EF.Property<object>(x, sortColumn));
                }
                else
                {
                    query = query.OrderBy(x => x.Id);
                }

                var data = await query.Skip(skip).Take(pageSize).ToListAsync();

                return Json(new
                {
                    draw = draw,
                    recordsFiltered = recordsTotal,
                    recordsTotal = recordsTotal,
                    data = data
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in GetJudgementRankPRData");
                return Json(new { error = _errorExcep });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetPRFilterOptions(byte? dataSource)
        {
            var ds = dataSource ?? 0;

            var plants = await _context.JudgmentRankPRs
                .Where(x => x.DataSource == ds)
                .Select(x => x.Plant)
                .Distinct()
                .Where(x => x != null)
                .ToListAsync();

            var ranks = await _context.JudgmentRankPRs
                .Where(x => x.DataSource == ds)
                .Select(x => x.JudgmentRank)
                .Distinct()
                .Where(x => x != null)
                .ToListAsync();

            var vendors = await _context.JudgmentRankPRs
                .Where(x => x.DataSource == ds)
                .Select(x => x.FixVendor)
                .Distinct()
                .Where(x => x != null)
                .ToListAsync();

            return Json(new { plants, ranks, vendors });
        }
        #endregion

        [HttpPost]
        public async Task<IActionResult> ExportJudgmentRankCombined(
        byte? dataSourceFilter,
        string? plantFilter,
        string? rankFilter,
        string? vendorFilter,
        string? materialFilter,
        DateTime? fromDate,
        DateTime? toDate)
        {
            try
            {
                var ds = dataSourceFilter ?? 0;
                DateTime? from = fromDate?.Date;
                DateTime? to = toDate?.Date;

                // ========== Query PO ==========
                var queryPO = _context.JudgmentRankPOs.Where(x => x.DataSource == ds);
                if (from.HasValue && to.HasValue) { queryPO = queryPO.Where(x => x.NECDate >= from.Value && x.NECDate <= to.Value); } 
                else if (from.HasValue) { queryPO = queryPO.Where(x => x.NECDate >= from.Value); } 
                else if (to.HasValue) { queryPO = queryPO.Where(x => x.NECDate <= to.Value); }

                if (!string.IsNullOrEmpty(plantFilter))
                    queryPO = queryPO.Where(x => x.Plant == plantFilter);
                if (!string.IsNullOrEmpty(rankFilter))
                    queryPO = queryPO.Where(x => x.JudgmentRank == rankFilter);
                if (!string.IsNullOrEmpty(vendorFilter))
                    queryPO = queryPO.Where(x => x.Vendor == vendorFilter);
                if (!string.IsNullOrEmpty(materialFilter))
                {
                    var materials = materialFilter
                        .Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(m => m.Trim())
                        .Where(m => !string.IsNullOrEmpty(m))
                        .ToList();
                    if (materials.Count > 0)
                        queryPO = queryPO.Where(x => materials.Contains(x.Material!));
                }
                var dataPO = await queryPO.OrderBy(x => x.Id).ToListAsync();

                // ========== Query PR ==========
                var queryPR = _context.JudgmentRankPRs.Where(x => x.DataSource == ds);
                if (from.HasValue && to.HasValue) { queryPR = queryPR.Where(x => x.DelivDate >= from.Value && x.DelivDate <= to.Value); } 
                else if (from.HasValue) { queryPR = queryPR.Where(x => x.DelivDate >= from.Value); } 
                else if (to.HasValue) { queryPR = queryPR.Where(x => x.DelivDate <= to.Value); }

                if (!string.IsNullOrEmpty(plantFilter))
                    queryPR = queryPR.Where(x => x.Plant == plantFilter);
                if (!string.IsNullOrEmpty(rankFilter))
                    queryPR = queryPR.Where(x => x.JudgmentRank == rankFilter);
                if (!string.IsNullOrEmpty(vendorFilter))
                    queryPR = queryPR.Where(x => x.FixVendor == vendorFilter);
                if (!string.IsNullOrEmpty(materialFilter))
                {
                    var materials = materialFilter
                        .Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                        .Select(m => m.Trim())
                        .Where(m => !string.IsNullOrEmpty(m))
                        .ToList();
                    if (materials.Count > 0)
                        queryPR = queryPR.Where(x => materials.Contains(x.Material!));
                }
                var dataPR = await queryPR.OrderBy(x => x.Id).ToListAsync();

                using var workbook = new XLWorkbook();

                // ========== Sheet 1: Judgement Rank PO ==========
                var wsPO = workbook.Worksheets.Add("Judgement Rank PO");
                CreateSheetPO(wsPO, dataPO);

                // ========== Sheet 2: Judgement Rank PR ==========
                var wsPR = workbook.Worksheets.Add("Judgement Rank PR");
                CreateSheetPR(wsPR, dataPR);

                // ========== Sheet 3: Summarize ==========
                var wsSummary = workbook.Worksheets.Add("Summarize");
                CreateSheetSummarize(wsSummary, dataPO, dataPR);

                // ========== Sheet 4: Detail ==========
                var wsDetail = workbook.Worksheets.Add("Air Cost");
                CreateSheetAirCost(wsDetail, dataPO, dataPR);

                using var stream = new MemoryStream();
                workbook.SaveAs(stream);
                var content = stream.ToArray();
                var sourceType = ds == 0 ? "SAP" : "TCode";

                return File(content, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    $"JudgementRank_{sourceType}_{DateTime.Now:yyyyMMdd_HHmmss}.xlsx");
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error exporting JudgementRank Combined");
                return BadRequest(_errorExcep);
            }
        }

        private void CreateSheetPO(IXLWorksheet ws, List<JudgmentRankPO> data)
        {
            var headers = new[] {
                "Plant", "Plant Name", "Vendor", "Vendor Name", "Material", "Short Text",
                "PO", "Item", "PO No Item", "Deliv.Date", "MRP", "NEC Date",
                "Qty Order", "Qty Inbound", "Qty Pending", "Created On", "LT",
                "Vendor Last CF", "ETA PSNV", "Shipping Mode",
                "ETA After Judegment", "Mode After Judegment",
                "GW Per 1Pcs","Unit of Packing", "Total GW", "Header Text", "Short LT",
                "Pur Grp", "MRP Ctr", "PIC", "Material Type",
                "Judgement Rank", "Freight Unit","Rounding Val", "GW Air"
            };

            // Header
            for (int i = 0; i < headers.Length; i++)
            {
                ws.Cell(1, i + 1).Value = headers[i];
                ws.Cell(1, i + 1).Style.Font.Bold = true;
                ws.Cell(1, i + 1).Style.Fill.BackgroundColor = XLColor.FromArgb(107, 91, 149);
                ws.Cell(1, i + 1).Style.Font.FontColor = XLColor.White;
            }

            // Data
            int row = 2;
            foreach (var item in data)
            {
                ws.Cell(row, 1).Value = item.Plant;
                ws.Cell(row, 2).Value = item.PlantName;
                ws.Cell(row, 3).Value = item.Vendor;
                ws.Cell(row, 4).Value = item.VendorName;
                ws.Cell(row, 5).Value = item.Material;
                ws.Cell(row, 6).Value = item.ShortText;
                ReflectionHelper.SetNumberCellNoComma(ws, row, 7, item.PO);
                ReflectionHelper.SetNumberCell(ws, row, 8, item.Item);
                ReflectionHelper.SetNumberCellNoComma(ws, row, 9, item.PONoItem);
                ReflectionHelper.SetDateCell(ws, row, 10, item.DelivDate);
                ws.Cell(row, 11).Value = item.MRP;
                ReflectionHelper.SetDateCell(ws, row, 12, item.NECDate);
                ReflectionHelper.SetNumberCell(ws, row, 13, item.QtyOrder);
                ReflectionHelper.SetNumberCell(ws, row, 14, item.QtyInbound);
                ReflectionHelper.SetNumberCell(ws, row, 15, item.QtyPending?.ToString());
                ReflectionHelper.SetDateCell(ws, row, 16, item.CreatedOn);
                ws.Cell(row, 17).Value = item.LT;
                ReflectionHelper.SetDateCell(ws, row, 18, item.VendorLastCF);
                ReflectionHelper.SetDateCell(ws, row, 19, item.ETAPSNV_VendorLastCF);
                ws.Cell(row, 20).Value = item.ShippingMode;
                ReflectionHelper.SetDateCell(ws, row, 21, item.ETAPSNV_AfterJudgement);
                ws.Cell(row, 22).Value = item.ShippingMode_AfterJudgement;
                ReflectionHelper.SetNumberCell(ws, row, 23, item.GWPer1Pcs);
                ReflectionHelper.SetNumberCell(ws, row, 24, item.UnitPacking);
                ReflectionHelper.SetNumberCell(ws, row, 25, item.TotalGW);
                ws.Cell(row, 26).Value = item.HeaderText;
                ReflectionHelper.SetNumberCell(ws, row, 27, item.ShortLT);
                ws.Cell(row, 28).Value = item.PurGrp;
                ws.Cell(row, 29).Value = item.MRPCtr;
                ws.Cell(row, 30).Value = item.PIC;
                ws.Cell(row, 31).Value = item.MaterialType;
                ws.Cell(row, 32).Value = item.JudgmentRank;
                ReflectionHelper.SetNumberCell(ws, row, 33, item.FreightUnit);
                ReflectionHelper.SetNumberCell(ws, row, 34, item.RoundingVal);
                ReflectionHelper.SetNumberCell(ws, row, 35, item.GWAir?.ToString());
                row++;
            }

            ws.Columns().AdjustToContents();
        }

        private void CreateSheetPR(IXLWorksheet ws, List<JudgmentRankPR> data)
        {
            var headers = new[] { "Plant", "Material", "Short Text", "Deliv Date", "Fix Vendor", "Vendor Name",
        "MRPC", "PIC", "PR Quantity", "Leadtime", "Short LT", "Material Type",
        "Judgement Rank", "Freight Unit","G/W per 1pcs","Unit of Packing" ,"Rounding Val", "GW Air" };

            // Header
            for (int i = 0; i < headers.Length; i++)
            {
                ws.Cell(1, i + 1).Value = headers[i];
                ws.Cell(1, i + 1).Style.Font.Bold = true;
                ws.Cell(1, i + 1).Style.Fill.BackgroundColor = XLColor.FromArgb(107, 91, 149);
                ws.Cell(1, i + 1).Style.Font.FontColor = XLColor.White;
            }

            // Data
            int row = 2;
            foreach (var item in data)
            {
                ws.Cell(row, 1).Value = item.Plant;
                ws.Cell(row, 2).Value = item.Material;
                ws.Cell(row, 3).Value = item.ShortText;
                ReflectionHelper.SetDateCell(ws, row, 4, item.DelivDate);
                ws.Cell(row, 5).Value = item.FixVendor;
                ws.Cell(row, 6).Value = item.VendorName;
                ws.Cell(row, 7).Value = item.MRPC;
                ws.Cell(row, 8).Value = item.PIC;
                ReflectionHelper.SetNumberCell(ws, row, 9, item.InboundQty?.ToString());
                ReflectionHelper.SetNumberCell(ws, row, 10, item.Leadtime?.ToString());
                ReflectionHelper.SetNumberCell(ws, row, 11, item.ShortLT?.ToString());
                ws.Cell(row, 12).Value = item.MaterialType;
                ws.Cell(row, 13).Value = item.JudgmentRank;
                ReflectionHelper.SetNumberCell(ws, row, 14, item.FreightUnit);
                ReflectionHelper.SetNumberCell(ws, row, 15, item.GWPer1Pcs);
                ReflectionHelper.SetNumberCell(ws, row, 16, item.UnitPacking);
                ReflectionHelper.SetNumberCell(ws, row, 17, item.RoundingVal);
                ReflectionHelper.SetNumberCell(ws, row, 18, item.GWAir?.ToString());
                row++;
            }

            ws.Columns().AdjustToContents();
        }

        private void CreateSheetSummarize(IXLWorksheet ws, List<JudgmentRankPO> dataPO, List<JudgmentRankPR> dataPR)
        {
            var purple = XLColor.FromArgb(107, 91, 149);
            var cream = XLColor.FromArgb(255, 242, 204);
            var ranks = new[] { "A1", "A2", "A3", "A4", "B", "Production Short LT" };

            // Lấy Maker name từ PartMaster cho các mã A1/A2
            var materialsA = dataPO.Where(x => x.JudgmentRank == "A1" || x.JudgmentRank == "A2")
                .Select(x => x.Material)
                .Union(dataPR.Where(x => x.JudgmentRank == "A1" || x.JudgmentRank == "A2").Select(x => x.Material))
                .Where(x => !string.IsNullOrEmpty(x))
                .Distinct()
                .ToList();
            var makerMaster = _context.PartMasters
                .Where(x => materialsA.Contains(x.PartNo))
                .ToList()
                .GroupBy(x => $"{x.PartNo}_{x.Vendor}")
                .ToDictionary(x => x.Key, x => x.First().MakerName);

            int row = 1;

            // =========================================================
            // SECTION 1: Rank Judgement
            // =========================================================
            ws.Cell(row, 1).Value = "Rank Judgement";
            ws.Cell(row, 1).Style.Font.Bold = true;
            ws.Cell(row, 1).Style.Font.FontSize = 14;
            row++;

            int rjHeaderRow = row;
            // Ô A: "Type of material" đẩy lên phải (trên), "Short LT" sát trái (dưới)
            // Dùng khoảng trắng để đẩy text tránh đường chéo
            ws.Cell(row, 1).Value = "                 Type of material\n         Short LT";
            ws.Cell(row, 2).Value = "S/M";
            ws.Cell(row, 3).Value = "E/A";
            ws.Cell(row, 4).Value = "Rank";
            for (int c = 2; c <= 4; c++)   // ô 2,3,4 canh giữa như cũ
            {
                var cell = ws.Cell(row, c);
                cell.Style.Font.Bold = true;
                cell.Style.Fill.BackgroundColor = purple;
                cell.Style.Font.FontColor = XLColor.White;
                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                cell.Style.Alignment.WrapText = true;
            }

            // Ô A: canh trái + wrap để khoảng trắng có tác dụng đẩy chữ
            var cellA = ws.Cell(row, 1);
            cellA.Style.Font.Bold = true;
            cellA.Style.Fill.BackgroundColor = purple;
            cellA.Style.Font.FontColor = XLColor.White;
            cellA.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
            cellA.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
            cellA.Style.Alignment.WrapText = true;

            // Gạch chéo trong ô A (góc trên-trái xuống dưới-phải)
            cellA.Style.Border.DiagonalDown = true;
            cellA.Style.Border.DiagonalBorder = XLBorderStyleValues.Thin;
            cellA.Style.Border.DiagonalBorderColor = XLColor.Black;

            // Cho ô A cao + cột A rộng để 2 dòng và đường chéo rõ
            ws.Row(row).Height = 40;
            ws.Column(1).Width = 22;

            row++;

            var rjRows = new (string shortLT, string sm, string ea, string rank)[]
            {
        (">30",   "•", "•", "A1"),
        ("15~30", "",  "•", "A2"),
        ("15~30", "•", "",  "A3"),
        ("0-15",  "•", "•", "A4"),
        ("<0",    "•", "•", "B"),
        //("All",   "•", "•", "Production Short LT"),
            };
            foreach (var r in rjRows)
            {
                ws.Cell(row, 1).Value = r.shortLT;
                ws.Cell(row, 2).Value = r.sm;
                ws.Cell(row, 3).Value = r.ea;
                ws.Cell(row, 4).Value = r.rank;
                for (int c = 1; c <= 4; c++)
                    ws.Cell(row, c).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                ws.Cell(row, 4).Style.Font.Bold = true;
                row++;
            }
            ws.Range(rjHeaderRow, 1, row - 1, 4).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            ws.Range(rjHeaderRow, 1, row - 1, 4).Style.Border.InsideBorder = XLBorderStyleValues.Thin;

            row++; // blank line

            // =========================================================
            // SECTION 2: Total By PO item / PR item
            // =========================================================
            ws.Cell(row, 1).Value = "Total By PO item/PR item";
            ws.Cell(row, 1).Style.Font.Bold = true;
            ws.Cell(row, 1).Style.Font.FontSize = 14;
            row++;

            int totHeaderRow = row;
            ws.Cell(row, 1).Value = "Rank";
            for (int i = 0; i < ranks.Length; i++)
                ws.Cell(row, i + 2).Value = ranks[i];
            ws.Cell(row, ranks.Length + 2).Value = "Total item";
            for (int c = 1; c <= ranks.Length + 2; c++)
            {
                var cell = ws.Cell(row, c);
                cell.Style.Font.Bold = true;
                cell.Style.Fill.BackgroundColor = purple;
                cell.Style.Font.FontColor = XLColor.White;
                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            }
            row++;

            // Qty of PO item
            ws.Cell(row, 1).Value = "Qty of PO item";
            ws.Cell(row, 1).Style.Font.Bold = true;
            int totalPO = 0;
            for (int i = 0; i < ranks.Length; i++)
            {
                var count = dataPO.Count(x => x.JudgmentRank == ranks[i]);
                ws.Cell(row, i + 2).Value = count;
                ws.Cell(row, i + 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                totalPO += count;
            }
            ws.Cell(row, ranks.Length + 2).Value = totalPO;
            ws.Cell(row, ranks.Length + 2).Style.Font.Bold = true;
            ws.Cell(row, ranks.Length + 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            ws.Cell(row, ranks.Length + 2).Style.Fill.BackgroundColor = cream;
            row++;

            // Qty of PR item
            ws.Cell(row, 1).Value = "Qty of PR item";
            ws.Cell(row, 1).Style.Font.Bold = true;
            int totalPR = 0;
            for (int i = 0; i < ranks.Length; i++)
            {
                var count = dataPR.Count(x => x.JudgmentRank == ranks[i]);
                ws.Cell(row, i + 2).Value = count;
                ws.Cell(row, i + 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                totalPR += count;
            }
            ws.Cell(row, ranks.Length + 2).Value = totalPR;
            ws.Cell(row, ranks.Length + 2).Style.Font.Bold = true;
            ws.Cell(row, ranks.Length + 2).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            ws.Cell(row, ranks.Length + 2).Style.Fill.BackgroundColor = cream;

            ws.Range(totHeaderRow, 1, row, ranks.Length + 2).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            ws.Range(totHeaderRow, 1, row, ranks.Length + 2).Style.Border.InsideBorder = XLBorderStyleValues.Thin;
            row += 2; // blank line

            var detailHeaders = new[]
            {
        "No", "Material", "Short Text", "Vendor", "Vendor Name", "Maker name",
        "Short LT (max)", "Nec.date/Deliv.date (first)", "Vendor status",
        "Other factory name", "Stock other factory", "Action"
    };

            // =========================================================
            // SECTION 3: Total Part By PO (A1/A2)
            // =========================================================
            ws.Cell(row, 1).Value = "Total Part By PO (A1/A2)";
            ws.Cell(row, 1).Style.Font.Bold = true;
            ws.Cell(row, 1).Style.Font.FontSize = 14;
            row++;

            var poA = dataPO
                .Where(x => x.JudgmentRank == "A1" || x.JudgmentRank == "A2")
                .GroupBy(x => x.Material)
                .Select(g => new
                {
                    Material = g.Key,
                    ShortText = g.First().ShortText,
                    Vendor = g.First().Vendor,
                    VendorName = g.First().VendorName,
                    Maker = makerMaster.TryGetValue($"{g.Key}_{g.First().Vendor}", out var mk) ? mk : "",
                    ShortLT = g.Select(x => ParseShortLT(x.ShortLT)).Min(),   // âm nhỏ nhất
                    NecDate = g.Where(x => x.NECDate.HasValue)
                               .Select(x => x.NECDate)
                               .DefaultIfEmpty()
                               .Min()
                })
                .OrderBy(x => x.NecDate)
                .ToList();

            row = WriteDetailBlock(ws, row, detailHeaders, purple,
                poA.Select((x, idx) => new object?[]
                {
                    idx + 1, x.Material, x.ShortText, x.Vendor, x.VendorName, x.Maker,
                    x.ShortLT,
                    x.NecDate?.ToString("dd-MMM-yy"),
                    null, null, null, null
                }).ToList());

            row += 2; // blank line

            // =========================================================
            // SECTION 4: Total Part By PR (A1/A2)
            // =========================================================
            ws.Cell(row, 1).Value = "Total Part By PR (A1/A2)";
            ws.Cell(row, 1).Style.Font.Bold = true;
            ws.Cell(row, 1).Style.Font.FontSize = 14;
            row++;

            var prA = dataPR
                .Where(x => x.JudgmentRank == "A1" || x.JudgmentRank == "A2")
                .GroupBy(x => x.Material)
                .Select(g => new
                {
                    Material = g.Key,
                    ShortText = g.First().ShortText,
                    Vendor = g.First().FixVendor,
                    VendorName = g.First().VendorName,
                    Maker = makerMaster.TryGetValue($"{g.Key}_{g.First().FixVendor}", out var mk) ? mk : "",
                    ShortLT = g.Select(x => x.ShortLT ?? 0).Min(),
                    DelivDate = g.Where(x => x.DelivDate.HasValue)
                                 .Select(x => x.DelivDate)
                                 .DefaultIfEmpty()
                                 .Min()
                })
                .OrderBy(x => x.DelivDate)
                .ToList();

            row = WriteDetailBlock(ws, row, detailHeaders, purple,
                prA.Select((x, idx) => new object?[]
                {
                    idx + 1, x.Material, x.ShortText, x.Vendor, x.VendorName, x.Maker,
                    x.ShortLT,
                    x.DelivDate?.ToString("dd-MMM-yy"),
                    null, null, null, null
                }).ToList());

            ws.Columns().AdjustToContents();
            ws.Column(1).Width = 22;
        }

        // Parse ShortLT string -> int, không parse được thì trả 0
        private int ParseShortLT(string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return 0;
            var cleaned = value.Trim();
            if (int.TryParse(cleaned, out var i)) return i;
            if (decimal.TryParse(cleaned, out var d)) return (int)Math.Round(d);
            return 0;
        }

        // Helper: ghi 1 block chi tiết có header + data, trả về row tiếp theo
        private int WriteDetailBlock(IXLWorksheet ws, int row, string[] headers, XLColor headerColor, List<object?[]> rows)
        {
            int headerRow = row;
            for (int c = 0; c < headers.Length; c++)
            {
                var cell = ws.Cell(row, c + 1);
                cell.Value = headers[c];
                cell.Style.Font.Bold = true;
                cell.Style.Fill.BackgroundColor = headerColor;
                cell.Style.Font.FontColor = XLColor.White;
                cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            }
            row++;

            foreach (var r in rows)
            {
                for (int c = 0; c < r.Length; c++)
                {
                    if (r[c] != null)
                        ws.Cell(row, c + 1).Value = XLCellValue.FromObject(r[c]);
                }
                row++;
            }

            int lastRow = rows.Count > 0 ? row - 1 : row;
            if (rows.Count == 0) row++;

            ws.Range(headerRow, 1, lastRow, headers.Length).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            ws.Range(headerRow, 1, lastRow, headers.Length).Style.Border.InsideBorder = XLBorderStyleValues.Thin;

            return row;
        }

        private void CreateSheetAirCost(IXLWorksheet ws, List<JudgmentRankPO> dataPO, List<JudgmentRankPR> dataPR)
        {
            // ========== FILTER DATA ==========
            // PO: Mode After Judgment = AIR hoặc Vendor Last CF = null/TBA/00-00-00
            var filteredPO = dataPO.Where(x =>
                x.ShippingMode_AfterJudgement == "AIR" ||
                (
                    (string.IsNullOrEmpty(x.VendorLastCF) || x.VendorLastCF == "TBA" || x.VendorLastCF == "00-00-00")
                    && int.TryParse(x.ShortLT, out int shortLT) && shortLT < 0
                )
            ).ToList();

            // PR: Short LT < 0
            var filteredPR = dataPR.Where(x => x.ShortLT < 0).ToList();

            // ========== GET MASTER DATA ==========
            // Plant Master
            var plantMaster = new Dictionary<string, string>
            {
                { "VG01", "KA" },
                { "V501", "App" },
                { "VE01", "Isb" },
                { "VR01", "DP" },
                { "VY01", "ODM" }
            };

            // Lấy Vendor Master từ DB
            var vendorCodes = filteredPO.Select(x => x.Vendor)
                .Union(filteredPR.Select(x => x.FixVendor))
                .Where(x => !string.IsNullOrEmpty(x))
                .Distinct()
                .ToList();
            var vendorMaster = _context.VendorMasters
                .Where(x => vendorCodes.Contains(x.Vendor))
                .ToDictionary(x => x.Vendor!, x => x.FreightUnit);

            // Lấy Part Master từ DB
            var materials = filteredPO.Select(x => x.Material)
                .Union(filteredPR.Select(x => x.Material))
                .Where(x => !string.IsNullOrEmpty(x))
                .Distinct()
                .ToList();
            var partMaster = _context.PartMasters
                .Where(x => materials.Contains(x.PartNo))
                .ToList()
                .GroupBy(x => $"{x.PartNo}_{x.Vendor}")
                .ToDictionary(x => x.Key, x => x.First().MakerName);

            // ========== PREPARE COMBINED DATA ==========
            var airCostData = new List<AirCostRow>();

            // Process PO
            foreach (var po in filteredPO)
            {
                var vendor = po.Vendor ?? "";
                var makerKey = $"{po.Material}_{vendor}";
                var maker = partMaster.ContainsKey(makerKey) ? partMaster[makerKey] : "";
                var plantName = plantMaster.ContainsKey(po.Plant ?? "") ? plantMaster[po.Plant!] : po.Plant;

                // Xác định tháng dựa vào Vendor Last CF hoặc NEC Date
                DateTime? monthDate = null;
                if (!string.IsNullOrEmpty(po.VendorLastCF) &&
                    po.VendorLastCF != "TBA" &&
                    po.VendorLastCF != "00-00-00" &&
                    DateTime.TryParse(po.VendorLastCF, out DateTime vendorCF))
                {
                    monthDate = vendorCF;
                }
                else
                {
                    monthDate = po.NECDate;
                }

                // ETA by Sea
                DateTime? etaBySea = null;
                if (po.ShippingMode == "SEA" && !string.IsNullOrEmpty(po.ETAPSNV_VendorLastCF) &&
                    DateTime.TryParse(po.ETAPSNV_VendorLastCF, out DateTime etaDate))
                {
                    etaBySea = etaDate;
                }

                // Freight Unit
                decimal freightUnit = 0;
                if (!string.IsNullOrEmpty(vendor) && vendorMaster.ContainsKey(vendor))
                {
                    decimal.TryParse(vendorMaster[vendor], out freightUnit);
                }

                // GW Air Logic:
                // Lấy GWAir nếu AIR hoặc (blank + ShortLT < 0), không lấy nếu SEA
                decimal? gwAir = null;
                var shippingMode = po.ShippingMode?.ToUpper();
                var shippingModeAfter = po.ShippingMode_AfterJudgement?.ToUpper();
                int? shortLT = null;
                if (int.TryParse(po.ShortLT, out int parsedShortLT))
                {
                    shortLT = parsedShortLT;
                }

                if (shippingMode == "AIR")
                {
                    gwAir = po.GWAir;
                }
                else if (shippingModeAfter == "AIR")
                {
                    gwAir = po.GWAir;
                }
                else if (string.IsNullOrEmpty(shippingModeAfter) && shortLT.HasValue && shortLT.Value < 0)
                {
                    gwAir = po.GWAir;
                }
                // else: SEA -> gwAir = null

                // Total Freight
                decimal? totalFreight = gwAir.HasValue ? gwAir.Value * freightUnit : null;

                airCostData.Add(new AirCostRow
                {
                    Vendor = vendor,
                    Maker = maker,
                    Plant = plantName,
                    Material = po.Material,
                    ShortText = po.ShortText,
                    NecDate = po.NECDate,
                    MonthDate = monthDate,
                    GWAir = gwAir,
                    FreightUnit = freightUnit,
                    TotalFreight = totalFreight,
                    ETABySea = etaBySea
                });
            }

            // Process PR
            foreach (var pr in filteredPR)
            {
                var vendor = pr.FixVendor ?? "";
                var makerKey = $"{pr.Material}_{vendor}";
                var maker = partMaster.ContainsKey(makerKey) ? partMaster[makerKey] : "";
                var plantName = plantMaster.ContainsKey(pr.Plant ?? "") ? plantMaster[pr.Plant!] : pr.Plant;

                // Tháng dựa vào Deliv Date
                DateTime? monthDate = pr.DelivDate;

                // ETA by Sea = Next Tuesday (từ ngày hiện tại) + Leadtime
                DateTime? etaBySea = null;
                if (pr.Leadtime.HasValue)
                {
                    var todayT = DateTime.Today;
                    // Tìm thứ Ba tiếp theo từ ngày hiện tại
                    var nextTuesday = todayT;
                    while (nextTuesday.DayOfWeek != DayOfWeek.Tuesday)
                    {
                        nextTuesday = nextTuesday.AddDays(1);
                    }
                    // Nếu hôm nay là thứ Ba, lấy thứ Ba tuần sau
                    if (todayT.DayOfWeek == DayOfWeek.Tuesday)
                    {
                        nextTuesday = nextTuesday.AddDays(7);
                    }
                    etaBySea = nextTuesday.AddDays(pr.Leadtime.Value);
                }

                // Freight Unit
                decimal freightUnit = 0;
                if (!string.IsNullOrEmpty(vendor) && vendorMaster.ContainsKey(vendor))
                {
                    decimal.TryParse(vendorMaster[vendor], out freightUnit);
                }

                // GW Air - PR đã được filter ShortLT < 0 nên lấy luôn
                decimal? gwAir = pr.GWAir;

                // Total Freight
                decimal? totalFreight = gwAir.HasValue ? gwAir.Value * freightUnit : null;

                airCostData.Add(new AirCostRow
                {
                    Vendor = vendor,
                    Maker = maker,
                    Plant = plantName,
                    Material = pr.Material,
                    ShortText = pr.ShortText,
                    NecDate = pr.DelivDate,
                    MonthDate = monthDate,
                    GWAir = gwAir,
                    FreightUnit = freightUnit,
                    TotalFreight = totalFreight,
                    ETABySea = etaBySea
                });
            }

            // ========== GROUP BY MONTH ==========
            var today = DateTime.Today;
            var monthGroups = airCostData
                .Where(x => x.MonthDate.HasValue)
                .GroupBy(x => new DateTime(x.MonthDate.Value.Year, x.MonthDate.Value.Month, 1))
                .OrderBy(x => x.Key)
                .ToList();

            // Nếu không có data thì tạo header rỗng
            if (!monthGroups.Any())
            {
                ws.Cell(1, 1).Value = "No data available";
                return;
            }

            // ========== MÀU SO LE CHO CÁC THÁNG ==========
            var monthHeaderColors = new[]
            {
                XLColor.FromArgb(237, 125, 49),   // cam
                XLColor.FromArgb(91, 155, 213)    // xanh
            };
            var monthSubColors = new[]
            {
                XLColor.FromArgb(248, 203, 173),  // cam nhạt
                XLColor.FromArgb(189, 215, 238)   // xanh nhạt
            };
            var monthFillColors = new[]
            {
                XLColor.FromArgb(252, 228, 214),  // cam rất nhạt
                XLColor.FromArgb(222, 235, 247)   // xanh rất nhạt
            };

            // ========== CREATE HEADER ==========
            int currentCol = 1;

            // Cột cố định
            var fixedHeaders = new[] { "Vendor", "Maker", "Plant", "Material", "Short text", "Nec.date/Deliv.date" };
            foreach (var header in fixedHeaders)
            {
                ws.Cell(1, currentCol).Value = header;
                ws.Range(1, currentCol, 2, currentCol).Merge();
                ws.Cell(1, currentCol).Style.Font.Bold = true;
                ws.Cell(1, currentCol).Style.Fill.BackgroundColor = XLColor.FromArgb(237, 125, 49);
                ws.Cell(1, currentCol).Style.Font.FontColor = XLColor.White;
                ws.Cell(1, currentCol).Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                ws.Cell(1, currentCol).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                ws.Cell(1, currentCol).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                currentCol++;
            }

            // Header động cho từng tháng (7 cột mỗi tháng) - so le màu
            for (int m = 0; m < monthGroups.Count; m++)
            {
                var monthGroup = monthGroups[m];
                var headerColor = monthHeaderColors[m % 2];
                var subColor = monthSubColors[m % 2];

                var displayMonth = monthGroup.Key.ToString("MMM-yy", System.Globalization.CultureInfo.InvariantCulture);

                // Header tháng (merge 7 cột)
                ws.Cell(1, currentCol).Value = displayMonth;
                ws.Range(1, currentCol, 1, currentCol + 6).Merge();
                ws.Cell(1, currentCol).Style.Font.Bold = true;
                ws.Cell(1, currentCol).Style.Fill.BackgroundColor = headerColor;
                ws.Cell(1, currentCol).Style.Font.FontColor = XLColor.White;
                ws.Cell(1, currentCol).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;

                // Sub headers (7 cột)
                var subHeaders = new[] {
                    "GW air",
                    "Freight unit",
                    "Total freight",
                    "ETA date by sea",
                    "Model affect if arrange by sea",
                    "Affect sale if arrange by sea (qty)",
                    "Affect sale if arrange by sea (amt)"
                };
                for (int i = 0; i < subHeaders.Length; i++)
                {
                    ws.Cell(2, currentCol + i).Value = subHeaders[i];
                    ws.Cell(2, currentCol + i).Style.Font.Bold = true;
                    ws.Cell(2, currentCol + i).Style.Fill.BackgroundColor = subColor;
                    ws.Cell(2, currentCol + i).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    ws.Cell(2, currentCol + i).Style.Alignment.WrapText = true;
                    ws.Cell(2, currentCol + i).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                }

                currentCol += 7;
            }

            var lastCol = currentCol - 1;

            // Border cho header
            ws.Range(1, 1, 2, lastCol).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            ws.Range(1, 1, 2, lastCol).Style.Border.InsideBorder = XLBorderStyleValues.Thin;

            // ========== SUMMARY ROW (Sum Total) ==========
            int row = 3;
            ws.Cell(row, 1).Value = "";
            ws.Range(row, 1, row, 6).Merge();
            ws.Cell(row, 1).Style.Fill.BackgroundColor = XLColor.FromArgb(255, 242, 204);

            currentCol = 7;
            for (int m = 0; m < monthGroups.Count; m++)
            {
                var monthGroup = monthGroups[m];
                var fillColor = monthFillColors[m % 2];

                var totalGW = monthGroup.Where(x => x.GWAir.HasValue).Sum(x => x.GWAir!.Value);
                var totalFreight = monthGroup.Where(x => x.TotalFreight.HasValue).Sum(x => x.TotalFreight!.Value);

                // Fill background cho cả 7 cột của tháng
                for (int i = 0; i < 7; i++)
                {
                    ws.Cell(row, currentCol + i).Style.Fill.BackgroundColor = fillColor;
                }

                // Sum GW Air
                ReflectionHelper.SetNumberCell(ws, row, currentCol, totalGW.ToString());
                ws.Cell(row, currentCol).Style.Font.Bold = true;

                // Sum Total Freight
                ReflectionHelper.SetNumberCell(ws, row, currentCol + 2, totalFreight.ToString());
                ws.Cell(row, currentCol + 2).Style.Font.Bold = true;

                currentCol += 7;
            }
            row++;

            // ========== DATA ROWS ==========
            foreach (var item in airCostData.OrderBy(x => x.MonthDate).ThenBy(x => x.Vendor))
            {
                ws.Cell(row, 1).Value = item.Vendor;
                ws.Cell(row, 2).Value = item.Maker;
                ws.Cell(row, 3).Value = item.Plant;
                ws.Cell(row, 4).Value = item.Material;
                ws.Cell(row, 5).Value = item.ShortText;
                ReflectionHelper.SetDateCell(ws, row, 6, item.NecDate);

                // Điền data vào tháng tương ứng
                if (item.MonthDate.HasValue)
                {
                    var itemMonth = new DateTime(item.MonthDate.Value.Year, item.MonthDate.Value.Month, 1);
                    var monthIndex = monthGroups.FindIndex(x => x.Key == itemMonth);

                    if (monthIndex >= 0)
                    {
                        var colStart = 7 + (monthIndex * 7);

                        // GW Air
                        if (item.GWAir.HasValue)
                            ReflectionHelper.SetNumberCell(ws, row, colStart, item.GWAir.Value.ToString());

                        // Freight Unit
                        ReflectionHelper.SetNumberCell(ws, row, colStart + 1, item.FreightUnit.ToString());

                        // Total Freight
                        if (item.TotalFreight.HasValue)
                            ReflectionHelper.SetNumberCell(ws, row, colStart + 2, item.TotalFreight.Value.ToString());

                        // ETA date by sea
                        ReflectionHelper.SetDateCell(ws, row, colStart + 3, item.ETABySea);

                        // Model affect if arrange by sea - để trống
                        ws.Cell(row, colStart + 4).Value = "";

                        // Affect sale if arrange by sea (qty) - để trống
                        ws.Cell(row, colStart + 5).Value = "";

                        // Affect sale if arrange by sea (amt) - để trống
                        ws.Cell(row, colStart + 6).Value = "";
                    }
                }

                // Tô nền so le cho toàn bộ vùng tháng của dòng này
                for (int m = 0; m < monthGroups.Count; m++)
                {
                    var colStartFill = 7 + (m * 7);
                    for (int i = 0; i < 7; i++)
                    {
                        ws.Cell(row, colStartFill + i).Style.Fill.BackgroundColor = monthFillColors[m % 2];
                    }
                }

                row++;
            }

            // Border cho data
            if (row > 4)
            {
                ws.Range(3, 1, row - 1, lastCol).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                ws.Range(3, 1, row - 1, lastCol).Style.Border.InsideBorder = XLBorderStyleValues.Thin;
            }

            ws.Columns().AdjustToContents();
            ws.Row(2).Height = 45;
        }
    }
}