using System.Text.Json.Serialization;
using Swms.FinishGoods.API.Features.Foss.DataAccess;

namespace Swms.FinishGoods.API.Features.Foss.Api;

/// <summary>
/// Một dòng serial trong pallet (list phẳng).
/// </summary>
public record FossPalletItemResponse(
    [property: JsonPropertyName("pallet_no")] string PalletNo,                  // Source_pallet
    [property: JsonPropertyName("box_no")] string BoxNo,                        // SERIAL_OUTER
    [property: JsonPropertyName("model_no")] string ModelNo,                    // sModelNo
    [property: JsonPropertyName("serial_no")] string SerialNo,                  // sSerialNo
    [property: JsonPropertyName("line")] string Line,                           // COD_SCALE_NO
    [property: JsonPropertyName("lot_name")] string LotName,                    // LotName
    [property: JsonPropertyName("production_date")] DateTime? ProductionDate,   // dShrinkDate
    [property: JsonPropertyName("shrink_by")] string? ShrinkBy,                 // dShrinkBy
    [property: JsonPropertyName("oqc_status")] byte? OQCStatus,                 // STATUS_FA
    [property: JsonPropertyName("date_insert")] DateTime? DateInsert)           // TBLPRODUCT_*.DATEINSERT
{
    public static FossPalletItemResponse From(FossPalletRow r)
        => new(
            r.PalletNo,
            r.BoxNo ?? r.SerialNo,
            r.ModelNo.EndsWith("-V4") ? r.ModelNo[..^3] : r.ModelNo,
            r.SerialNo,
            r.Line,
            r.LotName,
            r.ProductionDate,
            r.ShrinkBy,
            r.OQCStatus,
            r.DateInsert
            );
}
