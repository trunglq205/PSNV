﻿namespace Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;

/// <summary>
/// Một file tải về: bytes kèm tên file do SERVER đặt. Đặt ở feature này chứ
/// không nhét vào thư mục dùng chung — chưa có tính năng nào khác cần, mà sửa
/// file dùng chung thì dễ đụng nhánh của người khác.
/// </summary>
public sealed record FileDownload(string FileName, byte[] Bytes);

/// <summary>1 phiếu trong danh sách hàng bất thường.</summary>
public class NgReportSummaryDto
{
    public long Id { get; set; }
    public string DocNo { get; set; } = string.Empty;
    public long? LotId { get; set; }
    public string? PalletCode { get; set; }
    public string? Model { get; set; }
    public string NgType { get; set; } = string.Empty;
    public DateTime DiscoveredAt { get; set; }
    public string DocStatus { get; set; } = string.Empty;
    public string CurrentStep { get; set; } = string.Empty;
    public string LeaderStatus { get; set; } = string.Empty;
    public string FaStatus { get; set; } = string.Empty;

    /// <summary>Kết luận của FA — ok | ng | null (chưa đánh giá vòng này).</summary>
    public string? FaResult { get; set; }

    /// <summary>Hướng xử lý FA chọn khi kết luận NG.</summary>
    public string? FaResolution { get; set; }

    /// <summary>Vòng đánh giá OQC ⇄ FA thứ mấy. Bắt đầu từ 1.</summary>
    public int ReviewRound { get; set; } = 1;
    public string OqcStatus { get; set; } = string.Empty;
    public string Resolution { get; set; } = string.Empty;

    /// <summary>FA đề xuất Accept nhưng OQC kết luận NG — phiếu dừng lại chờ FA chỉnh.</summary>

    public int ItemCount { get; set; }
    public int QtyAffected { get; set; }
    public int PhotoCount { get; set; }
    public string? CreatedBy { get; set; }

    /// <summary>
    /// Mọi mục phạm vi đều là cả pallet ⟹ hiện "cả pallet" thay vì "1 cái".
    /// Server tính, client chỉ hiển thị.
    /// </summary>
    public bool IsWholePallet { get; set; }
}

public class NgItemDto
{
    public long Id { get; set; }
    public string Scope { get; set; } = string.Empty;   // pallet | box | serial
    public string? Code { get; set; }
    public int QtyAffected { get; set; }
    public string? Note { get; set; }
}

public class NgPhotoDto
{
    public long Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string? Caption { get; set; }
    public int SortOrder { get; set; }
}

public class NgApprovalDto
{
    public long Id { get; set; }
    public string Step { get; set; } = string.Empty;
    public string Action { get; set; } = string.Empty;
    public string? Resolution { get; set; }
    public string? Comment { get; set; }
    public string? ActedBy { get; set; }
    public DateTime ActedAt { get; set; }
}

public class NgReportDetailDto
{
    public NgReportSummaryDto Header { get; set; } = new();
    public string? Description { get; set; }

    public string? LeaderBy { get; set; }
    public DateTime? LeaderAt { get; set; }
    public string? LeaderComment { get; set; }

    public string? FaBy { get; set; }
    public DateTime? FaAt { get; set; }
    public string? FaComment { get; set; }

    public string? OqcBy { get; set; }
    public DateTime? OqcAt { get; set; }
    public string? OqcComment { get; set; }

    public string? FinalizedBy { get; set; }
    public DateTime? FinalizedAt { get; set; }
    public string? FinalComment { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    public List<NgItemDto> Items { get; set; } = new();
    public List<NgPhotoDto> Photos { get; set; } = new();
    public List<NgApprovalDto> Approvals { get; set; } = new();

    /// <summary>
    /// Server tự so: người đang xem CHÍNH LÀ người đã duyệt bước 2.
    /// Chỉ để hiện cảnh báo ở bước chốt, KHÔNG chặn — vẫn chốt được, và phiếu
    /// lưu riêng leader_by / finalized_by nên truy lại được ai làm bước nào.
    /// </summary>
    public bool LeaderIsMe { get; set; }
}

public class LeaderReviewRequestDto
{
    /// <summary>submit = duyệt, cancel = huỷ phiếu.</summary>
    public string Action { get; set; } = "submit";
    public string? Comment { get; set; }
}

public class FaConfirmRequestDto
{
    /// <summary>ok | ng</summary>
    public string Result { get; set; } = string.Empty;

    /// <summary>replace | accept | return | scrap. BẮT BUỘC khi Result = ng.</summary>
    public string? Resolution { get; set; }
    public string? Comment { get; set; }
}

/// <summary>FA báo đã xử lý xong lượt NG — hàng quay lại OQC đánh giá lại.</summary>
public class FaFixDoneRequestDto
{
    public string? Comment { get; set; }
}

public class OqcConfirmRequestDto
{
    /// <summary>ok | ng</summary>
    public string Result { get; set; } = string.Empty;
    public string? Comment { get; set; }
}

// FinalizeRequestDto (SCS Supervisor chốt) đã BỎ 23/11 — phiếu tự đóng khi
// OQC và FA cùng kết luận OK.

/// <summary>1 phạm vi ảnh hưởng khi sửa phiếu nháp.</summary>
public class NgItemInputDto
{
    public string Scope { get; set; } = "serial";
    public string? Code { get; set; }
    public int? QtyAffected { get; set; }
    public string? Note { get; set; }
}

/// <summary>Sửa phiếu nháp — danh sách gửi lên thay cho danh sách cũ.</summary>
public class UpdateNgReportRequestDto
{
    public string NgType { get; set; } = string.Empty;
    public string? Description { get; set; }
    public List<NgItemInputDto> Items { get; set; } = new();
}

/// <summary>1 người sẽ nhận mail bước 2. <see cref="Type"/> là TO | CC | BCC.</summary>
public class MailPreviewRecipientDto
{
    public string Type { get; set; } = "TO";
    public string Email { get; set; } = string.Empty;
    public string? DisplayName { get; set; }
}

/// <summary>
/// Duyệt xong sẽ gửi mail cho ai. Ba cờ chứ không chỉ danh sách: mail không
/// tới nơi vì ba lý do khác nhau (chưa khai người nhận / mẫu mail rỗng / đang
/// tắt gửi), và người duyệt cần biết là lý do nào.
/// </summary>
public class MailPreviewDto
{
    public string? CategoryCode { get; set; }
    public string? CategoryName { get; set; }
    public string? Model { get; set; }
    public bool MailEnabled { get; set; }

    /// <summary>
    /// Nhãn cate để hiện: tên nếu có, không thì quay về mã. Cate chưa khai
    /// trong master.categories vẫn phải hiện được cái gì đó — để trống thì
    /// người duyệt không biết mail đang lọc theo cate nào.
    /// </summary>
    public string? CategoryLabel =>
        string.IsNullOrWhiteSpace(CategoryName) ? CategoryCode : CategoryName;
    public bool TemplateReady { get; set; }
    public List<MailPreviewRecipientDto> Recipients { get; set; } = new();

    /// <summary>
    /// Không ai ở TO = không ai được yêu cầu xử lý. Phải kiểm TO chứ KHÔNG
    /// kiểm tổng số người nhận: người duyệt luôn được thêm vào CC nên tổng số
    /// không bao giờ bằng 0, kiểm tổng số sẽ che mất đúng cái lỗi cần báo.
    /// </summary>
    public bool HasNoActionRecipient => !Of("TO").Any();

    public IEnumerable<MailPreviewRecipientDto> Of(string type)
        => Recipients.Where(r => string.Equals(r.Type, type, StringComparison.OrdinalIgnoreCase));
}

/// <summary>
/// Một loại lỗi lấy từ master.ng_types. <see cref="Name"/> và <see cref="Note"/>
/// đã được API dịch theo ngôn ngữ, màn hình cứ hiện thẳng — không còn tra resx
/// theo mã nữa, nên thêm loại lỗi mới không phải build lại Web.
/// </summary>
public class NgTypeDto
{
    public string Code { get; set; } = string.Empty;
    public string Name { get; set; } = string.Empty;
    public string? Note { get; set; }
    public bool RequiresOqc { get; set; }
}

/// <summary>
/// Một loại lỗi ở màn quản trị — thô cả 4 ngôn ngữ, khác <see cref="NgTypeDto"/>
/// vốn đã được server dịch sẵn theo ngôn ngữ app.
/// </summary>
public class NgTypeAdminDto
{
    public string Code { get; set; } = string.Empty;

    public string NameVi { get; set; } = string.Empty;
    public string? NameEn { get; set; }
    public string? NameJa { get; set; }
    public string? NameZh { get; set; }

    public string? NoteVi { get; set; }
    public string? NoteEn { get; set; }
    public string? NoteJa { get; set; }
    public string? NoteZh { get; set; }

    public bool RequiresOqc { get; set; } = true;
    public int SortOrder { get; set; } = 100;
    public bool IsActive { get; set; } = true;

    /// <summary>Số phiếu đang mang mã này. Lớn hơn 0 thì không xoá được.</summary>
    public int UsedByReports { get; set; }

    /// <summary>Bản sao để sửa trong form mà không đụng dòng đang hiện trên bảng.</summary>
    public NgTypeAdminDto Clone() => (NgTypeAdminDto)MemberwiseClone();
}

/// <summary>Thân request thêm/sửa loại lỗi. Khớp SaveNgTypeRequest bên API.</summary>
public class SaveNgTypeRequestDto
{
    public string Code { get; set; } = string.Empty;
    public string NameVi { get; set; } = string.Empty;
    public string? NameEn { get; set; }
    public string? NameJa { get; set; }
    public string? NameZh { get; set; }
    public string? NoteVi { get; set; }
    public string? NoteEn { get; set; }
    public string? NoteJa { get; set; }
    public string? NoteZh { get; set; }
    public bool RequiresOqc { get; set; } = true;
    public int SortOrder { get; set; } = 100;
    public bool IsActive { get; set; } = true;
}
