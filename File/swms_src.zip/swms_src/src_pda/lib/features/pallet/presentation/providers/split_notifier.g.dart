// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'split_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Tách pallet. Family theo lot_no gốc; thùng lấy từ [palletProvider].
/// Loading/error của API do `appActionProvider` lo.

@ProviderFor(SplitNotifier)
final splitProvider = SplitNotifierFamily._();

/// Tách pallet. Family theo lot_no gốc; thùng lấy từ [palletProvider].
/// Loading/error của API do `appActionProvider` lo.
final class SplitNotifierProvider
    extends $NotifierProvider<SplitNotifier, SplitState> {
  /// Tách pallet. Family theo lot_no gốc; thùng lấy từ [palletProvider].
  /// Loading/error của API do `appActionProvider` lo.
  SplitNotifierProvider._({
    required SplitNotifierFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'splitProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$splitNotifierHash();

  @override
  String toString() {
    return r'splitProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  SplitNotifier create() => SplitNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(SplitState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<SplitState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is SplitNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$splitNotifierHash() => r'e5c748860830d70e054392e45e4b34d73c75d222';

/// Tách pallet. Family theo lot_no gốc; thùng lấy từ [palletProvider].
/// Loading/error của API do `appActionProvider` lo.

final class SplitNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          SplitNotifier,
          SplitState,
          SplitState,
          SplitState,
          String
        > {
  SplitNotifierFamily._()
    : super(
        retry: null,
        name: r'splitProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Tách pallet. Family theo lot_no gốc; thùng lấy từ [palletProvider].
  /// Loading/error của API do `appActionProvider` lo.

  SplitNotifierProvider call(String lotNo) =>
      SplitNotifierProvider._(argument: lotNo, from: this);

  @override
  String toString() => r'splitProvider';
}

/// Tách pallet. Family theo lot_no gốc; thùng lấy từ [palletProvider].
/// Loading/error của API do `appActionProvider` lo.

abstract class _$SplitNotifier extends $Notifier<SplitState> {
  late final _$args = ref.$arg as String;
  String get lotNo => _$args;

  SplitState build(String lotNo);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<SplitState, SplitState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<SplitState, SplitState>,
              SplitState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
