﻿namespace SWMS_WebTool.Models.Responses
{
    public class ApiResponseData
    {
        public string? status { get; set; }
        public object? data { get; set; }
        public string? message { get; set; }
    }
}
