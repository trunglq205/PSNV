﻿namespace Swms.FinishGoods.API.Shared.Reporting;

/// <summary>Một cột trong bảng báo cáo (library-agnostic).</summary>
public sealed class ReportColumn<T>
{
    public string Header { get; init; } = string.Empty;
    public Func<T, object?> Value { get; init; } = _ => null;
    public bool Numeric { get; init; }
    public double? Width { get; init; }
    /// <summary>Định dạng số (vd "0.####", "#,0"). Bỏ trống = mặc định.</summary>
    public string? NumberFormat { get; init; }
}

/// <summary>Mô tả 1 báo cáo dạng bảng: tiêu đề + meta + summary + bảng.</summary>
public sealed class ExcelTableReport<T>
{
    public string SheetName { get; init; } = "Report";
    public string Title { get; init; } = string.Empty;
    public IReadOnlyList<(string Key, string Value)> Meta { get; init; } = Array.Empty<(string, string)>();
    public IReadOnlyList<(string Key, string Value)> Summary { get; init; } = Array.Empty<(string, string)>();
    public IReadOnlyList<ReportColumn<T>> Columns { get; init; } = Array.Empty<ReportColumn<T>>();
    public IReadOnlyList<T> Rows { get; init; } = Array.Empty<T>();

    /// <summary>
    /// Số cột đầu ghim lại khi cuộn ngang. 0 = không ghim (mặc định, giữ đúng
    /// cách cũ). Bảng rộng mới cần: cuộn sang cột thứ 20 mà mất cột số phiếu
    /// thì không biết mình đang đọc dòng của phiếu nào. Hàng tiêu đề luôn được
    /// ghim, không phụ thuộc thuộc tính này.
    /// </summary>
    public int FreezeColumns { get; init; }
}

/// <summary>Sinh file Excel (.xlsx). Triển khai hiện tại: ClosedXML (MIT).</summary>
public interface IExcelReportBuilder
{
    byte[] BuildTable<T>(ExcelTableReport<T> report);
}
