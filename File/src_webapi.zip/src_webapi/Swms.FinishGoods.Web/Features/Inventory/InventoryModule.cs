// Features/Inventory/InventoryModule.cs
using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.Inventory.Business;
using Swms.FinishGoods.Web.Features.Inventory.Client;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.Inventory;

public static class InventoryModule
{
    public static IServiceCollection AddInventoryFeature(this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<IInventoryApi>(api);
        services.AddScoped<IInventoryBusiness, InventoryBusiness>();
        services.AddSingleton<StockEventCatalog>();

        return services;
    }
}
