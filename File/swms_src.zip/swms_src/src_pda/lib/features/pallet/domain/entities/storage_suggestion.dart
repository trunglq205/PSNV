import 'package:flutter/foundation.dart';

class ModelMasterConfig {
  const ModelMasterConfig({
    this.areaId,
    this.areaCode,
    this.rackRows = const [],
  });

  /// FK -> `master.warehouse_areas(id)`. Đây là giá trị PATCH cần, không phải
  /// [areaCode] — mã khu đổi được, id thì không.
  final int? areaId;

  final String? areaCode;

  /// Nội dung cột `suggest_rack_row` đã parse, vd [2, 3].
  final List<int> rackRows;

  bool get hasArea => areaId != null;
  bool get hasRackRows => rackRows.isNotEmpty;
  bool get isEmpty => !hasArea && !hasRackRows;
}

/// Chiến lược server dùng để ra gợi ý — hiển thị cho operator biết độ tin cậy.
enum SuggestionStrategy {
  /// Model có khai khu + tầng trong master, lại có lot cùng model đã lưu.
  masterAndLastLot,

  /// Model có khai master nhưng chưa có lot nào cùng model để bám.
  masterOnly,

  /// Model chưa khai master — chọn tầng theo chiều cao pallet.
  heightAndLastLot,

  /// Không có lot cùng model — bám lot cùng danh mục.
  categoryLastLot,

  /// Không có mốc nào — vị trí trống bất kỳ.
  random,

  /// Giá trị lạ từ server (tránh crash khi backend thêm chiến lược mới).
  unknown;

  static SuggestionStrategy fromApi(String? raw) => switch (raw) {
    'master_and_last_lot' => SuggestionStrategy.masterAndLastLot,
    'master_only' => SuggestionStrategy.masterOnly,
    'height_and_last_lot' => SuggestionStrategy.heightAndLastLot,
    'category_last_lot' => SuggestionStrategy.categoryLastLot,
    'random' => SuggestionStrategy.random,
    _ => SuggestionStrategy.unknown,
  };
}

/// Last lot được tìm theo model hay chỉ theo danh mục.
enum LastLotMatchedBy {
  model,
  category,
  unknown;

  static LastLotMatchedBy fromApi(String? raw) => switch (raw) {
    'model' => LastLotMatchedBy.model,
    'category' => LastLotMatchedBy.category,
    _ => LastLotMatchedBy.unknown,
  };
}

/// Giá trị cột `slot_kind` — `shelf` là giá lửng.
class SlotKinds {
  const SlotKinds._();
  static const String shelf = 'shelf';
}

/// Bản sao quy tắc chiều cao của server (`PalletHeightRule` bên API core).
///
/// App KHÔNG tự quyết vị trí — server mới là nơi chọn. Bản sao này chỉ để
/// dialog bổ sung thông tin hiển thị/suy tầng cho khớp với cái server sẽ trả,
/// tránh cảnh "dialog bảo tầng 2 mà gợi ý ra tầng 1".
///
/// ⚠ Đổi ngưỡng thì phải đổi cả 3 nơi: `PalletHeightRule` (API),
/// `CK_models_suggest_rack_row` (DDL) và class này.
class PalletHeightRule {
  const PalletHeightRule._();

  static const int shelfMaxCm = 70;
  static const int row23MaxCm = 135;
  static const int row1MaxCm = 155;
  static const int topRow = 4;

  /// Tổng số tầng của rack thường — dùng dựng danh sách chọn tầng.
  static const List<String> allFloors = ['1', '2', '3', '4'];

  static bool isShelf(int heightCm) =>
      heightCm > 0 && heightCm <= shelfMaxCm;

  /// Tập tầng server sẽ nhắm tới. Rỗng = giá lửng hoặc không biết chiều cao.
  static List<int> rackRowsFor(int heightCm) {
    if (heightCm <= 0 || heightCm <= shelfMaxCm) return const [];
    if (heightCm <= row23MaxCm) return const [2, 3];
    if (heightCm <= row1MaxCm) return const [1];
    return const [topRow];
  }

  /// Nhãn tầng cho `showStorageInfoDialog(inferFloor: ...)`.
  /// Trả `null` khi chiều cao không hợp lệ (dialog dùng để chặn nút Xác nhận).
  static String? floorLabel(int heightCm) {
    if (heightCm <= 0) return null;
    if (isShelf(heightCm)) return SlotKinds.shelf;
    return '${rackRowsFor(heightCm).first}';
  }
}

/// Một vị trí ứng viên do server gợi ý.
@immutable
class SuggestedLocator {
  final int locatorId;
  final String locatorCode;
  final String? rackCode;

  /// Tầng rack (1..4). Null với ô giá lửng.
  final int? rackRow;

  /// 'A' | 'B' với ô giá lửng; null với rack thường.
  final String? rackLevel;

  final String? slotKind;

  const SuggestedLocator({
    required this.locatorId,
    required this.locatorCode,
    this.rackCode,
    this.rackRow,
    this.rackLevel,
    this.slotKind,
  });

  bool get isShelf => slotKind == SlotKinds.shelf;
}

/// Vị trí lot gần nhất cùng model / cùng danh mục — mốc mà gợi ý bám theo.
@immutable
class LastLotLocation {
  final String lotNo;
  final String locatorCode;
  final String? rackCode;
  final int? rackRow;
  final LastLotMatchedBy matchedBy;

  const LastLotLocation({
    required this.lotNo,
    required this.locatorCode,
    required this.matchedBy,
    this.rackCode,
    this.rackRow,
  });
}

/// Kết quả `GET /api/pallets/by-lot-no/{lotNo}/storage-suggestion`.
@immutable
class StorageSuggestion {
  final String lotNo;
  final String? model;
  final SuggestionStrategy strategy;

  final String? suggestedAreaCode;
  final String? suggestedAreaName;

  /// Tầng gợi ý, vd [2, 3]. Rỗng = không ràng buộc tầng.
  final List<int> suggestedRackRows;

  /// `shelf` khi pallet thấp. Null = không ràng buộc loại ô.
  final String? suggestedSlotKind;

  final SuggestedLocator? suggestedLocator;
  final List<SuggestedLocator> alternatives;
  final LastLotLocation? lastLot;

  /// Cảnh báo mềm, server đã dịch sẵn theo Accept-Language.
  final List<String> warnings;

  /// Cấu hình master hiện có của model. Null = model chưa có trong
  /// master.models. Dùng để quyết định hiện tab khai master và chọn sẵn ô.
  final ModelMasterConfig? master;

  const StorageSuggestion({
    required this.lotNo,
    required this.strategy,
    this.model,
    this.suggestedAreaCode,
    this.suggestedAreaName,
    this.suggestedRackRows = const [],
    this.suggestedSlotKind,
    this.suggestedLocator,
    this.alternatives = const [],
    this.lastLot,
    this.master,
    this.warnings = const [],
  });

  /// Hết chỗ trống thì server vẫn trả 200 nhưng `suggestedLocator` = null.
  bool get hasLocator => suggestedLocator != null;

  bool get wantsShelf => suggestedSlotKind == SlotKinds.shelf;

  bool get hasWarning => warnings.isNotEmpty;
}