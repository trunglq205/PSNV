using Swms.FinishGoods.API.Features.Shortages.Api;

namespace Swms.FinishGoods.API.Features.Shortages.Business;

/// <summary>Gửi mail thật. Bản mặc định chỉ ghi log — thay bằng SMTP / Graph / hàng đợi
/// của hệ thống bạn, rồi đổi đăng ký trong ShortageModule.</summary>
public interface IShortageMailSender
{
    Task SendAsync(IReadOnlyList<RecipientResponse> recipients, string subject, string body, CancellationToken ct = default);
}

public class LoggingShortageMailSender : IShortageMailSender
{
    private readonly ILogger<LoggingShortageMailSender> _logger;
    public LoggingShortageMailSender(ILogger<LoggingShortageMailSender> logger) => _logger = logger;

    public Task SendAsync(IReadOnlyList<RecipientResponse> recipients, string subject, string body, CancellationToken ct = default)
    {
        _logger.LogInformation(
            "[Shortage mail — chưa gửi thật] TO: {To} | CC: {Cc} | {Subject}",
            string.Join(", ", recipients.Where(r => r.Type == "TO").Select(r => r.Email)),
            string.Join(", ", recipients.Where(r => r.Type == "CC").Select(r => r.Email)),
            subject);
        return Task.CompletedTask;
    }
}
