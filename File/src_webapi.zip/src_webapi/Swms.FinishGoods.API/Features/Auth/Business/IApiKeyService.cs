﻿using Swms.FinishGoods.API.Features.Auth.Api;

namespace Swms.FinishGoods.API.Features.Auth.Business
{
    public interface IApiKeyService
    {
        Task<ApiKeyIssuedResponse> CreateAsync(CreateApiKeyRequest request, string? createdBy);
        Task<ApiKeyIssuedResponse> RotateAsync(long id, string? createdBy);
        Task RevokeAsync(long id, string? by);
        Task<IReadOnlyList<ApiKeyInfo>> ListAsync();
    }
}
