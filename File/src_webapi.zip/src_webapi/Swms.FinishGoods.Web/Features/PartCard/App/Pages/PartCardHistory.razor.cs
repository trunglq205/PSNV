using System.Globalization;
using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Primitives;
using Swms.FinishGoods.Web.Features.PartCard.Business;
using Swms.FinishGoods.Web.Features.PartCard.Business.Models;
using Swms.FinishGoods.Web.Shared.App.Components;
using Swms.FinishGoods.Web.Shared.App.Layout;
using Swms.FinishGoods.Web.Shared.App.Model;
using Swms.FinishGoods.Web.Shared.App.Toast;

namespace Swms.FinishGoods.Web.Features.PartCard.App.Pages;

// Màn Lịch sử in Part Card — dựng theo khung màn Tồn kho (Inventories):
// ListPageBase lo search / filter / URL / phân trang; file này chỉ viết phần đặc thù.
//
//   • Tab đầu trang: Tất cả + mỗi Category SP 1 tab (click = lọc theo category),
//     riêng F/G và SUB GOM mỗi loại thành 1 tab (click = lọc theo master.categories.product).
//   • Toolbar: search đa phạm vi + select Loại phiếu (thường / oversea) + khoảng ngày in / ngày SX
//     (KHÔNG dùng panel lọc nâng cao của ListPageBase — mọi bộ lọc nằm thẳng trên toolbar)
//   • Bảng → dialog chi tiết (sửa kích thước, xem inner box/OQC) · In lại · Xoá · Export CSV
public partial class PartCardHistory
{
    [Inject] private IPartCardBusiness Business { get; set; } = default!;
    [Inject] private ToastService Toast { get; set; } = default!;

    // ── State đặc thù — đồng bộ URL ──
    private string _type = "";       // "" | normal | oversea  (select Loại phiếu ở toolbar)
    private string _category = "";   // tab đang chọn: "" = Tất cả, còn lại = mã category dạng chuỗi
    private string _product = "";    // tab gom đang chọn: "" = không lọc, còn lại = master.categories.product (F/G, SUB)

    // Khoảng ngày in / ngày SX: chuỗi yyyy-MM-dd (dạng nằm trên URL), "" = không lọc.
    private string _printedFrom = "", _printedTo = "";
    private string _prodFrom = "", _prodTo = "";

    // Tên tham số trên URL của 2 khoảng ngày (mỗi khoảng 2 đầu).
    private const string QPrintedFrom = "printedFrom";
    private const string QPrintedTo = "printedTo";
    private const string QProdFrom = "prodFrom";
    private const string QProdTo = "prodTo";

    private List<CategoryOptionDto> _categoryOptions = new();

    // ── Tab: category hiện riêng + loại hàng gom ──
    // Loại hàng nằm trong danh sách này KHÔNG tách từng category mà gom thành 1 tab,
    // theo đúng thứ tự khai báo. Mọi category còn lại (SP…) vẫn mỗi category 1 tab.
    private static readonly string[] MergedProducts = { "FG", "SUB" };

    // Key: product đã chuẩn hoá (so sánh); Product: giá trị gốc trong DB (hiển thị + gửi API);
    // Tooltip: các category nằm trong tab gom.
    private sealed record ProductTab(string Key, string Product, string Tooltip);

    private List<CategoryOptionDto> _categoryTabs = new();
    private List<ProductTab> _productTabs = new();

    // "F/G", "FG", " f/g " → "FG": DB đang lưu "F/G" nhưng không phụ thuộc cách viết.
    private static string ProductKey(string? product)
        => (product ?? "").Trim().ToUpperInvariant().Replace("/", "");

    private void BuildTabs()
    {
        _categoryTabs = _categoryOptions
            .Where(c => !MergedProducts.Contains(ProductKey(c.Product)))
            .ToList();

        _productTabs = new();
        foreach (var key in MergedProducts)
        {
            var items = _categoryOptions.Where(c => ProductKey(c.Product) == key).ToList();
            if (items.Count == 0) continue;
            _productTabs.Add(new ProductTab(
                key,
                items[0].Product!.Trim(),
                string.Join(", ", items.Select(c => $"{c.Code} {c.Name}"))));
        }
    }

    private const string TypeNormal = "normal";
    private const string TypeOversea = "oversea";

    private const string IcScopePo = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z'/><path d='M14 2v6h6M8 13h8M8 17h5'/></svg>";
    private const string IcScopeModel = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M20 7L12 3 4 7l8 4 8-4z'/><path d='M4 7v10l8 4 8-4V7'/><path d='M12 11v10'/></svg>";
    private const string IcScopePerson = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><circle cx='12' cy='8' r='4'/><path d='M4 21a8 8 0 0116 0'/></svg>";
    private const string IcScopeQr = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='3' y='3' width='7' height='7'/><rect x='14' y='3' width='7' height='7'/><rect x='3' y='14' width='7' height='7'/><path d='M14 14h3v3h-3zM20 14v.01M14 20h.01M17 20h4v-3'/></svg>";

    // ── (1) Search scopes ──
    // API khớp TIỀN TỐ cho PO / Model / người; QR là so khớp tuyệt đối cả payload.
    protected override IReadOnlyList<SearchScope> SearchScopes => new List<SearchScope>
    {
        new("po",      L["PartCardHistory.Search.Po.Title"],      L["PartCardHistory.Search.Po.Hint"],      IcScopePo,     L["PartCardHistory.Search.Po.Short"]),
        new("cusPo",   L["PartCardHistory.Search.CusPo.Title"],   L["PartCardHistory.Search.CusPo.Hint"],   IcScopePo,     L["PartCardHistory.Search.CusPo.Short"]),
        new("model",   L["PartCardHistory.Search.Model.Title"],   L["PartCardHistory.Search.Model.Hint"],   IcScopeModel,  L["PartCardHistory.Search.Model.Short"]),
        new("packer",  L["PartCardHistory.Search.Packer.Title"],  L["PartCardHistory.Search.Packer.Hint"],  IcScopePerson, L["PartCardHistory.Search.Packer.Short"]),
        new("checker", L["PartCardHistory.Search.Checker.Title"], L["PartCardHistory.Search.Checker.Hint"], IcScopePerson, L["PartCardHistory.Search.Checker.Short"]),
        new("qr",      L["PartCardHistory.Search.Qr.Title"],      L["PartCardHistory.Search.Qr.Hint"],      IcScopeQr,     L["PartCardHistory.Search.Qr.Short"]),
    };

    // ── (2) Không còn filter nâng cao: ngày in / ngày SX là state riêng của màn (DateRangePicker trên toolbar) ──
    protected override IReadOnlyList<ListFilterField> FilterFields => Array.Empty<ListFilterField>();

    // ── (3) Map state → query ──
    protected override PartCardQuery BuildQuery()
    {
        return new PartCardQuery
        {
            IsOverseaService = _type switch { TypeOversea => true, TypeNormal => false, _ => (bool?)null },
            Category = int.TryParse(_category, out var cat) ? cat : null,
            Product = _product != "" ? _product : null,
            IsLocked = LockFilterValue,

            PoNo = TryGetTerm("po", out var po) ? po : null,
            CustomerPoNo = TryGetTerm("cusPo", out var cpo) ? cpo : null,
            Model = TryGetTerm("model", out var mdl) ? mdl : null,
            Packer = TryGetTerm("packer", out var pk) ? pk : null,
            Checker = TryGetTerm("checker", out var ck) ? ck : null,
            Payload = TryGetTerm("qr", out var qr) ? qr : null,

            // API tự cộng 1 ngày cho đầu "đến" → chỉ cần gửi ngày, không cần cuối ngày.
            // Nhập ngược (từ > đến) không sao: API tự đảo lại.
            PrintedFrom = ToDate(_printedFrom),
            PrintedTo = ToDate(_printedTo),
            ProductionFrom = ToDate(_prodFrom),
            ProductionTo = ToDate(_prodTo),

            Page = Page,
            Size = PageSize,
        };
    }

    // ── (4) Tải trang ──
    protected override async Task<LoadOutcome<AppPartCardHistory>> LoadPageAsync(PartCardQuery query, CancellationToken ct)
    {
        var result = await Business.GetPrintHistoryAsync(query);
        if (!result.IsSuccess || result.Value == null)
            return LoadOutcome<AppPartCardHistory>.Fail(result.ErrorCode, result.ErrorMessage ?? L["PartCardHistory.Load.ListFailed"]);

        // API có thể trả Items = null → ép về rỗng (cùng lý do với dialog cũ).
        IReadOnlyList<AppPartCardHistory> items = (result.Value.Items ?? new List<PartCardDto>())
            .Select(AppPartCardHistory.From)
            .ToList();
        RefreshSelected(items);
        return LoadOutcome<AppPartCardHistory>.Ok(items, result.Value.TotalCount);
    }

    protected override void ShowError(string message) => Toast.Error(message);

    protected override async Task OnFirstLoadAsync()
    {
        var cats = await Business.GetCategoryOptionsAsync();
        if (cats.IsSuccess && cats.Value != null) _categoryOptions = cats.Value;
        BuildTabs();
        await ReloadAsync();
    }

    // ── State đặc thù <-> URL (type / cat / product / 2 khoảng ngày) ──
    protected override void ReadExtraFromUrl(Dictionary<string, StringValues> qs)
    {
        _type = GetQ(qs, "type", "");
        if (_type is not (TypeNormal or TypeOversea)) _type = "";
        _category = GetQ(qs, "cat", "");
        // Category hẹp hơn loại hàng → URL có cả hai thì category thắng.
        _product = _category != "" ? "" : GetQ(qs, "product", "").Trim();
        _lock = GetQ(qs, QLock, "");
        if (_lock is not (LockLocked or LockUnlocked)) _lock = "";
        _printedFrom = NormDate(GetQ(qs, QPrintedFrom, ""));
        _printedTo = NormDate(GetQ(qs, QPrintedTo, ""));
        _prodFrom = NormDate(GetQ(qs, QProdFrom, ""));
        _prodTo = NormDate(GetQ(qs, QProdTo, ""));
    }

    protected override void WriteExtraToUrl(Dictionary<string, object?> query)
    {
        query["type"] = _type != "" ? _type : null;
        query["cat"] = _category != "" ? _category : null;
        query["product"] = _product != "" ? _product : null;
        query[QLock] = _lock != "" ? _lock : null;
        query[QPrintedFrom] = _printedFrom != "" ? _printedFrom : null;
        query[QPrintedTo] = _printedTo != "" ? _printedTo : null;
        query[QProdFrom] = _prodFrom != "" ? _prodFrom : null;
        query[QProdTo] = _prodTo != "" ? _prodTo : null;
    }

    // Category / loại hàng là TAB chứ không phải filter: không tính vào chip, và "Xoá tất cả bộ lọc"
    // không đá người dùng ra khỏi tab đang đứng.
    protected override bool HasActiveFilters
        => base.HasActiveFilters || _type != "" || _lock != "" || HasPrintedRange || HasProdRange;

    protected override void ClearExtraFilters()
    {
        _type = "";
        _lock = "";
        _printedFrom = _printedTo = "";
        _prodFrom = _prodTo = "";
    }

    // ── Select Loại phiếu / tab Category ──
    private void SetType(string v) { _type = v; CommitState(); }

    // Tab category và tab gom loại hàng loại trừ nhau: chọn cái này thì bỏ cái kia.
    private void SetCategory(string v) { _category = v; _product = ""; CommitState(); }

    private void SetProduct(string v) { _product = v; _category = ""; CommitState(); }

    // ── Khoảng ngày in / ngày SX (DateRangePicker trên toolbar) ──
    private bool HasPrintedRange => _printedFrom != "" || _printedTo != "";
    private bool HasProdRange => _prodFrom != "" || _prodTo != "";

    // DateRangePicker gọi lần lượt FromChanged → ToChanged → OnChanged mỗi lần Áp dụng / Xoá.
    // Hai callback đầu CHỈ ghi state; tải lại bảng đúng 1 lần ở OnChanged.
    private void OnPrintedFromChanged(DateTime? d) => _printedFrom = DateStr(d);
    private void OnPrintedToChanged(DateTime? d) => _printedTo = DateStr(d);
    private void OnProdFromChanged(DateTime? d) => _prodFrom = DateStr(d);
    private void OnProdToChanged(DateTime? d) => _prodTo = DateStr(d);

    private void OnDateRangeChanged() => CommitState();

    private void ClearPrintedRange() { _printedFrom = _printedTo = ""; CommitState(); }
    private void ClearProdRange() { _prodFrom = _prodTo = ""; CommitState(); }

    private static DateTime? ToDate(string s)
        => DateTime.TryParseExact(s, "yyyy-MM-dd", CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;

    // DateTime? của DateRangePicker → chuỗi state; null (đã xoá) → "".
    private static string DateStr(DateTime? d)
        => d?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture) ?? "";

    // Chỉ nhận yyyy-MM-dd hợp lệ (URL gõ tay sai → "").
    private static string NormDate(string? s) => ToDate(s ?? "") is null ? "" : s!;

    // Chữ trên chip: "01/10/2026 – 02/10/2026"; đầu nào để trống thì hiện "…".
    private static string RangeText(string from, string to)
    {
        static string D(string s) => ToDate(s)?.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture) ?? "…";
        return $"{D(from)} – {D(to)}";
    }

    // ── Helper hiển thị ──
    private string CategoryText(int? code)
    {
        if (code is null or 0) return "—";
        var name = _categoryOptions.FirstOrDefault(c => c.Code == code)?.Name;
        return string.IsNullOrWhiteSpace(name) ? code.ToString()! : $"{code} · {name}";
    }

    private string TypeLabel(string type) => type switch
    {
        TypeNormal => L["PartCard.Type.Normal"],
        TypeOversea => L["PartCard.Type.Sp"],
        _ => type,
    };
}