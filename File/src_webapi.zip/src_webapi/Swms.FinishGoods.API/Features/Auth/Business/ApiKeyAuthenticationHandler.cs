﻿using System.Security.Claims;
using System.Text.Encodings.Web;
using Microsoft.AspNetCore.Authentication;
using Microsoft.Extensions.Options;
using Swms.FinishGoods.API.Features.Auth.DataAccess;
using Swms.FinishGoods.API.Shared.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;

namespace Swms.FinishGoods.API.Features.Auth.Business;

public sealed class ApiKeyAuthenticationOptions : AuthenticationSchemeOptions
{
    public const string Scheme = "ApiKey";
    public const string HeaderName = "X-Api-Key";
}

// Đọc header X-Api-Key, verify, dựng ClaimsPrincipal mang quyền của client
// qua claim "perm" -> ClaimsUserPermissionProvider đọc được, pipeline phân quyền
// [RequirePermission<...>] chạy y nguyên như user thường.
public sealed class ApiKeyAuthenticationHandler
    : AuthenticationHandler<ApiKeyAuthenticationOptions>
{
    private readonly IApiKeyRepository _repo;
    private readonly IPasswordHasher _hasher;

    public ApiKeyAuthenticationHandler(
        IOptionsMonitor<ApiKeyAuthenticationOptions> options,
        ILoggerFactory logger, UrlEncoder encoder,
        IApiKeyRepository repo, IPasswordHasher hasher)
        : base(options, logger, encoder)
    {
        _repo = repo;
        _hasher = hasher;
    }

    protected override async Task<AuthenticateResult> HandleAuthenticateAsync()
    {
        if (!Request.Headers.TryGetValue(
                ApiKeyAuthenticationOptions.HeaderName, out var values))
            return AuthenticateResult.NoResult();

        var provided = values.ToString();
        if (string.IsNullOrWhiteSpace(provided)
            || provided.Length < ApiKeyGenerator.PrefixLength)
            return AuthenticateResult.Fail("Invalid API key.");

        var prefix = provided[..ApiKeyGenerator.PrefixLength];
        var record = await _repo.GetByPrefixAsync(prefix);

        if (record is null || !record.IsActive)
            return AuthenticateResult.Fail("Invalid API key.");

        if (record.ExpiresAt is { } exp && exp < DateTime.UtcNow)
            return AuthenticateResult.Fail("API key expired.");

        if (!_hasher.Verify(provided, record.KeyHash))
            return AuthenticateResult.Fail("Invalid API key.");

        await _repo.UpdateLastUsedAsync(record.Id, DateTime.UtcNow);

        var claims = new List<Claim>
        {
            new(ClaimTypes.Name, record.ClientName),
            new(ClaimTypes.NameIdentifier, $"apikey:{record.Id}"),
            new("auth_method", "apikey"),
            new("client_name", record.ClientName)
        };

        foreach (var code in record.Permissions)
            claims.Add(new Claim(ClaimsUserPermissionProvider.PermissionClaimType, code));

        var identity = new ClaimsIdentity(claims, ApiKeyAuthenticationOptions.Scheme);
        var ticket = new AuthenticationTicket(
            new ClaimsPrincipal(identity), ApiKeyAuthenticationOptions.Scheme);

        return AuthenticateResult.Success(ticket);
    }
}