/* =====================================================================
   002 - Đổi lịch mẫu từ theo địa điểm (PSNV, JUPITER) sang theo bộ phận:
     VP           Lịch văn phòng (mặc định). Rule ETD: AIR, SEA, phần lớn TRUCK
     KHO_PSNV     Lịch kho PSNV     } Rule ETD: TRUCK PAPVN REF + WAS
     KHO_JUPITER  Lịch kho JUPITER  } chọn theo vanning place của hàng

   Không mất dữ liệu đã nhập: ngày đã có của
     PSNV    -> chép sang VP và KHO_PSNV
     JUPITER -> chép sang KHO_JUPITER
   rồi mới xoá PSNV, JUPITER. Chạy lại nhiều lần vẫn an toàn.
   ===================================================================== */

SET XACT_ABORT ON;
GO

BEGIN TRANSACTION;

-- 1. Tạo 3 lịch mới (chưa đặt mặc định)
IF NOT EXISTS (SELECT 1 FROM dbo.WorkingCalendars WHERE Code = 'VP')
    INSERT INTO dbo.WorkingCalendars (Code, Name, IsDefault) VALUES ('VP', N'Văn phòng', 0);
IF NOT EXISTS (SELECT 1 FROM dbo.WorkingCalendars WHERE Code = 'KHO_PSNV')
    INSERT INTO dbo.WorkingCalendars (Code, Name, IsDefault) VALUES ('KHO_PSNV', N'Kho PSNV', 0);
IF NOT EXISTS (SELECT 1 FROM dbo.WorkingCalendars WHERE Code = 'KHO_JUPITER')
    INSERT INTO dbo.WorkingCalendars (Code, Name, IsDefault) VALUES ('KHO_JUPITER', N'Kho JUPITER', 0);

-- 2. Chép ngày đã có (chỉ ngày chưa có ở lịch đích)
INSERT INTO dbo.WorkingDays (CalendarCode, [Date], IsWorking, DayType, Note)
SELECT m.NewCode, d.[Date], d.IsWorking, d.DayType, d.Note
FROM dbo.WorkingDays d
JOIN (VALUES ('PSNV', 'VP'), ('PSNV', 'KHO_PSNV'), ('JUPITER', 'KHO_JUPITER')) m(OldCode, NewCode)
  ON m.OldCode = d.CalendarCode
WHERE NOT EXISTS (
    SELECT 1 FROM dbo.WorkingDays x WHERE x.CalendarCode = m.NewCode AND x.[Date] = d.[Date]
);

-- 3. Xoá lịch cũ
DELETE FROM dbo.WorkingDays     WHERE CalendarCode IN ('PSNV', 'JUPITER');
DELETE FROM dbo.WorkingCalendars WHERE Code        IN ('PSNV', 'JUPITER');

-- 4. VP là lịch mặc định (bỏ cờ của lịch khác trước, vì chỉ được 1 lịch mặc định)
UPDATE dbo.WorkingCalendars SET IsDefault = 0 WHERE Code <> 'VP' AND IsDefault = 1;
UPDATE dbo.WorkingCalendars SET IsDefault = 1 WHERE Code = 'VP';

COMMIT;
GO

SELECT c.Code, c.Name, c.IsDefault, COUNT(d.[Date]) AS SoNgay
FROM dbo.WorkingCalendars c
LEFT JOIN dbo.WorkingDays d ON d.CalendarCode = c.Code
GROUP BY c.Code, c.Name, c.IsDefault
ORDER BY c.IsDefault DESC, c.Code;
