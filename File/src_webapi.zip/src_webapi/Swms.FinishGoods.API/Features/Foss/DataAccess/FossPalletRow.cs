namespace Swms.FinishGoods.API.Features.Foss.DataAccess;

public record FossPalletRow(
    string PalletNo,          // Source_pallet
    string BoxNo,             // SERIAL_OUTER
    string ModelNo,           // sModelNo
    string SerialNo,          // sSerialNo
    DateTime? ProductionDate, // dShrinkDate
    string? ShrinkBy,         // dShrinkBy
    byte? OQCStatus,          // STATUS_FA
    string Line,              // COD_SCALE_NO
    string LotName,           // LOT_NAME
    DateTime? DateInsert      // DATEINSERT
);

// record -> so sánh theo giá trị, dùng làm "chữ ký" Foss của pallet.
public sealed record FossPalletSummary
{
    public string PalletNo { get; init; } = "";
    public int BoxCount { get; init; }
    public int SerialCount { get; init; }
    public DateTime? LastShrinkDate { get; init; }
}
