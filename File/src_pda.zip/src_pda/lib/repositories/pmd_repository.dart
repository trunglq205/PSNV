import 'package:injectable/injectable.dart';
import 'package:smart_warehouse/services/api_service.dart';
import 'package:smart_warehouse/services/models/request/robot_call_request_model.dart';
import 'package:smart_warehouse/services/models/request/robot_outpallet_request_model.dart';

import '../services/models/request/returncardpmdrequestmodel.dart';
import '../services/models/request/update_boxcard_pmd_request_model.dart';
import '../services/models/request/update_return_card_pmd_request_model.dart';
import '../services/models/response/boxcard_pmd_model.dart';
import '../services/models/response/return_card_pmd_model.dart';

@injectable
class PMDRepository{
  PMDRepository(this._apiService);
  final ApiService _apiService;
  // Future<String?> CallRobot(RobotCallRequestModel request) async {
  //   return _apiService.Robot_call(request);
  // }
  // Future<String?> Outpallet(RobotOutpalletRequestModel request) async {
  //   return _apiService.Robot_outpallet(request);
  // }
  
Future<String?> GetMasterRecycle(String request) async {
  return await _apiService.GetMasterRecyclePDM( request: request);
}
Future<ReturnCardPmdModel?> CreateReturnCardPMD(ReturnCardPMDRequestModel request) async {
  return await _apiService.CreateReturnCardPMD(request);
}
  Future<ReturnCardPmdModel?> UpdateReturnCardPMD(UpdateReturnCardPmdRequestModel request) async {
    return await _apiService.UpdateReturnCardPMD(request);
  }

  Future<ReturnCardPmdModel?> GetInforReturnCardPMD(int request) async {
    return await _apiService.GetInforReturnCardPMD( request: request);
  }

  Future<BoxcardPMDModel?> GetBoxCardPMD(String request) async {
    return await _apiService.GetBoxCardPMD( request: request);
  }

  Future<BoxcardPMDModel?> UpdateBoxCardPMD(UpdateBoxcardPMDRequestModel request) async {
    return await _apiService.UpdateBoxCardPMD(request);
  }

  Future<String?> UpdatePlanQuantityPMD(UpdateBoxcardPMDRequestModel request) async {
    return await _apiService.UpdatePlanQuantityPMD(request);
  }

  Future<String?> UpdatePlanPMD(UpdateBoxcardPMDRequestModel request) async {
    return await _apiService.UpdatePlanPMD(request);
  }






}





// public class UpdateReturnCardPMDRequest
// {
//   public long ID { get; set; }
// public double Quantity { get; set; }
// public string Unit { get; set; }
// public string UserIDUpdate { get; set; }
//
//
// }