﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.CSharp;

namespace SWMS_WebTool.ViewModels
{
    public class VendorViewModel : TableViewModel<Vendor, VendorFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, VendorFilter? filter = null)
        {
            return new
            {
                VendorCode = filter?.VendorCode ?? Filter.VendorCode,
                GlobalCode = filter?.GlobalCode ?? Filter.GlobalCode,
                VendorName = filter?.VendorName ?? Filter.VendorName,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}