namespace Swms.FinishGoods.API.Features.Foss.DataAccess;

/// <summary>
/// Category hàng, suy từ 3 số đầu barcode pallet.
/// Giá trị enum = mã prefix (vd HP = 915) để tra 2 chiều dễ dàng.
/// </summary>
public enum FossCategory
{
    Default = 100,   // '_' : bảng không hậu tố
    PT = 913,
    MW = 914,
    HP = 915,
    TV = 916,
    CAM = 917,
    PEWVN = 918,
    DECT = 110,
    DP = 210,
    PBX = 310,
    Scanner = 410,
    HDC = 510,
    Faxboard = 610,
}

public static class FossCategoryExtensions
{
    /// <summary>
    /// Suy FossCategory từ 3 ký tự đầu barcode. Trả null nếu prefix không hợp lệ.
    /// </summary>
    public static FossCategory? FromBarcodePrefix(string barcode)
    {
        if (string.IsNullOrWhiteSpace(barcode) || barcode.Length < 3)
            return null;

        var prefix = barcode.Substring(0, 3);
        if (int.TryParse(prefix, out var code) && Enum.IsDefined(typeof(FossCategory), code))
            return (FossCategory)code;

        return null;
    }
}
