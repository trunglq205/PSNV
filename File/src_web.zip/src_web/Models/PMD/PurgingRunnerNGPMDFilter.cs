﻿namespace SWMS_WebTool.Models.PMD
{
    public class PurgingRunnerNGPMDFilter:BaseFilter
    {
        public string? Plant { get; set; }
        public string? Material { get; set; }
        public string? Model { get; set; }
        public string? Type { get; set; }
        public string? Recycle { get; set; }
        public string? Machine { get; set; }
        public string? Status { get; set; }
        public DateTime? TimeCreate { get; set; }
        public DateTime? TimeUpdate { get; set; }

    }
}
