using Swms.FinishGoods.API.Features.Pallets.Business.Entities;

namespace Swms.FinishGoods.API.Features.Pallets.Api
{
    // ── Response ──────────────────────────────────────────────

    /// <summary>
    /// Một vị trí ứng viên. Chỉ giữ những gì PDA cần để HIỂN THỊ và để GỌI TIẾP
    /// (PUT /api/pallets/{id}/storing nhận locatorCode).
    ///
    /// Các cờ xếp hạng (rowMatch / slotMatch / sameRack / distanceX / distanceY)
    /// và toạ độ bản đồ (posX / posY) đã bỏ: chúng chỉ phục vụ ORDER BY trong SQL,
    /// còn ý nghĩa nghiệp vụ "gợi ý này bị lệch" đã nằm ở <c>Warnings</c>.
    /// Khu vực cũng bỏ vì đã có ở mức trên và mọi ứng viên đều cùng khu.
    /// </summary>
    public record SuggestedLocatorResponse(
        long LocatorId,
        string LocatorCode,
        string? RackCode,

        /// <summary>Tầng rack (1..4). Null với ô giá lửng.</summary>
        int? RackRow,

        /// <summary>'A' | 'B' với ô giá lửng; null với rack thường.</summary>
        string? RackLevel,

        /// <summary>shelf = giá lửng.</summary>
        string? SlotKind)
    {
        public static SuggestedLocatorResponse From(LocatorCandidate c) => new(
            c.LocatorId, c.LocatorCode, c.RackCode, c.RackRow, c.RackLevel, c.SlotKind);
    }

    /// <summary>
    /// Vị trí lot gần nhất đã lưu — mốc mà gợi ý bám theo. Chỉ để operator đối chiếu
    /// "hàng cùng loại đang nằm ở đâu", nên giữ đúng phần đọc được bằng mắt.
    /// </summary>
    public record LastLotLocationResponse(
        string LotNo,
        string LocatorCode,
        string? RackCode,
        int? RackRow,

        /// <summary>model | category — cho biết mốc này đáng tin tới đâu.</summary>
        string MatchedBy)
    {
        public static LastLotLocationResponse From(LastLotLocation l) => new(
            l.LotNo, l.LocatorCode, l.RackCode, l.RackRow, l.MatchedBy);
    }

    /// <summary>
    /// Cấu hình ĐANG CÓ trong master.models của model này — trả nguyên trạng,
    /// KHÔNG phải kết quả gợi ý.
    ///
    /// Tách riêng khỏi <c>SuggestedAreaCode</c> / <c>SuggestedRackRows</c> vì hai
    /// thứ đó là kết quả cuối: khu có thể suy từ last lot, tầng có thể suy từ
    /// chiều cao. Client trước đây phải đoán "model đã khai master chưa" qua
    /// <c>Strategy</c> — mà Strategy chỉ nói về KHU, nên model khai tầng mà chưa
    /// khai khu bị đọc thành chưa có master.
    ///
    /// Null = model không có trong master.models (hoặc lot không xác định được model).
    /// Có object nhưng AreaId null + RackRows rỗng = có bản ghi nhưng chưa khai gì.
    /// </summary>
    public record ModelMasterConfigResponse(
        /// <summary>FK master.warehouse_areas(id) — giá trị PDA gửi lại khi PATCH.</summary>
        long? AreaId,
        string? AreaCode,

        /// <summary>Nội dung cột suggest_rack_row đã parse, vd [2, 3]. Rỗng = chưa khai.</summary>
        IReadOnlyList<int> RackRows)
    {
        public static ModelMasterConfigResponse? From(
            ModelStorageSuggestion? m, IReadOnlyList<int> rackRows)
            => m is null ? null : new(m.SuggestAreaId, m.SuggestAreaCode, rackRows);
    }

    /// <summary>
    /// Kết quả gợi ý vị trí lưu kho (FR-STR-02).
    ///
    /// Không echo lại tham số đầu vào (palletId, categoryCode, palletHeightCm) —
    /// client vừa gửi lên thì đã có sẵn.
    ///
    /// <c>SuggestedRackRows</c> rỗng nghĩa là không ràng buộc tầng: hoặc khu vực gợi ý
    /// không phải STORAGE, hoặc pallet vào giá lửng, hoặc không biết chiều cao.
    /// </summary>
    public record StorageSuggestionResponse(
        string LotNo,
        string? Model,

        /// <summary>Xem <see cref="SuggestionStrategies"/>.</summary>
        string Strategy,

        /// <summary>Cấu hình master hiện có của model. Null = chưa có bản ghi.</summary>
        ModelMasterConfigResponse? Master,

        /// <summary>Khu vực gợi ý — mọi ứng viên đều nằm trong khu này.</summary>
        string? SuggestedAreaCode,
        string? SuggestedAreaName,

        /// <summary>Tầng gợi ý, vd [2, 3]. Rỗng = không ràng buộc tầng.</summary>
        IReadOnlyList<int> SuggestedRackRows,

        /// <summary>shelf khi pallet thấp. Null = không ràng buộc loại ô.</summary>
        string? SuggestedSlotKind,

        /// <summary>Vị trí gợi ý tốt nhất. Null khi không còn chỗ trống.</summary>
        SuggestedLocatorResponse? SuggestedLocator,

        /// <summary>Phương án thay thế, đã xếp theo cùng thứ tự ưu tiên.</summary>
        IReadOnlyList<SuggestedLocatorResponse> Alternatives,

        LastLotLocationResponse? LastLot,

        /// <summary>Cảnh báo mềm: gợi ý lệch tầng, phải nới khu vực, thiếu chiều cao...</summary>
        IReadOnlyList<string> Warnings);

    // ── Error codes ───────────────────────────────────────────

    /// <summary>Mã lỗi / cảnh báo của luồng gợi ý vị trí lưu kho.</summary>
    public static class StorageSuggestionErrors
    {
        public const string PalletNotFound = "Lot.Suggestion.PalletNotFound";        // 404
        public const string HeightInvalid = "Lot.Suggestion.HeightInvalid";          // 422
        public const string NoFreeLocator = "Lot.Suggestion.NoFreeLocator";          // 422

        // Cảnh báo (trả trong Warnings, không throw)
        public const string WarnHeightMissing = "Lot.Suggestion.Warn.HeightMissing";
        public const string WarnAreaFallback = "Lot.Suggestion.Warn.AreaFallback";
        public const string WarnRowMismatch = "Lot.Suggestion.Warn.RowMismatch";
        public const string WarnSlotMismatch = "Lot.Suggestion.Warn.SlotMismatch";
        public const string WarnShelfNotSuitable = "Lot.Suggestion.Warn.ShelfNotSuitable";
        public const string WarnNoLastLot = "Lot.Suggestion.Warn.NoLastLot";
    }
}
