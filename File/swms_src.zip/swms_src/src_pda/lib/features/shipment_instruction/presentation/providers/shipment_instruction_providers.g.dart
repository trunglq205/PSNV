// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shipment_instruction_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(shipmentInstructionRemoteDataSource)
final shipmentInstructionRemoteDataSourceProvider =
    ShipmentInstructionRemoteDataSourceProvider._();

final class ShipmentInstructionRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ShipmentInstructionRemoteDataSource,
          ShipmentInstructionRemoteDataSource,
          ShipmentInstructionRemoteDataSource
        >
    with $Provider<ShipmentInstructionRemoteDataSource> {
  ShipmentInstructionRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'shipmentInstructionRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() =>
      _$shipmentInstructionRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ShipmentInstructionRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ShipmentInstructionRemoteDataSource create(Ref ref) {
    return shipmentInstructionRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ShipmentInstructionRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ShipmentInstructionRemoteDataSource>(
        value,
      ),
    );
  }
}

String _$shipmentInstructionRemoteDataSourceHash() =>
    r'55f33552b0cea36d8e153659153b229d0f84a234';

@ProviderFor(shipmentInstructionRepository)
final shipmentInstructionRepositoryProvider =
    ShipmentInstructionRepositoryProvider._();

final class ShipmentInstructionRepositoryProvider
    extends
        $FunctionalProvider<
          ShipmentInstructionRepository,
          ShipmentInstructionRepository,
          ShipmentInstructionRepository
        >
    with $Provider<ShipmentInstructionRepository> {
  ShipmentInstructionRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'shipmentInstructionRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$shipmentInstructionRepositoryHash();

  @$internal
  @override
  $ProviderElement<ShipmentInstructionRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ShipmentInstructionRepository create(Ref ref) {
    return shipmentInstructionRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ShipmentInstructionRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ShipmentInstructionRepository>(
        value,
      ),
    );
  }
}

String _$shipmentInstructionRepositoryHash() =>
    r'a63bb0d587684c06ac219572ab7d2dd93a1bfd18';
