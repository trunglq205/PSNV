using Swms.FinishGoods.API.Features.PartCards.Business;
using Swms.FinishGoods.API.Features.PartCards.DataAccess;

namespace Swms.FinishGoods.API.Features.PartCards;

public static class PartCardModule
{
    public static IServiceCollection AddPartCardFeature(this IServiceCollection services)
    {
        services.AddScoped<IPartCardService, PartCardService>();
        services.AddScoped<IPartCardRepository, PartCardRepository>();
        return services;
    }
}
