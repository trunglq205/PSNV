using Swms.FinishGoods.Api.Features.Roles.Business;
using Swms.FinishGoods.Api.Features.Roles.DataAccess;

namespace Swms.FinishGoods.Api.Features.Roles;

public static class RoleModule
{
    public static IServiceCollection AddRoleFeature(this IServiceCollection services)
    {
        services.AddScoped<IRoleService, RoleService>();
        services.AddScoped<IRoleRepository, RoleRepository>();
        services.AddScoped<PermissionCatalogSeeder>();
        return services;
    }
}
