import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/sap_status.dart';

/// Thẻ thông tin chính: mã pallet, trạng thái, model/qty, số thùng, vị trí.
class PalletInfoCard extends StatelessWidget {
  final Pallet pallet;

  const PalletInfoCard({super.key, required this.pallet});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: swms.primaryTint,
                  borderRadius: BorderRadius.circular(AppDimens.rBtn),
                ),
                child: Icon(
                  Icons.inventory_2_outlined,
                  color: swms.primary,
                  size: 22,
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      pallet.isStocky
                          ? LocaleKeys.pallet_detail_stocky_code.tr()
                          : LocaleKeys.pallet_detail_pallet_id.tr(),
                      style: AppTextStyles.caption.copyWith(color: swms.text3),
                    ),
                    Text(
                      pallet.isStocky
                          ? pallet.stockyCode ?? pallet.lotNo
                          : pallet.lotNo,
                      style: AppTextStyles.title.copyWith(
                        color: swms.text1,
                      ),
                    ),
                  ],
                ),
              ),
              if (pallet.isUrgent)
                StatusPill.danger(
                  context,
                  label: LocaleKeys.pallet_detail_urgent.tr(),
                ),
              Column(
                crossAxisAlignment: .end,
                children: [
                  StatusPill(
                    label: 'OQC ${pallet.inspectionStatus}',
                    background: pallet.inspectionStatus.color.bg,
                    foreground: pallet.inspectionStatus.color.fg,
                  ),
                  const SizedBox(height: AppDimens.xs),
                  if (pallet.sapStatus != null)
                    StatusPill(
                      label: 'SAP ${pallet.sapStatus}',
                      background: pallet.sapStatus!.color.bg,
                      foreground: pallet.sapStatus!.color.fg,
                    ),
                ],
              ),
            ],
          ),

          const SizedBox(height: AppDimens.sm),

          if (pallet.hasLocator)
            StatusPill.info(
              context,
              label: '${pallet.areaCode} - ${pallet.locatorCode ?? ''}',
              icon: Icons.location_on_outlined,
            )
          else
            StatusPill.warning(
              context,
              label: LocaleKeys.pallet_detail_no_storage.tr(),
              icon: Icons.location_on_outlined,
            ),

          const Divider(height: AppDimens.lg),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _InfoField(
                  label: LocaleKeys.pallet_detail_category.tr(),
                  child: Text(
                    pallet.categoryName ?? '${pallet.categoryCode}',
                    style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _InfoField(
                  label: LocaleKeys.pallet_detail_production_date.tr(),
                  child: Text(
                    pallet.productionDate == null
                        ? '—'
                        : DateFormat(
                            'dd/MM/yyyy',
                          ).format(pallet.productionDate!),
                    style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: AppDimens.sm),

          Text(
            LocaleKeys.pallet_detail_models.tr(),
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
          const SizedBox(height: AppDimens.xs),
          // Lot mức box_count không có box_lines -> modelQtys rỗng,
          // model lấy từ trường `models` của lot.
          if (pallet.modelQtys.isEmpty)
            Text(
              pallet.displayModels.isEmpty ? '—' : pallet.displayModels,
              style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
            )
          else
            for (final mq in pallet.modelQtys)
              Padding(
                padding: const EdgeInsets.only(bottom: AppDimens.xs),
                child: Row(
                  children: [
                    Expanded(
                      child: Text(
                        mq.model,
                        style: AppTextStyles.bodyStrong.copyWith(
                          color: swms.text1,
                        ),
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    Text(
                      LocaleKeys.pallet_detail_qty_value.tr(
                        args: ['${mq.totalQty}'],
                      ),
                      style: AppTextStyles.bodyStrong.copyWith(
                        color: swms.primary,
                      ),
                    ),
                  ],
                ),
              ),

          const SizedBox(height: AppDimens.sm),

          Row(
            children: [
              Expanded(
                child: _MiniStat(
                  label: LocaleKeys.pallet_detail_total_qty.tr(),
                  value: '${pallet.displayTotalQty}',
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _MiniStat(
                  label: LocaleKeys.pallet_detail_box_count.tr(),
                  value: '${pallet.displayBoxCount}',
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;

  const _MiniStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: AppDimens.sm,
        horizontal: AppDimens.sm,
      ),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
      ),
      child: Column(
        children: [
          Text(value, style: AppTextStyles.h2.copyWith(color: swms.text1)),
          Text(label, style: AppTextStyles.caption.copyWith(color: swms.text3)),
        ],
      ),
    );
  }
}

class _InfoField extends StatelessWidget {
  final String label;
  final Widget child;

  const _InfoField({required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTextStyles.caption.copyWith(color: context.swms.text3),
        ),
        const SizedBox(height: AppDimens.xs),
        child,
      ],
    );
  }
}