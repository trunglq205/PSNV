﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class VendorController : BaseController
    {
        private readonly ApiService _apiService;

        public VendorController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] VendorFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new VendorFilter();
                var response = await _apiService.SearchVendors(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<Vendor>();

                var model = new VendorViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/Vendor/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public IActionResult CreateVendor()
        {
            return PartialView("~/Views/Vendor/_CreateUpdateVendorModal.cshtml");
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmCreateVendor(Vendor model)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var vendor = new Vendor()
                {
                    VendorCode = model.VendorCode,
                    VendorName = model.VendorName,
                    VendorNameShort = model.VendorNameShort,
                    Country = model.Country,
                    GlobalCode = model.GlobalCode,
                };
                await _apiService.CreateVendor(new List<Vendor> { vendor });
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateVendor(string vendorCode)
        {
            var vendor = await _apiService.ReadVendor(vendorCode);
            var model = new Vendor()
            {
                VendorCode = vendor.VendorCode,
                GlobalCode = vendor.GlobalCode,
                VendorName = vendor.VendorName,
                VendorNameShort = vendor.VendorNameShort,
                Country = vendor.Country,
            };
            return PartialView("~/Views/Vendor/_CreateUpdateVendorModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmUpdateVendor(Vendor model)
        {
            try
            {
                var request = new Vendor()
                {
                    VendorCode = model.VendorCode,
                    GlobalCode = model.GlobalCode,
                    VendorName = model.VendorName,
                    VendorNameShort = model.VendorNameShort,
                    Country = model.Country,
                };
                await _apiService.UpdateVendor(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }

        [HttpPost]
        public IActionResult DeleteVendor(string id)
        {
            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDeleteVendor",
                Controller = "Vendor",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteVendor(string id)
        {
            try
            {
                await _apiService.DeleteVendor(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }
    }
}

