﻿using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.AbnormalReports.Api;

/// <summary>1 dòng trong danh sách phiếu hàng bất thường.</summary>
public record NgReportSummaryResponse(
    long Id, string DocNo, long? LotId, string? PalletCode, string? Model,
    string NgType, DateTime DiscoveredAt, string DocStatus, string CurrentStep,
    string LeaderStatus, string FaStatus, string? FaResult, string? FaResolution,
    string OqcStatus, string Resolution, int ReviewRound,
    int ItemCount, int QtyAffected, int PhotoCount, string? CreatedBy,
    bool IsWholePallet)
{
    public static NgReportSummaryResponse From(NgReport n) => new(
        n.Id, n.DocNo, n.LotId, n.PalletCode, n.Model,
        n.NgType, n.DiscoveredAt, n.DocStatus, n.CurrentStep,
        n.LeaderStatus, n.FaStatus, n.FaResult, n.FaResolution,
        n.OqcStatus, n.Resolution, n.ReviewRound,
        n.ItemCount, n.QtyAffected, n.PhotoCount, n.CreatedBy,
        n.IsWholePallet);
}

public record NgItemResponse(
    long Id, string Scope, long? PalletId, long? BoxId, long? BoxLineId,
    string? Code, int QtyAffected, string? Note)
{
    public static NgItemResponse From(NgItem i) =>
        new(i.Id, i.Scope, i.PalletId, i.BoxId, i.BoxLineId, i.Code, i.QtyAffected, i.Note);
}

public record NgPhotoResponse(long Id, long? ItemId, string FileName, string? Caption, int SortOrder)
{
    public static NgPhotoResponse From(NgPhoto p) => new(p.Id, p.ItemId, p.FileName, p.Caption, p.SortOrder);
}

public record NgApprovalResponse(
    long Id, string Step, string Action, string? Resolution, string? Comment,
    string? ActedBy, DateTime ActedAt)
{
    public static NgApprovalResponse From(NgApproval a) =>
        new(a.Id, a.Step, a.Action, a.Resolution, a.Comment, a.ActedBy, a.ActedAt);
}

/// <summary>Chi tiết phiếu: header + phạm vi ảnh hưởng + ảnh + nhật ký duyệt.</summary>
public record NgReportDetailResponse(
    NgReportSummaryResponse Header,
    string? Description,
    string? LeaderBy, DateTime? LeaderAt, string? LeaderComment,
    string? FaBy, DateTime? FaAt, string? FaComment,
    string? OqcBy, DateTime? OqcAt, string? OqcComment,
    string? FinalizedBy, DateTime? FinalizedAt, string? FinalComment,
    string? CancelledBy, DateTime? CancelledAt, string? CancelReason,
    IReadOnlyList<NgItemResponse> Items,
    IReadOnlyList<NgPhotoResponse> Photos,
    IReadOnlyList<NgApprovalResponse> Approvals,
    bool LeaderIsMe)
{
    /// <param name="actorCode">
    /// MÃ NHÂN VIÊN của người đang xem phiếu, so với leader_by_code để bật cảnh
    /// báo "bạn đã duyệt bước 2" ở bước chốt — CẢNH BÁO, không chặn.
    /// So bằng mã chứ không bằng họ tên: mã nhân viên là duy nhất và cũng là tên
    /// đăng nhập, nên hai người trùng họ tên không còn báo nhầm.
    /// Phiếu tạo trước khi có cột leader_by_code sẽ có giá trị NULL ⟹ không cảnh
    /// báo, chấp nhận được vì đây chỉ là nhắc nhở.
    /// </param>
    public static NgReportDetailResponse From(NgReportDetail d, string? actorCode) => new(
        NgReportSummaryResponse.From(d.Header),
        d.Header.Description,
        d.Header.LeaderBy, d.Header.LeaderAt, d.Header.LeaderComment,
        d.Header.FaBy, d.Header.FaAt, d.Header.FaComment,
        d.Header.OqcBy, d.Header.OqcAt, d.Header.OqcComment,
        d.Header.FinalizedBy, d.Header.FinalizedAt, d.Header.FinalComment,
        d.Header.CancelledBy, d.Header.CancelledAt, d.Header.CancelReason,
        d.Items.Select(NgItemResponse.From).ToList(),
        d.Photos.Select(NgPhotoResponse.From).ToList(),
        d.Approvals.Select(NgApprovalResponse.From).ToList(),
        !string.IsNullOrWhiteSpace(d.Header.LeaderByCode)
            && !string.IsNullOrWhiteSpace(actorCode)
            && string.Equals(d.Header.LeaderByCode.Trim(), actorCode.Trim(),
                             StringComparison.OrdinalIgnoreCase));
}

/// <summary>1 phạm vi ảnh hưởng khi tạo phiếu. Scope: pallet | box | serial.</summary>
public record CreateNgItemRequest(string Scope, string? Code, int? QtyAffected, string? Note);

/// <summary>
/// Tạo phiếu (trạng thái nháp). PalletCode là mã pallet đã quét — hàng bất thường
/// luôn phát hiện trên 1 pallet đã có mã.
/// </summary>
public record CreateNgReportRequest(
    string PalletCode, string NgType, string? Description, List<CreateNgItemRequest> Items);

public record CreateNgReportResponse(long Id, string DocNo);

/// <summary>Sửa phiếu nháp. Danh sách phạm vi ảnh hưởng gửi lên sẽ THAY cho danh sách cũ.</summary>
public record UpdateNgReportRequest(string NgType, string? Description, List<CreateNgItemRequest> Items);

/// <summary>Bước 2: Leader SCS duyệt (submit) hoặc huỷ (cancel).</summary>
public record LeaderReviewRequest(string Action, string? Comment);

/// <summary>
/// FA kết luận: <paramref name="Result"/> = ok | ng.
/// NG thì <paramref name="Resolution"/> BẮT BUỘC — replace | accept | return |
/// scrap. OK thì bỏ qua.
/// </summary>
public record FaConfirmRequest(string Result, string? Resolution, string? Comment);

/// <summary>FA báo đã xử lý xong lượt NG, để OQC đánh giá lại.</summary>
public record FaFixDoneRequest(string? Comment);

/// <summary>OQC kết luận chất lượng — ok | ng.</summary>
public record OqcConfirmRequest(string Result, string? Comment);

/// <summary>Kết quả tra pallet ở màn tạo phiếu trên PDA.</summary>
public record NgPalletCheckResponse(
    long Id, string Code, string? Model, int? BoxCount,
    string? InspectionStatus, bool IsUrgent, DateTime? ProductionDate,
    string? LocatorCode, string? AreaName)
{
    public static NgPalletCheckResponse From(NgPalletBrief b) => new(
        b.Id, b.Code, b.Model, b.BoxCount,
        b.InspectionStatus, b.IsUrgent, b.ProductionDate,
        b.LocatorCode, b.AreaName);
}

/// <summary>1 người sẽ nhận mail. <paramref name="Type"/> là TO | CC | BCC.</summary>
public record MailPreviewRecipient(string Type, string Email, string? DisplayName);

/// <summary>
/// Xem trước mail của bước 2 — ai sẽ nhận, trước khi Leader bấm duyệt.
///
/// Có ba cách mail lặng lẽ không tới nơi: chưa khai người nhận, mẫu mail rỗng,
/// và Mail:Enabled đang tắt. Trả về cả ba cờ chứ không chỉ danh sách người
/// nhận, để màn hình nói được lý do thay vì chỉ hiện một ô trống.
/// </summary>
public record MailPreviewResponse(
    string? CategoryCode,
    string? CategoryName,
    string? Model,
    bool MailEnabled,
    bool TemplateReady,
    List<MailPreviewRecipient> Recipients);

/// <summary>
/// Một loại lỗi cho danh sách thả xuống. <paramref name="Name"/> và
/// <paramref name="Note"/> đã theo ngôn ngữ người gọi, client cứ hiện thẳng.
///
/// Trả kèm <paramref name="RequiresOqc"/> để màn tạo phiếu nói trước cho người
/// lập biết loại này có phải chờ OQC hay không — thông tin đó đằng nào cũng
/// phải đi cùng danh sách, khỏi gọi thêm lần nữa.
/// </summary>
public record NgTypeResponse(string Code, string Name, string? Note, bool RequiresOqc);

/// <summary>
/// Một loại lỗi ở màn QUẢN TRỊ: đủ 4 ngôn ngữ, CHƯA dịch sẵn như
/// <see cref="NgTypeResponse"/>. Người quản trị phải nhìn và sửa được từng bản
/// dịch, nên ở đây trả thô.
/// </summary>
public record NgTypeAdminResponse(
    string Code,
    string NameVi, string? NameEn, string? NameJa, string? NameZh,
    string? NoteVi, string? NoteEn, string? NoteJa, string? NoteZh,
    bool RequiresOqc, int SortOrder, bool IsActive,
    int UsedByReports);

/// <summary>
/// Thân request thêm/sửa loại lỗi.
///
/// Độ dài khớp đúng cột trong master.ng_types: code NVARCHAR(30) — bằng
/// wms.ng_inspections.ng_type để khoá ngoại fk_ng_inspections_ng_type đứng được
/// — name NVARCHAR(200), note NVARCHAR(400).
/// </summary>
public class SaveNgTypeRequest
{
    [Required, MaxLength(30)] public string Code { get; set; } = "";

    [Required, MaxLength(200)] public string NameVi { get; set; } = "";
    [MaxLength(200)] public string? NameEn { get; set; }
    [MaxLength(200)] public string? NameJa { get; set; }
    [MaxLength(200)] public string? NameZh { get; set; }

    [MaxLength(400)] public string? NoteVi { get; set; }
    [MaxLength(400)] public string? NoteEn { get; set; }
    [MaxLength(400)] public string? NoteJa { get; set; }
    [MaxLength(400)] public string? NoteZh { get; set; }

    /// <summary>false = phiếu loại này bỏ qua bước OQC, Leader duyệt xong đi thẳng sang FA.</summary>
    public bool RequiresOqc { get; set; } = true;

    public int SortOrder { get; set; } = 100;
    public bool IsActive { get; set; } = true;
}
