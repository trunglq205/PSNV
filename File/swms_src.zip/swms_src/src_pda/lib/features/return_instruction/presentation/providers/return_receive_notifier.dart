import 'package:flutter/foundation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_receive_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_instruction_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'return_receive_notifier.g.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2a — bản nháp quét của màn Nhận hàng back.
//
//  Máy KHÔNG đoán mã quét được là thùng hay serial: phân biệt theo giai đoạn.
//  Chưa mở thùng nào thì mã quét là MÃ THÙNG; đang mở một thùng thì mọi mã
//  quét là SERIAL, tới khi bấm "Xong thùng". Đoán theo độ dài hay tiền tố mã
//  là cách chắc chắn sẽ sai với một lô hàng nào đó.
// ─────────────────────────────────────────────────────────────

@immutable
class ReturnReceiveState {
  /// Các thùng đã quét xong, chờ lưu.
  final List<ReturnBoxDraft> boxes;

  /// Thùng đang quét serial. `null` = đang chờ quét mã thùng mới.
  final ReturnBoxDraft? current;

  /// Model áp cho thùng SẮP mở. Phiếu một model thì màn hình tự chọn.
  final String? activeModel;

  const ReturnReceiveState({
    this.boxes = const [],
    this.current,
    this.activeModel,
  });

  /// Đang mở một thùng → mã quét tiếp theo là serial.
  bool get isScanningSerials => current != null;

  /// Tổng serial trong bản nháp, tính cả thùng đang mở.
  int get serialCount =>
      boxes.fold(0, (s, b) => s + b.serials.length) +
      (current?.serials.length ?? 0);

  /// Có gì để lưu chưa.
  bool get hasAnything => serialCount > 0;

  /// Số serial của một model trong bản nháp — màn hình cộng vào SL thực nhận
  /// của server để hiện "còn phải nhận bao nhiêu" ngay khi đang quét.
  int draftCountFor(String model) {
    var n = 0;
    for (final b in boxes) {
      if (_same(b.model, model)) n += b.serials.length;
    }
    final c = current;
    if (c != null && _same(c.model, model)) n += c.serials.length;
    return n;
  }

  /// Serial đã nằm trong bản nháp (so không phân biệt hoa thường).
  bool hasSerial(String serialNo) {
    for (final b in boxes) {
      if (b.serials.any((s) => _same(s, serialNo))) return true;
    }
    return current?.serials.any((s) => _same(s, serialNo)) ?? false;
  }

  bool hasBoxNo(String boxNo) =>
      boxes.any((b) => b.boxNo != null && _same(b.boxNo!, boxNo)) ||
      (current?.boxNo != null && _same(current!.boxNo!, boxNo));

  static bool _same(String a, String b) => a.toUpperCase() == b.toUpperCase();

  ReturnReceiveState copyWith({
    List<ReturnBoxDraft>? boxes,
    ReturnBoxDraft? current,
    String? activeModel,
    bool clearCurrent = false,
  }) =>
      ReturnReceiveState(
        boxes: boxes ?? this.boxes,
        current: clearCurrent ? null : current ?? this.current,
        activeModel: activeModel ?? this.activeModel,
      );
}

@riverpod
class ReturnReceiveNotifier extends _$ReturnReceiveNotifier {
  @override
  ReturnReceiveState build() => const ReturnReceiveState();

  /// Model cho thùng sắp mở. Không đổi model của thùng đang quét dở: serial
  /// đã quét vào đó thuộc model cũ, đổi là gán sai cho cả nhóm.
  void setActiveModel(String model) {
    state = state.copyWith(activeModel: model);
  }

  /// Mã quét được, định tuyến theo giai đoạn.
  Future<void> onScan(String raw) async {
    await ref.read(appActionProvider.notifier).run(() async {
      final code = raw.trim();
      if (code.isEmpty) return;

      if (state.current == null) {
        _openBox(code);
      } else {
        _addSerial(code);
      }
    });
  }

  void _openBox(String boxNo) {
    final model = state.activeModel;
    if (model == null) throw const ReturnNoModelSelectedException();

    // Quét lại nhãn thùng đã nhận trong chính phiên này.
    if (state.hasBoxNo(boxNo)) throw const BoxNoDuplicatedException();

    state = state.copyWith(
      current: ReturnBoxDraft(model: model, boxNo: boxNo),
    );
  }

  /// Hàng về rời, không còn thùng để quét: mở thùng không mã, server tự đặt
  /// tên theo Pallet ID.
  void openBoxWithoutCode() {
    final model = state.activeModel;
    if (model == null) throw const ReturnNoModelSelectedException();
    if (state.current != null) return;

    state = state.copyWith(current: ReturnBoxDraft(model: model));
  }

  void _addSerial(String serialNo) {
    // KHÔNG đổi hoa/thường: serial in trên máy có thể phân biệt, mà so sánh
    // thì đã không phân biệt rồi (cả ở đây và ở collation của DB).
    if (state.hasSerial(serialNo)) {
      throw ReturnDuplicateSerialException(serialNo);
    }

    final c = state.current!;
    state = state.copyWith(
      current: c.copyWith(serials: [...c.serials, serialNo]),
    );
  }

  /// Chốt thùng đang quét, sẵn sàng quét mã thùng kế tiếp.
  void finishBox() {
    final c = state.current;
    if (c == null) return;
    if (c.serials.isEmpty) throw const ReturnBoxEmptyException();

    state = ReturnReceiveState(
      boxes: [...state.boxes, c],
      activeModel: state.activeModel,
    );
  }

  /// Bỏ thùng đang quét (quét nhầm cả thùng).
  void cancelCurrentBox() {
    state = state.copyWith(clearCurrent: true);
  }

  void removeSerial(int index) {
    final c = state.current;
    if (c == null || index < 0 || index >= c.serials.length) return;

    final next = [...c.serials]..removeAt(index);
    state = state.copyWith(current: c.copyWith(serials: next));
  }

  void removeBox(int index) {
    if (index < 0 || index >= state.boxes.length) return;
    final next = [...state.boxes]..removeAt(index);
    state = ReturnReceiveState(
      boxes: next,
      current: state.current,
      activeModel: state.activeModel,
    );
  }

  /// Gửi toàn bộ bản nháp lên server.
  ///
  /// Thùng đang mở được chốt luôn nếu đã có serial — người dùng quét con cuối
  /// rồi bấm Lưu là chuyện bình thường, bắt họ bấm "Xong thùng" trước chỉ để
  /// vừa ý máy là vô lý.
  ///
  /// Trả `null` = lỗi, appActionProvider đã hiện thông báo của server.
  Future<ReturnReceiveResult?> submit(int docId) async {
    final c = state.current;
    if (c != null && c.serials.isNotEmpty) finishBox();

    final boxes = state.boxes;

    // Kiểm "chưa có gì để lưu" BÊN TRONG run(): ném ra ngoài thì không ai bắt
    // và màn hình chỉ đứng im, còn trong này appActionProvider hiện thông báo.
    final result = await ref.read(appActionProvider.notifier).run(() async {
      if (boxes.isEmpty) throw const ReturnNothingToSaveException();
      return ref
          .read(returnInstructionRepositoryProvider)
          .receive(docId: docId, boxes: boxes);
    });

    // Lưu được thì dọn bản nháp; lỗi thì GIỮ NGUYÊN để người dùng bấm lại,
    // không phải quét lại cả pallet.
    if (result != null) {
      state = ReturnReceiveState(activeModel: state.activeModel);
    }
    return result;
  }

  void reset() => state = const ReturnReceiveState();
}
