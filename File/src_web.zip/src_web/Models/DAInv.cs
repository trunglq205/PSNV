﻿using Newtonsoft.Json;
using static SWMS_WebTool.Models.DeliveryPlan;

namespace SWMS_WebTool.Models
{
    public class DAInv : DeliveryPlan
    {
        public int Id { get; set; }
        public string No { get; set; }
        public string GlobalCode { get; set; }
        public string VendorCode { get; set; }
        public DateTime DeliveryDate { get; set; }
        public List<DAInvDetail>? Details { get; set; }
    }

    public class DAInvDetail
    {
        [JsonProperty("daInvDetailId")]
        public int Id { get; set; }
        [JsonProperty("gRedTotalQuantity")]
        public int ActualQuantity { get; set; }
        public int TotalQuantity { get; set; }
        public string Material { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
        [JsonProperty("daInvoiceItemDetails")]
        public List<DAInvDetailItem> Items { get; set; }
    }

    public class DAInvDetailItem
    {
        [JsonProperty("daInvoiceDetailId")]
        public int Id { get; set; }
        [JsonProperty("poNo")]
        public string PurchaseOrderNo { get; set; }
        [JsonProperty("poItem")]
        public string PurchaseOrderItem { get; set; }
        [JsonProperty("daInvoiceItem")]
        public string DeliveryPlanItem { get; set; }
        public int PlanQuantity { get; set; }
        public int ActualQuantity { get; set; }
    }

    public class DeliveryPlanModel : DeliveryPlan
    {
        public long Id { get; set; }
        public string DeliveryPlanItem { get; set; }
        public string DeliveryPlanNo { get; set; }
        public string PONo { get; set; }
        public string POItem { get; set; }
        public double? PlanQuantity { get; set; }
        public double? ActualQuantity { get; set; }
        public string VendorCode { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }
        public DateTime? DAInvDate { get; set; }
    }
}
