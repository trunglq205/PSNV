using Swms.FinishGoods.API.Features.ShipmentTrips.Business;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

public interface IShipmentTripRepository
{
    // ── Đọc ─────────────────────────────────────────────────
    /// <summary>Chuyến (chưa xoá). from / toExclusive cùng null = không lọc ngày; có thì lấy chuyến có giờ
    /// dự kiến đến trong khoảng HOẶC có SI vanning trong khoảng.</summary>
    Task<List<TripRow>> GetListAsync(DateTime? from, DateTime? toExclusive, string? status, string? q, int max);
    Task<TripRow?> GetAsync(long id);
    Task<List<TripRow>> GetByIdsAsync(IReadOnlyCollection<long> ids);
    /// <summary>Id các chuyến (chưa xoá) có SI này.</summary>
    Task<List<long>> GetIdsBySiAsync(long siId);
    Task<List<TripSiRow>> GetSisByTripIdsAsync(IReadOnlyCollection<long> tripIds);

    // ── Kiểm tra ────────────────────────────────────────────
    /// <summary>SI chưa xoá trong danh sách id.</summary>
    Task<List<SiLinkInfo>> GetSiInfosAsync(IReadOnlyCollection<long> siIds);
    /// <summary>Chuyến chưa huỷ / chưa xoá đang chở các SI này (bỏ qua chuyến excludeTripId).</summary>
    Task<List<SiActiveTrip>> GetActiveTripsOfSisAsync(IReadOnlyCollection<long> siIds, long? excludeTripId);
    /// <summary>Số container đang thuộc 1 chuyến khác chưa xuất cổng / chưa huỷ.</summary>
    Task<bool> ContainerInUseAsync(string containerNo, long? excludeTripId);

    // ── Ghi ─────────────────────────────────────────────────
    Task<long> AddAsync(TripRow trip, IReadOnlyList<TripSiLink> sis);
    /// <summary>sis = null: giữ nguyên danh sách SI. false = chuyến không còn / đã xuất cổng / đã huỷ.</summary>
    Task<bool> UpdateAsync(TripRow trip, IReadOnlyList<TripSiLink>? sis);
    /// <summary>Đổi trạng thái nếu đang ở 1 trong các trạng thái from; ghi giờ + người của bước mới.</summary>
    Task<bool> TransitionAsync(long id, IReadOnlyCollection<string> from, string to, string? reason, string? actor);
    /// <summary>Chỉ chuyến còn planned.</summary>
    Task<bool> SoftDeleteAsync(long id, string? actor);
}
