﻿using System.Runtime.Serialization;

namespace SWMS_WebTool.Models
{
    public enum Status
    {
        [EnumMember(Value = "0")]
        Active,
        [EnumMember(Value = "1")]
        Deleted,
    }
}
