import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/assignment_card.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/pulse_dot.dart';

/// Khối "Việc của tôi": tiêu đề + đếm task + danh sách thẻ.
class AssignmentsSection extends StatelessWidget {
  final List<AssignmentData> items;
  final void Function(AssignmentData)? onTapItem;

  const AssignmentsSection({super.key, required this.items, this.onTapItem});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: AppDimens.md),
        Row(
          children: [
            const PulseDot(color: AppColors.success),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                LocaleKeys.home_my_tasks.tr().toUpperCase(),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.caption.copyWith(
                  color: swms.text2,
                  fontWeight: FontWeight.w800,
                  fontSize: 11,
                  letterSpacing: .6,
                ),
              ),
            ),
            const SizedBox(width: 8),
            Text(
              LocaleKeys.home_tasks_pending.plural(items.length),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.caption.copyWith(color: swms.text3),
            ),
          ],
        ),
        const SizedBox(height: AppDimens.sm),
        for (final a in items) ...[
          AssignmentCard(data: a, onTap: () => onTapItem?.call(a)),
          const SizedBox(height: 4),
        ],
      ],
    );
  }
}
