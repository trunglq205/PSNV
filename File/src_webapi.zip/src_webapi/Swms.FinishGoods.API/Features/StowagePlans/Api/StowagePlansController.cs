using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.StowagePlans.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.StowagePlans.Api;

/// <summary>Stowage Plan — sơ đồ xếp hàng vào container. Hiện 1 plan = 1 chuyến xe container.
/// Giai đoạn 1 dùng chung quyền SI như màn Chuyến xe: xem = Si.View, lưu = Si.Update.</summary>
[ApiController]
[Route("api/stowage-plans")]
public class StowagePlansController : ControllerBase
{
    private readonly IStowagePlanService _service;
    public StowagePlansController(IStowagePlanService service) => _service = service;

    /// <summary>VD: GET /api/stowage-plans/vanning-plans?keyword=TGHU&amp;status=Draft</summary>
    [HttpGet("vanning-plans")]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<List<VanningPlanSummaryDto>>> GetVanningPlans([FromQuery] StowagePlanQuery query)
        => Ok(await _service.GetListAsync(query));

    /// <summary>planNo = số plan đã lưu, hoặc "VP-T{tripId}" cho chuyến chưa lập sơ đồ.</summary>
    [HttpGet("{planNo}")]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<StowagePlanDto>> Get(string planNo)
        => Ok(await _service.GetAsync(planNo));

    /// <summary>Thay toàn bộ pallet / cọc / vị trí; trả plan sau khi lưu (id thật).</summary>
    [HttpPut("{planNo}")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<ActionResult<StowagePlanDto>> Save(string planNo, SaveStowagePlanRequest request)
        => Ok(await _service.SaveAsync(planNo, request));
}
