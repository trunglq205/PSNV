import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/feedback/feedback_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_pickup_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_fa_pallet_providers.dart';
import 'package:swms_finish_goods/shared/presentation/pda_scan_route_aware.dart';

// ─────────────────────────────────────────────────────────────
//  B5 — FA ĐẾN LẤY HÀNG RW/RB
//
//  Vì sao có màn này: trước đây SCS WH đặt pallet vào vị trí khu Nhận hàng là
//  serial sang luôn `at_fa`. Nhưng lúc đó hàng MỚI CHỈ nằm ở khu nhận hàng của
//  kho SCS — FA chưa đến lấy. Sổ nói "đang ở FA" trong khi hàng vẫn trong nhà
//  máy, và không ai đếm được còn bao nhiêu con đang nằm chờ FA.
//
//  Nay tách hai bước. Màn này là bước thứ hai: FA ra khu nhận hàng, quét Pallet
//  ID, hàng mới được tính là đã sang FA và pallet RỜI vị trí (không còn chiếm ô
//  trên bản đồ khu nhận hàng).
//
//  QUÉT MỘT MÃ PALLET, KHÔNG QUÉT TỪNG SERIAL: cả pallet đã được SCS WH tách
//  cho khớp SL đề nghị ở bước trước, FA chỉ xác nhận mang đi. Quét từng con ở
//  đây là bắt FA làm lại việc kho vừa làm.
//
//  ⚠ DÙNG ĐÚNG KHUÔN QUÉT CHUNG (sửa 16/11): `BarcodeScannerButton` + luồng
//  `pda.scanStream`, y như màn 2a/2d và mọi màn quét khác. Bản đầu tôi dựng ô
//  nhập chữ + nút Xác nhận — chạy thì chạy, nhưng người đứng kho đang quen mắt
//  với tấm thẻ quét đen ở giữa màn, đổi khuôn ở MỘT màn là màn đó đọc ra như
//  của phần mềm khác.
//
//  ĐIỀU HƯỚNG BẰNG MaterialPageRoute, không khai route auto_route — build_runner
//  trong source hiện tại đang vỡ (hai file cùng khai `@RoutePage() class
//  VanningPage`), thêm một @RoutePage là phải sinh lại app_router.gr.dart.
//
//  VÀO TỪ ĐÂU: nút trên thanh tiêu đề màn **Chỉ thị tái gia công**, gác bằng
//  `rework_refurbish.process_fa` (chốt 16/11 — PDA đã hiện chức năng theo bộ
//  phận rồi, không cần thêm một ô ở trang chủ).
//
//  QUYỀN: dùng lại `rework_refurbish.process_fa` — cùng một người của FA, cùng
//  một ca; thêm một lá quyền nữa chỉ tạo thêm chỗ để quên gán.
// ─────────────────────────────────────────────────────────────

/// Mở màn FA nhận hàng. Trả `true` nếu đã nhận được pallet nào — chỗ gọi dùng
/// nó để tải lại danh sách phiếu.
Future<bool> openFaPickupPage(BuildContext context) async {
  final done = await Navigator.of(context).push<bool>(
    MaterialPageRoute(builder: (_) => const _FaPickupPage()),
  );
  return done ?? false;
}

class _FaPickupPage extends ConsumerStatefulWidget {
  const _FaPickupPage();

  @override
  ConsumerState<_FaPickupPage> createState() => _FaPickupPageState();
}

class _FaPickupPageState extends ConsumerState<_FaPickupPage>
    with PdaScanRouteAware {
  bool _busy = false;

  /// Các lượt đã nhận TRONG PHIÊN này, mới nhất trước. Giữ lại để FA đối chiếu
  /// trước khi rời kho — chứ không phải lịch sử của phiếu.
  final List<FaPickupResult> _done = [];

  int get _pickedQty => _done.fold(0, (n, r) => n + r.pickedQty);

  @override
  void onScan(String data) {
    if (!mounted) return;
    _onScan(data);
  }

  // ── Nhận một mã pallet ────────────────────────────────────

  Future<void> _onScan(String raw) async {
    final code = raw.trim();
    if (code.isEmpty || _busy) return;

    setState(() => _busy = true);
    try {
      final res =
          await ref.read(returnFaPalletRepositoryProvider).faPickup(code);

      if (!mounted) return;
      unawaited(ref.read(appFeedbackProvider).success());
      setState(() => _done.insert(0, res));

      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_fa_pickup_ok.tr(
          namedArgs: {'qty': '${res.pickedQty}', 'lot': res.lotNo ?? code},
        ),
      );
    } catch (e) {
      if (!mounted) return;
      // ErrorHandler hiện NGUYÊN câu của server (và tự kêu feedback lỗi): ba lý
      // do không nhận được — chưa ra khu nhận hàng · không có gì chờ lấy ·
      // phiếu chưa được quản lý SCS duyệt — đều đã có câu riêng, bọc lại là
      // mất thông tin.
      await ref.read(errorHandlerProvider).handle(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        // Không hỏi lại: mỗi lượt quét đã ghi xong ngay lúc quét, thoát ra
        // không mất gì. Chỉ báo cho màn trước biết có cần tải lại không.
        Navigator.of(context).pop(_done.isNotEmpty);
      },
      child: Scaffold(
        appBar: AppTopBar(
          title: LocaleKeys.return_fa_pickup_title.tr(),
          subtitle: LocaleKeys.return_fa_pickup_subtitle.tr(),
        ),
        body: ListView(
          padding: const EdgeInsets.all(AppDimens.md),
          children: [
            BarcodeScannerButton(
              state: _busy ? ScannerState.loading : ScannerState.scanning,
              scanningLabel: LocaleKeys.return_fa_pickup_scan.tr(),
              loadingLabel: LocaleKeys.return_fa_pickup_saving.tr(),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.arrow_upward_rounded, size: 14, color: c.text3),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    LocaleKeys.return_fa_pickup_hint.tr(),
                    textAlign: TextAlign.center,
                    style: AppTextStyles.caption.copyWith(color: c.text2),
                  ),
                ),
              ],
            ),
            const SizedBox(height: AppDimens.md),

            if (_done.isEmpty)
              Padding(
                padding: const EdgeInsets.only(top: AppDimens.lg),
                child: Text(
                  LocaleKeys.return_fa_pickup_empty.tr(),
                  textAlign: TextAlign.center,
                  style: AppTextStyles.caption.copyWith(color: c.text3),
                ),
              )
            else ...[
              // Tổng của PHIÊN: FA đọc con số này trước khi đẩy xe ra cổng.
              Row(
                children: [
                  Text(
                    LocaleKeys.return_fa_pickup_done_title.tr(),
                    style: AppTextStyles.caption.copyWith(color: c.text2),
                  ),
                  const Spacer(),
                  StatusPill.success(
                    context,
                    label: LocaleKeys.return_fa_pickup_done_sum.tr(
                      namedArgs: {
                        'pallets': '${_done.length}',
                        'qty': '$_pickedQty',
                      },
                    ),
                  ),
                ],
              ),
              const SizedBox(height: AppDimens.sm),
              for (final row in _done) ...[
                _DoneRow(row: row),
                const SizedBox(height: AppDimens.sm),
              ],
            ],
          ],
        ),
      ),
    );
  }
}

/// Một lượt đã nhận: mã pallet · SL · phiếu · ô vừa lấy đi.
class _DoneRow extends StatelessWidget {
  const _DoneRow({required this.row});

  final FaPickupResult row;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Row(
        children: [
          Icon(Icons.check_circle, size: 20, color: c.success),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  row.lotNo ?? '',
                  style: AppTextStyles.body.copyWith(
                    fontWeight: FontWeight.w800,
                    color: c.text1,
                  ),
                ),
                Text(
                  LocaleKeys.return_fa_pickup_row.tr(namedArgs: {
                    'doc': row.docNo ?? '-',
                    'loc': row.locatorCode ?? '-',
                  }),
                  style: AppTextStyles.caption.copyWith(color: c.text3),
                ),
              ],
            ),
          ),
          Text(
            '${row.pickedQty}',
            style: AppTextStyles.body.copyWith(
              fontWeight: FontWeight.w800,
              color: c.success,
            ),
          ),
        ],
      ),
    );
  }
}
