﻿using Swms.FinishGoods.Api.Features.Categories;
using Swms.FinishGoods.Api.Features.Categories.Api;

namespace Swms.FinishGoods.API.Shared.DataAccess;

public interface ICategoryRepository
{
    Task<IReadOnlyList<CategoryEntity>> GetAllAsync(CategoryQuery query);
    Task<CategoryEntity?> GetByCodeAsync(int code);
    Task AddAsync(CategoryEntity entity);
    Task UpdateAsync(CategoryEntity entity);
    Task SoftDeleteAsync(int code, string? deletedBy);
    Task<bool> CodeExistsAsync(int code);
}