using Refit;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Client;

/// <summary>
/// Yêu cầu back hàng sang FA — mục 2c.
///
/// Tên query là camelCase: ASP.NET model binding KHÔNG phân biệt hoa thường
/// nhưng CÓ phân biệt dấu gạch dưới, nên <c>doc_id</c> sẽ không khớp vào
/// <c>BackRequestQuery.DocId</c>.
/// </summary>
public interface IReturnBackRequestApi
{
    [Get("/api/return-back-requests")]
    Task<List<ReturnBackRequestDto>> GetListAsync(
        [AliasAs("docId")] long? docId = null,
        [Query] string? status = null,
        [Query] string? step = null,
        [Query] string? keyword = null);

    [Get("/api/return-back-requests/{id}")]
    Task<ReturnBackRequestDto> GetByIdAsync(long id);

    /// <summary>SL còn gắp được theo model — màn soạn yêu cầu dùng.</summary>
    [Get("/api/return-back-requests/available/{docId}")]
    Task<List<BackAvailableModelDto>> GetAvailableAsync(long docId);

    [Post("/api/return-back-requests")]
    Task<ReturnBackRequestDto> CreateAsync([Body] CreateBackRequestRequestDto request);

    [Put("/api/return-back-requests/{id}")]
    Task<ReturnBackRequestDto> UpdateAsync(long id, [Body] UpdateBackRequestRequestDto request);

    /// <summary>B2 — quản lý FA duyệt.</summary>
    [Post("/api/return-back-requests/{id}/approve-fa")]
    Task<ReturnBackRequestDto> ApproveFaAsync(long id, [Body] BackRequestDecisionRequestDto request);

    /// <summary>B3 — SCS WH xác nhận và tạo chỉ thị back.</summary>
    [Post("/api/return-back-requests/{id}/instruct")]
    Task<ReturnBackRequestDto> InstructAsync(long id, [Body] BackRequestDecisionRequestDto request);

    /// <summary>
    /// B4 — quản lý SCS duyệt cho back. Bước này GẮP SERIAL và chuyển
    /// <c>at_fa</c>, nên nó là mốc hàng rời kho SCS.
    /// </summary>
    [Post("/api/return-back-requests/{id}/approve-scs")]
    Task<ReturnBackRequestDto> ApproveScsAsync(long id, [Body] BackRequestDecisionRequestDto request);

    [Post("/api/return-back-requests/{id}/cancel")]
    Task<ReturnBackRequestDto> CancelAsync(long id, [Body] BackRequestDecisionRequestDto request);
}
