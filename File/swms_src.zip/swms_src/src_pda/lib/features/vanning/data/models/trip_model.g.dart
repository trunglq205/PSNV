// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'trip_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TripSiModel _$TripSiModelFromJson(Map<String, dynamic> json) => TripSiModel(
  siId: (json['siId'] as num).toInt(),
  siNo: json['siNo'] as String,
  shipMode: json['shipMode'] as String?,
  pltPlanned: (json['pltPlanned'] as num?)?.toInt(),
  siPltTotal: (json['siPltTotal'] as num?)?.toInt() ?? 0,
);

TripModel _$TripModelFromJson(Map<String, dynamic> json) => TripModel(
  id: (json['id'] as num).toInt(),
  tripNo: json['tripNo'] as String,
  vehicleType: json['vehicleType'] as String,
  plateNo: json['plateNo'] as String?,
  containerNo: json['containerNo'] as String?,
  containerSize: json['containerSize'] as String?,
  sealNo: json['sealNo'] as String?,
  forwarderCode: json['forwarderCode'] as String?,
  plannedArrivalAt: json['plannedArrivalAt'] == null
      ? null
      : DateTime.parse(json['plannedArrivalAt'] as String),
  status: json['status'] as String,
  sis:
      (json['sis'] as List<dynamic>?)
          ?.map((e) => TripSiModel.fromJson(e as Map<String, dynamic>))
          .toList() ??
      const [],
);
