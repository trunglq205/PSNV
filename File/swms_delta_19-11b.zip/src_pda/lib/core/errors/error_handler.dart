import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/router/app_route_paths.dart';
import 'package:swms_finish_goods/core/utils/feedback/app_feedback.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_alert_dialog_helper.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';

enum _ErrorStyle { snackBar, dialog, sessionExpired }

class ErrorHandler {
  ErrorHandler(this._feedback, {this.onSessionExpired});

  final AppFeedback _feedback;

  /// Callback do tầng auth cung cấp: xoá token, clear cache, reset bloc...
  /// Để ErrorHandler ở core không phụ thuộc vào feature auth.
  final Future<void> Function()? onSessionExpired;

  /// Chặn nhiều request 401 cùng lúc -> nhiều dialog chồng nhau.
  bool _handlingSessionExpired = false;

  Future<void> handle(BuildContext context, Object error) async {
    final real = _unwrap(error);
    final style = _styleOf(real);
    final message = getMessage(real);

    unawaited(_feedback.error());

    switch (style) {
      case _ErrorStyle.snackBar:
        _showSnackBar(context, message);
      case _ErrorStyle.dialog:
        await _showDialog(context, message);
      case _ErrorStyle.sessionExpired:
        await _handleSessionExpired(context, message);
    }
  }

  String getMessage(Object error) {
    final real = _unwrap(error);
    if (real is InfraException) return real.message;
    if (real is AppException) {
      return real.code.tr(namedArgs: real.namedArgs);
    }
    return LocaleKeys.error_unknown.tr();
  }

  /// Gỡ lớp DioException để lấy exception THẬT.
  ///
  /// `ErrorInterceptor` không ném thẳng AppException được: Dio bắt buộc
  /// reject bằng một DioException, nên nó đặt exception thật vào
  /// `DioException.error`. `base_notifier_mixin` và `app_action_provider` tự
  /// gỡ lớp đó trước khi đẩy vào state, nhưng màn nào bắt lỗi bằng try/catch
  /// rồi đưa thẳng vào đây thì KHÔNG — và DioException không phải
  /// InfraException lẫn AppException, nên rơi xuống nhánh cuối.
  ///
  /// ⚠ Đã trả giá: màn "Đặt xe vào ô" hiện "Đã có lỗi không xác định" cho
  /// MỌI lỗi server — kể cả 404 lúc API chưa build lại — nuốt sạch câu thật.
  Object _unwrap(Object error) =>
      error is DioException ? (error.error ?? error) : error;

  _ErrorStyle _styleOf(Object error) {
    return switch (error) {
      UnauthorizedException() => _ErrorStyle.sessionExpired,
      ServerException() => _ErrorStyle.dialog,
      _ => _ErrorStyle.snackBar,
    };
  }

  Future<void> _handleSessionExpired(
    BuildContext context,
    String message,
  ) async {
    if (_handlingSessionExpired) return;
    _handlingSessionExpired = true;

    try {
      if (context.mounted) {
        await AppDialogHelper.error(
          context,
          title: LocaleKeys.error_title.tr(),
          message: message, // ví dụ: LocaleKeys.error_session_expired
        );
      }

      await onSessionExpired?.call(); // xoá token / clear session
      if (!context.mounted) return;
      await context.router.pushPath(AppRoutePaths.login);
    } finally {
      _handlingSessionExpired = false;
    }
  }

  void _showSnackBar(BuildContext context, String message) {
    AppToastHelper.toastError(context, message);
  }

  Future<void> _showDialog(BuildContext context, String message) {
    return AppDialogHelper.error(
      context,
      title: LocaleKeys.error_title.tr(),
      message: message,
    );
  }
}
