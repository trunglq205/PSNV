// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'receiving_pallet_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReceivingPalletModel _$ReceivingPalletModelFromJson(
  Map<String, dynamic> json,
) => ReceivingPalletModel(
  palletId: json['palletId'] as String,
  poCode: json['poCode'] as String,
  itemName: json['itemName'] as String,
  expected: (json['expected'] as num).toInt(),
  scanned: (json['scanned'] as num?)?.toInt() ?? 0,
);

Map<String, dynamic> _$ReceivingPalletModelToJson(
  ReceivingPalletModel instance,
) => <String, dynamic>{
  'palletId': instance.palletId,
  'poCode': instance.poCode,
  'itemName': instance.itemName,
  'scanned': instance.scanned,
  'expected': instance.expected,
};
