﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("tblActionHistory")]
    public class ActionHistory
    {
        [Key]
        public int Id { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        [StringLength(100)]
        public string ActionName { get; set; }

        [StringLength(255)]
        public string? FileName { get; set; }

        public DateTime CreatedAt { get; set; } = DateTime.Now;
    }
}