﻿namespace Swms.FinishGoods.API.Common.Models
{
    public class PagedQuery
    {
        public int Page { get; set; } = 1;
        public int Size { get; set; } = 20;
        public string? Keyword { get; set; }
    }
}
