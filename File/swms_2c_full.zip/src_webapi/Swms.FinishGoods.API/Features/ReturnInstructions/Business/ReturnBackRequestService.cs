using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

/// <summary>
/// Mục 2c — yêu cầu back hàng sang FA, bốn bước hai cấp duyệt.
///
/// Vì sao trạng thái nằm ở DB chứ không kiểm trong code rồi mới ghi: điều kiện
/// "đang ở đúng bước" nằm TRONG câu UPDATE của repository, nên hai người bấm
/// duyệt cùng lúc thì người sau không ăn gì và nhận
/// <see cref="ConflictException"/>, chứ không phải cả hai cùng ghi.
/// </summary>
public class ReturnBackRequestService : IReturnBackRequestService
{
    /// <summary>
    /// Trần số dòng một yêu cầu. Một chỉ thị nhận hàng thực tế có vài chục
    /// model; trần này chỉ để một request hỏng không kéo theo vài nghìn câu
    /// INSERT trong một transaction.
    /// </summary>
    private const int MaxLines = 200;

    private const int MaxModelLength = 100;
    private const int MaxNoteLength = 500;

    private readonly IReturnBackRequestRepository _repo;
    private readonly IReturnInstructionRepository _docs;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly ILogger<ReturnBackRequestService> _logger;

    public ReturnBackRequestService(
        IReturnBackRequestRepository repo,
        IReturnInstructionRepository docs,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        ILogger<ReturnBackRequestService> logger)
    {
        _repo = repo;
        _docs = docs;
        _currentUser = currentUser;
        _localizer = localizer;
        _logger = logger;
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    public async Task<IReadOnlyList<BackRequestResponse>> GetListAsync(BackRequestQuery query)
        => (await _repo.GetListAsync(query)).Select(BackRequestResponse.From).ToList();

    public async Task<BackRequestResponse> GetByIdAsync(long id)
        => BackRequestResponse.From(await LoadAsync(id));

    public Task<IReadOnlyList<BackAvailableModelResponse>> GetAvailableAsync(long docId)
        => _repo.GetAvailableAsync(docId);

    // ───────────────────────── B1 · FA tạo yêu cầu ─────────────────────────

    public async Task<BackRequestResponse> CreateAsync(CreateBackRequestRequest request)
    {
        var doc = await _docs.GetByIdAsync(request.DocId)
            ?? throw new NotFoundException(_localizer[BackMsg.DocNotFound, request.DocId]);

        if (doc.DocStatus == ReturnDocStatus.Cancelled)
            throw new BusinessRuleException(_localizer[BackMsg.DocCancelled, doc.DocNo]);

        var lines = await CleanLinesAsync(request.DocId, request.Lines);

        var id = await _repo.AddAsync(new ReturnBackRequest
        {
            DocId = request.DocId,
            Note = Trim(request.Note, MaxNoteLength),
            Lines = lines,
        }, Actor);

        return BackRequestResponse.From(await LoadAsync(id));
    }

    public async Task<BackRequestResponse> UpdateAsync(long id, UpdateBackRequestRequest request)
    {
        var current = await LoadAsync(id);
        RequireOpen(current);

        // Sửa được ở hai bước đầu: FA còn soạn, hoặc SCS WH đang xác nhận lại
        // thông tin (B3 — họ được phép chỉnh số trước khi trình quản lý SCS).
        if (current.CurrentStep is not (ReturnBackStep.FaApprove or ReturnBackStep.ScsInstruct))
            throw new ConflictException(
                _localizer[BackMsg.NotEditable, current.ReqNo, current.CurrentStep]);

        var lines = await CleanLinesAsync(current.DocId, request.Lines);

        await _repo.UpdateLinesAsync(id, Trim(request.Note, MaxNoteLength), lines, Actor);
        return BackRequestResponse.From(await LoadAsync(id));
    }

    // ─────────────────────────── Các bước duyệt ───────────────────────────

    public Task<BackRequestResponse> ApproveFaAsync(long id, BackRequestDecisionRequest request)
        => StepAsync(id,
            fromStep: ReturnBackStep.FaApprove,
            toStep: ReturnBackStep.ScsInstruct,
            toStatus: ReturnBackStatus.FaApproved,
            actorColumnPrefix: "fa_approved",
            comment: request.Comment);

    public Task<BackRequestResponse> InstructAsync(long id, BackRequestDecisionRequest request)
        => StepAsync(id,
            fromStep: ReturnBackStep.ScsInstruct,
            toStep: ReturnBackStep.ScsApprove,
            toStatus: ReturnBackStatus.ScsInstructed,
            actorColumnPrefix: "scs_instructed",
            comment: request.Comment);

    private async Task<BackRequestResponse> StepAsync(
        long id, string fromStep, string toStep, string toStatus,
        string actorColumnPrefix, string? comment)
    {
        var current = await LoadAsync(id);
        RequireOpen(current);

        var ok = await _repo.ApplyStepAsync(
            id, fromStep, toStep, toStatus, actorColumnPrefix,
            Trim(comment, MaxNoteLength), Actor);

        if (!ok)
            throw new ConflictException(
                _localizer[BackMsg.WrongStep, current.ReqNo, current.CurrentStep]);

        return BackRequestResponse.From(await LoadAsync(id));
    }

    // ───────────────── B4 · quản lý SCS duyệt + gắp serial ─────────────────

    public async Task<BackRequestResponse> ApproveScsAsync(
        long id, BackRequestDecisionRequest request)
    {
        var current = await LoadAsync(id);
        RequireOpen(current);

        if (current.Lines.Count == 0)
            throw new BusinessRuleException(_localizer[BackMsg.LinesRequired]);

        var taken = await _repo.ApproveAndAssignAsync(
            id, current.Lines, Trim(request.Comment, MaxNoteLength), Actor);

        // Rỗng = câu UPDATE bước không khớp dòng nào ⇒ ai đó đã duyệt hoặc huỷ
        // trước. Repository đã rollback nên không con serial nào bị gắp.
        if (taken.Count == 0)
            throw new ConflictException(
                _localizer[BackMsg.WrongStep, current.ReqNo, current.CurrentStep]);

        var total = taken.Values.Sum();
        if (total == 0)
            // Đã duyệt xong (transaction commit) nhưng kho không còn con nào để
            // gắp. KHÔNG ném lỗi: yêu cầu đã ở trạng thái đúng, ném lỗi ở đây
            // sẽ làm người dùng bấm lại và lần sau nhận WrongStep — không hiểu
            // gì. Ghi log và để bảng lệch trên màn hình nói sự thật.
            _logger.LogWarning(
                "Yeu cau back {ReqNo} da duyet nhung KHONG gap duoc serial nao — "
                + "kho khong con con nao o trang thai received cho cac model da xin.",
                current.ReqNo);
        else
            foreach (var l in current.Lines)
                if (taken.TryGetValue(l.Model, out var n) && n < l.Qty)
                    _logger.LogInformation(
                        "Yeu cau back {ReqNo} model {Model}: xin {Qty} nhung chi gap duoc {Taken}.",
                        current.ReqNo, l.Model, l.Qty, n);

        return BackRequestResponse.From(await LoadAsync(id));
    }

    public async Task<BackRequestResponse> CancelAsync(
        long id, BackRequestDecisionRequest request)
    {
        var current = await LoadAsync(id);

        if (current.IsCancelled)
            throw new ConflictException(_localizer[BackMsg.AlreadyCancelled, current.ReqNo]);

        // Đã cho back thì hàng đang ở FA — huỷ ở đây là mất dấu lô hàng đó.
        // Muốn kết thúc thì đi đường mục 3 (FA giao lại) hoặc đánh ng.
        if (current.IsApproved)
            throw new ConflictException(_localizer[BackMsg.AlreadyApproved, current.ReqNo]);

        if (!await _repo.CancelAsync(id, Trim(request.Comment, MaxNoteLength), Actor))
            throw new ConflictException(
                _localizer[BackMsg.WrongStep, current.ReqNo, current.CurrentStep]);

        return BackRequestResponse.From(await LoadAsync(id));
    }

    // ───────────────────────────── Hỗ trợ ─────────────────────────────

    private async Task<ReturnBackRequest> LoadAsync(long id)
        => await _repo.GetByIdAsync(id)
           ?? throw new NotFoundException(_localizer[BackMsg.NotFound, id]);

    private void RequireOpen(ReturnBackRequest r)
    {
        if (r.IsCancelled)
            throw new ConflictException(_localizer[BackMsg.AlreadyCancelled, r.ReqNo]);
        if (r.IsApproved)
            throw new ConflictException(_localizer[BackMsg.AlreadyApproved, r.ReqNo]);
    }

    /// <summary>
    /// Chuẩn hoá + kiểm dòng yêu cầu.
    ///
    /// Kiểm SL xin so với SL kho CÒN GẮP ĐƯỢC ngay ở đây, dù bước gắp thật là
    /// B4: để FA biết ngay lúc soạn, thay vì đi qua hai cấp duyệt rồi mới phát
    /// hiện kho không đủ hàng. Con số này có thể đổi giữa lúc soạn và lúc duyệt
    /// (một yêu cầu khác gắp trước), nên B4 vẫn gắp "được bao nhiêu lấy bấy
    /// nhiêu" và bảng lệch trên màn hình nói ra phần thiếu.
    /// </summary>
    private async Task<List<ReturnBackRequestLine>> CleanLinesAsync(
        long docId, IReadOnlyList<BackRequestLineRequest> raw)
    {
        if (raw.Count == 0)
            throw new BusinessRuleException(_localizer[BackMsg.LinesRequired]);

        if (raw.Count > MaxLines)
            throw new BusinessRuleException(_localizer[BackMsg.TooManyLines, MaxLines]);

        var lines = new List<ReturnBackRequestLine>(raw.Count);
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var r in raw)
        {
            var model = r.Model?.Trim();
            if (string.IsNullOrEmpty(model))
                throw new BusinessRuleException(_localizer[BackMsg.LinesRequired]);

            // Kiểm độ dài TRƯỚC khi vào transaction: để nguyên cho DB chặn sẽ
            // ném lỗi truncation thô giữa transaction, không dịch được.
            if (model.Length > MaxModelLength)
                throw new BusinessRuleException(
                    _localizer[BackMsg.ValueTooLong, model, MaxModelLength]);

            if (!seen.Add(model))
                throw new BusinessRuleException(_localizer[BackMsg.ModelDuplicated, model]);

            if (r.Qty <= 0)
                throw new BusinessRuleException(_localizer[BackMsg.LinesRequired]);

            lines.Add(new ReturnBackRequestLine
            {
                Model = model,
                Qty = r.Qty,
                Note = Trim(r.Note, MaxNoteLength),
            });
        }

        // Model phải có thật trong chỉ thị: xin một model không nằm trong phiếu
        // thì B4 gắp được 0 con và không ai hiểu vì sao.
        var docModels = new HashSet<string>(
            await _repo.GetDocModelsAsync(docId), StringComparer.OrdinalIgnoreCase);

        var unknown = lines.Select(l => l.Model)
            .Where(m => !docModels.Contains(m))
            .ToList();
        if (unknown.Count > 0)
            throw new BusinessRuleException(
                _localizer[BackMsg.ModelNotInDoc, string.Join(", ", unknown)]);

        var available = (await _repo.GetAvailableAsync(docId))
            .ToDictionary(a => a.Model, a => a.AvailableQty, StringComparer.OrdinalIgnoreCase);

        foreach (var l in lines)
        {
            var have = available.TryGetValue(l.Model, out var n) ? n : 0;
            if (l.Qty > have)
                throw new BusinessRuleException(
                    _localizer[BackMsg.QtyOverAvailable, l.Model, l.Qty, have]);
        }

        return lines;
    }

    private static string? Trim(string? s, int max)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        var t = s.Trim();
        return t.Length <= max ? t : t[..max];
    }
}
