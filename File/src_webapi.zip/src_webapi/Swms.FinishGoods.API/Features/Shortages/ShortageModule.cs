using Swms.FinishGoods.API.Features.Shortages.Business;
using Swms.FinishGoods.API.Features.Shortages.DataAccess;

namespace Swms.FinishGoods.API.Features.Shortages;

public static class ShortageModule
{
    public static IServiceCollection AddShortageFeature(this IServiceCollection services)
    {
        services.AddScoped<IShortageService, ShortageService>();
        services.AddScoped<IShortageRepository, ShortageRepository>();

        // Mail đi qua IMailSender dùng chung (đăng ký ở tầng Shared, cùng bản
        // phiếu bất thường đang dùng) — không đăng ký sender riêng ở đây nữa.
        return services;
    }
}
