import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/storage_map/domain/entities/storage_map_entities.dart';

part 'storage_map_models.g.dart';

/// Khớp `PositionOccResponse` (GET /api/storage/top-map → blocks[].positions[]).
@JsonSerializable()
class PositionOccModel {
  final int position;
  final int total;
  final int occupied;

  const PositionOccModel({
    required this.position,
    required this.total,
    required this.occupied,
  });

  factory PositionOccModel.fromJson(Map<String, dynamic> json) =>
      _$PositionOccModelFromJson(json);

  PositionOcc toEntity() =>
      PositionOcc(position: position, total: total, occupied: occupied);
}

/// Khớp `TopMapBlockResponse`.
@JsonSerializable()
class TopMapBlockModel {
  final int id;
  final String kind;
  final String? rackCode;
  final String? label;
  final String? color;
  final int gridX;
  final int gridY;
  final int gridW;
  final int gridH;
  final int totalSlots;
  final int occupiedSlots;
  final List<PositionOccModel> positions;
  final String? locatorCode;
  final String? status;
  final bool isUrgent;
  final String? model;
  final String? palletId;
  final int? boxCount;
  final DateTime? productionDate;

  const TopMapBlockModel({
    required this.id,
    required this.kind,
    required this.gridX,
    required this.gridY,
    required this.gridW,
    required this.gridH,
    this.rackCode,
    this.label,
    this.color,
    this.totalSlots = 0,
    this.occupiedSlots = 0,
    this.positions = const [],
    this.locatorCode,
    this.status,
    this.isUrgent = false,
    this.model,
    this.palletId,
    this.boxCount,
    this.productionDate,
  });

  factory TopMapBlockModel.fromJson(Map<String, dynamic> json) =>
      _$TopMapBlockModelFromJson(json);

  TopMapBlock toEntity() => TopMapBlock(
        id: id,
        kind: kind,
        rackCode: rackCode,
        label: label,
        color: color,
        gridX: gridX,
        gridY: gridY,
        gridW: gridW,
        gridH: gridH,
        totalSlots: totalSlots,
        occupiedSlots: occupiedSlots,
        positions: positions.map((e) => e.toEntity()).toList(),
        locatorCode: locatorCode,
        status: status,
        isUrgent: isUrgent,
        model: model,
        palletId: palletId,
        boxCount: boxCount,
        productionDate: productionDate,
      );
}

/// Khớp `TopMapResponse`.
@JsonSerializable()
class StorageTopMapModel {
  final int cols;
  final int rows;
  final List<TopMapBlockModel> blocks;

  const StorageTopMapModel({
    required this.cols,
    required this.rows,
    this.blocks = const [],
  });

  factory StorageTopMapModel.fromJson(Map<String, dynamic> json) =>
      _$StorageTopMapModelFromJson(json);

  StorageTopMap toEntity() => StorageTopMap(
        cols: cols,
        rows: rows,
        blocks: blocks.map((e) => e.toEntity()).toList(),
      );
}

/// Khớp `ElevationCellResponse`.
@JsonSerializable()
class ElevationCellModel {
  final int locatorId;
  final String locatorCode;
  final int location;
  final int floor;
  final String slotKind;
  final String? level;
  final bool occupied;
  final String? palletId;
  final String? model;
  final int? boxCount;
  final DateTime? productionDate;
  final String? disposition;
  final bool stopShipment;
  final String? status;
  @JsonKey(defaultValue: false)
  final bool isUrgent;

  const ElevationCellModel({
    required this.locatorId,
    required this.locatorCode,
    required this.location,
    required this.floor,
    required this.slotKind,
    required this.occupied,
    this.level,
    this.palletId,
    this.model,
    this.boxCount,
    this.productionDate,
    this.disposition,
    this.stopShipment = false,
    this.status,
    this.isUrgent = false,
  });

  factory ElevationCellModel.fromJson(Map<String, dynamic> json) =>
      _$ElevationCellModelFromJson(json);

  ElevationCell toEntity() => ElevationCell(
        locatorId: locatorId,
        locatorCode: locatorCode,
        location: location,
        floor: floor,
        slotKind: slotKind,
        level: level,
        occupied: occupied,
        palletId: palletId,
        model: model,
        boxCount: boxCount,
        productionDate: productionDate,
        disposition: disposition,
        stopShipment: stopShipment,
        status: status,
        isUrgent: isUrgent,
      );
}

/// Khớp `RackElevationResponse`.
@JsonSerializable()
class RackElevationModel {
  final String rackCode;
  final List<ElevationCellModel> cells;

  const RackElevationModel({required this.rackCode, this.cells = const []});

  factory RackElevationModel.fromJson(Map<String, dynamic> json) =>
      _$RackElevationModelFromJson(json);

  RackElevation toEntity() => RackElevation(
        rackCode: rackCode,
        cells: cells.map((e) => e.toEntity()).toList(),
      );
}


/// Tóm tắt 1 bản đồ kho (master.warehouse_areas) — để chọn trong dropdown.
@JsonSerializable()
class WarehouseAreaModel {
  final int id;
  final String areaCode;
  final String areaName;
  final String mapType;

  const WarehouseAreaModel({
    required this.id,
    required this.areaCode,
    required this.areaName,
    required this.mapType,
  });

  factory WarehouseAreaModel.fromJson(Map<String, dynamic> json) =>
      _$WarehouseAreaModelFromJson(json);

  WarehouseArea toEntity() =>
      WarehouseArea(id: id, areaCode: areaCode, areaName: areaName, mapType: mapType);
}

/// Khớp `LocatorLocationResponse` (GET /api/storage/locate/{code}).
@JsonSerializable()
class LocatorLocationModel {
  final String locatorCode;
  final String? areaCode;
  final String? areaName;
  final String? mapType;
  final String? rackCode;
  final int? rackCol;
  final int? rackRow;
  final String? rackLevel;

  const LocatorLocationModel({
    required this.locatorCode,
    this.areaCode,
    this.areaName,
    this.mapType,
    this.rackCode,
    this.rackCol,
    this.rackRow,
    this.rackLevel,
  });

  factory LocatorLocationModel.fromJson(Map<String, dynamic> json) =>
      _$LocatorLocationModelFromJson(json);

  Map<String, dynamic> toJson() => _$LocatorLocationModelToJson(this);

  LocatorLocation toEntity() => LocatorLocation(
        locatorCode: locatorCode,
        areaCode: areaCode,
        areaName: areaName,
        mapType: mapType,
        rackCode: rackCode,
        rackCol: rackCol,
        rackRow: rackRow,
        rackLevel: rackLevel,
      );
}

/// Khớp `PalletSerialResponse` (GET /api/storage/pallets/{palletCode}/serials).
@JsonSerializable()
class PalletSerialModel {
  final String? boxNo;
  final String? model;
  final String? serialNo;
  final int? qty;

  const PalletSerialModel({this.boxNo, this.model, this.serialNo, this.qty});

  factory PalletSerialModel.fromJson(Map<String, dynamic> json) =>
      _$PalletSerialModelFromJson(json);

  Map<String, dynamic> toJson() => _$PalletSerialModelToJson(this);

  PalletSerial toEntity() =>
      PalletSerial(boxNo: boxNo, model: model, serialNo: serialNo, qty: qty);
}
