import 'dart:io';

import 'package:android_intent_plus/android_intent.dart';
import 'package:flutter/services.dart';

class DataWedgeConfig {
  const DataWedgeConfig._();

  static Future<void> setBarcodeParams({
    required String profileName,
    required Map<String, String> params,
  }) async {
    if (!Platform.isAndroid) return;

    final intent = AndroidIntent(
      action: 'com.symbol.datawedge.api.ACTION',
      arguments: <String, dynamic>{
        'com.symbol.datawedge.api.SET_CONFIG': <String, dynamic>{
          'PROFILE_NAME': profileName,
          'PROFILE_ENABLED': 'true',
          'CONFIG_MODE': 'UPDATE',
          'PLUGIN_CONFIG': <String, dynamic>{
            'PLUGIN_NAME': 'BARCODE',
            'RESET_CONFIG': 'false',
            'PARAM_LIST': params,
          },
        },
      },
    );

    try {
      await intent.sendBroadcast();
    } on PlatformException {
      // Máy không phải Zebra hoặc không có DataWedge -> bỏ qua
    }
  }
}