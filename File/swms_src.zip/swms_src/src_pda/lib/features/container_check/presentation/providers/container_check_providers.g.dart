// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'container_check_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(containerCheckRemoteDataSource)
final containerCheckRemoteDataSourceProvider =
    ContainerCheckRemoteDataSourceProvider._();

final class ContainerCheckRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ContainerCheckRemoteDataSource,
          ContainerCheckRemoteDataSource,
          ContainerCheckRemoteDataSource
        >
    with $Provider<ContainerCheckRemoteDataSource> {
  ContainerCheckRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'containerCheckRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$containerCheckRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ContainerCheckRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ContainerCheckRemoteDataSource create(Ref ref) {
    return containerCheckRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ContainerCheckRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ContainerCheckRemoteDataSource>(
        value,
      ),
    );
  }
}

String _$containerCheckRemoteDataSourceHash() =>
    r'572b28f07df960cba3b17294484a5c4e24de1670';

@ProviderFor(containerCheckRepository)
final containerCheckRepositoryProvider = ContainerCheckRepositoryProvider._();

final class ContainerCheckRepositoryProvider
    extends
        $FunctionalProvider<
          ContainerCheckRepository,
          ContainerCheckRepository,
          ContainerCheckRepository
        >
    with $Provider<ContainerCheckRepository> {
  ContainerCheckRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'containerCheckRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$containerCheckRepositoryHash();

  @$internal
  @override
  $ProviderElement<ContainerCheckRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ContainerCheckRepository create(Ref ref) {
    return containerCheckRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ContainerCheckRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ContainerCheckRepository>(value),
    );
  }
}

String _$containerCheckRepositoryHash() =>
    r'56ef3f972cee8fc4267f44776e85ddbb64b03eca';
