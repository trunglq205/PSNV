import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/features/vanning/domain/vanning_entities.dart';

// Ảnh minh chứng + kiểm container của 1 chuyến (GET /shipment-trips/{id}/photos).
// Bộ ảnh do API quyết định theo loại xe (TripPhotoCatalog) — PDA không khai cứng mục ảnh.

/// Đơn vị của 1 mục ảnh. Mã khớp `unit` API trả về.
enum PhotoUnit {
  trip('trip', null),
  pallet('pallet', LocaleKeys.vanning_trip_unit_pallet),
  coc('coc', LocaleKeys.vanning_trip_unit_coc),
  row('row', LocaleKeys.vanning_trip_unit_row);

  const PhotoUnit(this.code, this.labelKey);
  final String code;

  /// null với ảnh theo chuyến (không có bộ chọn đơn vị).
  final String? labelKey;

  static PhotoUnit fromCode(String? code) => values.firstWhere(
        (u) => u.code == code?.toLowerCase(),
        orElse: () => PhotoUnit.trip,
      );
}

/// 1 mục ảnh bắt buộc, vd "4 góc trong cùng" (4 ảnh / chuyến) hay "Cân pallet" (1 ảnh / pallet).
class PhotoItemDef {
  final int step;
  final String stepTitle;
  final String key;
  final String label;
  final String? note;
  final int perUnit;
  final PhotoUnit unit;

  /// Số đơn vị ước tính (pallet / cọc / hàng); ảnh theo chuyến = 1.
  final int units;
  final List<String> slotLabels;

  const PhotoItemDef({
    required this.step,
    required this.stepTitle,
    required this.key,
    required this.label,
    this.note,
    required this.perUnit,
    required this.unit,
    required this.units,
    this.slotLabels = const [],
  });

  bool get perTrip => unit == PhotoUnit.trip;
  bool get perPallet => unit == PhotoUnit.pallet;
  bool get perCoc => unit == PhotoUnit.coc;
  int get required => perUnit * units;
}

/// Đơn vị của 1 ô ảnh — mỗi loại mục dùng 1 trường:
///   trip → cả 2 null · pallet → [palletCode] (quét tem) · cọc → [unitNo] = coc_no · hàng → [unitNo]
class PhotoUnitRef {
  final int? unitNo;
  final String? palletCode;
  final String label;

  const PhotoUnitRef({this.unitNo, this.palletCode, this.label = ''});

  static const trip = PhotoUnitRef();

  factory PhotoUnitRef.pallet(String code) =>
      PhotoUnitRef(palletCode: code, label: code);

  factory PhotoUnitRef.coc(int cocNo) =>
      PhotoUnitRef(unitNo: cocNo, label: 'C${cocNo.toString().padLeft(2, '0')}');

  factory PhotoUnitRef.row(int n) => PhotoUnitRef(unitNo: n, label: '$n');

  String get key => '${unitNo ?? 0}|${palletCode ?? ''}';

  @override
  bool operator ==(Object other) => other is PhotoUnitRef && other.key == key;

  @override
  int get hashCode => key.hashCode;
}

/// 1 Pallet List của chuyến (pallet thuộc chuyến còn hàng).
/// [cocNo] = đã ghép vào cọc nào; null = chưa ghép.
class TripPalletList {
  final String code;
  final int boxCount;
  final int pcs;
  final String? locatorCode;
  final int? cocNo;

  const TripPalletList({
    required this.code,
    required this.boxCount,
    required this.pcs,
    this.locatorCode,
    this.cocNo,
  });
}

/// 1 ảnh đã lên server. Đơn vị: [unitNo] (cọc / hàng) hoặc [palletCode] (pallet); cả 2 null = theo chuyến.
class TripPhoto {
  final int id;
  final String itemKey;
  final int? unitNo;
  final String? palletCode;
  final int slotNo;
  final DateTime createdAt;
  final String? createdBy;

  const TripPhoto({
    required this.id,
    required this.itemKey,
    required this.unitNo,
    this.palletCode,
    required this.slotNo,
    required this.createdAt,
    this.createdBy,
  });

  PhotoUnitRef get unit => PhotoUnitRef(unitNo: unitNo, palletCode: palletCode);

  /// Khoá ô: cùng khoá = chụp lại thay ảnh cũ (server làm y như vậy).
  String get slotKey => slotKeyOf(itemKey, unit, slotNo);

  static String slotKeyOf(String itemKey, PhotoUnitRef unit, int slotNo) =>
      '$itemKey|${unit.key}|$slotNo';
}

/// Hạng mục kiểm tình trạng container. [code] gửi lên server — đổi nhãn
/// thoải mái nhưng KHÔNG đổi code, báo cáo phía web đang group theo nó.
enum ContainerCondition {
  floor('floor', LocaleKeys.container_check_cond_floor),
  dry('dry', LocaleKeys.container_check_cond_dry),
  intact('intact', LocaleKeys.container_check_cond_intact),
  door('door', LocaleKeys.container_check_cond_door);

  const ContainerCondition(this.code, this.labelKey);
  final String code;
  final String labelKey;

  static ContainerCondition? fromCode(String code) {
    for (final c in values) {
      if (c.code == code) return c;
    }
    return null;
  }
}

enum InspectionResult {
  pass('pass'),

  /// Không đạt → container bị trả về đi rửa, hãng tàu cấp lại.
  fail('fail');

  const InspectionResult(this.code);
  final String code;

  static InspectionResult fromCode(String? code) =>
      code == 'pass' ? InspectionResult.pass : InspectionResult.fail;
}

/// Lần kiểm container mới nhất của chuyến.
class TripInspection {
  final InspectionResult result;
  final Set<ContainerCondition> passedConditions;
  final String? note;
  final String? containerNo;
  final DateTime inspectedAt;
  final String? inspectedBy;

  const TripInspection({
    required this.result,
    required this.passedConditions,
    this.note,
    this.containerNo,
    required this.inspectedAt,
    this.inspectedBy,
  });
}

/// Bộ ảnh + kết quả kiểm của 1 chuyến.
class TripEvidence {
  final int tripId;

  /// Chuyến còn mở (chưa xuất cổng / huỷ) — false thì chỉ xem.
  final bool canUpload;
  final int pallets;
  final int cocs;
  final int rows;
  final List<PhotoItemDef> items;
  final List<TripPhoto> photos;
  final TripInspection? inspection;

  /// Pallet List thật của chuyến (ảnh theo pallet chụp theo danh sách này).
  final List<TripPalletList> palletLists;

  /// Cọc đã ghép — ảnh "Cọc pallet" chụp theo coc_no.
  final List<TripStack> stacks;

  const TripEvidence({
    required this.tripId,
    required this.canUpload,
    required this.pallets,
    required this.cocs,
    required this.rows,
    required this.items,
    required this.photos,
    this.inspection,
    this.palletLists = const [],
    this.stacks = const [],
  });

  List<PhotoItemDef> get palletItems => items.where((i) => i.perPallet).toList();
  List<PhotoItemDef> get cocItems => items.where((i) => i.perCoc).toList();

  /// Số ảnh bắt buộc cho 1 pallet (tổng mọi mục theo pallet).
  int get perPalletRequired => palletItems.fold(0, (s, i) => s + i.perUnit);

  /// Đếm từ [photos] để chụp xong là cập nhật ngay.
  int haveOfPallet(String code) {
    final keys = palletItems.map((i) => i.key).toSet();
    return photos
        .where((p) => keys.contains(p.itemKey) && p.palletCode == code)
        .length
        .clamp(0, perPalletRequired);
  }

  TripPalletList? findPallet(String code) {
    final c = code.trim().toUpperCase();
    for (final p in palletLists) {
      if (p.code.toUpperCase() == c) return p;
    }
    return null;
  }

  /// Đơn vị để chụp của 1 mục (trừ pallet — pallet chọn bằng quét tem).
  /// Cọc: theo cọc đã ghép; chưa ghép thì tạm C01..Cn theo ước tính.
  List<PhotoUnitRef> unitsOf(PhotoItemDef item) => switch (item.unit) {
        PhotoUnit.trip => const [PhotoUnitRef.trip],
        PhotoUnit.pallet => [for (final p in palletLists) PhotoUnitRef.pallet(p.code)],
        PhotoUnit.coc => stacks.isNotEmpty
            ? [for (final s in stacks) PhotoUnitRef.coc(s.cocNo)]
            : [for (var i = 1; i <= item.units; i++) PhotoUnitRef.coc(i)],
        PhotoUnit.row => [for (var i = 1; i <= item.units; i++) PhotoUnitRef.row(i)],
      };

  /// Các bước theo thứ tự: (số bước, tên bước).
  List<(int, String)> get steps {
    final seen = <int>{};
    return [
      for (final i in items)
        if (seen.add(i.step)) (i.step, i.stepTitle),
    ];
  }

  List<PhotoItemDef> itemsOf(int step) =>
      items.where((i) => i.step == step).toList();

  List<TripPhoto> photosOf(String key) =>
      photos.where((p) => p.itemKey == key).toList();

  TripPhoto? photoAt(String key, PhotoUnitRef unit, int slotNo) {
    for (final p in photos) {
      if (p.itemKey == key && p.unit == unit && p.slotNo == slotNo) return p;
    }
    return null;
  }

  bool unitDone(PhotoItemDef item, PhotoUnitRef unit) {
    for (var s = 1; s <= item.perUnit; s++) {
      if (photoAt(item.key, unit, s) == null) return false;
    }
    return true;
  }

  /// Ảnh đã có / bắt buộc của 1 nhóm mục.
  int haveOfItems(Iterable<PhotoItemDef> list) =>
      list.fold(0, (s, i) => s + haveOf(i));
  int requiredOfItems(Iterable<PhotoItemDef> list) =>
      list.fold(0, (s, i) => s + i.required);

  /// Đếm lại từ [photos] (không dùng số API trả) để upload xong là cập nhật ngay.
  int haveOf(PhotoItemDef item) =>
      photosOf(item.key).length.clamp(0, item.required);

  int requiredOf(int step) =>
      itemsOf(step).fold(0, (s, i) => s + i.required);

  int haveOfStep(int step) =>
      itemsOf(step).fold(0, (s, i) => s + haveOf(i));

  int get required => items.fold(0, (s, i) => s + i.required);
  int get have => items.fold(0, (s, i) => s + haveOf(i));

  bool stepComplete(int step) => haveOfStep(step) >= requiredOf(step);

  /// Ảnh chụp xong thay đúng ô (cùng mục + đơn vị + ảnh thứ mấy).
  TripEvidence withPhoto(TripPhoto photo) => _copy(photos: [
        for (final p in photos)
          if (p.slotKey != photo.slotKey) p,
        photo,
      ]);

  TripEvidence withoutPhoto(int photoId) =>
      _copy(photos: photos.where((p) => p.id != photoId).toList());

  TripEvidence withInspection(TripInspection inspection) =>
      _copy(inspection: inspection);

  TripEvidence _copy({List<TripPhoto>? photos, TripInspection? inspection}) =>
      TripEvidence(
        tripId: tripId,
        canUpload: canUpload,
        pallets: pallets,
        cocs: cocs,
        rows: rows,
        items: items,
        photos: photos ?? this.photos,
        inspection: inspection ?? this.inspection,
        palletLists: palletLists,
        stacks: stacks,
      );
}
