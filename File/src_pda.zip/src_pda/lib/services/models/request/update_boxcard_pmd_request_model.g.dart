// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_boxcard_pmd_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UpdateBoxcardPMDRequestModel _$UpdateBoxcardPMDRequestModelFromJson(
        Map<String, dynamic> json) =>
    UpdateBoxcardPMDRequestModel(
      id: (json['id'] as num).toInt(),
      quantity: (json['quantity'] as num).toDouble(),
      userIDUpdate: json['userIDUpdate'] as String,
    );

Map<String, dynamic> _$UpdateBoxcardPMDRequestModelToJson(
        UpdateBoxcardPMDRequestModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'quantity': instance.quantity,
      'userIDUpdate': instance.userIDUpdate,
    };
