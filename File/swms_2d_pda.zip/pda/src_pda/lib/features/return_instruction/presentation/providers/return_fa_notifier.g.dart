// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_fa_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(FaScanNotifier)
final faScanProvider = FaScanNotifierProvider._();

final class FaScanNotifierProvider
    extends $NotifierProvider<FaScanNotifier, FaScanState> {
  FaScanNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'faScanProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$faScanNotifierHash();

  @$internal
  @override
  FaScanNotifier create() => FaScanNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(FaScanState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<FaScanState>(value),
    );
  }
}

String _$faScanNotifierHash() =>
    r'0000000000000000000000000000000000000000';

abstract class _$FaScanNotifier extends $Notifier<FaScanState> {
  FaScanState build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<FaScanState, FaScanState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<FaScanState, FaScanState>,
              FaScanState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
