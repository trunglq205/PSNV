using Swms.FinishGoods.API.Features.HdSoft.Business;
using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Swms.FinishGoods.API.Features.HdSoft.Api
{
    /// <summary>Một dòng lịch sử di chuyển của lot.</summary>
    public record HdSoftLotHistoryItemResponse(
        [property: JsonPropertyName("movement_date")] DateTime MovementDate,
        [property: JsonPropertyName("movement_time")] DateTime MovementTime,
        [property: JsonPropertyName("movement_type")] string MovementType,
        [property: JsonPropertyName("movement_type_desc")] string MovementTypeDescription,
        [property: JsonPropertyName("movement_qty")] decimal MovementQty,
        [property: JsonPropertyName("model")] string Model,
        [property: JsonPropertyName("locator")] string Locator,
        [property: JsonPropertyName("inout_doc_no")] string? InOutDocumentNo,
        [property: JsonPropertyName("movement_doc_no")] string? MovementDocumentNo)
    {
        // Chuẩn iDempiere. Mã lạ trả nguyên bản để không mất thông tin.
        private static readonly Dictionary<string, string> MovementTypeMap = new()
        {
            ["V+"] = "Nhận từ NCC",
            ["V-"] = "Trả NCC",
            ["C+"] = "Khách trả hàng",
            ["C-"] = "Xuất cho khách",
            ["M+"] = "Chuyển đến",
            ["M-"] = "Chuyển đi",
            ["I+"] = "Kiểm kê tăng",
            ["I-"] = "Kiểm kê giảm",
        };

        public static HdSoftLotHistoryItemResponse From(HdSoftLotMovementRow r)
            => new(
                r.MovementDate,
                r.MovementTime,
                r.MovementType,
                MovementTypeMap.TryGetValue(r.MovementType, out var desc) ? desc : r.MovementType,
                r.MovementQty,
                r.Model,
                r.Locator,
                r.InOutDocumentNo,
                r.MovementDocumentNo);
    }

    public record HdSoftPalletStockResponse(
        [property: JsonPropertyName("pallet_no")] string PalletNo,
        [property: JsonPropertyName("model")] string Model,
        [property: JsonPropertyName("locator")] string Locator,
        [property: JsonPropertyName("warehouse")] string Warehouse,
        [property: JsonPropertyName("qty_on_hand")] decimal QtyOnHand,
        [property: JsonPropertyName("date_in")] DateTime? DateIn)
        {
            public static HdSoftPalletStockResponse From(HdSoftPalletStockRow r)
                => new(
                    r.PalletNo,
                    HdSoftModel.Normalize(r.Model),
                    r.Locator,
                    r.Warehouse,
                    r.QtyOnHand,
                    r.DateIn);
    }
}
