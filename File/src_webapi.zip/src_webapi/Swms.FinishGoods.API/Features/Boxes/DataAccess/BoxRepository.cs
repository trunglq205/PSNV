﻿using Dapper;
using Swms.FinishGoods.API.Features.Boxes.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Text.Json;

namespace Swms.FinishGoods.API.Features.Boxes.DataAccess
{
    public interface IBoxRepository
    {
        /// <summary>Định danh duy nhất theo id.</summary>
        Task<BoxDetailEntity?> GetByIdAsync(long id);

        /// <summary>
        /// Tra box theo box_no (dùng cho quét). box_no KHÔNG duy nhất toàn cục
        /// nên trả về danh sách; caller phải lọc bằng palletId.
        /// </summary>
        Task<List<BoxDetailEntity>> FindByBoxNoAsync(string boxNo, string? palletId = null);

        /// <summary>
        /// Cập nhật PO của box theo id. null = xoá giá trị.
        /// Ghi event BOX_PO_CHANGED kèm giá trị trước/sau.
        /// </summary>
        Task<int> UpdatePoAsync(
            long id, string? customerPo, string? psnvPo,
            string? actor = null, string source = StockEventSources.Web);
    }

    public class BoxRepository : IBoxRepository
    {
        private readonly IDbConnectionFactory _factory;
        private readonly IStockEventWriter _events;

        public BoxRepository(IDbConnectionFactory factory, IStockEventWriter events)
        {
            _factory = factory;
            _events = events;
        }

        // Box + lot chứa + vị trí (vị trí ăn theo lot).
        private const string BoxSelect = """
            SELECT  b.id            AS Id,
                    b.box_no        AS BoxNo,
                    b.customer_po   AS CustomerPo,
                    b.psnv_po       AS PsnvPo,
                    b.production_date AS ProductionDate,
                    b.oqc_status    AS OqcStatus,
                    l.id            AS LotId,
                    b.raw_payload   AS Payload,
                    l.pallet_id     AS LotNo,
                    l.locator_id    AS LocatorId,
                    loc.locator_code AS LocatorCode,
                    a.area_code     AS AreaCode,
                    a.area_name     AS AreaName
            FROM wms.boxes b
            INNER JOIN wms.pallets l       ON l.id = b.lot_id AND l.is_deleted = 0
            LEFT JOIN master.locators loc  ON loc.id = l.locator_id AND loc.is_deleted = 0
            LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id AND a.is_deleted = 0
            WHERE b.is_deleted = 0
            """;

        private const string LinesSql = """
            SELECT  bl.id       AS Id,
                    bl.box_id   AS BoxId,
                    bl.model    AS Model,
                    bl.qty      AS Qty,
                    bl.serial_no AS SerialNo
            FROM wms.box_lines bl
            WHERE bl.box_id IN @boxIds AND bl.is_deleted = 0
            ORDER BY bl.box_id, bl.id;
            """;

        public async Task<BoxDetailEntity?> GetByIdAsync(long id)
        {
            using var conn = _factory.Create();

            const string sql = BoxSelect + " AND b.id = @id;";

            var box = await conn.QueryFirstOrDefaultAsync<BoxDetailEntity>(sql, new { id });
            if (box is null) return null;

            await LoadLinesAsync(conn, [box]);
            return box;
        }

        public async Task<List<BoxDetailEntity>> FindByBoxNoAsync(string boxNo, string? palletId = null)
        {
            using var conn = _factory.Create();

            const string sql = BoxSelect + """
                  AND b.box_no = @boxNo
                  AND (@palletId IS NULL OR l.pallet_id = @palletId)
                ORDER BY b.id;
                """;

            var boxes = (await conn.QueryAsync<BoxDetailEntity>(sql, new { boxNo, palletId })).ToList();
            if (boxes.Count == 0) return boxes;

            await LoadLinesAsync(conn, boxes);
            return boxes;
        }

        public async Task<int> UpdatePoAsync(
            long id, string? customerPo, string? psnvPo,
            string? actor = null, string source = StockEventSources.Web)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                // Đọc giá trị CŨ trước khi ghi đè. PO là dữ liệu đi ra khách hàng và
                // endpoint này mở cho quyền Temploc.Edit, nên phải lưu ai sửa từ gì
                // sang gì. Bản cũ UPDATE thẳng rồi mới GetByIdAsync -> mất giá trị cũ.
                const string beforeSql = """
                    SELECT customer_po AS CustomerPo, psnv_po AS PsnvPo
                    FROM wms.boxes
                    WHERE id = @id AND is_deleted = 0;
                    """;
                var before = await conn.QueryFirstOrDefaultAsync(beforeSql, new { id }, tx);
                if (before is null) { tx.Rollback(); return 0; }

                string? oldCustomerPo = (string?)before.CustomerPo;
                string? oldPsnvPo = (string?)before.PsnvPo;

                // SYSDATETIME() chứ không SYSUTCDATETIME(): toàn bộ hệ thống dùng giờ
                // nhà máy (xem LotRepository, PalletService.GenerateNextLotNoAsync).
                // Trộn hai loại làm timeline lệch 7 tiếng và sắp xếp sai thứ tự.
                const string sql = """
                    UPDATE wms.boxes
                    SET     customer_po = @customerPo,
                            psnv_po     = @psnvPo,
                            updated_at  = SYSDATETIME(),
                            updated_by  = @actor
                    WHERE id = @id AND is_deleted = 0;
                    """;

                var affected = await conn.ExecuteAsync(
                    sql, new { id, customerPo, psnvPo, actor }, tx);

                // Không đổi gì thì không ghi event — tránh rác timeline khi client
                // gửi lại nguyên giá trị cũ (BoxPatchRequest luôn gửi đủ field).
                var changed = !string.Equals(oldCustomerPo, customerPo, StringComparison.Ordinal)
                           || !string.Equals(oldPsnvPo, psnvPo, StringComparison.Ordinal);

                if (affected > 0 && changed)
                {
                    var payload = JsonSerializer.Serialize(new
                    {
                        customer_po = new { from = oldCustomerPo, to = customerPo },
                        psnv_po = new { from = oldPsnvPo, to = psnvPo },
                    });

                    await _events.WriteAsync(conn, tx, new StockEvent
                    {
                        SubjectType = StockEventSubjects.Box,
                        BoxId = id,
                        EventCode = StockEventCodes.BoxPoChanged,
                        Actor = actor,
                        Source = source,
                        Payload = payload,
                    });
                }

                tx.Commit();
                return affected;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        private static async Task LoadLinesAsync(System.Data.IDbConnection conn, IReadOnlyList<BoxDetailEntity> boxes)
        {
            var boxIds = boxes.Select(x => x.Id).ToArray();
            var lines = await conn.QueryAsync<BoxLineEntity>(LinesSql, new { boxIds });

            var map = lines.GroupBy(x => x.BoxId).ToDictionary(g => g.Key, g => g.ToList());
            foreach (var b in boxes)
                b.Lines = map.TryGetValue(b.Id, out var ls) ? ls : [];
        }
    }
}