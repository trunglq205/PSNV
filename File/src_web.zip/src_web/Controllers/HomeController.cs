﻿using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;

namespace SWMS_WebTool.Controllers;

public class HomeController : BaseController
{
    private readonly ILogger<HomeController> _logger;

    public HomeController(ILogger<HomeController> logger)
    {
        _logger = logger;
    }

    public IActionResult Index()
    {
        return View();
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error(string? message = null)
    {
        message ??= _loc.Get("Msg_GenericRequestError");
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier, Message = message });
    }

    public IActionResult NotFound()
    {
        return View("Views/Shared/NotFoundPage.cshtml");
    }
}

