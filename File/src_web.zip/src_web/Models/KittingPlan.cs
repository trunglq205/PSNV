﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace SWMS_WebTool.Models
{
    public class KittingPlan : AuditableEntity
    {
        public string Type { get; set; }
        public KittingTab Tab { get; set; }
        public string Model { get; set; }
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string SpecialPart { get; set; }
        public string PositionFA { get; set; }
        public double AssemblyQuantity { get; set; }
        public string ReceiptSloc { get; set; }
        public string PSNVStock { get; set; }
        public string KHFAN7 { get; set; }
        public string VenderName { get; set; }
        public double Quantity { get; set; }
        public string BarcodeLine { get; set; }
        public string Barcode { get; set; }
        public int ModelQuantity { get; set; }
        public string FreCategory { get; set; }
        public string Resvervation { get; set; }
        public string PartNo { get; set; }
        public string Urgent { get; set; }
        public double? PlanQuantity { get; set; }
        public double? ActualQuantity { get; set; }
        public DateTime? ConfirmDate { get; set; }
        public DateTime? ProductDate { get; set; }
        public string ConfirmID { get; set; }
        public string FromSloc { get; set; }
        public string ToSloc { get; set; }
        public string KitPic { get; set; }
        public string PullID { get; set; }
        public string UploadNo { get; set; }
        public string Material { get; set; }
        public string RequestDate { get; set; }
        public string Reason { get; set; }
        public string AutoSapDate { get; set; }
        public string TypeReport { get; set; }
        public string FinishGoods { get; set; }
        public string Assembly { get; set; }
        public string Lvl { get; set; }
        public string MovingType { get; set; }
        public string Descriptions { get; set; }
        public double MaterialQuantity { get; set; }
        public string Vendor { get; set; }
        public string Sloc { get; set; }
        public string SlocDIP { get; set; }
        public Int64 GroupID { get; set; }
        public Int64 ID { get; set; }
        public Int64 KittingLineID { get; set; }
        public string ReservationNo { get; set; }
        public string Frequency { get; set; }
        public string Recipient { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public string Unit { get; set; }
        public string Receipt_Location { get; set; }
        public string Issue_Sloc { get; set; }
        public string RoHS { get; set; }
        public string INS { get; set; }
        public string MaterialDescription { get; set; }
        public DateTime? RequirementsDate { get; set; }
        public string Tcode { get; set; }
        public string Remark { get; set; }
        public string GroupName { get; set; }
        public string Account { get; set; }
        public string CostCenter { get; set; }
        public string KittingTimeType { get; set; }
        public string KittingFrom { get; set; }
        public string KittingTypeDetail { get; set; }
        public string ModelFA { get; set; }
        public string PL { get; set; }
        public string STT { get; set; }
        public string MaterialType { get; set; }
        public string CategoryPL { get; set; }
        public string PositionJPT { get; set; }
        public string LocationName { get; set; }
        public bool IsUrgent { get; set; }
        public List<KittingPlan>? KittingPlans { get; set; }
        public int ReservationItem { get; set; }
    }
}
