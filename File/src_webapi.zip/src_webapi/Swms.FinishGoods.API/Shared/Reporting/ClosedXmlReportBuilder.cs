﻿using ClosedXML.Excel;

namespace Swms.FinishGoods.API.Shared.Reporting;

/// <summary>
/// Sinh Excel bằng ClosedXML (MIT). Đây là NƠI DUY NHẤT chạm ClosedXML —
/// muốn đổi thư viện sau này chỉ cần thay lớp này.
/// </summary>
public sealed class ClosedXmlReportBuilder : IExcelReportBuilder
{
    private static readonly XLColor HeaderFill = XLColor.FromHtml("#2F6FB0");
    private static readonly XLColor MetaKeyFill = XLColor.FromHtml("#EEF3F8");
    private static readonly XLColor Border = XLColor.FromHtml("#BFC9D4");

    public byte[] BuildTable<T>(ExcelTableReport<T> report)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add(string.IsNullOrWhiteSpace(report.SheetName) ? "Report" : report.SheetName);
        var colCount = Math.Max(1, report.Columns.Count);
        var row = 1;

        // ----- Title -----
        if (!string.IsNullOrWhiteSpace(report.Title))
        {
            var c = ws.Cell(row, 1);
            c.Value = report.Title;
            c.Style.Font.Bold = true;
            c.Style.Font.FontSize = 15;
            ws.Range(row, 1, row, colCount).Merge();
            row += 2;
        }

        // ----- Meta (key/value) -----
        foreach (var (k, v) in report.Meta)
        {
            var kc = ws.Cell(row, 1);
            kc.Value = k;
            kc.Style.Font.Bold = true;
            kc.Style.Fill.BackgroundColor = MetaKeyFill;
            var vc = ws.Cell(row, 2);
            vc.Value = v ?? string.Empty;
            if (colCount > 2) ws.Range(row, 2, row, colCount).Merge();
            row++;
        }
        if (report.Meta.Count > 0) row++;

        // ----- Table header -----
        var headerRow = row;
        for (var i = 0; i < report.Columns.Count; i++)
        {
            var col = report.Columns[i];
            var hc = ws.Cell(headerRow, i + 1);
            hc.Value = col.Header;
            hc.Style.Font.Bold = true;
            hc.Style.Font.FontColor = XLColor.White;
            hc.Style.Fill.BackgroundColor = HeaderFill;
            hc.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
            hc.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
            hc.Style.Border.OutsideBorderColor = Border;
        }
        row++;

        // ----- Data rows -----
        foreach (var item in report.Rows)
        {
            for (var i = 0; i < report.Columns.Count; i++)
            {
                var col = report.Columns[i];
                var cell = ws.Cell(row, i + 1);
                SetValue(cell, col.Value(item), col.Numeric);
                if (!string.IsNullOrEmpty(col.NumberFormat))
                    cell.Style.NumberFormat.Format = col.NumberFormat;
                if (col.Numeric)
                    cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Right;
                cell.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                cell.Style.Border.OutsideBorderColor = Border;
            }
            row++;
        }

        // ----- Summary -----
        if (report.Summary.Count > 0)
        {
            row++;
            foreach (var (k, v) in report.Summary)
            {
                var kc = ws.Cell(row, 1);
                kc.Value = k;
                kc.Style.Font.Bold = true;
                ws.Cell(row, 2).Value = v ?? string.Empty;
                row++;
            }
        }

        // ----- Widths + freeze -----
        // Tự co TRƯỚC, đặt bề rộng chỉ định SAU. Thứ tự ngược lại thì
        // AdjustToContents() ghi đè hết, nên ReportColumn.Width trước đây
        // không có tác dụng gì — khai bao nhiêu cũng vô nghĩa.
        //
        // Có cột cần chặn bề rộng thật: cột mô tả tự do mà để tự co thì nó
        // giãn bằng dòng mô tả dài nhất, bảng 27 cột thành ra kéo ngang mãi
        // không hết. Cột nào không khai Width vẫn tự co như cũ.
        ws.Columns().AdjustToContents();
        for (var i = 0; i < report.Columns.Count; i++)
        {
            var w = report.Columns[i].Width;
            if (w is > 0) ws.Column(i + 1).Width = w.Value;
        }
        if (report.Columns.Count > 0)
        {
            // Freeze(rows, cols) ghim hàng 1..rows VÀ cột 1..cols. Không khai
            // FreezeColumns thì vẫn chỉ ghim hàng, y như trước.
            if (report.FreezeColumns > 0)
                ws.SheetView.Freeze(headerRow, report.FreezeColumns);
            else
                ws.SheetView.FreezeRows(headerRow);
        }

        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    private static void SetValue(IXLCell cell, object? v, bool numeric)
    {
        switch (v)
        {
            case null:
                cell.Value = string.Empty;
                break;
            case string s:
                cell.Value = s;
                break;
            case DateTime dt:
                cell.Value = dt;
                break;
            case bool b:
                cell.Value = b;
                break;
            case byte or sbyte or short or ushort or int or uint or long or ulong or float or double or decimal:
                cell.Value = Convert.ToDouble(v);
                break;
            default:
                cell.Value = v.ToString() ?? string.Empty;
                break;
        }
    }
}
