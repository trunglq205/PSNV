import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';

/// State màn chi tiết chỉ thị — tách sẵn để thêm field (task soạn hàng,
/// thùng chỉ định…) mà không đổi cấu trúc.
class ShipmentInstructionDetailState {
  final AsyncValue<ShipmentInstructionDetail> detail;

  const ShipmentInstructionDetailState({
    this.detail = const AsyncValue.loading(),
  });

  ShipmentInstructionDetailState copyWith({
    AsyncValue<ShipmentInstructionDetail>? detail,
  }) => ShipmentInstructionDetailState(detail: detail ?? this.detail);
}
