# Tem pallet RW / RB — badge trên tem, đồng nhất ký hiệu, giữ dấu khi tách

12 file. **Không có script SQL.** Gói này **thay thế** `swms_pallet_label_rw.zip`
gửi trước đó (`LotRepository.cs` đã khác).

## 1. QR pallet ID tạo ở đâu (trả lời câu hỏi)

| Chỗ | File | Khi nào | RW/RB |
|---|---|---|---|
| PDA — tem 50×50, bản **mới** | `core/utils/printing/labels/qr_label.dart` → `QrLabelData` | Tách pallet · Chi tiết pallet · màn 2a | **có** |
| PDA — bản **cũ** trùng lặp | `core/utils/printing/labels/pallet_label.dart` → `PalletLabelData` | màn Nhận hàng | còn dùng |
| Web — in sẵn hàng loạt | `Features/Inventory/.../PrintPalletIdDialog.razor` | in trước dãy nhãn trắng | **không** |

Pallet ID = `{category:D3}{yyMMdd}{seq:D3}` = **đúng 12 ký tự**
(`PalletService.GenerateNextLotNoAsync`).

⚠ Màn Web kia in **nhãn trắng chưa gắn hàng** nên không thể có badge ⇒ **pallet
hàng back phải in tem tại chỗ**, không dùng nhãn in sẵn.

## 2. Cột đánh dấu: `wms.pallets.disposition` — đã có, đã ghi

`rework` | `refurbish` | NULL, cùng từ vựng với `return_instructions.goods_type`.
Màn 2a đã UPDATE nó trong **cùng transaction** tạo pallet. Bản đồ kho đã đọc cột
này từ trước. **Không cần cột mới.**

## 3. Badge trên tem

`QrLabelData` vốn đã tách `qr` (payload) và `caption` (chữ), nay thêm `badge`:

```dart
const QrLabelData.pallet(String lotNo, {this.badge})
static String? badgeForDisposition(String? d) =>
    switch (d) { 'rework' => 'RW', 'refurbish' => 'RB', _ => null };
```

**QR không đổi — vẫn 12 ký tự.** Bắt buộc, không phải lựa chọn:
`CreateLotRequest.LotNo` validate `^\d{12}$` (`LotModels.cs:122`), nên QR có đuôi
`-RW` sẽ bị **chính server từ chối** ở mọi màn quét.

**Vì sao badge riêng, không nối `-RW` vào chuỗi ID:** caption font `"4"` =
24 dot/ký tự, bắt đầu `_captionY = 40`, tem cao 400 dot.

| | Ký tự | Dài | Hết ở | Lề |
|---|---|---|---|---|
| hiện tại | 12 | 288 dot | y = 328 | 72 dot |
| nối `-RW` | 15 | 360 dot | y = **400** | **0** |

Badge nằm ở dải trống dưới QR (y 310..400), chữ to gấp 2 → đọc được từ xa, đúng
mục đích của ký hiệu này.

Nối vào ba chỗ in: **màn 2a** (badge từ `doc.goodsType`), **Chi tiết pallet**
(từ `pallet.disposition` — thiếu chỗ này thì tem in lại khác tem đang dán), và
**Tách pallet** (mục 5). Dialog in hiện `001251105001 · RW` để người bấm biết
trước tem sắp ra có ký hiệu gì.

## 4. Đồng nhất RW / RB — đã đổi hết RE → RB

Trước đây refurbish ghi `RE` trên bản đồ kho nhưng `RB` trên tem. Nay **cả ba
chỗ đều RW / RB**:

| Chỗ | File |
|---|---|
| Tem pallet | `core/utils/printing/labels/qr_label.dart:60` |
| Bản đồ kho PDA (chú thích + ô giá) | `features/storage_map/.../rack_elevation_sheet.dart:220,420` |
| Bản đồ kho Web | `Components/RackElevation.razor.cs` → `DispCode` |

Mỗi chỗ có comment trỏ sang hai chỗ kia — đổi một chỗ thì đổi cả ba.

KHÔNG đụng tới: `"RE"` trong `SiCompareModels.cs` là **mã trạng thái HdSoft**,
không liên quan refurbish. Và nhãn chữ đầy đủ `Refurbish` / `Rework` ở bảng chi
tiết giữ nguyên (không phải ký hiệu 2 chữ).

## 5. Tách pallet giữ dấu RW / RB

Hai chỗ cùng hỏng, sửa cả hai:

**API** — `ExecuteSplitAsync` clone lot mới từ lot gốc nhưng **không copy
`disposition`**. Đã thêm vào **cả hai** câu INSERT clone (có hai đường tách:
theo thùng và theo số lượng). Thiếu nó thì pallet con mất dấu RW/RB trên tem,
trên bản đồ kho, và mục 11 (list tồn rework) đếm thiếu.

**PDA** — `split_pallet_page.dart` in tem pallet con không badge. Nay lấy badge
theo `sourcePallet.disposition` (hợp lý vì server vừa clone đúng giá trị đó).

## 6. API — đưa `disposition` ra response

Trước đây nó **chỉ lộ ra qua StorageMap**, nên màn Chi tiết pallet không biết
pallet thuộc loại nào.

- `Pallet` entity: + `Disposition`
- `LotRepository.LotColumns`: + `l.disposition AS Disposition` — dùng chung bởi
  `GetOneAsync` (chi tiết) và `GetPagedAsync` (danh sách), một chỗ là đủ
- `PalletResponse`: + `string? Disposition`
- PDA: `PalletModel` / `Pallet` + `disposition`, `.g.dart` patch kèm

SELECT thẳng được, **không cần `COL_LENGTH` hay `EXEC`**: StorageMapRepository đã
đọc cột này không điều kiện từ trước, nên DB nào vẽ được bản đồ kho là đã có cột.
Khác `closed_at` ở mục 2b — cột đó do script của tôi thêm mới.

## 7. ⚠ Phải in thử rồi căn lại

Toạ độ badge là **ước tính, chưa in thử** — nhánh TSPL thì chính file gốc cũng
ghi *"CHƯA in thử trên MJ8001"*. Tất cả trong hằng số có tên:

| Nhánh | Hằng số | Giá trị |
|---|---|---|
| TSPL | `_badgeX` / `_badgeY` | 230 / 322 |
| TSPL | `_badgeBoxX1..Y2` | 214, 310, 342, 398 |
| TSPL | `_badgeFont` / `_badgeMul` | `"4"` / 2 |
| SBPL | `_sbplBadgeH` / `_sbplBadgeV` | `'0240'` / `'00300'` |
| SBPL | `_sbplBadgeFont` | `'080,084'` |

Khối SBPL dùng **đúng khuôn lệnh của caption** (đã in thật), nên rủi ro là badge
*lệch chỗ*, không phải *không in ra*. In một tem RW rồi gửi ảnh, tôi căn lại.

## 8. Áp dụng

1. Ghi đè 12 file.
2. Build API + Web + PDA.
3. PDA **không cần** `build_runner`: `pallet_model.g.dart` đã patch đúng khuôn
   json_serializable (`'disposition': ?instance.disposition`, cùng kiểu
   `stockyCode` bên cạnh).
4. In thử một tem RW → gửi ảnh để căn toạ độ.

## 9. Còn nợ (đã ghi tài liệu dự án)

`POST /api/pallets/split` vẫn **không cập nhật
`return_instruction_serials.pallet_id`** sang lot mới. Tách pallet hàng back thì
sổ serial còn trỏ vào pallet cũ. Khác với `disposition` ở gói này — chỗ đó cần
sửa cùng lúc với mục 2d/3 vì liên quan tới vòng đời serial.
