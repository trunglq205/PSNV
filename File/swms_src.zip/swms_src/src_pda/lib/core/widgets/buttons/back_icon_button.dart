import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

class BackIconButton extends StatelessWidget {
  const BackIconButton({super.key, this.onPressed});

  final VoidCallback? onPressed;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Material(
      color: Colors.transparent,
      child: InkWell(
        onTap: onPressed ?? () => Navigator.maybePop(context),
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
        child: Ink(
          height: 46,
          padding: const EdgeInsets.symmetric(horizontal: AppDimens.sm),
          decoration: BoxDecoration(
            color: Colors.transparent,
            borderRadius: BorderRadius.circular(AppDimens.rBtn),
            border: Border.all(color: swms.border),
          ),
          child: Center(
            child: Icon(Icons.chevron_left_rounded, size: 24, color: swms.text2),
          ),
        ),
      ),
    );
  }
}