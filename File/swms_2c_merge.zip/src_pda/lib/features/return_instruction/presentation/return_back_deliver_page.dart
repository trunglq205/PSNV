import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/feedback/feedback_provider.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_back_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2c · bước cuối — SCS WH giao hàng RW/RB cho FA.
//
//  Vào từ màn Chỉ thị back hàng: chạm phiếu → "Giao hàng cho FA" → quét.
//
//  MỘT MÀN, không hai: sau khi gộp đề nghị vào phiếu thì mỗi phiếu có đúng một
//  luồng back, nên không còn gì để chọn. Trước đây có thêm một màn chọn đề
//  nghị, và với phiếu chỉ có một đề nghị — tức gần như mọi phiếu — nó chỉ là
//  một lần chạm thừa khi WH đang đứng cạnh pallet.
//
//  ĐIỀU HƯỚNG BẰNG MaterialPageRoute, không khai route auto_route. Thêm một
//  @RoutePage là phải sinh lại app_router.gr.dart — file DÙNG CHUNG cả app, mà
//  build_runner trong source hiện tại đang vỡ (hai file cùng khai
//  `@RoutePage() class VanningPage`). Đây là việc làm một lượt từ một màn nên
//  không cần deep-link; đổi sang auto_route sau này chỉ là thêm annotation.
//
//  QUYỀN: `rework_refurbish.process`, khớp
//  `[RequirePermission<…Process>]` trên `POST {id}/deliver-back`. Màn này không
//  kiểm lại quyền — chỗ gọi đã ẩn nút khi không có.
// ─────────────────────────────────────────────────────────────

/// Mở màn giao hàng cho một phiếu.
///
/// Trả `true` khi đã giao được con nào — chỗ gọi dùng nó để tải lại danh sách.
Future<bool> openBackDeliverPage(
  BuildContext context, {
  required int docId,
  required String docNo,
  required BackFlow back,
}) async {
  final changed = await Navigator.of(context).push<bool>(
    MaterialPageRoute(
      builder: (_) => _ScanPage(docId: docId, docNo: docNo, back: back),
    ),
  );
  return changed ?? false;
}

class _ScanPage extends ConsumerStatefulWidget {
  const _ScanPage({
    required this.docId,
    required this.docNo,
    required this.back,
  });

  final int docId;
  final String docNo;
  final BackFlow back;

  @override
  ConsumerState<_ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends ConsumerState<_ScanPage> {
  StreamSubscription<String>? _sub;

  /// Mã đã quét, chưa gửi. Danh sách chứ không Set: THỨ TỰ quét là thứ tự WH
  /// xếp hàng lên xe, hiện đúng thứ tự thì họ soát lại bằng mắt được.
  final List<String> _lots = [];

  bool _saving = false;
  bool _changed = false;

  /// Kết quả lượt vừa xác nhận — giữ trên màn khi còn hàng chưa giao.
  BackDeliverResult? _last;

  /// Số liệu mới nhất của luồng back. Mỗi lượt giao xong thì server trả lại bản
  /// đã cập nhật, dùng nó thay vì giữ con số lúc mở màn.
  late BackFlow _back = widget.back;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Page đã dispose trong lúc chờ → không gán, tránh rò listener.
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      _onScan(data);
    });
  }

  /// Nhận một mã quét.
  ///
  /// Trùng thì KHÔNG thêm lần hai mà kêu một tiếng lỗi: quét hai lần cùng một
  /// pallet là chuyện thường ở máy quét, và gửi trùng lên server thì nhật ký có
  /// hai dòng cho một pallet với dòng thứ hai bằng 0 con.
  void _onScan(String raw) {
    final code = raw.trim();
    if (code.isEmpty || _saving) return;

    if (_lots.any((x) => x.toLowerCase() == code.toLowerCase())) {
      // error() chứ không phải success(): mã này KHÔNG được nhận, và tiếng bíp
      // là thứ duy nhất WH nghe được khi mắt đang nhìn pallet.
      ref.read(appFeedbackProvider).error();
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_back_scan_dup.tr(namedArgs: {'lot': code}),
      );
      return;
    }

    ref.read(appFeedbackProvider).success();
    setState(() => _lots.add(code));
  }

  void _remove(int ix) {
    if (ix < 0 || ix >= _lots.length) return;
    setState(() => _lots.removeAt(ix));
  }

  Future<void> _submit() async {
    if (_saving || _lots.isEmpty) return;

    final ok = await showConfirmDialog(
      context,
      title: LocaleKeys.return_back_confirm_title.tr(),
      message: LocaleKeys.return_back_confirm_msg.tr(namedArgs: {
        'count': '${_lots.length}',
        'docNo': widget.docNo,
      }),
      confirmLabel: LocaleKeys.return_back_confirm_ok.tr(),
      confirmVariant: AppButtonVariant.success,
    );
    if (!ok || !mounted) return;

    setState(() => _saving = true);
    try {
      // Lỗi API đã được appActionProvider bắt + toast → null.
      final res = await ref.read(appActionProvider.notifier).run(
            () => ref.read(returnBackRepositoryProvider).deliver(
                  docId: widget.docId,
                  lotNos: List<String>.from(_lots),
                ),
          );
      if (!mounted || res == null) return;

      setState(() {
        _last = res;
        _back = res.back ?? _back;
        // Chỉ xoá danh sách khi server ĐÃ nhận: xoá trước rồi gọi hỏng là WH
        // phải quét lại cả xe.
        _lots.clear();
        if (res.anyMoved) _changed = true;
      });

      ref.invalidate(backDeliveriesProvider(widget.docId));
      ref.invalidate(backRemainProvider(widget.docId));

      if (res.completed) {
        AppToastHelper.toastSuccess(
          context,
          LocaleKeys.return_back_done_all.tr(namedArgs: {'docNo': widget.docNo}),
        );
        // Giao xong cả phiếu thì không còn gì để quét — đóng màn luôn.
        Navigator.of(context).pop(true);
        return;
      }

      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_back_done_round.tr(namedArgs: {
          'qty': '${res.deliveredQty}',
          'remain': '${res.remainQty}',
        }),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        // Còn mã đã quét mà chưa gửi: hỏi lại. Thoát im lặng ở đây là mất cả
        // một xe hàng vừa quét mà không ai biết.
        if (_lots.isNotEmpty && !_saving) {
          final leave = await showConfirmDialog(
            context,
            title: LocaleKeys.return_back_leave_title.tr(),
            message: LocaleKeys.return_back_leave_msg
                .tr(namedArgs: {'count': '${_lots.length}'}),
            confirmLabel: LocaleKeys.return_back_leave_ok.tr(),
            confirmVariant: AppButtonVariant.danger,
          );
          if (!leave || !mounted) return;
        }
        if (mounted) Navigator.of(context).pop(_changed);
      },
      child: Scaffold(
        appBar: AppTopBar(
          title: LocaleKeys.return_back_scan_title.tr(),
          subtitle: widget.docNo,
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(AppDimens.md),
                children: [
                  _Summary(docId: widget.docId, back: _back, scanned: _lots.length),
                  const SizedBox(height: AppDimens.sm),

                  BarcodeScannerButton(
                    state:
                        _saving ? ScannerState.loading : ScannerState.scanning,
                    scanningLabel: LocaleKeys.return_back_scan_label.tr(),
                    loadingLabel: LocaleKeys.return_back_scan_saving.tr(),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.arrow_upward_rounded, size: 14, color: c.text3),
                      const SizedBox(width: 4),
                      Flexible(
                        child: Text(
                          LocaleKeys.return_back_scan_hint.tr(),
                          textAlign: TextAlign.center,
                          style: AppTextStyles.caption.copyWith(color: c.text2),
                        ),
                      ),
                    ],
                  ),

                  if (_last case final r?) ...[
                    const SizedBox(height: AppDimens.sm),
                    _LastRound(result: r),
                  ],

                  if (_lots.isNotEmpty) ...[
                    const SizedBox(height: AppDimens.sm),
                    _ScannedList(lots: _lots, onRemove: _remove),
                  ],

                  const SizedBox(height: AppDimens.sm),
                  _DeliveredLog(docId: widget.docId),
                ],
              ),
            ),

            // CTA ghim đáy màn: WH đeo găng, nút phải ở chỗ ngón tay vẫn tới
            // được mà không cuộn.
            Padding(
              padding: const EdgeInsets.all(AppDimens.md),
              child: AppButton(
                label: _lots.isEmpty
                    ? LocaleKeys.return_back_btn_submit_empty.tr()
                    : LocaleKeys.return_back_btn_submit
                        .tr(namedArgs: {'count': '${_lots.length}'}),
                variant: AppButtonVariant.success,
                size: AppButtonSize.lg,
                icon: Icons.local_shipping_outlined,
                isLoading: _saving,
                onPressed: _lots.isEmpty ? null : _submit,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Các khối nhỏ ────────────────────────────────────────────

/// Số liệu + bảng model còn ở kho, để WH soát "đúng hàng này không" trước khi
/// đẩy pallet.
class _Summary extends ConsumerWidget {
  const _Summary({
    required this.docId,
    required this.back,
    required this.scanned,
  });

  final int docId;
  final BackFlow back;
  final int scanned;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.swms;
    final rows = ref.watch(backRemainProvider(docId)).valueOrNull ??
        const <BackRemainModel>[];

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  LocaleKeys.return_back_remain_pcs
                      .tr(namedArgs: {'qty': '${back.remainQty}'}),
                  style: AppTextStyles.label.copyWith(
                    fontWeight: FontWeight.w700,
                    color: back.remainQty > 0 ? c.warning : c.success,
                  ),
                ),
              ),
              Text(
                LocaleKeys.return_back_scanned_count
                    .tr(namedArgs: {'count': '$scanned'}),
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            ],
          ),
          if (back.sentQty > 0) ...[
            const SizedBox(height: 2),
            Text(
              LocaleKeys.return_back_partly.tr(namedArgs: {
                'done': '${back.sentQty}',
                'total': '${back.sentQty + back.remainQty}',
              }),
              style: AppTextStyles.caption.copyWith(color: c.text2),
            ),
          ],
          // Bảng model nạp hỏng thì bỏ qua khối này thay vì hiện một khối đỏ:
          // đây là thông tin soát lại, không phải thứ chặn lượt quét.
          for (final r in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      r.model,
                      style: AppTextStyles.code
                          .copyWith(fontSize: 12, color: c.text1),
                    ),
                  ),
                  Text(
                    LocaleKeys.return_back_qty_pcs
                        .tr(namedArgs: {'qty': '${r.qty}'}),
                    style: AppTextStyles.label.copyWith(
                      fontWeight: FontWeight.w700,
                      color: c.text2,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Kết quả lượt vừa xác nhận. Mã sai và pallet rỗng là thứ WH phải đọc rồi đi
/// kiểm lại, nên để ngay trên màn chứ không chỉ một toast rồi biến mất.
class _LastRound extends StatelessWidget {
  const _LastRound({required this.result});

  final BackDeliverResult result;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_back_round_result.tr(namedArgs: {
              'qty': '${result.deliveredQty}',
              'pallets': '${result.pallets.length}',
            }),
            style: AppTextStyles.label.copyWith(
              fontWeight: FontWeight.w700,
              color: result.anyMoved ? c.success : c.warning,
            ),
          ),
          if (result.notFoundLots.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              LocaleKeys.return_back_lots_not_found
                  .tr(namedArgs: {'lots': result.notFoundLots.join(', ')}),
              style: AppTextStyles.caption.copyWith(color: c.danger),
            ),
          ],
          if (result.emptyLots.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              LocaleKeys.return_back_lots_empty
                  .tr(namedArgs: {'lots': result.emptyLots.join(', ')}),
              style: AppTextStyles.caption.copyWith(color: c.warning),
            ),
          ],
        ],
      ),
    );
  }
}

class _ScannedList extends StatelessWidget {
  const _ScannedList({required this.lots, required this.onRemove});

  final List<String> lots;
  final ValueChanged<int> onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_back_scanned_title.tr(),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
          for (var i = 0; i < lots.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  SizedBox(
                    width: 22,
                    child: Text('${i + 1}',
                        style: AppTextStyles.caption.copyWith(color: c.text3)),
                  ),
                  Expanded(
                    child: Text(
                      lots[i],
                      style: AppTextStyles.code
                          .copyWith(fontSize: 13, color: c.text1),
                    ),
                  ),
                  // Xoá được từng mã: quét nhầm pallet của phiếu khác là chuyện
                  // xảy ra, mà bắt quét lại cả xe thì không ai chịu.
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    constraints:
                        const BoxConstraints(minWidth: 36, minHeight: 36),
                    icon: Icon(Icons.close_rounded, size: 18, color: c.text3),
                    onPressed: () => onRemove(i),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Nhật ký pallet đã giao — giao dần nhiều lượt thì đây là chỗ duy nhất trả lời
/// "đã đẩy những pallet nào rồi".
class _DeliveredLog extends ConsumerWidget {
  const _DeliveredLog({required this.docId});

  final int docId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.swms;
    final rows = ref.watch(backDeliveriesProvider(docId)).valueOrNull ??
        const <BackDelivery>[];

    // Chưa giao gì thì không dựng thẻ rỗng. Lỗi tải nhật ký cũng im lặng: đây
    // là thông tin tham khảo, một khối đỏ ở đây làm WH tưởng lượt quét hỏng.
    if (rows.isEmpty) return const SizedBox.shrink();

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_back_log_title.tr(),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
          for (final d in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      d.lotNo,
                      style: AppTextStyles.code
                          .copyWith(fontSize: 12, color: c.text1),
                    ),
                  ),
                  Text(
                    LocaleKeys.return_back_qty_pcs
                        .tr(namedArgs: {'qty': '${d.serialCount}'}),
                    style: AppTextStyles.caption.copyWith(color: c.text2),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    DateFormat('dd/MM HH:mm').format(d.deliveredAt),
                    style: AppTextStyles.caption.copyWith(color: c.text3),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
