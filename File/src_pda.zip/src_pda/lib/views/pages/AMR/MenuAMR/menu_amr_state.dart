import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:smart_warehouse/shared/base/base_state.dart';
import 'package:smart_warehouse/shared/common/error_entity.dart';

part 'menu_amr_state.freezed.dart';

@freezed
class MenuAmrState extends BaseState with _$MenuAmrState {
  factory MenuAmrState({
    @Default(PageStatus.initial) PageStatus pageStatus,
    @Default(false) bool processing,
    @Default(null) ErrorEntity? errorEntity,
    @Default(null) String? Name,

  }) = _MenuAmrState;
}
