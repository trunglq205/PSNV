using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.ViewModels
{
    public class LoginViewModel
	{
        [Required(ErrorMessage = "ID is required.")]
        public string ID { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
    }

    public class ChangePasswordViewModel
    {
        [Required(ErrorMessage = "Old Password is required.")]
        public string OldPassword { get; set; }

        [Required(ErrorMessage = "Password is required.")]
        [DataType(DataType.Password)]
        public string NewPassword { get; set; }
    }
}

