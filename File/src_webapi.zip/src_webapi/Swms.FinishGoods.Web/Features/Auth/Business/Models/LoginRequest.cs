namespace Swms.FinishGoods.Web.Features.Auth.Business.Models;

public class LoginRequest
{
    public string Username { get; set; } = string.Empty;
    public string Password { get; set; } = string.Empty;
}
