/* ============================================================================
   Chuyển pallet hàng tái gia công sang inspection_status = 'ng'   (11/11)

   VÌ SAO:
     Pallet RW/RB trước đây được đóng dấu 'inspection_exempt'. Hai vấn đề:

     1) BỘ GOM HÀNG XUẤT chỉ loại pallet bằng `inspection_status <> N'ng'`
        (ShipmentInstructionRepository). 'inspection_exempt' LỌT bộ lọc đó, tức
        hàng tái gia công đang nằm trong kho CÓ THỂ bị gom vào một chỉ thị xuất
        và đi ra cổng. Đây là lý do chính.

     2) Nghiệp vụ chốt pallet mang trạng thái NG khi ra vị trí nhận hàng để
        giao FA. Để 'inspection_exempt' lúc trong kho rồi đổi sang 'ng' lúc ra
        là một pallet đổi màu trên bản đồ giữa đường, không ai giải thích được.

     'ng' vẫn là trạng thái CUỐI (cùng nhóm 'pass' / 'inspection_exempt' trong
     OqcFinalStatuses) nên pallet KHÔNG bị đẩy vào hàng đợi kiểm OQC.

   KÈM THEO Ở CODE (phải deploy cùng, nếu không WH mất nút Lưu kho):
     PalletDetailResponse.BuildAllowedActions mở "store" theo disposition thay
     vì theo trạng thái kiểm — pallet NG vẫn phải lưu kho được, vì NG là bản
     chất của hàng tái gia công chứ không phải kết quả OQC.

   CHẠY:
     @WhatIf = 1 (mặc định) chỉ IN RA những gì sẽ đổi, KHÔNG ghi.
     Soát số liệu xong thì đặt @WhatIf = 0 rồi chạy lại.
   ========================================================================= */

/* ---------- 0. Điều kiện tiên quyết — BATCH RIÊNG, có GO ----------

   Phải nằm ở batch riêng vì SQL Server bind TÊN CỘT lúc compile cả batch: nếu
   wms.pallets.disposition chưa tồn tại thì toàn bộ batch dưới KHÔNG CHẠY ĐƯỢC
   và chỉ ném lỗi 207 trơ trọi. Batch này chạy trước, in ra đúng việc phải làm.  */

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID(N'wms.pallets')
                 AND name = N'disposition')
BEGIN
    RAISERROR(N'THIEU cot wms.pallets.disposition. Chay return_back_merge_schema.sql truoc, roi chay lai script nay. (Batch duoi se bao loi 207 — bo qua, do la he qua.)',
              16, 1);
END
GO

SET NOCOUNT ON;

DECLARE @WhatIf bit = 1;        -- <<< đổi thành 0 để ghi thật

DECLARE @actor nvarchar(100) = N'migrate 11/11';

/* ---------- 1. Hiện trạng ---------- */

PRINT N'--- Pallet co disposition, theo inspection_status ---';

SELECT  p.disposition                      AS disposition,
        p.inspection_status                AS inspection_status,
        COUNT(*)                           AS so_pallet,
        SUM(CASE WHEN p.locator_id IS NULL THEN 0 ELSE 1 END) AS dang_co_vi_tri
FROM    wms.pallets p
WHERE   p.is_deleted = 0
  AND   p.disposition IS NOT NULL
GROUP BY p.disposition, p.inspection_status
ORDER BY p.disposition, p.inspection_status;

/* ---------- 2. Cảnh báo: pallet RW/RB đang NẰM TRONG danh sách gom hàng xuất
                 Đây là cái phải xem trước khi đổi — nếu có dòng, nghĩa là đã
                 có pallet tái gia công bị trỏ vào một chỉ thị xuất. Đổi trạng
                 thái sang 'ng' KHÔNG tự tháo nó ra khỏi chỉ thị đó.        */

PRINT N'';
PRINT N'--- CANH BAO: pallet RW/RB dang duoc tro boi shipment_instruction_boxes ---';

SELECT  RTRIM(p.pallet_id)  AS pallet_id,
        p.disposition       AS disposition,
        p.inspection_status AS inspection_status,
        COUNT(DISTINCT sb.line_id) AS so_dong_chi_thi,
        COUNT(*)            AS so_thung
FROM    wms.shipment_instruction_boxes sb
JOIN    wms.boxes   b ON b.id = sb.box_id  AND b.is_deleted = 0
JOIN    wms.pallets p ON p.id = b.lot_id   AND p.is_deleted = 0
WHERE   p.disposition IS NOT NULL
  AND   sb.picked_at IS NULL
GROUP BY p.pallet_id, p.disposition, p.inspection_status
ORDER BY so_dong_chi_thi DESC;

IF @@ROWCOUNT = 0 PRINT N'  (khong co — tot)';

/* ---------- 3. Danh sách sẽ đổi ---------- */

PRINT N'';
PRINT N'--- Se doi sang N''ng'' ---';

SELECT  RTRIM(p.pallet_id)  AS pallet_id,
        p.disposition       AS disposition,
        p.inspection_status AS tu_trang_thai,
        loc.locator_code    AS vi_tri,
        a.map_type          AS loai_khu
FROM      wms.pallets p
LEFT JOIN master.locators        loc ON loc.id = p.locator_id AND loc.is_deleted = 0
LEFT JOIN master.warehouse_areas a   ON a.id  = loc.area_id   AND a.is_deleted = 0
WHERE   p.is_deleted = 0
  AND   p.disposition IS NOT NULL
  AND   p.inspection_status <> N'ng'
ORDER BY p.id;

DECLARE @n int = @@ROWCOUNT;
PRINT CONCAT(N'  Tong: ', @n, N' pallet');

/* ---------- 4. Ghi ---------- */

IF @WhatIf = 1
BEGIN
    PRINT N'';
    PRINT N'@WhatIf = 1 — KHONG ghi gi. Dat @WhatIf = 0 roi chay lai de doi that.';
END
ELSE
BEGIN
    BEGIN TRAN;

    UPDATE  p
    SET     p.inspection_status = N'ng',
            p.updated_at        = SYSDATETIME(),
            p.updated_by        = @actor
    FROM    wms.pallets p
    WHERE   p.is_deleted = 0
      AND   p.disposition IS NOT NULL
      AND   p.inspection_status <> N'ng';

    PRINT CONCAT(N'Da doi ', @@ROWCOUNT, N' pallet sang N''ng''.');

    COMMIT;
END
GO
