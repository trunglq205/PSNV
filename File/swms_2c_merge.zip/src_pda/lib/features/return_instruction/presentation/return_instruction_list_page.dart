import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/widgets/common/app_tab_bar.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/dialogs/return_diff_dialog.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/return_back_deliver_page.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_instruction_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';
import 'package:swms_finish_goods/shared/presentation/providers/permission_providers.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Chỉ thị back hàng.
//  SCS Office nhập model / SL / ngày hàng về bên Web; SCS WH mở màn này để
//  biết sắp nhận gì, rồi quét nhận và chốt SL thực nhận.
//  Chạm vào một phiếu để bung chi tiết dòng. Kéo xuống để tải lại.
//
//  QUYỀN — giữ khớp từng dòng với controller bên API:
//    Tạo Pallet ID     → rework_refurbish.process
//                        (POST return-instructions/{id}/pallets)
//    Chốt thực nhận    → rework_refurbish.process HOẶC .create
//                        (POST return-instructions/{id}/close)
//    Giao hàng cho FA  → rework_refurbish.process
//                        (POST return-back-requests/{id}/deliver)
//  Không có quyền thì ẨN nút, không phải để bấm rồi ăn 403: giữa lúc quét
//  hàng thì một toast lỗi đỏ làm người dùng tưởng máy hỏng.
// ─────────────────────────────────────────────────────────────

/// Mã quyền — chép tay vì PDA không sinh hằng số quyền như bên Web.
/// Sai một ký tự là nút biến mất IM LẶNG, nên để một chỗ chứ đừng rải chuỗi.
const String _permProcess = 'rework_refurbish.process';
const String _permCreate = 'rework_refurbish.create';

@RoutePage()
class ReturnInstructionListPage extends ConsumerStatefulWidget {
  const ReturnInstructionListPage({super.key});

  @override
  ConsumerState<ReturnInstructionListPage> createState() =>
      _ReturnInstructionListPageState();
}

class _ReturnInstructionListPageState
    extends ConsumerState<ReturnInstructionListPage> {
  ReturnFilter _filter = ReturnFilter.open;

  /// Id phiếu đang bung chi tiết. Chỉ một phiếu mở tại một thời điểm —
  /// màn PDA hẹp, mở nhiều phiếu là phải cuộn rất xa mới thấy phiếu kế tiếp.
  int? _expanded;

  /// Mục 2b — chốt SL thực nhận.
  ///
  /// Cho người dùng xem BẢNG LỆCH trước khi xác nhận: bấm chốt là server gửi
  /// mail cho FA ngay, mà nội dung mail chính là bảng đó.
  Future<void> _close(ReturnInstruction doc) async {
    final ok = await showReturnDiffDialog(context, doc: doc);
    if (!ok || !mounted) return;

    // Lỗi API đã được appActionProvider bắt + toast → null.
    final saved = await ref.read(appActionProvider.notifier).run(
          () => ref.read(returnInstructionRepositoryProvider).close(doc.id),
        );
    if (!mounted || saved == null) return;

    ref.invalidate(returnInstructionListProvider);

    // Mail hỏng KHÔNG làm đổ việc chốt — nói ra để WH biết mà nhắc Office,
    // thay vì tưởng FA đã nhận được số.
    if (saved.actualMailSentAt == null) {
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_receive_closed_mail_failed
            .tr(namedArgs: {'docNo': saved.docNo}),
      );
    } else {
      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_receive_closed_ok
            .tr(namedArgs: {'docNo': saved.docNo}),
      );
    }
  }

  /// Mục 2c bước cuối — giao hàng RW/RB cho FA.
  ///
  /// Vào THẲNG màn quét: sau khi gộp đề nghị vào phiếu thì mỗi phiếu có đúng
  /// một luồng back, không còn gì để chọn. Nút chỉ hiện khi phiếu đang ở bước
  /// SCS giao hàng, nên không có cảnh mở ra rồi thấy rỗng.
  Future<void> _deliver(ReturnInstruction doc) async {
    final changed = await openBackDeliverPage(
      context,
      docId: doc.id,
      docNo: doc.docNo,
      back: doc.back,
    );
    // Hàng đã sang FA thì SL tồn của phiếu đổi → đọc lại danh sách.
    if (changed && mounted) ref.invalidate(returnInstructionListProvider);
  }

  /// Quyền quét nhận hàng — SCS WH. Dùng CHUNG cho cả nút Giao hàng cho FA:
  /// cả hai đều gác bằng rework_refurbish.process.
  bool get _mayReceive => ref.watch(myPermissionsProvider).can(_permProcess);

  /// Quyền chốt thực nhận — WH hoặc Office, khớp
  /// `RequireAnyPermission<Process, Create>` ở controller.
  bool get _mayClose {
    final perms = ref.watch(myPermissionsProvider);
    return perms.can(_permProcess) || perms.can(_permCreate);
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(returnInstructionListProvider(_filter.name));

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.return_instruction_title.tr(),
        subtitle: LocaleKeys.return_instruction_subtitle.tr(),
        actions: [
          IconButton(
            tooltip: LocaleKeys.return_instruction_refresh.tr(),
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(returnInstructionListProvider),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
                AppDimens.md, AppDimens.md, AppDimens.md, AppDimens.sm),
            child: AppTabBar<ReturnFilter>(
              expanded: true,
              items: [
                for (final f in ReturnFilter.values)
                  AppTabItem(value: f, label: f.labelKey.tr()),
              ],
              selected: _filter,
              // Mỗi bộ lọc một provider family riêng nên dữ liệu đã tải của
              // bộ lọc cũ vẫn còn — đổi qua đổi lại không gọi lại API.
              onChanged: (f) => setState(() {
                _filter = f;
                _expanded = null;
              }),
            ),
          ),
          Expanded(
            child: switch (async) {
              AsyncLoading() => const AppLoading(),
              AsyncError(:final error) => AppErrorView.page(
                  message: ref.read(errorHandlerProvider).getMessage(error),
                  onRetry: () => ref.invalidate(returnInstructionListProvider),
                ),
              AsyncValue(:final value) => _DocList(
                  docs: value ?? const [],
                  expanded: _expanded,
                  mayReceive: _mayReceive,
                  mayClose: _mayClose,
                  onToggle: (id) =>
                      setState(() => _expanded = _expanded == id ? null : id),
                  onRefresh: () async =>
                      ref.invalidate(returnInstructionListProvider),
                  onClose: _close,
                  onDeliver: _deliver,
                ),
            },
          ),
        ],
      ),
    );
  }
}

class _DocList extends StatelessWidget {
  final List<ReturnInstruction> docs;
  final int? expanded;
  final ValueChanged<int> onToggle;
  final Future<void> Function() onRefresh;

  /// Chốt thực nhận một phiếu (mục 2b).
  final Future<void> Function(ReturnInstruction) onClose;

  /// Giao hàng RW/RB cho FA (mục 2c, bước cuối).
  final Future<void> Function(ReturnInstruction) onDeliver;

  /// Có quyền quét nhận (`rework_refurbish.process`).
  final bool mayReceive;

  /// Có quyền chốt thực nhận (`process` hoặc `create`).
  final bool mayClose;

  const _DocList({
    required this.docs,
    required this.expanded,
    required this.onToggle,
    required this.onRefresh,
    required this.onClose,
    required this.onDeliver,
    required this.mayReceive,
    required this.mayClose,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    if (docs.isEmpty) {
      // Vẫn bọc RefreshIndicator: danh sách rỗng là lúc người dùng hay muốn
      // tải lại nhất, mà không bọc thì kéo xuống không có tác dụng gì.
      return RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 80),
              child: Text(
                LocaleKeys.return_instruction_empty.tr(),
                textAlign: TextAlign.center,
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(
            AppDimens.md, 0, AppDimens.md, AppDimens.md),
        itemCount: docs.length + 1,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (context, i) {
          if (i == 0) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                LocaleKeys.return_instruction_count.tr(namedArgs: {'count': '${docs.length}'}),
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            );
          }
          final doc = docs[i - 1];
          return _DocTile(
            doc: doc,
            open: expanded == doc.id,
            mayReceive: mayReceive,
            mayClose: mayClose,
            onTap: () => onToggle(doc.id),
            // Quay lại từ màn nhận hàng thì SL thực nhận đã khác → tải lại.
            onReceive: () async {
              await context.router.push(ReturnReceiveRoute(docId: doc.id));
              await onRefresh();
            },
            onClose: () => onClose(doc),
            onDeliver: () => onDeliver(doc),
          );
        },
      ),
    );
  }
}

class _DocTile extends StatelessWidget {
  final ReturnInstruction doc;
  final bool open;
  final VoidCallback onTap;
  final VoidCallback onReceive;
  final VoidCallback onClose;
  final VoidCallback onDeliver;
  final bool mayReceive;
  final bool mayClose;

  const _DocTile({
    required this.doc,
    required this.open,
    required this.onTap,
    required this.onReceive,
    required this.onClose,
    required this.onDeliver,
    required this.mayReceive,
    required this.mayClose,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.all(AppDimens.sm + 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          doc.docNo,
                          style: AppTextStyles.code.copyWith(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: c.text1,
                          ),
                        ),
                      ),
                      // Loại hàng của CẢ phiếu — số phiếu đã mang tiền tố
                      // RW-/RB- nhưng chip màu thì nhìn ra ngay từ xa.
                      _typePill(context, doc.goodsType),
                      const SizedBox(width: 4),
                      _statusPill(context, doc.status),
                      const SizedBox(width: 4),
                      Icon(
                        open ? Icons.expand_less : Icons.expand_more,
                        size: 18,
                        color: c.text3,
                      ),
                    ],
                  ),
                  if (doc.customer != null && doc.customer!.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(doc.customer!,
                        style: AppTextStyles.caption.copyWith(color: c.text2)),
                  ],
                  const SizedBox(height: 6),

                  // NGÀY HÀNG VỀ — thứ WH mở màn này để xem, nên đặt ngay
                  // dưới số phiếu.
                  Row(
                    children: [
                      Icon(Icons.event_outlined, size: 14, color: c.text3),
                      const SizedBox(width: 4),
                      Text(
                        doc.expectedDate == null
                            ? LocaleKeys.return_instruction_no_date.tr()
                            : DateFormat('dd/MM/yyyy').format(doc.expectedDate!),
                        style: AppTextStyles.label.copyWith(
                          color: doc.expectedDate == null ? c.text3 : c.text1,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        LocaleKeys.return_instruction_meta.tr(namedArgs: {
                          'models': '${doc.modelCount}',
                          'qty': '${doc.totalQty}',
                        }),
                        style: AppTextStyles.caption.copyWith(color: c.text3),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          if (open) ...[
            Divider(height: 1, color: c.border),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                  AppDimens.sm + 4, AppDimens.sm, AppDimens.sm + 4, AppDimens.sm + 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final l in doc.lines) _LineRow(line: l),
                  if (doc.note != null && doc.note!.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      '${LocaleKeys.return_instruction_note.tr()}: ${doc.note!}',
                      style: AppTextStyles.caption.copyWith(color: c.text3),
                    ),
                  ],

                  // Đã chốt: nói rõ FA đã được báo số thực nhận hay chưa.
                  if (doc.isClosed) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.verified_outlined, size: 13, color: c.text3),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            LocaleKeys.return_receive_closed_at.tr(namedArgs: {
                              'at': DateFormat('dd/MM HH:mm').format(doc.closedAt!),
                              'by': doc.closedBy ?? '—',
                            }),
                            style: AppTextStyles.caption.copyWith(color: c.text3),
                          ),
                        ),
                        if (doc.actualMailSentAt == null)
                          StatusPill.warning(
                            context,
                            label: LocaleKeys.return_receive_mail_not_sent.tr(),
                          ),
                      ],
                    ),
                  ],

                  // Cửa vào mục 2a + 2b. Chỉ hiện ở phiếu còn mở — phiếu đã
                  // đóng thì server cũng chặn nhận thêm.
                  //
                  // Hai nút hai quyền khác nhau nên xét riêng từng nút, và chỉ
                  // dựng cả hàng khi có ít nhất một nút: user chỉ có quyền XEM
                  // (SCS Office, FA) sẽ không thấy khoảng trống thừa dưới phiếu.
                  if (doc.isOpen && (mayReceive || (doc.hasReceipt && mayClose))) ...[
                    const SizedBox(height: AppDimens.sm),
                    Row(
                      children: [
                        if (mayReceive)
                          Expanded(
                            child: AppButton(
                              label: LocaleKeys.return_instruction_btn_receive.tr(),
                              variant: AppButtonVariant.primary,
                              size: AppButtonSize.sm,
                              icon: Icons.qr_code_scanner_rounded,
                              isFullWidth: false,
                              onPressed: onReceive,
                            ),
                          ),
                        // Chốt thực nhận chỉ hiện khi ĐÃ nhận được hàng: chốt
                        // một phiếu trống là gửi FA bảng toàn số 0.
                        if (doc.hasReceipt && mayClose) ...[
                          if (mayReceive) const SizedBox(width: AppDimens.sm),
                          Expanded(
                            child: AppButton(
                              label: LocaleKeys.return_receive_btn_close.tr(),
                              variant: AppButtonVariant.success,
                              size: AppButtonSize.sm,
                              icon: Icons.mark_email_read_outlined,
                              isFullWidth: false,
                              onPressed: onClose,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],

                  // Mục 2c bước cuối — GIAO HÀNG RW/RB CHO FA.
                  //
                  // Hàng RIÊNG, không nhồi vào hàng trên: ba nút cạnh nhau trên
                  // màn PDA thì nhãn bị cắt còn một hai chữ, và đây là việc
                  // KHÁC HẲN hai nút kia — hàng đi RA khỏi kho, không vào.
                  //
                  // CHỈ hiện khi phiếu đang ở bước SCS giao hàng (quản lý FA đã
                  // xác nhận), KHÔNG phải mọi phiếu đã nhận hàng: trước đó chưa
                  // ai đề nghị lấy về, bấm vào thì server chặn. Hiện cả SL còn
                  // phải giao ngay trên nhãn — WH biết luôn phải đẩy mấy con mà
                  // không cần mở màn.
                  if (doc.canDeliverBack && mayReceive) ...[
                    const SizedBox(height: AppDimens.sm),
                    AppButton(
                      label: LocaleKeys.return_back_btn_deliver
                          .tr(namedArgs: {'qty': '${doc.back.remainQty}'}),
                      variant: AppButtonVariant.warning,
                      size: AppButtonSize.sm,
                      icon: Icons.local_shipping_outlined,
                      onPressed: onDeliver,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _statusPill(BuildContext context, ReturnDocStatus s) => switch (s) {
        ReturnDocStatus.open =>
          StatusPill.info(context, label: s.labelKey.tr()),
        ReturnDocStatus.completed =>
          StatusPill.success(context, label: s.labelKey.tr()),
        ReturnDocStatus.cancelled =>
          StatusPill.neutral(context, label: s.labelKey.tr()),
      };

  /// Hai loại hàng hai màu, cùng tinh thần badge RW/RE trên bản đồ kho:
  /// người dùng quét bằng mắt chứ không đọc chữ.
  Widget _typePill(BuildContext context, ReturnGoodsType t) => switch (t) {
        ReturnGoodsType.rework =>
          StatusPill.warning(context, label: t.labelKey.tr()),
        ReturnGoodsType.refurbish =>
          StatusPill.info(context, label: t.labelKey.tr()),
      };
}

class _LineRow extends StatelessWidget {
  final ReturnInstructionLine line;
  const _LineRow({required this.line});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 20,
            child: Text('${line.lineNo}',
                style: AppTextStyles.caption.copyWith(color: c.text3)),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  line.model,
                  style: AppTextStyles.code.copyWith(fontSize: 12, color: c.text1),
                ),
                if (line.note != null && line.note!.isNotEmpty)
                  Text(line.note!,
                      style: AppTextStyles.caption.copyWith(color: c.text3)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                LocaleKeys.return_instruction_qty_pcs
                    .tr(namedArgs: {'qty': '${line.qty}'}),
                style: AppTextStyles.label.copyWith(
                  fontWeight: FontWeight.w700,
                  color: c.text1,
                ),
              ),
              // SL thực nhận: xanh khi đã đủ, cam khi vượt, xám khi còn thiếu.
              Text(
                LocaleKeys.return_instruction_received
                    .tr(namedArgs: {'qty': '${line.receivedQty}'}),
                style: AppTextStyles.caption.copyWith(
                  fontSize: 10.5,
                  color: line.remainingQty < 0
                      ? c.warning
                      : line.isDone
                          ? c.success
                          : c.text3,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
