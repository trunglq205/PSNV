﻿using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.AbnormalReports.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.AbnormalReports.Api;

[ApiController]
[Route("api/abnormal-reports")]
public class NgReportController : ControllerBase
{
    private readonly INgReportService _service;
    public NgReportController(INgReportService service) => _service = service;

    /// <summary>Danh sách phiếu hàng bất thường, lọc theo trạng thái / loại lỗi / ngày / từ khoá.</summary>
    [HttpGet]
    [RequirePermission<Perms.Receiving.AbnormalReport.View>]
    public async Task<ActionResult<IReadOnlyList<NgReportSummaryResponse>>> GetList(
        [FromQuery] string? status, [FromQuery] string? ngType,
        [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] string? keyword)
        => Ok(await _service.GetListAsync(status, ngType, from, to, keyword));

    /// <summary>
    /// Xuất Excel DANH SÁCH phiếu, nhận đúng bộ lọc như GET /api/abnormal-reports
    /// để file tải về khớp với những gì người dùng đang xem trên màn hình.
    ///
    /// Quyền View chứ không phải quyền riêng: nội dung file không có gì ngoài
    /// những cột màn danh sách đã hiện, đặt thêm một quyền nữa chỉ làm người
    /// quản trị phải nhớ gán hai quyền cho cùng một việc.
    /// </summary>
    [HttpGet("report.xlsx")]
    [RequirePermission<Perms.Receiving.AbnormalReport.View>]
    public async Task<IActionResult> Report(
        [FromQuery] string? status, [FromQuery] string? ngType,
        [FromQuery] DateTime? from, [FromQuery] DateTime? to, [FromQuery] string? keyword,
        [FromQuery] string? faRes, [FromQuery] string? oqc, [FromQuery] string? finalRes)
    {
        var (bytes, fileName) = await _service.BuildListReportAsync(
            status, ngType, from, to, keyword, faRes, oqc, finalRes);
        return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
    }

    /// <summary>Chi tiết 1 phiếu: phạm vi ảnh hưởng, ảnh, nhật ký duyệt.</summary>
    [HttpGet("{id:long}")]
    [RequirePermission<Perms.Receiving.AbnormalReport.View>]
    public async Task<ActionResult<NgReportDetailResponse>> Get(long id)
        => Ok(await _service.GetAsync(id));

    /// <summary>
    /// Tra pallet ngay lúc PDA quét mã, trước khi điền phiếu. 404 = mã không
    /// có trong hệ thống. KHÔNG tạo pallet mới — khác với
    /// GET /api/pallets/by-lot-no/{lotNo} vốn dựng lot từ Foss khi thiếu.
    /// </summary>
    /// <summary>
    /// Danh mục loại lỗi, nhãn theo ngôn ngữ người gọi. Quyền View chứ không
    /// phải quyền quản trị: ai xem được phiếu thì cũng cần đọc được tên loại
    /// lỗi trên phiếu đó.
    /// </summary>
    [HttpGet("types")]
    [RequirePermission<Perms.Receiving.AbnormalReport.View>]
    public async Task<ActionResult<IReadOnlyList<NgTypeResponse>>> GetTypes()
        => Ok(await _service.GetTypesAsync());

    // ---- Quản trị danh mục loại lỗi -------------------------------------
    // Quyền ManageTypes riêng, KHÔNG dùng chung với 5 quyền duyệt: đổi cờ
    // requires_oqc là đổi luồng duyệt của mọi phiếu lập sau đó.

    /// <summary>Danh mục cho màn quản trị: cả loại đang tắt, thô 4 ngôn ngữ.</summary>
    [HttpGet("types/all")]
    [RequirePermission<Perms.Receiving.AbnormalReport.ManageTypes>]
    public async Task<ActionResult<IReadOnlyList<NgTypeAdminResponse>>> GetTypesForAdmin()
        => Ok(await _service.GetTypesForAdminAsync());

    /// <summary>Thêm hoặc sửa. Mã đã có thì ghi đè, mã đã xoá mềm thì hồi sinh.</summary>
    [HttpPut("types")]
    [RequirePermission<Perms.Receiving.AbnormalReport.ManageTypes>]
    public async Task<IActionResult> SaveType([FromBody] SaveNgTypeRequest request)
    {
        await _service.SaveTypeAsync(request);
        return NoContent();
    }

    [HttpDelete("types/{code}")]
    [RequirePermission<Perms.Receiving.AbnormalReport.ManageTypes>]
    public async Task<IActionResult> DeleteType(string code)
    {
        await _service.DeleteTypeAsync(code);
        return NoContent();
    }

    [HttpGet("pallet-check")]
    [RequirePermission<Perms.Receiving.AbnormalReport.Create>]
    public async Task<ActionResult<NgPalletCheckResponse>> CheckPallet([FromQuery] string code)
        => Ok(await _service.CheckPalletAsync(code));

    /// <summary>Bước 1 — SCS tạo phiếu nháp trên 1 pallet đã quét.</summary>
    [HttpPost]
    [RequirePermission<Perms.Receiving.AbnormalReport.Create>]
    public async Task<ActionResult<CreateNgReportResponse>> Create([FromBody] CreateNgReportRequest request)
        => Ok(await _service.CreateAsync(request));

    /// <summary>Sửa phiếu khi còn ở trạng thái nháp.</summary>
    [HttpPut("{id:long}")]
    [RequirePermission<Perms.Receiving.AbnormalReport.Create>]
    public async Task<IActionResult> Update(long id, [FromBody] UpdateNgReportRequest request)
    {
        await _service.UpdateAsync(id, request);
        return Ok();
    }

    /// <summary>Xoá 1 ảnh của phiếu nháp.</summary>
    [HttpDelete("photos/{photoId:long}")]
    [RequirePermission<Perms.Receiving.AbnormalReport.Create>]
    public async Task<IActionResult> DeletePhoto(long photoId)
    {
        await _service.DeletePhotoAsync(photoId);
        return Ok();
    }

    /// <summary>Thêm ảnh lỗi cho phiếu (tối đa 5 ảnh).</summary>
    [HttpPost("{id:long}/photos")]
    [RequirePermission<Perms.Receiving.AbnormalReport.Create>]
    [RequestSizeLimit(30_000_000)]
    public async Task<IActionResult> AddPhoto(long id, IFormFile file)
    {
        if (file is null || file.Length == 0) return BadRequest();
        await using var stream = file.OpenReadStream();
        await _service.AddPhotoAsync(id, stream, file.FileName, file.Length);
        return Ok();
    }

    /// <summary>Tải ảnh: size = original | view | thumb.</summary>
    [HttpGet("photos/{photoId:long}")]
    [RequirePermission<Perms.Receiving.AbnormalReport.View>]
    public async Task<IActionResult> GetPhoto(long photoId, [FromQuery] string size = "view")
    {
        var (content, contentType, fileName) = await _service.GetPhotoAsync(photoId, size);
        return File(content, contentType, fileName);
    }

    /// <summary>
    /// Bước 2 — Leader SCS duyệt (submit) hoặc huỷ (cancel) phiếu nháp.
    /// Huỷ dùng CHUNG endpoint này nên cũng cần quyền leader_review: người tạo
    /// phiếu không tự huỷ được, phải qua Leader.
    /// </summary>
    /// <summary>
    /// Duyệt xong sẽ gửi mail cho ai — để Leader thấy trước khi bấm.
    ///
    /// Dùng quyền leader_review chứ KHÔNG phải system.email_config.view: đây là
    /// người duyệt xem mail của chính phiếu mình đang xử lý, không phải người
    /// quản trị mở cấu hình mail của cả hệ thống.
    /// </summary>
    [HttpGet("{id:long}/mail-preview")]
    [RequirePermission<Perms.Receiving.AbnormalReport.LeaderReview>]
    public async Task<ActionResult<MailPreviewResponse>> GetMailPreview(long id)
        => Ok(await _service.GetMailPreviewAsync(id));

    [HttpPost("{id:long}/leader-review")]
    [RequirePermission<Perms.Receiving.AbnormalReport.LeaderReview>]
    public async Task<IActionResult> LeaderReview(long id, [FromBody] LeaderReviewRequest request)
    {
        await _service.LeaderReviewAsync(id, request);
        return Ok();
    }

    /// <summary>
    /// Bước 3 — OQC kết luận chất lượng (ok | ng). OQC là người kết luận TRƯỚC;
    /// FA bị service chặn cho đến khi bước này xong.
    /// </summary>
    [HttpPost("{id:long}/oqc-confirm")]
    [RequirePermission<Perms.Receiving.AbnormalReport.OqcConfirm>]
    public async Task<IActionResult> OqcConfirm(long id, [FromBody] OqcConfirmRequest request)
    {
        await _service.OqcConfirmAsync(id, request);
        return Ok();
    }

    /// <summary>
    /// Bước 4 — FA kết luận OK hoặc NG. NG thì kèm hướng xử lý
    /// (replace | accept | return | scrap).
    /// </summary>
    [HttpPost("{id:long}/fa-confirm")]
    [RequirePermission<Perms.Receiving.AbnormalReport.FaConfirm>]
    public async Task<IActionResult> FaConfirm(long id, [FromBody] FaConfirmRequest request)
    {
        await _service.FaConfirmAsync(id, request);
        return Ok();
    }

    /// <summary>
    /// Bước 4b — FA báo đã xử lý xong lượt NG. Hàng quay lại OQC đánh giá lại;
    /// loại lỗi không cần qua OQC thì phiếu đóng luôn.
    /// </summary>
    [HttpPost("{id:long}/fa-fix-done")]
    [RequirePermission<Perms.Receiving.AbnormalReport.FaConfirm>]
    public async Task<IActionResult> FaFixDone(long id, [FromBody] FaFixDoneRequest request)
    {
        await _service.FaFixDoneAsync(id, request);
        return Ok();
    }

    // Endpoint "finalize" (SCS Supervisor chốt) đã BỎ 23/11 — phiếu tự đóng
    // khi OQC và FA cùng kết luận OK.
}
