using Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.AbnormalReports.Business;

public interface INgMailConfigBusiness
{
    /// <summary>Lấy 1 loại mail theo mã. Null nếu chưa khai trong master.email_events.</summary>
    Task<Result<NgEmailEventDto?>> GetEventAsync(string eventCode);

    Task<Result<List<NgEmailConfigDto>>> GetConfigsAsync(string eventCode);

    /// <summary>Id = 0 thì tạo mới, khác 0 thì cập nhật.</summary>
    Task<Result> SaveConfigAsync(NgEmailConfigDto config);

    Task<Result> DeleteConfigAsync(long id);

    Task<Result> SaveTemplateAsync(string eventCode, string subject, string? body);
}
