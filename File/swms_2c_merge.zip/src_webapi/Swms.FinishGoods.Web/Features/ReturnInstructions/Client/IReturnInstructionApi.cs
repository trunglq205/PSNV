using Refit;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Client;

public interface IReturnInstructionApi
{
    /// <summary>
    /// Danh sách chỉ thị. Mọi tham số lọc đều cho phép null = không lọc.
    /// Tên query là camelCase: ASP.NET model binding KHÔNG phân biệt hoa
    /// thường nhưng CÓ phân biệt dấu gạch dưới, nên goods_type sẽ không khớp
    /// vào ReturnInstructionQuery.GoodsType.
    /// </summary>
    [Get("/api/return-instructions")]
    Task<List<ReturnInstructionDto>> GetListAsync(
        [Query] string? status = null,
        [AliasAs("goodsType")] string? goodsType = null,
        [Query] string? keyword = null,
        [AliasAs("fromDate")] DateTime? fromDate = null,
        [AliasAs("toDate")] DateTime? toDate = null);

    [Get("/api/return-instructions/{id}")]
    Task<ReturnInstructionDto> GetByIdAsync(long id);

    [Post("/api/return-instructions")]
    Task<ReturnInstructionDto> CreateAsync([Body] ReturnInstructionRequestDto request);

    [Put("/api/return-instructions/{id}")]
    Task<ReturnInstructionDto> UpdateAsync(long id, [Body] ReturnInstructionRequestDto request);

    [Delete("/api/return-instructions/{id}")]
    Task DeleteAsync(long id);

    /// <summary>
    /// Pallet hàng return WH đã nhận vào phiếu (mục 2a). Màn Web chỉ ĐỌC —
    /// pallet do WH tạo trên PDA khi quét thùng + serial.
    /// </summary>
    [Get("/api/return-instructions/{id}/pallets")]
    Task<List<ReturnPalletDto>> GetPalletsAsync(long id);

    /// <summary>
    /// Huỷ một lần nhận: xoá pallet và GIẢI PHÓNG serial khỏi sổ của phiếu.
    ///
    /// Cần có đường này vì serial bị giữ trên phạm vi toàn hệ thống: pallet
    /// quét sai mà không tháo được thì những con hàng đó không quét lại được
    /// vào đâu nữa.
    /// </summary>
    [Delete("/api/return-instructions/{id}/pallets/{palletId}")]
    Task<ReturnInstructionDto> ReleasePalletAsync(long id, long palletId);

    /// <summary>
    /// Chốt SL thực nhận: đóng phiếu và TỰ GỬI MAIL báo FA số thực tế kèm bảng
    /// lệch. Lệch thiếu / vượt đều không chặn.
    /// </summary>
    [Post("/api/return-instructions/{id}/close")]
    Task<ReturnInstructionDto> CloseAsync(long id);

    /// <summary>
    /// Mở lại phiếu đã chốt để WH quét tiếp. Chốt lại sẽ gửi FA mail mới.
    /// </summary>
    [Post("/api/return-instructions/{id}/reopen")]
    Task<ReturnInstructionDto> ReopenAsync(long id);

    // ───────── Mục 2c · luồng nhận lại hàng về FA ─────────
    //
    // Cùng tiền tố route với phần trên vì sau khi gộp thì đây là một mặt của
    // phiếu. Bên API là controller riêng (ReturnBackFlowController) nhưng route
    // thì liền một bộ, nên client cũng để chung một interface — tách ra là
    // người đọc phải mở hai file mới thấy hết đường gọi của một màn.

    /// <summary>
    /// SL còn ở kho theo model — màn đề nghị gọi để CHO XEM phần sẽ lấy về.
    /// </summary>
    [Get("/api/return-instructions/{id}/back-remain")]
    Task<List<BackRemainModelDto>> GetBackRemainAsync(long id);

    /// <summary>Nhật ký pallet đã giao, mới nhất trước.</summary>
    [Get("/api/return-instructions/{id}/back-deliveries")]
    Task<List<BackDeliveryDto>> GetBackDeliveriesAsync(long id);

    /// <summary>B1 — FA đề nghị nhận lại hàng. Body chỉ có ghi chú.</summary>
    [Post("/api/return-instructions/{id}/request-back")]
    Task<BackFlowDto> RequestBackAsync(long id, [Body] RequestBackRequestDto request);

    /// <summary>Sửa ghi chú, chỉ khi còn chờ quản lý FA.</summary>
    [Put("/api/return-instructions/{id}/request-back")]
    Task<BackFlowDto> UpdateBackNoteAsync(long id, [Body] RequestBackRequestDto request);

    /// <summary>B2 — quản lý FA xác nhận. Mail sang SCS Office đi từ đây.</summary>
    [Post("/api/return-instructions/{id}/approve-back")]
    Task<BackFlowDto> ApproveBackAsync(long id, [Body] BackDecisionRequestDto request);

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA. Gọi được nhiều lần cho một
    /// phiếu; mail báo FA chỉ đi ở lượt làm xong cả phiếu.
    /// </summary>
    [Post("/api/return-instructions/{id}/deliver-back")]
    Task<BackDeliverResultDto> DeliverBackAsync(long id, [Body] DeliverBackRequestDto request);

    /// <summary>Huỷ đề nghị — chỉ khi chưa giao con nào.</summary>
    [Post("/api/return-instructions/{id}/cancel-back")]
    Task<BackFlowDto> CancelBackAsync(long id, [Body] BackDecisionRequestDto request);
}
