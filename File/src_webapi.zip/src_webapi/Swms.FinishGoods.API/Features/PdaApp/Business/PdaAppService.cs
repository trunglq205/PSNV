using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Api.Features.PdaApp.Api;
using Swms.FinishGoods.Api.Features.PdaApp.DataAccess;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.Api.Features.PdaApp.Business;

public class PdaAppService : IPdaAppService
{
    // Giới hạn kích thước APK (khớp UI Web: 150 MB).
    private const long MaxApkBytes = 150L * 1024 * 1024;

    private readonly IPdaAppRepository _repo;
    private readonly IApkInspector _inspector;
    private readonly IApkStorage _storage;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public PdaAppService(
        IPdaAppRepository repo,
        IApkInspector inspector,
        IApkStorage storage,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _inspector = inspector;
        _storage = storage;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    public async Task<List<PdaAppVersionResponse>> GetVersionsAsync()
    {
        var all = await _repo.GetAllAsync();
        return all.Select(PdaAppVersionResponse.From).ToList();
    }

    public async Task<PdaAppVersionResponse> PublishAsync(PublishPdaAppRequest request)
    {
        var file = request.File;

        // 1. Validate hình thức file.
        if (file is null || file.Length == 0)
            throw new BusinessRuleException(_localizer["PdaApp.FileRequired"]);
        if (file.Length > MaxApkBytes)
            throw new BusinessRuleException(_localizer["PdaApp.FileTooLarge"]);
        if (!file.FileName.EndsWith(".apk", StringComparison.OrdinalIgnoreCase))
            throw new BusinessRuleException(_localizer["PdaApp.NotApk"]);

        // 2. Đọc toàn bộ file 1 lần vào bộ nhớ để dùng lại cho cả đọc metadata lẫn lưu file.
        //    (IFormFile.OpenReadStream() không đảm bảo mở/tua lại được nhiều lần.)
        byte[] bytes;
        await using (var read = file.OpenReadStream())
        using (var buffer = new MemoryStream())
        {
            await read.CopyToAsync(buffer);
            bytes = buffer.ToArray();
        }

        // 2b. Đọc versionName/versionCode từ chính file APK (nguồn sự thật, không tin client).
        ApkInfo info;
        try
        {
            using var inspect = new MemoryStream(bytes, writable: false);
            info = await _inspector.ReadAsync(inspect);
        }
        catch (InvalidApkException ex)
        {
            throw new BusinessRuleException(_localizer["PdaApp.InvalidApk", ex.Message]);
        }

        // 3. Check trùng versionName.
        if (await _repo.VersionExistsAsync(info.Version))
            throw new ConflictException(_localizer["PdaApp.VersionExists", info.Version]);

        // 4. versionCode phải tăng so với bản mới nhất (tránh thiết bị "cập nhật lùi").
        var maxCode = await _repo.GetMaxVersionCodeAsync();
        if (info.VersionCode <= maxCode)
            throw new BusinessRuleException(
                _localizer["PdaApp.VersionCodeNotIncreasing", info.VersionCode, maxCode]);

        // 5. Lưu file APK lên storage (đồng thời là điểm phát hành "updateapp").
        string path, url;
        using (var save = new MemoryStream(bytes, writable: false))
        {
            (path, url) = await _storage.SaveAsync(save, info.Version, file.FileName);
        }

        // 6. Ghi DB trong transaction: bỏ current cũ, insert bản mới is_current = 1.
        var entity = new PdaAppVersionEntity
        {
            Version = info.Version,
            VersionCode = info.VersionCode,
            ReleaseNote = (request.ReleaseNote ?? "").Trim(),
            ApkPath = path,
            ApkUrl = url,
            SizeBytes = file.Length,
            ForceUpdate = request.ForceUpdate,
            PublishedAt = DateTime.UtcNow,
            CreatedBy = _currentUser.FullName,
        };
        entity.Id = await _repo.PublishAsync(entity);

        // 7. Đọc lại để trả response đầy đủ, nhất quán với GET.
        var full = await _repo.GetByIdAsync(entity.Id);
        return PdaAppVersionResponse.From(full ?? entity);
    }

    public async Task<(Stream Content, string FileName, string Version)> DownloadCurrentAsync()
    {
        var current = await _repo.GetCurrentAsync()
            ?? throw new NotFoundException(_localizer["PdaApp.NoCurrentVersion"]);

        // ApkPath do LocalApkStorage.SaveAsync trả về (vd "downloads\app_1.2.0.apk").
        var fullPath = Path.GetFullPath(current.ApkPath);
        if (!File.Exists(fullPath))
            throw new NotFoundException(_localizer["PdaApp.ApkFileMissing", current.Version]);

        Stream stream = new FileStream(fullPath, FileMode.Open, FileAccess.Read, FileShare.Read,
                                       bufferSize: 81920, useAsync: true);

        return (stream, $"app_{current.Version}.apk", current.Version);
    }
}