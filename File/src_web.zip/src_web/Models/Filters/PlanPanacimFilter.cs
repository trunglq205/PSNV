﻿namespace SWMS_WebTool.Models.Filters
{
    public class PlanPanacimFilter : BaseFilter
    {
        public string? Material { get; set; }
        public string? Plant { get; set; }
        public string? DeliveryDate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");
        public string? Invoice { get; set; }

    }
}
