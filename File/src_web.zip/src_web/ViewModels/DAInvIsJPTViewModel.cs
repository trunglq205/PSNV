﻿namespace SWMS_WebTool.ViewModels
{
    public class DAInvIsJPTViewModel
    {
        public Int64 DAInvID { get; set; }
        public string? DAInvNo { get; set; }
        public string? VendorCode { get; set; }
        public string? ReceivingCardID { get; set; }
        public Byte Status { get; set; }
    }
}
