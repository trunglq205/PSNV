namespace Swms.FinishGoods.API.Features.MapDesigner.DataAccess;

public interface IMapDesignerRepository
{
    Task<MapLayout?> GetLayoutAsync(string areaCode);
    Task SaveLayoutAsync(string areaCode, IReadOnlyList<MapBlock> blocks, string? user);
    Task<long> CreateRackAsync(string areaCode, CreateRackInput input, string? user);
    Task DeleteRackAsync(string areaCode, string rackCode, string? user);
    Task<bool> RackHasStockAsync(string areaCode, string rackCode);
    Task<bool> LocatorCodeExistsAsync(string locatorCode, long? exceptLocatorId = null);
}
