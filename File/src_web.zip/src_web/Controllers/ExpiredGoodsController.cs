﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;


namespace SWMS_WebTool.Controllers
{
    public class ExpiredGoodsController: BaseController
    {
        private readonly ApiService _apiService;

        public ExpiredGoodsController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] ExpiredGoodsFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());


                

                var _filter = filter ?? new ExpiredGoodsFilter();

                //if(_filter.Selectdate == null)
                //{
                //    _filter.Selectdate = DateTime.Now.ToString("yyyy-MM-dd");
                //}


                var response = await _apiService.SearchExpiredGoods(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<ExpiredGoods>();

                var model = new ExpiredGoodsViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };

                var slocResponse = await _apiService.GetAllMasterSloc(new MasterSlocFilter(), 1, Constants.PageMaximum);
                ViewBag.Plants = slocResponse.Records.Select(e => e.Plant).Distinct().ToList();
                ViewBag.Slocs = slocResponse.Records.Where(e => e.Plant == _filter.Plant || _filter.Plant == null).Select(e => e.Sloc).Distinct().ToList();
                ViewBag.Categories = slocResponse.Records.Where(e => e.Sloc == _filter.Sloc || _filter.Sloc == null && e.Plant == _filter.Plant || _filter.Plant == null).Select(e => e.Category).Distinct().ToList();


                return View("Views/ExpiredGoods/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

    }
}
