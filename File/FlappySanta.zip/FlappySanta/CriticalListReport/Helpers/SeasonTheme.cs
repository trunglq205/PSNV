﻿namespace CriticalListReport.Helpers
{
    /// <summary>
    /// Chọn giao diện theo mùa lễ cho Login + Layout.
    /// appsettings.json → "Theme": "auto" | "christmas" | "none"   (không khai báo = auto)
    ///   auto      : từ From tới hết ngày ThemeTo = Giáng sinh, ngoài khoảng đó = giao diện hồng gốc
    ///   christmas : luôn Giáng sinh        none : luôn giao diện hồng
    /// Mặc định: BXH tính từ 13/10, chốt lúc 13:00 ngày 30/12; giao diện Giáng sinh giữ tới hết 31/12.
    /// Đổi trong appsettings.json:
    ///   "GameSeason": { "christmas": { "From": "10-13", "To": "12-30", "EndTime": "13:00", "ThemeTo": "12-31",
    ///                   "Prize1": "50.000đ – 500.000đ", "Prize2": "50.000đ – 200.000đ", "Prize3": "50.000đ – 100.000đ" } }
    /// Xem thử nhanh không cần sửa cấu hình: thêm ?theme=christmas / ?theme=none vào URL.
    /// </summary>
    public static class SeasonTheme
    {
        public const string None = "none";
        public const string Christmas = "christmas";

        public const string DefaultFrom = "10-13";
        public const string DefaultTo = "12-30";        // ngày chốt BXH
        public const string DefaultEndTime = "13:00";   // giờ chốt BXH trong ngày To
        public const string DefaultThemeTo = "12-31";   // giao diện Giáng sinh giữ tới hết ngày này
        /// <summary>Giải Top 1 / 2 / 3 — số tiền bốc thăm ngẫu nhiên trong khoảng này lúc trao giải.</summary>
        public static readonly string[] DefaultPrizes = { "50.000đ – 500.000đ", "50.000đ – 200.000đ", "50.000đ – 100.000đ" };

        public static string Get(IConfiguration config, HttpContext? context)
        {
            // 1. Ghi đè tạm qua URL để xem thử
            var preview = context?.Request.Query["theme"].ToString();
            if (IsKnown(preview)) return preview!.Trim().ToLowerInvariant();

            // 2. Cấu hình cứng trong appsettings.json
            var setting = (config["Theme"] ?? "auto").Trim().ToLowerInvariant();
            if (IsKnown(setting)) return setting;

            // 3. auto: từ ngày bắt đầu mùa tới hết ngày ThemeTo
            var (from, _) = ChristmasSeason(config);
            var themeEnd = ParseMonthDay(config["GameSeason:christmas:ThemeTo"], from.Year) ?? ParseMonthDay(DefaultThemeTo, from.Year)!.Value;
            if (themeEnd < from) themeEnd = themeEnd.AddYears(1);
            var now = DateTime.Now;
            return now >= from && now < themeEnd.AddDays(1) ? Christmas : None;
        }

        /// <summary>Có hiện màn mini game sau đăng nhập không (cờ TempData do AccountController đặt, hoặc ?themegate=1 để mở lại).</summary>
        public static bool ShowGate(string theme, HttpContext context, object? tempDataFlag)
        {
            if (theme == None) return false;
            return tempDataFlag != null || context.Request.Query["themegate"] == "1";
        }

        /// <summary>Giải thưởng Top 1, 2, 3 (appsettings GameSeason:christmas:Prize1/Prize2/Prize3).</summary>
        public static string[] Prizes(IConfiguration config) => new[]
        {
            config["GameSeason:christmas:Prize1"] ?? DefaultPrizes[0],
            config["GameSeason:christmas:Prize2"] ?? DefaultPrizes[1],
            config["GameSeason:christmas:Prize3"] ?? DefaultPrizes[2]
        };

        /// <summary>
        /// Thời gian tính BXH của năm hiện tại: [From 00:00, To lúc EndTime) — ngày dạng MM-dd, giờ dạng HH:mm.
        /// Nếu From lớn hơn To (vd 12-01 → 01-05) thì To tính sang năm sau.
        /// </summary>
        public static (DateTime from, DateTime to) ChristmasSeason(IConfiguration config)
        {
            var year = DateTime.Today.Year;
            var from = ParseMonthDay(config["GameSeason:christmas:From"], year) ?? ParseMonthDay(DefaultFrom, year)!.Value;
            var toDay = ParseMonthDay(config["GameSeason:christmas:To"], year) ?? ParseMonthDay(DefaultTo, year)!.Value;
            if (toDay < from) toDay = toDay.AddYears(1);
            var endTime = TimeSpan.TryParse(config["GameSeason:christmas:EndTime"] ?? DefaultEndTime, out var et)
                          && et >= TimeSpan.Zero && et < TimeSpan.FromDays(1) ? et : TimeSpan.FromDays(1);
            if (endTime == TimeSpan.Zero) endTime = TimeSpan.FromDays(1);   // "00:00" = hết ngày
            return (from, toDay.Add(endTime));
        }

        /// <summary>Ngày chốt (dd/MM) và giờ chốt (HH:mm) để hiển thị.</summary>
        public static (string day, string time) CloseText(DateTime to)
        {
            var last = to.TimeOfDay == TimeSpan.Zero ? to.AddDays(-1) : to;
            return (last.ToString("dd/MM"), to.TimeOfDay == TimeSpan.Zero ? "23:59" : to.ToString("HH:mm"));
        }

        private static DateTime? ParseMonthDay(string? value, int year)
        {
            if (string.IsNullOrWhiteSpace(value)) return null;
            var parts = value.Split('-', '/');
            if (parts.Length == 2 && int.TryParse(parts[0], out var m) && int.TryParse(parts[1], out var d)
                && m is >= 1 and <= 12 && d >= 1 && d <= DateTime.DaysInMonth(year, m))
                return new DateTime(year, m, d);
            return null;
        }

        private static bool IsKnown(string? value)
        {
            var v = value?.Trim().ToLowerInvariant();
            return v == None || v == Christmas;
        }
    }
}
