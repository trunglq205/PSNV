using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Shared.App.Toast;

namespace Swms.FinishGoods.Web.Features.Models.App.Pages;

// Cum quan ly danh muc (category) mo tu nut "Danh muc" tren page-head.
// Tach rieng khoi Models.razor.Crud.cs vi day la master data khac, co vong doi
// dialog rieng (list -> form -> confirm) va reload rieng.
//
// Luu y: _categoryOptions (khai bao o Models.razor.cs) vua la nguon cho dropdown
// form model + filter, vua la nguon cho dialog nay -> moi lan CRUD xong phai nap lai
// de dropdown/filter khong con du lieu cu.
public partial class Models
{
    // ── Dialog danh sach ─────────────────────────────────────
    private bool _categoryListOpen;
    private bool _categoryLoading;

    private async Task OpenCategoryList()
    {
        _categoryListOpen = true;
        if (_categoryOptions.Count == 0) await ReloadCategoriesAsync();
    }

    private void CloseCategoryList() => _categoryListOpen = false;

    private async Task ReloadCategoriesAsync()
    {
        _categoryLoading = true;
        try
        {
            var r = await ModelBusiness.GetCategoriesAsync();
            if (r.IsSuccess && r.Value != null) _categoryOptions = r.Value;
            else Toast.Error(r.ErrorMessage ?? L["Category.Load.Failed"]);
        }
        finally
        {
            _categoryLoading = false;
        }
    }

    // ── Dialog them / sua ────────────────────────────────────
    private bool _categoryFormOpen;
    private bool _categoryIsEdit;
    private bool _categorySaving;
    private CategoryDto _categoryForm = new();
    private int _categoryEditingCode;
    private string? _categoryCodeServerError;

    private void OpenCategoryCreate()
    {
        _categoryIsEdit = false;
        _categoryEditingCode = 0;
        _categoryCodeServerError = null;
        _categoryForm = new CategoryDto();
        _categoryFormOpen = true;
    }

    private void OpenCategoryEdit(CategoryDto c)
    {
        _categoryIsEdit = true;
        _categoryEditingCode = c.Code;
        _categoryCodeServerError = null;
        _categoryForm = c.Clone();
        _categoryFormOpen = true;
    }

    private void CloseCategoryForm()
    {
        _categoryFormOpen = false;
        _categoryCodeServerError = null;
    }

    private async Task OnCategoryFormSave(CategoryDto form)
    {
        if (_categorySaving) return;
        _categorySaving = true;
        try
        {
            if (_categoryIsEdit)
            {
                var result = await ModelBusiness.UpdateCategoryAsync(
                    _categoryEditingCode, UpdateCategoryRequest.From(form));

                if (!result.IsSuccess)
                {
                    Toast.Error(result.ErrorMessage ?? L["Category.Toast.SaveFailed"]);
                    return;
                }
                Toast.Success(L["Category.Toast.Saved", form.DisplayText]);
            }
            else
            {
                var result = await ModelBusiness.CreateCategoryAsync(CreateCategoryRequest.From(form));

                if (!result.IsSuccess)
                {
                    // Trung ma -> gan loi vao o "ma danh muc" de nguoi dung sua tai cho,
                    // thay vi chi thay toast roi phai tu doan.
                    if (IsCodeConflict(result.ErrorMessage))
                        _categoryCodeServerError = result.ErrorMessage;

                    Toast.Error(result.ErrorMessage ?? L["Category.Toast.CreateFailed"]);
                    StateHasChanged();
                    return;
                }
                Toast.Success(L["Category.Toast.Created", form.DisplayText]);
            }

            CloseCategoryForm();
            await ReloadCategoriesAsync();

            // Sua danh muc doi ten -> cot "Danh muc" trong bang model phai doi theo.
            if (_categoryIsEdit) await ReloadAsync();
        }
        finally
        {
            _categorySaving = false;
        }
    }

    private static bool IsCodeConflict(string? message)
        => !string.IsNullOrWhiteSpace(message)
           && (message.Contains("code", StringComparison.OrdinalIgnoreCase)
               || message.Contains("mã", StringComparison.OrdinalIgnoreCase));

    // ── Confirm xoa ──────────────────────────────────────────
    private CategoryDto? _categoryDeleteTarget;

    private void OpenCategoryDeleteConfirm(CategoryDto c) => _categoryDeleteTarget = c;

    private async Task OnCategoryDeleteConfirmed(CategoryDto target)
    {
        _categoryDeleteTarget = null;

        var result = await ModelBusiness.DeleteCategoryAsync(target.Code);
        if (!result.IsSuccess)
        {
            // Thuong gap nhat: con model dang tham chieu -> API tra loi rang buoc khoa ngoai.
            Toast.Error(result.ErrorMessage ?? L["Category.Toast.DeleteFailed"], 5000);
            return;
        }

        Toast.Success(L["Category.Toast.Deleted", target.DisplayText]);
        await ReloadCategoriesAsync();
        await ReloadAsync();
    }

    // Thong diep confirm co kem ma + ten de khong xoa nham dong.
    private string CategoryDeleteMessage => _categoryDeleteTarget is null
        ? ""
        : L["Category.Confirm.Message", _categoryDeleteTarget.DisplayText].Value;
}
