import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';

typedef AppExpandableItemBuilder<T> =
Widget Function(BuildContext context, T item, int index);

/// Danh sách có thể thu gọn: hiện tối đa [collapsedCount] mục,
/// bấm "hiện thêm" để xem hết (và thu gọn lại nếu [collapsible]).
///
/// Hai kiểu hiển thị:
/// - `grouped: false` (mặc định): mỗi dòng tự là 1 thẻ (itemBuilder trả `AppCard`),
///   nút mở/thu là `TextButton` bên dưới.
/// - `grouped: true`: mọi dòng nằm chung 1 `Card` (CardTheme: `card`, viền `border`,
///   bo `rCard`), ngăn bằng `Divider`; nút mở/thu là dòng full-width ở đáy thẻ.
///   itemBuilder **không** bọc `AppCard`, chỉ trả nội dung dòng (xem [AppExpandableRow]).
class AppExpandableList<T> extends StatefulWidget {
  final List<T> items;

  /// Builder cho từng dòng. [index] là vị trí thật trong [items] (bắt đầu 0).
  final AppExpandableItemBuilder<T> itemBuilder;

  /// Nhãn tiêu đề (đã `.tr()` sẵn ở phía gọi). Null = không có title.
  final String? title;

  /// Widget bên phải header — nên dùng `AppButton(size: sm, variant: subtle)`.
  final Widget? headerAction;

  final int collapsedCount;

  /// Khoảng cách dọc giữa các dòng (chỉ dùng khi không [grouped]).
  final double spacing;

  /// Cho phép bấm "thu gọn" sau khi đã mở.
  final bool collapsible;

  final bool initiallyExpanded;

  /// Nhãn nút mở rộng. Mặc định `common.show_more` với 1 tham số = số mục ẩn.
  final String Function(int hidden)? showMoreLabel;

  /// Nhãn nút thu gọn. Mặc định `common.show_less`.
  final String Function()? showLessLabel;

  /// Hiển thị khi [items] rỗng (null = chỉ hiện header).
  final Widget? empty;

  final CrossAxisAlignment crossAxisAlignment;

  /// Căn nút mở/thu (chỉ dùng khi không [grouped]).
  final Alignment toggleAlignment;

  /// Animate chiều cao khi mở/thu. Tắt (mặc định) cho list dài — TC25 đỡ tốn CPU.
  /// Bật: các dòng ẩn trượt ra/vào; thu gọn xong thì gỡ hẳn khỏi tree,
  /// nên chiều cao luôn về đúng như ban đầu.
  final bool animate;

  /// Gộp các dòng vào 1 thẻ có divider.
  final bool grouped;

  const AppExpandableList({
    super.key,
    required this.items,
    required this.itemBuilder,
    this.title,
    this.headerAction,
    this.collapsedCount = 5,
    this.spacing = AppDimens.xs,
    this.collapsible = true,
    this.initiallyExpanded = false,
    this.showMoreLabel,
    this.showLessLabel,
    this.empty,
    this.crossAxisAlignment = CrossAxisAlignment.stretch,
    this.toggleAlignment = Alignment.center,
    this.animate = false,
    this.grouped = false,
  });

  @override
  State<AppExpandableList<T>> createState() => _AppExpandableListState<T>();
}

class _AppExpandableListState<T> extends State<AppExpandableList<T>>
    with SingleTickerProviderStateMixin {
  static const _duration = Duration(milliseconds: 180);

  late bool _expanded = widget.initiallyExpanded;

  late final AnimationController _ctrl = AnimationController(
    vsync: this,
    duration: _duration,
    value: _expanded ? 1 : 0,
  );

  late final Animation<double> _sizeFactor = CurvedAnimation(
    parent: _ctrl,
    curve: Curves.easeOut,
  );

  @override
  void didUpdateWidget(covariant AppExpandableList<T> oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.items.length <= widget.collapsedCount) {
      _expanded = false;
      _ctrl.value = 0;
    }
  }

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  void _toggle() {
    setState(() => _expanded = !_expanded);
    final target = _expanded ? 1.0 : 0.0;
    if (widget.animate) {
      _ctrl.animateTo(target);
    } else {
      _ctrl.value = target;
    }
  }

  String _toggleLabel(int hidden) => _expanded
      ? (widget.showLessLabel?.call() ?? LocaleKeys.common_show_less.tr())
      : (widget.showMoreLabel?.call(hidden) ??
      LocaleKeys.common_show_more.tr(args: ['$hidden']));

  CrossAxisAlignment get _rowsAlignment =>
      widget.grouped ? CrossAxisAlignment.stretch : widget.crossAxisAlignment;

  /// Dựng các dòng từ [start] đến [end) — [i] là vị trí thật trong items.
  /// Grouped: divider TRƯỚC mỗi dòng (trừ dòng 0).
  /// Thường: khoảng cách [spacing] TRÊN mỗi dòng (trừ dòng 0).
  Widget _buildRange(BuildContext context, int start, int end) {
    return Column(
      crossAxisAlignment: _rowsAlignment,
      mainAxisSize: MainAxisSize.min,
      children: [
        for (int i = start; i < end; i++)
          if (widget.grouped) ...[
            if (i > 0) const Divider(height: 1, thickness: 1),
            widget.itemBuilder(context, widget.items[i], i),
          ] else
            Padding(
              padding: EdgeInsets.only(top: i == 0 ? 0 : widget.spacing),
              child: widget.itemBuilder(context, widget.items[i], i),
            ),
      ],
    );
  }

  /// Phần dòng ẩn. Controller = 0 → gỡ hẳn khỏi tree (SizedBox.shrink),
  /// đảm bảo thu gọn xong chiều cao đúng bằng lúc chưa mở.
  Widget _buildHiddenRows(BuildContext context, int start, int end) {
    return AnimatedBuilder(
      animation: _sizeFactor,
      child: _buildRange(context, start, end),
      builder: (context, child) {
        if (_ctrl.isDismissed) return const SizedBox.shrink();
        if (_ctrl.isCompleted) return child!;
        return ClipRect(
          child: Align(
            alignment: Alignment.topCenter,
            widthFactor: 1,
            heightFactor: _sizeFactor.value,
            child: child,
          ),
        );
      },
    );
  }

  Widget _buildHeader(BuildContext context) {
    final swms = context.swms;
    final title = widget.title;
    return Padding(
      padding: EdgeInsets.only(
        left: widget.grouped ? 0 : AppDimens.xs,
        bottom: widget.grouped ? AppDimens.sm : AppDimens.xs,
      ),
      child: Row(
        children: [
          if (title != null)
            Expanded(
              child: Text(
                widget.grouped ? title.toUpperCase() : title,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.label.copyWith(color: swms.text3),
              ),
            ),
          if (widget.headerAction != null) widget.headerAction!,
        ],
      ),
    );
  }

  /// Nút mở/thu dạng dòng full-width ở đáy thẻ (grouped).
  /// Màu theo cặp `subtle`: nền primaryTint, chữ primaryDark.
  Widget _buildGroupedToggle(BuildContext context, int hidden) {
    final swms = context.swms;
    return InkWell(
      onTap: _toggle,
      child: Ink(
        color: swms.primaryTint,
        child: ConstrainedBox(
          constraints: const BoxConstraints(minHeight: AppDimens.rowH),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              AnimatedRotation(
                // chevron_right xoay 90° = chỉ xuống; -90° = chỉ lên
                turns: _expanded ? -0.25 : 0.25,
                duration: _duration,
                child: Icon(
                  Icons.chevron_right,
                  size: 18,
                  color: swms.primaryDark,
                ),
              ),
              const SizedBox(width: AppDimens.xs),
              Text(
                _toggleLabel(hidden),
                style: AppTextStyles.label.copyWith(color: swms.primaryDark),
              ),
            ],
          ),
        ),
      ),
    );
  }

  /// Nút mở/thu kiểu cũ (không grouped).
  Widget _buildTextToggle(BuildContext context, int hidden) {
    final swms = context.swms;
    return Align(
      alignment: widget.toggleAlignment,
      child: TextButton.icon(
        onPressed: _toggle,
        icon: Icon(
          _expanded ? Icons.expand_less : Icons.expand_more,
          size: 18,
        ),
        label: Text(
          _toggleLabel(hidden),
          style: AppTextStyles.label.copyWith(color: swms.primary),
        ),
        style: TextButton.styleFrom(
          foregroundColor: swms.primary,
          padding: const EdgeInsets.symmetric(
            horizontal: AppDimens.sm,
            vertical: AppDimens.xs,
          ),
          minimumSize: const Size(0, AppDimens.hitSm),
          tapTargetSize: MaterialTapTargetSize.shrinkWrap,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final total = widget.items.length;
    final collapsedCount = widget.collapsedCount.clamp(0, total);
    final canToggle = total > collapsedCount;
    final hidden = total - collapsedCount;
    final showToggle = canToggle && (!_expanded || widget.collapsible);

    final hasHeader =
        widget.title != null ||
            widget.headerAction != null;

    final Widget body = canToggle
        ? Column(
      crossAxisAlignment: _rowsAlignment,
      mainAxisSize: MainAxisSize.min,
      children: [
        _buildRange(context, 0, collapsedCount),
        _buildHiddenRows(context, collapsedCount, total),
      ],
    )
        : _buildRange(context, 0, total);

    final Widget content;
    if (total == 0) {
      content = widget.empty ?? const SizedBox.shrink();
    } else if (widget.grouped) {
      // Card lấy style từ CardTheme. Card là Material nên ripple của từng dòng
      // hiện đúng; clipBehavior cắt ripple theo góc bo.
      content = Card(
        margin: EdgeInsets.zero,
        clipBehavior: Clip.antiAlias,
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          mainAxisSize: MainAxisSize.min,
          children: [
            body,
            if (showToggle) ...[
              const Divider(height: 1, thickness: 1),
              _buildGroupedToggle(context, hidden),
            ],
          ],
        ),
      );
    } else {
      content = Column(
        crossAxisAlignment: widget.crossAxisAlignment,
        mainAxisSize: MainAxisSize.min,
        children: [
          body,
          if (showToggle) _buildTextToggle(context, hidden),
        ],
      );
    }

    return Column(
      crossAxisAlignment: widget.crossAxisAlignment,
      mainAxisSize: MainAxisSize.min,
      children: [
        if (hasHeader) _buildHeader(context),
        content,
      ],
    );
  }
}

/// Dòng chuẩn cho `AppExpandableList(grouped: true)`:
/// icon vuông nền tint + tiêu đề + phụ đề + trailing, cao tối thiểu `rowH`.
class AppExpandableRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBackground;

  /// Chữ nhỏ trước tiêu đề (vd số thứ tự "01").
  final String? leadingText;

  final String title;

  /// Style tiêu đề. Mặc định `AppTextStyles.code` (mã quét).
  final TextStyle? titleStyle;

  final String? subtitle;

  /// null + có [onTap] → chevron phải.
  final Widget? trailing;

  final VoidCallback? onTap;

  const AppExpandableRow({
    super.key,
    required this.icon,
    required this.iconColor,
    required this.iconBackground,
    required this.title,
    this.leadingText,
    this.titleStyle,
    this.subtitle,
    this.trailing,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final trailingWidget =
        trailing ??
            (onTap == null
                ? null
                : Icon(Icons.chevron_right, size: 18, color: swms.text4));

    final row = ConstrainedBox(
      constraints: const BoxConstraints(minHeight: AppDimens.rowH),
      child: Padding(
        padding: const EdgeInsets.symmetric(
          horizontal: AppDimens.md,
          vertical: AppDimens.sm,
        ),
        child: Row(
          children: [
            Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: iconBackground,
                borderRadius: BorderRadius.circular(AppDimens.rInput),
              ),
              child: Icon(icon, size: 16, color: iconColor),
            ),
            const SizedBox(width: AppDimens.sm),
            if (leadingText != null) ...[
              Text(
                leadingText!,
                style: AppTextStyles.caption.copyWith(color: swms.text4),
              ),
              const SizedBox(width: AppDimens.sm),
            ],
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: (titleStyle ?? AppTextStyles.code).copyWith(
                      color: swms.text1,
                    ),
                  ),
                  if (subtitle != null)
                    Text(
                      subtitle!,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.caption.copyWith(color: swms.text3),
                    ),
                ],
              ),
            ),
            if (trailingWidget != null) ...[
              const SizedBox(width: AppDimens.sm),
              trailingWidget,
            ],
          ],
        ),
      ),
    );

    return onTap == null ? row : InkWell(onTap: onTap, child: row);
  }
}