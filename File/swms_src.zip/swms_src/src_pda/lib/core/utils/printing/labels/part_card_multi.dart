import 'package:swms_finish_goods/core/utils/printing/labels/label.dart';
import 'package:swms_finish_goods/core/utils/printing/sato/sbpl.dart';
import 'package:swms_finish_goods/core/utils/printing/tspl/tspl.dart';

/// 1 dòng mã trên tem nhiều mã (đã format sẵn thành chuỗi).
class PartCardMultiRow {
  const PartCardMultiRow({
    required this.model,
    required this.box,
    required this.qty,
    required this.origin,
    required this.oqc,
  });

  final String model;
  final String box;
  final String qty;
  final String origin;

  /// Ký hiệu OQC đã format sẵn — xem [PartCardMultiData.oqcMark].
  final String oqc;
}

/// Dữ liệu của một tem Part Card **nhiều mã**.
///
/// Template có **ĐÚNG 3 dòng** cố định — thiếu thì để trống, KHÔNG giãn thêm
/// được (số thứ tự 1/2/3 và các đường kẻ đã vẽ sẵn trong template). Muốn hơn
/// 3 mã phải làm template khác.
///
/// Field có TÊN thay vì `List<String?>`: thứ tự 28 chỗ `%s` trong template là
/// kiến thức ngầm, truyền lệch một vị trí thì không compiler nào bắt được
/// và tem in ra vẫn "hợp lệ" — chỉ sai chỗ.
class PartCardMultiData extends Label {
  const PartCardMultiData({
    required this.qrNew,
    required this.qrOld,
    required this.psnvPo,
    required this.cusPo,
    required this.mfd,
    required this.category,
    required this.dimensionCm3,
    required this.weightKg,
    required this.rows,
    required this.totalBox,
    required this.totalQty,
    required this.totalOqc,
  });

  /// Số dòng của template. Đổi số này phải đổi cả [_sbplBody].
  static const int maxRows = 3;

  /// Ký hiệu OQC in trên tem: chưa check = "X", đã check = trống.
  /// Dùng chung cho tem in và preview để 2 bên không lệch nhau.
  static String oqcMark(bool checked) => checked ? '' : 'X';

  /// QR payload mới (H0016 V00144, size 02).
  final String qrNew;

  /// QR payload legacy (H0016 V00620, size 02).
  final String qrOld;

  final String psnvPo;
  final String cusPo;

  /// Đã format sẵn thành chuỗi hiển thị, ví dụ '28/07/2026'.
  final String mfd;

  final String category;

  /// Chỉ phần số — đơn vị 'cm3' đã nằm trong template.
  final String dimensionCm3;

  /// Chỉ phần số — đơn vị 'kg' đã nằm trong template.
  final String weightKg;

  /// Tối đa [maxRows] dòng. Dòng thiếu tự để trống.
  final List<PartCardMultiRow> rows;

  final String totalBox;
  final String totalQty;

  /// Ô OQC dòng Total — "X" khi KHÔNG dòng nào được check.
  final String totalOqc;

  PartCardMultiRow? _row(int i) => i < rows.length ? rows[i] : null;

  String _model(int i) => _row(i)?.model ?? '';

  String _box(int i) => _row(i)?.box ?? '';

  String _qty(int i) => _row(i)?.qty ?? '';

  String _origin(int i) => _row(i)?.origin ?? '';

  /// Dòng không có mã → trống (không in "X").
  String _oqc(int i) => _row(i)?.oqc ?? '';

  PartCardMultiData copyWith({
    String? qrNew,
    String? qrOld,
    String? psnvPo,
    String? cusPo,
    String? mfd,
    String? category,
    String? dimensionCm3,
    String? weightKg,
    List<PartCardMultiRow>? rows,
    String? totalBox,
    String? totalQty,
    String? totalOqc,
  }) => PartCardMultiData(
    qrNew: qrNew ?? this.qrNew,
    qrOld: qrOld ?? this.qrOld,
    psnvPo: psnvPo ?? this.psnvPo,
    cusPo: cusPo ?? this.cusPo,
    mfd: mfd ?? this.mfd,
    category: category ?? this.category,
    dimensionCm3: dimensionCm3 ?? this.dimensionCm3,
    weightKg: weightKg ?? this.weightKg,
    rows: rows ?? this.rows,
    totalBox: totalBox ?? this.totalBox,
    totalQty: totalQty ?? this.totalQty,
    totalOqc: totalOqc ?? this.totalOqc,
  );

  // ═══ SBPL ════════════════════════════════════════════════════════════════

  /// Thứ tự PHẢI khớp với thứ tự `%s` xuất hiện trong [_sbplBody] (28 chỗ).
  /// Đổi template thì đổi cả list này.
  List<String> get _sbplValues => [
    ...qrPair(qrNew), // 1-2:  DN<len>,<data> — H0016 V00144
    ...qrPair(qrOld), // 3-4:  DN<len>,<data> — H0016 V00620
    psnvPo, // 5:  H0160 V00620  PSNV PO:
    dimensionCm3, // 6:  H0120 V00620  Dim: ... cm3
    weightKg, // 7:  H0120 V00356  Weight: ... kg
    cusPo, // 8:  H0160 V00296  CUS PO:
    mfd, // 9:  H0192 V00620  MFD:
    _model(0), // 10: H0260 V00584
    _model(1), // 11: H0296 V00584
    _model(2), // 12: H0332 V00584
    _box(0), // 13: H0264 V00296
    _box(1), // 14: H0296 V00296
    _box(2), // 15: H0332 V00296
    totalBox, // 16: H0364 V00288  (đậm)
    _qty(0), // 17: H0264 V00216
    _qty(1), // 18: H0296 V00216
    _qty(2), // 19: H0328 V00216
    totalQty, // 20: H0364 V00212  (đậm)
    _origin(0), // 21: H0264 V00132
    _oqc(0), // 22: H0264 V00056
    _oqc(1), // 23: H0300 V00056
    _oqc(2), // 24: H0332 V00056
    totalOqc, // 25: H0364 V00056
    _origin(1), // 26: H0300 V00132
    _origin(2), // 27: H0332 V00132
    category, // 28: H0192 V00296  Cate:
  ];

  @override
  String get sbplSetup => _sbplSetup;

  /// Chuỗi SBPL của riêng block nhãn (chưa gồm block setup).
  @override
  String toSbpl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    if (rows.length > maxRows) {
      throw ArgumentError.value(
        rows.length,
        'rows',
        'template chỉ in được $maxRows mã',
      );
    }
    // Chốt chặn: template và list giá trị lệch nhau → lỗi ngay ở debug,
    // thay vì in ra tem "hợp lệ" nhưng sai chỗ.
    assert(
      '%s'.allMatches(_sbplBody).length == _sbplValues.length,
      'Số %s trong template khác số giá trị truyền vào',
    );
    return buildSbpl(
          _sbplBody.replaceAll('L,03,1', rows.length < 3 ? 'L,03,1' : 'L,02,1'),
          _sbplValues,
        ) +
        Sbpl.quantity(copies) +
        Sbpl.end +
        Sbpl.etx;
  }

  // Khổ tem KHÁC bản 1 mã: H0400 (bản 1 mã là H0440).
  //
  // Block 1 — cấu hình khổ tem (ESC A ... ESC Z), gửi một lần mỗi phiên.
  static const _sbplSetup =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00639H0400\x1BZ';

  // Block 2 — nội dung nhãn, chứa 28 chỗ `%s` (xem [_sbplValues]).
  static const _sbplBody =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00639H0400\x1BZ\x03\x02\x1BA\x1BPS\x1BW'
      'KNewLabel\x1B%0\x1BH0008\x1BV00008\x1BFW0404V0624H0384\x1B%1\x1BH0040\x1BV00452\x1BP02'
      '\x1BRH0,SATOSANS.ttf,1,036,052,Part Card\x1B%1\x1BH0016\x1BV00144\x1B2D30,L,03,1,0\x1BDN'
      '%s,%s\x1B%1\x1BH0016\x1BV00620\x1B2D30,L,02,1,0\x1BDN%s,%s\x1B%0\x1BH0152\x1BV00008\x1BF'
      'W0202V0624H0036\x1B%0\x1BH0220\x1BV00008\x1BFW0404V0624H0172\x1B%0\x1BH0012\x1BV00152'
      '\x1BFW02H0140\x1B%0\x1BH0256\x1BV00008\x1BFW0402V0624H0036\x1B%0\x1BH0324\x1BV00008\x1BF'
      'W0402V0624H0036\x1B%1\x1BH0160\x1BV00620\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,PSNV PO: %'
      's\x1B%1\x1BH0120\x1BV00620\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,Dim: %s cm3\x1B%1\x1BH01'
      '20\x1BV00356\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,Weight: %s kg\x1B%1\x1BH0160\x1BV00296'
      '\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,CUS PO: %s\x1B%1\x1BH0192\x1BV00620\x1BP02\x1BRH0,'
      'SATOSANS.ttf,0,023,022,MFD: %s\x1B%1\x1BH0228\x1BV00620\x1BP02\x1BRH0,SATOSANS.ttf,1,023'
      ',022,#\x1B%1\x1BH0260\x1BV00620\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,1\x1B%1\x1BH0296'
      '\x1BV00620\x1BP02\x1BRH0,SATOSANS.ttf,0,022,021,2\x1B%1\x1BH0332\x1BV00620\x1BP02\x1BRH0'
      ',SATOSANS.ttf,0,023,022,3\x1B%1\x1BH0260\x1BV00584\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,'
      '%s\x1B%1\x1BH0296\x1BV00584\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1\x1BH0332\x1BV0'
      '0584\x1BP02\x1BRH0,SATOSANS.ttf,0,022,021,%s\x1B%1\x1BH0264\x1BV00296\x1BP02\x1BRH0,SATO'
      'SANS.ttf,0,023,022,%s\x1B%1\x1BH0296\x1BV00296\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s'
      '\x1B%1\x1BH0332\x1BV00296\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1\x1BH0364\x1BV002'
      '88\x1BP02\x1BRH0,SATOSANS.ttf,1,023,022,%s\x1B%1\x1BH0264\x1BV00216\x1BP02\x1BRH0,SATOSA'
      'NS.ttf,0,023,022,%s\x1B%1\x1BH0296\x1BV00216\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B'
      '%1\x1BH0328\x1BV00216\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1\x1BH0364\x1BV00212'
      '\x1BP02\x1BRH0,SATOSANS.ttf,1,023,022,%s\x1B%1\x1BH0264\x1BV00132\x1BP02\x1BRH0,SATOSANS'
      '.ttf,0,023,022,%s\x1B%1\x1BH0264\x1BV00056\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1'
      '\x1BH0300\x1BV00056\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1\x1BH0332\x1BV00056\x1B'
      'P02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1\x1BH0364\x1BV00056\x1BP02\x1BRH0,SATOSANS.ttf'
      ',0,023,022,%s\x1B%1\x1BH0300\x1BV00132\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1\x1B'
      'H0332\x1BV00132\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,%s\x1B%1\x1BH0228\x1BV00508\x1BP02'
      '\x1BRH0,SATOSANS.ttf,1,023,022,Model\x1B%1\x1BH0363\x1BV00392\x1BP02\x1BRH0,SATOSANS.ttf'
      ',1,023,022,Total\x1B%1\x1BH0228\x1BV00216\x1BP02\x1BRH0,SATOSANS.ttf,1,023,022,Qty\x1B%1'
      '\x1BH0228\x1BV00144\x1BP02\x1BRH0,SATOSANS.ttf,1,023,022,COO\x1B%1\x1BH0228\x1BV00072'
      '\x1BP02\x1BRH0,SATOSANS.ttf,1,023,022,OQC\x1B%1\x1BH0228\x1BV00300\x1BP02\x1BRH0,SATOSAN'
      'S.ttf,1,023,022,Box\x1B%1\x1BH0192\x1BV00296\x1BP02\x1BRH0,SATOSANS.ttf,0,023,022,Cate: '
      '%s\x1B%0\x1BH0223\x1BV00592\x1BFW02H0136\x1B%0\x1BH0152\x1BV00308\x1BFW02H0236\x1B%0\x1B'
      'H0224\x1BV00232\x1BFW02H0168\x1B%0\x1BH0224\x1BV00152\x1BFW02H0164\x1B%0\x1BH0224\x1BV00'
      '080\x1BFW02H0164\x1BQ1\x1BZ\x03';

  // ═══ TSPL ════════════════════════════════════════════════════════════════
  //
  // Cùng quy ước với bản 1 mã: tem in xoay 90°, nên "hàng/cột" trong comment
  // là THEO HƯỚNG ĐỌC TEM. Đổi từ toạ độ đọc sang toạ độ giấy:
  //   paper.x = 392 - (đọc: y tính từ mép trên)   → x LỚN là ở TRÊN
  //   paper.y = 16  + (đọc: x tính từ mép trái)
  // Với TEXT xoay 90, `x` là mép DƯỚI của chữ theo hướng đọc (chữ mọc lên
  // phía x lớn), nên căn giữa ô = 392 - tâm_ô + chiều_cao_font / 2.
  //
  // Khổ 51×80 mm = 408×640 dot (203 dpi) — GIỮ NGUYÊN khổ của bản 1 mã vì
  // đó là khổ giấy thật đã in đúng trên MJ8001 (SBPL khai H0400 nhưng con
  // số đó không phải khổ giấy vật lý).
  //
  // ⚠ Toạ độ dưới đây suy ra từ layout bản 1 mã, CHƯA in thử. In một tem
  // rồi chỉnh các hằng số ở `_y*` / `_x*` là đủ, không phải sửa từng lệnh.

  // Đường kẻ NGANG theo hướng đọc — giá trị là paper.x.
  static const _lineDim = 242; // dưới Dim/Weight
  static const _linePo = 206; // dưới PSNV PO / CUS PO
  static const _lineMfd = 170; // dưới MFD / Cate
  static const _lineHead = 138; // dưới tiêu đề bảng
  static const _lineRow1 = 107;
  static const _lineRow2 = 76;
  static const _lineRow3 = 45; // trên dòng Total

  // Mốc cột — giá trị là paper.y (mép trái/phải của từng cột trong bảng).
  static const _colNo = 16;
  static const _colModel = 52;
  static const _colBox = 326; // cũng là vách PSNV PO | CUS PO
  static const _colQty = 402;
  static const _colOrigin = 485;
  static const _colOqc = 560; // vách COO | OQC
  static const _colEnd = 624;

  // Vị trí chữ (paper.x) của từng hàng — xem công thức ở đầu block.
  static const _xDim = 274; // font 2
  static const _xPo = 234; // font 2
  static const _xMfd = 198; // font 2
  static const _xHead = 166; // font 3
  static const _xRow = [134, 104, 73]; // font 3
  static const _xTotal = 43; // font 3

  static const _padding = 8;

  /// paper.y để [text] nằm GIỮA cột [start]..[end] (font rộng [charWidth]).
  static int _mid(int start, int end, String text, int charWidth) {
    final free = (end - start) - text.length * charWidth;
    return start + (free < 0 ? 0 : free ~/ 2);
  }

  @override
  List<String> get tsplSetup => _tsplSetup;

  static const _tsplSetup = [
    'SIZE 51 mm,80 mm',
    'GAP 0,0',
    'DIRECTION 1,0',
    'REFERENCE 0,0',
    'DENSITY 8',
    'SPEED 4',
  ];

  @override
  List<String> toTspl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    if (rows.length > maxRows) {
      throw ArgumentError.value(
        rows.length,
        'rows',
        'template chỉ in được $maxRows mã',
      );
    }
    return [
      Tspl.cls,

      // Khung ngoài
      Tspl.box(16, 16, 392, 624, 3),

      // Đường kẻ NGANG (theo hướng đọc) — chạy hết bề ngang tem
      Tspl.bar(_lineDim, 16, 3, 608),
      Tspl.bar(_linePo, 16, 3, 608),
      Tspl.bar(_lineMfd, 16, 3, 608),
      Tspl.bar(_lineHead, 16, 3, 608),
      Tspl.bar(_lineRow1, 16, 3, 608),
      Tspl.bar(_lineRow2, 16, 3, 608),
      Tspl.bar(_lineRow3, 16, 3, 608),

      // Đường kẻ DỌC (theo hướng đọc)
      Tspl.bar(_lineDim, 469, 150, 3), // tách cột QR lớn (chỉ khối đầu)
      Tspl.bar(16, _colBox, 226, 3), // PSNV|CUS và Model|Box, xuống hết bảng
      Tspl.bar(_lineRow3, _colModel, 125, 3), // #|Model, dừng trên dòng Total
      Tspl.bar(16, _colQty, 154, 3), // Box|Qty
      Tspl.bar(16, _colOrigin, 154, 3), // Qty|COO
      Tspl.bar(16, _colOqc, 154, 3), // COO|OQC
      // ── Khối đầu: QR nhỏ, tiêu đề, QR lớn, Dim/Weight ───────────────
      Tspl.qrcode(285, 24, 'L', 1, 'A', 0, qrOld),
      Tspl.text(350, 248, '5', 90, 2, 1, 'Part Card'),
      Tspl.qrcode(245, 475, 'L', 1, 'A', 0, qrNew),
      Tspl.text(_xDim, _colNo + 24, '2', 90, 1, 1, 'Dim: $dimensionCm3 cm3'),
      Tspl.text(_xDim, 296, '2', 90, 1, 1, 'Weight: $weightKg kg'),

      // ── PSNV PO / CUS PO ─────────────────────────────────────────────
      Tspl.text(_xPo, _colNo + 24, '2', 90, 1, 1, 'PSNV PO: $psnvPo'),
      Tspl.text(_xPo, _colBox + _padding, '2', 90, 1, 1, 'CUS PO: $cusPo'),

      // ── MFD / Cate ───────────────────────────────────────────────────
      Tspl.text(_xMfd, _colNo + 24, '2', 90, 1, 1, 'MFD: $mfd'),
      Tspl.text(_xMfd, _colBox + _padding, '2', 90, 1, 1, 'Cate: $category'),

      // ── Tiêu đề bảng ─────────────────────────────────────────────────
      Tspl.text(_xHead, _mid(_colNo, _colModel, '#', 16), '3', 90, 1, 1, '#'),
      Tspl.text(
        _xHead,
        _mid(_colModel, _colBox, 'Model', 16),
        '3',
        90,
        1,
        1,
        'Model',
      ),
      Tspl.text(
        _xHead,
        _mid(_colBox, _colQty, 'Box', 16),
        '3',
        90,
        1,
        1,
        'Box',
      ),
      Tspl.text(
        _xHead,
        _mid(_colQty, _colOrigin, 'Qty', 16),
        '3',
        90,
        1,
        1,
        'Qty',
      ),
      Tspl.text(
        _xHead,
        _mid(_colOrigin, _colOqc, 'COO', 16),
        '3',
        90,
        1,
        1,
        'COO',
      ),
      Tspl.text(
        _xHead,
        _mid(_colOqc, _colEnd, 'OQC', 16),
        '3',
        90,
        1,
        1,
        'OQC',
      ),

      // ── 3 dòng mã ────────────────────────────────────────────────────
      for (var i = 0; i < maxRows; i++) ...[
        Tspl.text(
          _xRow[i],
          _mid(_colNo, _colModel, '${i + 1}', 16),
          '3',
          90,
          1,
          1,
          '${i + 1}',
        ),
        Tspl.text(_xRow[i], _colModel + _padding, '3', 90, 1, 1, _model(i)),
        Tspl.text(
          _xRow[i],
          _mid(_colBox, _colQty, _box(i), 16),
          '3',
          90,
          1,
          1,
          _box(i),
        ),
        Tspl.text(
          _xRow[i],
          _mid(_colQty, _colOrigin, _qty(i), 16),
          '3',
          90,
          1,
          1,
          _qty(i),
        ),
        Tspl.text(_xRow[i], _colOrigin + _padding, '3', 90, 1, 1, _origin(i)),
        Tspl.text(
          _xRow[i],
          _mid(_colOqc, _colEnd, _oqc(i), 16),
          '3',
          90,
          1,
          1,
          _oqc(i),
        ),
      ],

      // ── Dòng Total ───────────────────────────────────────────────────
      Tspl.text(
        _xTotal,
        _colBox - _padding - 'Total'.length * 16,
        '3',
        90,
        1,
        1,
        'Total',
      ),
      Tspl.text(
        _xTotal,
        _mid(_colBox, _colQty, totalBox, 16),
        '3',
        90,
        1,
        1,
        totalBox,
      ),
      Tspl.text(
        _xTotal,
        _mid(_colQty, _colOrigin, totalQty, 16),
        '3',
        90,
        1,
        1,
        totalQty,
      ),
      Tspl.text(
        _xTotal,
        _mid(_colOqc, _colEnd, totalOqc, 16),
        '3',
        90,
        1,
        1,
        totalOqc,
      ),

      Tspl.print(copies),
    ];
  }
}
