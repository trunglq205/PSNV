﻿    namespace SWMS_WebTool.Models.DataKitting
{
    public class DataKittingOutside : DataKittingPL
    {
        public Int64 DataKittingOutsideID { get; set; }
        public string ReceiptSloc { get; set; }
        public string MaterialDescription { get; set; }
        public DateTime? RequirementsDate { get; set; }
        public string Tcode { get; set; }
        public string Remark { get; set; }
        public string Reason { get; set; }
        public string GroupName { get; set; }
        public string Account { get; set; }
        public string CostCenter { get; set; }
    }
}
