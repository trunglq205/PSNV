// Home.razor.js — JS module (JS isolation) cho trang chủ.
// Import: await JS.InvokeAsync<IJSObjectReference>("import", "./Components/Pages/Home.razor.js")
// MainLayout cũng import chính module này để gọi pushRecent khi đổi trang.

const KEY = 'swms.recent';
const MAX = 6;

export function getRecent() {
    try {
        const raw = localStorage.getItem(KEY);
        const list = raw ? JSON.parse(raw) : [];
        return Array.isArray(list) ? list : [];
    } catch {
        return [];              // localStorage bị chặn / dữ liệu hỏng
    }
}

export function pushRecent(href) {
    if (!href) return;          // "" = trang chủ, không ghi
    try {
        const list = getRecent().filter(x => x !== href);
        list.unshift(href);
        localStorage.setItem(KEY, JSON.stringify(list.slice(0, MAX)));
    } catch {
        /* bỏ qua */
    }
}

export function clearRecent() {
    try {
        localStorage.removeItem(KEY);
    } catch {
        /* bỏ qua */
    }
}
