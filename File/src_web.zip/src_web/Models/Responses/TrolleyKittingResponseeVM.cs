﻿namespace SWMS_WebTool.Models.Responses
{
    public class TrolleyKittingResponseeVM
    {
        public string TrolleyName { get; set; }
        public string TrolleyCode { get; set; }
        public string BarCode { get; set; }
        public byte? ActionStatus { get; set; }
        public string Description { get; set; }
        public string Time { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Model { get; set; }
        public string Line { get; set; }
        public int? ModelQuantity { get; set; }
        public string Category { get; set; }
        public string KittingTimeType { get; set; }
        public string PIC { get; set; }
        public string TrolleyFill
        {
            get
            {
                switch (ActionStatus)
                {
                    case 1:
                    case 2:
                    case 3:
                        return "#FFFF00";
                    case 4:
                        return "#A9D08E";
                    default:
                        return "#FFFFFF";
                }
            }
        }
    }
}
