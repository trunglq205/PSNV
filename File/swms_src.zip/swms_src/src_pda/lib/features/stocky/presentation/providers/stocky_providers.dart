﻿import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/stocky/data/datasources/stocky_remote_data_source.dart';
import 'package:swms_finish_goods/features/stocky/data/stocky_repository_impl.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';
import 'package:swms_finish_goods/features/stocky/domain/repositories/stocky_repository.dart';

part 'stocky_providers.g.dart';

@riverpod
StockyRemoteDataSource stockyRemoteDataSource(Ref ref) =>
    StockyRemoteDataSource(ref.watch(dioProvider));

@riverpod
StockyRepository stockyRepository(Ref ref) =>
    StockyRepositoryImpl(ref.watch(stockyRemoteDataSourceProvider));

/// Danh sách xe đang ở trong kho.
///
/// [filterName] là `StockyFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build —
/// `ng_providers.dart` ghi rõ cái bẫy này.
@riverpod
Future<List<StockyCart>> stockyCartList(Ref ref, String filterName) async {
  final filter = StockyFilter.values.firstWhere(
    (f) => f.name == filterName,
    orElse: () => StockyFilter.all,
  );
  return ref.watch(stockyRepositoryProvider).fetchList(hasGoods: filter.hasGoods);
}
