﻿namespace SWMS_WebTool.Models.Requests
{
    public class DisAndEnableQtyRequestVM
    {
        public string Sloc { get; set; }
        public string Category { get; set; }
        public string KittingType { get; set; }
        public string StartDate { get; set; }
        public string EndDate { get; set; }
        public bool IsEnable { get; set; }
    }
}
