﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.PMD;
using SWMS_WebTool.Services;
using SWMS_WebTool.ViewModels;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Models.ImportModel;

namespace SWMS_WebTool.Controllers
{
    public class PMDController : BaseController
    {

        private readonly ApiService _apiService;
        public PMDController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] PurgingRunnerNGPMDFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new PurgingRunnerNGPMDFilter();
                var response = await _apiService.PurgingRunnerNGPMDSearch(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<PurgingRunnerNGPMD>();

                var model = new PurgingRunnerNGPMDViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/PMD/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> Delete([FromBody] PurgingRunnerNGPMD item)
        {
            try
            {
                var rs =  await _apiService.DeletePurgingRunnerNGPMD(item);
                if (rs != null)
                {
                    return Json(new { success = true });
                }
                return Json(new { success = false });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> Update([FromBody] PurgingRunnerNGPMD item)
        {
            try
            {
                var rs = await _apiService.ConfirmPurgingRunnerNGPMD(item);
                if (rs != null)
                {
                    return Json(new { success = true });
                }
                return Json(new { success = false });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> UpdateAll([FromBody] List<PurgingRunnerNGPMD> item)
        {
            try
            {
                var rs = await _apiService.ConfirmPurgingRunnerNGPMDAll(item);
                if (rs.TotalRecord == item.Count)
                {
                    return Json(new { success = true });
                }
                return Json(new { success = false });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
       
    }
}
