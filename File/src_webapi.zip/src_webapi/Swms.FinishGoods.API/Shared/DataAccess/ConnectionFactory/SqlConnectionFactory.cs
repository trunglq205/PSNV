using System.Data;
using Microsoft.Data.SqlClient;

namespace Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

public class SqlConnectionFactory : IDbConnectionFactory
{
    private readonly string _connectionString;

    public SqlConnectionFactory(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("SWMSConnection")
            ?? throw new InvalidOperationException("Connection string 'Default' not found.");
    }

    public IDbConnection Create() => new SqlConnection(_connectionString);
}
