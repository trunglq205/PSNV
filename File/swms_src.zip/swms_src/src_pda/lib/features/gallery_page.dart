import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';

/// Màn demo toàn bộ design system — bật/tắt dark mode để xem cả hai theme.
@RoutePage()
class GalleryPage extends StatefulWidget {
  const GalleryPage({super.key});

  @override
  State<GalleryPage> createState() => _GalleryPageState();
}

class _GalleryPageState extends State<GalleryPage> {
  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Scaffold(
      appBar: AppBar(title: const Text('SWMS Design System')),
      body: ListView(
        padding: const EdgeInsets.all(AppDimens.md),
        children: [
          _section('Nút bấm'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              AppButton(label: 'Xác nhận', size: .sm, onPressed: () {}),
              AppButton(
                label: 'Mặc định',
                variant: .neutral,
                size: .sm,
                onPressed: () {},
              ),
              AppButton(
                label: 'Hoàn tất',
                variant: .success,
                size: .sm,
                icon: Icons.check,
                onPressed: () {},
              ),
              AppButton(
                label: 'Tạm hoãn',
                variant: .warning,
                size: .sm,
                onPressed: () {},
              ),
              AppButton(
                label: 'Báo NG',
                variant: .danger,
                size: .sm,
                onPressed: () {},
              ),
              AppButton(
                label: 'Bỏ qua',
                variant: .subtle,
                size: .sm,
                onPressed: () {},
              ),
            ],
          ),
          const SizedBox(height: AppDimens.md),
          const AppButton(
            label: 'Quét pallet',
            icon: Icons.qr_code_scanner,
            size: .lg,
          ),
          const SizedBox(height: AppDimens.sm),
          const AppButton(label: 'Đang xử lý', size: .lg, isLoading: true),

          _section('Quét mã'),
          const BarcodeScannerButton(scanningLabel: 'Đang quét'),

          _section('Ô nhập liệu'),
          const AppTextField(label: 'Ghi chú', hint: 'Nhập ghi chú...'),

          _section('Trạng thái'),
          Wrap(
            spacing: 8,
            runSpacing: 8,
            children: [
              StatusPill.success(
                context,
                label: 'Hoàn tất',
                icon: Icons.check_circle,
              ),
              StatusPill.warning(context, label: 'Chờ xử lý'),
              StatusPill.danger(context, label: 'NG', icon: Icons.close),
              StatusPill.info(context, label: 'Đang quét'),
              StatusPill.neutral(context, label: 'Nháp'),
            ],
          ),

          _section('Thẻ'),
          AppCard(
            onTap: () {},
            child: Column(
              crossAxisAlignment: .start,
              children: [
                Text(
                  'PLT-00482',
                  style: AppTextStyles.code.copyWith(color: swms.text1),
                ),
                const SizedBox(height: 4),
                Text(
                  'Lô A · 24 thùng · Kho lạnh 2',
                  style: AppTextStyles.body.copyWith(color: swms.text2),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppDimens.xl),
        ],
      ),
    );
  }

  Widget _section(String t) => Padding(
    padding: const EdgeInsets.only(top: AppDimens.lg, bottom: AppDimens.sm),
    child: Text(t, style: AppTextStyles.h2.copyWith(color: context.swms.text1)),
  );
}
