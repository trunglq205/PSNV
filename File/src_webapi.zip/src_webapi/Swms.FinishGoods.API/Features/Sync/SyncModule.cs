using Swms.FinishGoods.API.Features.Sync.Business;
using Swms.FinishGoods.API.Features.Sync.DataAccess;

namespace Swms.FinishGoods.API.Features.Sync
{
    public static class SyncModule
    {
        public static IServiceCollection AddSyncFeature(this IServiceCollection services)
        {
            services.AddSingleton<SyncRunner>();
            services.AddScoped<IFossSyncJob, FossSyncJob>();
            services.AddScoped<IHdSoftSyncJob, HdSoftSyncJob>();
            services.AddScoped<ISyncStateRepository, SyncStateRepository>();
            return services;
        }
    }
}
