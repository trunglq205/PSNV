import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast.dart';

/// Hàm tiện gọi toast. Trả Future để await kết quả.
/// confirm() trả bool (true nếu user đồng ý).
abstract final class AppToastHelper {
  const AppToastHelper._();

  /// Toast dùng ScaffoldMessenger (SnackBar floating).
  static void toast(
    BuildContext context, {
    required String message,
    String? title,
    AppToastType type = AppToastType.info,
    Duration duration = const Duration(seconds: 3),
    SnackBarAction? action,
  }) {
    final messenger = ScaffoldMessenger.of(context);
    messenger.hideCurrentSnackBar();

    final bgColor = type.color;

    messenger.showSnackBar(
      SnackBar(
        duration: duration,
        behavior: SnackBarBehavior.floating,
        backgroundColor: bgColor,
        elevation: 6,
        margin: const EdgeInsets.all(16),
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        action: action == null
            ? null
            : SnackBarAction(
                label: action.label,
                onPressed: action.onPressed,
                textColor: Colors.white,
              ),
        content: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Icon(type.icon, color: Colors.white, size: 22),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                mainAxisSize: MainAxisSize.min,
                children: [
                  if (title != null) ...[
                    Text(
                      title,
                      style: const TextStyle(
                        color: Colors.white,
                        fontWeight: FontWeight.w600,
                        fontSize: 14,
                      ),
                    ),
                    const SizedBox(height: 2),
                  ],
                  Text(
                    message,
                    style: const TextStyle(color: Colors.white, fontSize: 13),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  static void toastSuccess(
    BuildContext context,
    String message, {
    String? title,
  }) => toast(
    context,
    message: message,
    title: title,
    type: AppToastType.success,
  );

  static void toastError(
    BuildContext context,
    String message, {
    String? title,
  }) =>
      toast(context, message: message, title: title, type: AppToastType.error);

  static void toastWarning(
    BuildContext context,
    String message, {
    String? title,
  }) => toast(
    context,
    message: message,
    title: title,
    type: AppToastType.warning,
  );

  static void toastInfo(
    BuildContext context,
    String message, {
    String? title,
  }) => toast(context, message: message, title: title);
}
