using System.Text;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

/// <summary>
/// Mục 2c — đề nghị nhận lại hàng về FA. BA bước, MỘT cấp duyệt:
///   B1 FA tạo đề nghị                  (không mail)
///   B2 quản lý FA xác nhận             → mail TO SCS Office, CC FA
///   B3 SCS WH quét Pallet ID giao hàng → mail TO FA, CC SCS
///
/// Vì sao trạng thái nằm ở DB chứ không kiểm trong code rồi mới ghi: điều kiện
/// "đang ở đúng bước" nằm TRONG câu UPDATE của repository, nên hai người bấm
/// xác nhận cùng lúc thì người sau không ăn gì và nhận
/// <see cref="ConflictException"/>, chứ không phải cả hai cùng ghi.
/// </summary>
public class ReturnBackRequestService : IReturnBackRequestService
{
    /// <summary>
    /// Trần số dòng một yêu cầu. Một chỉ thị nhận hàng thực tế có vài chục
    /// model; trần này chỉ để một request hỏng không kéo theo vài nghìn câu
    /// INSERT trong một transaction.
    /// </summary>
    private const int MaxLines = 200;

    private const int MaxModelLength = 100;
    private const int MaxNoteLength = 500;

    /// <summary>
    /// Trần số pallet một lượt giao. Một lượt thực tế vài pallet; trần này chỉ
    /// để một request hỏng không kéo theo vài nghìn câu UPDATE trong một
    /// transaction.
    /// </summary>
    private const int MaxLotsPerDelivery = 100;

    /// <summary>Pallet ID chuẩn 12 ký tự; để rộng cho mã tay hoặc có hậu tố.</summary>
    private const int MaxLotLength = 30;

    // ─────────────────────────────────────────────────────────────
    //  ĐÚNG HAI LÁ MAIL — đúng hai chỗ hàng đổi tay giữa hai bộ phận.
    //
    //  B1 (FA tạo đề nghị) KHÔNG gửi mail: quản lý FA ngồi cùng bộ phận, mở màn
    //  hình ra là thấy hàng đợi. Giữa B2 và B3 cũng không có mail cho SCS WH —
    //  SCS Office tự thông báo cho kho ngoài hệ thống.
    //
    //  Hai mã riêng chứ không một mã chung: mẫu thư nằm trên
    //  master.email_events khoá theo code, một mã là MỘT mẫu. Hai lá này gửi
    //  cho hai bên khác nhau với nội dung khác nhau, nên buộc phải hai mã.
    //
    //  Người nhận khai riêng từng sự kiện trong master.email_config; sự kiện
    //  nào không có dòng TO đang bật thì SmtpMailSender coi là không có người
    //  nhận và không gửi. Muốn tắt một lá thì để trống người nhận, không phải
    //  sửa code.
    //
    //  Giữ KHỚP với return_back_mail_schema.sql và với ReturnMailConfigDialog
    //  bên Web (ReturnMailEvents.BackFaApproved / BackDelivered).
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// B2 — quản lý FA xác nhận. TO: SCS Office, CC: FA.
    /// SCS Office tự thông báo cho SCS WH ngoài hệ thống, nên không có mail
    /// cho WH.
    /// </summary>
    private const string MailBackFaApproved = "RETURN_BACK_FA_APPROVED";

    /// <summary>B3 — SCS WH quét pallet giao hàng xong. TO: FA, CC: SCS.</summary>
    private const string MailBackDelivered = "RETURN_BACK_DELIVERED";

    private readonly IReturnBackRequestRepository _repo;
    private readonly IReturnInstructionRepository _docs;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly ILogger<ReturnBackRequestService> _logger;
    private readonly IMailSender _mail;
    private readonly string? _webBaseUrl;

    public ReturnBackRequestService(
        IReturnBackRequestRepository repo,
        IReturnInstructionRepository docs,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        ILogger<ReturnBackRequestService> logger,
        IMailSender mail,
        IConfiguration config)
    {
        _repo = repo;
        _docs = docs;
        _currentUser = currentUser;
        _localizer = localizer;
        _logger = logger;
        _mail = mail;
        _webBaseUrl = config["Web:BaseUrl"]?.TrimEnd('/');
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    public async Task<IReadOnlyList<BackRequestResponse>> GetListAsync(BackRequestQuery query)
        => (await _repo.GetListAsync(query)).Select(BackRequestResponse.From).ToList();

    public async Task<BackRequestResponse> GetByIdAsync(long id)
        => BackRequestResponse.From(await LoadAsync(id));

    public Task<IReadOnlyList<BackAvailableModelResponse>> GetAvailableAsync(long docId)
        => _repo.GetAvailableAsync(docId);

    // ───────────────────────── B1 · FA tạo yêu cầu ─────────────────────────

    public async Task<BackRequestResponse> CreateAsync(CreateBackRequestRequest request)
    {
        var doc = await _docs.GetByIdAsync(request.DocId)
            ?? throw new NotFoundException(_localizer[BackMsg.DocNotFound, request.DocId]);

        if (doc.DocStatus == ReturnDocStatus.Cancelled)
            throw new BusinessRuleException(_localizer[BackMsg.DocCancelled, doc.DocNo]);

        // LẤY LÀ LẤY HẾT: dòng model + SL SUY TỪ PHIẾU. FA chỉ chọn phiếu; con
        // số trên form là để XEM, không nhập không sửa — nên request KHÔNG có
        // trường nào mang dòng vào đây được, kể cả khi gọi API trực tiếp.
        var lines = await DeriveLinesAsync(request.DocId);

        var id = await _repo.AddAsync(new ReturnBackRequest
        {
            DocId = request.DocId,
            Note = Trim(request.Note, MaxNoteLength),
            Lines = lines,
        }, Actor);

        // B1 KHÔNG gửi mail (quyết định 09/11): quản lý FA ngồi cùng bộ phận,
        // mở màn hình ra là thấy hàng đợi.
        return BackRequestResponse.From(await LoadAsync(id));
    }

    public async Task<BackRequestResponse> UpdateAsync(long id, UpdateBackRequestRequest request)
    {
        var current = await LoadAsync(id);
        RequireOpen(current);

        // Chỉ sửa khi còn chờ quản lý FA. Qua bước đó là SCS đã nhận được mail
        // với bảng số cụ thể — đổi số sau đó là hai bên nhìn hai bảng khác nhau.
        if (current.CurrentStep != ReturnBackStep.FaApprove)
            throw new ConflictException(
                _localizer[BackMsg.NotEditable, current.ReqNo, current.CurrentStep]);

        // Dòng model + SL luôn SUY LẠI TỪ PHIẾU, không nhận từ request: phiếu
        // có thể vừa nhận thêm hàng, và FA thì không được sửa số.
        var lines = await DeriveLinesAsync(current.DocId);

        await _repo.UpdateLinesAsync(id, Trim(request.Note, MaxNoteLength), lines, Actor);
        return BackRequestResponse.From(await LoadAsync(id));
    }

    // ─────────────────────────── Các bước duyệt ───────────────────────────

    /// <summary>
    /// B2 — quản lý FA xác nhận. Đây là lá mail DUY NHẤT của nửa đầu luồng:
    /// TO SCS Office, CC FA. Sau bước này SCS Office tự thông báo cho SCS WH.
    /// </summary>
    public async Task<BackRequestResponse> ApproveFaAsync(
        long id, BackRequestDecisionRequest request)
    {
        var current = await LoadAsync(id);
        RequireOpen(current);

        var ok = await _repo.ApplyStepAsync(
            id,
            fromStep: ReturnBackStep.FaApprove,
            toStep: ReturnBackStep.ScsDeliver,
            toStatus: ReturnBackStatus.FaApproved,
            actorColumnPrefix: "fa_approved",
            comment: Trim(request.Comment, MaxNoteLength),
            user: Actor);

        if (!ok)
            throw new ConflictException(
                _localizer[BackMsg.WrongStep, current.ReqNo, current.CurrentStep]);

        var saved = await LoadAsync(id);
        await NotifyAsync(MailBackFaApproved, saved, MarkdownMail.Blue);
        return BackRequestResponse.From(saved);
    }

    // ───────────── B3 · SCS WH quét Pallet ID giao hàng cho FA ─────────────

    /// <summary>
    /// Nhận nhiều mã pallet trong MỘT lượt rồi gửi MỘT mail: WH quét 5 pallet
    /// thì FA nhận một lá thư liệt kê 5 pallet, không phải 5 lá.
    ///
    /// Mã pallet sai KHÔNG làm cả lượt thất bại — 4 pallet đúng vẫn phải đi.
    /// Danh sách mã sai trả về để màn hình nói rõ cái nào.
    /// </summary>
    public async Task<BackDeliverResponse> DeliverAsync(
        long id, DeliverBackRequest request)
    {
        var lotNos = (request.LotNos ?? [])
            .Select(x => x?.Trim() ?? "")
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (lotNos.Count == 0)
            throw new BusinessRuleException(_localizer[BackMsg.LotsRequired]);

        if (lotNos.Count > MaxLotsPerDelivery)
            throw new BusinessRuleException(
                _localizer[BackMsg.TooManyLots, MaxLotsPerDelivery]);

        foreach (var lot in lotNos)
            if (lot.Length > MaxLotLength)
                throw new BusinessRuleException(
                    _localizer[BackMsg.ValueTooLong, lot, MaxLotLength]);

        var result = await _repo.DeliverPalletsAsync(
            id, lotNos, Trim(request.Comment, MaxNoteLength), Actor);

        if (result.NotFound)
            throw new NotFoundException(_localizer[BackMsg.NotFound, id]);

        var current = await LoadAsync(id);

        if (result.WrongStep)
            throw new ConflictException(
                _localizer[BackMsg.WrongStep, current.ReqNo, current.CurrentStep]);

        // Không chuyển được con nào: hoặc mã pallet sai hết, hoặc pallet đúng
        // nhưng hàng trên đó đã đi rồi. Ném lỗi để WH biết ngay tại máy quét —
        // nhật ký đã ghi xong nên vẫn tra được là họ đã quét gì.
        if (!result.AnyMoved)
            throw new BusinessRuleException(result.NotFoundLots.Count == lotNos.Count
                ? _localizer[BackMsg.LotNotFound, string.Join(", ", result.NotFoundLots)]
                : _localizer[BackMsg.NothingToDeliver, current.ReqNo]);

        // Mail chỉ gửi khi đã giao XONG cả đề nghị: giao dở dang thì FA chưa
        // cần biết, và một lá thư mỗi lượt quét là bội thực.
        if (result.Completed)
            await NotifyAsync(MailBackDelivered, current, MarkdownMail.Orange,
                              justDelivered: result);

        return BackDeliverResponse.From(result, current);
    }

    public async Task<IReadOnlyList<BackDeliveryResponse>> GetDeliveriesAsync(long id)
        => (await _repo.GetDeliveriesAsync(id)).Select(BackDeliveryResponse.From).ToList();

    public async Task<BackRequestResponse> CancelAsync(
        long id, BackRequestDecisionRequest request)
    {
        var current = await LoadAsync(id);

        if (current.IsCancelled)
            throw new ConflictException(_localizer[BackMsg.AlreadyCancelled, current.ReqNo]);

        // Đã giao xong thì hàng đang ở FA — huỷ ở đây là mất dấu lô hàng đó.
        // Muốn kết thúc thì đi đường mục 3 (FA giao lại) hoặc đánh ng.
        if (current.IsDelivered)
            throw new ConflictException(_localizer[BackMsg.AlreadyDelivered, current.ReqNo]);

        // Đã giao một phần: huỷ nửa vời để lại hàng ở FA mà không có đề nghị
        // nào đứng tên. Chặn luôn, buộc giao hết rồi đi đường mục 3.
        if (current.IsPartlyDelivered)
            throw new ConflictException(
                _localizer[BackMsg.PartlyDelivered, current.ReqNo, current.AtFaQty]);

        if (!await _repo.CancelAsync(id, Trim(request.Comment, MaxNoteLength), Actor))
            throw new ConflictException(
                _localizer[BackMsg.WrongStep, current.ReqNo, current.CurrentStep]);

        return BackRequestResponse.From(await LoadAsync(id));
    }

    // ───────────────────────────── Hỗ trợ ─────────────────────────────

    private async Task<ReturnBackRequest> LoadAsync(long id)
        => await _repo.GetByIdAsync(id)
           ?? throw new NotFoundException(_localizer[BackMsg.NotFound, id]);

    private void RequireOpen(ReturnBackRequest r)
    {
        if (r.IsCancelled)
            throw new ConflictException(_localizer[BackMsg.AlreadyCancelled, r.ReqNo]);
        if (r.IsDelivered)
            throw new ConflictException(_localizer[BackMsg.AlreadyDelivered, r.ReqNo]);
    }

    /// <summary>
    /// Dòng model + SL của đề nghị — SUY TỪ PHIẾU, không nhận từ request.
    ///
    /// LẤY LÀ LẤY HẾT: một đề nghị bao trọn phần phiếu còn ở kho, nên SL mỗi
    /// model = số serial đang <c>received</c> và chưa thuộc lượt back nào. FA
    /// chỉ chọn phiếu; con số trên form là để xem.
    ///
    /// Vì vậy ở đây KHÔNG còn kiểm "xin quá số kho có" — không ai nhập được số
    /// nữa thì không có gì để vượt.
    /// </summary>
    private async Task<List<ReturnBackRequestLine>> DeriveLinesAsync(long docId)
    {
        var available = await _repo.GetAvailableAsync(docId);

        var lines = available
            .Where(a => a.AvailableQty > 0)
            .OrderBy(a => a.Model, StringComparer.OrdinalIgnoreCase)
            .Select((a, i) => new ReturnBackRequestLine
            {
                LineNo = i + 1,
                Model = a.Model,
                Qty = a.AvailableQty,
            })
            .ToList();

        // Phiếu không còn con nào ở kho: hoặc đã đi FA hết, hoặc đã xuất.
        // Chặn ngay thay vì tạo một đề nghị rỗng rồi chờ ai đó phát hiện.
        if (lines.Count == 0)
            throw new BusinessRuleException(_localizer[BackMsg.NothingAvailable]);

        if (lines.Count > MaxLines)
            throw new BusinessRuleException(_localizer[BackMsg.TooManyLines, MaxLines]);

        foreach (var l in lines)
            if (l.Model.Length > MaxModelLength)
                throw new BusinessRuleException(
                    _localizer[BackMsg.ValueTooLong, l.Model, MaxModelLength]);

        return lines;
    }

    private static string? Trim(string? s, int max)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        var t = s.Trim();
        return t.Length <= max ? t : t[..max];
    }

    // ───────────────────────────── Mail ─────────────────────────────

    /// <summary>
    /// Gửi một lá mail của luồng 2c.
    ///
    /// NUỐT MỌI LỖI: việc nghiệp vụ ĐÃ ghi xong trước khi gọi tới đây, mail
    /// hỏng không được phép làm đổ nó — người dùng đã bấm xác nhận, bắt họ bấm
    /// lại vì SMTP chết là ghi đè hai lần. Cùng cách
    /// <c>ReturnInstructionService.NotifyFaAsync</c> làm.
    ///
    /// KHÔNG đóng dấu "đã gửi" vào DB như mục 2a/2b: bảng
    /// <c>return_back_requests</c> không có cột mail, và hai mốc thời gian đã có
    /// (<c>fa_approved_at</c>, <c>delivered_at</c>) đã trả lời được "đến bước
    /// này chưa". Thêm cột chỉ để ghi một việc không ai tra là nợ.
    /// </summary>
    private async Task NotifyAsync(string eventCode, ReturnBackRequest req, string accent,
                                   ReturnBackDeliverResult? justDelivered = null)
    {
        try
        {
            var tpl = await _docs.GetMailTemplateAsync(eventCode);
            if (tpl is null)
            {
                _logger.LogWarning(
                    "Chua khai su kien mail {Event} trong master.email_events — "
                    + "khong gui mail cho de nghi {ReqNo}.", eventCode, req.ReqNo);
                return;
            }

            var recipients = await _docs.GetMailRecipientsAsync(eventCode);
            if (recipients.Count == 0)
            {
                // Không phải lỗi: để trống người nhận CHÍNH LÀ cách tắt một lá
                // mail mà không sửa code. Vẫn ghi log để người ta tra ra vì sao
                // thư không tới.
                _logger.LogInformation(
                    "Su kien {Event} chua khai nguoi nhan trong master.email_config — "
                    + "bo qua mail cho de nghi {ReqNo}.", eventCode, req.ReqNo);
                return;
            }

            var replyTo = await _docs.GetUserEmailAsync(_currentUser.EmployeeCode);

            // Mẫu viết bằng MARKDOWN -> dựng HTML có khung (MarkdownMail, dùng
            // chung cả hệ thống). Phải đi qua đây mới khớp phần XEM TRƯỚC bên
            // Web — xem trước cũng render markdown.
            var subject = Fill(tpl.Subject, req, FillMode.Plain, justDelivered).Trim();
            await _mail.SendAsync(
                recipients, subject,
                MarkdownMail.Render(
                    subject, Fill(tpl.Body, req, FillMode.Markdown, justDelivered), accent),
                Actor, replyTo);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Loi khi gui mail {Event} cho de nghi {ReqNo} — viec nghiep vu VAN da ghi xong.",
                eventCode, req.ReqNo);
        }
    }

    /// <summary>Cách thoát giá trị khi điền vào mẫu.</summary>
    private enum FillMode
    {
        /// <summary>Tiêu đề mail: chữ thuần, không thoát gì.</summary>
        Plain,

        /// <summary>
        /// Thân mail markdown: thoát ký tự markdown để "*" hay "#" trong ghi chú
        /// hiện y nguyên, và "|" trong ghi chú không cắt ô bảng làm hai.
        /// </summary>
        Markdown,
    }

    /// <summary>
    /// Điền mẫu mail. Mẫu viết bằng MARKDOWN — đúng quy ước của hệ thống, để màn
    /// Cấu hình email xem trước ra đúng lá mail sẽ gửi. Vì vậy chữ người dùng
    /// nhập thoát bằng <see cref="MarkdownMail.Escape"/> chứ KHÔNG phải
    /// HtmlEncode: thân mail không còn là HTML gõ tay, mà HtmlEncode trong
    /// markdown sẽ hiện ra "&amp;amp;" cho người đọc thấy.
    ///
    /// Dùng CHUNG cho cả hai mẫu: <c>Replace</c> một placeholder không có trong
    /// mẫu là không làm gì, nên mỗi mẫu chỉ nhận đúng phần nó khai.
    ///
    /// <paramref name="dl"/> là kết quả LƯỢT GIAO vừa xong, chỉ có ở lá
    /// RETURN_BACK_DELIVERED. Không có nó thì các biến của lượt giao lấy số của
    /// cả đề nghị — mẫu khai sai chỗ vẫn ra số đọc được, không ra chuỗi rỗng.
    /// </summary>
    private string Fill(string? template, ReturnBackRequest req, FillMode mode,
                        ReturnBackDeliverResult? dl = null)
    {
        if (string.IsNullOrWhiteSpace(template)) return string.Empty;

        var link = template.Contains("{Link}", StringComparison.Ordinal)
            ? BuildLink(req) : string.Empty;
        var table = template.Contains("{LinesTable}", StringComparison.Ordinal)
            ? BuildLinesTable(req) : string.Empty;
        var pallets = template.Contains("{PalletTable}", StringComparison.Ordinal)
            ? BuildPalletTable(dl) : string.Empty;

        Func<string?, string> enc = mode == FillMode.Markdown ? MarkdownMail.Escape : v => v ?? "";

        // GIỮ KHỚP danh sách biến với ReturnMailConfigDialog bên Web (BackVars).
        // Link KHÔNG thoát markdown — thoát làm hỏng địa chỉ.
        return template
            .Replace("{Link}", link)
            .Replace("{LinesTable}", table)
            .Replace("{PalletTable}", pallets)
            .Replace("{ReqNo}", enc(req.ReqNo))
            .Replace("{DocNo}", enc(req.DocNo))
            .Replace("{GoodsType}", GoodsTypeLabel(req.GoodsType))
            .Replace("{ModelCount}", req.ModelCount.ToString())
            .Replace("{TotalQty}", req.TotalQty.ToString("N0"))
            // SL giao LƯỢT NÀY. Khác {AtFaQty} là tổng đang ở FA của cả đề nghị.
            .Replace("{DeliveredQty}", (dl?.DeliveredQty ?? req.AtFaQty).ToString("N0"))
            .Replace("{PalletCount}", (dl?.Pallets.Count(p => p.SerialCount > 0) ?? 0).ToString())
            .Replace("{AtFaQty}", req.AtFaQty.ToString("N0"))
            .Replace("{RemainQty}", (dl?.RemainQty ?? req.RemainQty).ToString("N0"))
            .Replace("{Note}", enc(req.Note))
            .Replace("{RequestedBy}", enc(req.RequestedBy))
            .Replace("{RequestedAt}", Dt(req.RequestedAt))
            .Replace("{FaApprovedBy}", enc(req.FaApprovedBy))
            .Replace("{FaApprovedAt}", Dt(req.FaApprovedAt))
            .Replace("{FaComment}", enc(req.FaComment))
            .Replace("{DeliveredBy}", enc(req.DeliveredBy ?? Actor))
            .Replace("{DeliveredAt}", Dt(req.DeliveredAt ?? DateTime.Now))
            .Replace("{ScsComment}", enc(req.ScsComment))
            .Replace("{Now}", Dt(DateTime.Now));
    }

    /// <summary>
    /// Bảng model + SL trong thân mail, dạng bảng pipe của markdown. Dựng ở code
    /// chứ không nhét vào mẫu: số dòng thay đổi theo từng đề nghị, mẫu trong DB
    /// không lặp được.
    ///
    /// Mở đầu VÀ kết thúc bằng một dòng trắng: mẫu do người dùng soạn, viết
    /// "Chi tiết:" rồi {LinesTable} ngay dòng dưới thì bảng nằm chung đoạn văn
    /// và markdown không nhận ra nó là bảng; thiếu dòng trắng ở cuối thì dòng
    /// chữ ngay sau bị hút vào bảng thành một ô.
    /// </summary>
    private static string BuildLinesTable(ReturnBackRequest req)
    {
        // Cột "Đã giao" chỉ hiện khi ĐÃ giao được con nào. Ở lá mail B2 thì cả
        // cột toàn số 0 và chỉ làm người đọc tưởng kho không có hàng.
        var showDelivered = req.AssignedQty > 0;

        var sb = new StringBuilder("\n\n");
        sb.Append(showDelivered
            ? "| # | Model | SL đề nghị | Đã giao |\n|--:|---|--:|--:|\n"
            : "| # | Model | SL đề nghị |\n|--:|---|--:|\n");

        foreach (var l in req.Lines)
        {
            sb.Append("| ").Append(l.LineNo)
              .Append(" | ").Append(MarkdownMail.Escape(l.Model))
              .Append(" | ").Append(l.Qty.ToString("N0"));
            if (showDelivered)
                sb.Append(" | ").Append(l.AssignedQty.ToString("N0"));
            sb.Append(" |\n");
        }

        sb.Append("| | **Tổng** | **").Append(req.TotalQty.ToString("N0")).Append("**");
        if (showDelivered)
            sb.Append(" | **").Append(req.AssignedQty.ToString("N0")).Append("**");
        sb.Append(" |\n");

        return sb.Append('\n').ToString();
    }

    /// <summary>
    /// Bảng pallet đã giao trong LƯỢT NÀY — thứ FA cần để đi nhận đúng pallet.
    ///
    /// Bỏ qua pallet chuyển được 0 con: nhật ký vẫn ghi để tra, nhưng in vào mail
    /// một dòng "pallet này không có gì" chỉ làm FA đi tìm vô ích.
    ///
    /// Không có dòng nào thì trả về hai dòng trắng, KHÔNG trả chuỗi rỗng: mẫu
    /// viết {PalletTable} giữa hai đoạn văn, cắt sạch đi thì hai đoạn dính vào
    /// nhau thành một.
    /// </summary>
    private static string BuildPalletTable(ReturnBackDeliverResult? dl)
    {
        var rows = dl?.Pallets.Where(p => p.SerialCount > 0).ToList() ?? [];
        if (rows.Count == 0) return "\n\n";

        var sb = new StringBuilder("\n\n");
        sb.Append("| # | Pallet ID | SL |\n|--:|---|--:|\n");

        var i = 0;
        foreach (var r in rows)
            sb.Append("| ").Append(++i)
              .Append(" | ").Append(MarkdownMail.Escape(r.LotNo))
              .Append(" | ").Append(r.SerialCount.ToString("N0"))
              .Append(" |\n");

        return sb.Append('\n').ToString();
    }

    private static string Dt(DateTime? v) => v?.ToString("dd/MM/yyyy HH:mm") ?? "";

    /// <summary>
    /// Nhãn loại hàng trong mail. Để nguyên tiếng Anh, KHÔNG qua localizer: mail
    /// gửi cho cả FA lẫn SCS và không có ngôn ngữ của người nhận — dịch theo
    /// ngôn ngữ của người BẤM là tuỳ tiện.
    /// </summary>
    private static string GoodsTypeLabel(string? goodsType) =>
        goodsType == ReturnGoodsType.Rework ? "Rework"
        : goodsType == ReturnGoodsType.Refurbish ? "Refurbish"
        : "";

    /// <summary>
    /// Link mở đúng tab Yêu cầu back hàng, lọc sẵn theo SỐ ĐỀ NGHỊ chứ không
    /// phải id: màn hình điền nó vào ô tìm kiếm nên người nhận hiểu vì sao danh
    /// sách chỉ còn một dòng, và số đề nghị là thứ người ta nhắc lại cho nhau
    /// được qua điện thoại.
    /// </summary>
    private string BuildLink(ReturnBackRequest req)
    {
        if (string.IsNullOrWhiteSpace(_webBaseUrl))
        {
            _logger.LogWarning(
                "Chua khai Web:BaseUrl trong appsettings — mail de nghi {ReqNo} se khong co link.",
                req.ReqNo);
            return string.Empty;
        }
        return $"{_webBaseUrl}/rework-back?reqNo={Uri.EscapeDataString(req.ReqNo)}";
    }
}
