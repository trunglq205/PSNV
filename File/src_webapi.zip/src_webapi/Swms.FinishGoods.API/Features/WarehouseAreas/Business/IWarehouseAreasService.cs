using Swms.FinishGoods.API.Features.WarehouseAreas.Api;

namespace Swms.FinishGoods.API.Features.WarehouseAreas.Business;

public interface IWarehouseAreasService
{
    Task<IReadOnlyList<WarehouseAreaSummary>> ListAsync(string? mapType, bool includeInactive);
    Task<WarehouseAreaSummary?> GetAsync(long id);
    Task<long> CreateAsync(CreateWarehouseAreaRequest req, string? user);
    Task UpdateAsync(long id, UpdateWarehouseAreaRequest req, string? user);
    Task SetActiveAsync(long id, bool active, string? user);
    Task SoftDeleteAsync(long id, string? user);
}
