using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Common.DataAccess;

public static class CommonModule
{
    public static IServiceCollection AddCommonInfrastructure(this IServiceCollection services)
    {
        // Connection factory is stateless -> singleton is fine.
        services.AddSingleton<IDbConnectionFactory, SqlConnectionFactory>();
        services.AddHttpContextAccessor();
        services.AddScoped<ICurrentUser, CurrentUser>();
        // Nguồn request (Web / PDA) cho stock_events.source — đọc header X-Client.
        services.AddScoped<IRequestSource, RequestSource>();
        services.AddScoped<ISapInboundLogRepository, SapInboundLogRepository>();
        services.AddScoped<SapInboundLogFilter>();
        return services;
    }
}
