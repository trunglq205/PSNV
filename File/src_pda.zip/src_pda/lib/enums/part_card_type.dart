enum PartCardType { Local, OverSea }
