using Microsoft.AspNetCore.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Yêu cầu một quyền, tham chiếu TRỰC TIẾP type trong cây Perms — không magic string:
///   [RequirePermission&lt;Perms.Receiving.Asn.Create&gt;]
/// Gõ sai type ⟹ compiler báo lỗi. Type không phải quyền hợp lệ ⟹ ném lỗi lúc khởi tạo.
/// (Generic attribute: cần C# 11 / .NET 7+.)
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequirePermissionAttribute<TPermission>
    : AuthorizeAttribute where TPermission : class
{
    public RequirePermissionAttribute()
        => Policy = PermissionPolicy.Prefix + PermissionCatalog.CodeOf<TPermission>();
}

// Policy dạng "perm:temploc.view|pda_receiving.temp_location"
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequireAnyPermissionAttribute<T1, T2> : AuthorizeAttribute
    where T1 : class where T2 : class
{
    public RequireAnyPermissionAttribute()
        => Policy = PermissionPolicy.Prefix
            + PermissionCatalog.CodeOf<T1>() + "|" + PermissionCatalog.CodeOf<T2>();
}

/// <summary>
/// Bản BA quyền — cho bước mà ba bên khác nhau đều phải làm được (vd huỷ yêu
/// cầu back: FA, quản lý FA và quản lý SCS, ai đang giữ bước cũng phải dừng
/// được). Policy vẫn là chuỗi nối '|' và
/// <see cref="PermissionAuthorizationHandler"/> đã xét OR trên đó, nên không
/// cần thêm gì ở tầng xử lý.
///
/// KHÔNG stack hai <see cref="RequirePermissionAttribute{T}"/> để thay thế:
/// ASP.NET AND các AuthorizeAttribute lại với nhau, ra ngược ý.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequireAnyPermissionAttribute<T1, T2, T3> : AuthorizeAttribute
    where T1 : class where T2 : class where T3 : class
{
    public RequireAnyPermissionAttribute()
        => Policy = PermissionPolicy.Prefix
            + PermissionCatalog.CodeOf<T1>() + "|"
            + PermissionCatalog.CodeOf<T2>() + "|"
            + PermissionCatalog.CodeOf<T3>();
}

/// <summary>
/// Bản nhận string — chỉ dùng khi BẮT BUỘC cần động (vd build policy từ dữ liệu).
/// Ưu tiên bản generic ở trên cho mọi endpoint tĩnh.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequirePermissionByCodeAttribute : AuthorizeAttribute
{
    public RequirePermissionByCodeAttribute(string permission)
        => Policy = PermissionPolicy.Prefix + permission;
}

public static class PermissionPolicy
{
    public const string Prefix = "perm:";

    public static string? ExtractPermission(string policyName)
        => policyName.StartsWith(Prefix, StringComparison.Ordinal)
            ? policyName[Prefix.Length..]
            : null;
}

public sealed class PermissionRequirement : IAuthorizationRequirement
{
    public string Permission { get; }
    public PermissionRequirement(string permission) => Permission = permission;
}
