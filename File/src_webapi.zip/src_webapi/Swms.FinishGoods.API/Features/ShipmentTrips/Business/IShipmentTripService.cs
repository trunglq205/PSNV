using Swms.FinishGoods.API.Features.ShipmentTrips.Api;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

public interface IShipmentTripService
{
    /// <summary>Danh sách chuyến; số CCCD / GPLX chỉ còn 4 số cuối.</summary>
    Task<List<TripResponse>> GetListAsync(TripQuery query);
    /// <summary>fullDriverId = true chỉ cho endpoint sửa (quyền sửa).</summary>
    Task<TripResponse> GetAsync(long id, bool fullDriverId);
    /// <summary>Các chuyến (chưa xoá, kể cả đã huỷ) có SI này.</summary>
    Task<List<TripResponse>> GetBySiAsync(long siId);

    Task<TripResponse> CreateAsync(TripSaveRequest request);
    Task<TripResponse> UpdateAsync(long id, TripSaveRequest request);
    Task<TripResponse> ChangeStatusAsync(long id, TripStatusRequest request);
    Task DeleteAsync(long id);
}
