using Swms.FinishGoods.API.Features.HdSoft.Business;
using Swms.FinishGoods.API.Features.HdSoft.DataAccess;
using Swms.FinishGoods.API.Features.HdSoft.PalletSync.Business;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.Sync.DataAccess;

namespace Swms.FinishGoods.API.Features.Sync.Business;

/// <summary>Job nền phần HD soft: đồng bộ vị trí theo giao dịch mới nhất.</summary>
public interface IHdSoftSyncJob
{
    /// <summary>
    /// Đồng bộ vị trí theo HD soft.
    ///  full = false: chỉ lot có giao dịch mới kể từ lần trước (1 câu SQL, rất nhanh).
    ///  full = true : mọi pallet đang tồn trong SWMS (tick "Quét toàn bộ" — vá chỗ sót,
    ///                vd. pallet lần trước bị cảnh báo vì đang kiểm OQC).
    ///  Lần đầu tiên (chưa có watermark) luôn chạy toàn bộ.
    /// </summary>
    Task SyncHdSoftAsync(SyncProgress p, bool full, CancellationToken ct);
}

/// <summary>Từng pallet đi qua <see cref="IPalletHdSoftSyncService"/> trong scope riêng (xem SyncBatch).</summary>
public sealed class HdSoftSyncJob : IHdSoftSyncJob
{
    // ── Hằng số ──────────────────────────────────────────────────────

    /// <summary>Key trong master.configs giữ mốc đồng bộ HD soft.</summary>
    private const string HdSoftWatermarkKey = "hdsoft.last_movement";

    /// <summary>Số pallet xử lý song song.</summary>
    private const int LocatorParallel = 4;

    /// <summary>Số lot mỗi câu ANY(@Lots) khi quét toàn bộ. Mỗi câu = 1 lần seq scan M_Transaction.</summary>
    private const int HdSoftChunkSize = 2000;

    /// <summary>
    /// Lùi mốc khi chạy incremental để không sót giao dịch commit muộn.
    /// Áp vị trí là idempotent nên lùi rộng tay cũng không sao.
    /// </summary>
    private const int HdSoftOverlapMinutes = 30;

    // ─────────────────────────────────────────────────────────────────

    private readonly ILotRepository _lots;
    private readonly IHdSoftLotRepository _hdRepo;
    private readonly ISyncStateRepository _state;
    private readonly SyncBatch<IPalletHdSoftSyncService> _batch;

    public HdSoftSyncJob(
        ILotRepository lots,
        IHdSoftLotRepository hdRepo,
        ISyncStateRepository state,
        IServiceScopeFactory scopes,
        ILogger<HdSoftSyncJob> log)
    {
        _lots = lots;
        _hdRepo = hdRepo;
        _state = state;
        _batch = new SyncBatch<IPalletHdSoftSyncService>(scopes, log);
    }

    // ── 3) HD soft: vị trí ───────────────────────────────────────────
    public async Task SyncHdSoftAsync(SyncProgress p, bool full, CancellationToken ct)
    {
        const string step = "HD soft";
        p.BeginStep(step, 0);

        var since = full ? null : await _state.GetWatermarkAsync(HdSoftWatermarkKey);
        IReadOnlyDictionary<string, HdSoftLastMovementRow> lastByLot;

        if (since is null)
        {
            // TOÀN BỘ (tick "Quét toàn bộ" hoặc lần đầu): pallet đang tồn trong SWMS, hỏi HD soft theo khối lớn
            // (trước đây 50 lot/lần = mỗi 50 pallet lại seq scan M_Transaction 1 lần).
            var lots = await _lots.GetLotNosInStockAsync();
            var map = new Dictionary<string, HdSoftLastMovementRow>(StringComparer.OrdinalIgnoreCase);
            var chunks = lots.Chunk(HdSoftChunkSize).ToList();

            p.BeginStep(step + " · đọc giao dịch", chunks.Count);
            foreach (var chunk in chunks)
            {
                ct.ThrowIfCancellationRequested();
                foreach (var kv in await _hdRepo.GetLastMovementsAsync(chunk))
                    map.TryAdd(kv.Key, kv.Value);
                Interlocked.Increment(ref p.StepProcessed);
            }
            lastByLot = map;
        }
        else
        {
            // INCREMENTAL: chỉ lot có giao dịch mới — 1 câu, 1 lần quét, không cần danh sách lot.
            lastByLot = await _hdRepo.GetLastMovementsSinceAsync(
                since.Value.AddMinutes(-HdSoftOverlapMinutes));
        }

        // Watermark tính theo đồng hồ của CHÍNH HD soft -> không lệch giờ giữa 2 server.
        DateTime? newWatermark = lastByLot.Count > 0
            ? lastByLot.Values.Max(x => x.MovementTime)
            : since;

        // 1 câu SQL nạp vị trí hiện tại của cả nhóm (trước đây 1–2 câu / pallet).
        // Lot có bên HD soft nhưng không có trong SWMS -> bỏ qua; bước FA sẽ tạo nếu cần.
        var infos = await _lots.GetLocationInfosByLotNosAsync(lastByLot.Keys.ToList());
        var work = infos.Values
            .Where(i => lastByLot.ContainsKey(i.LotNo))
            .Select(i => (Info: i, Last: lastByLot[i.LotNo]))
            .ToList();

        p.BeginStep(step + " · cập nhật vị trí", work.Count);

        var batchId = Guid.NewGuid();
        await _batch.ForEachAsync(work, w => w.Info.LotNo, LocatorParallel, step, p, ct, async (svc, w) =>
        {
            // nhiều khả năng ý định là w.Last.UpdateBy. Giữ nguyên hành vi cũ khi sắp xếp lại.
            var updateBy = lastByLot.FirstOrDefault().Value?.UpdateBy.ToString();
            var r = await svc.ApplyHdSoftAsync(w.Info, w.Last, SyncLots.NewSync(StockEventSources.HdSoft, batchId, updateBy));
            if (r.Actions.Count > 0) Interlocked.Increment(ref p.LocatorChanged);
            foreach (var msg in r.Warnings) p.Warn(step, w.Info.LotNo, msg);
        });

        // Chỉ tiến watermark khi chạy hết (bị huỷ giữa chừng thì ForEachAsync đã ném).
        if (newWatermark is not null && newWatermark != since)
            await _state.SetWatermarkAsync(HdSoftWatermarkKey, newWatermark.Value);
    }

}
