import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';

enum InspectionStatus {
  notInspected('not_inspected'),
  underInspection('under_inspection'),
  pendingResult('pending_result'),
  pass('pass'),
  ng('ng'),
  inspectionExempt('inspection_exempt');

  final String key;

  const InspectionStatus(this.key);

  static InspectionStatus fromKey(String? key) {
    return values.firstWhere((e) => e.key == key, orElse: () => .notInspected);
  }

  @override
  String toString() => 'inspection_status.$key'.tr();
}

class StatusColor {
  final Color fg; // màu số/chữ + màu swatch
  final Color bg; // màu nền badge (nếu dùng dạng pill)
  const StatusColor(this.fg, this.bg);
}

extension InspectionStatusColor on InspectionStatus {
  StatusColor get color {
    switch (this) {
      case InspectionStatus.notInspected:
        // "Empty" — ô xám nhạt viền
        return const StatusColor(AppColors.text4, AppColors.card2);

      case InspectionStatus.underInspection:
        // "Under inspection" — cam
        return const StatusColor(AppColors.warning, AppColors.warningBg);

      case InspectionStatus.pendingResult:
        // "Pending result" — xanh dương nhạt
        return const StatusColor(AppColors.primaryLight, AppColors.primaryTint);

      case InspectionStatus.ng:
        // "NG" — đỏ
        return const StatusColor(AppColors.danger, AppColors.dangerBg);

      case InspectionStatus.inspectionExempt:
        // "Inspection exempt" — xanh dương đậm hơn pending
        return const StatusColor(AppColors.primary, AppColors.primaryTint2);

      case InspectionStatus.pass:
        // "OK" — xanh lá
        return const StatusColor(AppColors.success, AppColors.successBg);
    }
  }
}
