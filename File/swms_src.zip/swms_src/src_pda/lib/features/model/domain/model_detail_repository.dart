import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';

abstract class ModelDetailRepository {
  /// Chi tiết model theo id.
  Future<ModelDetail> getDetail(int id);

  /// Chỉnh sửa model (PUT — ghi đè toàn bộ). Trả bản mới nhất từ server.
  Future<ModelDetail> update(int id, ModelEdit edit);

  /// Cập nhật RIÊNG gợi ý lưu kho. null / rỗng = xoá gợi ý đó.
  /// API ghi đè CẢ HAI cột nên luôn phải truyền đủ cả khu lẫn tầng.
  Future<ModelDetail> updateSuggestion({
    required int id,
    required int? suggestAreaId,
    required List<int> suggestRackRow,
  });
}