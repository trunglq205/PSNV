// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'kitting_task_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Màn lấy hàng tại 1 vị trí.
///   - Đọc  : GET  tasks/{id}/pick                        → executePartial
///   - Ghi  : confirm-pallet / boxes / gỡ thùng / vanning → appAction
///            (overlay + lỗi server đã dịch), mỗi lúc 1 lệnh.

@ProviderFor(KittingTaskNotifier)
final kittingTaskProvider = KittingTaskNotifierFamily._();

/// Màn lấy hàng tại 1 vị trí.
///   - Đọc  : GET  tasks/{id}/pick                        → executePartial
///   - Ghi  : confirm-pallet / boxes / gỡ thùng / vanning → appAction
///            (overlay + lỗi server đã dịch), mỗi lúc 1 lệnh.
final class KittingTaskNotifierProvider
    extends $NotifierProvider<KittingTaskNotifier, KittingTaskState> {
  /// Màn lấy hàng tại 1 vị trí.
  ///   - Đọc  : GET  tasks/{id}/pick                        → executePartial
  ///   - Ghi  : confirm-pallet / boxes / gỡ thùng / vanning → appAction
  ///            (overlay + lỗi server đã dịch), mỗi lúc 1 lệnh.
  KittingTaskNotifierProvider._({
    required KittingTaskNotifierFamily super.from,
    required PickTask super.argument,
  }) : super(
         retry: null,
         name: r'kittingTaskProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$kittingTaskNotifierHash();

  @override
  String toString() {
    return r'kittingTaskProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  KittingTaskNotifier create() => KittingTaskNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(KittingTaskState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<KittingTaskState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is KittingTaskNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$kittingTaskNotifierHash() =>
    r'836ab557ccc8be80dc9c7329a4a4bc38134335fe';

/// Màn lấy hàng tại 1 vị trí.
///   - Đọc  : GET  tasks/{id}/pick                        → executePartial
///   - Ghi  : confirm-pallet / boxes / gỡ thùng / vanning → appAction
///            (overlay + lỗi server đã dịch), mỗi lúc 1 lệnh.

final class KittingTaskNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          KittingTaskNotifier,
          KittingTaskState,
          KittingTaskState,
          KittingTaskState,
          PickTask
        > {
  KittingTaskNotifierFamily._()
    : super(
        retry: null,
        name: r'kittingTaskProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Màn lấy hàng tại 1 vị trí.
  ///   - Đọc  : GET  tasks/{id}/pick                        → executePartial
  ///   - Ghi  : confirm-pallet / boxes / gỡ thùng / vanning → appAction
  ///            (overlay + lỗi server đã dịch), mỗi lúc 1 lệnh.

  KittingTaskNotifierProvider call(PickTask task) =>
      KittingTaskNotifierProvider._(argument: task, from: this);

  @override
  String toString() => r'kittingTaskProvider';
}

/// Màn lấy hàng tại 1 vị trí.
///   - Đọc  : GET  tasks/{id}/pick                        → executePartial
///   - Ghi  : confirm-pallet / boxes / gỡ thùng / vanning → appAction
///            (overlay + lỗi server đã dịch), mỗi lúc 1 lệnh.

abstract class _$KittingTaskNotifier extends $Notifier<KittingTaskState> {
  late final _$args = ref.$arg as PickTask;
  PickTask get task => _$args;

  KittingTaskState build(PickTask task);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<KittingTaskState, KittingTaskState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<KittingTaskState, KittingTaskState>,
              KittingTaskState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
