using System.Globalization;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.ShipmentInstruction.Business.Models;

namespace Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business.Models;

// ── Đối chiếu SI: SWMS ↔ HD soft (hệ thống cũ) ─────────────
// SAP gửi SI cho cả hai; chạy song song thì 2 bên phải có cùng SI, cùng header, cùng dòng.
// API so sẵn (đã chuẩn hoá 2 bên như nhau), màn hình chỉ hiển thị.

/// <summary>1 SI trong danh sách đối chiếu.</summary>
public class AppSiCompareSummary
{
    public string SiNo { get; set; } = "";
    /// <summary>match | mismatch | only_swms (HD soft không có) | only_hdsoft (SWMS chưa có).</summary>
    public string Result { get; set; } = "";
    public int IssueCount { get; set; }
    public string? FirstIssue { get; set; }
    /// <summary>1 trong 2 bên đã huỷ.</summary>
    public bool IsCancelled { get; set; }
    /// <summary>ETD SWMS; SI chỉ có ở HD soft thì là ETD bên HD soft.</summary>
    public DateTime? EtdDate { get; set; }
    public DateTime? VanningDate { get; set; }
    public int? DaysToVanning => VanningDate is { } d ? (d.Date - DateTime.Today).Days : null;

    public long? SwmsId { get; set; }
    public string? SwmsDocNo { get; set; }
    public string? SwmsStatus { get; set; }
    public DateTime? SwmsCreatedAt { get; set; }
    public int SwmsLineCount { get; set; }
    public int SwmsTotalQty { get; set; }

    public long? HdSoftOrderId { get; set; }
    public string? HdSoftDocNo { get; set; }
    public string? HdSoftStatus { get; set; }
    public string? HdSoftStatusName { get; set; }
    public DateTime? HdSoftCreatedAt { get; set; }
    public int HdSoftLineCount { get; set; }
    public decimal HdSoftTotalQty { get; set; }

    public bool HasSwms => SwmsId is not null;
    public bool HasHdSoft => HdSoftOrderId is not null;
    public bool IsMatch => Result == SiCompareDisplay.Match;

    /// <summary>HD soft − SWMS (tổng số lượng). null khi SI chỉ có ở 1 bên.</summary>
    public decimal? QtyDiff => HasSwms && HasHdSoft ? HdSoftTotalQty - SwmsTotalQty : null;

    public DateTime? CreatedAt => SwmsCreatedAt ?? HdSoftCreatedAt;

    /// <summary>Số ngày tới ETD (0 = hôm nay).</summary>
    public int? DaysToEtd => EtdDate is { } e ? (e.Date - DateTime.Today).Days : null;
}

/// <summary>1 trường header. Status: match | diff | only_swms | only_hdsoft.
/// Label = nhãn tiếng Việt API gửi kèm, dùng khi web chưa có resource cho Field.</summary>
public record AppSiCompareField(string Field, string Label, string? Swms, string? HdSoft, string Status)
{
    public bool IsDiff => Status == "diff";
}

/// <summary>1 nhóm dòng cùng khoá (packing list + item + model, hoặc chỉ model).</summary>
public class AppSiCompareLine
{
    public string Key { get; set; } = "";
    public string Model { get; set; } = "";
    public string? PackingListNo { get; set; }
    public string? PackingItemNo { get; set; }
    /// <summary>match | qty_diff | field_diff | only_swms | only_hdsoft.</summary>
    public string Status { get; set; } = "";
    public int? SwmsQty { get; set; }
    public decimal? HdSoftQty { get; set; }
    public List<int> SwmsLineNos { get; set; } = new();
    public List<int> HdSoftLineNos { get; set; } = new();

    // Chỉ để xem, không tính là lệch
    public int SwmsQtyPicked { get; set; }
    public int SwmsQtyCut { get; set; }
    public decimal HdSoftQtyDelivered { get; set; }

    /// <summary>SO / SO item hai bên (chỉ khi khớp theo packing).</summary>
    public List<AppSiCompareField> Fields { get; set; } = new();
    public string? Note { get; set; }

    public bool IsIssue => Status != SiCompareDisplay.Match;
    /// <summary>HD soft − SWMS. null khi dòng chỉ có ở 1 bên.</summary>
    public decimal? QtyDiff => SwmsQty is { } s && HdSoftQty is { } h ? h - s : null;
}

/// <summary>Chi tiết đối chiếu 1 SI.</summary>
public class AppSiCompare
{
    public AppSiCompareSummary Summary { get; set; } = new();
    /// <summary>packing: khớp từng packing item | model: HD soft thiếu cột packing, so tổng theo model.</summary>
    public string LineKeyMode { get; set; } = "";
    public List<AppSiCompareField> Header { get; set; } = new();
    public List<AppSiCompareLine> Lines { get; set; } = new();
    /// <summary>Thông tin phụ: HD soft nhiều phiếu cùng SI, trường không so được vì thiếu cột…</summary>
    public List<string> Notes { get; set; } = new();
    public DateTime ComparedAt { get; set; }

    public bool PackingMode => LineKeyMode == "packing";
    public int HeaderDiffCount => Header.Count(f => f.IsDiff);
    public int LineIssueCount => Lines.Count(l => l.IsIssue);
}

/// <summary>Kết quả đối chiếu theo khoảng ngày. Số đếm tính trên tất cả SI.</summary>
public class AppSiCompareList
{
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public string? Warehouse { get; set; }
    public int Total { get; set; }
    public int Matched { get; set; }
    public int Mismatched { get; set; }
    public int OnlySwms { get; set; }
    public int OnlyHdSoft { get; set; }
    public List<AppSiCompareSummary> Items { get; set; } = new();
    public DateTime ComparedAt { get; set; }

    public int IssueCount => Total - Matched;
    public int MatchPercent => Total == 0 ? 0 : (int)Math.Floor(Matched * 100.0 / Total);
}

// ── Helper hiển thị ─────────────────────────────────────────
public static class SiCompareDisplay
{
    public const string Match = "match";
    public const string Mismatch = "mismatch";
    public const string OnlySwms = "only_swms";
    public const string OnlyHdSoft = "only_hdsoft";

    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    // Nhãn dịch theo key; chưa có key thì hiện fallback (giống SiDisplay.Loc).
    private static string Loc(IStringLocalizer L, string key, string fallback)
    {
        var v = L[key];
        return v.ResourceNotFound ? fallback : v.Value;
    }

    // ── Kết quả 1 SI ──
    public static string ResultLabel(string r, IStringLocalizer L) => Loc(L, $"SiCmp.Result.{r}", r);

    public static string ResultPill(string r) => r switch
    {
        Match => "success",
        Mismatch => "warning",
        OnlySwms or OnlyHdSoft => "danger",
        _ => "dim",
    };

    // ── Trạng thái 1 dòng ──
    public static string LineLabel(string s, IStringLocalizer L) => Loc(L, $"SiCmp.Line.{s}", s);

    public static string LinePill(string s) => s switch
    {
        Match => "success",
        "field_diff" => "warning",
        _ => "danger",                  // qty_diff, only_swms, only_hdsoft
    };

    /// <summary>DocStatus iDempiere: hoàn thành / đóng xanh lá; nháp, huỷ / đảo mờ (cùng màu "Nháp" SWMS); còn lại xanh dương.</summary>
    public static string HdStatusPill(string? code) => code?.Trim().ToUpperInvariant() switch
    {
        "CO" or "CL" => "success",
        "DR" or "VO" or "RE" => "dim",
        null or "" => "dim",
        _ => "info",
    };

    /// <summary>Tạo được SI SWMS theo HD soft: chỉ có ở HD soft và HD soft chưa huỷ / đảo.</summary>
    public static bool CanCreateFromHdSoft(AppSiCompareSummary x)
        => x.Result == OnlyHdSoft && !x.IsCancelled
        && x.HdSoftStatus?.Trim().ToUpperInvariant() is not ("VO" or "RE");

    /// <summary>Nhãn trường: resource của màn SI nếu có (dùng chung bảng nhãn lịch sử SAP), không thì nhãn API gửi.</summary>
    public static string FieldLabel(AppSiCompareField f, IStringLocalizer L)
    {
        var label = SiDisplay.HistFieldLabel(f.Field, L);
        return label == f.Field ? f.Label : label;
    }

    /// <summary>Giá trị hiển thị: ngày dd/MM/yyyy, trống "—" (cùng quy tắc lịch sử SAP).</summary>
    public static string Value(string field, string? raw, IStringLocalizer L) => SiDisplay.HistValue(field, raw, L);

    /// <summary>Số lượng: số nguyên không phần lẻ, có phần lẻ thì tối đa 3 chữ số.</summary>
    public static string Qty(decimal? q) => q is null ? "—" : q.Value.ToString("#,##0.###", CultureInfo.CurrentCulture);

    public static string Qty(int? q) => q is null ? "—" : q.Value.ToString("N0", CultureInfo.CurrentCulture);

    /// <summary>"+100" / "−50"; 0 hoặc null -> "—".</summary>
    public static string Diff(decimal? d)
    {
        if (d is null || d == 0) return "—";
        var abs = Math.Abs(d.Value).ToString("#,##0.###", CultureInfo.CurrentCulture);
        return d > 0 ? $"+{abs}" : $"−{abs}";
    }

    /// <summary>Phần trăm cho width CSS — luôn InvariantCulture ("12.5%", không "12,5%").</summary>
    public static string Pct(int part, int total)
        => total <= 0 ? "0%" : Math.Min(100.0, part * 100.0 / total).ToString("0.##", Inv) + "%";
}

// ── Tạo SI SWMS theo HD soft (SI chỉ có ở HD soft) ─────────
// SI loại này do HD soft tự tạo, SAP không gửi lại -> tạo ở SWMS bằng API tạo SI có sẵn.
// Lấy giá trị phía HD soft trong kết quả so — API đã chuẩn hoá qua SapSiMapper
// (ngày yyyy-MM-dd, cut-off yyyy-MM-dd HH:mm, cờ "Có"/"Không").
public static class SiHdSoftCreate
{
    private static readonly CultureInfo Inv = CultureInfo.InvariantCulture;

    /// <summary>Giá trị HD soft của 1 trường header; trường không so được (HD soft thiếu cột) -> null.</summary>
    public static string? Hd(AppSiCompare d, string field)
    {
        var v = d.Header.FirstOrDefault(f => f.Field == field)?.HdSoft;
        return string.IsNullOrWhiteSpace(v) ? null : v.Trim();
    }

    public static DateTime? Date(string? v)
        => DateTime.TryParseExact(v, "yyyy-MM-dd", Inv, DateTimeStyles.None, out var d) ? d.Date : null;

    public static DateTime? DateTimeHm(string? v)
        => DateTime.TryParseExact(v, "yyyy-MM-dd HH:mm", Inv, DateTimeStyles.None, out var d) ? d : null;

    /// <summary>API trả "Có" / "Không" (SiHdSoftComparer.YesNo).</summary>
    public static bool? YesNo(string? v) => v?.Trim().ToLowerInvariant() switch
    {
        "có" or "true" or "yes" => true,
        "không" or "false" or "no" => false,
        _ => null,
    };

    /// <summary>ETD: trường etd_date; HD soft không có cột etd thì ETD của summary (API lấy DatePromised).</summary>
    public static DateTime? Etd(AppSiCompare d) => Date(Hd(d, "etd_date")) ?? d.Summary.EtdDate?.Date;

    /// <summary>Dòng sẽ tạo: dòng có số lượng bên HD soft.</summary>
    public static List<AppSiCompareLine> Lines(AppSiCompare d)
        => d.Lines.Where(l => l.HdSoftQty is > 0 && !string.IsNullOrWhiteSpace(l.Model)).ToList();

    /// <summary>null = tạo được; còn lại là lý do (đã dịch).</summary>
    public static string? Check(AppSiCompare d, IStringLocalizer L)
    {
        var s = d.Summary;
        if (s.HasSwms) return L["SiCmp.Create.Exists", s.SiNo];
        if (!SiCompareDisplay.CanCreateFromHdSoft(s)) return L["SiCmp.Create.HdCancelled", s.SiNo];
        if (Etd(d) is null) return L["SiCmp.Create.NoEtd", s.SiNo];

        var lines = Lines(d);
        if (lines.Count == 0) return L["SiCmp.Create.NoLines", s.SiNo];

        var bad = lines.FirstOrDefault(l => l.HdSoftQty!.Value != decimal.Truncate(l.HdSoftQty.Value)
                                         || l.HdSoftQty.Value > int.MaxValue);
        if (bad is not null) return L["SiCmp.Create.BadQty", bad.Model, SiCompareDisplay.Qty(bad.HdSoftQty)];

        return null;
    }
}