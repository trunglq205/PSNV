﻿using CriticalListReport.Helpers;
using CriticalListReport.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CriticalListReport.Controllers
{
    [Authorize]
    [Authorize(Roles = "Admin,User")]
    public class UploadMasterController : Controller
    {
        private readonly ILogger<UploadMasterController> _logger;
        private readonly AppDbContext _context;
        private const string _errorFile = "File không hợp lệ!";
        private const string _errorNoData = "Không có dữ liệu hợp lệ để import.";
        private const string _errorExcep = "Có lỗi xảy ra. Kiểm tra lại format hoặc liên hệ quản trị viên!";

        public UploadMasterController(ILogger<UploadMasterController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public IActionResult Index()
        {
            return View();
        }

        private string MsgUploadSuccess(int count)
        {
            return $"Upload thành công {count} dòng!";
        }

        private async Task LogActionAsync(string actionName, string fileName)
        {
            _context.ActionHistories.Add(new ActionHistory
            {
                Username = User.Identity?.Name ?? "Anonymous",
                ActionName = actionName,
                FileName = fileName
            });
            await _context.SaveChangesAsync();
        }

        [HttpPost]
        public async Task<IActionResult> UploadVendorMaster(IFormFile vendorMaster)
        {
            try
            {
                if (vendorMaster == null || vendorMaster.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();
                var list = await excelService.ParseExcelAsync<VendorMaster>(vendorMaster, row =>
                {
                    return new VendorMaster
                    {
                        Vendor = row.Cell(1).GetString().Trim(),
                        VendorName = row.Cell(2).GetString().Trim(),
                        FreightUnit = row.Cell(3).GetString().Trim()
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE VendorMaster");
                _context.VendorMasters.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(vendorMaster, "VendorMasterFormat.xlsx");

                await LogActionAsync("UploadMaster_Vendor", vendorMaster.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadCategoryMaster(IFormFile categoryMaster)
        {
            try
            {
                if (categoryMaster == null || categoryMaster.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();
                var list = await excelService.ParseExcelAsync<CategoryMaster>(categoryMaster, row =>
                {
                    return new CategoryMaster
                    {
                        Category = row.Cell(1).GetString().Trim(),
                        ProfitCenterCode = row.Cell(2).GetString().Trim(),
                        BusinessDivision = row.Cell(3).GetString().Trim()
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE ProfitCentersMaster");
                _context.CategoryMasters.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(categoryMaster, "CategoryMasterFormat.xlsx");

                await LogActionAsync("UploadMaster_Category", categoryMaster.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadPartMaster(IFormFile partMaster)
        {
            try
            {
                if (partMaster == null || partMaster.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();
                var list = await excelService.ParseExcelAsync<PartMaster>(partMaster, row =>
                {
                    return new PartMaster
                    {
                        PartNo = row.Cell(1).GetString().Trim(),
                        Vendor = row.Cell(2).GetString().Trim(),
                        MakerName = row.Cell(3).GetString().Trim()
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                list = list
                    .GroupBy(x => new { x.PartNo, x.Vendor, x.MakerName })
                    .Select(g => g.First())
                    .ToList();

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE PartMaster");
                _context.PartMasters.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(partMaster, "PartMasterFormat.xlsx");

                await LogActionAsync("UploadMaster_Part", partMaster.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadGWMaster(IFormFile gWMaster)
        {
            try
            {
                if (gWMaster == null || gWMaster.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();
                var list = await excelService.ParseExcelAsync<GrossWeightMaster>(gWMaster, row =>
                {
                    var material = row.Cell(1).GetString().Trim();
                    var gw = decimal.TryParse(row.Cell(2).GetString().Trim(), out var gwValue) ? gwValue : 0;
                    var unit = row.Cell(3).GetString().Trim();

                    // Quy đổi G → KG cho vật liệu ZM
                    if (material.StartsWith("ZM", StringComparison.OrdinalIgnoreCase)
                        && unit.Equals("G", StringComparison.OrdinalIgnoreCase))
                    {
                        gw = gw / 1000.0m;
                        unit = "KG";
                    }

                    return new GrossWeightMaster
                    {
                        Material = material,
                        GrossWeight = gw,
                        UnitOfPacking = unit
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                list = list
                    .Where(x => x.GrossWeight != 0)
                    .GroupBy(x => new { x.Material, x.GrossWeight, x.UnitOfPacking })
                    .Select(g => g.First())
                    .ToList();

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE GrossWeightMaster");
                _context.GrossWeightMasters.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(gWMaster, "GrossWeightMasterFormat.xlsx");

                await LogActionAsync("UploadMaster_GrossWeight", gWMaster.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadMRPMaster(IFormFile mrpMaster)
        {
            try
            {
                if (mrpMaster == null || mrpMaster.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();
                var list = await excelService.ParseExcelAsync<MRPMaster>(mrpMaster, row =>
                {
                    return new MRPMaster
                    {
                        MRPC = row.Cell(1).GetString().Trim(),
                        MRPName = row.Cell(2).GetString().Trim()
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                list = list
                    .GroupBy(x => new { x.MRPC, x.MRPName })
                    .Select(g => g.First())
                    .ToList();

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE MRPMaster");
                _context.MRPMasters.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(mrpMaster, "MRPMasterFormat.xlsx");

                await LogActionAsync("UploadMaster_MRP", mrpMaster.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadFactoryMaster(IFormFile factoryMaster)
        {
            try
            {
                if (factoryMaster == null || factoryMaster.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();
                var list = await excelService.ParseExcelAsync<FactoryMaster>(factoryMaster, row =>
                {
                    return new FactoryMaster
                    {
                        FactoryCode = row.Cell(1).GetString().Trim(),
                        FactoryName = row.Cell(2).GetString().Trim()
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                list = list
                    .GroupBy(x => new { x.FactoryCode, x.FactoryName })
                    .Select(g => g.First())
                    .ToList();

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE FactoryMaster");
                _context.FactoryMasters.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(factoryMaster, "FactoryMasterFormat.xlsx");

                await LogActionAsync("UploadMaster_Factory", factoryMaster.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadStockOtherFactory(IFormFile stockOtherFactory)
        {
            try
            {
                if (stockOtherFactory == null || stockOtherFactory.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();

                var list = await excelService.ParseExcelAsync<StockOtherFactory>(stockOtherFactory, row =>
                {
                    return new StockOtherFactory
                    {
                        Plant = row.Cell(1).GetString().Trim(),
                        Material = row.Cell(2).GetString().Trim(),
                        Stock = decimal.TryParse(row.Cell(25).GetString().Trim(), out var stockValue)
                        ? stockValue
                        : 0
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE StockOtherFactory");

                _context.StockOtherFactories.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(stockOtherFactory, "StockOtherFactoryFormat.xlsx");

                await LogActionAsync("UploadMaster_StockOtherFactory", stockOtherFactory.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadNonWorkingCalendar(IFormFile nonWorkingCalendar)
        {
            try
            {
                if (nonWorkingCalendar == null || nonWorkingCalendar.Length == 0)
                    return Json(new { success = false, message = _errorFile });

                var excelService = new ExcelUploadHelper();

                var list = await excelService.ParseExcelAsync<NonWorkingCalendar>(nonWorkingCalendar, row =>
                {
                    var dateStr = row.Cell(5).GetString().Trim();

                    if (!DateTime.TryParse(dateStr, out var fromDate))
                        return null;

                    return new NonWorkingCalendar
                    {
                        FromDate = fromDate
                    };
                });

                if (list.Count == 0)
                    return Json(new { success = false, message = _errorNoData });

                await _context.Database.ExecuteSqlRawAsync("TRUNCATE TABLE NonWorkingCalendar");

                _context.NonWorkingCalendars.AddRange(list);
                await _context.SaveChangesAsync();

                await FileTemplateHelper.SaveUploadedFileAsTemplateAsync(nonWorkingCalendar, "NonWorkingCalendarFormat.xlsx");

                await LogActionAsync("UploadMaster_NonWorkingCalendar", nonWorkingCalendar.FileName);

                return Json(new { success = true, message = MsgUploadSuccess(list.Count) });
            }
            catch
            {
                return Json(new { success = false, message = _errorExcep });
            }
        }
    }
}