import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_pickup_entities.dart';

// ─────────────────────────────────────────────────────────────
//  B5 — đọc JSON của một lượt FA nhận hàng, VIẾT TAY.
//
//  Cùng lý do với cả bộ 2c/2d: build_runner đang vỡ nên không sinh `.g.dart`.
//  Mọi hàm đọc đều chịu được trường thiếu / sai kiểu — vỡ parse giữa lúc FA
//  đang đứng ở kho quét hàng là mất cả lượt làm, trong khi thứ FA cần biết chỉ
//  là "nhận được mấy con".
//
//  Khoá JSON camelCase: API dùng JsonNamingPolicy.CamelCase mặc định của
//  ASP.NET, nên record `FaPickupResponse(long DocId, …)` ra `docId`, `docNo`, …
// ─────────────────────────────────────────────────────────────

int _int(Object? v, [int fallback = 0]) => switch (v) {
      int i => i,
      double d => d.round(),
      num n => n.round(),
      String s => int.tryParse(s) ?? fallback,
      _ => fallback,
    };

bool _bool(Object? v, [bool fallback = false]) => switch (v) {
      bool b => b,
      String s => s.toLowerCase() == 'true',
      _ => fallback,
    };

String? _str(Object? v) {
  if (v == null) return null;
  final s = v.toString().trim();
  return s.isEmpty ? null : s;
}

FaPickupResult faPickupResultFromJson(Object? json) {
  final m = json is Map ? json : const {};
  return FaPickupResult(
    docId: _int(m['docId']),
    docNo: _str(m['docNo']),
    round: _int(m['round']),
    lotNo: _str(m['lotNo']),
    locatorCode: _str(m['locatorCode']),
    pickedQty: _int(m['pickedQty']),
    remainQty: _int(m['remainQty']),
    completed: _bool(m['completed']),
  );
}
