import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_event.dart';
import 'package:swms_finish_goods/features/box_detail/domain/repositories/box_detail_repository.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/providers/box_detail_providers.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/providers/box_detail_state.dart';

part 'box_detail_notifier.g.dart';

/// Notifier family theo boxId (id là định danh duy nhất, không dùng boxNo).
@riverpod
class BoxDetailNotifier extends _$BoxDetailNotifier
    with BaseNotifierMixin<BoxDetailState> {
  BoxDetailRepository get _repo => ref.read(boxDetailRepositoryProvider);

  @override
  BoxDetailState build(int boxId) {
    Future.microtask(() {
      load();
      loadHistory();
    });
    return const BoxDetailState();
  }

  /// Đọc/lookup → executePartial (lỗi hiển thị inline trong vùng detail).
  Future<void> load() => executePartial<BoxDetail>(
    action: () => _repo.getDetail(boxId),
    getField: (s) => s.detail,
    setField: (s, f) => s.copyWith(detail: f),
  );

  /// Lịch sử thùng.
  ///
  /// Gọi SONG SONG với [load] chứ không nối tiếp: hai request độc lập, và
  /// timeline không nên phải chờ danh sách serial.
  ///
  /// Lỗi nằm gọn trong `state.history` (executePartial) — lịch sử hỏng thì màn
  /// vẫn xem được thông tin thùng và sửa PO bình thường.
  Future<void> loadHistory() => executePartial<BoxHistory>(
    action: () => _repo.getHistory(boxId, ownOnly: state.historyOwnOnly),
    getField: (s) => s.history,
    setField: (s, f) => s.copyWith(history: f),
  );

  /// Bật/tắt "chỉ thao tác trên thùng này".
  ///
  /// Lọc ở SERVER nên phải gọi lại API. Không lọc ở client vì pallet nằm kho
  /// lâu có thể kéo theo hàng trăm dòng kế thừa — tải hết rồi vứt đi là lãng
  /// phí mạng kho.
  Future<void> setHistoryOwnOnly(bool value) async {
    if (value == state.historyOwnOnly) return;
    state = state.copyWith(historyOwnOnly: value);
    await loadHistory();
  }

  /// Cập nhật PO — optimistic, rollback nếu lỗi.
  /// null = xoá giá trị (khớp includeIfNull: true của body PATCH).
  Future<void> updatePo({
    required String? customerPo,
    required String? psnvPo,
  }) async {
    final current = state.detail.value;
    if (current == null) return;

    final optimistic = current.copyWithPo(
      customerPo: customerPo,
      psnvPo: psnvPo,
    );

    await applyOptimistic(state.copyWith(detail: AsyncValue.data(optimistic)), (
        _,
        ) async {
      final updated = await _repo.updatePo(
        id: boxId,
        customerPo: customerPo,
        psnvPo: psnvPo,
      );
      // Bản server-authoritative (server có thể trim/chuẩn hoá).
      state = state.copyWith(detail: AsyncValue.data(updated));
    });

    // Sửa PO sinh event BOX_PO_CHANGED -> timeline phải có dòng mới.
    // Đặt ngoài applyOptimistic: rollback PO thì cũng không có event nào để nạp.
    if (state.detail.hasValue) await loadHistory();
  }
}