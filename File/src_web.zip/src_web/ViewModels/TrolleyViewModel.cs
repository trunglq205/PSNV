﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Layout;

namespace SWMS_WebTool.ViewModels
{
    public class TrolleyViewModel : TableViewModel<Trolley, TrolleyFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, TrolleyFilter? filter = null)
        {
            return new
            {
                Name = filter?.Name ?? Filter.Name,
                Code = filter?.Code ?? Filter.Code,
                Category = filter?.Category ?? Filter.Category,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
