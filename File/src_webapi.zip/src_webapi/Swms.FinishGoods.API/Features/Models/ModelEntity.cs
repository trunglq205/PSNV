namespace Swms.FinishGoods.Api.Features.Models;

/// <summary>
/// Domain entity map bảng master.models. Không lộ ra ngoài — chỉ trả ModelResponse.
/// CategoryCode/CategoryName được JOIN từ master.categories khi đọc.
/// SuggestAreaCode/SuggestAreaName được LEFT JOIN từ master.warehouse_areas khi đọc.
/// </summary>
public class ModelEntity
{
    public int Id { get; set; }
    public string? GTIN { get; set; }
    public string Code { get; set; } = "";

    /// <summary>
    /// Mã xuất xứ 2 ký tự (cột origin CHAR(2)) — vd "VN", "JP". NULL = chưa khai báo.
    /// Service đã chuẩn hoá Trim + viết HOA trước khi ghi (xem OriginRule.Normalize).
    /// </summary>
    public string? Origin { get; set; }

    public int CategoryId { get; set; }
    public int CategoryCode { get; set; }   // join-only
    public string CategoryName { get; set; } = "";   // join-only
    public int Length { get; set; }                  // mm — kich thuoc carton
    public int Width { get; set; }                   // mm
    public int Height { get; set; }                  // mm
    public int StandardPacking { get; set; }         // set / box

    // ── Quy cach xep pallet. NULL = chua cau hinh (model cu). ──
    public int? LayerLimit { get; set; }             // so tang toi da duoc chong
    public int? LayerCount { get; set; }             // No of layer: so tang thuc te
    public int? StackingLength { get; set; }         // so thung theo Length carton
    public int? StackingWidth { get; set; }          // so thung theo Width carton

    /// <summary>FK -> master.warehouse_areas(id). NULL = chưa cấu hình khu vực gợi ý.</summary>
    public int? SuggestAreaId { get; set; }
    public string? SuggestAreaCode { get; set; }   // join-only
    public string? SuggestAreaName { get; set; }   // join-only

    /// <summary>
    /// Danh sách tầng rack được phép lưu, LƯU NGUYÊN DẠNG CỘT DB: chuỗi ngăn cách
    /// bởi dấu phẩy — vd "2,3" = tầng 2 và tầng 3 (rack có 4 tầng).
    /// Service đã chuẩn hoá trước khi ghi: distinct + sắp tăng dần, mỗi giá trị trong [1..4].
    /// Ra ngoài API thì quy đổi sang List&lt;int&gt; (xem RackRowRule.Parse / ToStorage).
    /// </summary>
    public string? SuggestRackRow { get; set; }

    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>
/// Bản vá cho import upsert khi mã model đã tồn tại: chỉ field KHÁC NULL mới được ghi xuống DB,
/// field null giữ nguyên giá trị hiện có (COALESCE trong ModelRepository.UpsertManyAsync).
/// Vì vậy bản vá không dùng để xoá trắng 1 cột được.
/// </summary>
public class ModelImportPatch
{
    public int Id { get; set; }
    public string? GTIN { get; set; }
    public string? Origin { get; set; }
    public int? CategoryId { get; set; }
    public int? Length { get; set; }
    public int? Width { get; set; }
    public int? Height { get; set; }
    public int? StandardPacking { get; set; }
    public int? LayerLimit { get; set; }
    public int? LayerCount { get; set; }
    public int? StackingLength { get; set; }
    public int? StackingWidth { get; set; }
    public int? SuggestAreaId { get; set; }

    /// <summary>Dạng lưu DB, vd "2,3" (đã qua NormalizeRackRow).</summary>
    public string? SuggestRackRow { get; set; }

    public bool? IsActive { get; set; }
    public string? UpdatedBy { get; set; }

    /// <summary>Không có field nào để ghi -> bỏ qua, không UPDATE (tránh đổi updated_at vô cớ).</summary>
    public bool IsEmpty =>
        GTIN is null && Origin is null && CategoryId is null
        && Length is null && Width is null && Height is null && StandardPacking is null
        && LayerLimit is null && LayerCount is null && StackingLength is null && StackingWidth is null
        && SuggestAreaId is null && SuggestRackRow is null && IsActive is null;
}

/// <summary>Row option category cho dropdown FE.</summary>
public class CategoryOption
{
    public int Id { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
}