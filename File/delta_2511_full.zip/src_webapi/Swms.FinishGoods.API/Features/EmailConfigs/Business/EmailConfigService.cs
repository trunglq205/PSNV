using System.Text.RegularExpressions;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.EmailConfigs.Api;
using Swms.FinishGoods.API.Features.EmailConfigs.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.EmailConfigs.Business;

public interface IEmailConfigService
{
    Task<List<EmailEventResponse>> GetEventsAsync(string? module);
    Task<List<EmailSubtypeResponse>> GetSubtypesAsync(string eventCode);
    Task<EmailScopeOptionsResponse> GetScopeOptionsAsync();
    Task SaveTemplateAsync(string code, SaveTemplateRequest request);
    Task<List<EmailConfigResponse>> GetConfigsAsync(string eventCode);
    Task<EmailConfigResponse> CreateAsync(SaveEmailConfigRequest request);
    Task UpdateAsync(long id, SaveEmailConfigRequest request);
    Task DeleteAsync(long id);
    Task<List<EmailRecipientResponse>> ResolveAsync(
        string eventCode, string? department, string? subCode, string? category, string? model, string? areaCode);
}

public class EmailConfigService : IEmailConfigService
{
    private readonly IEmailConfigRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    private static readonly HashSet<string> Types = new() { "TO", "CC", "BCC" };
    /// <summary>
    /// Bộ phận hay gặp — GỢI Ý cho màn hình, KHÔNG phải danh sách đóng.
    ///
    /// Trước đây đây là whitelist và mọi giá trị ngoài sáu cái này đều bị từ
    /// chối. Chốt cứng như vậy mâu thuẫn với chính thiết kế định tuyến mail:
    /// câu tra người nhận suy danh sách bộ phận ra TỪ DỮ LIỆU
    /// (master.email_config), nên "thêm bộ phận thứ bảy" lẽ ra là việc làm
    /// trên màn Cấu hình email, không phải việc sửa code rồi build lại API.
    /// </summary>
    private static readonly string[] KnownDepts = { "FA", "OQC", "VP", "SCS", "SEC", "IT" };

    /// <summary>
    /// Vẫn chặn ký tự lạ. Bỏ kiểm hoàn toàn thì một ô gõ nhầm (" FA", "F A",
    /// "fa.") đẻ ra một bộ phận không bao giờ khớp ai, và mail im lặng không
    /// tới — đúng loại lỗi không có chỗ nào báo.
    /// </summary>
    private static readonly Regex DeptPattern =
        new(@"^[A-Z0-9][A-Z0-9_-]{0,9}$", RegexOptions.Compiled);

    public EmailConfigService(IEmailConfigRepository repo, ICurrentUser currentUser, IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    // name_key -> nhãn theo ngôn ngữ; thiếu khoá resource thì hiện description
    private string Name(string key, string? fallback)
    {
        var s = _localizer[key];
        return s.ResourceNotFound ? fallback ?? key : s.Value;
    }

    public async Task<List<EmailEventResponse>> GetEventsAsync(string? module)
        => (await _repo.GetEventsAsync(Clean(module)))
            .Select(e => new EmailEventResponse(
                e.Code, e.Module, Name(e.NameKey, e.Description), e.Description,
                e.SubjectTemplate ?? "", e.BodyTemplate ?? "", e.UpdatedAt, e.UpdatedBy))
            .ToList();

    public async Task<List<EmailSubtypeResponse>> GetSubtypesAsync(string eventCode)
        => (await _repo.GetSubtypesAsync(eventCode))
            .Select(s => new EmailSubtypeResponse(s.EventCode, s.SubCode, Name(s.NameKey, s.SubCode), s.Severity))
            .ToList();

    public async Task SaveTemplateAsync(string code, SaveTemplateRequest request)
    {
        _ = await _repo.GetEventAsync(code)
            ?? throw new NotFoundException(_localizer["Email.EventNotFound", code]);
        await _repo.SaveTemplateAsync(code, request.Subject.Trim(), request.Body, _currentUser.FullName);
    }

    public async Task<List<EmailConfigResponse>> GetConfigsAsync(string eventCode)
        => (await _repo.GetConfigsAsync(eventCode)).Select(ToResponse).ToList();

    public async Task<EmailConfigResponse> CreateAsync(SaveEmailConfigRequest request)
    {
        await ValidateAsync(request, excludeId: null);
        var id = await _repo.AddConfigAsync(request, _currentUser.FullName);
        var row = await _repo.GetConfigAsync(id)
            ?? throw new NotFoundException(_localizer["Email.ConfigNotFound", id]);
        return ToResponse(row);
    }

    public async Task UpdateAsync(long id, SaveEmailConfigRequest request)
    {
        var cur = await _repo.GetConfigAsync(id)
            ?? throw new NotFoundException(_localizer["Email.ConfigNotFound", id]);
        request.EventCode = cur.EventCode;              // không cho chuyển cấu hình sang loại mail khác
        await ValidateAsync(request, excludeId: id);
        if (!await _repo.UpdateConfigAsync(id, request, _currentUser.FullName))
            throw new NotFoundException(_localizer["Email.ConfigNotFound", id]);
    }

    public async Task DeleteAsync(long id)
    {
        if (!await _repo.SoftDeleteConfigAsync(id, _currentUser.FullName))
            throw new NotFoundException(_localizer["Email.ConfigNotFound", id]);
    }

    /// <summary>
    /// Gợi ý cho ô Bộ phận và ô Danh mục. Gộp bộ hay gặp với bộ đang thật sự
    /// được khai, để màn hình vừa có sẵn cái quen thuộc vừa không giấu đi cái
    /// người ta đã tự thêm.
    /// </summary>
    public async Task<EmailScopeOptionsResponse> GetScopeOptionsAsync()
    {
        var used = await _repo.GetUsedDepartmentsAsync();
        var depts = KnownDepts
            .Concat(used.Select(d => d.Trim().ToUpperInvariant()))
            .Where(d => d.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(d => d, StringComparer.OrdinalIgnoreCase)
            .ToList();

        return new EmailScopeOptionsResponse(depts, await _repo.GetCategoryOptionsAsync());
    }

    public Task<List<EmailRecipientResponse>> ResolveAsync(
        string eventCode, string? department, string? subCode, string? category, string? model, string? areaCode)
        => _repo.ResolveAsync(eventCode, Clean(department), Clean(subCode), Clean(category), Clean(model), Clean(areaCode));

    // ── helpers ─────────────────────────────────────────────

    private async Task ValidateAsync(SaveEmailConfigRequest r, long? excludeId)
    {
        r.EventCode = r.EventCode.Trim();
        r.RecipientType = r.RecipientType.Trim().ToUpperInvariant();
        r.Department = Clean(r.Department)?.ToUpperInvariant();
        r.SubCode = Clean(r.SubCode);
        r.Category = Clean(r.Category);
        r.Model = Clean(r.Model);
        r.AreaCode = Clean(r.AreaCode);
        r.Email = Clean(r.Email);
        r.DisplayName = Clean(r.DisplayName);

        _ = await _repo.GetEventAsync(r.EventCode)
            ?? throw new NotFoundException(_localizer["Email.EventNotFound", r.EventCode]);
        if (!Types.Contains(r.RecipientType))
            throw new BusinessRuleException(_localizer["Email.TypeInvalid", r.RecipientType]);
        if (r.Department is not null && !DeptPattern.IsMatch(r.Department))
            throw new BusinessRuleException(_localizer["Email.DepartmentInvalid", r.Department]);

        // Khớp CK_email_config_target: đúng 1 trong 2
        if (r.UserId is null && r.Email is null)
            throw new BusinessRuleException(_localizer["Email.TargetRequired"]);
        if (r.UserId is { } uid && !await _repo.UserExistsAsync(uid))
            throw new NotFoundException(_localizer["Email.UserNotFound", uid]);

        // Khớp FK 2 cột (event_code, sub_code)
        if (r.SubCode is not null
            && (await _repo.GetSubtypesAsync(r.EventCode)).All(s => s.SubCode != r.SubCode))
            throw new BusinessRuleException(_localizer["Email.SubCodeInvalid", r.SubCode, r.EventCode]);

        if (await _repo.ScopeExistsAsync(r, excludeId))
            throw new ConflictException(_localizer["Email.ConfigDuplicate"]);
    }

    private static EmailConfigResponse ToResponse(EmailConfigRow c) => new(
        c.Id, c.EventCode, c.Department, c.SubCode, c.Category, c.Model, c.AreaCode,
        c.RecipientType, c.UserId, c.Email ?? "", c.DisplayName, c.IsActive);

    private static string? Clean(string? v) => string.IsNullOrWhiteSpace(v) ? null : v.Trim();
}
