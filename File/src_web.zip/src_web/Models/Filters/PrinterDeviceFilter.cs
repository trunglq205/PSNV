﻿namespace SWMS_WebTool.Models.Filters
{
    public class PrinterDeviceFilter : BaseFilter
    {
        public string? ID { get; set; }
        public string? MacAddress { get; set; }
    }
}
