﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.JSInterop;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.AbnormalReports.Business;
using Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.Auth;

namespace Swms.FinishGoods.Web.Features.AbnormalReports.App.Pages;

public partial class AbnormalReport : ComponentBase
{
    [Inject] private INgReportBusiness Business { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;

    /// <summary>
    /// Quyền của user đang đăng nhập. Mỗi bước duyệt là MỘT quyền riêng, nên nút
    /// chỉ hiện khi hội đủ hai điều: phiếu đang đúng bước, VÀ user có quyền bước đó.
    /// API vẫn chặn độc lập bằng [RequirePermission] — gate ở đây chỉ để user không
    /// bấm vào nút rồi mới ăn 403.
    /// </summary>
    [Inject] private PermissionState Perm { get; set; } = default!;

    /// <summary>Để đọc query string của link mở từ mail.</summary>
    [Inject] private NavigationManager Nav { get; set; } = default!;

    /// <summary>Chỉ dùng để đẩy file Excel đã tải về xuống máy người dùng.</summary>
    [Inject] private IJSRuntime JS { get; set; } = default!;

    /// <summary>
    /// Loại lỗi nạp từ API (master.ng_types) thay vì khai cứng — thêm một loại
    /// lỗi chỉ là một dòng trong DB, không phải build lại Web.
    /// </summary>
    private List<NgTypeDto> _types = new();

    /// <summary>
    /// Nhãn của một mã loại lỗi. Không tra ra thì hiện chính cái mã: phiếu cũ
    /// mang loại lỗi đã ngưng dùng vẫn phải đọc được, và ô trống thì người xem
    /// không biết là lỗi gì hay là chưa tải xong.
    /// </summary>
    private string TypeName(string? code)
        => _types.FirstOrDefault(t => t.Code == code)?.Name ?? code ?? "";
    private static readonly string[] Resolutions = { "replace", "accept", "return", "scrap" };

    /// <summary>
    /// Thứ tự hiện trong ô xem trước mail. Có cả BCC: người duyệt chính là
    /// người gửi nên không có gì phải giấu họ, và bỏ BCC ra thì cấu hình chỉ
    /// khai mỗi BCC sẽ hiện một ô trống trơn, trông y như chưa khai ai.
    /// </summary>
    private static readonly string[] MailTypes = { "TO", "CC", "BCC" };

    private static readonly (string Key, string Label)[] Tabs =
    {
        ("", "Ng.Tab.All"),
        ("draft", "Ng.Tab.Draft"),
        ("in_review", "Ng.Tab.InReview"),
        ("ready_to_finalize", "Ng.Tab.Ready"),
        ("finalized", "Ng.Tab.Finalized"),
        ("cancelled", "Ng.Tab.Cancelled"),
    };

    private List<NgReportSummaryDto> _rows = new();
    private List<NgReportSummaryDto> _all = new();
    private NgReportDetailDto? _detail;


    private string _status = "";
    private string _ngType = "";
    private string _faRes = "";       // pending | replace | accept | return | scrap
    private string _oqc = "";         // pending | ok | ng
    private string _finalRes = "";
    private string? _keyword;
    private DateTime? _from;
    private DateTime? _to;

    private string? _comment;
    private string _resolution = "";
    private string? _actionError;
    /// <summary>Lỗi khi tải danh sách — tách khỏi trường hợp danh sách rỗng thật.</summary>
    private string? _loadError;
    private bool _busy;

    /// <summary>Đang tải file Excel. Tách khỏi <c>_busy</c> để nút xuất đổi chữ
    /// mà danh sách không bị thay bằng dòng "Đang tải…".</summary>
    private bool _exporting;
    private string? _exportError;

    /// <summary>
    /// Mở màn hình từ link trong mail:
    /// <c>/abnormal-report?docNo=NG-20261012-014</c>.
    ///
    /// Điền số phiếu vào ô tìm kiếm rồi tìm luôn, chứ KHÔNG mở thẳng hộp chi
    /// tiết. Hai cái lợi: người dùng nhìn thấy ngay vì sao danh sách chỉ còn
    /// một dòng, và thao tác tiếp theo vẫn là bấm vào dòng đó như mọi khi.
    ///
    /// Số phiếu sai hoặc không truyền thì ô tìm kiếm trống và hiện danh sách
    /// như thường — link hỏng không được phép làm vỡ màn hình.
    ///
    /// Đọc thẳng từ URL bằng NavigationManager, KHÔNG dùng
    /// [SupplyParameterFromQuery]: đây là cách ListPageBase của chính dự án
    /// này đang dùng cho mọi màn danh sách, và nó không phụ thuộc vào việc
    /// tham số có được gán kịp trước OnInitialized hay không — thứ đổi theo
    /// render mode của trang.
    /// </summary>
    private void ReadDocNoFromUrl()
    {
        var qs = QueryHelpers.ParseQuery(Nav.ToAbsoluteUri(Nav.Uri).Query);
        if (!qs.TryGetValue("docNo", out var raw)) return;

        var v = raw.ToString().Trim();
        if (v.Length > 0) _keyword = v;
    }

    protected override async Task OnInitializedAsync()
    {
        ReadDocNoFromUrl();

        // Nạp danh mục TRƯỚC danh sách phiếu: danh sách hiện nhãn loại lỗi
        // ngay ở dòng đầu, nạp sau thì người dùng thấy mã thô nhấp nháy một
        // nhịp rồi mới đổi thành tên.
        var t = await Business.GetTypesAsync();
        if (t.IsSuccess && t.Value is not null) _types = t.Value;

        await Reload();
    }

    private async Task Reload()
    {
        _busy = true;
        // Tải không lọc trạng thái để đếm được số trên từng tab, rồi lọc tại chỗ.
        var r = await Business.GetListAsync(null, string.IsNullOrEmpty(_ngType) ? null : _ngType,
            _from, _to, _keyword);
        _loadError = r.IsSuccess ? null : (r.ErrorMessage ?? L["Ng.Err.LoadFailed"]);
        _all = r.IsSuccess && r.Value is not null ? r.Value : new List<NgReportSummaryDto>();
        ApplyStatus();
        _busy = false;
    }

    /// <summary>
    /// Lọc tại chỗ trên dữ liệu đã tải: trạng thái, FA, OQC, hướng xử lý, xung đột.
    /// Chỉ loại lỗi, khoảng ngày và từ khoá mới phải gọi lại server.
    /// </summary>
    private void ApplyStatus()
    {
        IEnumerable<NgReportSummaryDto> q = _all;

        if (!string.IsNullOrEmpty(_status)) q = q.Where(x => x.DocStatus == _status);

        if (!string.IsNullOrEmpty(_faRes))
            q = _faRes == "pending"
                ? q.Where(x => x.FaStatus != "approved")
                : q.Where(x => x.FaResolution == _faRes);

        if (!string.IsNullOrEmpty(_oqc)) q = q.Where(x => x.OqcStatus == _oqc);

        if (!string.IsNullOrEmpty(_finalRes)) q = q.Where(x => x.Resolution == _finalRes);

        _rows = q.ToList();

        // Kẹp trang thay vì về trang 1: sau khi duyệt / sửa phiếu, Reload chạy lại
        // và người dùng phải ở nguyên trang đang xem. Chỉ đổi BỘ LỌC mới về trang 1
        // (xem ApplyLocal / ReloadFromFilter).
        if (_page > TotalPages) _page = TotalPages;
    }

    /// <summary>Đổi bộ lọc tại chỗ (FA / OQC / hướng xử lý) → về trang 1.</summary>
    private void ApplyLocal()
    {
        _page = 1;
        ApplyStatus();
    }

    /// <summary>Đổi bộ lọc phải gọi server (loại lỗi / khoảng ngày) → về trang 1.</summary>
    private async Task ReloadFromFilter()
    {
        _page = 1;
        await Reload();
    }

    // ----- Phân trang (phía client: Reload đã tải đủ danh sách để đếm số trên tab) -----

    private static readonly int[] PageSizeOptions = { 20, 50, 100 };
    private int _page = 1;
    private int _pageSize = 20;

    private int TotalPages => Math.Max(1, (int)Math.Ceiling(_rows.Count / (double)_pageSize));

    /// <summary>Các dòng của trang đang xem.</summary>
    private IEnumerable<NgReportSummaryDto> PagedRows
        => _rows.Skip((_page - 1) * _pageSize).Take(_pageSize);

    /// <summary>"21–40 / 135". Danh sách rỗng thì "0 / 0".</summary>
    private string PagerInfo
    {
        get
        {
            if (_rows.Count == 0) return "0 / 0";
            var from = (_page - 1) * _pageSize + 1;
            var to = Math.Min(_page * _pageSize, _rows.Count);
            return $"{from:N0}–{to:N0} / {_rows.Count:N0}";
        }
    }

    /// <summary>
    /// Số trang để hiện: luôn có trang đầu, trang cuối và 2 trang quanh trang
    /// đang xem; chỗ nhảy cóc là 0 (vẽ thành "…").
    /// </summary>
    private List<int> PageNumbers()
    {
        var list = new List<int>();
        var last = TotalPages;
        for (var p = 1; p <= last; p++)
        {
            if (p == 1 || p == last || Math.Abs(p - _page) <= 2) list.Add(p);
            else if (list.Count > 0 && list[^1] != 0) list.Add(0);
        }
        return list;
    }

    private void GoPage(int p) => _page = Math.Clamp(p, 1, TotalPages);

    private void OnPageSizeChanged(ChangeEventArgs e)
    {
        if (!int.TryParse(e.Value?.ToString(), out var size) || size <= 0) return;
        _pageSize = size;
        _page = 1;
    }

    /// <summary>Số trên tab tính theo các bộ lọc khác, trừ chính trạng thái của tab.</summary>
    private int CountOf(string key)
    {
        IEnumerable<NgReportSummaryDto> q = _all;
        if (!string.IsNullOrEmpty(_faRes))
            q = _faRes == "pending"
                ? q.Where(x => x.FaStatus != "approved")
                : q.Where(x => x.FaResolution == _faRes);
        if (!string.IsNullOrEmpty(_oqc)) q = q.Where(x => x.OqcStatus == _oqc);
        if (!string.IsNullOrEmpty(_finalRes)) q = q.Where(x => x.Resolution == _finalRes);

        return string.IsNullOrEmpty(key) ? q.Count() : q.Count(x => x.DocStatus == key);
    }

    private void SetStatus(string key)
    {
        _status = key;
        _page = 1;
        ApplyStatus();
    }

    private bool HasAnyFilter =>
        !string.IsNullOrEmpty(_ngType) || !string.IsNullOrEmpty(_faRes)
        || !string.IsNullOrEmpty(_oqc) || !string.IsNullOrEmpty(_finalRes)
        || _from is not null || _to is not null
        || !string.IsNullOrWhiteSpace(_keyword);

    // ----- Xoá từng chip bộ lọc -----
    // Loại lỗi và khoảng ngày đi server nên phải Reload; FA / OQC / hướng xử lý
    // lọc tại chỗ nên chỉ ApplyLocal — giống hệt cách các ô select đang làm.

    private async Task ClearNgType() { _ngType = ""; await ReloadFromFilter(); }
    private async Task ClearDates() { _from = _to = null; await ReloadFromFilter(); }
    private void ClearOqc() { _oqc = ""; ApplyLocal(); }
    private void ClearFa() { _faRes = ""; ApplyLocal(); }
    private void ClearFinalRes() { _finalRes = ""; ApplyLocal(); }

    /// <summary>Nhãn chip FA / hướng xử lý: "pending" là Chờ, còn lại là tên hướng xử lý.</summary>
    private string ResLabel(string key)
        => key == "pending" ? L["Ng.Waiting"].Value : L[$"Ng.Res.{key}"].Value;

    private string OqcLabel(string key) => key switch
    {
        "ok" => "OK",
        "ng" => "NG",
        _ => L["Ng.Waiting"].Value,
    };

    /// <summary>Cùng định dạng chip ngày với màn Tồn kho.</summary>
    private static string DateChip(DateTime? f, DateTime? t)
        => f?.Date == t?.Date ? $"{f:dd/MM/yyyy}"
         : $"{f?.ToString("dd/MM/yyyy") ?? "…"} – {t?.ToString("dd/MM/yyyy") ?? "…"}";

    private async Task ClearFilters()
    {
        _ngType = _faRes = _oqc = _finalRes = "";
        _keyword = null;
        _from = _to = null;
        _page = 1;
        await Reload();
    }

    /// <summary>
    /// Xuất Excel danh sách phiếu. Truyền ĐỦ CẢ 8 bộ lọc hiện hành — kể cả 3
    /// cái màn hình đang lọc tại chỗ (FA / OQC / hướng xử lý) — để file tải về
    /// đúng bằng những dòng đang thấy trên màn hình.
    ///
    /// Trạng thái truyền <c>_status</c> của tab đang mở, dù <see cref="Reload"/>
    /// cố tình gọi API không lọc trạng thái (để đếm số trên từng tab). Hai việc
    /// khác nhau: đếm thì cần cả rổ, xuất thì chỉ cần tab đang xem.
    /// </summary>
    private async Task ExportExcel()
    {
        if (_exporting) return;
        _exporting = true;
        _exportError = null;
        StateHasChanged();

        var r = await Business.DownloadListReportAsync(
            string.IsNullOrEmpty(_status) ? null : _status,
            string.IsNullOrEmpty(_ngType) ? null : _ngType,
            _from, _to, _keyword,
            string.IsNullOrEmpty(_faRes) ? null : _faRes,
            string.IsNullOrEmpty(_oqc) ? null : _oqc,
            string.IsNullOrEmpty(_finalRes) ? null : _finalRes);

        if (r.IsSuccess && r.Value is not null)
        {
            await JS.InvokeVoidAsync("swmsSaveFile", r.Value.FileName,
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                Convert.ToBase64String(r.Value.Bytes));
        }
        else
        {
            _exportError = r.ErrorMessage ?? L["Ng.Rep.Failed"];
        }

        _exporting = false;
        StateHasChanged();
    }

    private async Task OnKeyword(string? value)
    {
        _keyword = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        _page = 1;
        await Reload();
    }

    private async Task Open(long id)
    {
        _actionError = null;
        _comment = null;
        _resolution = "";

        var r = await Business.GetAsync(id);
        if (!r.IsSuccess || r.Value is null) return;
        _detail = r.Value;
        StateHasChanged();
    }

    /// <summary>Danh sách id ảnh truyền cho component chung.</summary>
    private List<long> _photoIds => _detail?.Photos.Select(p => p.Id).ToList() ?? new List<long>();

    /// <summary>Nút xoá ảnh chỉ gắn khi phiếu còn nháp.</summary>
    private EventCallback<long> _removePhotoCallback =>
        _detail?.Header.DocStatus == "draft"
            ? EventCallback.Factory.Create<long>(this, RemovePhoto)
            : default;

    /// <summary>Hàm tải ảnh cho component chung: trả data-uri theo kích thước yêu cầu.</summary>
    private async Task<string?> LoadPhoto(long photoId, string size)
    {
        var r = await Business.GetPhotoDataUriAsync(photoId, size);
        if (r.IsSuccess) return r.Value;

        // Ném ra để PhotoGallery hiện được lý do. Nuốt lỗi ở đây là cách nhanh
        // nhất để ảnh "mất tích" mà không ai biết vì sao.
        throw new InvalidOperationException(
            $"#{photoId} {size}: {r.ErrorCode} {r.ErrorMessage}".Trim());
    }

    // ----- Sửa phiếu nháp -----
    private bool _editing;
    // Không đặt mặc định bằng một mã cụ thể: StartEdit() luôn gán từ phiếu
    // đang mở trước khi form hiện ra, mà một mã cứng ở đây sẽ thành sai ngay
    // khi ai đó ngưng dùng loại lỗi đó trong master.ng_types.
    private string _editType = "";
    private string? _editDesc;
    private List<NgItemInputDto> _editItems = new();

    /// <summary>Mở phiếu rồi vào thẳng chế độ sửa (nút Sửa ngoài danh sách).</summary>
    private async Task OpenEdit(long id)
    {
        await Open(id);
        if (_detail?.Header.DocStatus == "draft") StartEdit();
    }

    private void StartEdit()
    {
        if (_detail is null) return;
        _editing = true;
        _editType = _detail.Header.NgType;
        _editDesc = _detail.Description;
        _editItems = _detail.Items
            .Select(i => new NgItemInputDto
            {
                Scope = i.Scope,
                Code = i.Code,
                QtyAffected = i.QtyAffected,
                Note = i.Note
            })
            .ToList();
    }

    private void CancelEdit()
    {
        _editing = false;
        _editItems.Clear();
    }

    private void AddEditItem() => _editItems.Add(new NgItemInputDto { Scope = "serial", QtyAffected = 1 });

    private async Task SaveEdit()
    {
        if (_detail is null) return;
        if (_editItems.Count == 0)
        {
            _actionError = L["Ng.Err.NeedItem"];
            return;
        }

        var r = await Business.UpdateAsync(_detail.Header.Id, new UpdateNgReportRequestDto
        {
            NgType = _editType,
            Description = _editDesc,
            Items = _editItems
        });

        if (!r.IsSuccess)
        {
            _actionError = r.ErrorMessage ?? L["Ng.Err.ActionFailed"];
            return;
        }

        _editing = false;
        var id = _detail.Header.Id;
        await Reload();
        await Open(id);
    }

    /// <summary>Xoá 1 ảnh của phiếu nháp.</summary>
    private async Task RemovePhoto(long photoId)
    {
        if (_detail is null) return;
        var r = await Business.DeletePhotoAsync(photoId);
        if (!r.IsSuccess)
        {
            _actionError = r.ErrorMessage ?? L["Ng.Err.ActionFailed"];
            return;
        }

        await Open(_detail.Header.Id);
    }

    private void Close()
    {
        _editing = false;
        _detail = null;
    }



    // ----- Quyền thuần, không xét trạng thái phiếu -----
    // Tách riêng vì danh sách cần kiểm quyền khi CHƯA tải chi tiết phiếu nào.
    // Khai ở một chỗ để mọi nơi trong trang dùng cùng một định nghĩa.

    private bool MayCreate => Perm.Has(Perms.abnormal_report_create.Key());
    private bool MayLeaderReview => Perm.Has(Perms.abnormal_report_leader_review.Key());
    private bool MayOqcConfirm => Perm.Has(Perms.abnormal_report_oqc_confirm.Key());
    private bool MayFaConfirm => Perm.Has(Perms.abnormal_report_fa_confirm.Key());
    // Lá quyền abnormal_report.finalize không còn gác gì sau khi bỏ bước
    // Supervisor chốt (23/11). Lá vẫn khai trong Perms — xoá rồi khai lại
    // đúng tên cũ sẽ làm sống lại quyền của mọi role từng được gán.

    /// <summary>
    /// Quyền sửa cấu hình email. Đây là quyền DÙNG CHUNG cho mọi module
    /// (email_config.update), không phải quyền riêng của Hàng bất thường — ai
    /// sửa được mail của màn khác thì cũng sửa được ở đây.
    /// </summary>
    private bool MayEmailConfig => Perm.Has(Perms.email_config_update.Key());

    /// <summary>
    /// Quyền sửa danh mục loại lỗi. Tách khỏi 5 quyền duyệt: đổi cờ requires_oqc
    /// là đổi luồng duyệt của mọi phiếu lập sau đó.
    /// </summary>
    private bool MayManageTypes => Perm.Has(Perms.abnormal_report_manage_types.Key());

    /// <summary>
    /// Mã sự kiện mail của màn này, khớp hằng MailEventAbnormal bên
    /// NgReportService. Để ở một chỗ để sau này đổi thì chỉ sửa một nơi.
    /// </summary>
    private const string MailEventCode = "RECEIVING_ABNORMAL";

    /// <summary>Hộp cấu hình (bánh răng) đang mở hay không.</summary>
    private bool _cfgOpen;

    /// <summary>Có quyền ở ít nhất một trong hai bước giữa — dùng cho nút mở phiếu.</summary>
    private bool MayConfirmAnyStep => MayOqcConfirm || MayFaConfirm;

    // ----- Điều kiện hiện nút theo bước: TRẠNG THÁI PHIẾU && QUYỀN CỦA USER -----

    /// <summary>Phiếu còn nháp — mốc chung cho cả sửa (SCS) và duyệt/huỷ (Leader).</summary>
    private bool IsDraft => _detail?.Header.DocStatus == "draft";

    /// <summary>
    /// SCS sửa lại phiếu nháp của mình: quyền TẠO phiếu, không phải quyền duyệt.
    /// Tách khỏi CanLeaderReview để người tạo không cần quyền Leader mới sửa được.
    /// </summary>
    private bool CanEditDraft => IsDraft && MayCreate;

    /// <summary>
    /// Bước 2 — Leader SCS duyệt hoặc huỷ. Huỷ dùng chung endpoint leader-review
    /// nên cũng nằm trong quyền này: SCS không tự huỷ phiếu mình tạo.
    /// </summary>
    private bool CanLeaderReview => IsDraft && MayLeaderReview;

    /// <summary>Leader đã duyệt và phiếu chưa chốt/huỷ.</summary>
    private bool CanConfirm =>
        _detail is not null
        && _detail.Header.LeaderStatus == "submitted"
        && _detail.Header.DocStatus is "in_review" or "submitted";

    /// <summary>Bước 3 — OQC là người kết luận đầu tiên trong cặp OQC-FA.</summary>
    private bool CanOqcConfirm => CanConfirm
                                  && _detail!.Header.OqcStatus == "pending"
                                  && MayOqcConfirm;

    /// <summary>
    /// Bước 4 — FA kết luận OK/NG. Phải đợi OQC xong ('skipped' cũng là xong).
    /// Không hiện khi phiếu đang ở bước FA xử lý: lúc đó đường đi là nút "đã
    /// xử lý xong", không phải đánh giá lại từ đầu.
    /// </summary>
    private bool CanFaConfirm => CanConfirm
                                 && _detail!.Header.OqcStatus != "pending"
                                 && _detail.Header.CurrentStep != "fa_fix"
                                 && _detail.Header.FaResult != "ok"
                                 && MayFaConfirm;

    /// <summary>
    /// Bước 4b — FA đã xử lý xong lượt NG của mình. Xác nhận xong thì hàng
    /// quay lại OQC đánh giá lại; loại lỗi không qua OQC thì phiếu đóng luôn.
    /// </summary>
    private bool CanFaFixDone => CanConfirm
                                 && _detail!.Header.CurrentStep == "fa_fix"
                                 && MayFaConfirm;

    // ----- Thao tác: mọi thay đổi trạng thái đều đi qua hộp xác nhận -----

    /// <summary>Loại thao tác đang chờ xác nhận; null = không có.</summary>
    private string? _confirm;
    private long _confirmId;
    private bool _acting;

    /// <summary>FA và chốt cuối phải chọn hướng xử lý.</summary>
    /// <summary>Chỉ nhánh FA kết luận NG mới phải chọn hướng xử lý.</summary>
    private bool ConfirmNeedsResolution => _confirm is "fa-ng";

    /// <summary>Huỷ phiếu và OQC báo không đạt thì bắt buộc ghi lý do.</summary>
    private bool ConfirmNeedsComment => _confirm is "leader-cancel" or "oqc-ng" or "fa-ng";

    /// <summary>
    /// Tông màu hộp xác nhận (.confirm-ic + nút OK): huỷ phiếu và OQC NG là
    /// danger, chốt là warning vì không quay lại được, còn lại info.
    /// </summary>
    private string ConfirmTone() => _confirm switch
    {
        "leader-cancel" or "oqc-ng" or "fa-ng" => "danger",
        "fa-fix" => "warning",
        _ => "info",
    };

    /// <summary>
    /// Duyệt xong sẽ gửi mail cho ai. Chỉ có giá trị ở bước 2 — các bước khác
    /// chưa gửi mail nên để null.
    /// </summary>
    private MailPreviewDto? _mailPreview;
    private bool _mailPreviewLoading;

    /// <summary>
    /// Mỗi dòng cấu hình một dòng hiển thị: "Tên (địa chỉ 1, địa chỉ 2, …)".
    ///
    /// Phải gom lại vì tầng dưới đã TÁCH ô email gộp thành từng địa chỉ riêng
    /// để gửi và khử trùng; không gom thì tên nhóm lặp đúng bằng số người
    /// trong nhóm. Gom theo tên hiển thị — hai dòng cấu hình trùng tên thì coi
    /// là một nhóm, đúng hơn là tách làm hai dòng giống hệt nhau.
    ///
    /// Vẫn kèm địa chỉ chứ không chỉ tên: tên là chữ người ta tự gõ vào cấu
    /// hình, nên gõ nhầm địa chỉ thì nhìn tên không bao giờ phát hiện ra.
    /// Không có tên thì hiện mỗi địa chỉ, khỏi ra cặp ngoặc trống.
    /// </summary>
    private static List<string> MailGroups(IEnumerable<MailPreviewRecipientDto> people)
        => people
            .GroupBy(p => (p.DisplayName ?? string.Empty).Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g =>
            {
                var addrs = string.Join(", ", g.Select(p => p.Email));
                return string.IsNullOrEmpty(g.Key) ? addrs : $"{g.Key} ({addrs})";
            })
            .ToList();

    /// <summary>Mở hộp xác nhận cho phiếu đang xem.</summary>
    private Task Ask(string kind)
        => _detail is null ? Task.CompletedTask : Ask(_detail.Header.Id, kind);

    /// <summary>Mở hộp xác nhận từ nút ngoài danh sách (chưa mở chi tiết).</summary>
    private Task AskFromList(long id, string kind) => Ask(id, kind);

    private async Task Ask(long id, string kind)
    {
        _confirmId = id;
        _confirm = kind;
        _comment = null;
        _resolution = "";
        _actionError = null;
        _mailPreview = null;

        // Chỉ bước 2 gửi mail, các bước khác khỏi gọi.
        if (kind != "leader-submit") return;

        // Hộp xác nhận hiện NGAY, phần người nhận điền vào sau. Chờ xong mới mở
        // hộp thì mỗi lần bấm Duyệt lại khựng một nhịp không rõ vì sao.
        _mailPreviewLoading = true;
        StateHasChanged();
        try
        {
            var r = await Business.GetMailPreviewAsync(id);
            _mailPreview = r.IsSuccess ? r.Value : null;
        }
        finally
        {
            _mailPreviewLoading = false;
        }
    }

    private void CancelConfirm()
    {
        _confirm = null;
        _actionError = null;
        _mailPreview = null;
    }

    private string ConfirmTitle() => _confirm switch
    {
        "leader-submit" => L["Ng.Submit"],
        "leader-cancel" => L["Ng.Cancel"],
        "fa-ok" => L["Ng.FaOk"],
        "fa-ng" => L["Ng.FaNg"],
        "fa-fix" => L["Ng.FaFixDone"],
        "oqc-ok" => L["Ng.OqcOk"],
        _ => L["Ng.OqcNg"]
    };

    private string ConfirmMessage() => _confirm switch
    {
        "leader-submit" => L["Ng.Ask.LeaderSubmit"],
        "leader-cancel" => L["Ng.Ask.LeaderCancel"],
        "fa-ok" => L["Ng.Ask.FaOk"],
        "fa-ng" => L["Ng.Ask.FaNg"],
        "fa-fix" => L["Ng.Ask.FaFixDone"],
        "oqc-ok" => L["Ng.Ask.OqcOk"],
        _ => L["Ng.Ask.OqcNg"]
    };

    /// <summary>Chạy thao tác đã xác nhận.</summary>
    private async Task RunConfirm()
    {
        if (_confirm is null || _acting) return;

        if (ConfirmNeedsComment && string.IsNullOrWhiteSpace(_comment))
        {
            _actionError = L["Ng.Err.NeedReason"];
            return;
        }

        if (ConfirmNeedsResolution && string.IsNullOrEmpty(_resolution))
        {
            _actionError = L["Ng.Err.NeedResolution"];
            return;
        }

        _acting = true;
        var id = _confirmId;

        var result = _confirm switch
        {
            "leader-submit" => await Business.LeaderReviewAsync(id,
                new LeaderReviewRequestDto { Action = "submit", Comment = _comment }),
            "leader-cancel" => await Business.LeaderReviewAsync(id,
                new LeaderReviewRequestDto { Action = "cancel", Comment = _comment }),
            "fa-ok" => await Business.FaConfirmAsync(id,
                new FaConfirmRequestDto { Result = "ok", Comment = _comment }),
            "fa-ng" => await Business.FaConfirmAsync(id,
                new FaConfirmRequestDto { Result = "ng", Resolution = _resolution, Comment = _comment }),
            "fa-fix" => await Business.FaFixDoneAsync(id,
                new FaFixDoneRequestDto { Comment = _comment }),
            "oqc-ok" => await Business.OqcConfirmAsync(id,
                new OqcConfirmRequestDto { Result = "ok", Comment = _comment }),
            _ => await Business.OqcConfirmAsync(id,
                new OqcConfirmRequestDto { Result = "ng", Comment = _comment })
        };

        _acting = false;

        if (!result.IsSuccess)
        {
            _actionError = result.ErrorMessage ?? L["Ng.Err.ActionFailed"];
            return;
        }

        _confirm = null;
        _comment = null;
        _resolution = "";
        _actionError = null;
        _mailPreview = null;

        await Reload();
        if (_detail is not null) await Open(id);
    }

    // ----- Nhãn & màu — theo .pill / .lot-chip của swms-components.css -----
    // Nhãn loại lỗi đến từ DB chứ không từ resx, mà MarkupString là HTML thô —
    // phải mã hoá, nếu không một cái tên có ký tự '<' là vỡ trang. Mã hoá luôn
    // cả nhãn resx cho đồng nhất: chữ thường thì mã hoá không đổi gì.

    private static string Enc(string? s) => System.Net.WebUtility.HtmlEncode(s ?? "");

    /// <summary>Pill trạng thái chuẩn design system: <c>.pill.sm.{tone}</c> có chấm màu.</summary>
    private static MarkupString Pill(string tone, string text) =>
        new($"<span class=\"pill sm {tone}\"><span class=\"dot\"></span>{Enc(text)}</span>");

    /// <summary>
    /// Bảng màu cho chấm của loại lỗi. Loại lỗi do DB khai nên không thể gán
    /// màu cố định theo mã trong CSS như trước — chọn màu theo mã, ổn định giữa
    /// các lần chạy (KHÔNG dùng string.GetHashCode: .NET trộn ngẫu nhiên mỗi
    /// lần khởi động, cùng một loại lỗi sẽ đổi màu sau mỗi lần deploy).
    /// </summary>
    private static readonly string[] TypePalette =
    {
        "var(--info, #0F6CBD)", "var(--accent-orange, #E65100)", "var(--accent-purple, #7B1FA2)",
        "var(--accent-teal, #00838F)", "var(--warning, #B7791F)", "var(--danger, #C42B1C)",
        "var(--success, #107C10)",
    };

    private static string TypeColor(string? code)
    {
        if (string.IsNullOrEmpty(code)) return "var(--text-3)";
        var sum = 0;
        foreach (var ch in code) sum = (sum * 31 + ch) & 0x7FFFFFFF;
        return TypePalette[sum % TypePalette.Length];
    }

    /// <summary>Loại lỗi là phân loại chứ không phải trạng thái → .lot-chip trung tính + chấm màu.</summary>
    private MarkupString TypeChip(string type) =>
        new($"<span class=\"lot-chip\" title=\"{Enc(type)}\">"
            + $"<span class=\"swatch\" style=\"background:{TypeColor(type)}\"></span>"
            + $"{Enc(TypeName(type))}</span>");

    /// <summary>Hướng xử lý: thay = info · chấp nhận = success · trả về = warning · huỷ bỏ = danger.</summary>
    private static string ResolutionTone(string? resolution) => resolution switch
    {
        "accept" => "success",
        "return" => "warning",
        "scrap" => "danger",
        _ => "info",
    };

    /// <summary>
    /// Kết luận của FA. NG thì ghép luôn hướng xử lý vào cùng một chip — hai
    /// chip cạnh nhau cho một bước làm người đọc phải ghép lại trong đầu.
    /// </summary>
    private MarkupString FaChip(string? result, string? resolution) => result switch
    {
        "ok" => Pill("success", "OK"),
        "ng" => Pill("danger", resolution is null
                               ? "NG"
                               : $"NG · {L[$"Ng.Res.{resolution}"].Value}"),
        _ => Pill("dim", L["Ng.Waiting"].Value)
    };

    private MarkupString OqcChip(string status) => status switch
    {
        "ok" => Pill("success", "OK"),
        "ng" => Pill("danger", "NG"),
        // Model không cần OQC: phải nói rõ "không áp dụng", để nguyên chữ
        // "chờ" thì phiếu trông như đang treo ở một bước không ai làm.
        "skipped" => Pill("dim", L["Ng.OqcSkipped"].Value),
        _ => Pill("dim", L["Ng.Waiting"].Value)
    };

    private MarkupString ResolutionChip(string resolution) =>
        resolution == "pending"
            ? Pill("dim", L["Ng.Waiting"].Value)
            : Pill(ResolutionTone(resolution), L[$"Ng.Res.{resolution}"].Value);

    private MarkupString StatusPill(string status)
    {
        var tone = status switch
        {
            "draft" => "dim",
            "submitted" or "in_review" => "warning",
            "ready_to_finalize" => "warning",
            "finalized" => "success",
            _ => "danger"
        };
        return Pill(tone, L[$"Ng.Status.{status}"].Value);
    }

    /// <summary>Phạm vi mục lỗi trong bảng chi tiết: pallet = danger · box = warning · serial = info.</summary>
    private static string ScopeTone(string? scope) => scope switch
    {
        "pallet" => "danger",
        "box" => "warning",
        _ => "info",
    };

    /// <summary>Vai trò người nhận trong ô xem trước mail — cùng màu với bảng cấu hình.</summary>
    private static string MailTone(string type) => type switch
    {
        "TO" => "info",
        "CC" => "dim",
        _ => "warning",
    };

    /// <summary>
    /// Lớp màu của dải trạng thái. Tên phải có tiền tố ng-h-: lớp chung như
    /// "progress" đã được swms-theme.css dùng cho thanh tiến độ cao 6px.
    /// </summary>
    private string HeroClass() => _detail!.Header switch
    {
        { DocStatus: "finalized" } => "ng-h-done",
        { DocStatus: "cancelled" } => "ng-h-cancelled",
        { DocStatus: "ready_to_finalize" } => "ng-h-ready",
        _ => "ng-h-progress"
    };

    private string HeroText() => _detail!.Header switch
    {
        { DocStatus: "finalized" } => L["Ng.Hero.Finalized", L[$"Ng.Res.{_detail.Header.Resolution}"].Value],
        { DocStatus: "cancelled" } => L["Ng.Hero.Cancelled"],
        { DocStatus: "ready_to_finalize" } => L["Ng.Hero.Ready"],
        { DocStatus: "draft" } => L["Ng.Hero.Draft"],
        // Luồng tuần tự: nói rõ đang chờ ai, thay vì "chờ FA và OQC" chung chung.
        { OqcStatus: "pending" } => L["Ng.Hero.WaitOqc"],
        _ => L["Ng.Hero.WaitFa"]
    };

    // ----- Tiến trình xử lý (.stepper-v) -----
    // Giá trị trạng thái của bước: done | current | todo | cancel | skip.
    // Chuỗi này được gắn thẳng làm class của .step-v — CSS định nghĩa đủ 5 giá trị.

    private string LeaderState() => _detail!.Header.LeaderStatus switch
    {
        "submitted" => "done",
        "cancelled" => "cancel",
        _ => _detail.Header.DocStatus == "draft" ? "current" : "todo"
    };

    // FaState() và FaFixState() đã bỏ: mỗi lượt OQC/FA giờ là một bước riêng
    // dựng từ nhật ký, lượt đã xảy ra luôn là 'done' còn lượt đang chờ luôn là
    // 'current'. Suy trạng thái từ cột tổng hợp sẽ sai ngay khi phiếu quay vòng.

    /// <summary>
    /// Đóng phiếu KHÔNG còn là một bước ai bấm — nó xảy ra lúc OQC và FA cùng
    /// kết luận OK. Vẫn hiện ra để người đọc thấy phiếu đã tới đích hay chưa.
    /// </summary>
    private string CloseState() => _detail!.Header.DocStatus switch
    {
        "finalized" => "done",
        "cancelled" => "cancel",
        _ => "todo"
    };

    /// <summary>1 bước trong tiến trình — thay cho StepRow (RenderTreeBuilder) trước đây.</summary>
    /// <param name="Hint">
    /// Một dòng nói AI làm gì ở bước này. Sơ đồ cũ chỉ có tên bước, nên người
    /// đọc phải tự nhớ "FA" là ai và họ quyết cái gì.
    /// </param>
    private sealed record NgStep(int No, string Title, string State, string? By, DateTime? At,
                                 string? Comment, MarkupString? Badge = null, string? Hint = null);

    /// <summary>
    /// Hai bước ĐẦU — chỉ xảy ra một lần cho mỗi phiếu, nên sơ đồ xếp chúng
    /// CÙNG MỘT HÀNG NGANG: nhìn một nhịp là biết phiếu đã qua cửa SCS chưa.
    /// </summary>
    private IEnumerable<NgStep> HeadSteps()
    {
        var d = _detail!;
        yield return new NgStep(1, L["Ng.Step.Created"].Value, "done",
            d.Header.CreatedBy, d.Header.DiscoveredAt, null,
            Hint: L["Ng.Hint.Created"].Value);
        yield return new NgStep(2, L["Ng.Step.Leader"].Value, LeaderState(),
            d.LeaderBy, d.LeaderAt, d.LeaderComment,
            Hint: L["Ng.Hint.Leader"].Value);
    }

    /// <summary>
    /// Phần LẶP — mỗi LƯỢT là một BƯỚC RIÊNG, đánh số tiếp, chứ không phải một
    /// ô bị ghi đè. Phiếu quay ba vòng thì sơ đồ có ba lượt OQC và ba lượt FA,
    /// đọc được ai nói gì ở lượt nào.
    ///
    /// Vì vậy phải dựng từ NHẬT KÝ (wms.ng_inspection_approvals) chứ không từ
    /// ba cột oqc_by / fa_by / *_at: ba cột đó chỉ giữ LẦN CUỐI của mỗi bên,
    /// nên phiếu quay ba vòng vẫn trông như chỉ có một lượt OQC và một lượt FA.
    /// </summary>
    private IEnumerable<NgStep> LoopSteps()
    {
        var d = _detail!;
        var no = 3;
        var nth = new Dictionary<string, int>();

        foreach (var a in d.Approvals
                           .Where(x => x.Step is "oqc" or "fa" or "fa_fix")
                           .OrderBy(x => x.ActedAt).ThenBy(x => x.Id))
        {
            nth[a.Step] = nth.TryGetValue(a.Step, out var seen) ? seen + 1 : 1;
            yield return new NgStep(no++, StepTitle(a.Step, nth[a.Step]), "done",
                a.ActedBy, a.ActedAt, a.Comment, StepBadge(a), StepHint(a.Step));
        }

        // Lượt ĐANG CHỜ chưa có dòng nhật ký nào, nên phải dựng từ current_step.
        var waiting = d.Header.DocStatus is "finalized" or "cancelled"
            ? null
            : d.Header.CurrentStep switch
            {
                "oqc_confirm" => "oqc",
                "fa_confirm" => "fa",
                "fa_fix" => "fa_fix",
                _ => null
            };

        if (waiting is not null)
        {
            nth[waiting] = nth.TryGetValue(waiting, out var seen) ? seen + 1 : 1;
            yield return new NgStep(no++, StepTitle(waiting, nth[waiting]), "current",
                null, null, null, null, StepHint(waiting));
        }

        yield return new NgStep(no, L["Ng.Step.Close"].Value, CloseState(),
            d.FinalizedBy, d.FinalizedAt, d.FinalComment,
            ResolutionChip(d.Header.Resolution), L["Ng.Hint.Close"].Value);
    }

    /// <summary>Tên bước, kèm "lần n" từ lượt thứ hai trở đi.</summary>
    private string StepTitle(string step, int nth)
    {
        var name = step switch
        {
            "oqc" => L["Ng.Step.Oqc"].Value,
            "fa_fix" => L["Ng.Step.FaFix"].Value,
            _ => L["Ng.Step.Fa"].Value
        };
        return nth <= 1 ? name : $"{name} · {L["Ng.Step.Nth", nth].Value}";
    }

    private string StepHint(string step) => step switch
    {
        "oqc" => L["Ng.Hint.Oqc"].Value,
        "fa_fix" => L["Ng.Hint.FaFix"].Value,
        _ => L["Ng.Hint.Fa"].Value
    };

    /// <summary>
    /// Chip của một lượt ĐÃ XẢY RA, đọc từ chính dòng nhật ký — không đọc
    /// trạng thái hiện tại của phiếu, vì lượt cũ phải giữ nguyên kết quả cũ.
    ///
    /// Phiếu CŨ ghi action = 'approve' (trước 23/11 FA không đánh OK/NG, chỉ
    /// chọn hướng xử lý), khi đó quay về hiện hướng xử lý như sơ đồ cũ.
    /// </summary>
    private MarkupString? StepBadge(NgApprovalDto a) => a.Step switch
    {
        "oqc" => OqcChip(a.Action),
        "fa" when a.Action is "ok" or "ng" => FaChip(a.Action, a.Resolution),
        "fa" when a.Resolution is not null
            => Pill(ResolutionTone(a.Resolution), L[$"Ng.Res.{a.Resolution}"].Value),
        _ => null
    };

    /// <summary>
    /// Ô tròn đầu bước: ✓ khi xong, – khi bỏ qua (nhìn cột số là biết ngay bước
    /// nào không áp dụng, không phải đọc chữ bên cạnh), còn lại là số thứ tự.
    /// </summary>
    private static string StepMark(NgStep s) => s.State switch
    {
        "done" => "✓",
        "skip" => "–",
        _ => s.No.ToString()
    };

    /// <summary>Dòng phụ "người · thời điểm"; chưa ai làm thì ghi "Chưa".</summary>
    private string StepMeta(NgStep s)
        => s.By is null
            ? L["Ng.NotYet"].Value
            : $"{s.By} · {s.At:dd/MM/yyyy HH:mm}";

    /// <summary>
    /// Số lượng ảnh hưởng để hiện ra. Lỗi cả pallet thì số lượng vô nghĩa —
    /// mỗi mục phạm vi lưu qty_affected = 1, hiện "1 cái" làm người đọc tưởng
    /// chỉ một sản phẩm bị lỗi.
    ///
    /// Để ở đây thay vì viết thẳng trong .razor vì chuỗi nội suy có chứa chuỗi
    /// con trong dấu nháy đôi, đặt trong @(...) của Razor rất dễ vỡ khi sửa.
    /// </summary>
    private string QtyText(bool wholePallet, int qty)
        => wholePallet
            ? L["Ng.WholePallet"].Value
            : $"{qty} {L["Ng.QtyWord"].Value}";
}