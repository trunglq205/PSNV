﻿using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;

namespace Swms.FinishGoods.API.Features.Pallets
{
    public static class LotModule
    {
        public static IServiceCollection AddLotFeature(this IServiceCollection services)
        {
            services.AddScoped<IPalletService, PalletService>();
            services.AddScoped<ILotRepository, LotRepository>();

            // Gợi ý vị trí lưu kho — slice riêng, không đụng PalletService.
            services.AddScoped<IStorageSuggestionService, StorageSuggestionService>();
            services.AddScoped<IStorageSuggestionRepository, StorageSuggestionRepository>();
            return services;
        }
    }
}