// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'print_history_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PrintHistoryRowRequestModel _$PrintHistoryRowRequestModelFromJson(
  Map<String, dynamic> json,
) => PrintHistoryRowRequestModel(
  model: json['model'] as String,
  qty: (json['qty'] as num).toInt(),
  g21Part: json['g21Part'] as String?,
  innerBox: json['innerBox'] as String?,
  origin: json['origin'] as String?,
  oqcChecked: json['oqcChecked'] as bool? ?? false,
  innerLength: (json['innerLength'] as num?)?.toDouble(),
  innerWidth: (json['innerWidth'] as num?)?.toDouble(),
  innerHeight: (json['innerHeight'] as num?)?.toDouble(),
  innerWeight: (json['innerWeight'] as num?)?.toDouble(),
);

Map<String, dynamic> _$PrintHistoryRowRequestModelToJson(
  PrintHistoryRowRequestModel instance,
) => <String, dynamic>{
  'g21Part': ?instance.g21Part,
  'model': instance.model,
  'innerBox': ?instance.innerBox,
  'qty': instance.qty,
  'origin': ?instance.origin,
  'oqcChecked': instance.oqcChecked,
  'innerLength': ?instance.innerLength,
  'innerWidth': ?instance.innerWidth,
  'innerHeight': ?instance.innerHeight,
  'innerWeight': ?instance.innerWeight,
};

PrintHistoryRequestModel _$PrintHistoryRequestModelFromJson(
  Map<String, dynamic> json,
) => PrintHistoryRequestModel(
  productionDate: DateTime.parse(json['productionDate'] as String),
  isOverseaService: json['isOverseaService'] as bool,
  rows: (json['rows'] as List<dynamic>)
      .map(
        (e) => PrintHistoryRowRequestModel.fromJson(e as Map<String, dynamic>),
      )
      .toList(),
  poNo: json['poNo'] as String?,
  customerPoNo: json['customerPoNo'] as String?,
  packer: json['packer'] as String?,
  checker: json['checker'] as String?,
  length: (json['length'] as num?)?.toDouble(),
  width: (json['width'] as num?)?.toDouble(),
  height: (json['height'] as num?)?.toDouble(),
  weight: (json['weight'] as num?)?.toDouble(),
  payload: json['payload'] as String?,
  model: json['model'] as String?,
  qty: (json['qty'] as num?)?.toInt(),
  origin: json['origin'] as String?,
  category: (json['category'] as num?)?.toInt(),
);

Map<String, dynamic> _$PrintHistoryRequestModelToJson(
  PrintHistoryRequestModel instance,
) => <String, dynamic>{
  'poNo': ?instance.poNo,
  'customerPoNo': ?instance.customerPoNo,
  'productionDate': instance.productionDate.toIso8601String(),
  'packer': ?instance.packer,
  'checker': ?instance.checker,
  'length': ?instance.length,
  'width': ?instance.width,
  'height': ?instance.height,
  'weight': ?instance.weight,
  'payload': ?instance.payload,
  'model': ?instance.model,
  'qty': ?instance.qty,
  'origin': ?instance.origin,
  'category': ?instance.category,
  'isOverseaService': instance.isOverseaService,
  'rows': instance.rows,
};
