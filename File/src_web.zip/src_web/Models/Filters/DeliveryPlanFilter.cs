﻿using Refit;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class DeliveryPlanFilter : BaseFilter
    {
        public DeliveryPlanType Type { get; set; }

        [AliasAs("DAInvNo")]
        public string? No { get; set; }

        [AliasAs("planOrderNumber")]
        [Display(Name = "Plan Order Number")]
        public string? PlanOrderNumber { get; set; }

        [Display(Name = "Vendor Code")]
        public string? VendorCode { get; set; }

        [Display(Name = "Material")]
        public string? Material { get; set; }

        [Display(Name = "PO")]
        public string? PoNo { get; set; }

        [Display(Name = "PO Item")]
        public string? PoItem { get; set; }

        [Display(Name = "Plant")]
        public string? Plant { get; set; }
        [Display(Name = "Sloc")]
        public string? Sloc { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? Date { get; set; } = DateTime.Now;
    }
}
