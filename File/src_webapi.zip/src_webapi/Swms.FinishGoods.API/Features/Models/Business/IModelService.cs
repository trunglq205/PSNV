﻿using Swms.FinishGoods.Api.Features.Models.Api;
using Swms.FinishGoods.API.Common.Models;

namespace Swms.FinishGoods.Api.Features.Models.Business;

public interface IModelService
{
    Task<PagedResult<ModelResponse>> GetPagedAsync(ModelQuery query);
    Task<ModelResponse> GetByIdAsync(int id);
    Task<ModelResponse> GetByCodeAsync(string code);
    Task<ModelResponse> GetByGTINAsync(string gtin);
    Task<ModelResponse> CreateAsync(CreateModelRequest request);
    Task<List<ModelResponse>> BulkCreateAsync(IReadOnlyList<CreateModelRequest> requests);
    Task<BulkUpsertResult> BulkUpsertAsync(IReadOnlyList<UpsertModelRequest> requests);
    Task UpdateAsync(int id, UpdateModelRequest request);

    /// <summary>Chỉ cập nhật suggest_area + suggest_rack_row theo id. Trả bản ghi sau khi ghi.</summary>
    Task<ModelResponse> PatchSuggestionAsync(int id, PatchModelSuggestionRequest request);

    /// <summary>Như trên nhưng tra theo mã model (PDA quét lot chỉ có code, không có id).</summary>
    Task<ModelResponse> PatchSuggestionByCodeAsync(string code, PatchModelSuggestionRequest request);

    Task DeleteAsync(int id);
}