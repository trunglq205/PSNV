// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_lot_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CreateLotRequestModel _$CreateLotRequestModelFromJson(
  Map<String, dynamic> json,
) => CreateLotRequestModel(
  detailLevel: $enumDecode(_$LotDetailLevelEnumMap, json['detailLevel']),
  categoryCode: (json['categoryCode'] as num).toInt(),
  lotType: $enumDecode(_$LotTypeEnumMap, json['lotType']),
  lotNo: json['lotNo'] as String,
  stockyCode: json['stockyCode'] as String?,
  boxCount: (json['boxCount'] as num?)?.toInt(),
  model: json['model'] as String?,
  standardPacking: (json['standardPacking'] as num?)?.toInt(),
  productionDate: _dateFromJson(json['productionDate'] as String?),
  boxes: (json['boxes'] as List<dynamic>?)
      ?.map((e) => CreateLotBoxModel.fromJson(e as Map<String, dynamic>))
      .toList(),
);

Map<String, dynamic> _$CreateLotRequestModelToJson(
  CreateLotRequestModel instance,
) => <String, dynamic>{
  'detailLevel': _$LotDetailLevelEnumMap[instance.detailLevel]!,
  'categoryCode': instance.categoryCode,
  'lotType': _$LotTypeEnumMap[instance.lotType]!,
  'lotNo': instance.lotNo,
  'stockyCode': ?instance.stockyCode,
  'boxCount': ?instance.boxCount,
  'model': ?instance.model,
  'standardPacking': ?instance.standardPacking,
  'productionDate': ?_dateToJson(instance.productionDate),
  'boxes': ?instance.boxes,
};

const _$LotDetailLevelEnumMap = {
  LotDetailLevel.serial: 'serial',
  LotDetailLevel.boxLine: 'box_line',
  LotDetailLevel.boxCount: 'box_count',
};

const _$LotTypeEnumMap = {LotType.pallet: 'pallet', LotType.stocky: 'stocky'};

CreateLotBoxModel _$CreateLotBoxModelFromJson(Map<String, dynamic> json) =>
    CreateLotBoxModel(
      boxNo: json['boxNo'] as String,
      lines: (json['lines'] as List<dynamic>)
          .map((e) => CreateBoxLineModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      psnvPo: json['psnvPo'] as String?,
      customerPo: json['customerPo'] as String?,
      productionDate: _dateFromJson(json['productionDate'] as String?),
      rawPayload: json['rawPayload'] as String?,
    );

Map<String, dynamic> _$CreateLotBoxModelToJson(CreateLotBoxModel instance) =>
    <String, dynamic>{
      'boxNo': instance.boxNo,
      'psnvPo': ?instance.psnvPo,
      'customerPo': ?instance.customerPo,
      'productionDate': ?_dateToJson(instance.productionDate),
      'rawPayload': ?instance.rawPayload,
      'lines': instance.lines,
    };

CreateBoxLineModel _$CreateBoxLineModelFromJson(Map<String, dynamic> json) =>
    CreateBoxLineModel(
      model: json['model'] as String,
      qty: (json['qty'] as num).toInt(),
      serialNo: json['serialNo'] as String?,
      productionDate: _dateFromJson(json['productionDate'] as String?),
      cartonCount: (json['cartonCount'] as num?)?.toInt(),
    );

Map<String, dynamic> _$CreateBoxLineModelToJson(CreateBoxLineModel instance) =>
    <String, dynamic>{
      'model': instance.model,
      'qty': instance.qty,
      'serialNo': ?instance.serialNo,
      'productionDate': ?_dateToJson(instance.productionDate),
      'cartonCount': ?instance.cartonCount,
    };
