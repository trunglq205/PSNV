import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

/// Bước lưu vanning: pallet nào → đặt ở vị trí nào.
class KittingVanningCard extends StatelessWidget {
  /// Pallet đem ra vanning. null = chưa biết, cần quét tem (sau tách).
  final String? palletCode;

  /// Vị trí chỉ định. null = bất kỳ trong khu vanning.
  final String? targetLocator;

  /// Vị trí vừa quét (chưa lưu) hoặc đã lưu.
  final String? locatorCode;

  /// Đã lưu trên server.
  final bool saved;

  /// Cho quét lại tem pallet. null = không hiện nút.
  final VoidCallback? onRescanPallet;

  const KittingVanningCard({
    super.key,
    required this.palletCode,
    required this.targetLocator,
    required this.locatorCode,
    required this.saved,
    this.onRescanPallet,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final hasTarget = (targetLocator ?? '').isNotEmpty;
    final hasLoc = (locatorCode ?? '').isNotEmpty;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  LocaleKeys.kitting_task_vanning_title.tr(),
                  style: AppTextStyles.title.copyWith(
                    fontSize: 14,
                    color: swms.text1,
                  ),
                ),
              ),
              if (saved)
                StatusPill.success(
                  context,
                  label: LocaleKeys.kitting_task_vanning_saved_short.tr(),
                )
              else if (hasLoc)
                StatusPill.success(
                  context,
                  label: LocaleKeys.kitting_task_scanned.tr(),
                )
              else
                StatusPill.neutral(
                  context,
                  label: LocaleKeys.kitting_task_not_scanned.tr(),
                ),
            ],
          ),
          const SizedBox(height: 10),
          _InfoRow(
            icon: Icons.view_module_outlined,
            label: LocaleKeys.kitting_task_vanning_pallet.tr(),
            value: palletCode,
            placeholder: saved
                ? kSiDash
                : LocaleKeys.kitting_task_vanning_pallet_unknown.tr(),
            trailing: onRescanPallet == null
                ? null
                : AppButton(
              label: LocaleKeys.kitting_task_rescan.tr(),
              icon: Icons.refresh,
              variant: AppButtonVariant.neutral,
              size: AppButtonSize.sm,
              isFullWidth: false,
              onPressed: onRescanPallet!,
            ),
          ),
          const SizedBox(height: AppDimens.sm),
          _InfoRow(
            icon: Icons.local_shipping_outlined,
            label: LocaleKeys.kitting_task_vanning_target.tr(),
            value: hasTarget ? targetLocator : null,
            placeholder: LocaleKeys.kitting_task_vanning_any.tr(),
          ),
          if (hasLoc) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
              decoration: BoxDecoration(
                color: swms.successBg,
                border: Border.all(color: swms.success),
                borderRadius: BorderRadius.circular(AppDimens.rBtn),
              ),
              child: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: swms.success,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(
                      Icons.check,
                      size: 16,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          saved
                              ? LocaleKeys.kitting_task_vanning_saved.tr(
                            args: [locatorCode!],
                          )
                              : LocaleKeys.kitting_task_vanning_ok.tr(
                            args: [locatorCode!],
                          ),
                          style: AppTextStyles.bodyStrong.copyWith(
                            fontWeight: FontWeight.w700,
                            color: swms.success,
                          ),
                        ),
                        if (!saved)
                          Text(
                            LocaleKeys.kitting_task_vanning_confirm_hint.tr(),
                            style: AppTextStyles.caption.copyWith(
                              color: swms.text3,
                            ),
                          ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _InfoRow extends StatelessWidget {
  final IconData icon;
  final String label;
  final String? value;
  final String placeholder;
  final Widget? trailing;

  const _InfoRow({
    required this.icon,
    required this.label,
    required this.value,
    required this.placeholder,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final hasValue = (value ?? '').isNotEmpty;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
      ),
      child: Row(
        children: [
          Icon(icon, size: 20, color: swms.primary),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  label,
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
                Text(
                  hasValue ? value! : placeholder,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: hasValue
                      ? AppTextStyles.code.copyWith(
                    fontSize: 18,
                    letterSpacing: .5,
                    fontWeight: FontWeight.w800,
                    color: swms.text1,
                  )
                      : AppTextStyles.bodyStrong.copyWith(color: swms.text2),
                ),
              ],
            ),
          ),
          if (trailing != null) ...[
            const SizedBox(width: AppDimens.sm),
            trailing!,
          ],
        ],
      ),
    );
  }
}