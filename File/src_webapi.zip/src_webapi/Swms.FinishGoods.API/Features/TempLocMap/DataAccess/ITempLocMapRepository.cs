﻿using Swms.FinishGoods.API.Features.TempLocMap.Api;

namespace Swms.FinishGoods.API.Features.TempLocMap.DataAccess;

public interface ITempLocMapRepository
{
    Task<IReadOnlyList<WarehouseArea>> GetAreasAsync();
    Task<WarehouseArea?> GetAreaByCodeAsync(string areaCode);
    Task<long> CreateAreaAsync(WarehouseArea area, string? createdBy);

    Task<IReadOnlyList<MapLocator>> GetLocatorsByAreaAsync(long areaId);

    Task<IReadOnlyList<PalletLot>> GetLotsByAreaAsync(long areaId);

    /// <summary>Lưu toàn bộ layout của khu: cập nhật kích thước lưới + thay danh sách ô (transaction).</summary>
    Task SaveLayoutAsync(long areaId, SaveLayoutRequest request, string? user);

    /// <summary>Đổi trạng thái 1 locator theo mã + ghi 1 dòng lịch sử. Trả false nếu không thấy.</summary>
    Task<bool> ChangeStatusAsync(string locatorCode, ChangeStatusRequest request, string? user);

    /// <summary>
    /// Vị trí + khu + pallet đang chứa. Null nếu locator không tồn tại,
    /// Pallets rỗng nếu vị trí trống.
    /// </summary>
    Task<LocatorOccupancy?> GetLocatorOccupancyAsync(string locatorCode);
}