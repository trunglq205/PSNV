namespace Swms.FinishGoods.API.Features.StorageMap.DataAccess;

public interface IStorageMapRepository
{
    /// <summary>Danh sách kệ trong 1 khu (kèm đếm slot/chiếm chỗ).</summary>
    Task<IReadOnlyList<RackSummary>> GetRacksAsync(string areaCode);

    /// <summary>Tóm tắt 1 kệ theo mã (null nếu không có).</summary>
    Task<RackSummary?> GetRackByCodeAsync(string areaCode, string rackCode);

    /// <summary>Toàn bộ locator của 1 kệ (mặt đứng) + tình trạng chiếm chỗ.</summary>
    Task<IReadOnlyList<ElevationLocator>> GetElevationAsync(string areaCode, string rackCode);

    /// <summary>Sơ đồ top-down (kích thước lưới + khối rack/decor + chiếm chỗ theo kệ).</summary>
    Task<TopMap?> GetTopMapAsync(string areaCode);

    /// <summary>Tra một mã vị trí nằm ở khu nào, kệ nào. Null nếu không có.</summary>
    Task<LocatorLocation?> LocateAsync(string locatorCode);

    /// <summary>Serial của từng thùng trong 1 pallet (theo mã pallet).</summary>
    Task<IReadOnlyList<PalletSerial>> GetSerialsAsync(string palletCode);

    /// <summary>Lưu vị trí/kích thước các khối top-down (editor).</summary>
    Task SaveTopMapAsync(string areaCode, IReadOnlyList<SaveTopMapBlock> blocks, string? user);

    /// <summary>Tạo kệ mới (rack + locators theo mô hình p4/p3 + block top-down).</summary>
    Task CreateRackAsync(string areaCode, string code, int positions, int floors, IReadOnlyList<int> shelfPositions,
        int gridX, int gridY, int gridW, int gridH, string? user);

    /// <summary>Xoá kệ (locators + block + rack; gỡ pallet.locator_id).</summary>
    Task DeleteRackAsync(string areaCode, string rackCode, string? user);

    /// <summary>Đổi 1 ô giữa pallet và giá lửng (A/B).</summary>
    Task SetCellKindAsync(string areaCode, string rackCode, int position, int floor, string kind, string? user);
}
