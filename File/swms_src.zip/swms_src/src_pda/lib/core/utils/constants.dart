abstract final class SettingsKeys {
  static const language = 'settings.language';
  static const soundAlert = 'settings.soundAlert';
  static const pushNotify = 'settings.pushNotify';
}