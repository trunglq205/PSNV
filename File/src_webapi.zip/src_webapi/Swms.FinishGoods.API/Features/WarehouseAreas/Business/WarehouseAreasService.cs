using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.WarehouseAreas.Api;
using Swms.FinishGoods.API.Features.WarehouseAreas.DataAccess;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.WarehouseAreas.Business;

public class WarehouseAreasService : IWarehouseAreasService
{
    private static readonly HashSet<string> AllowedTypes = new(StringComparer.OrdinalIgnoreCase)
        { "storing", "receiving", "vanning" };

    private readonly IWarehouseAreasRepository _repo;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public WarehouseAreasService(
        IWarehouseAreasRepository repo,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _localizer = localizer;
    }

    public Task<IReadOnlyList<WarehouseAreaSummary>> ListAsync(string? mapType, bool includeInactive)
    {
        var t = string.IsNullOrWhiteSpace(mapType) ? null : mapType.Trim().ToLowerInvariant();
        if (t is not null && !AllowedTypes.Contains(t))
            throw new BusinessRuleException(_localizer["MapDesign.Err.InvalidMapType", mapType!]);
        return _repo.ListAsync(t, includeInactive);
    }

    public Task<WarehouseAreaSummary?> GetAsync(long id) => _repo.GetAsync(id);

    public async Task<long> CreateAsync(CreateWarehouseAreaRequest req, string? user)
    {
        var code = (req.AreaCode ?? "").Trim().ToUpperInvariant();
        var name = (req.AreaName ?? "").Trim();
        var mapType = (req.MapType ?? "").Trim().ToLowerInvariant();

        if (string.IsNullOrEmpty(code))
            throw new BusinessRuleException(_localizer["MapDesign.Err.MissingCode"]);
        if (string.IsNullOrEmpty(name))
            throw new BusinessRuleException(_localizer["MapDesign.Err.MissingName"]);
        if (!AllowedTypes.Contains(mapType))
            throw new BusinessRuleException(_localizer["MapDesign.Err.InvalidMapType", req.MapType ?? ""]);
        if (req.Cols <= 0 || req.Rows <= 0)
            throw new BusinessRuleException(_localizer["MapDesign.Err.SizePositive"]);
        if (await _repo.AreaCodeExistsAsync(code))
            throw new ConflictException(_localizer["MapDesign.Err.CodeExists", code]);

        return await _repo.CreateAsync(
            new CreateWarehouseAreaRequest(code, name, mapType, req.Cols, req.Rows, req.CellMeters),
            user);
    }

    public async Task UpdateAsync(long id, UpdateWarehouseAreaRequest req, string? user)
    {
        var name = (req.AreaName ?? "").Trim();
        if (string.IsNullOrEmpty(name))
            throw new BusinessRuleException(_localizer["MapDesign.Err.MissingName"]);
        if (req.Cols <= 0 || req.Rows <= 0)
            throw new BusinessRuleException(_localizer["MapDesign.Err.SizePositive"]);

        _ = await _repo.GetAsync(id)
            ?? throw new NotFoundException(_localizer["MapDesign.Err.MapNotFound", id]);

        await _repo.UpdateAsync(id,
            new UpdateWarehouseAreaRequest(name, req.Cols, req.Rows, req.CellMeters),
            user);
    }

    public Task SetActiveAsync(long id, bool active, string? user)
        => _repo.SetActiveAsync(id, active, user);

    public Task SoftDeleteAsync(long id, string? user)
        => _repo.SoftDeleteAsync(id, user);
}
