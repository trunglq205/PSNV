// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'storage_map_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(storageMapRemoteDataSource)
final storageMapRemoteDataSourceProvider =
    StorageMapRemoteDataSourceProvider._();

final class StorageMapRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          StorageMapRemoteDataSource,
          StorageMapRemoteDataSource,
          StorageMapRemoteDataSource
        >
    with $Provider<StorageMapRemoteDataSource> {
  StorageMapRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'storageMapRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$storageMapRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<StorageMapRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  StorageMapRemoteDataSource create(Ref ref) {
    return storageMapRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StorageMapRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StorageMapRemoteDataSource>(value),
    );
  }
}

String _$storageMapRemoteDataSourceHash() =>
    r'5614ca9c4fc34f607fec3600a1c42353567fe67c';

@ProviderFor(storageMapRepository)
final storageMapRepositoryProvider = StorageMapRepositoryProvider._();

final class StorageMapRepositoryProvider
    extends
        $FunctionalProvider<
          StorageMapRepository,
          StorageMapRepository,
          StorageMapRepository
        >
    with $Provider<StorageMapRepository> {
  StorageMapRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'storageMapRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$storageMapRepositoryHash();

  @$internal
  @override
  $ProviderElement<StorageMapRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  StorageMapRepository create(Ref ref) {
    return storageMapRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StorageMapRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StorageMapRepository>(value),
    );
  }
}

String _$storageMapRepositoryHash() =>
    r'570ffb30d95f39bd3caea37906bd847496b43fa7';

/// Danh sách bản đồ kho lưu trữ (cho dropdown chọn).

@ProviderFor(storageAreas)
final storageAreasProvider = StorageAreasProvider._();

/// Danh sách bản đồ kho lưu trữ (cho dropdown chọn).

final class StorageAreasProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<WarehouseArea>>,
          List<WarehouseArea>,
          FutureOr<List<WarehouseArea>>
        >
    with
        $FutureModifier<List<WarehouseArea>>,
        $FutureProvider<List<WarehouseArea>> {
  /// Danh sách bản đồ kho lưu trữ (cho dropdown chọn).
  StorageAreasProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'storageAreasProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$storageAreasHash();

  @$internal
  @override
  $FutureProviderElement<List<WarehouseArea>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<WarehouseArea>> create(Ref ref) {
    return storageAreas(ref);
  }
}

String _$storageAreasHash() => r'71102661b72434be3689942d8c84ac3e772208b4';

/// Bản đồ đang xem — null = khu mặc định của server.

@ProviderFor(SelectedStorageArea)
final selectedStorageAreaProvider = SelectedStorageAreaProvider._();

/// Bản đồ đang xem — null = khu mặc định của server.
final class SelectedStorageAreaProvider
    extends $NotifierProvider<SelectedStorageArea, String?> {
  /// Bản đồ đang xem — null = khu mặc định của server.
  SelectedStorageAreaProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'selectedStorageAreaProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$selectedStorageAreaHash();

  @$internal
  @override
  SelectedStorageArea create() => SelectedStorageArea();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(String? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<String?>(value),
    );
  }
}

String _$selectedStorageAreaHash() =>
    r'6cba7f4d7f494f6e7903a896d2ebd605f8f571af';

/// Bản đồ đang xem — null = khu mặc định của server.

abstract class _$SelectedStorageArea extends $Notifier<String?> {
  String? build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<String?, String?>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<String?, String?>,
              String?,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

/// Mã khu đang xem thực tế: ưu tiên lựa chọn của người dùng;
/// chưa chọn thì mở kho lưu chính, không có thì lấy bản đồ đầu danh sách.
/// Dropdown và nội dung dùng chung giá trị này nên luôn khớp nhau.

@ProviderFor(effectiveStorageArea)
final effectiveStorageAreaProvider = EffectiveStorageAreaProvider._();

/// Mã khu đang xem thực tế: ưu tiên lựa chọn của người dùng;
/// chưa chọn thì mở kho lưu chính, không có thì lấy bản đồ đầu danh sách.
/// Dropdown và nội dung dùng chung giá trị này nên luôn khớp nhau.

final class EffectiveStorageAreaProvider
    extends $FunctionalProvider<AsyncValue<String?>, String?, FutureOr<String?>>
    with $FutureModifier<String?>, $FutureProvider<String?> {
  /// Mã khu đang xem thực tế: ưu tiên lựa chọn của người dùng;
  /// chưa chọn thì mở kho lưu chính, không có thì lấy bản đồ đầu danh sách.
  /// Dropdown và nội dung dùng chung giá trị này nên luôn khớp nhau.
  EffectiveStorageAreaProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'effectiveStorageAreaProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$effectiveStorageAreaHash();

  @$internal
  @override
  $FutureProviderElement<String?> $createElement($ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<String?> create(Ref ref) {
    return effectiveStorageArea(ref);
  }
}

String _$effectiveStorageAreaHash() =>
    r'a9c993b4e10b04f468c49e4d96f1dcbb995aa18f';

/// Bản đồ top-down của khu đang xem.

@ProviderFor(storageTopMap)
final storageTopMapProvider = StorageTopMapProvider._();

/// Bản đồ top-down của khu đang xem.

final class StorageTopMapProvider
    extends
        $FunctionalProvider<
          AsyncValue<StorageTopMap>,
          StorageTopMap,
          FutureOr<StorageTopMap>
        >
    with $FutureModifier<StorageTopMap>, $FutureProvider<StorageTopMap> {
  /// Bản đồ top-down của khu đang xem.
  StorageTopMapProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'storageTopMapProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$storageTopMapHash();

  @$internal
  @override
  $FutureProviderElement<StorageTopMap> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<StorageTopMap> create(Ref ref) {
    return storageTopMap(ref);
  }
}

String _$storageTopMapHash() => r'2ccc50af34c233cf5e9ee272ad290f98a84df741';

/// Mặt cắt 1 kệ theo mã (trong khu đang xem).

@ProviderFor(rackElevation)
final rackElevationProvider = RackElevationFamily._();

/// Mặt cắt 1 kệ theo mã (trong khu đang xem).

final class RackElevationProvider
    extends
        $FunctionalProvider<
          AsyncValue<RackElevation>,
          RackElevation,
          FutureOr<RackElevation>
        >
    with $FutureModifier<RackElevation>, $FutureProvider<RackElevation> {
  /// Mặt cắt 1 kệ theo mã (trong khu đang xem).
  RackElevationProvider._({
    required RackElevationFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'rackElevationProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$rackElevationHash();

  @override
  String toString() {
    return r'rackElevationProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<RackElevation> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<RackElevation> create(Ref ref) {
    final argument = this.argument as String;
    return rackElevation(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is RackElevationProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$rackElevationHash() => r'7010804b74a17d9ca7bdec853030527a83cdaabd';

/// Mặt cắt 1 kệ theo mã (trong khu đang xem).

final class RackElevationFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<RackElevation>, String> {
  RackElevationFamily._()
    : super(
        retry: null,
        name: r'rackElevationProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Mặt cắt 1 kệ theo mã (trong khu đang xem).

  RackElevationProvider call(String rackCode) =>
      RackElevationProvider._(argument: rackCode, from: this);

  @override
  String toString() => r'rackElevationProvider';
}
