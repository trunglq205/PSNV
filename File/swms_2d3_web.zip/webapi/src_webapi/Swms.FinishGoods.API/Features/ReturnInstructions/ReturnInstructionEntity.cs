namespace Swms.FinishGoods.API.Features.ReturnInstructions;

/// <summary>
/// Chỉ thị back hàng (<c>wms.return_instructions</c>) — SCS Office ghi nhận
/// thông tin khách hàng báo trả hàng về PSNV: model nào, bao nhiêu, về ngày nào.
///
/// Phiếu này là GỐC của cả luồng return / refurbish: mục 2 đối chiếu số lượng
/// thực nhận với <see cref="Lines"/>, mục 7 phát sinh SI đuôi -RE / -R theo
/// <see cref="GoodsType"/> của chính phiếu.
/// </summary>
public class ReturnInstruction
{
    public long Id { get; set; }

    /// <summary>
    /// Sinh ở server. Tiền tố nói luôn loại hàng:
    /// <c>RW-yyyyMMdd-###</c> (rework) | <c>RB-yyyyMMdd-###</c> (refurbish).
    /// </summary>
    public string DocNo { get; set; } = string.Empty;

    /// <summary>
    /// MỘT PHIẾU MỘT LOẠI: <c>rework</c> | <c>refurbish</c>.
    ///
    /// Nằm ở phiếu chứ không ở dòng. Khách báo cả hai loại trong một lần thì
    /// SCS Office tạo hai phiếu — nhờ vậy số phiếu nói luôn loại, và bước 7
    /// (SI đuôi -RE / -R định tuyến theo loại) bám thẳng vào phiếu được.
    /// </summary>
    public string GoodsType { get; set; } = string.Empty;

    public string? Customer { get; set; }

    /// <summary>Ngày hàng dự kiến về PSNV, theo thông tin khách hàng.</summary>
    public DateTime? ExpectedDate { get; set; }

    /// <summary><c>open</c> | <c>completed</c> | <c>cancelled</c>.</summary>
    public string DocStatus { get; set; } = ReturnDocStatus.Open;

    public string? Note { get; set; }

    /// <summary>
    /// Đã báo FA lúc nào. NULL = chưa gửi được — mail bị tắt
    /// (<c>Mail:Enabled</c>), hoặc chưa khai người nhận trong
    /// <c>master.email_config</c>. Tạo phiếu KHÔNG hỏng vì mail hỏng.
    /// </summary>
    public DateTime? MailSentAt { get; set; }
    public string? MailSentTo { get; set; }

    /// <summary>
    /// WH đã chốt SL thực nhận lúc nào (mục 2b). NULL = chưa chốt.
    ///
    /// Tách khỏi <see cref="DocStatus"/> dù chốt là đóng phiếu: Office mở lại
    /// phiếu thì trạng thái về <c>open</c>, còn mốc chốt lần trước vẫn đọc được
    /// để biết FA đã nhận số nào.
    /// </summary>
    public DateTime? ClosedAt { get; set; }
    public string? ClosedBy { get; set; }

    /// <summary>
    /// Đã báo FA SỐ THỰC NHẬN lúc nào. Khác <see cref="MailSentAt"/> (mail lúc
    /// TẠO phiếu) — "FA đã biết phiếu" và "FA đã biết số thực nhận" là hai việc.
    /// </summary>
    public DateTime? ActualMailSentAt { get; set; }
    public string? ActualMailSentTo { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    public List<ReturnInstructionLine> Lines { get; set; } = [];

    /// <summary>Tổng SL kỳ vọng của cả phiếu — dùng ở danh sách và trong mail.</summary>
    public int TotalQty => Lines.Sum(l => l.Qty);

    /// <summary>
    /// Tổng SL THỰC NHẬN = số serial đã đăng ký vào phiếu (mục 2a). Suy ra từ
    /// dòng chứ không lưu trên header, cùng lý do với <see cref="TotalQty"/>.
    /// </summary>
    public int ReceivedQty => Lines.Sum(l => l.ReceivedQty);

    /// <summary>
    /// Đã nhận nhiều hơn chỉ thị ở ít nhất một model. KHÔNG phải lỗi: hàng về
    /// nhiều hơn khách báo là chuyện thường, và mục 2b có nhiệm vụ mail cho FA
    /// đúng số thực tế. Màn hình chỉ cần hiện cảnh báo.
    /// </summary>
    public bool OverReceived => Lines.Any(l => l.ReceivedQty > l.Qty);

    /// <summary>
    /// Đã nhận ÍT hơn chỉ thị ở ít nhất một model. Cũng không phải lỗi — khách
    /// báo 100 mà về 94 là chuyện thường; việc của hệ thống là báo FA số thực.
    /// </summary>
    public bool ShortReceived => Lines.Any(l => l.ReceivedQty < l.Qty);

    /// <summary>
    /// Lệch của cả phiếu = thực nhận − chỉ thị. Dương là nhận vượt, âm là thiếu.
    ///
    /// Tính từ hai con số chứ KHÔNG ghi SL thực nhận đè lên
    /// <c>return_instruction_lines.qty</c>: qty là mốc để so, ghi đè nó là mất
    /// luôn cái để so và từ đó bảng lệch luôn báo 0.
    /// </summary>
    public int DiffQty => ReceivedQty - TotalQty;

    /// <summary>
    /// Tổng SL đang ở FA của cả phiếu (mục 2c đã giao, chưa nhận lại). Màn Web
    /// cần con số này để biết còn hàng ngoài kho hay không — nhìn vào phiếu đã
    /// chốt mà không thấy nó thì tưởng xong việc rồi.
    /// </summary>
    public int AtFaQty => Lines.Sum(l => l.AtFaQty);

    /// <summary>Tổng SL FA đã giao lại và SCS đã nhận (mục 3).</summary>
    public int ReturnedQty => Lines.Sum(l => l.ReturnedQty);

    /// <summary>Đã chốt thực nhận. Mở lại phiếu KHÔNG xoá mốc này.</summary>
    public bool IsClosed => ClosedAt is not null;

    /// <summary>
    /// Số model trong phiếu. Mỗi dòng đúng một model (unique theo
    /// <c>(doc_id, model)</c>) nên đếm dòng chính là đếm model — đặt tên theo
    /// thứ người dùng đọc, không theo cách lưu.
    /// </summary>
    public int ModelCount => Lines.Count;
}

/// <summary>Một dòng model + số lượng trong chỉ thị (<c>wms.return_instruction_lines</c>).</summary>
public class ReturnInstructionLine
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public int LineNo { get; set; }

    /// <summary>Khớp <c>master.models.code</c> — service kiểm trước khi ghi.</summary>
    public string Model { get; set; } = string.Empty;

    public int Qty { get; set; }
    public string? Note { get; set; }

    /// <summary>
    /// SL thực nhận = số serial của model này đã đăng ký trong
    /// <c>wms.return_instruction_serials</c>. KHÔNG phải cột trong bảng dòng:
    /// repository đếm sang bảng sổ serial rồi gán vào đây.
    ///
    /// Lưu sẵn một con số đếm được là phải nhớ cập nhật ở mọi đường ghi serial
    /// (nhận hàng, giao FA, nhận lại, xuất) — quên một đường là lệch vĩnh viễn.
    /// </summary>
    public int ReceivedQty { get; set; }

    /// <summary>
    /// Số serial của model này ĐANG Ở FA (<c>status = 'at_fa'</c>) — mục 2c đã
    /// chỉ thị giao, FA chưa giao lại. Cũng đếm sang sổ serial như
    /// <see cref="ReceivedQty"/>, trong CÙNG một câu query.
    /// </summary>
    public int AtFaQty { get; set; }

    /// <summary>
    /// Số serial FA đã giao lại và SCS đã nhận (<c>status = 'returned'</c>) —
    /// mục 3. Đây là con số đóng vòng đi–về: còn ở FA + đã giao lại = đã từng
    /// giao FA (với phiếu không có con nào NG).
    /// </summary>
    public int ReturnedQty { get; set; }

    /// <summary>Còn phải nhận bao nhiêu. Âm thì đã nhận vượt — xem OverReceived.</summary>
    public int RemainingQty => Qty - ReceivedQty;

    /// <summary>
    /// Lệch của dòng = thực nhận − chỉ thị. Dương là vượt, âm là thiếu, 0 là đủ.
    ///
    /// Cùng con số với <see cref="RemainingQty"/> nhưng ĐỔI DẤU, và để riêng có
    /// chủ ý: màn hình đọc "còn phải nhận 6" khi đang nhận, còn bảng đối chiếu
    /// và mail báo FA đọc "lệch −6". Bắt một chỗ tự đổi dấu của chỗ kia là nơi
    /// sớm muộn sẽ có người quên.
    /// </summary>
    public int DiffQty => ReceivedQty - Qty;
}

/// <summary>
/// Một serial hàng return đã đăng ký vào phiếu
/// (<c>wms.return_instruction_serials</c>).
///
/// Đây là SỔ của phiếu, không phải ảnh chụp pallet: một serial sẽ đi qua nhiều
/// Pallet ID trong suốt chu trình (WH nhận → giao FA → FA trả → xuất), còn
/// dòng sổ này thì sống từ lúc quét tới lúc xuất xong.
/// </summary>
public class ReturnSerial
{
    public long Id { get; set; }
    public long DocId { get; set; }

    /// <summary>Khớp model của một dòng trong phiếu.</summary>
    public string Model { get; set; } = string.Empty;

    public string SerialNo { get; set; } = string.Empty;

    /// <summary>Mã thùng lúc nhận. NULL khi hàng về rời, không có thùng để quét.</summary>
    public string? BoxNo { get; set; }

    /// <summary>Id <c>wms.pallets</c> ĐANG giữ serial (không phải pallet_id dạng chuỗi).</summary>
    public long? PalletDbId { get; set; }

    /// <summary>Mã pallet dạng người đọc — JOIN sang <c>wms.pallets.pallet_id</c>.</summary>
    public string? PalletNo { get; set; }

    public string Status { get; set; } = ReturnSerialStatus.Received;

    public DateTime ReceivedAt { get; set; }
    public string? CreatedBy { get; set; }
}

/// <summary>
/// Một pallet hàng return của phiếu — gom từ sổ serial, không phải một bảng.
/// </summary>
public class ReturnPallet
{
    public long Id { get; set; }
    public string LotNo { get; set; } = string.Empty;
    public string? LocatorCode { get; set; }
    public int SerialCount { get; set; }
    public int BoxCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }

    /// <summary>Model → số serial trên pallet này.</summary>
    public Dictionary<string, int> ModelCounts { get; set; } = [];
}

/// <summary>
/// Trạng thái của MỘT serial trong chu trình return. Khai đủ ngay từ mục 2a để
/// các mục sau không phải ALTER bảng; CHECK của
/// <c>wms.return_instruction_serials</c> giữ đúng bộ giá trị này.
/// </summary>
public static class ReturnSerialStatus
{
    /// <summary>WH đã nhận vào kho SCS. Mục 2a chỉ sinh ra giá trị này.</summary>
    public const string Received = "received";

    /// <summary>Đã giao sang FA (mục 2c / 3).</summary>
    public const string AtFa = "at_fa";

    /// <summary>FA đã trả về SCS (mục 5).</summary>
    public const string Returned = "returned";

    /// <summary>Đã xuất cho khách (mục 10).</summary>
    public const string Shipped = "shipped";

    /// <summary>Kiểm lại không đạt (nhánh NG của mục 5).</summary>
    public const string Ng = "ng";

    public static bool IsValid(string? s) =>
        s is Received or AtFa or Returned or Shipped or Ng;
}

/// <summary>
/// Loại hàng trả về. Để hằng chuỗi vì giá trị này đi thẳng vào cột
/// <c>nvarchar</c>, và cũng là hậu tố khoá dịch (<c>Return.GoodsType.*</c>).
///
/// ⚠ TRÙNG CÓ CHỦ Ý với <c>wms.pallets.disposition</c>. Mục 2 phải đối chiếu
/// dòng chỉ thị với pallet WH đã tạo, và bản đồ kho đã vẽ badge RW/RE theo
/// đúng hai chuỗi này — đặt bộ từ vựng thứ hai là chuốc thêm một lớp quy đổi
/// và sớm muộn sẽ lệch.
/// </summary>
public static class ReturnGoodsType
{
    /// <summary>Hàng rework. SI xuất mang đuôi <c>-RE</c>.</summary>
    public const string Rework = "rework";

    /// <summary>Hàng refurbish. SI xuất mang đuôi <c>-R</c>.</summary>
    public const string Refurbish = "refurbish";

    public static bool IsValid(string? s) => s is Rework or Refurbish;

    /// <summary>
    /// Tiền tố số phiếu theo loại. Giữ ở ĐÂY cạnh chính hai hằng loại hàng:
    /// thêm loại thứ ba mà quên tiền tố thì lỗi lộ ra ngay tại đây, thay vì
    /// âm thầm sinh ra một phiếu mang tiền tố của loại khác.
    /// </summary>
    public static string DocPrefix(string goodsType) => goodsType switch
    {
        Rework => "RW",
        Refurbish => "RB",
        _ => throw new ArgumentOutOfRangeException(nameof(goodsType), goodsType,
            "Loại hàng không hợp lệ — không suy ra được tiền tố số phiếu."),
    };
}

/// <summary>
/// Trạng thái phiếu. Mục 1 chỉ sinh ra <see cref="Open"/>; hai giá trị còn lại
/// đã khai sẵn trong CHECK của bảng để mục 2 trở đi không phải ALTER.
/// </summary>
public static class ReturnDocStatus
{
    /// <summary>Đang theo dõi — hàng chưa về đủ.</summary>
    public const string Open = "open";

    /// <summary>Đã nhận đủ hàng.</summary>
    public const string Completed = "completed";

    public const string Cancelled = "cancelled";

    public static bool IsValid(string? s) => s is Open or Completed or Cancelled;
}
