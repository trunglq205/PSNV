namespace Swms.FinishGoods.Web.Features.Inventory.Business.Models;

/// <summary>
/// Một dòng tồn kho — khớp <c>InventoryItemResponse</c> từ GET /api/inventory.
///
/// TRƯỚC ĐÂY kế thừa PalletDto của feature Lots. Giờ tự chứa: Inventory không còn
/// phụ thuộc feature Pallet nào ở tầng Web.
///
/// Route API vẫn là /api/pallets/... vì phía backend feature Pallets vẫn tồn tại —
/// chỉ có feature phía Web bị gỡ.
/// </summary>
public class InventoryItemDto
{
    // ── Phần dùng chung với pallet ──
    public long Id { get; set; }
    public string LotNo { get; set; } = "";
    public string? StockyCode { get; set; }
    public int CategoryCode { get; set; }
    public string CategoryName { get; set; } = "";
    public string LotType { get; set; } = "";
    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string? AreaCode { get; set; }
    public string DetailLevel { get; set; } = "";      // serial | box_line | box_count
    public int? BoxCount { get; set; }
    public int? TotalQty { get; set; }
    public string InspectionStatus { get; set; } = "";
    public bool IsUrgent { get; set; }
    public bool IsEvenPallet { get; set; }
    public DateTime? ProductionDate { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public int? SapStatus { get; set; }
    public DateTime? SapPushedAt { get; set; }
    public string? SiNo { get; set; }
    public string? Model { get; set; }
    public List<InventoryBoxDto> Boxes { get; set; } = new();

    // ── Phần đặc thù tồn kho (inv.stock_onhand) ──
    public string? AreaKey { get; set; }        // staging | storing | vanning | jupiter | borrowed
    public string? LocatorName { get; set; }
    public string? LocatorType { get; set; }    // storage | staging | reserve | vanning | production
    public string? BorrowedFrom { get; set; }   // FA, MCS… (kho mượn)
    public bool IsHeavy { get; set; }           // hàng quá nặng → Jupiter
    public bool HasSerial { get; set; }

    public static AppInventoryItem ToViewModel(InventoryItemDto d)
    {
        var age = InventoryDisplay.AgeDays(d.ProductionDate);

        return new AppInventoryItem
        {
            Id = d.Id,
            LotNo = d.LotNo,
            StockyCode = d.StockyCode,
            SiNo = d.SiNo,
            CategoryCode = d.CategoryCode,
            CategoryName = d.CategoryName,
            LotType = d.LotType,
            LocatorId = d.LocatorId,
            LocatorCode = d.LocatorCode,
            AreaCode = d.AreaCode,
            DetailLevel = d.DetailLevel,
            InspectionStatus = string.IsNullOrEmpty(d.InspectionStatus) ? "not_required" : d.InspectionStatus,
            IsUrgent = d.IsUrgent,
            IsEvenPallet = d.IsEvenPallet,

            BoxCount = d.BoxCount ?? d.Boxes.Count,
            LineCount = d.Boxes.Sum(b => b.Lines.Count),
            TotalQty = d.TotalQty ?? 0,

            Model = d.Model,
            // Lot box_count không có box_lines -> lấy lots.model; còn lại gộp DISTINCT.
            Models = d.Model != null
                ? new List<string> { d.Model }
                : d.Boxes.SelectMany(b => b.Lines.Select(l => l.Model))
                         .Where(m => !string.IsNullOrWhiteSpace(m))
                         .Distinct()
                         .ToList(),
            Origins = d.Boxes.SelectMany(b => b.Lines.Select(l => l.OriginCountry))
                             .Where(o => !string.IsNullOrWhiteSpace(o))
                             .Select(o => o!)
                             .Distinct()
                             .ToList(),

            ProductionDate = d.ProductionDate?.ToString("dd/MM/yyyy") ?? "—",
            CreatedAt = d.CreatedAt.ToString("dd/MM/yyyy HH:mm"),
            CreatedBy = d.CreatedBy ?? "",
            SapStatus = d.SapStatus,
            SapPushedAt = d.SapPushedAt?.ToLocalTime().ToString("dd/MM/yyyy HH:mm") ?? "—",
            Boxes = d.Boxes.Select(InventoryBoxDto.ToViewModel).ToList(),

            IsAging = age is { } a && a > InventoryDisplay.AgingThresholdDays,
            AreaKey = string.IsNullOrEmpty(d.AreaKey)
                ? InventoryDisplay.AreaFromCode(d.AreaCode, d.BorrowedFrom, d.IsHeavy)
                : d.AreaKey!,
            LocatorName = d.LocatorName,
            BorrowedFrom = d.BorrowedFrom,
            AgeDays = age,
            HasSerial = d.HasSerial || d.Boxes.Any(x => x.Lines.Any(l => !string.IsNullOrWhiteSpace(l.SerialNo))),
        };
    }
}

/// <summary>Một thùng trong lot.</summary>
public class InventoryBoxDto
{
    public long Id { get; set; }
    public string BoxNo { get; set; } = "";
    public string? SpecCode { get; set; }
    public decimal? Length { get; set; }
    public decimal? Width { get; set; }
    public decimal? Height { get; set; }
    public decimal? Weight { get; set; }
    public string? PsnvPo { get; set; }
    public string? CustomerPo { get; set; }

    public int? OqcStatus { get; set; }   // 2 check · 3 chờ KQ · 4 NG · 5 pass
    public string? Line { get; set; }
    public string? LotName { get; set; }
    public string? Payload { get; set; }
    public DateTime? ProductionDate { get; set; }
    public List<InventoryBoxLineDto> Lines { get; set; } = new();

    public static AppInventoryBox ToViewModel(InventoryBoxDto b) => new()
    {
        Id = b.Id,
        BoxNo = b.BoxNo,
        SpecCode = b.SpecCode,
        Line = b.Line,
        OqcStatus = b.OqcStatus,
        LotName = b.LotName,
        Dimension = FormatDim(b.Length/10, b.Width/10, b.Height/10),
        GrossWeight = b.Weight,
        PsnvPo = b.PsnvPo,
        CustomerPo = b.CustomerPo,
        Payload = b.Payload,
        ProductionDate = b.ProductionDate?.ToString("dd/MM/yyyy") ?? "—",
        Lines = b.Lines.Select(InventoryBoxLineDto.ToViewModel).ToList(),
    };

    internal static string FormatDim(decimal? l, decimal? w, decimal? h)
        => l is null || w is null || h is null
            ? "—"
            : $"{Trim(l.Value)}×{Trim(w.Value)}×{Trim(h.Value)}";

    private static string Trim(decimal v) => v.ToString("0.##");
}

/// <summary>Một dòng model / serial trong thùng.</summary>
public class InventoryBoxLineDto
{
    public long Id { get; set; }
    public string Model { get; set; } = "";
    public int Qty { get; set; }
    public string? SerialNo { get; set; }
    public DateTime? ProductionDate { get; set; }
    public string? OriginCountry { get; set; }
    public int? CartonQty { get; set; }
    public string? CartonSpecCode { get; set; }

    public static AppInventoryBoxLine ToViewModel(InventoryBoxLineDto l) => new()
    {
        Id = l.Id,
        Model = l.Model,
        Qty = l.Qty,
        SerialNo = l.SerialNo,
        OriginCountry = l.OriginCountry ?? "",
        CartonQty = l.CartonQty,
        // pcs / carton = qty / cartonQty (chỉ khi có cartonQty > 0)
        PcsPerCarton = l.CartonQty is > 0 ? (int)(l.Qty / l.CartonQty.Value) : (int?)null,
    };
}

/// <summary>Option danh mục để đổ dropdown lọc + dialog in tem.</summary>
public class CategoryOptionDto
{
    public int Code { get; set; }
    public string Name { get; set; } = "";
}

/// <summary>Khớp GET /api/inventory/areas.</summary>
public class InventoryAreaDto
{
    public string AreaKey { get; set; } = "";
    public int PalletCount { get; set; }
    public int BoxCount { get; set; }
    public int TotalQty { get; set; }
    public int ModelCount { get; set; }

    public static AppInventoryArea ToViewModel(InventoryAreaDto d) => new()
    {
        Key = d.AreaKey,
        PalletCount = d.PalletCount,
        BoxCount = d.BoxCount,
        TotalQty = d.TotalQty,
        ModelCount = d.ModelCount,
    };
}

/// <summary>Khớp GET /api/inventory/aging.</summary>
public class InventoryAgingBucketDto
{
    public string Key { get; set; } = "";
    public int FromDays { get; set; }
    public int? ToDays { get; set; }
    public int PalletCount { get; set; }
    public int TotalQty { get; set; }

    public static List<AppAgingBucket> ToViewModel(IEnumerable<InventoryAgingBucketDto> src)
    {
        var list = src.ToList();
        var total = Math.Max(1, list.Sum(x => x.PalletCount));
        return list.Select(x => new AppAgingBucket
        {
            Key = x.Key,
            FromDays = x.FromDays,
            ToDays = x.ToDays,
            PalletCount = x.PalletCount,
            TotalQty = x.TotalQty,
            Share = (double)x.PalletCount / total,
        }).ToList();
    }
}
