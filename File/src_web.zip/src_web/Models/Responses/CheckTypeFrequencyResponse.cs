﻿namespace SWMS_WebTool.Models.Responses
{
    public class CheckTypeFrequencyResponse
    {
        public string? Material { get; set; }
        public string? Sloc { get; set; }
        public string? Category { get; set; }
        public bool? IsExist { get; set; }
    }
}
