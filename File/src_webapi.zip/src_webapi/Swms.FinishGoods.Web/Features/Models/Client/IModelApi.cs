using Refit;
using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.Models.Client
{
    public interface IModelApi
    {
        [Get("/api/models")]
        Task<PagedResult<ModelDto>> GetAllAsync([Query] ModelQuery query);

        [Get("/api/models/{id}")]
        Task<ModelDto> GetByIdAsync(int id);

        [Post("/api/models")]
        Task<ModelDto> CreateAsync([Body] CreateModelRequest request);

        [Post("/api/models/bulk")]
        Task<List<ModelDto>> BulkCreateAsync([Body] IReadOnlyList<CreateModelRequest> request);

        [Post("/api/models/bulk-upsert")]
        Task<BulkUpsertResult> BulkUpsertAsync([Body] IReadOnlyList<UpsertModelRequest> request);

        [Put("/api/models/{id}")]
        Task UpdateAsync(int id, [Body] UpdateModelRequest request);

        [Delete("/api/models/{id}")]
        Task DeleteAsync(int id);

        // ── Category ────────────────────────────────────────────────────────
        // Code (int) la business key -> dung lam route param, khong doi khi sua.

        /// <summary>
        /// Danh sách danh mục (category) đầy đủ — dùng cho dropdown, filter, CSV resolve
        /// và dialog quản lý danh mục.
        /// </summary>
        [Get("/api/categories")]
        Task<List<CategoryDto>> GetCategoriesAsync([Query] CategoryQuery query);

        [Post("/api/categories")]
        Task<CategoryDto> CreateCategoryAsync([Body] CreateCategoryRequest request);

        [Put("/api/categories/{code}")]
        Task UpdateCategoryAsync(int code, [Body] UpdateCategoryRequest request);

        [Delete("/api/categories/{code}")]
        Task DeleteCategoryAsync(int code);

        // ── Warehouse area ──────────────────────────────────────────────────

        /// <summary>
        /// Danh sách khu vực kho — dùng cho dropdown "khu vực gợi ý" ở form + filter
        /// và để resolve mã khu vực → Id khi import CSV.
        /// </summary>
        [Get("/api/warehouse-areas")]
        Task<List<WarehouseAreaDto>> GetWarehouseAreasAsync(
            [AliasAs("type")] string? type = "storing",
            [AliasAs("includeInactive")] bool includeInactive = false
        );
    }
}
