﻿using Newtonsoft.Json;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Models.Layout
{
    public enum WidgetType
    {
        Group = 0,
        Floor = 1,
        Zone = 2,
        Rack = 3,
        ZoneSingleDoor = 4,
        ZoneDoubleDoor = 5,
        ZoneNoDoor = 6,
        Rectangle = 7,
        Circle = 8,
        Line = 9,
        Arrow = 10,
        ArrowFill = 11,
        Text = 12,
        Door = 13,
        SingleDoor = 14,
        DoubleDoor = 15,
        NoDoor = 16,
        Trolley = 17,
        RobotLine = 18,
        Stair = 19,
        Wall = 20,
        Folklift = 100,
        FolkliftWorking = 101,
        Container = 102,
        Folklift2 = 103,
        Container2 = 104,
        Pallet = 105,
    }

    static class WidgetTypeExtension
    {
        public static string GetImagePath(this WidgetType type)
        {
            switch(type)
            {
                case WidgetType.Rectangle:
                    return "/img/rectangle.png";
                case WidgetType.Circle:
                    return "/img/circle.png";
                case WidgetType.Line:
                    return "/img/line.png";
                case WidgetType.Arrow:
                    return "/img/arrow.png";
                case WidgetType.ArrowFill:
                    return "/img/arrow_fill.png";
                case WidgetType.Text:
                    return "/img/text.png";
                case WidgetType.ZoneSingleDoor:
                    return "/img/rectangle_building.png";
                case WidgetType.ZoneDoubleDoor:
                    return "/img/double_door_building.png";
                case WidgetType.ZoneNoDoor:
                    return "/img/no_door_building.png";
                case WidgetType.Rack:
                    return "/img/SmallRackBlue.png";
                case WidgetType.SingleDoor:
                    return "/img/door.png";
                case WidgetType.DoubleDoor:
                    return "/img/double_door.png";
                case WidgetType.Folklift:
                    return "/img/folklift.png";
                case WidgetType.FolkliftWorking:
                    return "/img/folklift_working.png";
                case WidgetType.Container:
                    return "/img/container.png";
                case WidgetType.Folklift2:
                    return "/img/folklift1.png";
                case WidgetType.Container2:
                    return "/img/container2.png";
                case WidgetType.Pallet:
                    return "/img/pallet.png";
                case WidgetType.Trolley:
                    return "/img/trolley.jpg";
            }

            return "";
        }
    }

    public class BoundingBox
    {
        public double X;
        public double Y;
        public double Width;
        public double Height;

        public (double, double) GetCenterPoint()
        {
            return (X + Width / 2, Y + Height / 2);
        }
    }

    public abstract class Layout : Widget
    {
        protected Layout() { 
            Widgets = new List<Widget>();
        }  
        protected Layout(KonvaObject konvaObject) : base(konvaObject)
        {
            Widgets = new List<Widget>();
        }

        public List<Widget> Widgets { get; set; }

        public virtual KonvaObject ToKonvaContainer()
        {
            List<KonvaObject> children = (Widgets ?? new List<Widget>()).Select((widget) => widget.ToKonvaObject()).ToList();

            var Attrs = ToKonvaAttr();

            return new KonvaObject()
            {
                ClassName = KonvaClassType.Stage.GetString(),
                Attrs = new KonvaAttr()
                {
                    Id = Attrs.Id,
                    Title = Attrs.Title,
                    Width = Attrs.Width,
                    Height = Attrs.Height,
                    Name = Attrs.Name,
                    Fill = Attrs.Fill,
                    Stroke = Attrs.Stroke,
                    StrokeWidth = Attrs.StrokeWidth,
                    CustomData = Attrs.CustomData,
                },
                Children = new List<KonvaObject>()
                {
                    new KonvaObject()
                    {
                        ClassName = KonvaClassType.Layer.GetString(),
                        Attrs = new KonvaAttr(),
                        Children = children,
                    }
                }
            };
        }

        public string ToJson()
        {
            return JsonConvert.SerializeObject(ToKonvaContainer(), new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver()
            });
        }
    }

    public abstract class Widget
    {
        public int? Id { get; set; }
        public string? Title { get; set; }
        public double? X { get; set; }
        public double? Y { get; set; }
        public double? ScaleX { get; set; }
        public double? ScaleY { get; set; }
        public double? Width { get; set; }
        public double? Height { get; set; }
        public double? Rotation { get; set; }
        public string? Fill { get; set; }
        public double? BorderWidth { get; set; }
        public string? Border { get; set; }
        public bool IsLock { get; set; }
        public BoundingBox? BoundingBox { get; set; }
        public Status? Status { get; set; } = Models.Status.Active;
        public virtual WidgetType Type { get; }
        protected virtual KonvaClassType ClassName { get; }
        public string? Align { get; set; }
        public string? VertialAlign { get; set; }

        protected Widget() {
        }

        protected Widget(KonvaObject konvaObject)
        {
            Id = konvaObject.Attrs.Id;
            Title = konvaObject.Attrs.Title;
            X = konvaObject.Attrs.X;
            Y = konvaObject.Attrs.Y;
            ScaleX = konvaObject.Attrs.ScaleX;
            ScaleY = konvaObject.Attrs.ScaleY;
            Width = konvaObject.Attrs.Width;
            Height = konvaObject.Attrs.Height;
            Fill = konvaObject.Attrs.Fill;
            Rotation = konvaObject.Attrs.Rotation;
            BorderWidth = konvaObject.Attrs.StrokeWidth;
            Border = konvaObject.Attrs.Stroke;
            Status = konvaObject.Attrs.Visible == false ? Models.Status.Deleted : Models.Status.Active;
            IsLock = konvaObject.Attrs.Locked ?? false;
            Align = konvaObject.Attrs.Align;
            VertialAlign = konvaObject.Attrs.VertialAlign;
            var arr = konvaObject.Attrs.BoundingBox?.Split(";");
            if (arr?.Length == 4)
            {
                BoundingBox = new BoundingBox()
                {
                    X = double.Parse(arr[0]),
                    Y = double.Parse(arr[1]),
                    Width = double.Parse(arr[2]),
                    Height = double.Parse(arr[3]),
                };
            }
        }

        public virtual KonvaObject ToKonvaObject()
        {
            return new KonvaObject()
            {
                ClassName = ClassName.GetString(),
                Attrs = ToKonvaAttr(),
            };
        }

        protected virtual KonvaAttr ToKonvaAttr()
        {
            return new KonvaAttr()
            {
                Id = Id,
                Title = Title,
                X = X,
                Y = Y,
                ScaleX = ScaleX,
                ScaleY = ScaleY,
                Width = Width,
                Height = Height,
                Rotation = Rotation,
                Fill = Fill,
                Stroke = Border,
                StrokeWidth = BorderWidth,
                Draggable = !IsLock,
                Name = Type.GetString(),
                Visible = Status == Models.Status.Active,
                Locked = IsLock,
                Align = Align,
                VertialAlign = VertialAlign,
                BoundingBox = BoundingBox != null ? $"{BoundingBox.X};{BoundingBox.Y};{BoundingBox.Width};{BoundingBox.Height}" : null,
            };
        }
    }
}
