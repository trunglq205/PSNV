namespace Swms.FinishGoods.API.Common.Business.Exceptions;

public class ConflictException : Exception
{
    public ConflictException(string message) : base(message) { }
}
