using Refit;
using Swms.FinishGoods.Web.Features.MapDesigner.Business.Models;

namespace Swms.FinishGoods.Web.Features.MapDesigner.Client;

public interface IMapDesignerApi
{
    [Get("/api/map-designer/{areaCode}/layout")]
    Task<MapLayoutDto> GetLayoutAsync(string areaCode);

    [Put("/api/map-designer/{areaCode}/layout")]
    Task SaveLayoutAsync(string areaCode, [Body] List<MapBlockDto> blocks);

    [Post("/api/map-designer/{areaCode}/racks")]
    Task<long> CreateRackAsync(string areaCode, [Body] CreateRackInputDto input);

    [Delete("/api/map-designer/{areaCode}/racks/{rackCode}")]
    Task DeleteRackAsync(string areaCode, string rackCode);
}
