import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/return_instruction/data/datasources/return_instruction_remote_data_source.dart';
import 'package:swms_finish_goods/features/return_instruction/data/return_instruction_repository_impl.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/repositories/return_instruction_repository.dart';

part 'return_instruction_providers.g.dart';

@riverpod
ReturnInstructionRemoteDataSource returnInstructionRemoteDataSource(Ref ref) =>
    ReturnInstructionRemoteDataSource(ref.watch(dioProvider));

@riverpod
ReturnInstructionRepository returnInstructionRepository(Ref ref) =>
    ReturnInstructionRepositoryImpl(
      ref.watch(returnInstructionRemoteDataSourceProvider),
    );

/// Danh sách chỉ thị theo bộ lọc.
///
/// [filterName] là `ReturnFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build — cùng
/// cái bẫy đã ghi ở `stocky_providers.dart`.
@riverpod
Future<List<ReturnInstruction>> returnInstructionList(
  Ref ref,
  String filterName,
) async {
  final filter = ReturnFilter.values.firstWhere(
    (f) => f.name == filterName,
    orElse: () => ReturnFilter.open,
  );
  return ref
      .watch(returnInstructionRepositoryProvider)
      .fetchList(status: filter.status);
}

/// Một phiếu, đọc lại khi mở màn Nhận hàng back.
///
/// Màn đó KHÔNG nhận phiếu qua tham số điều hướng: máy khác có thể vừa quét
/// thêm, mà "còn phải nhận bao nhiêu" phải tính từ số mới nhất.
@riverpod
Future<ReturnInstruction> returnInstructionDetail(Ref ref, int docId) =>
    ref.watch(returnInstructionRepositoryProvider).fetchById(docId);
