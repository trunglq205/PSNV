import 'package:swms_finish_goods/features/settings/domain/settings_entity.dart';
// TODO: chỉnh đường dẫn import cho đúng cấu trúc dự án.

/// Hợp đồng repository cài đặt — domain layer, không biết nguồn dữ liệu.
abstract interface class SettingsRepository {
  /// Nạp cài đặt hiện tại (mặc định nếu chưa có).
  Future<SettingsEntity> getSettings();

  /// Lưu toàn bộ cài đặt.
  Future<void> saveSettings(SettingsEntity settings);
}
