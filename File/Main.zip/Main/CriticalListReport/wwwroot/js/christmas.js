/* =========================================================
   CHỦ ĐỀ GIÁNG SINH — hiệu ứng nền cho Login + Layout
   Drop-in: wwwroot/js/christmas.js  (đặt sau bootstrap.bundle)
   - Tuyết rơi (canvas, nằm sau nội dung)
   - Băng chúc mừng + đếm ngược tới 25/12 (chỉ trang có <main>)
   - Đánh dấu menu đang mở theo URL
   - Bông tuyết bung ra khi bấm nút chính
   ========================================================= */
(function () {
    "use strict";

    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function el(tag, cls, css) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (css) n.setAttribute("style", css);
        return n;
    }

    /* ---------- 1. Khung trang có menu cố định ---------- */
    function buildFrame() {
        if (document.querySelector(".navbar.fixed-top")) document.body.classList.add("xm-framed");
    }

    /* ---------- 2. Menu đang mở ---------- */
    function markActiveNav() {
        // Chuẩn hoá: bỏ "/" cuối, bỏ "/index", bỏ "/home" (trang chủ) — chạy được cả khi host trong virtual directory IIS
        function norm(p) {
            p = (p || "").split("?")[0].split("#")[0].toLowerCase().replace(/\/+$/, "");
            p = p.replace(/\/index$/, "").replace(/\/home$/, "");
            return p || "/";
        }
        var path = norm(location.pathname);
        document.querySelectorAll(".nav-group-item[href]").forEach(function (a) {
            if (norm(a.getAttribute("href")) === path) a.classList.add("active");
        });
    }

    /* ---------- 3. Băng chúc mừng + đếm ngược Giáng sinh ---------- */
    function buildBanner() {
        var main = document.querySelector("main");
        if (!main || document.querySelector(".xm-banner")) return; // trang Login không có <main>

        var now = new Date();
        var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        var xmas = new Date(now.getFullYear(), 11, 25);
        if (today > xmas) xmas = new Date(now.getFullYear() + 1, 11, 25);
        var days = Math.round((xmas - today) / 86400000);
        var chip = days === 0 ? "Hôm nay là Giáng sinh!" : "Còn " + days + " ngày đến Giáng sinh";

        var msg = "Chúc cả team một mùa Giáng sinh ấm áp, an lành — số liệu gọn gàng, báo cáo đúng hạn và một năm mới thật nhiều niềm vui!";

        var b = el("div", "xm-banner");
        var bells = el("div", "xm-banner-bells");
        bells.textContent = "🔔";
        var title = el("div", "xm-banner-title");
        title.textContent = "Merry Christmas";
        var mq = el("div", "xm-marquee");
        var inner = el("div");
        for (var i = 0; i < 2; i++) {
            var sp = el("span");
            sp.textContent = msg;
            inner.appendChild(sp);
        }
        mq.appendChild(inner);
        var c = el("div", "xm-chip");
        c.textContent = chip;

        b.appendChild(bells);
        b.appendChild(title);
        b.appendChild(mq);
        b.appendChild(c);
        main.insertBefore(b, main.firstChild);
    }

    /* ---------- 4. Tuyết rơi nền ---------- */
    function buildSnow() {
        if (REDUCED || document.querySelector(".xm-snow")) return;
        var cv = el("canvas", "xm-snow");
        document.body.appendChild(cv);
        var ctx = cv.getContext("2d"), W = 0, H = 0, DPR = Math.min(window.devicePixelRatio || 1, 2);
        var flakes = [];

        function resize() {
            W = cv.clientWidth; H = cv.clientHeight;
            cv.width = W * DPR; cv.height = H * DPR;
            ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
            var target = Math.round(Math.min(140, (W * H) / 14000));
            while (flakes.length < target) flakes.push(make(true));
            flakes.length = target;
        }

        function make(anyY) {
            var depth = Math.random(); // 0 = xa, 1 = gần
            return {
                x: Math.random() * W,
                y: anyY ? Math.random() * H : -10,
                r: 0.8 + depth * 2.4,
                vy: 0.35 + depth * 1.1,
                drift: Math.random() * Math.PI * 2,
                a: 0.35 + depth * 0.55
            };
        }

        resize();
        window.addEventListener("resize", resize);

        var last = performance.now();
        function frame(t) {
            var dt = Math.min((t - last) / 16.67, 3);
            last = t;
            if (!document.hidden) {
                ctx.clearRect(0, 0, W, H);
                ctx.fillStyle = "#fff";
                for (var i = 0; i < flakes.length; i++) {
                    var f = flakes[i];
                    f.y += f.vy * dt;
                    f.drift += 0.012 * dt;
                    f.x += Math.sin(f.drift) * 0.35 * dt;
                    if (f.y > H + 8 || f.x < -10 || f.x > W + 10) { flakes[i] = make(false); continue; }
                    ctx.globalAlpha = f.a;
                    ctx.beginPath();
                    ctx.arc(f.x, f.y, f.r, 0, 6.2832);
                    ctx.fill();
                }
                ctx.globalAlpha = 1;
            }
            requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
    }

    /* ---------- 5. Bông tuyết bung ra khi bấm nút chính ---------- */
    function sparkLayer() {
        var l = document.querySelector(".xm-spark-layer");
        if (!l) { l = el("div", "xm-spark-layer"); document.body.appendChild(l); }
        return l;
    }

    function burst(x, y, n) {
        if (REDUCED) return;
        var layer = sparkLayer();
        var glyphs = ["❄", "❅", "❆", "✦"];
        for (var i = 0; i < (n || 14); i++) {
            var a = Math.random() * Math.PI * 2, r = 36 + Math.random() * 60;
            var p = el("div", "xm-spark",
                "left:" + x + "px;top:" + y + "px;font-size:" + (10 + Math.random() * 10) + "px" +
                ";--dx:" + Math.cos(a) * r + "px;--dy:" + (Math.sin(a) * r + 24) + "px" +
                ";animation-duration:" + (0.6 + Math.random() * 0.5) + "s");
            p.textContent = glyphs[i % glyphs.length];
            layer.appendChild(p);
            (function (node) { setTimeout(function () { node.remove(); }, 1200); })(p);
        }
    }

    function wireSparks() {
        var sel = ".btn-export, .btn-filter, .btn-apply, .btn-update, .btn-update-vendor, .btn-update-inbound, .btn-login";
        document.addEventListener("click", function (e) {
            var t = e.target.closest ? e.target.closest(sel) : null;
            if (!t) return;
            var r = t.getBoundingClientRect();
            burst(r.left + r.width / 2, r.top + r.height / 2, 16);
        }, true);
    }

    function init() {
        buildFrame();
        markActiveNav();
        buildSnow();
        buildBanner();
        wireSparks();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();

    window.Christmas = { burst: burst };
})();
