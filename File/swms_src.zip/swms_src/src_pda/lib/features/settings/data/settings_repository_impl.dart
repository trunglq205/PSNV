import 'package:swms_finish_goods/features/settings/data/settings_local_data_source.dart';
import 'package:swms_finish_goods/features/settings/domain/settings_entity.dart';
import 'package:swms_finish_goods/features/settings/domain/settings_repository.dart';

/// Hiện chỉ có nguồn cục bộ. Khi cần đồng bộ server, thêm remote data source
/// và phối ở đây mà không đổi interface.
class SettingsRepositoryImpl implements SettingsRepository {
  final SettingsLocalDataSource _local;

  const SettingsRepositoryImpl(this._local);

  @override
  Future<SettingsEntity> getSettings() => _local.read();

  @override
  Future<void> saveSettings(SettingsEntity settings) =>
      _local.write(settings);
}
