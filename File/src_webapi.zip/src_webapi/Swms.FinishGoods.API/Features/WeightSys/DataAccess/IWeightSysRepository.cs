using Swms.FinishGoods.API.Features.Foss.DataAccess;

namespace Swms.FinishGoods.API.Features.WeightSys.DataAccess;

public interface IWeightSysRepository
{
    Task<IReadOnlyCollection<WeightDto>> GetSerialWeightAsync(FossCategory category, string model, List<string> serials);
}