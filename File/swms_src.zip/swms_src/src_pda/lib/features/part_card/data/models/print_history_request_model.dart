import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';

part 'print_history_request_model.g.dart';

/// Khớp `SavePartCardRowRequest` phía API.
///
/// `Model` là **[Required]** — gửi rows rỗng hoặc thiếu model thì server trả
/// 400 "Yêu cầu thông tin mã model".
@JsonSerializable(includeIfNull: false)
class PrintHistoryRowRequestModel {
  final String? g21Part;
  final String model;
  final String? innerBox;
  final int qty;
  final String? origin;
  final bool oqcChecked;
  final double? innerLength;
  final double? innerWidth;
  final double? innerHeight;
  final double? innerWeight;

  const PrintHistoryRowRequestModel({
    required this.model,
    required this.qty,
    this.g21Part,
    this.innerBox,
    this.origin,
    this.oqcChecked = false,
    this.innerLength,
    this.innerWidth,
    this.innerHeight,
    this.innerWeight,
  });

  factory PrintHistoryRowRequestModel.fromParams(PartCardPrintRow row) =>
      PrintHistoryRowRequestModel(
        model: row.model,
        qty: row.qty,
        g21Part: row.g21Part,
        innerBox: row.innerBox,
        origin: row.origin,
        oqcChecked: row.oqcChecked,
        innerLength: row.innerLength,
        innerWidth: row.innerWidth,
        innerHeight: row.innerHeight,
        innerWeight: row.innerWeight,
      );

  factory PrintHistoryRowRequestModel.fromJson(Map<String, dynamic> json) =>
      _$PrintHistoryRowRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$PrintHistoryRowRequestModelToJson(this);

  @override
  String toString() {
    return toJson().toString();
  }
}

/// Khớp `SavePrintRequest` phía API.
///
/// `isOverseaService` = phiếu **nhiều mã** (`PartCardMode.multi`). Tên field
/// giữ theo server, đừng đổi.
@JsonSerializable(includeIfNull: false)
class PrintHistoryRequestModel {
  final String? poNo;
  final String? customerPoNo;
  final DateTime productionDate;
  final String? packer;
  final String? checker;

  final double? length;
  final double? width;
  final double? height;
  final double? weight;

  final String? payload;

  /// Thông tin cấp phiếu — chỉ gửi khi phiếu 1 mã.
  final String? model;
  final int? qty;
  final String? origin;

  final int? category;
  final bool isOverseaService;

  /// KHÔNG được rỗng.
  final List<PrintHistoryRowRequestModel> rows;

  const PrintHistoryRequestModel({
    required this.productionDate,
    required this.isOverseaService,
    required this.rows,
    this.poNo,
    this.customerPoNo,
    this.packer,
    this.checker,
    this.length,
    this.width,
    this.height,
    this.weight,
    this.payload,
    this.model,
    this.qty,
    this.origin,
    this.category,
  });

  factory PrintHistoryRequestModel.fromParams(PartCardPrintParams params) =>
      PrintHistoryRequestModel(
        poNo: params.poNo,
        customerPoNo: params.customerPoNo,
        productionDate: params.productionDate,
        packer: params.packer,
        checker: params.checker,
        length: params.length,
        width: params.width,
        height: params.height,
        weight: params.weight,
        payload: params.payload,
        model: params.model,
        qty: params.qty,
        origin: params.origin,
        category: params.categoryCode,
        isOverseaService: params.isMulti,
        rows: params.rows
            .map(PrintHistoryRowRequestModel.fromParams)
            .toList(growable: false),
      );

  factory PrintHistoryRequestModel.fromJson(Map<String, dynamic> json) =>
      _$PrintHistoryRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$PrintHistoryRequestModelToJson(this);
}