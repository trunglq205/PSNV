using Swms.FinishGoods.API.Shared.Business.Mail;

namespace Swms.FinishGoods.API.Features.Shortages.DataAccess;

public interface IShortageRepository
{
    /// <summary>Mọi dòng SI đang mở (released / picking) còn thiếu. KHÔNG lọc ở SQL:
    /// chia nguồn phải xét đủ mọi SI cùng model theo thứ tự ưu tiên, lọc sau.</summary>
    Task<List<OpenShortLine>> GetOpenShortLinesAsync(int? categoryId = null);

    Task<List<ReasonRow>> GetReasonsAsync();
    Task<List<StockPalletRow>> GetStockAsync(IReadOnlyCollection<string> models);
    Task<List<ProducingRow>> GetProducingAsync(IReadOnlyCollection<string> models);
    Task<List<FollowUpRow>> GetFollowUpsAsync(IReadOnlyCollection<long> lineIds);

    /// <summary>Người nhận của 1 bộ phận, đã chuẩn hoá theo MailRecipientList.Normalize
    /// (tách nhiều địa chỉ trong 1 ô, TO thắng CC, khử trùng).</summary>
    Task<List<MailRecipient>> GetRecipientsAsync(
        string eventCode, string? department, string? subCode, string? category, string? model);

    /// <summary>
    /// Người nhận của 1 sự kiện không chia theo model (báo cáo ngày): lấy MỌI bộ phận đang
    /// được cấu hình cho sự kiện rồi tra qua fn_email_recipients — cùng cách phiếu bất thường.
    /// Đã Normalize.
    /// </summary>
    Task<List<MailRecipient>> GetEventRecipientsAsync(string eventCode);

    /// <summary>Mẫu tiêu đề / nội dung trong master.email_events. null = chưa khai sự kiện.</summary>
    Task<ShortageMailTemplateRow?> GetMailTemplateAsync(string eventCode);

    /// <summary>Email của nhân viên — để CC chính người gửi và đặt Reply-To. null = chưa khai.</summary>
    Task<string?> GetUserEmailAsync(string? employeeCode);

    /// <summary>Ghi / làm mới dòng theo dõi: số đang thiếu + thời điểm đòi.</summary>
    Task UpsertFollowUpsAsync(IReadOnlyList<(long LineId, string ReasonCode, int Qty)> rows);
}
