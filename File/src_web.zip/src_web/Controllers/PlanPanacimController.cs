﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using System.Data;

namespace SWMS_WebTool.Controllers
{
    public class PlanPanacimController : BaseController
    {
        private readonly ApiService _apiService;

        public PlanPanacimController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] PlanPanacimFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new PlanPanacimFilter();
                var response = await _apiService.SearchPlanPrintPanacim(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<PlanPrintPanacim>();

                var model = new PlanPrintPanacimViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/PlanPanacim/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportPlanPrintPanacim(IFormFile file, DateTime deliverydate)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        dt = Function.GetDataTableFromExcel(filepath, "Percentage", Constants.PlanPrintPanacimHeader, Constants.IndexHeaderPlanPanacim);
                        if (dt != null && dt.Columns.Count == Constants.PlanPrintPanacimHeader.Count)
                        {

                            List<ImportPlanPanacim>? data = Function.DataTatbleToPkanPrintPanacim(dt, deliverydate);
                            if (data != null && data.Count > 0)
                            {
                                return PartialView("~/Views/PlanPanacim/_ImportMasterPlanPrintPanacim.cshtml", data);
                            }
                        }
                    }

                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportPlanPrintPanacim([FromBody] List<ImportPlanPanacim> requests)
        {
            try
            {
                await _apiService.ImportPlanPrintPanacim(requests);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
