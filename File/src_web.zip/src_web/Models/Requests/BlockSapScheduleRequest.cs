﻿namespace SWMS_WebTool.Models.Requests
{
    public class BlockSapScheduleRequest
    {
        public byte? KittingType { get; set; }
        public DateTime? BlockDate { get; set; }
        public string BlockTime { get; set; }
        public DateTime? OpenDate { get; set; }
        public string OpenTime { get; set; }
    }

    public class BlockSapSchedulePlanRequest
    {
        public byte? KittingType { get; set; }
        public string Plant { get; set; }
        public string Category { get; set; }
    }
}
