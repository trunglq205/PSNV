part of 'exceptions.dart';

/// Lỗi nghiệp vụ màn Container Check (quét QR container, chốt kết quả kiểm).
sealed class ContainerException extends AppException {
  const ContainerException(super.message, {required super.code});
}

/// QR quét được không khớp container nào đang chờ đóng hàng.
class ContainerNotFoundException extends ContainerException {
  const ContainerNotFoundException(this.containerNo)
      : super(
    'Không tìm thấy container "$containerNo"',
    code: 'error.container_not_found',
  );

  final String containerNo;

  @override
  Map<String, String> get namedArgs => {'code': containerNo};
}

/// Chốt "đạt" khi chưa tick đủ hạng mục / chưa chụp đủ 4 góc.
/// UI đã khoá nút, đây là chốt chặn thứ hai ở notifier.
class ContainerInspectionIncompleteException extends ContainerException {
  const ContainerInspectionIncompleteException()
      : super(
    'Chưa kiểm đủ hạng mục hoặc chưa chụp đủ ảnh',
    code: 'error.container_inspection_incomplete',
  );
}

/// Báo "không đạt" mà không ghi lý do — hãng tàu cần lý do để xử lý.
class ContainerFailNoteRequiredException extends ContainerException {
  const ContainerFailNoteRequiredException()
      : super(
    'Vui lòng nhập lý do không đạt',
    code: 'error.container_fail_note_required',
  );
}
