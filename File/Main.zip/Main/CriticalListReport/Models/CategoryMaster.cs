﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("ProfitCentersMaster")]
    public class CategoryMaster
    {
        public int ProfitCenterID { get; set; }
        public string? Category { get; set; }
        public string? ProfitCenterCode { get; set; }
        public string? BusinessDivision { get; set; }
    }
}
