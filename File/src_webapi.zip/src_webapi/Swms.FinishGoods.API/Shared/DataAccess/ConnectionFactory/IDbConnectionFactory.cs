using System.Data;

namespace Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

public interface IDbConnectionFactory
{
    IDbConnection Create();
}
