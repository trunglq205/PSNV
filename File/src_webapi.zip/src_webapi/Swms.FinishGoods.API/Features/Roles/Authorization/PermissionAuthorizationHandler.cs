using Microsoft.AspNetCore.Authorization;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Kiểm tra user có quyền yêu cầu không. Lấy danh sách quyền qua
/// <see cref="IUserPermissionProvider"/> (JWT claims hoặc DB-cache).
/// </summary>
public sealed class PermissionAuthorizationHandler
    : AuthorizationHandler<PermissionRequirement>
{
    private readonly IUserPermissionProvider _provider;

    public PermissionAuthorizationHandler(IUserPermissionProvider provider)
        => _provider = provider;

    protected override async Task HandleRequirementAsync(
        AuthorizationHandlerContext context, PermissionRequirement requirement)
    {
        if (context.User?.Identity?.IsAuthenticated != true)
            return; // chưa đăng nhập ⟹ fail (401/403)

        var perms = await _provider.GetPermissionsAsync(context.User);
        if (requirement.Permission.Split('|').Any(perms.Contains))
            context.Succeed(requirement);
        // không Succeed ⟹ framework trả 403
    }
}
