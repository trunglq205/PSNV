using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Features.Models.Client;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Client;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.Auth;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.App.Pages;

/// <summary>
/// Màn quản lý chỉ thị back hàng — mục 1 của quy trình return / refurbish.
///
/// SCS Office nhập model + SL khách báo trả về; tạo xong hệ thống tự gửi mail
/// báo FA (người nhận khai trong màn Cấu hình email, sự kiện
/// <c>RETURN_INSTRUCTION_CREATED</c>). SCS WH xem cùng dữ liệu này trên PDA.
///
/// MÀN NÀY CÕNG CẢ MỤC 2C — luồng nhận lại hàng về FA, ba bước trên chính
/// phiếu. Một màn cho cả ba bên (FA, quản lý FA, SCS WH), tách việc bằng bộ lọc
/// hàng đợi + quyền trên từng nút. Không dựng màn riêng: sau khi gộp thì đề
/// nghị back LÀ một mặt của phiếu, hai màn là hai nơi nhìn cùng một dòng.
/// </summary>
public partial class ReworkRefurbish
{
    [Inject] private IReturnInstructionApi Api { get; set; } = default!;
    [Inject] private IModelApi ModelApi { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private PermissionState Perm { get; set; } = default!;
    [Inject] private NavigationManager Nav { get; set; } = default!;

    /// <summary>null = tất cả. Thứ tự tab trên màn hình.</summary>
    private static readonly string?[] StatusTabs =
        { ReturnDocStatus.Open, ReturnDocStatus.Completed, ReturnDocStatus.Cancelled, null };

    private List<ReturnInstructionDto> _rows = new();
    private List<string> _models = new();

    /// <summary>
    /// Pallet hàng return theo từng phiếu, nạp LAZY khi bung dòng: danh sách
    /// phiếu có thể vài trăm dòng, nạp pallet của tất cả ngay từ đầu là vài
    /// trăm request cho thứ người dùng chỉ xem một hai phiếu.
    /// Không có khoá trong dictionary = đang nạp.
    /// </summary>
    private readonly Dictionary<long, List<ReturnPalletDto>> _pallets = new();

    private bool _loading = true;
    private string? _error;

    private string? _status = ReturnDocStatus.Open;
    private string _goodsType = "";
    private string _keyword = "";
    private DateTime? _fromDate;
    private DateTime? _toDate;

    private long? _expanded;

    // ── Menu thao tác của từng dòng ──
    //
    // Một phiếu có thể mở tới 6 nút cùng lúc (chốt thực nhận · sửa · xoá ·
    // đề nghị nhận lại · xác nhận · giao hàng · huỷ). Bày hết ra cột cuối thì
    // bảng bị đẩy ngang và mỗi dòng cao gấp đôi, nên gom vào một menu.
    //
    // Giữ ID chứ không giữ bool: chỉ MỘT menu được mở tại một thời điểm —
    // mỗi dòng một cờ riêng thì mở dòng này không đóng dòng kia, và người dùng
    // thấy hai menu chồng nhau.
    private long? _menu;

    private void ToggleMenu(long id) => _menu = _menu == id ? null : id;

    private void CloseMenu() => _menu = null;

    // Điều kiện của từng mục. Tách ra thành hàm chứ không viết thẳng trong
    // markup: mỗi điều kiện dùng HAI lần (một lần quyết định có hiện mục đó,
    // một lần quyết định có hiện cả NHÓM) — viết hai lần là sớm muộn lệch.

    /// <summary>
    /// Chốt thực nhận: chỉ khi đã nhận được hàng — chốt phiếu trống là gửi FA
    /// bảng toàn số 0.
    ///
    /// SCS WH <c>hoặc</c> SCS Office, khớp <c>RequireAnyPermission&lt;Process,
    /// Create&gt;</c> ở controller và <c>_mayClose</c> bên PDA: WH chốt tại máy
    /// PDA ngay lúc quét xong, Office chốt trên Web khi WH báo miệng. Trước đây
    /// chỗ này chỉ xét <c>MayCreate</c>, nên user SCS WH gọi được API và thấy
    /// nút trên PDA mà trên Web lại không có mục nào — lệch gương ba bên.
    /// </summary>
    private bool CanCloseDoc(ReturnInstructionDto d)
        => (MayCreate || MayProcess) && d.IsOpen && d.HasReceipt;

    private bool CanEditDoc(ReturnInstructionDto d) => MayCreate && d.IsOpen;

    private bool CanDeleteDoc(ReturnInstructionDto d) => MayCreate && d.IsOpen;

    private bool CanReopenDoc(ReturnInstructionDto d) => MayCreate && d.IsCompleted;

    /// <summary>Nhóm "Phiếu chỉ thị" có mục nào không.</summary>
    private bool AnyDocAction(ReturnInstructionDto d)
        => CanCloseDoc(d) || CanEditDoc(d) || CanDeleteDoc(d) || CanReopenDoc(d);

    /// <summary>Nhóm "Nhận lại hàng" có mục nào không.</summary>
    private bool AnyBackAction(ReturnInstructionDto d)
        => CanRequestBack(d) || CanEditBackNote(d) || CanApproveBack(d)
           || CanDeliverBack(d) || CanCancelBack(d);

    /// <summary>
    /// Không có mục nào thì KHÔNG dựng nút ba chấm: một nút bấm vào hiện menu
    /// rỗng còn khó chịu hơn là không có nút.
    /// </summary>
    private bool HasAnyAction(ReturnInstructionDto d)
        => AnyDocAction(d) || AnyBackAction(d);

    // ── Bộ lọc hàng đợi của luồng back ──
    //
    // Lọc ở CLIENT, không thêm tham số cho API: dữ liệu đã tải đủ, mà đếm số
    // trên từng mục thì buộc phải có toàn bộ — gọi API cho từng mục sẽ thành
    // năm lượt gọi chỉ để vẽ năm con số.
    //
    // Dùng <select> chứ không thêm một hàng tab nữa: hàng tab trên đã dành cho
    // trạng thái phiếu, hai hàng tab cạnh nhau thì không ai biết cái nào lọc gì.

    /// <summary>"" = không lọc theo luồng back.</summary>
    private string _backFilter = "";

    /// <summary>Giá trị bộ lọc. Thứ tự đúng thứ tự hiện trên màn.</summary>
    private static readonly string[] BackFilters =
        { "", "none", BackStep.FaApprove, BackStep.ScsDeliver, "delivered" };

    private static bool MatchBack(ReturnInstructionDto d, string filter) => filter switch
    {
        "" => true,
        "none" => !d.Back.Requested || d.Back.IsCancelled,
        "delivered" => d.Back.IsDelivered,
        var step => d.Back.IsOpen && d.Back.Step == step,
    };

    /// <summary>Dòng sau khi lọc hàng đợi back.</summary>
    private List<ReturnInstructionDto> Rows
        => _backFilter.Length == 0
            ? _rows
            : _rows.Where(d => MatchBack(d, _backFilter)).ToList();

    private int BackCount(string filter) => _rows.Count(d => MatchBack(d, filter));

    private void SetBackFilter(ChangeEventArgs e)
    {
        CloseMenu();
        _backFilter = e.Value?.ToString() ?? "";
        // Dòng đang bung gần như chắc chắn không thuộc mục mới — thu lại để
        // không còn một hàng chi tiết mồ côi.
        if (_expanded is { } id && Rows.All(r => r.Id != id)) _expanded = null;
    }

    // ── form tạo / sửa ──────────────────────────────────────
    private ReturnInstructionRequestDto? _form;
    private long? _editId;
    private string? _editDocNo;
    private string? _formError;
    private bool _saving;

    private ReturnInstructionDto? _deleting;

    /// <summary>Pallet đang chờ xác nhận huỷ lần nhận, kèm phiếu của nó.</summary>
    private (ReturnInstructionDto Doc, ReturnPalletDto Pallet)? _releasing;

    /// <summary>Phiếu đang chờ xác nhận chốt thực nhận (dialog hiện bảng lệch).</summary>
    private ReturnInstructionDto? _closing;

    /// <summary>Phiếu đang chờ xác nhận mở lại.</summary>
    private ReturnInstructionDto? _reopening;

    private bool MayCreate => Perm.Has(Perms.rework_refurbish_create.Key());

    // ── Quyền của luồng nhận lại hàng (mục 2c) ──
    // GIỮ KHỚP TỪNG DÒNG với attribute trên ReturnBackFlowController. Lệch một
    // chỗ là hoặc thấy nút rồi ăn 403, hoặc có quyền mà không thấy nút — cả hai
    // đều khó lần ra vì Has() trả false IM LẶNG.

    /// <summary>B1 — FA đề nghị / sửa ghi chú.</summary>
    private bool MayRequestBack => Perm.Has(Perms.rework_refurbish_request_back.Key());

    /// <summary>B2 — quản lý FA xác nhận.</summary>
    private bool MayApproveFa => Perm.Has(Perms.rework_refurbish_approve_fa.Key());

    /// <summary>B3 — SCS WH quét pallet giao hàng.</summary>
    private bool MayProcess => Perm.Has(Perms.rework_refurbish_process.Key());

    // Nút = QUYỀN **AND** ĐÚNG BƯỚC. Lớp "đúng bước" là thứ làm cho xác nhận có
    // nghĩa: role khai sai cũng không nhảy được bước, và server còn chặn lần
    // nữa bằng điều kiện bước nằm trong câu UPDATE.

    private bool CanRequestBack(ReturnInstructionDto d)
        => MayRequestBack && d.Back.CanRequest;

    /// <summary>Sửa ghi chú: chỉ FA, chỉ khi còn chờ quản lý FA.</summary>
    private bool CanEditBackNote(ReturnInstructionDto d)
        => MayRequestBack && d.Back.Status == BackStatus.FaRequested;

    private bool CanApproveBack(ReturnInstructionDto d)
        => MayApproveFa && d.Back.Status == BackStatus.FaRequested;

    /// <summary>B3 — giao hàng. Gọi được NHIỀU LẦN: giao dần từng xe.</summary>
    private bool CanDeliverBack(ReturnInstructionDto d)
        => MayProcess && d.Back.Status == BackStatus.FaApproved;

    /// <summary>
    /// Huỷ: ai đang giữ bước cũng phải dừng được, không phải chờ bên kia.
    /// ĐÃ GIAO ĐƯỢC CON NÀO thì KHÔNG huỷ — hàng ở FA rồi, huỷ là để lại một lô
    /// hàng ở FA mà không có đề nghị nào đứng tên.
    /// </summary>
    private bool CanCancelBack(ReturnInstructionDto d)
        => d.Back.IsOpen && !d.Back.IsPartlyDelivered
           && (MayRequestBack || MayApproveFa || MayProcess);

    /// <summary>
    /// Quyền sửa cấu hình email là quyền HỆ THỐNG (<c>email_config.update</c>),
    /// không phải quyền của màn này — ai sửa được mail của module khác thì cũng
    /// sửa được ở đây. Cùng cách với màn Hàng bất thường.
    /// </summary>
    private bool MayEmailConfig => Perm.Has(Perms.email_config_update.Key());

    /// <summary>Dialog cấu hình 2 mail của quy trình back hàng.</summary>
    private bool _mailCfgOpen;

    private int FormTotalQty => _form?.Lines.Sum(l => l.Qty) ?? 0;

    /// <summary>
    /// Ngày về dự kiến tách riêng khỏi DTO: input type=date bind vào
    /// <c>DateTime?</c> được, nhưng để nguyên trong DTO thì phần giờ của
    /// DateTime.MinValue lọt xuống API. Gán lại lúc Lưu.
    /// </summary>
    private DateTime? _formExpectedDate;

    protected override async Task OnInitializedAsync()
    {
        // Mail báo FA mang link kèm ?docNo=... — mở link là lọc sẵn đúng phiếu,
        // người nhận không phải tự tìm trong danh sách.
        if (QueryHelpers.ParseQuery(new Uri(Nav.Uri).Query).TryGetValue("docNo", out var docNo))
        {
            _keyword = docNo.ToString();
            _status = null;                 // phiếu có thể đã đóng
        }

        await LoadModels();
        await Load();
    }

    /// <summary>
    /// Trang lấy mỗi lần khi nạp danh mục model. Cùng giá trị với
    /// <c>PartCards.MasterFetchSize</c> — hai màn cùng nạp toàn bộ danh mục
    /// nên dùng chung một cỡ trang để hành vi giống nhau.
    /// </summary>
    private const int ModelFetchSize = 9999;

    /// <summary>
    /// Nạp mã model một lần cho datalist, thay vì gọi lại server theo từng ký
    /// tự gõ: danh mục model của nhà máy cỡ vài nghìn dòng, tải một lần rẻ hơn
    /// nhiều so với một request mỗi lần gõ.
    ///
    /// Lặp theo trang cho tới khi hết, đúng cách <c>PartCards</c> đang làm:
    /// xin một trang thật lớn rồi tin là đã lấy hết là sai khi danh mục vượt
    /// cỡ trang, và lỗi đó im lặng — vài model cuối bảng chữ cái đơn giản là
    /// không gợi ý được.
    /// </summary>
    private async Task LoadModels()
    {
        var codes = new List<string>();
        try
        {
            for (var page = 1; ; page++)
            {
                // PagedQuery dùng tên `Size`, KHÔNG phải `PageSize`.
                var res = await ModelApi.GetAllAsync(
                    new ModelQuery { Page = page, Size = ModelFetchSize });

                var items = res.Items;
                if (items is null || items.Count == 0) break;

                codes.AddRange(items.Select(m => m.Code).Where(c => !string.IsNullOrWhiteSpace(c)));

                if (items.Count < ModelFetchSize) break;
            }
        }
        catch
        {
            // Datalist chỉ là gợi ý gõ nhanh. Tải hỏng thì vẫn nhập tay được,
            // và server vẫn kiểm model có trong danh mục hay không — nên nuốt
            // lỗi ở đây thay vì chặn cả màn hình.
        }

        _models = codes.Distinct(StringComparer.OrdinalIgnoreCase)
                       .OrderBy(c => c, StringComparer.OrdinalIgnoreCase)
                       .ToList();
    }

    private void SetStatus(string? s) { _status = s; _ = Load(); }

    private async Task OnKeywordKey(Microsoft.AspNetCore.Components.Web.KeyboardEventArgs e)
    {
        if (e.Key == "Enter") await Load();
    }

    private async Task Load()
    {
        _loading = true; _error = null; CloseMenu(); StateHasChanged();
        try
        {
            _rows = await Api.GetListAsync(
                status: _status,
                goodsType: string.IsNullOrWhiteSpace(_goodsType) ? null : _goodsType,
                keyword: string.IsNullOrWhiteSpace(_keyword) ? null : _keyword.Trim(),
                fromDate: _fromDate,
                toDate: _toDate);

            // Phiếu đang mở rộng mà biến mất khỏi kết quả lọc thì thu lại,
            // nếu không sẽ còn một hàng chi tiết mồ côi.
            if (_expanded is { } id && _rows.All(r => r.Id != id)) _expanded = null;

            // Bảng pallet nạp lazy — xoá cache để lần bung sau đọc lại số mới.
            _pallets.Clear();
            _backDeliveries.Clear();
            if (_expanded is { } stillOpen)
            {
                _ = LoadPallets(stillOpen);
                _ = LoadBackDeliveries(stillOpen);
            }
        }
        catch (Exception ex) { _error = Describe(ex); }
        finally { _loading = false; StateHasChanged(); }
    }

    private void Toggle(long id)
    {
        CloseMenu();
        _expanded = _expanded == id ? null : id;
        if (_expanded != id) return;
        _ = LoadPallets(id);
        _ = LoadBackDeliveries(id);
    }

    /// <summary>
    /// Pallet của một phiếu. Nạp lại mỗi lần bung: WH đang quét hàng trong lúc
    /// Office mở màn này, cache lại là Office nhìn số cũ mà không biết.
    /// Lỗi thì coi như không có pallet — không chặn cả màn hình vì một bảng con.
    /// </summary>
    private async Task LoadPallets(long docId)
    {
        _pallets.Remove(docId);
        StateHasChanged();
        try
        {
            _pallets[docId] = await Api.GetPalletsAsync(docId);
        }
        catch
        {
            _pallets[docId] = new List<ReturnPalletDto>();
        }
        StateHasChanged();
    }

    // ── tạo / sửa ───────────────────────────────────────────

    private void OpenCreate()
    {
        _editId = null;
        _editDocNo = null;
        _formError = null;
        _formExpectedDate = null;
        // Mặc định theo tab loại đang lọc: người dùng đang xem Rework thì
        // gần như chắc chắn đang tạo phiếu Rework.
        _form = new ReturnInstructionRequestDto
        {
            GoodsType = string.IsNullOrWhiteSpace(_goodsType) ? ReturnGoodsType.Rework : _goodsType,
        };
        AddLine();
    }

    private void OpenEdit(ReturnInstructionDto d)
    {
        CloseMenu();
        _editId = d.Id;
        _editDocNo = d.DocNo;
        _formError = null;
        _formExpectedDate = d.ExpectedDate;
        _form = new ReturnInstructionRequestDto
        {
            GoodsType = d.GoodsType,
            Customer = d.Customer,
            Note = d.Note,
            // COPY sang object mới, không trỏ thẳng vào _rows: người dùng sửa
            // rồi bấm Huỷ thì bảng nền phải nguyên như cũ.
            Lines = d.Lines.Select(l => new ReturnInstructionLineRequestDto
            {
                Model = l.Model,
                Qty = l.Qty,
                Note = l.Note,
            }).ToList(),
        };
        if (_form.Lines.Count == 0) AddLine();
    }

    private void CloseForm() { _form = null; _formError = null; }

    private void AddLine() => _form?.Lines.Add(new ReturnInstructionLineRequestDto { Qty = 1 });

    private void RemoveLine(int idx)
    {
        if (_form is null || idx < 0 || idx >= _form.Lines.Count) return;
        _form.Lines.RemoveAt(idx);
        // Luôn chừa lại một dòng trống: bảng rỗng trông như hỏng, và người
        // dùng phải đi tìm nút Thêm dòng.
        if (_form.Lines.Count == 0) AddLine();
    }

    private async Task Save()
    {
        if (_form is null) return;

        // Kiểm sơ ở client để người dùng khỏi chờ một vòng mạng mới biết
        // thiếu ô. Server vẫn kiểm lại đầy đủ — đây chỉ là lớp cho nhanh.
        var lines = _form.Lines
            .Where(l => !string.IsNullOrWhiteSpace(l.Model))
            .ToList();

        if (lines.Count == 0) { _formError = L["Return.Err.LinesRequired"]; return; }
        if (lines.Any(l => l.Qty <= 0)) { _formError = L["Return.Err.QtyPositive"]; return; }

        // Loại hàng đã ở đầu phiếu nên trùng chỉ còn xét theo model.
        var dup = lines.GroupBy(l => l.Model.Trim().ToUpperInvariant())
                       .FirstOrDefault(g => g.Count() > 1);
        if (dup is not null)
        {
            _formError = L["Return.Err.DuplicateLine", dup.First().Model];
            return;
        }

        _saving = true; _formError = null; StateHasChanged();
        try
        {
            var body = new ReturnInstructionRequestDto
            {
                GoodsType = _form.GoodsType,
                Customer = _form.Customer,
                ExpectedDate = _formExpectedDate?.Date,
                Note = _form.Note,
                Lines = lines.Select(l => new ReturnInstructionLineRequestDto
                {
                    Model = l.Model.Trim(),
                    Qty = l.Qty,
                    Note = string.IsNullOrWhiteSpace(l.Note) ? null : l.Note.Trim(),
                }).ToList(),
            };

            if (_editId is { } id) await Api.UpdateAsync(id, body);
            else await Api.CreateAsync(body);

            _form = null;
            await Load();
        }
        catch (Exception ex) { _formError = Describe(ex); }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── xoá ─────────────────────────────────────────────────

    private void AskDelete(ReturnInstructionDto d)
    {
        CloseMenu();
        _deleting = d;
    }

    private async Task ConfirmDelete()
    {
        if (_deleting is null) return;
        _saving = true; StateHasChanged();
        try
        {
            await Api.DeleteAsync(_deleting.Id);
            _deleting = null;
            await Load();
        }
        catch (Exception ex) { _error = Describe(ex); _deleting = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── chốt thực nhận / mở lại (mục 2b) ────────────────────

    private void AskClose(ReturnInstructionDto d)
    {
        CloseMenu();
        _closing = d;
    }

    private void AskReopen(ReturnInstructionDto d)
    {
        CloseMenu();
        _reopening = d;
    }

    /// <summary>
    /// Chốt thực nhận. Server đóng phiếu RỒI tự gửi mail báo FA số thực tế —
    /// nên dialog phải cho người bấm xem bảng lệch trước, vì đó chính là nội
    /// dung FA sẽ đọc.
    /// </summary>
    private async Task ConfirmClose()
    {
        if (_closing is null) return;

        _saving = true; StateHasChanged();
        try
        {
            var saved = await Api.CloseAsync(_closing.Id);
            _closing = null;
            await Load();

            // Mail hỏng KHÔNG làm đổ việc chốt — nói ra để Office biết mà xử
            // lý tay, thay vì tưởng FA đã nhận được số.
            if (saved.ActualMailSentAt is null)
                _error = L["Return.ClosedButMailFailed", saved.DocNo];
        }
        catch (Exception ex) { _error = Describe(ex); _closing = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    private async Task ConfirmReopen()
    {
        if (_reopening is null) return;

        _saving = true; StateHasChanged();
        try
        {
            await Api.ReopenAsync(_reopening.Id);
            _reopening = null;
            await Load();
        }
        catch (Exception ex) { _error = Describe(ex); _reopening = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── hiển thị lệch ───────────────────────────────────────

    /// <summary>Số lệch kèm dấu: <c>+6</c> / <c>-6</c> / <c>0</c>.</summary>
    private static string Signed(int qty) => qty > 0 ? $"+{qty:N0}" : qty.ToString("N0");

    private static string DiffClass(int qty) =>
        qty > 0 ? "ri-over" : qty < 0 ? "ri-short" : "ri-done";

    private static string DiffPill(int qty) =>
        qty > 0 ? "warn" : qty < 0 ? "st-short" : "ok";

    private string DiffState(int qty) =>
        qty > 0 ? L["Return.Diff.Over"]
        : qty < 0 ? L["Return.Diff.Short"]
        : L["Return.Diff.Exact"];

    // ── huỷ một lần nhận ────────────────────────────────────

    private void AskReleasePallet(ReturnInstructionDto doc, ReturnPalletDto pallet)
        => _releasing = (doc, pallet);

    /// <summary>
    /// Huỷ pallet đã nhận. Việc QUAN TRỌNG là nó giải phóng serial khỏi sổ:
    /// không có đường này thì một pallet quét sai khoá vĩnh viễn những con hàng
    /// đó khỏi mọi phiếu về sau.
    /// </summary>
    private async Task ConfirmReleasePallet()
    {
        if (_releasing is not { } r) return;

        _saving = true; StateHasChanged();
        try
        {
            await Api.ReleasePalletAsync(r.Doc.Id, r.Pallet.Id);
            _releasing = null;
            await Load();                 // SL thực nhận đã đổi
            await LoadPallets(r.Doc.Id);  // bảng pallet cũng đã đổi
        }
        catch (Exception ex) { _error = Describe(ex); _releasing = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    /// <summary>
    // ═══════════════ Mục 2c · luồng nhận lại hàng về FA ═══════════════

    /// <summary>
    /// Nhật ký pallet đã giao theo từng phiếu, nạp LAZY khi bung dòng — cùng lý
    /// do với <see cref="_pallets"/>. Không có khoá = đang nạp.
    /// </summary>
    private readonly Dictionary<long, List<BackDeliveryDto>> _backDeliveries = new();

    private List<BackDeliveryDto> DeliveriesOf(long docId)
        => _backDeliveries.TryGetValue(docId, out var v) ? v : new();

    private async Task LoadBackDeliveries(long docId)
    {
        _backDeliveries.Remove(docId);
        try
        {
            _backDeliveries[docId] = await Api.GetBackDeliveriesAsync(docId);
        }
        catch
        {
            // Nhật ký là thông tin tham khảo. Tải hỏng thì coi như chưa giao gì
            // — không chặn cả màn hình vì một bảng con.
            _backDeliveries[docId] = new List<BackDeliveryDto>();
        }
        StateHasChanged();
    }

    /// <summary>Nhãn trạng thái luồng back. null = chưa ai đề nghị.</summary>
    private string BackLabel(ReturnInstructionDto d) => d.Back.Status switch
    {
        null => L["Return.Back.St.None"],
        BackStatus.FaRequested => L["Return.Back.St.FaRequested"],
        BackStatus.FaApproved => L["Return.Back.St.FaApproved"],
        BackStatus.Delivered => L["Return.Back.St.Delivered"],
        BackStatus.Cancelled => L["Return.Back.St.Cancelled"],
        var s => s,
    };

    /// <summary>Lớp CSS của chip trạng thái — dùng chuỗi status làm hậu tố.</summary>
    private static string BackPill(ReturnInstructionDto d)
        => d.Back.Status is null ? "bk-none" : $"bk-{d.Back.Status}";

    private sealed record BackStepCell(string LabelKey, string Who, string State);

    /// <summary>
    /// Ba mốc của luồng back. Hiện cả người và lúc: "đang chờ SCS giao hàng" mà
    /// không biết chờ từ bao giờ thì không ai biết có phải đi nhắc hay không.
    ///
    /// Mốc cuối ghi "đang giao dở" khi đã giao được pallet nào mà chưa hết —
    /// một cột trống ở đó làm WH tưởng chưa ai làm gì và quét lại từ đầu.
    /// </summary>
    private List<BackStepCell> BackTrail(ReturnInstructionDto d)
    {
        const string done = "done";
        const string wait = "wait";
        const string idle = "idle";

        var b = d.Back;

        string W(string? who, DateTime? at)
            => at is null ? "—" : $"{who} · {at:dd/MM HH:mm}";

        var faState = b.ApprovedAt is not null ? done
            : b.IsOpen && b.Step == BackStep.FaApprove ? wait : idle;

        var dlState = b.IsDelivered ? done
            : b.IsOpen && b.Step == BackStep.ScsDeliver ? wait : idle;

        var dlWho = b.IsDelivered
            ? W(b.DeliveredBy, b.DeliveredAt)
            : b.IsPartlyDelivered
                ? L["Return.Back.Partly", b.SentQty, b.SentQty + b.RemainQty].Value
                : "—";

        return
        [
            new("Return.Back.Step.Requested", W(b.RequestedBy, b.RequestedAt), done),
            new("Return.Back.Step.FaApprove", W(b.ApprovedBy, b.ApprovedAt), faState),
            new("Return.Back.Step.ScsDeliver", dlWho, dlState),
        ];
    }

    // ── Dialog đề nghị / sửa ghi chú ──

    private ReturnInstructionDto? _backForm;
    private bool _backFormIsEdit;
    private string? _backNote;

    /// <summary>
    /// SL còn ở kho theo model — CHỈ ĐỂ XEM. Lấy là lấy hết nên đây đồng thời
    /// là đúng phần hàng sẽ sang FA. null = đang nạp.
    /// </summary>
    private List<BackRemainModelDto>? _backRemain;

    private async Task OpenBackForm(ReturnInstructionDto d, bool isEdit)
    {
        CloseMenu();
        _backForm = d;
        _backFormIsEdit = isEdit;
        _backNote = isEdit ? d.Back.Note : null;
        _backRemain = null;
        _formError = null;
        StateHasChanged();

        try
        {
            _backRemain = await Api.GetBackRemainAsync(d.Id);
        }
        catch (Exception ex)
        {
            _formError = Describe(ex);
            _backRemain = new List<BackRemainModelDto>();
        }
        StateHasChanged();
    }

    private void CloseBackForm()
    {
        _backForm = null;
        _backRemain = null;
        _formError = null;
    }

    private int BackRemainTotal => _backRemain?.Sum(x => x.Qty) ?? 0;

    private async Task SubmitBackForm()
    {
        if (_backForm is null) return;
        var id = _backForm.Id;
        _saving = true; _formError = null; StateHasChanged();
        try
        {
            var body = new RequestBackRequestDto { Note = Blank(_backNote) };
            if (_backFormIsEdit)
                await Api.UpdateBackNoteAsync(id, body);
            else
                await Api.RequestBackAsync(id, body);

            CloseBackForm();
            await Load();
        }
        catch (Exception ex) { _formError = Describe(ex); }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── Dialog xác nhận / huỷ ──

    private enum BackAction { Approve, Cancel }

    private ReturnInstructionDto? _backAsking;
    private BackAction _backAction;
    private string? _backComment;

    private string BackAskTitleKey => _backAction == BackAction.Approve
        ? "Return.Back.ApproveTitle"
        : "Return.Back.CancelTitle";

    private string BackAskConfirmKey => _backAction == BackAction.Approve
        ? "Return.Back.Approve"
        : "Return.Back.Cancel";

    private void AskBack(ReturnInstructionDto d, BackAction action)
    {
        CloseMenu();
        _backAsking = d;
        _backAction = action;
        _backComment = null;
        _formError = null;
    }

    private void CloseBackAsk()
    {
        _backAsking = null;
        _formError = null;
    }

    private async Task ConfirmBackAsk()
    {
        if (_backAsking is null) return;
        var id = _backAsking.Id;
        _saving = true; _formError = null; StateHasChanged();
        try
        {
            var body = new BackDecisionRequestDto { Comment = Blank(_backComment) };
            if (_backAction == BackAction.Approve)
                await Api.ApproveBackAsync(id, body);
            else
                await Api.CancelBackAsync(id, body);

            CloseBackAsk();
            await Load();
        }
        catch (Exception ex)
        {
            // Lỗi hay gặp nhất ở đây là "có người vừa xử lý trước" (409). Giữ
            // dialog mở để người dùng đọc được câu đó, rồi tải lại danh sách để
            // họ thấy trạng thái mới.
            _formError = Describe(ex);
            await Load();
        }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── Dialog giao hàng (B3) ──
    //
    // Chỗ QUÉT thật là PDA — WH đứng cạnh pallet với máy quét. Dialog này là
    // đường NHẬP TAY cho văn phòng: dán danh sách Pallet ID, mỗi dòng một mã.
    // Vẫn gọi đúng endpoint của PDA nên hai đường không lệch nghiệp vụ.

    private ReturnInstructionDto? _delivering;
    private string _lotText = "";
    private string? _deliverComment;
    private BackDeliverResultDto? _deliverResult;

    /// <summary>
    /// Mỗi dòng một mã. Tách theo DÒNG chứ không theo dấu phẩy: máy quét và
    /// Excel đều xuống dòng, còn Pallet ID thì không chứa dấu phẩy nên tách
    /// kiểu kia chỉ thêm cách gõ sai.
    /// </summary>
    private List<string> ParsedLots
        => _lotText.Split(['\n', '\r'], StringSplitOptions.RemoveEmptyEntries)
            .Select(x => x.Trim())
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

    private async Task OpenDeliver(ReturnInstructionDto d)
    {
        CloseMenu();
        _delivering = d;
        _lotText = "";
        _deliverComment = null;
        _deliverResult = null;
        _formError = null;
        await LoadBackDeliveries(d.Id);
    }

    private void CloseDeliver()
    {
        _delivering = null;
        _deliverResult = null;
        _formError = null;
    }

    private async Task ConfirmDeliver()
    {
        if (_delivering is null) return;
        var lots = ParsedLots;
        if (lots.Count == 0) return;

        var id = _delivering.Id;
        _saving = true; _formError = null; _deliverResult = null; StateHasChanged();
        try
        {
            _deliverResult = await Api.DeliverBackAsync(id, new DeliverBackRequestDto
            {
                LotNos = lots,
                Comment = Blank(_deliverComment),
            });

            // Chỉ xoá ô mã khi server ĐÃ nhận: xoá trước rồi gọi hỏng là WH
            // phải nhập lại cả xe.
            _lotText = "";

            await Load();
            await LoadBackDeliveries(id);

            // Giao XONG cả phiếu thì đóng dialog — không còn gì để quét. Còn dở
            // dang thì GIỮ MỞ kèm kết quả lượt vừa rồi: WH làm tiếp xe sau, mà
            // đóng ra mở lại là mất danh sách mã vừa sai.
            if (_deliverResult.Completed) { CloseDeliver(); return; }

            _delivering = _rows.FirstOrDefault(x => x.Id == id) ?? _delivering;
        }
        catch (Exception ex) { _formError = Describe(ex); }
        finally { _saving = false; StateHasChanged(); }
    }

    /// <summary>Ô trống gửi lên thành NULL, không phải chuỗi rỗng.</summary>
    private static string? Blank(string? s)
        => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    /// <summary>
    /// Câu lỗi hiện cho người dùng. API trả envelope {status, title, ...} và
    /// <c>title</c> ĐÃ là câu đã dịch, nên ưu tiên dùng nguyên câu đó thay vì
    /// một câu chung chung — nó nói rõ model nào sai, phiếu nào khoá.
    /// </summary>
    private string Describe(Exception ex) =>
        ex is Refit.ApiException api && !string.IsNullOrWhiteSpace(api.Content)
            ? ExtractTitle(api.Content) ?? api.Message
            : ex.Message;

    private static string? ExtractTitle(string content)
    {
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(content);
            return doc.RootElement.TryGetProperty("title", out var t) ? t.GetString() : null;
        }
        catch { return null; }
    }
}
