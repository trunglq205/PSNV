// core/utils/feedback/app_feedback.dart
abstract interface class AppFeedback {
  /// Báo lỗi: bíp tone lỗi + rung 2 nhịp.
  Future<void> error();

  /// Báo thành công: bíp ngắn + rung nhẹ.
  Future<void> success();
}