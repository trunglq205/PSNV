namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

/// <summary>
/// Một chỉ thị back hàng. Tên trường khớp JSON camelCase mà API trả về
/// (<c>ReturnInstructionResponse</c>) — Refit dùng System.Text.Json với chính
/// sách mặc định nên không cần khai thuộc tính đặt tên.
/// </summary>
public class ReturnInstructionDto
{
    public long Id { get; set; }

    /// <summary>RW-yyyyMMdd-### (rework) | RB-yyyyMMdd-### (refurbish).</summary>
    public string DocNo { get; set; } = string.Empty;

    /// <summary>
    /// rework | refurbish. MỘT PHIẾU MỘT LOẠI — loại nằm ở phiếu, không ở dòng.
    /// </summary>
    public string GoodsType { get; set; } = ReturnGoodsType.Rework;

    public string? Customer { get; set; }
    public DateTime? ExpectedDate { get; set; }

    /// <summary>open | completed | cancelled.</summary>
    public string DocStatus { get; set; } = ReturnDocStatus.Open;

    public string? Note { get; set; }
    public int ModelCount { get; set; }
    public int TotalQty { get; set; }

    /// <summary>SL thực nhận = số serial WH đã quét vào phiếu (mục 2a).</summary>
    public int ReceivedQty { get; set; }

    /// <summary>
    /// Có model nhận vượt SL chỉ thị. Cảnh báo, không phải lỗi — hàng về nhiều
    /// hơn khách báo là chuyện thường.
    /// </summary>
    public bool OverReceived { get; set; }

    /// <summary>Có model nhận thiếu. Cũng chỉ là cảnh báo.</summary>
    public bool ShortReceived { get; set; }

    /// <summary>Lệch cả phiếu = thực nhận − chỉ thị. Dương vượt, âm thiếu.</summary>
    public int DiffQty { get; set; }

    /// <summary>WH đã chốt SL thực nhận lúc nào. NULL = chưa chốt.</summary>
    public DateTime? ClosedAt { get; set; }
    public string? ClosedBy { get; set; }

    /// <summary>
    /// Đã báo FA SỐ THỰC NHẬN lúc nào — khác <see cref="MailSentAt"/> là mail
    /// lúc tạo phiếu.
    /// </summary>
    public DateTime? ActualMailSentAt { get; set; }
    public string? ActualMailSentTo { get; set; }

    /// <summary>Đã báo FA lúc nào. NULL = chưa gửi được, xem MailSentTo.</summary>
    public DateTime? MailSentAt { get; set; }
    public string? MailSentTo { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    /// <summary>
    /// Mục 2c — luồng nhận lại hàng về FA, GỘP vào chính phiếu này.
    ///
    /// Luôn có giá trị (API dựng từ phiếu), <c>Back.Status</c> null = FA chưa
    /// đề nghị gì. Khởi tạo sẵn một bản rỗng để màn hình không phải kiểm null
    /// ở ba chục chỗ — một phiếu cũ do JSON thiếu trường thì vẫn đọc được.
    /// </summary>
    public BackFlowDto Back { get; set; } = new();

    public List<ReturnInstructionLineDto> Lines { get; set; } = new();

    public bool IsOpen =>
        string.Equals(DocStatus, ReturnDocStatus.Open, StringComparison.OrdinalIgnoreCase);

    /// <summary>Đã đóng — mở lại được. Khác với đã huỷ.</summary>
    public bool IsCompleted =>
        string.Equals(DocStatus, ReturnDocStatus.Completed, StringComparison.OrdinalIgnoreCase);

    /// <summary>Đã nhận được hàng — điều kiện để chốt thực nhận.</summary>
    public bool HasReceipt => ReceivedQty > 0;
}

/// <summary>
/// Trạng thái luồng nhận lại hàng về FA của một phiếu (mục 2c).
///
/// Mọi cờ và con số do API tính rồi trả xuống — web KHÔNG tự suy lại:
/// <c>RemainQty</c> đếm từ sổ serial, và tính lại bằng phép trừ ở đây là sớm
/// muộn ra số khác (con đã đánh <c>ng</c> không còn chờ giao).
/// </summary>
public class BackFlowDto
{
    /// <summary>
    /// null = FA chưa đề nghị gì. Ngoài ra: fa_requested | fa_approved |
    /// scs_approved | delivered | cancelled.
    /// </summary>
    public string? Status { get; set; }

    /// <summary>
    /// Bước đang chờ ai: fa_approve | scs_approve | scs_deliver | done.
    /// null = chưa đề nghị. API suy từ <see cref="Status"/>, DB không có cột này.
    /// </summary>
    public string? Step { get; set; }

    public bool Requested { get; set; }
    public bool IsOpen { get; set; }
    public bool IsDelivered { get; set; }

    /// <summary>Đã giao được con nào nhưng chưa xong — mốc KHÔNG huỷ được nữa.</summary>
    public bool IsPartlyDelivered { get; set; }

    public bool IsCancelled { get; set; }

    /// <summary>FA đề nghị được chưa: phiếu chưa huỷ, còn hàng, chưa có đề nghị.</summary>
    public bool CanRequest { get; set; }

    /// <summary>
    /// SCS WH được tách pallet và quét giao chưa — tức đã qua bước quản lý SCS
    /// duyệt và còn hàng ở kho.
    ///
    /// Do API tính, KHÔNG tự suy lại từ <see cref="Status"/> ở đây: ba nơi gác
    /// nút (controller, màn này, màn PDA) mà mỗi nơi tự suy thì lệch một chỗ là
    /// hoặc thấy nút rồi ăn 403, hoặc có quyền mà không thấy nút.
    /// </summary>
    public bool CanDeliver { get; set; }

    /// <summary>Còn ở kho SCS, chưa giao lần nào.</summary>
    public int RemainQty { get; set; }

    /// <summary>Đã TỪNG giao sang FA (kể cả sau đó FA đã trả lại).</summary>
    public int SentQty { get; set; }

    /// <summary>Đang ở FA lúc này.</summary>
    public int AtFaQty { get; set; }

    /// <summary>FA đã trả về SCS.</summary>
    public int ReturnedQty { get; set; }

    public string? Note { get; set; }
    public string? RequestedBy { get; set; }
    public DateTime? RequestedAt { get; set; }
    public string? ApprovedBy { get; set; }
    public DateTime? ApprovedAt { get; set; }
    public string? FaComment { get; set; }

    /// <summary>Quản lý SCS xác nhận (thêm 10/11).</summary>
    public string? ScsApprovedBy { get; set; }
    public DateTime? ScsApprovedAt { get; set; }

    public string? DeliveredBy { get; set; }
    public DateTime? DeliveredAt { get; set; }

    /// <summary>Ý kiến phía SCS — dùng chung cho bước duyệt và lượt giao cuối.</summary>
    public string? ScsComment { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    /// <summary>
    /// SL FA xin lấy về theo model.
    ///
    /// RỖNG nghĩa là xin TOÀN BỘ phần còn ở kho — hoặc là phiếu được đề nghị
    /// trước 10/11, lúc đó chưa có chỗ nhập một phần. Màn hình phải chịu được
    /// rỗng, đừng coi rỗng là lỗi.
    /// </summary>
    public List<BackReqLineDto> Lines { get; set; } = new();

    /// <summary>
    /// LẦN đề nghị đang mở; 0 = chưa đề nghị lần nào (thêm 12/11).
    /// </summary>
    public int Round { get; set; }

    /// <summary>Lượt sắp tới là ĐỀ NGHỊ TIẾP, không phải lần đầu.</summary>
    public bool CanRequestAgain { get; set; }

    /// <summary>
    /// Mỗi LẦN đề nghị một dòng, cũ trước mới — vẽ thành các tiến trình con.
    ///
    /// RỖNG với phiếu chưa đề nghị, và cũng rỗng khi DB chưa chạy
    /// <c>return_back_round_schema.sql</c>. Màn hình phải chịu được rỗng: lúc
    /// đó lùi về tiến trình MỘT lớp như trước 12/11.
    /// </summary>
    public List<BackRoundDto> Rounds { get; set; } = new();
}

/// <summary>Một dòng FA xin: model + SL + đã giao được bao nhiêu của lần này.</summary>
public class BackReqLineDto
{
    public string Model { get; set; } = string.Empty;
    public int ReqQty { get; set; }

    /// <summary>
    /// Đã giao bao nhiêu con của model này TRONG lần đang mở. API tính; đừng
    /// suy từ SentQty của phiếu — con số đó là tổng của mọi lần.
    /// </summary>
    public int DeliveredQty { get; set; }
}

/// <summary>
/// Một LẦN đề nghị: đủ mốc để vẽ một tiến trình con bốn bước, kèm "xin bao
/// nhiêu / đã giao bao nhiêu" của riêng lần đó.
/// </summary>
public class BackRoundDto
{
    public int Round { get; set; }

    /// <summary>null = lần đó xin TOÀN BỘ phần còn ở kho.</summary>
    public int? AskedQty { get; set; }

    public int DeliveredQty { get; set; }

    /// <summary>Lần này đã đóng — giao xong hoặc bị huỷ.</summary>
    public bool IsClosed { get; set; }

    public string? Note { get; set; }
    public string? RequestedBy { get; set; }
    public DateTime? RequestedAt { get; set; }
    public string? FaApprovedBy { get; set; }
    public DateTime? FaApprovedAt { get; set; }
    public string? FaComment { get; set; }
    public string? ScsApprovedBy { get; set; }
    public DateTime? ScsApprovedAt { get; set; }
    public string? ScsComment { get; set; }
    public string? DeliveredBy { get; set; }
    public DateTime? DeliveredAt { get; set; }
    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }
}

/// <summary>
/// B1 / sửa ghi chú.
///
/// Từ 10/11 FA đề nghị được MỘT PHẦN nên có <see cref="Lines"/>. Gửi rỗng =
/// xin toàn bộ phần còn ở kho.
/// </summary>
public class RequestBackRequestDto
{
    public string? Note { get; set; }
    public List<BackReqLineDto> Lines { get; set; } = new();
}

/// <summary>Xác nhận / huỷ — một ô ý kiến dùng chung.</summary>
public class BackDecisionRequestDto
{
    public string? Comment { get; set; }
}

/// <summary>Một pallet đã giao.</summary>
public class BackDeliveryDto
{
    public string LotNo { get; set; } = string.Empty;
    public int SerialCount { get; set; }
    public DateTime DeliveredAt { get; set; }
    public string? DeliveredBy { get; set; }
}

/// <summary>SL còn ở kho theo model — màn đề nghị CHỈ XEM.</summary>
public class BackRemainModelDto
{
    public string Model { get; set; } = string.Empty;
    public int Qty { get; set; }
}

// BackDeliverResultDto đã XOÁ (11/11): không còn "một lượt quét giao" nào.
// BackDeliveryDto ở trên GIỮ LẠI — nhật ký pallet đã giao vẫn hiện trong
// dialog chi tiết phiếu, chỉ là dòng nhật ký giờ do luồng chuyển vị trí ghi.

/// <summary>
/// Giá trị <c>Back.Step</c>. GIỮ KHỚP <c>ReturnBackStep</c> bên API — lệch một
/// ký tự là tab hàng đợi rỗng mà không báo lỗi gì.
/// </summary>
public static class BackStep
{
    public const string FaApprove = "fa_approve";

    /// <summary>Chờ quản lý SCS xác nhận (thêm 10/11).</summary>
    public const string ScsApprove = "scs_approve";

    public const string ScsDeliver = "scs_deliver";
    public const string Done = "done";
}

/// <summary>Giá trị <c>Back.Status</c>. GIỮ KHỚP <c>ReturnBackStatus</c>.</summary>
public static class BackStatus
{
    public const string FaRequested = "fa_requested";
    public const string FaApproved = "fa_approved";

    /// <summary>Quản lý SCS đã duyệt — SCS WH được tách pallet và giao (10/11).</summary>
    public const string ScsApproved = "scs_approved";

    public const string Delivered = "delivered";
    public const string Cancelled = "cancelled";
}

public class ReturnInstructionLineDto
{
    public long Id { get; set; }
    public int LineNo { get; set; }
    public string Model { get; set; } = string.Empty;
    public int Qty { get; set; }

    /// <summary>SL thực nhận của model này — số serial đã quét vào phiếu.</summary>
    public int ReceivedQty { get; set; }

    /// <summary>Còn phải nhận. Âm = đã nhận vượt.</summary>
    public int RemainingQty { get; set; }

    /// <summary>Lệch = thực nhận − chỉ thị. Dương vượt, âm thiếu, 0 đủ.</summary>
    public int DiffQty { get; set; }

    public string? Note { get; set; }
}

/// <summary>
/// Một pallet hàng return WH đã nhận vào phiếu. Office chỉ XEM: pallet do WH
/// tạo trên PDA, màn Web không tạo được.
/// </summary>
public class ReturnPalletDto
{
    public long Id { get; set; }
    public string LotNo { get; set; } = string.Empty;
    public string? LocatorCode { get; set; }
    public int BoxCount { get; set; }
    public int SerialCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public List<ReturnPalletModelDto> Models { get; set; } = new();
}

public class ReturnPalletModelDto
{
    public string Model { get; set; } = string.Empty;
    public int SerialCount { get; set; }
}

/// <summary>Thân request tạo / sửa. Gửi nguyên danh sách dòng mong muốn.</summary>
public class ReturnInstructionRequestDto
{
    /// <summary>rework | refurbish. Khoá sau khi tạo — xem API.</summary>
    public string GoodsType { get; set; } = ReturnGoodsType.Rework;

    public string? Customer { get; set; }
    public DateTime? ExpectedDate { get; set; }
    public string? Note { get; set; }
    public List<ReturnInstructionLineRequestDto> Lines { get; set; } = new();
}

public class ReturnInstructionLineRequestDto
{
    public string Model { get; set; } = string.Empty;
    public int Qty { get; set; } = 1;
    public string? Note { get; set; }
}

/// <summary>
/// Giá trị cột <c>goods_type</c>, cũng là hậu tố khoá dịch
/// (<c>Return.GoodsType.*</c>). Trùng có chủ ý với
/// <c>wms.pallets.disposition</c> — xem ghi chú bên API.
/// </summary>
public static class ReturnGoodsType
{
    public const string Rework = "rework";
    public const string Refurbish = "refurbish";

    public static readonly string[] All = { Rework, Refurbish };
}

/// <summary>Giá trị cột <c>doc_status</c>, cũng là hậu tố khoá dịch.</summary>
public static class ReturnDocStatus
{
    public const string Open = "open";
    public const string Completed = "completed";
    public const string Cancelled = "cancelled";

    public static readonly string[] All = { Open, Completed, Cancelled };
}

// ──────────────── Mục 2d — nhật ký serial lệch ────────────────

/// <summary>
/// Một dòng nhật ký: serial FA quét ra mà không khớp sổ của phiếu.
///
/// Khớp <c>ReturnMismatchResponse</c> bên API. Tên trường là <c>Serial</c>
/// (không phải <c>SerialNo</c>) vì record bên kia khai vậy.
/// </summary>
public class ReturnMismatchDto
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public long? PalletId { get; set; }

    /// <summary>Pallet FA đang đóng lúc quét ra con lạ. Null khi lượt quét đó
    /// không sinh được pallet nào (không con nào khớp).</summary>
    public string? LotNo { get; set; }

    public string Serial { get; set; } = string.Empty;
    public string? Model { get; set; }

    /// <summary><see cref="ReturnMismatchReason"/>.</summary>
    public string Reason { get; set; } = string.Empty;

    public string? FoundStatus { get; set; }
    public string? OtherDocNo { get; set; }
    public DateTime ScannedAt { get; set; }
    public string? ScannedBy { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public string? ResolvedBy { get; set; }
    public string? ResolveNote { get; set; }
    public bool IsResolved { get; set; }
}

/// <summary>SCS đánh dấu đã xử lý một dòng nhật ký.</summary>
public class ResolveMismatchRequestDto
{
    public string? Note { get; set; }
}

/// <summary>
/// Trạng thái một dòng sổ serial — khớp <c>ReturnSerialStatus</c> bên API và
/// cột <c>return_instruction_serials.status</c>.
///
/// Mirror sang Web vì <c>ReturnMismatchDto.FoundStatus</c> là chuỗi thô từ API,
/// mà so chuỗi bằng literal rải khắp markup thì sai một ký tự là im lặng hiện
/// sai nhãn. Cùng khuôn với <see cref="ReturnGoodsType"/> và
/// <see cref="ReturnDocStatus"/> ở trên.
/// </summary>
public static class ReturnSerialStatus
{
    /// <summary>WH đã nhận vào kho SCS (mục 2a).</summary>
    public const string Received = "received";

    /// <summary>Đã giao sang FA (mục 2c).</summary>
    public const string AtFa = "at_fa";

    /// <summary>FA đã trả về SCS (mục 3).</summary>
    public const string Returned = "returned";

    /// <summary>Đã xuất cho khách (mục 10).</summary>
    public const string Shipped = "shipped";

    /// <summary>Hàng NG tại FA (mục 5).</summary>
    public const string Ng = "ng";
}

/// <summary>
/// Lý do một serial bị loại — khớp CHECK <c>ck_rsm_reason</c> và cũng là hậu tố
/// khoá dịch (<c>Return.Fa.Reason.*</c>).
/// </summary>
public static class ReturnMismatchReason
{
    /// <summary>Không có trong sổ của phiếu này, cũng không thuộc phiếu nào.</summary>
    public const string NotInDoc = "not_in_doc";

    /// <summary>Có trong phiếu này nhưng không ở <c>at_fa</c>.</summary>
    public const string WrongStatus = "wrong_status";

    /// <summary>Đang thuộc một phiếu khác.</summary>
    public const string OtherDoc = "other_doc";
}
