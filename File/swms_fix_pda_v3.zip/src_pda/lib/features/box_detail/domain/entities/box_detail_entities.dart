import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart';

/// Chi tiết box (Quick Scan / bấm box). Khớp BoxDetailResponse của API.
class BoxDetail {
  final int id;
  final String boxNo;
  final String? primaryModel;
  final int totalQty;
  final int serialCount;
  final String? customerPo;
  final String? psnvPo;
  final DateTime? productionDate;

  /// Trạng thái OQC. null = server chưa có giá trị hoặc trả key lạ.
  final InspectionStatus? oqcStatus;

  // Lot chứa box (Pallet ID = lot_no)
  final int lotId;
  final String lotNo;
  /// Null khi thùng không có tem QR gốc (thùng của pallet hàng return).
  final String? payload;

  // Vị trí — ăn theo lot chứa box
  final int? locatorId;
  final String? locatorCode;
  final String? areaCode;
  final String? areaName;

  // Danh sách serial
  final List<BoxSerial> serials;

  const BoxDetail({
    required this.id,
    required this.boxNo,
    required this.totalQty,
    required this.serialCount,
    required this.lotId,
    required this.lotNo,
    this.payload,
    this.primaryModel,
    this.customerPo,
    this.psnvPo,
    this.productionDate,
    this.oqcStatus,
    this.locatorId,
    this.locatorCode,
    this.areaCode,
    this.areaName,
    this.serials = const [],
  });

  bool get hasLocator => locatorId != null && locatorCode != null;

  /// Hiển thị khi chưa có trạng thái OQC.
  InspectionStatus get oqcStatusOrDefault =>
      oqcStatus ?? InspectionStatus.notInspected;

  /// Copy riêng cho PO — nhận null tường minh (null = xoá giá trị),
  /// nên không dùng copyWith tổng quát để tránh sentinel.
  BoxDetail copyWithPo({
    required String? customerPo,
    required String? psnvPo,
  }) => BoxDetail(
    id: id,
    boxNo: boxNo,
    primaryModel: primaryModel,
    totalQty: totalQty,
    serialCount: serialCount,
    customerPo: customerPo,
    psnvPo: psnvPo,
    productionDate: productionDate,
    oqcStatus: oqcStatus,
    lotId: lotId,
    lotNo: lotNo,
    payload: payload,
    locatorId: locatorId,
    locatorCode: locatorCode,
    areaCode: areaCode,
    areaName: areaName,
    serials: serials,
  );
}

class BoxSerial {
  final int id;
  final String serialNo;
  final String model;

  const BoxSerial({
    required this.id,
    required this.serialNo,
    required this.model,
  });
}
