namespace ShippingScs.Web.Services;

/// <summary>
/// Lịch làm việc đã nạp sẵn cho một khoảng ngày. Mọi hàm chạy trong bộ nhớ, không gọi DB,
/// nên Schedule Engine dùng trong vòng lặp hàng nghìn dòng FC/Demand thoải mái.
///
/// Ngày ngoài khoảng đã nạp, hoặc trong khoảng mà chưa có dòng trong dbo.WorkingDays,
/// ném <see cref="CalendarNotConfiguredException"/>. Không tự đoán ngày làm việc:
/// đoán sai làm lệch ETD mà không ai biết.
/// </summary>
public class WorkingCalendarSnapshot
{
    // Giới hạn số ngày dò khi tìm ngày làm việc (tránh lặp vô hạn nếu lịch toàn ngày nghỉ)
    private const int MaxScanDays = 366;

    private readonly IReadOnlyDictionary<DateOnly, bool> _days;

    public string CalendarCode { get; }
    public DateOnly From { get; }
    public DateOnly To { get; }

    /// <param name="days">Ngày -> có làm việc không. Phải phủ đủ [from, to].</param>
    public WorkingCalendarSnapshot(string calendarCode, DateOnly from, DateOnly to,
        IReadOnlyDictionary<DateOnly, bool> days)
    {
        if (to < from) throw new ArgumentException("to must be >= from", nameof(to));
        CalendarCode = calendarCode;
        From = from;
        To = to;
        _days = days;
    }

    public bool IsWorkingDay(DateOnly date)
    {
        if (date < From || date > To || !_days.TryGetValue(date, out var isWorking))
            throw new CalendarNotConfiguredException(CalendarCode, date);
        return isWorking;
    }

    /// <summary>
    /// Ngày làm việc thứ n (đếm từ 1) của tháng.
    /// Rule Long FC: ngày làm việc thứ 5 (PEWVN, CAT khác), thứ 9 (PAP-WAS).
    /// </summary>
    public DateOnly GetNthWorkingDayOfMonth(int year, int month, int n)
    {
        if (n < 1) throw new ArgumentOutOfRangeException(nameof(n), "n must be >= 1");

        var date = new DateOnly(year, month, 1);
        var count = 0;
        while (date.Month == month)
        {
            if (IsWorkingDay(date))
            {
                count++;
                if (count == n) return date;
            }
            date = date.AddDays(1);
        }

        throw new CalendarNotConfiguredException(CalendarCode, new DateOnly(year, month, 1),
            $"Tháng {month:00}/{year} lịch '{CalendarCode}' chỉ có {count} ngày làm việc, không có ngày thứ {n}.");
    }

    /// <summary>
    /// Cộng (n &gt; 0) hoặc trừ (n &lt; 0) n ngày làm việc, bỏ qua ngày nghỉ.
    /// n = 0 trả về chính ngày đó, kể cả khi là ngày nghỉ.
    /// Ex-factory AIR = AddWorkingDays(ETD, -1). Các đợt PAP-WAS cách nhau AddWorkingDays(d, 5).
    /// </summary>
    public DateOnly AddWorkingDays(DateOnly date, int n)
    {
        if (n == 0) return date;

        var step = n > 0 ? 1 : -1;
        var remaining = Math.Abs(n);
        var limit = MaxScanDays + remaining;
        var current = date;

        for (var scanned = 0; remaining > 0; scanned++)
        {
            if (scanned >= limit)
                throw new CalendarNotConfiguredException(CalendarCode, current,
                    $"Lịch '{CalendarCode}' không tìm được ngày làm việc gần {date:dd/MM/yyyy}.");
            current = current.AddDays(step);
            if (IsWorkingDay(current)) remaining--;
        }

        return current;
    }

    /// <summary>Chính ngày đó nếu là ngày làm việc, nếu không thì ngày làm việc kế tiếp.</summary>
    public DateOnly OnOrAfter(DateOnly date) => Scan(date, 1);

    /// <summary>Chính ngày đó nếu là ngày làm việc, nếu không thì ngày làm việc liền trước.</summary>
    public DateOnly OnOrBefore(DateOnly date) => Scan(date, -1);

    /// <summary>Số ngày làm việc trong [from, to], tính cả hai đầu.</summary>
    public int CountWorkingDays(DateOnly from, DateOnly to)
    {
        var count = 0;
        for (var d = from; d <= to; d = d.AddDays(1))
            if (IsWorkingDay(d)) count++;
        return count;
    }

    private DateOnly Scan(DateOnly date, int step)
    {
        var current = date;
        for (var i = 0; i <= MaxScanDays; i++)
        {
            if (IsWorkingDay(current)) return current;
            current = current.AddDays(step);
        }
        throw new CalendarNotConfiguredException(CalendarCode, date,
            $"Lịch '{CalendarCode}' không tìm được ngày làm việc gần {date:dd/MM/yyyy}.");
    }
}

public class CalendarNotConfiguredException : BusinessException
{
    public string CalendarCode { get; }
    public DateOnly Date { get; }

    public CalendarNotConfiguredException(string calendarCode, DateOnly date, string? message = null)
        : base(message ?? $"Lịch '{calendarCode}' chưa có dữ liệu ngày {date:dd/MM/yyyy}. Vào Lịch làm việc để sinh năm.")
    {
        CalendarCode = calendarCode;
        Date = date;
    }
}
