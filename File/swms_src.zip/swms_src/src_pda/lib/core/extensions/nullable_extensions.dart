/// Chuẩn hoá các giá trị "rỗng theo nhiều kiểu" về đúng MỘT dạng: null.
///
/// Dùng ở tầng data, ngay trước khi dựng request model. Gom thành extension vì
/// cùng phép chuẩn hoá này đang lặp ở Model / Pallet / PartCard — mà lặp thì
/// sớm muộn có chỗ quên trim rồi gửi " ABC " lên server, hoặc gửi 0 vào một FK
/// optional và ăn 400 mà không hiểu vì sao.
library;

extension StringNullableX on String? {
  /// Trim rồi quy chuỗi rỗng về null.
  ///
  /// Với cột UNIQUE (vd `master.models.gtin`) thì `""` và `NULL` KHÁC nhau:
  /// nhiều bản ghi cùng `""` sẽ đụng unique ngay ở bản ghi thứ hai, còn nhiều
  /// bản ghi cùng `NULL` thì không.
  String? get trimmedOrNull {
    final v = this?.trim();
    return (v == null || v.isEmpty) ? null : v;
  }
}

extension IntNullableX on int? {
  /// Giữ giá trị > 0; null / 0 / âm đều về null.
  ///
  /// Hợp với các FK optional bên server đang khai `[Range(1, int.MaxValue)]`.
  /// UI (chip, dropdown) thường trả 0 khi người dùng BỎ CHỌN — đó là ý "xoá
  /// gợi ý", không phải lỗi nhập liệu, nên đừng để nó thành 400.
  int? get positiveOrNull {
    final v = this;
    return (v != null && v > 0) ? v : null;
  }
}

extension IntListNullableX on List<int>? {
  /// Khử trùng + sắp tăng dần; null / rỗng đều về null.
  ///
  /// Khớp `RackRowRule.ToStorage` bên server. Cùng một tập giá trị chọn theo
  /// thứ tự khác nhau phải ra cùng một body, nếu không log/diff đầy thay đổi giả.
  ///
  /// KHÔNG lọc theo khoảng hợp lệ: luật đó thuộc về server. Lọc ở client sẽ tạo
  /// nguồn sự thật thứ hai, rồi khi server nới khoảng (rack thêm tầng) thì
  /// client âm thầm vứt giá trị hợp lệ — kiểu lệch không ai thấy lỗi.
  List<int>? get distinctSortedOrNull {
    final v = this;
    if (v == null || v.isEmpty) return null;
    return v.toSet().toList()..sort();
  }
}
