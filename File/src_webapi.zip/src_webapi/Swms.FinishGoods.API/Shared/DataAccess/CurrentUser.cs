﻿using System.Security.Claims;

namespace Swms.FinishGoods.API.Shared.DataAccess
{
    public class CurrentUser : ICurrentUser
    {
        private readonly IHttpContextAccessor _http;

        public CurrentUser(IHttpContextAccessor http) => _http = http;

        private ClaimsPrincipal? Principal => _http.HttpContext?.User;

        public long? UserId
        {
            get
            {
                var raw = Principal?.FindFirstValue(ClaimTypes.NameIdentifier);
                return long.TryParse(raw, out var id) ? id : null;
            }
        }

        public string? EmployeeCode => Principal?.FindFirstValue("employee_code"); // custom claim
        public string? FullName => Principal?.FindFirstValue(ClaimTypes.Name);

        public bool IsAuthenticated => Principal?.Identity?.IsAuthenticated ?? false;
    }
}
