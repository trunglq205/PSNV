using Swms.FinishGoods.API.Features.ReturnInstructions.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

public interface IReturnFaPalletService
{
    /// <summary>
    /// Sổ serial dạng gọn để PDA kiểm NGAY LÚC QUÉT, không chờ mạng từng con.
    /// </summary>
    Task<IReadOnlyList<ReturnSerialIndexResponse>> GetSerialIndexAsync(long docId);

    /// <summary>
    /// Mục 2d — FA đóng pallet mới sau rework.
    ///
    /// Serial khớp thì vào pallet; serial không khớp thì KHÔNG vào pallet nhưng
    /// được ghi nhật ký và trả về để FA đặt riêng ra ngay tại bàn.
    /// </summary>
    Task<CreateFaPalletResponse> CreateAsync(long docId, CreateFaPalletRequest request);

    Task<IReadOnlyList<ReturnMismatchResponse>> GetMismatchesAsync(long docId, bool openOnly);

    Task<ReturnMismatchResponse> ResolveMismatchAsync(long id, ResolveMismatchRequest request);
}
