using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentTrips;

public static class ShipmentTripModule
{
    /// <summary>Gọi trong Program.cs cạnh AddShipmentInstructionFeature().</summary>
    public static IServiceCollection AddShipmentTripFeature(this IServiceCollection services)
    {
        services.AddScoped<IShipmentTripService, ShipmentTripService>();
        services.AddScoped<IShipmentTripRepository, ShipmentTripRepository>();

        // Ảnh minh chứng hàng xuất (PDA upload, Web xem). IImageStorage dùng chung với phiếu bất thường.
        services.AddScoped<ITripPhotoService, TripPhotoService>();
        services.AddScoped<ITripPhotoRepository, TripPhotoRepository>();

        // Vanning trên PDA: kiểm container + gộp pallet / pallet đôi.
        // TripMergeService gọi IPalletService (Features/Pallets) — đăng ký bởi module Pallets.
        services.AddScoped<ITripVanningRepository, TripVanningRepository>();
        services.AddScoped<ITripInspectionService, TripInspectionService>();
        services.AddScoped<ITripMergeService, TripMergeService>();

        // Ghép cọc + xếp cont theo Stowage Plan của chuyến (đọc bảng stowage_*, ghi shipment_trip_columns).
        services.AddScoped<ITripStowageRepository, TripStowageRepository>();
        services.AddScoped<ITripStowageService, TripStowageService>();
        return services;
    }
}
