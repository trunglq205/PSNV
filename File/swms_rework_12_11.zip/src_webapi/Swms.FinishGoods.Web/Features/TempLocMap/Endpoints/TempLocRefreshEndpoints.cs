﻿using Swms.FinishGoods.Web.Features.MapView.Client;

namespace Swms.FinishGoods.Web.Features.TempLocMap.Endpoints;

/// <summary>
/// Proxy endpoint CÙNG ORIGIN cho realtime polling của màn hình chiếu.
///
/// Vì sao cần: JS trên trình duyệt fetch thẳng API (origin khác) sẽ không kèm
/// đúng auth (token nằm trong cookie của Web, Refit mới gắn vào header). Nên JS
/// gọi endpoint này (cùng origin -> cookie tự kèm), Web dùng ITempLocMapApi (Refit,
/// đã có token) gọi API rồi trả JSON layout. Độc lập với Blazor circuit -> mạng
/// chậm/đứt không kích hoạt overlay reconnect, màn hình không bị mờ/trắng.
/// </summary>
public static class TempLocRefreshEndpoints
{
    public static IEndpointRouteBuilder MapTempLocRefreshEndpoints(this IEndpointRouteBuilder app)
    {
        app.MapGet("/receiving-map/refresh", async (string area, IMapViewApi api) =>
        {
            if (string.IsNullOrWhiteSpace(area))
                return Results.BadRequest("Thiếu tham số 'area'.");

            try
            {
                // Dùng API bản đồ chung: đủ kệ + ô pallet + khối chức năng và thống kê.
                var layout = await api.GetAsync(area);
                return Results.Json(new
                {
                    areaCode = layout.AreaCode,
                    cols = layout.Cols,
                    rows = layout.Rows,
                    cellMeters = layout.CellMeters,
                    summary = layout.Summary,
                    cells = layout.Blocks.Select(b => new
                    {
                        id = b.Id,
                        code = b.Kind == "rack" ? b.RackCode : b.LocatorCode,
                        cellType = b.Kind,
                        gridX = b.GridX, gridY = b.GridY, gridW = b.GridW, gridH = b.GridH,
                        arrow = b.Arrow, color = b.Color, label = b.Label,
                        status = b.Status, model = b.Model,
                        lotNo = (string?)null, sortOrder = 0, isUrgent = b.IsUrgent,
                        rackCode = b.RackCode,
                        totalSlots = b.TotalSlots, occupiedSlots = b.OccupiedSlots,
                        positions = b.Positions.Select(p => new
                        {
                            position = p.Position, total = p.Total, occupied = p.Occupied
                        }),
                        lots = b.Lots.Select(x => new
                        {
                            lotId = x.LotId, lotNo = x.PalletId,
                            inspectionStatus = x.Status, mappedStatus = x.Status,
                            isUrgent = x.IsUrgent, boxCount = x.BoxCount,
                            models = x.Model, productionDate = x.ProductionDate,
                            // Dấu RW/RB. Đây là đường realtime (poll 30s) — thiếu
                            // nó thì dấu hiện lúc mới mở màn rồi BIẾN MẤT sau lượt
                            // làm mới đầu tiên, triệu chứng rất khó đoán.
                            disposition = x.Disposition
                        })
                    })
                });
            }
            catch (Exception ex)
            {
                // Lỗi (API/mạng) -> trả 502; JS bỏ qua kỳ này, giữ map cũ, thử lại sau.
                Console.Error.WriteLine($"[ReceivingMapRefresh] lỗi lấy layout '{area}': {ex.Message}");
                return Results.StatusCode(StatusCodes.Status502BadGateway);
            }
        })
        .AllowAnonymous();   // Màn hình chiếu trong mạng nội bộ, không cần đăng nhập

        return app;
    }
}