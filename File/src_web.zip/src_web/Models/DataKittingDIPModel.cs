﻿namespace SWMS_WebTool.Models
{
    public class DataKittingDIPModel : AuditableEntity
    {
        public Int64 ID { get; set; }
        public string Plant { get; set; }
        public string SlocDIP { get; set; }
        public string Model { get; set; }
        public double? Quantity { get; set; }
        public double? Blog { get; set; }
        public DateTime? ProductDate { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Note { get; set; }
        public string ModelFA { get; set; }
        public string UploadNo { get; set; }
        public bool IsUrgent { get; set; }
    }
}
