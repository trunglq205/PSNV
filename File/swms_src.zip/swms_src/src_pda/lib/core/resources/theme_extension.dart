import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';

/// Token PDA không vừa với ColorScheme chuẩn (tint, bg ngữ nghĩa, accent,
/// thang chữ 4 cấp). Gói vào ThemeExtension để tự đổi theo light/dark.
class SwmsColors extends ThemeExtension<SwmsColors> {
  // Primary phụ trợ
  final Color primary;

  /// Tông đậm của primary — dùng cho CHỮ/ICON nằm trên nền [primaryTint].
  /// Ở dark thì ngược lại: nền tint là xanh tối nên đây là tông SÁNG hơn.
  final Color primaryDark;

  final Color primaryTint;
  final Color primaryTint2;

  // Semantic backgrounds
  final Color success, successBg;
  final Color warning, warningBg;
  final Color danger, dangerBg;

  // Surface / text scale
  /// Nền nổi: thẻ, dialog, sheet. Sáng hơn nền màn hình (`bg`).
  final Color card;

  /// Nền chìm một cấp so với [card]: header dialog, ô chọn, skeleton.
  final Color card2;

  final Color border, border2;
  final Color text1, text2, text3, text4;

  const SwmsColors({
    required this.primary,
    required this.primaryDark,
    required this.primaryTint,
    required this.primaryTint2,
    required this.success,
    required this.successBg,
    required this.warning,
    required this.warningBg,
    required this.danger,
    required this.dangerBg,
    required this.card,
    required this.card2,
    required this.border,
    required this.border2,
    required this.text1,
    required this.text2,
    required this.text3,
    required this.text4,
  });

  static const SwmsColors light = SwmsColors(
    primary: AppColors.primary,
    primaryDark: AppColors.primaryDark,
    primaryTint: AppColors.primaryTint,
    primaryTint2: AppColors.primaryTint2,
    success: AppColors.success,
    successBg: AppColors.successBg,
    warning: AppColors.warning,
    warningBg: AppColors.warningBg,
    danger: AppColors.danger,
    dangerBg: AppColors.dangerBg,
    card: AppColors.card,
    card2: AppColors.card2,
    border: AppColors.border,
    border2: AppColors.border2,
    text1: AppColors.text1,
    text2: AppColors.text2,
    text3: AppColors.text3,
    text4: AppColors.text4,
  );

  static const SwmsColors dark = SwmsColors(
    primary: AppColors.primaryDark,
    // Nền tint ở dark là xanh tối -> chữ phải sáng hơn nền, không phải đậm hơn.
    primaryDark: AppColors.primaryLight,
    primaryTint: Color(0x330F6CBD),
    // rgba(15,108,189,.20)
    primaryTint2: Color(0x520F6CBD),
    // rgba(15,108,189,.32)
    success: AppColors.success,
    successBg: Color(0x2E2E7D32),
    warning: AppColors.warning,
    warningBg: Color(0x2EE65100),
    danger: AppColors.danger,
    dangerBg: Color(0x33C62828),
    card: AppColors.darkCard,
    card2: AppColors.darkCard2,
    border: AppColors.darkBorder,
    border2: AppColors.darkBorder2,
    text1: AppColors.darkText1,
    text2: AppColors.darkText2,
    text3: AppColors.darkText3,
    text4: AppColors.darkText4,
  );

  @override
  SwmsColors copyWith({
    Color? primary,
    Color? primaryDark,
    Color? primaryTint,
    Color? primaryTint2,
    Color? success,
    Color? successBg,
    Color? warning,
    Color? warningBg,
    Color? danger,
    Color? dangerBg,
    Color? card,
    Color? card2,
    Color? border,
    Color? border2,
    Color? text1,
    Color? text2,
    Color? text3,
    Color? text4,
  }) {
    return SwmsColors(
      primary: primary ?? this.primary,
      primaryDark: primaryDark ?? this.primaryDark,
      primaryTint: primaryTint ?? this.primaryTint,
      primaryTint2: primaryTint2 ?? this.primaryTint2,
      success: success ?? this.success,
      successBg: successBg ?? this.successBg,
      warning: warning ?? this.warning,
      warningBg: warningBg ?? this.warningBg,
      danger: danger ?? this.danger,
      dangerBg: dangerBg ?? this.dangerBg,
      card: card ?? this.card,
      card2: card2 ?? this.card2,
      border: border ?? this.border,
      border2: border2 ?? this.border2,
      text1: text1 ?? this.text1,
      text2: text2 ?? this.text2,
      text3: text3 ?? this.text3,
      text4: text4 ?? this.text4,
    );
  }

  @override
  SwmsColors lerp(SwmsColors? other, double t) {
    if (other == null) return this;
    Color l(Color a, Color b) => Color.lerp(a, b, t)!;
    return SwmsColors(
      primary: l(primary, other.primary),
      primaryDark: l(primaryDark, other.primaryDark),
      primaryTint: l(primaryTint, other.primaryTint),
      primaryTint2: l(primaryTint2, other.primaryTint2),
      success: l(success, other.success),
      successBg: l(successBg, other.successBg),
      warning: l(warning, other.warning),
      warningBg: l(warningBg, other.warningBg),
      danger: l(danger, other.danger),
      dangerBg: l(dangerBg, other.dangerBg),
      card: l(card, other.card),
      card2: l(card2, other.card2),
      border: l(border, other.border),
      border2: l(border2, other.border2),
      text1: l(text1, other.text1),
      text2: l(text2, other.text2),
      text3: l(text3, other.text3),
      text4: l(text4, other.text4),
    );
  }
}

/// Tiện đọc: context.swms.successBg, context.swms.text2 ...
extension SwmsColorsX on BuildContext {
  SwmsColors get swms => Theme.of(this).extension<SwmsColors>()!;
}