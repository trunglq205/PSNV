﻿using Microsoft.EntityFrameworkCore;

namespace CriticalListReport.Models
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        {
        }

        public DbSet<CriticalItem> CriticalItems { get; set; }
        public DbSet<NumberColumnShow> NumberColumnShows { get; set; }
        public DbSet<VendorMaster> VendorMasters { get; set; }
        public DbSet<CategoryMaster> CategoryMasters { get; set; }
        public DbSet<PartMaster> PartMasters { get; set; }
        public DbSet<GrossWeightMaster> GrossWeightMasters { get; set; }
        public DbSet<MRPMaster> MRPMasters { get; set; }
        public DbSet<FactoryMaster> FactoryMasters { get; set; }
        public DbSet<StockOtherFactory> StockOtherFactories { get; set; }
        public DbSet<NonWorkingCalendar> NonWorkingCalendars { get; set; }
        public DbSet<JudgmentRankPO> JudgmentRankPOs { get; set; }
        public DbSet<JudgmentRankPR> JudgmentRankPRs { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<ActionHistory> ActionHistories { get; set; }
        public DbSet<GameScore> GameScores { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<CriticalItem>()
                        .HasKey(x => x.ID);
            modelBuilder.Entity<NumberColumnShow>()
                        .HasKey(x => x.DataSource);
            modelBuilder.Entity<VendorMaster>()
                        .HasKey(v => v.ID);
            modelBuilder.Entity<CategoryMaster>()
                        .HasKey(v => v.ProfitCenterID);
            modelBuilder.Entity<PartMaster>()
                        .HasKey(v => v.ID);
            modelBuilder.Entity<GrossWeightMaster>()
                        .HasKey(v => v.ID);
            modelBuilder.Entity<MRPMaster>()
                        .HasKey(v => v.ID);
            modelBuilder.Entity<FactoryMaster>()
                        .HasKey(v => v.ID);
            modelBuilder.Entity<StockOtherFactory>()
                       .HasKey(v => v.ID);
            modelBuilder.Entity<NonWorkingCalendar>()
                       .HasKey(v => v.ID);
            modelBuilder.Entity<JudgmentRankPO>()
                       .HasKey(v => v.Id);
            modelBuilder.Entity<JudgmentRankPR>()
                       .HasKey(v => v.Id);
            modelBuilder.Entity<User>()
                       .HasKey(v => v.Id);
            modelBuilder.Entity<ActionHistory>()
                       .HasKey(v => v.Id);
            modelBuilder.Entity<GameScore>()
                       .HasKey(v => v.Id);
        }
    }
}
