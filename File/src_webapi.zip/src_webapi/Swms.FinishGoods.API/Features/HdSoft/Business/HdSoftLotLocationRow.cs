namespace Swms.FinishGoods.API.Features.HdSoft.Business
{
    /// <summary>
    /// 1 dòng tồn hiện tại của lot trong HD soft (M_StorageOnhand, QtyOnHand &gt; 0).
    /// Bình thường 1 lot chỉ nằm ở 1 vị trí; nhiều dòng = lot đang tồn ở nhiều vị trí / nhiều model.
    /// </summary>
    public class HdSoftLotLocationRow
    {
        public string PalletNo { get; set; } = "";
        public string? Model { get; set; }
        public string? Locator { get; set; }
        public string? Warehouse { get; set; }
        public decimal QtyOnHand { get; set; }
    }
}
