import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';

part 'stocky_cart_model.g.dart';

/// KHÔNG dùng `fieldRename: FieldRename.snake`.
///
/// API của dự án để NGUYÊN chính sách đặt tên mặc định của ASP.NET Core, tức
/// camelCase (`Program.cs` chỉ thêm converter cho enum, không đặt
/// `PropertyNamingPolicy`). Bản trước khai snake nên code sinh ra đọc
/// `json['lot_count']` trong khi server gửi `lotCount` — field luôn về 0 mà
/// không báo lỗi gì. Mock che mất lỗi này.
///
/// Đối chiếu: các model khác gọi cùng API (vd `ng_models.dart`) đều để tên
/// trường y như Dart, không khai fieldRename.
@JsonSerializable()
class StockyCartModel {
  final String code;
  final String? name;
  final String? model;
  final int qty;
  final int lotCount;
  final bool hasGoods;
  final String? status;
  final String? locatorCode;
  final String? areaCode;
  final String? palletCode;
  final String? siNo;

  /// Xe đang ở FA. Server tính; mặc định false để response cũ (chưa có trường
  /// này) không làm vỡ parse.
  final bool atFa;

  final DateTime? receivedAt;

  const StockyCartModel({
    required this.code,
    this.name,
    this.model,
    this.qty = 0,
    this.lotCount = 0,
    this.hasGoods = false,
    this.status,
    this.locatorCode,
    this.areaCode,
    this.palletCode,
    this.siNo,
    this.atFa = false,
    this.receivedAt,
  });

  factory StockyCartModel.fromJson(Map<String, dynamic> json) =>
      _$StockyCartModelFromJson(json);
  Map<String, dynamic> toJson() => _$StockyCartModelToJson(this);

  StockyCart toEntity() => StockyCart(
        code: code,
        name: name,
        model: model,
        qty: qty,
        lotCount: lotCount,
        hasGoods: hasGoods,
        status: status,
        locatorCode: locatorCode,
        areaCode: areaCode,
        palletCode: palletCode,
        siNo: siNo,
        atFa: atFa,
        receivedAt: receivedAt,
      );
}

/// Thân request của cả hai endpoint nhận xe và trả xe.
///
/// KHÔNG còn trường `mode`: chiều nằm ở ĐƯỜNG DẪN (`/receive` hay `/return`),
/// vì mỗi chiều một quyền riêng bên server (`stocky.create` / `stocky.transfer`)
/// mà quyền thì gắn theo endpoint.
@JsonSerializable()
class StockyBatchRequest {
  final List<String> codes;

  const StockyBatchRequest({required this.codes});

  factory StockyBatchRequest.fromJson(Map<String, dynamic> json) =>
      _$StockyBatchRequestFromJson(json);
  Map<String, dynamic> toJson() => _$StockyBatchRequestToJson(this);
}

@JsonSerializable()
class StockySubmitResultModel {
  final int cartCount;
  final int qty;

  const StockySubmitResultModel({required this.cartCount, required this.qty});

  factory StockySubmitResultModel.fromJson(Map<String, dynamic> json) =>
      _$StockySubmitResultModelFromJson(json);
  Map<String, dynamic> toJson() => _$StockySubmitResultModelToJson(this);

  StockySubmitResult toEntity() =>
      StockySubmitResult(cartCount: cartCount, qty: qty);
}
