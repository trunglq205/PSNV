// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'trip_evidence_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

TripPhotoItemModel _$TripPhotoItemModelFromJson(Map<String, dynamic> json) =>
    TripPhotoItemModel(
      step: (json['step'] as num).toInt(),
      stepTitle: json['stepTitle'] as String,
      key: json['key'] as String,
      label: json['label'] as String,
      note: json['note'] as String?,
      perUnit: (json['perUnit'] as num).toInt(),
      unit: json['unit'] as String,
      units: (json['units'] as num).toInt(),
      slotLabels: (json['slotLabels'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList(),
    );

TripPhotoModel _$TripPhotoModelFromJson(Map<String, dynamic> json) =>
    TripPhotoModel(
      id: (json['id'] as num).toInt(),
      itemKey: json['itemKey'] as String,
      unitNo: (json['unitNo'] as num?)?.toInt(),
      palletCode: json['palletCode'] as String?,
      slotNo: (json['slotNo'] as num).toInt(),
      createdAt: DateTime.parse(json['createdAt'] as String),
      createdBy: json['createdBy'] as String?,
    );

TripInspectionModel _$TripInspectionModelFromJson(Map<String, dynamic> json) =>
    TripInspectionModel(
      result: json['result'] as String,
      passedConditions:
          (json['passedConditions'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      note: json['note'] as String?,
      containerNo: json['containerNo'] as String?,
      inspectedAt: DateTime.parse(json['inspectedAt'] as String),
      inspectedBy: json['inspectedBy'] as String?,
    );

TripPalletListModel _$TripPalletListModelFromJson(Map<String, dynamic> json) =>
    TripPalletListModel(
      code: json['code'] as String,
      boxCount: (json['boxCount'] as num?)?.toInt() ?? 0,
      pcs: (json['pcs'] as num?)?.toInt() ?? 0,
      locatorCode: json['locatorCode'] as String?,
      cocNo: (json['cocNo'] as num?)?.toInt(),
    );

TripEvidenceModel _$TripEvidenceModelFromJson(Map<String, dynamic> json) =>
    TripEvidenceModel(
      tripId: (json['tripId'] as num).toInt(),
      canUpload: json['canUpload'] as bool,
      pallets: (json['pallets'] as num?)?.toInt() ?? 0,
      cocs: (json['cocs'] as num?)?.toInt() ?? 0,
      rows: (json['rows'] as num?)?.toInt() ?? 0,
      items:
          (json['items'] as List<dynamic>?)
              ?.map(
                (e) => TripPhotoItemModel.fromJson(e as Map<String, dynamic>),
              )
              .toList() ??
          const [],
      photos:
          (json['photos'] as List<dynamic>?)
              ?.map((e) => TripPhotoModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
      inspection: json['inspection'] == null
          ? null
          : TripInspectionModel.fromJson(
              json['inspection'] as Map<String, dynamic>,
            ),
      palletLists: (json['palletLists'] as List<dynamic>?)
          ?.map((e) => TripPalletListModel.fromJson(e as Map<String, dynamic>))
          .toList(),
      stacks: (json['stacks'] as List<dynamic>?)
          ?.map((e) => TripStackModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$TripInspectionRequestModelToJson(
  TripInspectionRequestModel instance,
) => <String, dynamic>{
  'result': instance.result,
  'passedConditions': instance.passedConditions,
  'note': ?instance.note,
};
