using Swms.FinishGoods.API.Features.HdSoft.Business;
using Swms.FinishGoods.API.Features.HdSoft.DataAccess;
using Swms.FinishGoods.API.Features.HdSoft.PalletSync.Business;

namespace Swms.FinishGoods.API.Features.HdSoft
{
    public static class HdSoftModule
    {
        public static IServiceCollection AddHdSoftFeature(this IServiceCollection services)
        {
            // ── Đọc HD soft (read-only): lot, tồn, SI, hàng thiếu ──
            services.AddSingleton<IHdSoftDbConnectionFactory, HdSoftDbConnectionFactory>();
            services.AddScoped<IHdSoftLotRepository, HdSoftLotRepository>();
            services.AddScoped<IHdSoftSiRepository, HdSoftSiRepository>();
            services.AddScoped<IHdSoftService, HdSoftService>();

            // ── HD soft -> pallet SWMS (vị trí, si_no) ──
            services.AddScoped<IPalletHdSoftSyncService, PalletHdSoftSyncService>();
            return services;
        }
    }
}
