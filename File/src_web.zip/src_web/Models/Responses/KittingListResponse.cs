﻿namespace SWMS_WebTool.Models.Responses
{
    public class KittingListResponse
    {
        public string Plant { get; set; }
        //Tuấn Anh sửa
        // public string ReservationNo { get; set; }
        public string SpecialPart { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Model { get; set; }
        public int ModelQuantity { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Category { get; set; }
        public string BarcodeLine { get; set; }
        public string Barcode { get; set; }
        public double Quantity { get; set; }
        public byte KittingType { get; set; }
        public string CodeTrolley { get; set; }
        public string PositionFA { get; set; }
        public string KittingTimeType { get; set; }
        //Tuấn Anh sửa
        //public List<KittingListDetail> kittingPlans { get; set; }
        public List<KittingListDetailForKitting> kittingPlans { get; set; }
    }
}
