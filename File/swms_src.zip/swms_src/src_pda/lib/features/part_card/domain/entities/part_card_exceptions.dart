/// Lỗi nghiệp vụ màn Part Card — ném ra trong `appActionProvider.run`
/// để tầng UI hiển thị message.
// TODO: nếu core/errors/exceptions.dart đã có base class riêng
// (như DuplicateCartonException...) thì cho các lỗi dưới đây kế thừa base đó.
class PartCardFailure implements Exception {
  const PartCardFailure(this.message);

  final String message;

  @override
  String toString() => message;
}

class EmptyModelInputException extends PartCardFailure {
  const EmptyModelInputException() : super('Vui lòng nhập hoặc quét mã model.');
}

class NoPrinterSelectedException extends PartCardFailure {
  const NoPrinterSelectedException()
    : super('Chưa chọn máy in. Chạm "Đổi" để chọn máy in.');
}

class IncompletePartCardException extends PartCardFailure {
  IncompletePartCardException(List<String> fields)
    : super('Thiếu dữ liệu: ${fields.join(', ')}');
}
