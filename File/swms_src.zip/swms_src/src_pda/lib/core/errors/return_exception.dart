part of 'exceptions.dart';

/// Lỗi nghiệp vụ màn Nhận hàng back (chỉ thị rework / refurbish).
///
/// Chỉ các lỗi CHẶN ĐƯỢC NGAY TRÊN MÁY nằm ở đây — model chưa chọn, serial
/// trùng trong phiên quét, chưa quét được gì. Mọi lỗi server (serial thuộc
/// phiếu khác, lẫn category, phiếu đã đóng) đã có câu đã dịch trong response
/// và ErrorInterceptor hiện nguyên câu đó; bọc lại ở đây chỉ làm mất thông tin.
sealed class ReturnReceiveException extends AppException {
  const ReturnReceiveException(super.message, {required super.code});
}

/// Quét mã thùng khi chưa chọn model của thùng.
///
/// Serial in trên sản phẩm không cho biết model, nên model phải chọn trước —
/// không có nó thì không biết serial vừa quét thuộc dòng nào của phiếu.
class ReturnNoModelSelectedException extends ReturnReceiveException {
  const ReturnNoModelSelectedException()
      : super(
          'Chọn model của thùng trước khi quét',
          code: 'error.return_no_model',
        );
}

/// Serial đã quét trong chính phiên này (cùng thùng hoặc thùng khác).
class ReturnDuplicateSerialException extends ReturnReceiveException {
  const ReturnDuplicateSerialException(this.serialNo)
      : super(
          'Serial "$serialNo" đã quét rồi',
          code: 'error.return_duplicate_serial',
        );

  final String serialNo;

  @override
  Map<String, String> get namedArgs => {'serial': serialNo};
}

/// Bấm "Xong thùng" khi thùng chưa có serial nào.
class ReturnBoxEmptyException extends ReturnReceiveException {
  const ReturnBoxEmptyException()
      : super(
          'Thùng chưa có serial nào',
          code: 'error.return_box_empty',
        );
}

/// Bấm Lưu khi chưa quét được serial nào.
class ReturnNothingToSaveException extends ReturnReceiveException {
  const ReturnNothingToSaveException()
      : super(
          'Chưa quét được serial nào để lưu',
          code: 'error.return_nothing_to_save',
        );
}
