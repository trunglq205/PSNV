using System.Data;
using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Models.Responses;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using static SWMS_WebTool.Models.GoodReceipt;

namespace SWMS_WebTool.Controllers.Receiving
{
    public class GoodReceiptController : BaseController
    {
        private readonly ApiService _apiService;

        public GoodReceiptController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] GoodReceiptFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new GoodReceiptFilter();
                _filter.Material = _filter.Material?.Trim().ToUpper();
                _filter.TrackingNumber = _filter.TrackingNumber?.Trim();
                var response = await _apiService.SearchGoodReceipts(_filter, pageNumber, _pageSize);
                var scheduleResponse = await _apiService.GetScheduleRC();
                var total = response.TotalRecord;
                var items = response.Records ?? new List<GoodReceipt>();

                var model = new GoodReceiptViewModel()
                {
                    Items = items,
                    ReceivingSchedule = new ReceivingSchedule
                    {
                        IsBlock = false,
                        BlockDate = DateTime.Now,
                        DatePrint = DateTime.Now,
                    },
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total
                };


                if (scheduleResponse != null)
                {
                    var schedule = new ReceivingSchedule
                    {
                        IsBlock = scheduleResponse.IsBlock,
                        BlockDate = scheduleResponse.BlockDate,
                        DatePrint = scheduleResponse.DatePrint,
                    };

                    model = new GoodReceiptViewModel()
                    {
                        Items = items,
                        ReceivingSchedule = schedule,
                        Filter = _filter,
                        PageNumber = pageNumber,
                        PageSize = _pageSize,
                        TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                        Total = total,

                    };
                }
                
                return View("Views/GoodReceipt/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new
                {
                    Message = e.Message
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> InputTrackingNumber(string searchDate, string vendorcode, string dacode, int pageNumber = 1, string? pageSize = null)
        {
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageMaximum.ToString());
            var _filter = new GoodReceiptFilter();
            _filter.Date = string.IsNullOrEmpty(searchDate) ? DateTime.Now : Convert.ToDateTime(searchDate);
            var filterData = new GoodReceiptFilter()
            {
                VendorCode = vendorcode,
                DeliveryPlanNo = dacode,
                DACode = dacode,
                Date = _filter.Date
            };
            var dataResult = new List<GoodReceipt>();
            var response = await _apiService.SearchGoodReceipts(_filter, pageNumber, _pageSize);
            ViewBag.VendorCodes = new SelectList(response.Records != null ? response.Records?.Select(x => x.VendorCode).Distinct().ToList() : new List<string>());
            if (!string.IsNullOrEmpty(vendorcode) || !string.IsNullOrEmpty(dacode))
            {
                dataResult = response.Records?.Where(s => (s.VendorCode == vendorcode || s.DeliveryPlanNo == dacode) && string.IsNullOrEmpty(s.TrackingNumber)).ToList();
            }
            else
            {
                dataResult = response.Records?.Where(s => string.IsNullOrEmpty(s.TrackingNumber)).ToList();
            }

            var total = response.TotalRecord;
            var items = dataResult ?? new List<GoodReceipt>();
            var model = new GoodReceiptViewModel()
            {
                Items = items,
                Filter = filterData,
                PageNumber = pageNumber,
                PageSize = _pageSize,
                TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                Total = total,
            };
            var newRequest = new Tuple<GoodReceiptViewModel, DateTime>(model, _filter.Date ?? DateTime.Now);
            return PartialView("~/Views/GoodReceipt/_InputTrackingNumberModal.cshtml", newRequest);
        }

        //[HttpPost]
        //public async Task<IActionResult> ConfirmInputTrackingNumber([FromBody] List<GoodReceipt> request, string selectedItems, string trackingnumber)
        //{
        //    selectedItems = "[" + selectedItems + "]";
        //    List<InputTrackingNumberResponse> dataList = JsonConvert.DeserializeObject<List<InputTrackingNumberResponse>>(selectedItems);
        //    try
        //    {
        //        // Lấy loại của đối tượng đầu tiên trong danh sách
        //        int? targetType = dataList.FirstOrDefault()?.Type;
        //        var lstByTargetType = dataList.Where(e => e.Type == targetType);
        //        var lstNotByTargetType = dataList.Where(e => e.Type != targetType);
        //        if (!lstByTargetType.Any() && !lstNotByTargetType.Any())
        //        {
        //            return BadRequest("Không có bản ghi nào tồn tại");
        //        }
        //        if (lstByTargetType.Any())
        //        {
        //            var request1 = new UpdateTrackingNoByVendorCodeRequest()
        //            {
        //                Id = lstByTargetType.Select(e => e.Id).ToList(),
        //                Type = lstByTargetType.First().Type,
        //                TrackingNumber = trackingnumber ?? "",
        //            };

        //            await _apiService.InputTrackingNumber(request1);
        //        }
        //        if (lstNotByTargetType.Any())
        //        {
        //            var request1 = new UpdateTrackingNoByVendorCodeRequest()
        //            {
        //                Id = lstNotByTargetType.Select(e => e.Id).ToList(),
        //                Type = lstNotByTargetType.First().Type,
        //                TrackingNumber = trackingnumber ?? "",
        //            };

        //            await _apiService.InputTrackingNumber(request1);
        //        }

        //        return Json(new { success = true });
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}
        [HttpPost]
        public async Task<IActionResult> ConfirmInputTrackingNumber([FromBody] ConfirmInputModel request)
        {
            List<InputTrackingNumberResponse> dataList = request.selectedItems;

            try
            {
                // Lấy loại của đối tượng đầu tiên trong danh sách
                int? targetType = dataList.FirstOrDefault()?.Type;
                var lstByTargetType = dataList.Where(e => e.Type == targetType);
                var lstNotByTargetType = dataList.Where(e => e.Type != targetType);
                if (!lstByTargetType.Any() && !lstNotByTargetType.Any())
                {
                    return BadRequest(_loc.Get("Field_NoRecordsExist"));
                }
                if (lstByTargetType.Any())
                {
                    var request1 = new UpdateTrackingNoByVendorCodeRequest()
                    {
                        Id = lstByTargetType.Select(e => e.Id).ToList(),
                        Type = lstByTargetType.First().Type,
                        TrackingNumber = request.trackingnumber ?? "",
                    };

                    await _apiService.InputTrackingNumber(request1);
                }
                if (lstNotByTargetType.Any())
                {
                    var request1 = new UpdateTrackingNoByVendorCodeRequest()
                    {
                        Id = lstNotByTargetType.Select(e => e.Id).ToList(),
                        Type = lstNotByTargetType.First().Type,
                        TrackingNumber = request.trackingnumber ?? "",
                    };

                    await _apiService.InputTrackingNumber(request1);
                }

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        public async Task<IActionResult> ConfirmGoodReceipt(string searchDate, string vendorcode, int pageNumber = 1, string? pageSize = "max")
        {
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
            var _filter = new GoodReceiptFilter();
            _filter.Date = string.IsNullOrEmpty(searchDate) ? DateTime.Now : Convert.ToDateTime(searchDate);
            _filter.VendorCode = !string.IsNullOrEmpty(vendorcode) ? vendorcode : string.Empty;
            var response = await _apiService.SearchGoodReceipts(_filter, pageNumber, _pageSize);
            var dataResult = response.Records.Where(r => r.Status == DeliveryPlanStatus.ReceiptLack).ToList();
            var total = response.TotalRecord;
            var items = dataResult ?? new List<GoodReceipt>();
            var model = new GoodReceiptViewModel()
            {
                Items = items,
                Filter = _filter,
                PageNumber = pageNumber,
                PageSize = _pageSize,
                TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                Total = total,

            };
            return PartialView("~/Views/GoodReceipt/_ConfirmGoodReceiptModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmGoodReceipt(string selectedItems)
        {
            try
            {
                selectedItems = "[" + selectedItems + "]";
                List<ConfirmGoodReceiptResponse> dataList = JsonConvert.DeserializeObject<List<ConfirmGoodReceiptResponse>>(selectedItems);

                // get first type
                int? targetType = dataList.FirstOrDefault()?.Type;
                var lstByTargetType = dataList.Where(e => e.Type == targetType);
                var lstNotByTargetType = dataList.Where(e => e.Type != targetType);
                if (!lstByTargetType.Any() && !lstNotByTargetType.Any())
                {
                    return BadRequest(_loc.Get("Field_NoRecordsExist"));
                }
                if (lstByTargetType.Any())
                {
                    var request1 = new ConfirmGoodReceiptRequest()
                    {
                        ItemDetailIds = lstByTargetType.Select(x => x.Id).ToList(),
                        Type = lstByTargetType.First().Type,
                    };
                    await _apiService.ConfirmGoodReceipts(request1);
                }
                if (lstNotByTargetType.Any())
                {
                    var request2 = new ConfirmGoodReceiptRequest()
                    {
                        ItemDetailIds = lstNotByTargetType.Select(x => x.Id).ToList(),
                        Type = lstNotByTargetType.First().Type,
                    };
                    await _apiService.ConfirmGoodReceipts(request2);
                }

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportTrackingNumberByFile(IFormFile file)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx")
                    {
                        dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.InvoiceTrackingHeader, Constants.InvoiceTrackingIndexHeader);
                        if (dt != null && dt.Columns.Count == Constants.InvoiceTrackingHeader.Count)
                        {

                            List<TrackingNumberImport>? trackings = Function.DataTatbleToTrackingNumder(dt);
                            string jsonData = JsonConvert.SerializeObject(trackings);
                            if (trackings != null && trackings.Count > 0)
                            {
                                return PartialView("~/Views/GoodReceipt/_InputTrackingNumberByFileModal.cshtml", trackings);
                            }
                        }
                        else
                        {
                            return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                        }
                    }
                    else
                    {
                        return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                    }
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportTrackingNumberByFile([FromBody] List<TrackingNumberImport> trackings)
        {
            try
            {
                await _apiService.ImportTrackingNumberByFile(trackings);
                var countData = trackings.Count();
                return Json(new { success = true, countData = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmBlockDate(ReceivingSchedule request)
        {
            try
            {
                var scheduleResponse = await _apiService.GetScheduleRC();
                var newrequest = new ReceivingSchedule
                {
                    BlockDate = request.BlockDate == null ? scheduleResponse.BlockDate : request.BlockDate,
                    DatePrint = request.DatePrint == null ? scheduleResponse.DatePrint : request.DatePrint,
                    IsBlock = request.IsBlock
                };
                await _apiService.CreateScheduleRC(newrequest);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> SearchReceivingCardDetail(long id, int type)
        {
            var models = await _apiService.GetReceivingCardDetailByReceivingCardId(type, id);
            return PartialView("Views/GoodReceipt/_GetReceivingCardDetailByReceivingCardId.cshtml", models);
        }

        [HttpPost]
        public IActionResult RevertReceivingCard([FromBody] RevertReceivingCardGRModelNew model)
        {
            try
            {
                return PartialView("Views/GoodReceipt/_ConfirmRevertReceivingCardModal.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmRevertReceivingCard([FromBody] RevertReceivingCardGRModelNew request)
        {
            try
            {
                await _apiService.RevertRCGR(request.Material, request.DeliveryPlanNo, request.Type);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

    }
}
