/* =========================================================
   CHỦ ĐỀ GIÁNG SINH — hiệu ứng nền cho Login + Layout
   Drop-in: wwwroot/js/christmas.js  (đặt sau bootstrap.bundle)
   - Tuyết rơi (canvas, nằm sau nội dung)
   - Băng chúc mừng + đếm ngược tới 25/12 (chỉ trang có <main>)
   - Đánh dấu menu đang mở theo URL
   - Bông tuyết bung ra khi bấm nút chính
   - Nút 🎅 Chơi Flappy Santa + 🏆 BXH + hộp thể lệ (GameScoreController)
   ========================================================= */
(function () {
    "use strict";

    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function el(tag, cls, css) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (css) n.setAttribute("style", css);
        return n;
    }

    /* ---------- 1. Khung trang có menu cố định ---------- */
    function buildFrame() {
        if (document.querySelector(".navbar.fixed-top")) document.body.classList.add("xm-framed");
    }

    /* ---------- 2. Menu đang mở ---------- */
    function markActiveNav() {
        // Chuẩn hoá: bỏ "/" cuối, bỏ "/index", bỏ "/home" (trang chủ) — chạy được cả khi host trong virtual directory IIS
        function norm(p) {
            p = (p || "").split("?")[0].split("#")[0].toLowerCase().replace(/\/+$/, "");
            p = p.replace(/\/index$/, "").replace(/\/home$/, "");
            return p || "/";
        }
        var path = norm(location.pathname);
        document.querySelectorAll(".nav-group-item[href]").forEach(function (a) {
            if (norm(a.getAttribute("href")) === path) a.classList.add("active");
        });
    }

    /* ---------- 3. Băng chúc mừng + đếm ngược Giáng sinh ---------- */
    function buildBanner() {
        var main = document.querySelector("main");
        if (!main || document.querySelector(".xm-banner")) return; // trang Login không có <main>

        var now = new Date();
        var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        var xmas = new Date(now.getFullYear(), 11, 25);
        if (today > xmas) xmas = new Date(now.getFullYear() + 1, 11, 25);
        var days = Math.round((xmas - today) / 86400000);
        var chip = days === 0 ? "Hôm nay là Giáng sinh!" : "Còn " + days + " ngày đến Giáng sinh";

        var msg = "Chúc cả team một mùa Giáng sinh ấm áp, an lành — số liệu gọn gàng, báo cáo đúng hạn và một năm mới thật nhiều niềm vui!";

        var b = el("div", "xm-banner");
        var bells = el("div", "xm-banner-bells");
        bells.textContent = "🔔";
        var title = el("div", "xm-banner-title");
        title.textContent = "Merry Christmas";
        var mq = el("div", "xm-marquee");
        var inner = el("div");
        var pz = prizes();
        var msg2 = boardUrl() ? "🏆 Đua Top 2 BXH Flappy Santa (27/11 → 12h trưa 25/12) — Top 1 và Top 2 lần lượt đấu 1vs1 với Admin chiều 25/12, thắng là được quay quà: 🥇 " + pz[0] + " · 🥈 " + pz[1] + "! Bấm nút 🏆 để xem thể lệ." : "";
        for (var i = 0; i < 2; i++) {
            var sp = el("span");
            sp.textContent = msg;
            inner.appendChild(sp);
            if (msg2) {
                var sp2 = el("span", "xm-marquee-prize");
                sp2.textContent = msg2;
                inner.appendChild(sp2);
            }
        }
        mq.appendChild(inner);
        var c = el("div", "xm-chip");
        c.textContent = chip;

        b.appendChild(bells);
        b.appendChild(title);
        b.appendChild(mq);
        b.appendChild(c);
        if (boardUrl()) {
            var pb = el("button", "xm-play-btn");
            pb.type = "button";
            pb.innerHTML = "🎅 Chơi Flappy Santa";
            pb.title = "Mở lại màn chơi Flappy Santa (không cần đăng nhập lại)";
            pb.addEventListener("click", playAgain);
            var bb = el("button", "xm-board-btn");
            bb.type = "button";
            bb.innerHTML = "🏆 BXH";
            bb.title = "Bảng xếp hạng Flappy Santa mùa Giáng sinh";
            bb.addEventListener("click", function () { openBoard(); });
            b.appendChild(pb);
            b.appendChild(bb);
        }
        main.insertBefore(b, main.firstChild);
    }

    /* ---------- 3b. Bảng xếp hạng Flappy Santa (GameScoreController.Leaderboard) ---------- */
    function boardUrl() {
        var m = document.querySelector('meta[name="game-board-url"]');
        return m ? m.getAttribute("content") : null;
    }

    // giải [Top 1, Top 2] (khoảng quay ngẫu nhiên, bước 50k) — appsettings GameSeason:christmas:Prize1 / Prize2
    function prizes(d) {
        if (d && d.prizes && d.prizes.length === 2) return d.prizes;
        var m = document.querySelector('meta[name="game-prizes"]');
        var v = m ? (m.getAttribute("content") || "").split("|") : [];
        return v.length === 2 ? v : ["50.000đ – 300.000đ", "50.000đ – 200.000đ"];
    }

    // các mức quay của 1 khoảng giải, bước 50k (vd "50.000đ – 300.000đ" → "50k · 100k · … · 300k")
    function prizeSteps(range) {
        var nums = String(range).replace(/\./g, "").match(/\d+/g) || [];
        var lo = parseInt(nums[0], 10), hi = parseInt(nums[nums.length - 1], 10), out = [];
        if (!(lo > 0) || !(hi >= lo)) return esc(range);
        for (var v = lo; v <= hi && out.length < 40; v += 50000) out.push(v / 1000 + "k");
        return out.join(" · ");
    }

    function prizeBoxHtml(p, cls) {
        return '<div class="' + cls + '">' +
            '<div class="xm-prize-step"><span>🥇 Top 1</span><b>Thắng Admin: quay ' + esc(p[0]) + '</b></div>' +
            '<div class="xm-prize-step"><span>🥈 Top 2</span><b>Thắng Admin: quay ' + esc(p[1]) + '</b></div>' +
            '<div class="xm-prize-step"><span>⚔️ 1vs1</span><b>Lần lượt đấu với Admin chiều 25/12</b></div>' +
            '</div>';
    }

    // mở lại màn chơi: tải lại trang hiện tại kèm ?themegate=1 (server render màn chơi)
    function playAgain() {
        var u = new URL(location.href);
        u.searchParams.set("themegate", "1");
        location.href = u.pathname + u.search + u.hash;
    }

    function esc(t) {
        return String(t == null ? "" : t).replace(/[&<>"']/g, function (ch) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
        });
    }

    var boardEl = null;

    function openBoard() {
        var url = boardUrl();
        if (!url) return;
        if (!boardEl) {
            boardEl = el("div", "xm-board-overlay");
            boardEl.innerHTML =
                '<div class="xm-board" role="dialog" aria-modal="true" aria-labelledby="xmBoardTitle">' +
                '  <div class="xm-board-head">' +
                '    <h3 id="xmBoardTitle">🏆 Bảng xếp hạng Flappy Santa</h3>' +
                '    <div class="xm-board-head-actions">' +
                '      <button type="button" class="xm-rules-btn xm-play-in-board">🎅 Chơi ngay</button>' +
                '      <button type="button" class="xm-rules-btn">📜 Thể lệ</button>' +
                '      <button type="button" class="xm-board-close" aria-label="Đóng">×</button>' +
                '    </div>' +
                '  </div>' +
                '  <div class="xm-board-prize">🎁 Giải thưởng dành cho Top 1 &amp; Top 2:' + prizeBoxHtml(prizes(), "xm-prize-list") + '</div>' +
                '  <div class="xm-board-sub"></div>' +
                '  <div class="xm-board-body"></div>' +
                '  <div class="xm-board-note">Xếp theo <b>điểm cao nhất</b> (số cột người tuyết bay qua) · mỗi người lấy lượt cao nhất · bằng điểm thì ai đạt trước xếp trên.<br />' +
                '  Điểm do <b>máy chủ tự tính lại</b> từ lượt chơi — lượt có dữ liệu bất thường không được tính.</div>' +
                '</div>';
            document.body.appendChild(boardEl);
            boardEl.addEventListener("click", function (e) { if (e.target === boardEl) closeBoard(); });
            boardEl.querySelector(".xm-board-close").addEventListener("click", closeBoard);
            boardEl.querySelector(".xm-rules-btn:not(.xm-play-in-board)").addEventListener("click", function () { openRules(); });
            boardEl.querySelector(".xm-play-in-board").addEventListener("click", playAgain);
            document.addEventListener("keydown", function (e) {
                if (e.key === "Escape" && boardEl && boardEl.classList.contains("open")
                    && !(rulesEl && rulesEl.classList.contains("open"))) closeBoard();
            });
        }
        boardEl.classList.add("open");
        loadBoard();
        boardEl.querySelector(".xm-board-close").focus();
    }

    function closeBoard() { if (boardEl) boardEl.classList.remove("open"); }

    function loadBoard() {
        var body = boardEl.querySelector(".xm-board-body");
        var sub = boardEl.querySelector(".xm-board-sub");
        body.innerHTML = '<div class="xm-board-empty">Đang tải… 🎅</div>';
        sub.textContent = "";
        var url = boardUrl();
        url += (url.indexOf("?") < 0 ? "?" : "&") + "top=20";
        fetch(url, { credentials: "same-origin", headers: { "Accept": "application/json" } })
            .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
            .then(function (d) { renderBoard(d); })
            .catch(function () { body.innerHTML = '<div class="xm-board-empty">Không tải được bảng xếp hạng. Thử lại sau nhé.</div>'; });
    }

    function renderBoard(d) {
        season = { from: d.from, to: d.to, closeTime: d.closeTime, prizes: prizes(d), closed: d.closed };
        var body = boardEl.querySelector(".xm-board-body");
        var sub = boardEl.querySelector(".xm-board-sub");
        sub.innerHTML = "Mùa Giáng sinh " + d.from + " – " + d.to + " · " + d.total + " người chơi · " +
            (d.closed ? '<span class="xm-closed">🔒 Đã chốt BXH</span>'
                      : !d.started ? "chưa bắt đầu"
                      : '<span class="xm-left">còn ' + d.daysLeft + " ngày</span>");
        var rows = d.rows || [];
        if (!rows.length) {
            body.innerHTML = '<div class="xm-board-empty">Chưa ai lên bảng.' +
                "<br />Bấm 🎅 Chơi Flappy Santa để làm người đầu tiên! 🎄</div>";
            return;
        }
        var myName = d.me ? d.me.username : null;
        var medal = ["🥇", "🥈", "🥉"];
        function row(r) {
            return '<tr class="' + (r.username === myName ? "me" : "") + (r.rank <= 3 ? " top" : "") + '">' +
                '<td class="rk">' + (medal[r.rank - 1] || "#" + r.rank) + "</td>" +
                '<td class="nm">' + esc(r.fullName) + (r.username === myName ? ' <span class="you">bạn</span>' : "") + "</td>" +
                '<td class="num">' + r.score + "</td></tr>";
        }
        var html = '<table><thead><tr><th>Hạng</th><th>Người chơi</th><th>Điểm</th></tr></thead><tbody>';
        rows.forEach(function (r) { html += row(r); });
        if (d.me && !rows.some(function (r) { return r.username === myName; })) {
            html += '<tr class="gap"><td colspan="3">…</td></tr>' + row(d.me);
        }
        html += "</tbody></table>";
        if (!d.me) html += '<div class="xm-board-mine">Bạn chưa có điểm trong mùa này.</div>';
        body.innerHTML = html;
    }

    /* ---------- 3c. Thể lệ "Flappy Santa săn quà" ---------- */
    var rulesEl = null, season = null;

    function rulesHtml(se) {
        var from = se ? se.from : "27/11", to = se ? se.to : "25/12", ct = (se && se.closeTime) || "12:00", pz = (se && se.prizes) || prizes();
        return '' +
            '<div class="xm-rules-prize">🎁 Giải thưởng dành cho <b>Top 1</b> &amp; <b>Top 2</b>' + prizeBoxHtml(pz, "xm-prize-list") + '</div>' +
            '<ol class="xm-rules-list">' +
            '<li><b>Thời gian:</b> từ ngày <b>' + from + '</b> đến hết <b>' + ct + ' trưa ngày ' + to + '</b> (chốt BXH).' +
            (se && se.closed ? ' <span class="xm-closed">🔒 Đã chốt</span>' : '') + '</li>' +
            '<li><b>Cách chơi:</b> sau khi đăng nhập, <b>click chuột</b>, <b>chạm</b> hoặc nhấn <b>Space</b> để ông già Noel bay lên, ' +
            'luồn qua khe giữa các cột <b>người tuyết</b>. Đâm vào người tuyết hoặc rơi xuống đất là thua. ' +
            'Muốn chơi tiếp: bấm <b>🔁 Chơi lại</b> ở màn kết quả, hoặc nút <b>🎅 Chơi Flappy Santa</b> trên băng chúc mừng — chơi bao nhiêu lượt cũng được. ' +
            'Không muốn chơi thì bấm <b>Bỏ qua</b> (hoặc phím Esc).</li>' +
            '<li><b>Cách tính:</b> mỗi cột người tuyết bay qua được <b>1 điểm</b>. ' +
            'Mỗi người chỉ lấy <b>lượt điểm cao nhất</b> của mình.</li>' +
            '<li><b>Xếp hạng:</b> điểm cao hơn xếp trên → bằng điểm thì ai <b>đạt trước</b> xếp trên.</li>' +
            '<li><b>Không được tính:</b>' +
            '<ul>' +
            '<li>Lượt chơi sau thời gian chốt BXH, hoặc lượt dừng giữa chừng vì chuyển sang tab khác.</li>' +
            '<li>Lượt có dữ liệu bất thường: điểm được <b>máy chủ tự tính lại</b> từ toàn bộ lượt chơi, nên sửa điểm, tua nhanh hay làm chậm game đều bị phát hiện và loại.</li>' +
            '<li>Dùng tool / bot chơi hộ hoặc có dấu hiệu gian lận khác — Ban tổ chức có quyền huỷ kết quả.</li>' +
            '</ul></li>' +
            '<li><b>Giải thưởng — dành cho Top 1 và Top 2:</b>' +
            '<ul>' +
            '<li>2 người đứng <b>Top 1</b> và <b>Top 2</b> trên BXH lúc chốt sẽ <b>lần lượt đấu trực tiếp 1vs1 với Admin</b> vào <b>chiều ngày ' + to + '</b>.</li>' +
            '<li>Ai <b>thắng Admin</b> mới được <b>quay ngẫu nhiên</b> giải thưởng (các mức cách nhau 50k):' +
            '<ul>' +
            '<li>🥇 <b>Top 1:</b> ' + esc(pz[0]) + ' — <b>' + prizeSteps(pz[0]) + '</b></li>' +
            '<li>🥈 <b>Top 2:</b> ' + esc(pz[1]) + ' — <b>' + prizeSteps(pz[1]) + '</b></li>' +
            '</ul></li>' +
            '<li>Thua Admin thì không có giải. Ban tổ chức sẽ liên hệ Top 1 và Top 2 để hẹn giờ thi đấu.</li>' +
            '</ul></li>' +
            '</ol>';
    }

    function openRules() {
        if (!rulesEl) {
            rulesEl = el("div", "xm-rules-overlay");
            rulesEl.innerHTML =
                '<div class="xm-rules" role="dialog" aria-modal="true" aria-labelledby="xmRulesTitle">' +
                '  <div class="xm-board-head">' +
                '    <h3 id="xmRulesTitle">📜 Thể lệ "Flappy Santa săn quà"</h3>' +
                '    <button type="button" class="xm-board-close" aria-label="Đóng">×</button>' +
                '  </div>' +
                '  <div class="xm-rules-body"></div>' +
                '  <div class="xm-rules-foot"><button type="button" class="xm-rules-ok">Đã hiểu 👍</button></div>' +
                '</div>';
            document.body.appendChild(rulesEl);
            rulesEl.addEventListener("click", function (e) { if (e.target === rulesEl) closeRules(); });
            rulesEl.querySelector(".xm-board-close").addEventListener("click", closeRules);
            rulesEl.querySelector(".xm-rules-ok").addEventListener("click", closeRules);
            // chặn phím lọt xuống màn chơi phía sau (Space/Enter)
            rulesEl.addEventListener("keydown", function (e) {
                e.stopPropagation();
                if (e.key === "Escape") closeRules();
            });
        }
        var body = rulesEl.querySelector(".xm-rules-body");
        body.innerHTML = rulesHtml(season);
        rulesEl.classList.add("open");
        rulesEl.querySelector(".xm-rules-ok").focus();
        // lấy ngày mùa giải mới nhất từ server (nếu chưa có)
        var url = boardUrl();
        if (!season && url && window.fetch) {
            fetch(url + (url.indexOf("?") < 0 ? "?" : "&") + "top=3",
                { credentials: "same-origin", headers: { "Accept": "application/json" } })
                .then(function (r) { return r.ok ? r.json() : null; })
                .then(function (d) {
                    if (!d) return;
                    season = { from: d.from, to: d.to, closeTime: d.closeTime, prizes: prizes(d), closed: d.closed };
                    body.innerHTML = rulesHtml(season);
                })
                .catch(function () { });
        }
    }

    function closeRules() {
        if (!rulesEl) return;
        rulesEl.classList.remove("open");
        var g = document.querySelector(".xg-gate");
        if (g) g.focus({ preventScroll: true });   // trả focus về màn chơi để chơi tiếp
    }


    /* ---------- 4. Tuyết rơi nền ---------- */
    function buildSnow() {
        if (REDUCED || document.querySelector(".xm-snow")) return;
        var cv = el("canvas", "xm-snow");
        document.body.appendChild(cv);
        var ctx = cv.getContext("2d"), W = 0, H = 0, DPR = Math.min(window.devicePixelRatio || 1, 2);
        var flakes = [];

        function resize() {
            W = cv.clientWidth; H = cv.clientHeight;
            cv.width = W * DPR; cv.height = H * DPR;
            ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
            var target = Math.round(Math.min(140, (W * H) / 14000));
            while (flakes.length < target) flakes.push(make(true));
            flakes.length = target;
        }

        function make(anyY) {
            var depth = Math.random(); // 0 = xa, 1 = gần
            return {
                x: Math.random() * W,
                y: anyY ? Math.random() * H : -10,
                r: 0.8 + depth * 2.4,
                vy: 0.35 + depth * 1.1,
                drift: Math.random() * Math.PI * 2,
                a: 0.35 + depth * 0.55
            };
        }

        resize();
        window.addEventListener("resize", resize);

        var last = performance.now();
        function frame(t) {
            var dt = Math.min((t - last) / 16.67, 3);
            last = t;
            if (!document.hidden) {
                ctx.clearRect(0, 0, W, H);
                ctx.fillStyle = "#fff";
                for (var i = 0; i < flakes.length; i++) {
                    var f = flakes[i];
                    f.y += f.vy * dt;
                    f.drift += 0.012 * dt;
                    f.x += Math.sin(f.drift) * 0.35 * dt;
                    if (f.y > H + 8 || f.x < -10 || f.x > W + 10) { flakes[i] = make(false); continue; }
                    ctx.globalAlpha = f.a;
                    ctx.beginPath();
                    ctx.arc(f.x, f.y, f.r, 0, 6.2832);
                    ctx.fill();
                }
                ctx.globalAlpha = 1;
            }
            requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
    }

    /* ---------- 5. Bông tuyết bung ra khi bấm nút chính ---------- */
    function sparkLayer() {
        var l = document.querySelector(".xm-spark-layer");
        if (!l) { l = el("div", "xm-spark-layer"); document.body.appendChild(l); }
        return l;
    }

    function burst(x, y, n) {
        if (REDUCED) return;
        var layer = sparkLayer();
        var glyphs = ["❄", "❅", "❆", "✦"];
        for (var i = 0; i < (n || 14); i++) {
            var a = Math.random() * Math.PI * 2, r = 36 + Math.random() * 60;
            var p = el("div", "xm-spark",
                "left:" + x + "px;top:" + y + "px;font-size:" + (10 + Math.random() * 10) + "px" +
                ";--dx:" + Math.cos(a) * r + "px;--dy:" + (Math.sin(a) * r + 24) + "px" +
                ";animation-duration:" + (0.6 + Math.random() * 0.5) + "s");
            p.textContent = glyphs[i % glyphs.length];
            layer.appendChild(p);
            (function (node) { setTimeout(function () { node.remove(); }, 1200); })(p);
        }
    }

    function wireSparks() {
        var sel = ".btn-export, .btn-filter, .btn-apply, .btn-update, .btn-update-vendor, .btn-update-inbound, .btn-login";
        document.addEventListener("click", function (e) {
            var t = e.target.closest ? e.target.closest(sel) : null;
            if (!t) return;
            var r = t.getBoundingClientRect();
            burst(r.left + r.width / 2, r.top + r.height / 2, 16);
        }, true);
    }

    function init() {
        buildFrame();
        markActiveNav();
        buildSnow();
        buildBanner();
        wireSparks();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();

    window.Christmas = { burst: burst, openBoard: openBoard, openRules: openRules, prizes: prizes, playAgain: playAgain };
})();
