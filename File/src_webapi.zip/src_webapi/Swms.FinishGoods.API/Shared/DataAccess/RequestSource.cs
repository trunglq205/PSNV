﻿using Swms.FinishGoods.API.Features.StockEvents.Business;

namespace Swms.FinishGoods.API.Shared.DataAccess
{
    /// <summary>
    /// Nguồn phát sinh request hiện tại, để ghi đúng wms.stock_events.source.
    ///
    /// Trước đây mọi event do người dùng tạo đều ghi 'WEB' vì API không có cách
    /// phân biệt Web với PDA (ICurrentUser chỉ mang thông tin user). Lịch sử vì
    /// thế nói sai nguồn: tách pallet, gán vị trí, lưu kho... đều do PDA làm
    /// nhưng đọc lại thấy WEB.
    ///
    /// Cách phân biệt: client gửi header <c>X-Client</c>. Đây đúng là hướng đã
    /// ghi trong chú thích của <see cref="StockEventSources"/>.
    /// </summary>
    public interface IRequestSource
    {
        /// <summary>
        /// Giá trị cho <c>stock_events.source</c>. Luôn là một hằng trong
        /// <see cref="StockEventSources"/>, không bao giờ null.
        /// </summary>
        string Current { get; }
    }

    public sealed class RequestSource : IRequestSource
    {
        /// <summary>Header client tự khai. Không tin tuyệt đối — chỉ dùng để ghi log.</summary>
        public const string HeaderName = "X-Client";

        private readonly IHttpContextAccessor _http;

        public RequestSource(IHttpContextAccessor http) => _http = http;

        public string Current
        {
            get
            {
                var ctx = _http.HttpContext;

                // Không có HttpContext -> đang chạy trong job nền (SyncRunner tự
                // tạo scope). Các job đó đều set source tường minh (FOSS/HDSOFT),
                // nên nhánh này chỉ là phương án cuối; JOB vẫn đúng hơn WEB.
                if (ctx is null) return StockEventSources.Job;

                var raw = ctx.Request.Headers[HeaderName].ToString().Trim();
                return Map(raw);
            }
        }

        /// <summary>
        /// Chỉ nhận đúng tập giá trị đã biết. Header là chuỗi client tự gửi nên
        /// không được ghi thẳng vào DB: cột source là varchar(10) và còn dùng để
        /// nhóm/lọc báo cáo, nhận bừa là vừa tràn cột vừa làm bẩn dữ liệu nhóm.
        /// Giá trị lạ hoặc rỗng -> WEB, giữ đúng hành vi cũ.
        /// </summary>
        private static string Map(string raw) => raw.ToUpperInvariant() switch
        {
            "PDA" => StockEventSources.Pda,
            "WEB" => StockEventSources.Web,
            "API" => StockEventSources.Api,
            "SAP" => StockEventSources.Sap,
            _ => StockEventSources.Web,
        };
    }
}
