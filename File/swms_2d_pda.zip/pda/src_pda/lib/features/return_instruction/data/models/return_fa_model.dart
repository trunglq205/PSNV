import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_instruction_model.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_entities.dart';

part 'return_fa_model.g.dart';

/// KHÔNG dùng `fieldRename: FieldRename.snake` — API dùng camelCase. Xem ghi
/// chú ở `return_instruction_model.dart`.

/// Một dòng sổ serial dạng gọn: GET {docId}/serial-index.
@JsonSerializable(createToJson: false)
class ReturnSerialIndexModel {
  final String serial;
  final String model;
  final String status;

  const ReturnSerialIndexModel({
    required this.serial,
    required this.model,
    required this.status,
  });

  factory ReturnSerialIndexModel.fromJson(Map<String, dynamic> json) =>
      _$ReturnSerialIndexModelFromJson(json);

  ReturnSerialIndexEntry toEntity() => ReturnSerialIndexEntry(
        serial: serial,
        model: model,
        status: status,
      );
}

/// Một thùng FA gửi lên. KHÔNG có `model` — sổ đã biết model từng con.
@JsonSerializable(createFactory: false)
class FaPalletBoxRequestModel {
  final String? boxNo;
  final List<String> serials;

  const FaPalletBoxRequestModel({required this.serials, this.boxNo});

  factory FaPalletBoxRequestModel.fromDraft(FaBoxDraft d) =>
      FaPalletBoxRequestModel(boxNo: d.boxNo, serials: d.serials);

  Map<String, dynamic> toJson() => _$FaPalletBoxRequestModelToJson(this);
}

/// Thân POST /api/return-instructions/{docId}/fa-pallets.
@JsonSerializable(createFactory: false)
class CreateFaPalletRequestModel {
  final List<FaPalletBoxRequestModel> boxes;

  const CreateFaPalletRequestModel({required this.boxes});

  factory CreateFaPalletRequestModel.fromDrafts(List<FaBoxDraft> drafts) =>
      CreateFaPalletRequestModel(
        boxes: drafts.map(FaPalletBoxRequestModel.fromDraft).toList(),
      );

  Map<String, dynamic> toJson() => _$CreateFaPalletRequestModelToJson(this);
}

/// Response của một lần FA đóng pallet.
///
/// `mismatches` server trả là nhật ký CÒN MỞ của cả phiếu, không chỉ lần quét
/// này — PDA không dùng tới (máy đã có danh sách của chính lần quét), nên bỏ
/// qua khi parse: thêm field chỉ để đó là thêm một chỗ phải nuôi.
@JsonSerializable(createToJson: false)
class CreateFaPalletResponseModel {
  final int palletId;
  final String lotNo;
  final int categoryCode;
  final int boxCount;
  final int serialCount;
  final int mismatchCount;
  final ReturnInstructionModel doc;

  const CreateFaPalletResponseModel({
    required this.palletId,
    required this.lotNo,
    required this.categoryCode,
    required this.boxCount,
    required this.serialCount,
    required this.mismatchCount,
    required this.doc,
  });

  factory CreateFaPalletResponseModel.fromJson(Map<String, dynamic> json) =>
      _$CreateFaPalletResponseModelFromJson(json);

  FaPalletResult toEntity() => FaPalletResult(
        palletId: palletId,
        lotNo: lotNo,
        categoryCode: categoryCode,
        boxCount: boxCount,
        serialCount: serialCount,
        mismatchCount: mismatchCount,
        doc: doc.toEntity(),
      );
}
