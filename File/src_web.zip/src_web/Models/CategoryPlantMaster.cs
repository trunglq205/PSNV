﻿namespace SWMS_WebTool.Models
{
    public class CategoryPlantMaster
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string SpecialPart { get; set; }
    }

    public class CategoryKittingtype
    {
        public string Category { get; set; }
        public string KittingType { get; set; }
    }
}
