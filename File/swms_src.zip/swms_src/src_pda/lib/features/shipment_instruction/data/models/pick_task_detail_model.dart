import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/shipment_instruction/data/models/shipment_instruction_model.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';

part 'pick_task_detail_model.g.dart';

/// GET  /api/shipment-instructions/tasks/{taskId}/pick
/// POST /api/shipment-instructions/tasks/{taskId}/confirm-pallet
/// POST /api/shipment-instructions/tasks/{taskId}/boxes
/// DEL  /api/shipment-instructions/tasks/{taskId}/boxes/{boxNo}
/// POST /api/shipment-instructions/tasks/{taskId}/vanning
@JsonSerializable(createToJson: false)
class PickTaskDetailModel {
  final PickTaskModel task;
  final int pcsPerBox;
  final List<PickBoxModel> boxes;

  const PickTaskDetailModel({
    required this.task,
    this.pcsPerBox = 0,
    this.boxes = const [],
  });

  factory PickTaskDetailModel.fromJson(Map<String, dynamic> json) =>
      _$PickTaskDetailModelFromJson(json);

  /// Task trong response không có model / PO (thuộc dòng SI) → lấy từ task
  /// đang cầm trên tuyến.
  PickTaskDetail toEntity({required String model, String? poNo}) =>
      PickTaskDetail(
        task: task.toEntity(model: model, poNo: poNo),
        pcsPerBox: pcsPerBox,
        boxes: boxes.map((e) => e.toEntity()).toList(),
      );
}

@JsonSerializable(createToJson: false)
class PickBoxModel {
  final int boxId;
  final String boxNo;
  final DateTime? productionDate;
  final int qty;
  final String? state;

  const PickBoxModel({
    required this.boxId,
    required this.boxNo,
    this.productionDate,
    this.qty = 0,
    this.state,
  });

  factory PickBoxModel.fromJson(Map<String, dynamic> json) =>
      _$PickBoxModelFromJson(json);

  PickBox toEntity() => PickBox(
    boxId: boxId,
    boxNo: boxNo,
    productionDate: productionDate,
    qty: qty,
    state: PickBoxState.fromKey(state),
  );
}

@JsonSerializable(createFactory: false)
class ConfirmPalletRequest {
  final String palletCode;
  const ConfirmPalletRequest(this.palletCode);
  Map<String, dynamic> toJson() => _$ConfirmPalletRequestToJson(this);
}

@JsonSerializable(createFactory: false)
class PickBoxRequest {
  final String boxNo;
  const PickBoxRequest(this.boxNo);
  Map<String, dynamic> toJson() => _$PickBoxRequestToJson(this);
}

/// Lưu pallet tại vị trí vanning.
///   palletCode : pallet gốc (nguyên pallet / lấy hết thùng) hoặc pallet
///                mới tách (chứa các thùng đã lấy của task).
///   locatorCode: vị trí trong khu vanning; phải khớp toLocatorCode nếu có.
@JsonSerializable(createFactory: false)
class StageVanningRequest {
  final String palletCode;
  final String locatorCode;
  const StageVanningRequest({
    required this.palletCode,
    required this.locatorCode,
  });
  Map<String, dynamic> toJson() => _$StageVanningRequestToJson(this);
}