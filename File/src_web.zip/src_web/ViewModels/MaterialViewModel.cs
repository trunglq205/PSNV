﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using Microsoft.CSharp;

namespace SWMS_WebTool.ViewModels
{
    public class MaterialViewModel : TableViewModel<MaterialInfo, MaterialFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, MaterialFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Material = filter?.Material ?? Filter.Material,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
