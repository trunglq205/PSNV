import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_suggestion.dart';

abstract interface class PartCardRepository {
  /// In mới · bước 2: lịch sử in gần nhất của [model] (mới nhất trước) — để
  /// gợi ý kích thước / cate / origin / qty / weight.
  Future<List<PartCardHistorySample>> getHistorySamples(String model);

  /// In mới · bước 3: lưu lịch sử in — 1 hoặc nhiều phiếu trong 1 lần gọi.
  Future<List<PartCardPrintHistory>> savePrintHistory(
    List<PartCardPrintParams> items,
  );

  /// Sửa: id trên server của phiếu có đúng [payload]; null = không có / đã xoá.
  Future<int?> findIdByPayload(String payload);

  /// Sửa: ghi đè phiếu [id] theo [item]. Trả `false` khi server báo không tìm
  /// thấy (404 — phiếu đã bị xoá); lỗi khác thì ném ra như thường.
  Future<bool> updatePrintHistory(int id, PartCardPrintParams item);

  /// Tách: tạo [items] + huỷ tem [sourcePayload] trong 1 transaction.
  Future<List<PartCardPrintHistory>> splitPrintHistory(
    String sourcePayload,
    List<PartCardPrintParams> items,
  );

  /// Gộp: tạo [item] + huỷ toàn bộ [sourcePayloads] trong 1 transaction.
  Future<PartCardPrintHistory> mergePrintHistory(
    List<String> sourcePayloads,
    PartCardPrintParams item,
  );
}
