import 'package:freezed_annotation/freezed_annotation.dart';
import 'base_request_model.dart';

part 'robot_call_request_model.g.dart';

@JsonSerializable()
class RobotCallRequestModel extends BaseRequestModel {
  RobotCallRequestModel({
    required this.qrcode,
    required this.isUgent,
    required this.isCancel,

  });
  factory RobotCallRequestModel.fromJson(Map<String, dynamic> json) =>
      _$RobotCallRequestModelFromJson(json);

  final String qrcode;
  final bool isUgent;
  final bool isCancel;

  @override
  Map<String, dynamic> toJson() => _$RobotCallRequestModelToJson(this);
}
