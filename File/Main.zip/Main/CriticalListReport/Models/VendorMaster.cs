﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("VendorMaster")]
    public class VendorMaster
    {
        public int ID { get; set; }
        public string? Vendor { get; set; }
        public string? VendorName { get; set; }
        public string? FreightUnit { get; set; }
    }
}
