// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'assignment_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

AssignmentModel _$AssignmentModelFromJson(Map<String, dynamic> json) =>
    AssignmentModel(
      id: json['id'] as String,
      type: json['type'] as String,
      code: json['code'] as String,
      done: (json['done'] as num).toInt(),
      total: (json['total'] as num).toInt(),
      subArgs:
          (json['subArgs'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
      deadlineText: json['deadlineText'] as String? ?? '',
      urgent: json['urgent'] as bool? ?? false,
    );

Map<String, dynamic> _$AssignmentModelToJson(AssignmentModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'type': instance.type,
      'code': instance.code,
      'subArgs': instance.subArgs,
      'deadlineText': instance.deadlineText,
      'urgent': instance.urgent,
      'done': instance.done,
      'total': instance.total,
    };
