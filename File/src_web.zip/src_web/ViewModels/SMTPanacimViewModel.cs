﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using Microsoft.CSharp;

namespace SWMS_WebTool.ViewModels
{
    public class SMTRCPanacimViewModel : TableViewModel<ReceivingCard, SMTPanacimFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, SMTPanacimFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                VendorCode = filter?.VendorCode ?? Filter.VendorCode,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                Date = (filter?.Date ?? Filter.Date)?.ToString("yyyy-MM-dd"),
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class SMTPanacimViewModel : TableViewModel<SMTPanacim, SMTPanacimFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, SMTPanacimFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                VendorCode = filter?.VendorCode ?? Filter.VendorCode,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                Date = filter?.Date ?? Filter.Date,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
