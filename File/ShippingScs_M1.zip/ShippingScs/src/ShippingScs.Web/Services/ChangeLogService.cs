using System.Security.Claims;
using System.Text.Json;
using Dapper;
using ShippingScs.Web.Data;

namespace ShippingScs.Web.Services;

public class ChangeLogEntry
{
    public long Id { get; set; }
    public string EntityType { get; set; } = "";
    public string? EntityKey { get; set; }
    public string Action { get; set; } = "";
    public string? Note { get; set; }
    public string? Payload { get; set; }
    public string? UserName { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>Ghi nhật ký thay đổi. Gọi sau mỗi thao tác làm đổi dữ liệu nghiệp vụ.</summary>
public class ChangeLogService
{
    private readonly Db _db;
    private readonly IHttpContextAccessor _http;

    public ChangeLogService(Db db, IHttpContextAccessor http)
    {
        _db = db;
        _http = http;
    }

    /// <param name="payload">Object bất kỳ, sẽ serialize JSON. null = không có.</param>
    /// <param name="userId">null = lấy user đang đăng nhập.</param>
    public async Task WriteAsync(string entityType, string? entityKey, string action,
        string? note, object? payload = null, int? userId = null)
    {
        userId ??= CurrentUserId(_http.HttpContext?.User);

        using var conn = _db.Connection();
        await conn.ExecuteAsync(@"
            INSERT INTO dbo.ChangeLogs (EntityType, EntityKey, Action, Note, Payload, UserId)
            VALUES (@entityType, @entityKey, @action, @note, @payload, @userId)",
            new
            {
                entityType,
                entityKey = Truncate(entityKey, 100),
                action,
                note = Truncate(note, 500),
                payload = payload == null ? null : JsonSerializer.Serialize(payload),
                userId,
            });
    }

    public async Task<List<ChangeLogEntry>> ListAsync(string? entityType, string? entityKey, int top = 200)
    {
        using var conn = _db.Connection();
        var rows = await conn.QueryAsync<ChangeLogEntry>(@"
            SELECT TOP (@top) l.Id, l.EntityType, l.EntityKey, l.Action, l.Note, l.Payload,
                   u.UserName, l.CreatedAt
            FROM dbo.ChangeLogs l
            LEFT JOIN dbo.Users u ON u.Id = l.UserId
            WHERE (@entityType IS NULL OR l.EntityType = @entityType)
              AND (@entityKey  IS NULL OR l.EntityKey  = @entityKey)
            ORDER BY l.Id DESC",
            new { top, entityType, entityKey });
        return rows.AsList();
    }

    public static int? CurrentUserId(ClaimsPrincipal? user)
    {
        var value = user?.FindFirst(ClaimTypes.NameIdentifier)?.Value;
        return int.TryParse(value, out var id) ? id : null;
    }

    private static string? Truncate(string? value, int max) =>
        value == null || value.Length <= max ? value : value.Substring(0, max);
}
