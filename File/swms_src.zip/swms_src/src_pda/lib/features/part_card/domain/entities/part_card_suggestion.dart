import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';

/// 1 lần in trong lịch sử của 1 model — rút gọn về các field dùng để gợi ý.
@immutable
class PartCardHistorySample {
  const PartCardHistorySample({
    required this.length,
    required this.width,
    required this.height,
    required this.weight,
    required this.qty,
    this.category,
    this.origin,
  });

  final double length;
  final double width;
  final double height;

  /// 0 = lịch sử không có.
  final double weight;

  /// pcs của model trên phiếu. 0 = lịch sử không có.
  final int qty;

  /// Mã số category (`Category.value`).
  final int? category;

  /// Mã origin (`PartCardOrigin.code`).
  final String? origin;
}

/// 1 gợi ý điền form: kích thước hộp + cate / origin / qty / weight đi kèm.
@immutable
class PartCardSuggestion {
  const PartCardSuggestion({
    required this.length,
    required this.width,
    required this.height,
    required this.weight,
    required this.qty,
    required this.count,
    this.category,
    this.origin,
  });

  final double length;
  final double width;
  final double height;
  final double weight;
  final int qty;
  final int? category;
  final String? origin;

  /// Số lần in: với chip = số lần dùng loại hộp này.
  final int count;

  String get boxText =>
      '${formatDecimal(length)}×${formatDecimal(width)}×${formatDecimal(height)}';

  /// Form đang dùng đúng hộp này → chip hiển thị trạng thái đã chọn.
  bool isSameBox(PartCardForm form) =>
      form.length == length && form.width == width && form.height == height;
}

/// Kết quả thống kê lịch sử in của 1 model.
/// Kết quả thống kê lịch sử in của 1 model.
@immutable
class PartCardSuggestions {
  const PartCardSuggestions({this.best, this.boxes = const []});

  static const empty = PartCardSuggestions();

  /// Số chip tối đa.
  static const int maxBoxes = 3;

  /// Hộp dùng nhiều nhất + cate / origin / qty / weight đi kèm → tự điền khi
  /// vào bước 2. Luôn trùng với chip đầu tiên (nếu có chip).
  final PartCardSuggestion? best;

  /// Các loại hộp hay dùng nhất. RỖNG khi lịch sử chỉ có ≤ 1 loại hộp.
  final List<PartCardSuggestion> boxes;

  /// [samples] phải xếp MỚI NHẤT TRƯỚC — hoà số lần thì ưu tiên cái gần nhất.
  ///
  /// Giá trị THIẾU (cate / origin null, qty / weight = 0) là "không biết",
  /// KHÔNG được tính như 1 lựa chọn — tránh phiếu cũ lưu thiếu dữ liệu
  /// thắng phiếu đủ dữ liệu chỉ vì nhiều hơn.
  factory PartCardSuggestions.fromSamples(List<PartCardHistorySample> samples) {
    if (samples.isEmpty) return empty;

    // Gom theo L×W×H. Map giữ thứ tự chèn, nên nhóm nào có bản ghi
    // mới nhất sẽ đứng trước.
    final byBox = <(double, double, double), List<PartCardHistorySample>>{};
    for (final s in samples) {
      byBox.putIfAbsent((s.length, s.width, s.height), () => []).add(s);
    }

    final fallbackCategory = _mode(samples.map((s) => s.category).nonNulls);
    final fallbackOrigin = _mode(samples.map((s) => s.origin).nonNulls);

    PartCardSuggestion build(List<PartCardHistorySample> group) {
      final first = group.first;
      return PartCardSuggestion(
        length: first.length,
        width: first.width,
        height: first.height,
        category:
            _mode(group.map((s) => s.category).nonNulls) ?? fallbackCategory,
        origin: _mode(group.map((s) => s.origin).nonNulls) ?? fallbackOrigin,
        qty: _mode(group.map((s) => s.qty).where((q) => q > 0)) ?? 0,
        weight: _mode(group.map((s) => s.weight).where((w) => w > 0)) ?? 0,
        count: group.length,
      );
    }

    final all = [for (final g in byBox.values) build(g)];
    final best = all.first;
    if (all.length < 2) return PartCardSuggestions(best: best);

    return PartCardSuggestions(
      best: best,
      boxes: all.take(maxBoxes).toList(growable: false),
    );
  }

  /// Giá trị xuất hiện nhiều nhất; hoà thì lấy giá trị gặp TRƯỚC (mới hơn).
  /// Rỗng → null.
  static T? _mode<T>(Iterable<T> values) {
    final counts = <T, int>{};
    for (final v in values) {
      counts[v] = (counts[v] ?? 0) + 1;
    }
    T? best;
    var bestCount = 0;
    counts.forEach((v, c) {
      if (c > bestCount) {
        best = v;
        bestCount = c;
      }
    });
    return best;
  }
}
