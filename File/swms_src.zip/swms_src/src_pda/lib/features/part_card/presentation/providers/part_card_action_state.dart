import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_mapper.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';

/// Bước của màn Sửa / Tách / Gộp.
enum PartCardActionStep { setup, print }

/// Tem nguồn đã quét: payload gốc (khoá tra server) + dữ liệu đọc từ tem.
@immutable
class PartCardSource {
  const PartCardSource({required this.payload, required this.card});

  final String payload;
  final PartCard card;

  String get cardId => card.cardId.trim();

  /// `MODEL×box, MODEL×box` — hiển thị gọn trong danh sách nguồn.
  String get summary => card.models
      .map((m) => '${PartCardMapper.normModel(m.model)}×${PartCardMapper.boxOf(m)}')
      .join(', ');
}

/// State màn thao tác trên tem ĐÃ IN — ĐỒNG BỘ.
/// Loading/error của call API do `appActionProvider` lo.
@immutable
class PartCardActionState {
  const PartCardActionState({
    required this.action,
    this.step = PartCardActionStep.setup,
    this.loading = true,
    this.mode = PartCardMode.single,
    this.form,
    this.sources = const [],
    this.splitParts = const [],
    this.saved = false,
    this.pendingPrint = const [],
  });

  final PartCardAction action;
  final PartCardActionStep step;

  /// Đang đọc tem nguồn lần đầu (tải danh mục Cate).
  final bool loading;

  final PartCardMode mode;

  /// edit / merge: phiếu sẽ in. split: phiếu NGUỒN (chỉ đọc).
  final PartCardForm? form;

  /// Tem nguồn theo thứ tự quét. edit / split: đúng 1.
  final List<PartCardSource> sources;

  /// split: từng tem con — phiếu ĐẦY ĐỦ (Dim / Weight / Cate / MFD / PO /
  /// Box / Qty / Origin / OQC), user sửa tự do như in mới.
  ///
  /// Giá trị ban đầu chép từ tem nguồn. Ràng buộc DUY NHẤT giữa các tem con:
  /// tổng Qty = Qty tem nguồn (xem [canSubmit]).
  final List<PartCardForm> splitParts;

  /// Đã lưu lên server. Từ đây KHÔNG lưu lại nữa, không sửa dữ liệu nữa —
  /// chỉ in nốt [pendingPrint].
  final bool saved;

  /// Nhãn đã lưu server nhưng CHƯA ra giấy.
  final List<PartCardPrintJob> pendingPrint;

  /// Đã lưu + in hết → page báo + đóng.
  bool get done => saved && pendingPrint.isEmpty;

  /// Số pcs của tem nguồn (split).
  int get sourceQty => form?.totalPcs ?? 0;

  int get splitTotal => splitParts.fold(0, (sum, p) => sum + p.totalPcs);

  /// Dương = chưa chia hết; âm = chia vượt tem nguồn.
  int get splitRemaining => sourceQty - splitTotal;

  /// Số thùng tem nguồn / tổng thùng tem con — CHỈ để hiển thị, không chặn.
  int get sourceBox => form?.totalBox ?? 0;

  int get splitBoxTotal => splitParts.fold(0, (sum, p) => sum + p.totalBox);

  int get droppedOnSingle {
    final count = form?.lines.length ?? 0;
    return count > 1 ? count - 1 : 0;
  }

  /// Đủ điều kiện sang bước in / lưu.
  ///
  /// split: mỗi tem con phải đủ field để in (cùng luật với in mới) và
  /// tổng Qty khớp tem nguồn. Box / Weight / Dim / PO… không ràng buộc chéo.
  bool get canSubmit {
    final complete = form?.isComplete ?? false;
    return switch (action) {
      PartCardAction.edit => complete,
      PartCardAction.merge => complete && sources.length >= 2,
      PartCardAction.split =>
      splitParts.length >= 2 &&
          splitParts.every((p) => p.isComplete && p.totalPcs > 0) &&
          splitRemaining == 0,
    };
  }

  /// Các phiếu sẽ in, theo đúng thứ tự (chưa gắn Card_ID).
  /// Tách / gộp luôn in NHIỀU MÃ (có ô PO, Box, Total).
  List<PartCardForm> get printForms {
    if (action == PartCardAction.split) {
      return [
        for (final p in splitParts) p.copyWith(mode: PartCardMode.multi),
      ];
    }
    final f = form?.copyWith(mode: mode);
    return f == null ? const [] : [f];
  }

  PartCardActionState copyWith({
    PartCardActionStep? step,
    bool? loading,
    PartCardMode? mode,
    PartCardForm? form,
    List<PartCardSource>? sources,
    List<PartCardForm>? splitParts,
    bool? saved,
    List<PartCardPrintJob>? pendingPrint,
  }) {
    return PartCardActionState(
      action: action,
      step: step ?? this.step,
      loading: loading ?? this.loading,
      mode: mode ?? this.mode,
      form: form ?? this.form,
      sources: sources ?? this.sources,
      splitParts: splitParts ?? this.splitParts,
      saved: saved ?? this.saved,
      pendingPrint: pendingPrint ?? this.pendingPrint,
    );
  }
}