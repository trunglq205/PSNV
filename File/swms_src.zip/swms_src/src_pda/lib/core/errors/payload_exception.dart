part of 'exceptions.dart';

/// Lỗi khi parse payload của part card (QR/barcode).
sealed class PayloadException extends AppException {
  const PayloadException(super.message, {required super.code});
}

class InvalidPayloadException extends PayloadException {
  const InvalidPayloadException()
      : super(
    'Thông tin payload không đúng định dạng',
    code: 'error.invalid_payload',
  );
}

class MissingPayloadFieldException extends PayloadException {
  const MissingPayloadFieldException(this.field)
      : super(
    'Thiếu thông tin bắt buộc: $field',
    code: 'error.missing_payload_field',
  );

  final String field;

  @override
  Map<String, String> get namedArgs => {'field': field};
}

class InvalidPayloadFieldException extends PayloadException {
  const InvalidPayloadFieldException({
    required this.field,
    required this.value,
  }) : super(
    'Giá trị không hợp lệ cho $field: "$value"',
    code: 'error.invalid_payload_field',
  );

  final String field;
  final String value;

  @override
  Map<String, String> get namedArgs => {
    'field': field,
    'value': value,
  };
}