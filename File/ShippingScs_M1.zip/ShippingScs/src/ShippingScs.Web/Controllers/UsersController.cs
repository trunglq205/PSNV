using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShippingScs.Web.Models;
using ShippingScs.Web.Services;

namespace ShippingScs.Web.Controllers;

[Authorize(Roles = Roles.Admin)]
public class UsersController : Controller
{
    private readonly UserService _users;

    public UsersController(UserService users) => _users = users;

    public async Task<IActionResult> Index() => View(await _users.ListAsync());

    [HttpGet]
    public IActionResult Create() => View("Edit", new UserEditModel());

    [HttpGet]
    public async Task<IActionResult> Edit(int id)
    {
        var u = await _users.GetAsync(id);
        if (u == null) return NotFound();
        return View(new UserEditModel
        {
            Id = u.Id,
            UserName = u.UserName,
            FullName = u.FullName,
            Email = u.Email,
            PicCode = u.PicCode,
            Role = u.Role,
            IsActive = u.IsActive,
        });
    }

    [HttpPost]
    public async Task<IActionResult> Save(UserEditModel model)
    {
        if (!ModelState.IsValid) return View("Edit", model);

        try
        {
            var byUserId = ChangeLogService.CurrentUserId(User);
            if (model.Id == 0)
                await _users.CreateAsync(model, byUserId);
            else
                await _users.UpdateAsync(model, byUserId);

            TempData["Success"] = $"Đã lưu user {model.UserName}.";
            return RedirectToAction(nameof(Index));
        }
        catch (BusinessException ex)
        {
            ModelState.AddModelError("", ex.Message);
            model.NewPassword = null;
            return View("Edit", model);
        }
    }
}
