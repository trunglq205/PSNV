import 'package:dio/dio.dart';
import 'package:swms_finish_goods/core/storage/secure_storage_service.dart';

/// Gắn access token vào header mỗi request.
class AuthInterceptor extends Interceptor {
  final SecureStorageService _storage;
  AuthInterceptor(this._storage);

  @override
  Future<void> onRequest(
    RequestOptions options,
    RequestInterceptorHandler handler,
  ) async {
    final token = await _storage.readToken();
    if (token != null && token.isNotEmpty) {
      options.headers['Authorization'] = 'Bearer $token';
    }
    handler.next(options);
  }
}
