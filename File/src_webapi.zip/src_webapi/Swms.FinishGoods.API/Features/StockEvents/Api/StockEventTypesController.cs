﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Net.Http.Headers;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.StockEvents.Business;

namespace Swms.FinishGoods.API.Features.StockEvents.Api
{
    /// <summary>
    /// Catalog loại event.
    ///
    /// Tồn tại để nhãn / màu / icon KHÔNG phải lặp ở mọi dòng timeline: chỉ có 29
    /// tổ hợp, trong khi một timeline 50 event sẽ lặp cùng chuỗi 50 lần.
    ///
    /// Client tải một lần, cache theo ETag:
    ///   Blazor  — singleton giữ trong bộ nhớ
    ///   Flutter — Riverpod provider + SharedPreferences
    /// Tra theo eventCode khi render.
    /// </summary>
    [ApiController]
    [Route("api/stock-event-types")]
    public class StockEventTypesController : ControllerBase
    {
        private readonly IStockEventService _service;
        public StockEventTypesController(IStockEventService service) => _service = service;

        /// <param name="subjectType">pallet | box. Bỏ trống = cả hai.</param>
        [HttpGet]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<StockEventTypeListResponse>> GetAll(
            [FromQuery] string? subjectType = null)
        {
            var result = await _service.GetEventTypesAsync(subjectType);

            // Version là hash nội dung: seed không đổi -> client dùng lại bản cache,
            // đổi một dòng seed -> ETag đổi và client tải lại ngay.
            var etag = $"\"{result.Version}\"";

            if (Request.Headers.TryGetValue(HeaderNames.IfNoneMatch, out var inm)
                && inm.ToString() == etag)
                return StatusCode(StatusCodes.Status304NotModified);

            Response.Headers[HeaderNames.ETag] = etag;
            return Ok(result);
        }
    }
}