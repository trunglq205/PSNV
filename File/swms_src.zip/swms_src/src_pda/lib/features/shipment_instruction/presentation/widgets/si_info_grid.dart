import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Một ô nhãn/giá trị. [mono] cho mã, ngày giờ.
class SiInfoItem {
  final String label;
  final String value;
  final bool mono;

  const SiInfoItem(this.label, this.value, {this.mono = false});
}

/// Lưới 2 cột nhãn / giá trị.
class SiInfoGrid extends StatelessWidget {
  final List<SiInfoItem> items;

  const SiInfoGrid({super.key, required this.items});

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var i = 0; i < items.length; i += 2) {
      if (i > 0) rows.add(const SizedBox(height: AppDimens.sm));
      rows.add(
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Expanded(child: _Cell(items[i])),
            const SizedBox(width: AppDimens.sm),
            Expanded(
              child: i + 1 < items.length
                  ? _Cell(items[i + 1])
                  : const SizedBox.shrink(),
            ),
          ],
        ),
      );
    }
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: rows,
    );
  }
}

class _Cell extends StatelessWidget {
  final SiInfoItem item;
  const _Cell(this.item);

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final valueStyle = item.mono
        ? AppTextStyles.code.copyWith(
            fontSize: 13,
            letterSpacing: 0,
            fontWeight: FontWeight.w600,
            color: swms.text1,
          )
        : AppTextStyles.bodyStrong.copyWith(color: swms.text1);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          item.label,
          style: AppTextStyles.caption.copyWith(color: swms.text3),
        ),
        const SizedBox(height: 2),
        Text(item.value, style: valueStyle, overflow: TextOverflow.ellipsis),
      ],
    );
  }
}
