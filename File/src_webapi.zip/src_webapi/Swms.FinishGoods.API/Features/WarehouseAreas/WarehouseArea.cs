namespace Swms.FinishGoods.API.Features.WarehouseAreas;

/// <summary>Bản đồ kho (warehouse_areas). map_type cố định khi tạo.</summary>
public class WarehouseAreaSummary
{
    public long Id { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public string MapType { get; set; } = "storing"; // storing | receiving | vanning
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public bool IsActive { get; set; }
    public int CellCount { get; set; }      // số block đã vẽ trong map
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}
