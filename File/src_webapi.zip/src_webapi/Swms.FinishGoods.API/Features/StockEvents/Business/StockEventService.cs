﻿using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.StockEvents.Api;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.StockEvents.Business
{
    public interface IStockEventService
    {
        Task<PalletHistoryResponse> GetPalletHistoryAsync(long palletId, StockEventQuery query);
        Task<PalletHistoryResponse> GetPalletHistoryByLotNoAsync(string lotNo, StockEventQuery query);
        Task<BoxHistoryResponse> GetBoxHistoryAsync(long boxId, bool ownOnly);
        Task<BoxHistoryResponse> GetBoxHistoryByBoxNoAsync(string boxNo, string? palletCode, bool ownOnly);

        /// <summary>Catalog loại event — client tải một lần rồi cache theo Version.</summary>
        Task<StockEventTypeListResponse> GetEventTypesAsync(string? subjectType);
    }

    public class StockEventService : IStockEventService
    {
        private readonly IStockEventRepository _repo;
        private readonly IStringLocalizer<SharedResource> _localizer;

        public StockEventService(
            IStockEventRepository repo,
            IStringLocalizer<SharedResource> localizer)
        {
            _repo = repo;
            _localizer = localizer;
        }

        public async Task<PalletHistoryResponse> GetPalletHistoryAsync(long palletId, StockEventQuery query)
        {
            var history = await _repo.GetPalletHistoryAsync(palletId, query.ToFilter())
                ?? throw new NotFoundException(_localizer["History.PalletNotFound", palletId]);

            return PalletHistoryResponse.From(history);
        }

        public async Task<PalletHistoryResponse> GetPalletHistoryByLotNoAsync(string lotNo, StockEventQuery query)
        {
            lotNo = (lotNo ?? "").Trim();
            if (lotNo.Length == 0)
                throw new BusinessRuleException(_localizer["Lot.LotNoRequired"]);

            var history = await _repo.GetPalletHistoryByLotNoAsync(lotNo, query.ToFilter())
                ?? throw new NotFoundException(_localizer["History.PalletNotFound", lotNo]);

            return PalletHistoryResponse.From(history);
        }

        public async Task<BoxHistoryResponse> GetBoxHistoryAsync(long boxId, bool ownOnly)
        {
            var history = await _repo.GetBoxHistoryAsync(boxId, ownOnly)
                ?? throw new NotFoundException(_localizer["History.BoxNotFound", boxId]);

            return BoxHistoryResponse.From(history);
        }

        public async Task<BoxHistoryResponse> GetBoxHistoryByBoxNoAsync(
            string boxNo, string? palletCode, bool ownOnly)
        {
            boxNo = (boxNo ?? "").Trim();
            if (boxNo.Length == 0)
                throw new NotFoundException(_localizer["History.BoxNotFound", ""]);

            var history = await _repo.GetBoxHistoryByBoxNoAsync(boxNo, palletCode, ownOnly)
                ?? throw new NotFoundException(_localizer["History.BoxNotFound", boxNo]);

            return BoxHistoryResponse.From(history);
        }

        public async Task<StockEventTypeListResponse> GetEventTypesAsync(string? subjectType)
        {
            var types = await _repo.GetEventTypesAsync(subjectType);
            return StockEventTypeListResponse.From(types);
        }
    }
}