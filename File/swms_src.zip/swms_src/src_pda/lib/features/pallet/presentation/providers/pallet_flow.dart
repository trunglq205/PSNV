import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';

/// 3 màn "quét pallet → chọn hành động → quét vị trí → xác nhận" chỉ khác nhau
/// ở: dữ liệu nạp thêm, hành động được phép hiện, và chữ trên màn.
/// Gom thành 1 enum để dùng chung 1 notifier + 1 body.
enum PalletFlow {
  /// Vị trí tạm: gán / rời / chuyển.
  tempLocation,

  /// Lưu kho: chỉ "store", có gợi ý vị trí.
  storing,

  /// Chuyển / Out (pallet đã lưu kho): move, bỏ assign.
  warehouseMove,

  /// Khu tập kết (vanning): đưa pallet đã soạn ra khu chờ đóng cont.
  /// Chỉ gán / chuyển vào vị trí — không lưu kho, không rời vị trí.
  vanningArea;

  /// Dữ liệu cần nạp thêm khi lookup ở bước 1.
  ///
  /// Storing KHÔNG còn `PalletInclude.suggestion`: gợi ý vị trí đã tách sang
  /// `GET by-lot-no/{lotNo}/storage-suggestion` vì cần thêm chiều cao pallet.
  Set<PalletInclude> get include => const {};

  /// Màn này có gọi API gợi ý vị trí lưu kho hay không.
  bool get needsStorageSuggestion => this == PalletFlow.storing;

  /// Loại khu (`warehouse_areas.map_type`) mà màn này được phép quét vị trí.
  String get mapType => switch (this) {
    PalletFlow.tempLocation => 'receiving',
    PalletFlow.storing => 'storing',
    PalletFlow.warehouseMove => 'storing',
    PalletFlow.vanningArea => 'vanning',
  };

  /// Lọc `allowedActions` của server theo màn.
  List<PalletAction> actionsFor(Pallet p) {
    final wanted = switch (this) {
      PalletFlow.tempLocation => {
        PalletAction.assign,
        PalletAction.moveReceiving,
      },
      PalletFlow.storing => {PalletAction.store},
      PalletFlow.warehouseMove => {PalletAction.moveStoring},
      PalletFlow.vanningArea => {
        PalletAction.vanning,
        PalletAction.moveVanning,
      },
    };
    return p.allowedActions.where(wanted.contains).toList();
  }
}
