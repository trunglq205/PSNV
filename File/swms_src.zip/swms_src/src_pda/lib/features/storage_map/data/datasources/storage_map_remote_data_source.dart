import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/storage_map/data/models/storage_map_models.dart';

part 'storage_map_remote_data_source.g.dart';

@RestApi()
abstract class StorageMapRemoteDataSource {
  factory StorageMapRemoteDataSource(Dio dio, {String baseUrl}) =
      _StorageMapRemoteDataSource;

  /// Danh sách bản đồ theo loại (storing / receiving / vanning).
  @GET('/api/warehouse-areas')
  Future<List<WarehouseAreaModel>> fetchAreas({
    @Query('type') String? type,
  });

  /// Bản đồ top-down của một khu lưu trữ (null = khu mặc định).
  @GET('/api/storage/top-map')
  Future<StorageTopMapModel> fetchTopMap({
    @Query('areaCode') String? areaCode,
  });

  /// Mặt cắt 1 kệ trong khu chỉ định.
  @GET('/api/storage/racks/{rackCode}/elevation')
  Future<RackElevationModel> fetchElevation(
    @Path('rackCode') String rackCode, {
    @Query('areaCode') String? areaCode,
  });

  @GET('/api/storage/locate/{locatorCode}')
  Future<LocatorLocationModel> locate(@Path('locatorCode') String locatorCode);

  /// Serial của từng thùng trong 1 pallet.
  @GET('/api/storage/pallets/{palletCode}/serials')
  Future<List<PalletSerialModel>> serials(@Path('palletCode') String palletCode);
}
