import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';
import 'package:swms_finish_goods/features/container_check/presentation/providers/container_check_state.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/condition_checklist_card.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/container_header_card.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/container_inspect_skeleton.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/container_status_pill.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/photo_slots_card.dart';

/// Chế độ kiểm: thẻ container + checklist + 4 ảnh. Nút chốt nằm ở
/// bottomNavigationBar của page (xem [ContainerInspectActions]).
class ContainerInspectView extends ConsumerWidget {
  final ContainerCheckState state;
  final ContainerItem item;
  final VoidCallback onRetry;
  final ValueChanged<ContainerCondition> onToggle;
  final ValueChanged<ContainerPhotoSlot> onCapture;
  final ValueChanged<ContainerPhotoSlot> onRemovePhoto;

  const ContainerInspectView({
    super.key,
    required this.state,
    required this.item,
    required this.onRetry,
    required this.onToggle,
    required this.onCapture,
    required this.onRemovePhoto,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return ListView(
      padding: const EdgeInsets.all(AppDimens.md),
      children: [
        // Header hiện ngay từ dòng danh sách; chỉ cờ SAP chờ chi tiết.
        ContainerHeaderCard(item: item),
        const SizedBox(height: AppDimens.sm),
        ...state.detail.when(
          loading: () => const [ContainerInspectSkeleton()],
          error: (e, _) => [
            AppErrorView.widget(
              message: ref.read(errorHandlerProvider).getMessage(e),
              onRetry: onRetry,
            ),
          ],
          data: (d) => _body(d.status),
        ),
      ],
    );
  }

  List<Widget> _body(ContainerStatus status) {
    final editable = state.editable;
    return [
      if (status != ContainerStatus.verify) ...[
        _ReadOnlyBanner(status: status),
        const SizedBox(height: AppDimens.sm),
      ],
      ConditionChecklistCard(
        checked: state.checked,
        onToggle: editable ? onToggle : null,
      ),
      const SizedBox(height: AppDimens.sm),
      PhotoSlotsCard(
        photos: state.photos,
        onCapture: editable ? onCapture : null,
        onRemove: editable ? onRemovePhoto : null,
      ),
    ];
  }
}

/// Thanh nút đáy chế độ kiểm: Không đạt · Xác nhận đạt.
class ContainerInspectActions extends StatelessWidget {
  final ContainerCheckState state;
  final VoidCallback onFail;
  final VoidCallback onPass;

  const ContainerInspectActions({
    super.key,
    required this.state,
    required this.onFail,
    required this.onPass,
  });

  @override
  Widget build(BuildContext context) => Row(
    children: [
      Expanded(
        child: AppButton(
          label: LocaleKeys.container_check_btn_fail.tr(),
          icon: Icons.warning_amber_rounded,
          variant: AppButtonVariant.danger,
          isFullWidth: false,
          onPressed: state.canFail ? onFail : null,
        ),
      ),
      const SizedBox(width: AppDimens.sm),
      Expanded(
        child: AppButton(
          label: LocaleKeys.container_check_btn_pass.tr(),
          icon: Icons.check_rounded,
          variant: AppButtonVariant.success,
          isFullWidth: false,
          isLoading: state.submitting,
          onPressed: state.canPass ? onPass : null,
        ),
      ),
    ],
  );
}

/// Container không còn "chờ kiểm" → báo rõ vì sao không thao tác được.
class _ReadOnlyBanner extends StatelessWidget {
  final ContainerStatus status;
  const _ReadOnlyBanner({required this.status});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return AppCard(
      padding: const EdgeInsets.all(AppDimens.sm + 4),
      child: Row(
        children: [
          Icon(Icons.lock_outline_rounded, size: 18, color: c.text3),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text(
              LocaleKeys.container_check_read_only.tr(),
              style: AppTextStyles.body.copyWith(color: c.text2),
            ),
          ),
          ContainerStatusPill(status: status),
        ],
      ),
    );
  }
}