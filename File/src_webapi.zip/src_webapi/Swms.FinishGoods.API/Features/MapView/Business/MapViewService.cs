using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.MapView.DataAccess;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.MapView.Business;

public class MapViewService : IMapViewService
{
    private readonly IMapViewRepository _repo;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public MapViewService(IMapViewRepository repo, IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _localizer = localizer;
    }

    public async Task<MapViewLayout> GetLayoutAsync(string areaCode)
    {
        var code = (areaCode ?? "").Trim().ToUpperInvariant();
        return await _repo.GetLayoutAsync(code)
            ?? throw new NotFoundException(_localizer["MapDesign.Err.AreaNotFound", code]);
    }
}
