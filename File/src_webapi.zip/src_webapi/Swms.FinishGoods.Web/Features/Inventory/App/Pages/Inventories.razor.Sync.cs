using Microsoft.AspNetCore.Components;
using Swms.FinishGoods.Web.Features.Sync.Business;
using Swms.FinishGoods.Web.Features.Sync.Business.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.App.Pages;

// Cụm đồng bộ: job chạy trên SERVER (API). Trang chỉ gửi lệnh và hỏi trạng thái
// mỗi 2 giây khi dialog đang mở. Đóng dialog, rời trang, tắt máy — job vẫn chạy;
// mở lại dialog (từ máy nào cũng được) là thấy tiếp tiến độ.
//
// Markup trang Inventories.razor:
//   <SyncJobDialog Open="_hdSyncOpen"
//                     Status="_sync"
//                     Error="_syncError"
//                     OnStart="StartSync"
//                     OnCancel="CancelSync"
//                     OnClose="CloseHdSoftSync" />
public partial class Inventories : IDisposable
{
    [Inject] private ISyncBusiness SyncJobs { get; set; } = default!;

    private static readonly TimeSpan SyncPollInterval = TimeSpan.FromSeconds(2);

    private bool _hdSyncOpen;
    private SyncStatusDto _sync = new();
    private string? _syncError;
    private bool _syncWasRunning;
    private CancellationTokenSource? _syncPollCts;

    private async Task OpenHdSoftSync()
    {
        _hdSyncOpen = true;
        _syncError = null;
        await RefreshSyncStatusAsync();
        StartSyncPolling();
    }

    private void CloseHdSoftSync()
    {
        _hdSyncOpen = false;
        StopSyncPolling();
    }

    private async Task StartSync(SyncStartArgs args)
    {
        _syncError = null;

        var r = await SyncJobs.StartSyncAsync(args.Kind, args.Full);
        if (!r.IsSuccess || r.Value is null)
        {
            _syncError = r.ErrorMessage ?? L["Inventory.HdSync.UnknownError"];
            return;
        }

        _sync = r.Value;
        if (_sync.AlreadyRunning) _syncError = L["Inventory.HdSync.AlreadyRunning"];
        _syncWasRunning = _sync.IsRunning;
        StartSyncPolling();
    }

    private async Task CancelSync()
    {
        var r = await SyncJobs.CancelSyncAsync();
        if (r.IsSuccess && r.Value is not null) _sync = r.Value;
    }

    private void StartSyncPolling()
    {
        if (_syncPollCts is not null) return;
        _syncPollCts = new CancellationTokenSource();
        _ = PollSyncAsync(_syncPollCts.Token);
    }

    private void StopSyncPolling()
    {
        _syncPollCts?.Cancel();
        _syncPollCts?.Dispose();
        _syncPollCts = null;
    }

    private async Task PollSyncAsync(CancellationToken ct)
    {
        using var timer = new PeriodicTimer(SyncPollInterval);
        try
        {
            while (await timer.WaitForNextTickAsync(ct))
            {
                await RefreshSyncStatusAsync();
                await InvokeAsync(StateHasChanged);
            }
        }
        catch (OperationCanceledException) { /* đóng dialog / rời trang */ }
    }

    private async Task RefreshSyncStatusAsync()
    {
        var r = await SyncJobs.GetSyncStatusAsync();
        if (!r.IsSuccess || r.Value is null) return;

        var wasRunning = _syncWasRunning;
        _sync = r.Value;
        _syncWasRunning = _sync.IsRunning;

        // Vừa chạy xong và có thay đổi -> làm mới bảng + 5 card.
        if (wasRunning && !_sync.IsRunning && _sync.HasChanges)
            await InvokeAsync(ReloadAsync);
    }

    public override void Dispose()
    {
        StopSyncPolling();
        _exportCts?.Cancel();
        base.Dispose();
    }
}
