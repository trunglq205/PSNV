﻿using Swms.FinishGoods.API.Features.Auth.Business;

namespace Swms.FinishGoods.API.Features.Auth.DataAccess;

public interface IApiKeyRepository
{
    Task<long> CreateAsync(ApiKey key);
    Task<ApiKey?> GetByPrefixAsync(string prefix);
    Task<ApiKey?> GetByIdAsync(long id);
    Task<IReadOnlyList<ApiKey>> ListAsync();
    Task UpdateLastUsedAsync(long id, DateTime utcNow);
    Task RevokeAsync(long id, DateTime utcNow, string? by);

    // Rotate: tạo key mới + revoke MỌI key active cùng client, nguyên tử.
    // Trả về id key mới.
    Task<long> RotateForClientAsync(ApiKey newKey, string clientName, DateTime utcNow, string? by);
}