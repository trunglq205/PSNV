﻿
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models
{
    public record Category
    {
        public long CategoryID { get; set; }
        
        [Required]
        [MaxLength(50)]
        public string Plant { get; set; }

        [Display(Name = "Category Name")]
        [Required]
        [MaxLength(50)]
        public string CategoryName { get; set; }
        
        [Display(Name = "Short Name")]
        [Required]
        [MaxLength(10)]
        public string ShortName { get; set; }
        public string Color { get; set; }

    }
}
