/// Cách lấy hàng tại 1 vị trí. Khớp `pickMode` của API.
enum PickMode {
  /// Lấy nguyên pallet — xác nhận bằng quét Pallet ID.
  wholePallet('pallet'),

  /// Lấy theo thùng, bắt buộc NSX cũ trước.
  fifoBox('fifo'),

  /// Lấy đúng các thùng được chỉ định.
  designatedBox('designated');

  const PickMode(this.key);
  final String key;

  /// null = key lạ → UI hiện nguyên key, không vỡ app.
  static PickMode? fromKey(String? key) {
    for (final m in values) {
      if (m.key == key?.trim().toLowerCase()) return m;
    }
    return null;
  }
}

/// Trạng thái 1 dòng kế hoạch. Khớp `shipmentStatus` của API:
/// server chỉ có `pending` | `picked` (không có trạng thái "đang lấy").
/// Đã lưu vanning hay chưa xem [PickTask.stagedLocatorCode].
enum PickTaskStatus {
  pending('pending'),
  done('picked');

  const PickTaskStatus(this.key);
  final String key;

  /// Key lạ / null → coi như chưa lấy (an toàn hơn là coi như xong).
  static PickTaskStatus fromKey(String? key) {
    for (final s in values) {
      if (s.key == key?.trim().toLowerCase()) return s;
    }
    return PickTaskStatus.pending;
  }
}

/// 1 điểm dừng trên tuyến soạn hàng. Khớp `SiTaskResponse` của API.
class PickTask {
  final int id;
  final int lineId;

  /// Thứ tự đi tuyến. API hiện CHƯA trả → null, giữ nguyên thứ tự API.
  final int? seq;

  /// Vị trí kệ. Pallet chưa putaway / chưa gán vị trí → null.
  final String? locatorCode;
  final String? areaCode;
  final String? palletCode;

  final PickMode? mode;
  final String? modeKey;

  /// "box" | "pallet" — giữ nguyên key, chưa cần enum.
  final String? unitType;
  final bool isFifo;

  /// Vị trí vanning chỉ định (3D loading). null = bất kỳ vị trí trong
  /// khu vanning, server kiểm tra khi lưu.
  final String? toLocatorCode;

  /// Vị trí vanning đã lưu. null = chưa lưu vanning.
  final String? stagedLocatorCode;
  final DateTime? stagedAt;

  final int boxPlanned;
  final int boxPicked;
  final int qtyPlanned;

  final PickTaskStatus status;
  final String? statusKey;

  /// NSX của pallet — căn cứ FIFO.
  final DateTime? productionDate;
  final DateTime? pickedAt;
  final String? pickedBy;
  final String? skipReason;

  /// Lấy từ dòng SI chứa nhiệm vụ (API task không lặp lại 2 field này).
  final String model;
  final String? poNo;

  const PickTask({
    required this.id,
    required this.lineId,
    required this.model,
    this.seq,
    this.locatorCode,
    this.areaCode,
    this.palletCode,
    this.mode,
    this.modeKey,
    this.unitType,
    this.isFifo = false,
    this.toLocatorCode,
    this.stagedLocatorCode,
    this.stagedAt,
    this.boxPlanned = 0,
    this.boxPicked = 0,
    this.qtyPlanned = 0,
    this.status = PickTaskStatus.pending,
    this.statusKey,
    this.productionDate,
    this.pickedAt,
    this.pickedBy,
    this.skipReason,
    this.poNo,
  });

  /// Đã lấy xong (server đóng task) — chưa chắc đã lưu vanning.
  bool get isDone => status == PickTaskStatus.done;

  /// Đã lưu vanning.
  bool get isStaged => stagedLocatorCode?.trim().isNotEmpty ?? false;

  /// Xong hẳn vị trí này: đã lấy + đã lưu vanning.
  bool get isComplete => isDone && isStaged;

  bool get hasLocator => locatorCode?.trim().isNotEmpty ?? false;

  /// API chưa trả qty đã lấy theo task → suy theo tỉ lệ thùng đã lấy.
  int get qtyPicked {
    if (isDone) return qtyPlanned;
    if (boxPlanned <= 0) return 0;
    return (qtyPlanned * boxPicked / boxPlanned).floor();
  }

  /// Pallet đã lấy thì server không cập nhật boxPicked (vẫn 0)
  /// → hiển thị tiến độ thùng theo trạng thái.
  int get boxPickedDisplay => isDone ? boxPlanned : boxPicked;
}

/// Trạng thái 1 thùng trên màn lấy hàng. Khớp `PickBoxResponse.state`.
enum PickBoxState {
  /// Được phép lấy ngay (NSX cũ nhất / nằm trong danh sách chỉ định).
  eligible('eligible'),

  /// Đã quét lấy.
  picked('picked'),

  /// Chưa tới lượt — NSX mới hơn, phải giữ lại.
  locked('locked'),

  /// Báo lỗi — CHƯA dùng: server chưa có API báo lỗi thùng.
  skipped('skipped');

  const PickBoxState(this.key);
  final String key;

  /// Key lạ → coi như khoá: an toàn hơn là cho lấy nhầm.
  static PickBoxState fromKey(String? key) {
    for (final s in values) {
      if (s.key == key?.trim().toLowerCase()) return s;
    }
    return PickBoxState.locked;
  }
}

class PickBox {
  final int boxId;
  final String boxNo;
  final DateTime? productionDate;
  final int qty;
  final PickBoxState state;

  const PickBox({
    required this.boxId,
    required this.boxNo,
    this.productionDate,
    this.qty = 0,
    this.state = PickBoxState.locked,
  });
}

/// Màn lấy hàng tại 1 vị trí. Khớp `PickTaskDetailResponse`.
class PickTaskDetail {
  /// Bản mới nhất từ server (boxPicked / status / staged đã cập nhật sau
  /// mỗi lần quét).
  final PickTask task;
  final int pcsPerBox;

  /// NSX cũ → mới. Rỗng với lấy nguyên pallet.
  final List<PickBox> boxes;

  const PickTaskDetail({
    required this.task,
    required this.pcsPerBox,
    this.boxes = const [],
  });

  int get pickedBoxCount =>
      boxes.where((b) => b.state == PickBoxState.picked).length;
}

extension PickRouteX on List<PickTask> {
  /// Vị trí chưa xong hẳn (chưa lấy, hoặc lấy rồi mà chưa lưu vanning) đầu
  /// tiên SAU [after] theo thứ tự tuyến; hết thì vòng lại từ đầu tuyến
  /// (vị trí bị bỏ qua trước đó). null = tuyến đã xong hết.
  PickTask? nextPendingAfter(PickTask after) {
    final i = indexWhere((t) => t.id == after.id);
    return [
      ...skip(i + 1),
      ...take(i < 0 ? 0 : i),
    ].where((t) => !t.isComplete && t.id != after.id).firstOrNull;
  }
}