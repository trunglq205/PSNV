# Mục 2d — Màn PDA cho FA đóng pallet sau rework

10 file code + 2 file tool. Ghi đè SAU `swms_2d_backend.zip`.

⚠ **Gói này KHÔNG chứa file i18n và KHÔNG chứa file router.** Đọc mục 5 — đó
không phải thiếu sót, mà là để không xoá mất dữ liệu của anh.

## 1. Màn hình

Hai bước (màn 2a có ba): **quét thùng → quét serial**. FA **không phải chọn
model** — sổ serial đã biết mỗi con thuộc model nào.

Mở màn là máy tải **toàn bộ sổ serial của phiếu** (`GET {docId}/serial-index`)
rồi kiểm từng con **ngay trên máy**, không chờ mạng:

| Quét ra | Màn hình | Vào pallet? |
|---|---|---|
| đang ở FA của phiếu này | tick xanh | **có** |
| thuộc phiếu này nhưng sai trạng thái | chữ đỏ + ghi rõ trạng thái | không |
| không có trong sổ của phiếu | chữ đỏ "không thuộc phiếu này" | không |

Serial không khớp **vẫn cho quét tiếp** — đúng yêu cầu của anh. Chúng gom vào
một khối đỏ riêng ở giữa màn, kèm câu *"Đặt riêng những con này ra để SCS WH xử
lý. Hệ thống đã ghi lại."* — để FA không phải cuộn tìm từng con.

Thẻ tiến độ trên cùng: **Đang ở FA · Khớp · Không khớp**.

Bấm Lưu khi có cảnh báo → hỏi lại một lần, nói rõ *bao nhiêu con vào pallet,
bao nhiêu con không*, vì FA phải nhớ đặt chúng riêng ra **trước khi rời bàn**.

Lưu xong → in tem có **badge RW / RB** (lấy từ `doc.goodsType`), in lỗi thì mời
in lại y như màn 2a.

## 2. Hai chỗ quan trọng trong thiết kế

**Máy gửi TOÀN BỘ serial đã quét lên server, kể cả con đã gắn cờ.** Nếu máy lọc
trước thì nhật ký lệch bên server sẽ **luôn rỗng** và SCS không bao giờ biết có
hàng lạ. Server đối chiếu lại, tự loại và tự ghi nhật ký — nó mới là chốt cuối,
vì sổ tải về máy có thể đã cũ (một con vừa bị SCS nhận về trong lúc FA đang
quét).

Hệ quả: sau khi lưu, toast nói con số **của server** (`mismatchCount`), không
phải con số máy tự đếm. Hai số có thể khác nhau, và số của server mới đúng.

**Chưa tải xong sổ thì KHÔNG cho quét** — mã quét được bị bỏ, và nếu tải sổ hỏng
thì màn hiện lỗi kèm nút Thử lại thay vì cho quét. Quét mà không có sổ là nhận
mà không kiểm, và FA sẽ tưởng hàng lạ là hàng tốt.

## 3. File trong gói

| File | Mới / sửa |
|---|---|
| `domain/entities/return_fa_entities.dart` | mới |
| `data/models/return_fa_model.dart` (+ `.g.dart`) | mới |
| `presentation/providers/return_fa_notifier.dart` (+ `.g.dart`) | mới |
| `presentation/return_fa_pallet_page.dart` | mới |
| `data/datasources/return_instruction_remote_data_source.dart` (+ `.g.dart`) | sửa — thêm 2 endpoint |
| `data/return_instruction_repository_impl.dart` | sửa |
| `domain/repositories/return_instruction_repository.dart` | sửa |

Hai file `.g.dart` tôi viết tay đúng khuôn generator (retrofit + riverpod), nên
**không cần `build_runner`** cho chúng. Vẫn phải chạy build_runner cho
`app_router.gr.dart` — xem mục 4.

## 4. ⚠ Phải chèn tay: 3 dòng + 1 tile

**(a) `lib/core/router/app_route_paths.dart`** — thêm cạnh `returnReceive`:

```dart
  /// Mục 2d — FA quét serial đóng lại pallet sau khi rework xong.
  static const String returnFaPallet = '/return-instruction/fa-pallet';
```

**(b) `lib/core/router/app_router.dart`** — thêm cạnh `ReturnReceiveRoute`:

```dart
    AutoRoute(page: ReturnFaPalletRoute.page, path: AppRoutePaths.returnFaPallet),
```

**(c) `lib/features/home/presentation/providers/home_notifier.dart`** — thêm
vào nhóm `inbound`:

```dart
// Tile của FA, tách khỏi tile nhận hàng của WH: hai bên khác người dùng,
// FA không được thấy tile của WH và ngược lại.
FeatureItem(
  key: 'pda_receiving.return_fa_pallet',
  routeName: AppRoutePaths.returnFaPallet,
  nameKey: LocaleKeys.return_fa_title,
  icon: Icons.build_circle_outlined,
),
```

**(d)** Xoá `lib/core/router/app_router.gr.dart` rồi chạy:
`dart run build_runner build --delete-conflicting-outputs`

Vì sao tôi **không gửi kèm** 3 file này: bản `app_router.dart` /
`app_route_paths.dart` / `home_notifier.dart` trong máy tôi dựng từ zip cũ hơn
và đã lệch với bản của anh (tên route `TripStowageRoute` / `ContainerFinishRoute`
khác, nhóm Xuất hàng khác). Ghi đè là lặp lại đúng lỗi `app_router.gr.dart` hôm
trước.

## 5. ⚠ i18n — chạy script, KHÔNG ghi đè file

34 khoá `return_fa.*` × 4 ngôn ngữ. Tôi **không gửi** 4 file JSON,
`codegen_loader.g.dart` và `locale_keys.g.dart`, vì đã đối chiếu và thấy bản
trong máy tôi **thiếu khoá so với bản của anh**:

- `codegen_loader.g.dart` / `locale_keys.g.dart`: thiếu `stocky_btn_export`,
  `stocky_confirm_export`, `home.feature.return_fa`, `mode_gtin`…
- 4 file JSON: thiếu khoá trong namespace **`vanning`** và **`stocky`**

Ghi đè những file đó là **xoá mất các câu dịch đó**. Nên gói này gửi **script
chèn**, chạy trên chính file của anh:

```bash
cd <thu-muc-src_pda>
python3 -I tools/pda_i18n_ns.py tools/fa_i18n.json .
```

Script sửa 6 file tại chỗ: 4 JSON + `codegen_loader.g.dart` +
`locale_keys.g.dart`. **Chạy lại nhiều lần được** — namespace đã có thì bỏ qua.
Nó chèn thêm, giữ nguyên thứ tự khoá cũ (file JSON của dự án không sắp theo
alphabet, dump lại sẽ xáo trộn cả file).

Sau khi chạy, kiểm nhanh: `grep -c '"return_fa"' assets/translations/vi.json`
phải ra 1, và `grep -c 'return_fa_title' lib/core/localization/generated/locale_keys.g.dart` ra 1.

## 6. Quyền

Role FA cần: `rework_refurbish.view` + `rework_refurbish.process_fa` +
`pda_receiving.return_fa_pallet` (tile). Ba quyền, cùng cách tile Thùng NG đang
chạy.

## 7. Đã kiểm

- 10 file Dart cân đối `{} () []`
- 34 khoá i18n có đủ giá trị ở **cả 4** ngôn ngữ, có mặt trong cả 4 map của
  `codegen_loader`, và mọi `LocaleKeys.return_fa_*` màn dùng đều đã khai
- `namedArgs` khớp đúng placeholder `{…}` của từng câu dịch
- màu / text style / widget dùng đều có thật trong theme (đã sửa `dangerTint`
  → `dangerBg` vì theme chỉ có `dangerBg`)

## 8. Chưa có

- **Màn Web xem nhật ký serial lệch** — sẽ gộp vào gói mục 3.
- **Mục 3** (SCS nhận lại pallet bằng MỘT lần quét mã pallet) — làm tiếp.
