﻿namespace SWMS_WebTool.Models.Filters
{
    public class SearchKittingListDetails
    {
        public string UserId { get; set; }
        public long? KittingListID { get; set; }
        public string Barcode { get; set; }
        public string KittingTimeType { get; set; }
        public string Material { get; set; }
        public int? StartTime { get; set; }
        public int? EndTime { get; set; }
        public string Model { get; set; }
        public bool AutoTransfer { get; set; }
        public string LocationName { get; set; }
        public string Category { get; set; }
        public string DeliveryDate { get; set; }
        public byte? KittingType { get; set; }
    }
}
