import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/extensions/datetime_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

/// Danh sách thùng trong pallet, NSX cũ → mới.
class KittingBoxList extends StatelessWidget {
  final List<PickBox> boxes;

  /// Gỡ thùng quét nhầm. null = không cho gỡ.
  final ValueChanged<PickBox>? onUnpick;

  const KittingBoxList({super.key, required this.boxes, this.onUnpick});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final header = AppTextStyles.caption.copyWith(
      fontWeight: FontWeight.w700,
      letterSpacing: .4,
      color: swms.text3,
    );

    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    LocaleKeys.kitting_task_boxes_in_pallet.tr().toUpperCase(),
                    style: header,
                  ),
                ),
                Text(
                  LocaleKeys.kitting_task_mfg_old_to_new.tr(),
                  style: header.copyWith(fontWeight: FontWeight.w500),
                ),
              ],
            ),
          ),
          for (final b in boxes) ...[
            Divider(height: 1, color: swms.border),
            _BoxRow(
              box: b,
              onUnpick: onUnpick == null ? null : () => onUnpick!(b),
            ),
          ],
          Divider(height: 1, color: swms.border),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 9),
            child: Row(
              children: [
                Icon(Icons.info_outline, size: 13, color: swms.text4),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    LocaleKeys.kitting_task_fifo_rule.tr(),
                    style: AppTextStyles.caption.copyWith(color: swms.text4),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _BoxRow extends StatelessWidget {
  final PickBox box;
  final VoidCallback? onUnpick;

  const _BoxRow({required this.box, required this.onUnpick});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final (bg, iconBg, iconFg, icon, faded) = switch (box.state) {
      PickBoxState.eligible => (
        swms.warningBg,
        swms.warning,
        Colors.white,
        Icons.gps_fixed,
        false,
      ),
      PickBoxState.picked => (
        swms.successBg,
        swms.success,
        Colors.white,
        Icons.check,
        false,
      ),
      PickBoxState.skipped => (
        swms.dangerBg,
        swms.danger,
        Colors.white,
        Icons.close,
        false,
      ),
      PickBoxState.locked => (
        swms.card,
        swms.border,
        swms.text4,
        Icons.lock_outline,
        true,
      ),
    };

    final trailing = switch (box.state) {
      PickBoxState.eligible => const SizedBox.shrink(),
      PickBoxState.picked =>
        onUnpick == null
            ? StatusPill.success(
                context,
                label: LocaleKeys.kitting_task_picked.tr(),
              )
            : AppButton(
                label: LocaleKeys.kitting_task_unpick.tr(),
                icon: Icons.undo,
                variant: AppButtonVariant.neutral,
                size: AppButtonSize.sm,
                isFullWidth: false,
                onPressed: onUnpick,
              ),
      PickBoxState.skipped => StatusPill.danger(
        context,
        label: LocaleKeys.kitting_task_skipped.tr(),
      ),
      PickBoxState.locked => StatusPill.neutral(
        context,
        label: LocaleKeys.kitting_task_keep.tr(),
      ),
    };

    return Opacity(
      opacity: faded ? .5 : 1,
      child: Container(
        color: bg,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
        child: Row(
          children: [
            Container(
              width: 30,
              height: 30,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(AppDimens.sm),
              ),
              child: Icon(icon, size: 15, color: iconFg),
            ),
            const SizedBox(width: 11),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    box.boxNo,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.code.copyWith(
                      fontSize: 13,
                      letterSpacing: 0,
                      fontWeight: FontWeight.w700,
                      color: swms.text1,
                    ),
                  ),
                  Text(
                    LocaleKeys.kitting_task_mfg.tr(
                      args: [box.productionDate?.mmYYYY ?? kSiDash],
                    ),
                    style: AppTextStyles.caption.copyWith(color: swms.text3),
                  ),
                ],
              ),
            ),
            const SizedBox(width: AppDimens.sm),
            trailing,
          ],
        ),
      ),
    );
  }
}
