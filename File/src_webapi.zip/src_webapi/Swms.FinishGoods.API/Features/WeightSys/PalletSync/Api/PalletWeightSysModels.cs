namespace Swms.FinishGoods.API.Features.WeightSys.PalletSync.Api
{
    public sealed record BoxWeightSyncItem(
        long BoxId,
        string BoxNo);

}
