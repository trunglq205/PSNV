import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/auth/data/models/login_request_model.dart';
import 'package:swms_finish_goods/features/auth/data/models/login_response_model.dart';

part 'auth_remote_datasource.g.dart';

@RestApi()
abstract class AuthRemoteDataSource {
  factory AuthRemoteDataSource(Dio dio, {String baseUrl}) =
  _AuthRemoteDataSource;

  @POST('/api/auth/login')
  Future<LoginResponseModel> login(@Body() LoginRequestModel body);
}