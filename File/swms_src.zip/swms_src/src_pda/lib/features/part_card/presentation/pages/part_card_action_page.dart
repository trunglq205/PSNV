import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/router/router_provider.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_message.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/back_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_bottom_hint.dart';
import 'package:swms_finish_goods/core/widgets/common/app_stepper_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_action_notifier.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_action_state.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_action_print_body.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_confirm_body.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_confirm_skeleton.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_merge_sources.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_mode_switch.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_split_body.dart';
import 'package:swms_finish_goods/shared/presentation/pda_scan_route_aware.dart';
import 'package:swms_finish_goods/shared/presentation/printer_picker_dialog.dart';

// ─────────────────────────────────────────────────────────────
//  Sửa / Tách / Gộp tem Part Card ĐÃ IN.
//  Mở từ Home: quét tem → chọn action → màn này (2 bước: Xác nhận → In).
//
//  Lưu server TRƯỚC, in SAU (xem PartCardActionNotifier). Đã lưu thì khoá
//  dữ liệu, không quay lại bước 1 — chỉ còn in nốt.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class PartCardActionPage extends ConsumerStatefulWidget {
  const PartCardActionPage({
    super.key,
    required this.action,
    required this.payload,
  });

  final PartCardAction action;

  /// Payload QR của tem vừa quét ở Home.
  final String payload;

  @override
  ConsumerState<PartCardActionPage> createState() =>
      _PartCardActionPageState();
}

class _PartCardActionPageState extends ConsumerState<PartCardActionPage>
    with PdaScanRouteAware {
  /// Family theo (action, payload) — mỗi lần mở từ Home là 1 state mới.
  late final _provider = partCardActionProvider(widget.action, widget.payload);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final routeObserver = ref.watch(routeObserverProvider);
    routeObserver.subscribe(this, ModalRoute.of(context)! as ModalRoute<void>);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) async {
      final ok = await ref.read(_provider.notifier).init();
      // Tem không đọc được / không tách được → lỗi đã báo, quay về Home.
      if (!ok && mounted) await context.router.maybePop();
    });
  }

  @override
  void onScan(String data) {
    if (!mounted) return;
    ref.read(_provider.notifier).onScan(data);
  }

  String get _title => switch (widget.action) {
    PartCardAction.edit => LocaleKeys.part_card_action_title_edit.tr(),
    PartCardAction.split => LocaleKeys.part_card_action_title_split.tr(),
    PartCardAction.merge => LocaleKeys.part_card_action_title_merge.tr(),
  };

  String _doneMessage(PartCardActionState s) => switch (widget.action) {
    PartCardAction.edit => LocaleKeys.part_card_action_done_edit.tr(
      namedArgs: {'id': s.sources.firstOrNull?.cardId ?? ''},
    ),
    PartCardAction.split => LocaleKeys.part_card_action_done_split.tr(
      namedArgs: {'count': '${s.splitParts.length}'},
    ),
    PartCardAction.merge => LocaleKeys.part_card_action_done_merge.tr(
      namedArgs: {'count': '${s.sources.length}'},
    ),
  };

  Future<void> _changeMode(PartCardMode mode) async {
    final state = ref.read(_provider);
    if (state.mode == mode) return;

    final dropped = mode.isSingle ? state.droppedOnSingle : 0;
    if (dropped > 0) {
      final ok = await showConfirmDialog(
        context,
        title: LocaleKeys.part_card_switch_title.tr(),
        message: LocaleKeys.part_card_switch_body.tr(
          namedArgs: {'count': '$dropped'},
        ),
      );
      if (!ok || !mounted) return;
    }
    ref.read(_provider.notifier).setMode(mode);
  }

  /// Lưu + in. Riêng Sửa: tem cũ không còn trên server → hỏi lưu thành tem
  /// mới (giữ Card_ID cũ).
  Future<void> _submit() async {
    final notifier = ref.read(_provider.notifier);

    final notFound = await notifier.submit();
    if (!notFound || !mounted) return;

    final cardId = ref.read(_provider).sources.firstOrNull?.cardId ?? '';
    final ok = await showConfirmDialog(
      context,
      title: LocaleKeys.part_card_update_not_found_title.tr(),
      message: LocaleKeys.part_card_update_not_found_body.tr(
        namedArgs: {'id': cardId},
      ),
    );
    if (!ok || !mounted) return;

    await notifier.saveEditAsNew();
  }

  Future<void> _pickPrinter() async {
    ref.invalidate(pairedPrintersProvider);

    final List<PrinterDevice> devices;
    try {
      devices = await ref.read(pairedPrintersProvider.future);
    } on PrinterException catch (e) {
      if (!mounted) return;
      AppToastHelper.toastInfo(context, printerMessage(e));
      return;
    } catch (e) {
      if (!mounted) return;
      AppToastHelper.toastInfo(context, e.toString());
      return;
    }

    final pda = await ref.read(pdaProvider.future);
    if (!mounted) return;

    // Dialog là route đè lên page → PdaScanRouteAware tự ngưng nghe quét.
    await showPrinterPickerDialog(
      context,
      selectedMac: ref.read(selectedPrinterProvider)?.macAddress,
      printers: devices,
      scanStream: pda.scanStream,
      onSelected: (printer) async {
        await ref.read(selectedPrinterProvider.notifier).select(printer);
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(_provider);

    // Lưu + in xong → báo rồi về Home.
    ref.listen(_provider.select((s) => s.done), (_, done) {
      if (!done) return;
      AppToastHelper.toastInfo(context, _doneMessage(ref.read(_provider)));
      context.router.maybePop();
    });

    final ids = state.sources.map((s) => s.cardId).join(' · ');

    return PopScope(
      // Đã lưu mà chưa in hết → không cho thoát ngang, tránh mất nhãn.
      canPop: !state.saved || state.done,
      child: Scaffold(
        appBar: AppTopBar(
          title: _title,
          subtitle: ids.isEmpty ? '' : 'ID: $ids',
          actions: [
            if (widget.action == PartCardAction.edit &&
                state.step == PartCardActionStep.setup &&
                !state.loading)
              PartCardModeSwitch(
                mode: state.mode,
                enabled: !state.saved,
                onChanged: _changeMode,
              ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(AppDimens.md),
          child: Column(
            children: [
              AppStepperBar(
                current: state.step.index + 1,
                steps: [
                  StepItem(LocaleKeys.part_card_step_confirm.tr()),
                  StepItem(LocaleKeys.part_card_step_print.tr()),
                ],
              ),
              const SizedBox(height: AppDimens.sm),
              Expanded(child: _buildBody(state)),
            ],
          ),
        ),
        bottomNavigationBar: state.loading ? null : _buildBottom(state),
      ),
    );
  }

  Widget _buildBody(PartCardActionState state) {
    final form = state.form;
    if (state.loading || form == null) {
      return PartCardConfirmSkeleton(
        multi: widget.action == PartCardAction.merge,
      );
    }

    final notifier = ref.read(_provider.notifier);

    if (state.step == PartCardActionStep.print) {
      return PartCardActionPrintBody(
        printer: ref.watch(selectedPrinterProvider),
        forms: state.saved
            ? [for (final j in state.pendingPrint) j.form]
            : state.printForms,
        saved: state.saved,
        onChangePrinter: _pickPrinter,
      );
    }

    switch (widget.action) {
      case PartCardAction.edit:
        return PartCardConfirmBody(
          form: form,
          mode: state.mode,
          onChanged: notifier.onFormChanged,
          onAddModel: state.mode.isMulti ? notifier.addLine : null,
        );

      case PartCardAction.split:
        return PartCardSplitBody(
          source: form,
          cardId: state.sources.first.cardId,
          parts: state.splitParts,
          remaining: state.splitRemaining,
          onPartChanged: notifier.updateSplitPart,
          onAdd: notifier.addSplitPart,
          onRemove: notifier.removeSplitPart,
        );

      case PartCardAction.merge:
        return Column(
          children: [
            PartCardMergeSources(
              sources: state.sources,
              onRemove: state.saved ? null : notifier.removeSource,
            ),
            const SizedBox(height: AppDimens.sm),
            Expanded(
              child: PartCardConfirmBody(
                form: form,
                mode: PartCardMode.multi,
                onChanged: notifier.onFormChanged,
                // Dòng chỉ đến từ tem nguồn; Qty phải khớp tem nguồn, Box sửa được.
                lockLineQty: true,
              ),
            ),
          ],
        );
    }
  }

  Widget _buildBottom(PartCardActionState state) {
    final notifier = ref.read(_provider.notifier);

    if (state.step == PartCardActionStep.setup) {
      return AppBottomHint(
        child: Row(
          children: [
            BackIconButton(onPressed: () => context.router.maybePop()),
            const SizedBox(width: AppDimens.sm),
            Expanded(
              child: AppButton(
                label: LocaleKeys.part_card_btn_confirm_next.tr(),
                variant: AppButtonVariant.success,
                isFullWidth: false,
                onPressed: state.canSubmit ? notifier.toPrint : null,
              ),
            ),
          ],
        ),
      );
    }

    final ready = ref.watch(selectedPrinterProvider) != null;
    final count = state.saved
        ? state.pendingPrint.length
        : state.printForms.length;

    return AppBottomHint(
      child: Row(
        children: [
          // Đã lưu thì notifier tự chặn quay lại (dữ liệu đã chốt trên server).
          BackIconButton(onPressed: notifier.backToSetup),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: AppButton(
              label: state.saved
                  ? LocaleKeys.part_card_action_btn_print_rest.tr(
                      namedArgs: {'count': '$count'},
                    )
                  : LocaleKeys.part_card_action_btn_save_print.tr(
                      namedArgs: {'count': '$count'},
                    ),
              variant: AppButtonVariant.success,
              icon: Icons.print,
              isFullWidth: false,
              onPressed: ready ? _submit : null,
            ),
          ),
        ],
      ),
    );
  }
}
