class UserInfo {
  final String id;
  final String employeeCode;
  final String fullName;

  UserInfo({
    required this.id,
    required this.employeeCode,
    required this.fullName,
  });
}