/// Trạng thái chỉ thị lấy hàng. Khớp `docStatus` của API.
enum SiStatus {
  released('released'),
  picking('picking'),
  completed('completed'),
  cancelled('cancelled');

  const SiStatus(this.key);

  /// Giá trị gửi/nhận với API.
  final String key;

  /// null = server chưa có giá trị hoặc trả key lạ. KHÔNG ném lỗi: server thêm
  /// trạng thái mới thì app cũ vẫn chạy, chỉ hiện pill trung tính.
  static SiStatus? fromKey(String? key) {
    if (key == null) return null;
    final k = key.trim().toLowerCase();
    for (final s in values) {
      if (s.key == k) return s;
    }
    return null;
  }

  /// Còn soạn hàng được (hiện nút "Soạn hàng").
  bool get canPick => this == picking;}
