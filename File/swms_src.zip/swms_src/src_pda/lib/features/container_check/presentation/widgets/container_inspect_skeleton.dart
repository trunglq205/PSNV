import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_skeleton.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';

/// Giữ chỗ lúc tải chi tiết container — cùng bố cục [ConditionChecklistCard]
/// + [PhotoSlotsCard] (số dòng / số ô lấy từ enum) để dữ liệu về không nhảy.
class ContainerInspectSkeleton extends StatelessWidget {
  const ContainerInspectSkeleton({super.key});

  static const _pad = EdgeInsets.all(AppDimens.sm + 4);

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Checklist: header + 1 dòng / hạng mục.
        SkeletonCard(
          padding: _pad,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const _Header(),
              for (var i = 0; i < ContainerCondition.values.length; i++)
                SizedBox(
                  height: AppDimens.hitSm,
                  child: Row(
                    children: [
                      const Bone(width: 20, height: 20),
                      const SizedBox(width: 10),
                      // Lệch độ dài cho giống chữ thật, không thành 4 vạch đều.
                      Bone(width: i.isEven ? 180 : 140),
                    ],
                  ),
                ),
            ],
          ),
        ),
        const SizedBox(height: AppDimens.sm),
        // Ảnh: header + lưới 2×2 tỉ lệ 4:3.
        SkeletonCard(
          padding: _pad,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const _Header(),
              const SizedBox(height: AppDimens.xs),
              GridView.count(
                crossAxisCount: 2,
                childAspectRatio: 4 / 3,
                mainAxisSpacing: AppDimens.sm,
                crossAxisSpacing: AppDimens.sm,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: [
                  // Ô grid ép kích thước chặt → Bone giãn kín ô.
                  for (var i = 0; i < ContainerPhotoSlot.values.length; i++)
                    const Bone(height: double.infinity, radius: AppDimens.rInput),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}

/// Header thẻ: tiêu đề trái + bộ đếm `x/y` phải, cao bằng InspectSectionHeader.
class _Header extends StatelessWidget {
  const _Header();

  @override
  Widget build(BuildContext context) => const Padding(
    padding: EdgeInsets.only(bottom: AppDimens.xs),
    child: SizedBox(
      height: 20,
      child: Row(
        children: [
          Bone(width: 130, height: 14),
          Spacer(),
          Bone(width: 24),
        ],
      ),
    ),
  );
}