import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/features/container_check/data/datasources/container_check_remote_data_source.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';
import 'package:swms_finish_goods/features/container_check/domain/repositories/container_check_repository.dart';

class ContainerCheckRepositoryImpl implements ContainerCheckRepository {
  // ignore: unused_field — dùng khi bật API thật
  final ContainerCheckRemoteDataSource _remote;

  const ContainerCheckRepositoryImpl(this._remote);

  @override
  Future<List<ContainerItem>> getContainers() async {
    // ── MOCK TẠM (backend chưa sẵn sàng) ──
    await Future.delayed(const Duration(milliseconds: 1200), () {});
    return _mockContainers;
    // ── BẬT LẠI khi có API ──
    // final models = await _remote.fetchContainers();
    // return models.map((m) => m.toEntity()).toList();
  }

  @override
  Future<ContainerItem> getByContainerNo(String containerNo) async {
    // ── MOCK TẠM ──
    await Future.delayed(const Duration(milliseconds: 600), () {});
    for (final c in _mockContainers) {
      if (c.matches(containerNo)) return c;
    }
    throw ContainerNotFoundException(containerNo);
    // ── BẬT LẠI khi có API ──
    // (server trả 404 → map sang ContainerNotFoundException ở interceptor
    //  hoặc bắt NotFoundException tại đây)
    // final model = await _remote.fetchByContainerNo(containerNo);
    // return model.toEntity();
  }

  @override
  Future<ContainerItem> getDetail(int containerId) async {
    // ── MOCK TẠM ──
    await Future.delayed(const Duration(milliseconds: 800), () {});
    return _mockContainers.firstWhere((c) => c.id == containerId);
    // ── BẬT LẠI khi có API ──
    // final model = await _remote.fetchDetail(containerId);
    // return model.toEntity();
  }

  @override
  Future<void> submitInspection(ContainerInspection inspection) async {
    // ── MOCK TẠM ──
    await Future.delayed(const Duration(milliseconds: 1500), () {});
    // ── BẬT LẠI khi có API ──
    // await _remote.submitInspection(
    //   inspection.containerId,
    //   ContainerInspectionRequest.fromEntity(inspection),
    // );
    // if (inspection.photos.isNotEmpty) {
    //   final entries = inspection.photos.entries.toList();
    //   await _remote.uploadPhotos(
    //     inspection.containerId,
    //     entries.map((e) => e.key.code).toList(),
    //     entries.map((e) => File(e.value)).toList(),
    //   );
    // }
  }
}

const _mockContainers = [
  ContainerItem(
    id: 1,
    containerNo: 'CMAU-7382041-3',
    sealNo: 'VN-SL-44218',
    siCode: 'SI-2026-0506-018',
    type: "40' HC",
    lot: LotColor.a,
    status: ContainerStatus.verify,
  ),
  ContainerItem(
    id: 2,
    containerNo: 'MSCU-9981234-7',
    sealNo: 'VN-SL-44219',
    siCode: 'SI-2026-0506-017',
    type: "40' HC",
    lot: LotColor.b,
    status: ContainerStatus.loading,
  ),
  ContainerItem(
    id: 3,
    containerNo: 'TCNU-4501122-9',
    sealNo: 'VN-SL-44215',
    siCode: 'SI-2026-0506-015',
    type: "20' GP",
    lot: LotColor.d,
    status: ContainerStatus.done,
  ),
  ContainerItem(
    id: 4,
    containerNo: 'OOLU-3344556-1',
    sealNo: 'VN-SL-44210',
    siCode: 'SI-2026-0506-013',
    type: "40' HC",
    lot: LotColor.a,
    status: ContainerStatus.done,
  ),
];
