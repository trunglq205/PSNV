﻿/* ============================================================
   SWMS · Vị trí tạm — map editor (Blazor interop)
   BẢN: 2026-01-EDIT-NO-STATUS (đã bỏ Trạng thái hàng + Model khỏi tab Chỉnh sửa)
   Kiến trúc: C# (Blazor) lo DATA + gọi API (Refit) + i18n (resx).
              JS lo VẼ + TƯƠNG TÁC canvas, callback .NET khi có thay đổi.

   API:
     window.swmsTempLocMap.init(container, dotNetRef, opts)
        opts = { layout, i18n }
        - layout: { areaCode, cols, rows, cellMeters, cells:[...] }
        - i18n:   { key: text, ... }  (đã dịch sẵn từ resx)
     .destroy(container)

   Callback .NET (qua dotNetRef.invokeMethodAsync):
     - "OnSaveLayout"  (payloadJson)   khi bấm Lưu
     - "OnChangeStatus"(code, status, model, lotNo) khi đổi trạng thái nhanh
     - "OnPrintQR"     (codesJson)     khi bấm in (C# có thể xử lý thêm nếu cần)
     - "OnToast"       (message)       hiển thị toast qua ToastService của app
   ============================================================ */
(function (global) {
    'use strict';

    const METERS_PER_CELL_DEFAULT = 0.2;
    const CELL_PX_BASE = 11;

    // Bộ mã trạng thái CHUẨN (khớp domain OQC). 'varc' = phần lõi tên biến CSS (--st-{varc}-bg),
    // 'key' = khoá i18n. is_urgent là LỚP PHỦ viền độc lập (frame), không phải màu nền.
    const STATUS_META = {
        empty:             { cls: 'st-empty',     varc: 'empty',     key: 'TempLoc.Status.Empty' },
        not_inspected:     { cls: 'st-notinsp',   varc: 'notinsp',   key: 'TempLoc.Status.NotInspected' },
        under_inspection:  { cls: 'st-underinsp', varc: 'underinsp', key: 'TempLoc.Status.UnderInspection' },
        ng:                { cls: 'st-ng',        varc: 'ng',        key: 'TempLoc.Status.Ng' },
        pending_result:    { cls: 'st-pending',   varc: 'pending',   key: 'TempLoc.Status.PendingResult' },
        inspection_exempt: { cls: 'st-exempt',    varc: 'exempt',    key: 'TempLoc.Status.InspectionExempt' },
        pass:              { cls: 'st-pass',      varc: 'pass',      key: 'TempLoc.Status.Pass' },
        is_urgent:         { cls: 'is-urgent',    varc: 'urgent',    key: 'TempLoc.Status.Urgent', frame: true },
    };
    const STATUS_ORDER = ['empty', 'not_inspected', 'under_inspection', 'ng', 'pending_result', 'inspection_exempt', 'pass', 'is_urgent'];
    const ARROW_SVG = {
        up: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 19V5M5 12l7-7 7 7"/></svg>',
        down: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M12 5v14M19 12l-7 7-7-7"/></svg>',
        left: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M19 12H5M12 19l-7-7 7-7"/></svg>',
        right: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>',
    };
    const ARROW_CH = { up: '↑', down: '↓', left: '←', right: '→' };
    // Mũi tên KHỐI ĐẶC (tô đen) cho tem in — đậm, to như mẫu QR location.
    const ARROW_SOLID = {
        left: '<svg viewBox="0 0 100 100" fill="#000"><path d="M2 50 L44 14 L44 34 L96 34 L96 66 L44 66 L44 86 Z"/></svg>',
        right: '<svg viewBox="0 0 100 100" fill="#000"><path d="M98 50 L56 14 L56 34 L4 34 L4 66 L56 66 L56 86 Z"/></svg>',
        up: '<svg viewBox="0 0 100 100" fill="#000"><path d="M50 2 L14 44 L34 44 L34 96 L66 96 L66 44 L86 44 Z"/></svg>',
        down: '<svg viewBox="0 0 100 100" fill="#000"><path d="M50 98 L14 56 L34 56 L34 4 L66 4 L66 56 L86 56 Z"/></svg>',
    };
    // Thang màu chiếm chỗ của kệ: xám nhạt (trống) -> xanh đậm (đầy).
    const RK_FROM = [205, 226, 243], RK_TO = [26, 90, 153];
    function rackMix(ratio) {
        if (!(ratio > 0)) return [238, 242, 246];   // #EEF2F6
        const t = Math.min(1, ratio);
        return RK_FROM.map((f, i) => Math.round(f + (RK_TO[i] - f) * t));
    }

    function rackFill(ratio) {
        const c = rackMix(ratio);
        return 'rgb(' + c[0] + ',' + c[1] + ',' + c[2] + ')';
    }

    /// Màu chữ trong ô kệ, theo độ sáng của chính màu nền ô đó.
    ///
    /// Không dùng được textColor() sẵn có: hàm đó chỉ bóc chuỗi "#rrggbb", còn
    /// rackFill() trả về "rgb(r,g,b)" nên sẽ rơi vào nhánh catch và luôn ra màu
    /// tối — chữ tối trên nền xanh đậm thì không đọc được.
    ///
    /// Cũng không dùng mix-blend-mode: trên màu trung gian của thang này nó cho
    /// ra màu nâu đỏ, không phải đen/trắng.
    function rackInk(ratio) {
        const c = rackMix(ratio);
        return (0.299 * c[0] + 0.587 * c[1] + 0.114 * c[2]) > 150 ? '#14354f' : '#fff';
    }

    // ── Nhãn chữ vừa khít hộp ──────────────────────────────────────────
    //
    // Giống hệt FitFont()/FontCss() bên C# (StorageTopMap.razor.cs). GIỮ ĐỒNG
    // BỘ hai bên: map Storing và hai map Receiving/Vanning phải hiện nhãn ô
    // cùng một dạng.
    //
    // KHÁC một điểm quan trọng so với map Storing: ở đó cả mặt bản đồ được
    // phóng bằng transform:scale() nên chữ tự to theo. Engine này nhân KÍCH
    // THƯỚC THẬT theo zoom (cell * zoom), nên cỡ chữ phải tính lại từ kích
    // thước ĐÃ ZOOM, và trần cỡ chữ cũng phải nhân theo zoom — để im thì zoom
    // to ra chữ đứng nguyên, nhãn bé tí trong ô rộng.

    /// Bề rộng trung bình một ký tự theo em, với font monospace. Để nhẹ tay hơn
    /// thực tế để chữ không bao giờ sát mép.
    const CHAR_ADV = 0.64;

    /// Cỡ chữ lớn nhất để `lines` vừa khít hộp w × h. Bị chặn bởi CẢ HAI chiều:
    /// bề rộng của dòng dài nhất, và tổng chiều cao các dòng (line-height = 1).
    function fitFont(w, h, lines) {
        let longest = 0;
        for (const s of lines) longest = Math.max(longest, s.length);
        if (!longest || !lines.length || w <= 0 || h <= 0) return 0;
        return Math.min(w / (longest * CHAR_ADV), h / lines.length);
    }

    /// Làm tròn XUỐNG: cỡ chữ vừa khít là chỗ_dư / (số_ký_tự × CHAR_ADV), nên
    /// làm tròn lên là chữ rộng hơn chỗ dư.
    function fontPx(f) { return (Math.floor(f * 1000) / 1000) + 'px'; }

    /// Thoát HTML. PHẢI có bản riêng ở tầm vực module: `esc` của dự án khai
    /// bằng const BÊN TRONG hàm init của từng instance, nên rackLabelHtml ở
    /// đây gọi tới sẽ ném ReferenceError lúc chạy.
    function escHtml(s) {
        return String(s == null ? '' : s)
            .replace(/&/g, '&amp;').replace(/</g, '&lt;')
            .replace(/>/g, '&gt;').replace(/"/g, '&quot;');
    }

    /// Nhãn kệ: "E1 (24/58)". Trả về HTML của viên pill .rk.
    ///
    /// `cw` = bề rộng khả dụng (px đã zoom), `base` = cỡ chữ gốc (đã nhân zoom).
    /// Kệ chưa khai ô nào thì chỉ hiện mã kệ — "(0/0)" không nói lên điều gì.
    function rackLabelHtml(code, occ, total, cw, base) {
        const safe = escHtml(code);
        if (!(total > 0) || cw <= 0) return '<span class="rk">' + safe + '</span>';

        const ratio = '(' + occ + '/' + total + ')';

        // Một dòng, CHỈ khi vừa ở trọn cỡ chữ gốc — giữ nguyên dáng nhãn như cũ.
        if ((code.length + 1 + ratio.length) * CHAR_ADV * base <= cw) {
            return '<span class="rk" style="font-size:' + fontPx(base) + '">' +
                   '<span class="rc">' + safe + '</span> ' +
                   '<span class="ro">' + ratio + '</span></span>';
        }

        // Hai dòng, mỗi dòng một cỡ chữ riêng. Mã kệ ưu tiên giữ cỡ gốc.
        const fCode = Math.min(cw / (code.length * CHAR_ADV), base);
        const fRatio = Math.min(cw / (ratio.length * CHAR_ADV), base);
        return '<span class="rk two" style="font-size:' + fontPx(fCode) + '">' +
               '<span class="rc">' + safe + '</span>' +
               '<span class="ro" style="font-size:' + fontPx(fRatio) + '">' + ratio + '</span></span>';
    }

    const ZONE_COLORS = ['#E53935', '#3F6FB5', '#2E9E52', '#F5E6C0', '#C7DCEC', '#8A6FBF', '#8894A5'];

    const instances = new WeakMap();

    function tr(i18n, key, fallback) { return (i18n && i18n[key]) || fallback || key; }

    function init(container, dotNetRef, opts) {
        if (!container) return;
        opts = opts || {};
        const i18n = opts.i18n || {};
        const layout = opts.layout || { cols: 115, rows: 75, cellMeters: 0.2, cells: [] };
        const M = layout.cellMeters || METERS_PER_CELL_DEFAULT;

        // state
        let model = {
            areaCode: layout.areaCode,
            cols: layout.cols, rows: layout.rows, cell: CELL_PX_BASE, cellMeters: M,
            cells: (layout.cells || []).map(c => ({
                id: c.id ?? uid(), code: c.code, type: c.cellType || 'pallet',
                rackCode: c.rackCode, totalSlots: c.totalSlots, occupiedSlots: c.occupiedSlots,
                positions: c.positions || [],
                x: c.gridX, y: c.gridY, w: c.gridW, h: c.gridH,
                arrow: c.arrow, color: c.color, label: c.label,
                status: c.status || 'empty', model: c.model, lotNo: c.lotNo, sortOrder: c.sortOrder || 0,
                lots: c.lots || [], isUrgent: !!c.isUrgent
            }))
        };
        let zoom = 1, tool = 'select', mode = 'view', selId = null, filterStatus = null;
        let _lastClick = null; // {id, t} — để tự phát hiện double-click ở tab Vận hành
        let uidCounter = 1;
        const undoStack = [];

        function uid() { return 'n' + (uidCounter++); }
        const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
        const esc = s => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
        const m2 = k => tr(i18n, k, k);
        function clampCell(c) { c.w = clamp(c.w, 1, model.cols); c.h = clamp(c.h, 1, model.rows); c.x = clamp(c.x, 0, model.cols - c.w); c.y = clamp(c.y, 0, model.rows - c.h); }
        function textColor(hex) { try { const h = hex.replace('#', ''); const r = parseInt(h.substr(0, 2), 16), g = parseInt(h.substr(2, 2), 16), b = parseInt(h.substr(4, 2), 16); return (0.299 * r + 0.587 * g + 0.114 * b) > 150 ? '#242424' : '#fff'; } catch (_) { return '#242424'; } }

        container.classList.add('tlm-root');
        container.innerHTML = buildShell(i18n);
        // Chưa đăng nhập -> ẩn tab Chỉnh sửa (chỉ cho Vận hành xem). LAN nội bộ.
        const canEdit = opts.canEdit !== false;
        if (!canEdit) {
            // Chỉ xem: ẩn cả cụm tab chế độ (còn mỗi "Vận hành" thì không cần hiện).
            const tabs = container.querySelector('.tlm-modetabs');
            if (tabs) tabs.style.display = 'none';
        }
        const $ = s => container.querySelector(s);
        const grid = $('.tlm-grid'), inspBody = $('.tlm-insp-body'), inspTitle = $('.tlm-insp-title'), inspSub = $('.tlm-insp-sub');

        // ---- QR (quiet zone rộng, in không khuyết) ----
        function drawQR(canvas, text) {
            try {
                if (typeof qrcode === 'undefined') return;
                const qr = qrcode(0, 'M'); qr.addData(String(text || '')); qr.make();
                const n = qr.getModuleCount(), s = 4, margin = 4, dim = (n + margin * 2) * s;
                canvas.width = dim; canvas.height = dim;
                const ctx = canvas.getContext('2d');
                ctx.fillStyle = '#fff'; ctx.fillRect(0, 0, dim, dim); ctx.fillStyle = '#111';
                for (let r = 0; r < n; r++)for (let col = 0; col < n; col++)if (qr.isDark(r, col)) ctx.fillRect((col + margin) * s, (r + margin) * s, s, s);
            } catch (e) { }
        }
        function qrDataURL(t) { try { const c = document.createElement('canvas'); drawQR(c, t); return c.toDataURL('image/png'); } catch (e) { return ''; } }

        // ---- render ----
        function renderGrid() {
            grid.style.setProperty('--cell', (model.cell * zoom) + 'px');
            const cp = model.cell * zoom;
            // View: lưới bám sát nội dung cho kín; Edit: giữ lưới đầy đủ để còn chỗ kéo-thả.
            const gb = (mode === 'edit') ? { w: model.cols, h: model.rows } : contentBounds();
            grid.style.width = (gb.w * cp) + 'px'; grid.style.height = (gb.h * cp) + 'px';
            grid.innerHTML = '';
            for (let mx = 0; mx <= gb.w * model.cellMeters + 0.001; mx += 1) { const l = document.createElement('div'); l.className = 'tlm-ruler'; l.style.left = (Math.round(mx / model.cellMeters) * cp + 2) + 'px'; l.style.top = '-15px'; l.textContent = mx + 'm'; grid.appendChild(l); }
            for (let my = 0; my <= gb.h * model.cellMeters + 0.001; my += 1) { const l = document.createElement('div'); l.className = 'tlm-ruler'; l.style.left = '-30px'; l.style.top = (Math.round(my / model.cellMeters) * cp - 5) + 'px'; l.textContent = my + 'm'; grid.appendChild(l); }
            model.cells.forEach(c => {
                const el = renderCell(c);
                if (mode === 'view' && filterStatus && c.type === 'pallet') {
                    const hide = filterStatus === 'is_urgent' ? !c.isUrgent : (c.status !== filterStatus);
                    if (hide) el.style.opacity = .12;
                }
                grid.appendChild(el);
            });
        }
        // Tooltip 1 ô: dòng đầu là mã ô, mỗi lô một dòng "mã · model (số thùng)".
        // Giữ ĐÚNG định dạng với bản Blazor ở mặt cắt kệ và bản đồ kho lưu, để
        // người dùng đi qua lại giữa các map không phải đọc hai kiểu.
        function cellTitle(c) {
            const code = c.code || c.label || '';
            const lines = (c.lots || []).map(l => {
                let s = String(l.lotNo || '').trim();
                // models là chuỗi ở cả hai màn, nhưng chặn sẵn trường hợp mảng.
                const m = Array.isArray(l.models)
                    ? l.models.join(', ')
                    : String(l.models || '').trim();
                if (m) s += (s ? ' · ' : '') + m;
                if (l.boxCount > 0) s += ' (' + l.boxCount + ')';
                return s;
            }).filter(Boolean);

            // Ô chưa có danh sách lô nhưng có model ở cấp ô (dữ liệu cũ).
            if (!lines.length && c.model) lines.push(String(c.model).trim());
            return lines.length ? code + '\n' + lines.join('\n') : code;
        }

        function renderCell(c) {
            const cp = model.cell * zoom, el = document.createElement('div');
            el.className = 'tlm-cell ' + (c.type === 'zone' ? 't-zone'
                                        : c.type === 'rack' ? 't-rack' : 't-pallet');
            el.dataset.id = c.id;
            el.style.cssText = `left:${c.x * cp}px;top:${c.y * cp}px;width:${c.w * cp}px;height:${c.h * cp}px`;
            if (c.type === 'pallet') el.classList.add((STATUS_META[c.status] || STATUS_META.empty).cls);
            // Cờ khẩn là lớp phủ ĐỘC LẬP với màu nền (viền đứt đỏ), hiện đồng thời.
            if (c.type === 'pallet' && c.isUrgent) el.classList.add('is-urgent');
            if (c.type === 'zone' && c.color) { el.style.background = c.color; el.style.color = textColor(c.color); }
            if (String(c.id) === selId) el.classList.add('sel');
            const lbl = document.createElement('div'); lbl.className = 'lbl';
            if (c.type === 'rack') {
                // Kệ: chia khoang theo từng vị trí, tô đậm dần theo tỉ lệ chiếm chỗ.
                const horiz = (c.w || 1) >= (c.h || 1);
                const pos = c.positions || [];
                const rkCode = String(c.rackCode || '');

                // Kích thước MỘT ô vị trí, px đã zoom. .tlm-rk-cells là
                // inset:1px + gap:1px, nên trừ 2px viền và (n-1) khe.
                const n = Math.max(1, pos.length);
                const innerW = c.w * cp - 2, innerH = c.h * cp - 2;
                const pw = horiz ? (innerW - (n - 1)) / n : innerW;
                const ph = horiz ? innerH : (innerH - (n - 1)) / n;

                const cells = pos.map(p => {
                    const r = p.total ? p.occupied / p.total : 0;
                    const code = rkCode + '-' + p.position;
                    const ratio = '(' + p.occupied + '/' + p.total + ')';

                    // Trong ô CHỈ in mã khoang, một dòng. Ô chật thì chỉ thu nhỏ
                    // cỡ chữ — không bỏ chữ. Trần 9px nhân theo zoom cho cùng
                    // tỉ lệ ở mọi mức.
                    const f = Math.min(fitFont(pw - 2, ph - 1, [code]), 9 * zoom);
                    const txt = f > 0 ? '<span>' + esc(code) + '</span>' : '';

                    // Tooltip CHỈ còn tỉ lệ chiếm dụng: mã khoang đã nằm trong ô
                    // nên không lặp lại, và tỉ lệ của cả kệ đã hiện thường trực
                    // ở nhãn kệ bên dưới.
                    return '<i style="background:' + rackFill(r) +
                           (f > 0 ? ';font-size:' + fontPx(f) + ';color:' + rackInk(r) : '') +
                           '" title="' + ratio + '">' + txt + '</i>';
                }).join('');
                if (cells) {
                    const box = document.createElement('div');
                    box.className = 'tlm-rk-cells ' + (horiz ? 'h' : 'v');
                    box.innerHTML = cells;
                    el.appendChild(box);
                }

                // Nhãn kệ: mã kệ + số ô có hàng / tổng số ô. Nhãn là một viên
                // pill nằm ĐÈ trên kệ, nên phải vừa bề rộng kệ.
                // Kệ rộng -> một dòng ở trọn cỡ chữ gốc. Kệ hẹp -> hai dòng và
                // mã kệ ưu tiên giữ nguyên cỡ, chỉ phần tỉ lệ thu nhỏ: nhồi cả
                // hai vào một dòng sẽ làm mã kệ nhỏ đến mức không đọc được.
                lbl.innerHTML = rackLabelHtml(rkCode, c.occupiedSlots || 0, c.totalSlots || 0,
                                              c.w * cp - 4, 12 * zoom);
                el.title = rkCode + ' (' + (c.occupiedSlots || 0) + '/' + (c.totalSlots || 0) + ')';
            }
            else if (c.type === 'pallet') {
                lbl.innerHTML = '<span class="pl">' + esc(c.code || c.label || '') + '</span>' + (c.model ? '<span class="md">' + esc(c.model) + '</span>' : '');
                el.title = cellTitle(c);   // mã ô + từng lô: mã · model (số thùng)
            }
            else lbl.textContent = c.label || '';
            el.appendChild(lbl);
            // Không hiển thị mũi tên hướng trên ô map — chiều mũi tên chỉ in trên tem QR.
            // (QR mini góc ô cũng đã bỏ; QR chỉ hiện ở panel thuộc tính & khi in.)
            if (String(c.id) === selId && mode === 'edit') { const rz = document.createElement('div'); rz.className = 'rz'; el.appendChild(rz); }
            return el;
        }

        function selectCell(id) { selId = id == null ? null : String(id); renderGrid(); renderInspector(); }

        // ---- inspector (rút gọn: chỉ phần cốt lõi, đủ thao tác) ----
        // Trạng thái pallet (chỉ đọc) — màu nền theo inspection + cờ khẩn nếu có.
        function renderStatusView(c) {
            const st = c.status || 'empty';
            const stNm = stLabel(st);
            const urgent = c.isUrgent ? '<span class="tlm-sv-urgent">' + m2('TempLoc.Status.Urgent') + '</span>' : '';
            return '<div class="tlm-sv">'
                + '<span class="tlm-sv-dot" style="background:' + stBg(st) + '"></span>'
                + '<span class="tlm-sv-name">' + stNm + '</span>' + urgent + '</div>';
        }

        // Tóm tắt lot trong panel: số lot + nút gợi ý double-click xem chi tiết.
        function renderLotSummary(c) {
            const lots = c.lots || [];
            if (!lots.length) {
                return '<div class="tlm-lots-empty">' + m2('TempLoc.Lots.Empty') + '</div>';
            }
            // đếm theo trạng thái để hiện chip nhỏ
            const cnt = {};
            lots.forEach(l => { const s = l.mappedStatus || 'not_inspected'; cnt[s] = (cnt[s] || 0) + 1; });
            const chips = Object.keys(cnt).map(s => '<span class="tlm-lsum-chip"><span class="d" style="background:' + stBg(s) + '"></span>' + cnt[s] + '</span>').join('');
            return '<div class="tlm-lsum" data-role="lotsummary">'
                + '<div class="tlm-lsum-top"><span class="tlm-lsum-title">' + m2('TempLoc.Lots.Title') + ' (' + lots.length + ')</span>' + chips + '</div>'
                + '<div class="tlm-lsum-hint">' + m2('TempLoc.Lots.DblClickHint') + '</div>'
                + '</div>';
        }

        // Dấu RW/RB cạnh Pallet ID.
        //
        // Bắt buộc có ở khu Nhận hàng: pallet tái gia công mang
        // inspection_status 'ng' suốt vòng đời, nhìn y hệt pallet bị OQC đánh
        // fail — mà một bên là hàng đang chờ giao cho FA, một bên là hàng lỗi
        // phải xử lý. Màu trùng với bản đồ kho và badge trên tem: RW tím, RB
        // cam; một pallet không được đổi màu khi đổi màn.
        function dispChip(d) {
            if (d === 'rework') return '<span class="tlm-lotrow-disp rw">RW</span>';
            if (d === 'refurbish') return '<span class="tlm-lotrow-disp rb">RB</span>';
            return '';
        }

        // Dialog danh sách lot đầy đủ — mỗi dòng màu theo trạng thái lot.
        function openLotDialog(c) {
            const lots = c.lots || [];
            let ov = document.querySelector('.tlm-lotdlg-ov');
            if (ov) ov.remove();
            ov = document.createElement('div');
            ov.className = 'tlm-lotdlg-ov';

            const rows = lots.length ? lots.map(l => {
                const st = l.mappedStatus || 'not_inspected';
                const stName = stLabel(st);
                const urgent = l.isUrgent ? '<span class="tlm-lotrow-urgent">' + m2('TempLoc.Status.Urgent') + '</span>' : '';
                const models = l.models ? esc(l.models) : '—';
                const boxes = (l.boxCount != null) ? String(l.boxCount) : '—';
                const pdate = l.productionDate ? new Date(l.productionDate).toLocaleDateString('vi-VN') : '—';
                return '<div class="tlm-lotrow ' + stMeta(st).cls + '">'
                    + '<div class="tlm-lotrow-bar"></div>'
                    + '<div class="tlm-lotrow-main">'
                    + '<div class="tlm-lotrow-r1"><span class="tlm-lotrow-no">' + esc(l.lotNo || '') + '</span>'
                    + dispChip(l.disposition) + urgent
                    + '<span class="tlm-lotrow-badge">' + stName + '</span></div>'
                    + '<div class="tlm-lotrow-r2"><span class="tlm-lotrow-model" title="' + models + '">' + models + '</span></div>'
                    + '</div>'
                    + '<div class="tlm-lotrow-meta"><div><b>' + boxes + '</b><span>' + m2('TempLoc.Lots.BoxCol') + '</span></div>'
                    + '<div><b>' + pdate + '</b><span>' + m2('TempLoc.Lots.DateCol') + '</span></div></div>'
                    + '</div>';
            }).join('') : '<div class="tlm-lots-empty" style="margin:20px">' + m2('TempLoc.Lots.Empty') + '</div>';

            ov.innerHTML = '<div class="tlm-lotdlg">'
                + '<div class="tlm-lotdlg-hd"><div><div class="tlm-lotdlg-title">' + esc(c.code || '') + '</div>'
                + '<div class="tlm-lotdlg-sub">' + m2('TempLoc.Lots.Title') + ' · ' + lots.length + '</div></div>'
                + '<button class="tlm-lotdlg-x" data-role="close">&times;</button></div>'
                + '<div class="tlm-lotdlg-body">' + rows + '</div>'
                + '</div>';
            document.body.appendChild(ov);
            const close = () => ov.remove();
            ov.addEventListener('click', e => { if (e.target === ov || e.target.closest('[data-role=close]')) close(); });
            window.addEventListener('keydown', function esc2(e) { if (e.key === 'Escape') { close(); window.removeEventListener('keydown', esc2); } });
        }

        function renderInspector() {
            const c = model.cells.find(x => String(x.id) === selId);
            if (!c) {
                inspTitle.textContent = m2('TempLoc.Insp.Title'); inspSub.textContent = m2('TempLoc.Insp.Hint');
                inspBody.innerHTML = '<div class="tlm-insp-empty">' + m2('TempLoc.Insp.Empty') + '<br/>' + m2('TempLoc.Insp.ClickHint') + '</div>'; return;
            }
            inspTitle.textContent = c.code || c.label || m2('TempLoc.ZoneCell');
            inspSub.textContent = (c.w * model.cellMeters).toFixed(1) + '×' + (c.h * model.cellMeters).toFixed(1) + 'm';

            let h = '';

            if (mode === 'view') {
                if (c.type === 'pallet') {
                    h += '<div class="tlm-qrprev"><canvas data-role="vqr"></canvas><div class="code">' + esc(c.code || '') + '</div></div>';
                    // Trạng thái hiện tại (CHỈ ĐỌC — dẫn xuất từ lot, không sửa tay).
                    h += renderStatusView(c);
                    // Tóm tắt lot + gợi ý double-click xem chi tiết (list đầy đủ ở dialog).
                    h += renderLotSummary(c);
                    h += '<div class="tlm-divider"></div><button class="tlm-btn" data-role="vprint" style="width:100%">' + m2('TempLoc.Btn.PrintThis') + '</button>';
                } else {
                    h += '<div class="tlm-stat" style="border-left:4px solid ' + (c.color || '#8894A5') + '"><div class="k">' + m2('TempLoc.ZoneCell') + '</div><div class="v">' + esc(c.label || '') + '</div></div>';
                }
            } else {
                // edit
                h += '<div class="tlm-field"><label>' + m2('TempLoc.Field.CellType') + '</label><div class="tlm-typetog" data-role="typetog">' +
                    '<button class="tlm-typebtn ' + (c.type === 'pallet' ? 'on' : '') + '" data-t="pallet"><span class="sw" style="background:var(--st-pass-bg)"></span>' + m2('TempLoc.Tool.Pallet').split(' (')[0] + '</button>' +
                    '<button class="tlm-typebtn ' + (c.type === 'zone' ? 'on' : '') + '" data-t="zone"><span class="sw" style="background:' + (c.color || '#8894A5') + '"></span>' + m2('TempLoc.ZoneCell') + '</button></div></div>';
                if (c.type === 'pallet') {
                    h += fld(m2('TempLoc.Field.PlName'), '<input data-role="code" value="' + esc(c.code || '') + '">');
                    h += '<div class="tlm-field"><label>' + m2('TempLoc.Field.Arrow') + '</label><div class="tlm-arrows" data-role="arrow">' +
                        ['up', 'left', 'right', 'down'].map(a => '<button data-a="' + a + '" class="' + (c.arrow === a ? 'on' : '') + '">' + ARROW_SVG[a] + '</button>').join('') + '</div></div>';
                    h += '<div class="tlm-qrprev"><canvas data-role="qr"></canvas><div class="code">' + esc(c.code || '') + '</div></div>';
                } else {
                    h += fld(m2('TempLoc.Field.ZoneLabel'), '<textarea data-role="label" rows="2" placeholder="' + m2('TempLoc.ZonePlaceholder') + '">' + esc(c.label || '') + '</textarea>');
                    h += '<div class="tlm-field"><label>' + m2('TempLoc.Field.ZoneColor') + '</label><div class="tlm-swatch" data-role="color">' +
                        ZONE_COLORS.map(v => '<button data-c="' + v + '" class="' + (c.color === v ? 'on' : '') + '" style="background:' + v + '"></button>').join('') + '</div></div>';
                }
                h += '<div class="tlm-field"><label>' + m2('TempLoc.Field.Pos') + '</label><div class="row2">' +
                    ['x', 'y', 'w', 'h'].map(k => '<div class="tlm-inline"><span class="h">' + k.toUpperCase() + '</span><input data-role="' + k + '" type="number" value="' + c[k] + '"></div>').join('') + '</div></div>';
                h += '<div class="tlm-divider"></div><div style="display:flex;gap:8px">' +
                    '<button class="tlm-btn" data-role="dup" style="flex:1">' + m2('TempLoc.Btn.Dup') + '</button>' +
                    '<button class="tlm-btn danger" data-role="del" style="flex:1">' + m2('TempLoc.Btn.Del') + '</button></div>';
            }
            inspBody.innerHTML = h; bindInsp(c);
        }
        function cap(s) { return s.charAt(0).toUpperCase() + s.slice(1); }
        function fld(l, inner) { return '<div class="tlm-field"><label>' + l + '</label>' + inner + '</div>'; }

        function bindInsp(c) {
            const q = r => inspBody.querySelector('[data-role=' + r + ']');
            const vq = q('vqr'); if (vq) drawQR(vq, c.code || '');
            const qc = q('qr'); if (qc) drawQR(qc, c.code || '');
            const vp = q('vprint'); if (vp) vp.addEventListener('click', () => printLabels([c]));
            const lsum = q('lotsummary'); if (lsum) { lsum.style.cursor = 'pointer'; lsum.addEventListener('click', () => openLotDialog(c)); }
            const tt = q('typetog'); if (tt) tt.querySelectorAll('.tlm-typebtn').forEach(b => b.addEventListener('click', () => { if (c.type === b.dataset.t) return; pushUndo(); c.type = b.dataset.t; if (c.type === 'zone' && !c.color) c.color = '#8894A5'; selectCell(c.id); }));
            const cl = q('color'); if (cl) cl.querySelectorAll('button').forEach(b => b.addEventListener('click', () => { pushUndo(); c.color = b.dataset.c; cl.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.c === c.color)); renderGrid(); }));
            const lab = q('label'); if (lab) lab.addEventListener('input', e => { c.label = e.target.value; syncLabel(c); });
            const cod = q('code'); if (cod) cod.addEventListener('input', e => {
                const v = e.target.value.trim();
                c.code = e.target.value;
                // cảnh báo nếu trùng mã với ô pallet khác
                const dup = v && model.cells.some(x => x.id !== c.id && x.type === 'pallet'
                    && (x.code || '').trim().toLowerCase() === v.toLowerCase());
                e.target.style.borderColor = dup ? 'var(--danger)' : '';
                e.target.title = dup ? ('Mã "' + v + '" đã tồn tại ở ô khác') : '';
                if (dup) toast('Mã "' + v + '" đã tồn tại — hãy đặt mã khác.');
                const cc = inspBody.querySelector('.tlm-qrprev .code'); if (cc) cc.textContent = c.code || '';
                if (qc) drawQR(qc, c.code || ''); syncLabel(c);
            });
            ['x', 'y', 'w', 'h'].forEach(k => { const el = q(k); if (el) el.addEventListener('change', e => { pushUndo(); c[k] = Math.max((k === 'w' || k === 'h') ? 1 : 0, parseInt(e.target.value) || 0); clampCell(c); renderGrid(); renderInspector(); }); });
            const ar = q('arrow'); if (ar) ar.querySelectorAll('button').forEach(b => b.addEventListener('click', () => { pushUndo(); c.arrow = (c.arrow === b.dataset.a) ? null : b.dataset.a; ar.querySelectorAll('button').forEach(x => x.classList.toggle('on', x.dataset.a === c.arrow)); renderGrid(); }));
            const du = q('dup'); if (du) du.addEventListener('click', dupSel);
            const de = q('del'); if (de) de.addEventListener('click', delSel);
        }
        function syncLabel(c) { const el = grid.querySelector('.tlm-cell[data-id="' + c.id + '"] .lbl'); if (el) { if (c.type === 'pallet') el.innerHTML = '<span class="pl">' + esc(c.code || c.label || '') + '</span>' + (c.model ? '<span class="md">' + esc(c.model) + '</span>' : ''); else el.textContent = c.label || ''; } }

        // ---- mouse (vẽ/kéo/resize, kẹp biên) ----
        let drag = null;
        grid.addEventListener('mousedown', e => {
            if (mode !== 'edit') {
                const ce = e.target.closest('.tlm-cell');
                if (ce) {
                    // Tự phát hiện double-click: 2 lần bấm cùng 1 ô trong 350ms -> mở dialog lot.
                    // (Không dùng sự kiện 'dblclick' vì renderGrid vẽ lại DOM giữa 2 click làm nó không kích hoạt.)
                    const id = ce.dataset.id, now = Date.now();
                    if (_lastClick && _lastClick.id === id && (now - _lastClick.t) < 350) {
                        _lastClick = null;
                        const c = model.cells.find(x => String(x.id) === String(id));
                        if (c && c.type === 'pallet') openLotDialog(c);
                        // Kệ: mở mặt đứng (C# xử lý) để xem chi tiết từng tầng/vị trí.
                        else if (c && c.type === 'rack' && c.rackCode) {
                            try { dotNetRef.invokeMethodAsync('OnOpenRack', c.rackCode); } catch (e) { }
                        }
                        return;
                    }
                    _lastClick = { id, t: now };
                    selectCell(id);
                }
                return;
            }
            const cp = model.cell * zoom, r = grid.getBoundingClientRect();
            let gx = clamp((e.clientX - r.left) / cp, 0, model.cols), gy = clamp((e.clientY - r.top) / cp, 0, model.rows);
            if (e.target.classList.contains('rz')) { const c = model.cells.find(x => String(x.id) === String(selId)); if (!c) return; drag = { m: 'resize', c, sx: gx, sy: gy, ow: c.w, oh: c.h }; pushUndo(); return; }
            const ce = e.target.closest('.tlm-cell');
            if (tool === 'select') { if (ce) { const c = model.cells.find(x => String(x.id) === String(ce.dataset.id)); if (c) { selectCell(c.id); drag = { m: 'move', c, sx: gx, sy: gy, ox: c.x, oy: c.y }; pushUndo(); } } else selectCell(null); return; }
            if (tool === 'erase') { if (ce) { pushUndo(); model.cells = model.cells.filter(x => String(x.id) !== String(ce.dataset.id)); selId = null; renderGrid(); renderInspector(); } return; }
            drag = { m: 'draw', sx: Math.floor(gx), sy: Math.floor(gy), ghost: null }; pushUndo();
        });
        window.addEventListener('mousemove', onMove); window.addEventListener('mouseup', onUp);
        function onMove(e) {
            if (!drag) return; const cp = model.cell * zoom, r = grid.getBoundingClientRect();
            let gx = clamp((e.clientX - r.left) / cp, 0, model.cols), gy = clamp((e.clientY - r.top) / cp, 0, model.rows);
            if (drag.m === 'move') { drag.c.x = clamp(Math.round(drag.ox + (gx - drag.sx)), 0, model.cols - drag.c.w); drag.c.y = clamp(Math.round(drag.oy + (gy - drag.sy)), 0, model.rows - drag.c.h); pos(drag.c); }
            else if (drag.m === 'resize') { drag.c.w = clamp(Math.round(drag.ow + (gx - drag.sx)), 1, model.cols - drag.c.x); drag.c.h = clamp(Math.round(drag.oh + (gy - drag.sy)), 1, model.rows - drag.c.y); pos(drag.c); }
            else if (drag.m === 'draw') {
                let fx = clamp(Math.floor(gx), 0, model.cols - 1), fy = clamp(Math.floor(gy), 0, model.rows - 1);
                const x0 = Math.min(drag.sx, fx), y0 = Math.min(drag.sy, fy), w = Math.abs(fx - drag.sx) + 1, h = Math.abs(fy - drag.sy) + 1;
                if (!drag.ghost) { drag.ghost = document.createElement('div'); drag.ghost.className = 'tlm-cell ' + (tool === 'zone' ? 't-zone' : 't-pallet'); drag.ghost.style.opacity = .55; if (tool === 'zone') drag.ghost.style.background = '#8894A5'; grid.appendChild(drag.ghost); }
                drag.ghost.style.cssText = `left:${x0 * cp}px;top:${y0 * cp}px;width:${w * cp}px;height:${h * cp}px;opacity:.55`; drag.rect = { x: x0, y: y0, w, h };
            }
        }
        function onUp() {
            if (!drag) return;
            if (drag.m === 'draw' && drag.rect) {
                const r = drag.rect;
                const nc = { id: uid(), type: tool === 'zone' ? 'zone' : 'pallet', x: r.x, y: r.y, w: r.w, h: r.h, code: tool === 'zone' ? nextZone() : nextPL(), label: tool === 'zone' ? m2('TempLoc.ZoneCell') : null, arrow: tool === 'zone' ? null : 'left', status: 'empty', color: tool === 'zone' ? '#8894A5' : null, sortOrder: model.cells.length };
                clampCell(nc); model.cells.push(nc); if (drag.ghost) drag.ghost.remove(); selectCell(nc.id); setTool('select');
            }
            else if (drag.m === 'move' || drag.m === 'resize') { renderInspector(); }
            drag = null;
        }
        function pos(c) { const cp = model.cell * zoom, el = grid.querySelector('.tlm-cell[data-id="' + c.id + '"]'); if (el) { el.style.left = (c.x * cp) + 'px'; el.style.top = (c.y * cp) + 'px'; el.style.width = (c.w * cp) + 'px'; el.style.height = (c.h * cp) + 'px'; } }
        function nextPL() { let mx = 0; model.cells.forEach(c => { const m = /^PL(\d+)$/.exec(c.code || ''); if (m) mx = Math.max(mx, +m[1]); }); return 'PL' + (mx + 1); }
        // Mã kỹ thuật cho vùng zone (không phải vị trí lưu hàng, nhưng cột locator_code NOT NULL).
        function nextZone() {
            const area = (model.areaCode || 'Z'); let mx = 0;
            model.cells.forEach(c => { const m = new RegExp('^' + area + '-Z-(\\d+)$').exec(c.code || ''); if (m) mx = Math.max(mx, +m[1]); });
            return area + '-Z-' + (mx + 1);
        }

        function dupSel() { const c = model.cells.find(x => String(x.id) === selId); if (!c) return; pushUndo(); const nc = Object.assign({}, c, { id: uid(), x: clamp(c.x + c.w, 0, model.cols - c.w), code: c.type === 'pallet' ? nextPL() : nextZone() }); clampCell(nc); model.cells.push(nc); selectCell(nc.id); }
        function delSel() { if (!selId) return; pushUndo(); model.cells = model.cells.filter(x => String(x.id) !== selId); selId = null; renderGrid(); renderInspector(); }

        // ---- tools / mode ----
        function setTool(t) { tool = t; container.querySelectorAll('.tlm-tool').forEach(b => b.classList.toggle('active', b.dataset.tool === t)); }
        container.querySelectorAll('.tlm-tool').forEach(b => b.addEventListener('click', () => {
            const t = b.dataset.tool;
            if (t === 'renumber') { renumber(); return; }
            if (t === 'palletrow') { addRow(); return; }
            setTool(t);
        }));
        function setMode(mm) {
            mode = mm; filterStatus = null;
            container.querySelectorAll('.tlm-modetab').forEach(b => b.classList.toggle('active', b.dataset.mode === mm));
            $('.tlm-toolbar').classList.toggle('hidden', mm !== 'edit');
            // nút thu gọn trái chỉ hiện khi có thanh công cụ (mode edit)
            $('.tlm-collapse-tab.left').style.display = mm === 'edit' ? '' : 'none';
            $('.tlm-save').style.display = mm === 'edit' ? '' : 'none';
            // panel điều khiển trái CHỈ hiện ở Vận hành
            const op = $('.tlm-oppanel'); if (op) op.classList.toggle('hidden', mm !== 'view');
            selId = null; renderGrid(); renderInspector();
            if (mm === 'view') { renderMapHeader(); renderStats(); renderNewLots(); }
        }
        $('[data-mode=view]').addEventListener('click', () => setMode('view'));
        // Input tìm Model -> nháy pallet chứa model (debounce nhẹ).
        (function () {
            const inp = $('[data-role=modelsearch]'); if (!inp) return; let t = null;
            inp.addEventListener('input', e => { clearTimeout(t); const v = e.target.value; t = setTimeout(() => highlightByModel(v), 180); });
        })();
        $('[data-mode=edit]').addEventListener('click', () => setMode('edit'));

        // Helpers trạng thái (bám STATUS_META, tránh lệ thuộc dạng chuỗi mã).
        function stMeta(code) { return STATUS_META[code] || STATUS_META.empty; }
        function stBg(code) { return 'var(--st-' + stMeta(code).varc + '-bg)'; }
        function stLabel(code) { return m2(stMeta(code).key); }
        function renderMapHeader() {
            const wrapSel = $('[data-role=mapselwrap]');
            const sel = $('[data-role=mapsel]');
            const maps = opts.maps || [];

            if (sel && maps.length > 1) {
                sel.innerHTML = maps.map(m =>
                    `<option value="${esc(m.areaCode)}"${m.areaCode === opts.areaCode ? ' selected' : ''}>${esc(m.areaName)}</option>`
                ).join('');
                sel.onchange = () => {
                    try { dotNetRef.invokeMethodAsync('OnMapSelectedJs', sel.value); } catch (e) { }
                };
                if (wrapSel) wrapSel.style.display = '';
            } else if (wrapSel) {
                wrapSel.style.display = 'none';
            }

            const sum = opts.summary;
            const wrapSum = $('[data-role=sumwrap]');
            if (sum && (sum.totalSlots || 0) > 0) {
                const occ = sum.occupiedSlots || 0;
                const tot = sum.totalSlots || 0;
                const pct = sum.occupiedPercent != null
                    ? sum.occupiedPercent
                    : Math.round(occ * 1000 / tot) / 10;
                // Ba con số rời nhau, mỗi số một nhãn: người đọc không phải tự
                // trừ tổng ra số ô còn trống. Math.max phòng dữ liệu lệch
                // (đã chứa > tổng) thì hiện 0 chứ không hiện số âm.
                const put = (role, v) => {
                    const el = $(`[data-role=${role}]`);
                    if (el) el.textContent = v;
                };
                put('sumocc', occ);
                put('sumfree', Math.max(0, tot - occ));
                put('sumtot', tot);
                const p = $('[data-role=sumpct]');
                const bar = $('[data-role=sumbar]');
                if (p) p.textContent = pct + '%';
                if (bar) bar.style.width = Math.min(100, pct) + '%';
                if (wrapSum) wrapSum.style.display = '';
            } else if (wrapSum) {
                wrapSum.style.display = 'none';
            }
        }

        function renderStats() {
            const box = $('[data-role=opstats]'); if (!box) return;
            const pals = model.cells.filter(c => c.type === 'pallet'); const cnt = {}; STATUS_ORDER.forEach(k => cnt[k] = 0);
            pals.forEach(c => {
                if (cnt[c.status] !== undefined) cnt[c.status]++;
                if (c.isUrgent) cnt['is_urgent']++;
            });
            // Kho lưu / vanning chỉ dùng vài trạng thái -> chỉ liệt kê cái ĐANG CÓ trên bản đồ.
            // Receiving là nơi hàng đi qua mọi trạng thái nên vẫn hiện đủ danh sách.
            const dynamic = (opts.mapType === 'vanning' || opts.mapType === 'storing');
            const keys = dynamic
                ? STATUS_ORDER.filter(k => cnt[k] > 0 || filterStatus === k)
                : STATUS_ORDER;

            box.innerHTML = keys.map(k => {
                const mt = STATUS_META[k];
                const sw = mt.frame
                    ? '<span class="sw frame"></span>'
                    : '<span class="sw" style="background:var(--st-' + mt.varc + '-bg)"></span>';
                return '<div class="tlm-opstat ' + (filterStatus === k ? 'on' : '') + '" data-f="' + k + '">'
                    + sw + '<span class="n">' + cnt[k] + '</span><span class="t">' + m2(mt.key) + '</span></div>';
            }).join('');
            box.querySelectorAll('.tlm-opstat').forEach(b => b.addEventListener('click', () => {
                filterStatus = filterStatus === b.dataset.f ? null : b.dataset.f; renderGrid(); renderStats();
            }));
        }

        // List model mới về: tách từng model từ các lot đã có vị trí, sort theo production_date giảm dần, lấy 10.
        function renderNewLots() {
            const track = $('[data-role=newtrack]'); if (!track) return;
            const all = [];
            model.cells.forEach(c => {
                if (c.type !== 'pallet' || !Array.isArray(c.lots)) return;
                c.lots.forEach(l => {
                    const models = (l.models || '').split(',').map(s => s.trim()).filter(Boolean);
                    const pd = l.productionDate ? +new Date(l.productionDate) : 0;
                    if (models.length) {
                        models.forEach(mdl => all.push({
                            model: mdl, lotNo: l.lotNo, palletCode: c.code,
                            mappedStatus: l.mappedStatus,
                            cellStatus: c.status,      // trạng thái tổng của pallet (cho khung mã)
                            cellUrgent: c.isUrgent, pd
                        }));
                    }
                });
            });
            all.sort((a, b) => b.pd - a.pd);
            const top = all.slice(0, 10);
            if (!top.length) { track.innerHTML = '<div class="tlm-op-newempty">' + m2('TempLoc.Op.NoNewLots') + '</div>'; return; }
            const rowHtml = r => {
                const st = r.mappedStatus || 'not_inspected';
                const pst = r.cellStatus || 'empty';
                const plCls = 'pl-' + stMeta(pst).varc + (r.cellUrgent ? ' pl-urgent' : '');
                return '<div class="tlm-newrow" data-model="' + esc((r.model || '').toLowerCase()) + '">'
                    + '<span class="tlm-newrow-dot" style="background:' + stBg(st) + '"></span>'
                    + '<span class="tlm-newrow-lot">' + esc(r.model || '') + '</span>'
                    + '<span class="tlm-newrow-arrow">→</span>'
                    + '<span class="tlm-newrow-pl ' + plCls + '">' + esc(r.palletCode || '') + '</span></div>';
            };
            const enableScroll = top.length > 6;
            track.innerHTML = enableScroll ? (top.map(rowHtml).join('') + top.map(rowHtml).join('')) : top.map(rowHtml).join('');
            track.style.animation = enableScroll ? '' : 'none';
        }

        // Nháy sáng các pallet chứa model đang tìm.
        let _hlModel = '';
        function highlightByModel(q) {
            _hlModel = (q || '').trim().toLowerCase();
            const hint = $('[data-role=searchhint]');
            grid.querySelectorAll('.tlm-cell.t-pallet').forEach(el => el.classList.remove('hl-match'));
            if (!_hlModel) { if (hint) hint.textContent = ''; return; }
            let n = 0; const codes = [];
            model.cells.forEach(c => {
                if (c.type !== 'pallet' || !Array.isArray(c.lots)) return;
                const match = c.lots.some(l => (l.models || '').toLowerCase().includes(_hlModel));
                if (match) {
                    n++; codes.push(c.code);
                    const el = grid.querySelector('.tlm-cell[data-id="' + c.id + '"]'); if (el) el.classList.add('hl-match');
                }
            });
            if (hint) hint.textContent = n ? (m2('TempLoc.Op.FoundAt') + ': ' + codes.join(', ')) : m2('TempLoc.Op.NotFound');
        }

        function renumber() {
            const r = prompt('PL,1'); if (!r) return; const [p = 'PL', k = '1'] = r.split(',').map(s => s.trim()); pushUndo();
            const pals = model.cells.filter(c => c.type === 'pallet'); pals.sort((a, b) => k === '2' ? (a.x - b.x) || (a.y - b.y) : (a.y - b.y) || (a.x - b.x)); pals.forEach((c, i) => c.code = p + (i + 1)); renderGrid(); renderInspector();
        }
        function addRow() { const n = parseInt(prompt('10')) || 0; if (!n) return; pushUndo(); let x = 2, y = 2; for (let i = 0; i < n; i++) { const nc = { id: uid(), type: 'pallet', x, y, w: 7, h: 6, code: nextPL(), arrow: 'left', status: 'empty', sortOrder: model.cells.length }; clampCell(nc); model.cells.push(nc); y += 6; } renderGrid(); }

        // ---- undo / zoom ----
        function pushUndo() { undoStack.push(JSON.stringify(model.cells)); if (undoStack.length > 60) undoStack.shift(); }
        function undo() { if (!undoStack.length) return; model.cells = JSON.parse(undoStack.pop()); selId = null; renderGrid(); renderInspector(); if (mode === 'view') renderStats(); }
        function onKey(e) {
            if (/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName)) return; if (!container.isConnected) return;
            if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'z') { e.preventDefault(); undo(); return; }
            if (mode !== 'edit') return;
            if (e.key === 'Delete' || e.key === 'Backspace') { delSel(); return; }
            const map = { v: 'select', p: 'pallet', z: 'zone', e: 'erase' }; if (map[e.key.toLowerCase()]) setTool(map[e.key.toLowerCase()]);
            if (selId && ['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
                e.preventDefault(); const c = model.cells.find(x => String(x.id) === selId); if (!c) return; pushUndo();
                if (e.key === 'ArrowUp') c.y = clamp(c.y - 1, 0, model.rows - c.h); if (e.key === 'ArrowDown') c.y = clamp(c.y + 1, 0, model.rows - c.h);
                if (e.key === 'ArrowLeft') c.x = clamp(c.x - 1, 0, model.cols - c.w); if (e.key === 'ArrowRight') c.x = clamp(c.x + 1, 0, model.cols - c.w); pos(c);
            }
        }
        window.addEventListener('keydown', onKey);
        function setZoom(z) { zoom = clamp(z, 0.3, 3); $('.tlm-zoom .zv').textContent = Math.round(zoom * 100) + '%'; renderGrid(); }
        // Vùng thật đang có nội dung (bounding box của mọi ô) — để fit phóng to sát nội dung,
        // không bị lưới trống 115×75 kéo cho nhỏ lại.
        function contentBounds() {
            if (!model.cells.length) return { w: model.cols, h: model.rows };
            let maxX = 0, maxY = 0;
            model.cells.forEach(c => { maxX = Math.max(maxX, c.x + c.w); maxY = Math.max(maxY, c.y + c.h); });
            // chừa lề 3 ô mỗi phía cho thước + khoảng thở
            return { w: Math.min(model.cols, maxX + 3), h: Math.min(model.rows, maxY + 3) };
        }
        function fit() {
            const a = $('.tlm-canvas'), pad = 70; const b = contentBounds();
            // Ưu tiên lấp đầy chiều NGANG để pallet to, rõ; nếu quá cao thì cuộn dọc.
            // Vẫn chặn trên bằng zoom vừa đủ để không bị cắt quá nhiều chiều cao.
            const zW = (a.clientWidth - pad) / (b.w * model.cell);
            const zH = (a.clientHeight - pad) / (b.h * model.cell);
            // lấy theo ngang, nhưng không vượt quá 1.6× chiều cao (tránh phải cuộn quá dài)
            setZoom(Math.min(zW, zH * 1.6));
        }
        $('.tlm-zoom-in').addEventListener('click', () => setZoom(zoom + 0.1));
        $('.tlm-zoom-out').addEventListener('click', () => setZoom(zoom - 0.1));
        // Nút ⤢: bật/tắt chế độ xem toàn màn hình bằng CSS (KHÔNG dùng Fullscreen API
        // vì fullscreen một element lồng sâu có thể làm hỏng tương tác của layout cha).
        $('.tlm-zoom-fit').addEventListener('click', () => {
            const on = container.classList.toggle('tlm-fullpage');
            document.body.style.overflow = on ? 'hidden' : '';
            setTimeout(fit, 120);
        });
        // Esc để thoát chế độ toàn màn hình.
        window.addEventListener('keydown', e => {
            if (e.key === 'Escape' && container.classList.contains('tlm-fullpage')) {
                container.classList.remove('tlm-fullpage'); document.body.style.overflow = ''; setTimeout(fit, 120);
            }
        });
        $('.tlm-canvas').addEventListener('wheel', e => { if (e.ctrlKey) { e.preventDefault(); setZoom(zoom + (e.deltaY < 0 ? 0.08 : -0.08)); } }, { passive: false });

        // ---- collapse ----
        $('.tlm-collapse-tab.left').addEventListener('click', () => { $('.tlm-toolbar').classList.toggle('collapsed'); });
        $('.tlm-collapse-tab.right').addEventListener('click', () => { $('.tlm-insp').classList.toggle('collapsed'); });

        // ---- save (gọi .NET) ----
        $('.tlm-save').addEventListener('click', async () => {
            // đảm bảo MỌI ô đều có code (cột locator_code NOT NULL): ô nào trống thì tự sinh.
            model.cells.forEach(c => { if (!c.code || !String(c.code).trim()) { c.code = c.type === 'zone' ? nextZone() : nextPL(); } });
            const payload = {
                cols: model.cols, rows: model.rows, cellMeters: model.cellMeters,
                cells: model.cells.map(c => ({
                    id: (typeof c.id === 'string' && c.id[0] === 'n') ? null : c.id, code: c.code, cellType: c.type,
                    gridX: c.x, gridY: c.y, gridW: c.w, gridH: c.h, arrow: c.arrow, color: c.color, label: c.label,
                    status: c.status, model: c.model, lotNo: c.lotNo, sortOrder: c.sortOrder || 0
                }))
            };
            try {
                await dotNetRef.invokeMethodAsync('OnSaveLayout', JSON.stringify(payload));
            } catch (e) {
                console.error('[TempLocMap] Lưu layout lỗi:', e);
                toast('Lưu thất bại: ' + (e && e.message ? e.message : e));
            }
        });

        // ---- print QR ----
        $('.tlm-print-btn').addEventListener('click', () => { const pals = model.cells.filter(c => c.type === 'pallet' && c.code); printLabels(selId ? model.cells.filter(c => String(c.id) === selId && c.type === 'pallet') : pals); });
        function printLabels(list) {
            if (!list || !list.length) { toast(m2('TempLoc.Toast.NoPrint')); return; }
            if (typeof qrcode === 'undefined') { toast('Chưa nạp được thư viện QR — không thể in mã.'); console.error('[TempLocMap] qrcode library undefined'); return; }

            // Mỗi tem = 1 nhãn 15cm x 5cm: mũi tên lên (trái) · mã PL 1 dòng (giữa) · QR (phải).
            // Thực tế chỉ cần mũi tên HƯỚNG LÊN — user xoay tờ giấy khi dán vào PL.
            // Mã PL tối đa 2 chữ số (PL1..PL99) -> font to cố định, luôn vừa 1 dòng.
            const labels = list.map(c => {
                const arw = ARROW_SOLID.up;
                const img = qrDataURL(c.code || 'PL');
                const code = esc(c.code || '');
                // Vùng chữ giữa rộng ~58mm. Mã tối đa PL + 2 chữ số (PL99).
                // Font co nhẹ theo độ dài để mã 4 ký tự không chạm mép.
                const len = (c.code || '').length;
                const fs = len <= 3 ? 104 : 84;   // vùng giữa rộng hơn -> font to hơn
                return '<div class="lbl">'
                    + '<div class="arw">' + arw + '</div>'
                    + '<div class="pl" style="font-size:' + fs + 'px">' + code + '</div>'
                    + '<div class="qr"><img src="' + img + '"/></div>'
                    + '</div>';
            }).join('');

            const html = '<!DOCTYPE html><html><head><meta charset="utf-8"><title>QR Location</title><style>'
                + '*{margin:0;padding:0;box-sizing:border-box}'
                + 'body{font-family:Arial,\'Segoe UI\',sans-serif;padding:6mm;background:#fff}'
                + '.lbl{position:relative;width:150mm;height:50mm;border:2.5px solid #000;border-radius:3mm;'
                + 'margin:0 auto 5mm;break-inside:avoid;page-break-inside:avoid;overflow:hidden}'
                // mũi tên chốt sát mép trái
                + '.arw{position:absolute;left:1mm;top:50%;transform:translateY(-50%);'
                + 'width:30mm;height:44mm;display:flex;align-items:center;justify-content:center}'
                + '.arw svg{width:100%;height:100%}'
                // QR chốt sát mép phải, to hơn
                + '.qr{position:absolute;right:2mm;top:50%;transform:translateY(-50%);width:50mm;height:50mm}'
                + '.qr img{width:100%;height:100%;image-rendering:pixelated;display:block}'
                // chữ nằm giữa khoảng trống giữa mũi tên và QR (không đẩy được 2 đầu)
                + '.pl{position:absolute;left:31mm;right:51mm;top:0;bottom:0;'
                + 'display:flex;align-items:center;justify-content:center;'
                + 'font-weight:900;letter-spacing:-2px;line-height:1;white-space:nowrap;overflow:hidden}'
                + '@page{size:A4;margin:6mm}'
                + '@media print{body{padding:0}.lbl{margin:0 auto 4mm}}'
                + '</style></head><body>' + labels + '</body></html>';

            // In qua iframe ẩn — KHÔNG mở tab mới, bấm In là ra hộp thoại in mặc định.
            let ifr = document.getElementById('tlm-print-frame');
            if (ifr) ifr.remove();
            ifr = document.createElement('iframe');
            ifr.id = 'tlm-print-frame';
            ifr.style.cssText = 'position:fixed;right:0;bottom:0;width:0;height:0;border:0;visibility:hidden';
            document.body.appendChild(ifr);
            const doc = ifr.contentWindow.document;
            doc.open(); doc.write(html); doc.close();
            // đợi ảnh QR render xong rồi mở hộp thoại in
            setTimeout(() => {
                try { ifr.contentWindow.focus(); ifr.contentWindow.print(); }
                catch (e) { console.error('[TempLocMap] print error:', e); toast('Không in được: ' + e.message); }
                setTimeout(() => { ifr.remove(); }, 1500);
            }, 350);
        }

        function toast(msg) { try { dotNetRef.invokeMethodAsync('OnToast', msg); } catch (e) { } }

        // ============ Realtime polling (màn hình chiếu) ============
        // Fetch endpoint CÙNG ORIGIN mỗi chu kỳ. An toàn cho mạng xưởng:
        //  - map cũ LUÔN giữ tới khi có data mới hợp lệ (không bao giờ trắng trang)
        //  - cờ chống gọi chồng; timeout mỗi lần; chỉ vẽ lại khi data thật sự đổi
        //  - tạm dừng khi đang ở tab Chỉnh sửa (tránh đè lúc user đang sửa)
        const POLL_MS = 30000;      // 30s
        const POLL_TIMEOUT = 30000;  // 30s/lần, tránh treo vô hạn
        let _polling = false, _lastSig = null, _pollTimer = null, _staleCount = 0;

        function layoutSignature(cells) {
            // chuỗi rút gọn chỉ gồm thứ ảnh hưởng hiển thị -> so sánh phát hiện đổi.
            try {
                return (cells || []).map(c => c.id + ':' + c.status + ':' + (c.isUrgent ? 1 : 0)
                    + ':' + (Array.isArray(c.lots) ? c.lots.length : 0)
                    + ':' + (c.lots || []).map(l => l.lotNo + '|' + (l.mappedStatus || '') + '|' + (l.models || '')
                                                 + '|' + (l.disposition || '')).join('~')
                ).join(';');
            } catch (e) { return Math.random().toString(); }
        }

        function setConnDot(fresh) {
            const d = $('[data-role=conndot]'); if (!d) return;
            d.classList.toggle('fresh', !!fresh);
            d.classList.toggle('stale', !fresh);
            d.title = fresh ? m2('TempLoc.Rt.Fresh') : m2('TempLoc.Rt.Stale');
        }

        function applyLayout(newLayout) {
            // Chỉ áp khi data hợp lệ. Giữ nguyên map cũ nếu rỗng/hỏng.
            if (!newLayout || !Array.isArray(newLayout.cells)) return false;
            // Cập nhật thống kê để panel trái luôn có số liệu mới nhất.
            if (newLayout.summary) opts.summary = newLayout.summary;
            const sig = layoutSignature(newLayout.cells);
            if (sig === _lastSig) return false;   // không đổi -> không vẽ lại (tránh nháy)
            _lastSig = sig;
            // cập nhật model.cells (giữ nguyên cols/rows/cellMeters)
            model.cells = newLayout.cells.map(c => ({
                id: c.id ?? uid(), code: c.code, type: c.cellType || 'pallet',
                x: c.gridX, y: c.gridY, w: c.gridW, h: c.gridH,
                arrow: c.arrow, color: c.color, label: c.label,
                status: c.status || 'empty', model: c.model, lotNo: c.lotNo, sortOrder: c.sortOrder || 0,
                lots: c.lots || [], isUrgent: !!c.isUrgent
            }));
            // chỉ vẽ lại nếu đang ở Vận hành (không phá thao tác sửa)
            if (mode === 'view') {
                renderGrid(); renderMapHeader(); renderStats(); renderNewLots();
                if (_hlModel) highlightByModel($('[data-role=modelsearch]')?.value || '');
            }
            return true;
        }

        async function pollOnce() {
            if (_polling) return;               // đang gọi -> bỏ qua, không chồng
            if (mode === 'edit') return;          // đang sửa layout -> không refresh
            _polling = true;
            const ctrl = new AbortController();
            const to = setTimeout(() => ctrl.abort(), POLL_TIMEOUT);
            try {
                const url = '/temploc/refresh?area=' + encodeURIComponent(model.areaCode || '');
                const res = await fetch(url, { signal: ctrl.signal, credentials: 'same-origin', headers: { 'Accept': 'application/json' } });
                if (!res.ok) throw new Error('HTTP ' + res.status);
                const data = await res.json();
                applyLayout(data);
                _staleCount = 0; setConnDot(true);      // lấy được data mới -> tươi
            } catch (e) {
                // lỗi/timeout/mạng: GIỮ map cũ, đánh dấu cũ nếu lặp lại
                _staleCount++; if (_staleCount >= 1) setConnDot(false);
                console.warn('[TempLocMap] refresh bỏ qua kỳ này:', e.message);
            } finally {
                clearTimeout(to); _polling = false;
            }
        }

        function startPolling() {
            stopPolling();
            _pollTimer = setInterval(pollOnce, POLL_MS);
        }
        function stopPolling() { if (_pollTimer) { clearInterval(_pollTimer); _pollTimer = null; } }

        // boot — mở ở 100% cho pallet đủ lớn (không auto-fit về mức nhỏ).
        setMode('view'); setTimeout(() => setZoom(1), 50);
        _lastSig = layoutSignature(model.cells);   // mốc so sánh ban đầu
        setConnDot(true);
        startPolling();

        instances.set(container, { destroy() { stopPolling(); window.removeEventListener('keydown', onKey); window.removeEventListener('mousemove', onMove); window.removeEventListener('mouseup', onUp); container.innerHTML = ''; } });
    }

    function destroy(container) { const inst = instances.get(container); if (inst) { inst.destroy(); instances.delete(container); } }

    // ---- shell markup (label lấy từ i18n) ----
    function buildShell(i) {
        const t = (k, f) => tr(i, k, f);
        return `
    <div class="tlm-head">
      <div class="tlm-modetabs">
        <button class="tlm-modetab active" data-mode="view">${t('TempLoc.ModeView')}</button>
        <button class="tlm-modetab" data-mode="edit">${t('TempLoc.ModeEdit')}</button>
      </div>
      <div class="sp"></div>
      <button class="tlm-btn primary tlm-save" style="display:none">${t('TempLoc.Save')}</button>
    </div>
    <div class="tlm-body">
      <aside class="tlm-oppanel">
        <div class="tlm-op-sec tlm-op-mapsel" data-role="mapselwrap" style="display:none">
          <select class="tlm-op-select" data-role="mapsel"></select>
        </div>
        <div class="tlm-op-sec tlm-op-print">
          <button class="tlm-btn tlm-print-btn">${t('TempLoc.PrintQR')}</button>
        </div>
        <div class="tlm-op-sec tlm-op-sum" data-role="sumwrap" style="display:none">
          <span class="tlm-sum-head">${t('MapView.Sum.Title')}</span>
          <div class="tlm-sum-top">
            <span class="tlm-sum-bar"><i data-role="sumbar"></i></span>
            <span class="tlm-sum-pct" data-role="sumpct"></span>
          </div>
          <dl class="tlm-sum-rows">
            <dt><span class="sw occ"></span>${t('MapView.Sum.Occupied')}</dt><dd data-role="sumocc"></dd>
            <dt><span class="sw free"></span>${t('MapView.Sum.Free')}</dt><dd data-role="sumfree"></dd>
            <dt class="tot">${t('MapView.Sum.Total')}</dt><dd class="tot" data-role="sumtot"></dd>
          </dl>
        </div>
        <div class="tlm-op-sec">
          <label class="tlm-op-label">${t('TempLoc.Op.ModelSearch')}</label>
          <input class="tlm-op-search" placeholder="${t('TempLoc.Op.ModelPlaceholder')}" data-role="modelsearch"/>
          <div class="tlm-op-searchhint" data-role="searchhint"></div>
        </div>
        <div class="tlm-op-sec">
          <div class="tlm-op-sectitle">${t('TempLoc.Op.StatusTitle')}</div>
          <div class="tlm-op-stats" data-role="opstats"></div>
        </div>
        <div class="tlm-op-sec tlm-op-newlots">
          <div class="tlm-op-sectitle">${t('TempLoc.Op.NewLotsTitle')}</div>
          <div class="tlm-op-newlist" data-role="newlots"><div class="tlm-op-newtrack" data-role="newtrack"></div></div>
        </div>
      </aside>
      <button class="tlm-collapse-tab left"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M15 18l-6-6 6-6"/></svg></button>
      <aside class="tlm-toolbar hidden">
        <div class="tlm-sec">${t('TempLoc.Tool.Section')}</div>
        <button class="tlm-tool active" data-tool="select"><span class="tx">${t('TempLoc.Tool.Select')}</span></button>
        <button class="tlm-tool" data-tool="erase"><span class="tx">${t('TempLoc.Tool.Erase')}</span></button>
        <div class="tlm-sec">${t('TempLoc.Tool.DrawSection')}</div>
        <button class="tlm-tool" data-tool="pallet"><span class="sw" style="background:var(--st-pass-bg)"></span><span class="tx">${t('TempLoc.Tool.Pallet')}</span></button>
        <button class="tlm-tool" data-tool="zone"><span class="sw" style="background:linear-gradient(135deg,#3F6FB5,#E53935)"></span><span class="tx">${t('TempLoc.Tool.Zone')}</span></button>
        <button class="tlm-tool" data-tool="palletrow"><span class="tx">${t('TempLoc.Tool.PalletRow')}</span></button>
        <div class="tlm-sec">${t('TempLoc.Tool.UtilSection')}</div>
        <button class="tlm-tool" data-tool="renumber" style="color:var(--primary)"><span class="tx">${t('TempLoc.Tool.Renumber')}</span></button>
        <div class="tlm-hint">${t('TempLoc.Tool.Hint')}</div>
      </aside>
      <div class="tlm-canvas">
        <div class="tlm-conn" data-role="conndot"><span class="dot"></span></div>
        <div class="tlm-zoom"><button class="tlm-zoom-out" title="Thu nhỏ">−</button><div class="zv">100%</div><button class="tlm-zoom-in" title="Phóng to">+</button><button class="tlm-zoom-fit" title="Toàn màn hình">⤢</button></div>
        <div class="tlm-stage"><div class="tlm-grid"></div></div>
      </div>
      <button class="tlm-collapse-tab right"><svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2"><path d="M9 18l6-6-6-6"/></svg></button>
      <aside class="tlm-insp">
        <div class="tlm-insp-head"><h3 class="tlm-insp-title">${t('TempLoc.Insp.Title')}</h3><div class="sub tlm-insp-sub">${t('TempLoc.Insp.Hint')}</div></div>
        <div class="tlm-insp-body"><div class="tlm-insp-empty">${t('TempLoc.Insp.Empty')}</div></div>
      </aside>
    </div>`;
    }

    global.swmsTempLocMap = { init, destroy };
    console.log('%c[SWMS temploc] JS BẢN MỚI đã nạp — tab Chỉnh sửa KHÔNG còn Trạng thái hàng/Model', 'color:#0F6CBD;font-weight:bold');
})(window);