import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';

/// Thanh trạng thái máy in + nút "Đổi" — giao diện giống `_PrinterBar` của
/// Part Card, dùng chung cho các màn có in tem.
class PrinterStatusBar extends StatelessWidget {
  const PrinterStatusBar({super.key, required this.device, this.onChange});

  /// Máy in đang chọn (`selectedPrinterProvider`); null = chưa chọn.
  final PrinterDevice? device;
  final VoidCallback? onChange;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final ready = device != null;
    final dot = ready ? swms.success : swms.danger;

    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              color: dot,
              boxShadow: [
                BoxShadow(color: dot.withValues(alpha: .2), spreadRadius: 3),
              ],
            ),
          ),
          const SizedBox(width: AppDimens.md),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  device?.name ?? LocaleKeys.printer_none.tr(),
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.label.copyWith(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: swms.text1,
                  ),
                ),
                Text(
                  device?.macAddress ?? LocaleKeys.printer_pick_hint.tr(),
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ],
            ),
          ),
          const SizedBox(width: AppDimens.sm),
          _SmallOutlinedButton(
            label: LocaleKeys.printer_change.tr(),
            onTap: onChange,
          ),
        ],
      ),
    );
  }
}

class _SmallOutlinedButton extends StatelessWidget {
  const _SmallOutlinedButton({required this.label, this.onTap});

  final String label;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Material(
      color: swms.card2,
      borderRadius: BorderRadius.circular(AppDimens.sm),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.sm),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 5),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppDimens.sm),
            border: Border.all(color: swms.border),
          ),
          child: Text(
            label,
            style: AppTextStyles.caption.copyWith(
              fontWeight: FontWeight.w700,
              color: swms.text2,
            ),
          ),
        ),
      ),
    );
  }
}
