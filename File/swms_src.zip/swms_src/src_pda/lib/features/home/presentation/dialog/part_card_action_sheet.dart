import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/home/domain/scan_result.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';

/// Lựa chọn trên sheet quét tem Part Card ở Home.
enum PartCardScanChoice {
  edit,
  split,
  merge,

  /// Mở màn IN MỚI với form điền sẵn từ tem đã quét — tem gốc không đụng tới.
  clone;

  /// Thao tác trên tem cũ (màn Sửa / Tách / Gộp); `null` = nhân bản.
  PartCardAction? get action => switch (this) {
    edit => PartCardAction.edit,
    split => PartCardAction.split,
    merge => PartCardAction.merge,
    clone => null,
  };
}

/// Quét tem Part Card ở Home → chọn Sửa / Tách / Gộp / Nhân bản.
///
/// [info] do `GET /api/scan/resolve` trả (đọc thẳng `wms.part_cards`). Nút nào
/// bị khoá thì hiện lý do thay cho mô tả. Trả `null` khi đóng sheet.
Future<PartCardScanChoice?> showPartCardActionSheet(
    BuildContext context, {
      required PartCardScanInfo info,
    }) {
  return showModalBottomSheet<PartCardScanChoice>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black54,
    builder: (_) => _PartCardActionSheet(info: info),
  );
}

class _PartCardActionSheet extends StatelessWidget {
  const _PartCardActionSheet({required this.info});

  final PartCardScanInfo info;

  /// Lý do chung chặn thao tác — OQC chặn mọi thứ, khoá tay chặn tách / gộp.
  String? get _blockedReason => info.inOqc
      ? LocaleKeys.part_card_actions_reason_oqc.tr()
      : info.isLocked
      ? LocaleKeys.part_card_actions_reason_locked.tr()
      : null;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final swms = context.swms;
    final blocked = _blockedReason;

    void pick(PartCardScanChoice c) => Navigator.of(context).pop(c);

    return Container(
      decoration: BoxDecoration(
        color: cs.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(
              child: Container(
                width: 36,
                height: 4,
                margin: const EdgeInsets.only(top: 10, bottom: 4),
                decoration: BoxDecoration(
                  color: cs.onSurface.withValues(alpha: 0.12),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),

            // ── Header ────────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppDimens.md,
                AppDimens.sm,
                AppDimens.sm,
                AppDimens.sm,
              ),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: AppColors.primaryTint,
                      borderRadius: BorderRadius.circular(11),
                    ),
                    child: const Icon(
                      Icons.inventory_2,
                      color: AppColors.primary,
                      size: 20,
                    ),
                  ),
                  const SizedBox(width: AppDimens.sm + AppDimens.xs),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          LocaleKeys.part_card_actions_title.tr(),
                          style: AppTextStyles.title.copyWith(
                            color: swms.text1,
                          ),
                        ),
                        const SizedBox(height: 2),
                        Text(
                          LocaleKeys.part_card_actions_sub.tr(
                            namedArgs: {
                              'id': info.cardId,
                              'count': '${info.modelCount}',
                            },
                          ),
                          style: AppTextStyles.code.copyWith(
                            fontSize: 11,
                            color: swms.text3,
                          ),
                        ),
                      ],
                    ),
                  ),
                  IconButton(
                    onPressed: () => Navigator.of(context).pop(),
                    icon: Icon(
                      Icons.close_rounded,
                      size: 18,
                      color: swms.text2,
                    ),
                  ),
                ],
              ),
            ),

            // ── Trạng thái chặn (OQC / khoá) ──────────────────────
            if (blocked != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(
                  AppDimens.md,
                  0,
                  AppDimens.md,
                  AppDimens.sm,
                ),
                child: Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 10,
                    vertical: 8,
                  ),
                  decoration: BoxDecoration(
                    color: swms.dangerBg,
                    borderRadius: BorderRadius.circular(AppDimens.rInput),
                    border: Border.all(
                      color: swms.danger.withValues(alpha: .25),
                    ),
                  ),
                  child: Row(
                    children: [
                      Icon(
                        info.inOqc
                            ? Icons.fact_check_outlined
                            : Icons.lock_outline,
                        size: 14,
                        color: swms.danger,
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          blocked,
                          style: AppTextStyles.caption.copyWith(
                            fontSize: 11,
                            fontWeight: FontWeight.w700,
                            color: swms.danger,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
              ),

            // ── Actions ───────────────────────────────────────────
            Padding(
              padding: const EdgeInsets.fromLTRB(
                AppDimens.md,
                0,
                AppDimens.md,
                AppDimens.md,
              ),
              child: Column(
                spacing: AppDimens.sm,
                children: [
                  _ActionTile(
                    icon: Icons.edit_rounded,
                    tone: AppColors.primary,
                    title: LocaleKeys.part_card_actions_edit.tr(),
                    hint: LocaleKeys.part_card_actions_edit_hint.tr(),
                    onTap: info.canEdit
                        ? () => pick(PartCardScanChoice.edit)
                        : null,
                  ),
                  _ActionTile(
                    icon: Icons.call_split_rounded,
                    tone: const Color(0xFFE65100),
                    title: LocaleKeys.part_card_actions_split.tr(),
                    // Bị chặn vì OQC / khoá thì banner trên đã nói; còn lại là
                    // tem không phải 1 mã, 1 thùng.
                    hint: info.canSplit || blocked != null
                        ? LocaleKeys.part_card_actions_split_hint.tr()
                        : LocaleKeys.part_card_actions_split_disabled.tr(),
                    onTap: info.canSplit
                        ? () => pick(PartCardScanChoice.split)
                        : null,
                  ),
                  _ActionTile(
                    icon: Icons.call_merge_rounded,
                    tone: const Color(0xFF2E7D32),
                    title: LocaleKeys.part_card_actions_merge.tr(),
                    hint: LocaleKeys.part_card_actions_merge_hint.tr(),
                    onTap: info.canMerge
                        ? () => pick(PartCardScanChoice.merge)
                        : null,
                  ),
                  // = in mới với dữ liệu điền sẵn, không đụng tem gốc → luôn cho,
                  // kể cả tem đang khoá / đã vào OQC.
                  _ActionTile(
                    icon: Icons.copy_all_rounded,
                    tone: const Color(0xFF6A1B9A),
                    title: LocaleKeys.part_card_actions_clone.tr(),
                    hint: LocaleKeys.part_card_actions_clone_hint.tr(),
                    onTap: () => pick(PartCardScanChoice.clone),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// 1 lựa chọn — cả ô bấm được (thao tác bằng găng tay).
class _ActionTile extends StatelessWidget {
  const _ActionTile({
    required this.icon,
    required this.tone,
    required this.title,
    required this.hint,
    required this.onTap,
  });

  final IconData icon;
  final Color tone;
  final String title;
  final String hint;

  /// null = khoá.
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Opacity(
      opacity: onTap == null ? .5 : 1,
      child: GestureDetector(
        onTap: onTap,
        child: AppCard(
          padding: const EdgeInsets.all(AppDimens.sm + AppDimens.xs),
          child: Row(
            children: [
              Container(
                width: 36,
                height: 36,
                decoration: BoxDecoration(
                  color: tone.withValues(alpha: .1),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Icon(icon, color: tone, size: 20),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      title,
                      style: AppTextStyles.label.copyWith(color: swms.text1),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      hint,
                      style: AppTextStyles.caption.copyWith(
                        fontSize: 10.5,
                        color: swms.text3,
                      ),
                    ),
                  ],
                ),
              ),
              Icon(Icons.chevron_right_rounded, color: swms.text4),
            ],
          ),
        ),
      ),
    );
  }
}