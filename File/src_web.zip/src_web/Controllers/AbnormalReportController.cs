﻿using System.Security.Claims;
using DocumentFormat.OpenXml.InkML;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class AbnormalReportController : BaseController
    {
        private readonly ApiService _apiService;

        private string GetCurrentSection()
            => User.FindFirstValue(ClaimTypes.GroupSid) ?? string.Empty;

        private string GetCurrentRole()
         => User.FindFirstValue(ClaimTypes.Role) ?? string.Empty;

        public AbnormalReportController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] AbnormalReportFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max"
                    ? Constants.PageMaximum
                    : int.Parse(pageSize ?? Constants.PageLimit.ToString());

                filter ??= new AbnormalReportFilter();
                filter.VendorCodes = filter.NormalizedVendorCodes;
                filter.PageNumber = pageNumber;
                filter.PageSize = _pageSize;

                var responseData = await _apiService.GetAllAbnormalReport(filter);
                var total = responseData?.TotalRecord ?? 0;
                var items = responseData?.Records ?? new List<AbnormalReport>();

                var section = GetCurrentSection();

                var model = new AbnormalReportViewModel
                {
                    Items = items,
                    Filter = filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                    UserSection = section,
                };
                return View("Views/AbnormalReport/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        /// <summary>Mở modal tạo mới</summary>
        [HttpGet]
        public IActionResult CreateNGReport()
        {
            return PartialView("~/Views/AbnormalReport/_CreateViewModal.cshtml", new AbnormalReport());
        }

        /// <summary>Mở modal edit</summary>
        [HttpGet]
        public async Task<IActionResult> EditNGReport(Guid id)
        {
            try
            {
                var report = await _apiService.GetAbnormalReportById(id);
                var images = await _apiService.GetReportImages(report.Id);
                report.ImageViews = images;
                return PartialView("~/Views/AbnormalReport/_CreateViewModal.cshtml", report ?? new AbnormalReport());
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        /// <summary>Submit create</summary>
        [HttpPost]
        public async Task<IActionResult> ConfirmCreateAbnormalReport(AbnormalReportRequestVM request)
        {
            if (!ModelState.IsValid)
                return BadRequest(string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));

            if (!request.ProblemTypeA && !request.ProblemTypeB && !request.ProblemTypeC)
                return BadRequest(_loc.Get("Msg_PleaseSelectProblemType"));

            try
            {
                request.DiscoveryDate = request.DiscoveryDate == default ? DateTime.Now : request.DiscoveryDate;
                request.ReceivingDate = request.ReceivingDate == default ? DateTime.Now : request.ReceivingDate;
                var result = await _apiService.CreateUpdateAbnormalReport(request);

                // Upload ảnh sau khi tạo report thành công
                if (result?.ReportId != null && request.Images?.Any() == true)
                    await UploadImages(result.ReportId.Value, request.Images);

                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        /// <summary>Submit update</summary>
        [HttpPost]
        public async Task<IActionResult> UpdateAbnormalReport(AbnormalReportRequestVM request)
        {
            if (!ModelState.IsValid)
                return BadRequest(string.Join(" | ", ModelState.Values
                    .SelectMany(v => v.Errors).Select(e => e.ErrorMessage)));

            if (!request.ProblemTypeA && !request.ProblemTypeB && !request.ProblemTypeC)
                return BadRequest(_loc.Get("Msg_PleaseSelectProblemType"));

            try
            {
                await _apiService.CreateUpdateAbnormalReport(request);

                // Upload ảnh mới nếu có (ảnh cũ giữ nguyên)
                if (request.Id.HasValue && request.Images?.Any() == true)
                    await UploadImages(request.Id.Value, request.Images);

                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        /// <summary>Soft delete</summary>
        [HttpPost]
        public async Task<IActionResult> DeleteAbnormalReport(Guid id)
        {
            try
            {
                await _apiService.DeleteAbnormalReport(id);
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        /// <summary>MCS gửi report đi → ReportStatus 0 → 1</summary>
        [HttpPost]
        public async Task<IActionResult> SendToIQCPUS(Guid id)
        {
            try
            {
                await _apiService.SendToIQCPUS(id);
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        #region IQC Confirm

        [HttpGet]
        public async Task<IActionResult> OpenIQCConfirm(Guid id)
        {
            try
            {
                var report = await _apiService.GetAbnormalReportById(id);
                var images = await _apiService.GetReportImages(report.Id);
                report.ImageViews = images;
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                return PartialView("~/Views/AbnormalReport/_ConfirmIQCModal.cshtml", report);
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmIQC(AbnormalReport request)
        {
            if (request.IQCResult == null || (request.IQCResult != 1 && request.IQCResult != 2))
                return BadRequest(_loc.Get("Msg_PleaseSelectOkOrNg"));

            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound")); 
                if (!string.IsNullOrWhiteSpace(report.IQCApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportApprovedCannotEdit"));

                await _apiService.ConfirmIQCAbnormalReport(new IQCConfirmRequestVM
                {
                    ReportId = request.Id,
                    IQCResult = request.IQCResult.Value,
                    IQCNote = request.IQCNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> ApproveIQC(AbnormalReport request)
        {
            if (GetCurrentRole() != "Leader")
                return BadRequest(_loc.Get("Msg_NoApprovePermission"));

            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                if (!report.IQCResult.HasValue)
                    return BadRequest(_loc.Get("Msg_IqcNotConfirmedCannotApprove"));
                if (!string.IsNullOrWhiteSpace(report.IQCApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportAlreadyApproved"));

                await _apiService.ApproveIQCAbnormalReport(new ApproveRequestVM
                {
                    ReportId = request.Id,
                    LeaderNote = request.IQCLeaderNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> RequestUpdateIQC(AbnormalReport request)
        {
            if (GetCurrentRole() != "Leader")
                return BadRequest(_loc.Get("Msg_NoRequestUpdatePermission"));

            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                if (!report.IQCResult.HasValue)
                    return BadRequest(_loc.Get("Msg_IqcNotConfirmedNothingToUpdate"));
                if (!string.IsNullOrWhiteSpace(report.IQCApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportApprovedCannotRequestUpdate"));

                // Không cho yêu cầu cập nhật IQC nếu PUS đã xác nhận (đảo ngược thứ tự quy trình)
                if (report.PUSAction.HasValue)
                    return BadRequest(_loc.Get("Msg_PusConfirmedBasedOnIqc"));

                await _apiService.RequestUpdateIQCAbnormalReport(new RequestUpdateVM
                {
                    ReportId = request.Id,
                    LeaderNote = request.IQCLeaderNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }


        #endregion

        #region PUS Confirm

        [HttpGet]
        public async Task<IActionResult> OpenPUSConfirm(Guid id)
        {
            try
            {
                var report = await _apiService.GetAbnormalReportById(id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                var images = await _apiService.GetReportImages(report.Id);
                report.ImageViews = images;
                return PartialView("~/Views/AbnormalReport/_ConfirmPUSModal.cshtml", report);
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmPUS(AbnormalReport request)
        {
            if (request.PUSAction == null || (request.PUSAction != 1 && request.PUSAction != 2))
                return BadRequest(_loc.Get("Msg_PleaseSelectReportOrMms"));

            try
            {
                // Server-side check: IQC phải xác nhận trước
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                if (string.IsNullOrWhiteSpace(report.IQCConfirmedBy) && report.RequiresIQC)
                    return BadRequest(_loc.Get("Msg_IqcNotConfirmedCannotCountermeasure"));
                if (!string.IsNullOrWhiteSpace(report.PUSApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportApprovedCannotEdit"));

                await _apiService.ConfirmPUSAbnormalReport(new PUSConfirmRequestVM
                {
                    ReportId = request.Id,
                    PUSAction = request.PUSAction.Value,
                    PUSNote = request.PUSNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> ApprovePUS(AbnormalReport request)
        {
            if (GetCurrentRole() != "Leader")
                return BadRequest(_loc.Get("Msg_NoApprovePermission"));

            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                if (!report.PUSAction.HasValue)
                    return BadRequest(_loc.Get("Msg_PusNotConfirmedCannotApprove"));
                if (!string.IsNullOrWhiteSpace(report.PUSApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportAlreadyApproved"));

                await _apiService.ApprovePUSAbnormalReport(new ApproveRequestVM
                {
                    ReportId = request.Id,
                    LeaderNote = request.PUSLeaderNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> RequestUpdatePUS(AbnormalReport request)
        {
            if (GetCurrentRole() != "Leader")
                return BadRequest(_loc.Get("Msg_NoRequestUpdatePermission"));

            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                if (!report.PUSAction.HasValue)
                    return BadRequest(_loc.Get("Msg_PusNotConfirmedNothingToUpdate"));
                if (!string.IsNullOrWhiteSpace(report.PUSApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportApprovedCannotRequestUpdate"));

                await _apiService.RequestUpdatePUSAbnormalReport(new RequestUpdateVM
                {
                    ReportId = request.Id,
                    LeaderNote = request.PUSLeaderNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        #endregion

        #region MCS Confirm

        [HttpGet]
        public async Task<IActionResult> OpenMCSConfirm(Guid id)
        {
            try
            {
                var report = await _apiService.GetAbnormalReportById(id);
                var images = await _apiService.GetReportImages(report.Id);
                report.ImageViews = images;
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                return PartialView("~/Views/AbnormalReport/_ConfirmMCSModal.cshtml", report);
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmMCS(AbnormalReport request)
        {
            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));

                if (!string.IsNullOrWhiteSpace(report.MCSApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportApprovedCannotEdit"));

                await _apiService.ConfirmMCSAbnormalReport(new MCSConfirmRequestVM
                {
                    ReportId = request.Id,
                    MCSNote = request.MCSNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> ApproveMCS(AbnormalReport request)
        {
            if (GetCurrentRole() != "Leader")
                return BadRequest(_loc.Get("Msg_NoApprovePermission"));

            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                if (string.IsNullOrWhiteSpace(report.MCSConfirmedBy))
                    return BadRequest(_loc.Get("Msg_McsNotConfirmedCannotApprove"));
                if (!string.IsNullOrWhiteSpace(report.MCSApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportAlreadyApproved"));

                await _apiService.ApproveMCSAbnormalReport(new ApproveRequestVM
                {
                    ReportId = request.Id,
                    LeaderNote = request.MCSLeaderNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        [HttpPost]
        public async Task<IActionResult> RequestUpdateMCS(AbnormalReport request)
        {
            if (GetCurrentRole() != "Leader")
                return BadRequest(_loc.Get("Msg_NoRequestUpdatePermission"));

            try
            {
                var report = await _apiService.GetAbnormalReportById(request.Id);
                if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
                if (string.IsNullOrWhiteSpace(report.MCSConfirmedBy))
                    return BadRequest(_loc.Get("Msg_McsNotConfirmedNothingToUpdate"));
                if (!string.IsNullOrWhiteSpace(report.MCSApprovedBy))
                    return BadRequest(_loc.Get("Msg_ReportApprovedCannotRequestUpdate"));

                await _apiService.RequestUpdateMCSAbnormalReport(new RequestUpdateVM
                {
                    ReportId = request.Id,
                    LeaderNote = request.MCSLeaderNote
                });
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        #endregion

        [HttpGet]
        public async Task<IActionResult> ViewReportDetail(Guid id)
        {
            var report = await _apiService.GetAbnormalReportById(id);
            var images = await _apiService.GetReportImages(report.Id);
            report.ImageViews = images;
            if (report == null) return BadRequest(_loc.Get("Msg_ReportNotFound"));
            return PartialView("~/Views/AbnormalReport/_ReportDetailModal.cshtml", report);
        }

        /// <summary>
        /// Helper: convert IFormFile → UploadImageRequest (Base64)
        /// </summary>
        private static async Task<AbnormalReportImageUploadRequest> BuildUploadRequest(
            Guid reportId, IFormFile file, string? comment)
        {
            byte[] fileBytes;
            using (var ms = new MemoryStream())
            {
                await file.CopyToAsync(ms);
                fileBytes = ms.ToArray();
            }

            return new AbnormalReportImageUploadRequest
            {
                ReportId = reportId,
                FileData = Convert.ToBase64String(fileBytes),
                FileName = file.FileName,
                MimeType = file.ContentType ?? "image/jpeg",
                Comment = comment ?? string.Empty
            };
        }

        /// <summary>
        /// Helper: upload nhiều ảnh tuần tự, bỏ qua ảnh lỗi (không throw)
        /// </summary>
        private async Task UploadImages(Guid reportId, List<ImageUploadItem> images)
        {
            foreach (var img in images)
            {
                if (img.File == null || img.File.Length == 0) continue;
                try
                {
                    var request = await BuildUploadRequest(reportId, img.File, img.Comment);
                    await _apiService.UploadReportImage(request);
                }
                catch (Exception ex)
                {
                }
            }
        }

        /// <summary>Xóa ảnh</summary>
        [HttpDelete]
        public async Task<IActionResult> DeleteReportImage(Guid imageId)
        {
            try
            {
                await _apiService.DeleteReportImage(imageId);
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        /// <summary>Mở dialog config email</summary>
        [HttpGet]
        public async Task<IActionResult> OpenEmailConfig()
        {
            try
            {
                var config = await _apiService.GetAbnormalReportEmailConfig();
                var model = new AbnormalReportEmailConfig
                {
                    MCSEmails = config?.MCS ?? new List<string>(),
                    IQCEmails = config?.IQC ?? new List<string>(),
                    PUSLocalEmails = config?.PUSLocal ?? new List<string>(),
                    PUSOverseaEmails = config?.PUSOversea ?? new List<string>(),
                    MCSLeaderEmails = config?.MCSLeader ?? new List<string>(),
                    IQCLeaderEmails = config?.IQCLeader ?? new List<string>(),
                    PUSLeaderLocalEmails = config?.PUSLeaderLocal ?? new List<string>(),
                    PUSLeaderOverseaEmails = config?.PUSLeaderOversea ?? new List<string>()
                };
                return PartialView("~/Views/AbnormalReport/_EmailConfigModal.cshtml", model);
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }

        /// <summary>Lưu config email</summary>
        [HttpPost]
        public async Task<IActionResult> SaveAbnormalReportEmailConfig([FromBody] AbnormalReportEmailConfigRequest request)
        {
            try
            {
                await _apiService.SaveAbnormalReportEmailConfig(request);
                return Json(new { success = true });
            }
            catch (Exception e) { return BadRequest(e.Message); }
        }
    }
}