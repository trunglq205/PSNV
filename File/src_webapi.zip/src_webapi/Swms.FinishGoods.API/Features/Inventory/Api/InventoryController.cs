using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Inventory.Business;

namespace Swms.FinishGoods.API.Features.Inventory.Api
{
    [ApiController]
    [Route("api/inventory")]
    public class InventoryController : ControllerBase
    {
        private readonly IInventoryService _service;
        public InventoryController(IInventoryService service) => _service = service;

        /// <summary>Danh sách lot đang tồn (filter + phân trang). Không kèm Boxes — chi tiết qua GET /api/pallets/{id}.</summary>
        [HttpGet]
        [RequirePermission<Perms.Storage.Inventory.View>]
        public async Task<ActionResult<PagedResult<InventoryItemResponse>>> GetAll([FromQuery] InventoryQuery query)
            => Ok(await _service.GetPagedAsync(query));

        /// <summary>Thống kê 5 khu vực theo cùng filter (bỏ qua area).</summary>
        [HttpGet("areas")]
        [RequirePermission<Perms.Storage.Inventory.View>]
        public async Task<ActionResult<IReadOnlyList<InventoryAreaStatResponse>>> GetAreas([FromQuery] InventoryQuery query)
            => Ok(await _service.GetAreaStatsAsync(query));

        /// <summary>Phân bố tuổi tồn theo bucket (Aging / FIFO).</summary>
        [HttpGet("aging")]
        [RequirePermission<Perms.Storage.Inventory.View>]
        public async Task<ActionResult<IReadOnlyList<InventoryAgingBucketResponse>>> GetAging([FromQuery] InventoryQuery query)
            => Ok(await _service.GetAgingAsync(query));
    }
}
