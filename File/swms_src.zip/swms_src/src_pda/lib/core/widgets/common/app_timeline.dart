import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Sắc thái màu của một mốc trên [AppTimeline].
///
/// Khai ngay tại đây vì codebase KHÔNG có enum tone dùng chung: `StatusPill`
/// nhận thẳng `background` / `foreground` qua factory constructor chứ không
/// qua enum. Nếu sau này tách được một enum tone chung cho cả design system thì
/// thay vào, chỗ sửa chỉ nằm trong file này và các wrapper.
enum AppTimelineTone {
  success,
  warning,
  danger,
  info,

  /// Mốc thường — không tô màu. Phần lớn timeline rơi vào đây.
  neutral;

  /// Màu chấm. Lấy từ token qua `context.swms`, không hardcode.
  Color color(BuildContext context) {
    final swms = context.swms;
    return switch (this) {
      AppTimelineTone.success => swms.success,
      AppTimelineTone.warning => swms.warning,
      AppTimelineTone.danger => swms.danger,
      AppTimelineTone.info => swms.primary,
    // border2 chứ không phải border: border quá nhạt, chấm sẽ chìm vào nền thẻ.
      AppTimelineTone.neutral => swms.border2,
    };
  }
}

/// Một mốc trên [AppTimeline].
///
/// Cố tình chỉ nhận CHUỖI ĐÃ FORMAT, không nhận entity: timeline dùng chung cho
/// lịch sử pallet, lịch sử thùng, và sau này là bất kỳ dòng thời gian nào —
/// widget không được biết gì về nghiệp vụ của chúng.
class AppTimelineItem {
  /// Dòng chính. Vd "Lưu kho".
  final String title;

  /// Bổ nghĩa cho [title], in cùng dòng, kiểu mono. Vd mã vị trí "A-03-02-01".
  final String? code;

  /// Dòng mô tả dưới tiêu đề. Vd "Số thùng: 12 → 8".
  final String? description;

  /// Dòng chân: thời gian · người thực hiện. Widget không tự format.
  final String meta;

  /// Màu chấm. [AppTimelineTone.neutral] = mốc thường.
  final AppTimelineTone tone;

  /// Mốc mờ — dùng cho event KẾ THỪA ở màn lịch sử thùng: thao tác xảy ra trên
  /// pallet chứa thùng, không phải trên chính thùng đó. Chấm nhỏ hơn và chữ
  /// nhạt hơn để phân biệt, nếu không người dùng tưởng có ai quét riêng từng
  /// thùng.
  final bool muted;

  const AppTimelineItem({
    required this.title,
    required this.meta,
    this.code,
    this.description,
    this.tone = AppTimelineTone.neutral,
    this.muted = false,
  });
}

/// Timeline dọc: chấm + đường nối, mốc mới nhất ở trên.
///
/// Dùng chung cho lịch sử pallet và lịch sử thùng. KHÔNG bọc sẵn `AppCard` và
/// không tự xử lý trạng thái rỗng — mỗi màn có tiêu đề, nút và câu "chưa có dữ
/// liệu" riêng, nên phần đó để caller quyết.
///
/// Mốc đầu tiên được nhấn bằng quầng màu: đó là trạng thái HIỆN TẠI, thứ người
/// dùng tìm trước nhất khi mở lịch sử.
class AppTimeline extends StatelessWidget {
  final List<AppTimelineItem> items;

  /// Nhấn mốc đầu bằng quầng. Tắt khi timeline nằm giữa một danh sách dài hơn
  /// và mốc đầu không mang nghĩa "hiện tại".
  final bool emphasizeFirst;

  const AppTimeline({
    super.key,
    required this.items,
    this.emphasizeFirst = true,
  });

  @override
  Widget build(BuildContext context) {
    if (items.isEmpty) return const SizedBox.shrink();

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        for (int i = 0; i < items.length; i++)
          _TimelineRow(
            item: items[i],
            isLast: i == items.length - 1,
            emphasize: emphasizeFirst && i == 0,
          ),
      ],
    );
  }
}

class _TimelineRow extends StatelessWidget {
  final AppTimelineItem item;
  final bool isLast;
  final bool emphasize;

  const _TimelineRow({
    required this.item,
    required this.isLast,
    required this.emphasize,
  });

  /// Bề ngang cột chấm. Cố định để mọi dòng thẳng hàng bất kể chấm to nhỏ.
  static const double _railWidth = 16;

  /// Đường kính chấm thường.
  static const double _dotSize = 9;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final color = item.tone.color(context);

    final size = item.muted ? 7.0 : (emphasize ? 12.0 : _dotSize);
    final titleColor = item.muted ? swms.text2 : swms.text1;

    return IntrinsicHeight(
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: _railWidth,
            child: Column(
              children: [
                // Canh tâm chấm ngang với chữ hoa của dòng tiêu đề, bất kể cỡ chấm.
                Container(
                  width: size,
                  height: size,
                  margin: EdgeInsets.only(top: 6 - (size - _dotSize) / 2),
                  decoration: BoxDecoration(
                    color: color,
                    shape: BoxShape.circle,
                    // Quầng chỉ ở mốc hiện tại, và chỉ khi có màu thật —
                    // quầng xám quanh chấm xám nhìn như vết bẩn.
                    boxShadow: emphasize && item.tone != AppTimelineTone.neutral
                        ? [
                      BoxShadow(
                        color: color.withValues(alpha: 0.20),
                        spreadRadius: 3,
                      ),
                    ]
                        : null,
                  ),
                ),
                if (!isLast)
                  Expanded(
                    child: Container(
                      width: 1.5,
                      margin: const EdgeInsets.only(top: 4),
                      color: swms.border,
                    ),
                  ),
              ],
            ),
          ),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Padding(
              padding: EdgeInsets.only(bottom: isLast ? 0 : AppDimens.md),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Tiêu đề + mã vị trí trên cùng một dòng, tự xuống dòng khi dài.
                  Wrap(
                    spacing: AppDimens.xs + 2,
                    crossAxisAlignment: WrapCrossAlignment.center,
                    children: [
                      Text(
                        item.title,
                        style: AppTextStyles.bodyStrong.copyWith(
                          color: titleColor,
                        ),
                      ),
                      if (item.code != null && item.code!.isNotEmpty)
                        Text(item.code!, style: AppTextStyles.code),
                    ],
                  ),
                  if (item.description != null &&
                      item.description!.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      item.description!,
                      style: AppTextStyles.body.copyWith(color: swms.text2),
                    ),
                  ],
                  const SizedBox(height: 2),
                  Text(
                    item.meta,
                    style: AppTextStyles.caption.copyWith(color: swms.text3),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}