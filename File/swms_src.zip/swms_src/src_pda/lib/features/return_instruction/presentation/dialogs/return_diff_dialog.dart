import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2b — bảng đối chiếu chỉ thị vs thực nhận, xem trước khi chốt.
//
//  Bấm chốt là server gửi mail cho FA ngay, mà nội dung mail chính là bảng
//  này. Nên nó phải hiện TRƯỚC khi bấm, không phải sau.
// ─────────────────────────────────────────────────────────────

/// Mở bảng lệch. Trả `true` nếu người dùng xác nhận chốt.
Future<bool> showReturnDiffDialog(
  BuildContext context, {
  required ReturnInstruction doc,
}) async {
  final ok = await showDialog<bool>(
    context: context,
    builder: (_) => _ReturnDiffDialog(doc: doc),
  );
  return ok ?? false;
}

class _ReturnDiffDialog extends StatelessWidget {
  const _ReturnDiffDialog({required this.doc});

  final ReturnInstruction doc;

  @override
  Widget build(BuildContext context) {
    return AppDialog(
      title: LocaleKeys.return_receive_close_title.tr(),
      subtitle: doc.docNo,
      align: AppDialogAlign.start,
      headerTone: AppDialogHeaderTone.muted,
      dividers: true,
      scrollable: true,
      // Phiếu nhiều model thì bảng dài — giới hạn chiều cao để hai nút ở đáy
      // không bị đẩy ra khỏi màn PDA.
      maxBodyHeight: 340,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _DiffHeaderRow(),
          const Divider(height: 10),
          for (final l in doc.lines) _DiffRow(line: l),
          const Divider(height: 10),
          _TotalRow(doc: doc),
          const SizedBox(height: AppDimens.sm),
          Text(
            LocaleKeys.return_receive_close_mail_note.tr(),
            style: AppTextStyles.caption.copyWith(color: context.swms.text3),
          ),
        ],
      ),
      actions: [
        AppDialogAction.cancel(context, result: false),
        AppDialogAction(
          label: LocaleKeys.return_receive_close_confirm.tr(),
          icon: Icons.mark_email_read_outlined,
          onPressed: () => Navigator.pop(context, true),
        ),
      ],
    );
  }
}

class _DiffHeaderRow extends StatelessWidget {
  const _DiffHeaderRow();

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final st = AppTextStyles.caption.copyWith(
      fontSize: 10.5,
      fontWeight: FontWeight.w700,
      color: c.text3,
    );

    return Row(
      children: [
        Expanded(child: Text(LocaleKeys.return_receive_col_model.tr(), style: st)),
        SizedBox(width: 42, child: Text(LocaleKeys.return_receive_col_plan.tr(),
            textAlign: TextAlign.right, style: st)),
        SizedBox(width: 46, child: Text(LocaleKeys.return_receive_col_actual.tr(),
            textAlign: TextAlign.right, style: st)),
        SizedBox(width: 46, child: Text(LocaleKeys.return_receive_col_diff.tr(),
            textAlign: TextAlign.right, style: st)),
      ],
    );
  }
}

class _DiffRow extends StatelessWidget {
  const _DiffRow({required this.line});

  final ReturnInstructionLine line;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    // Ba trạng thái ba màu: đủ (xanh) · thiếu (đỏ) · vượt (cam). Một cột số âm
    // mà cùng màu thì người đọc nhanh dễ bỏ qua dấu trừ.
    final diffColor = line.diffQty == 0
        ? c.success
        : line.diffQty < 0
            ? c.danger
            : c.warning;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3),
      child: Row(
        children: [
          Expanded(
            child: Text(
              line.model,
              style: AppTextStyles.code.copyWith(fontSize: 12, color: c.text1),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          SizedBox(
            width: 42,
            child: Text('${line.qty}',
                textAlign: TextAlign.right,
                style: AppTextStyles.label.copyWith(color: c.text2)),
          ),
          SizedBox(
            width: 46,
            child: Text('${line.receivedQty}',
                textAlign: TextAlign.right,
                style: AppTextStyles.label.copyWith(
                  fontWeight: FontWeight.w700,
                  color: c.text1,
                )),
          ),
          SizedBox(
            width: 46,
            child: Text(
              signedQty(line.diffQty),
              textAlign: TextAlign.right,
              style: AppTextStyles.label.copyWith(
                fontWeight: FontWeight.w700,
                color: diffColor,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _TotalRow extends StatelessWidget {
  const _TotalRow({required this.doc});

  final ReturnInstruction doc;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final diffColor = doc.diffQty == 0
        ? c.success
        : doc.diffQty < 0
            ? c.danger
            : c.warning;

    return Row(
      children: [
        Expanded(
          child: Text(
            LocaleKeys.return_receive_total.tr(),
            style: AppTextStyles.label.copyWith(
              fontWeight: FontWeight.w700,
              color: c.text2,
            ),
          ),
        ),
        SizedBox(
          width: 42,
          child: Text('${doc.totalQty}',
              textAlign: TextAlign.right,
              style: AppTextStyles.label
                  .copyWith(fontWeight: FontWeight.w700, color: c.text2)),
        ),
        SizedBox(
          width: 46,
          child: Text('${doc.receivedQty}',
              textAlign: TextAlign.right,
              style: AppTextStyles.label
                  .copyWith(fontWeight: FontWeight.w700, color: c.text1)),
        ),
        SizedBox(
          width: 46,
          child: Text(
            signedQty(doc.diffQty),
            textAlign: TextAlign.right,
            style: AppTextStyles.label
                .copyWith(fontWeight: FontWeight.w800, color: diffColor),
          ),
        ),
      ],
    );
  }
}

/// Số lệch kèm dấu: `+6` / `-6` / `0`. Dấu cộng tường minh vì "6" và "+6" đọc
/// khác nhau hẳn trong một bảng có cả số âm.
String signedQty(int qty) => qty > 0 ? '+$qty' : '$qty';
