import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

class LoginStatusRow extends StatefulWidget {
  const LoginStatusRow({super.key, required this.scanning});

  final bool scanning;

  @override
  State<LoginStatusRow> createState() => _LoginStatusRowState();
}

class _LoginStatusRowState extends State<LoginStatusRow>
    with SingleTickerProviderStateMixin {
  late final AnimationController _pulse;

  @override
  void initState() {
    super.initState();
    _pulse = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 900),
    )..repeat(reverse: true);
  }

  @override
  void dispose() {
    _pulse.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          AnimatedBuilder(
            animation: _pulse,
            builder: (_, _) => Container(
              width: 7,
              height: 7,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                color: widget.scanning
                    ? swms.success
                    : swms.text4.withValues(alpha: 0.4),
                boxShadow: widget.scanning
                    ? [
                        BoxShadow(
                          color: swms.success.withValues(alpha: 0.6),
                          blurRadius: 6,
                        ),
                      ]
                    : null,
              ),
            ),
          ),
          const SizedBox(width: AppDimens.sm),
          Text(
            widget.scanning
                ? LocaleKeys.login_card_processing.tr()
                : LocaleKeys.login_waiting_scanner_signal.tr(),
            style: AppTextStyles.body.copyWith(color: swms.text3),
          ),
        ],
      ),
    );
  }
}
