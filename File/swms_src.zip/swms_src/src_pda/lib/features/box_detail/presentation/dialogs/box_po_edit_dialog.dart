import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_bottom_sheet.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_text_field.dart';

/// Kết quả sửa PO. null = xoá giá trị (khớp semantics PATCH của API).
class BoxPoEditResult {
  final String? customerPo;
  final String? psnvPo;

  const BoxPoEditResult({required this.customerPo, required this.psnvPo});
}

/// Bottom sheet sửa PO.
/// Field vẫn focus để nhận dữ liệu từ máy quét, nhưng KHÔNG bung bàn phím mềm.
/// Có nút bật bàn phím khi cần nhập tay.
Future<BoxPoEditResult?> showBoxPoEditDialog(
  BuildContext context, {
  String? customerPo,
  String? psnvPo,
}) {
  return showAppBottomSheet<BoxPoEditResult>(
    context,
    // Chạm ra ngoài / vuốt xuống là mất nội dung đang gõ -> chỉ cho đóng bằng
    // nút X hoặc Huỷ.
    isDismissible: false,
    enableDrag: false,
    builder: (_) => _BoxPoEditSheet(customerPo: customerPo, psnvPo: psnvPo),
  );
}

class _BoxPoEditSheet extends StatefulWidget {
  final String? customerPo;
  final String? psnvPo;

  const _BoxPoEditSheet({this.customerPo, this.psnvPo});

  @override
  State<_BoxPoEditSheet> createState() => _BoxPoEditSheetState();
}

class _BoxPoEditSheetState extends State<_BoxPoEditSheet> {
  late final TextEditingController _customer = TextEditingController(
    text: widget.customerPo ?? '',
  );
  late final TextEditingController _psnv = TextEditingController(
    text: widget.psnvPo ?? '',
  );

  final _customerFocus = FocusNode();
  final _psnvFocus = FocusNode();

  @override
  void dispose() {
    _customer.dispose();
    _psnv.dispose();
    _customerFocus.dispose();
    _psnvFocus.dispose();
    super.dispose();
  }

  String? _norm(String v) {
    final s = v.trim();
    return s.isEmpty ? null : s;
  }

  void _submit() => Navigator.of(context).pop(
    BoxPoEditResult(
      customerPo: _norm(_customer.text),
      psnvPo: _norm(_psnv.text),
    ),
  );

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppBottomSheet(
      title: LocaleKeys.box_detail_edit_po_title.tr(),
      actions: [
        AppDialogAction.cancel(context),
        AppDialogAction.confirm(onPressed: _submit),
      ],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          AppTextField(
            controller: _customer,
            focusNode: _customerFocus,
            label: LocaleKeys.box_detail_customer_po.tr(),
            // Focus sẵn ô đầu để quét được ngay, không cần chạm.
            autofocus: true,
            clearable: true,
            textInputAction: TextInputAction.next,
            onSubmitted: (_) => _psnvFocus.requestFocus(),
          ),
          const SizedBox(height: AppDimens.md),
          AppTextField(
            controller: _psnv,
            focusNode: _psnvFocus,
            label: LocaleKeys.box_detail_psnv_po.tr(),
            textInputAction: TextInputAction.done,
            clearable: true,
            onSubmitted: (_) => _submit(),
          ),
          const SizedBox(height: AppDimens.sm),
          Text(
            LocaleKeys.box_detail_po_clear_hint.tr(),
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
        ],
      ),
    );
  }
}
