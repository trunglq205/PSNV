import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';

/// Bộ chọn số bằng nhiều dial, mỗi dial 1 chữ số 0–9 (kiểu khoá số).
///
/// So với 1 bánh xe chạy hết dải giá trị: mỗi dial chỉ có 10 nấc nên tối đa
/// 5 nấc là tới chữ số cần chọn, không phụ thuộc độ lớn của số.
///
/// Widget này chỉ lo phần chọn số. Việc kiểm tra min/max và cho phép xác nhận
/// hay không thuộc về nơi gọi — xem [showNumberDialDialog].
///
/// Không kiểm soát từ ngoài (uncontrolled): [initialValue] chỉ đọc 1 lần lúc
/// khởi tạo, sau đó giá trị mới báo ra qua [onChanged].
class NumberDialPicker extends StatefulWidget {
  const NumberDialPicker({
    super.key,
    required this.initialValue,
    required this.onChanged,
    this.decimalDigits = 0,
    this.maxValue,
    this.unit,
    this.separator = '.',
    this.dialWidth = AppDimens.hitMd,
    this.itemExtent = AppDimens.hitMd,
    this.visibleItems = 3,
  }) : assert(decimalDigits >= 0 && decimalDigits <= 3);

  /// Giá trị ban đầu. Giá trị âm được coi là 0.
  final num initialValue;

  /// Báo giá trị mới mỗi khi một dial dừng ở chữ số khác.
  final ValueChanged<num> onChanged;

  /// Số chữ số phần thập phân. 0 = số nguyên.
  final int decimalDigits;

  /// Quyết định số cột phần nguyên. Bỏ trống → tối thiểu 3 cột (999),
  /// tự nới thêm nếu [initialValue] cần nhiều chữ số hơn.
  final num? maxValue;

  /// Đơn vị hiển thị cạnh dial (kg, pcs/box...).
  final String? unit;

  /// Ký tự ngăn cách phần thập phân.
  final String separator;

  /// Bề rộng 1 cột. Mặc định hitMd để vuốt được khi đeo găng.
  final double dialWidth;

  /// Chiều cao 1 nấc.
  final double itemExtent;

  /// Số nấc nhìn thấy — quyết định chiều cao tổng.
  final int visibleItems;

  @override
  State<NumberDialPicker> createState() => _NumberDialPickerState();
}

class _NumberDialPickerState extends State<NumberDialPicker> {
  /// Số cột phần nguyên.
  late final int _wholeDigits;

  /// Chữ số từ trái sang phải, gồm cả phần thập phân.
  late final List<int> _digits;
  late final List<FixedExtentScrollController> _controllers;

  late final int _scale;

  int get _totalDigits => _wholeDigits + widget.decimalDigits;

  @override
  void initState() {
    super.initState();

    _scale = math.pow(10, widget.decimalDigits).toInt();

    final safe = widget.initialValue.isFinite && widget.initialValue > 0
        ? widget.initialValue.toDouble()
        : 0.0;

    final ceiling = (widget.maxValue ?? math.max<num>(safe, 999)).toDouble();
    _wholeDigits = math
        .max(
          ceiling.floor().toString().length,
          safe.floor().toString().length,
        )
        .clamp(1, 7);

    final hardMax = math.pow(10, _totalDigits).toInt() - 1;
    final startMinor = (safe * _scale).round().clamp(0, hardMax);

    _digits = _split(startMinor);
    _controllers = List.generate(
      _digits.length,
      (i) => FixedExtentScrollController(initialItem: _digits[i]),
    );
  }

  @override
  void dispose() {
    for (final c in _controllers) {
      c.dispose();
    }
    super.dispose();
  }

  /// Tách số thành từng chữ số, bù 0 ở đầu cho đủ số cột.
  List<int> _split(int minor) =>
      minor.toString().padLeft(_totalDigits, '0').split('').map(int.parse).toList();

  void _onDigitChanged(int column, int digit) {
    HapticFeedback.selectionClick();
    _digits[column] = digit;

    final minor = _digits.fold<int>(0, (acc, d) => acc * 10 + d);
    // Làm tròn qua chuỗi để tránh sai số dấu phẩy động khi chia cho _scale.
    final value = double.parse(
      (minor / _scale).toStringAsFixed(widget.decimalDigits),
    );
    widget.onChanged(widget.decimalDigits == 0 ? value.round() : value);
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final children = <Widget>[];

    for (var i = 0; i < _digits.length; i++) {
      if (widget.decimalDigits > 0 && i == _wholeDigits) {
        children.add(_separatorWidget(swms));
      }
      children.add(
        _DigitDial(
          controller: _controllers[i],
          isDecimal: i >= _wholeDigits,
          itemExtent: widget.itemExtent,
          width: widget.dialWidth,
          onChanged: (d) => _onDigitChanged(i, d),
        ),
      );
    }

    if (widget.unit != null && widget.unit!.isNotEmpty) {
      children.add(_unitWidget(swms));
    }

    // Căn giữa khi vừa màn hình, cuộn ngang khi nhiều chữ số / màn hình hẹp.
    return SizedBox(
      height: widget.itemExtent * widget.visibleItems,
      child: LayoutBuilder(
        builder: (context, constraints) {
          return SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            physics: const ClampingScrollPhysics(),
            child: ConstrainedBox(
              constraints: BoxConstraints(minWidth: constraints.maxWidth),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.center,
                children: children,
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _separatorWidget(SwmsColors swms) {
    return SizedBox(
      width: AppDimens.sm + AppDimens.xs,
      child: Center(
        child: Text(
          widget.separator,
          style: AppTextStyles.code.copyWith(
            fontSize: 24,
            fontWeight: FontWeight.w900,
            letterSpacing: 0,
            color: swms.text1,
          ),
        ),
      ),
    );
  }

  Widget _unitWidget(SwmsColors swms) {
    return Padding(
      padding: const EdgeInsets.only(left: AppDimens.sm),
      child: ConstrainedBox(
        constraints: const BoxConstraints(maxWidth: 88),
        child: Text(
          widget.unit!,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: AppTextStyles.caption.copyWith(
            fontWeight: FontWeight.w700,
            color: swms.text3,
          ),
        ),
      ),
    );
  }
}

/// Một dial 0–9. Thứ tự 0 trên → 9 dưới (vuốt lên = tăng) theo quy ước iOS.
/// Đảo `_values` nếu muốn cảm giác khoá số vật lý (9 ở trên).
class _DigitDial extends StatefulWidget {
  const _DigitDial({
    required this.controller,
    required this.isDecimal,
    required this.itemExtent,
    required this.width,
    required this.onChanged,
  });

  final FixedExtentScrollController controller;
  final bool isDecimal;
  final double itemExtent;
  final double width;
  final ValueChanged<int> onChanged;

  @override
  State<_DigitDial> createState() => _DigitDialState();
}

class _DigitDialState extends State<_DigitDial> {
  static const List<int> _values = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9];

  /// ValueNotifier thay cho setState: đổi style ô đang chọn mà không
  /// rebuild cả hàng dial mỗi lần cuộn.
  late final ValueNotifier<int> _selected = ValueNotifier<int>(
    widget.controller.initialItem,
  );

  @override
  void dispose() {
    _selected.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return SizedBox(
      width: widget.width,
      child: ListWheelScrollView.useDelegate(
        controller: widget.controller,
        physics: const FixedExtentScrollPhysics(),
        itemExtent: widget.itemExtent,
        diameterRatio: 1.3,
        perspective: 0.006,
        overAndUnderCenterOpacity: 0.55,
        onSelectedItemChanged: (index) {
          if (_selected.value == index) return;
          _selected.value = index;
          widget.onChanged(_values[index]);
        },
        childDelegate: ListWheelChildBuilderDelegate(
          childCount: _values.length,
          builder: (context, index) {
            if (index < 0 || index >= _values.length) return null;

            return ValueListenableBuilder<int>(
              valueListenable: _selected,
              builder: (context, selected, _) {
                final isSelected = index == selected;

                return Container(
                  margin: const EdgeInsets.symmetric(
                    horizontal: 3,
                    vertical: 2,
                  ),
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: isSelected
                        ? (widget.isDecimal ? swms.card2 : swms.primaryTint)
                        : Colors.transparent,
                    border: Border.all(
                      color: isSelected
                          ? (widget.isDecimal
                                ? swms.border2
                                : swms.primaryTint2)
                          : Colors.transparent,
                    ),
                    borderRadius: BorderRadius.circular(AppDimens.rInput),
                  ),
                  child: Text(
                    '${_values[index]}',
                    maxLines: 1,
                    style: AppTextStyles.code.copyWith(
                      fontSize: 24,
                      letterSpacing: 0,
                      fontWeight: isSelected
                          ? FontWeight.w900
                          : FontWeight.w500,
                      color: isSelected ? swms.text1 : swms.text3,
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
