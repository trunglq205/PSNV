using Dapper;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Data;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

/// <summary>Đọc Stowage Plan của chuyến (bảng stowage_* — chỉ đọc) và ghi thực tế ghép cọc / xếp cont
/// (wms.shipment_trip_columns). Đọc cọc đã ghép: ITripVanningRepository.GetStacksAsync.</summary>
public interface ITripStowageRepository
{
    Task<TripPlanRow?> GetPlanAsync(long tripId);
    Task<List<PlanColumnRow>> GetPlanColumnsAsync(long planId, int containerIndex);
    /// <summary>SI của 1 pallet: phân bổ pallet cho SI, thùng trong packing list, hoặc si_no trên pallet.</summary>
    Task<List<long>> GetPalletSiIdsAsync(long palletId);
    Task<(StackSaveResult Result, string? OtherCode)> SaveStackAsync(
        long tripId, string code, long bottomPalletId, long? topPalletId, string? user);
    /// <summary>false = cọc chưa ghép.</summary>
    Task<bool> PlaceAsync(long tripId, string code, string? user);
    /// <summary>Đã xếp -> gỡ xếp (giữ cọc). Chưa xếp -> bỏ cọc đã ghép. false = không có gì để gỡ.</summary>
    Task<bool> ClearAsync(long tripId, string code, string? user);
    /// <summary>Bỏ cọc đã ghép có mã không còn trong plan (văn phòng đổi / bỏ cọc khi lưu lại sơ đồ) —
    /// không thì pallet của chúng bị giữ mãi, ghép lại báo "đã nằm ở cọc khác".</summary>
    Task<int> ClearOrphansAsync(long tripId, IReadOnlyCollection<string> planCodes, string? user);

    // ── Kế hoạch Pallet List (gộp pallet theo pallet soạn của plan) ──
    /// <summary>Pallet soạn của plan (trong container của chuyến, hoặc chưa đặt vị trí) chứa thùng
    /// đang nằm trên pallet thật [palletId]; nhiều thùng nhất đứng đầu.</summary>
    Task<List<PlanPalletMatchRow>> FindPlanPalletsOfAsync(long planId, int containerIndex, long palletId);
    /// <summary>Thùng của 1 pallet soạn theo đúng thứ tự Web lưu + đang nằm trên pallet thật nào.</summary>
    Task<List<PlanPalletBoxRow>> GetPlanPalletBoxesAsync(long stowagePalletId);
    /// <summary>Thùng thật đang nằm trên 1 pallet.</summary>
    Task<List<PalletBoxRow>> GetPalletBoxesAsync(long palletId);
    /// <summary>Pallet soạn của 1 cọc trong plan (tầng 1 / 2).</summary>
    Task<List<PlanPalletMatchRow>> GetColumnPalletsAsync(long planId, string columnCode);
}

public class TripStowageRepository : ITripStowageRepository
{
    private readonly IDbConnectionFactory _factory;
    public TripStowageRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<TripPlanRow?> GetPlanAsync(long tripId)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<TripPlanRow>("""
            SELECT TOP 1 sp.id AS PlanId, sp.plan_no AS PlanNo, sp.status AS Status, sp.ship_mode AS ShipMode,
                   sp.container_type AS ContainerType, c.container_index AS ContainerIndex
            FROM wms.stowage_plan_containers c
            JOIN wms.stowage_plans sp ON sp.id = c.plan_id AND sp.is_deleted = 0
            WHERE c.trip_id = @tripId
            ORDER BY sp.id DESC;
            """, new { tripId });
    }

    public async Task<List<PlanColumnRow>> GetPlanColumnsAsync(long planId, int containerIndex)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<PlanColumnRow>("""
            SELECT c.id AS ColumnId, c.code AS Code, c.row_no AS RowNo, c.lane_no AS LaneNo,
                   ISNULL(p.tier, 0) AS Tier, p.code AS PlanPalletCode, p.si_id AS SiId,
                   si.si_no AS SiNo, p.pallet_size AS PalletSize
            FROM wms.stowage_columns c
            LEFT JOIN wms.stowage_pallets p ON p.column_id = c.id
            LEFT JOIN wms.shipment_instructions si ON si.id = p.si_id
            WHERE c.plan_id = @planId AND c.container_index = @containerIndex
            ORDER BY c.row_no, c.lane_no, c.code, p.tier;
            """, new { planId, containerIndex })).ToList();
    }

    public async Task<List<long>> GetPalletSiIdsAsync(long palletId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<long>("""
            SELECT sl.si_id
            FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines sl ON sl.id = sp.line_id
            WHERE sp.pallet_id = @palletId AND sp.shipment_status <> N'skipped'
            UNION
            SELECT sl.si_id
            FROM wms.boxes b
            JOIN wms.shipment_instruction_boxes sb ON sb.box_id = b.id
            JOIN wms.shipment_instruction_lines sl ON sl.id = sb.line_id
            WHERE b.lot_id = @palletId AND b.is_deleted = 0
            UNION
            SELECT si.id
            FROM wms.pallets p
            JOIN wms.shipment_instructions si ON si.si_no = p.si_no
            WHERE p.id = @palletId;
            """, new { palletId })).ToList();
    }

    /*  UPDLOCK + HOLDLOCK trên các cọc của chuyến: 2 PDA cùng ghép thì máy sau chờ máy trước,
        1 pallet không thể nằm ở 2 cọc. Ghép lại cọc đã ghép (chưa xếp) = thay pallet.            */
    public async Task<(StackSaveResult Result, string? OtherCode)> SaveStackAsync(
        long tripId, string code, long bottomPalletId, long? topPalletId, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var current = await conn.QueryFirstOrDefaultAsync<CurrentColumn>("""
                SELECT id AS Id, placed_at AS PlacedAt FROM wms.shipment_trip_columns WITH (UPDLOCK, HOLDLOCK)
                WHERE trip_id = @tripId AND column_code = @code AND is_deleted = 0;
                """, new { tripId, code }, tx);
            if (current?.PlacedAt is not null)
            {
                tx.Rollback();
                return (StackSaveResult.Placed, null);
            }

            var other = await conn.QueryFirstOrDefaultAsync<string?>("""
                SELECT TOP 1 column_code FROM wms.shipment_trip_columns WITH (UPDLOCK, HOLDLOCK)
                WHERE trip_id = @tripId AND is_deleted = 0 AND column_code <> @code
                  AND (bottom_pallet_id IN (@bottomPalletId, ISNULL(@topPalletId, -1))
                       OR top_pallet_id IN (@bottomPalletId, ISNULL(@topPalletId, -1)));
                """, new { tripId, code, bottomPalletId, topPalletId }, tx);
            if (other is not null)
            {
                tx.Rollback();
                return (StackSaveResult.PalletUsed, other);
            }

            if (current is not null)
            {
                await conn.ExecuteAsync("""
                    UPDATE wms.shipment_trip_columns
                    SET bottom_pallet_id = @bottomPalletId, top_pallet_id = @topPalletId,
                        stacked_at = SYSDATETIME(), stacked_by = @user
                    WHERE id = @id;
                    """, new { id = current.Id, bottomPalletId, topPalletId, user }, tx);
            }
            else
            {
                await conn.ExecuteAsync("""
                    INSERT INTO wms.shipment_trip_columns
                        (trip_id, column_code, bottom_pallet_id, top_pallet_id, stacked_at, stacked_by, is_deleted)
                    VALUES (@tripId, @code, @bottomPalletId, @topPalletId, SYSDATETIME(), @user, 0);
                    """, new { tripId, code, bottomPalletId, topPalletId, user }, tx);
            }

            await SyncActualPalletAsync(conn, tx, tripId, code, bottomPalletId, topPalletId);

            tx.Commit();
            return (StackSaveResult.Ok, null);
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<bool> PlaceAsync(long tripId, string code, string? user)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteAsync("""
            UPDATE wms.shipment_trip_columns
            SET placed_at = SYSDATETIME(), placed_by = @user
            WHERE trip_id = @tripId AND column_code = @code AND is_deleted = 0;
            """, new { tripId, code, user }) > 0;
    }

    public async Task<bool> ClearAsync(long tripId, string code, string? user)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteAsync("""
            UPDATE wms.shipment_trip_columns
            SET placed_at = CASE WHEN placed_at IS NULL THEN placed_at ELSE NULL END,
                placed_by = CASE WHEN placed_at IS NULL THEN placed_by ELSE NULL END,
                is_deleted = CASE WHEN placed_at IS NULL THEN 1 ELSE 0 END,
                deleted_at = CASE WHEN placed_at IS NULL THEN SYSDATETIME() ELSE deleted_at END,
                deleted_by = CASE WHEN placed_at IS NULL THEN @user ELSE deleted_by END
            WHERE trip_id = @tripId AND column_code = @code AND is_deleted = 0;
            """, new { tripId, code, user }) > 0;
    }

    public async Task<int> ClearOrphansAsync(long tripId, IReadOnlyCollection<string> planCodes, string? user)
    {
        using var conn = _factory.Create();
        var codes = planCodes.Count == 0 ? new[] { "" } : planCodes.ToArray();
        return await conn.ExecuteAsync("""
            UPDATE wms.shipment_trip_columns
            SET is_deleted = 1, deleted_at = SYSDATETIME(), deleted_by = @user
            WHERE trip_id = @tripId AND is_deleted = 0 AND column_code NOT IN @codes;
            """, new { tripId, codes, user });
    }

    private sealed class CurrentColumn
    {
        public long Id { get; set; }
        public DateTime? PlacedAt { get; set; }
    }

    private static async Task SyncActualPalletAsync(
        IDbConnection conn,
        IDbTransaction tx,
        long tripId,
        string code,
        long bottomPalletId,
        long? topPalletId)
    {
        var pallets = new List<long> { bottomPalletId };

        if (topPalletId.HasValue)
            pallets.Add(topPalletId.Value);

        await conn.ExecuteAsync("""
        UPDATE sp
        SET sp.wms_pallet_id = m.WmsPalletId
        FROM wms.stowage_pallets sp
        JOIN (
            SELECT
                pp.StowagePalletId,
                x.WmsPalletId
            FROM (
                SELECT
                    planMatch.StowagePalletId,
                    planMatch.WmsPalletId,
                    ROW_NUMBER() OVER(
                        PARTITION BY planMatch.StowagePalletId
                        ORDER BY planMatch.MatchCount DESC
                    ) rn
                FROM (
                    SELECT
                        pb.stowage_pallet_id StowagePalletId,
                        b.lot_id WmsPalletId,
                        COUNT(*) MatchCount
                    FROM wms.stowage_pallet_boxes pb
                    JOIN wms.shipment_instruction_boxes sb
                        ON sb.id = pb.si_box_id
                    JOIN wms.boxes b
                        ON b.id = sb.box_id
                    WHERE b.lot_id IN @PalletIds
                    GROUP BY
                        pb.stowage_pallet_id,
                        b.lot_id
                ) planMatch
            ) x
            WHERE x.rn = 1
        ) m
            ON m.StowagePalletId = sp.id;
        """,
            new
            {
                PalletIds = pallets
            },
            tx);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Kế hoạch Pallet List
    // ═══════════════════════════════════════════════════════════════

    /*  Thùng thật -> thùng của SI -> thùng của pallet soạn:
          wms.boxes b -> shipment_instruction_boxes sb (sb.box_id = b.id; packing list chưa khớp box
          thì so box_no) -> stowage_pallet_boxes pb (pb.si_box_id = sb.id) -> stowage_pallets.
        Thùng dự kiến (chưa lấy hàng) không có box thật nên không khớp được pallet nào.            */
    public async Task<List<PlanPalletMatchRow>> FindPlanPalletsOfAsync(long planId, int containerIndex, long palletId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<PlanPalletMatchRow>("""
            SELECT sp.id AS StowagePalletId, sp.code AS Code, si.si_no AS SiNo, sp.pallet_size AS PalletSize,
                   c.code AS ColumnCode, CAST(sp.tier AS int) AS Tier, COUNT(DISTINCT b.id) AS Matched
            FROM wms.boxes b
            JOIN wms.shipment_instruction_boxes sb
                 ON sb.box_id = b.id OR (sb.box_id IS NULL AND sb.box_no = b.box_no)
            JOIN wms.stowage_pallet_boxes pb ON pb.si_box_id = sb.id AND pb.plan_id = @planId
            JOIN wms.stowage_pallets sp      ON sp.id = pb.stowage_pallet_id
            JOIN wms.stowage_columns c       ON c.id = sp.column_id
            LEFT JOIN wms.shipment_instructions si ON si.id = sp.si_id
            WHERE b.lot_id = @palletId AND b.is_deleted = 0
              AND (c.container_index = @containerIndex OR c.container_index IS NULL)
            GROUP BY sp.id, sp.code, si.si_no, sp.pallet_size, c.code, sp.tier
            ORDER BY COUNT(DISTINCT b.id) DESC, sp.code;
            """, new { planId, containerIndex, palletId })).ToList();
    }

    public async Task<List<PlanPalletBoxRow>> GetPlanPalletBoxesAsync(long stowagePalletId)
    {
        using var conn = _factory.Create();
        // Mã thùng / model lấy từ wms.fn_stowage_si_boxes — cùng nguồn màn Stowage Plan của Web.
        return (await conn.QueryAsync<PlanPalletBoxRow>("""
            DECLARE @siId bigint = (SELECT si_id FROM wms.stowage_pallets WHERE id = @stowagePalletId);

            SELECT pb.id AS PlanBoxId, pb.si_box_id AS SiBoxId,
                   COALESCE(f.box_no, sb.box_no) AS PlanBoxNo, f.si_no AS SiNo, f.line_no AS [LineNo],
                   pb.carton_seq AS CartonSeq, f.model AS Model, CAST(ISNULL(f.is_estimated, 0) AS bit) AS IsEstimated,
                   rb.id AS BoxId, rb.box_no AS BoxNo, p.id AS PalletId, RTRIM(p.pallet_id) AS PalletCode,
                   loc.locator_code AS LocatorCode,
                   ISNULL(pc.cnt, 0) AS PalletBoxCount, ISNULL(q.qty, 0) AS Pcs
            FROM wms.stowage_pallet_boxes pb
            LEFT JOIN wms.fn_stowage_si_boxes(@siId) f
                 ON (pb.si_box_id IS NOT NULL AND f.si_box_id = pb.si_box_id)
                 OR (pb.si_box_id IS NULL AND f.si_line_id = pb.si_line_id AND f.carton_seq = pb.carton_seq)
            LEFT JOIN wms.shipment_instruction_boxes sb ON sb.id = pb.si_box_id
            OUTER APPLY (SELECT TOP (1) b.id, b.box_no, b.lot_id
                         FROM wms.boxes b
                         WHERE sb.id IS NOT NULL AND b.is_deleted = 0
                           AND (b.id = sb.box_id OR (sb.box_id IS NULL AND b.box_no = sb.box_no))
                         ORDER BY CASE WHEN b.id = sb.box_id THEN 0 ELSE 1 END, b.id DESC) rb
            LEFT JOIN wms.pallets p ON p.id = rb.lot_id AND p.is_deleted = 0
            LEFT JOIN master.locators loc ON loc.id = p.locator_id
            OUTER APPLY (SELECT COUNT(1) AS cnt FROM wms.boxes x
                         WHERE x.lot_id = p.id AND x.is_deleted = 0) pc
            OUTER APPLY (SELECT SUM(bl.qty) AS qty FROM wms.box_lines bl
                         WHERE bl.box_id = rb.id AND bl.is_deleted = 0) q
            WHERE pb.stowage_pallet_id = @stowagePalletId
            ORDER BY pb.id;
            """, new { stowagePalletId })).ToList();
    }

    public async Task<List<PlanPalletMatchRow>> GetColumnPalletsAsync(long planId, string columnCode)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<PlanPalletMatchRow>("""
            SELECT sp.id AS StowagePalletId, sp.code AS Code, si.si_no AS SiNo, sp.pallet_size AS PalletSize,
                   c.code AS ColumnCode, CAST(sp.tier AS int) AS Tier, 0 AS Matched
            FROM wms.stowage_columns c
            JOIN wms.stowage_pallets sp ON sp.column_id = c.id
            LEFT JOIN wms.shipment_instructions si ON si.id = sp.si_id
            WHERE c.plan_id = @planId AND c.code = @columnCode
            ORDER BY sp.tier;
            """, new { planId, columnCode })).ToList();
    }

    public async Task<List<PalletBoxRow>> GetPalletBoxesAsync(long palletId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<PalletBoxRow>(
            "SELECT id AS Id, box_no AS BoxNo FROM wms.boxes WHERE lot_id = @palletId AND is_deleted = 0 ORDER BY id;",
            new { palletId })).ToList();
    }
}