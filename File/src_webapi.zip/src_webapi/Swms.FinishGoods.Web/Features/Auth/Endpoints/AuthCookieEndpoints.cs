using Microsoft.AspNetCore.Mvc;

namespace Swms.FinishGoods.Web.Shared.Infrastructure.Auth;

// Minimal API endpoints để set/xóa cookie HttpOnly.
// Vì sao cần: Blazor Server interactive KHÔNG ghi cookie trực tiếp được
// (không còn HttpResponse lúc đó). Login.razor POST token sang đây, endpoint
// chạy trong HTTP context thật nên ghi được cookie.
public static class AuthCookieEndpoints
{
    public const string CookieName = "swms_token";

    public static IEndpointRouteBuilder MapAuthCookieEndpoints(this IEndpointRouteBuilder app)
    {
        // Nhận token (đã lấy từ API) + hạn dùng -> ghi cookie HttpOnly.
        app.MapPost("/auth/set-cookie", (HttpContext http, [FromBody] SetCookieRequest req) =>
        {
            if (string.IsNullOrWhiteSpace(req.Token))
                return Results.BadRequest();

            http.Response.Cookies.Append(CookieName, req.Token, new CookieOptions
            {
                HttpOnly = true,                 // JS không đọc được -> chống XSS
                Secure = http.Request.IsHttps,   // ← chỉ Secure khi thực sự chạy HTTPS
                SameSite = SameSiteMode.Lax,     // ← Strict có thể chặn vài luồng redirect
                Expires = req.ExpiresAtUtc,      // khớp hạn token; null = session cookie
                Path = "/"
            });
            return Results.Ok();
        });

        app.MapPost("/auth/logout", (HttpContext http) =>
        {
            http.Response.Cookies.Delete(CookieName);
            return Results.Ok();
        });

        return app;
    }
}

public record SetCookieRequest(string Token, DateTime? ExpiresAtUtc);
