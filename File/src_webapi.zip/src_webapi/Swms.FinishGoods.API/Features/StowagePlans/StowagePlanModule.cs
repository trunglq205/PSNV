using Swms.FinishGoods.API.Features.StowagePlans.Business;
using Swms.FinishGoods.API.Features.StowagePlans.DataAccess;

namespace Swms.FinishGoods.API.Features.StowagePlans;

public static class StowagePlanModule
{
    /// <summary>Gọi trong Program.cs cạnh AddShipmentTripFeature().</summary>
    public static IServiceCollection AddStowagePlanFeature(this IServiceCollection services)
    {
        services.AddScoped<IStowagePlanService, StowagePlanService>();
        services.AddScoped<IStowagePlanRepository, StowagePlanRepository>();
        return services;
    }
}
