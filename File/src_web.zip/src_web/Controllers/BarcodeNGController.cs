﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class BarcodeNGController : BaseController
    {
        private readonly ApiService _apiService;

        public BarcodeNGController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] BarcodeNGFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new BarcodeNGFilter();
                var response = await _apiService.SearchBarcodeNG(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<BarcodeNG>();

                var model = new BarcodeNGViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/BarcodeNG/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }
    }
}

