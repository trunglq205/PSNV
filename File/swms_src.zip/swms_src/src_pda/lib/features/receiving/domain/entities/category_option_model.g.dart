// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_option_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CategoryOptionModel _$CategoryOptionModelFromJson(Map<String, dynamic> json) =>
    CategoryOptionModel(
      code: (json['code'] as num).toInt(),
      name: json['name'] as String?,
    );

Map<String, dynamic> _$CategoryOptionModelToJson(
  CategoryOptionModel instance,
) => <String, dynamic>{'code': instance.code, 'name': ?instance.name};
