import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/repositories/shipment_instruction_repository.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/kitting_task_state.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'kitting_task_notifier.g.dart';

/// Kết quả quét cần màn phản hồi. null = không cần (lỗi server đã hiện qua
/// appAction, hoặc mã bị bỏ qua).
enum KittingScanResult {
  palletMatched,
  palletMismatch,

  /// Thùng cuối vừa lấy → server đóng task. Còn thùng → splitPending = true.
  boxesDone,

  /// Bước vanning sau tách: đã nhận tem pallet mới.
  stagePalletSet,

  /// Bước vanning sau tách: quét nhầm pallet gốc (còn hàng giữ lại).
  stagePalletIsOrigin,

  vanningScanned,
  vanningMismatch,
}

/// Màn lấy hàng tại 1 vị trí.
///   - Đọc  : GET  tasks/{id}/pick                        → executePartial
///   - Ghi  : confirm-pallet / boxes / gỡ thùng / vanning → appAction
///            (overlay + lỗi server đã dịch), mỗi lúc 1 lệnh.
@riverpod
class KittingTaskNotifier extends _$KittingTaskNotifier
    with BaseNotifierMixin<KittingTaskState> {
  ShipmentInstructionRepository get _repo =>
      ref.read(shipmentInstructionRepositoryProvider);

  @override
  KittingTaskState build(PickTask task) {
    Future.microtask(load);
    return const KittingTaskState();
  }

  Future<void> load() => executePartial<PickTaskDetail>(
    action: () => _repo.getPickTask(task),
    getField: (s) => s.detail,
    setField: (s, f) => s.copyWith(detail: f),
  );

  /// Router cho mã quét từ PDA — theo bước hiện tại.
  /// Bước tách / đã xong: bỏ qua mọi mã quét.
  Future<KittingScanResult?> onScan(String raw) async {
    final code = raw.trim();
    if (code.isEmpty) return null;
    switch (state.stepFor(task)) {
      case KittingStep.pickPallet:
        return _onPalletScanned(code);
      case KittingStep.pickBoxes:
        return _onBoxScanned(code);
      case KittingStep.vanning:
        return _onVanningScanned(code);
      case KittingStep.split:
      case KittingStep.done:
        return null;
    }
  }

  PickTask get _currentTask => state.taskOr(task);

  /// Bỏ khoảng trắng, không phân biệt hoa thường — cùng quy tắc với server.
  static String _norm(String? s) => (s ?? '').trim().toUpperCase();

  /// So ngay ở client để báo "Pallet khớp" tức thì (không chờ mạng).
  /// Server vẫn kiểm lại khi xác nhận.
  KittingScanResult _onPalletScanned(String code) {
    if (_norm(code) != _norm(task.palletCode)) {
      state = state.copyWith(clearScannedPallet: true);
      return KittingScanResult.palletMismatch;
    }
    state = state.copyWith(scannedPalletCode: code);
    return KittingScanResult.palletMatched;
  }

  /// Quét thùng — server kiểm tra; đủ thùng thì server tự đóng task.
  Future<KittingScanResult?> _onBoxScanned(String code) async {
    final ok = await _run(() => _repo.pickBox(task, code));
    if (!ok || !ref.mounted || !_currentTask.isDone) return null;
    if (state.hasRemainingBoxes) state = state.copyWith(splitPending: true);
    return KittingScanResult.boxesDone;
  }

  /// Bước vanning:
  ///   - chưa biết pallet (sau tách) → mã đầu tiên là tem pallet mới
  ///   - đã biết pallet → mã quét là vị trí vanning
  KittingScanResult? _onVanningScanned(String code) {
    final up = _norm(code);
    final pallet = state.vanningPalletFor(task);

    if (pallet == null) {
      // Pallet gốc chỉ bị chặn khi còn thùng giữ lại (tức là phải tách).
      // Lấy hết thùng thì không có gì để tách -> quét chính pallet gốc là đúng.
      if (up == _norm(_currentTask.palletCode) && state.hasRemainingBoxes) {
        return KittingScanResult.stagePalletIsOrigin;
      }
      state = state.copyWith(stagePalletCode: code, clearScannedVanning: true);
      return KittingScanResult.stagePalletSet;
    }

    // Lỡ quét lại tem pallet → bỏ qua.
    if (up == _norm(pallet)) return null;

    final target = _currentTask.toLocatorCode;
    if (_norm(target).isNotEmpty && up != _norm(target)) {
      state = state.copyWith(clearScannedVanning: true);
      return KittingScanResult.vanningMismatch;
    }
    state = state.copyWith(scannedVanningCode: code);
    return KittingScanResult.vanningScanned;
  }

  /// Lấy nguyên pallet. true = thành công → màn tự sang bước vanning
  /// (task isDone, chưa có stagedLocatorCode).
  Future<bool> confirmPallet() async {
    final code = state.scannedPalletCode;
    if (code == null) return false;
    return _run(() => _repo.confirmPallet(task, code));
  }

  /// Màn tách báo xong → sang bước vanning (quét tem pallet mới).
  void markSplitDone() => state = state.copyWith(splitPending: false);

  /// Quét nhầm tem pallet ở bước vanning → quét lại.
  void resetStagePallet() => state = state.copyWith(
    clearStagePallet: true,
    clearScannedVanning: true,
  );

  /// Lưu pallet tại vị trí vanning. true = thành công (màn đi tiếp).
  Future<bool> saveVanning() async {
    final pallet = state.vanningPalletFor(task);
    final locator = state.scannedVanningCode;
    if (pallet == null || locator == null) return false;
    return _run(
          () => _repo.stageVanning(
        task,
        palletCode: pallet,
        locatorCode: locator,
      ),
    );
  }

  /// Gỡ thùng quét nhầm.
  Future<bool> unpickBox(String boxNo) =>
      _run(() => _repo.unpickBox(task, boxNo));

  /// Mọi lệnh ghi: 1 lệnh tại 1 thời điểm. PDA quét rất nhanh — lệnh sau tới
  /// khi lệnh trước chưa xong thì bỏ, thao tác viên thấy khung quét đang xử lý
  /// và quét lại.
  Future<bool> _run(Future<PickTaskDetail> Function() action) async {
    if (state.busy) return false;
    state = state.copyWith(busy: true);
    try {
      final result = await ref.read(appActionProvider.notifier).run(action);
      if (!ref.mounted || result == null) return false;
      state = state.copyWith(detail: AsyncData(result));
      return true;
    } finally {
      if (ref.mounted) state = state.copyWith(busy: false);
    }
  }
}