using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.ShipmentTrips.Api;
using Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.Business.Media;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

/*  Ảnh minh chứng hàng xuất theo chuyến — cùng cách lưu với ảnh phiếu bất thường
    (IImageStorage: file trên đĩa + bản view / thumb, DB giữ đường dẫn tương đối).

    - PDA upload theo Ô: (item_key, unit_no, slot_no). Gửi lại cùng ô = chụp lại.
    - Chỉ nhận ảnh khi chuyến CÒN MỞ (planned / arrived / sealed): bước "trước khi
      quấn hàng" của AIR / LCL và "hàng trước khi đóng cont" của FCL thường chụp
      trước khi xe tới, nên planned cũng phải nhận.
    - Xuất cổng / huỷ: khoá cả upload lẫn xoá — bộ ảnh lúc đó là hồ sơ đã chốt.
    - Web chỉ đọc (GET), không có nút xoá.                                        */
public class TripPhotoService : ITripPhotoService
{
    /// <summary>Dung lượng tối đa 1 ảnh nhận từ PDA — bằng ảnh phiếu bất thường.</summary>
    public const long MaxPhotoBytes = 25L * 1024 * 1024;

    /// <summary>Thư mục của tính năng trong kho ảnh chung ("ng" là của phiếu bất thường).</summary>
    private const string StorageArea = "trip";

    private static readonly HashSet<string> OpenStatuses = new() { "planned", "arrived", "sealed" };

    private readonly ITripPhotoRepository _photos;
    private readonly IShipmentTripRepository _trips;
    private readonly ITripVanningRepository _vanning;
    private readonly ITripStowageRepository _stowage;
    private readonly IImageStorage _storage;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public TripPhotoService(
        ITripPhotoRepository photos,
        IShipmentTripRepository trips,
        ITripVanningRepository vanning,
        ITripStowageRepository stowage,
        IImageStorage storage,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _photos = photos;
        _trips = trips;
        _vanning = vanning;
        _stowage = stowage;
        _storage = storage;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    // ═══════════════════════════════════════════════════════════════
    //  Đọc
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripPhotoListResponse> GetAsync(long tripId)
    {
        var trip = await TripOrThrowAsync(tripId);

        // Pallet List thật của chuyến = pallet thuộc chuyến còn hàng (pallet nguồn gộp hết thùng thì rỗng, tự rơi ra).
        // Chưa phân pallet cho SI (chưa có dòng nào) -> tạm ước tính theo số PLT của SI.
        var palletLists = (await _vanning.GetTripPalletsAsync(tripId)).Where(p => p.BoxCount > 0).ToList();
        var pallets = palletLists.Count > 0
            ? palletLists.Count
            : (await _trips.GetSisByTripIdsAsync(new[] { tripId })).Sum(s => s.SiPltTotal);

        // Cọc / hàng: chuyến có Stowage Plan thì lấy số thật của container chuyến này
        // (số cọc C0x, số hàng row_no); chưa có plan thì ước tính 2 pallet / cọc, 2 cọc / hàng.
        var stacks = await _vanning.GetStacksAsync(tripId);
        int cocs, rows;
        if (await _stowage.GetPlanAsync(tripId) is { } plan
            && await _stowage.GetPlanColumnsAsync(plan.PlanId, plan.ContainerIndex) is { Count: > 0 } cols)
        {
            cocs = cols.Select(c => c.Code).Distinct().Count();
            rows = cols.Max(c => c.RowNo ?? 0) + 1;
        }
        else
        {
            cocs = Math.Max(stacks.Count, (pallets + 1) / 2);
            rows = (cocs + 1) / 2;
        }
        var units = (Pallets: pallets, Cocs: cocs, Rows: rows);

        var photos = await _photos.GetByTripAsync(tripId);
        var have = photos.GroupBy(p => p.ItemKey).ToDictionary(g => g.Key, g => g.Count());
        var perPallet = TripPhotoCatalog.For(trip.VehicleType)
            .Where(d => d.Unit == TripPhotoUnit.Pallet).Sum(d => d.PerUnit);
        var havePallet = photos.Where(p => p.PalletId is not null)
            .GroupBy(p => p.PalletId!.Value).ToDictionary(g => g.Key, g => g.Count());
        var cocOf = stacks
            .SelectMany(s => s.TopPalletId is { } top
                ? new (long Id, int Coc)[] { (s.BottomPalletId, s.CocNo), (top, s.CocNo) }
                : new (long Id, int Coc)[] { (s.BottomPalletId, s.CocNo) })
            .ToDictionary(x => x.Id, x => x.Coc);

        var items = TripPhotoCatalog.For(trip.VehicleType).Select(d =>
        {
            var n = TripPhotoCatalog.UnitsOf(d.Unit, units);
            return new TripPhotoItemResponse(
                d.Step, d.StepTitle, d.Key, d.Label, d.Note,
                d.PerUnit, TripPhotoCatalog.UnitCode(d.Unit), n, d.PerUnit * n,
                have.GetValueOrDefault(d.Key), d.SlotLabels);
        }).ToList();

        return new TripPhotoListResponse(
            trip.Id, trip.TripNo, trip.VehicleType, trip.Status, OpenStatuses.Contains(trip.Status),
            units.Pallets, units.Cocs, units.Rows,
            items.Sum(i => i.Required),
            // Ảnh chụp dư (vd pallet thực tế nhiều hơn số ước tính) không tính quá phần bắt buộc
            items.Sum(i => Math.Min(i.Have, i.Required)),
            items,
            photos.Select(TripPhotoResponse.From).ToList(),
            await _vanning.GetLatestInspectionAsync(tripId) is { } ins ? TripInspectionResponse.From(ins) : null,
            palletLists.Select(p => new TripPalletListResponse(
                p.Code, p.BoxCount, p.Pcs, p.LocatorCode,
                cocOf.TryGetValue(p.Id, out var c) ? c : (int?)null,
                havePallet.GetValueOrDefault(p.Id), perPallet)).ToList(),
            stacks.Select(TripStackResponse.From).ToList());
    }

    public async Task<(Stream Content, string ContentType, string FileName)> GetFileAsync(long photoId, string size)
    {
        // Thiếu dòng và thiếu file là 2 câu khác nhau — giống ảnh phiếu bất thường
        var photo = await _photos.GetAsync(photoId)
            ?? throw new NotFoundException(_localizer["Trip.Photo.RowMissing", photoId]);

        var resolved = _storage.Resolve(photo.FilePath, size)
            ?? throw new NotFoundException(_localizer["Trip.Photo.FileMissing", photo.FilePath, _storage.Root]);

        return (File.OpenRead(resolved.FullPath), resolved.ContentType, photo.FileName);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Ghi (PDA)
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripPhotoResponse> UploadAsync(long tripId, TripPhotoUploadRequest r)
    {
        var trip = await TripOrThrowAsync(tripId);
        EnsureOpen(trip);

        var file = r.File;
        if (file is null || file.Length <= 0 || file.Length > MaxPhotoBytes)
            throw new BusinessRuleException(_localizer["Trip.Photo.TooLarge"]);

        var key = (r.ItemKey ?? "").Trim().ToLowerInvariant();
        var def = TripPhotoCatalog.Find(trip.VehicleType, key)
            ?? throw new BusinessRuleException(_localizer["Trip.Photo.KeyInvalid", key, trip.VehicleType]);

        // Ảnh theo chuyến: không có đơn vị.
        // Ảnh theo pallet: gắn pallet thật (PDA quét tem) — pallet phải thuộc chuyến.
        // Ảnh theo cọc / hàng: unit_no (cọc = coc_no). Không chặn vượt số ước tính — số hàng chỉ là ước tính.
        int? unitNo = null;
        long? palletId = null;
        if (def.Unit == TripPhotoUnit.Pallet)
        {
            var code = (r.PalletCode ?? "").Trim().ToUpperInvariant();
            if (code.Length == 0)
                throw new BusinessRuleException(_localizer["Trip.Photo.PalletRequired", def.Label]);
            var pallet = await _vanning.FindPalletAsync(tripId, code)
                ?? throw new NotFoundException(_localizer["Trip.Photo.PalletNotFound", code]);
            if (!pallet.InScope)
                throw new BusinessRuleException(_localizer["Trip.Photo.PalletNotInTrip", code]);
            palletId = pallet.Id;
        }
        else if (def.Unit != TripPhotoUnit.Trip)
        {
            unitNo = r.UnitNo ?? throw new BusinessRuleException(_localizer["Trip.Photo.UnitRequired", def.Label]);
        }

        // Mục 1 ảnh thì khỏi gửi slot; mục nhiều ảnh (vd 4 góc cont) phải nói rõ ảnh thứ mấy
        var slotNo = r.SlotNo ?? (def.PerUnit == 1 ? 1 : 0);
        if (slotNo < 1 || slotNo > def.PerUnit)
            throw new BusinessRuleException(_localizer["Trip.Photo.SlotInvalid", def.Label, def.PerUnit]);

        StoredImage saved;
        try
        {
            await using var stream = file.OpenReadStream();
            saved = await _storage.SaveAsync(stream, StorageArea, trip.TripNo, file.FileName);
        }
        catch (NotAnImageException)
        {
            throw new BusinessRuleException(_localizer["Trip.Photo.NotAnImage"]);
        }

        var row = new TripPhotoRow
        {
            TripId = tripId,
            ItemKey = key,
            UnitNo = unitNo,
            PalletId = palletId,
            SlotNo = slotNo,
            FilePath = saved.RelativePath,
            FileName = saved.FileName,
            ContentType = saved.ContentType,
            SizeBytes = saved.SizeBytes,
            CreatedBy = Actor,
        };
        var (id, _) = await _photos.ReplaceSlotAsync(row);

        return TripPhotoResponse.From(await _photos.GetAsync(id) ?? row);
    }

    public async Task DeleteAsync(long photoId)
    {
        var photo = await _photos.GetAsync(photoId)
            ?? throw new NotFoundException(_localizer["Trip.Photo.RowMissing", photoId]);
        EnsureOpen(await TripOrThrowAsync(photo.TripId));

        if (!await _photos.SoftDeleteAsync(photoId, Actor))
            throw new NotFoundException(_localizer["Trip.Photo.RowMissing", photoId]);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Kiểm tra
    // ═══════════════════════════════════════════════════════════════

    private async Task<TripRow> TripOrThrowAsync(long tripId)
        => await _trips.GetAsync(tripId)
           ?? throw new NotFoundException(_localizer["Trip.NotFound", tripId]);

    private void EnsureOpen(TripRow t)
    {
        if (!OpenStatuses.Contains(t.Status))
            throw new BusinessRuleException(_localizer["Trip.Photo.Locked", t.Status]);
    }
}
