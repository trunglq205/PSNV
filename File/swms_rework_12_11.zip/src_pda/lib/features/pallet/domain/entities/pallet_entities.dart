﻿import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/sap_status.dart';
import 'package:swms_finish_goods/shared/domain/entities/stock_event.dart';

/// Hành động server cho phép với 1 pallet — khớp `allowedActions` của API.
enum PalletAction {
  /// Gán vào khu nhận hàng (pallet chưa có vị trí).
  assign,

  /// Đổi ô trong khu nhận hàng.
  moveReceiving,

  /// Lưu kho: khu nhận hàng → kho.
  store,

  /// Đổi ô trong kho.
  moveStoring,

  /// Ra khu tập kết: kho → tập kết.
  vanning,

  /// Đổi ô trong khu tập kết.
  moveVanning,

  /// Out kho: pallet rời vị trí hiện tại và KHÔNG nằm ở ô nào.
  ///
  /// Khác mọi hành động còn lại ở một điểm quyết định cả giao diện: nó không
  /// có vị trí đích, nên bước 2 không quét gì, bấm xác nhận được ngay.
  /// Server đã có sẵn `DELETE /api/pallets/{id}/locator` từ trước; enum này
  /// từng bỏ `release` nên `fromCode` ném mã đó đi và nút biến mất.
  release;

  bool get isMove =>
      this == moveReceiving || this == moveStoring || this == moveVanning;

  /// Hành động này có cần quét vị trí đích hay không.
  /// Dùng ở `canSubmit` và ở khối quét của bước 2 — hai chỗ đó mà lệch nhau là
  /// hoặc nút xác nhận chết, hoặc đòi quét một vị trí không tồn tại.
  bool get needsLocator => this != release;

  static PalletAction? fromCode(String code) => switch (code) {
    'assign' => assign,
    'move_receiving' => moveReceiving,
    'store' => store,
    'move_storing' => moveStoring,
    'vanning' => vanning,
    'move_vanning' => moveVanning,
    'release' => release,
    _ => null, // mã lạ bị bỏ qua
  };
}

/// Phần dữ liệu nạp thêm qua `?include=` của `GET /api/pallets/by-lot-no/{lotNo}`.
enum PalletInclude {
  boxes,
  history,
  suggestion,
  all;

  /// Chuỗi query gửi lên server; null nếu không cần nạp thêm gì.
  static String? toQuery(Set<PalletInclude> set) {
    if (set.isEmpty) return null;
    if (set.contains(PalletInclude.all)) return PalletInclude.all.name;
    return set.map((e) => e.name).join(',');
  }
}

/// Giá trị `detail_level` của pallet CHỈ BIẾT SỐ THÙNG: không có dòng nào
/// trong wms.boxes, nên không quét được từng thùng. Hai giá trị còn lại là
/// `serial` và `box_line`, cả hai đều có thùng để quét.
const String kDetailLevelBoxCount = 'box_count';

/// Pallet — khớp `PalletDetailResponse` của API. Pallet ID = lot_no.
/// Dùng chung cho mọi màn: Detail, Vị trí tạm, Lưu kho, Chuyển/Out, Tách, Tìm thùng.
class Pallet {
  final int id;
  final String lotNo;
  final int categoryCode;
  final String? categoryName;
  final String lotType;

  /// Mã xe stocky — chỉ có khi lotType = stocky.
  final String? stockyCode;

  final String detailLevel;
  final int? boxCount;
  final int? totalQty;
  final InspectionStatus inspectionStatus;

  /// Loại hàng back: `rework` | `refurbish`, null với hàng thường. Cùng từ
  /// vựng với `wms.pallets.disposition` và `return_instructions.goods_type`.
  /// Dùng để in badge RW / RB trên tem.
  final String? disposition;

  final bool isUrgent;
  final SapStatus? sapStatus;
  final DateTime? sapPushedAt;
  final DateTime? productionDate;

  /// Model gộp bằng ", ". Dùng khi [modelQtys] rỗng (lot mức box_count).
  final String? models;

  /// Model + tổng qty + số thùng (mỗi model 1 dòng).
  final List<PalletModelQty> modelQtys;

  /// Vị trí hiện tại (null nếu chưa gán).
  final int? locatorId;
  final String? locatorCode;
  final String? areaCode;
  final String? areaName;

  /// Hành động server cho phép (đã bỏ mã lạ).
  final List<PalletAction> allowedActions;

  /// Vị trí gợi ý lưu kho — chỉ có khi `include=suggestion`.
  final LocatorSuggestion? suggestedLocator;

  /// Thùng trong pallet — chỉ có khi `include=boxes`.
  final List<PalletBox> boxes;

  /// Lịch sử (mới nhất trước) — chỉ có khi `include=history`.
  ///
  /// ĐỔI KIỂU: trước là `List<PalletHistoryEntry>` đọc từ
  /// `wms.locator_status_history` (bảng đã bỏ). Giờ là [PalletEvent] đọc từ
  /// `wms.stock_events`, tối đa 10 mốc gần nhất.
  final List<PalletEvent> history;

  const Pallet({
    required this.id,
    required this.lotNo,
    required this.categoryCode,
    required this.lotType,
    required this.detailLevel,
    required this.inspectionStatus,
    required this.isUrgent,
    this.allowedActions = const [],
    this.categoryName,
    this.stockyCode,
    this.disposition,
    this.boxCount,
    this.totalQty,
    this.sapStatus,
    this.sapPushedAt,
    this.productionDate,
    this.models,
    this.modelQtys = const [],
    this.locatorId,
    this.locatorCode,
    this.areaCode,
    this.areaName,
    this.suggestedLocator,
    this.boxes = const [],
    this.history = const [],
  });

  bool get hasLocator => locatorId != null && locatorCode != null;

  bool get hasSuggestion => suggestedLocator != null;

  /// DB doc: `stocky_cart`; app hiện dùng `stocky` — nhận cả hai.
  static const _stockyLotTypes = {'stocky', 'stocky_cart'};

  bool get isStocky => _stockyLotTypes.contains(lotType.toLowerCase());

  bool can(PalletAction a) => allowedActions.contains(a);

  bool get canAssign => can(PalletAction.assign);

  bool get canMove => allowedActions.any((a) => a.isMove);

  bool get canStore => can(PalletAction.store);

  /// Tổng qty: ưu tiên server, fallback cộng dồn [modelQtys].
  int get displayTotalQty =>
      totalQty ?? modelQtys.fold(0, (s, e) => s + e.totalQty);

  /// Số thùng: ưu tiên server, fallback đếm [boxes].
  int get displayBoxCount => boxCount ?? boxes.length;

  /// Chuỗi model để hiển thị: ưu tiên [modelQtys], fallback [models].
  String get displayModels => modelQtys.isNotEmpty
      ? modelQtys.map((e) => e.model).join(', ')
      : (models ?? '');
}

/// Vị trí gợi ý để lưu pallet (API tính theo FIFO / loại SP / chỗ trống).
class LocatorSuggestion {
  final int locatorId;
  final String locatorCode;
  final String? areaCode;
  final String? areaName;

  /// Lý do gợi ý (vd: "gần khu cùng model"). Tùy chọn.
  final String? reason;

  const LocatorSuggestion({
    required this.locatorId,
    required this.locatorCode,
    this.areaCode,
    this.areaName,
    this.reason,
  });
}

class PalletModelQty {
  final String model;
  final int totalQty;

  /// Số thùng chứa model này trong pallet.
  final int boxCount;

  const PalletModelQty({
    required this.model,
    required this.totalQty,
    this.boxCount = 0,
  });
}

class PalletBox {
  final int id;
  final String boxNo;
  final String? payload;
  final List<PalletBoxLine> lines;

  const PalletBox({
    required this.id,
    required this.boxNo,
    this.payload,
    this.lines = const [],
  });

  /// Model đại diện của thùng (dòng đầu).
  String? get primaryModel => lines.isEmpty ? null : lines.first.model;

  /// Tổng qty của thùng.
  int get totalQty => lines.fold(0, (s, l) => s + l.qty);
}

class PalletBoxLine {
  final int id;
  final String model;
  final int qty;
  final String? serialNo;

  const PalletBoxLine({
    required this.id,
    required this.model,
    required this.qty,
    this.serialNo,
  });
}

// PalletHistoryEntry đã XOÁ cùng bảng wms.locator_status_history.
// Thay bằng PalletEvent — xem domain/entities/stock_event.dart