using Swms.FinishGoods.Api.Features.Roles.Business.Models;

namespace Swms.FinishGoods.Api.Features.Roles.DataAccess;

public interface IRoleRepository
{
    // Roles
    Task<List<Role>> GetAllAsync();
    Task<Role?> GetByCodeAsync(string code);
    Task<bool> CodeExistsAsync(string code);

    // Map permission code → id (chỉ các code đang active trong DB)
    Task<Dictionary<string, long>> GetPermissionIdsByCodesAsync(IEnumerable<string> codes);

    Task<long> AddAsync(Role role, IEnumerable<long> permissionIds, string actor);
    Task UpdateAsync(string currentCode, Role role, string actor);
    Task ReplacePermissionsAsync(string code, IEnumerable<long> permissionIds, string actor);
    Task SoftDeleteAsync(string code);

    // /api/me
    Task<List<string>> GetEffectivePermissionsForUserAsync(long userId);
    Task<bool> UserHasSystemRoleAsync(long userId);
}
