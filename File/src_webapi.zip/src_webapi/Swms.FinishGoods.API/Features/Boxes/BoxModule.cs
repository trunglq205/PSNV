﻿using Swms.FinishGoods.API.Features.Boxes.Business;
using Swms.FinishGoods.API.Features.Boxes.DataAccess;

namespace Swms.FinishGoods.API.Features.Boxes
{
    public static class BoxModule
    {
        public static IServiceCollection AddBoxFeature(this IServiceCollection services)
        {
            services.AddScoped<IBoxService, BoxService>();
            services.AddScoped<IBoxRepository, BoxRepository>();
            return services;
        }
    }
}