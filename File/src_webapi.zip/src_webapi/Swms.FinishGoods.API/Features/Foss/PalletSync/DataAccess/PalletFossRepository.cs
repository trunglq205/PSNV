using Dapper;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Boxes;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Data;
using System.Linq;
using System.Text.Json;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;

namespace Swms.FinishGoods.API.Features.Foss.PalletSync.DataAccess
{
    /// <summary>Lý do 1 thùng Foss không được thêm.</summary>
    public static class FossSkipReasons
    {
        /// <summary>box_no đang nằm trên pallet active khác (vd đã tách, hoặc Foss đổi pallet).</summary>
        public const string BoxOnOtherPallet = "BOX_ON_OTHER_PALLET";
        /// <summary>Thùng mới nhưng mọi serial đã nằm trên pallet active khác.</summary>
        public const string SerialsOnOtherPallet = "SERIALS_ON_OTHER_PALLET";
        /// <summary>box_no đã có trên chính pallet này (so khớp C# lệch với SQL, vd khoảng trắng cuối).</summary>
        public const string AlreadyOnThisPallet = "ALREADY_ON_THIS_PALLET";
    }

    /// <summary>1 thùng Foss không được thêm.</summary>
    /// <param name="HeldByPalletId">pallet_id đang giữ thùng / serial.</param>
    public sealed record FossSkippedBox(string BoxNo, string Reason, string? HeldByPalletId);

    /// <summary>Số thùng / serial thực sự được chèn khi bổ sung từ Foss, kèm thùng bị bỏ qua.</summary>
    public sealed record FossAppendResult(int BoxesAdded, int LinesAdded, IReadOnlyList<FossSkippedBox> Skipped)
    {
        public static readonly FossAppendResult Empty = new(0, 0, []);
    }

    /// <summary>Số thùng / serial đang có trên SWMS của 1 pallet (lọc nhanh ứng viên top-up).</summary>
    public sealed record PalletContentCount
    {
        public string LotNo { get; init; } = "";
        public int BoxCount { get; init; }
        public int SerialCount { get; init; }
    }

    /// <summary>
    /// Ghi / đọc wms.pallets phục vụ đồng bộ Foss (trước đây nằm trong LotRepository):
    /// bổ sung thùng / serial, ghi OQC, chọn ứng viên cho job FA / OQC.
    /// Insert thùng dùng chung PalletSqlShared để thùng bổ sung có cùng shape với thùng lúc tạo.
    /// </summary>
    public class PalletFossRepository : IPalletFossRepository
    {
        private readonly IDbConnectionFactory _factory;
        private readonly IStockEventWriter _events;

        public PalletFossRepository(IDbConnectionFactory factory, IStockEventWriter events)
        {
            _factory = factory;
            _events = events;
        }

        // ── Bổ sung thùng từ Foss ────────────────────────────────────

        /// <summary>
        /// Khoá so khớp (model, số) — box_no / serial CHỈ duy nhất trong phạm vi 1 model.
        /// Chuẩn hoá trim + upper để khớp với so sánh của SQL Server (collation CI, bỏ khoảng trắng cuối).
        /// </summary>
        private readonly record struct ModelKey
        {
            public ModelKey(string? model, string? value)
            {
                Model = (model ?? "").Trim().ToUpperInvariant();
                Value = (value ?? "").Trim().ToUpperInvariant();
            }

            public string Model { get; }
            public string Value { get; }
        }

        private static string Norm(string? s) => (s ?? "").Trim();

        /// <summary>Model của 1 thùng: lấy từ line đầu tiên có model (entity Box không mang model).</summary>
        private static string ModelOfBox(Box b) =>
            Norm(b.Lines.Select(l => l.Model).FirstOrDefault(m => !string.IsNullOrWhiteSpace(m)));

        /// <summary>
        /// Bổ sung thùng / serial Foss thêm vào SAU khi SWMS đã tạo pallet
        /// (Foss tạo pallet chưa xong mà SWMS đã lấy).
        ///
        /// Bỏ qua box_no / serial đã nằm trên BẤT KỲ pallet active nào: thùng đã tách sang
        /// pallet khác vẫn còn trong Foss dưới pallet gốc, không được kéo về lại.
        /// Mỗi thùng bị bỏ qua được trả kèm lý do + pallet đang giữ nó.
        /// Khoá dòng pallet: job nền và PDA cùng bổ sung 1 pallet thì xếp hàng, không chèn trùng.
        /// </summary>
        public async Task<FossAppendResult> AppendFossBoxesAsync(
            long lotId,
            IReadOnlyList<Box> newBoxes,
            IReadOnlyList<(long BoxId, BoxLine Line)> newLines,
            int? standardPallet,
            string user,
            StockEventContext ctx)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                // 1) Khoá pallet + lấy pallet_id của chính nó
                //    (để phân biệt "thùng ở pallet khác" với "đã ở đây rồi").
                const string lockSql = """
                    SELECT pallet_id FROM wms.pallets WITH (UPDLOCK, ROWLOCK)
                    WHERE id = @lotId AND is_deleted = 0;
                    """;
                var ownLotNo = await conn.ExecuteScalarAsync<string?>(lockSql, new { lotId }, tx);
                if (ownLotNo is null)
                {
                    tx.Rollback();
                    return FossAppendResult.Empty;
                }

                const string countSql = """
                    SELECT COUNT(*) FROM wms.boxes WHERE lot_id = @lotId AND is_deleted = 0;
                    """;
                var boxCountBefore = await conn.ExecuteScalarAsync<int>(countSql, new { lotId }, tx);

                // 2) (model, box_no) / (model, serial) đã dùng ở pallet active bất kỳ -> kèm pallet đang giữ.
                //    PHẢI kèm model: SERIAL_OUTER là số chạy ngắn (AJ0171...) và serial đều có thể
                //    trùng giữa các model khác nhau — so riêng số sẽ báo nhầm "thùng ở pallet khác".
                //    OPENJSON thay vì IN @list: pallet nhiều serial dễ vượt giới hạn 2100 tham số.
                var boxKeys = newBoxes
                    .Where(b => !string.IsNullOrWhiteSpace(b.BoxNo))
                    .Select(b => new ModelKey(ModelOfBox(b), b.BoxNo.Trim()))
                    .Distinct()
                    .ToList();

                var serialKeys = newBoxes.SelectMany(b => b.Lines)
                    .Concat(newLines.Select(x => x.Line))
                    .Where(l => !string.IsNullOrWhiteSpace(l.SerialNo))
                    .Select(l => new ModelKey(Norm(l.Model), l.SerialNo!.Trim()))
                    .Distinct()
                    .ToList();

                // Model của box: boxes.model (box đơn model) hoặc bất kỳ line nào của box.
                const string usedBoxSql = """
                    SELECT j.m AS Model, j.v AS [Key], MIN(l.pallet_id) AS PalletId
                    FROM OPENJSON(@items) WITH (m varchar(200) '$.m', v varchar(200) '$.v') j
                    JOIN wms.boxes b WITH (UPDLOCK, HOLDLOCK)
                         ON b.box_no = j.v AND b.is_deleted = 0
                    JOIN wms.pallets l ON l.id = b.lot_id AND l.is_deleted = 0
                    WHERE b.model = j.m
                       OR EXISTS (SELECT 1 FROM wms.box_lines bl
                                  WHERE bl.box_id = b.id AND bl.is_deleted = 0 AND bl.model = j.m)
                    GROUP BY j.m, j.v;
                    """;

                const string usedSerialSql = """
                    SELECT j.m AS Model, j.v AS [Key], MIN(l.pallet_id) AS PalletId
                    FROM OPENJSON(@items) WITH (m varchar(200) '$.m', v varchar(200) '$.v') j
                    JOIN wms.box_lines bl WITH (UPDLOCK, HOLDLOCK)
                         ON bl.serial_no = j.v AND bl.model = j.m AND bl.is_deleted = 0
                    JOIN wms.boxes b ON b.id = bl.box_id AND b.is_deleted = 0
                    JOIN wms.pallets l ON l.id = b.lot_id AND l.is_deleted = 0
                    GROUP BY j.m, j.v;
                    """;

                async Task<Dictionary<ModelKey, string>> HeldByAsync(string sql, List<ModelKey> items)
                {
                    var map = new Dictionary<ModelKey, string>();
                    if (items.Count == 0) return map;
                    var json = JsonSerializer.Serialize(items.Select(k => new { m = k.Model, v = k.Value }));
                    var rows = await conn.QueryAsync<(string Model, string Key, string PalletId)>(
                        sql, new { items = json }, tx);
                    foreach (var r in rows) map.TryAdd(new ModelKey(Norm(r.Model), r.Key.Trim()), r.PalletId);
                    return map;
                }

                var usedBoxes = await HeldByAsync(usedBoxSql, boxKeys);
                var usedSerials = await HeldByAsync(usedSerialSql, serialKeys);

                ModelKey SerialKey(BoxLine l) => new(Norm(l.Model), l.SerialNo!.Trim());
                bool SerialFree(BoxLine l) =>
                    string.IsNullOrWhiteSpace(l.SerialNo) || !usedSerials.ContainsKey(SerialKey(l));

                // 3) Thùng mới.
                var insertedBoxes = new List<Box>();
                var skipped = new List<FossSkippedBox>();
                var linesAdded = 0;

                foreach (var box in newBoxes)
                {
                    if (usedBoxes.TryGetValue(new ModelKey(ModelOfBox(box), box.BoxNo.Trim()), out var holder))
                    {
                        skipped.Add(new FossSkippedBox(
                            box.BoxNo,
                            string.Equals(holder, ownLotNo, StringComparison.OrdinalIgnoreCase)
                                ? FossSkipReasons.AlreadyOnThisPallet
                                : FossSkipReasons.BoxOnOtherPallet,
                            holder));
                        continue;
                    }

                    var freeLines = box.Lines.Where(SerialFree).ToList();
                    if (freeLines.Count == 0)
                    {
                        var serialHolder = box.Lines
                            .Where(l => !string.IsNullOrWhiteSpace(l.SerialNo))
                            .Select(l => usedSerials.TryGetValue(SerialKey(l), out var p) ? p : null)
                            .FirstOrDefault(p => p is not null);
                        skipped.Add(new FossSkippedBox(box.BoxNo, FossSkipReasons.SerialsOnOtherPallet, serialHolder));
                        continue;
                    }

                    box.Lines = freeLines;
                    await PalletSqlShared.InsertBoxWithLinesAsync(conn, tx, lotId, box);
                    insertedBoxes.Add(box);
                    linesAdded += box.Lines.Count;
                }

                // 4) Serial mới trong thùng đã có.
                foreach (var g in newLines.Where(x => SerialFree(x.Line)).GroupBy(x => x.BoxId))
                {
                    var lines = g.Select(x => x.Line).ToList();
                    await PalletSqlShared.InsertLinesAsync(conn, tx, g.Key, lines);
                    linesAdded += lines.Count;
                }

                if (insertedBoxes.Count == 0 && linesAdded == 0)
                {
                    tx.Rollback();
                    return new FossAppendResult(0, 0, skipped);
                }

                // 5) Tính lại box_count / even_lot / production_date (FIFO: oldest wins).
                var minDate = insertedBoxes
                    .Select(b => b.ProductionDate)
                    .Where(d => d is not null)
                    .Min();

                const string updSql = """
                    UPDATE l
                    SET box_count = x.cnt,
                        even_lot  = CASE WHEN @standardPallet IS NULL THEN l.even_lot
                                         WHEN x.cnt = @standardPallet THEN 1 ELSE 0 END,
                        production_date = CASE WHEN @minDate IS NOT NULL
                                                AND (l.production_date IS NULL OR @minDate < l.production_date)
                                               THEN @minDate ELSE l.production_date END,
                        updated_at = SYSDATETIME(),
                        updated_by = @user
                    FROM wms.pallets l
                    CROSS APPLY (SELECT COUNT(*) AS cnt
                                 FROM wms.boxes b
                                 WHERE b.lot_id = l.id AND b.is_deleted = 0) x
                    WHERE l.id = @lotId;
                    """;
                await conn.ExecuteAsync(updSql, new { lotId, standardPallet, minDate, user }, tx);

                // 6) Event: 1 dòng cấp pallet + BOX_CREATED cho từng thùng mới.
                await _events.WriteAsync(conn, tx, new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = lotId,
                    EventCode = ctx.EventCode,
                    Actor = ctx.Actor ?? user,
                    Source = ctx.Source,
                    BoxCountBefore = boxCountBefore,
                    BoxCountAfter = boxCountBefore + insertedBoxes.Count,
                    Note = ctx.Note,
                    Payload = ctx.Payload,
                });

                if (insertedBoxes.Count > 0)
                {
                    await _events.WriteManyAsync(conn, tx, insertedBoxes.Select(box => new StockEvent
                    {
                        SubjectType = StockEventSubjects.Box,
                        PalletId = lotId,
                        BoxId = box.Id,
                        EventCode = StockEventCodes.BoxCreated,
                        EventAt = box.CreatedAt == default ? null : box.CreatedAt,
                        Actor = box.CreatedBy ?? ctx.Actor ?? user,
                        Source = ctx.Source,
                    }));
                }

                tx.Commit();
                return new FossAppendResult(insertedBoxes.Count, linesAdded, skipped);
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>Số thùng / serial đang có trên SWMS cho cả nhóm, 1 câu (lọc ứng viên top-up).</summary>
        public async Task<Dictionary<string, PalletContentCount>> GetContentCountsAsync(
            IReadOnlyCollection<string> lotNos)
        {
            var map = new Dictionary<string, PalletContentCount>(StringComparer.OrdinalIgnoreCase);
            if (lotNos.Count == 0) return map;

            using var conn = _factory.Create();
            const string sql = """
                SELECT l.pallet_id                  AS LotNo,
                       COUNT(DISTINCT b.id)         AS BoxCount,
                       -- serial chỉ duy nhất trong 1 model -> đếm theo cặp (model, serial)
                       COUNT(DISTINCT CASE WHEN bl.serial_no IS NOT NULL
                                           THEN CONCAT(bl.model, '|', bl.serial_no) END) AS SerialCount
                FROM OPENJSON(@lots) WITH (lot varchar(50) '$') j
                JOIN wms.pallets l         ON l.pallet_id = j.lot AND l.is_deleted = 0
                LEFT JOIN wms.boxes b      ON b.lot_id = l.id AND b.is_deleted = 0
                LEFT JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                GROUP BY l.pallet_id;
                """;

            var rows = await conn.QueryAsync<PalletContentCount>(
                sql, new { lots = JsonSerializer.Serialize(lotNos) }, commandTimeout: 60);

            foreach (var r in rows) map.TryAdd(r.LotNo, r);
            return map;
        }

        /// <summary>
        /// Pallet Foss có thể còn thiếu thùng: chưa chẵn, tạo trong cửa sổ thời gian,
        /// chưa xuất cho khách, không phải pallet thẻ in (Card_ID=).
        /// Pallet lẻ thật sự sẽ tự rơi khỏi danh sách khi hết cửa sổ.
        /// </summary>
        public async Task<List<string>> GetFossTopUpCandidatesAsync(DateTime createdSince)
        {
            using var conn = _factory.Create();
            var sql = $"""
                SELECT l.pallet_id
                FROM wms.pallets l
                WHERE l.is_deleted = 0
                  AND l.detail_level <> 'box_count'
                  AND ISNULL(l.even_lot, 0) = 0
                  AND l.created_at >= @createdSince
                  AND {PalletSqlShared.NotShippedSql}
                  AND NOT EXISTS (SELECT 1 FROM wms.boxes b
                                  WHERE b.lot_id = l.id AND b.is_deleted = 0
                                    AND b.raw_payload LIKE 'Card_ID=%')
                ORDER BY l.created_at;
                """;
            return (await conn.QueryAsync<string>(
                sql, new { createdSince }, commandTimeout: 60)).ToList();
        }

        // ── OQC ──────────────────────────────────────────────────────

        /// <summary>
        /// Ghi oqc_status theo box_id + inspection_status của pallet trong 1 transaction.
        /// Nguồn trạng thái do service quyết định (Foss STATUS_FA hoặc part_cards cho thùng thẻ in).
        /// </summary>
        public async Task<int> UpdateOqcStatusAsync(
            long lotId,
            IReadOnlyDictionary<long, int> boxStatuses,
            string inspectionStatus,
            string? user,
            StockEventContext? ctx = null)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                var updated = 0;
                if (boxStatuses.Count > 0)
                {
                    const string boxSql = """
                        UPDATE b
                        SET b.oqc_status = j.status,
                            b.updated_at = SYSDATETIME(),
                            b.updated_by = @user
                        FROM wms.boxes b
                        JOIN OPENJSON(@items) WITH (box_id bigint, status tinyint) j
                          ON j.box_id = b.id
                        WHERE b.lot_id = @lotId AND b.is_deleted = 0;
                        """;
                    var items = JsonSerializer.Serialize(
                        boxStatuses.Select(kv => new { box_id = kv.Key, status = kv.Value }));
                    updated = await conn.ExecuteAsync(boxSql, new { lotId, items, user }, tx);
                }

                // Chỉ ghi khi trạng thái thật sự đổi.
                const string palletSql = """
                    UPDATE wms.pallets
                    SET inspection_status = @inspectionStatus,
                        updated_at = SYSDATETIME(),
                        updated_by = @user
                    WHERE id = @lotId
                      AND inspection_status <> @inspectionStatus;
                    """;
                var palletChanged = await conn.ExecuteAsync(
                    palletSql, new { lotId, inspectionStatus, user }, tx) > 0;

                // Chỉ ghi khi thật sự có thay đổi.
                if (ctx is not null && (updated > 0 || palletChanged))
                {
                    await _events.WriteAsync(conn, tx, new StockEvent
                    {
                        SubjectType = StockEventSubjects.Pallet,
                        PalletId = lotId,
                        EventCode = ctx.EventCode,
                        Actor = ctx.Actor ?? user,
                        Source = ctx.Source,
                        Note = ctx.Note,
                        Payload = ctx.Payload,
                    });
                }

                tx.Commit();
                return updated;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>Pallet còn tồn, có thùng, chưa có kết quả OQC cuối — cũ nhất trước.</summary>
        public async Task<List<string>> GetLotNosNeedingOqcAsync(IReadOnlyCollection<string> finalStatuses)
        {
            using var conn = _factory.Create();
            var sql = $"""
                SELECT l.pallet_id
                FROM wms.pallets l
                WHERE l.is_deleted = 0
                  AND l.detail_level <> 'box_count'
                  AND (l.inspection_status IS NULL OR l.inspection_status NOT IN @finals)
                  AND {PalletSqlShared.NotShippedSql}
                ORDER BY l.production_date, l.id;
                """;
            return (await conn.QueryAsync<string>(
                sql, new { finals = finalStatuses.ToList() }, commandTimeout: 60)).ToList();
        }

    }
}
