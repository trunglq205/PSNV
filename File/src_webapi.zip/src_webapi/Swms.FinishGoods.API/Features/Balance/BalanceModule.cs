using Swms.FinishGoods.API.Features.Balance.Business;
using Swms.FinishGoods.API.Features.Balance.DataAccess;

namespace Swms.FinishGoods.API.Features.Balance;

public static class BalanceModule
{
    public static IServiceCollection AddBalanceFeature(this IServiceCollection services)
    {
        services.AddScoped<IBalanceService, BalanceService>();
        services.AddScoped<IBalanceRepository, BalanceRepository>();
        return services;
    }
}
