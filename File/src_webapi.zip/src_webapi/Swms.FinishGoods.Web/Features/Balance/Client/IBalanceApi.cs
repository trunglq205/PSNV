using Refit;
using Swms.FinishGoods.Web.Features.Balance.Business.Models;

namespace Swms.FinishGoods.Web.Features.Balance.Client;

public interface IBalanceApi
{
    [Get("/api/balance/docs")]
    Task<List<BalanceDocSummaryDto>> GetDocsAsync([Query] string? status);

    [Get("/api/balance/docs/{id}")]
    Task<BalanceDocDetailDto> GetDocAsync(long id);

    [Post("/api/balance/docs/{docId}/lines/{lineId}/resolution")]
    Task SetLineAsync(long docId, long lineId, [Body] SetResolutionRequestDto req);

    [Post("/api/balance/docs/{docId}/lines/resolution")]
    Task SetLinesAsync(long docId, [Body] BulkResolutionRequestDto req);

    [Post("/api/balance/docs/{id}/issue-fa")]
    Task<IssueFaResultDto> IssueFaAsync(long id);
}
