﻿using Swms.FinishGoods.Web.Shared.Auth;

namespace Swms.FinishGoods.Web.Shared.App.Layout;

// Perms đảo lên trước Icon để dễ đọc khi khai báo NavItem
public record NavItem(string Label, string Href, string[] Perms, string Icon);
public record Cluster(string Name, string? Step, NavItem[] Items);

public class NavRegistry
{
    public IReadOnlyList<Cluster> Clusters { get; }

    // route -> (clusterKey, pageKey), build 1 lần từ Clusters
    public IReadOnlyDictionary<string, (string? Cluster, string Page)> Map { get; }

    public NavRegistry()
    {
        Clusters = BuildClusters();
        Map = Clusters
            .SelectMany(c => c.Items.Select(it => (it.Href, c.Name, it.Label)))
            .ToDictionary(
                x => x.Href,
                x => ((string?)(x.Name == "Nav.Cluster.Overview" ? null : x.Name), x.Label));
    }

    // Shorthand: enum(s) -> string[]
    private static string[] P(params Perms[] perms) => PermsExtensions.Keys(perms);

    // Không cần quyền -> luôn hiện
    private static readonly string[] Public = Array.Empty<string>();

    private static string Ic(string path)
        => $"<svg viewBox=\"0 0 24 24\" fill=\"none\" stroke=\"currentColor\" stroke-width=\"2\" stroke-linecap=\"round\" stroke-linejoin=\"round\">{path}</svg>";

    private static Cluster[] BuildClusters() => new[]
    {
        new Cluster("Nav.Cluster.Overview", null, new[]
        {
            new NavItem("Nav.Home",  "",  Public,
                Ic("<rect x='3' y='3' width='7' height='9'/><rect x='14' y='3' width='7' height='5'/><rect x='14' y='12' width='7' height='9'/><rect x='3' y='16' width='7' height='5'/>")),
        }),

        new Cluster("Nav.Cluster.Receiving", "1", new[]
        {
            new NavItem("Nav.PartCard", "part-cards", P(Perms.part_card_view),
                Ic("<rect x='3' y='4' width='18' height='16' rx='2'/><path d='M7 8h6M7 12h6M7 16h4'/><rect x='15' y='13' width='4' height='4' rx='0.5'/>")),
            
            new NavItem("Nav.PartCardHistory", "part-card-histories", P(Perms.part_card_view),
                Ic("<path d='M3 12a9 9 0 1 0 3-6.7'/><path d='M3 4v4h4'/><path d='M12 7v5l3 2'/>")),

            new NavItem("Nav.ReceivingMap",   "receiving-map",   P(Perms.temploc_view),
                Ic("<path d='M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z'/><circle cx='12' cy='10' r='3'/>")),

            new NavItem("Nav.AbnormalReport",  "abnormal-report",  P(Perms.abnormal_report_view),
                Ic("<path d='M21 16V8a2 2 0 00-1-1.7l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.7l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z'/><path d='M9 9l6 6M15 9l-6 6'/>")),

            new NavItem("Nav.ReworkRefurbish",    "rework-refurbish",    P(Perms.rework_refurbish_view),
                Ic("<path d='M23 4v6h-6'/><path d='M20.49 15a9 9 0 11-2.12-9.36L23 10'/>")),
        }),

        new Cluster("Nav.Cluster.Storage", "2", new[]
        {
            new NavItem("Nav.Inventory",    "inventory", P(Perms.inventory_view),
                Ic("<path d='M21 16V8a2 2 0 00-1-1.7l-7-4a2 2 0 00-2 0l-7 4A2 2 0 003 8v8a2 2 0 001 1.7l7 4a2 2 0 002 0l7-4A2 2 0 0021 16z'/>")),

            new NavItem("Nav.WarehouseMap", "storage-map",      P(Perms.map_view),
                Ic("<rect x='3' y='3' width='7' height='7'/><rect x='14' y='3' width='7' height='7'/><rect x='3' y='14' width='7' height='7'/><rect x='14' y='14' width='7' height='7'/>")),

            new NavItem("Nav.StockCheck",   "kiemke",   P(Perms.stocktake_view),
                Ic("<path d='M9 11l3 3 8-8'/><path d='M20 12v7a2 2 0 01-2 2H6a2 2 0 01-2-2V6a2 2 0 012-2h9'/>")),

            new NavItem("Nav.StockBalance", "canbang",  P(Perms.balance_view),
                Ic("<path d='M12 3v18'/><path d='M3 7h18'/><path d='M6.5 7L3 13a3 3 0 006 0z'/><path d='M17.5 7L21 13a3 3 0 01-6 0z'/>")),
        }),

        new Cluster("Nav.Cluster.Shipping", "3", new[]
        {
            new NavItem("Nav.SI",          "shipment-instructions",           P(Perms.si_view),
                Ic("<path d='M14 3v6h6M14 3l6 6v12a2 2 0 01-2 2H6a2 2 0 01-2-2V5a2 2 0 012-2z'/>")),

            new NavItem("Nav.Shortage",    "shortages",     P(Perms.shortage_view),
                Ic("<path d='M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z'/><path d='M12 9v4M12 17h.01'/>")),

            new NavItem("Nav.VanningMap", "vanning-map", P(Perms.map_view),
                Ic("<path d='M1 6v16l7-3 8 3 7-3V3l-7 3-8-3-7 3z'/><path d='M8 3v16M16 6v16'/>")),
        }),

        new Cluster("Nav.Cluster.Transport", "4", new[]
        {
            new NavItem("Nav.Stowage",   "stowage-plans",   P(Perms.stowage_view),
                Ic("<rect x='3' y='3' width='7' height='7'/><rect x='14' y='3' width='7' height='7'/><rect x='3' y='14' width='7' height='7'/><rect x='14' y='14' width='7' height='7'/>")),

            new NavItem("Nav.Trips", "shipment-trips", P(Perms.container_view),
                Ic("<rect x='3' y='6' width='18' height='13' rx='1'/><path d='M7 6v13M11 6v13M15 6v13M19 6v13'/>")),
        }),

        new Cluster("Nav.Cluster.Analytics", null, new[]
        {
            new NavItem("Nav.Reports", "reports", P(Perms.reports_view),
                Ic("<path d='M3 3v18h18'/><path d='M7 14l4-4 4 4 6-6'/>")),
        }),

        new Cluster("Nav.Cluster.Config", null, new[]
        {
            new NavItem("Nav.MapDesign", "map-designer", P(Perms.map_edit),
                Ic("<path d='M12 20h9'/><path d='M16.5 3.5a2.121 2.121 0 013 3L7 19l-4 1 1-4L16.5 3.5z'/>")),

            new NavItem("Nav.Models", "master/models", P(Perms.models_view),
                Ic("<path d='M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z'/><polyline points='3.27 6.96 12 12.01 20.73 6.96'/><line x1='12' y1='22.08' x2='12' y2='12'/>")),

            new NavItem("Nav.Users",      "users",    P(Perms.users_view),
                Ic("<circle cx='9' cy='8' r='4'/><path d='M3 21a6 6 0 0112 0'/><circle cx='17' cy='9' r='3'/><path d='M21 21a4 4 0 00-7-2.6'/>")),

            new NavItem("Nav.Roles",      "roles",    P(Perms.roles_view),
                Ic("<path d='M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z'/><path d='M9 12l2 2 4-4'/>")),

            new NavItem("Nav.Settings",   "settings", P(Perms.settings_view),
                Ic("<circle cx='12' cy='12' r='3'/><path d='M19.4 15a1.65 1.65 0 00.33 1.82l.06.06a2 2 0 01-2.83 2.83l-.06-.06a1.65 1.65 0 00-1.82-.33 1.65 1.65 0 00-1 1.51V21a2 2 0 01-4 0v-.09A1.65 1.65 0 009 19.4a1.65 1.65 0 00-1.82.33l-.06.06a2 2 0 01-2.83-2.83l.06-.06a1.65 1.65 0 00.33-1.82 1.65 1.65 0 00-1.51-1H3a2 2 0 010-4h.09A1.65 1.65 0 004.6 9a1.65 1.65 0 00-.33-1.82l-.06-.06a2 2 0 012.83-2.83l.06.06a1.65 1.65 0 001.82.33H9a1.65 1.65 0 001-1.51V3a2 2 0 014 0v.09a1.65 1.65 0 001 1.51 1.65 1.65 0 001.82-.33l.06-.06a2 2 0 012.83 2.83l-.06.06a1.65 1.65 0 00-.33 1.82V9a1.65 1.65 0 001.51 1H21a2 2 0 010 4h-.09a1.65 1.65 0 00-1.51 1z'/>")),
        }),
    };
}