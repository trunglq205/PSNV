using System.Globalization;
using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Sync.DataAccess;

/// <summary>
/// Mốc đã đồng bộ tới (watermark), lưu trong master.configs dạng key/value.
/// Key dùng: <c>hdsoft.last_movement</c> — xoá/để trống giá trị = lần bấm sau quét toàn bộ.
/// </summary>
public interface ISyncStateRepository
{
    Task<DateTime?> GetWatermarkAsync(string key);
    Task SetWatermarkAsync(string key, DateTime value);
}

public sealed class SyncStateRepository : ISyncStateRepository
{
    /// <summary>
    /// config_value là chuỗi -> ghi theo định dạng cố định, không phụ thuộc culture của server.
    /// Giữ 6 chữ số lẻ: M_Transaction.Created (Postgres timestamp) có độ chính xác micro giây.
    /// </summary>
    private const string Format = "yyyy-MM-dd HH:mm:ss.ffffff";

    private readonly IDbConnectionFactory _factory;

    public SyncStateRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<DateTime?> GetWatermarkAsync(string key)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT TOP 1 config_value
            FROM master.configs
            WHERE config_key = @key AND is_deleted = 0;
            """;
        var raw = await conn.ExecuteScalarAsync<string?>(sql, new { key });

        // Giá trị rỗng / sai định dạng (ai đó sửa tay) -> coi như chưa có mốc -> quét toàn bộ.
        // Kind = Unspecified: giờ của HD soft (timestamp không múi giờ), để Npgsql không quy đổi.
        return DateTime.TryParseExact(
                (raw ?? "").Trim(), Format, CultureInfo.InvariantCulture, DateTimeStyles.None, out var value)
            ? DateTime.SpecifyKind(value, DateTimeKind.Unspecified)
            : null;
    }

    public async Task SetWatermarkAsync(string key, DateTime value)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.configs
            SET config_value = @value,
                updated_at   = SYSDATETIME(),
                updated_by   = @user
            WHERE config_key = @key AND is_deleted = 0;

            IF @@ROWCOUNT = 0
                INSERT INTO master.configs
                    (config_key, config_value, description, is_deleted, created_at, created_by)
                VALUES
                    (@key, @value, N'Mốc đồng bộ HD soft — xoá giá trị để lần sau quét toàn bộ',
                     0, SYSDATETIME(), @user);
            """;
        await conn.ExecuteAsync(sql, new
        {
            key,
            value = value.ToString(Format, CultureInfo.InvariantCulture),
            user = "SYNC",
        });
    }
}
