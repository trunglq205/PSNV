import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';

/// 3 màn "quét pallet → chọn hành động → quét vị trí → xác nhận" chỉ khác nhau
/// ở: dữ liệu nạp thêm, hành động được phép hiện, và chữ trên màn.
/// Gom thành 1 enum để dùng chung 1 notifier + 1 body.
enum PalletFlow {
  /// Vị trí tạm: gán / rời / chuyển.
  tempLocation,

  /// Lưu kho: chỉ "store", có gợi ý vị trí.
  storing,

  /// Chuyển / Out (pallet đã lưu kho): move, bỏ assign.
  warehouseMove,

  /// Khu tập kết (vanning): đưa pallet đã soạn ra khu chờ đóng cont.
  /// Chỉ gán / chuyển vào vị trí — không lưu kho, không rời vị trí.
  vanningArea;

  /// Dữ liệu cần nạp thêm khi lookup ở bước 1.
  ///
  /// Storing KHÔNG còn `PalletInclude.suggestion`: gợi ý vị trí đã tách sang
  /// `GET by-lot-no/{lotNo}/storage-suggestion` vì cần thêm chiều cao pallet.
  Set<PalletInclude> get include => const {};

  /// Màn này có gọi API gợi ý vị trí lưu kho hay không.
  bool get needsStorageSuggestion => this == PalletFlow.storing;

  /// Loại khu (`warehouse_areas.map_type`) MẶC ĐỊNH của màn.
  ///
  /// Chỉ còn dùng làm phương án dự phòng khi chưa chọn hành động. Khu đích
  /// THẬT bám theo HÀNH ĐỘNG (xem [PalletActionArea.mapType]), không theo màn:
  /// một màn có thể có hai hành động đi về hai khu khác nhau — màn Chuyển / Out
  /// vừa chuyển nội bộ trong kho (storing), vừa out hàng RW/RB ra khu nhận
  /// hàng để giao FA (receiving).
  String get mapType => switch (this) {
    PalletFlow.tempLocation => 'receiving',
    PalletFlow.storing => 'storing',
    PalletFlow.warehouseMove => 'storing',
    PalletFlow.vanningArea => 'vanning',
  };

  /// Lọc `allowedActions` của server theo màn.
  List<PalletAction> actionsFor(Pallet p) {
    final wanted = switch (this) {
      PalletFlow.tempLocation => {
        PalletAction.assign,
        PalletAction.moveReceiving,
      },
      PalletFlow.storing => {PalletAction.store},
      // moveReceiving ở màn này KHÔNG thành một nút riêng (xem phần gộp bên
      // dưới): nó chỉ nói "pallet này chuyển được sang khu Nhận hàng", tức là
      // mở rộng KHU ĐƯỢC PHÉP của nút Chuyển. Server chỉ trả action này cho
      // hàng RW/RB nên hàng thường không bị ảnh hưởng.
      // release: OUT KHO cho mọi loại hàng — pallet rời vị trí, không nằm ở ô nào.
      // release: OUT KHO cho MỌI loại hàng — pallet rời vị trí và không nằm ở
      // ô nào. Đặt ở màn này vì đây là màn của pallet đang nằm trong kho.
      PalletFlow.warehouseMove => {
        PalletAction.moveStoring,
        PalletAction.moveReceiving,
        PalletAction.release,
      },
      PalletFlow.vanningArea => {
        PalletAction.vanning,
        PalletAction.moveVanning,
      },
    };
    final list = p.allowedActions.where(wanted.contains).toList();

    // GỘP: trong kho chỉ có MỘT việc "chuyển vị trí". Hàng RW/RB chuyển được
    // sang cả khu Nhận hàng, nhưng đó vẫn là chuyển vị trí — không phải một
    // thao tác khác. Để hai nút cạnh nhau là bắt người quét phải tự biết vị
    // trí mình sắp quét thuộc khu nào TRƯỚC khi quét, và bấm sai thì ăn lỗi
    // "không đúng khu". Khu được phép giờ nằm ở [areasFor].
    if (this == PalletFlow.warehouseMove &&
        list.contains(PalletAction.moveStoring) &&
        list.contains(PalletAction.moveReceiving)) {
      list.remove(PalletAction.moveReceiving);
    }

    return list;
  }

  /// Những khu (`warehouse_areas.map_type`) mà vị trí quét vào được phép thuộc,
  /// cho hành động [a] trên pallet [p].
  ///
  /// MỘT HÀNH ĐỘNG CÓ THỂ NHẬN NHIỀU KHU. Màn Chuyển / Out với pallet hàng
  /// RW/RB nhận cả `storing` (xếp lại trong kho) và `receiving` (đưa ra khu
  /// Nhận hàng — server tự chuyển trạng thái phiếu sang đã giao FA). Biết điều
  /// đó bằng chính `allowedActions` của server, KHÔNG tự đọc `disposition` ở
  /// client: cùng một nguồn sự thật với cổng chặn.
  Set<String> areasFor(PalletAction a, Pallet p) {
    final areas = <String>{};

    final own = a.mapType;
    if (own != null) areas.add(own);

    if (this == PalletFlow.warehouseMove &&
        a == PalletAction.moveStoring &&
        p.allowedActions.contains(PalletAction.moveReceiving)) {
      areas.add('receiving');
    }

    return areas;
  }
}

/// Khu đích của từng hành động.
///
/// Đây mới là nguồn sự thật cho "vị trí quét vào phải thuộc khu nào", chứ
/// không phải [PalletFlow.mapType]: cùng một màn có thể có hai hành động đi về
/// hai khu khác nhau.
extension PalletActionArea on PalletAction {
  /// null = hành động KHÔNG có vị trí đích (out kho), nên không có khu nào để
  /// đối chiếu. Khai `String?` chứ không trả một chuỗi bừa: trả 'storing' cho
  /// out kho là lại dựng đúng cái bẫy "khu của màn" mà extension này sinh ra
  /// để dẹp.
  String? get mapType => switch (this) {
    PalletAction.assign => 'receiving',
    PalletAction.moveReceiving => 'receiving',
    PalletAction.store => 'storing',
    PalletAction.moveStoring => 'storing',
    PalletAction.vanning => 'vanning',
    PalletAction.moveVanning => 'vanning',
    PalletAction.release => null,
  };
}
