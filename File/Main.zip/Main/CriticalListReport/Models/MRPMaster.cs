﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("MRPMaster")]
    public class MRPMaster
    {
        public int ID { get; set; }
        public string? MRPC { get; set; }
        public string? MRPName { get; set; }
    }
}
