﻿using Dapper;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.AbnormalReports.DataAccess;

public class NgReportRepository : INgReportRepository
{
    private readonly IDbConnectionFactory _factory;
    public NgReportRepository(IDbConnectionFactory factory) => _factory = factory;

    // Phiếu + thông tin pallet + số liệu tổng hợp (dùng chung cho danh sách & chi tiết)
    private const string HeaderSelect = """
        SELECT n.id AS [Id], n.doc_no AS [DocNo], n.lot_id AS [LotId],
               RTRIM(p.pallet_id) AS [PalletCode],
               -- Pallet serial / box_line KHÔNG ghi cột pallets.model (model nằm
               -- ở box_lines), nên đọc thẳng p.model làm phiếu NG của hai loại
               -- đó trống cột Model — cả trên màn hình, file Excel và mail.
               -- Cùng quy ước COALESCE với LocationInfoSql.
               COALESCE(
                   (SELECT STRING_AGG(z.model, ', ')
                    FROM (SELECT DISTINCT bl.model
                          FROM wms.boxes bx
                          JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                          WHERE bx.lot_id = p.id AND bx.is_deleted = 0) z),
                   p.model) AS [Model],
               RTRIM(p.category_id) AS [CategoryCode],
               cat.name AS [CategoryName],
               n.ng_type AS [NgType], n.description AS [Description], n.discovered_at AS [DiscoveredAt],
               n.doc_status AS [DocStatus], n.current_step AS [CurrentStep],
               n.leader_status AS [LeaderStatus], n.leader_by AS [LeaderBy],
               n.leader_by_code AS [LeaderByCode], n.leader_at AS [LeaderAt],
               n.leader_comment AS [LeaderComment],
               n.fa_status AS [FaStatus], n.fa_result AS [FaResult],
               n.fa_resolution AS [FaResolution], n.fa_by AS [FaBy],
               n.fa_at AS [FaAt], n.fa_comment AS [FaComment],
               n.review_round AS [ReviewRound],
               n.pallet_status_before AS [PalletStatusBefore],
               n.oqc_status AS [OqcStatus], n.oqc_by AS [OqcBy], n.oqc_at AS [OqcAt],
               n.oqc_comment AS [OqcComment],
               n.resolution AS [Resolution], n.finalized_by AS [FinalizedBy],
               n.finalized_at AS [FinalizedAt], n.final_comment AS [FinalComment],
               n.cancelled_by AS [CancelledBy], n.cancelled_at AS [CancelledAt],
               n.cancel_reason AS [CancelReason],
               n.created_at AS [CreatedAt], n.created_by AS [CreatedBy],
               ISNULL(it.item_count, 0) AS [ItemCount], ISNULL(it.qty_affected, 0) AS [QtyAffected],
               ISNULL(it.whole_pallet, 0) AS [IsWholePallet],
               ISNULL(ph.photo_count, 0) AS [PhotoCount]
        FROM wms.ng_inspections n
        LEFT JOIN wms.pallets p ON p.id = n.lot_id
        -- Ten cate de hien ra man hinh; LEFT JOIN vi pallet co the mang ma cate
        -- chua khai trong master.categories, luc do CategoryName = NULL va man
        -- hinh tu quay ve hien ma. Dung LEFT JOIN thang nhu moi feature khac
        -- (master.categories.code la ma duy nhat, khac master.models.code).
        LEFT JOIN master.categories cat ON cat.code = p.category_id
        OUTER APPLY (
            -- whole_pallet: MIN tren 0/1 nen chi bang 1 khi MOI muc deu la
            -- scope='pallet'. Phieu khong co muc nao -> MIN tra NULL -> ISNULL = 0.
            SELECT COUNT(*) AS item_count, SUM(i.qty_affected) AS qty_affected,
                   MIN(CASE WHEN i.scope = N'pallet' THEN 1 ELSE 0 END) AS whole_pallet
            FROM wms.ng_inspection_items i WHERE i.ng_id = n.id AND i.is_deleted = 0
        ) it
        OUTER APPLY (
            SELECT COUNT(*) AS photo_count
            FROM wms.ng_inspection_photos f WHERE f.ng_id = n.id AND f.is_deleted = 0
        ) ph
        """;

    public async Task<IReadOnlyList<NgReport>> GetListAsync(
        string? status, string? ngType, DateTime? from, DateTime? to, string? keyword)
    {
        // Phải có xuống dòng: chuỗi thô không giữ ký tự cuối, nối thẳng sẽ ra ") phWHERE"
        var sql = HeaderSelect + "\n" + """
            WHERE n.is_deleted = 0
              AND (@status  IS NULL OR n.doc_status = @status)
              AND (@ngType  IS NULL OR n.ng_type = @ngType)
              AND (@from    IS NULL OR n.discovered_at >= @from)
              AND (@to      IS NULL OR n.discovered_at < DATEADD(day, 1, @to))
              AND (@kw      IS NULL OR n.doc_no LIKE @kw OR RTRIM(p.pallet_id) LIKE @kw OR p.model LIKE @kw)
            ORDER BY n.discovered_at DESC, n.id DESC;
            """;
        using var conn = _factory.Create();
        return (await conn.QueryAsync<NgReport>(sql, new
        {
            status, ngType, from, to,
            kw = string.IsNullOrWhiteSpace(keyword) ? null : $"%{keyword.Trim()}%"
        })).ToList();
    }

    public async Task<NgReportDetail?> GetAsync(long id)
    {
        using var conn = _factory.Create();

        var header = await conn.QuerySingleOrDefaultAsync<NgReport>(
            HeaderSelect + " WHERE n.id = @id AND n.is_deleted = 0;", new { id });
        if (header is null) return null;

        var items = (await conn.QueryAsync<NgItem>("""
            SELECT i.id AS [Id], i.ng_id AS [NgId], i.scope AS [Scope], i.pallet_id AS [PalletId],
                   i.box_id AS [BoxId], i.box_line_id AS [BoxLineId], i.code AS [Code],
                   i.qty_affected AS [QtyAffected], i.note AS [Note]
            FROM wms.ng_inspection_items i
            WHERE i.ng_id = @id AND i.is_deleted = 0
            ORDER BY i.id;
            """, new { id })).ToList();

        var photos = (await conn.QueryAsync<NgPhoto>("""
            SELECT f.id AS [Id], f.ng_id AS [NgId], f.item_id AS [ItemId], f.file_path AS [FilePath],
                   f.file_name AS [FileName], f.content_type AS [ContentType], f.size_bytes AS [SizeBytes],
                   f.caption AS [Caption], f.sort_order AS [SortOrder]
            FROM wms.ng_inspection_photos f
            WHERE f.ng_id = @id AND f.is_deleted = 0
            ORDER BY f.sort_order, f.id;
            """, new { id })).ToList();

        var approvals = (await conn.QueryAsync<NgApproval>("""
            SELECT a.id AS [Id], a.ng_id AS [NgId], a.step AS [Step], a.action AS [Action],
                   a.resolution AS [Resolution], a.comment AS [Comment],
                   a.acted_by AS [ActedBy], a.acted_at AS [ActedAt]
            FROM wms.ng_inspection_approvals a
            WHERE a.ng_id = @id
            ORDER BY a.acted_at, a.id;
            """, new { id })).ToList();

        return new NgReportDetail { Header = header, Items = items, Photos = photos, Approvals = approvals };
    }

    /// <summary>Tra pallet theo mã quét. Null = không có hoặc đã xoá.</summary>
    public async Task<long?> FindPalletAsync(string palletCode)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<long?>(
            "SELECT TOP 1 id FROM wms.pallets WHERE RTRIM(pallet_id) = @palletCode AND is_deleted = 0;",
            new { palletCode });
    }

    /// <summary>
    /// Tra pallet để PDA xác nhận ngay lúc quét: null = không có hoặc đã xoá.
    /// Dùng CHÍNH điều kiện của <see cref="FindPalletAsync"/> nên màn quét và
    /// lúc tạo phiếu không bao giờ lệch kết luận.
    /// </summary>
    public async Task<NgPalletBrief?> FindPalletBriefAsync(string palletCode)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<NgPalletBrief>("""
            SELECT TOP 1 p.id              AS [Id],
                   RTRIM(p.pallet_id)      AS [Code],
                   -- Xem chú thích ở HeaderSelect.
                   COALESCE(
                       (SELECT STRING_AGG(z.model, ', ')
                        FROM (SELECT DISTINCT bl.model
                              FROM wms.boxes bx
                              JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                              WHERE bx.lot_id = p.id AND bx.is_deleted = 0) z),
                       p.model)            AS [Model],
                   p.box_count             AS [BoxCount],
                   p.inspection_status     AS [InspectionStatus],
                   ISNULL(p.is_urgent, 0)  AS [IsUrgent],
                   p.production_date       AS [ProductionDate],
                   l.locator_code          AS [LocatorCode],
                   a.area_name             AS [AreaName]
            FROM   wms.pallets p
            LEFT JOIN master.locators        l ON l.id = p.locator_id
            LEFT JOIN master.warehouse_areas a ON a.id = l.area_id
            WHERE  RTRIM(p.pallet_id) = @palletCode AND p.is_deleted = 0
            ORDER BY p.id DESC;
            """, new { palletCode });
    }

    /// <summary>Tạo phiếu nháp kèm các dòng phạm vi ảnh hưởng. Trả id + số phiếu.</summary>
    public async Task<(long Id, string DocNo)> CreateAsync(NgReport header, IReadOnlyList<NgItem> items, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // NG-yyyyMMdd-nnn, nnn chạy lại mỗi ngày
            var today = header.DiscoveredAt.Date;
            var seq = await conn.ExecuteScalarAsync<int>("""
                SELECT ISNULL(MAX(TRY_CAST(RIGHT(doc_no, 3) AS int)), 0) + 1
                FROM wms.ng_inspections
                WHERE doc_no LIKE @prefix + '%';
                """, new { prefix = $"NG-{today:yyyyMMdd}-" }, tx);
            var docNo = $"NG-{today:yyyyMMdd}-{seq:000}";

            var id = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.ng_inspections
                    (doc_no, lot_id, ng_type, description, discovered_at,
                     doc_status, current_step, created_at, created_by, updated_at, updated_by)
                OUTPUT INSERTED.id
                VALUES (@docNo, @lotId, @ngType, @description, @discoveredAt,
                        N'draft', N'created', SYSDATETIME(), @user, SYSDATETIME(), @user);
                """, new
            {
                docNo, lotId = header.LotId, ngType = header.NgType,
                description = header.Description, discoveredAt = header.DiscoveredAt, user
            }, tx);

            foreach (var it in items)
            {
                await conn.ExecuteAsync("""
                    INSERT INTO wms.ng_inspection_items
                        (ng_id, scope, pallet_id, box_id, box_line_id, code, qty_affected, note,
                         is_deleted, created_at, created_by)
                    VALUES (@ngId, @scope, @palletId, @boxId, @boxLineId, @code, @qty, @note,
                            0, SYSDATETIME(), @user);
                    """, new
                {
                    ngId = id, scope = it.Scope, palletId = it.PalletId, boxId = it.BoxId,
                    boxLineId = it.BoxLineId, code = it.Code, qty = it.QtyAffected, note = it.Note, user
                }, tx);
            }

            tx.Commit();
            return (id, docNo);
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>
    /// Sửa phiếu nháp: cập nhật loại lỗi + mô tả, và thay toàn bộ danh sách phạm vi
    /// ảnh hưởng. Trả false nếu phiếu không còn ở trạng thái nháp.
    /// </summary>
    public async Task<bool> UpdateDraftAsync(long id, string ngType, string? description,
        IReadOnlyList<NgItem> items, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var rows = await conn.ExecuteAsync("""
                UPDATE wms.ng_inspections
                SET ng_type = @ngType, description = @description,
                    updated_at = SYSDATETIME(), updated_by = @user
                WHERE id = @id AND is_deleted = 0 AND doc_status = N'draft';
                """, new { id, ngType, description, user }, tx);

            if (rows == 0) { tx.Rollback(); return false; }

            // Thay cả danh sách cho đơn giản: phiếu nháp chưa ai duyệt nên không mất vết gì.
            await conn.ExecuteAsync(
                "UPDATE wms.ng_inspection_items SET is_deleted = 1 WHERE ng_id = @id AND is_deleted = 0;",
                new { id }, tx);

            foreach (var it in items)
            {
                await conn.ExecuteAsync("""
                    INSERT INTO wms.ng_inspection_items
                        (ng_id, scope, pallet_id, box_id, box_line_id, code, qty_affected, note,
                         is_deleted, created_at, created_by)
                    VALUES (@id, @scope, @palletId, @boxId, @boxLineId, @code, @qty, @note,
                            0, SYSDATETIME(), @user);
                    """, new
                {
                    id, scope = it.Scope, palletId = it.PalletId, boxId = it.BoxId,
                    boxLineId = it.BoxLineId, code = it.Code, qty = it.QtyAffected, note = it.Note, user
                }, tx);
            }

            tx.Commit();
            return true;
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>Xoá mềm 1 ảnh; chỉ khi phiếu còn nháp. File trên đĩa giữ lại.</summary>
    public async Task<bool> DeletePhotoAsync(long photoId, string? user)
    {
        using var conn = _factory.Create();
        var rows = await conn.ExecuteAsync("""
            UPDATE f
            SET f.is_deleted = 1
            FROM wms.ng_inspection_photos f
            JOIN wms.ng_inspections n ON n.id = f.ng_id
            WHERE f.id = @photoId AND f.is_deleted = 0 AND n.doc_status = N'draft';
            """, new { photoId, user });
        return rows > 0;
    }

    public async Task AddPhotoAsync(NgPhoto photo, string? user)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            INSERT INTO wms.ng_inspection_photos
                (ng_id, item_id, file_path, file_name, content_type, size_bytes, caption, sort_order,
                 is_deleted, created_at, created_by)
            VALUES (@NgId, @ItemId, @FilePath, @FileName, @ContentType, @SizeBytes, @Caption,
                    (SELECT ISNULL(MAX(sort_order), 0) + 1 FROM wms.ng_inspection_photos WHERE ng_id = @NgId),
                    0, SYSDATETIME(), @user);
            """, new
        {
            photo.NgId, photo.ItemId, photo.FilePath, photo.FileName,
            photo.ContentType, photo.SizeBytes, photo.Caption, user
        });
    }

    public async Task<int> CountPhotosAsync(long ngId)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM wms.ng_inspection_photos WHERE ng_id = @ngId AND is_deleted = 0;",
            new { ngId });
    }

    /// <summary>1 ảnh theo id — để trả file về cho người xem.</summary>
    public async Task<NgPhoto?> GetPhotoAsync(long photoId)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<NgPhoto>("""
            SELECT id AS [Id], ng_id AS [NgId], item_id AS [ItemId], file_path AS [FilePath],
                   file_name AS [FileName], content_type AS [ContentType], size_bytes AS [SizeBytes],
                   caption AS [Caption], sort_order AS [SortOrder]
            FROM wms.ng_inspection_photos
            WHERE id = @photoId AND is_deleted = 0;
            """, new { photoId });
    }

    /// <summary>Lấy trạng thái hiện tại để kiểm tra bước nào được phép thao tác.</summary>
    public async Task<NgReport?> GetHeaderAsync(long id)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<NgReport>(
            HeaderSelect + " WHERE n.id = @id AND n.is_deleted = 0;", new { id });
    }

    /// <summary>
    /// Ghi 1 bước duyệt: cập nhật cột trạng thái tương ứng + thêm dòng nhật ký,
    /// rồi tính lại doc_status/current_step theo tiến độ của cả 3 bên.
    /// </summary>
    /// <param name="user">Tên hiển thị, ghi vào *_by để hiện ra giao diện.</param>
    /// <param name="userCode">
    /// Mã nhân viên, chỉ ghi ở bước leader (leader_by_code). Dùng cho phép so
    /// "người chốt có phải chính người duyệt bước 2" — so bằng mã mới chắc.
    /// </param>
    public async Task ApplyStepAsync(long id, string step, string action,
        string? resolution, string? comment, string? user, string? userCode = null,
        bool skipOqc = false)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var sql = step switch
            {
                // Bỏ OQC được CHỐT NGAY TẠI ĐÂY, không tra lại lúc hiển thị:
                // phiếu giữ đúng lịch sử khi quy tắc đổi về sau, và vì 'skipped'
                // khác 'pending' nên mọi guard tuần tự phía sau tự đúng —
                // FaConfirmAsync và câu tính lại current_step không phải sửa.
                "leader" when action == "submit" => """
                    UPDATE wms.ng_inspections
                    SET leader_status = N'submitted', leader_by = @user,
                        leader_by_code = @userCode, leader_at = SYSDATETIME(),
                        leader_comment = @comment, doc_status = N'in_review',
                        oqc_status   = CASE WHEN @skipOqc = 1 THEN N'skipped' ELSE oqc_status END,
                        current_step = CASE WHEN @skipOqc = 1 THEN N'fa_confirm' ELSE N'oqc_confirm' END,
                        updated_at = SYSDATETIME(), updated_by = @user
                    WHERE id = @id;
                    """,

                // FA kết luận OK.
                //
                // ⚠ Mọi CASE dưới đây đọc GIÁ TRỊ CŨ của oqc_status, kể cả khi
                // chính câu này đang gán lại nó — SQL Server tính hết vế phải
                // trên ảnh chụp trước khi ghi. Nhờ vậy một câu UPDATE vừa đọc
                // được "OQC đã nói gì" vừa đặt lại được trạng thái mới.
                //
                // OQC đã NG mà FA bảo OK ⇒ ngược nhau ⇒ trả về cho OQC đánh
                // giá lại, tăng số vòng. OQC OK hoặc không cần OQC ⇒ thống
                // nhất ⇒ ĐÓNG PHIẾU ngay tại đây, không còn ai phải bấm chốt.
                "fa" when action == "ok" => """
                    UPDATE wms.ng_inspections
                    SET fa_status = N'approved', fa_result = N'ok', fa_by = @user,
                        fa_at = SYSDATETIME(), fa_comment = @comment,
                        oqc_status   = CASE WHEN oqc_status = N'ng' THEN N'pending' ELSE oqc_status END,
                        review_round = CASE WHEN oqc_status = N'ng' THEN review_round + 1 ELSE review_round END,
                        doc_status   = CASE WHEN oqc_status = N'ng' THEN N'in_review' ELSE N'finalized' END,
                        current_step = CASE WHEN oqc_status = N'ng' THEN N'oqc_confirm' ELSE N'done' END,
                        resolution   = CASE WHEN oqc_status = N'ng' THEN resolution
                                            ELSE COALESCE(NULLIF(resolution, N'pending'),
                                                          fa_resolution, N'accept') END,
                        finalized_by = CASE WHEN oqc_status = N'ng' THEN finalized_by ELSE @user END,
                        finalized_at = CASE WHEN oqc_status = N'ng' THEN finalized_at ELSE SYSDATETIME() END,
                        final_comment = CASE WHEN oqc_status = N'ng' THEN final_comment ELSE @comment END,
                        updated_at = SYSDATETIME(), updated_by = @user
                    WHERE id = @id;
                    """,

                // FA kết luận NG: bắt buộc kèm hướng xử lý, rồi phiếu sang
                // bước "FA xử lý". Chưa xử lý xong thì OQC không có gì để
                // đánh giá lại, nên KHÔNG trả về OQC ở đây.
                "fa" => """
                    UPDATE wms.ng_inspections
                    SET fa_status = N'pending', fa_result = N'ng',
                        fa_resolution = @resolution, fa_by = @user,
                        fa_at = SYSDATETIME(), fa_comment = @comment,
                        doc_status = N'in_review', current_step = N'fa_fix',
                        updated_at = SYSDATETIME(), updated_by = @user
                    WHERE id = @id;
                    """,

                // FA báo đã xử lý xong. Người xử lý không tự nghiệm thu được,
                // nên hàng quay lại OQC đánh giá lại — trừ loại lỗi vốn KHÔNG
                // qua OQC (oqc_status = 'skipped'), lúc đó đóng phiếu luôn.
                "fa_fix" => """
                    UPDATE wms.ng_inspections
                    SET fa_status = N'approved', fa_result = N'ok', fa_by = @user,
                        fa_at = SYSDATETIME(), fa_comment = @comment,
                        oqc_status   = CASE WHEN oqc_status = N'skipped' THEN oqc_status ELSE N'pending' END,
                        review_round = CASE WHEN oqc_status = N'skipped' THEN review_round ELSE review_round + 1 END,
                        doc_status   = CASE WHEN oqc_status = N'skipped' THEN N'finalized' ELSE N'in_review' END,
                        current_step = CASE WHEN oqc_status = N'skipped' THEN N'done' ELSE N'oqc_confirm' END,
                        resolution   = CASE WHEN oqc_status = N'skipped'
                                            THEN COALESCE(NULLIF(resolution, N'pending'),
                                                          fa_resolution, N'accept')
                                            ELSE resolution END,
                        finalized_by = CASE WHEN oqc_status = N'skipped' THEN @user ELSE finalized_by END,
                        finalized_at = CASE WHEN oqc_status = N'skipped' THEN SYSDATETIME() ELSE finalized_at END,
                        final_comment = CASE WHEN oqc_status = N'skipped' THEN @comment ELSE final_comment END,
                        updated_at = SYSDATETIME(), updated_by = @user
                    WHERE id = @id;
                    """,
                "leader" => """
                    UPDATE wms.ng_inspections
                    SET leader_status = N'cancelled', leader_by = @user,
                        leader_by_code = @userCode, leader_at = SYSDATETIME(),
                        leader_comment = @comment, doc_status = N'cancelled',
                        cancelled_by = @user, cancelled_at = SYSDATETIME(), cancel_reason = @comment,
                        updated_at = SYSDATETIME(), updated_by = @user
                    WHERE id = @id;
                    """,
                // OQC kết luận. OQC nói OK mà FA đã OK từ vòng trước ⇒ hai bên
                // thống nhất ⇒ đóng luôn, không bắt FA bấm lại một lần nữa chỉ
                // để xác nhận điều họ vừa nói. Mọi trường hợp còn lại: xoá kết
                // luận cũ của FA và trả về cho FA đánh giá lại.
                "oqc" => """
                    UPDATE wms.ng_inspections
                    SET oqc_status = @action, oqc_by = @user, oqc_at = SYSDATETIME(),
                        oqc_comment = @comment,
                        fa_status    = CASE WHEN @action = N'ok' AND fa_result = N'ok'
                                            THEN fa_status ELSE N'pending' END,
                        fa_result    = CASE WHEN @action = N'ok' AND fa_result = N'ok'
                                            THEN fa_result ELSE NULL END,
                        doc_status   = CASE WHEN @action = N'ok' AND fa_result = N'ok'
                                            THEN N'finalized' ELSE N'in_review' END,
                        current_step = CASE WHEN @action = N'ok' AND fa_result = N'ok'
                                            THEN N'done' ELSE N'fa_confirm' END,
                        resolution   = CASE WHEN @action = N'ok' AND fa_result = N'ok'
                                            THEN COALESCE(NULLIF(resolution, N'pending'),
                                                          fa_resolution, N'accept')
                                            ELSE resolution END,
                        finalized_by = CASE WHEN @action = N'ok' AND fa_result = N'ok'
                                            THEN @user ELSE finalized_by END,
                        finalized_at = CASE WHEN @action = N'ok' AND fa_result = N'ok'
                                            THEN SYSDATETIME() ELSE finalized_at END,
                        updated_at = SYSDATETIME(), updated_by = @user
                    WHERE id = @id;
                    """,
                // Mọi bước phải khai tường minh ở trên. Trước đây nhánh này là
                // bước finalize, nghĩa là gõ sai tên bước sẽ ÂM THẦM ĐÓNG PHIẾU.
                // Bước đó bỏ rồi, nên giờ nó nổ — sai thì phải thấy ngay.
                _ => throw new ArgumentOutOfRangeException(
                         nameof(step), step, "Buoc duyet khong hop le.")
            };
            await conn.ExecuteAsync(sql, new { id, action, resolution, comment, user, userCode, skipOqc }, tx);

            await conn.ExecuteAsync("""
                INSERT INTO wms.ng_inspection_approvals (ng_id, step, action, resolution, comment, acted_by, acted_at)
                VALUES (@id, @step, @action, @resolution, @comment, @user, SYSDATETIME());
                """, new { id, step, action, resolution, comment, user }, tx);

            // ── Dấu chất lượng trên PALLET, trong CÙNG transaction ──────
            //
            // Phải cùng transaction với bước duyệt: dấu này gác việc xuất hàng
            // (ShipmentInstructionRepository lọc inspection_status IN
            // ('pass','inspection_exempt')), nên phiếu đã duyệt mà dấu chưa
            // đóng là một khoảng thời gian pallet NG vẫn lên được phiếu xuất.
            //
            // KHÔNG đi qua IPalletService: ở đây không có chuyện đổi vị trí,
            // không sinh sự kiện kho, và gọi sang đó sẽ kéo theo cả cổng duyệt
            // của luồng back hàng — thứ chẳng liên quan gì tới hàng bất thường.
            if (step == "leader" && action == "submit")
            {
                // Nhớ giá trị cũ TRƯỚC rồi mới ghi đè. Làm ngược lại là mất nó,
                // và lúc cần hoàn nguyên thì chỉ còn nước đoán.
                await conn.ExecuteAsync("""
                    UPDATE n
                    SET    n.pallet_status_before =
                               ISNULL(n.pallet_status_before, ISNULL(p.inspection_status, N''))
                    FROM   wms.ng_inspections n
                    JOIN   wms.pallets p ON p.id = n.lot_id AND p.is_deleted = 0
                    WHERE  n.id = @id;

                    UPDATE p
                    SET    p.inspection_status = N'ng',
                           p.updated_at = SYSDATETIME(), p.updated_by = @user
                    FROM   wms.pallets p
                    JOIN   wms.ng_inspections n ON n.lot_id = p.id
                    WHERE  n.id = @id AND p.is_deleted = 0;
                    """, new { id, user }, tx);
            }

            // Phiếu vừa đóng ⇒ trả pallet về 'pass'. Viết điều kiện theo
            // doc_status chứ không theo step: ba nhánh khác nhau đều có thể là
            // nhánh đóng phiếu, và câu này chỉ chạm vào pallet khi phiếu THẬT
            // SỰ đã đóng nên chạy thừa cũng vô hại.
            await conn.ExecuteAsync("""
                UPDATE p
                SET    p.inspection_status = N'pass',
                       p.updated_at = SYSDATETIME(), p.updated_by = @user
                FROM   wms.pallets p
                JOIN   wms.ng_inspections n ON n.lot_id = p.id
                WHERE  n.id = @id AND p.is_deleted = 0
                  AND  n.doc_status = N'finalized';
                """, new { id, user }, tx);

            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<List<MailRecipient>> GetMailRecipientsAsync(
        string eventCode, string? category = null, string? model = null)
    {
        using var conn = _factory.Create();
        // Dùng chung hàm master.fn_email_recipients với các tính năng khác, nên
        // quy tắc phân tầng người nhận (department / sub_code / category /
        // model / area_code) chỉ có MỘT nơi định nghĩa. Phiếu bất thường không
        // Truyền CẢ category và model vào: hàm tra chọn TO theo tầng đặc thù
        // nhất khớp được (model 16 > category 4 > department 1) và cộng dồn
        // CC/BCC. Nhờ vậy "chỉ gửi cho người quản lý cate đó" là chuyện CẤU
        // HÌNH, không phải chuyện code — khai thêm một dòng category là xong.
        //
        // Bảng dẫn xuất d liệt kê CÁC BỘ PHẬN ĐANG ĐƯỢC CẤU HÌNH cho sự kiện
        // này rồi CROSS APPLY vào hàm tra. Làm vậy để danh sách bộ phận nằm
        // trong dữ liệu, KHÔNG nằm trong code: thêm bộ phận thứ ba vào màn Cấu
        // hình email là nó tự nhận mail. DISTINCT để một người được cấu hình ở
        // cả 'OQC' lẫn bộ phận rỗng không bị nhận hai lần.
        const string sql = """
            SELECT DISTINCT
                   r.recipient_type AS Type, r.email AS Email, r.display_name AS DisplayName
            FROM   (SELECT DISTINCT c.department
                    FROM   master.email_config c
                    WHERE  c.event_code = @eventCode
                           AND c.is_active = 1 AND c.is_deleted = 0) d
            CROSS APPLY master.fn_email_recipients(
                            @eventCode, d.department, NULL, @category, @model, NULL) r;
            """;
        var rows = (await conn.QueryAsync<MailRecipient>(sql, new { eventCode, category, model })).ToList();

        // Một ô email được phép chứa NHIỀU địa chỉ, ngăn bởi dấu phẩy hoặc chấm
        // phẩy, để khai theo nhóm thay vì mỗi người một dòng. Tách ngay tại đây
        // chứ không để nguyên cả cụm chuỗi đi tiếp: màn xem trước, phép khử
        // trùng và dòng log đều làm việc trên TỪNG địa chỉ — để nguyên cụm thì
        // cả ba cùng sai, mà không chỗ nào báo lỗi.
        var split = rows
            .Where(r => !string.IsNullOrWhiteSpace(r.Email))
            .SelectMany(r => r.Email
                .Split(new[] { ',', ';' },
                       StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(addr => new MailRecipient
                {
                    Type = (r.Type ?? "TO").Trim().ToUpperInvariant(),
                    Email = addr,
                    DisplayName = r.DisplayName
                }))
            .ToList();

        // Đứng ở TO rồi thì bỏ khỏi CC. Gộp nhóm bằng dấu phẩy làm chuyện trùng
        // nhau xảy ra thường xuyên hơn hẳn — một người vừa nằm trong nhóm OQC
        // vừa nằm trong nhóm SCS là bình thường. Để cả hai thì hộp thư hiện tên
        // họ hai lần, và ý "anh phải xử lý" của dòng TO bị dòng CC làm nhẹ đi.
        var toSet = split.Where(r => r.Type == "TO")
                         .Select(r => r.Email)
                         .ToHashSet(StringComparer.OrdinalIgnoreCase);

        // Sắp TO trước CC trước BCC — sắp ở đây vì DISTINCT không cho ORDER BY
        // theo cột không có trong danh sách chọn.
        return split
            .Where(r => r.Type == "TO" || !toSet.Contains(r.Email))
            .GroupBy(r => (r.Type, Email: r.Email.ToLowerInvariant()))
            .Select(g => g.First())
            .OrderBy(r => r.Type switch { "TO" => 0, "CC" => 1, _ => 2 })
            .ThenBy(r => r.Email, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    public async Task<MailTemplateRow?> GetMailTemplateAsync(string eventCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT subject_template AS [Subject], body_template AS [Body]
            FROM   master.email_events
            WHERE  code = @eventCode AND is_active = 1;
            """;
        return await conn.QuerySingleOrDefaultAsync<MailTemplateRow>(sql, new { eventCode });
    }

    /// <summary>
    /// Các loại lỗi đang dùng được, theo thứ tự hiện trên màn hình. Dùng chung
    /// cho cả danh sách thả xuống lẫn việc kiểm mã hợp lệ — một nguồn duy nhất.
    /// </summary>
    public async Task<List<NgTypeRow>> GetTypesAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT code         AS [Code],
                   name_vi      AS [NameVi], name_en AS [NameEn],
                   name_ja      AS [NameJa], name_zh AS [NameZh],
                   note_vi      AS [NoteVi], note_en AS [NoteEn],
                   note_ja      AS [NoteJa], note_zh AS [NoteZh],
                   requires_oqc AS [RequiresOqc],
                   sort_order   AS [SortOrder]
            FROM   master.ng_types
            WHERE  is_active = 1 AND is_deleted = 0
            ORDER  BY sort_order, code;
            """;
        return (await conn.QueryAsync<NgTypeRow>(sql)).ToList();
    }

    /// <summary>
    /// Danh mục cho màn QUẢN TRỊ: lấy cả loại đang tắt, kèm số phiếu đang dùng.
    ///
    /// Khác <see cref="GetTypesAsync"/> ở chỗ không lọc is_active: người quản
    /// trị phải thấy loại đã ngưng để bật lại được, còn người lập phiếu thì
    /// không nên thấy.
    /// </summary>
    public async Task<List<NgTypeRow>> GetTypesForAdminAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT t.code         AS [Code],
                   t.name_vi      AS [NameVi], t.name_en AS [NameEn],
                   t.name_ja      AS [NameJa], t.name_zh AS [NameZh],
                   t.note_vi      AS [NoteVi], t.note_en AS [NoteEn],
                   t.note_ja      AS [NoteJa], t.note_zh AS [NoteZh],
                   t.requires_oqc AS [RequiresOqc],
                   t.sort_order   AS [SortOrder],
                   t.is_active    AS [IsActive],
                   (SELECT COUNT(*) FROM wms.ng_inspections n WHERE n.ng_type = t.code)
                                  AS [UsedByReports]
            FROM   master.ng_types t
            WHERE  t.is_deleted = 0
            ORDER  BY t.sort_order, t.code;
            """;
        return (await conn.QueryAsync<NgTypeRow>(sql)).ToList();
    }

    /// <summary>Số phiếu đang mang mã này — dùng để chặn xoá.</summary>
    public async Task<int> CountReportsOfTypeAsync(string code)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM wms.ng_inspections WHERE ng_type = @code;", new { code });
    }

    /// <summary>
    /// Thêm hoặc sửa một loại lỗi.
    ///
    /// Mã từng bị xoá mềm thì HỒI SINH (is_deleted = 0) chứ không chèn mới: chèn
    /// mới sẽ đụng khoá chính pk_ng_types và người dùng chỉ nhận được một lỗi
    /// khó hiểu. UPDATE trước rồi mới INSERT, và đọc @@ROWCOUNT ngay dòng kế —
    /// xen bất cứ câu lệnh nào vào giữa là @@ROWCOUNT đổi giá trị.
    /// </summary>
    public async Task UpsertTypeAsync(NgTypeRow t, string? user)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.ng_types
            SET    name_vi = @NameVi, name_en = @NameEn, name_ja = @NameJa, name_zh = @NameZh,
                   note_vi = @NoteVi, note_en = @NoteEn, note_ja = @NoteJa, note_zh = @NoteZh,
                   requires_oqc = @RequiresOqc, sort_order = @SortOrder, is_active = @IsActive,
                   is_deleted = 0, updated_at = SYSDATETIME(), updated_by = @user
            WHERE  code = @Code;

            IF @@ROWCOUNT = 0
                INSERT INTO master.ng_types
                    (code, name_vi, name_en, name_ja, name_zh,
                     note_vi, note_en, note_ja, note_zh,
                     requires_oqc, sort_order, is_active, is_deleted, created_at, created_by)
                VALUES
                    (@Code, @NameVi, @NameEn, @NameJa, @NameZh,
                     @NoteVi, @NoteEn, @NoteJa, @NoteZh,
                     @RequiresOqc, @SortOrder, @IsActive, 0, SYSDATETIME(), @user);
            """;
        await conn.ExecuteAsync(sql, new
        {
            t.Code, t.NameVi, t.NameEn, t.NameJa, t.NameZh,
            t.NoteVi, t.NoteEn, t.NoteJa, t.NoteZh,
            t.RequiresOqc, t.SortOrder, t.IsActive, user,
        });
    }

    /// <summary>
    /// Xoá mềm. Giữ nguyên dòng để khoá ngoại fk_ng_inspections_ng_type đứng
    /// được — xoá cứng là SQL Server chặn ngay nếu còn phiếu tham chiếu.
    /// </summary>
    public async Task<bool> SoftDeleteTypeAsync(string code, string? user)
    {
        using var conn = _factory.Create();
        var n = await conn.ExecuteAsync("""
            UPDATE master.ng_types
            SET    is_deleted = 1, is_active = 0,
                   updated_at = SYSDATETIME(), updated_by = @user
            WHERE  code = @code AND is_deleted = 0;
            """, new { code, user });
        return n > 0;
    }

    public async Task<bool?> GetRequiresOqcAsync(string? ngType)
    {
        if (string.IsNullOrWhiteSpace(ngType)) return null;

        using var conn = _factory.Create();
        // Tra theo LOẠI LỖI, không theo model: việc một bất thường có cần OQC
        // kết luận hay không là tính chất của loại lỗi đó (lệch số lượng là
        // chuyện đếm, không phải chuyện chất lượng), chứ không phải của model.
        //
        // KHÔNG lọc is_active: phiếu cũ mang loại lỗi đã ngưng dùng vẫn phải
        // duyệt cho xong. Ngưng dùng là chặn TẠO phiếu mới, không phải khoá
        // những phiếu đang dở.
        //
        // Trả null khi KHÔNG có dòng nào — nơi gọi tự quyết mặc định, để "chưa
        // khai" và "khai là có OQC" không bị lẫn vào nhau.
        const string sql = """
            SELECT TOP 1 t.requires_oqc
            FROM   master.ng_types t
            WHERE  t.code = @ngType AND t.is_deleted = 0;
            """;
        return await conn.ExecuteScalarAsync<bool?>(sql, new { ngType });
    }

    public async Task<string?> GetUserEmailAsync(string? employeeCode)
    {
        if (string.IsNullOrWhiteSpace(employeeCode)) return null;

        using var conn = _factory.Create();
        // Chỉ để đặt Reply-To. Người chưa khai mail thì trả null và mail vẫn gửi
        // bình thường, chỉ là không bấm Reply về đúng người được.
        const string sql = """
            SELECT TOP 1 u.email
            FROM   master.users u
            WHERE  u.employee_code = @employeeCode AND u.is_deleted = 0;
            """;
        return await conn.ExecuteScalarAsync<string?>(sql, new { employeeCode });
    }
}
