// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'box_detail_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BoxDetailModel _$BoxDetailModelFromJson(Map<String, dynamic> json) =>
    BoxDetailModel(
      id: (json['id'] as num).toInt(),
      boxNo: json['boxNo'] as String,
      totalQty: (json['totalQty'] as num).toInt(),
      serialCount: (json['serialCount'] as num).toInt(),
      lotId: (json['lotId'] as num).toInt(),
      lotNo: json['lotNo'] as String,
      payload: json['payload'] as String,
      primaryModel: json['primaryModel'] as String?,
      customerPo: json['customerPo'] as String?,
      psnvPo: json['psnvPo'] as String?,
      productionDate: json['productionDate'] == null
          ? null
          : DateTime.parse(json['productionDate'] as String),
      oqcStatus: json['oqcStatus'] as String?,
      locatorId: (json['locatorId'] as num?)?.toInt(),
      locatorCode: json['locatorCode'] as String?,
      areaCode: json['areaCode'] as String?,
      areaName: json['areaName'] as String?,
      serials:
          (json['serials'] as List<dynamic>?)
              ?.map((e) => BoxSerialModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
    );

Map<String, dynamic> _$BoxDetailModelToJson(BoxDetailModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'boxNo': instance.boxNo,
      'primaryModel': ?instance.primaryModel,
      'totalQty': instance.totalQty,
      'serialCount': instance.serialCount,
      'customerPo': ?instance.customerPo,
      'psnvPo': ?instance.psnvPo,
      'productionDate': ?instance.productionDate?.toIso8601String(),
      'oqcStatus': ?instance.oqcStatus,
      'lotId': instance.lotId,
      'lotNo': instance.lotNo,
      'payload': instance.payload,
      'locatorId': ?instance.locatorId,
      'locatorCode': ?instance.locatorCode,
      'areaCode': ?instance.areaCode,
      'areaName': ?instance.areaName,
      'serials': instance.serials,
    };

BoxSerialModel _$BoxSerialModelFromJson(Map<String, dynamic> json) =>
    BoxSerialModel(
      id: (json['id'] as num).toInt(),
      serialNo: json['serialNo'] as String,
      model: json['model'] as String,
    );

Map<String, dynamic> _$BoxSerialModelToJson(BoxSerialModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'serialNo': instance.serialNo,
      'model': instance.model,
    };

Map<String, dynamic> _$BoxPatchRequestToJson(BoxPatchRequest instance) =>
    <String, dynamic>{
      'customerPo': instance.customerPo,
      'psnvPo': instance.psnvPo,
    };
