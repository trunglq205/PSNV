part of 'exceptions.dart';

/// Lỗi hạ tầng — phát sinh từ tầng data (Dio, Hive, storage...).
/// [message] mang chuỗi gốc từ hạ tầng để log; UI hiển thị theo [code].
sealed class InfraException extends AppException {
  const InfraException(super.message, {required super.code, super.statusCode});
}

class ServerException extends InfraException {
  const ServerException(super.message, {super.statusCode})
      : super(code: 'error.server');
}

class NetworkException extends InfraException {
  const NetworkException(super.message) : super(code: 'error.network');
}

class TimeoutException extends InfraException {
  const TimeoutException(super.message) : super(code: 'error.timeout');
}

class UnauthorizedException extends InfraException {
  const UnauthorizedException(super.message)
      : super(code: 'error.unauthorized');
}

class ForbiddenException extends InfraException {
  const ForbiddenException(super.message)
      : super(code: 'error.forbidden');
}

class NotFoundException extends InfraException {
  const NotFoundException(super.message) : super(code: 'error.not_found');
}

class CacheException extends InfraException {
  const CacheException(super.message) : super(code: 'error.cache');
}

class UnknownException extends InfraException {
  const UnknownException(super.message) : super(code: 'error.unknown');
}