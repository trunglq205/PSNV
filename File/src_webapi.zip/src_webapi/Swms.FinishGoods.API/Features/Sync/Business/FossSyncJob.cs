using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Foss.Business;
using Swms.FinishGoods.API.Features.Foss.DataAccess;
using Swms.FinishGoods.API.Features.Foss.PalletSync.Business;
using Swms.FinishGoods.API.Features.Foss.PalletSync.DataAccess;
using Swms.FinishGoods.API.Features.HdSoft.DataAccess;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using System.Collections.Concurrent;

namespace Swms.FinishGoods.API.Features.Sync.Business;

/// <summary>Job nền phần Foss: tạo pallet + bổ sung thùng (FA), đồng bộ OQC.</summary>
public interface IFossSyncJob
{
    /// <summary>Tạo pallet từ Foss cho pallet có trên Foss hôm nay / tồn HD soft mà SWMS chưa có.</summary>
    Task SyncFaAsync(SyncProgress p, CancellationToken ct);

    /// <summary>Đồng bộ OQC cho pallet còn tồn mà chưa có kết quả cuối.</summary>
    Task SyncOqcAsync(SyncProgress p, CancellationToken ct);
}

/// <summary>
/// Từng pallet đi qua <see cref="IPalletFossSyncService"/> trong scope riêng (xem SyncBatch).
///
/// Lưu ý: danh sách ứng viên FA lấy cả tồn HD soft — pallet có bên HD soft mà SWMS chưa có
/// thì cũng tạo từ Foss. Đây là chỗ DUY NHẤT phần Foss đọc HD soft, và chỉ đọc danh sách mã.
/// </summary>
public sealed class FossSyncJob : IFossSyncJob
{
    // ── Hằng số ──────────────────────────────────────────────────────

    /// <summary>
    /// Pallet Foss tạo trong khoảng này mà chưa chẵn thì đọc lại Foss để bổ sung thùng
    /// (Foss đóng pallet chưa xong mà SWMS đã tạo).
    /// </summary>
    private const int FossTopUpWindowHours = 6;

    /// <summary>Số pallet xử lý song song ở từng bước. Foss chậm / quá tải thì giảm.</summary>
    private const int FossParallel = 4;
    private const int OqcParallel = 6;

    /// <summary>Pallet không có trên Foss thì bao lâu mới thử lại (bấm lại nhiều lần không lặp lỗi cũ).</summary>
    private const int FossMissRetryMinutes = 360;

    /// <summary>Trạng thái OQC đã chốt — không gọi Foss nữa. PHẢI khớp giá trị lưu trong DB.</summary>
    private static readonly string[] OqcFinalStatuses = ["pass", "ng", InspectionStatus.InspectionExempt];

    /// <summary>Lot không có trên Foss -> nghỉ tới thời điểm này. Static: sống qua các lần bấm.</summary>
    private static readonly ConcurrentDictionary<string, DateTime> FossMisses =
        new(StringComparer.OrdinalIgnoreCase);

    /// <summary>
    /// Chữ ký Foss ở lần top-up gần nhất. Foss không đổi -> không top-up lại.
    /// Chặn pallet đã tách (Foss luôn nhiều thùng hơn SWMS) bị gọi lại mỗi lượt.
    /// </summary>
    private static readonly ConcurrentDictionary<string, FossPalletSummary> FossTopUpSeen =
        new(StringComparer.OrdinalIgnoreCase);

    // ─────────────────────────────────────────────────────────────────

    private readonly ILotRepository _lots;
    private readonly IPalletFossRepository _fossRepo;
    private readonly IHdSoftLotRepository _hdRepo;
    private readonly IFossService _foss;
    private readonly SyncBatch<IPalletFossSyncService> _batch;
    private readonly ILogger<FossSyncJob> _log;

    public FossSyncJob(
        ILotRepository lots,
        IPalletFossRepository fossRepo,
        IHdSoftLotRepository hdRepo,
        IFossService foss,
        IServiceScopeFactory scopes,
        ILogger<FossSyncJob> log)
    {
        _lots = lots;
        _fossRepo = fossRepo;
        _hdRepo = hdRepo;
        _foss = foss;
        _batch = new SyncBatch<IPalletFossSyncService>(scopes, log);
        _log = log;
    }

    // ── 1) FA: tạo pallet từ Foss + bổ sung thùng còn thiếu ─────────
    public async Task SyncFaAsync(SyncProgress p, CancellationToken ct)
    {
        const string step = "FA";
        p.BeginStep(step, 0);

        var todayTask = _foss.GetTodayPalletsAsync();
        var stockTask = _hdRepo.GetPalletsInStockAsync(null);
        await Task.WhenAll(todayTask, stockTask);

        var candidates = SyncLots.Clean(todayTask.Result.Concat(stockTask.Result.Select(r => r.PalletNo)));
        var existing = await _lots.GetExistingLotNosAsync(candidates);

        var now = DateTime.Now;
        var missing = candidates
            .Where(l => !existing.Contains(l))
            .Where(l => !FossMisses.TryGetValue(l, out var until) || until < now)
            .ToList();

        var batchId = Guid.NewGuid();

        // Pallet vừa tạo ở lượt này đã lấy dữ liệu Foss mới nhất -> không top-up lại.
        var createdNow = new ConcurrentDictionary<string, byte>(StringComparer.OrdinalIgnoreCase);

        // 1a) Tạo pallet SWMS chưa có.
        p.BeginStep(step, missing.Count);
        if (missing.Count > 0)
        {
            await _batch.ForEachAsync(missing, x => x, FossParallel, step, p, ct, async (svc, lot) =>
            {
                try
                {
                    if (await svc.TryCreateFromFossAsync(lot, SyncLots.NewSync(StockEventSources.Foss, batchId)))
                    {
                        Interlocked.Increment(ref p.Created);
                        createdNow.TryAdd(lot, 0);
                    }
                    FossMisses.TryRemove(lot, out _);
                }
                catch (NotFoundException)
                {
                    FossMisses[lot] = DateTime.Now.AddMinutes(FossMissRetryMinutes);
                    throw;
                }
            });
        }

        // 1b) Bổ sung thùng — chỉ pallet mà Foss có NHIỀU HƠN SWMS và Foss đã đổi từ lần thử trước.
        const string topUpStep = step + " · bổ sung thùng";

        var topUpCandidates = SyncLots.Clean(await _fossRepo.GetFossTopUpCandidatesAsync(
                DateTime.Now.AddHours(-FossTopUpWindowHours)))
            .Where(l => !createdNow.ContainsKey(l))
            .ToList();

        // Dọn chữ ký của pallet đã ra khỏi cửa sổ để dictionary không phình mãi.
        var candidateSet = topUpCandidates.ToHashSet(StringComparer.OrdinalIgnoreCase);
        foreach (var key in FossTopUpSeen.Keys)
            if (!candidateSet.Contains(key)) FossTopUpSeen.TryRemove(key, out _);

        if (topUpCandidates.Count == 0)
        {
            p.BeginStep(topUpStep, 0);
            return;
        }

        // 2 câu đếm chạy song song, thay cho N lần gọi chi tiết Foss.
        var fossSumTask = _foss.GetPalletSummariesAsync(topUpCandidates);
        var swmsSumTask = _fossRepo.GetContentCountsAsync(topUpCandidates);
        await Task.WhenAll(fossSumTask, swmsSumTask);
        var fossSum = fossSumTask.Result;
        var swmsSum = swmsSumTask.Result;

        var need = topUpCandidates
            .Where(l => fossSum.TryGetValue(l, out var f)
                        && swmsSum.TryGetValue(l, out var s)
                        && (f.BoxCount > s.BoxCount || f.SerialCount > s.SerialCount)
                        && !(FossTopUpSeen.TryGetValue(l, out var seen) && seen == f))
            .ToList();

        p.BeginStep(topUpStep, need.Count);
        if (need.Count == 0) return;

        await _batch.ForEachAsync(need, x => x, FossParallel, topUpStep, p, ct, async (svc, lot) =>
        {
            var r = await svc.TopUpFromFossAsync(lot, SyncLots.NewSync(StockEventSources.Foss, batchId));

            // Ghi nhận chữ ký kể cả khi không thêm được gì (vd thùng đã tách đi):
            // lượt sau Foss vẫn vậy thì bỏ qua. Lỗi -> ForEachAsync bắt, không ghi -> lượt sau thử lại.
            FossTopUpSeen[lot] = fossSum[lot];

            if (r.Changed)
            {
                Interlocked.Increment(ref p.ToppedUp);
                _log.LogInformation("[{Step}] {Lot}: +{Boxes} thùng, +{Lines} serial",
                    topUpStep, lot, r.BoxesAdded, r.LinesAdded);
            }
        });
    }

    // ── 2) OQC ───────────────────────────────────────────────────────
    public async Task SyncOqcAsync(SyncProgress p, CancellationToken ct)
    {
        const string step = "OQC";
        p.BeginStep(step, 0);

        // Lọc ngay trong SQL: chỉ pallet còn tồn, có thùng, chưa có kết quả cuối.
        // Trước đây phải GET từng pallet về Web rồi mới biết có cần sync hay không.
        var lots = await _fossRepo.GetLotNosNeedingOqcAsync(OqcFinalStatuses);

        p.BeginStep(step, lots.Count);
        if (lots.Count == 0) return;

        var batchId = Guid.NewGuid();
        await _batch.ForEachAsync(lots, x => x, OqcParallel, step, p, ct, async (svc, lot) =>
        {
            if (await svc.SyncOqcQuietAsync(lot, SyncLots.NewSync(StockEventSources.Foss, batchId)))
                Interlocked.Increment(ref p.OqcChanged);
        });
    }
}
