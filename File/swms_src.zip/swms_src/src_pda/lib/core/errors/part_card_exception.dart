part of 'exceptions.dart';

/// Lỗi nghiệp vụ Part Card: màn in mới + màn Sửa / Tách / Gộp.
///
/// Kiểm tra phía client trước khi gọi API. Lỗi do server trả về (tem bị khoá,
/// vừa bị đổi ở máy khác…) đi đường [ServerException] như mọi màn khác.
/// Chưa chọn máy in dùng [PrinterException] (`PrinterErrorType.noPrinter`).
sealed class PartCardException extends AppException {
  const PartCardException(super.message, {required super.code});
}

// ── Màn in mới ────────────────────────────────────────────────

/// Bấm tra / quét mà chưa có mã model.
class PartCardEmptyModelException extends PartCardException {
  const PartCardEmptyModelException()
      : super(
    'Vui lòng nhập hoặc quét mã model',
    code: 'error.part_card_empty_model',
  );
}

/// Quét tem ĐÃ IN ở màn in mới — sửa / tách / gộp phải đi từ Home.
class PartCardUseHomeException extends PartCardException {
  const PartCardUseHomeException()
      : super(
    'Tem đã in — quét ở màn Home để sửa / tách / gộp',
    code: 'error.part_card_use_home',
  );
}

// ── Sửa / Tách / Gộp ──────────────────────────────────────────

/// Payload tem không đọc được (thiếu Card_ID / không có model).
class PartCardInvalidException extends PartCardException {
  const PartCardInvalidException()
      : super(
    'Không đọc được tem Part Card',
    code: 'error.part_card_invalid',
  );
}

/// Màn gộp: quét mã không phải tem Part Card.
class PartCardNotACardException extends PartCardException {
  const PartCardNotACardException()
      : super(
    'Chỉ quét tem Part Card để gộp',
    code: 'error.part_card_not_a_card',
  );
}

/// Màn tách: tem nguồn nhiều mã / nhiều thùng.
class PartCardSplitSingleOnlyException extends PartCardException {
  const PartCardSplitSingleOnlyException()
      : super(
    'Chỉ tách được tem 1 mã, 1 thùng',
    code: 'error.part_card_split_single_only',
  );
}

/// Màn gộp: quét lại tem đã có trong danh sách.
class PartCardMergeDuplicateException extends PartCardException {
  const PartCardMergeDuplicateException(this.cardId)
      : super(
    'Tem "$cardId" đã có trong danh sách gộp',
    code: 'error.part_card_merge_duplicate',
  );

  final String cardId;

  @override
  Map<String, String> get namedArgs => {'code': cardId};
}

/// Màn gộp: tổng số mã vượt số dòng của template tem nhiều mã.
class PartCardMergeTooManyException extends PartCardException {
  const PartCardMergeTooManyException(this.max)
      : super(
    'Gộp quá $max mã — tem chỉ in được $max dòng',
    code: 'error.part_card_merge_too_many',
  );

  final int max;

  @override
  Map<String, String> get namedArgs => {'max': '$max'};
}