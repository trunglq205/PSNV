using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.ShipmentTrips.Api;
using Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

public interface ITripStowageService
{
    Task<TripStowageResponse> GetAsync(long tripId);
    Task<TripStowageResponse> StackAsync(long tripId, string code, TripStackRequest request);
    Task<TripStowageResponse> PlaceAsync(long tripId, string code, TripPlaceRequest request);
    Task<TripStowageResponse> ClearAsync(long tripId, string code);
}

/*  PDA làm theo Stowage Plan văn phòng đã lập cho chuyến:
      Pallet Stack  — ghép Pallet List thật vào cọc C0x (tầng dưới / trên theo plan)
      Stowage       — đặt cọc C0x vào đúng ô trong cont (hàng row_no, làn lane_no)

    Kiểm khi ghép:
      - cọc thuộc container của chuyến; số tầng đúng plan (plan 1 tầng thì không nhận tầng trên)
      - Pallet List thuộc chuyến và còn hàng
      - SI của pallet khớp SI của tầng đó trong plan (pallet chưa xác định được SI thì cho qua)
      - 1 pallet chỉ ở 1 cọc; cọc đã xếp vào cont thì phải gỡ xếp mới ghép lại
    Chỉ khi chuyến còn mở (planned / arrived / sealed).

    Mọi lệnh ghi trả lại cả sơ đồ để PDA vẽ lại ngay.                                       */
public class TripStowageService : ITripStowageService
{
    private static readonly HashSet<string> OpenStatuses = new() { "planned", "arrived", "sealed" };

    private readonly IShipmentTripRepository _trips;
    private readonly ITripStowageRepository _repo;
    private readonly ITripVanningRepository _vanning;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public TripStowageService(
        IShipmentTripRepository trips,
        ITripStowageRepository repo,
        ITripVanningRepository vanning,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _trips = trips;
        _repo = repo;
        _vanning = vanning;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    // ═══════════════════════════════════════════════════════════════
    //  Đọc
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripStowageResponse> GetAsync(long tripId)
    {
        var trip = await TripAsync(tripId);
        var plan = await PlanAsync(tripId);
        return await BuildAsync(trip, plan);
    }

    private async Task<TripStowageResponse> BuildAsync(TripRow trip, TripPlanRow plan)
    {
        var rows = await _repo.GetPlanColumnsAsync(plan.PlanId, plan.ContainerIndex);
        var done = (await _vanning.GetStacksAsync(trip.Id))
            .ToDictionary(s => s.ColumnCode, StringComparer.OrdinalIgnoreCase);

        var columns = rows.GroupBy(r => r.Code).Select(g =>
        {
            var c = g.First();
            done.TryGetValue(c.Code, out var s);
            return new TripStowageColumnResponse(
                c.Code, TripStowageRules.CocNoOf(c.Code), c.RowNo, c.LaneNo,
                g.Where(t => t.Tier > 0)
                 .Select(t => new TripStowageTierResponse(t.Tier, t.PlanPalletCode, t.SiNo, t.PalletSize))
                 .ToList(),
                s?.BottomCode, s?.TopCode, s?.CreatedAt, s?.CreatedBy, s?.PlacedAt, s?.PlacedBy);
        })
        .OrderBy(c => c.RowNo).ThenBy(c => c.LaneNo).ThenBy(c => c.Code)
        .ToList();

        return new TripStowageResponse(
            trip.Id, plan.PlanNo, plan.Status, plan.ShipMode, plan.ContainerType,
            Rows: columns.Count == 0 ? 0 : columns.Max(c => c.RowNo ?? 0) + 1,
            Lanes: columns.Count == 0 ? 0 : columns.Max(c => c.LaneNo ?? 0) + 1,
            Stacked: columns.Count(c => c.BottomCode is not null),
            Placed: columns.Count(c => c.PlacedAt is not null),
            CanEdit: OpenStatuses.Contains(trip.Status),
            columns);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Ghép cọc · Xếp cont · Gỡ
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripStowageResponse> StackAsync(long tripId, string code, TripStackRequest r)
    {
        var trip = await OpenTripAsync(tripId);
        var plan = await PlanAsync(tripId);
        await SaveStackAsync(trip, plan, code, r.BottomCode, r.TopCode);
        return await BuildAsync(trip, plan);
    }

    public async Task<TripStowageResponse> PlaceAsync(long tripId, string code, TripPlaceRequest r)
    {
        var trip = await OpenTripAsync(tripId);
        var plan = await PlanAsync(tripId);
        var column = await ColumnAsync(plan, code);

        var stacked = (await _vanning.GetStacksAsync(tripId))
            .FirstOrDefault(s => string.Equals(s.ColumnCode, column.Code, StringComparison.OrdinalIgnoreCase));

        if (stacked is null)
        {
            // Chưa ghép ở màn Pallet Stack -> ghép luôn tại chỗ (cọc 1 tầng thường đi thẳng vào cont).
            if (string.IsNullOrWhiteSpace(r.BottomCode))
                throw new BusinessRuleException(_localizer["Trip.Stowage.NotStacked", column.Code]);
            await SaveStackAsync(trip, plan, column.Code, r.BottomCode, r.TopCode);
        }
        else if (!string.IsNullOrWhiteSpace(r.BottomCode)
                 && !string.Equals(Clean(r.BottomCode), stacked.BottomCode, StringComparison.OrdinalIgnoreCase)
                 && !string.Equals(Clean(r.BottomCode), stacked.TopCode, StringComparison.OrdinalIgnoreCase))
        {
            // Quét tem để chắc đang đặt đúng cọc: mã quét phải là 1 trong 2 pallet của cọc
            throw new BusinessRuleException(_localizer["Trip.Stowage.WrongColumn", Clean(r.BottomCode), column.Code]);
        }

        if (!await _repo.PlaceAsync(tripId, column.Code, Actor))
            throw new BusinessRuleException(_localizer["Trip.Stowage.NotStacked", column.Code]);
        return await BuildAsync(trip, plan);
    }

    /// <summary>Không đòi cọc còn trong plan: cọc văn phòng đã đổi / bỏ vẫn gỡ được để trả pallet.</summary>
    public async Task<TripStowageResponse> ClearAsync(long tripId, string code)
    {
        var trip = await OpenTripAsync(tripId);
        var plan = await PlanAsync(tripId);
        code = Clean(code);
        if (!await _repo.ClearAsync(tripId, code, Actor))
            throw new BusinessRuleException(_localizer["Trip.Stowage.NotStacked", code]);
        return await BuildAsync(trip, plan);
    }

    private async Task ClearOrphansAsync(long tripId, TripPlanRow plan)
    {
        var codes = (await _repo.GetPlanColumnsAsync(plan.PlanId, plan.ContainerIndex))
            .Select(c => c.Code).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        await _repo.ClearOrphansAsync(tripId, codes, Actor);
    }

    private async Task SaveStackAsync(TripRow trip, TripPlanRow plan, string code, string? bottomCode, string? topCode)
    {
        var column = await ColumnAsync(plan, code);
        await ClearOrphansAsync(trip.Id, plan);
        var tiers = column.Tiers;
        var needTop = tiers.Any(t => t.Tier == 2);

        bottomCode = Clean(bottomCode);
        topCode = string.IsNullOrWhiteSpace(topCode) ? null : Clean(topCode);
        if (bottomCode.Length == 0)
            throw new BusinessRuleException(_localizer["Trip.Stowage.BottomRequired", column.Code]);
        if (needTop && topCode is null)
            throw new BusinessRuleException(_localizer["Trip.Stowage.TopRequired", column.Code]);
        if (!needTop && topCode is not null)
            throw new BusinessRuleException(_localizer["Trip.Stowage.SingleTier", column.Code]);
        if (topCode is not null && string.Equals(topCode, bottomCode, StringComparison.OrdinalIgnoreCase))
            throw new BusinessRuleException(_localizer["Trip.Stowage.SamePallet"]);

        var bottom = await TripPalletAsync(trip.Id, bottomCode);
        await CheckSiAsync(bottom, tiers.FirstOrDefault(t => t.Tier == 1), column.Code);

        TripPalletInfo? top = null;
        if (topCode is not null)
        {
            top = await TripPalletAsync(trip.Id, topCode);
            await CheckSiAsync(top, tiers.FirstOrDefault(t => t.Tier == 2), column.Code);
        }

        var (result, other) = await _repo.SaveStackAsync(trip.Id, column.Code, bottom.Id, top?.Id, Actor);
        switch (result)
        {
            case StackSaveResult.Placed:
                throw new ConflictException(_localizer["Trip.Stowage.AlreadyPlaced", column.Code]);
            case StackSaveResult.PalletUsed:
                throw new ConflictException(_localizer["Trip.Stowage.PalletUsed", other ?? ""]);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Kiểm tra
    // ═══════════════════════════════════════════════════════════════

    private async Task<TripRow> TripAsync(long tripId)
        => await _trips.GetAsync(tripId)
           ?? throw new NotFoundException(_localizer["Trip.NotFound", tripId]);

    private async Task<TripRow> OpenTripAsync(long tripId)
    {
        var trip = await TripAsync(tripId);
        if (!OpenStatuses.Contains(trip.Status))
            throw new BusinessRuleException(_localizer["Trip.Stowage.Locked", trip.Status]);
        return trip;
    }

    private async Task<TripPlanRow> PlanAsync(long tripId)
        => await _repo.GetPlanAsync(tripId)
           ?? throw new NotFoundException(_localizer["Trip.Stowage.NoPlan"]);

    /// <summary>Cọc của plan trong container của chuyến + các tầng theo plan (Tier 1 / 2).</summary>
    private async Task<(string Code, List<PlanColumnRow> Tiers)> ColumnAsync(TripPlanRow plan, string? code)
    {
        code = Clean(code);
        var rows = (await _repo.GetPlanColumnsAsync(plan.PlanId, plan.ContainerIndex))
            .Where(r => string.Equals(r.Code, code, StringComparison.OrdinalIgnoreCase))
            .ToList();
        if (rows.Count == 0)
            throw new NotFoundException(_localizer["Trip.Stowage.ColumnNotFound", code]);
        return (rows[0].Code, rows.Where(r => r.Tier > 0).ToList());
    }

    /// <summary>Pallet List thật: thuộc chuyến và còn hàng.</summary>
    private async Task<TripPalletInfo> TripPalletAsync(long tripId, string code)
    {
        var p = await _vanning.FindPalletAsync(tripId, code)
            ?? throw new NotFoundException(_localizer["Trip.Merge.ItemNotFound", code]);
        if (!p.InScope)
            throw new BusinessRuleException(_localizer["Trip.Merge.ItemNotInTrip", code]);
        if (p.BoxCount == 0)
            throw new BusinessRuleException(_localizer["Trip.Merge.PalletEmpty", code]);
        return p;
    }

    /// <summary>SI của pallet phải khớp SI của tầng theo plan. Tầng chưa có pallet soạn, hoặc pallet
    /// chưa xác định được SI (Pallet List mới chưa có thùng packing list) thì cho qua.</summary>
    private async Task CheckSiAsync(TripPalletInfo pallet, PlanColumnRow? tier, string columnCode)
    {
        if (tier?.SiId is not { } planSi) return;
        var sis = await _repo.GetPalletSiIdsAsync(pallet.Id);
        if (sis.Count == 0 || sis.Contains(planSi)) return;
        throw new BusinessRuleException(
            _localizer["Trip.Stowage.SiMismatch", pallet.Code, columnCode, tier.SiNo ?? planSi.ToString()]);
    }

    private static string Clean(string? v) => (v ?? "").Trim().ToUpperInvariant();
}
