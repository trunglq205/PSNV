using Microsoft.AspNetCore.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Yêu cầu một quyền, tham chiếu TRỰC TIẾP type trong cây Perms — không magic string:
///   [RequirePermission&lt;Perms.Receiving.Asn.Create&gt;]
/// Gõ sai type ⟹ compiler báo lỗi. Type không phải quyền hợp lệ ⟹ ném lỗi lúc khởi tạo.
/// (Generic attribute: cần C# 11 / .NET 7+.)
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequirePermissionAttribute<TPermission>
    : AuthorizeAttribute where TPermission : class
{
    public RequirePermissionAttribute()
        => Policy = PermissionPolicy.Prefix + PermissionCatalog.CodeOf<TPermission>();
}

// Policy dạng "perm:temploc.view|pda_receiving.temp_location"
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequireAnyPermissionAttribute<T1, T2> : AuthorizeAttribute
    where T1 : class where T2 : class
{
    public RequireAnyPermissionAttribute()
        => Policy = PermissionPolicy.Prefix
            + PermissionCatalog.CodeOf<T1>() + "|" + PermissionCatalog.CodeOf<T2>();
}

/// <summary>
/// Bản BA quyền — HOẶC, giống bản hai quyền ở trên.
///
/// Cần thật, không phải cho đủ bộ: huỷ một yêu cầu back (mục 2c) thì FA, quản
/// lý FA và quản lý SCS đều phải huỷ được, tuỳ yêu cầu đang dừng ở bước nào.
///
/// ⚠ Xếp hai <c>[RequirePermission]</c> lên cùng một action là **AND**, không
/// phải OR — ASP.NET cộng dồn policy. Muốn OR thì phải dùng attribute này.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequireAnyPermissionAttribute<T1, T2, T3> : AuthorizeAttribute
    where T1 : class where T2 : class where T3 : class
{
    public RequireAnyPermissionAttribute()
        => Policy = PermissionPolicy.Prefix
            + PermissionCatalog.CodeOf<T1>() + "|"
            + PermissionCatalog.CodeOf<T2>() + "|"
            + PermissionCatalog.CodeOf<T3>();
}

/// <summary>
/// Bản nhận string — chỉ dùng khi BẮT BUỘC cần động (vd build policy từ dữ liệu).
/// Ưu tiên bản generic ở trên cho mọi endpoint tĩnh.
/// </summary>
[AttributeUsage(AttributeTargets.Class | AttributeTargets.Method, AllowMultiple = true)]
public sealed class RequirePermissionByCodeAttribute : AuthorizeAttribute
{
    public RequirePermissionByCodeAttribute(string permission)
        => Policy = PermissionPolicy.Prefix + permission;
}

public static class PermissionPolicy
{
    public const string Prefix = "perm:";

    public static string? ExtractPermission(string policyName)
        => policyName.StartsWith(Prefix, StringComparison.Ordinal)
            ? policyName[Prefix.Length..]
            : null;
}

public sealed class PermissionRequirement : IAuthorizationRequirement
{
    public string Permission { get; }
    public PermissionRequirement(string permission) => Permission = permission;
}
