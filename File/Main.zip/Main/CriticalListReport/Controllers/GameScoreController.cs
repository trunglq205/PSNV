﻿using System.Text.Json.Serialization;
using CriticalListReport.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CriticalListReport.Controllers
{
    /// <summary>
    /// Bảng xếp hạng mini game sau đăng nhập — 1 bảng duy nhất cho cả mùa lễ.
    ///   POST /GameScore/Submit       — lưu kết quả 1 lượt chơi (gọi từ halloween-gate.js)
    ///   GET  /GameScore/Leaderboard  — BXH cả mùa (gọi từ halloween.js, nút 🏆 trên băng chúc mừng)
    ///
    /// Luật xếp hạng: thời gian hoàn thành nhanh nhất (từ quả ném đầu tiên tới lúc trúng đủ).
    ///   - Mỗi người lấy lượt tốt nhất trong mùa; bằng thời gian thì ít lần ném hơn xếp trên.
    ///   - Lượt có dùng phím Space (tự ngắm) vẫn được lưu nhưng KHÔNG được xếp hạng.
    ///   - Chỉ tính các lượt chơi trong mùa (mặc định Halloween: 01/10 → hết ngày 30/10).
    ///     Đổi ngày / giải thưởng trong appsettings.json:
    ///     "GameSeason": { "halloween": { "From": "10-01", "To": "10-30", "Prize": "200.000đ" } }
    /// </summary>
    [Authorize]
    public class GameScoreController : Controller
    {
        private static readonly Dictionary<string, (string From, string To)> DefaultSeasons = new()
        {
            ["halloween"] = ("10-01", "10-30"),
            ["christmas"] = ("12-01", "12-25")
        };

        private const int MinDurationMs = 800;             // nhanh hơn mức này coi như không hợp lệ
        private const int MaxDurationMs = 30 * 60 * 1000;  // quá 30 phút: bỏ
        private const int MaxThrows = 1000;

        private readonly AppDbContext _context;
        private readonly IConfiguration _config;

        public GameScoreController(AppDbContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Submit([FromBody] GameScoreSubmit model)
        {
            var theme = NormalizeTheme(model?.Theme);
            if (model == null || theme == null)
                return BadRequest(new { message = "Dữ liệu không hợp lệ." });

            if (model.Hits < 1 || model.Hits > 50 || model.Throws < model.Hits || model.Throws > MaxThrows
                || model.DurationMs < MinDurationMs || model.DurationMs > MaxDurationMs)
                return BadRequest(new { message = "Kết quả không hợp lệ." });

            var username = User.Identity?.Name ?? string.Empty;
            if (string.IsNullOrEmpty(username)) return Unauthorized();

            // chống gửi trùng liên tục (F5 / double submit)
            var recent = await _context.GameScores
                .Where(g => g.Username == username)
                .OrderByDescending(g => g.PlayedAt)
                .Select(g => (DateTime?)g.PlayedAt)
                .FirstOrDefaultAsync();
            if (recent.HasValue && (DateTime.Now - recent.Value).TotalSeconds < 3)
                return StatusCode(429, new { message = "Gửi quá nhanh." });

            var score = new GameScore
            {
                Username = username,
                FullName = User.FindFirst("FullName")?.Value,
                Theme = theme,
                DurationMs = model.DurationMs,
                Throws = model.Throws,
                Hits = model.Hits,
                UsedAuto = model.UsedAuto,
                PlayedAt = DateTime.Now
            };
            _context.GameScores.Add(score);
            await _context.SaveChangesAsync();

            var (from, to) = Season(theme);
            var inSeason = score.PlayedAt >= from && score.PlayedAt < to;
            var board = await BuildBoard(theme);
            var me = board.FirstOrDefault(r => r.Username == username);

            return Json(new
            {
                saved = true,
                ranked = !score.UsedAuto && inSeason,
                inSeason,
                rank = me?.Rank,
                total = board.Count,
                // lượt này có phải kỷ lục cá nhân của mùa không
                personalBest = !score.UsedAuto && inSeason && me != null
                               && me.DurationMs == score.DurationMs && me.Throws == score.Throws,
                bestMs = me?.DurationMs,
                prize = _config[$"GameSeason:{theme}:Prize"] ?? "200.000đ",
                seasonTo = to.AddDays(-1).ToString("dd/MM")
            });
        }

        [HttpGet]
        public async Task<IActionResult> Leaderboard(string theme = "halloween", int top = 20)
        {
            var t = NormalizeTheme(theme) ?? "halloween";
            top = Math.Clamp(top, 3, 100);

            var board = await BuildBoard(t);
            var username = User.Identity?.Name ?? string.Empty;
            var me = board.FirstOrDefault(r => r.Username == username);
            var (from, to) = Season(t);
            var today = DateTime.Today;

            return Json(new
            {
                theme = t,
                from = from.ToString("dd/MM"),
                to = to.AddDays(-1).ToString("dd/MM"),
                started = today >= from,
                closed = today >= to,                                   // đã chốt BXH
                daysLeft = today >= to ? 0 : (int)(to - today).TotalDays, // tính cả hôm nay
                prize = _config[$"GameSeason:{t}:Prize"] ?? "200.000đ",       // giải thưởng top 1
                total = board.Count,
                rows = board.Take(top),
                me
            });
        }

        // ===== helpers =====

        private async Task<List<BoardRow>> BuildBoard(string theme)
        {
            var (from, to) = Season(theme);

            // Số lượt của 1 mùa trong nhà máy không lớn → kéo các lượt hợp lệ về rồi gom nhóm trong bộ nhớ
            var scores = await _context.GameScores
                .AsNoTracking()
                .Where(g => g.Theme == theme && g.PlayedAt >= from && g.PlayedAt < to)
                .ToListAsync();

            var rows = scores
                .GroupBy(g => g.Username)
                .Select(grp =>
                {
                    var best = grp.Where(g => !g.UsedAuto)
                                  .OrderBy(g => g.DurationMs).ThenBy(g => g.Throws).ThenBy(g => g.PlayedAt)
                                  .FirstOrDefault();
                    if (best == null) return null; // chỉ có lượt dùng Space → không xếp hạng
                    return new BoardRow
                    {
                        Username = grp.Key,
                        FullName = grp.OrderByDescending(g => g.PlayedAt).Select(g => g.FullName).FirstOrDefault() ?? grp.Key,
                        DurationMs = best.DurationMs,
                        Throws = best.Throws,
                        Hits = best.Hits,
                        Accuracy = best.Throws > 0 ? (int)Math.Round(100.0 * best.Hits / best.Throws) : 0,
                        BestAt = best.PlayedAt.ToString("dd/MM HH:mm"),
                        BestAtTime = best.PlayedAt
                    };
                })
                .Where(r => r != null)
                .Select(r => r!)
                .OrderBy(r => r.DurationMs).ThenBy(r => r.Throws).ThenBy(r => r.BestAtTime)
                .ToList();

            for (int i = 0; i < rows.Count; i++) rows[i].Rank = i + 1;
            return rows;
        }

        /// <summary>
        /// Khoảng thời gian của mùa trong năm hiện tại: [From 00:00, hết ngày To).
        /// Đọc từ appsettings "GameSeason:{theme}:From/To" (định dạng MM-dd), không có thì dùng mặc định.
        /// </summary>
        private (DateTime from, DateTime to) Season(string theme)
        {
            var def = DefaultSeasons[theme];
            var fromStr = _config[$"GameSeason:{theme}:From"] ?? def.From;
            var toStr = _config[$"GameSeason:{theme}:To"] ?? def.To;
            var year = DateTime.Today.Year;
            var from = ParseMonthDay(fromStr, year) ?? ParseMonthDay(def.From, year)!.Value;
            var toDay = ParseMonthDay(toStr, year) ?? ParseMonthDay(def.To, year)!.Value;
            return (from, toDay.AddDays(1));
        }

        private static DateTime? ParseMonthDay(string value, int year)
        {
            var parts = value.Split('-', '/');
            if (parts.Length == 2 && int.TryParse(parts[0], out var m) && int.TryParse(parts[1], out var d)
                && m is >= 1 and <= 12 && d >= 1 && d <= DateTime.DaysInMonth(year, m))
                return new DateTime(year, m, d);
            return null;
        }

        private static string? NormalizeTheme(string? theme)
        {
            var t = theme?.Trim().ToLowerInvariant();
            return t != null && DefaultSeasons.ContainsKey(t) ? t : null;
        }

        public class BoardRow
        {
            public int Rank { get; set; }
            public string Username { get; set; } = string.Empty;
            public string FullName { get; set; } = string.Empty;
            public int DurationMs { get; set; }
            public int Throws { get; set; }
            public int Hits { get; set; }
            public int Accuracy { get; set; }
            public string BestAt { get; set; } = string.Empty;
            [JsonIgnore] public DateTime BestAtTime { get; set; }
        }
    }
}
