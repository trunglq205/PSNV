/// Kết quả tách pallet (khớp `SplitPalletResponse` của API).
class SplitResult {
  final String sourceLotNo;
  final int sourceRemainingBoxes;
  final String targetLotNo;
  final bool targetIsNew;
  final int movedBoxes;

  const SplitResult({
    required this.sourceLotNo,
    required this.sourceRemainingBoxes,
    required this.targetLotNo,
    required this.targetIsNew,
    required this.movedBoxes,
  });
}

/// Kết quả sau khi gán / rời / chuyển / lưu kho.
/// Khớp `LocatorChangeResponse` (PUT/DELETE /locator) và `StoringResponse`
/// (PUT /storing) — StoringResponse là tập con nên dùng chung 1 entity.
class LocatorChangeResult {
  final int lotId;
  final String lotNo;
  final int? fromLocatorId;
  final String? fromLocatorCode;

  /// Vị trí đích — null với "rời/out".
  final int? toLocatorId;
  final String? toLocatorCode;

  /// Cảnh báo khi vị trí đích đã có pallet khác (thao tác vẫn thành công).
  final String? warning;

  const LocatorChangeResult({
    required this.lotId,
    required this.lotNo,
    this.fromLocatorId,
    this.fromLocatorCode,
    this.toLocatorId,
    this.toLocatorCode,
    this.warning,
  });

  /// Không có vị trí đích ⇒ là thao tác rời/out.
  bool get isRelease => toLocatorId == null;
  bool get hasWarning => warning != null && warning!.isNotEmpty;
}
