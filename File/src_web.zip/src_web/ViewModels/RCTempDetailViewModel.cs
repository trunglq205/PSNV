﻿
namespace SWMS_WebTool.ViewModels
{
    public record RCTempDetailViewModel
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }
        public string MaterialFrequency { get; set; }
        public string MaterialType { get; set; }
        public string TemporaryAreaCode { get; set; }
        public double CurrentQuantity { get; set; }
        public DateTime? CreatedDate { get; set; }
        

    }
}
