// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'robot_outpallet_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RobotOutpalletRequestModel _$RobotOutpalletRequestModelFromJson(
        Map<String, dynamic> json) =>
    RobotOutpalletRequestModel(
      qrcode: json['qrcode'] as String,
    );

Map<String, dynamic> _$RobotOutpalletRequestModelToJson(
        RobotOutpalletRequestModel instance) =>
    <String, dynamic>{
      'qrcode': instance.qrcode,
    };
