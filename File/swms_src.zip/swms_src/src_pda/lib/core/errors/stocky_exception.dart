part of 'exceptions.dart';

/// Lỗi nghiệp vụ màn Xe Stocky.
sealed class StockyException extends AppException {
  const StockyException(super.message, {required super.code});
}

/// Quét lại xe đã có trong danh sách.
class StockyDuplicateException extends StockyException {
  const StockyDuplicateException(this.cartCode)
      : super(
    'Xe "$cartCode" đã có trong danh sách',
    code: 'error.stocky_duplicate',
  );

  final String cartCode;

  @override
  Map<String, String> get namedArgs => {'code': cartCode};
}

/// Xe không ở trạng thái hợp lệ cho chiều đang chọn (đã nhập rồi mà nhập
/// lại, chưa nhập mà đã xuất…) — server trả về khi tra.
class StockyInvalidStateException extends StockyException {
  const StockyInvalidStateException(this.cartCode)
      : super(
    'Xe "$cartCode" không thể thao tác ở tab này',
    code: 'error.stocky_invalid_state',
  );

  final String cartCode;

  @override
  Map<String, String> get namedArgs => {'code': cartCode};
}
