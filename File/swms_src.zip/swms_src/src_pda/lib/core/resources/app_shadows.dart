import 'package:flutter/material.dart';

/// Thang đổ bóng — từ tokens.css.
abstract final class AppShadows {
  const AppShadows._();

  static const List<BoxShadow> s1 = [
    BoxShadow(color: Color(0x0A000000), offset: Offset(0, 1), blurRadius: 2),
    BoxShadow(color: Color(0x0F000000), offset: Offset(0, 1), blurRadius: 3),
  ];
  static const List<BoxShadow> s2 = [
    BoxShadow(color: Color(0x0D000000), offset: Offset(0, 4), blurRadius: 6),
    BoxShadow(color: Color(0x0A000000), offset: Offset(0, 2), blurRadius: 4),
  ];
  static const List<BoxShadow> s4 = [
    BoxShadow(color: Color(0x14000000), offset: Offset(0, 10), blurRadius: 15),
    BoxShadow(color: Color(0x0D000000), offset: Offset(0, 4), blurRadius: 6),
  ];
}
