﻿namespace SWMS_WebTool.Models.Requests
{
    public class CreateUpdateZoneRequest
    {
        public int FloorId { get; set; }
        public string ZoneName { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public bool IsJIT { get; set; }
        public bool IsDIP { get; set; }
    }

    public class UpdateZoneRequest
    {
        public long ZoneId { get; set; }
        public string ZoneName { get; set; }
        public bool IsJIT { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
    }
}
