﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class InventoryStoredQuantityViewModel : TableViewModel<InventoryStoredQuantity, InventoryStoredQuantityFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, InventoryStoredQuantityFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Category = filter?.Category ?? Filter.Category,
                Material = filter?.Material ?? Filter.Material,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                DateStorage = filter?.DateStorage ?? Filter.DateStorage,
                ToDate = filter?.ToDate ?? Filter.ToDate,
                FromDate = filter?.FromDate ?? Filter.FromDate,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class InventoryViewModel : TableViewModel<Inventory, InventoryFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, InventoryFilter? filter = null)
        {
            return new
            {
                Material = filter?.Material ?? Filter.Material,
                ToDate = filter?.ToDate ?? Filter.ToDate,
                FromDate = filter?.FromDate ?? Filter.FromDate,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class InvenoryGoodReceiptViewModel : TableViewModel<InventoryGoodReceipt, InvenoryGoodReceiptFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, InvenoryGoodReceiptFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Category = filter?.Category ?? Filter.Category,
                Material = filter?.Material ?? Filter.Material,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                DateReceive = filter?.DateReceive ?? Filter.DateReceive,
                ToDate = filter?.ToDate ?? Filter.ToDate,
                FromDate = filter?.FromDate ?? Filter.FromDate,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class InventoryMovedOutViewModel : TableViewModel<InventotyMovedOut, InventoryMovedOutFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, InventoryMovedOutFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Category = filter?.Category ?? Filter.Category,
                Material = filter?.Material ?? Filter.Material,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                KittingDate = filter?.KittingDate ?? Filter.KittingDate,
                ToDate = filter?.ToDate ?? Filter.ToDate,
                FromDate = filter?.FromDate ?? Filter.FromDate,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class SapStockViewModel : TableViewModel<SAPStock, SapStockFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, SapStockFilter? filter = null)
        {
            return new
            {
                Material = filter?.Material ?? Filter.Material,
                Plant = filter?.Plant ?? Filter.Plant,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class InventoryFormViewModel : TableViewModel<InventoryForm, InventoryFormFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, InventoryFormFilter? filter = null)
        {
            return new
            {
                Tab = filter?.Tab ?? Filter.Tab,
                Material = filter?.Material ?? Filter.Material,
                Plant = filter?.Plant ?? Filter.Plant,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                BalanceType = filter?.BalanceType ?? Filter.BalanceType,
                StartDate = filter?.StartDate ?? Filter.StartDate,
                EndDate = filter?.EndDate ?? Filter.EndDate,
                Type = filter?.Type ?? Filter.Type,
                IsAll = filter?.IsAll ?? Filter.IsAll,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class InventoryFormKittingViewModel : TableViewModel<InventoryForm, InventoryFormKittingFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, InventoryFormKittingFilter? filter = null)
        {
            return new
            {
                Tab = filter?.Tab ?? Filter.Tab,
                Material = filter?.Material ?? Filter.Material,
                Plant = filter?.Plant ?? Filter.Plant,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                BalanceType = filter?.BalanceType ?? Filter.BalanceType,
                IsAll = filter?.IsAll ?? Filter.IsAll,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
