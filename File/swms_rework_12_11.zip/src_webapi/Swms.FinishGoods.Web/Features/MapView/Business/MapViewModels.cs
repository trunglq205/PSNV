namespace Swms.FinishGoods.Web.Features.MapView.Business.Models;

public class RackPositionOccDto
{
    public long RackId { get; set; }
    public int Position { get; set; }
    public int Total { get; set; }
    public int Occupied { get; set; }
}

public class MapViewLotDto
{
    public long LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public int? BoxCount { get; set; }
    public DateTime? ProductionDate { get; set; }
    public string Status { get; set; } = "empty";
    public bool IsUrgent { get; set; }

    /// <summary>rework | refurbish | null — dấu RW/RB cạnh Pallet ID.</summary>
    public string? Disposition { get; set; }
}

public class MapViewBlockDto
{
    public long Id { get; set; }
    public string Kind { get; set; } = "zone";

    /// <summary>
    /// rework | refurbish | null — ô có hàng tái gia công; bản đồ vẽ dấu nhỏ ở
    /// góc ô. Lấy theo lot đầu tiên có dấu.
    /// </summary>
    public string? Disposition { get; set; }

    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; }
    public int GridH { get; set; }
    public string? Label { get; set; }
    public string? Color { get; set; }
    public string? Arrow { get; set; }

    public long? RackId { get; set; }
    public string? RackCode { get; set; }
    public int TotalSlots { get; set; }
    public int OccupiedSlots { get; set; }
    public List<RackPositionOccDto> Positions { get; set; } = new();

    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string Status { get; set; } = "empty";
    public bool IsUrgent { get; set; }
    public string? Model { get; set; }
    public List<MapViewLotDto> Lots { get; set; } = new();
}

public class MapViewSummaryDto
{
    public int TotalSlots { get; set; }
    public int OccupiedSlots { get; set; }
    public int EmptySlots { get; set; }
    public double OccupiedPercent { get; set; }
    public int RackTotalSlots { get; set; }
    public int RackOccupiedSlots { get; set; }
    public int PalletTotalSlots { get; set; }
    public int PalletOccupiedSlots { get; set; }
}

public class MapViewLayoutDto
{
    public long AreaId { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public string MapType { get; set; } = "storing";
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public List<MapViewBlockDto> Blocks { get; set; } = new();
    public MapViewSummaryDto Summary { get; set; } = new();
}
