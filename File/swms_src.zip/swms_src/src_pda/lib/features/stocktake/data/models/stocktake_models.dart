import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/stocktake/domain/entities/stocktake_entities.dart';

part 'stocktake_models.g.dart';

@JsonSerializable()
class CountSummaryModel {
  final int id;
  final String docNo;
  final String? countType;
  final DateTime countDate;
  final String docStatus;
  final String? description;
  final int totalLines;
  final int countedLines;
  final int discrepancyLines;

  const CountSummaryModel({
    required this.id,
    required this.docNo,
    required this.countType,
    required this.countDate,
    required this.docStatus,
    required this.description,
    required this.totalLines,
    required this.countedLines,
    required this.discrepancyLines,
  });

  factory CountSummaryModel.fromJson(Map<String, dynamic> json) =>
      _$CountSummaryModelFromJson(json);

  CountSummary toEntity() => CountSummary(
        id: id,
        docNo: docNo,
        countType: countType,
        countDate: countDate,
        docStatus: docStatus,
        description: description,
        totalLines: totalLines,
        countedLines: countedLines,
        discrepancyLines: discrepancyLines,
      );
}

@JsonSerializable()
class CountLineModel {
  final int id;
  final int lineNo;
  final int productId;
  final String? productName;
  final int locatorId;
  final String locatorCode;
  final int? lotId;
  final String? palletId;
  final String? model;
  final int qtySystem;
  final int? qtyCount;
  final int? boxCountSystem;
  final int? boxCountCounted;
  final int? standardPacking;
  final int walkSeq;
  final String? areaCode;
  final String? areaName;
  @JsonKey(defaultValue: false)
  final bool isFound;
  final String? systemLocatorCode;

  const CountLineModel({
    required this.id,
    required this.lineNo,
    required this.productId,
    required this.productName,
    required this.locatorId,
    required this.locatorCode,
    required this.lotId,
    required this.palletId,
    required this.model,
    required this.qtySystem,
    required this.qtyCount,
    this.boxCountSystem,
    this.boxCountCounted,
    this.standardPacking,
    this.walkSeq = 0,
    this.areaCode,
    this.areaName,
    this.isFound = false,
    this.systemLocatorCode,
  });

  factory CountLineModel.fromJson(Map<String, dynamic> json) =>
      _$CountLineModelFromJson(json);

  CountLine toEntity() => CountLine(
        id: id,
        lineNo: lineNo,
        productId: productId,
        productName: productName,
        locatorId: locatorId,
        locatorCode: locatorCode,
        lotId: lotId,
        palletId: palletId,
        model: model,
        qtySystem: qtySystem,
        qtyCount: qtyCount,
        boxCountSystem: boxCountSystem,
        boxCountCounted: boxCountCounted,
        standardPacking: standardPacking,
        walkSeq: walkSeq,
        areaCode: areaCode,
        areaName: areaName,
        isFound: isFound,
        systemLocatorCode: systemLocatorCode,
      );
}

@JsonSerializable()
class CountDetailModel {
  final CountSummaryModel header;
  final List<CountLineModel> lines;

  const CountDetailModel({required this.header, required this.lines});

  factory CountDetailModel.fromJson(Map<String, dynamic> json) =>
      _$CountDetailModelFromJson(json);

  CountDetail toEntity() => CountDetail(
        header: header.toEntity(),
        lines: lines.map((e) => e.toEntity()).toList(),
      );
}

@JsonSerializable(createFactory: false)
class SetCountRequestModel {
  final int qtyCount;
  final String? note;

  /// Số box đếm được — lưu lại để đối chiếu, null khi người kiểm nhập
  /// thẳng số lượng (model chưa khai quy cách, hoặc thực tế lệch quy cách).
  final int? boxCountCounted;

  const SetCountRequestModel({
    required this.qtyCount,
    this.note,
    this.boxCountCounted,
  });

  Map<String, dynamic> toJson() => _$SetCountRequestModelToJson(this);
}

/// Khớp `AddFoundResponse` (POST /api/stocktake/counts/{id}/found).
@JsonSerializable()
class AddFoundResultModel {
  final int lineId;
  @JsonKey(defaultValue: true)
  final bool created;

  const AddFoundResultModel({required this.lineId, this.created = true});

  factory AddFoundResultModel.fromJson(Map<String, dynamic> json) =>
      _$AddFoundResultModelFromJson(json);

  Map<String, dynamic> toJson() => _$AddFoundResultModelToJson(this);
}

/// Ghi pallet phát sinh: quét mã pallet tại một ô trong phiếu.
@JsonSerializable(createFactory: false)
class AddFoundRequestModel {
  final int locatorId;
  final String palletId;

  const AddFoundRequestModel({required this.locatorId, required this.palletId});
  Map<String, dynamic> toJson() => _$AddFoundRequestModelToJson(this);
}
