using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Business;

public interface IShipmentInstructionService
{
    // Danh sách / chi tiết
    Task<PagedResult<SiListItemResponse>> GetPagedAsync(SiQuery query);
    Task<SiStatusCountResponse> GetStatusCountsAsync();
    Task<SiDetailResponse> GetByIdAsync(long id);
    /// <summary>Các lần SAP gửi SI này (ai sửa, lúc nào, đổi gì), mới nhất trước.</summary>
    Task<List<SiHistoryItemResponse>> GetHistoryAsync(long id, bool onlyChanges);

    // Header
    Task<SiDetailResponse> CreateAsync(CreateSiRequest request);
    /// <summary>Payload SAP nguyên dạng. Phiếu nhận diện theo si_no: chưa có -> tạo (Created = true),
    /// đã có -> cập nhật phiếu đó (Created = false). Thay đổi được ghi vào SapInboundAudit.</summary>
    Task<(SiDetailResponse Si, bool Created)> CreateFromSapAsync(SapSiRequest request);
    Task UpdateAsync(long id, UpdateSiRequest request);
    Task DeleteAsync(long id);
    Task CancelAsync(long id, CancelSiRequest request);    
    /// <summary>Đánh dấu hoàn thành — chỉ đổi trạng thái, không kiểm tra điều kiện.</summary>
    Task CompleteAsync(long id);

    // Line
    Task<SiLineResponse> AddLineAsync(long siId, SiLineRequest request);
    Task UpdateLineAsync(long lineId, SiLineRequest request);
    Task DeleteLineAsync(long lineId);
    Task CutLineAsync(long lineId, CutLineRequest request);

    // Phân bổ
    Task<AllocateResponse> AllocateAsync(long id, AllocateRequest request);
    Task<List<SiTaskResponse>> GetTasksAsync(long id);
    Task UpdateTaskAsync(long taskId, UpdateTaskRequest request);
    Task ReleaseTaskAsync(long taskId);

    // Mã thùng chỉ định
    Task<List<SiBoxResponse>> DesignateBoxesAsync(long lineId, DesignateBoxesRequest request);
    Task<List<SiBoxResponse>> RematchBoxesAsync(long lineId);
    Task ResolveBoxAsync(long id, ResolveBoxRequest request);
    Task DeleteBoxAsync(long id);

    // Lấy hàng (PDA)
    Task<PickTaskDetailResponse> GetPickTaskAsync(long taskId);
    Task<PickTaskDetailResponse> ConfirmPalletAsync(long taskId, ConfirmPalletRequest request);
    Task<PickTaskDetailResponse> PickBoxAsync(long taskId, PickBoxRequest request);
    Task<PickTaskDetailResponse> UnpickBoxAsync(long taskId, string boxNo);

    // Vanning (PDA)
    Task<PickTaskDetailResponse> StageVanningAsync(long taskId, StageVanningRequest request);
}