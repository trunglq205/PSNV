import 'package:swms_finish_goods/features/receiving/data/datasources/receiving_history_local_data_source.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_history_entry.dart';
import 'package:swms_finish_goods/features/receiving/domain/repositories/receiving_history_repository.dart';

/// Bản nháp quét lấy từ local storage. Luật hết hạn 1 ngày đặt ở đây vì đó là
/// quy tắc nghiệp vụ, không phải chi tiết lưu trữ.
class ReceivingHistoryRepositoryImpl implements ReceivingHistoryRepository {
  final ReceivingHistoryLocalDataSource _local;

  const ReceivingHistoryRepositoryImpl(this._local);

  @override
  Future<ReceivingHistoryEntry?> read() async {
    final entry = _local.read();
    if (entry == null) return null;

    if (entry.isExpired) {
      await _local.clear();
      return null;
    }
    return entry;
  }

  @override
  Future<void> save(ReceivingHistoryEntry entry) => _local.write(entry);

  @override
  Future<void> clear() => _local.clear();
}