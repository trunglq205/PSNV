﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Services;

namespace SWMS_WebTool.Utils.Extensions
{
    public static class LocalizationExtensions
    {
        /// <summary>
        /// Dùng trong View: @Html.T("Common_Home")
        /// </summary>
        public static string T(this IHtmlHelper html, string key)
        {
            var loc = html.ViewContext.HttpContext.RequestServices
                .GetService(typeof(ILocalizationService)) as ILocalizationService;
            return loc?.Get(key) ?? key;
        }

        public static string T(this IHtmlHelper html, string key, params object[] args)
        {
            var loc = html.ViewContext.HttpContext.RequestServices
                .GetService(typeof(ILocalizationService)) as ILocalizationService;
            return loc?.Get(key, args) ?? key;
        }
    }
}