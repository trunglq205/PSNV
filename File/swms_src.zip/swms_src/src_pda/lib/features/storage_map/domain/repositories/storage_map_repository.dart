import 'package:swms_finish_goods/features/storage_map/domain/entities/storage_map_entities.dart';

/// Đọc bản đồ Storage (chỉ xem) — phục vụ công nhân xem trước vị trí/tình trạng hàng.
abstract class StorageMapRepository {
  /// Danh sách bản đồ để chọn (mặc định lấy loại storing).
  Future<List<WarehouseArea>> fetchAreas({String? type});

  /// Bản đồ top-down khu Storage (kệ + khu chức năng + độ chứa).
  Future<StorageTopMap> fetchTopMap({String? areaCode});

  /// Mặt cắt 1 kệ theo mã kệ.
  Future<RackElevation> fetchElevation(String rackCode, {String? areaCode});

  /// Tra một mã vị trí nằm ở bản đồ nào, kệ nào.
  Future<LocatorLocation> locate(String locatorCode);

  /// Serial trong 1 pallet (theo mã pallet).
  Future<List<PalletSerial>> serials(String palletCode);
}
