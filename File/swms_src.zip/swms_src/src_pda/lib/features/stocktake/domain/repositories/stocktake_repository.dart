import 'package:swms_finish_goods/features/stocktake/domain/entities/stocktake_entities.dart';

abstract class StocktakeRepository {
  Future<List<CountSummary>> fetchCounts({String? type});
  Future<CountDetail> fetchCount(int id);
  /// Ghi số đếm. [boxCount] là số box đếm được — gửi kèm khi người kiểm đếm
  /// theo box; null khi họ nhập thẳng số lượng.
  Future<void> setCount(int lineId, int qty, {String? note, int? boxCount});
  Future<void> closeCount(int id);

  /// Ghi pallet phát sinh tại [locatorId]. Trả id dòng (dòng mới, hoặc dòng sẵn có
  /// nếu pallet vốn thuộc ô này).
  Future<int> addFound(int countId, int locatorId, String palletId);
}
