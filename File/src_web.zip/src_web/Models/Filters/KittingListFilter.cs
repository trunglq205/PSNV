﻿using Refit;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class KittingListFilter : BaseFilter
    {
        public KittingType? Type { get; set; }
        public KittingTab Tab { get; set; }
        [Display(Name = "Kitting From")]
        public KittingFrom KTFrom { get; set; }
        public string? ProDate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");
        public string? Model { get; set; }
        public string? Plant { get; set; }
        [Display(Name = "Category")]
        public string? Cate { get; set; }
        public string? Sloc { get; set; }
        public string? SpecialPart { get; set; }
        public string? Material { get; set; }
        public string? Reservation { get; set; }
        public string? KittingDate { get; set; }
        public string? SupplyDate { get; set; }
        [Display(Name = "Time start")]
        public string? FromTime { get; set; }
        [Display(Name = "Time end")]
        public string? FinishTime { get; set; }
        public string? Line { get; set; }
        public string? Time { get; set; }
        public string? PullID { get; set; }
        public bool IsLoadByTime { get; set; } = false;
        [Display(Name = "Urgent")]
        public bool IsUrgentDIP { get; set; }
        public bool Prepare { get; set; }
        public bool Other { get; set; }
        public bool JIT { get; set; }
        public bool Process { get; set; }
        public bool CommonPart { get; set; }
        public double? Quantity { get; set; }
        public KittingStatus? Status { get; set; }
        [Query(Format = "yyyy-MM-dd")]
        public DateTime? ReDate { get; set; } = DateTime.Now;
        public DateTime? CreatedDate { get; set; }

    }
}
