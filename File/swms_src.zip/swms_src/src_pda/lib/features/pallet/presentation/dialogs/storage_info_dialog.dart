import 'dart:math' as math;

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/pickers/number_dial_picker.dart';
import 'package:swms_finish_goods/shared/domain/entities/warehouse_area.dart';
import 'package:swms_finish_goods/shared/presentation/providers/warehouse_area_providers.dart';

/// Cách người dùng bổ sung thông tin để suy ra vị trí lưu kho.
enum StorageInfoMode {
  /// Quay chiều cao pallet -> hệ thống suy ra khu / tầng.
  dimension,

  /// Khai báo thẳng khu / tầng vào master.
  master,
}

/// Kết quả trả về khi bấm "Xác nhận". `null` nghĩa là người dùng huỷ.
///
/// Hai constructor tách riêng để không dựng được vật thể vô nghĩa: nhánh kích
/// thước không có areaId, nhánh master không có heightCm. Trước đây một
/// constructor chung cho cả hai nên nơi nhận phải tự đoán field nào có nghĩa.
class StorageInfoResult {
  /// Tab "Nhập kích thước" — chiều cao của RIÊNG pallet đang cầm, không ghi master.
  const StorageInfoResult.dimension(this.heightCm)
    : mode = StorageInfoMode.dimension,
      suggestAreaId = null,
      suggestRackRow = null;

  /// Tab "Khai báo master" — ghi thẳng `master.models` của mã hàng này.
  /// null / rỗng = XOÁ gợi ý tương ứng, khớp ngữ nghĩa PATCH bên server.
  const StorageInfoResult.master({this.suggestAreaId, this.suggestRackRow})
    : mode = StorageInfoMode.master,
      heightCm = null;

  final StorageInfoMode mode;

  /// Chỉ có ở [StorageInfoMode.dimension].
  final int? heightCm;

  /// FK -> `master.warehouse_areas(id)`. KHÔNG phải areaCode ("FA", "SCM"):
  /// mã khu có thể đổi, id thì không, mà cột suggest_area là FK theo id.
  final int? suggestAreaId;

  /// Tầng rack được phép lưu, vd [2, 3]. Server validate trong [1..4].
  final List<int>? suggestRackRow;
}

/// Mở dialog bổ sung thông tin lưu kho cho một mã hàng. Trả về null nếu huỷ.
///
///   - [itemCode]         mã hàng đang xử lý, hiện ở dòng phụ tiêu đề.
///   - [initialAreaId]    khu chọn sẵn — truyền lại giá trị thao tác viên vừa
///                        khai trong phiên để mở lại không phải chọn lại từ đầu.
///   - [initialRackRows]  tầng chọn sẵn, cùng mục đích như trên.
///   - [rackRowOptions]   các tầng rack cho chọn; khớp `RackRowRule.Min/Max`
///                        bên server ([1..4]) — đổi ở server thì đổi cả đây.
///   - [maxHeight]        chặn trên của vòng quay, cũng quyết định số cột dial.
///   - [allowMasterMode]  cho phép tab "Khai báo master". Đặt `false` khi mã hàng
///     ĐÃ có master: lúc đó chỉ cần nhập chiều cao (server vẫn dùng chiều cao khi
///     master mới khai khu mà chưa khai tầng), còn khai lại khu/tầng là thừa và
///     dễ ghi đè nhầm cấu hình đang đúng.
///
/// Danh sách khu KHÔNG còn truyền vào: dialog tự đọc `warehouseAreasProvider`
/// (`GET /api/warehouse-areas`). Bắt mọi nơi mở dialog phải tự nạp trước thì
/// sớm muộn có chỗ quên, và chỗ đó sẽ hiện danh sách rỗng chứ không báo lỗi.
Future<StorageInfoResult?> showStorageInfoDialog(
  BuildContext context, {
  required String itemCode,
  int? initialHeightCm,
  int? initialAreaId,
  List<int> initialRackRows = const [],
  List<int> rackRowOptions = const [1, 2, 3, 4],
  int maxHeight = 250,
  bool allowMasterMode = true,
}) {
  return showDialog<StorageInfoResult>(
    context: context,
    builder: (_) => _StorageInfoDialog(
      itemCode: itemCode,
      initialHeightCm: initialHeightCm,
      initialAreaId: initialAreaId,
      initialRackRows: initialRackRows,
      rackRowOptions: rackRowOptions,
      maxHeight: maxHeight,
      allowMasterMode: allowMasterMode,
    ),
  );
}

class _StorageInfoDialog extends ConsumerStatefulWidget {
  const _StorageInfoDialog({
    required this.itemCode,
    required this.initialHeightCm,
    required this.initialAreaId,
    required this.initialRackRows,
    required this.rackRowOptions,
    required this.maxHeight,
    required this.allowMasterMode,
  });

  final String itemCode;
  final int? initialHeightCm;
  final int? initialAreaId;
  final List<int> initialRackRows;
  final List<int> rackRowOptions;
  final int maxHeight;
  final bool allowMasterMode;

  @override
  ConsumerState<_StorageInfoDialog> createState() => _StorageInfoDialogState();
}

class _StorageInfoDialogState extends ConsumerState<_StorageInfoDialog> {
  /// Vị trí xuất phát của vòng quay khi mã hàng chưa có kích thước.
  static const _fallbackHeight = 120;

  /// Luôn khởi tạo ở tab kích thước. Khi `allowMasterMode = false` thì thanh
  /// chuyển tab bị ẩn nên giá trị này không đổi được nữa.
  StorageInfoMode _mode = StorageInfoMode.dimension;
  late int _height = widget.initialHeightCm ?? _fallbackHeight;
  late int? _areaId = widget.initialAreaId;
  late final Set<int> _rackRows = {...widget.initialRackRows};

  bool get _canSave => switch (_mode) {
    // Vòng quay luôn có giá trị nên tab này lúc nào cũng lưu được.
    StorageInfoMode.dimension => true,
    // Yêu cầu chọn ít nhất một thứ: bấm Xác nhận khi chưa chọn gì sẽ XOÁ sạch
    // gợi ý trong master (null = xoá), một thao tác phá dữ liệu mà trên PDA
    // không có gì hoàn tác. Muốn xoá hẳn thì làm trên Blazor.
    StorageInfoMode.master => _areaId != null || _rackRows.isNotEmpty,
  };

  void _save() {
    Navigator.pop(context, switch (_mode) {
      StorageInfoMode.dimension => StorageInfoResult.dimension(_height),
      StorageInfoMode.master => StorageInfoResult.master(
        suggestAreaId: _areaId,
        suggestRackRow: _rackRows.isEmpty ? null : (_rackRows.toList()..sort()),
      ),
    });
  }

  void _toggleRackRow(int row) => setState(() {
    if (!_rackRows.remove(row)) _rackRows.add(row);
  });

  /// NumberDialPicker là uncontrolled: đổi tab rồi quay lại sẽ dựng lại dial
  /// từ _height hiện tại nên không mất giá trị.
  Widget _buildDimensionForm() => _DimensionForm(
    initialHeightCm: _height,
    maxHeight: widget.maxHeight,
    onHeightChanged: (h) => setState(() => _height = h),
  );

  Widget _buildMasterForm() => _MasterForm(
    // Chỉ đọc provider ở nhánh master -> mã hàng đã có master (allowMasterMode
    // = false) sẽ không tốn lượt gọi /api/warehouse-areas.
    areas: ref.watch(warehouseAreasProvider),
    rackRowOptions: widget.rackRowOptions,
    areaId: _areaId,
    rackRows: _rackRows,
    onAreaChanged: (id) => setState(() => _areaId = id),
    onRackRowToggled: _toggleRackRow,
    onRetry: () => ref.invalidate(warehouseAreasProvider),
  );

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Dialog(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppDimens.rCard),
      ),
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.md),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'pallet.flow.storage_info_title'.tr(),
              textAlign: TextAlign.center,
              style: AppTextStyles.h2.copyWith(color: swms.text1),
            ),
            const SizedBox(height: AppDimens.xs),
            Text(
              'pallet.flow.storage_info_subtitle'.tr(args: [widget.itemCode]),
              textAlign: TextAlign.center,
              style: AppTextStyles.caption.copyWith(color: swms.text4),
            ),
            const SizedBox(height: AppDimens.md),

            // ── Tab chọn cách bổ sung ──
            // Mã hàng đã có master -> chỉ còn 1 cách, ẩn thanh tab cho gọn
            // thay vì hiện một tab duy nhất không bấm được.
            if (widget.allowMasterMode) ...[
              _ModeSwitch(
                mode: _mode,
                onChanged: (m) => setState(() => _mode = m),
              ),
              const SizedBox(height: AppDimens.md),
            ],

            // ── Nội dung theo tab ──
            // IndexedStack cao bằng con cao nhất (vòng quay), nên tab master
            // ngắn hơn sẽ thừa chỗ. `alignment: center` chia phần thừa đều
            // trên/dưới thay vì dồn hết xuống đáy — nếu không, form master trông
            // như bị treo lơ lửng ở mép trên.
            if (widget.allowMasterMode)
              IndexedStack(
                alignment: Alignment.center,
                index: _mode.index,
                children: [_buildDimensionForm(), _buildMasterForm()],
              )
            else
              _buildDimensionForm(),

            const SizedBox(height: AppDimens.md + AppDimens.xs),
            Row(
              children: [
                Expanded(
                  child: AppButton(
                    label: 'common.cancel'.tr(),
                    variant: AppButtonVariant.neutral,
                    onPressed: () => Navigator.pop(context),
                  ),
                ),
                const SizedBox(width: AppDimens.sm + AppDimens.xs),
                // AppButton nếu nhận `onPressed` nullable thì đổi thành
                // `onPressed: _canSave ? _save : null` cho gọn.
                Expanded(
                  child: Opacity(
                    opacity: _canSave ? 1 : .45,
                    child: IgnorePointer(
                      ignoring: !_canSave,
                      child: AppButton(
                        label: 'common.confirm'.tr(),
                        onPressed: _save,
                      ),
                    ),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Thanh chuyển tab kiểu segmented (nền chìm, ô đang chọn nổi lên).
class _ModeSwitch extends StatelessWidget {
  const _ModeSwitch({required this.mode, required this.onChanged});

  final StorageInfoMode mode;
  final ValueChanged<StorageInfoMode> onChanged;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    Widget item(StorageInfoMode m, String key) {
      final selected = m == mode;
      return Expanded(
        child: GestureDetector(
          onTap: () => onChanged(m),
          behavior: HitTestBehavior.opaque,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 140),
            padding: const EdgeInsets.symmetric(vertical: AppDimens.sm),
            decoration: BoxDecoration(
              color: selected ? swms.primaryTint : Colors.transparent,
              borderRadius: BorderRadius.circular(AppDimens.rInput),
            ),
            child: Text(
              key.tr(),
              textAlign: TextAlign.center,
              style: AppTextStyles.caption.copyWith(
                fontWeight: FontWeight.w700,
                color: selected ? swms.primary : swms.text4,
              ),
            ),
          ),
        ),
      );
    }

    return Container(
      padding: const EdgeInsets.all(AppDimens.xs),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
      ),
      child: Row(
        spacing: AppDimens.xs,
        children: [
          item(StorageInfoMode.dimension, 'pallet.flow.tab_dimension'),
          item(StorageInfoMode.master, 'pallet.flow.tab_master'),
        ],
      ),
    );
  }
}

/// Tab 1: vòng quay chiều cao ngay tại chỗ.
class _DimensionForm extends StatelessWidget {
  const _DimensionForm({
    required this.initialHeightCm,
    required this.maxHeight,
    required this.onHeightChanged,
  });

  final int initialHeightCm;
  final int maxHeight;
  final ValueChanged<int> onHeightChanged;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      spacing: AppDimens.sm + AppDimens.xs,
      children: [
        _FieldLabel('pallet.flow.pallet_height'.tr()),
        Container(
          padding: const EdgeInsets.symmetric(vertical: AppDimens.xs),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppDimens.rInput),
            border: Border.all(color: swms.border),
          ),
          child: NumberDialPicker(
            initialValue: initialHeightCm,
            maxValue: maxHeight,
            unit: 'pallet.flow.unit_cm'.tr(),
            onChanged: (v) => onHeightChanged(v.round()),
          ),
        ),
      ],
    );
  }
}

/// Tab 2: khai báo thẳng khu / tầng vào master.
///
/// Khu chọn MỘT (cột suggest_area là FK đơn), tầng chọn NHIỀU (cột
/// suggest_rack_row là danh sách "2,3"). Ép tầng chọn một sẽ không bao giờ
/// khai được model dùng được cả 2-3 tầng.
///
/// Cả hai nhóm đều dùng lưới ô ĐỀU NHAU thay vì Wrap: mã khu dài ngắn khác
/// nhau ("FA" vs "SCM") và số tầng chỉ 1 ký tự, để Wrap tự co thì ra một hàng
/// ô to nhỏ lộn xộn — trên PDA đeo găng thì ô 1 ký tự còn khó bấm trúng.
class _MasterForm extends StatelessWidget {
  const _MasterForm({
    required this.areas,
    required this.rackRowOptions,
    required this.areaId,
    required this.rackRows,
    required this.onAreaChanged,
    required this.onRackRowToggled,
    required this.onRetry,
  });

  final AsyncValue<List<WarehouseArea>> areas;
  final List<int> rackRowOptions;
  final int? areaId;
  final Set<int> rackRows;
  final ValueChanged<int> onAreaChanged;
  final ValueChanged<int> onRackRowToggled;
  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      spacing: AppDimens.sm + AppDimens.xs,
      children: [
        _FieldLabel('pallet.flow.zone'.tr()),
        switch (areas) {
          AsyncLoading() => const _ChipGridSkeleton(),
          AsyncError() => _ChipsError(onRetry: onRetry),
          AsyncData(:final value) when value.isEmpty => _ChipsError(
            onRetry: onRetry,
          ),
          AsyncData(:final value) => _ChipGrid(
            children: [
              for (final a in value)
                _Chip(
                  label: a.code.isEmpty ? a.name : a.code,
                  tooltip: a.name,
                  selected: a.id == areaId,
                  onTap: () => onAreaChanged(a.id),
                ),
            ],
          ),
        },

        // Nhắc "chọn nhiều" ngay cạnh nhãn: ô tầng nhìn y hệt ô khu (chọn một),
        // không có gì trên màn hình cho biết ô này bấm được nhiều cái.
        _FieldLabel(
          'pallet.flow.floor'.tr(),
          hint: 'pallet.flow.floor_multi_hint'.tr(),
        ),
        _ChipGrid(
          // Đúng bằng số tầng -> gọn 1 hàng, các ô rộng bằng nhau.
          columns: math.max(rackRowOptions.length, 1),
          children: [
            for (final r in rackRowOptions)
              _Chip(
                label: 'pallet.flow.floor_value'.tr(args: ['$r']),
                selected: rackRows.contains(r),
                onTap: () => onRackRowToggled(r),
              ),
          ],
        ),
      ],
    );
  }
}

/// Lưới ô chọn rộng đều nhau, [columns] ô mỗi hàng.
///
/// Hàng cuối thiếu ô thì chèn chỗ trống để các ô còn lại giữ nguyên bề rộng —
/// nếu để chúng giãn ra cho đầy hàng thì cùng một danh sách khu, chỉ cần thêm
/// bớt một khu là cả lưới đổi kích thước.
class _ChipGrid extends StatelessWidget {
  const _ChipGrid({required this.children, this.columns = 3});

  final List<Widget> children;
  final int columns;

  @override
  Widget build(BuildContext context) {
    if (children.isEmpty) return const SizedBox.shrink();

    final rows = <Widget>[];
    for (var start = 0; start < children.length; start += columns) {
      final slice = children.sublist(
        start,
        math.min(start + columns, children.length),
      );
      rows.add(
        Row(
          children: [
            for (var c = 0; c < columns; c++) ...[
              if (c > 0) const SizedBox(width: AppDimens.sm),
              Expanded(
                child: c < slice.length ? slice[c] : const SizedBox.shrink(),
              ),
            ],
          ],
        ),
      );
    }

    return Column(
      mainAxisSize: MainAxisSize.min,
      spacing: AppDimens.sm,
      children: rows,
    );
  }
}

/// Chiều cao cố định của một ô chọn — dùng chung cho ô thật, skeleton và khung
/// báo lỗi để lưới không nhảy khi dữ liệu về.
const double _kChipHeight = 44;

class _Chip extends StatelessWidget {
  const _Chip({
    required this.label,
    required this.selected,
    required this.onTap,
    this.tooltip,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  /// Tên đầy đủ của khu — ô chỉ đủ chỗ cho mã.
  final String? tooltip;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final chip = GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 120),
        height: _kChipHeight,
        alignment: Alignment.center,
        padding: const EdgeInsets.symmetric(horizontal: AppDimens.sm),
        decoration: BoxDecoration(
          color: selected ? swms.primaryTint : swms.card2,
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          border: Border.all(
            color: selected ? swms.primary : swms.border,
            width: selected ? 1.4 : 1,
          ),
        ),
        child: Text(
          label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          textAlign: TextAlign.center,
          style: AppTextStyles.caption.copyWith(
            fontWeight: FontWeight.w700,
            color: selected ? swms.primary : swms.text2,
          ),
        ),
      ),
    );

    final tip = tooltip;
    return (tip == null || tip.isEmpty || tip == label)
        ? chip
        : Tooltip(message: tip, child: chip);
  }
}

/// Ô mờ khi đang nạp danh sách khu — giữ đúng dáng lưới thật để dialog không
/// giật một nhịp lúc dữ liệu về.
class _ChipGridSkeleton extends StatelessWidget {
  const _ChipGridSkeleton() : columns = 3, count = 3;

  final int count;
  final int columns;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return _ChipGrid(
      columns: columns,
      children: [
        for (var i = 0; i < count; i++)
          Container(
            height: _kChipHeight,
            decoration: BoxDecoration(
              color: swms.card2,
              borderRadius: BorderRadius.circular(AppDimens.rInput),
              border: Border.all(color: swms.border),
            ),
            alignment: Alignment.center,
            child: i == 0
                ? SizedBox(
                    width: 16,
                    height: 16,
                    child: CircularProgressIndicator(
                      strokeWidth: 2,
                      color: swms.text4,
                    ),
                  )
                : null,
          ),
      ],
    );
  }
}

class _ChipsError extends StatelessWidget {
  const _ChipsError({required this.onRetry});

  final VoidCallback onRetry;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      height: _kChipHeight,
      padding: const EdgeInsets.only(left: AppDimens.md),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              'pallet.flow.area_load_error'.tr(),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.caption.copyWith(color: swms.text4),
            ),
          ),
          IconButton(
            onPressed: onRetry,
            icon: const Icon(Icons.refresh_rounded, size: 20),
            color: swms.primary,
            visualDensity: VisualDensity.compact,
            tooltip: 'pallet.flow.suggestion_retry'.tr(),
          ),
        ],
      ),
    );
  }
}

class _FieldLabel extends StatelessWidget {
  const _FieldLabel(this.text, {this.hint});

  final String text;

  /// Chú thích phụ, canh phải trên cùng dòng nhãn.
  final String? hint;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final label = Text(
      text,
      style: AppTextStyles.caption.copyWith(
        fontWeight: FontWeight.w700,
        color: swms.text4,
      ),
    );

    final h = hint;
    if (h == null || h.isEmpty) return label;

    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      crossAxisAlignment: CrossAxisAlignment.baseline,
      textBaseline: TextBaseline.alphabetic,
      children: [
        Flexible(child: label),
        const SizedBox(width: AppDimens.sm),
        Text(h, style: AppTextStyles.caption.copyWith(color: swms.text4)),
      ],
    );
  }
}
