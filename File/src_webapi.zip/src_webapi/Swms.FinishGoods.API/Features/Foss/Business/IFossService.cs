using Swms.FinishGoods.API.Features.Foss.Api;
using Swms.FinishGoods.API.Features.Foss.DataAccess;

namespace Swms.FinishGoods.API.Features.Foss.Business;

public interface IFossService
{
    Task<List<FossPalletItemResponse>> GetPalletByBarcodeAsync(string barcode);
    Task<List<string>> GetTodayPalletsAsync();
    Task<Dictionary<string, FossPalletSummary>> GetPalletSummariesAsync(
        IReadOnlyCollection<string> barcodes);
}
