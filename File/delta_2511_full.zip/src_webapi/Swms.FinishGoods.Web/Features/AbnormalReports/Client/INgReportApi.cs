﻿using Refit;
using Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;

namespace Swms.FinishGoods.Web.Features.AbnormalReports.Client;

public interface INgReportApi
{
    [Get("/api/abnormal-reports")]
    Task<List<NgReportSummaryDto>> GetListAsync([Query] string? status, [Query] string? ngType,
        [Query] DateTime? from, [Query] DateTime? to, [Query] string? keyword);

    /// <summary>
    /// Xuất Excel danh sách. Nhận ĐỦ 8 bộ lọc như màn hình, kể cả 3 cái màn
    /// hình vẫn lọc tại trình duyệt — không truyền thì file chứa cả dòng đang
    /// bị ẩn.
    /// </summary>
    [Get("/api/abnormal-reports/report.xlsx")]
    Task<HttpResponseMessage> DownloadListReportAsync(
        [Query] string? status, [Query] string? ngType,
        [Query] DateTime? from, [Query] DateTime? to, [Query] string? keyword,
        [Query] string? faRes, [Query] string? oqc, [Query] string? finalRes);

    [Get("/api/abnormal-reports/{id}")]
    Task<NgReportDetailDto> GetAsync(long id);

    /// <summary>size = original | view | thumb</summary>
    [Get("/api/abnormal-reports/photos/{photoId}")]
    Task<HttpResponseMessage> GetPhotoAsync(long photoId, [Query] string size);

    [Put("/api/abnormal-reports/{id}")]
    Task UpdateAsync(long id, [Body] UpdateNgReportRequestDto request);

    [Delete("/api/abnormal-reports/photos/{photoId}")]
    Task DeletePhotoAsync(long photoId);

    [Get("/api/abnormal-reports/types")]
    Task<List<NgTypeDto>> GetTypesAsync();

    [Get("/api/abnormal-reports/{id}/mail-preview")]
    Task<MailPreviewDto> GetMailPreviewAsync(long id);

    [Post("/api/abnormal-reports/{id}/leader-review")]
    Task LeaderReviewAsync(long id, [Body] LeaderReviewRequestDto request);

    [Post("/api/abnormal-reports/{id}/fa-confirm")]
    Task FaConfirmAsync(long id, [Body] FaConfirmRequestDto request);

    [Post("/api/abnormal-reports/{id}/oqc-confirm")]
    Task OqcConfirmAsync(long id, [Body] OqcConfirmRequestDto request);

    /// <summary>FA báo đã xử lý xong lượt NG, để OQC đánh giá lại.</summary>
    [Post("/api/abnormal-reports/{id}/fa-fix-done")]
    Task FaFixDoneAsync(long id, [Body] FaFixDoneRequestDto request);
    // ---- Quản trị danh mục loại lỗi (quyền abnormal_report.manage_types) ----

    [Get("/api/abnormal-reports/types/all")]
    Task<List<NgTypeAdminDto>> GetTypesForAdminAsync();

    [Put("/api/abnormal-reports/types")]
    Task SaveTypeAsync([Body] SaveNgTypeRequestDto request);

    [Delete("/api/abnormal-reports/types/{code}")]
    Task DeleteTypeAsync(string code);
}
