using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models
{
    public class ReceivingSchedule
    {

        [BindProperty]
        [Display(Name = "SAP export blocked.")]
        public bool IsBlock { get; set; }
        public DateTime? BlockDate { get; set; }
        public DateTime? DatePrint { get; set; }
    }
}
