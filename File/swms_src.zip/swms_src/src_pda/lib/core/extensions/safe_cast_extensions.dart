extension SafeCastExtension on Object? {
  T? safeCast<T>() {
    return this is T ? this as T : null;
  }

  T castOrThrow<T>([String? message]) {
    if (this is T) {
      return this as T;
    }

    throw FormatException(
      message ?? 'Cannot cast $runtimeType to $T',
    );
  }
}

extension DynamicExtension on dynamic {
  String? asString() => this?.toString();

  int? asInt() {
    final value = this;

    if (value is int) return value;
    if (value is num) return value.toInt();

    return int.tryParse(value?.toString() ?? '');
  }

  bool? asBool() {
    final value = this;

    if (value is bool) return value;

    switch (value?.toString().toLowerCase()) {
      case 'true':
        return true;
      case 'false':
        return false;
      default:
        return null;
    }
  }
}