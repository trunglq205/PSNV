﻿using ClosedXML.Excel;

namespace CriticalListReport.Helpers
{
    public class ExcelUploadHelper
    {
        public async Task<List<T>> ParseExcelAsync<T>(IFormFile file, Func<IXLRow, T?> mapRow)
            where T : class
        {
            var list = new List<T>();

            using (var stream = new MemoryStream())
            {
                await file.CopyToAsync(stream);
                stream.Position = 0;

                using (var workbook = new XLWorkbook(stream))
                {
                    var worksheet = workbook.Worksheet(1);
                    var rows = worksheet.RowsUsed();

                    if (!rows.Any()) return list;

                    var headerRowNumber = worksheet.FirstRowUsed().RowNumber();

                    foreach (var row in rows.Where(r => r.RowNumber() > headerRowNumber))
                    {
                        var entity = mapRow(row);
                        if (entity != null)
                            list.Add(entity);
                    }
                }
            }

            return list;
        }
    }
}
