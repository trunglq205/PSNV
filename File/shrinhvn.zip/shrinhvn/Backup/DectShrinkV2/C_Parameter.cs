﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DectShrinkV2
{
    class C_Parameter
    {
        public string Pass_Admin { get; set; }
    }
}
