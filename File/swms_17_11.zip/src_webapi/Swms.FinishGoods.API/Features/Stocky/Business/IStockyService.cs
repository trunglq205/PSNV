using Swms.FinishGoods.API.Features.Stocky.Api;

namespace Swms.FinishGoods.API.Features.Stocky.Business;

public interface IStockyService
{
    /// <summary>Danh sách xe kèm vị trí và tình trạng rỗng / có hàng.</summary>
    Task<IReadOnlyList<StockyCartResponse>> GetListAsync(StockyQuery query);

    /// <summary>
    /// Tra một xe vừa quét và kiểm xe có đi được theo chiều <paramref name="mode"/>
    /// không. Sai chiều thì ném <c>ConflictException</c> (HTTP 409) — PDA map
    /// 409 thành <c>StockyInvalidStateException</c> và hiện đúng câu tiếng Việt.
    /// </summary>
    /// <param name="mode">
    /// in = nhận vào kho (xe mới từ vendor HOẶC xe đang ở FA đưa về),
    /// fa = đẩy sang FA, out = trả về vendor.
    /// </param>
    Task<StockyLookupResponse> LookupAsync(string code, string? mode);

    /// <summary>
    /// Nhận một lô xe vào kho: xe mới từ vendor, xe vendor giao lại, hoặc xe
    /// đang ở FA được đưa về kho (ô xe được kéo về bãi đậu).
    /// </summary>
    Task<StockySubmitResponse> ReceiveAsync(StockyBatchRequest request);

    /// <summary>
    /// Đẩy một lô xe sang FA. Xe VẪN được quản lý, chỉ đổi vị trí — khác hẳn
    /// <see cref="ReturnAsync"/>.
    /// </summary>
    Task<StockySubmitResponse> ExportToFaAsync(StockyBatchRequest request);

    /// <summary>
    /// Trả một lô xe VỀ VENDOR. Xe rời hệ thống và biến mất khỏi danh sách
    /// theo dõi — đây là trạng thái cuối duy nhất.
    /// </summary>
    Task<StockySubmitResponse> ReturnAsync(StockyBatchRequest request);

    /// <summary>
    /// Đặt MỘT xe vào MỘT ô trong kho. Hàng trên xe đi theo xe.
    ///
    /// Khác ba chiều kia ở chỗ đây không phải chuyện xe có còn được quản lý hay
    /// không — xe vẫn <c>in_warehouse</c>, chỉ đổi chỗ đứng.
    /// </summary>
    Task<StockyPlaceResponse> PlaceAsync(StockyPlaceRequest request);
}
