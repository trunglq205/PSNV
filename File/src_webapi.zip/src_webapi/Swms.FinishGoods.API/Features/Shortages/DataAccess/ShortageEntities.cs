namespace Swms.FinishGoods.API.Features.Shortages.DataAccess;

/// <summary>1 dòng SI đang mở còn thiếu (trước khi trừ tồn chưa phân bổ).</summary>
public class OpenShortLine
{
    public long LineId { get; set; }
    public long SiId { get; set; }
    public int? CategoryId { get; set; }
    public string SiNo { get; set; } = "";
    public string Model { get; set; } = "";
    public string? Category { get; set; }
    public string? ShipMode { get; set; }
    public DateTime VanningDate { get; set; }       // COALESCE(vanning_date, etd_date)
    public string? ForwarderCode { get; set; }      // = Vanning place
    public string? ConsigneeCode { get; set; }
    public string? CountryCode { get; set; }
    public string? PoNo { get; set; }
    public int QtyShort { get; set; }
}

/// <summary>1 pallet có hàng của model — đã phân loại bucket.</summary>
public class StockPalletRow
{
    public string Model { get; set; } = "";
    public long PalletId { get; set; }
    public string PalletCode { get; set; } = "";
    public string? LocatorCode { get; set; }
    public string? AreaCode { get; set; }
    public DateTime? ProductionDate { get; set; }
    public int Qty { get; set; }            // pcs của model trên pallet, trừ thùng đã bị SI giữ
    public int Reserved { get; set; }       // pcs dòng fifo pending đã hứa (chưa biết thùng nào)
    public string? Bucket { get; set; }     // NG | FA_UNDELIVERED | RECEIVING | OQC | ALLOCATED | AVAILABLE | null
    public string? HeldBySi { get; set; }
}

public class ProducingRow
{
    public string Model { get; set; } = "";
    public int Qty { get; set; }
}

/// <summary>1 dòng wms.shipment_instruction_shortages — chỉ còn dùng "đã đòi lúc nào".
/// Các cột due_at / eta_at / confirmed_* / reason vẫn còn trong bảng (dữ liệu cũ) nhưng không đọc nữa.</summary>
public class FollowUpRow
{
    public long LineId { get; set; }
    public string ReasonCode { get; set; } = "";
    public int QtyShort { get; set; }
    public DateTime NotifiedAt { get; set; }
}

/// <summary>Mẫu mail trong master.email_events. Class có property (không dùng ValueTuple)
/// để Dapper map theo TÊN cột.</summary>
public class ShortageMailTemplateRow
{
    public string? Subject { get; set; }
    public string? Body { get; set; }
}

/// <summary>master.shortage_reasons — thứ tự xét bucket nằm ở sort_order.</summary>
public class ReasonRow
{
    public string Code { get; set; } = "";
    public string Department { get; set; } = "";
    public bool IsPlanOnly { get; set; }
    public int SortOrder { get; set; }
}
