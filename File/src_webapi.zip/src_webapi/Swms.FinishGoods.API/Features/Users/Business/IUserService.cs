using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Users.Api;

namespace Swms.FinishGoods.API.Features.Users.Business;

public interface IUserService
{
    Task<UserResponse> GetByIdAsync(int id);
    Task<PagedResult<UserResponse>> GetPagedAsync(UserQuery query);
    Task<UserResponse> CreateAsync(CreateUserRequest request);
    Task<List<UserResponse>> BulkCreateAsync(IReadOnlyList<CreateUserRequest> requests);
    Task UpdateAsync(int id, UpdateUserRequest request);
    Task DeleteAsync(int id);
    Task<UserDeptCountResponse> GetDeptCountsAsync();
    Task ResetPasswordAsync(int id);
    Task<List<RoleOptionResponse>> GetRoleOptionsAsync();
}
