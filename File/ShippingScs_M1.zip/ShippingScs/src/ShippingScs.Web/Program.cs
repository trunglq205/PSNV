using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShippingScs.Web.Data;
using ShippingScs.Web.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews(options =>
{
    // Mọi POST đều kiểm anti-forgery token (form dùng asp-* tag helper tự có token)
    options.Filters.Add(new AutoValidateAntiforgeryTokenAttribute());
});

builder.Services
    .AddAuthentication(CookieAuthenticationDefaults.AuthenticationScheme)
    .AddCookie(options =>
    {
        options.LoginPath = "/Account/Login";
        options.AccessDeniedPath = "/Account/AccessDenied";
        options.ExpireTimeSpan = TimeSpan.FromHours(10);
        options.SlidingExpiration = true;
    });

// Mặc định mọi trang đều phải đăng nhập; trang nào mở công khai thì gắn [AllowAnonymous]
builder.Services.AddAuthorization(options =>
{
    options.FallbackPolicy = new AuthorizationPolicyBuilder().RequireAuthenticatedUser().Build();
});

builder.Services.AddHttpContextAccessor();
builder.Services.AddSingleton<Db>();
builder.Services.AddScoped<UserService>();
builder.Services.AddScoped<ChangeLogService>();
builder.Services.AddScoped<WorkingCalendarService>();

var app = builder.Build();

if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
    // Chỉ ép HTTPS trên server thật. Dev chạy profile "http" thì không cần chứng chỉ.
    app.UseHttpsRedirection();
}
app.UseStaticFiles();
app.UseRouting();
app.UseAuthentication();
app.UseAuthorization();

app.MapControllerRoute(name: "default", pattern: "{controller=Home}/{action=Index}/{id?}");

await SeedAdminAsync(app);

app.Run();

// Bảng Users trống thì tạo 1 admin từ cấu hình SeedAdmin. Sau khi đăng nhập được, xoá Password khỏi config.
static async Task SeedAdminAsync(WebApplication app)
{
    using var scope = app.Services.CreateScope();
    var users = scope.ServiceProvider.GetRequiredService<UserService>();
    var logger = scope.ServiceProvider.GetRequiredService<ILogger<Program>>();

    if (await users.CountAsync() > 0) return;

    var userName = app.Configuration["SeedAdmin:UserName"];
    var password = app.Configuration["SeedAdmin:Password"];
    if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrWhiteSpace(password))
    {
        logger.LogWarning("Users table is empty. Set SeedAdmin:UserName and SeedAdmin:Password to create the first admin.");
        return;
    }

    await users.CreateAsync(new ShippingScs.Web.Models.UserEditModel
    {
        UserName = userName,
        FullName = "Administrator",
        Role = ShippingScs.Web.Models.Roles.Admin,
        IsActive = true,
        NewPassword = password,
    });
    logger.LogInformation("Created first admin user '{UserName}'.", userName);
}
