import 'package:logger/logger.dart';

final logger = AppLogger();

/// Bọc package logger để toàn app dùng cùng cấu hình.
class AppLogger {
  final Logger _logger;

  AppLogger()
      : _logger = Logger(
          printer: PrettyPrinter(
            errorMethodCount: 5,
            lineLength: 80,
          ),
        );

  void d(String message) => _logger.d(message);
  void i(String message) => _logger.i(message);
  void w(String message) => _logger.w(message);
  void e(String message, {Object? error, StackTrace? stackTrace}) =>
      _logger.e(message, error: error, stackTrace: stackTrace);
}
