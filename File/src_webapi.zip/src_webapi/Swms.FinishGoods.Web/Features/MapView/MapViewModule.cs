using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.MapView.Business;
using Swms.FinishGoods.Web.Features.MapView.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.MapView;

public static class MapViewModule
{
    public static IServiceCollection AddMapViewFeature(this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<IMapViewApi>(api);
        services.AddScoped<IMapViewBusiness, MapViewBusiness>();
        return services;
    }
}
