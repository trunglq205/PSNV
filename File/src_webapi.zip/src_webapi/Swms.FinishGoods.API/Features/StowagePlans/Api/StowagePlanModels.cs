using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Swms.FinishGoods.API.Features.StowagePlans.Api;

// Request / response cho màn Stowage Plan. Khớp IStowagePlanApi (Refit) + StowagePlanDto.cs bên Web —
// đổi tên / kiểu ở đây thì đổi cả bên Web.

/// <summary>Trạng thái lập sơ đồ. DB: not_started | draft | saved.</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum StowageStatus { NotStarted, Draft, Saved }

/// <summary>Loại đế pallet, suy từ shipment_instructions.packing_type (xem StowagePlanService.BaseOfPacking).
/// DB: wood | plastic | no_base | loose | paper.</summary>
[JsonConverter(typeof(JsonStringEnumConverter))]
public enum PalletBaseType { Wood, Plastic, NoBase, Loose, Paper }

// ── Query ───────────────────────────────────────────────────
public class StowagePlanQuery
{
    [MaxLength(50)] public string? Keyword { get; set; }
    public StowageStatus? Status { get; set; }
    /// <summary>Lọc theo ngày (giống màn Chuyến xe): giờ dự kiến đến của chuyến hoặc ngày vanning / ETD của SI.
    /// To null = chỉ ngày From. Cả 2 null = không lọc ngày.</summary>
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
}

// ── Response ────────────────────────────────────────────────
/// <summary>1 dòng danh sách bên trái. Chuyến container chưa lập sơ đồ: PlanNo = "VP-T{tripId}", NotStarted.</summary>
public class VanningPlanSummaryDto
{
    public string PlanNo { get; set; } = "";
    public long? TripId { get; set; }
    public string? TripNo { get; set; }
    public string UnitKind { get; set; } = "CONT";      // CONT | ULD | LOT
    public string UnitNo { get; set; } = "";
    public string ContainerType { get; set; } = "";
    public string Destination { get; set; } = "";
    public string Mode { get; set; } = "FCL";           // FCL | LCL | AIR
    public int SiCount { get; set; }
    public int BoxCount { get; set; }
    public StowageStatus Status { get; set; }
    public int PlacedColumns { get; set; }
    public int TotalColumns { get; set; }
}

public class StowageSiDto
{
    public string SiNo { get; set; } = "";
    public string Customer { get; set; } = "";
    public string? Color { get; set; }
    /// <summary>Packing type trên SI: CARTON BOX | Double Carton | Paper pallet | PLASTIC PALLET | SLIP SHEET.</summary>
    public string? PackingType { get; set; }
    /// <summary>Loại đế suy từ PackingType (null = SI không ghi -> theo đế chung của plan).</summary>
    public PalletBaseType? BaseType { get; set; }
}

/// <summary>BoxNo = khoá thùng trong plan: số box thật (trùng giữa 2 SI thì "{box_no}#{id}"),
/// thùng dự kiến "{si_no}/{line_no}/{seq:000}".</summary>
public class StowageBoxDto
{
    public string BoxNo { get; set; } = "";
    public string SiNo { get; set; } = "";
    public string Model { get; set; } = "";
    public double Length { get; set; }                  // cm
    public double Width { get; set; }
    public double Height { get; set; }
    public double Weight { get; set; }                  // kg
    public string? Color { get; set; }
    /// <summary>Tối đa số tầng / pallet theo master.models.layer_limit (null = không giới hạn).</summary>
    public int? LayerLimit { get; set; }
    /// <summary>true = thùng dự kiến (chưa lấy hàng): số thùng = số lượng / standard_packing.</summary>
    public bool IsEstimated { get; set; }
    /// <summary>Số cái trong thùng (null = không biết).</summary>
    public int? Qty { get; set; }
    public string? Category { get; set; }
    public int? LayerCount { get; set; }
    /// <summary>master.models.stacking_length / stacking_width: 1 tầng = dài × rộng thùng. null = tự tính.</summary>
    public int? StackingLength { get; set; }
    public int? StackingWidth { get; set; }
}

public class StowagePalletDto
{
    [Required, MaxLength(60)] public string PalletNo { get; set; } = "";   // id; pallet mới bên Web = "TMP-…"
    [Required, MaxLength(10)] public string Code { get; set; } = "";
    [Required, MaxLength(30)] public string SiNo { get; set; } = "";
    [MaxLength(10)] public string Size { get; set; } = "S1210";
    /// <summary>Mặt bằng chiếm sàn (cm). Pallet có đế = cỡ đế; slip sheet / thùng rời = mặt khối thùng.</summary>
    [Range(1, 400)] public double PalletLength { get; set; } = 120;     // 1 số lẻ (VD 118,5)
    [Range(1, 400)] public double PalletWidth { get; set; } = 100;
    public List<string> BoxNos { get; set; } = new();
}

public class StowageColumnDto
{
    [Required, MaxLength(60)] public string ColumnNo { get; set; } = "";
    [Required, MaxLength(10)] public string Code { get; set; } = "";
    [MaxLength(60)] public string? BottomPalletNo { get; set; }
    [MaxLength(60)] public string? TopPalletNo { get; set; }
}

public class StowagePlacementDto
{
    [Range(0, 99)] public int ContainerIndex { get; set; }
    [Range(0, 999)] public int Row { get; set; }
    [Range(0, 9)] public int Lane { get; set; }
    [Required, MaxLength(60)] public string ColumnNo { get; set; } = "";
    /// <summary>true = xoay ngang (cạnh rộng pallet nằm dọc container). DB: stowage_columns.rotated.</summary>
    public bool Rotated { get; set; }
}

public class StowagePlanDto
{
    public string PlanNo { get; set; } = "";
    public long? TripId { get; set; }
    public string? TripNo { get; set; }
    public string UnitKind { get; set; } = "CONT";
    public string UnitNo { get; set; } = "";
    public string ContainerType { get; set; } = "";
    public string Destination { get; set; } = "";
    public DateTime? Etd { get; set; }
    public string? Forwarder { get; set; }
    public string Mode { get; set; } = "FCL";
    public PalletBaseType BaseType { get; set; } = PalletBaseType.NoBase;
    public StowageStatus Status { get; set; }
    public int ContainerCount { get; set; } = 1;

    public List<StowageSiDto> Sis { get; set; } = new();
    public List<StowageBoxDto> Boxes { get; set; } = new();
    public List<StowagePalletDto> Pallets { get; set; } = new();
    public List<StowageColumnDto> Columns { get; set; } = new();
    public List<StowagePlacementDto> Placements { get; set; } = new();
}

// ── Request ─────────────────────────────────────────────────
/// <summary>PUT /api/stowage-plans/{planNo}: thay toàn bộ pallet / cọc / vị trí.
/// Complete do server tự tính (mọi cọc đã có vị trí), giá trị gửi lên chỉ để tham khảo.</summary>
public class SaveStowagePlanRequest
{
    /// <summary>Không dùng nữa: loại đế lấy theo packing type của SI. Giữ để Web cũ gửi lên không lỗi.</summary>
    public PalletBaseType BaseType { get; set; }
    [Range(1, 20)] public int ContainerCount { get; set; } = 1;
    public bool Complete { get; set; }
    [MaxLength(2000)] public List<StowagePalletDto> Pallets { get; set; } = new();
    [MaxLength(2000)] public List<StowageColumnDto> Columns { get; set; } = new();
    [MaxLength(2000)] public List<StowagePlacementDto> Placements { get; set; } = new();
}