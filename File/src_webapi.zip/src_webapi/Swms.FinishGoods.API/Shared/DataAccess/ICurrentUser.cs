﻿namespace Swms.FinishGoods.API.Shared.DataAccess
{
    public interface ICurrentUser
    {
        long? UserId { get; }
        string? EmployeeCode { get; }
        string? FullName { get; }
        bool IsAuthenticated { get; }
    }
}
