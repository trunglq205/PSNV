/* ============================================================================
   Soi 1 pallet: vì sao KHÔNG có nút "Out kho" / không có dấu RW-RB    (12/11)

   DÙNG KHI:
     • Màn PDA "Chuyển / Out vị trí" chỉ thấy "Chuyển trong kho", không thấy
       "Out kho (giao FA)".
     • Quét vị trí ở khu Nhận hàng thì báo "Vị trí PLxx thuộc khu Khu vực nhận
       hàng, không đúng khu của màn này".
     • Màn chi tiết pallet không hiện dấu RW / RB.

   BA TRIỆU CHỨNG TRÊN LÀ MỘT NGUYÊN NHÂN. Khi server không coi pallet là hàng
   tái gia công, nó không trả action `move_receiving`; PDA chỉ còn MỘT hành
   động nên tự chọn "Chuyển trong kho", và màn đó chỉ nhận vị trí thuộc khu lưu
   trữ -> quét PL15 (khu Nhận hàng) là sai khu. Không phải PDA chặn sai, mà là
   nút kia chưa bao giờ được mở.

   Server coi pallet là hàng tái gia công khi:
       wms.pallets.disposition IS NOT NULL                (dấu, do luồng nhận
                                                            hàng back đóng)
    HOẶC pallet đang giữ serial trong wms.return_instruction_serials
                                                           (sổ serial — thêm
                                                            12/11, cho dữ liệu
                                                            cũ chưa có dấu)

   CHẠY:
     Sửa @PalletId ở Mục 1 rồi chạy cả file. Mục 1-4 CHỈ ĐỌC.
     Mục 5 có vá dữ liệu, mặc định @WhatIf = 1 (không ghi).
   ========================================================================= */

/* ---------- 0. Điều kiện tiên quyết — BATCH RIÊNG, có GO ----------

   SQL Server bind TÊN CỘT lúc compile CẢ batch: thiếu một cột là toàn bộ batch
   dưới không chạy và chỉ ném lỗi 207 trơ trọi. Batch này chạy trước, in ra
   đúng việc phải làm.                                                        */

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID(N'wms.pallets') AND name = N'disposition')
    RAISERROR(N'THIEU cot wms.pallets.disposition — chay return_back_merge_schema.sql truoc.', 16, 1);

IF OBJECT_ID(N'wms.return_instruction_serials') IS NULL
    RAISERROR(N'THIEU bang wms.return_instruction_serials — chay return_receiving_schema.sql truoc.', 16, 1);

IF NOT EXISTS (SELECT 1 FROM sys.columns
               WHERE object_id = OBJECT_ID(N'wms.return_instructions') AND name = N'back_status')
    RAISERROR(N'THIEU cot wms.return_instructions.back_status — chay return_back_merge_schema.sql truoc.', 16, 1);
GO

SET NOCOUNT ON;

/* ---------- 1. Pallet cần soi ---------- */

DECLARE @PalletId nvarchar(50) = N'311261111001';   -- <<< SỬA Ở ĐÂY
DECLARE @WhatIf   bit          = 1;                 -- Mục 5: 0 = ghi thật

DECLARE @actor nvarchar(100) = N'fix 12/11';

DECLARE @id bigint = (
    SELECT TOP 1 p.id
    FROM   wms.pallets p
    WHERE  (RTRIM(p.pallet_id) = @PalletId OR RTRIM(p.stocky_code) = @PalletId)
      AND  p.is_deleted = 0
    ORDER BY p.id DESC);

IF @id IS NULL
BEGIN
    PRINT CONCAT(N'KHONG TIM THAY pallet ', @PalletId, N' (hoac da bi xoa mem).');
    RETURN;
END

/* ---------- 2. Đúng những gì API đọc ----------

   Ba cột cuối là KẾT LUẬN, đọc từ phải sang trái:
     la_hang_rw_rb = 0  -> server không mở nút Out kho (xem Mục 5 để vá)
     co_nut_out    = 0  -> PDA chỉ còn "Chuyển trong kho" -> quét vị trí khu
                           Nhận hàng sẽ báo sai khu                            */

PRINT N'--- 2. Trang thai pallet (dung nguon ma API doc) ---';

SELECT  RTRIM(p.pallet_id)      AS pallet_id,
        p.disposition           AS disposition,
        p.inspection_status     AS inspection_status,
        loc.locator_code        AS vi_tri,
        a.area_name             AS khu,
        a.map_type              AS loai_khu,
        CAST(CASE WHEN EXISTS (SELECT 1 FROM wms.return_instruction_serials ris
                               WHERE ris.pallet_id = p.id AND ris.is_deleted = 0)
                  THEN 1 ELSE 0 END AS bit)                      AS co_serial_phieu_back,
        CAST(CASE WHEN p.disposition IS NOT NULL
                    OR EXISTS (SELECT 1 FROM wms.return_instruction_serials ris
                               WHERE ris.pallet_id = p.id AND ris.is_deleted = 0)
                  THEN 1 ELSE 0 END AS bit)                      AS la_hang_rw_rb,
        CAST(CASE WHEN a.map_type = N'storing'
                   AND (p.disposition IS NOT NULL
                        OR EXISTS (SELECT 1 FROM wms.return_instruction_serials ris
                                   WHERE ris.pallet_id = p.id AND ris.is_deleted = 0))
                  THEN 1 ELSE 0 END AS bit)                      AS co_nut_out_kho,
        CAST(CASE WHEN p.disposition IN (N'rework', N'refurbish')
                  THEN 1 ELSE 0 END AS bit)                      AS co_dau_rw_rb_tren_man
FROM      wms.pallets p
LEFT JOIN master.locators        loc ON loc.id = p.locator_id AND loc.is_deleted = 0
LEFT JOIN master.warehouse_areas a   ON a.id  = loc.area_id   AND a.is_deleted = 0
WHERE     p.id = @id;

/* ---------- 3. Phiếu back của pallet này + cổng duyệt SCS ----------

   Thấy nút Out kho rồi vẫn bị chặn khi BẤM thì xem cột back_status: phải là
   `scs_approved`. Quản lý SCS chưa duyệt thì chỉ chuyển nội bộ trong kho được
   (nghiệp vụ chốt 11/11) — API trả 400 Return.Back.Err.MoveNeedScsApprove.   */

PRINT N'';
PRINT N'--- 3. Phieu back dang giu serial cua pallet nay ---';

SELECT  d.id                AS doc_id,
        d.doc_no            AS so_phieu,
        d.goods_type        AS loai_hang,
        d.doc_status         AS trang_thai_phieu,
        d.back_status       AS trang_thai_back,
        CAST(CASE WHEN d.back_status = N'scs_approved' THEN 1 ELSE 0 END AS bit)
                            AS scs_da_duyet_out_kho,
        COUNT(*)            AS so_serial_tren_pallet,
        SUM(CASE WHEN ris.status = N'received' THEN 1 ELSE 0 END) AS con_o_kho_scs,
        SUM(CASE WHEN ris.status = N'at_fa'    THEN 1 ELSE 0 END) AS da_giao_fa
FROM    wms.return_instruction_serials ris
JOIN    wms.return_instructions d ON d.id = ris.doc_id
WHERE   ris.pallet_id = @id
  AND   ris.is_deleted = 0
GROUP BY d.id, d.doc_no, d.goods_type, d.doc_status, d.back_status
ORDER BY d.id;

IF @@ROWCOUNT = 0
    PRINT N'  (khong co serial phieu back nao tro vao pallet nay — day la pallet hang thuong, hoac serial da chuyen sang pallet khac)';

/* ---------- 4. Toàn bộ pallet hàng back đang THIẾU DẤU ----------

   Pallet có serial phiếu back nhưng disposition rỗng. Mã lệnh từ 12/11 vẫn mở
   nút Out kho cho những con này (đọc sổ serial), NHƯNG màn hình không vẽ được
   dấu RW / RB vì dấu lấy theo `disposition`. Mục 5 vá.                       */

PRINT N'';
PRINT N'--- 4. Pallet hang back THIEU dau disposition ---';

SELECT  RTRIM(p.pallet_id)  AS pallet_id,
        p.inspection_status AS inspection_status,
        loc.locator_code    AS vi_tri,
        a.map_type          AS loai_khu,
        MIN(d.doc_no)       AS phieu,
        MIN(d.goods_type)   AS dau_se_dong,
        COUNT(DISTINCT d.goods_type) AS so_loai_hang,
        COUNT(*)            AS so_serial
FROM      wms.return_instruction_serials ris
JOIN      wms.return_instructions d   ON d.id = ris.doc_id
JOIN      wms.pallets p               ON p.id = ris.pallet_id AND p.is_deleted = 0
LEFT JOIN master.locators        loc  ON loc.id = p.locator_id AND loc.is_deleted = 0
LEFT JOIN master.warehouse_areas a    ON a.id  = loc.area_id   AND a.is_deleted = 0
WHERE     ris.is_deleted = 0
  AND     p.disposition IS NULL
GROUP BY  p.pallet_id, p.inspection_status, loc.locator_code, a.map_type
ORDER BY  p.pallet_id;

DECLARE @thieu int = @@ROWCOUNT;
PRINT CONCAT(N'  Tong: ', @thieu, N' pallet thieu dau.');

/* ---------- 5. Vá: đóng dấu disposition theo loại hàng của phiếu ----------

   Đóng luôn inspection_status = 'ng' cho khớp pallet sinh ra sau 11/11: NG là
   BẢN CHẤT của hàng tái gia công, và bộ gom hàng xuất chỉ loại pallet bằng
   `inspection_status <> 'ng'` — để 'inspection_exempt' là hàng back vẫn có thể
   bị gom vào một chỉ thị xuất và đi ra cổng.

   BỎ QUA pallet đang giữ serial của HAI loại phiếu khác nhau (rework lẫn
   refurbish): một pallet chỉ có một dấu, chọn bừa là nói sai về hàng. Mục 4 in
   cột so_loai_hang để nhận ra; những con đó phải tách pallet trước.          */

IF @WhatIf = 1
BEGIN
    PRINT N'';
    PRINT N'@WhatIf = 1 — KHONG ghi gi. Doc ky Muc 4 roi dat @WhatIf = 0 va chay lai.';
END
ELSE IF @thieu > 0
BEGIN
    BEGIN TRAN;

    UPDATE  p
    SET     p.disposition      = x.goods_type,
            p.inspection_status = N'ng',
            p.updated_at       = SYSDATETIME(),
            p.updated_by       = @actor
    FROM    wms.pallets p
    JOIN   (SELECT   ris.pallet_id,
                     MIN(d.goods_type) AS goods_type
            FROM     wms.return_instruction_serials ris
            JOIN     wms.return_instructions d ON d.id = ris.doc_id
            WHERE    ris.is_deleted = 0
            GROUP BY ris.pallet_id
            HAVING   COUNT(DISTINCT d.goods_type) = 1) x
           ON x.pallet_id = p.id
    WHERE   p.is_deleted = 0
      AND   p.disposition IS NULL;

    PRINT CONCAT(N'Da dong dau cho ', @@ROWCOUNT, N' pallet.');

    COMMIT;
END
GO

/* ---------- 6. Index cho cột pallet_id của sổ serial ----------

   Mã 12/11 thêm một EXISTS theo `ris.pallet_id` vào câu đọc thông tin pallet —
   câu chạy MỖI LẦN quét pallet trên PDA, và cả theo lô trong job đồng bộ HD
   soft. Index hiện có là ix_ris_pickable(doc_id, pallet_id), cột dẫn đầu là
   doc_id nên lookup theo pallet_id KHÔNG seek được.                          */

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE name = N'ix_ris_pallet'
                 AND object_id = OBJECT_ID(N'wms.return_instruction_serials'))
BEGIN
    CREATE NONCLUSTERED INDEX ix_ris_pallet
        ON wms.return_instruction_serials (pallet_id)
        WHERE is_deleted = 0;
    PRINT N'+ Da tao index ix_ris_pallet.';
END
ELSE
    PRINT N'= ix_ris_pallet da co.';
GO
