using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.Balance.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.Balance;

public static class BalanceModule
{
    public static IServiceCollection AddBalanceFeature(this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<IBalanceApi>(api);
        return services;
    }
}
