import 'dart:async';

import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/router/router_provider.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';

/// Chỉ màn đang ở trên cùng mới nghe scanStream.
/// - Route được hiển thị (didPush / didPopNext) → bắt đầu nghe.
/// - Có màn khác đè lên (didPushNext) hoặc bị pop (didPop) → ngưng nghe.
mixin PdaScanRouteAware<T extends ConsumerStatefulWidget> on ConsumerState<T>
implements RouteAware {
  StreamSubscription<String>? _scanSub;
  RouteObserver<ModalRoute<void>>? _observer;
  ModalRoute<void>? _route;

  /// Cờ mong muốn: đang cần nghe hay không. Dùng để chặn race khi
  /// `_startScan` còn đang await pdaProvider mà route đã bị đè.
  bool _wantScan = false;

  /// Màn con cài đặt: xử lý mã vừa quét.
  void onScan(String data);

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final route = ModalRoute.of(context);
    if (route is! ModalRoute<void> || route == _route) return;

    _observer ??= ref.read(routeObserverProvider);
    if (_route != null) _observer!.unsubscribe(this);
    _route = route;
    // subscribe() gọi didPush() ngay lập tức → bắt đầu nghe tại đó.
    _observer!.subscribe(this, route);
  }

  @override
  void dispose() {
    _observer?.unsubscribe(this);
    _stopScan();
    super.dispose();
  }

  // ── RouteAware ──────────────────────────────────────────────
  @override
  void didPush() => _startScan();

  @override
  void didPopNext() => _startScan();

  @override
  void didPushNext() => _stopScan();

  @override
  void didPop() => _stopScan();

  // ── Internal ────────────────────────────────────────────────
  Future<void> _startScan() async {
    _wantScan = true;
    if (_scanSub != null) return;

    final pda = await ref.read(pdaProvider.future);
    // Trong lúc await: page có thể đã dispose, đã bị đè, hoặc đã có sub.
    if (!mounted || !_wantScan || _scanSub != null) return;

    _scanSub = pda.scanStream.listen(onScan);
  }

  void _stopScan() {
    _wantScan = false;
    _scanSub?.cancel();
    _scanSub = null;
  }

  // ── Ngưng theo Ý MUỐN của màn, ngoài cơ chế route ───────────

  /// Ngưng nghe khi màn mở một hộp thoại TỰ NGHE scanStream — ví dụ hộp chọn
  /// máy in, nơi người dùng quét MÃ MAC. `printer_picker_dialog.dart` ghi rõ
  /// nó KHÔNG tự ngưng hộ màn gọi, nên màn gọi phải tự lo.
  ///
  /// Hộp thoại nào đẩy route thì didPushNext đã ngưng sẵn; hàm này là lớp thứ
  /// hai, để một hộp thoại dựng bằng overlay (không có route) cũng không lọt
  /// mã. Gọi hai lần không sao.
  void pauseScan() => _stopScan();

  /// Nghe lại sau [pauseScan]. KHÔNG nghe lại nếu màn đã bị màn khác đè lên:
  /// làm vậy là hai bộ nghe cùng sống, đúng cái lỗi mixin này dẹp.
  void resumeScan() {
    if (!mounted || _route?.isCurrent != true) return;
    _startScan();
  }
}