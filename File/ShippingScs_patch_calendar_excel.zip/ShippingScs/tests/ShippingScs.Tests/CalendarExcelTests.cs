using ClosedXML.Excel;
using ShippingScs.Web.Services;

namespace ShippingScs.Tests;

public class CalendarExcelTests
{
    private readonly CalendarExcelService _svc = new();

    // Tạo file Excel trong bộ nhớ: mỗi phần tử là (Ngày, Loại, Ghi chú); Ngày là DateTime hoặc string
    private static MemoryStream MakeFile(params (object? Date, string Type, string Note)[] rows)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add("Lich");
        ws.Cell(1, 1).Value = "Ngày";
        ws.Cell(1, 2).Value = "Loại";
        ws.Cell(1, 3).Value = "Ghi chú";
        for (var i = 0; i < rows.Length; i++)
        {
            var r = i + 2;
            if (rows[i].Date is DateTime dt) ws.Cell(r, 1).Value = dt;
            else if (rows[i].Date is string s) ws.Cell(r, 1).Value = s;
            ws.Cell(r, 2).Value = rows[i].Type;
            ws.Cell(r, 3).Value = rows[i].Note;
        }
        var ms = new MemoryStream();
        wb.SaveAs(ms);
        ms.Position = 0;
        return ms;
    }

    [Fact]
    public void Parses_date_cells_text_dates_and_vietnamese_types()
    {
        using var f = MakeFile(
            (new DateTime(2027, 9, 2), "Nghỉ lễ", "Quốc khánh"),
            ("30/04/2027", "nghi le", ""),
            ("2027-05-08", "Làm bù", "Bù 03/05"),
            ("01/01/2027", "Holiday", ""));

        var r = _svc.Parse(f);

        Assert.True(r.IsValid, string.Join("; ", r.Errors));
        Assert.Equal(4, r.Rows.Count);
        Assert.Equal(new DateOnly(2027, 9, 2), r.Rows[0].Date);
        Assert.Equal(DayTypes.Holiday, r.Rows[0].DayType);
        Assert.Equal("Quốc khánh", r.Rows[0].Note);
        Assert.Equal(DayTypes.Holiday, r.Rows[1].DayType);
        Assert.Null(r.Rows[1].Note);
        Assert.Equal(DayTypes.ExtraWorkday, r.Rows[2].DayType);
        Assert.Equal(new DateOnly(2027, 5, 8), r.Rows[2].Date);
    }

    [Fact]
    public void Skips_blank_rows()
    {
        using var f = MakeFile(
            (new DateTime(2027, 9, 2), "Nghỉ lễ", ""),
            (null, "", ""),
            (new DateTime(2027, 9, 3), "Nghỉ lễ", ""));

        var r = _svc.Parse(f);
        Assert.True(r.IsValid);
        Assert.Equal(2, r.Rows.Count);
    }

    [Fact]
    public void Reports_bad_date_bad_type_and_duplicate_with_row_numbers()
    {
        using var f = MakeFile(
            ("32/01/2027", "Nghỉ lễ", ""),                    // dòng 2: ngày sai
            (new DateTime(2027, 9, 2), "Nghỉ phép", ""),     // dòng 3: loại sai
            (new DateTime(2027, 9, 3), "Nghỉ lễ", ""),       // dòng 4: ok
            (new DateTime(2027, 9, 3), "Làm bù", ""),        // dòng 5: trùng dòng 4
            (new DateTime(2027, 9, 4), "", ""));             // dòng 6: thiếu loại

        var r = _svc.Parse(f);

        Assert.False(r.IsValid);
        Assert.Equal(4, r.Errors.Count);
        Assert.StartsWith("Dòng 2:", r.Errors[0]);
        Assert.StartsWith("Dòng 3:", r.Errors[1]);
        Assert.Contains("trùng với dòng 4", r.Errors[2]);
        Assert.StartsWith("Dòng 6:", r.Errors[3]);
    }

    [Fact]
    public void Not_an_excel_file_gives_friendly_error()
    {
        using var f = new MemoryStream(System.Text.Encoding.UTF8.GetBytes("Ngày,Loại\n01/01/2027,Nghỉ lễ"));
        var r = _svc.Parse(f);
        Assert.False(r.IsValid);
        Assert.Contains(".xlsx", r.Errors[0]);
    }

    [Fact]
    public void Exported_file_can_be_imported_back()
    {
        var days = WorkingCalendarService.BuildYear("VP", 2027, false);
        days[0].DayType = DayTypes.Holiday;   // 01/01/2027
        days[0].IsWorking = false;
        days[0].Note = "Tết Dương lịch";

        var bytes = _svc.BuildExport(days, "VP", 2027);
        using var ms = new MemoryStream(bytes);
        var r = _svc.Parse(ms);

        Assert.True(r.IsValid, string.Join("; ", r.Errors));
        Assert.Equal(365, r.Rows.Count);
        Assert.Equal(DayTypes.Holiday, r.Rows[0].DayType);
        Assert.Equal("Tết Dương lịch", r.Rows[0].Note);
        Assert.Equal(days.Count(d => d.DayType == DayTypes.Weekend), r.Rows.Count(x => x.DayType == DayTypes.Weekend));
    }

    [Fact]
    public void Template_is_valid_import_file()
    {
        using var ms = new MemoryStream(_svc.BuildTemplate(2027));
        var r = _svc.Parse(ms);
        Assert.True(r.IsValid, string.Join("; ", r.Errors));
        Assert.All(r.Rows, x => Assert.Equal(DayTypes.Holiday, x.DayType));
    }

    [Theory]
    [InlineData("Nghỉ lễ", "nghile")]
    [InlineData("  LÀM BÙ ", "lambu")]
    [InlineData("Cuối tuần", "cuoituan")]
    [InlineData("Ghi chú", "ghichu")]
    [InlineData("Ngày", "ngay")]
    public void Key_removes_vietnamese_accents(string input, string expected)
    {
        Assert.Equal(expected, CalendarExcelService.Key(input));
    }
}
