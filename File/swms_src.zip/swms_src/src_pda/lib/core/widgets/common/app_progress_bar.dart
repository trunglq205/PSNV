import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Thanh tiến độ bo tròn.
///
/// [color] null → tự chọn theo tiến độ: đủ 100% = success, chưa đủ = warning
/// (quy ước dùng cho soạn hàng / nhập kho). Truyền [color] khi cần tông khác.
class AppProgressBar extends StatelessWidget {
  /// 0..1, ngoài khoảng sẽ bị kẹp lại.
  final double value;
  final double height;
  final Color? color;
  final Color? backgroundColor;

  const AppProgressBar({
    super.key,
    required this.value,
    this.height = 5,
    this.color,
    this.backgroundColor,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final v = value.clamp(0.0, 1.0);
    return LinearProgressIndicator(
      value: v,
      minHeight: height,
      borderRadius: BorderRadius.circular(height),
      backgroundColor: backgroundColor ?? swms.border,
      color: color ?? (v >= 1 ? swms.success : swms.warning),
    );
  }
}
