import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_message.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/back_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_bottom_hint.dart';
import 'package:swms_finish_goods/core/widgets/common/app_stepper_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_notifier.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_state.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_box_chips.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_confirm_body.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_confirm_skeleton.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_input_body.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_mode_switch.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_print_body.dart';
import 'package:swms_finish_goods/shared/presentation/printer_picker_dialog.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Part Card — IN PHIẾU MỚI.
//  Quy trình 3 bước: Nhập/Quét model → Xác nhận → In.
//  Bước 3 in xong gọi API lưu lịch sử in (bulk).
//
//  Sửa / tách / gộp tem ĐÃ IN không làm ở đây: quét tem ở Home → chọn action
//  → PartCardActionPage. Quét tem đã in ở màn này chỉ báo user sang Home.
//
//  Nhân bản (Home → quét tem → "Nhân bản"): mở màn này với [clonePayload] —
//  form điền sẵn từ tem đó, in + lưu y như in mới (Card_ID mới, tem gốc giữ).
//
//  Switch đổi 1 mã ↔ nhiều mã chỉ hiện ở bước 2. Nhiều mã = 1 tem gom N model,
//  có thêm PSNV PO / CUS PO, cột Box và dòng Total. Đổi mode giữ nguyên dữ liệu
//  card-level; về 1 mã thì chỉ giữ dòng đầu.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class PartCardPage extends ConsumerStatefulWidget {
  const PartCardPage({super.key, this.clonePayload});

  /// Payload tem đã in cần nhân bản. `null` = in mới từ đầu.
  final String? clonePayload;

  @override
  ConsumerState<PartCardPage> createState() => _PartCardPageState();
}

class _PartCardPageState extends ConsumerState<PartCardPage> {
  StreamSubscription<String>? _sub;

  @override
  void initState() {
    super.initState();
    _listen();

    final payload = widget.clonePayload;
    if (payload != null) {
      WidgetsBinding.instance.addPostFrameCallback((_) async {
        final ok = await ref.read(partCardProvider.notifier).loadForClone(payload);
        // Tem không đọc được → lỗi đã báo, quay về Home.
        if (!ok && mounted) await context.router.maybePop();
      });
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Await xong mới gán: nếu page đã dispose trong lúc chờ thì subscription
    // sẽ không bao giờ được cancel → rò listener.
    if (!mounted) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      ref.read(partCardProvider.notifier).onScan(data);
    });
  }

  /// Đổi 1 mã ↔ nhiều mã. Dữ liệu card-level được giữ nguyên, chỉ hỏi khi
  /// chuyển về 1 mã mà đang có nhiều dòng — các dòng sau dòng 1 sẽ bị xoá.
  Future<void> _changeMode(PartCardMode mode) async {
    final state = ref.read(partCardProvider);
    if (state.mode == mode) return;

    final dropped = mode.isSingle ? state.droppedOnSingle : 0;
    if (dropped > 0) {
      final ok = await showConfirmDialog(
        context,
        title: LocaleKeys.part_card_switch_title.tr(),
        message: LocaleKeys.part_card_switch_body.tr(
          namedArgs: {'count': '$dropped'},
        ),
      );
      // Huỷ hoặc bấm ra ngoài → showConfirmDialog trả false.
      if (!ok || !mounted) return;
    }
    ref.read(partCardProvider.notifier).setMode(mode);
  }

  Future<void> _pickPrinter() async {
    ref.invalidate(pairedPrintersProvider);

    final List<PrinterDevice> devices;
    try {
      devices = await ref.read(pairedPrintersProvider.future);
    } on PrinterException catch (e) {
      if (!mounted) return;
      AppToastHelper.toastInfo(context, printerMessage(e));
      return;
    } catch (e) {
      if (!mounted) return;
      AppToastHelper.toastInfo(context, e.toString());
      return;
    }

    final pda = await ref.read(pdaProvider.future);

    // Ngưng listener của page để nó không nhận scan khi dialog đang mở.
    await _sub?.cancel();
    _sub = null;

    if (!mounted) return;

    await showPrinterPickerDialog(
      context,
      selectedMac: ref.read(selectedPrinterProvider)?.macAddress,
      printers: devices,
      scanStream: pda.scanStream,
      onSelected: (printer) async {
        await ref.read(selectedPrinterProvider.notifier).select(printer);
      },
    );

    // Dialog đóng → nghe lại.
    if (!mounted) return;
    await _listen();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(partCardProvider);

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.part_card_title.tr(),
        subtitle: LocaleKeys.part_card_subtitle.tr(),
        actions: [
          // Chỉ bước xác nhận mới đổi được loại tem: bước 1 chưa có dữ liệu,
          // bước 3 đã chốt layout.
          if (state.step == PartCardStep.confirm)
            PartCardModeSwitch(
              mode: state.mode,
              enabled: !state.hasPrinted && !state.loadingSuggestions,
              onChanged: _changeMode,
            ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppDimens.md),
        child: Column(
          children: [
            AppStepperBar(
              current: state.step.number,
              steps: [
                StepItem(LocaleKeys.part_card_step_input.tr()),
                StepItem(LocaleKeys.part_card_step_confirm.tr()),
                StepItem(LocaleKeys.part_card_step_print.tr()),
              ],
            ),
            const SizedBox(height: AppDimens.sm),
            Expanded(child: _buildStepBody(state)),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottom(state),
    );
  }

  Widget _buildStepBody(PartCardState state) {
    final notifier = ref.read(partCardProvider.notifier);

    switch (state.step) {
      case PartCardStep.input:
        return PartCardInputBody(
          value: state.modelInput,
          mode: state.mode,
          onChanged: notifier.onModelInputChanged,
          onSubmit: notifier.lookupModel,
        );

      case PartCardStep.confirm:
        final form = state.form;
        if (form == null) return const SizedBox.shrink(); // chưa nhập model

        // Đang tải lịch sử → skeleton, tránh form rỗng nháy đỏ.
        if (state.loadingSuggestions) {
          return PartCardConfirmSkeleton(multi: state.mode.isMulti);
        }

        return Column(
          children: [
            PartCardBoxChips(
              boxes: state.suggestions.boxes,
              form: form,
              enabled: !state.hasPrinted,
              onSelected: notifier.applySuggestion,
            ),
            Expanded(
              child: PartCardConfirmBody(
                form: form,
                mode: state.mode,
                onChanged: notifier.onFormChanged,
                onAddModel: notifier.addLine,
              ),
            ),
          ],
        );

      case PartCardStep.printCard:
        final form = state.form;
        if (form == null) return const SizedBox.shrink();

        return PartCardPrintBody(
          form: form,
          mode: state.mode,
          printer: ref.watch(selectedPrinterProvider),
          copies: state.copies,
          onCopiesChanged: notifier.setCopies,
          printed: state.hasPrinted,
          onChangePrinter: _pickPrinter,
        );
    }
  }

  Widget _buildBottom(PartCardState state) {
    final notifier = ref.read(partCardProvider.notifier);

    switch (state.step) {
      case PartCardStep.input:
        return AppBottomHint(
          child: AppButton(
            label: LocaleKeys.part_card_btn_lookup.tr(),
            icon: Icons.search_rounded,
            onPressed: state.canLookup ? notifier.lookupModel : null,
          ),
        );

      case PartCardStep.confirm:
        final complete = state.form?.isComplete ?? false;

        return AppBottomHint(
          child: Row(
            children: [
              BackIconButton(
                onPressed: () => notifier.goStep(PartCardStep.input.number),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: AppButton(
                  label: LocaleKeys.part_card_btn_confirm_next.tr(),
                  variant: AppButtonVariant.success,
                  isFullWidth: false,
                  onPressed: complete ? notifier.confirmForm : null,
                ),
              ),
            ],
          ),
        );

      case PartCardStep.printCard:
        final ready = ref.watch(selectedPrinterProvider) != null;

        return AppBottomHint(
          child: Row(
            children: [
              BackIconButton(
                onPressed: () => notifier.goStep(PartCardStep.confirm.number),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: AppButton(
                  // Đã in mà lưu lịch sử fail → chỉ gọi lại API, không in lại.
                  label: state.hasPrinted
                      ? LocaleKeys.part_card_btn_save_history.tr()
                      : LocaleKeys.part_card_btn_print.tr(
                    namedArgs: {'count': '${state.copies}'},
                  ),
                  variant: AppButtonVariant.success,
                  icon: state.hasPrinted ? Icons.check_rounded : Icons.print,
                  isFullWidth: false,
                  onPressed: ready ? notifier.printAndSave : null,
                ),
              ),
            ],
          ),
        );
    }
  }
}