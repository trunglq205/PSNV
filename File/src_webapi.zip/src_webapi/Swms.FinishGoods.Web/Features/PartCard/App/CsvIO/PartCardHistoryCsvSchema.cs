using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.PartCard.Business.Models;
using Swms.FinishGoods.Web.Shared.App.CsvIo;
using System.Globalization;

namespace Swms.FinishGoods.Web.Features.PartCard.App.Csvlo;

// ─────────────────────────────────────────────────────────────
//  CSV EXPORT lịch sử in (không import).
//
//  Mỗi dòng CSV = 1 DÒNG HÀNG (không phải 1 phiếu):
//    • Phiếu thường  → 1 dòng (model / qty / origin của phiếu).
//    • Phiếu oversea → N dòng, mỗi inner box 1 dòng; các cột cấp phiếu
//      (PO, ngày, kích thước, người in…) LẶP LẠI trên từng dòng để
//      lọc / pivot trong Excel không bị ô trống.
//  Cột "id" + "line_no" xác định duy nhất 1 dòng.
//
//  Cột created_from / edit_count / last_changed_at đánh dấu phiếu đã qua
//  sửa / tách / gộp — trống hết = phiếu in mới, chưa đổi gì.
//
//  Tên cột dùng chung với file import (po_no, customer_po_no, model, qty,
//  origin, inner_box, oqc_check = "ASSY") để người dùng quen 1 bộ tên.
// ─────────────────────────────────────────────────────────────

/// <summary>1 dòng CSV export: phiếu + (tuỳ chọn) 1 inner box của phiếu đó.</summary>
public sealed record PartCardHistoryCsvRow(AppPartCardHistory Card, int LineNo, PartCardRowDto? Item)
{
    public string Model => Item?.Model ?? Card.ModelText;
    public int Qty => Item?.Qty ?? Card.TotalQty;
    public string Origin => Item?.Origin ?? Card.Origin ?? "";
    public string InnerBox => Item?.InnerBox ?? "";

    /// <summary>Chỉ dòng inner box mới có OQC; phiếu thường để trống.</summary>
    public string OqcCheck => Item is { OqcChecked: true } ? PartCardHistoryCsvSchema.OqcCheckedValue : "";
}

public static class PartCardHistoryCsvSchema
{
    // Cùng giá trị với cột oqc_check của file import (PartCardCsvSchema).
    public const string OqcCheckedValue = "ASSY";

    /// <param name="categoryText">Tra tên category từ mã — page truyền vào (danh mục do API cấp).</param>
    public static CsvSchema<PartCardHistoryCsvRow> BuildSchema(IStringLocalizer L, Func<int?, string> categoryText) => new()
    {
        FileBaseName = "swms_part_card_history",
        Columns = new List<CsvColumn<PartCardHistoryCsvRow>>
        {
            // ── Cấp phiếu (lặp lại trên mọi dòng của phiếu) ──
            new() { Key = "id",              Description = L["PartCardHistoryCsv.Col.Id"],             Get = r => r.Card.Id.ToString(),                      IncludeInImport = false },
            new() { Key = "printed_at",      Description = L["PartCardHistoryCsv.Col.PrintedAt"],      Get = r => r.Card.PrintedAt,                          IncludeInImport = false },
            new() { Key = "printed_by",      Description = L["PartCardHistoryCsv.Col.PrintedBy"],      Get = r => r.Card.PrintedBy,                          IncludeInImport = false },
            new() { Key = "type",            Description = L["PartCardHistoryCsv.Col.Type"],           Get = r => r.Card.IsOversea ? "oversea" : "normal",   IncludeInImport = false },
            new() { Key = "category",        Description = L["PartCardHistoryCsv.Col.Category"],       Get = r => categoryText(r.Card.Category),             IncludeInImport = false },
            new() { Key = "po_no",           Description = L["PartCardHistoryCsv.Col.PoNo"],           Get = r => r.Card.PoNo,                               IncludeInImport = false },
            new() { Key = "customer_po_no",  Description = L["PartCardHistoryCsv.Col.CustPoNo"],       Get = r => r.Card.CustomerPoNo,                       IncludeInImport = false },
            new() { Key = "production_date", Description = L["PartCardHistoryCsv.Col.ProductionDate"], Get = r => r.Card.ProductionDate,                     IncludeInImport = false },
            new() { Key = "length",          Description = L["PartCardHistoryCsv.Col.Length"],         Get = r => Dec(r.Card.Length),                        IncludeInImport = false },
            new() { Key = "width",           Description = L["PartCardHistoryCsv.Col.Width"],          Get = r => Dec(r.Card.Width),                         IncludeInImport = false },
            new() { Key = "height",          Description = L["PartCardHistoryCsv.Col.Height"],         Get = r => Dec(r.Card.Height),                        IncludeInImport = false },
            new() { Key = "weight",          Description = L["PartCardHistoryCsv.Col.Weight"],         Get = r => Dec(r.Card.Weight),                        IncludeInImport = false },
            new() { Key = "packer",          Description = L["PartCardHistoryCsv.Col.Packer"],         Get = r => r.Card.Packer,                             IncludeInImport = false },
            new() { Key = "checker",         Description = L["PartCardHistoryCsv.Col.Checker"],        Get = r => r.Card.Checker,                            IncludeInImport = false },

            // ── Đánh dấu sửa / tách / gộp (trống = phiếu chưa qua thao tác nào) ──
            new() { Key = "created_from",    Description = L["PartCardHistoryCsv.Col.CreatedFrom"],    Get = r => r.Card.CreatedFrom ?? "",                  IncludeInImport = false },
            new() { Key = "edit_count",      Description = L["PartCardHistoryCsv.Col.EditCount"],      Get = r => r.Card.EditCount > 0 ? r.Card.EditCount.ToString(CultureInfo.InvariantCulture) : "", IncludeInImport = false },
            new() { Key = "last_changed_at", Description = L["PartCardHistoryCsv.Col.LastChangedAt"],  Get = r => r.Card.LastChangedAt,                      IncludeInImport = false },

            // ── Cấp dòng hàng ──
            new() { Key = "line_no",         Description = L["PartCardHistoryCsv.Col.LineNo"],         Get = r => r.LineNo.ToString(),                       IncludeInImport = false },
            new() { Key = "model",           Description = L["PartCardHistoryCsv.Col.Model"],          Get = r => r.Model,                                   IncludeInImport = false },
            new() { Key = "inner_box",       Description = L["PartCardHistoryCsv.Col.InnerBox"],       Get = r => r.InnerBox,                                IncludeInImport = false },
            new() { Key = "qty",             Description = L["PartCardHistoryCsv.Col.Qty"],            Get = r => r.Qty.ToString(CultureInfo.InvariantCulture), IncludeInImport = false },
            new() { Key = "origin",          Description = L["PartCardHistoryCsv.Col.Origin"],         Get = r => r.Origin,                                  IncludeInImport = false },
            new() { Key = "oqc_check",       Description = L["PartCardHistoryCsv.Col.OqcCheck"],       Get = r => r.OqcCheck,                                IncludeInImport = false },
        },
    };

    /// <summary>
    /// Bung danh sách phiếu thành dòng CSV, GIỮ thứ tự phiếu như trên màn hình.
    /// Phiếu oversea không có inner box nào (dữ liệu lỗi) vẫn ra 1 dòng để không mất phiếu.
    /// </summary>
    public static List<PartCardHistoryCsvRow> Flatten(IEnumerable<AppPartCardHistory> cards)
    {
        var list = new List<PartCardHistoryCsvRow>();
        foreach (var c in cards)
        {
            if (c.IsOversea && c.Rows.Count > 0)
            {
                for (var i = 0; i < c.Rows.Count; i++)
                    list.Add(new PartCardHistoryCsvRow(c, i + 1, c.Rows[i]));
            }
            else
            {
                list.Add(new PartCardHistoryCsvRow(c, 1, null));
            }
        }
        return list;
    }

    // Dấu chấm thập phân cố định — không phụ thuộc culture của server.
    private static string Dec(decimal? v)
        => v is { } d ? d.ToString("0.####", CultureInfo.InvariantCulture) : "";
}