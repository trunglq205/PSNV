﻿using System.ComponentModel;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace SWMS_WebTool.Models
{
    public class User
    {
        [JsonProperty("userID")]
        public string ID { get; set; }
        [JsonProperty("userFullName")]
        public string FullName { get; set; }
        [JsonProperty("SectionID")]
        public Section Section { get; set; }
        [JsonProperty("PositionUserID")]
        public Role Role { get; set; }
        [JsonProperty("lstWebRole")]
        public List<WebRole>? WebRole { get; set; } = new List<WebRole>();   
        [JsonProperty("lstPDARole")]
        public List<PDARole>? PDARole { get; set; } = new List<PDARole>();
    }

    public enum Section
    {
        [EnumMember(Value = "0")]
        [Description("Status_MCS")]
        MCS,
        [EnumMember(Value = "1")]
        [Description("Status_PMD")]
        PMD,
        [EnumMember(Value = "2")]
        [Description("Status_FA")]
        FA,
        [EnumMember(Value = "3")]
        [Description("Status_OCS")]
        OCS,
        [EnumMember(Value = "4")]
        [Description("Status_IT")]
        IT,
        [EnumMember(Value = "5")]
        [Description("Status_IQC")]
        IQC,
        [EnumMember(Value = "6")]
        [Description("Status_PUS")]
        PUS
    }

    public enum Role
    {
        [EnumMember(Value = "0")]
        [Description("Status_Member")]
        Member,
        [EnumMember(Value = "1")]
        [Description("Status_Leader")]
        Leader,
    }

    public enum WebRole
    {
        [EnumMember(Value = "receiving")]
        Receiving,
        [EnumMember(Value = "storage")]
        Storage,
        [EnumMember(Value = "kitting")]
        Kitting,
        [EnumMember(Value = "supply")]
        Supply,
        [EnumMember(Value = "inventory")]
        Inventory,
        [EnumMember(Value = "managerment")]
        Managerment,
        [EnumMember(Value = "ortherSection")]
        OrtherSection,
    }

    public enum PDARole
    {
        [EnumMember(Value = "receiving")]
        Receiving,
        [EnumMember(Value = "storage")]
        Storage,
        [EnumMember(Value = "kitting")]
        Kitting,
        [EnumMember(Value = "supply")]
        Supply,
        [EnumMember(Value = "inventory")]
        Inventory,
    }
}
