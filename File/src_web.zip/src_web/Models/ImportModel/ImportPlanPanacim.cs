﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class ImportPlanPanacim
    {
        public string? Plant {  get; set; }
        public string? Material { get; set; }
        public string? Category { get; set; }
        public int? GRQuantity { get; set; }
        public int? SPQ { get; set; }
        public int? SoundbizQuantity { get; set; } 
        public int? ProjectorQuantity { get; set; }
        public string? Invoice { get; set; }
        public string? DeliveryDate { get; set; }

    }
}
