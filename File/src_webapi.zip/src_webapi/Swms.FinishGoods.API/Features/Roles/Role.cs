namespace Swms.FinishGoods.Api.Features.Roles.Business.Models;

/// <summary>Vai trò (master.roles) — entity nội bộ, không lộ ra ngoài controller.</summary>
public class Role
{
    public long Id { get; set; }
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public string Description { get; set; } = "";
    public string Dot { get; set; } = "info";   // danger|warning|info|success|dim
    public bool IsSystem { get; set; }
    public int UserCount { get; set; }
    public List<string> Permissions { get; set; } = new();   // code quyền: "asn.create"
}
