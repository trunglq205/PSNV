/* ============================================================================
   LUỒNG NHẬN LẠI HÀNG VỀ FA — BẢN SỬA 10/11
   ----------------------------------------------------------------------------
   Chạy SAU return_back_merge_schema.sql.

   BA thay đổi nghiệp vụ, tất cả do quyết định 10/11:

   1. FA ĐỀ NGHỊ ĐƯỢC MỘT PHẦN.
      Trước đây đề nghị là "lấy toàn bộ phần còn ở kho" nên không lưu SL ở đâu
      cả. Nay FA nhập SL theo từng model ⇒ dựng bảng wms.return_back_lines.
      SCS WH tách Pallet ID cho khớp đúng SL đó rồi mới giao.

   2. THÊM LẠI BƯỚC QUẢN LÝ SCS XÁC NHẬN.
      back_status thêm giá trị 'scs_approved', nằm GIỮA fa_approved và
      delivered. SCS WH chỉ được giao sau bước này.

   3. BỎ LÁ MAIL LÚC GIAO HÀNG (RETURN_BACK_DELIVERED).
      Vì đã có bước quản lý SCS duyệt ở trên — duyệt xong là hai bên đã biết,
      thêm một lá mail nữa không ai đọc. Còn ĐÚNG MỘT lá: quản lý FA duyệt →
      SCS Office.

   Luồng sau khi chạy script này:

     B1  FA đề nghị, nhập SL theo model     back_status = fa_requested
     B2  Quản lý FA xác nhận                fa_approved    → mail SCS Office
     B3  Quản lý SCS xác nhận               scs_approved
     B4  SCS WH tách pallet rồi quét giao   delivered      (không mail)

   AN TOÀN KHI CHẠY LẠI: mọi bước đều có IF NOT EXISTS / IF EXISTS.

   ⚠ BẪY T-SQL: một batch không có GO thì bind tên CỘT lúc compile, nên cột vừa
     ALTER thêm trong cùng batch gây lỗi 207 và CẢ SCRIPT không chạy dòng nào.
     Vì thế mọi câu đụng cột mới đều bọc trong EXEC(N'…'). Tên BẢNG thì có
     deferred name resolution nên tạo bảng + index trong một batch lại không sao.
============================================================================ */

SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ---------------------------------------------------------------------------
   Tiền đề
--------------------------------------------------------------------------- */
IF COL_LENGTH(N'wms.return_instructions', N'back_status') IS NULL
BEGIN
    RAISERROR(N'Thieu cot back_status — chay return_back_merge_schema.sql truoc.', 16, 1);
    RETURN;
END;

BEGIN TRAN;

/* ---------------------------------------------------------------------------
   1. wms.return_back_lines — SL FA xin lấy về, theo model.
--------------------------------------------------------------------------- */
PRINT N'1. Dong de nghi back theo model';

IF OBJECT_ID(N'wms.return_back_lines', N'U') IS NULL
BEGIN
    /* MỘT chỉ thị = MỘT đợt back (quyết định 09/11: về nhiều đợt thì mỗi đợt
       một chỉ thị), nên dòng treo thẳng vào doc_id, không cần bảng "đề nghị"
       trung gian. Đề nghị lại sau khi huỷ thì XOÁ CỨNG dòng cũ rồi chèn lại —
       xem ghi chú ở RequestAsync bên API. */
    CREATE TABLE wms.return_back_lines
    (
        id          BIGINT IDENTITY(1,1) NOT NULL,
        doc_id      BIGINT         NOT NULL,

        /* Khớp master.models.code và khớp model của một dòng chỉ thị.
           KHÔNG lưu line_id: mỗi lần Office sửa phiếu là xoá mềm toàn bộ dòng
           rồi chèn lại với id mới, nên mọi liên kết phải đi qua model. */
        model       NVARCHAR(100)  NOT NULL,

        /* SL FA xin lấy về. > 0; trần là SL đang còn ở kho, API kiểm. */
        req_qty     INT            NOT NULL,

        created_at  DATETIME2(0)   NOT NULL CONSTRAINT df_rbl_created DEFAULT SYSDATETIME(),
        created_by  NVARCHAR(100)  NULL,
        updated_at  DATETIME2(0)   NULL,
        updated_by  NVARCHAR(100)  NULL,

        CONSTRAINT pk_return_back_lines PRIMARY KEY (id),
        CONSTRAINT ck_rbl_qty CHECK (req_qty > 0),

        /* Xoá phiếu là dọn luôn dòng đề nghị — dòng không có phiếu thì vô nghĩa. */
        CONSTRAINT fk_rbl_doc FOREIGN KEY (doc_id)
            REFERENCES wms.return_instructions(id) ON DELETE CASCADE
    );

    /* MỘT model MỘT dòng trong một phiếu: hai dòng cùng model thì bảng đối
       chiếu và câu tách pallet đều phải cộng dồn, mà quên cộng ở một chỗ là
       lệch âm thầm. Chặn ngay ở DB. */
    CREATE UNIQUE INDEX ux_rbl_doc_model ON wms.return_back_lines(doc_id, model);

    PRINT N'   + wms.return_back_lines';
END
ELSE
    PRINT N'   = wms.return_back_lines da co';

/* ---------------------------------------------------------------------------
   2. Hai mốc của bước quản lý SCS xác nhận.
      back_scs_comment đã có sẵn từ bản gộp — chỉ thiếu người và lúc.
--------------------------------------------------------------------------- */
PRINT N'2. Moc buoc quan ly SCS xac nhan';

IF COL_LENGTH(N'wms.return_instructions', N'back_scs_approved_by') IS NULL
BEGIN
    /* nvarchar(100), bằng MỌI cột *_by khác trong solution. Hẹp hơn là câu
       UPDATE ném 8152 lúc gặp tên dài — đã trả giá một lần ở bản gộp. */
    ALTER TABLE wms.return_instructions ADD back_scs_approved_by NVARCHAR(100) NULL;
    PRINT N'   + back_scs_approved_by';
END
ELSE
    PRINT N'   = back_scs_approved_by da co';

IF COL_LENGTH(N'wms.return_instructions', N'back_scs_approved_at') IS NULL
BEGIN
    ALTER TABLE wms.return_instructions ADD back_scs_approved_at DATETIME2(0) NULL;
    PRINT N'   + back_scs_approved_at';
END
ELSE
    PRINT N'   = back_scs_approved_at da co';

/* ---------------------------------------------------------------------------
   3. back_status nhận thêm 'scs_approved'.
--------------------------------------------------------------------------- */
PRINT N'3. Mo rong ck_ri_back_status';

IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'ck_ri_back_status')
BEGIN
    ALTER TABLE wms.return_instructions DROP CONSTRAINT ck_ri_back_status;
    PRINT N'   - ck_ri_back_status (ban cu)';
END;

/* NULL = FA chưa đề nghị gì. Ràng buộc phải cho phép NULL, nếu không mọi phiếu
   cũ vi phạm ngay. */
EXEC(N'ALTER TABLE wms.return_instructions
         ADD CONSTRAINT ck_ri_back_status CHECK (back_status IS NULL OR back_status IN
             (N''fa_requested'', N''fa_approved'', N''scs_approved'',
              N''delivered'', N''cancelled''));');

PRINT N'   + ck_ri_back_status (them scs_approved)';

/* ---------------------------------------------------------------------------
   4. Phiếu ĐANG chờ giao theo luồng CŨ được nâng sang bước mới.

      Phiếu đang fa_approved nghĩa là quản lý FA đã duyệt và theo luồng cũ thì
      WH được giao ngay. Nếu để nguyên, sau khi chạy script này chúng sẽ kẹt ở
      bước chờ quản lý SCS mà không ai biết vì sao hàng dừng.

      Coi như quản lý SCS đã duyệt, đóng dấu rõ là do script nâng cấp — để sau
      này tra ra được vì sao có mốc duyệt mà không có tên người.
--------------------------------------------------------------------------- */
PRINT N'4. Nang phieu dang cho giao sang buoc moi';

DECLARE @lifted INT = 0;

EXEC sp_executesql N'
    UPDATE wms.return_instructions
    SET    back_status           = N''scs_approved'',
           back_scs_approved_at  = SYSDATETIME(),
           back_scs_approved_by  = N''(nang cap 10/11)'',
           back_scs_comment      = ISNULL(back_scs_comment,
                                          N''Tu dong duyet khi them buoc quan ly SCS.'')
    WHERE  back_status = N''fa_approved'' AND is_deleted = 0;

    SELECT @n = @@ROWCOUNT;',
    N'@n INT OUTPUT', @n = @lifted OUTPUT;

PRINT N'   Da nang ' + CAST(@lifted AS nvarchar(20)) + N' phieu fa_approved -> scs_approved';

/* ---------------------------------------------------------------------------
   5. Bỏ lá mail lúc giao hàng.

      XOÁ HẲN chứ không để lại mà ngừng gửi: để lại thì nó vẫn hiện trong màn
      bánh răng cấu hình mail, người dùng khai người nhận rồi ngồi chờ một lá
      thư không bao giờ đi.

      Xoá cấu hình người nhận TRƯỚC rồi mới xoá sự kiện — email_config trỏ sang
      email_events bằng event_code.
--------------------------------------------------------------------------- */
PRINT N'5. Bo la mail luc giao hang (RETURN_BACK_DELIVERED)';

DECLARE @cfg INT = 0, @edited BIT = 0, @subj NVARCHAR(400), @body NVARCHAR(MAX);

IF EXISTS (SELECT 1 FROM master.email_events WHERE code = N'RETURN_BACK_DELIVERED')
BEGIN
    /* Mẫu đã bị sửa tay (updated_at khác NULL) thì IN RA trước khi xoá.
       Quy tắc của dự án là không đè mẫu người dùng đã sửa; ở đây buộc phải xoá
       vì lá mail này không còn trong luồng, nhưng xoá IM LẶNG là mất công
       người ta đã ngồi soạn mà không ai biết. In ra để còn chép lại được. */
    SELECT @edited = CASE WHEN updated_at IS NULL THEN 0 ELSE 1 END,
           @subj   = subject_template,
           @body   = body_template
    FROM   master.email_events
    WHERE  code = N'RETURN_BACK_DELIVERED';

    IF @edited = 1
    BEGIN
        PRINT N'   ⚠ Mau nay DA BI SUA TAY. Noi dung cu, chep lai neu con can:';
        PRINT N'   --- Tieu de ---';
        PRINT N'   ' + ISNULL(@subj, N'(trong)');
        PRINT N'   --- Than thu ---';
        PRINT ISNULL(@body, N'(trong)');
        PRINT N'   ---------------';
    END;

    DELETE FROM master.email_config WHERE event_code = N'RETURN_BACK_DELIVERED';
    SET @cfg = @@ROWCOUNT;

    DELETE FROM master.email_events WHERE code = N'RETURN_BACK_DELIVERED';

    PRINT N'   - RETURN_BACK_DELIVERED (va ' + CAST(@cfg AS nvarchar(20))
          + N' dong cau hinh nguoi nhan)';
END
ELSE
    PRINT N'   = RETURN_BACK_DELIVERED da khong con';

COMMIT;

/* ---------------------------------------------------------------------------
   Soát lại
--------------------------------------------------------------------------- */
PRINT N'';
PRINT N'=== Ket qua ===';

SELECT N'wms.return_back_lines' AS [Doi tuong],
       CASE WHEN OBJECT_ID(N'wms.return_back_lines', N'U') IS NULL
            THEN N'!! THIEU' ELSE N'OK' END AS [Tinh trang]
UNION ALL SELECT N'back_scs_approved_by',
       CASE WHEN COL_LENGTH(N'wms.return_instructions', N'back_scs_approved_by') IS NULL
            THEN N'!! THIEU' ELSE N'OK' END
UNION ALL SELECT N'back_scs_approved_at',
       CASE WHEN COL_LENGTH(N'wms.return_instructions', N'back_scs_approved_at') IS NULL
            THEN N'!! THIEU' ELSE N'OK' END
UNION ALL SELECT N'ck_ri_back_status co scs_approved',
       CASE WHEN EXISTS (SELECT 1 FROM sys.check_constraints
                         WHERE name = N'ck_ri_back_status'
                           AND definition LIKE N'%scs_approved%')
            THEN N'OK' ELSE N'!! THIEU' END
UNION ALL SELECT N'Mail RETURN_BACK_DELIVERED da bo',
       CASE WHEN EXISTS (SELECT 1 FROM master.email_events
                         WHERE code = N'RETURN_BACK_DELIVERED')
            THEN N'!! VAN CON' ELSE N'OK' END
UNION ALL SELECT N'Mail RETURN_BACK_FA_APPROVED con lai',
       CASE WHEN EXISTS (SELECT 1 FROM master.email_events
                         WHERE code = N'RETURN_BACK_FA_APPROVED')
            THEN N'OK' ELSE N'!! MAT' END;

PRINT N'';
PRINT N'Con lai phai lam bang tay:';
PRINT N'  · Gan quyen rework_refurbish.approve_scs cho role Quan ly SCS (man /roles).';
PRINT N'  · Restart API (quyen cache 5 phut, resx nap luc khoi dong).';
PRINT N'  · Man banh rang cau hinh mail nay con 3 tab thay vi 4.';
