import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_pallet_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2d — đọc JSON VIẾT TAY, không @JsonSerializable.
//
//  Cùng lý do đã ghi ở return_back_model.dart: build_runner trong source hiện
//  tại đang vỡ (hai file cùng khai `@RoutePage() class VanningPage`), nên bộ
//  mục 2d làm sao để không phải sinh file nào. Đổi lại phải tự viết, và mọi
//  hàm dưới đây đều chịu được trường thiếu / sai kiểu thay vì ném giữa lúc FA
//  đang quét.
//
//  Khoá JSON là camelCase: API dùng cấu hình mặc định của ASP.NET
//  (JsonNamingPolicy.CamelCase) nên record `ReturnMismatchResponse(long Id, …)`
//  ra JSON thành `id`, `docId`, `lotNo`, …
// ─────────────────────────────────────────────────────────────

int _int(Object? v, [int fallback = 0]) => switch (v) {
      int i => i,
      double d => d.round(),
      num n => n.round(),
      String s => int.tryParse(s) ?? fallback,
      _ => fallback,
    };

int? _intOrNull(Object? v) => v == null ? null : _int(v);

bool _bool(Object? v, [bool fallback = false]) => switch (v) {
      bool b => b,
      String s => s.toLowerCase() == 'true',
      _ => fallback,
    };

String? _str(Object? v) {
  if (v == null) return null;
  final s = v.toString().trim();
  return s.isEmpty ? null : s;
}

/// Mốc thời gian. Thiếu hoặc không parse được thì trả `null` ở nơi cho phép
/// null; riêng `scannedAt` là NOT NULL bên DB nên fallback về epoch — một mốc
/// 1970 trông rõ là sai, còn `DateTime.now()` thì trông y như mốc thật.
DateTime? _date(Object? v) {
  final s = _str(v);
  return s == null ? null : DateTime.tryParse(s);
}

List<Map<String, Object?>> _rows(Object? v) => v is List
    ? v.whereType<Map>().map((e) => e.cast<String, Object?>()).toList()
    : const [];

/// Một dòng sổ serial gọn. `ReturnSerialIndexResponse(string Serial, …)` nên
/// khoá là `serial`, KHÔNG phải `serialNo`.
FaSerialIndexRow faSerialIndexRowFromJson(Map<String, Object?> j) =>
    FaSerialIndexRow(
      serial: _str(j['serial']) ?? '',
      model: _str(j['model']) ?? '',
      status: _str(j['status']) ?? '',
    );

List<FaSerialIndexRow> faSerialIndexFromJson(Object? v) =>
    _rows(v).map(faSerialIndexRowFromJson).toList();

FaMismatch faMismatchFromJson(Map<String, Object?> j) => FaMismatch(
      id: _int(j['id']),
      docId: _int(j['docId']),
      palletId: _intOrNull(j['palletId']),
      lotNo: _str(j['lotNo']),
      serial: _str(j['serial']) ?? '',
      model: _str(j['model']),
      reason: _str(j['reason']) ?? 'not_in_doc',
      foundStatus: _str(j['foundStatus']),
      otherDocNo: _str(j['otherDocNo']),
      scannedAt: _date(j['scannedAt']) ?? DateTime.fromMillisecondsSinceEpoch(0),
      scannedBy: _str(j['scannedBy']),
      resolvedAt: _date(j['resolvedAt']),
      resolvedBy: _str(j['resolvedBy']),
      resolveNote: _str(j['resolveNote']),
      // Lấy cờ của server chứ không tự suy từ resolvedAt: server là nơi quyết
      // định, và nếu hai bên suy khác nhau thì màn hình nói khác API.
      isResolved: _bool(j['isResolved'], _date(j['resolvedAt']) != null),
    );

List<FaMismatch> faMismatchesFromJson(Object? v) =>
    _rows(v).map(faMismatchFromJson).toList();

FaPalletResult faPalletResultFromJson(Map<String, Object?> j) => FaPalletResult(
      palletId: _int(j['palletId']),
      lotNo: _str(j['lotNo']) ?? '',
      categoryCode: _int(j['categoryCode']),
      boxCount: _int(j['boxCount']),
      serialCount: _int(j['serialCount']),
      mismatchCount: _int(j['mismatchCount']),
      mismatches: faMismatchesFromJson(j['mismatches']),
    );
