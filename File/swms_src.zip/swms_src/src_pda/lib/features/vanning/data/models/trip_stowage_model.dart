import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/vanning/domain/trip_stowage.dart';

part 'trip_stowage_model.g.dart';

// Khớp TripStowageModels.cs (API). JSON camelCase.

@JsonSerializable(createToJson: false)
class StowageTierModel {
  final int tier;
  final String? planPalletCode;
  final String? siNo;
  final String? palletSize;

  const StowageTierModel({
    required this.tier,
    this.planPalletCode,
    this.siNo,
    this.palletSize,
  });

  factory StowageTierModel.fromJson(Map<String, dynamic> json) =>
      _$StowageTierModelFromJson(json);

  StowageTier toEntity() => StowageTier(
    tier: tier,
    planPalletCode: planPalletCode,
    siNo: siNo,
    palletSize: palletSize,
  );
}

@JsonSerializable(createToJson: false)
class StowageColumnModel {
  final String code;
  final int cocNo;
  final int? rowNo;
  final int? laneNo;
  final List<StowageTierModel> tiers;
  final String? bottomCode;
  final String? topCode;
  final DateTime? stackedAt;
  final DateTime? placedAt;
  final String? placedBy;

  const StowageColumnModel({
    required this.code,
    required this.cocNo,
    this.rowNo,
    this.laneNo,
    this.tiers = const [],
    this.bottomCode,
    this.topCode,
    this.stackedAt,
    this.placedAt,
    this.placedBy,
  });

  factory StowageColumnModel.fromJson(Map<String, dynamic> json) =>
      _$StowageColumnModelFromJson(json);

  StowageColumn toEntity() => StowageColumn(
    code: code,
    cocNo: cocNo,
    rowNo: rowNo,
    laneNo: laneNo,
    tiers: [for (final t in tiers) t.toEntity()],
    bottomCode: bottomCode,
    topCode: topCode,
    stackedAt: stackedAt,
    placedAt: placedAt,
    placedBy: placedBy,
  );
}

@JsonSerializable(createToJson: false)
class TripStowageModel {
  final int tripId;
  final String planNo;
  final String planStatus;
  final String shipMode;
  final String containerType;
  final int rows;
  final int lanes;
  final int stacked;
  final int placed;
  final bool canEdit;
  final List<StowageColumnModel> columns;

  const TripStowageModel({
    required this.tripId,
    required this.planNo,
    required this.planStatus,
    required this.shipMode,
    required this.containerType,
    this.rows = 0,
    this.lanes = 0,
    this.stacked = 0,
    this.placed = 0,
    this.canEdit = false,
    this.columns = const [],
  });

  factory TripStowageModel.fromJson(Map<String, dynamic> json) =>
      _$TripStowageModelFromJson(json);

  TripStowage toEntity() => TripStowage(
    tripId: tripId,
    planNo: planNo,
    planStatus: planStatus,
    shipMode: shipMode,
    containerType: containerType,
    rows: rows,
    lanes: lanes,
    stackedCount: stacked,
    placedCount: placed,
    canEdit: canEdit,
    columns: [for (final c in columns) c.toEntity()],
  );
}

/// Body ghép cọc / xếp cọc. topCode null = cọc 1 tầng; bottomCode null khi xếp cọc đã ghép mà không quét.
@JsonSerializable(createFactory: false, includeIfNull: false)
class StowageCodesRequestModel {
  final String? bottomCode;
  final String? topCode;

  const StowageCodesRequestModel({this.bottomCode, this.topCode});

  Map<String, dynamic> toJson() => _$StowageCodesRequestModelToJson(this);
}