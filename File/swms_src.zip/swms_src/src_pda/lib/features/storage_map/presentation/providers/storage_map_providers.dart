import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/storage_map/data/datasources/storage_map_remote_data_source.dart';
import 'package:swms_finish_goods/features/storage_map/data/storage_map_repository_impl.dart';
import 'package:swms_finish_goods/features/storage_map/domain/entities/storage_map_entities.dart';
import 'package:swms_finish_goods/features/storage_map/domain/repositories/storage_map_repository.dart';

part 'storage_map_providers.g.dart';

@riverpod
StorageMapRemoteDataSource storageMapRemoteDataSource(Ref ref) {
  final dio = ref.watch(dioProvider);
  return StorageMapRemoteDataSource(dio);
}

@riverpod
StorageMapRepository storageMapRepository(Ref ref) {
  return StorageMapRepositoryImpl(
    ref.watch(storageMapRemoteDataSourceProvider),
  );
}

/// Danh sách bản đồ kho lưu trữ (cho dropdown chọn).
@riverpod
Future<List<WarehouseArea>> storageAreas(Ref ref) {
  return ref.watch(storageMapRepositoryProvider).fetchAreas(type: 'storing');
}

/// Bản đồ đang xem — null = khu mặc định của server.
@riverpod
class SelectedStorageArea extends _$SelectedStorageArea {
  @override
  String? build() => null;

  void select(String? areaCode) => state = areaCode;
}

/// Bản đồ mở sẵn khi vào màn (nếu có trong danh sách).
const _defaultAreaCode = 'STORAGE';

/// Mã khu đang xem thực tế: ưu tiên lựa chọn của người dùng;
/// chưa chọn thì mở kho lưu chính, không có thì lấy bản đồ đầu danh sách.
/// Dropdown và nội dung dùng chung giá trị này nên luôn khớp nhau.
@riverpod
Future<String?> effectiveStorageArea(Ref ref) async {
  final selected = ref.watch(selectedStorageAreaProvider);
  if (selected != null && selected.isNotEmpty) return selected;

  final areas = await ref.watch(storageAreasProvider.future);
  if (areas.isEmpty) return null;

  final preferred = areas.where((a) => a.areaCode == _defaultAreaCode);
  return preferred.isNotEmpty ? preferred.first.areaCode : areas.first.areaCode;
}

/// Bản đồ top-down của khu đang xem.
@riverpod
Future<StorageTopMap> storageTopMap(Ref ref) async {
  final areaCode = await ref.watch(effectiveStorageAreaProvider.future);
  return ref.watch(storageMapRepositoryProvider).fetchTopMap(areaCode: areaCode);
}

/// Mặt cắt 1 kệ theo mã (trong khu đang xem).
@riverpod
Future<RackElevation> rackElevation(Ref ref, String rackCode) async {
  final areaCode = await ref.watch(effectiveStorageAreaProvider.future);
  return ref.watch(storageMapRepositoryProvider)
      .fetchElevation(rackCode, areaCode: areaCode);
}
