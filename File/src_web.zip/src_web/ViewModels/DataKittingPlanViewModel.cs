﻿using SWMS_WebTool.Models.DataKitting;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class DataKittingPlanViewModel : TableViewModel<DataKittingPL, DataKittingPLFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, DataKittingPLFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Tab = filter?.Tab ?? Filter.Tab,
                ProDate = filter?.ProDate ?? Filter.ProDate,
                Cate = filter?.Cate ?? Filter.Cate,
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                PartNo = filter?.SpecialPart ?? Filter.SpecialPart,
                Reservation = filter?.Reservation ?? Filter.Reservation,
                KittingDate = filter?.KittingDate ?? Filter.KittingDate,
                FromTime = filter?.FromTime ?? Filter.FromTime,
                FinishTime = filter?.FinishTime ?? Filter.FinishTime,
                Quantity = filter?.Quantity ?? Filter.Quantity,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
