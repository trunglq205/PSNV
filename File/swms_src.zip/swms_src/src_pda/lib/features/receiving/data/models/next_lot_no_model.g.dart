// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'next_lot_no_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NextLotNoModel _$NextLotNoModelFromJson(Map<String, dynamic> json) =>
    NextLotNoModel(
      lotNo: json['lotNo'] as String,
      categoryCode: (json['categoryCode'] as num).toInt(),
      datePart: json['datePart'] as String,
      sequence: (json['sequence'] as num).toInt(),
    );

Map<String, dynamic> _$NextLotNoModelToJson(NextLotNoModel instance) =>
    <String, dynamic>{
      'lotNo': instance.lotNo,
      'categoryCode': instance.categoryCode,
      'datePart': instance.datePart,
      'sequence': instance.sequence,
    };
