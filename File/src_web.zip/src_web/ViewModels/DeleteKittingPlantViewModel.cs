﻿using SWMS_WebTool.Models;

namespace SWMS_WebTool.ViewModels
{
    public class DeleteKittingPlantViewModel
    {
        public string Plant { get; set; }
        public string ProducteDate { get; set; }
        public string Model { get; set; }
        public bool IsUrgentDIP { get; set; }
        public IEnumerable<DataKittingDIPModel> Items { get; set; }
    }
}
