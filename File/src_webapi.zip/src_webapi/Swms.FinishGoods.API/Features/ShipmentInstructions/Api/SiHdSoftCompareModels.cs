using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

// So sánh SI giữa SWMS và HD soft (hệ thống cũ) — chạy song song phải khớp dữ liệu.

/// <summary>Lọc theo NGÀY VANNING ở 1 trong 2 hệ thống (gộp SI_No của cả hai). Chỉ từ hôm nay trở đi —
/// đối chiếu để kịp sửa trước khi xuất, không xem lại quá khứ.
/// Vanning: SWMS = COALESCE(vanning_date, etd_date); HD soft = "Loading date" trong headernote3, không có thì ETD.
/// Warehouse lọc phía HD soft (HD soft chung nhiều kho); để trống "warehouse=" = mọi kho.</summary>
public class SiCompareQuery
{
    [Required] public DateTime? From { get; set; }
    [Required] public DateTime? To { get; set; }
    [MaxLength(50)] public string? Warehouse { get; set; } = "PSNV";
    /// <summary>true: Items chỉ gồm SI có vấn đề (số đếm vẫn tính trên tất cả).</summary>
    public bool OnlyIssues { get; set; }
}

/// <summary>Result: match | mismatch | only_swms (HD soft không có) | only_hdsoft (SWMS chưa có).</summary>
public record SiCompareSummaryResponse(
    string SiNo,
    string Result,
    int IssueCount,
    string? FirstIssue,
    bool IsCancelled,               // 1 trong 2 bên đã huỷ — web có thể làm mờ
    DateTime? EtdDate,              // ETD SWMS; SI chỉ có ở HD soft thì lấy ETD bên HD soft
    DateTime? VanningDate,          // vanning SWMS (trống thì ETD); SI chỉ có ở HD soft thì lấy bên HD soft — dùng để lọc / sắp xếp
    long? SwmsId,
    string? SwmsDocNo,
    string? SwmsStatus,
    DateTime? SwmsCreatedAt,
    int SwmsLineCount,
    int SwmsTotalQty,

    long? HdSoftOrderId,
    string? HdSoftDocNo,
    string? HdSoftStatus,
    string? HdSoftStatusName,
    DateTime? HdSoftCreatedAt,
    int HdSoftLineCount,
    decimal HdSoftTotalQty);

/// <summary>1 trường header. Status: match | diff | only_swms | only_hdsoft (SI chỉ có ở 1 bên).
/// Swms / HdSoft đã chuẩn hoá giống nhau (ngày yyyy-MM-dd, bỏ số 0 đầu…), null = trống.</summary>
public record SiCompareField(string Field, string Label, string? Swms, string? HdSoft, string Status);

/// <summary>1 nhóm dòng cùng khoá (packing list + item + model, hoặc chỉ model).
/// Status: match | qty_diff | field_diff | only_swms | only_hdsoft.
/// SwmsQtyPicked / SwmsQtyCut / HdSoftQtyDelivered chỉ để xem, không tính vào lệch.</summary>
public record SiCompareLine(
    string Key,
    string Model,
    string? PackingListNo,
    string? PackingItemNo,
    string Status,
    int? SwmsQty,
    decimal? HdSoftQty,
    List<int> SwmsLineNos,
    List<int> HdSoftLineNos,
    int SwmsQtyPicked,
    int SwmsQtyCut,
    decimal HdSoftQtyDelivered,
    List<SiCompareField> Fields,
    string? Note);

/// <summary>LineKeyMode: packing (khớp từng packing item) | model (HD soft không có cột packing -> so tổng theo model).
/// Notes: thông tin phụ (HD soft nhiều phiếu cùng SI, trường không so được vì thiếu cột…).</summary>
public record SiCompareDetailResponse(
    SiCompareSummaryResponse Summary,
    string LineKeyMode,
    List<SiCompareField> Header,
    List<SiCompareLine> Lines,
    List<string> Notes,
    DateTime ComparedAt);

public record SiCompareListResponse(
    DateTime From,
    DateTime To,
    string? Warehouse,
    int Total,
    int Matched,
    int Mismatched,
    int OnlySwms,
    int OnlyHdSoft,
    List<SiCompareSummaryResponse> Items,
    DateTime ComparedAt);
