using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.ReturnInstructions.Business;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// Mục 2d — FA quét serial đóng lại Pallet ID sau rework.
///
/// Khác mục 2a (SCS WH nhận hàng khách trả) ở chỗ quan trọng nhất: serial lạ
/// VẪN cho quét tiếp, chỉ bị loại khỏi pallet và ghi vào nhật ký lệch để SCS WH
/// đặt riêng ra. Mục 2a thì CHẶN.
///
/// Đặt chung route <c>/api/return-instructions/{docId}</c> chứ không mở route
/// mới: đây vẫn là việc trên một phiếu back hàng, và PDA đã có sẵn base đó.
/// </summary>
[ApiController]
[Route("api/return-instructions/{docId:long}")]
public class ReturnFaPalletsController : ControllerBase
{
    private readonly IReturnFaPalletService _service;

    /// <summary>Luồng back hàng — chỗ ở của bước "FA đến lấy hàng".</summary>
    private readonly IReturnBackFlowService _backFlow;

    public ReturnFaPalletsController(
        IReturnFaPalletService service, IReturnBackFlowService backFlow)
    {
        _service = service;
        _backFlow = backFlow;
    }

    /// <summary>
    /// Sổ serial dạng GỌN (serial · model · status) để PDA tải một lần rồi kiểm
    /// NGAY LÚC QUÉT, không chờ mạng từng con.
    ///
    /// Chỉ cần quyền xem: nó là dữ liệu của phiếu, và cả FA lẫn SCS đều đọc.
    /// </summary>
    [HttpGet("serial-index")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<ReturnSerialIndexResponse>>> GetSerialIndex(long docId)
        => Ok(await _service.GetSerialIndexAsync(docId));

    /// <summary>FA đóng pallet mới sau rework.</summary>
    [HttpPost("fa-pallets")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ProcessFa>]
    public async Task<ActionResult<CreateFaPalletResponse>> CreateFaPallet(
        long docId, [FromBody] CreateFaPalletRequest request)
        => Ok(await _service.CreateAsync(docId, request));

    /// <summary>
    /// FA ĐẾN LẤY HÀNG (B5): quét một Pallet ID đang đứng ở khu Nhận hàng.
    /// Serial sang at_fa, pallet rời vị trí, lần đề nghị đóng nếu đã đủ SL.
    ///
    /// Route TUYỆT ĐỐI (dấu / ở đầu) vì nó KHÔNG có docId: FA chỉ cầm pallet
    /// trong tay, phiếu suy ra từ sổ serial. Vẫn để trong controller này để mọi
    /// endpoint phía FA nằm cùng một chỗ.
    ///
    /// Dùng lại quyền đóng pallet của FA (chốt 12/11) — không thêm lá mới:
    /// cùng một người, cùng một ca làm, thêm lá nữa chỉ tạo thêm chỗ để quên gán.
    /// </summary>
    [HttpPost("/api/return-instructions/fa-pickup")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ProcessFa>]
    public async Task<ActionResult<FaPickupResponse>> FaPickup(
        [FromBody] FaPickupRequest request)
        => Ok(await _backFlow.FaPickupAsync(request));

    /// <summary>
    /// Nhật ký serial lệch. <paramref name="openOnly"/> mặc định true — màn hình
    /// cần việc CÒN PHẢI LÀM, nhật ký cũ thì càng ngày càng dài.
    /// </summary>
    [HttpGet("mismatches")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<ReturnMismatchResponse>>> GetMismatches(
        long docId, [FromQuery] bool openOnly = true)
        => Ok(await _service.GetMismatchesAsync(docId, openOnly));

    /// <summary>
    /// SCS đánh dấu đã đặt riêng / đã trả về đúng phiếu.
    ///
    /// Nhận cả <c>Process</c> và <c>Create</c>: người đặt hàng riêng ra là SCS
    /// WH, nhưng Office cũng phải đóng được một dòng nhật ký đã xử lý xong —
    /// cùng lý do hai bên đều chốt được thực nhận ở mục 2b.
    /// </summary>
    [HttpPost("mismatches/{id:long}/resolve")]
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.Process,
                          Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<ActionResult<ReturnMismatchResponse>> ResolveMismatch(
        long docId, long id, [FromBody] ResolveMismatchRequest request)
        => Ok(await _service.ResolveMismatchAsync(id, request));
}
