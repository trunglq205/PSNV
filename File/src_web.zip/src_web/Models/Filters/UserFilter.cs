﻿namespace SWMS_WebTool.Models.Filters
{
    public class UserFilter : BaseFilter
    {
        public string? UId { get; set; }
        public string? FullName { get; set; }
    }
}
