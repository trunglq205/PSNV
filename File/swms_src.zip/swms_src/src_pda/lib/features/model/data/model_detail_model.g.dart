// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'model_detail_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ModelDetailModel _$ModelDetailModelFromJson(Map<String, dynamic> json) =>
    ModelDetailModel(
      id: (json['id'] as num).toInt(),
      code: json['code'] as String,
      categoryId: (json['categoryId'] as num).toInt(),
      categoryCode: (json['categoryCode'] as num?)?.toInt() ?? 0,
      categoryName: json['categoryName'] as String? ?? '',
      length: (json['length'] as num?)?.toInt() ?? 0,
      width: (json['width'] as num?)?.toInt() ?? 0,
      height: (json['height'] as num?)?.toInt() ?? 0,
      standardPacking: (json['standardPacking'] as num?)?.toInt() ?? 0,
      isActive: json['isActive'] as bool? ?? true,
      gtin: json['gtin'] as String?,
      layerLimit: (json['layerLimit'] as num?)?.toInt(),
      layerCount: (json['layerCount'] as num?)?.toInt(),
      stackingLength: (json['stackingLength'] as num?)?.toInt(),
      stackingWidth: (json['stackingWidth'] as num?)?.toInt(),
      boxPerLayer: (json['boxPerLayer'] as num?)?.toInt(),
      boxPerPallet: (json['boxPerPallet'] as num?)?.toInt(),
      setPerPallet: (json['setPerPallet'] as num?)?.toInt(),
      cargoLength: (json['cargoLength'] as num?)?.toInt(),
      cargoWidth: (json['cargoWidth'] as num?)?.toInt(),
      cargoHeight: (json['cargoHeight'] as num?)?.toInt(),
      suggestAreaId: (json['suggestAreaId'] as num?)?.toInt(),
      suggestAreaCode: json['suggestAreaCode'] as String?,
      suggestAreaName: json['suggestAreaName'] as String?,
      suggestRackRow: (json['suggestRackRow'] as List<dynamic>?)
          ?.map((e) => (e as num).toInt())
          .toList(),
      createdAt: json['createdAt'] == null
          ? null
          : DateTime.parse(json['createdAt'] as String),
    );

Map<String, dynamic> _$ModelSuggestionPatchRequestToJson(
  ModelSuggestionPatchRequest instance,
) => <String, dynamic>{
  'suggestAreaId': instance.suggestAreaId,
  'suggestRackRow': instance.suggestRackRow,
};

Map<String, dynamic> _$ModelUpdateRequestToJson(ModelUpdateRequest instance) =>
    <String, dynamic>{
      'gtin': instance.gtin,
      'length': instance.length,
      'width': instance.width,
      'height': instance.height,
      'standardPacking': instance.standardPacking,
      'layerLimit': instance.layerLimit,
      'layerCount': instance.layerCount,
      'stackingLength': instance.stackingLength,
      'stackingWidth': instance.stackingWidth,
      'suggestAreaId': instance.suggestAreaId,
      'suggestRackRow': instance.suggestRackRow,
      'isActive': instance.isActive,
    };
