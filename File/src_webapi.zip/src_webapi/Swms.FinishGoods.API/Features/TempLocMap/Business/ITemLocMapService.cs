﻿using Swms.FinishGoods.API.Features.TempLocMap.Api;

namespace Swms.FinishGoods.API.Features.TempLocMap.Business;

public interface ITempLocMapService
{
    Task<IReadOnlyList<AreaSummaryResponse>> GetAreasAsync();
    Task<MapLayoutResponse?> GetLayoutAsync(string areaCode);
    Task<AreaSummaryResponse> CreateAreaAsync(CreateAreaRequest request);
    Task SaveLayoutAsync(string areaCode, SaveLayoutRequest request);
    Task ChangeStatusAsync(string locatorCode, ChangeStatusRequest request);
    Task<LocatorPalletsResponse> GetLocatorPalletsAsync(string locatorCode);
}