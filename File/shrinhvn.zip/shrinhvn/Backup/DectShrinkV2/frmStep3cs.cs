﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class frmStep3cs : Form
    {
        Bussiness obj = new Bussiness();
        WebService objService = new WebService();
        ConnectSQL objConnect = new ConnectSQL();
        string _codepallet = "";
        string id;
        ConnectSQL conn = new ConnectSQL();
        public frmStep3cs(string id)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Normal;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            KeyPreview = true;
            this.id = id;
        }

        private void txtExtension_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtModel1.Focus();

            }
        }

        private void txtByHand_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;

                //if (cboCategory.Text.ToString() == "DP")
                //{
                //    //1.Kiểm tra 
                //    object[] objV = { this.txtPostCode.Text.ToUpper().Trim() };
                //    DataTable dtResult = conn.StoreFillDTable("SP_PRODUCT_GOPGHEP_CheckModel_PatcodeOuter", CommandType.StoredProcedure, objV);
                //    if (dtResult.Rows.Count > 0)
                //    {
                //        this.txtModel1.Text = dtResult.Rows[0]["STR_PROCESS_FACTORY"].ToString();
                //    }

                //    String value = txtModel1.Text.Trim();

                //    if (value.Contains("-V4"))
                //    {
                //        value = value.Replace("-V4", String.Empty);
                //    }
                //    txtModel1.Text = value;
                //    string process = txtModel1.Text.Trim() + "-" + txtExtension.Text.Trim();
                //    if (objService.confirmExitsModel(process, cboCategory.Text.Trim()) != "1")
                //    {
                //        lblStatus.Text = "MODEL KHONG TON TAI";
                //        lblStatus.BackColor = Color.Red;
                //        txtPostCode.Text = "";
                //        txtPostCode.Focus();
                //        txtModel1.Text = "";

                //    }
                //    else
                //    {
                //        if (Model_pallet == "")
                //            Model_pallet = value;
                //        if (value.ToUpper() != Model_pallet.ToUpper().Replace("-" + txtExtension.Text.Trim(), ""))
                //        {
                //            lblStatus.Text = "Pallet nay dang su dung cho Model " + Model_pallet.ToUpper() + Environment.NewLine + " Vui long Scan dung Model khac hoac scan Pallet moi";
                //            lblStatus.BackColor = Color.Red;
                //            this.txtPostCode.Text = "";
                //            txtPostCode.Focus();
                //            txtModel1.Text = "";
                //        }
                //        else
                //        {
                //            lblStatus.Text = "";
                //            lblStatus.BackColor = Color.Silver;
                //            //txtSerial1.Focus();
                //            string s_pallet = txtPallet.Text.Trim();
                //            string s_model = txtModel1.Text.Trim();
                //            string model_fullname = s_model + "-" + txtExtension.Text.Trim();

                //            String status = objService.verifyOverFlow(model_fullname, s_pallet, cboCategory.Text.Trim());
                //            if (status == "0")
                //            {
                //                MessageBox.Show("Đã quét đầy rồi");
                //                txtPallet.Text = "";
                //                txtModel1.Text = "";
                //                txtModel2.Text = "";
                //                txtSerial1.Text = "";
                //                txtSerial2.Text = "";
                //                txtPostCode.Text = "";
                //                txtPallet.Focus();

                //            }
                //            else if (status == "1")
                //            {
                //                txtPallet.Text = "";
                //                txtModel1.Text = "";
                //                txtModel2.Text = "";
                //                txtSerial1.Text = "";
                //                txtPostCode.Text = "";
                //                txtSerial2.Text = ""; txtPallet.Focus();
                //                lblStatus.BackColor = Color.Silver;
                //                lblStatus.Text = "";
                //                //Pallet vẫn chưa đầy theo tiêu chuẩn nên vẫn có thể quét tiếp
                //                frmShrink st4 = new frmShrink(id, s_model, txtExtension.Text, s_pallet, cboCategory.Text.Trim());
                //                st4.ShowDialog();
                //                st4.TopMost = true;
                //                //lblStatus.Text = "OK";
                //            }
                //        }
                //        //txtSerial2.Focus();
                //    }
                //}

                if (cboCategory.Text.ToString() != "DP")
                {
                    String value = txtModel1.Text.Trim();

                    if (value.Contains("-V4"))
                    {
                        value = value.Replace("-V4", String.Empty);
                    }
                    txtModel1.Text = value;
                    string process = txtModel1.Text.Trim() + "-" + txtExtension.Text.Trim();
                    if (objService.confirmExitsModel(process, cboCategory.Text.Trim()) != "1")
                    {
                        lblStatus.Text = "MODEL KHONG TON TAI";
                        lblStatus.BackColor = Color.Red;
                        txtModel1.Text = "";
                        txtModel1.Focus();

                    }
                    else
                    {
                        if (Model_pallet == "")
                            Model_pallet = value;
                        if (value.ToUpper() != Model_pallet.ToUpper().Replace("-" + txtExtension.Text.Trim(), ""))
                        {
                            lblStatus.Text = "Pallet nay dang su dung cho Model " + Model_pallet.ToUpper() + Environment.NewLine + " Vui long Scan dung Model khac hoac scan Pallet moi";
                            lblStatus.BackColor = Color.Red;
                            txtModel1.Text = "";
                            txtModel1.Focus();
                        }
                        else
                        {
                            lblStatus.Text = "";
                            lblStatus.BackColor = Color.Silver;
                            //txtSerial1.Focus();
                            string s_pallet = txtPallet.Text.Trim();
                            string s_model = txtModel1.Text.Trim();
                            string model_fullname = s_model + "-" + txtExtension.Text.Trim();

                            String status = objService.verifyOverFlow(model_fullname, s_pallet, cboCategory.Text.Trim());
                            if (status == "0")
                            {
                                MessageBox.Show("Đã quét đầy rồi");
                                txtPallet.Text = "";
                                txtModel1.Text = "";
                                txtModel2.Text = "";
                                txtSerial1.Text = "";
                                txtSerial2.Text = ""; txtPallet.Focus();

                            }
                            else if (status == "1")
                            {
                                txtPallet.Text = "";
                                txtModel1.Text = "";
                                txtModel2.Text = "";
                                txtSerial1.Text = "";
                                txtSerial2.Text = ""; txtPallet.Focus();
                                lblStatus.BackColor = Color.Silver;
                                lblStatus.Text = "";
                                //Pallet vẫn chưa đầy theo tiêu chuẩn nên vẫn có thể quét tiếp
                                frmShrink st4 = new frmShrink(id, s_model, txtExtension.Text, s_pallet, cboCategory.Text.Trim());
                                st4.ShowDialog();
                                st4.TopMost = true;
                                //lblStatus.Text = "OK";
                            }
                        }
                        //txtSerial2.Focus();
                    }



                }
            }
        }

        private void txtByBarcode_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                txtModel2.Text = txtModel2.Text.Trim();
                txtModel2.Focus();

            }

        }

        private void txtByHand_TextChanged(object sender, EventArgs e)
        {
            if (txtModel1.Text.Trim().Contains('%'))
            {
                txtModel1.Text = txtModel1.Text.Replace('%', ' ');
                txtModel1.Text = txtModel1.Text.Trim();
            }

        }


        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtByBarcode_TextChanged(object sender, EventArgs e)
        {
            if (txtSerial1.Text.Trim().Contains('%'))
            {
                txtSerial1.Text = txtSerial1.Text.Replace('%', ' ');
                txtSerial1.Text = txtSerial1.Text.Trim();
            }
        }

        private void btnResetText_Click(object sender, EventArgs e)
        {
            txtSerial1.Text = "";
            txtModel1.Text = "";
            txtPostCode.Text = "";
            txtSerial2.Text = ""; txtModel2.Text = "";

            txtModel1.Focus();

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void frmStep3cs_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.F5)
            {
                e.SuppressKeyPress = true;
                btnResetText_Click(sender, e);
            }
        }
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Escape)
            {
                e.Handled = true;   // stop annoying beep
            }

            // call base handler...
            base.OnKeyPress(e);
        }
        private void frmStep3cs_Load(object sender, EventArgs e)
        {
            DataTable dt_Fact = new DataTable();
            dt_Fact = objService.FactCode_GetAll();
            txtExtension.DataSource = dt_Fact;
            txtExtension.DisplayMember = "FactCode";
            txtExtension.SelectedIndex = 0;
            txtPallet.Focus();

            //txtExtension.Items.Add("EU");
            cboCategory.DataSource = objService.Get_category();
            cboCategory.DisplayMember = "Description";
            cboCategory.ValueMember = "Codepallet";
            cboCategory.SelectedIndex = 0;
            cboCategory_SelectedIndexChanged(sender, e);

            
        }

        private void txtModel2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                String value = txtModel2.Text;

                if (value.Contains("-V4"))
                {
                    value = value.Replace("-V4", String.Empty);
                }
                txtModel2.Text = value;

                if (txtModel1.Text.Trim() != txtModel2.Text.Trim())
                {
                    lblStatus.Text = "2 MODEL PHAI BANG NHAU";
                    lblStatus.BackColor = Color.Red;
                    txtModel2.Text = "";
                    txtModel2.Focus();
                }
                else
                {
                    string process = txtModel1.Text.Trim() + "-" + txtExtension.Text.Trim();
                    if (objService.confirmExitsModel(process, cboCategory.Text.Trim()) != "1")
                    {
                        lblStatus.Text = "MODEL KHONG TON TAI";
                        lblStatus.BackColor = Color.Red;
                        txtModel2.Text = "";
                        txtModel2.Focus();
                    }
                    else
                    {
                        txtSerial2.Focus();
                        lblStatus.BackColor = Color.Silver;
                        lblStatus.Text = "";
                    }
                }

            }
        }

        private void txtModel2_TextChanged(object sender, EventArgs e)
        {
            if (txtModel2.Text.Trim().Contains('%'))
            {
                txtModel2.Text = txtModel2.Text.Replace('%', ' ');
                txtModel2.Text = txtModel2.Text.Trim();

            }
        }

        private void txtSerial2_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtSerial2_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                if ((txtModel1.Text == txtModel2.Text) && (txtSerial1.Text != txtSerial2.Text))
                {

                    string process = txtModel1.Text.Trim() + "-" + txtExtension.Text.Trim();
                    if (objService.confirmExitsModel(process, cboCategory.Text.Trim()) != "1")
                    {
                        lblStatus.Text = "Model Không tồn tại";
                        lblStatus.BackColor = Color.Red;
                        txtModel1.Text = "";
                        txtModel2.Text = "";
                        txtSerial2.Text = "";
                        txtSerial1.Text = "";
                        txtModel1.Focus();


                    }
                    else
                    {
                        lblStatus.Text = "";
                        string s_pallet = txtPallet.Text.Trim();
                        string s_model = txtModel1.Text.Trim();
                        string model_fullname = s_model + "-" + txtExtension.Text.Trim();

                        String status = objService.verifyOverFlow(model_fullname, s_pallet,cboCategory.Text.Trim());
                        if (status == "0")
                        {
                            MessageBox.Show("Đã quét đầy rồi");
                            txtPallet.Text = "";
                            txtModel1.Text = "";
                            txtModel2.Text = "";
                            txtSerial1.Text = "";
                            txtSerial2.Text = ""; txtPallet.Focus();
                            txtPostCode.Text = "";
                            lblStatus.Text = "Đã quét đầy rồi";
                            lblStatus.BackColor = Color.Red;

                        }
                        else if (status == "1")
                        {
                            txtPallet.Text = "";
                            txtModel1.Text = "";
                            txtModel2.Text = "";
                            txtSerial1.Text = "";
                            txtSerial2.Text = ""; txtPallet.Focus();
                            lblStatus.BackColor = Color.Silver;
                            lblStatus.Text = "";
                            txtPostCode.Text = "";
                            //Pallet vẫn chưa đầy theo tiêu chuẩn nên vẫn có thể quét tiếp
                            frmShrink st4 = new frmShrink(id, s_model, txtExtension.Text, s_pallet,cboCategory.Text.Trim());
                            st4.ShowDialog();
                            st4.TopMost = true;
                            //lblStatus.Text = "OK";
                        }
                    }
                }
                else
                {
                    lblStatus.Text = "QUÉT SAI";
                    lblStatus.BackColor = Color.Red;
                }
            }
        }
        //public string totalBefore()
        //{
        //    return objService.count_model(txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim());
        //}
        string Model_pallet="";
        private void txtPallet_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (cboCategory.Text.ToString() == "DP")
                {

                    //txtPostCode


                    e.SuppressKeyPress = true;
                    string pallet_no = txtPallet.Text.Trim();

                    if (pallet_no.Length != 12)
                    {

                        lblStatus.Text = "SAI ĐỊNH DẠNG SỐ PALLET";
                        lblStatus.BackColor = Color.Red;
                        txtPallet.Focus();
                        txtPallet.SelectAll();

                    }

                    else
                    {
                        if (pallet_no.Trim().Substring(0, 3) != _codepallet)
                        {
                            lblStatus.Text = "SAI ĐỊNH DẠNG SỐ PALLET " + Environment.NewLine + "ĐỊNH DẠNG DÚNG BẮT ĐẦU BẰNG " + _codepallet;
                            lblStatus.BackColor = Color.Red;
                            txtPallet.Focus();
                            txtPallet.SelectAll();
                            return;
                        }

                        else
                        {

                            DataTable dt_Model_pallet = obj.Get_Model_PalletID(txtPallet.Text.Trim(), cboCategory.Text.Trim());
                            Model_pallet = "";
                            if (dt_Model_pallet.Rows.Count > 0)
                            {
                                Model_pallet = dt_Model_pallet.Rows[0][0].ToString();

                                txtPostCode.Text = "";
                                txtPostCode.Focus();
                                // txtModel1.Text = Model_pallet;
                                //this.txtModel1 .Focus();
                                lblStatus.BackColor = Color.Silver;
                                lblStatus.Text = "";
                            }
                            else
                            {
                                txtPostCode.SelectAll();
                                txtPostCode.Focus();
                                lblStatus.BackColor = Color.Silver;
                                lblStatus.Text = "";
                                //lblStatus.Text = "Không đúng Model trên Pallet này!";
                                //lblStatus.ForeColor = Color.Red;
                                //lblStatus.BackColor = Color.Black;
                            }

                        }
                    }
                }


                else
                {


                    //
                    e.SuppressKeyPress = true;
                    string pallet_no = txtPallet.Text.Trim();

                    if (pallet_no.Length != 12)
                    {

                        lblStatus.Text = "SAI ĐỊNH DẠNG SỐ PALLET";
                        lblStatus.BackColor = Color.Red;
                        txtPallet.Focus();
                        txtPallet.SelectAll();

                    }

                    else
                    {
                        if (pallet_no.Trim().Substring(0, 3) != _codepallet)
                        {
                            lblStatus.Text = "SAI ĐỊNH DẠNG SỐ PALLET " + Environment.NewLine + "ĐỊNH DẠNG DÚNG BẮT ĐẦU BẰNG " + _codepallet;
                            lblStatus.BackColor = Color.Red;
                            txtPallet.Focus();
                            txtPallet.SelectAll();
                            return;
                        }

                        else
                        {

                            DataTable dt_Model_pallet = obj.Get_Model_PalletID(txtPallet.Text.Trim(), cboCategory.Text.Trim());
                            Model_pallet = "";
                            if (dt_Model_pallet.Rows.Count > 0)
                            {
                                Model_pallet = dt_Model_pallet.Rows[0][0].ToString();
                                txtModel1.Focus();
                                lblStatus.BackColor = Color.Silver;
                                lblStatus.Text = "";
                            }
                            else
                            {
                                txtModel1.SelectAll();
                                txtModel1.Focus();
                                lblStatus.BackColor = Color.Silver;
                                lblStatus.Text = "";
                                //lblStatus.Text = "Không đúng Model trên Pallet này!";
                                //lblStatus.ForeColor = Color.Red;
                                //lblStatus.BackColor = Color.Black;
                            }

                        }
                    }
                    //txtPostCode.Focus();

                }
            }
        }

 
        
        private void txtExtension_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cboCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                _codepallet = cboCategory.SelectedValue.ToString();
                //MessageBox.Show(_codepallet);
            }
            catch
            {
                _codepallet = "";
            }
        }

      

        private void txtPostCode_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                e.SuppressKeyPress = true;
                lblStatus.Text = "";
                lblStatus.BackColor = Color.White; ;

                if (cboCategory.Text.ToString() == "DP")
                {
                    if (txtPostCode.Text == "")
                      {

                            lblStatus.Text = "POSTCODE KHÔNG ĐƯỢC TRỐNG.";
                            lblStatus.BackColor = Color.Red;
                            this.txtPostCode.Text = "";
                            txtPostCode.Focus();
                     }
                    else
                    {

                    //1.Kiểm tra 
                    object[] objV = { this.txtPostCode.Text.ToUpper().Trim() };
                    DataTable dtResult = conn.StoreFillDTable("SP_PRODUCT_GOPGHEP_CheckModel_PatcodeOuter", CommandType.StoredProcedure, objV);
                    if (dtResult.Rows.Count > 0)
                    {
                        this.txtModel1.Text = dtResult.Rows[0]["STR_PROCESS_FACTORY"].ToString();
                    }

                    String value = txtModel1.Text.Trim();

                    if (value.Contains("-V4"))
                    {
                        value = value.Replace("-V4", String.Empty);
                    }
                    txtModel1.Text = value;
                    string process = txtModel1.Text.Trim() + "-" + txtExtension.Text.Trim();
                    if (objService.confirmExitsModel(process, cboCategory.Text.Trim()) != "1")
                    {
                        lblStatus.Text = "MODEL KHÔNG TỒN TẠI.";
                        lblStatus.BackColor = Color.Red;
                        txtPostCode.Text = "";
                        txtPostCode.Focus();
                        txtModel1.Text = "";

                    }
                    else
                    {
                        if (Model_pallet == "")
                            Model_pallet = value;
                        if (value.ToUpper() != Model_pallet.ToUpper().Replace("-" + txtExtension.Text.Trim(), ""))
                        {
                             lblStatus.Text = "Pallet nay dang su dung cho Model " + Model_pallet.ToUpper() + Environment.NewLine + " Vui long Scan dung Model khac hoac scan Pallet moi";
                             lblStatus.BackColor = Color.Red;
                             this.txtPostCode.Text = "";
                             txtPostCode.Focus();
                             txtModel1.Text = "";
                        }
                        else
                        {
                            lblStatus.Text = "";
                            lblStatus.BackColor = Color.Silver;
                            //txtSerial1.Focus();
                            string s_pallet = txtPallet.Text.Trim();
                            string s_model = txtModel1.Text.Trim();
                            string model_fullname = s_model + "-" + txtExtension.Text.Trim();

                            String status = objService.verifyOverFlow(model_fullname, s_pallet, cboCategory.Text.Trim());
                            if (status == "0")
                            {
                                MessageBox.Show("Đã quét đầy rồi");
                                txtPallet.Text = "";
                                txtModel1.Text = "";
                                txtModel2.Text = "";
                                txtSerial1.Text = "";
                                txtSerial2.Text = "";
                                txtPostCode.Text = "";
                                txtPallet.Focus();
                                lblStatus.Text = "Đã quét đầy rồi.";
                                lblStatus.BackColor = Color.Red;

                            }
                            else if (status == "1")
                            {
                                txtPallet.Text = "";
                                txtModel1.Text = "";
                                txtModel2.Text = "";
                                txtSerial1.Text = "";
                                txtPostCode.Text = "";
                                txtSerial2.Text = ""; txtPallet.Focus();
                                lblStatus.BackColor = Color.Silver;
                                lblStatus.Text = "";
                                txtPostCode.Text = "";
                                //Pallet vẫn chưa đầy theo tiêu chuẩn nên vẫn có thể quét tiếp
                                frmShrink st4 = new frmShrink(id, s_model, txtExtension.Text, s_pallet, cboCategory.Text.Trim());
                                st4.ShowDialog();
                                st4.TopMost = true;
                                //lblStatus.Text = "OK";
                            }
                        }
                        //txtSerial2.Focus();
                    }
                }
                }
            }
           
         }

        
    }
}
