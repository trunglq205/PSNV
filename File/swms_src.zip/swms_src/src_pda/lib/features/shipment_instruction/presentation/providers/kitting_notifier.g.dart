// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'kitting_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Màn Soạn hàng. Family theo [siId]:
///   - có siId (bấm "Soạn hàng" ở danh sách / chi tiết SI) → mở đúng SI đó.
///   - null (vào thẳng từ menu) → tự lấy SI đang soạn ĐẦU TIÊN.

@ProviderFor(KittingNotifier)
final kittingProvider = KittingNotifierFamily._();

/// Màn Soạn hàng. Family theo [siId]:
///   - có siId (bấm "Soạn hàng" ở danh sách / chi tiết SI) → mở đúng SI đó.
///   - null (vào thẳng từ menu) → tự lấy SI đang soạn ĐẦU TIÊN.
final class KittingNotifierProvider
    extends $NotifierProvider<KittingNotifier, KittingState> {
  /// Màn Soạn hàng. Family theo [siId]:
  ///   - có siId (bấm "Soạn hàng" ở danh sách / chi tiết SI) → mở đúng SI đó.
  ///   - null (vào thẳng từ menu) → tự lấy SI đang soạn ĐẦU TIÊN.
  KittingNotifierProvider._({
    required KittingNotifierFamily super.from,
    required int? super.argument,
  }) : super(
         retry: null,
         name: r'kittingProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$kittingNotifierHash();

  @override
  String toString() {
    return r'kittingProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  KittingNotifier create() => KittingNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(KittingState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<KittingState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is KittingNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$kittingNotifierHash() => r'18e88eaba2bc92ef5e74293d3938898e41a747fd';

/// Màn Soạn hàng. Family theo [siId]:
///   - có siId (bấm "Soạn hàng" ở danh sách / chi tiết SI) → mở đúng SI đó.
///   - null (vào thẳng từ menu) → tự lấy SI đang soạn ĐẦU TIÊN.

final class KittingNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          KittingNotifier,
          KittingState,
          KittingState,
          KittingState,
          int?
        > {
  KittingNotifierFamily._()
    : super(
        retry: null,
        name: r'kittingProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Màn Soạn hàng. Family theo [siId]:
  ///   - có siId (bấm "Soạn hàng" ở danh sách / chi tiết SI) → mở đúng SI đó.
  ///   - null (vào thẳng từ menu) → tự lấy SI đang soạn ĐẦU TIÊN.

  KittingNotifierProvider call(int? siId) =>
      KittingNotifierProvider._(argument: siId, from: this);

  @override
  String toString() => r'kittingProvider';
}

/// Màn Soạn hàng. Family theo [siId]:
///   - có siId (bấm "Soạn hàng" ở danh sách / chi tiết SI) → mở đúng SI đó.
///   - null (vào thẳng từ menu) → tự lấy SI đang soạn ĐẦU TIÊN.

abstract class _$KittingNotifier extends $Notifier<KittingState> {
  late final _$args = ref.$arg as int?;
  int? get siId => _$args;

  KittingState build(int? siId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<KittingState, KittingState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<KittingState, KittingState>,
              KittingState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
