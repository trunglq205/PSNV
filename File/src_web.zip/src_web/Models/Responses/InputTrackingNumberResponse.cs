﻿namespace SWMS_WebTool.Models.Responses
{
    public class InputTrackingNumberResponse
    {
        public int Id { get; set; }
        public int Type { get; set; }
    }
}
