// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shipment_instruction_list_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Danh sách chỉ thị lấy hàng.

@ProviderFor(ShipmentInstructionListNotifier)
final shipmentInstructionListProvider =
    ShipmentInstructionListNotifierProvider._();

/// Danh sách chỉ thị lấy hàng.
final class ShipmentInstructionListNotifierProvider
    extends
        $NotifierProvider<
          ShipmentInstructionListNotifier,
          ShipmentInstructionListState
        > {
  /// Danh sách chỉ thị lấy hàng.
  ShipmentInstructionListNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'shipmentInstructionListProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$shipmentInstructionListNotifierHash();

  @$internal
  @override
  ShipmentInstructionListNotifier create() => ShipmentInstructionListNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ShipmentInstructionListState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ShipmentInstructionListState>(value),
    );
  }
}

String _$shipmentInstructionListNotifierHash() =>
    r'76a4e8cc59ad27b5a85e7a3c5e4ef06e195b1a9b';

/// Danh sách chỉ thị lấy hàng.

abstract class _$ShipmentInstructionListNotifier
    extends $Notifier<ShipmentInstructionListState> {
  ShipmentInstructionListState build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref
            as $Ref<ShipmentInstructionListState, ShipmentInstructionListState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                ShipmentInstructionListState,
                ShipmentInstructionListState
              >,
              ShipmentInstructionListState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
