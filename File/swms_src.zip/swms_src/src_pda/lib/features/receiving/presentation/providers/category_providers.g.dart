// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'category_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Danh mục Cate — tải 1 lần, giữ suốt phiên.
/// KHÔNG `read(.future)` trực tiếp — dùng [CategoriesRefX.readCategories]
/// để lỗi lần trước không bị cache vĩnh viễn.

@ProviderFor(categories)
final categoriesProvider = CategoriesProvider._();

/// Danh mục Cate — tải 1 lần, giữ suốt phiên.
/// KHÔNG `read(.future)` trực tiếp — dùng [CategoriesRefX.readCategories]
/// để lỗi lần trước không bị cache vĩnh viễn.

final class CategoriesProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<Category>>,
          List<Category>,
          FutureOr<List<Category>>
        >
    with $FutureModifier<List<Category>>, $FutureProvider<List<Category>> {
  /// Danh mục Cate — tải 1 lần, giữ suốt phiên.
  /// KHÔNG `read(.future)` trực tiếp — dùng [CategoriesRefX.readCategories]
  /// để lỗi lần trước không bị cache vĩnh viễn.
  CategoriesProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'categoriesProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$categoriesHash();

  @$internal
  @override
  $FutureProviderElement<List<Category>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<Category>> create(Ref ref) {
    return categories(ref);
  }
}

String _$categoriesHash() => r'9ddd97413db7f162f803ae33a714ab7800ac3932';
