﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class PlanPrintPanacimViewModel : TableViewModel<PlanPrintPanacim, PlanPanacimFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, PlanPanacimFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                DeliveryDate = filter?.DeliveryDate ?? Filter.DeliveryDate,
                Invoice = filter?.Invoice ?? Filter.Invoice,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
