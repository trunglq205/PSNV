﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models
{
    public class Vendor
    {
        [Display(Name = "Vendor Code")]
        public string VendorCode { get; set; }
        [Display(Name = "Global Code")]
        public string GlobalCode { get; set; }
        [Display(Name = "Vendor Name")]
        public string VendorName { get; set; }
        [Display(Name = "Vendor Short Name")]
        public string VendorNameShort { get; set; }
        public string Country { get; set; }
    }
}
