import 'package:swms_finish_goods/core/extensions/jwt_extensions.dart';
import 'package:swms_finish_goods/core/extensions/safe_cast_extensions.dart';
import 'package:swms_finish_goods/core/storage/secure_storage_service.dart';
import 'package:swms_finish_goods/features/auth/data/datasouces/auth_remote_datasource.dart';
import 'package:swms_finish_goods/features/auth/data/models/login_request_model.dart';
import 'package:swms_finish_goods/features/auth/domain/auth_entity.dart';
import 'package:swms_finish_goods/features/auth/domain/auth_repository.dart';
import 'package:swms_finish_goods/features/auth/domain/user_info.dart';

class AuthRepositoryImpl implements AuthRepository {
  final AuthRemoteDataSource _remote;
  final SecureStorageService _local;

  AuthRepositoryImpl(this._remote, this._local);

  @override
  Future<AuthEntity> login(String username, String password) async {
    final response = await _remote.login(
      LoginRequestModel(username: username, password: password),
    );

    // Lưu token sau khi login thành công
    await _local.saveToken(response.accessToken);

    return response.toEntity();
  }

  @override
  Future<UserInfo> getUserInfo() async {
    final token = await _local.readToken();
    final claims = token?.claims;

    if (claims == null) {
      throw Exception('Token not found');
    }

    return UserInfo(
      id: claims[JwtClaims.nameIdentifier].asString() ?? '',
      employeeCode: claims[JwtClaims.employeeCode].asString() ?? '',
      fullName: claims[JwtClaims.name].asString() ?? '',
    );
  }
}
