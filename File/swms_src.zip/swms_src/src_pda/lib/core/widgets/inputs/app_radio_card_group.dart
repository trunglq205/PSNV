import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Một lựa chọn trong [AppRadioCardGroup].
class RadioCardItem<T> {
  const RadioCardItem({
    required this.value,
    required this.title,
    required this.subtitle,
    required this.icon,
  });

  final T value;
  final String title;
  final String subtitle;
  final IconData icon;
}

/// Nhóm radio dạng thẻ (card) — mỗi mục có icon, tiêu đề, phụ đề và chấm chọn.
///
/// Mục được chọn: viền primary, nền tô nhẹ xanh, icon gradient xanh lá, chấm
/// chọn primary. Các mục khác: viền border, icon nền bg-2 (card2), chấm rỗng.
///
/// ```dart
/// AppRadioCardGroup<RecvMode>(
///   value: mode,
///   onChanged: (m) => setState(() => mode = m),
///   items: const [
///     RadioCardItem(
///       value: RecvMode.pallet,
///       title: 'Quét Pallet ID',
///       subtitle: 'Pallet đã có QR sẵn',
///       icon: Icons.grid_view_rounded,
///     ),
///     RadioCardItem(
///       value: RecvMode.carton,
///       title: 'Quét Carton Card',
///       subtitle: 'Quét từng thùng trên pallet',
///       icon: Icons.inventory_2_outlined,
///     ),
///     RadioCardItem(
///       value: RecvMode.manual,
///       title: 'Nhập tay',
///       subtitle: 'Pallet không có mã',
///       icon: Icons.edit_outlined,
///     ),
///   ],
/// );
/// ```
class AppRadioCardGroup<T> extends StatelessWidget {
  const AppRadioCardGroup({
    super.key,
    required this.value,
    required this.items,
    required this.onChanged,
    this.spacing = AppDimens.sm,
  });

  final T? value;
  final List<RadioCardItem<T>> items;
  final ValueChanged<T>? onChanged;

  /// Khoảng cách giữa các thẻ.
  final double spacing;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < items.length; i++) ...[
          if (i > 0) SizedBox(height: spacing),
          _RadioCard<T>(
            item: items[i],
            selected: items[i].value == value,
            onTap: onChanged == null ? null : () => onChanged!(items[i].value),
          ),
        ],
      ],
    );
  }
}

class _RadioCard<T> extends StatelessWidget {
  const _RadioCard({
    required this.item,
    required this.selected,
    required this.onTap,
  });

  final RadioCardItem<T> item;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final scheme = Theme.of(context).colorScheme;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 150),
        padding: const EdgeInsets.symmetric(
          horizontal: AppDimens.md - 2, // 14
          vertical: AppDimens.md - AppDimens.xs, // 12
        ),
        decoration: BoxDecoration(
          color: scheme.surface,
          borderRadius: BorderRadius.circular(AppDimens.rCard), // 14
          border: Border.all(
            color: selected ? AppColors.primary : swms.border,
            width: selected ? 1.5 : 1,
          ),
          boxShadow: selected
              ? [
                  BoxShadow(
                    color: swms.success.withValues(alpha: 0.18),
                    offset: const Offset(0, 4),
                    blurRadius: 12,
                    spreadRadius: -2,
                  ),
                  const BoxShadow(
                    color: Color(0x0A000000),
                    offset: Offset(0, 1),
                    blurRadius: 3,
                  ),
                ]
              : const [
                  BoxShadow(
                    color: Color(0x0A000000),
                    offset: Offset(0, 1),
                    blurRadius: 2,
                  ),
                ],
        ),
        child: Row(
          children: [
            _LeadingIcon(icon: item.icon, selected: selected),
            const SizedBox(width: AppDimens.md - AppDimens.xs), // 12
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  Text(
                    item.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.body.copyWith(
                      fontSize: 14,
                      fontWeight: FontWeight.w700,
                      letterSpacing: -0.1,
                      color: selected ? AppColors.primaryDark : swms.text1,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    item.subtitle,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.caption.copyWith(
                      fontSize: 11,
                      fontWeight: FontWeight.w400,
                      color: swms.text3,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(width: AppDimens.sm),
            _RadioDot(selected: selected),
          ],
        ),
      ),
    );
  }
}

/// Icon vuông 36px — gradient xanh lá khi chọn, nền card2 khi không.
class _LeadingIcon extends StatelessWidget {
  const _LeadingIcon({required this.icon, required this.selected});

  final IconData icon;
  final bool selected;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      width: 36,
      height: 36,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        gradient: selected
            ? const LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [Color(0xFF43A047), AppColors.success],
              )
            : null,
        color: selected ? null : swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput), // 10
        boxShadow: selected
            ? [
                BoxShadow(
                  color: swms.success.withValues(alpha: 0.3),
                  offset: const Offset(0, 2),
                  blurRadius: 6,
                ),
              ]
            : null,
      ),
      child: Icon(icon, size: 18, color: selected ? Colors.white : swms.text2),
    );
  }
}

/// Chấm chọn 20px — vành dày primary khi chọn, vành mảnh border2 khi không.
class _RadioDot extends StatelessWidget {
  const _RadioDot({required this.selected});

  final bool selected;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 150),
      width: 20,
      height: 20,
      decoration: BoxDecoration(
        color: Colors.white,
        shape: BoxShape.circle,
        border: Border.all(
          color: selected ? AppColors.primary : swms.border2,
          width: selected ? 6 : 2,
        ),
      ),
    );
  }
}
