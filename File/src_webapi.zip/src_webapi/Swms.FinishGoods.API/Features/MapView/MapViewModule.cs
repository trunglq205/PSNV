using Swms.FinishGoods.API.Features.MapView.Business;
using Swms.FinishGoods.API.Features.MapView.DataAccess;

namespace Swms.FinishGoods.API.Features.MapView;

public static class MapViewModule
{
    public static IServiceCollection AddMapViewFeature(this IServiceCollection services)
    {
        services.AddScoped<IMapViewService, MapViewService>();
        services.AddScoped<IMapViewRepository, MapViewRepository>();
        return services;
    }
}
