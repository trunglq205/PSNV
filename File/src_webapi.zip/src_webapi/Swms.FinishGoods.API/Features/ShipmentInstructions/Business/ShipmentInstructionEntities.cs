namespace Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

// Entity đọc/ghi bằng Dapper — tên property khớp alias trong SQL của repository.
// Cột DB xem si_schema.sql.

public class SiHeader
{
    public long Id { get; set; }
    public string DocNo { get; set; } = "";
    public string SiNo { get; set; } = "";
    public string? Revision { get; set; }
    public string? Category { get; set; }
    public string? ShipMode { get; set; }

    public DateTime EtdDate { get; set; }
    public DateTime? EtaDate { get; set; }
    public DateTime? VanningDate { get; set; }
    public DateTime? CutOffAt { get; set; }

    public string? PortOfLoading { get; set; }
    public string? PortOfDischarge { get; set; }
    public string? CountryCode { get; set; }
    public string? ForwarderCode { get; set; }
    public string? CarrierCode { get; set; }
    public string? ConsigneeCode { get; set; }

    public string? PackingType { get; set; }
    public bool? IsWhiteFilm { get; set; }
    public bool? IsCaseMark { get; set; }
    public bool? IsSerialRequired { get; set; }

    public string? PicName { get; set; }
    public long? ToAreaId { get; set; }
    public string DocStatus { get; set; } = "released";
    public string? Description { get; set; }

    /// <summary>JSON thô của cột header_note.</summary>
    public string? HeaderNote { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>1 dòng màn danh sách: header + số tổng hợp từ line / kế hoạch.</summary>
public class SiListRow : SiHeader
{
    public int LineCount { get; set; }
    public int PackingListCount { get; set; }
    public int ModelCount { get; set; }
    public string? ModelsPreview { get; set; }   // tối đa 2 model, cách nhau ", "
    public string? PoNos { get; set; }           // tối đa 3 PO
    public int QtyRequired { get; set; }
    public int QtyFulfilled { get; set; }
    public int QtyCut { get; set; }
    public int QtyShort { get; set; }
    public int TotalPlt { get; set; }
    public int TotalCtn { get; set; }
    public int QtyPending { get; set; }
    public int QtyPicked { get; set; }
    public int UnmatchedBoxCount { get; set; }
}

public class SiLine
{
    public long Id { get; set; }
    public long SiId { get; set; }
    public int LineNo { get; set; }
    public string Model { get; set; } = "";
    public string? CustomerMaterial { get; set; }
    public string? PoNo { get; set; }
    public string? PackingListNo { get; set; }
    public string? PackingItemNo { get; set; }
    public string? InvoiceNo { get; set; }
    public string? SoNo { get; set; }
    public string? SoItemNo { get; set; }
    public int QtyRequired { get; set; }
    public string? Uom { get; set; }
    public int? PackagePlt { get; set; }
    public int? PackageCtn { get; set; }
    public int? QtyCut { get; set; }
    public string? CutBy { get; set; }
    public DateTime? CutAt { get; set; }

    // Tính khi đọc — xem LineAggSql trong repository
    public int QtyPending { get; set; }
    public int QtyPicked { get; set; }

    public int QtyShort => Math.Max(0, QtyRequired - (QtyCut ?? 0) - QtyPending - QtyPicked);
}

/// <summary>1 dòng wms.shipment_instruction_pallets.</summary>
public class SiTask
{
    public long Id { get; set; }
    public long LineId { get; set; }
    public long PalletId { get; set; }
    public string PalletCode { get; set; } = "";
    public string PickMode { get; set; } = "fifo";
    public string UnitType { get; set; } = "box";
    public int BoxPlanned { get; set; }
    public int BoxPicked { get; set; }
    public int QtyPlanned { get; set; }
    public string? LocatorCode { get; set; }
    public string? AreaCode { get; set; }
    public long? ToLocatorId { get; set; }
    public string? ToLocatorCode { get; set; }
    public string? AssignedTo { get; set; }
    public bool IsFifo { get; set; }
    public string ShipmentStatus { get; set; } = "pending";
    public DateTime? PickedAt { get; set; }
    public string? PickedBy { get; set; }
    public string? SkipReason { get; set; }
    public DateTime? ProductionDate { get; set; }

    // Vanning — suy từ vị trí hiện tại của pallet chứa hàng đã lấy (không lưu cột riêng).
    // Lịch sử ai / lúc nào nằm ở wms.stock_events. null = chưa ở khu vanning.
    public long? StagedPalletId { get; set; }
    public string? StagedPalletCode { get; set; }
    public string? StagedLocatorCode { get; set; }
}

/// <summary>Vị trí quét ở bước vanning — kèm loại khu để service kiểm tra.</summary>
public class LocatorRow
{
    public long Id { get; set; }
    public string LocatorCode { get; set; } = "";
    public string? MapType { get; set; }
}

/// <summary>1 dòng wms.shipment_instruction_boxes.</summary>
public class SiBox
{
    public long Id { get; set; }
    public long LineId { get; set; }
    public long? SiPalletId { get; set; }
    public string BoxNo { get; set; } = "";
    public long? BoxId { get; set; }
    public string? PalletCode { get; set; }
    public string AssignSource { get; set; } = "designated";
    public string MatchStatus { get; set; } = "pending";
    public string? TakenBySi { get; set; }
    public DateTime? MatchedAt { get; set; }
    public DateTime? PickedAt { get; set; }
    public string? PickedBy { get; set; }
}

public class SiDetail
{
    public SiHeader Header { get; set; } = new();
    public List<SiLine> Lines { get; set; } = new();
    public List<SiTask> Tasks { get; set; } = new();
    public List<SiBox> Boxes { get; set; } = new();
}

// ── Lấy hàng (PDA) ──────────────────────────────────────────
/// <summary>1 thùng của pallet trong dòng kế hoạch (cùng model với dòng SI).
/// Trạng thái eligible / locked do service tính — xem ShipmentInstructionService.BuildPickBoxes.</summary>
public class PickBoxRow
{
    public long BoxId { get; set; }
    public string BoxNo { get; set; } = "";
    public DateTime? ProductionDate { get; set; }
    public int Qty { get; set; }
    /// <summary>Đã có dòng _boxes gắn vào dòng kế hoạch này.</summary>
    public bool IsMine { get; set; }
    public bool IsPicked { get; set; }
    /// <summary>Đang bị dòng kế hoạch / thùng chỉ định KHÁC giữ.</summary>
    public bool HeldByOther { get; set; }
}

public enum PickScanResult { Ok, AlreadyPicked, Taken }

// ── Nội bộ phân bổ ──────────────────────────────────────────
public class AllocCandidate
{
    public long BoxId { get; set; }
    public long PalletId { get; set; }
    public DateTime? ProdDate { get; set; }
    public int Qty { get; set; }
}

public class DesignatedCandidate
{
    public long SbId { get; set; }
    public long PalletId { get; set; }
    public int Qty { get; set; }
}