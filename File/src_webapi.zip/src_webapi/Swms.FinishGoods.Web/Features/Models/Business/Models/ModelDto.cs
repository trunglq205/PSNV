namespace Swms.FinishGoods.Web.Features.Models.Business.Models;

/// <summary>
/// Dữ liệu model trả về từ API (dùng cho cả danh sách và chi tiết).
/// Khớp shape với ModelResponse phía API core.
/// </summary>
public class ModelDto
{
    public int Id { get; set; }
    public string? GTIN { get; set; }                // API tra null khi chua co
    public string Code { get; set; } = string.Empty;
    public string? Origin { get; set; }              // ma xuat xu 2 chu cai; API tra null khi chua khai bao
    public int CategoryCode { get; set; }
    public string CategoryName { get; set; } = string.Empty;
    public int Length { get; set; }                  // mm
    public int Width { get; set; }                   // mm
    public int Height { get; set; }                  // mm
    public int StandardPacking { get; set; }         // set / box

    // Quy cách xếp pallet (null = chưa cấu hình). Các giá trị tính (BoxPerLayer,
    // SetPerPallet, Cargo*) API cũng trả về nhưng Web tự tính lại ở AppModel nên không map.
    public int? LayerLimit { get; set; }
    public int? LayerCount { get; set; }
    public int? StackingLength { get; set; }
    public int? StackingWidth { get; set; }

    /// <summary>FK khu vực gợi ý. Null = chưa cấu hình.</summary>
    public int? SuggestAreaId { get; set; }
    public string? SuggestAreaCode { get; set; }
    public string? SuggestAreaName { get; set; }

    /// <summary>Tầng rack gợi ý, vd [2, 3]. API trả mảng số (không phải chuỗi).</summary>
    public List<int>? SuggestRackRow { get; set; }

    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }

    public static AppModel ToViewModel(ModelDto d) => new()
    {
        Id = d.Id,
        Code = d.Code,
        GTIN = d.GTIN ?? "",
        Origin = d.Origin ?? "",
        CategoryCode = d.CategoryCode,
        CategoryName = d.CategoryName,
        Length = d.Length,
        Width = d.Width,
        Height = d.Height,
        StandardPacking = d.StandardPacking,
        LayerLimit = d.LayerLimit,
        LayerCount = d.LayerCount,
        StackingLength = d.StackingLength,
        StackingWidth = d.StackingWidth,
        SuggestAreaId = d.SuggestAreaId,
        SuggestAreaCode = d.SuggestAreaCode ?? "",
        SuggestAreaName = d.SuggestAreaName ?? "",
        SuggestRackRow = d.SuggestRackRow is null ? new() : new List<int>(d.SuggestRackRow),
        IsActive = d.IsActive,
        CreatedAt = d.CreatedAt.ToLocalTime().ToString("HH:mm dd/MM/yyyy"),
    };
}