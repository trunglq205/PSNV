﻿namespace SWMS_WebTool.Models
{
    public class MasterSloc
    {
        public Int64 Id { get; set; }
        public string? Plant { get; set; }
        public string? Category { get; set; }
        public string? Sloc { get; set; }
        public string? Type { get; set; }
        public string? Address { get; set; }
        public string? Description { get; set; }
    }
}
