﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace SWMS_WebTool.Models.Layout
{
    public enum KonvaClassType
    {
        Stage,
        Layer,
        Rect,
        Circle,
        Line,
        Path,
        Image,       
        Text,
        Group,
    }

    public class KonvaObject
    {
        public KonvaAttr Attrs { get; set; }
        public String ClassName { get; set; }
        public List<KonvaObject>? Children { get; set; }
    }

    public class KonvaAttr
    {
        public int? Id { get; set; }
        public string? Title { get; set; }
        public double? X { get; set; } = 0;
        public double? Y { get; set; } = 0;
        public double? ScaleX { get; set; } = 1;
        public double? ScaleY { get; set; } = 1;
        public double? Width { get; set; }
        public double? Height { get; set; }
        public double? Radius { get; set; }
        public double? Rotation { get; set; }
        public string? Fill { get; set; } = "rgb(0, 0, 0, 0)";
        public string? Text { get; set; }
        public double? FontSize { get; set; }
        public string? FontStyle { get; set; }
        public string? Align { get; set; }
        public string? VertialAlign { get; set; }
        public double? StrokeWidth { get; set; } = 0;
        public string? Stroke { get; set; } = "rgb(0, 0, 0, 0)";
        public string? Name { get; set; }
        public string? Data { get; set; }
        public string? CustomData { get; set; }
        public bool? Visible { get; set; }
        public bool? Draggable { get; set; }
        public bool? Locked { get; set; }
        public bool? Listening { get; set; }
        public List<double>? Points { get; set; }
        public bool? StrokeScaleEnabled { get; set; }
        public string? BoundingBox { get; set; }
    }
}