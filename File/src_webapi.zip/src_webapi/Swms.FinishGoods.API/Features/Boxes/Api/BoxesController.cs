﻿using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Boxes.Business;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.StockEvents.Api;
using Swms.FinishGoods.API.Features.StockEvents.Business;

namespace Swms.FinishGoods.API.Features.Boxes.Api
{
    [ApiController]
    [Route("api/boxes")]
    public class BoxesController : ControllerBase
    {
        private readonly IBoxService _service;
        private readonly IStockEventService _history;

        public BoxesController(IBoxService service, IStockEventService history)
        {
            _service = service;
            _history = history;
        }

        /// <summary>Chi tiết box theo id — thông tin + serial + lot + vị trí + OQC.</summary>
        [HttpGet("{id:long}/detail")]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<BoxDetailResponse>> GetBoxDetail(long id)
        {
            var detail = await _service.GetBoxDetailAsync(id);
            return detail is null ? throw new NotFoundException("Box") : Ok(detail);
        }

        /// <summary>
        /// Chi tiết box theo box_no (Quick Scan). box_no không duy nhất —
        /// truyền palletId của pallet đang quét để định danh chính xác.
        /// </summary>
        [HttpGet("by-box-no/{boxNo}/detail")]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<BoxDetailResponse>> GetBoxDetailByBoxNo(
            string boxNo,
            [FromQuery] string? palletId = null)
        {
            var detail = await _service.GetBoxDetailByBoxNoAsync(boxNo, palletId);
            return detail is null ? throw new NotFoundException("Box") : Ok(detail);
        }

        /// <summary>Cập nhật PO của box (psnv_po, customer_po) theo id. null = xoá giá trị.</summary>
        [HttpPatch("{id:long}")]
        [RequirePermission<Perms.Receiving.Temploc.Edit>]
        public async Task<ActionResult<BoxDetailResponse>> PatchBox(
            long id,
            [FromBody] BoxPatchRequest req)
        {
            var detail = await _service.UpdatePoAsync(id, req);
            return detail is null ? throw new NotFoundException("Box") : Ok(detail);
        }

        // ── Lịch sử box ─────────────────────────────────────────────

        /// <summary>
        /// Lịch sử box: header + timeline.
        ///
        /// Timeline gồm HAI loại dòng, phân biệt bằng cờ <c>inherited</c>:
        ///   false — thao tác trên chính thùng này (tạo, đổi pallet, sửa PO, OQC)
        ///   true  — kế thừa từ pallet chứa nó trong khoảng thời gian tương ứng
        ///           (lưu kho, chuyển vị trí, vanning...)
        ///
        /// Box không tự đi lưu kho — nó nằm trên pallet và pallet đi. Vì vậy event
        /// vị trí KHÔNG được nhân bản cho từng thùng (pallet 40 box sẽ đẻ 40 dòng
        /// mỗi lần quét) mà suy ra lúc đọc.
        ///
        /// <param name="ownOnly">true = bỏ phần kế thừa, chỉ thao tác trên thùng.</param>
        /// </summary>
        [HttpGet("{id:long}/history")]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<BoxHistoryResponse>> GetHistory(
            long id, [FromQuery] bool ownOnly = false)
            => Ok(await _history.GetBoxHistoryAsync(id, ownOnly));

        /// <summary>
        /// Lịch sử box theo box_no. box_no chỉ duy nhất trong phạm vi MỘT pallet
        /// (RequireBoxes chỉ chống trùng trong 1 lot), nên palletId là cần thiết
        /// trên thực tế — thiếu nó, proc lấy bản ghi mới nhất.
        /// </summary>
        [HttpGet("by-box-no/{boxNo}/history")]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<BoxHistoryResponse>> GetHistoryByBoxNo(
            string boxNo,
            [FromQuery] string? palletId = null,
            [FromQuery] bool ownOnly = false)
            => Ok(await _history.GetBoxHistoryByBoxNoAsync(boxNo, palletId, ownOnly));
    }
}