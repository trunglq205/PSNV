// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stocky_cart_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

StockyCartModel _$StockyCartModelFromJson(Map<String, dynamic> json) =>
    StockyCartModel(
      code: json['code'] as String,
      name: json['name'] as String?,
      model: json['model'] as String?,
      qty: (json['qty'] as num?)?.toInt() ?? 0,
      lotCount: (json['lotCount'] as num?)?.toInt() ?? 0,
      hasGoods: json['hasGoods'] as bool? ?? false,
      status: json['status'] as String?,
      locatorCode: json['locatorCode'] as String?,
      areaCode: json['areaCode'] as String?,
      palletCode: json['palletCode'] as String?,
      siNo: json['siNo'] as String?,
      atFa: json['atFa'] as bool? ?? false,
      receivedAt: json['receivedAt'] == null
          ? null
          : DateTime.parse(json['receivedAt'] as String),
    );

Map<String, dynamic> _$StockyCartModelToJson(StockyCartModel instance) =>
    <String, dynamic>{
      'code': instance.code,
      'name': ?instance.name,
      'model': ?instance.model,
      'qty': instance.qty,
      'lotCount': instance.lotCount,
      'hasGoods': instance.hasGoods,
      'status': ?instance.status,
      'locatorCode': ?instance.locatorCode,
      'areaCode': ?instance.areaCode,
      'palletCode': ?instance.palletCode,
      'siNo': ?instance.siNo,
      'atFa': instance.atFa,
      'receivedAt': ?instance.receivedAt?.toIso8601String(),
    };

StockyBatchRequest _$StockyBatchRequestFromJson(Map<String, dynamic> json) =>
    StockyBatchRequest(
      codes: (json['codes'] as List<dynamic>).map((e) => e as String).toList(),
    );

Map<String, dynamic> _$StockyBatchRequestToJson(StockyBatchRequest instance) =>
    <String, dynamic>{'codes': instance.codes};

StockySubmitResultModel _$StockySubmitResultModelFromJson(
  Map<String, dynamic> json,
) => StockySubmitResultModel(
  cartCount: (json['cartCount'] as num).toInt(),
  qty: (json['qty'] as num).toInt(),
);

Map<String, dynamic> _$StockySubmitResultModelToJson(
  StockySubmitResultModel instance,
) => <String, dynamic>{'cartCount': instance.cartCount, 'qty': instance.qty};
