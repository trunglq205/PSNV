import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/pick_task_ui.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

/// Tuyến lấy hàng: mỗi dòng 1 vị trí, theo thứ tự server tính.
class KittingRouteList extends StatelessWidget {
  final List<PickTask> tasks;
  final ValueChanged<PickTask> onTap;

  const KittingRouteList({super.key, required this.tasks, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        children: [
          for (var i = 0; i < tasks.length; i++) ...[
            if (i > 0) Divider(height: 1, color: swms.border),
            _TaskRow(task: tasks[i], onTap: () => onTap(tasks[i])),
          ],
        ],
      ),
    );
  }
}

class _TaskRow extends StatelessWidget {
  final PickTask task;
  final VoidCallback onTap;

  const _TaskRow({required this.task, required this.onTap});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final mono = AppTextStyles.code.copyWith(letterSpacing: 0);

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppDimens.rCard),
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        child: Row(
          children: [
            _StatusDot(task: task),
            const SizedBox(width: 10),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Text(
                        task.locationLabel,
                        style: mono.copyWith(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: task.hasLocator ? swms.text1 : swms.text2,
                        ),
                      ),
                      const SizedBox(width: 6),
                      Flexible(
                        child: Text(
                          task.modeLabel(),
                          overflow: TextOverflow.ellipsis,
                          style: AppTextStyles.caption.copyWith(
                            fontSize: 11,
                            fontWeight: FontWeight.w600,
                            color: task.modeColor(context),
                          ),
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 2),
                  Text(
                    siJoin([task.model, task.poNo]),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: mono.copyWith(fontSize: 12, color: swms.text3),
                  ),
                ],
              ),
            ),
            const SizedBox(width: AppDimens.sm),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text.rich(
                  TextSpan(
                    children: [
                      TextSpan(text: '${task.qtyPicked}'),
                      TextSpan(
                        text: '/${task.qtyPlanned}',
                        style: TextStyle(
                          color: swms.text3,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  style: AppTextStyles.bodyStrong.copyWith(
                    fontWeight: FontWeight.w700,
                    color: swms.text1,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
                Text(
                  'pcs',
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ],
            ),
            const SizedBox(width: AppDimens.xs),
            Icon(Icons.chevron_right, size: 18, color: swms.text4),
          ],
        ),
      ),
    );
  }
}

/// Vòng trạng thái đầu dòng: xong (xanh, tick) · đang lấy dở (xanh nhạt,
/// đồng hồ) · chưa lấy (viền, ô trống).
///
/// Server chỉ có pending | picked — "đang lấy dở" suy từ task còn pending mà
/// đã quét được ít nhất 1 thùng.
class _StatusDot extends StatelessWidget {
  final PickTask task;

  const _StatusDot({required this.task});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final inProgress = !task.isComplete && (task.isDone || task.boxPicked > 0);

    final (bg, fg, icon, border) = task.isComplete
        ? (swms.success, Colors.white, Icons.check, null)
        : inProgress
        ? (swms.primaryTint, swms.primary, Icons.schedule, null)
        : (swms.card, swms.text3, Icons.crop_square, swms.border2);

    return Container(
      width: 30,
      height: 30,
      decoration: BoxDecoration(
        color: bg,
        shape: BoxShape.circle,
        border: border == null ? null : Border.all(color: border, width: 1.5),
      ),
      child: Icon(icon, size: 15, color: fg),
    );
  }
}
