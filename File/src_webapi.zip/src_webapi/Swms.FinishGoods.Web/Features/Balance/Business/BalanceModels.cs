namespace Swms.FinishGoods.Web.Features.Balance.Business.Models;

public class BalanceDocSummaryDto
{
    public long Id { get; set; }
    public string DocNo { get; set; } = "";
    public long CountId { get; set; }
    public string CountDocNo { get; set; } = "";
    public string? CountType { get; set; }
    public DateTime CountDate { get; set; }
    public string DocStatus { get; set; } = "pending";
    public string? FaRef { get; set; }
    public int TotalLines { get; set; }
    public int ResolvedLines { get; set; }
    public decimal NetDelta { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? IssuedAt { get; set; }
}

public class BalanceLineDto
{
    public long LineId { get; set; }
    public int LineNo { get; set; }
    public int ProductId { get; set; }
    public string? ProductName { get; set; }
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = "";
    public long? LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public decimal QtySystem { get; set; }
    public decimal QtyCount { get; set; }
    public decimal Delta { get; set; }
    public string? Resolution { get; set; }
    public string? Note { get; set; }
    /// <summary>Pallet phát sinh khi kiểm (tìm thấy ở ô này, hệ thống ghi ở SystemLocatorCode).</summary>
    public bool IsFound { get; set; }
    public string? SystemLocatorCode { get; set; }
}

public class BalanceDocDetailDto
{
    public BalanceDocSummaryDto Header { get; set; } = new();
    public List<BalanceLineDto> Lines { get; set; } = new();
}

public class SetResolutionRequestDto { public string Resolution { get; set; } = "count"; }
public class BulkResolutionRequestDto { public List<long> LineIds { get; set; } = new(); public string Resolution { get; set; } = "count"; }
public class IssueFaResultDto { public string FaRef { get; set; } = ""; public int AdjustedPallets { get; set; }
    public string MoveDocNo { get; set; } = ""; }
