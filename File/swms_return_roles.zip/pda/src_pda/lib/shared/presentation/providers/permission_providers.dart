import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/shared/presentation/providers/providers.dart';

part 'permission_providers.g.dart';

/// Mã quyền của user đang đăng nhập, lấy từ `GET /api/auth/me`.
///
/// Vì sao KHÔNG đọc `homeProvider`: màn Home có sẵn danh sách này trong state
/// của nó, nhưng state đó chỉ có khi đã đi qua màn Home. Vào màn bằng
/// deep-link hoặc khi hệ điều hành dựng lại app thì state rỗng và MỌI nút sẽ
/// bị ẩn oan — mà nút bị ẩn thì người dùng không có cách nào biết là do chưa
/// nạp quyền hay do không có quyền. Provider riêng thì màn nào cần tự nạp.
///
/// `keepAlive`: quyền không đổi trong một lần đăng nhập, mà màn nào cũng hỏi.
/// Đổi role thì phải đăng nhập lại — phía API còn cache 5 phút
/// (`perms:user:{userId}`) nên invalidate ngay cũng chưa chắc ra số mới.
@Riverpod(keepAlive: true)
Future<List<String>> myPermissions(Ref ref) =>
    ref.watch(rolesRepositoryProvider).getPermissions();

/// Kiểm quyền ngay trên `AsyncValue` để không phải khớp mẫu ở từng màn.
extension MyPermissionsX on AsyncValue<List<String>> {
  /// `true` khi đã nạp xong quyền VÀ có [key].
  ///
  /// Đang nạp hoặc lỗi → `false`: nút chưa hiện cho tới khi biết chắc. Thà
  /// thiếu nút một nhịp còn hơn cho bấm rồi ăn 403 giữa lúc đang quét hàng.
  ///
  /// Dùng khớp mẫu `AsyncData` chứ KHÔNG dùng `valueOrNull` — riverpod 3.3.2
  /// đã bỏ getter đó.
  bool can(String key) => switch (this) {
        AsyncData(:final value) => value.contains(key),
        _ => false,
      };
}
