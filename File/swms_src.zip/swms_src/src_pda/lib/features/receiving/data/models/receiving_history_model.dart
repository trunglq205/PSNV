import 'dart:convert';

import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_history_entry.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// Chuyển [ReceivingHistoryEntry] <-> JSON string cho SharedPreferences.
abstract final class ReceivingHistoryCodec {
  const ReceivingHistoryCodec._();

  static String encode(ReceivingHistoryEntry e) {
    return jsonEncode({
      'savedAt': e.savedAt.toIso8601String(),
      'mode': e.mode.name,
      'modelName': e.modelName,
      'cardPayloads': e.cardPayloads,
      'modelInfo': e.modelInfo == null ? null : _modelToJson(e.modelInfo!),
      'boxCount': e.boxCount,
      'stdPackOverride': e.stdPackOverride,
      'serials': e.serials,
    });
  }

  /// Trả null nếu JSON hỏng — dữ liệu cũ lỗi thì coi như không có lịch sử,
  /// không nên làm crash màn scan.
  static ReceivingHistoryEntry? decode(String raw) {
    try {
      final map = jsonDecode(raw) as Map<String, dynamic>;
      return ReceivingHistoryEntry(
        savedAt: DateTime.parse(map['savedAt'] as String),
        mode: ReceivingMode.values.byName(map['mode'] as String),
        modelName: map['modelName'] as String?,
        cardPayloads: (map['cardPayloads'] as List? ?? const []).cast<String>(),
        modelInfo: map['modelInfo'] == null
            ? null
            : _modelFromJson(map['modelInfo'] as Map<String, dynamic>),
        boxCount: map['boxCount'] as int? ?? 0,
        stdPackOverride: map['stdPackOverride'] as int?,
        serials: (map['serials'] as List? ?? const []).cast<String>(),
      );
    } catch (_) {
      return null;
    }
  }

  /// Lưu CẢ mã lẫn tên: codec chạy đồng bộ, không tra được danh mục từ API.
  static Map<String, dynamic> _modelToJson(ModelInfo m) => {
    'gtin': m.gtin,
    'model': m.model,
    'categoryCode': m.category?.value,
    'category': m.category?.key,
    'length': m.length,
    'width': m.width,
    'height': m.height,
    'standardPacking': m.standardPacking,
  };

  static ModelInfo _modelFromJson(Map<String, dynamic> j) => ModelInfo(
    gtin: j['gtin'] as String?,
    model: j['model'] as String,
    category: _categoryFromJson(j),
    length: j['length'] as int,
    width: j['width'] as int,
    height: j['height'] as int,
    standardPacking: j['standardPacking'] as int,
  );

  /// - Có `categoryCode` → dựng lại đủ mã + tên.
  /// - Bản nháp định dạng CŨ (chỉ có tên, không có mã) → ném lỗi để [decode]
  ///   trả null: không tự đoán mã từ tên.
  /// - Không có cate → null.
  static Category? _categoryFromJson(Map<String, dynamic> j) {
    final code = j['categoryCode'] as int?;
    final name = j['category'] as String?;

    if (code != null) {
      return Category(
        value: code,
        key: (name == null || name.trim().isEmpty) ? '$code' : name,
      );
    }
    if (name != null) {
      throw const FormatException('Legacy draft: category has no code');
    }
    return null;
  }
}