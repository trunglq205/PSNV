/* =========================================================
   MÀN "VÉN MÀN" GIÁNG SINH SAU ĐĂNG NHẬP
   Drop-in: wwwroot/js/christmas-gate.js (nạp bởi Views/Shared/_XmasGate.cshtml)

   Cách chơi: người tuyết đi qua lại trên màn ảnh. Click / chạm vào đâu thì
   quả cầu tuyết được ném tới đó theo đường vòng cung. Ném trúng đủ
   HITS_REQUIRED người tuyết → 2 cánh màn mở ra, vào trang Home.
   Bàn phím: Space / Enter = ném tự ngắm vào người tuyết gần nhất.
   ========================================================= */
(function () {
    "use strict";

    /* ---------- CẤU HÌNH ---------- */
    var HITS_REQUIRED = 3;       // số người tuyết cần ném trúng
    var SNOWMEN_ON_FIELD = 3;    // số người tuyết cùng lúc trên màn
    var SKIP_AFTER_MS = 0;       // >0: hiện nút "Bỏ qua" sau n ms (0 = bắt buộc phải chơi)
    var THROW_COOLDOWN_MS = 220; // chống spam click
    var SPEED_MULT = 1.8;        // hệ số tốc độ đi ngang (0.5 = bản "dễ")
    var LEVEL_UP = 0.22;         // mỗi lần trúng, người tuyết nhanh thêm bao nhiêu (0.08 = bản "dễ")
    var DASH = true;             // true: người tuyết thỉnh thoảng lao vụt đi
    var AIM_ASSIST = 0;          // "nam châm": >0 thì click trong bán kính n × cỡ người tuyết là cầu tự bay theo và trúng (1.8 = bản "dễ"; 0 = tắt)
    var Y_MIN = 0.46, Y_MAX = 0.95; // vùng người tuyết được đi lại theo chiều dọc (tỉ lệ chiều cao màn)
    var VSPEED = 0.0045;         // tốc độ đi lên/xuống tối đa (tỉ lệ chiều cao / frame)
    var HOP = 0.16;              // độ nảy khi nhún nhảy (tỉ lệ kích thước người tuyết)
    var SNOWMAN_SIZE = 1.4;      // kích thước người tuyết (1 = bản cũ)
    var SNOWBALL_SIZE = 1.8;     // kích thước quả cầu tuyết (1 = bản cũ)
    var SLEIGH_FIRST_MS = 1200;  // ông già Noel bay qua lần đầu sau n ms
    var SLEIGH_EVERY_MS = [6000, 10000]; // khoảng nghỉ giữa các lượt bay (ngẫu nhiên trong khoảng)
    var SLEIGH_CROSS_MS = 7500;  // thời gian bay hết chiều ngang màn
    var SLEIGH_SIZE = 1;         // phóng to/thu nhỏ đoàn xe (1 = mặc định)

    var gate = document.getElementById("xmasGate");
    if (!gate) return;

    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var root = document.documentElement;
    root.classList.add("xg-lock");

    var hud = gate.querySelector(".xg-hud");
    var dots = [];
    var progress = gate.querySelector(".xg-progress");
    for (var d = 0; d < HITS_REQUIRED; d++) {
        var sp = document.createElement("span");
        sp.textContent = "❄";
        progress.appendChild(sp);
        dots.push(sp);
    }
    /* ---------- DÒNG MẸO PHÍM SPACE (luôn hiện rõ) ---------- */
    (function buildTip() {
        if (!document.getElementById("xg-tip-style")) {
            var st = document.createElement("style");
            st.id = "xg-tip-style";
            st.textContent =
                ".xg-tip{display:block!important;margin:14px auto 0;padding:10px 16px;border-radius:12px;" +
                "background:linear-gradient(180deg,#ffd978,#e8b64c);color:#3a2600;border:2px solid #fff;" +
                "font:800 16.5px/1.4 'Be Vietnam Pro','Segoe UI',sans-serif;letter-spacing:.1px;" +
                "box-shadow:0 0 0 4px rgba(232,182,76,.35),0 8px 22px rgba(0,0,0,.35);" +
                "animation:xgTipPulse 1.4s ease-in-out infinite;transform-origin:center}" +
                ".xg-tip kbd{display:inline-block;padding:2px 12px;margin:0 3px;border-radius:7px;background:#1b2447;" +
                "color:#fff;font:800 15px 'Be Vietnam Pro','Segoe UI',sans-serif;box-shadow:0 3px 0 #000;vertical-align:1px}" +
                ".xg-hud{width:min(660px,calc(100% - 24px))!important}" +
                ".xg-hud.done .xg-tip{display:none!important}" +
                "@keyframes xgTipPulse{0%,100%{transform:scale(1);box-shadow:0 0 0 4px rgba(232,182,76,.35),0 8px 22px rgba(0,0,0,.35)}" +
                "50%{transform:scale(1.07);box-shadow:0 0 0 8px rgba(255,217,120,.55),0 0 26px rgba(255,217,120,.9)}}" +
                "@media (prefers-reduced-motion:reduce){.xg-tip{animation:none}}";
            document.head.appendChild(st);
        }
        if (!gate.querySelector(".xg-tip")) {
            var tip = document.createElement("div");
            tip.className = "xg-tip";
            tip.innerHTML = "💡 Mẹo: nhấn liên tục hoặc giữ phím <kbd>Space</kbd> để qua nhanh";
            progress.parentNode.appendChild(tip);
        }
    })();

    var countEl = gate.querySelector("[data-xg-count]");
    if (countEl) countEl.textContent = String(HITS_REQUIRED);

    var cv = document.createElement("canvas");
    cv.className = "xg-canvas";
    cv.setAttribute("aria-hidden", "true");
    gate.insertBefore(cv, hud);
    var ctx = cv.getContext("2d");

    var W = 0, H = 0, DPR = Math.min(window.devicePixelRatio || 1, 2);

    var snowmen = [], balls = [], parts = [], texts = [], flakes = [];
    var sleigh = null, sleighAt = performance.now() + SLEIGH_FIRST_MS, dust = [];
    var hits = 0, finished = false, lastThrow = 0, aim = null, reloadAt = 0;

    function resize() {
        var oldW = W || 1;
        W = gate.clientWidth; H = gate.clientHeight;
        cv.width = W * DPR; cv.height = H * DPR;
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        snowmen.forEach(function (s) { s.x = s.x * W / oldW; });
        var target = Math.round(Math.min(110, (W * H) / 16000));
        while (flakes.length < target) flakes.push(makeFlake(true));
        flakes.length = target;
    }

    function baseUnit() { return Math.max(52, Math.min(140, H * 0.13)); }
    function unit() { return baseUnit() * SNOWMAN_SIZE; }
    function ballR0() { return Math.max(18, baseUnit() * 0.2 * SNOWBALL_SIZE); }  // cỡ lúc vừa ném (gần)
    function ballR1() { return Math.max(9, baseUnit() * 0.1 * SNOWBALL_SIZE); }   // cỡ lúc chạm đích (xa)
    // phối cảnh: càng lên cao (xa) càng nhỏ, càng xuống thấp (gần) càng to
    function depthOf(s) { return (s.gy - Y_MIN) / (Y_MAX - Y_MIN); }
    function sizeOf(s) { return unit() * (0.68 + depthOf(s) * 0.45); }
    function groundOf(s) { return H * s.gy; }

    /* ---------- NGƯỜI TUYẾT ---------- */
    function spawnSnowman() {
        var dir = Math.random() < 0.5 ? 1 : -1;
        var level = 1 + hits * LEVEL_UP;                          // mỗi lần trúng, người tuyết nhanh hơn
        var speed = (2.0 + Math.random() * 1.6) * SPEED_MULT * level * (REDUCED ? 0.5 : 1);
        // chia vùng dọc thành các dải để người tuyết không dồn một chỗ
        var band = snowmen.filter(function (s) { return s.alive; }).length % 3;
        var gy = Y_MIN + (Y_MAX - Y_MIN) * ((band + Math.random()) / 3);
        snowmen.push({
            x: dir > 0 ? -60 : W + 60,
            gy: gy,
            dir: dir,
            speed: speed,
            vy: randVy() * level,
            phase: Math.random() * 6.28,
            alive: true,
            nextTurn: 900 + Math.random() * 2200,
            nextVy: 600 + Math.random() * 1400,
            dash: 0,
            hat: Math.random() < 0.7 ? "santa" : "top"
        });
    }

    function randVy() { return (Math.random() < 0.5 ? -1 : 1) * VSPEED * (0.35 + Math.random() * 0.65) * (REDUCED ? 0.5 : 1); }

    function hitCircles(s) {
        var u = sizeOf(s), g = groundOf(s) + hop(s);
        var rb = u * 0.30, rm = u * 0.22, rh = u * 0.165;
        var yb = g - rb, ym = yb - rb * 0.85 - rm * 0.85, yh = ym - rm * 0.85 - rh * 0.9;
        return [{ x: s.x, y: yb, r: rb }, { x: s.x, y: ym, r: rm }, { x: s.x, y: yh, r: rh * 1.35 }];
    }

    function hop(s) { return -Math.abs(Math.sin(s.phase)) * sizeOf(s) * HOP; }

    function drawSnowman(s) {
        var u = sizeOf(s), g = groundOf(s), h = hop(s);
        var tilt = Math.sin(s.phase) * 0.06 * s.dir;
        var rb = u * 0.30, rm = u * 0.22, rh = u * 0.165;

        // bóng dưới chân
        ctx.save();
        ctx.globalAlpha = 0.28 + h / u;
        ctx.fillStyle = "#1b2447";
        ctx.beginPath();
        ctx.ellipse(s.x, g + 2, rb * 1.05, rb * 0.22, 0, 0, 6.2832);
        ctx.fill();
        ctx.restore();

        ctx.save();
        ctx.translate(s.x, g + h);
        ctx.rotate(tilt);

        var yb = -rb, ym = yb - rb * 0.85 - rm * 0.85, yh = ym - rm * 0.85 - rh * 0.9;

        // tay que gỗ
        var wave = Math.sin(s.phase * 2) * 0.35;
        ctx.strokeStyle = "#6b4226";
        ctx.lineWidth = Math.max(2, u * 0.028);
        ctx.lineCap = "round";
        [-1, 1].forEach(function (side) {
            var a = side * (0.5 + (side === s.dir ? wave : -wave * 0.4));
            var x0 = side * rm * 0.85, y0 = ym - rm * 0.1;
            var x1 = x0 + side * u * 0.28 * Math.cos(a * 0.6), y1 = y0 - u * 0.2 * Math.sin(Math.abs(a) + 0.4);
            ctx.beginPath(); ctx.moveTo(x0, y0); ctx.lineTo(x1, y1); ctx.stroke();
            ctx.beginPath(); ctx.moveTo(x1 - side * u * 0.05, y1 + u * 0.01); ctx.lineTo(x1 + side * u * 0.02, y1 - u * 0.07); ctx.stroke();
        });

        ball(0, yb, rb);
        ball(0, ym, rm);

        // cúc áo
        ctx.fillStyle = "#2a2f45";
        for (var i = 0; i < 3; i++) {
            ctx.beginPath(); ctx.arc(s.dir * rm * 0.08, ym - rm * 0.45 + i * rm * 0.42, u * 0.022, 0, 6.2832); ctx.fill();
        }

        ball(0, yh, rh);

        // khăn quàng đỏ
        ctx.fillStyle = "#c0282f";
        ctx.beginPath();
        ctx.ellipse(0, yh + rh * 0.85, rh * 1.05, rh * 0.28, 0, 0, 6.2832);
        ctx.fill();
        ctx.save();
        ctx.translate(-s.dir * rh * 0.55, yh + rh * 0.95);
        ctx.rotate(-s.dir * (0.2 + Math.sin(s.phase * 2) * 0.15));
        ctx.fillRect(-rh * 0.18, 0, rh * 0.36, rh * 1.1);
        ctx.fillStyle = "#fff";
        ctx.fillRect(-rh * 0.18, rh * 0.8, rh * 0.36, rh * 0.12);
        ctx.restore();

        // mắt, miệng
        ctx.fillStyle = "#1e2233";
        var ex = s.dir * rh * 0.18;
        ctx.beginPath(); ctx.arc(ex - rh * 0.32, yh - rh * 0.18, rh * 0.1, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(ex + rh * 0.28, yh - rh * 0.18, rh * 0.1, 0, 6.2832); ctx.fill();
        for (var m = -2; m <= 2; m++) {
            ctx.beginPath();
            ctx.arc(ex + m * rh * 0.16, yh + rh * 0.38 + Math.abs(m) * -rh * 0.06, rh * 0.05, 0, 6.2832);
            ctx.fill();
        }
        // má hồng
        ctx.fillStyle = "rgba(240,110,120,.45)";
        ctx.beginPath(); ctx.arc(ex - rh * 0.55, yh + rh * 0.12, rh * 0.14, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(ex + rh * 0.5, yh + rh * 0.12, rh * 0.14, 0, 6.2832); ctx.fill();

        // mũi cà rốt quay theo hướng đi
        ctx.fillStyle = "#f07b1d";
        ctx.beginPath();
        ctx.moveTo(ex, yh - rh * 0.02);
        ctx.lineTo(ex + s.dir * rh * 0.85, yh + rh * 0.1);
        ctx.lineTo(ex, yh + rh * 0.2);
        ctx.closePath();
        ctx.fill();

        // mũ
        if (s.hat === "santa") {
            ctx.fillStyle = "#c0282f";
            ctx.beginPath();
            ctx.moveTo(-rh * 0.95, yh - rh * 0.55);
            ctx.quadraticCurveTo(-s.dir * rh * 0.2, yh - rh * 2.2, -s.dir * rh * 1.35, yh - rh * 1.35);
            ctx.lineTo(rh * 0.95, yh - rh * 0.55);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = "#fff";
            roundRect(-rh * 1.05, yh - rh * 0.72, rh * 2.1, rh * 0.34, rh * 0.17);
            ctx.beginPath(); ctx.arc(-s.dir * rh * 1.38, yh - rh * 1.32, rh * 0.22, 0, 6.2832); ctx.fill();
        } else {
            ctx.fillStyle = "#23283d";
            ctx.fillRect(-rh * 0.95, yh - rh * 0.78, rh * 1.9, rh * 0.18);
            ctx.fillRect(-rh * 0.6, yh - rh * 1.7, rh * 1.2, rh * 0.95);
            ctx.fillStyle = "#1f6b45";
            ctx.fillRect(-rh * 0.6, yh - rh * 0.98, rh * 1.2, rh * 0.18);
        }

        ctx.restore();
    }

    function ball(x, y, r) {
        var gr = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
        gr.addColorStop(0, "#ffffff");
        gr.addColorStop(0.7, "#f1f5fb");
        gr.addColorStop(1, "#c9d6ea");
        ctx.fillStyle = gr;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, 6.2832);
        ctx.fill();
        ctx.lineWidth = Math.max(1, r * 0.06);
        ctx.strokeStyle = "rgba(27,36,71,.35)"; // viền mảnh để nổi trên nền tuyết
        ctx.stroke();
    }

    function roundRect(x, y, w, h, r) {
        ctx.beginPath();
        ctx.moveTo(x + r, y);
        ctx.arcTo(x + w, y, x + w, y + h, r);
        ctx.arcTo(x + w, y + h, x, y + h, r);
        ctx.arcTo(x, y + h, x, y, r);
        ctx.arcTo(x, y, x + w, y, r);
        ctx.closePath();
        ctx.fill();
    }

    /* ---------- QUẢ CẦU TUYẾT ---------- */
    function origin() { return { x: W / 2, y: H - ballR0() - 8 }; }

    function throwAt(tx, ty) {
        if (finished) return;
        var now = performance.now();
        if (now - lastThrow < THROW_COOLDOWN_MS) return;
        lastThrow = now;
        reloadAt = now + THROW_COOLDOWN_MS;
        var o = origin();
        var dist = Math.hypot(tx - o.x, ty - o.y);
        balls.push({
            x0: o.x, y0: o.y, x1: tx, y1: ty,
            homing: pickAssist(tx, ty),
            t0: now,
            dur: 330 + dist * 0.32,
            arc: Math.min(220, dist * 0.28),
            r0: ballR0(),
            r1: ballR1()
        });
    }

    // tìm người tuyết gần điểm click nhất (trong bán kính hút) để cầu tự bay theo
    function pickAssist(tx, ty) {
        if (!(AIM_ASSIST > 0)) return null;
        var best = null, bestD = 1e9;
        snowmen.forEach(function (s) {
            if (!s.alive) return;
            var c = hitCircles(s)[1];
            var dd = Math.hypot(tx - c.x, ty - c.y);
            if (dd < sizeOf(s) * AIM_ASSIST && dd < bestD) { bestD = dd; best = s; }
        });
        return best;
    }

    function flightTime(tx, ty) {
        var o = origin();
        return 330 + Math.hypot(tx - o.x, ty - o.y) * 0.32;
    }

    // Space / Enter: tự ngắm (có tính trước đường đi của người tuyết)
    function autoThrow() {
        var best = null, bestD = 1e9, o = origin();
        snowmen.forEach(function (s) {
            if (!s.alive || s.x < 0 || s.x > W) return;
            var c = hitCircles(s)[1];
            var dd = Math.hypot(c.x - o.x, c.y - o.y);
            if (dd < bestD) { bestD = dd; best = s; }
        });
        if (!best) return;
        var c = hitCircles(best)[1];
        var t = flightTime(c.x, c.y);
        var frames = t / 16.67;
        var boost = best.dash > 0 ? 1.9 : 1;
        throwAt(c.x + best.dir * best.speed * boost * frames, c.y + best.vy * H * frames);
    }

    function landBall(b) {
        if (b.homing && b.homing.alive) { knockDown(b.homing, b.x1, b.y1); return; }
        var target = null;
        snowmen.forEach(function (s) {
            if (!s.alive || target) return;
            hitCircles(s).forEach(function (c) {
                if (Math.hypot(b.x1 - c.x, b.y1 - c.y) <= c.r * 1.12 + b.r1) target = s;
            });
        });
        if (target) knockDown(target, b.x1, b.y1);
        else if (sleighHit(b.x1, b.y1)) {
            splat(b.x1, b.y1, 14, "#ffe39a", 2.5);
            texts.push({ x: b.x1, y: b.y1 - 30, t: 0, label: "Ho ho ho! 🎁" });
        }
        else splat(b.x1, b.y1, 10, "#ffffff");
    }

    function knockDown(s, x, y) {
        s.alive = false;
        hits++;
        var u = sizeOf(s);
        // vỡ tuyết
        splat(x, y, 26, "#ffffff", u * 0.06);
        hitCircles(s).forEach(function (c) { splat(c.x, c.y, 8, "#e9f0fb", c.r * 0.35); });
        // mũi cà rốt & mũ bay lên
        parts.push(piece(s.x, hitCircles(s)[2].y, "#f07b1d", u * 0.09, "carrot"));
        parts.push(piece(s.x, hitCircles(s)[2].y - u * 0.1, s.hat === "santa" ? "#c0282f" : "#23283d", u * 0.13, "hat"));
        texts.push({ x: s.x, y: hitCircles(s)[2].y - u * 0.35, t: 0, label: hits >= HITS_REQUIRED ? "Tuyệt vời!" : "Trúng rồi!" });

        if (dots[hits - 1]) dots[hits - 1].classList.add("on");
        if (hits >= HITS_REQUIRED) finish();
        else setTimeout(spawnSnowman, 500);
    }

    function piece(x, y, color, size, kind) {
        return {
            x: x, y: y, vx: (Math.random() - 0.5) * 6, vy: -7 - Math.random() * 4,
            rot: 0, vr: (Math.random() - 0.5) * 0.4, r: size, color: color, kind: kind, life: 1, g: 0.32
        };
    }

    function splat(x, y, n, color, size) {
        for (var i = 0; i < n; i++) {
            var a = Math.random() * 6.2832, v = 1.5 + Math.random() * 4.5;
            parts.push({
                x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 2,
                r: (size || 3) * (0.5 + Math.random()), color: color, kind: "dot", life: 1, g: 0.22, rot: 0, vr: 0
            });
        }
    }

    /* ---------- ÔNG GIÀ NOEL CƯỠI TUẦN LỘC (trang trí, bay ngang bầu trời) ---------- */
    function sleighScale() { return Math.max(0.8, Math.min(1.7, W / 1000)) * SLEIGH_SIZE; }

    function startSleigh(now) {
        var dir = Math.random() < 0.5 ? 1 : -1;
        var k = sleighScale();
        var len = 260 * k;                       // chiều dài cả đoàn (tuần lộc + xe)
        // bay thấp hơn đáy khung chữ HUD để không bị che
        var hudBottom = hud.getBoundingClientRect().bottom - gate.getBoundingClientRect().top;
        var base = Math.min(0.5, (hudBottom + 55 * k) / H + 0.05);
        sleigh = {
            dir: dir, t0: now, k: k, len: len,
            dur: SLEIGH_CROSS_MS * (REDUCED ? 1.4 : 1) * (0.9 + Math.random() * 0.25),
            base: base + Math.random() * 0.07,   // độ cao bay (tỉ lệ chiều cao màn), luôn ở dưới khung chữ
            climb: Math.random() * 0.05,         // bay chếch lên nhẹ
            wave: 0.012 + Math.random() * 0.015,
            ho: false, x: -9999, y: -9999
        };
    }

    // vị trí theo tiến trình p (0..1): tâm chiếc xe trượt tuyết
    function sleighPos(S, p) {
        var span = W + S.len * 2;
        var x = S.dir > 0 ? -S.len + span * p - S.len * 0.2 : W + S.len - span * p + S.len * 0.2;
        var y = H * (S.base - S.climb * p) + Math.sin(p * Math.PI * 3) * H * S.wave;
        return { x: x, y: y };
    }

    function updateSleigh(now, dt) {
        if (!sleigh) {
            if (now >= sleighAt && !finished) startSleigh(now);
            return;
        }
        var S = sleigh;
        var p = (now - S.t0) / S.dur;
        if (p >= 1.05) {
            sleigh = null;
            sleighAt = now + SLEIGH_EVERY_MS[0] + Math.random() * (SLEIGH_EVERY_MS[1] - SLEIGH_EVERY_MS[0]);
            return;
        }
        var a = sleighPos(S, p), b = sleighPos(S, p + 0.004);
        S.x = a.x; S.y = a.y;
        S.tilt = Math.atan2(b.y - a.y, Math.abs(b.x - a.x) + 0.001) * 0.8;

        // bụi sao lấp lánh phía sau xe
        if (!REDUCED || Math.random() < 0.3) {
            for (var i = 0; i < 2; i++) {
                dust.push({
                    x: S.x - S.dir * 34 * S.k + (Math.random() - 0.5) * 10,
                    y: S.y + 10 * S.k + (Math.random() - 0.5) * 8,
                    vx: -S.dir * (0.2 + Math.random() * 0.5), vy: 0.15 + Math.random() * 0.35,
                    r: (1.2 + Math.random() * 2.2) * S.k, life: 1,
                    c: Math.random() < 0.6 ? "#ffe39a" : "#ffffff"
                });
            }
        }
        // "Ho ho ho!" khi bay qua giữa màn
        if (!S.ho && Math.abs(S.x - W / 2) < W * 0.08) {
            S.ho = true;
            texts.push({ x: S.x, y: S.y - 50 * S.k, t: 0, label: "Ho ho ho!" });
        }
    }

    function drawDust(dt) {
        for (var i = dust.length - 1; i >= 0; i--) {
            var d = dust[i];
            d.x += d.vx * dt; d.y += d.vy * dt; d.life -= 0.012 * dt;
            if (d.life <= 0) { dust.splice(i, 1); continue; }
            ctx.globalAlpha = d.life * (0.6 + Math.random() * 0.4);
            ctx.fillStyle = d.c;
            star4(d.x, d.y, d.r * (0.6 + d.life * 0.6));
        }
        ctx.globalAlpha = 1;
    }

    function star4(x, y, r) {
        ctx.beginPath();
        ctx.moveTo(x, y - r * 2);
        ctx.quadraticCurveTo(x, y, x + r * 2, y);
        ctx.quadraticCurveTo(x, y, x, y + r * 2);
        ctx.quadraticCurveTo(x, y, x - r * 2, y);
        ctx.quadraticCurveTo(x, y, x, y - r * 2);
        ctx.fill();
    }

    function drawSleigh(now) {
        var S = sleigh;
        if (!S) return;
        var t = now / 1000;
        ctx.save();
        ctx.translate(S.x, S.y);
        ctx.scale(S.dir * S.k, S.k);   // vẽ hướng sang phải, lật khi bay sang trái
        ctx.rotate(-S.tilt * S.dir);

        // bầy tuần lộc: 2 cặp + Rudolph dẫn đầu
        var deer = [
            { x: 62, y: -2, row: 0 }, { x: 58, y: 6, row: 1 },
            { x: 108, y: -4, row: 0 }, { x: 104, y: 4, row: 1 },
            { x: 154, y: -3, row: 0, rudolph: true }
        ];
        var harness = [];
        deer.forEach(function (d, i) {
            var ph = t * 9 + i * 0.9;
            var dy = Math.sin(ph) * 3;
            harness.push({ x: d.x - 4, y: d.y + dy - 2, row: d.row });
            d.ph = ph; d.dy = dy;
        });

        // dây cương vàng (vẽ trước để nằm dưới thân tuần lộc)
        ctx.strokeStyle = "#e8b64c";
        ctx.lineWidth = 1.3;
        ctx.beginPath();
        ctx.moveTo(22, -14);
        harness.forEach(function (h) { ctx.lineTo(h.x, h.y); });
        ctx.stroke();
        ctx.beginPath();
        ctx.moveTo(8, -20);
        ctx.quadraticCurveTo(40, -24, harness[0].x, harness[0].y);
        ctx.stroke();

        // tuần lộc hàng sau vẽ trước, hàng trước vẽ sau
        deer.filter(function (d) { return d.row === 1; }).forEach(function (d) { drawReindeer(d, 0.82); });
        deer.filter(function (d) { return d.row === 0; }).forEach(function (d) { drawReindeer(d, 1); });

        drawSleighBody(t);
        ctx.restore();
    }

    function drawReindeer(d, shade) {
        ctx.save();
        ctx.translate(d.x, d.y + d.dy);
        var ph = d.ph;
        var body = shade < 1 ? "#6e4523" : "#8b5a2b";
        var dark = shade < 1 ? "#4d2f17" : "#5e3a1b";

        // chân phi nước đại (2 đoạn)
        ctx.strokeStyle = dark;
        ctx.lineCap = "round";
        ctx.lineWidth = 2.4;
        [[9, 1], [6, 1.3], [-9, -1], [-12, -1.3]].forEach(function (L) {
            var sw = Math.sin(ph + L[1]) * 0.9;
            var front = L[0] > 0 ? 1 : -1;
            var kx = L[0] + Math.sin(sw) * 8 * front, ky = 4 + 7 * Math.cos(sw * 0.6);
            ctx.beginPath();
            ctx.moveTo(L[0], 3);
            ctx.lineTo(kx, ky);
            ctx.lineTo(kx + front * 5 * Math.max(0.2, Math.abs(sw)), ky + 5);
            ctx.stroke();
        });

        // thân
        var g = ctx.createLinearGradient(0, -8, 0, 8);
        g.addColorStop(0, shade < 1 ? "#8a5a30" : "#a8703a");
        g.addColorStop(1, body);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(0, 0, 16, 7.5, 0, 0, 6.2832);
        ctx.fill();
        // bụng sáng + đuôi trắng
        ctx.fillStyle = "rgba(245,225,200,.8)";
        ctx.beginPath(); ctx.ellipse(1, 4, 10, 2.6, 0, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.ellipse(-16, -3, 3, 2.2, -0.5, 0, 6.2832); ctx.fill();

        // yên cương đỏ + chuông vàng
        ctx.fillStyle = "#c0282f";
        ctx.fillRect(-4, -7.5, 7, 15);
        ctx.fillStyle = "#e8b64c";
        ctx.beginPath(); ctx.arc(-0.5, 8, 1.9, 0, 6.2832); ctx.fill();

        // cổ + đầu
        ctx.fillStyle = body;
        ctx.beginPath();
        ctx.moveTo(10, -5); ctx.lineTo(17, -15); ctx.lineTo(22, -12); ctx.lineTo(15, 0);
        ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.ellipse(22, -16, 6.5, 4.2, 0.25, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.ellipse(27, -14.5, 3.4, 2.6, 0.2, 0, 6.2832); ctx.fill(); // mõm
        // tai
        ctx.beginPath(); ctx.ellipse(17.5, -20, 3.2, 1.4, -0.7, 0, 6.2832); ctx.fill();
        // mắt
        ctx.fillStyle = "#1e2233";
        ctx.beginPath(); ctx.arc(23, -17.5, 1, 0, 6.2832); ctx.fill();

        // gạc
        ctx.strokeStyle = "#d9b88a";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(19, -20); ctx.lineTo(15, -29); ctx.lineTo(11, -32);
        ctx.moveTo(16.5, -26); ctx.lineTo(20, -31);
        ctx.moveTo(21, -20); ctx.lineTo(20, -28); ctx.lineTo(24, -32);
        ctx.moveTo(15.3, -28.5); ctx.lineTo(13, -26);
        ctx.stroke();

        // mũi: Rudolph đỏ phát sáng, còn lại đen
        if (d.rudolph) {
            var glow = ctx.createRadialGradient(30, -14.5, 0, 30, -14.5, 9);
            glow.addColorStop(0, "rgba(255,90,90,.9)");
            glow.addColorStop(1, "rgba(255,60,60,0)");
            ctx.fillStyle = glow;
            ctx.beginPath(); ctx.arc(30, -14.5, 9, 0, 6.2832); ctx.fill();
            ctx.fillStyle = "#ff3030";
            ctx.beginPath(); ctx.arc(30, -14.5, 2.4, 0, 6.2832); ctx.fill();
        } else {
            ctx.fillStyle = "#2a1a10";
            ctx.beginPath(); ctx.arc(30, -14.5, 1.6, 0, 6.2832); ctx.fill();
        }
        ctx.restore();
    }

    function drawSleighBody(t) {
        // túi quà sau lưng
        ctx.fillStyle = "#7a4a26";
        ctx.beginPath(); ctx.ellipse(-20, -18, 11, 12, -0.2, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#1f6b45"; ctx.fillRect(-30, -32, 9, 9);
        ctx.fillStyle = "#e8b64c"; ctx.fillRect(-21, -34, 8, 8);
        ctx.fillStyle = "#3b6fd1"; ctx.fillRect(-27, -38, 7, 7);
        ctx.fillStyle = "#c0282f"; ctx.fillRect(-26.2, -32, 1.6, 9); ctx.fillRect(-30, -28.3, 9, 1.6);

        // ông già Noel
        ctx.fillStyle = "#c0282f";
        ctx.beginPath(); ctx.ellipse(2, -15, 10, 11, 0, 0, 6.2832); ctx.fill();   // thân áo
        ctx.fillStyle = "#fff";
        ctx.fillRect(-2, -8, 10, 2.5);                                             // viền áo
        ctx.fillStyle = "#23283d"; ctx.fillRect(-7, -12, 18, 3);                   // thắt lưng
        ctx.fillStyle = "#e8b64c"; ctx.fillRect(1, -12.5, 3.5, 4);
        // tay cầm dây cương
        ctx.strokeStyle = "#c0282f"; ctx.lineWidth = 4; ctx.lineCap = "round";
        ctx.beginPath(); ctx.moveTo(6, -19); ctx.lineTo(12, -18 + Math.sin(t * 6) * 1.5); ctx.stroke();
        ctx.fillStyle = "#23283d";
        ctx.beginPath(); ctx.arc(13, -18 + Math.sin(t * 6) * 1.5, 2.3, 0, 6.2832); ctx.fill();
        // mặt + râu
        ctx.fillStyle = "#f5c9a8";
        ctx.beginPath(); ctx.arc(5, -30, 6, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.ellipse(6, -25, 6.5, 5.5, 0, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#e05a5a";
        ctx.beginPath(); ctx.arc(9.5, -29.5, 1.5, 0, 6.2832); ctx.fill();        // mũi
        ctx.fillStyle = "#1e2233";
        ctx.beginPath(); ctx.arc(7.5, -32, 0.9, 0, 6.2832); ctx.fill();          // mắt
        // mũ bay phấp phới về sau
        var flap = Math.sin(t * 5) * 2;
        ctx.fillStyle = "#c0282f";
        ctx.beginPath();
        ctx.moveTo(-1, -33); ctx.quadraticCurveTo(0, -44, -12, -40 + flap); ctx.lineTo(11, -34);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.fillRect(-2, -36, 14, 3.4);
        ctx.beginPath(); ctx.arc(-12.5, -40 + flap, 2.6, 0, 6.2832); ctx.fill();

        // thân xe trượt tuyết
        var g = ctx.createLinearGradient(0, -12, 0, 10);
        g.addColorStop(0, "#d93a41");
        g.addColorStop(1, "#8f1b21");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(-34, -14);
        ctx.quadraticCurveTo(-38, 8, -22, 9);
        ctx.lineTo(18, 9);
        ctx.quadraticCurveTo(30, 8, 31, -6);
        ctx.quadraticCurveTo(33, -16, 26, -18);
        ctx.quadraticCurveTo(22, -12, 18, -6);
        ctx.lineTo(-24, -6);
        ctx.quadraticCurveTo(-28, -12, -34, -14);
        ctx.closePath();
        ctx.fill();
        // viền vàng
        ctx.strokeStyle = "#e8b64c";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-30, 2); ctx.lineTo(22, 2);
        ctx.stroke();
        ctx.beginPath(); ctx.arc(26, -15, 3, 0, 6.2832); ctx.stroke();
        // càng + ván trượt vàng
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(-18, 9); ctx.lineTo(-18, 15);
        ctx.moveTo(12, 9); ctx.lineTo(12, 15);
        ctx.moveTo(-34, 15);
        ctx.lineTo(28, 15);
        ctx.quadraticCurveTo(40, 15, 38, 5);
        ctx.quadraticCurveTo(36, 1, 33, 4);
        ctx.stroke();
    }

    function sleighHit(x, y) {
        if (!sleigh) return false;
        var S = sleigh, k = S.k;
        // vùng chạm: từ đuôi xe tới Rudolph
        var x0 = S.x - S.dir * 38 * k, x1 = S.x + S.dir * 185 * k;
        var lo = Math.min(x0, x1), hi = Math.max(x0, x1);
        return x >= lo && x <= hi && Math.abs(y - (S.y - 12 * k)) < 34 * k;
    }

    /* ---------- TUYẾT RƠI TRÊN MÀN ---------- */
    function makeFlake(anyY) {
        var depth = Math.random();
        return {
            x: Math.random() * W, y: anyY ? Math.random() * H : -10,
            r: 0.8 + depth * 2.2, vy: 0.4 + depth * 1.2, drift: Math.random() * 6.28, a: 0.35 + depth * 0.5
        };
    }

    /* ---------- VÒNG LẶP ---------- */
    var last = performance.now();
    function frame(now) {
        if (!gate.isConnected) return;
        var dt = Math.min((now - last) / 16.67, 3);
        last = now;
        ctx.clearRect(0, 0, W, H);

        // tuyết rơi
        if (!REDUCED) {
            ctx.fillStyle = "#fff";
            for (var i = 0; i < flakes.length; i++) {
                var f = flakes[i];
                f.y += f.vy * dt; f.drift += 0.012 * dt; f.x += Math.sin(f.drift) * 0.3 * dt;
                if (f.y > H + 6) { flakes[i] = makeFlake(false); continue; }
                ctx.globalAlpha = f.a;
                ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, 6.2832); ctx.fill();
            }
            ctx.globalAlpha = 1;
        }

        // ông già Noel bay ngang bầu trời (vẽ trước người tuyết → nằm phía sau)
        updateSleigh(now, dt);
        drawDust(dt);
        drawSleigh(now);

        // người tuyết: đi, thỉnh thoảng quay đầu, dội lại ở mép
        var alive = snowmen.filter(function (s) { return s.alive; });
        snowmen = alive;
        alive.sort(function (a, b) { return a.gy - b.gy; });   // xa vẽ trước, gần vẽ sau
        alive.forEach(function (s) {
            var ms = 16.67 * dt;
            // thỉnh thoảng lao nhanh (dash) trong chốc lát
            if (s.dash > 0) s.dash -= ms;
            else if (DASH && Math.random() < 0.004 * dt) s.dash = 450 + Math.random() * 500;
            var boost = s.dash > 0 ? 1.9 : 1;

            s.x += s.dir * s.speed * boost * dt;
            s.gy += s.vy * dt;
            s.phase += 0.13 * dt * (0.8 + s.speed * 0.12) * boost;
            s.nextTurn -= ms;
            s.nextVy -= ms;

            // dội lại ở mép trái/phải và biên trên/dưới
            var margin = sizeOf(s) * 0.5;
            if (s.x < margin && s.dir < 0) s.dir = 1;
            else if (s.x > W - margin && s.dir > 0) s.dir = -1;
            else if (s.nextTurn <= 0 && s.x > margin * 2 && s.x < W - margin * 2) {
                s.dir *= -1;
                s.nextTurn = 900 + Math.random() * 2400;
            }
            if (s.gy < Y_MIN) { s.gy = Y_MIN; s.vy = Math.abs(s.vy); }
            else if (s.gy > Y_MAX) { s.gy = Y_MAX; s.vy = -Math.abs(s.vy); }
            if (s.nextVy <= 0) { s.vy = randVy() * (1 + hits * LEVEL_UP); s.nextVy = 500 + Math.random() * 1500; }

            drawSnowman(s);
        });

        // đường ngắm
        if (aim && !finished) {
            var o = origin();
            var dist = Math.hypot(aim.x - o.x, aim.y - o.y);
            var arc = Math.min(220, dist * 0.28);
            ctx.fillStyle = "rgba(255,255,255,.55)";
            for (var k = 1; k < 14; k++) {
                var tt = k / 14;
                var px = o.x + (aim.x - o.x) * tt;
                var py = o.y + (aim.y - o.y) * tt - Math.sin(Math.PI * tt) * arc;
                ctx.beginPath(); ctx.arc(px, py, 2.2, 0, 6.2832); ctx.fill();
            }
            ctx.strokeStyle = "rgba(255,255,255,.8)";
            ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(aim.x, aim.y, 12, 0, 6.2832); ctx.stroke();
        }

        // quả cầu tuyết đang bay
        for (var bI = balls.length - 1; bI >= 0; bI--) {
            var b = balls[bI];
            var p = Math.min(1, (now - b.t0) / b.dur);
            if (b.homing && b.homing.alive) {           // cầu bám theo người tuyết đã chọn
                var hc = hitCircles(b.homing)[1];
                b.x1 = hc.x; b.y1 = hc.y;
            }
            b.x = b.x0 + (b.x1 - b.x0) * p;
            b.y = b.y0 + (b.y1 - b.y0) * p - Math.sin(Math.PI * p) * b.arc;
            var r = b.r0 + (b.r1 - b.r0) * p;
            ball(b.x, b.y, r);
            if (p >= 1) { balls.splice(bI, 1); landBall(b); }
        }

        // quả cầu chờ ném ở dưới giữa màn
        if (!finished) {
            var oo = origin();
            var ready = now >= reloadAt;
            var rr = ballR0() * (ready ? 1 : 0.6);
            ctx.globalAlpha = ready ? 1 : 0.6;
            ball(oo.x, oo.y + Math.sin(now / 300) * 2, rr);
            ctx.globalAlpha = 1;
        }

        // mảnh vỡ
        for (var q = parts.length - 1; q >= 0; q--) {
            var pt = parts[q];
            pt.vy += pt.g * dt; pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.rot += pt.vr * dt;
            pt.life -= 0.018 * dt;
            if (pt.life <= 0 || pt.y > H + 40) { parts.splice(q, 1); continue; }
            ctx.save();
            ctx.globalAlpha = Math.max(0, pt.life);
            ctx.translate(pt.x, pt.y);
            ctx.rotate(pt.rot);
            ctx.fillStyle = pt.color;
            if (pt.kind === "carrot") {
                ctx.beginPath(); ctx.moveTo(0, -pt.r * 0.3); ctx.lineTo(pt.r * 1.4, 0); ctx.lineTo(0, pt.r * 0.3); ctx.closePath(); ctx.fill();
            } else if (pt.kind === "hat") {
                ctx.beginPath(); ctx.moveTo(-pt.r, pt.r * 0.4); ctx.lineTo(0, -pt.r * 1.2); ctx.lineTo(pt.r, pt.r * 0.4); ctx.closePath(); ctx.fill();
                ctx.fillStyle = "#fff"; ctx.fillRect(-pt.r * 1.1, pt.r * 0.3, pt.r * 2.2, pt.r * 0.35);
            } else {
                ctx.beginPath(); ctx.arc(0, 0, pt.r, 0, 6.2832); ctx.fill();
            }
            ctx.restore();
        }

        // chữ nổi
        for (var tI = texts.length - 1; tI >= 0; tI--) {
            var tx = texts[tI];
            tx.t += 0.02 * dt;
            if (tx.t >= 1) { texts.splice(tI, 1); continue; }
            ctx.globalAlpha = 1 - tx.t;
            ctx.font = "700 " + Math.round(unit() * 0.32) + "px 'Dancing Script', 'Be Vietnam Pro', cursive";
            ctx.textAlign = "center";
            ctx.lineWidth = 4;
            ctx.strokeStyle = "rgba(27,36,71,.7)";
            ctx.strokeText(tx.label, tx.x, tx.y - tx.t * 50);
            ctx.fillStyle = "#ffe29a";
            ctx.fillText(tx.label, tx.x, tx.y - tx.t * 50);
            ctx.globalAlpha = 1;
        }

        requestAnimationFrame(frame);
    }

    /* ---------- MỞ MÀN ---------- */
    function finish() {
        if (finished) return;
        finished = true;
        aim = null;
        hud.classList.add("done");
        hud.querySelector("h2").textContent = "Giáng sinh an lành!";
        hud.querySelector("p").textContent = "Màn đang mở…";
        setTimeout(openCurtains, 750);
    }

    function openCurtains() {
        gate.classList.add("opening");
        if (window.Christmas && window.Christmas.burst) {
            window.Christmas.burst(window.innerWidth / 2, window.innerHeight / 2, 28);
        }
        setTimeout(function () {
            gate.remove();
            root.classList.remove("xg-lock");
            var main = document.querySelector("main");
            if (main) { main.setAttribute("tabindex", "-1"); main.focus({ preventScroll: true }); }
            // báo cho trang biết màn đã mở (vd. DataTables cần adjust cột)
            window.dispatchEvent(new Event("resize"));
            document.dispatchEvent(new CustomEvent("xmas-gate-opened"));
        }, REDUCED ? 700 : 1600);
    }

    /* ---------- SỰ KIỆN ---------- */
    function localPoint(e) {
        var r = cv.getBoundingClientRect();
        return { x: e.clientX - r.left, y: e.clientY - r.top };
    }

    cv.addEventListener("pointerdown", function (e) {
        e.preventDefault();
        var p = localPoint(e);
        throwAt(p.x, p.y);
    });
    cv.addEventListener("pointermove", function (e) {
        if (e.pointerType === "mouse") aim = localPoint(e);
    });
    cv.addEventListener("pointerleave", function () { aim = null; });

    // Space / Enter: nhấn liên tục hoặc GIỮ phím đều được (giữ phím → tự ném mỗi khi hồi xong)
    var holding = false;
    function isThrowKey(e) { return e.key === " " || e.key === "Spacebar" || e.key === "Enter"; }
    gate.addEventListener("keydown", function (e) {
        if (!isThrowKey(e)) return;
        e.preventDefault();
        if (!e.repeat) autoThrow();
        holding = true;
    });
    gate.addEventListener("keyup", function (e) { if (isThrowKey(e)) holding = false; });
    window.addEventListener("blur", function () { holding = false; });
    (function holdLoop() {
        if (!gate.isConnected) return;
        if (holding && !finished && balls.length < 2) autoThrow();
        setTimeout(holdLoop, THROW_COOLDOWN_MS + 30);
    })();

    var skip = gate.querySelector(".xg-skip");
    if (skip) {
        skip.addEventListener("click", function () { if (!finished) { finished = true; openCurtains(); } });
        if (SKIP_AFTER_MS > 0) setTimeout(function () { if (!finished) skip.classList.add("show"); }, SKIP_AFTER_MS);
    }

    window.addEventListener("resize", resize);
    resize();
    for (var n = 0; n < SNOWMEN_ON_FIELD; n++) {
        (function (delay) { setTimeout(spawnSnowman, delay); })(n * 700);
    }
    gate.focus({ preventScroll: true });
    requestAnimationFrame(frame);
})();
