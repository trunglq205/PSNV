﻿namespace SWMS_WebTool.Models.Requests
{
    public class ReplaceKittingListDetailRequest
    {
        public long Id { get; set; }
        public string Material { get; set; }
        public double Quantity { get; set; }
        public string MaterialReplace { get; set; }
        public double? QuantityReplace { get; set; }
    }
}
