namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

/// <summary>
/// Luồng nhận lại hàng về FA (mục 2c) — đọc / ghi 13 cột <c>back_*</c> trên
/// <c>wms.return_instructions</c> và bảng nhật ký giao hàng.
///
/// Slice RIÊNG dù ghi vào bảng của mục 2a: ba bước này có bộ quyền riêng, bộ
/// mail riêng và vòng đời riêng với việc nhận hàng. Nhồi vào
/// <see cref="IReturnInstructionRepository"/> là làm file đó phình ra gấp đôi
/// và mọi sửa đổi của hai nghiệp vụ dính vào nhau.
///
/// Đổi lại, mọi câu ĐỌC số liệu đi qua <see cref="IReturnInstructionRepository"/>
/// (đã nạp đủ 13 cột + bốn con số) — ở đây chỉ còn các câu GHI và nhật ký.
/// </summary>
public interface IReturnBackFlowRepository
{
    /// <summary>
    /// B1 — FA đề nghị. Điều kiện nằm TRONG câu UPDATE, không SELECT-rồi-UPDATE:
    /// hai người bấm cùng lúc thì người sau cập nhật 0 dòng và nhận 409, chứ
    /// không ghi đè.
    ///
    /// Cho đề nghị lại sau khi đã huỷ (<c>back_status = 'cancelled'</c>) — huỷ
    /// là đổi ý, không phải cấm vĩnh viễn. Lúc đó XOÁ SẠCH dấu của lượt huỷ
    /// trước, nếu không màn hình hiện một đề nghị mới kèm lý do huỷ cũ.
    /// </summary>
    /// <returns><c>false</c> khi phiếu không ở trạng thái đề nghị được.</returns>
    Task<bool> RequestAsync(long docId, string? note, string? user);

    /// <summary>Sửa ghi chú, chỉ khi còn chờ quản lý FA xác nhận.</summary>
    Task<bool> UpdateNoteAsync(long docId, string? note, string? user);

    /// <summary>B2 — quản lý FA xác nhận.</summary>
    Task<bool> ApproveAsync(long docId, string? comment, string? user);

    /// <summary>
    /// Huỷ luồng back. Chặn khi ĐÃ GIAO được con nào: điều kiện
    /// <c>NOT EXISTS (serial có sent_fa_at)</c> nằm trong chính câu UPDATE, nên
    /// không có khe nào để một lượt giao chen vào giữa lúc kiểm và lúc ghi.
    /// </summary>
    Task<bool> CancelAsync(long docId, string? reason, string? user);

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA.
    ///
    /// Mỗi mã: tìm pallet, chuyển serial của phiếu đang ở <c>received</c> trên
    /// pallet đó sang <c>at_fa</c> + đóng <c>sent_fa_at</c>, rồi ghi một dòng
    /// nhật ký — GHI CẢ KHI 0 con chuyển được, để sau tra ra được là đã quét
    /// pallet đó rồi mà nó rỗng.
    ///
    /// KHÔNG xoá <c>pallet_id</c> của serial: hàng sang FA vẫn nằm trên đúng
    /// pallet đó, và mục 2d cần biết con nào từ pallet nào về.
    ///
    /// Hết con nào ở <c>received</c> thì đóng luồng:
    /// <c>back_status = 'delivered'</c> + mốc người giao. Đếm theo PHIẾU, không
    /// theo một tổng lưu sẵn — đó mới là câu trả lời đúng cho "còn hàng không".
    ///
    /// Cả hàm trong MỘT transaction: giao nửa rồi lỗi thì mail không gửi mà
    /// serial đã đổi trạng thái là hỏng không lần ra được.
    /// </summary>
    Task<ReturnBackDeliverResult> DeliverAsync(
        long docId, IReadOnlyList<string> lotNos, string? comment, string? user);

    /// <summary>Nhật ký pallet đã giao của một phiếu, mới nhất trước.</summary>
    Task<IReadOnlyList<ReturnBackDelivery>> GetDeliveriesAsync(long docId);

    /// <summary>
    /// SL còn ở kho theo model — màn đề nghị gọi để CHO XEM phần sẽ lấy về, và
    /// mail dùng đúng số này dựng bảng.
    ///
    /// Đếm serial đang <c>received</c>, KHÔNG đọc <c>return_instruction_lines</c>:
    /// dòng chỉ thị là số khách BÁO, còn đây phải là số thực còn trong kho.
    /// </summary>
    Task<IReadOnlyList<BackModelQty>> GetRemainByModelAsync(long docId);
}

