import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';

/// Khung bottom sheet dùng chung — song sinh với [AppDialog]: cùng token nền,
/// cùng [AppDialogAction] cho thanh nút đáy, chỉ khác chỗ bám (đáy màn hình)
/// và việc tự né bàn phím.
///
/// Dùng sheet thay dialog khi nội dung có ô nhập: sheet được đẩy lên theo
/// `viewInsets` nên bàn phím không che ô đang gõ, dialog thì che.
///
/// ```dart
/// showAppBottomSheet<String>(
///   context,
///   builder: (_) => AppBottomSheet(
///     title: 'Sửa PO',
///     child: ...,
///     actions: [
///       AppDialogAction.cancel(context),
///       AppDialogAction.confirm(onPressed: _submit),
///     ],
///   ),
/// );
/// ```
class AppBottomSheet extends StatelessWidget {
  const AppBottomSheet({
    super.key,
    this.leading,
    this.icon,
    this.title,
    this.subtitle,
    this.trailing = const [],
    this.showClose = true,
    this.onClose,
    this.showGrabber = true,
    this.child,
    this.actions = const [],
    this.bodyPadding,
    this.scrollable = true,
    this.maxHeightFactor = 0.9,
    this.backgroundColor,
    this.dividers = true,
  });

  /// Khối tự vẽ bên trái tiêu đề (badge gradient, avatar…). Có [leading] thì
  /// [icon] bị bỏ qua.
  final Widget? leading;

  /// Icon đơn giản bên trái tiêu đề.
  final IconData? icon;

  final String? title;
  final String? subtitle;

  /// Nút phụ bên phải tiêu đề, đứng trước nút đóng.
  final List<Widget> trailing;

  /// Nút X. Để `true` cả khi `isDismissible: false` — không thì người dùng
  /// không còn cách nào thoát ngoài nút Huỷ.
  final bool showClose;

  /// Việc cần làm trước khi đóng (nhả focus, xác nhận bỏ dở…).
  /// Bỏ trống = `Navigator.pop()`.
  final VoidCallback? onClose;

  /// Thanh kéo nhỏ trên cùng. Tắt khi `enableDrag: false` cho khỏi gợi ý sai.
  final bool showGrabber;

  final Widget? child;

  /// Thanh nút đáy, dùng chung kiểu với [AppDialog].
  final List<AppDialogAction> actions;

  final EdgeInsetsGeometry? bodyPadding;

  /// Thân cuộn được. Mặc định bật: sheet cao tối đa [maxHeightFactor] màn hình,
  /// bàn phím bung lên là chỗ còn lại rất hẹp.
  final bool scrollable;

  /// Trần chiều cao theo tỉ lệ màn hình.
  final double maxHeightFactor;

  final Color? backgroundColor;

  /// Kẻ ngăn dưới header.
  final bool dividers;

  bool get _hasHeader =>
      title != null || subtitle != null || icon != null || leading != null;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final insets = MediaQuery.viewInsetsOf(context).bottom;
    final maxHeight = MediaQuery.sizeOf(context).height * maxHeightFactor;

    return Padding(
      // Bàn phím bung -> đẩy cả sheet lên đúng bằng chiều cao bàn phím.
      padding: EdgeInsets.only(bottom: insets),
      child: ConstrainedBox(
        constraints: BoxConstraints(maxHeight: maxHeight),
        child: Material(
          color: backgroundColor ?? swms.card,
          surfaceTintColor: Colors.transparent,
          clipBehavior: Clip.antiAlias,
          borderRadius: const BorderRadius.vertical(
            top: Radius.circular(AppDimens.rCard),
          ),
          child: SafeArea(
            top: false,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                if (showGrabber) const _Grabber(),
                if (_hasHeader) _buildHeader(context),
                if (child != null) _buildBody(),
                if (actions.isNotEmpty) _buildFooter(),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final swms = context.swms;
    final t = title;
    final s = subtitle;

    return Container(
      padding: EdgeInsets.fromLTRB(
        AppDimens.md,
        showGrabber ? AppDimens.xs : AppDimens.md,
        // Có nút bên phải -> chừa ít lề hơn, IconButton đã tự có vùng chạm.
        (trailing.isEmpty && !showClose) ? AppDimens.md : AppDimens.sm,
        AppDimens.sm,
      ),
      decoration: dividers
          ? BoxDecoration(
        border: Border(bottom: BorderSide(color: swms.border)),
      )
          : null,
      child: Row(
        children: [
          if (leading != null) ...[
            leading!,
            const SizedBox(width: AppDimens.sm + 2),
          ] else if (icon != null) ...[
            Icon(icon, size: 20, color: swms.primary),
            const SizedBox(width: AppDimens.sm),
          ],
          Expanded(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                if (t != null)
                  Text(t, style: AppTextStyles.title.copyWith(color: swms.text1)),
                if (s != null) ...[
                  const SizedBox(height: 2),
                  Text(
                    s,
                    style: AppTextStyles.caption.copyWith(color: swms.text3),
                  ),
                ],
              ],
            ),
          ),
          ...trailing,
          if (showClose)
            IconButton(
              onPressed: onClose ?? () => Navigator.of(context).pop(),
              icon: const Icon(Icons.close, size: 20),
              color: swms.text3,
              tooltip: MaterialLocalizations.of(context).closeButtonTooltip,
            ),
        ],
      ),
    );
  }

  Widget _buildBody() {
    final padding = bodyPadding ?? const EdgeInsets.all(AppDimens.md);
    return Flexible(
      child: scrollable
          ? SingleChildScrollView(padding: padding, child: child!)
          : Padding(padding: padding, child: child!),
    );
  }

  Widget _buildFooter() {
    return Padding(
      // Thân đã có padding đáy md -> footer không thêm lề trên nữa.
      padding: const EdgeInsets.fromLTRB(
        AppDimens.md,
        0,
        AppDimens.md,
        AppDimens.md,
      ),
      child: Row(
        children: [
          for (var i = 0; i < actions.length; i++) ...[
            if (i > 0) const SizedBox(width: AppDimens.sm + AppDimens.xs),
            Expanded(
              child: AppButton(
                label: actions[i].label,
                variant: actions[i].variant,
                icon: actions[i].icon,
                isLoading: actions[i].isLoading,
                onPressed: actions[i].onPressed,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _Grabber extends StatelessWidget {
  const _Grabber();

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Center(
      child: Container(
        width: 36,
        height: 4,
        margin: const EdgeInsets.only(top: AppDimens.sm, bottom: AppDimens.xs),
        decoration: BoxDecoration(
          color: swms.border2,
          borderRadius: BorderRadius.circular(2),
        ),
      ),
    );
  }
}

/// Mở [AppBottomSheet]. Luôn `isScrollControlled` (sheet tự lo chiều cao) và
/// nền trong suốt (bo góc do sheet vẽ), lớp phủ nhạt như [showAppDialog].
Future<T?> showAppBottomSheet<T>(
    BuildContext context, {
      required WidgetBuilder builder,
      bool isDismissible = true,
      bool enableDrag = true,
      bool useRootNavigator = false,
    }) {
  return showModalBottomSheet<T>(
    context: context,
    builder: builder,
    isScrollControlled: true,
    isDismissible: isDismissible,
    enableDrag: enableDrag,
    useRootNavigator: useRootNavigator,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black.withValues(alpha: .32),
  );
}