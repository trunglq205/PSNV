import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_toggle_switch.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';

/// Chuyển 1 mã ↔ nhiều mã trên AppBar.
///
/// Nhãn hiển thị chế độ ĐANG chọn: in nhầm loại phiếu là tốn giấy + phải huỷ,
/// nên trạng thái phải nhìn thấy chứ không để người dùng đoán.
class PartCardModeSwitch extends StatelessWidget {
  const PartCardModeSwitch({
    super.key,
    required this.mode,
    required this.onChanged,
    this.enabled = true,
  });

  final PartCardMode mode;
  final ValueChanged<PartCardMode> onChanged;

  /// Khoá lại khi đã in ra giấy mà chưa lưu lịch sử.
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return AppToggleSwitch(
      value: mode.isMulti,
      enabled: enabled,
      offLabel: LocaleKeys.part_card_mode_single.tr(),
      onLabel: LocaleKeys.part_card_mode_multi.tr(),
      onChanged: (on) =>
          onChanged(on ? PartCardMode.multi : PartCardMode.single),
    );
  }
}
