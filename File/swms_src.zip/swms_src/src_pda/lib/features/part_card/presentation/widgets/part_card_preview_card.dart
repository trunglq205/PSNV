import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_preview.dart';

/// Thẻ preview nhãn: header (PART CARD · loại tem · trạng thái) + nhãn giấy.
///
/// Dùng chung cho màn in mới và màn Sửa / Tách / Gộp.
class PartCardPreviewCard extends StatelessWidget {
  const PartCardPreviewCard({
    super.key,
    required this.form,
    required this.mode,
    required this.status,
    this.success = false,
  });

  final PartCardForm form;
  final PartCardMode mode;

  /// Chữ bên phải header (vd "Chờ in", "Đã in", "2/3").
  final String status;

  /// Tô [status] màu success.
  final bool success;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            decoration: BoxDecoration(
              color: swms.card2,
              borderRadius: const BorderRadius.vertical(
                top: Radius.circular(AppDimens.rCard),
              ),
              border: Border(bottom: BorderSide(color: swms.border)),
            ),
            child: Row(
              children: [
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: 7,
                    vertical: 3,
                  ),
                  decoration: BoxDecoration(
                    color: swms.success,
                    borderRadius: BorderRadius.circular(6),
                  ),
                  child: Text(
                    'PART CARD',
                    style: AppTextStyles.caption.copyWith(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: .5,
                    ),
                  ),
                ),
                const SizedBox(width: 6),
                Text(
                  (mode.isMulti
                          ? LocaleKeys.part_card_mode_multi.tr()
                          : LocaleKeys.part_card_mode_single.tr())
                      .toUpperCase(),
                  style: AppTextStyles.caption.copyWith(
                    fontSize: 9,
                    fontWeight: FontWeight.w800,
                    letterSpacing: .5,
                    color: swms.text3,
                  ),
                ),
                const Spacer(),
                Text(
                  status,
                  style: AppTextStyles.caption.copyWith(
                    fontWeight: FontWeight.w700,
                    color: success ? swms.success : swms.text3,
                  ),
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.all(16),
            child: PartCardPreview(form: form, mode: mode),
          ),
        ],
      ),
    );
  }
}
