# feature `pallet` — gộp pallet_detail + storing + temp_location + warehouse_move

```
lib/features/pallet/
├─ domain/
│  ├─ entities/pallet_entities.dart      Pallet · PalletAction · PalletInclude · LocatorSuggestion · PalletBox…
│  ├─ entities/pallet_results.dart       SplitResult · LocatorChangeResult
│  └─ repositories/pallet_repository.dart
├─ data/
│  ├─ datasources/pallet_remote_data_source.dart   5 API (1 GET by-lot-no + split + PUT/DELETE locator + PUT storing)
│  ├─ models/pallet_model.dart           PalletModel (+ suggestedLocator) — cấu trúc chuẩn PalletDetailResponse
│  ├─ models/locator_models.dart         LocatorRequestModel · LocatorChangeResponseModel (dùng chung locator + storing)
│  ├─ models/split_models.dart
│  └─ pallet_repository_impl.dart
└─ presentation/
   ├─ providers/
   │  ├─ pallet_providers.dart           DI + palletProvider(lotNo)  (include = boxes,history)
   │  ├─ pallet_flow.dart                enum PalletFlow: tempLocation | storing | warehouseMove
   │  ├─ pallet_flow_state.dart
   │  ├─ pallet_flow_notifier.dart       palletFlowProvider(flow) — BaseNotifierMixin.executePartial cho lookup
   │  ├─ find_missing_notifier.dart      findMissingProvider(lotNo)
   │  └─ split_notifier.dart             splitProvider(lotNo)
   ├─ pages/
   │  ├─ pallet_detail_page.dart         @RoutePage PalletDetailScreen
   │  ├─ pallet_flow_page.dart           widget dùng chung (không phải route)
   │  ├─ temp_location_page.dart         @RoutePage TempLocationScreen  → PalletFlowPage(tempLocation)
   │  ├─ storing_page.dart               @RoutePage StoringScreen       → PalletFlowPage(storing)
   │  ├─ warehouse_move_page.dart        @RoutePage WarehouseMoveScreen → PalletFlowPage(warehouseMove)
   │  ├─ find_missing_box_page.dart      @RoutePage FindMissingBoxScreen (chỉ nhận lotNo)
   │  └─ split_pallet_page.dart          @RoutePage SplitPalletScreen    (chỉ nhận lotNo)
   └─ widgets/
      ├─ detail/  pallet_info_card · pallet_action_list · pallet_box_list · pallet_history_timeline
      └─ flow/    pallet_flow_pallet_card · pallet_flow_scan_body · pallet_flow_action_body
   └─ utils/pallet_i18n.dart          enum ↔ LocaleKeys (labelKey/submitKey/scanLocatorKey,
                                      titleKey/subtitleKey, palletAreaLabel, palletStatusLabel)
```

## Điểm thay đổi chính

| Trước | Sau |
|---|---|
| 3 endpoint GET riêng (`/location`, `/storing`, `by-lot-no`) + 3 entity (`LotLocationInfo`, `StoringPalletInfo`, `MovePalletInfo`) | 1 endpoint `by-lot-no/{lotNo}?include=…` + 1 entity `Pallet` |
| `allowedActions: List<String>` | `List<PalletAction>` (assign / release / move / store), mã lạ bị bỏ |
| `StoringResult` + `LocatorChangeResult` + `WarehouseMoveResult` | 1 `LocatorChangeResult` (`isRelease`, `hasWarning`) |
| 3 notifier + 3 state + 3 bộ widget gần giống nhau | 1 `PalletFlowNotifier` family theo `PalletFlow`, 1 body chung; khác nhau chỉ ở `flow.include` và `flow.actionsFor()` |
| Storing luôn cho submit | Storing chỉ có nút khi server trả `store` trong `allowedActions` (pallet đang ở khu vị trí tạm) — không tự suy nữa |
| `BaseNotifierMixin` được mixin nhưng không dùng | `executePartial` cập nhật `state.pallet: AsyncValue<Pallet?>` → bước 1 hiện loading / lỗi inline + nút thử lại. Mutation vẫn qua `appActionProvider`. |
| Route Tìm thùng / Tách nhận `boxes` | Chỉ nhận `lotNo`; notifier đọc thùng từ `palletProvider(lotNo)` (đã cache bởi Detail) và tự `invalidate` sau khi tách / lưu kho |

## Các bước migrate

1. Copy thư mục `pallet/` vào `lib/features/pallet/`, xoá 4 feature cũ
   (`pallet_detail`, `storing`, `temp_location`, `warehouse_move`).
2. `core/router/app_router.dart`: sửa import của `PalletDetailScreen`, `TempLocationScreen`,
   `StoringScreen`, `WarehouseMoveScreen`, `FindMissingBoxScreen`, `SplitPalletScreen`
   sang `features/pallet/presentation/pages/...`. Tên route giữ nguyên.
3. **i18n — gộp 6 namespace thành 1 `pallet`.** Dùng `en.json` kèm theo:
   xoá `pallet_detail`, `split`, `find_missing`, `storing`, `temp_location`,
   `warehouse_move` ở cấp gốc; thêm khối `pallet` gồm `detail` · `flow` ·
   `split` · `find_missing` · `temp_location` · `storing` · `warehouse_move`.
   Vì `pallet.detail.title` sinh ra đúng `LocaleKeys.pallet_detail_title` như cũ
   nên toàn bộ LocaleKeys của màn Detail **không đổi tên**.

   Với vi/ja/zh, chép giá trị cũ sang vị trí mới theo bảng:

   | key mới (`pallet.…`) | lấy từ key cũ |
   |---|---|
   | `detail.*` | `pallet_detail.*` (nguyên xi) |
   | `split.*` | `split.*` (bỏ `split.error`) |
   | `find_missing.*` | `find_missing.*` |
   | `temp_location.title/subtitle` | `temp_location.title/subtitle` |
   | `storing.title/subtitle` | `storing.title/subtitle` |
   | `warehouse_move.title/subtitle` | `warehouse_move.title/subtitle` |
   | `flow.step_scan` / `step_action` | `warehouse_move.step_scan` / `step_action` |
   | `flow.scan_pallet_label` / `_on_label` | `warehouse_move.*` cùng tên |
   | `flow.scan_pallet_hint` / `_to_start` | `storing.*` cùng tên |
   | `flow.urgent` / `total_qty` | `storing.*` cùng tên |
   | `flow.qty_value` / `box_count` / `current_location` / `no_location` | `temp_location.*` cùng tên |
   | `flow.choose_action` | `warehouse_move.choose_action` |
   | `flow.action_assign/release/move` | `temp_location.action_*` |
   | `flow.action_store` | `storing.title` |
   | `flow.scan_locator_assign/move` | `temp_location.*` cùng tên |
   | `flow.scan_locator_store` | `storing.scan_locator` |
   | `flow.scan_locator_label` / `target_location` / `rescan` / `release_hint` / `location_word` | `temp_location.*` cùng tên |
   | `flow.suggested_location` / `scan_to_confirm` / `mismatch_hint` | `storing.*` cùng tên |
   | `flow.submit_assign/release/move` | `temp_location.submit_*` |
   | `flow.submit_store` | `storing.submit_store` |
   | `flow.done_to` / `done_release` | `temp_location.assigned_msg` / `released_msg` |
   | `flow.area.*` | `temp_location.area.*` |

   Bảy key **phải dịch mới**: `flow.load_error`, `flow.no_action_hint`,
   `split.load_error`, `find_missing.load_error`, `detail.act_warehouse_move`,
   `detail.act_warehouse_move_sub`, `detail.status.stored`.

   Lưu ý khi chép từ `warehouse_move.*`: các câu ở đó dùng placeholder `{0}`/`{1}`
   — easy_localization chỉ thay `{}` theo thứ tự với `args:`, nên phải đổi thành `{}`.
4. Hai màn `find_missing_box_page.dart` / `split_pallet_page.dart` đã được viết lại
   trong feature này: route bỏ tham số `boxes`, chỉ còn `lotNo`. Nơi gọi
   (`pallet_detail_page`) đã sửa sẵn; nếu còn chỗ khác push 2 route này thì bỏ `boxes`.
   Giữ nguyên namespace i18n `split.*` / `find_missing.*`, chỉ thêm 2 key `*.load_error`.
5. `dart run build_runner build -d` để sinh lại `*.g.dart`
   (json_serializable, retrofit, riverpod) và `app_router.gr.dart`.

## Giả định cần kiểm tra

- `AppException` có getter `message` (dùng ở `pallet_flow_page._errorMessage`).
- `appActionProvider.notifier.run(...)` trả `null` khi lỗi và đã tự toast (như code cũ).
- Server trả `allowedActions` đầy đủ (kể cả `store`) ở `by-lot-no` — nếu chưa,
  `PalletFlow.storing.actionsFor` sẽ trả rỗng và màn Lưu kho không có nút xác nhận.
