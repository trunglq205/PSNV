import 'package:swms_finish_goods/core/utils/app_local_storage.dart';
import 'package:swms_finish_goods/features/receiving/data/models/receiving_history_model.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_history_entry.dart';

abstract final class ReceivingHistoryKeys {
  static const draft = 'receiving.history.draft';
}

abstract interface class ReceivingHistoryLocalDataSource {
  ReceivingHistoryEntry? read();
  Future<void> write(ReceivingHistoryEntry entry);
  Future<void> clear();
}

class ReceivingHistoryLocalDataSourceImpl
    implements ReceivingHistoryLocalDataSource {
  final AppLocalStorage _storage;

  const ReceivingHistoryLocalDataSourceImpl(this._storage);

  @override
  ReceivingHistoryEntry? read() {
    final raw = _storage.readString(ReceivingHistoryKeys.draft);
    if (raw == null) return null;
    return ReceivingHistoryCodec.decode(raw);
  }

  @override
  Future<void> write(ReceivingHistoryEntry entry) {
    // Luôn ghi đè — chỉ giữ 1 bản nháp gần nhất.
    return _storage.writeString(
      ReceivingHistoryKeys.draft,
      ReceivingHistoryCodec.encode(entry),
    );
  }

  @override
  Future<void> clear() => _storage.remove(ReceivingHistoryKeys.draft);
}