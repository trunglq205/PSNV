import 'dart:typed_data';

import 'package:swms_finish_goods/core/utils/printing/printer.dart';

/// Ký tự điều khiển của giao thức SBPL.
class Sbpl {
  Sbpl._();

  static const stx = '\x02';
  static const etx = '\x03';
  static const esc = '\x1B';

  /// ESC Q\<n> — số bản in.
  static String quantity(int copies) => '${esc}Q$copies';

  /// ESC Z — kết thúc block.
  static const end = '${esc}Z';
}

int placeholderCount(String template) =>
    RegExp('%s').allMatches(template).length;

/// Thay lần lượt từng `%s` trong [template] bằng [values].
///
/// Số lượng phải khớp tuyệt đối — lệch một cái là cả nhãn sai vị trí,
/// nên fail sớm thay vì in ra tem rác.
String buildSbpl(String template, List<String> values) {
  final expected = placeholderCount(template);
  if (values.length != expected) {
    throw PrinterException(
      PrinterErrorType.invalidData,
      message: 'Template cần $expected giá trị, nhận được ${values.length}',
    );
  }
  var i = 0;
  return template.replaceAllMapped(
    RegExp('%s'),
        (_) => sanitizeSbplValue(values[i++]),
  );
}

/// Bỏ ký tự điều khiển (ESC/STX/ETX sẽ phá cấu trúc lệnh) và dấu phẩy
/// (dấu phân cách tham số SBPL).
String sanitizeSbplValue(String value) =>
    value.replaceAll(RegExp(r'[\u0000-\u001F\u007F]'), '');

/// Cặp `length,data` cho lệnh QR dạng `DN%s,%s`.
///
/// Độ dài phải tính TRÊN CHUỖI ĐÃ SANITIZE, vì [buildSbpl] cũng sanitize
/// data trước khi chèn — nếu tính trên chuỗi gốc, máy in sẽ đọc lệch byte.
List<String> qrPair(String data) {
  final clean = sanitizeSbplValue(data);
  return [clean.length.toString().padLeft(4, '0'), clean];
}

/// SBPL là byte stream 1 byte/ký tự — chặn sớm ký tự ngoài Latin-1
/// (tiếng Việt có dấu, emoji...) vì máy in sẽ in ra rác.
Uint8List encodeSbpl(String data) {
  final units = data.codeUnits;
  final bad = units.where((u) => u > 0xFF);
  if (bad.isNotEmpty) {
    throw const PrinterException(
      PrinterErrorType.invalidData,
      message: 'Dữ liệu chứa ký tự ngoài phạm vi 1 byte (cần bỏ dấu)',
    );
  }
  return Uint8List.fromList(units);
}