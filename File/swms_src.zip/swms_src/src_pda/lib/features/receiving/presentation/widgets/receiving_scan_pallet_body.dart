import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/common/printer_status_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_radio_card_group.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/receiving_state.dart';

/// Bước 3: Pallet ID — quét nhãn có sẵn hoặc tự in nhãn mới.
///
/// PAP không có lựa chọn: lotNo luôn do server cấp, giá trị quét là mã stocky.
class ReceivingScanPalletBody extends StatelessWidget {
  const ReceivingScanPalletBody({
    super.key,
    required this.lotId,
    required this.isPap,
    required this.source,
    required this.onSourceChanged,
    required this.printer,
    required this.onChangePrinter,
  });

  /// Giá trị đã quét (Pallet ID, hoặc mã stocky với PAP).
  final String? lotId;
  final bool isPap;
  final PalletIdSource source;
  final ValueChanged<PalletIdSource> onSourceChanged;

  /// Máy in đang chọn — chỉ dùng khi tự in nhãn.
  final PrinterDevice? printer;

  /// Null = khoá (đang tạo / in).
  final VoidCallback? onChangePrinter;

  @override
  Widget build(BuildContext context) {
    final scanned = lotId;
    final printNew = !isPap && source == PalletIdSource.printNew;

    return ListView(
      padding: const EdgeInsets.only(top: AppDimens.sm),
      children: [
        if (!isPap) ...[
          _SectionLabel('receiving.pallet_source_label'.tr()),
          AppRadioCardGroup<PalletIdSource>(
            value: source,
            onChanged: onSourceChanged,
            items: [
              RadioCardItem(
                value: PalletIdSource.scanExisting,
                title: 'receiving.pallet_source_scan_title'.tr(),
                subtitle: 'receiving.pallet_source_scan_sub'.tr(),
                icon: Icons.qr_code_scanner_rounded,
              ),
              RadioCardItem(
                value: PalletIdSource.printNew,
                title: 'receiving.pallet_source_print_title'.tr(),
                subtitle: 'receiving.pallet_source_print_sub'.tr(),
                icon: Icons.print_rounded,
              ),
            ],
          ),
          const SizedBox(height: AppDimens.md),
        ],
        if (printNew) ...[
          _SectionLabel('receiving.printer_section'.tr()),
          PrinterStatusBar(device: printer, onChange: onChangePrinter),
        ] else if (scanned != null) ...[
          _PalletIdView(palletId: scanned),
          const SizedBox(height: AppDimens.sm),
          Text(
            'receiving.rescan_to_replace'.tr(),
            textAlign: TextAlign.center,
            style: AppTextStyles.caption.copyWith(color: context.swms.text4),
          ),
        ] else
          BarcodeScannerButton(
            scanningLabel: LocaleKeys.receiving_scan_pallet_hint.tr(),
          ),
        const SizedBox(height: AppDimens.md),
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.sm),
      child: Text(
        text,
        style: AppTextStyles.label.copyWith(
          fontWeight: FontWeight.w700,
          color: context.swms.text3,
        ),
      ),
    );
  }
}

/// Hiển thị Pallet ID đã quét.
class _PalletIdView extends StatelessWidget {
  const _PalletIdView({required this.palletId});

  final String palletId;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      child: Column(
        crossAxisAlignment: .start,
        mainAxisSize: .min,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'PALLET ID',
                  style: AppTextStyles.caption.copyWith(
                    fontSize: 10.5,
                    fontWeight: FontWeight.w700,
                    letterSpacing: .6,
                    color: swms.text3,
                  ),
                ),
              ),
              StatusPill.success(
                context,
                label: LocaleKeys.receiving_scanned.tr(),
                icon: Icons.check_rounded,
              ),
            ],
          ),
          const Divider(),
          Text(
            palletId,
            style: AppTextStyles.code.copyWith(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              letterSpacing: .5,
              color: swms.text1,
            ),
          ),
        ],
      ),
    );
  }
}