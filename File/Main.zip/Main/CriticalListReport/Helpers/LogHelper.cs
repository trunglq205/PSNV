﻿namespace CriticalListReport.Helpers
{
    public static class LogHelper
    {
        private static readonly object _lock = new object();

        public static string LogFolder => Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Logs");

        public static void WriteError(Exception ex, string context)
        {
            try
            {
                if (!Directory.Exists(LogFolder))
                    Directory.CreateDirectory(LogFolder);

                var fileName = $"error-{DateTime.Now:yyyy-MM-dd}.txt";
                var filePath = Path.Combine(LogFolder, fileName);

                var message = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [{context}]{Environment.NewLine}" +
                              $"Type: {ex.GetType().Name}{Environment.NewLine}" +
                              $"Message: {ex.Message}{Environment.NewLine}" +
                              $"Inner: {ex.InnerException?.Message}{Environment.NewLine}" +
                              $"StackTrace: {ex.StackTrace}{Environment.NewLine}" +
                              $"========================================{Environment.NewLine}";

                lock (_lock)
                {
                    File.AppendAllText(filePath, message);
                }
            }
            catch { }
        }
    }
}