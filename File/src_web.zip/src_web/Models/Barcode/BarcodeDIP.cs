﻿namespace SWMS_WebTool.Models.Barcode
{
    public class BarcodeDIP
    {
        public string Model { get; set; }
        public string Material { get; set; }
        public string Line { get; set; }
        public double Quantity { get; set; }
        public string Position { get; set; }
        public string Sloc { get; set; }
        public string ProductDate { get; set; }
        public string Plant { get; set; }
        public string Time { get; set; }
        public string SlocDIP { get; set; }
        public string UploadNo { get; set; }
        public string Category { get; set; }
        public string CategoryJT { get; set; }
        public string R { get; set; } = "RDIP";
        public string Kitting { get; set; } = "KittingList";
    }
}
