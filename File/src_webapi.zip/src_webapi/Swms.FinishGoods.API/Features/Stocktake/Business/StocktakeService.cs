using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Stocktake.Api;
using Swms.FinishGoods.API.Features.Stocktake.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.Reporting;

namespace Swms.FinishGoods.API.Features.Stocktake.Business;

public class StocktakeService : IStocktakeService
{
    private readonly IStocktakeRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly IExcelReportBuilder _excel;

    public StocktakeService(
        IStocktakeRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        IExcelReportBuilder excel)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
        _excel = excel;
    }

    public async Task<IReadOnlyList<CountSummaryResponse>> GetCountsAsync(string? type, string? status, DateTime? from, DateTime? to)
    {
        var rows = await _repo.GetCountsAsync(type, status, from, to);
        return rows.Select(CountSummaryResponse.From).ToList();
    }

    public async Task<CountDetailResponse> GetCountAsync(long id)
    {
        var d = await _repo.GetCountAsync(id)
                ?? throw new NotFoundException(_localizer["Stocktake.Err.CountNotFound"]);
        return new CountDetailResponse(
            CountSummaryResponse.From(d.Header),
            d.Lines.Select(CountLineResponse.From).ToList());
    }

    public async Task<CountPreviewResponse> PreviewAsync(string type, IReadOnlyList<string>? areaCodes)
    {
        var t = (type ?? string.Empty).Trim().ToLowerInvariant();
        if (t != "morning" && t != "monthly")
            throw new BusinessRuleException(_localizer["Stocktake.Err.TypeNotSupported"]);
        var areas = await NormalizeAreasAsync(t, areaCodes);
        var (loc, line) = await _repo.PreviewAsync(t, areas);
        return new CountPreviewResponse(t, loc, line);
    }

    /// <summary>
    /// Phiếu sáng luôn quét mọi bản đồ lưu kho nên bỏ qua lựa chọn bản đồ.
    /// Phiếu tháng: rỗng = mọi bản đồ lưu kho; có chọn thì từng mã phải là bản đồ lưu kho.
    /// </summary>
    private async Task<IReadOnlyList<string>?> NormalizeAreasAsync(string type, IReadOnlyList<string>? areaCodes)
    {
        if (type == "morning" || areaCodes is null) return null;

        var picked = areaCodes
            .Select(c => (c ?? string.Empty).Trim())
            .Where(c => c.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (picked.Count == 0) return null;   // không chọn gì = tất cả

        var storing = await _repo.GetStoringAreaCodesAsync();
        var bad = picked.FirstOrDefault(c => !storing.Contains(c, StringComparer.OrdinalIgnoreCase));
        if (bad is not null)
            throw new BusinessRuleException(_localizer["Stocktake.Err.AreaNotStoring", bad]);

        // chọn hết cũng coi như "tất cả" cho câu lệnh gọn
        return picked.Count == storing.Count ? null : picked;
    }

    public async Task<CreateCountResult> CreateAsync(CreateCountRequest request)
    {
        var type = (request.CountType ?? string.Empty).Trim().ToLowerInvariant();
        if (type != "morning" && type != "monthly")
            throw new BusinessRuleException(_localizer["Stocktake.Err.TypeNotSupported"]);
        var areas = await NormalizeAreasAsync(type, request.AreaCodes);
        return await _repo.CreateAsync(type, areas, request.Description, _currentUser.UserId);
    }

    public Task CloseAsync(long id) => _repo.CloseAsync(id, _currentUser.UserId);

    /// <summary>Ghi pallet phát sinh: quét được pallet ở một ô mà hệ thống không ghi nó ở đó.</summary>
    public async Task<AddFoundResponse> AddFoundAsync(long countId, AddFoundRequest request)
    {
        var code = (request.PalletId ?? string.Empty).Trim();
        if (code.Length == 0)
            throw new BusinessRuleException(_localizer["Stocktake.Err.PalletRequired"]);

        try
        {
            var r = await _repo.AddFoundAsync(countId, request.LocatorId, code, _currentUser.UserId);
            return new AddFoundResponse(r.LineId, r.Created);
        }
        catch (KeyNotFoundException)
        {
            throw new NotFoundException(_localizer["Stocktake.Err.PalletNotFound", code]);
        }
        catch (InvalidOperationException ex) when (ex.Message == "CountNotFound")
        {
            throw new NotFoundException(_localizer["Stocktake.Err.CountNotFound"]);
        }
        catch (InvalidOperationException ex) when (ex.Message is "CountClosed" or "LocatorNotInCount" or "PalletAlreadyFound")
        {
            throw new BusinessRuleException(_localizer[$"Stocktake.Err.{ex.Message}", code]);
        }
    }

    public async Task SetNoteAsync(long lineId, SetNoteRequest request)
    {
        var ok = await _repo.SetNoteAsync(lineId, request.Note, _currentUser.UserId);
        if (!ok) throw new BusinessRuleException(_localizer["Stocktake.Err.CountClosed"]);
    }

    public async Task SetCountAsync(long lineId, SetCountRequest request)
    {
        if (request.QtyCount < 0)
            throw new BusinessRuleException(_localizer["Stocktake.Err.InvalidQty"]);
        try
        {
            await _repo.SetCountAsync(lineId, request.QtyCount, request.Note,
                request.BoxCountCounted, _currentUser.UserId);
        }
        catch (InvalidOperationException ex) when (ex.Message == "EmptySlotQty")
        {
            throw new BusinessRuleException(_localizer["Stocktake.Err.EmptySlotQty"]);
        }
    }

    // ===================== BÁO CÁO EXCEL =====================
    private sealed record ReportRow(
        int LineNo, string Rack, string Locator, string Product, string? PalletId,
        int QtySystem, int? QtyCount, int? Delta, string Status, string? Note);

    public async Task<(byte[] Bytes, string FileName)> BuildReportAsync(long id)
    {
        var d = await _repo.GetCountAsync(id)
                ?? throw new NotFoundException(_localizer["Stocktake.Err.CountNotFound"]);

        string L(string key) => _localizer[key];
        string TypeLabel(string? t) => t switch
        {
            "morning" => L("Stocktake.TypeMorning"),
            "monthly" => L("Stocktake.TypeMonthly"),
            "shipment" => L("Stocktake.TypeShipment"),
            _ => t ?? string.Empty
        };
        string StatusLabel(string s) => s switch
        {
            "pending" => L("Stocktake.StatusPending"),
            "counting" => L("Stocktake.StatusCounting"),
            "closed" => L("Stocktake.StatusClosed"),
            _ => s
        };
        static string Rack(string code) { var i = code.IndexOf('-'); return i > 0 ? code[..i] : code; }
        static string F(int v) => v.ToString(System.Globalization.CultureInfo.InvariantCulture);

        var rows = d.Lines.Select(l =>
        {
            int? delta = l.QtyCount is null ? null : l.QtyCount.Value - l.QtySystem;
            var status = l.QtyCount is null
                ? L("Stocktake.LineWait")
                : (delta == 0 ? "OK" : L("Stocktake.LineDiff"));
            string? note = null;
            if (l.QtyCount is not null && delta is not null && delta != 0)
                note = delta < 0
                    ? string.Format(L("Stocktake.NoteShort"), F(-delta.Value))
                    : string.Format(L("Stocktake.NoteOver"), F(delta.Value));
            if (l.IsFound)   // pallet phát sinh: ghi rõ hệ thống đang ghi nó ở đâu
            {
                var found = string.Format(L("Stocktake.NoteFound"), l.SystemLocatorCode ?? "—");
                note = note is null ? found : $"{found}; {note}";
            }
            var product = l.LotId is null
                ? L("Stocktake.EmptySlot")   // dòng ô trống (kiểm cuối tháng theo ô)
                : l.Model ?? l.ProductName ?? l.ProductId.ToString();
            return new ReportRow(l.LineNo, Rack(l.LocatorCode), l.LocatorCode,
                product, l.PalletId,
                l.QtySystem, l.QtyCount, delta, status, note);
        }).ToList();

        var counted = d.Lines.Count(x => x.QtyCount != null);
        var match = d.Lines.Count(x => x.QtyCount != null && x.QtyCount.Value == x.QtySystem);
        var disc = d.Lines.Count(x => x.QtyCount != null && x.QtyCount.Value != x.QtySystem);

        var report = new ExcelTableReport<ReportRow>
        {
            SheetName = d.Header.DocNo,
            Title = L("Stocktake.ReportTitle"),
            Meta = new List<(string, string)>
            {
                (L("Stocktake.DocNo"), d.Header.DocNo),
                (L("Stocktake.Type"), TypeLabel(d.Header.CountType)),
                (L("Stocktake.Date"), d.Header.CountDate.ToString("dd/MM/yyyy")),
                (L("Stocktake.Status"), StatusLabel(d.Header.DocStatus)),
                (L("Stocktake.ScopeWord"), $"{d.Lines.Count} {L("Stocktake.PalletsWord")}"),
                (L("Stocktake.Description"), d.Header.Description ?? string.Empty),
            },
            Summary = new List<(string, string)>
            {
                (L("Stocktake.LineCount"), d.Lines.Count.ToString()),
                (L("Stocktake.Counted"), counted.ToString()),
                (L("Stocktake.KpiMatch"), match.ToString()),
                (L("Stocktake.Discrepancy"), disc.ToString()),
            },
            Columns = new List<ReportColumn<ReportRow>>
            {
                new() { Header = "STT", Value = r => r.LineNo, Numeric = true },
                new() { Header = "Rack", Value = r => r.Rack },
                new() { Header = L("Stocktake.Location"), Value = r => r.Locator },
                new() { Header = L("Stocktake.Product"), Value = r => r.Product },
                new() { Header = L("Stocktake.PalletId"), Value = r => r.PalletId },
                new() { Header = L("Stocktake.QtySystem"), Value = r => r.QtySystem, Numeric = true },
                new() { Header = L("Stocktake.QtyCount"), Value = r => r.QtyCount, Numeric = true },
                new() { Header = L("Stocktake.Delta"), Value = r => r.Delta, Numeric = true },
                new() { Header = L("Stocktake.Status"), Value = r => r.Status },
                new() { Header = L("Stocktake.NoteCol"), Value = r => r.Note },
            },
            Rows = rows,
        };

        var bytes = _excel.BuildTable(report);
        return (bytes, $"{d.Header.DocNo}.xlsx");
    }
}
