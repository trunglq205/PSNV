import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';

// ─────────────────────────────────────────────────────────────
//  ĐẶT XE VÀO Ô — đọc / ghi JSON, VIẾT TAY (17/11)
//
//  Vì sao không dùng json_serializable như `stocky_cart_model.dart`:
//  `build_runner` trong source hiện tại đang vỡ (hai file cùng khai
//  `@RoutePage() class VanningPage`), nên không sinh được `.g.dart` mới. Cả bộ
//  mục 2c/2d trước đó cũng theo cách này.
//
//  Khoá JSON camelCase: API dùng JsonNamingPolicy.CamelCase mặc định của
//  ASP.NET, nên record `StockyPlaceResponse(string Code, …)` ra `code`,
//  `locatorCode`, `areaCode`, `lotCount`.
// ─────────────────────────────────────────────────────────────

/// Thân request của `POST /api/stocky-carts/place`.
class StockyPlaceRequestModel {
  const StockyPlaceRequestModel({
    required this.code,
    required this.locatorCode,
  });

  final String code;
  final String locatorCode;

  Map<String, dynamic> toJson() => {
        'code': code,
        'locatorCode': locatorCode,
      };
}

int _int(Object? v, [int fallback = 0]) => switch (v) {
      int i => i,
      double d => d.round(),
      num n => n.round(),
      String s => int.tryParse(s) ?? fallback,
      _ => fallback,
    };

String? _str(Object? v) {
  if (v == null) return null;
  final s = v.toString().trim();
  return s.isEmpty ? null : s;
}

/// Đọc kết quả một lượt đặt xe. Chịu được trường thiếu / sai kiểu: vỡ parse
/// giữa lúc người ta đang đứng kho đẩy xe là mất cả lượt làm, trong khi thứ
/// cần biết chỉ là "xe đã vào ô nào".
StockyPlaceResult stockyPlaceResultFromJson(Object? json) {
  final m = json is Map ? json : const {};
  return StockyPlaceResult(
    code: _str(m['code']) ?? '',
    locatorCode: _str(m['locatorCode']) ?? '',
    areaCode: _str(m['areaCode']),
    lotCount: _int(m['lotCount']),
  );
}
