import 'package:swms_finish_goods/features/scan/data/datasources/scan_remote_data_source.dart';
import 'package:swms_finish_goods/features/scan/domain/entities/scan_result.dart';
import 'package:swms_finish_goods/features/scan/domain/repositories/scan_repository.dart';

class ScanRepositoryImpl implements ScanRepository {
  final ScanRemoteDataSource _remote;
  const ScanRepositoryImpl(this._remote);

  @override
  Future<ScanResult> resolve(String code) async {
    final res = await _remote.resolve(code.trim());
    return res.toEntity();
  }
}
