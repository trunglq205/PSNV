import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Công tắc bật/tắt kiểu pill, nhãn nằm ĐỐI DIỆN núm.
///
/// ```
///  ( ) 1 MÃ            NHIỀU MÃ ( )
///   tắt                     bật
/// ```
///
/// Nhãn mô tả **trạng thái hiện tại** (giống OFF/ON), không phải hành động —
/// người dùng nhìn là biết đang ở đâu, không phải đoán.
///
/// Bề rộng tính theo nhãn DÀI NHẤT trong hai trạng thái nên không bị giật khi
/// bật/tắt. Bỏ [onLabel]/[offLabel] thì thành công tắc trơn.
class AppToggleSwitch extends StatelessWidget {
  const AppToggleSwitch({
    super.key,
    required this.value,
    required this.onChanged,
    this.onLabel,
    this.offLabel,
    this.enabled = true,
    this.height = 28,
    this.activeColor,
  });

  final bool value;

  /// `null` = khoá (cũng có thể dùng [enabled]).
  final ValueChanged<bool>? onChanged;

  final String? onLabel;
  final String? offLabel;

  final bool enabled;
  final double height;

  /// Màu nền khi bật. Mặc định `swms.primary`.
  final Color? activeColor;

  static const Duration _duration = Duration(milliseconds: 180);

  bool get _interactive => enabled && onChanged != null;

  double _measure(BuildContext context, String? text, TextStyle style) {
    if (text == null || text.isEmpty) return 0;
    final painter = TextPainter(
      text: TextSpan(text: text, style: style),
      textDirection: TextDirection.ltr,
      textScaler: MediaQuery.textScalerOf(context),
    )..layout();
    return painter.width;
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final labelStyle = AppTextStyles.caption.copyWith(
      fontSize: 10,
      fontWeight: FontWeight.w800,
      letterSpacing: .3,
    );

    final knob = height - 6;
    final label = value ? onLabel : offLabel;

    // Chốt bề rộng theo nhãn dài nhất → đổi trạng thái không đổi kích thước.
    final labelWidth = [
      _measure(context, onLabel, labelStyle),
      _measure(context, offLabel, labelStyle),
    ].reduce((a, b) => a > b ? a : b);

    final gap = labelWidth == 0 ? 0.0 : labelWidth + 14;
    final width = 3 + knob + 3 + gap;

    return Opacity(
      opacity: _interactive ? 1 : .45,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: _interactive ? () => onChanged!(!value) : null,
        child: AnimatedContainer(
          duration: _duration,
          curve: Curves.easeOut,
          width: width,
          height: height,
          padding: const EdgeInsets.all(3),
          decoration: BoxDecoration(
            color: value ? (activeColor ?? swms.primary) : swms.card2,
            borderRadius: BorderRadius.circular(height),
            border: Border.all(
              color: value
                  ? (activeColor ?? swms.primary)
                  : swms.border,
            ),
          ),
          child: Stack(
            children: [
              if (label != null && label.isNotEmpty)
                AnimatedAlign(
                  duration: _duration,
                  curve: Curves.easeOut,
                  alignment: value
                      ? Alignment.centerLeft
                      : Alignment.centerRight,
                  child: Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 7),
                    child: Text(
                      label,
                      style: labelStyle.copyWith(
                        color: value ? Colors.white : swms.text3,
                      ),
                    ),
                  ),
                ),
              AnimatedAlign(
                duration: _duration,
                curve: Curves.easeOut,
                alignment: value
                    ? Alignment.centerRight
                    : Alignment.centerLeft,
                child: Container(
                  width: knob,
                  height: knob,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.white,
                    border: value ? null : Border.all(color: swms.border),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withValues(alpha: .12),
                        blurRadius: 2,
                        offset: const Offset(0, 1),
                      ),
                    ],
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
