﻿using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Api.Features.Categories.Api;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.Api.Features.Categories.Business;

public class CategoryService : ICategoryService
{
    private readonly ICategoryRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public CategoryService(
        ICategoryRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    public async Task<List<CategoryResponse>> GetAllAsync(CategoryQuery query)
    {
        query.Code = Norm(query.Code);
        query.Name = Norm(query.Name);
        query.PlantCode = Norm(query.PlantCode);
        query.Product = Norm(query.Product);

        var items = await _repo.GetAllAsync(query);
        return items.Select(CategoryResponse.From).ToList();
    }

    public async Task<List<CategoryOptionResponse>> GetOptionsAsync()
    {
        var items = await _repo.GetAllAsync(new CategoryQuery());
        return items.Select(CategoryOptionResponse.From).ToList();
    }

    public async Task<CategoryResponse> GetByCodeAsync(int code)
    {
        var entity = await _repo.GetByCodeAsync(code);
        if (entity is null)
            throw new NotFoundException(_localizer["Categories.NotFound", code]);

        return CategoryResponse.From(entity);
    }

    public async Task<CategoryResponse> CreateAsync(CreateCategoryRequest request)
    {
        var code = request.Code;

        // Check trùng business key
        if (await _repo.CodeExistsAsync(code))
            throw new ConflictException(_localizer["Categories.CodeExists", code]);

        var entity = BuildEntity(request, code);
        entity.CreatedBy = _currentUser.FullName;
        await _repo.AddAsync(entity);

        return await GetByCodeAsync(code);
    }

    public async Task UpdateAsync(int code, UpdateCategoryRequest request)
    {
        var existing = await _repo.GetByCodeAsync(code);
        if (existing is null)
            throw new NotFoundException(_localizer["Categories.NotFound", code]);

        existing.Name = Norm(request.Name);
        existing.Description = Norm(request.Description);
        existing.Bd = Norm(request.Bd);
        existing.PlantCode = Norm(request.PlantCode);
        existing.Product = Norm(request.Product);
        existing.SlockPmd = Norm(request.SlockPmd);
        existing.SlockFa = Norm(request.SlockFa);
        existing.SlockScs = Norm(request.SlockScs);
        existing.SlockJpt = Norm(request.SlockJpt);
        existing.SlockPort = Norm(request.SlockPort);
        existing.ProductionVersion = Norm(request.ProductionVersion);
        existing.UpdatedBy = _currentUser.FullName;

        await _repo.UpdateAsync(existing);
    }

    public async Task DeleteAsync(int code)
    {
        var existing = await _repo.GetByCodeAsync(code);
        if (existing is null)
            throw new NotFoundException(_localizer["Categories.NotFound", code]);

        await _repo.SoftDeleteAsync(code, _currentUser.FullName);
    }

    // ── helpers ──────────────────────────────────────────────────────
    private static string? Norm(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private static CategoryEntity BuildEntity(CreateCategoryRequest r, int code) => new()
    {
        Code = code,
        Name = Norm(r.Name),
        Description = Norm(r.Description),
        Bd = Norm(r.Bd),
        PlantCode = Norm(r.PlantCode),
        Product = Norm(r.Product),
        SlockPmd = Norm(r.SlockPmd),
        SlockFa = Norm(r.SlockFa),
        SlockScs = Norm(r.SlockScs),
        SlockJpt = Norm(r.SlockJpt),
        SlockPort = Norm(r.SlockPort),
        ProductionVersion = Norm(r.ProductionVersion),
    };
}