﻿
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class KittingViewModel : TableViewModel<KittingReport, KittingFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, KittingFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Tab = filter?.Tab ?? Filter.Tab,
                ProDate = filter?.ProDate ?? Filter.ProDate,
                Cate = filter?.Cate ?? Filter.Cate,
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                FromSloc = filter?.FromSloc ?? Filter.FromSloc,
                PartNo = filter?.PartNo ?? Filter.PartNo,
                Reservation = filter?.Reservation ?? Filter.Reservation,
                Status = filter?.Status ?? Filter.Status,
                KittingDate = filter?.KittingDate ?? Filter.KittingDate,
                SubplyDate = filter?.SubplyDate ?? Filter.SubplyDate,
                FromTime = filter?.FromTime ?? Filter.FromTime,
                FinishTime = filter?.FinishTime ?? Filter.FinishTime,
                Quantity = filter?.Quantity ?? Filter.Quantity,
                KTFrom = filter?.KTFrom ?? Filter.KTFrom,
                UploadNo = filter?.UploadNo ?? Filter.UploadNo,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
