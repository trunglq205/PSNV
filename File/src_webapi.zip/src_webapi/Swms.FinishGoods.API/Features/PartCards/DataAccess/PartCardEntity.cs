namespace Swms.FinishGoods.API.Shared.Models;

// Entity ánh xạ wms.part_cards (1 phiếu Part Card đã in).
public class PartCard
{
    public long Id { get; set; }
    public string? PoNo { get; set; }
    public string? CustomerPoNo { get; set; }
    public DateTime ProductionDate { get; set; }
    public string? Packer { get; set; }
    public string? Checker { get; set; }
    public decimal? Length { get; set; }
    public decimal? Width { get; set; }
    public decimal? Height { get; set; }
    public decimal? Weight { get; set; }
    // Phân loại sản phẩm — mã số (110=DECT, 210=DP, ...).
    public int? Category { get; set; }
    public bool IsOverseaService { get; set; }
    public string? Model { get; set; }
    public int? Qty { get; set; }
    public string? Origin { get; set; }
    public DateTime PrintedAt { get; set; }
    public string? PrintedBy { get; set; }
    public string? Payload { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }

    // Khoá thủ công: phiếu đang khoá thì KHÔNG xoá được.
    // Khác với "khoá OQC" (Status_OQC <> 0) vốn chặn sửa — hai cơ chế độc lập.
    public bool IsLocked { get; set; }
    public DateTime? LockedAt { get; set; }
    public string? LockedBy { get; set; }

    public List<PartCardRow> Rows { get; set; } = new();

    // Tóm tắt lịch sử sửa / tách / gộp (wms.part_card_lineage). null = phiếu chưa qua
    // thao tác nào. Chỉ nạp ở màn danh sách / chi tiết, không lưu xuống DB.
    public PartCardChangeSummary? Changes { get; set; }
}

// Tóm tắt thay đổi của 1 phiếu — đủ để đánh dấu ở danh sách + CSV.
//   CreatedFrom   — "split" | "merge" khi phiếu SINH RA từ tách / gộp; null = in mới.
//   EditCount     — số lần sửa tại chỗ.
//   LastChangedAt — thời điểm thao tác gần nhất (UTC).
public record PartCardChangeSummary(string? CreatedFrom, int EditCount, DateTime LastChangedAt);

// Entity ánh xạ wms.part_card_rows (1 dòng hàng / inner box).
// Các field oversea (G21Part, InnerBox, dims, OqcChecked) chỉ có giá trị
// khi phiếu bật is_oversea_service; ngược lại null/0.
public class PartCardRow
{
    public long Id { get; set; }
    public long PartCardId { get; set; }
    public int LineNo { get; set; }
    public string? G21Part { get; set; }
    public string Model { get; set; } = "";
    public string? InnerBox { get; set; }
    public int Qty { get; set; }
    public string? Origin { get; set; }
    public bool OqcChecked { get; set; }

    // Kích thước / khối lượng inner box — cấp dòng (oversea).
    public decimal? InnerLength { get; set; }
    public decimal? InnerWidth { get; set; }
    public decimal? InnerHeight { get; set; }
    public decimal? InnerWeight { get; set; }
}