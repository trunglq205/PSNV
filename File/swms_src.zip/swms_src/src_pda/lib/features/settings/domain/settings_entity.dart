import 'package:swms_finish_goods/features/settings/domain/app_language.dart';

/// Trạng thái cài đặt người dùng (PDA).
class SettingsEntity {
  final AppLanguage language;
  final bool soundAlert;
  final bool pushNotify;

  const SettingsEntity({
    this.language = AppLanguage.vi,
    this.soundAlert = true,
    this.pushNotify = true,
  });

  SettingsEntity copyWith({
    AppLanguage? language,
    bool? soundAlert,
    bool? pushNotify,
  }) {
    return SettingsEntity(
      language: language ?? this.language,
      soundAlert: soundAlert ?? this.soundAlert,
      pushNotify: pushNotify ?? this.pushNotify,
    );
  }
}