using Swms.FinishGoods.API.Features.Stocktake.Api;

namespace Swms.FinishGoods.API.Features.Stocktake.Business;

public interface IStocktakeService
{
    Task<IReadOnlyList<CountSummaryResponse>> GetCountsAsync(string? type, string? status, DateTime? from, DateTime? to);
    Task<CountDetailResponse> GetCountAsync(long id);
    Task<CountPreviewResponse> PreviewAsync(string type, IReadOnlyList<string>? areaCodes);
    Task<CreateCountResult> CreateAsync(CreateCountRequest request);
    /// <summary>Ghi chú của 1 dòng — lý do lệch, tình trạng thực tế.</summary>
    Task SetNoteAsync(long lineId, SetNoteRequest request);

    Task SetCountAsync(long lineId, SetCountRequest request);
    Task CloseAsync(long id);
    Task<AddFoundResponse> AddFoundAsync(long countId, AddFoundRequest request);
    Task<(byte[] Bytes, string FileName)> BuildReportAsync(long id);
}
