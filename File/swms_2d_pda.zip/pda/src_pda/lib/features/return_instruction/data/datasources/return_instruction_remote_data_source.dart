import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_fa_model.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_instruction_model.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_receive_model.dart';

part 'return_instruction_remote_data_source.g.dart';

/// Đường dẫn PHẢI có tiền tố `/api`: BASE_URL trong `config/*.json` chỉ tới
/// host + port, không chứa `/api` (xem `app_config.dart`).
@RestApi()
abstract class ReturnInstructionRemoteDataSource {
  factory ReturnInstructionRemoteDataSource(Dio dio, {String baseUrl}) =
      _ReturnInstructionRemoteDataSource;

  /// Danh sách chỉ thị back hàng. Response ĐÃ kèm đủ dòng, nên màn PDA không
  /// phải gọi thêm một request cho mỗi phiếu khi người dùng bung chi tiết.
  ///
  /// Tên tham số query là camelCase (`goodsType`): ASP.NET model binding so
  /// tên KHÔNG phân biệt hoa thường nhưng CÓ phân biệt dấu gạch dưới.
  @GET('/api/return-instructions')
  Future<List<ReturnInstructionModel>> list({
    @Query('status') String? status,
    @Query('goodsType') String? goodsType,
    @Query('keyword') String? keyword,
  });

  /// Một phiếu kèm dòng và SL thực nhận mới nhất.
  ///
  /// Màn nhận hàng đọc lại phiếu khi mở chứ không nhận qua tham số điều hướng:
  /// máy khác có thể vừa quét thêm, mà màn này quyết định "còn phải nhận bao
  /// nhiêu" từ chính con số đó.
  @GET('/api/return-instructions/{id}')
  Future<ReturnInstructionModel> getById(@Path('id') int id);

  /// Nhận một pallet hàng return vào phiếu: gửi toàn bộ thùng + serial đã quét.
  /// Server cấp Pallet ID và trả lại phiếu đã cập nhật SL thực nhận.
  @POST('/api/return-instructions/{id}/pallets')
  Future<ReceiveReturnResponseModel> receive(
    @Path('id') int id,
    @Body() ReceiveReturnRequestModel body,
  );

  /// Chốt SL thực nhận: server đóng phiếu và TỰ GỬI MAIL báo FA số thực tế
  /// kèm bảng lệch so với chỉ thị.
  ///
  /// Không có thân request: SL thực nhận là số serial đã quét, server tự đếm.
  /// Gửi thêm con số từ máy là mở đường cho hai bên nói hai số khác nhau.
  @POST('/api/return-instructions/{id}/close')
  Future<ReturnInstructionModel> close(@Path('id') int id);

  // ── Mục 2d — FA đóng lại pallet sau rework ──────────────────────

  /// Sổ serial dạng GỌN (serial · model · status) để kiểm NGAY TRÊN MÁY.
  ///
  /// Tải một lần khi mở màn, không hỏi server từng con: FA quét liên tục, mà
  /// mỗi lượt gọi mạng trong kho là một nhịp chờ thấy rõ trên PDA.
  @GET('/api/return-instructions/{docId}/serial-index')
  Future<List<ReturnSerialIndexModel>> serialIndex(@Path('docId') int docId);

  /// FA đóng pallet mới: gửi TOÀN BỘ serial đã quét, kể cả con máy đã cảnh báo
  /// là không khớp.
  ///
  /// Vì sao gửi hết chứ không chỉ gửi con khớp: SERVER mới là nơi quyết định.
  /// Sổ tải về máy có thể đã cũ (một con vừa bị SCS nhận về trong lúc FA đang
  /// quét), nên server đối chiếu lại rồi tự loại và tự ghi nhật ký. Nếu máy
  /// lọc trước thì nhật ký lệch sẽ luôn rỗng và SCS không bao giờ biết có hàng
  /// lạ. Kiểm trên máy chỉ để cảnh báo NGAY cho FA đặt riêng ra tại bàn.
  @POST('/api/return-instructions/{docId}/fa-pallets')
  Future<CreateFaPalletResponseModel> createFaPallet(
    @Path('docId') int docId,
    @Body() CreateFaPalletRequestModel body,
  );
}
