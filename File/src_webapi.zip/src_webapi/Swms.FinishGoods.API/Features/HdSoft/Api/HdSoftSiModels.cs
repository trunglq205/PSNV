using System.Text.Json.Serialization;
using System.Text.RegularExpressions;
using Swms.FinishGoods.API.Features.HdSoft.Business;

namespace Swms.FinishGoods.API.Features.HdSoft.Api;

/// <summary>SI bên HD soft: C_Order mới nhất (chưa huỷ) theo SINo + dòng.
/// fields = cột SAP tuỳ biến đọc được, khoá là tên trường payload SAP (etd, contactno…).</summary>
public record HdSoftSiResponse(
    [property: JsonPropertyName("order_id")] long OrderId,
    [property: JsonPropertyName("si_no")] string SiNo,
    [property: JsonPropertyName("document_no")] string DocumentNo,
    [property: JsonPropertyName("revision")] string? Revision,
    [property: JsonPropertyName("doc_status")] string? DocStatus,
    [property: JsonPropertyName("doc_status_name")] string? DocStatusName,
    [property: JsonPropertyName("bpartner")] string? BPartner,
    [property: JsonPropertyName("warehouse")] string? Warehouse,
    [property: JsonPropertyName("date_ordered")] DateTime? DateOrdered,
    [property: JsonPropertyName("date_promised")] DateTime? DatePromised,
    [property: JsonPropertyName("description")] string? Description,
    [property: JsonPropertyName("created")] DateTime Created,
    [property: JsonPropertyName("updated")] DateTime? Updated,
    [property: JsonPropertyName("order_count")] int OrderCount,
    [property: JsonPropertyName("total_qty")] decimal TotalQty,
    [property: JsonPropertyName("fields")] IReadOnlyDictionary<string, string?> Fields,
    [property: JsonPropertyName("lines")] List<HdSoftSiLineResponse> Lines)
{
    public static HdSoftSiResponse From(HdSoftSiOrder o) => new(
        o.OrderId, o.SiNo, o.DocumentNo, Revisions(o),
        o.DocStatus, HdSoftDocStatus.Name(o.DocStatus),
        o.BPartnerCode, o.WarehouseCode, o.DateOrdered, o.DatePromised, o.Description,
        o.Created, o.Updated, o.OrderCount,
        o.Lines.Sum(l => l.QtyEntered),
        o.Fields,
        o.Lines.Select(HdSoftSiLineResponse.From).ToList());

    /// <summary>"Ver: First" (driverphoneno) nếu có, không thì phần sau "SINo-" trong DocumentNo.</summary>
    private static string? Revisions(HdSoftSiOrder o)
    {
        var ver = o.Field("driverphoneno");
        if (!string.IsNullOrWhiteSpace(ver))
        {
            var m = Regex.Match(ver, @"^\s*ver\s*:\s*(.+)$", RegexOptions.IgnoreCase);
            return (m.Success ? m.Groups[1].Value : ver).Trim();
        }
        var prefix = o.SiNo + "-";
        return o.DocumentNo.StartsWith(prefix, StringComparison.OrdinalIgnoreCase)
            ? o.DocumentNo[prefix.Length..].Trim()
            : null;
    }
}

public record HdSoftSiLineResponse(
    [property: JsonPropertyName("line_id")] long LineId,
    [property: JsonPropertyName("line_no")] int LineNo,
    [property: JsonPropertyName("product")] string Product,
    [property: JsonPropertyName("model")] string Model,
    [property: JsonPropertyName("qty_entered")] decimal QtyEntered,
    [property: JsonPropertyName("qty_delivered")] decimal QtyDelivered,
    [property: JsonPropertyName("uom")] string? Uom,
    [property: JsonPropertyName("description")] string? Description,
    [property: JsonPropertyName("fields")] IReadOnlyDictionary<string, string?> Fields)
{
    public static HdSoftSiLineResponse From(HdSoftSiLine l) => new(
        l.LineId, l.LineNo, l.ProductValue, l.Model, l.QtyEntered, l.QtyDelivered,
        l.Uom, l.Description, l.Fields);
}

/// <summary>Trường SAP nào đọc được từ cột nào của HD soft — để kiểm tra cấu hình.</summary>
public record HdSoftSiColumnsResponse(
    [property: JsonPropertyName("header")] List<HdSoftSiColumnResponse> Header,
    [property: JsonPropertyName("line")] List<HdSoftSiColumnResponse> Line,
    [property: JsonPropertyName("missing_header")] IReadOnlyList<string> MissingHeader,
    [property: JsonPropertyName("missing_line")] IReadOnlyList<string> MissingLine,
    [property: JsonPropertyName("loaded_at")] DateTime LoadedAt)
{
    public static HdSoftSiColumnsResponse From(HdSoftSiSchema s) => new(
        s.Header.Select(HdSoftSiColumnResponse.From).ToList(),
        s.Line.Select(HdSoftSiColumnResponse.From).ToList(),
        s.MissingHeader, s.MissingLine, s.LoadedAt);
}

public record HdSoftSiColumnResponse(
    [property: JsonPropertyName("field")] string Field,
    [property: JsonPropertyName("column")] string Column,
    [property: JsonPropertyName("data_type")] string DataType)
{
    public static HdSoftSiColumnResponse From(HdSoftSiColumn c) => new(c.Field, c.Column, c.DataType);
}

// ── Hàng thiếu theo ngày vanning ────────────────────────────

/// <summary>Lọc báo cáo hàng thiếu: SI có NGÀY VANNING trong [from, to] (tối đa 62 ngày).
/// Vanning = "Loading date" trong headernote3; SI không có loading date thì lấy ETD.
/// warehouse: kho HD soft (cả SI lẫn tồn kho); để trống "warehouse=" = mọi kho.</summary>
public class HdSoftShortageQuery
{
    [System.ComponentModel.DataAnnotations.Required] public DateTime? From { get; set; }
    [System.ComponentModel.DataAnnotations.Required] public DateTime? To { get; set; }
    [System.ComponentModel.DataAnnotations.MaxLength(50)] public string? Warehouse { get; set; } = "PSNV";
    /// <summary>true (mặc định): chỉ trả dòng còn thiếu.</summary>
    public bool OnlyShort { get; set; } = true;
}

/// <summary>1 dòng SI cần xuất. qty_open = đặt − đã giao; tồn được chia theo ngày vanning sớm trước (cùng ngày: ETD, SI No, số dòng).
/// qty_available = tồn còn lại của model ngay trước dòng này; qty_short = phần không đủ hàng.</summary>
public record HdSoftShortageLineResponse(
    [property: JsonPropertyName("vanning_date")] DateTime VanningDate,
    [property: JsonPropertyName("etd")] DateTime? Etd,
    [property: JsonPropertyName("si_no")] string SiNo,
    [property: JsonPropertyName("document_no")] string DocumentNo,
    [property: JsonPropertyName("line_no")] int LineNo,
    [property: JsonPropertyName("model")] string Model,
    [property: JsonPropertyName("packing_no")] string? PackingNo,
    [property: JsonPropertyName("qty_open")] decimal QtyOpen,
    [property: JsonPropertyName("qty_available")] decimal QtyAvailable,
    [property: JsonPropertyName("qty_allocated")] decimal QtyAllocated,
    [property: JsonPropertyName("qty_short")] decimal QtyShort);

/// <summary>Tổng theo model trong cả khoảng ngày.</summary>
public record HdSoftShortageModelResponse(
    [property: JsonPropertyName("model")] string Model,
    [property: JsonPropertyName("qty_on_hand")] decimal QtyOnHand,
    [property: JsonPropertyName("qty_open")] decimal QtyOpen,
    [property: JsonPropertyName("qty_short")] decimal QtyShort,
    [property: JsonPropertyName("first_short_vanning")] DateTime? FirstShortVanning,
    [property: JsonPropertyName("si_count")] int SiCount);

/// <summary>Tổng theo ngày vanning.</summary>
public record HdSoftShortageDayResponse(
    [property: JsonPropertyName("vanning_date")] DateTime VanningDate,
    [property: JsonPropertyName("si_count")] int SiCount,
    [property: JsonPropertyName("qty_open")] decimal QtyOpen,
    [property: JsonPropertyName("qty_short")] decimal QtyShort,
    [property: JsonPropertyName("short_line_count")] int ShortLineCount);

public record HdSoftShortageResponse(
    [property: JsonPropertyName("from")] DateTime From,
    [property: JsonPropertyName("to")] DateTime To,
    [property: JsonPropertyName("warehouse")] string? Warehouse,
    [property: JsonPropertyName("si_count")] int SiCount,
    [property: JsonPropertyName("qty_open")] decimal QtyOpen,
    [property: JsonPropertyName("qty_short")] decimal QtyShort,
    [property: JsonPropertyName("days")] List<HdSoftShortageDayResponse> Days,
    [property: JsonPropertyName("models")] List<HdSoftShortageModelResponse> Models,
    [property: JsonPropertyName("lines")] List<HdSoftShortageLineResponse> Lines,
    [property: JsonPropertyName("generated_at")] DateTime GeneratedAt);
