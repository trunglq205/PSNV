using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Components.Authorization;
using Refit;
using Swms.FinishGoods.Web.Features.Auth.Client;
using Swms.FinishGoods.Web.Features.Models.Client;
using Swms.FinishGoods.Web.Features.PartCard.Client;
using Swms.FinishGoods.Web.Features.Roles.Client;
using Swms.FinishGoods.Web.Features.Settings.Client;
using Swms.FinishGoods.Web.Features.StorageMap.Client;
using Swms.FinishGoods.Web.Features.Stocktake.Client;
using Swms.FinishGoods.Web.Features.Balance.Client;
using Swms.FinishGoods.Web.Features.TempLocMap.Client;
using Swms.FinishGoods.Web.Features.Users.Client;
using Swms.FinishGoods.Web.Shared.Application.Interfaces;
using Swms.FinishGoods.Web.Shared.Auth;
using Swms.FinishGoods.Web.Shared.Client.Http;
using Swms.FinishGoods.Web.Shared.Client.Profile;
using Swms.FinishGoods.Web.Shared.Infrastructure.Http;
using System.Net;
using System.Net.Sockets;

namespace Swms.FinishGoods.Web.Extensions;

/// <summary>
/// LAYER 3 — Refit clients, HttpClient config, message handlers, auth.
/// Web KHÔNG giữ JWT Secret: chỉ đọc claims từ cookie để hiển thị/chặn route.
/// Bảo mật thật do API verify token.
/// </summary>
public static class ServicesServiceExtensions
{
    public static IServiceCollection AddServiceServices(
        this IServiceCollection services, IConfiguration configuration)
    {
        var apiSettings = configuration.GetSection("ApiSettings").Get<ApiSettings>()
                          ?? new ApiSettings();
        services.AddSingleton(apiSettings);

        services.AddHttpContextAccessor();
        services.AddScoped<ITokenProvider, CookieTokenProvider>();
        services.AddTransient<AuthTokenHandler>();
        services.AddScoped<AuthenticationStateProvider, CookieAuthenticationStateProvider>();
        services.AddAuthorizationCore();
        services.AddCascadingAuthenticationState();
        services.AddTransient<LanguageHandler>();

        // Scheme tự viết: đọc claims từ cookie, KHÔNG verify chữ ký, KHÔNG cần Secret.
        services.AddAuthentication(CookieJwtAuthHandler.SchemeName)
            .AddScheme<AuthenticationSchemeOptions, CookieJwtAuthHandler>(
                CookieJwtAuthHandler.SchemeName, _ => { });

        services.AddAuthorization();

        var refitSettings = RefitSettingsFactory.Create();

        var port = apiSettings.Port; // hoặc hardcode 5000
        var localIp = GetLocalIpAddress();
        var baseUrl = $"http://{localIp}:{port}";

        Console.WriteLine($"[DIAG] ApiSettings.BaseUrl = '{baseUrl}'...");

        void ConfigureClient(HttpClient client)
        {
            client.BaseAddress = new Uri(baseUrl);
            client.Timeout = TimeSpan.FromSeconds(apiSettings.TimeoutSeconds);
        }

        // Gói cấu hình chung cho mọi Refit client (chữ ký AddApiClient<T>(ApiClientContext, bool)).
        var api = new ApiClientContext(refitSettings, ConfigureClient);

        services.AddApiClient<IAuthApi>(api, withAuth: false);
        services.AddApiClient<IUserApi>(api);
        services.AddApiClient<IRoleApi>(api);
        services.AddApiClient<IProfileApi>(api);
        services.AddApiClient<IPartCardApi>(api);
        services.AddApiClient<ITempLocMapApi>(api);
        services.AddApiClient<IModelApi>(api);
        services.AddApiClient<ISettingsApi>(api);
        services.AddApiClient<IStorageMapApi>(api);
        services.AddApiClient<IStocktakeApi>(api);
        services.AddApiClient<IBalanceApi>(api);

        return services;
    }

    public static string GetLocalIpAddress()
    {
        try
        {
            using var socket = new Socket(AddressFamily.InterNetwork, SocketType.Dgram, 0);
            socket.Connect("8.8.8.8", 65530); // không thực sự gửi gì
            var endPoint = socket.LocalEndPoint as IPEndPoint;
            return endPoint?.Address.ToString() ?? "127.0.0.1";
        }
        catch
        {
            return "127.0.0.1";
        }
    }
}
