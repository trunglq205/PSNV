// dart format width=80
// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i37;
import 'package:collection/collection.dart' as _i41;
import 'package:flutter/material.dart' as _i38;
import 'package:swms_finish_goods/features/abnormal_report/presentation/pages/ng_create_page.dart'
    as _i11;
import 'package:swms_finish_goods/features/abnormal_report/presentation/pages/ng_detail_page.dart'
    as _i12;
import 'package:swms_finish_goods/features/abnormal_report/presentation/pages/ng_list_page.dart'
    as _i13;
import 'package:swms_finish_goods/features/auth/presentation/pages/login_page.dart'
    as _i9;
import 'package:swms_finish_goods/features/box_detail/presentation/pages/box_detail_page.dart'
    as _i1;
import 'package:swms_finish_goods/features/gallery_page.dart' as _i5;
import 'package:swms_finish_goods/features/home/presentation/pages/home_page.dart'
    as _i6;
import 'package:swms_finish_goods/features/model/presentaition/pages/model_detail_page.dart'
    as _i10;
import 'package:swms_finish_goods/features/pallet/presentation/pages/find_missing_box_page.dart'
    as _i4;
import 'package:swms_finish_goods/features/pallet/presentation/pages/pallet_detail_page.dart'
    as _i14;
import 'package:swms_finish_goods/features/pallet/presentation/pages/split_pallet_page.dart'
    as _i24;
import 'package:swms_finish_goods/features/pallet/presentation/pages/storing_page.dart'
    as _i30;
import 'package:swms_finish_goods/features/pallet/presentation/pages/temp_location_page.dart'
    as _i31;
import 'package:swms_finish_goods/features/pallet/presentation/pages/vanning_area_page.dart'
    as _i34;
import 'package:swms_finish_goods/features/pallet/presentation/pages/warehouse_move_page.dart'
    as _i36;
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart'
    as _i40;
import 'package:swms_finish_goods/features/part_card/presentation/pages/part_card_action_page.dart'
    as _i16;
import 'package:swms_finish_goods/features/part_card/presentation/pages/part_card_page.dart'
    as _i17;
import 'package:swms_finish_goods/features/receiving/presentation/pages/receiving_page.dart'
    as _i18;
import 'package:swms_finish_goods/features/return_instruction/presentation/return_instruction_list_page.dart'
    as _i19;
import 'package:swms_finish_goods/features/return_instruction/presentation/return_receive_page.dart'
    as _i20;
import 'package:swms_finish_goods/features/settings/presentation/pages/settings_page.dart'
    as _i21;
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart'
    as _i39;
import 'package:swms_finish_goods/features/shipment_instruction/presentation/pages/kitting_page.dart'
    as _i7;
import 'package:swms_finish_goods/features/shipment_instruction/presentation/pages/kitting_task_page.dart'
    as _i8;
import 'package:swms_finish_goods/features/shipment_instruction/presentation/pages/shipment_instruction_detail_page.dart'
    as _i22;
import 'package:swms_finish_goods/features/shipment_instruction/presentation/pages/shipment_instruction_list_page.dart'
    as _i23;
import 'package:swms_finish_goods/features/stocktake/presentation/pages/stocktake_detail_page.dart'
    as _i25;
import 'package:swms_finish_goods/features/stocktake/presentation/pages/stocktake_type_pages.dart'
    as _i26;
import 'package:swms_finish_goods/features/stocky/presentation/stocky_list_page.dart'
    as _i27;
import 'package:swms_finish_goods/features/stocky/presentation/stocky_page.dart'
    as _i28;
import 'package:swms_finish_goods/features/storage_map/presentation/pages/storage_map_page.dart'
    as _i29;
import 'package:swms_finish_goods/features/vanning/presentation/pages/container_check_page.dart'
    as _i2;
import 'package:swms_finish_goods/features/vanning/presentation/pages/container_finish_page.dart'
    as _i3;
import 'package:swms_finish_goods/features/vanning/presentation/pages/pallet_stack_page.dart'
    as _i15;
import 'package:swms_finish_goods/features/vanning/presentation/pages/trip_pallet_photos_page.dart'
    as _i32;
import 'package:swms_finish_goods/features/vanning/presentation/pages/trip_stowage_page.dart'
    as _i33;
import 'package:swms_finish_goods/features/vanning/presentation/pages/vanning_page.dart'
    as _i35;

/// generated route for
/// [_i1.BoxDetailScreen]
class BoxDetailRoute extends _i37.PageRouteInfo<BoxDetailRouteArgs> {
  BoxDetailRoute({
    _i38.Key? key,
    required int boxId,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         BoxDetailRoute.name,
         args: BoxDetailRouteArgs(key: key, boxId: boxId),
         rawPathParams: {'boxId': boxId},
         initialChildren: children,
       );

  static const String name = 'BoxDetailRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final pathParams = data.inheritedPathParams;
      final args = data.argsAs<BoxDetailRouteArgs>(
        orElse: () => BoxDetailRouteArgs(boxId: pathParams.getInt('boxId')),
      );
      return _i1.BoxDetailScreen(key: args.key, boxId: args.boxId);
    },
  );
}

class BoxDetailRouteArgs {
  const BoxDetailRouteArgs({this.key, required this.boxId});

  final _i38.Key? key;

  final int boxId;

  @override
  String toString() {
    return 'BoxDetailRouteArgs{key: $key, boxId: $boxId}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! BoxDetailRouteArgs) return false;
    return key == other.key && boxId == other.boxId;
  }

  @override
  int get hashCode => key.hashCode ^ boxId.hashCode;
}

/// generated route for
/// [_i2.ContainerCheckPage]
class ContainerCheckRoute extends _i37.PageRouteInfo<void> {
  const ContainerCheckRoute({List<_i37.PageRouteInfo>? children})
    : super(ContainerCheckRoute.name, initialChildren: children);

  static const String name = 'ContainerCheckRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i2.ContainerCheckPage();
    },
  );
}

/// generated route for
/// [_i3.ContainerFinishPage]
class ContainerFinishRoute extends _i37.PageRouteInfo<void> {
  const ContainerFinishRoute({List<_i37.PageRouteInfo>? children})
    : super(ContainerFinishRoute.name, initialChildren: children);

  static const String name = 'ContainerFinishRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i3.ContainerFinishPage();
    },
  );
}

/// generated route for
/// [_i4.FindMissingBoxScreen]
class FindMissingBoxRoute extends _i37.PageRouteInfo<FindMissingBoxRouteArgs> {
  FindMissingBoxRoute({
    _i38.Key? key,
    required String lotNo,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         FindMissingBoxRoute.name,
         args: FindMissingBoxRouteArgs(key: key, lotNo: lotNo),
         initialChildren: children,
       );

  static const String name = 'FindMissingBoxRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<FindMissingBoxRouteArgs>();
      return _i4.FindMissingBoxScreen(key: args.key, lotNo: args.lotNo);
    },
  );
}

class FindMissingBoxRouteArgs {
  const FindMissingBoxRouteArgs({this.key, required this.lotNo});

  final _i38.Key? key;

  final String lotNo;

  @override
  String toString() {
    return 'FindMissingBoxRouteArgs{key: $key, lotNo: $lotNo}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! FindMissingBoxRouteArgs) return false;
    return key == other.key && lotNo == other.lotNo;
  }

  @override
  int get hashCode => key.hashCode ^ lotNo.hashCode;
}

/// generated route for
/// [_i5.GalleryPage]
class GalleryRoute extends _i37.PageRouteInfo<void> {
  const GalleryRoute({List<_i37.PageRouteInfo>? children})
    : super(GalleryRoute.name, initialChildren: children);

  static const String name = 'GalleryRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i5.GalleryPage();
    },
  );
}

/// generated route for
/// [_i6.HomeScreen]
class HomeRoute extends _i37.PageRouteInfo<void> {
  const HomeRoute({List<_i37.PageRouteInfo>? children})
    : super(HomeRoute.name, initialChildren: children);

  static const String name = 'HomeRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i6.HomeScreen();
    },
  );
}

/// generated route for
/// [_i7.KittingScreen]
class KittingRoute extends _i37.PageRouteInfo<KittingRouteArgs> {
  KittingRoute({_i38.Key? key, int? siId, List<_i37.PageRouteInfo>? children})
    : super(
        KittingRoute.name,
        args: KittingRouteArgs(key: key, siId: siId),
        rawQueryParams: {'siId': siId},
        initialChildren: children,
      );

  static const String name = 'KittingRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final queryParams = data.queryParams;
      final args = data.argsAs<KittingRouteArgs>(
        orElse: () => KittingRouteArgs(siId: queryParams.optInt('siId')),
      );
      return _i7.KittingScreen(key: args.key, siId: args.siId);
    },
  );
}

class KittingRouteArgs {
  const KittingRouteArgs({this.key, this.siId});

  final _i38.Key? key;

  final int? siId;

  @override
  String toString() {
    return 'KittingRouteArgs{key: $key, siId: $siId}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! KittingRouteArgs) return false;
    return key == other.key && siId == other.siId;
  }

  @override
  int get hashCode => key.hashCode ^ siId.hashCode;
}

/// generated route for
/// [_i8.KittingTaskScreen]
class KittingTaskRoute extends _i37.PageRouteInfo<KittingTaskRouteArgs> {
  KittingTaskRoute({
    _i38.Key? key,
    required _i39.PickTask task,
    required int index,
    required int total,
    _i39.PickTask? next,
    int? siId,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         KittingTaskRoute.name,
         args: KittingTaskRouteArgs(
           key: key,
           task: task,
           index: index,
           total: total,
           next: next,
           siId: siId,
         ),
         initialChildren: children,
       );

  static const String name = 'KittingTaskRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<KittingTaskRouteArgs>();
      return _i8.KittingTaskScreen(
        key: args.key,
        task: args.task,
        index: args.index,
        total: args.total,
        next: args.next,
        siId: args.siId,
      );
    },
  );
}

class KittingTaskRouteArgs {
  const KittingTaskRouteArgs({
    this.key,
    required this.task,
    required this.index,
    required this.total,
    this.next,
    this.siId,
  });

  final _i38.Key? key;

  final _i39.PickTask task;

  final int index;

  final int total;

  final _i39.PickTask? next;

  final int? siId;

  @override
  String toString() {
    return 'KittingTaskRouteArgs{key: $key, task: $task, index: $index, total: $total, next: $next, siId: $siId}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! KittingTaskRouteArgs) return false;
    return key == other.key &&
        task == other.task &&
        index == other.index &&
        total == other.total &&
        next == other.next &&
        siId == other.siId;
  }

  @override
  int get hashCode =>
      key.hashCode ^
      task.hashCode ^
      index.hashCode ^
      total.hashCode ^
      next.hashCode ^
      siId.hashCode;
}

/// generated route for
/// [_i9.LoginPage]
class LoginRoute extends _i37.PageRouteInfo<void> {
  const LoginRoute({List<_i37.PageRouteInfo>? children})
    : super(LoginRoute.name, initialChildren: children);

  static const String name = 'LoginRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i9.LoginPage();
    },
  );
}

/// generated route for
/// [_i10.ModelDetailScreen]
class ModelDetailRoute extends _i37.PageRouteInfo<ModelDetailRouteArgs> {
  ModelDetailRoute({
    _i38.Key? key,
    required int modelId,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         ModelDetailRoute.name,
         args: ModelDetailRouteArgs(key: key, modelId: modelId),
         rawPathParams: {'modelId': modelId},
         initialChildren: children,
       );

  static const String name = 'ModelDetailRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final pathParams = data.inheritedPathParams;
      final args = data.argsAs<ModelDetailRouteArgs>(
        orElse: () =>
            ModelDetailRouteArgs(modelId: pathParams.getInt('modelId')),
      );
      return _i10.ModelDetailScreen(key: args.key, modelId: args.modelId);
    },
  );
}

class ModelDetailRouteArgs {
  const ModelDetailRouteArgs({this.key, required this.modelId});

  final _i38.Key? key;

  final int modelId;

  @override
  String toString() {
    return 'ModelDetailRouteArgs{key: $key, modelId: $modelId}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! ModelDetailRouteArgs) return false;
    return key == other.key && modelId == other.modelId;
  }

  @override
  int get hashCode => key.hashCode ^ modelId.hashCode;
}

/// generated route for
/// [_i11.NgCreatePage]
class NgCreateRoute extends _i37.PageRouteInfo<void> {
  const NgCreateRoute({List<_i37.PageRouteInfo>? children})
    : super(NgCreateRoute.name, initialChildren: children);

  static const String name = 'NgCreateRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i11.NgCreatePage();
    },
  );
}

/// generated route for
/// [_i12.NgDetailPage]
class NgDetailRoute extends _i37.PageRouteInfo<NgDetailRouteArgs> {
  NgDetailRoute({
    _i38.Key? key,
    required int id,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         NgDetailRoute.name,
         args: NgDetailRouteArgs(key: key, id: id),
         rawPathParams: {'id': id},
         initialChildren: children,
       );

  static const String name = 'NgDetailRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final pathParams = data.inheritedPathParams;
      final args = data.argsAs<NgDetailRouteArgs>(
        orElse: () => NgDetailRouteArgs(id: pathParams.getInt('id')),
      );
      return _i12.NgDetailPage(key: args.key, id: args.id);
    },
  );
}

class NgDetailRouteArgs {
  const NgDetailRouteArgs({this.key, required this.id});

  final _i38.Key? key;

  final int id;

  @override
  String toString() {
    return 'NgDetailRouteArgs{key: $key, id: $id}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! NgDetailRouteArgs) return false;
    return key == other.key && id == other.id;
  }

  @override
  int get hashCode => key.hashCode ^ id.hashCode;
}

/// generated route for
/// [_i13.NgListPage]
class NgListRoute extends _i37.PageRouteInfo<void> {
  const NgListRoute({List<_i37.PageRouteInfo>? children})
    : super(NgListRoute.name, initialChildren: children);

  static const String name = 'NgListRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i13.NgListPage();
    },
  );
}

/// generated route for
/// [_i14.PalletDetailScreen]
class PalletDetailRoute extends _i37.PageRouteInfo<PalletDetailRouteArgs> {
  PalletDetailRoute({
    _i38.Key? key,
    required String lotNo,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         PalletDetailRoute.name,
         args: PalletDetailRouteArgs(key: key, lotNo: lotNo),
         rawPathParams: {'lotNo': lotNo},
         initialChildren: children,
       );

  static const String name = 'PalletDetailRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final pathParams = data.inheritedPathParams;
      final args = data.argsAs<PalletDetailRouteArgs>(
        orElse: () =>
            PalletDetailRouteArgs(lotNo: pathParams.getString('lotNo')),
      );
      return _i14.PalletDetailScreen(key: args.key, lotNo: args.lotNo);
    },
  );
}

class PalletDetailRouteArgs {
  const PalletDetailRouteArgs({this.key, required this.lotNo});

  final _i38.Key? key;

  final String lotNo;

  @override
  String toString() {
    return 'PalletDetailRouteArgs{key: $key, lotNo: $lotNo}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! PalletDetailRouteArgs) return false;
    return key == other.key && lotNo == other.lotNo;
  }

  @override
  int get hashCode => key.hashCode ^ lotNo.hashCode;
}

/// generated route for
/// [_i15.PalletStackPage]
class PalletStackRoute extends _i37.PageRouteInfo<void> {
  const PalletStackRoute({List<_i37.PageRouteInfo>? children})
    : super(PalletStackRoute.name, initialChildren: children);

  static const String name = 'PalletStackRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i15.PalletStackPage();
    },
  );
}

/// generated route for
/// [_i16.PartCardActionPage]
class PartCardActionRoute extends _i37.PageRouteInfo<PartCardActionRouteArgs> {
  PartCardActionRoute({
    _i38.Key? key,
    required _i40.PartCardAction action,
    required String payload,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         PartCardActionRoute.name,
         args: PartCardActionRouteArgs(
           key: key,
           action: action,
           payload: payload,
         ),
         initialChildren: children,
       );

  static const String name = 'PartCardActionRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<PartCardActionRouteArgs>();
      return _i16.PartCardActionPage(
        key: args.key,
        action: args.action,
        payload: args.payload,
      );
    },
  );
}

class PartCardActionRouteArgs {
  const PartCardActionRouteArgs({
    this.key,
    required this.action,
    required this.payload,
  });

  final _i38.Key? key;

  final _i40.PartCardAction action;

  final String payload;

  @override
  String toString() {
    return 'PartCardActionRouteArgs{key: $key, action: $action, payload: $payload}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! PartCardActionRouteArgs) return false;
    return key == other.key &&
        action == other.action &&
        payload == other.payload;
  }

  @override
  int get hashCode => key.hashCode ^ action.hashCode ^ payload.hashCode;
}

/// generated route for
/// [_i17.PartCardPage]
class PartCardRoute extends _i37.PageRouteInfo<PartCardRouteArgs> {
  PartCardRoute({
    _i38.Key? key,
    String? clonePayload,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         PartCardRoute.name,
         args: PartCardRouteArgs(key: key, clonePayload: clonePayload),
         initialChildren: children,
       );

  static const String name = 'PartCardRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<PartCardRouteArgs>(
        orElse: () => const PartCardRouteArgs(),
      );
      return _i17.PartCardPage(key: args.key, clonePayload: args.clonePayload);
    },
  );
}

class PartCardRouteArgs {
  const PartCardRouteArgs({this.key, this.clonePayload});

  final _i38.Key? key;

  final String? clonePayload;

  @override
  String toString() {
    return 'PartCardRouteArgs{key: $key, clonePayload: $clonePayload}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! PartCardRouteArgs) return false;
    return key == other.key && clonePayload == other.clonePayload;
  }

  @override
  int get hashCode => key.hashCode ^ clonePayload.hashCode;
}

/// generated route for
/// [_i18.ReceivingScreen]
class ReceivingRoute extends _i37.PageRouteInfo<void> {
  const ReceivingRoute({List<_i37.PageRouteInfo>? children})
    : super(ReceivingRoute.name, initialChildren: children);

  static const String name = 'ReceivingRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i18.ReceivingScreen();
    },
  );
}

/// generated route for
/// [_i19.ReturnInstructionListPage]
class ReturnInstructionListRoute extends _i37.PageRouteInfo<void> {
  const ReturnInstructionListRoute({List<_i37.PageRouteInfo>? children})
    : super(ReturnInstructionListRoute.name, initialChildren: children);

  static const String name = 'ReturnInstructionListRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i19.ReturnInstructionListPage();
    },
  );
}

/// generated route for
/// [_i20.ReturnReceivePage]
class ReturnReceiveRoute extends _i37.PageRouteInfo<ReturnReceiveRouteArgs> {
  ReturnReceiveRoute({
    _i38.Key? key,
    required int docId,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         ReturnReceiveRoute.name,
         args: ReturnReceiveRouteArgs(key: key, docId: docId),
         initialChildren: children,
       );

  static const String name = 'ReturnReceiveRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<ReturnReceiveRouteArgs>();
      return _i20.ReturnReceivePage(key: args.key, docId: args.docId);
    },
  );
}

class ReturnReceiveRouteArgs {
  const ReturnReceiveRouteArgs({this.key, required this.docId});

  final _i38.Key? key;

  final int docId;

  @override
  String toString() {
    return 'ReturnReceiveRouteArgs{key: $key, docId: $docId}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! ReturnReceiveRouteArgs) return false;
    return key == other.key && docId == other.docId;
  }

  @override
  int get hashCode => key.hashCode ^ docId.hashCode;
}

/// generated route for
/// [_i21.SettingsScreen]
class SettingsRoute extends _i37.PageRouteInfo<void> {
  const SettingsRoute({List<_i37.PageRouteInfo>? children})
    : super(SettingsRoute.name, initialChildren: children);

  static const String name = 'SettingsRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i21.SettingsScreen();
    },
  );
}

/// generated route for
/// [_i22.ShipmentInstructionDetailScreen]
class ShipmentInstructionDetailRoute
    extends _i37.PageRouteInfo<ShipmentInstructionDetailRouteArgs> {
  ShipmentInstructionDetailRoute({
    _i38.Key? key,
    required int siId,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         ShipmentInstructionDetailRoute.name,
         args: ShipmentInstructionDetailRouteArgs(key: key, siId: siId),
         rawPathParams: {'siId': siId},
         initialChildren: children,
       );

  static const String name = 'ShipmentInstructionDetailRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final pathParams = data.inheritedPathParams;
      final args = data.argsAs<ShipmentInstructionDetailRouteArgs>(
        orElse: () =>
            ShipmentInstructionDetailRouteArgs(siId: pathParams.getInt('siId')),
      );
      return _i22.ShipmentInstructionDetailScreen(
        key: args.key,
        siId: args.siId,
      );
    },
  );
}

class ShipmentInstructionDetailRouteArgs {
  const ShipmentInstructionDetailRouteArgs({this.key, required this.siId});

  final _i38.Key? key;

  final int siId;

  @override
  String toString() {
    return 'ShipmentInstructionDetailRouteArgs{key: $key, siId: $siId}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! ShipmentInstructionDetailRouteArgs) return false;
    return key == other.key && siId == other.siId;
  }

  @override
  int get hashCode => key.hashCode ^ siId.hashCode;
}

/// generated route for
/// [_i23.ShipmentInstructionListScreen]
class ShipmentInstructionListRoute extends _i37.PageRouteInfo<void> {
  const ShipmentInstructionListRoute({List<_i37.PageRouteInfo>? children})
    : super(ShipmentInstructionListRoute.name, initialChildren: children);

  static const String name = 'ShipmentInstructionListRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i23.ShipmentInstructionListScreen();
    },
  );
}

/// generated route for
/// [_i24.SplitPalletScreen]
class SplitPalletRoute extends _i37.PageRouteInfo<SplitPalletRouteArgs> {
  SplitPalletRoute({
    _i38.Key? key,
    required String lotNo,
    Set<int>? pickedBoxIds,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         SplitPalletRoute.name,
         args: SplitPalletRouteArgs(
           key: key,
           lotNo: lotNo,
           pickedBoxIds: pickedBoxIds,
         ),
         initialChildren: children,
       );

  static const String name = 'SplitPalletRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<SplitPalletRouteArgs>();
      return _i24.SplitPalletScreen(
        key: args.key,
        lotNo: args.lotNo,
        pickedBoxIds: args.pickedBoxIds,
      );
    },
  );
}

class SplitPalletRouteArgs {
  const SplitPalletRouteArgs({
    this.key,
    required this.lotNo,
    this.pickedBoxIds,
  });

  final _i38.Key? key;

  final String lotNo;

  final Set<int>? pickedBoxIds;

  @override
  String toString() {
    return 'SplitPalletRouteArgs{key: $key, lotNo: $lotNo, pickedBoxIds: $pickedBoxIds}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! SplitPalletRouteArgs) return false;
    return key == other.key &&
        lotNo == other.lotNo &&
        const _i41.SetEquality<int>().equals(pickedBoxIds, other.pickedBoxIds);
  }

  @override
  int get hashCode =>
      key.hashCode ^
      lotNo.hashCode ^
      const _i41.SetEquality<int>().hash(pickedBoxIds);
}

/// generated route for
/// [_i25.StocktakeDetailPage]
class StocktakeDetailRoute
    extends _i37.PageRouteInfo<StocktakeDetailRouteArgs> {
  StocktakeDetailRoute({
    _i38.Key? key,
    required int id,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         StocktakeDetailRoute.name,
         args: StocktakeDetailRouteArgs(key: key, id: id),
         initialChildren: children,
       );

  static const String name = 'StocktakeDetailRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<StocktakeDetailRouteArgs>();
      return _i25.StocktakeDetailPage(key: args.key, id: args.id);
    },
  );
}

class StocktakeDetailRouteArgs {
  const StocktakeDetailRouteArgs({this.key, required this.id});

  final _i38.Key? key;

  final int id;

  @override
  String toString() {
    return 'StocktakeDetailRouteArgs{key: $key, id: $id}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! StocktakeDetailRouteArgs) return false;
    return key == other.key && id == other.id;
  }

  @override
  int get hashCode => key.hashCode ^ id.hashCode;
}

/// generated route for
/// [_i26.StocktakeMonthlyPage]
class StocktakeMonthlyRoute extends _i37.PageRouteInfo<void> {
  const StocktakeMonthlyRoute({List<_i37.PageRouteInfo>? children})
    : super(StocktakeMonthlyRoute.name, initialChildren: children);

  static const String name = 'StocktakeMonthlyRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i26.StocktakeMonthlyPage();
    },
  );
}

/// generated route for
/// [_i26.StocktakeMorningPage]
class StocktakeMorningRoute extends _i37.PageRouteInfo<void> {
  const StocktakeMorningRoute({List<_i37.PageRouteInfo>? children})
    : super(StocktakeMorningRoute.name, initialChildren: children);

  static const String name = 'StocktakeMorningRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i26.StocktakeMorningPage();
    },
  );
}

/// generated route for
/// [_i26.StocktakeShipmentPage]
class StocktakeShipmentRoute extends _i37.PageRouteInfo<void> {
  const StocktakeShipmentRoute({List<_i37.PageRouteInfo>? children})
    : super(StocktakeShipmentRoute.name, initialChildren: children);

  static const String name = 'StocktakeShipmentRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i26.StocktakeShipmentPage();
    },
  );
}

/// generated route for
/// [_i27.StockyListPage]
class StockyListRoute extends _i37.PageRouteInfo<void> {
  const StockyListRoute({List<_i37.PageRouteInfo>? children})
    : super(StockyListRoute.name, initialChildren: children);

  static const String name = 'StockyListRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i27.StockyListPage();
    },
  );
}

/// generated route for
/// [_i28.StockyPage]
class StockyRoute extends _i37.PageRouteInfo<void> {
  const StockyRoute({List<_i37.PageRouteInfo>? children})
    : super(StockyRoute.name, initialChildren: children);

  static const String name = 'StockyRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i28.StockyPage();
    },
  );
}

/// generated route for
/// [_i29.StorageMapPage]
class StorageMapRoute extends _i37.PageRouteInfo<StorageMapRouteArgs> {
  StorageMapRoute({
    _i38.Key? key,
    String? locator,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         StorageMapRoute.name,
         args: StorageMapRouteArgs(key: key, locator: locator),
         rawQueryParams: {'locator': locator},
         initialChildren: children,
       );

  static const String name = 'StorageMapRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final queryParams = data.queryParams;
      final args = data.argsAs<StorageMapRouteArgs>(
        orElse: () =>
            StorageMapRouteArgs(locator: queryParams.optString('locator')),
      );
      return _i29.StorageMapPage(key: args.key, locator: args.locator);
    },
  );
}

class StorageMapRouteArgs {
  const StorageMapRouteArgs({this.key, this.locator});

  final _i38.Key? key;

  final String? locator;

  @override
  String toString() {
    return 'StorageMapRouteArgs{key: $key, locator: $locator}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! StorageMapRouteArgs) return false;
    return key == other.key && locator == other.locator;
  }

  @override
  int get hashCode => key.hashCode ^ locator.hashCode;
}

/// generated route for
/// [_i30.StoringScreen]
class StoringRoute extends _i37.PageRouteInfo<StoringRouteArgs> {
  StoringRoute({
    _i38.Key? key,
    String? lotNo,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         StoringRoute.name,
         args: StoringRouteArgs(key: key, lotNo: lotNo),
         initialChildren: children,
       );

  static const String name = 'StoringRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<StoringRouteArgs>(
        orElse: () => const StoringRouteArgs(),
      );
      return _i30.StoringScreen(key: args.key, lotNo: args.lotNo);
    },
  );
}

class StoringRouteArgs {
  const StoringRouteArgs({this.key, this.lotNo});

  final _i38.Key? key;

  final String? lotNo;

  @override
  String toString() {
    return 'StoringRouteArgs{key: $key, lotNo: $lotNo}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! StoringRouteArgs) return false;
    return key == other.key && lotNo == other.lotNo;
  }

  @override
  int get hashCode => key.hashCode ^ lotNo.hashCode;
}

/// generated route for
/// [_i31.TempLocationScreen]
class TempLocationRoute extends _i37.PageRouteInfo<TempLocationRouteArgs> {
  TempLocationRoute({
    _i38.Key? key,
    String? lotNo,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         TempLocationRoute.name,
         args: TempLocationRouteArgs(key: key, lotNo: lotNo),
         initialChildren: children,
       );

  static const String name = 'TempLocationRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<TempLocationRouteArgs>(
        orElse: () => const TempLocationRouteArgs(),
      );
      return _i31.TempLocationScreen(key: args.key, lotNo: args.lotNo);
    },
  );
}

class TempLocationRouteArgs {
  const TempLocationRouteArgs({this.key, this.lotNo});

  final _i38.Key? key;

  final String? lotNo;

  @override
  String toString() {
    return 'TempLocationRouteArgs{key: $key, lotNo: $lotNo}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! TempLocationRouteArgs) return false;
    return key == other.key && lotNo == other.lotNo;
  }

  @override
  int get hashCode => key.hashCode ^ lotNo.hashCode;
}

/// generated route for
/// [_i32.TripPalletPhotosPage]
class TripPalletPhotosRoute
    extends _i37.PageRouteInfo<TripPalletPhotosRouteArgs> {
  TripPalletPhotosRoute({
    _i38.Key? key,
    String? initialCode,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         TripPalletPhotosRoute.name,
         args: TripPalletPhotosRouteArgs(key: key, initialCode: initialCode),
         initialChildren: children,
       );

  static const String name = 'TripPalletPhotosRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<TripPalletPhotosRouteArgs>(
        orElse: () => const TripPalletPhotosRouteArgs(),
      );
      return _i32.TripPalletPhotosPage(
        key: args.key,
        initialCode: args.initialCode,
      );
    },
  );
}

class TripPalletPhotosRouteArgs {
  const TripPalletPhotosRouteArgs({this.key, this.initialCode});

  final _i38.Key? key;

  final String? initialCode;

  @override
  String toString() {
    return 'TripPalletPhotosRouteArgs{key: $key, initialCode: $initialCode}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! TripPalletPhotosRouteArgs) return false;
    return key == other.key && initialCode == other.initialCode;
  }

  @override
  int get hashCode => key.hashCode ^ initialCode.hashCode;
}

/// generated route for
/// [_i33.TripStowagePage]
class TripStowageRoute extends _i37.PageRouteInfo<void> {
  const TripStowageRoute({List<_i37.PageRouteInfo>? children})
    : super(TripStowageRoute.name, initialChildren: children);

  static const String name = 'TripStowageRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i33.TripStowagePage();
    },
  );
}

/// generated route for
/// [_i34.VanningAreaScreen]
class VanningAreaRoute extends _i37.PageRouteInfo<VanningAreaRouteArgs> {
  VanningAreaRoute({
    _i38.Key? key,
    String? lotNo,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         VanningAreaRoute.name,
         args: VanningAreaRouteArgs(key: key, lotNo: lotNo),
         initialChildren: children,
       );

  static const String name = 'VanningAreaRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<VanningAreaRouteArgs>(
        orElse: () => const VanningAreaRouteArgs(),
      );
      return _i34.VanningAreaScreen(key: args.key, lotNo: args.lotNo);
    },
  );
}

class VanningAreaRouteArgs {
  const VanningAreaRouteArgs({this.key, this.lotNo});

  final _i38.Key? key;

  final String? lotNo;

  @override
  String toString() {
    return 'VanningAreaRouteArgs{key: $key, lotNo: $lotNo}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! VanningAreaRouteArgs) return false;
    return key == other.key && lotNo == other.lotNo;
  }

  @override
  int get hashCode => key.hashCode ^ lotNo.hashCode;
}

/// generated route for
/// [_i35.VanningPage]
class VanningRoute extends _i37.PageRouteInfo<void> {
  const VanningRoute({List<_i37.PageRouteInfo>? children})
    : super(VanningRoute.name, initialChildren: children);

  static const String name = 'VanningRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      return const _i35.VanningPage();
    },
  );
}

/// generated route for
/// [_i36.WarehouseMoveScreen]
class WarehouseMoveRoute extends _i37.PageRouteInfo<WarehouseMoveRouteArgs> {
  WarehouseMoveRoute({
    _i38.Key? key,
    String? lotNo,
    List<_i37.PageRouteInfo>? children,
  }) : super(
         WarehouseMoveRoute.name,
         args: WarehouseMoveRouteArgs(key: key, lotNo: lotNo),
         initialChildren: children,
       );

  static const String name = 'WarehouseMoveRoute';

  static _i37.PageInfo page = _i37.PageInfo(
    name,
    builder: (data) {
      final args = data.argsAs<WarehouseMoveRouteArgs>(
        orElse: () => const WarehouseMoveRouteArgs(),
      );
      return _i36.WarehouseMoveScreen(key: args.key, lotNo: args.lotNo);
    },
  );
}

class WarehouseMoveRouteArgs {
  const WarehouseMoveRouteArgs({this.key, this.lotNo});

  final _i38.Key? key;

  final String? lotNo;

  @override
  String toString() {
    return 'WarehouseMoveRouteArgs{key: $key, lotNo: $lotNo}';
  }

  @override
  bool operator ==(Object other) {
    if (identical(this, other)) return true;
    if (other is! WarehouseMoveRouteArgs) return false;
    return key == other.key && lotNo == other.lotNo;
  }

  @override
  int get hashCode => key.hashCode ^ lotNo.hashCode;
}
