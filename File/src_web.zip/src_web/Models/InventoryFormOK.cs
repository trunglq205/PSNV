﻿namespace SWMS_WebTool.Models
{
    public class InventoryFormOK
    {
        public string Material { get; set; }
        public string MaterialDescription { get; set; }
        public string PositionKitting { get; set; }
        public double SystemQuantity { get; set; }
        public double SwmsQuantity { get; set; }
        public double DiffQuantity { get; set; }
        public double ActualRecheck { get; set; }
        public string Remark { get; set; }
        public double BalanceQuantity { get; set; }
        public string TypeKitting { get; set; }
        public double StandardPrice { get; set; }
        public double Amount { get; set; }
    }
}
