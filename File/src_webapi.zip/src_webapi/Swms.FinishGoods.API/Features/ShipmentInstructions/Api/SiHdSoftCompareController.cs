using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

/// <summary>So SI giữa SWMS và HD soft (hệ thống cũ) — kiểm tra 2 hệ thống chạy song song có khớp dữ liệu.</summary>
[ApiController]
[Route("api/shipment-instructions/hdsoft-compare")]
public class SiHdSoftCompareController : ControllerBase
{
    private readonly ISiHdSoftCompareService _service;
    public SiHdSoftCompareController(ISiHdSoftCompareService service) => _service = service;

    /// <summary>Mọi SI có ETD trong khoảng ngày (từ hôm nay, tối đa 62 ngày) ở 1 trong 2 hệ thống:
    /// khớp / lệch / thiếu bên nào. from trước hôm nay -> 400.
    /// VD: GET /api/shipment-instructions/hdsoft-compare?from=2026-10-22&amp;to=2026-11-05&amp;onlyIssues=true</summary>
    [HttpGet]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<SiCompareListResponse>> CompareRange([FromQuery] SiCompareQuery query)
        => Ok(await _service.CompareRangeAsync(query));

    /// <summary>Chi tiết 1 SI: từng trường header + từng dòng hai bên.
    /// VD: GET /api/shipment-instructions/hdsoft-compare/PB202506J3</summary>
    [HttpGet("{siNo}")]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<SiCompareDetailResponse>> Compare(string siNo)
        => Ok(await _service.CompareAsync(siNo));
}
