import 'package:flutter/services.dart';

class CertificateService {
  CertificateService._(this.caBytes);

  final Uint8List caBytes;

  static CertificateService? _instance;
  static CertificateService get instance {
    final i = _instance;
    if (i == null) {
      throw StateError(
        'CertificateService chưa init. Gọi CertificateService.init() trong main().',
      );
    }
    return i;
  }

  static Future<void> init({
    String assetPath = 'assets/certs/ca.pem',
  }) async {
    final data = await rootBundle.load(assetPath);
    _instance = CertificateService._(data.buffer.asUint8List());
  }
}