using Swms.FinishGoods.API.Features.Stocktake.Business;
using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Stocktake.DataAccess;

public class StocktakeRepository : IStocktakeRepository
{
    private readonly IDbConnectionFactory _factory;
    public StocktakeRepository(IDbConnectionFactory factory) => _factory = factory;


    // SELECT tóm tắt phiếu + đếm dòng (dùng chung list & header detail)
    private const string SummarySelect = """
        SELECT c.id AS Id, c.doc_no AS DocNo, c.count_type AS CountType, c.count_date AS CountDate,
               c.doc_status AS DocStatus, c.source_ref AS SourceRef, c.description AS Description,
               c.created_at AS CreatedAt,
               ISNULL(a.total,0) AS TotalLines, ISNULL(a.counted,0) AS CountedLines, ISNULL(a.disc,0) AS DiscrepancyLines,
               ISNULL(a.req,0) AS RequiredLines, ISNULL(a.req_counted,0) AS CountedRequiredLines
        FROM wms.inventory_counts c
        OUTER APPLY (
            SELECT COUNT(*) AS total,
                   SUM(CASE WHEN cl.qty_count IS NOT NULL THEN 1 ELSE 0 END) AS counted,
                   SUM(CASE WHEN cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system THEN 1 ELSE 0 END) AS disc,
                   -- Cặp "phải đếm" tách riêng: phiếu sáng mang đủ mọi pallet
                   -- của ô để Web hiện bối cảnh, nên tổng số dòng KHÁC số dòng
                   -- phải đếm. Tiến độ đi theo cặp này.
                   SUM(CASE WHEN cl.is_required = 1 THEN 1 ELSE 0 END) AS req,
                   SUM(CASE WHEN cl.is_required = 1 AND cl.qty_count IS NOT NULL THEN 1 ELSE 0 END) AS req_counted
            FROM wms.inventory_count_lines cl
            WHERE cl.count_id = c.id AND cl.is_deleted = 0
        ) a
        """;

    public async Task<IReadOnlyList<CountSummary>> GetCountsAsync(string? type, string? status, DateTime? from, DateTime? to)
    {
        using var conn = _factory.Create();
        var sql = SummarySelect + "\n" + """
            WHERE c.is_deleted = 0
              AND (@type IS NULL OR c.count_type = @type)
              AND (@status IS NULL OR c.doc_status = @status)
              AND (@from IS NULL OR c.count_date >= @from)
              AND (@to IS NULL OR c.count_date <= @to)
            ORDER BY c.id DESC;
            """;
        var rows = await conn.QueryAsync<CountSummary>(sql, new { type, status, from, to });
        return rows.ToList();
    }

    public async Task<CountDetail?> GetCountAsync(long id)
    {
        using var conn = _factory.Create();

        const string headSql = """
            SELECT c.id AS [Id], c.doc_no AS [DocNo], c.count_type AS [CountType], c.count_date AS [CountDate],
                   c.doc_status AS [DocStatus], c.source_ref AS [SourceRef], c.description AS [Description],
                   c.created_at AS [CreatedAt],
                   (SELECT COUNT(*) FROM wms.inventory_count_lines x
                     WHERE x.count_id = c.id AND x.is_deleted = 0) AS [TotalLines],
                   (SELECT COUNT(*) FROM wms.inventory_count_lines x
                     WHERE x.count_id = c.id AND x.is_deleted = 0 AND x.qty_count IS NOT NULL) AS [CountedLines],
                   (SELECT COUNT(*) FROM wms.inventory_count_lines x
                     WHERE x.count_id = c.id AND x.is_deleted = 0 AND x.qty_count IS NOT NULL AND x.qty_count <> x.qty_system) AS [DiscrepancyLines],
                   (SELECT COUNT(*) FROM wms.inventory_count_lines x
                     WHERE x.count_id = c.id AND x.is_deleted = 0 AND x.is_required = 1) AS [RequiredLines],
                   (SELECT COUNT(*) FROM wms.inventory_count_lines x
                     WHERE x.count_id = c.id AND x.is_deleted = 0 AND x.is_required = 1
                       AND x.qty_count IS NOT NULL) AS [CountedRequiredLines]
            FROM wms.inventory_counts c
            WHERE c.is_deleted = 0 AND c.id = @id;
            """;
        var header = await conn.QuerySingleOrDefaultAsync<CountSummary>(headSql, new { id });
        if (header is null) return null;

        const string lineSql = """
            SELECT cl.id AS [Id], cl.line_no AS [LineNo], ISNULL(CAST(cl.product_id AS int), 0) AS [ProductId],
                   cat.name AS [ProductName], cl.locator_id AS [LocatorId], l.locator_code AS [LocatorCode],
                   cl.lot_id AS [LotId], RTRIM(p.pallet_id) AS [PalletId],
                   -- Pallet serial / box_line KHÔNG ghi cột pallets.model (model
                   -- nằm ở box_lines) nên đọc thẳng p.model làm dòng phiếu kiểm
                   -- kê của hai loại đó trống cột Model. Cùng quy ước COALESCE
                   -- với LocationInfoSql. Dòng ô TRỐNG (cl.lot_id NULL, p LEFT
                   -- JOIN không khớp) vẫn ra NULL như trước.
                   COALESCE(
                       (SELECT STRING_AGG(z.model, ', ')
                        FROM (SELECT DISTINCT bl.model
                              FROM wms.boxes bx
                              JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                              WHERE bx.lot_id = p.id AND bx.is_deleted = 0) z),
                       p.model) AS [Model],
                   cl.qty_system AS [QtySystem], cl.qty_count AS [QtyCount], cl.is_adjusted AS [IsAdjusted],
                   cl.note AS [Note],
                   cl.box_count_system AS [BoxCountSystem], cl.box_count_counted AS [BoxCountCounted],
                   cl.standard_packing AS [StandardPacking],
                   cl.is_found AS [IsFound], sl.locator_code AS [SystemLocatorCode],
                   -- Dòng này có PHẢI ĐẾM không. Đọc thẳng cột đã chốt lúc tạo
                   -- phiếu, KHÔNG tính lại từ wms.stock_events lúc đọc.
                   --
                   -- Bản đầu tính lúc đọc và nó SAI: cửa sổ suy từ count_date
                   -- nên mỗi lần có sự kiện kho mới rơi vào khoảng đó, một phiếu
                   -- ĐÃ ĐÓNG sẽ đổi nghĩa — hôm nay 1 dòng cần kiểm, mai thành
                   -- 2. Phạm vi phải đóng băng tại thời điểm tạo phiếu.
                   cl.is_required AS [IsRequired]
            FROM wms.inventory_count_lines cl
            JOIN master.locators l ON l.id = cl.locator_id
            LEFT JOIN wms.pallets p ON p.id = cl.lot_id
            LEFT JOIN master.categories cat ON cat.code = cl.product_id
            LEFT JOIN master.locators sl ON sl.id = cl.system_locator_id
            WHERE cl.count_id = @id AND cl.is_deleted = 0
            ORDER BY cl.line_no;
            """;
        var lines = (await conn.QueryAsync<CountLine>(lineSql, new { id })).ToList();

        // Toạ độ trên bản đồ của mọi vị trí trong phiếu -> tính thứ tự đi.
        // Ô thuộc kệ lấy khung của kệ; ô pallet sàn lấy khung của chính nó.
        const string geoSql = """
            SELECT  l.id            AS [LocatorId],
                    l.locator_code  AS [LocatorCode],
                    a.area_code     AS [AreaCode],
                    a.area_name     AS [AreaName],
                    a.rows          AS [AreaRows],
                    l.rack_id       AS [RackId],
                    r.cols          AS [RackPositions],
                    l.rack_col      AS [RackCol],
                    l.rack_row      AS [RackRow],
                    l.rack_level    AS [RackLevel],
                    COALESCE(mr.grid_x, ml.grid_x) AS [GridX],
                    COALESCE(mr.grid_y, ml.grid_y) AS [GridY],
                    COALESCE(mr.grid_w, ml.grid_w) AS [GridW],
                    COALESCE(mr.grid_h, ml.grid_h) AS [GridH]
            FROM (SELECT DISTINCT locator_id FROM wms.inventory_count_lines
                  WHERE count_id = @id AND is_deleted = 0) x
            JOIN      master.locators l        ON l.id = x.locator_id
            LEFT JOIN master.warehouse_areas a ON a.id = l.area_id
            LEFT JOIN master.racks r           ON r.id = l.rack_id
            OUTER APPLY (SELECT TOP 1 m.grid_x, m.grid_y, m.grid_w, m.grid_h
                         FROM master.locator_map m
                         WHERE l.rack_id IS NOT NULL AND m.rack_id = l.rack_id AND m.is_deleted = 0) mr
            OUTER APPLY (SELECT TOP 1 m.grid_x, m.grid_y, m.grid_w, m.grid_h
                         FROM master.locator_map m
                         WHERE m.locator_id = l.id AND m.is_deleted = 0) ml;
            """;
        var geo = (await conn.QueryAsync<LocatorGeoRow>(geoSql, new { id })).ToList();

        var walk = WalkSequencer.Sequence(geo.Select(g => g.ToGeo()));
        var areaOf = geo.ToDictionary(g => g.LocatorId, g => (g.AreaCode, g.AreaName));
        foreach (var l in lines)
        {
            l.WalkSeq = walk.TryGetValue(l.LocatorId, out var w) ? w : int.MaxValue;
            if (areaOf.TryGetValue(l.LocatorId, out var ar)) { l.AreaCode = ar.AreaCode; l.AreaName = ar.AreaName; }
        }

        return new CountDetail
        {
            Header = header,
            // Ô không có toạ độ trên bản đồ xếp cuối, theo mã so tự nhiên (A1-2-1 trước A1-10-1).
            Lines = lines.OrderBy(l => l.WalkSeq)
                         .ThenBy(l => l.LocatorCode, NaturalCodeComparer.Instance)
                         .ThenBy(l => l.LineNo)
                         .ToList()
        };
    }

    private sealed class LocatorGeoRow
    {
        public long LocatorId { get; set; }
        public string LocatorCode { get; set; } = string.Empty;
        public string? AreaCode { get; set; }
        public string? AreaName { get; set; }
        public int AreaRows { get; set; }
        public long? RackId { get; set; }
        public int? RackPositions { get; set; }
        public int? RackCol { get; set; }
        public int? RackRow { get; set; }
        public string? RackLevel { get; set; }
        public int? GridX { get; set; }
        public int? GridY { get; set; }
        public int? GridW { get; set; }
        public int? GridH { get; set; }

        public LocatorGeo ToGeo() => new()
        {
            LocatorId = LocatorId, LocatorCode = LocatorCode, AreaCode = AreaCode, AreaRows = AreaRows,
            RackId = RackId, RackPositions = RackPositions, RackCol = RackCol,
            RackRow = RackRow, RackLevel = RackLevel,
            GridX = GridX, GridY = GridY, GridW = GridW, GridH = GridH
        };
    }

    private sealed class PreviewRow { public int LineCount { get; set; } public int LocatorCount { get; set; } }

    private sealed class FoundPalletRow
    {
        public long Id { get; set; }
        public long? LocatorId { get; set; }
        public long? CategoryId { get; set; }
    }

    private sealed class FoundLineRow
    {
        public long Id { get; set; }
        public long LocatorId { get; set; }
        public bool IsFound { get; set; }
    }

    public async Task<(int LocatorCount, int LineCount)> PreviewAsync(string type, IReadOnlyList<string>? areaCodes)
    {
        using var conn = _factory.Create();

        PreviewRow r;
        if (type == "morning")
        {
            // Buổi sáng: ô CÓ BIẾN ĐỘNG hôm qua, trên MỌI bản đồ lưu kho (map_type = storing).
            var t0 = DateTime.Today;
            var y0 = t0.AddDays(-1);
            r = await conn.QuerySingleAsync<PreviewRow>(
                // Đếm ô theo l.id chứ KHÔNG theo p.locator_id: từ 19/11 phiếu
                // sáng gồm cả ô đã chuyển đi hết, ở đó p là NULL nên đếm theo
                // p.locator_id sẽ bỏ sót đúng những ô đó.
                MorningSql("SELECT COUNT(*) AS LineCount, COUNT(DISTINCT l.id) AS LocatorCount"),
                new { y0, t0 });
        }
        else
        {
            // Cuối tháng: MỌI ô của các bản đồ đã chọn, KỂ CẢ Ô TRỐNG
            // (không chọn = mọi bản đồ lưu kho). Ô có n pallet = n dòng, ô trống = 1 dòng.
            r = await conn.QuerySingleAsync<PreviewRow>($"""
                SELECT COUNT(*) AS LineCount, COUNT(DISTINCT l.id) AS LocatorCount
                FROM master.locators l
                JOIN master.warehouse_areas a ON a.id = l.area_id AND a.is_deleted = 0 AND a.map_type = N'storing'
                LEFT JOIN wms.pallets p ON p.locator_id = l.id AND p.is_deleted = 0
                WHERE l.is_deleted = 0 {AreaFilter(areaCodes)};
                """, new { areaCodes });
        }
        return (r.LocatorCount, r.LineCount);
    }

    public async Task<IReadOnlyList<string>> GetStoringAreaCodesAsync()
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<string>("""
            SELECT area_code FROM master.warehouse_areas
            WHERE map_type = N'storing' AND is_deleted = 0
            ORDER BY area_code;
            """)).ToList();
    }

    /// <summary>Lọc theo danh sách bản đồ đã chọn; rỗng = mọi bản đồ lưu kho.</summary>
    private static string AreaFilter(IReadOnlyList<string>? areaCodes)
        => areaCodes is null || areaCodes.Count == 0 ? string.Empty : " AND a.area_code IN @areaCodes";

    /// <summary>
    /// Vị trí "có biến động hôm qua", đọc từ wms.stock_events.
    ///
    /// Bảng wms.locator_status_history ĐÃ BỊ XOÁ khỏi DB; câu cũ đọc nó nên
    /// endpoint preview / tạo phiếu sáng đổ "Invalid object name". SP
    /// wms.usp_stocktake_create_morning đã chuyển sang stock_events từ bản v2 —
    /// câu dưới đây GIỮ ĐÚNG cùng định nghĩa để job 6h sáng và luồng tạo tay
    /// không ra hai kết quả khác nhau:
    ///
    ///   (a) from_locator_id / to_locator_id của mọi event hôm qua
    ///       -> pallet vào / ra / chuyển vị trí.
    ///   (b) vị trí HIỆN TẠI của pallet có event hôm qua nhưng event không mang
    ///       vị trí (vd. thêm/bớt/chuyển thùng giữa 2 pallet -> số thùng tại ô
    ///       đổi mà không có from/to). Tính cả related_pallet_id để bắt pallet
    ///       bên kia của thao tác gộp/tách.
    ///
    /// Alias e / p2 / x: query ngoài đã dùng p (pallets), l (locators), a (areas).
    /// </summary>
    private const string ChangedLocatorsSql = """
        SELECT x.locator_id
        FROM (
            SELECT e.from_locator_id AS locator_id
            FROM wms.stock_events e
            WHERE e.event_at >= @y0 AND e.event_at < @t0
              AND e.from_locator_id IS NOT NULL
            UNION
            SELECT e.to_locator_id
            FROM wms.stock_events e
            WHERE e.event_at >= @y0 AND e.event_at < @t0
              AND e.to_locator_id IS NOT NULL
            UNION
            SELECT p2.locator_id
            FROM wms.stock_events e
            JOIN wms.pallets p2 ON p2.id IN (e.pallet_id, e.related_pallet_id)
            WHERE e.event_at >= @y0 AND e.event_at < @t0
              AND e.from_locator_id IS NULL AND e.to_locator_id IS NULL
              AND p2.is_deleted = 0 AND p2.locator_id IS NOT NULL
        ) x
        """;

    /// <summary>
    /// Thân câu lệnh phiếu sáng: MỌI Ô có biến động hôm qua, mọi bản đồ lưu kho.
    ///
    /// ⚠ Chạy theo Ô chứ không theo pallet (đổi 19/11). Bản cũ đi từ
    /// <c>wms.pallets</c> nên ô có biến động mà pallet đã CHUYỂN ĐI HẾT thì
    /// không sinh dòng nào — đúng cái ô cần người ra tận nơi xác nhận là rỗng
    /// thật lại là ô duy nhất không ai được giao đi kiểm. Nay LEFT JOIN như
    /// phiếu cuối tháng: ô rỗng ra 1 dòng không pallet.
    /// </summary>
    private static string MorningSql(string head) => head + "\n" + """
        FROM master.locators l
        JOIN master.warehouse_areas a ON a.id = l.area_id AND a.is_deleted = 0 AND a.map_type = N'storing'
        LEFT JOIN wms.pallets p ON p.locator_id = l.id AND p.is_deleted = 0
        """ + "\n" + PackingApply + "\n" + """
        WHERE l.is_deleted = 0
          AND l.id IN (
        """ + "\n" + ChangedLocatorsSql + "\n" + """
          );
        """;

    /// <summary>
    /// Giá trị <c>is_required</c> của phiếu SÁNG, chốt ngay lúc tạo.
    ///
    /// Ô trống (p.id NULL) = phải kiểm: xác nhận ô rỗng thật.
    /// Pallet có sự kiện kho trong cửa sổ hôm qua = phải kiểm.
    /// Pallet nằm yên từ trước = KHÔNG phải kiểm, chỉ để Web hiện bối cảnh ô.
    /// </summary>
    private const string MorningRequiredCol = """
        CASE WHEN p.id IS NULL THEN 1
             WHEN EXISTS (SELECT 1 FROM wms.stock_events e
                          WHERE e.event_at >= @y0 AND e.event_at < @t0
                            AND p.id IN (e.pallet_id, e.related_pallet_id))
                  THEN 1
             ELSE 0 END
        """;

    /// <summary>
    /// Quy cách và số lượng thật của pallet, dùng cho cả 2 kiểu phiếu.
    ///
    /// ⚠ THỨ TỰ ƯU TIÊN ĐÃ ĐẢO (19/11). Trước đây lấy
    /// <c>box_count x master.models.standard_packing</c> trước, chỉ khi model
    /// chưa khai quy cách mới lấy số thật. Sai ở chỗ: quy cách là một con số
    /// KHAI TAY trong danh mục, khai thiếu hoặc khai 1 là qty_system ra đúng
    /// bằng SỐ BOX — và màn kiểm kê hiện con số đó như thể là số lượng. Không
    /// có lỗi nào để lần ra, chỉ là số nhỏ hơn thực tế vài chục lần.
    ///
    /// Nay: SỐ THẬT TRƯỚC, công thức chỉ là đường lùi.
    ///   1. SUM(wms.box_lines.qty) — cái thực sự đang nằm trong các thùng.
    ///   2. box_count x standard_packing — chỉ khi pallet KHÔNG có dòng thùng
    ///      nào (detail_level = box_count), tức không có gì để cộng.
    ///   3. 0 — không biết gì cả.
    ///
    /// standard_packing trả về cũng theo đúng thứ tự đó (suy từ số thật trước),
    /// để dòng gợi ý "N box x P = M cái" trên PDA không bao giờ nói ngược với
    /// chính con số bên cạnh nó.
    ///
    /// KHÔNG dùng wms.pallets.standard_packing — cột đó phục vụ đóng hàng,
    /// không có ý nghĩa trong kiểm kê.
    /// </summary>
    /// <remarks>
    /// Cả hai đều là OUTER APPLY ... TOP 1 / aggregate nên trả đúng 1 dòng:
    /// master.models.code không có ràng buộc unique, LEFT JOIN thẳng vào đó sẽ
    /// nhân dòng và làm phiếu sinh ra trùng.
    /// </remarks>
    private const string PackingApply = """
        OUTER APPLY (SELECT TOP 1 m.standard_packing
                     FROM master.models m
                     WHERE m.code = p.model AND m.is_deleted = 0
                     ORDER BY m.id) mdl
        OUTER APPLY (SELECT SUM(bl.qty) AS qty
                     FROM wms.boxes b
                     JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                     WHERE b.lot_id = p.id AND b.is_deleted = 0) bx
        """;

    /// <summary>
    /// 6 giá trị của 1 dòng, đúng thứ tự trong <see cref="LineInsertColumns"/>:
    /// qty_system, qty_count, is_adjusted, box_count_system, box_count_counted,
    /// standard_packing. Ô trống (p.id IS NULL) để NULL ở các cột box thay vì 0,
    /// để màn hình phân biệt được "không có pallet" với "pallet 0 box".
    /// </summary>
    private const string QtyColumns = """
        CASE WHEN ISNULL(bx.qty, 0) > 0 THEN bx.qty
             WHEN ISNULL(mdl.standard_packing, 0) > 0
                  THEN ISNULL(p.box_count, 0) * mdl.standard_packing
             ELSE 0 END, NULL, 0,
        CASE WHEN p.id IS NULL THEN NULL ELSE ISNULL(p.box_count, 0) END, NULL,
        CASE WHEN p.id IS NULL THEN NULL
             WHEN ISNULL(bx.qty, 0) > 0 AND ISNULL(p.box_count, 0) > 0
                  AND bx.qty % p.box_count = 0 THEN bx.qty / p.box_count
             WHEN ISNULL(mdl.standard_packing, 0) > 0 THEN mdl.standard_packing
             ELSE NULL END
        """;

    /// <summary>Danh sách cột của INSERT dòng kiểm kê — dùng chung 2 kiểu phiếu.</summary>
    private const string LineInsertColumns = """
        (count_id, line_no, product_id, locator_id, lot_id,
         qty_system, qty_count, is_adjusted,
         box_count_system, box_count_counted, standard_packing,
         is_required,
         created_at, updated_at, is_deleted)
        """;

    public async Task<CreateCountResult> CreateAsync(string type, IReadOnlyList<string>? areaCodes, string? description, long? userId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var whId = await conn.ExecuteScalarAsync<long?>(
                "SELECT MIN(id) FROM master.warehouses WHERE is_deleted = 0;", null, tx);
            if (whId is null)
            {
                whId = await conn.ExecuteScalarAsync<long>("""
                    INSERT INTO master.warehouses (code, name, is_active, created_at, updated_at, is_deleted)
                    OUTPUT INSERTED.id
                    VALUES (N'SCS', N'Kho thành phẩm', 1, SYSDATETIME(), SYSDATETIME(), 0);
                    """, null, tx);
            }
            var seq = await conn.ExecuteScalarAsync<int>(
                "SELECT COUNT(*) + 1 FROM wms.inventory_counts WHERE count_date = CAST(GETDATE() AS date) AND count_type = @type;",
                new { type }, tx);
            var prefix = type == "morning" ? "M" : "E";
            var docNo = $"KK{prefix}-{DateTime.Now:yyyyMMdd}-{seq:D3}";

            var countId = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.inventory_counts
                    (doc_no, warehouse_id, count_date, doc_status, description, count_type, source_ref,
                     created_at, created_by, updated_at, updated_by, is_deleted)
                OUTPUT INSERTED.id
                VALUES (@docNo, @whId, CAST(GETDATE() AS date), N'pending', @description, @type, NULL,
                        SYSDATETIME(), @userId, SYSDATETIME(), @userId, 0);
                """, new { docNo, whId, description, type, userId }, tx);

            int lineCount;
            if (type == "morning")
            {
                // Buổi sáng: MỌI pallet đang đứng ở ô có biến động hôm qua đều
                // thành dòng (để Web thấy đủ bối cảnh của ô), nhưng chỉ dòng có
                // is_required = 1 mới phải đếm. Ô đã chuyển đi hết ra 1 dòng ô
                // trống, và dòng đó LÀ phải kiểm.
                var t0 = DateTime.Today;
                var y0 = t0.AddDays(-1);
                var insertHead =
                    "INSERT INTO wms.inventory_count_lines\n" + LineInsertColumns + "\n" +
                    "SELECT @countId, ROW_NUMBER() OVER (ORDER BY l.locator_code, p.id),\n" +
                    "       p.category_id, l.id, p.id,\n" +
                    QtyColumns + ",\n" + MorningRequiredCol + ", SYSDATETIME(), SYSDATETIME(), 0";
                lineCount = await conn.ExecuteAsync(
                    MorningSql(insertHead), new { countId, y0, t0 }, tx);
            }
            else // monthly — kiểm THEO Ô: mọi ô của các bản đồ đã chọn, kể cả ô trống
            {
                // Ô có pallet: mỗi pallet 1 dòng.
                // Ô trống: 1 dòng không pallet, không sản phẩm, số hệ thống 0 — công nhân
                // xác nhận trống, hoặc quét "pallet phát sinh" nếu thực tế có hàng ở đó.
                var sql =
                    "INSERT INTO wms.inventory_count_lines\n" + LineInsertColumns + "\n" +
                    "SELECT @countId, ROW_NUMBER() OVER (ORDER BY l.locator_code, p.id),\n" +
                    "       p.category_id, l.id, p.id,\n" +
                    // Cuối tháng kiểm HẾT -> mọi dòng đều phải đếm.
                    QtyColumns + ", 1, SYSDATETIME(), SYSDATETIME(), 0\n" + """
                    FROM master.locators l
                    JOIN master.warehouse_areas a ON a.id = l.area_id AND a.is_deleted = 0 AND a.map_type = N'storing'
                    LEFT JOIN wms.pallets p ON p.locator_id = l.id AND p.is_deleted = 0
                    """ + "\n" + PackingApply + "\n" +
                    $"WHERE l.is_deleted = 0 {AreaFilter(areaCodes)};";
                lineCount = await conn.ExecuteAsync(sql, new { countId, areaCodes }, tx);
            }

            tx.Commit();
            return new CreateCountResult { Id = countId, DocNo = docNo, LineCount = lineCount };
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task CloseAsync(long id, long? userId)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            UPDATE wms.inventory_counts
            SET doc_status = N'closed', updated_at = SYSDATETIME(), updated_by = @userId
            WHERE id = @id AND is_deleted = 0;
            """, new { id, userId });
    }

    /// <summary>
    /// Ghi ghi chú cho 1 dòng (lý do lệch, tình trạng thực tế) mà không đụng số đếm.
    /// Chỉ cho sửa khi phiếu chưa đóng.
    /// </summary>
    public async Task<bool> SetNoteAsync(long lineId, string? note, long? userId)
    {
        using var conn = _factory.Create();
        var rows = await conn.ExecuteAsync("""
            UPDATE cl
            SET cl.note = @note, cl.updated_at = SYSDATETIME(), cl.updated_by = @userId
            FROM wms.inventory_count_lines cl
            JOIN wms.inventory_counts c ON c.id = cl.count_id
            WHERE cl.id = @lineId AND cl.is_deleted = 0
              AND c.doc_status NOT IN (N'closed', N'cancelled');
            """, new { note, userId, lineId });
        return rows > 0;
    }

    public async Task SetCountAsync(long lineId, int qtyCount, string? note, int? boxCountCounted, long? userId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // Dòng ô trống không có pallet để điều chỉnh: chỉ xác nhận 0.
            // Có hàng thật thì phải quét pallet để ghi phát sinh (AddFoundAsync).
            var isEmptySlot = await conn.ExecuteScalarAsync<int>("""
                SELECT CASE WHEN lot_id IS NULL THEN 1 ELSE 0 END
                FROM wms.inventory_count_lines WHERE id = @lineId AND is_deleted = 0;
                """, new { lineId }, tx);
            if (isEmptySlot == 1 && qtyCount != 0) throw new InvalidOperationException("EmptySlotQty");

            // Số box đếm được lưu kèm để đối chiếu với box_count_system.
            // null = người kiểm nhập thẳng số lượng, không đếm theo box.
            await conn.ExecuteAsync("""
                UPDATE wms.inventory_count_lines
                SET qty_count = @qtyCount, note = @note, box_count_counted = @boxCountCounted,
                    updated_at = SYSDATETIME(), updated_by = @userId
                WHERE id = @lineId AND is_deleted = 0;
                """, new { qtyCount, note, boxCountCounted, userId, lineId }, tx);

            // draft -> counting khi bắt đầu có số đếm
            await conn.ExecuteAsync("""
                UPDATE c SET c.doc_status = N'counting', c.updated_at = SYSDATETIME()
                FROM wms.inventory_counts c
                JOIN wms.inventory_count_lines cl ON cl.count_id = c.id
                WHERE cl.id = @lineId AND c.doc_status = N'pending';
                """, new { lineId }, tx);

            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>
    /// Ghi pallet phát sinh tại một ô. Pallet vốn thuộc ô này (đã có dòng) thì trả dòng đó.
    /// Ném <see cref="KeyNotFoundException"/> khi không có pallet; <see cref="InvalidOperationException"/>
    /// (message = mã lỗi) khi ô không thuộc phiếu hoặc pallet đã ghi phát sinh ở ô khác.
    /// </summary>
    public async Task<AddFoundResult> AddFoundAsync(long countId, long locatorId, string palletCode, long? userId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var status = await conn.ExecuteScalarAsync<string?>(
                "SELECT doc_status FROM wms.inventory_counts WHERE id = @countId AND is_deleted = 0;",
                new { countId }, tx);
            if (status is null) throw new InvalidOperationException("CountNotFound");
            if (status == "closed") throw new InvalidOperationException("CountClosed");

            var inSheet = await conn.ExecuteScalarAsync<int>("""
                SELECT COUNT(*) FROM wms.inventory_count_lines
                WHERE count_id = @countId AND locator_id = @locatorId AND is_deleted = 0;
                """, new { countId, locatorId }, tx);
            if (inSheet == 0) throw new InvalidOperationException("LocatorNotInCount");

            var pallet = await conn.QuerySingleOrDefaultAsync<FoundPalletRow>("""
                SELECT TOP 1 id AS [Id], locator_id AS [LocatorId], category_id AS [CategoryId]
                FROM wms.pallets
                WHERE RTRIM(pallet_id) = @palletCode AND is_deleted = 0;
                """, new { palletCode }, tx)
                ?? throw new KeyNotFoundException("PalletNotFound");

            // Đã có dòng của pallet này trong phiếu?
            var existing = (await conn.QueryAsync<FoundLineRow>("""
                SELECT id AS [Id], locator_id AS [LocatorId], is_found AS [IsFound] FROM wms.inventory_count_lines
                WHERE count_id = @countId AND lot_id = @palletId AND is_deleted = 0;
                """, new { countId, palletId = pallet.Id }, tx)).ToList();

            var here = existing.FirstOrDefault(e => e.LocatorId == locatorId);
            if (here is not null)
            {
                tx.Commit();
                return new AddFoundResult { LineId = here.Id, Created = false };
            }
            if (existing.Any(e => e.IsFound))
                throw new InvalidOperationException("PalletAlreadyFound");

            var lineId = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.inventory_count_lines
                    (count_id, line_no, product_id, locator_id, lot_id, qty_system, qty_count, is_adjusted,
                     is_found, system_locator_id, is_required,
                     created_at, created_by, updated_at, updated_by, is_deleted)
                OUTPUT INSERTED.id
                -- is_required = 1: pallet phát sinh luôn phải đếm, nó chính là
                -- cái bất thường của lượt kiểm. Ghi thẳng chứ không dựa vào
                -- DEFAULT của cột, để bỏ default đi thì câu này vẫn đúng.
                SELECT @countId, ISNULL(MAX(line_no), 0) + 1, @categoryId, @locatorId, @palletId, 0, NULL, 0,
                       1, @systemLocatorId, 1, SYSDATETIME(), @userId, SYSDATETIME(), @userId, 0
                FROM wms.inventory_count_lines WHERE count_id = @countId;
                """, new
            {
                countId, locatorId, palletId = pallet.Id, categoryId = pallet.CategoryId,
                systemLocatorId = pallet.LocatorId, userId
            }, tx);

            // Ô hệ thống ghi "trống" mà thực tế có pallet: dòng ô trống coi như đã kiểm
            // (số hệ thống 0 = đếm 0); phần chênh nằm ở dòng phát sinh vừa tạo.
            await conn.ExecuteAsync("""
                UPDATE wms.inventory_count_lines
                SET qty_count = 0, updated_at = SYSDATETIME(), updated_by = @userId
                WHERE count_id = @countId AND locator_id = @locatorId AND lot_id IS NULL
                  AND qty_count IS NULL AND is_deleted = 0;

                UPDATE wms.inventory_counts SET doc_status = N'counting', updated_at = SYSDATETIME()
                WHERE id = @countId AND doc_status = N'pending';
                """, new { countId, locatorId, userId }, tx);

            tx.Commit();
            return new AddFoundResult { LineId = lineId, Created = true };
        }
        catch { tx.Rollback(); throw; }
    }
}
