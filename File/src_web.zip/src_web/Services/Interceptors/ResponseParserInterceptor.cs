﻿using System.Text;
using Newtonsoft.Json;
using SWMS_WebTool.Models.Responses;

namespace SWMS_WebTool.Services.Interceptors
{
    public class ResponseParserInterceptor : DelegatingHandler
    {
        protected override async Task<HttpResponseMessage> SendAsync(HttpRequestMessage request, CancellationToken cancellationToken)
        { 
            var response = await base.SendAsync(request, cancellationToken).ConfigureAwait(false);
            var result = await response.Content.ReadAsStringAsync();

            if (result != null)
            {
                var data = JsonConvert.DeserializeObject<BaseResponse>(result);

                if (response.IsSuccessStatusCode)
                {
                    //response.Content = new StringContent(JsonConvert.SerializeObject(data?.Data, Formatting.None));

                    var json = JsonConvert.SerializeObject(data?.Data, Formatting.None);
                    response.Content = new StringContent(json, Encoding.UTF8, "application/json");
                } 
                else
                {
                    throw new Exception(data?.Detail);
                }
            }

            return response;
        }
    }
}
