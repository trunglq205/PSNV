﻿import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/common/app_tab_bar.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';
import 'package:swms_finish_goods/features/stocky/presentation/providers/stocky_notifier.dart';
import 'package:swms_finish_goods/features/stocky/presentation/widgets/stocky_cart_list_card.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Xe Stocky — quét xe Stocky rồi chốt cả danh sách 1 lần.
//
//  Ba tab, phân biệt theo việc xe CÓ CÒN ĐƯỢC QUẢN LÝ KHÔNG:
//    "Nhập xe"    — vào kho. Xe mới từ vendor, HOẶC xe đang ở FA đưa về.
//    "Xuất FA"    — sang FA. Xe VẪN trong danh sách theo dõi, chỉ đổi vị trí.
//    "Trả vendor" — xe RỜI hệ thống. Đây là đường ra duy nhất.
//
//  ⚠ Trước đây chỉ có 2 tab và "Xuất sang FA" gọi đúng endpoint trả vendor,
//  nên đẩy xe sang FA là xe biến mất khỏi danh sách — sai nghiệp vụ.
//
//  Mỗi lần quét tra server để kiểm xe đúng chiều đang chọn; xe mới quét
//  nằm trên cùng. Đổi tab khi đã có xe → hỏi trước (danh sách sẽ bị bỏ).
// ─────────────────────────────────────────────────────────────

@RoutePage()
class StockyPage extends ConsumerStatefulWidget {
  const StockyPage({super.key});

  @override
  ConsumerState<StockyPage> createState() => _StockyPageState();
}

class _StockyPageState extends ConsumerState<StockyPage> {
  StreamSubscription<String>? _sub;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Await xong mới gán: nếu page đã dispose trong lúc chờ thì subscription
    // sẽ không bao giờ được cancel → rò listener.
    if (!mounted) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      ref.read(stockyProvider.notifier).onScan(data);
    });
  }

  /// AppTabBar không có trạng thái khoá và bấm lại tab đang chọn vẫn gọi
  /// onChanged → chặn ở đây.
  Future<void> _changeTab(StockyMode mode) async {
    final state = ref.read(stockyProvider);
    if (state.mode == mode || state.busy) return;
    if (state.carts.isNotEmpty) {
      final ok = await showConfirmDialog(
        context,
        title: LocaleKeys.stocky_discard_title.tr(),
        message: LocaleKeys.stocky_discard_message.tr(
          namedArgs: {'count': '${state.carts.length}'},
        ),
        confirmVariant: AppButtonVariant.danger,
      );
      if (!ok || !mounted) return;
    }
    ref.read(stockyProvider.notifier).setMode(mode);
  }

  Future<void> _submit() async {
    final state = ref.read(stockyProvider);
    final ok = await showConfirmDialog(
      context,
      title: state.mode.buttonKey.tr(),
      // Câu xác nhận / câu báo xong lấy thẳng từ enum chứ không rẽ nhánh theo
      // mode ở đây: với 3 chiều thì chuỗi `?:` lồng nhau là chỗ dễ sót.
      message: state.mode.confirmKey
          .tr(namedArgs: {'count': '${state.carts.length}'}),
      // Trả vendor là đường ra DUY NHẤT của xe và không có thao tác hoàn tác,
      // nên nút xác nhận để màu cảnh báo cho khác hai chiều còn lại.
      confirmVariant: state.mode == StockyMode.returnVendor
          ? AppButtonVariant.danger
          : AppButtonVariant.primary,
    );
    if (!ok || !mounted) return;

    final result = await ref.read(stockyProvider.notifier).submit();
    if (result == null || !mounted) return;
    AppToastHelper.toastSuccess(
      context,
      state.mode.doneKey.tr(namedArgs: {'count': '${result.cartCount}'}),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(stockyProvider);
    final notifier = ref.read(stockyProvider.notifier);

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.stocky_title.tr(),
        subtitle: LocaleKeys.stocky_subtitle.tr(),
        actions: [
          IconButton(
            tooltip: LocaleKeys.stocky_inwh_title.tr(),
            icon: const Icon(Icons.inventory_2_outlined),
            onPressed: () => context.router.push(const StockyListRoute()),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppDimens.md),
        children: [
          AppTabBar<StockyMode>(
            expanded: true,
            items: [
              for (final m in StockyMode.values)
                AppTabItem(value: m, label: m.tabKey.tr()),
            ],
            selected: state.mode,
            onChanged: _changeTab,
          ),
          const SizedBox(height: AppDimens.sm),
          AppCard(
            padding: const EdgeInsets.all(AppDimens.sm + 4),
            child: BarcodeScannerButton(
              height: 64,
              state: state.lookingUp ? ScannerState.loading : ScannerState.scanning,
              scanningLabel: LocaleKeys.stocky_scan_hint.tr(),
            ),
          ),
          const SizedBox(height: AppDimens.sm),
          StockyCartListCard(
            carts: state.carts,
            onRemove: state.submitting ? null : notifier.remove,
          ),
        ],
      ),
      bottomNavigationBar: AppBottomHint(
        child: AppButton(
          label: state.mode.buttonKey.tr(),
          icon: Icons.local_shipping_rounded,
          size: AppButtonSize.lg,
          isLoading: state.submitting,
          onPressed: state.canSubmit ? _submit : null,
        ),
      ),
    );
  }
}
