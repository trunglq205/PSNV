﻿import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';
import 'package:swms_finish_goods/features/pallet/domain/repositories/pallet_repository.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'split_notifier.g.dart';

/// Kết quả 1 lần quét box ở bước chọn thùng.
enum ScanPickOutcome { picked, already, foreign }

/// Loại pallet đích.
enum SplitTargetKind { existing, newLot }

@immutable
class SplitState {
  /// Pallet gốc. Null khi chưa nạp xong.
  final Pallet? sourcePallet;

  /// Pallet đích đã nạp — chỉ có khi [targetKind] = existing và mã đích đủ
  /// hình dạng pallet_id. Dùng để so category / detail_level / model TRƯỚC
  /// khi gửi lệnh tách.
  final Pallet? targetPallet;

  /// Đang nạp [targetPallet].
  final bool targetLoading;

  /// Không đọc được pallet đích: không tồn tại, hoặc lỗi mạng.
  /// KHÔNG chặn submit — server vẫn là nơi phán quyết cuối.
  final bool targetError;

  /// Toàn bộ box của lot gốc. RỖNG với pallet box_count.
  final List<PalletBox> allBoxes;

  /// Pallet gốc chỉ biết SỐ thùng, không có thùng nào để quét
  /// (detail_level = box_count). Quyết định cả giao diện lẫn thân request.
  final bool byQty;

  /// Tổng số thùng của pallet gốc khi [byQty]. Lấy từ pallet.boxCount.
  final int totalBoxCount;

  /// Số thùng người dùng nhập để tách, khi [byQty].
  final int qty;

  /// id box đã chọn để tách.
  final Set<int> pickedIds;

  /// Bước hiện tại (0 quét gốc – đã xong, 1 chọn thùng, 2 chọn đích).
  final int step;

  /// Mở từ Soạn hàng: thùng đã chọn sẵn là kết quả quét trên server → khoá.
  final bool locked;

  final SplitTargetKind? targetKind;
  final String targetLotNo;

  const SplitState({
    required this.allBoxes,
    this.sourcePallet,
    this.targetPallet,
    this.targetLoading = false,
    this.targetError = false,
    this.byQty = false,
    this.totalBoxCount = 0,
    this.qty = 0,
    this.pickedIds = const {},
    this.step = 1,
    this.targetKind,
    this.targetLotNo = '',
    this.locked = false,
  });

  int get totalBoxes => byQty ? totalBoxCount : allBoxes.length;
  int get pickedCount => byQty ? qty : pickedIds.length;
  int get remainingCount => totalBoxes - pickedCount;

  int get pickedPcs => allBoxes
      .where((b) => pickedIds.contains(b.id))
      .fold(0, (s, b) => s + b.totalQty);
  int get remainingPcs => allBoxes
      .where((b) => !pickedIds.contains(b.id))
      .fold(0, (s, b) => s + b.totalQty);

  bool isPicked(int id) => pickedIds.contains(id);

  /// Phải để lại ít nhất 1 thùng ở pallet gốc — tách hết thì pallet gốc rỗng.
  /// Server cũng chặn (Split.QtyAll), ở đây chặn sớm để khỏi đi một vòng mạng.
  bool get qtyValid => qty > 0 && qty < totalBoxCount;

  bool get canGoToTarget => byQty ? qtyValid : pickedCount > 0;
  bool get canSubmit {
    if (byQty ? !qtyValid : pickedCount == 0) return false;
    return switch (targetKind) {
      SplitTargetKind.newLot => true,
      // Lệch category / detail_level là chặn cứng: server từ chối chắc chắn,
      // không để người dùng bấm rồi mới nhận toast lỗi.
      SplitTargetKind.existing =>
        targetLotNo.trim().isNotEmpty && !targetLoading && !targetBlocked,
      null => false,
    };
  }

  // ── So sánh với pallet đích ──────────────────────────────────
  //
  // Chỉ có ý nghĩa khi targetKind = existing và targetPallet đã nạp.
  // Tách sang lot MỚI thì không có gì để lệch.

  /// Tập model của 1 pallet, suy theo ĐÚNG cách server suy:
  ///   serial / box_line -> DISTINCT box_lines.model  (API trả ở modelSummary)
  ///   box_count         -> cột pallets.model         (API trả ở models)
  static List<String> modelsOf(Pallet? p) {
    if (p == null) return const [];
    if (p.modelQtys.isNotEmpty) {
      return p.modelQtys
          .map((m) => m.model.trim())
          .where((m) => m.isNotEmpty)
          .toList();
    }
    return (p.models ?? '')
        .split(',')
        .map((m) => m.trim())
        .where((m) => m.isNotEmpty)
        .toList();
  }

  /// Model của phần sắp tách ra.
  ///
  /// CHỈ [foreignModels] đọc getter này, và nó đã chặn byQty từ trước, nên
  /// nhánh byQty dưới đây hiện KHÔNG còn đường tới. Giữ lại cho đúng nghĩa
  /// của getter; ai thêm caller mới thì nhớ byQty có luật riêng.
  ///
  /// Thùng không có dòng line nào thì không góp model — PalletBox không mang
  /// cột model riêng như `boxes.model` bên server. Hệ quả: client BỎ SÓT cảnh
  /// báo ở thùng dữ liệu lỗi đó, và vì cờ xác nhận chỉ bật khi client phát
  /// hiện được, người dùng sẽ ăn lỗi Split.ModelMismatch mà không có đường xác
  /// nhận. Cần `boxes.model` trong BoxResponse mới vá được.
  List<String> get movingModels {
    if (byQty) return modelsOf(sourcePallet);
    final out = <String>{};
    for (final b in allBoxes) {
      if (!pickedIds.contains(b.id)) continue;
      for (final l in b.lines) {
        final m = l.model.trim();
        if (m.isNotEmpty) out.add(m);
      }
    }
    return out.toList();
  }

  /// Model đang có trên pallet đích.
  List<String> get targetModels => modelsOf(targetPallet);

  /// Model lạ so với pallet đích — tức phần cần người dùng xác nhận.
  /// Rỗng = gộp thẳng được, hoặc không phải trường hợp xác nhận được.
  ///
  /// GIỮ ĐỒNG BỘ với `SplitModelCheck.ForeignModels` phía server: chỉ tính là
  /// lệch khi pallet đích có ĐÚNG 1 model. Đích rỗng hoặc đã đa model thì
  /// server cho gộp, nên client cũng không cảnh báo.
  ///
  /// Trả rỗng với pallet box_count: server chặn cứng nhóm này kể cả khi có cờ
  /// xác nhận (model box_count chỉ nằm ở cột pallets.model, gộp vào sẽ khai
  /// sai model và sai tổng SL). Mời xác nhận ở đây thì người dùng bấm đồng ý
  /// rồi vẫn ăn lỗi — tệ hơn là không mời.
  List<String> get foreignModels {
    if (targetKind != SplitTargetKind.existing) return const [];
    if (byQty) return const [];
    final t = targetModels;
    if (t.length != 1) return const [];
    final tm = t.first.toLowerCase();
    return movingModels.where((m) => m.toLowerCase() != tm).toList();
  }

  /// Khác model — cho tách nhưng phải xác nhận.
  bool get hasModelMismatch => foreignModels.isNotEmpty;

  /// Khác category — chặn cứng, không có đường xác nhận.
  bool get categoryMismatch =>
      targetKind == SplitTargetKind.existing &&
      sourcePallet != null &&
      targetPallet != null &&
      sourcePallet!.categoryCode != targetPallet!.categoryCode;

  /// Khác cấp chi tiết — chặn cứng (gộp vào sẽ lẫn 2 kiểu dữ liệu).
  bool get detailLevelMismatch =>
      targetKind == SplitTargetKind.existing &&
      sourcePallet != null &&
      targetPallet != null &&
      sourcePallet!.detailLevel.toLowerCase() !=
          targetPallet!.detailLevel.toLowerCase();

  bool get targetBlocked => categoryMismatch || detailLevelMismatch;

  SplitState copyWith({
    int? qty,
    Set<int>? pickedIds,
    int? step,
    SplitTargetKind? targetKind,
    String? targetLotNo,
    bool clearTargetKind = false,
    bool? locked,
    Pallet? targetPallet,
    bool clearTargetPallet = false,
    bool? targetLoading,
    bool? targetError,
  }) {
    return SplitState(
      allBoxes: allBoxes,
      sourcePallet: sourcePallet,
      targetPallet: clearTargetPallet
          ? null
          : (targetPallet ?? this.targetPallet),
      targetLoading: targetLoading ?? this.targetLoading,
      targetError: targetError ?? this.targetError,
      byQty: byQty,
      totalBoxCount: totalBoxCount,
      qty: qty ?? this.qty,
      pickedIds: pickedIds ?? this.pickedIds,
      step: step ?? this.step,
      targetKind: clearTargetKind ? null : (targetKind ?? this.targetKind),
      targetLotNo: targetLotNo ?? this.targetLotNo,
      locked: locked ?? this.locked,
    );
  }
}

/// Tách pallet. Family theo lot_no gốc; thùng lấy từ [palletProvider].
/// Loading/error của API do `appActionProvider` lo.
@riverpod
class SplitNotifier extends _$SplitNotifier {
  PalletRepository get _repo => ref.read(palletRepositoryProvider);

  @override
  SplitState build(String lotNo) {
    final pallet = ref.watch(palletProvider(lotNo)).value;
    final boxes = pallet?.boxes ?? const <PalletBox>[];

    // Kiểu tách do DỮ LIỆU quyết định, không do người dùng chọn: pallet
    // box_count không có dòng thùng nào nên không thể quét.
    final byQty = pallet?.detailLevel == kDetailLevelBoxCount;

    return SplitState(
      allBoxes: boxes,
      sourcePallet: pallet,
      byQty: byQty,
      totalBoxCount: byQty ? (pallet?.boxCount ?? 0) : boxes.length,
    );
  }

  /// Mã pallet đích đã tra cứu được chưa.
  ///
  /// Chỉ cần KHÁC RỖNG, không ràng 12 chữ số: mã đích vào đây chỉ qua súng
  /// quét (xem _onScan của màn tách — không có ô nhập tay nào), nên không có
  /// chuyện gọi API theo từng ký tự. Và server tra đích bằng
  /// `WHERE pallet_id = @lotNo OR stocky_code = @lotNo`, nên quét mã xe Stocky
  /// cũng là mã đích hợp lệ — ràng 12 số sẽ bỏ sót đúng nhóm đó.
  static bool _isLookupReady(String code) => code.isNotEmpty;

  /// Số thứ tự request nạp pallet đích. Người dùng gõ mã khác trong lúc chờ
  /// thì kết quả cũ về sau phải bị bỏ, không được ghi lên state.
  int _targetSeq = 0;

  /// Đặt số thùng cần tách. Kẹp trong [0, tổng số] để nút +/- và ô nhập tay
  /// không đẩy ra ngoài khoảng hợp lệ.
  void setQty(int value) {
    if (!state.byQty || state.locked) return;
    final v = value < 0 ? 0 : (value > state.totalBoxCount ? state.totalBoxCount : value);
    state = state.copyWith(qty: v);
  }

  /// Mở từ Soạn hàng: chọn sẵn thùng đã lấy, KHOÁ danh sách, nhảy thẳng sang
  /// bước chọn đích (mặc định lot mới — thùng xuất đi pallet riêng).
  void preselect(Set<int> boxIds) {
    final valid = state.allBoxes
        .map((b) => b.id)
        .where(boxIds.contains)
        .toSet();
    state = state.copyWith(
      pickedIds: valid,
      step: 2,
      targetKind: SplitTargetKind.newLot,
      locked: true,
    );
  }

  /// Quét 1 box ở bước chọn thùng.
  ScanPickOutcome onScanBox(String rawCode) {
    if (state.locked) return ScanPickOutcome.already;

    final code = rawCode.trim();
    if (code.isEmpty) return ScanPickOutcome.foreign;

    PalletBox? box;
    for (final b in state.allBoxes) {
      if (b.boxNo == code) {
        box = b;
        break;
      }
    }
    if (box == null) return ScanPickOutcome.foreign;
    if (state.pickedIds.contains(box.id)) return ScanPickOutcome.already;

    state = state.copyWith(pickedIds: {...state.pickedIds, box.id});
    return ScanPickOutcome.picked;
  }

  void unpick(int id) {
    if (state.locked) return;
    final s = {...state.pickedIds}..remove(id);
    state = state.copyWith(pickedIds: s);
  }

  void goToStep(int step) => state = state.copyWith(step: step);

  void chooseTargetKind(SplitTargetKind kind) {
    _targetSeq++; // bỏ kết quả của lần nạp đang chờ
    state = state.copyWith(
      targetKind: kind,
      targetLotNo: '',
      clearTargetPallet: true,
      targetLoading: false,
      targetError: false,
    );
  }

  /// Đặt mã pallet đích, rồi nạp luôn thông tin pallet đó để so
  /// category / detail_level / model ngay tại bước này.
  void setTargetLotNo(String value) {
    final code = value.trim();

    // Mã này đã xử lý xong rồi -> không gọi lại. Tính cả targetError: súng quét
    // ở chế độ quét liên tục bắn lại cùng một mã vài lần mỗi giây, không chốt
    // thì một mã không tra được sẽ thành tràng 404. Muốn thử lại thì bấm nút
    // "Thử lại" (retryTargetLookup) — một chủ ý rõ ràng, không phải lặp máy.
    if (code == state.targetLotNo &&
        (state.targetPallet != null ||
            state.targetLoading ||
            state.targetError)) {
      return;
    }

    _targetSeq++;
    state = state.copyWith(
      targetLotNo: code,
      clearTargetPallet: true,
      targetLoading: false,
      targetError: false,
    );

    if (!_isLookupReady(code)) return;
    unawaited(_loadTarget(code, _targetSeq));
  }

  /// Nạp lại pallet đích sau khi lỗi. Có nút riêng vì quét lại cùng một mã
  /// không còn tự gọi lại nữa (xem chốt chống lặp ở [setTargetLotNo]).
  ///
  /// Đây là đường thoát cho lỗi mạng chốc lát: không có nó thì một lần nghẽn
  /// đúng lúc quét mã đích sẽ làm cảnh báo khác model không bao giờ hiện, và
  /// người dùng mắc kẹt với lỗi Split.ModelMismatch mà không có cách nào xác
  /// nhận để đi tiếp.
  void retryTargetLookup() {
    final code = state.targetLotNo.trim();
    if (code.isEmpty || state.targetLoading) return;

    _targetSeq++;
    state = state.copyWith(targetError: false, clearTargetPallet: true);
    unawaited(_loadTarget(code, _targetSeq));
  }

  /// Kết quả về còn dùng được không: chưa bị dispose, chưa có request mới, và
  /// mã đích trên state vẫn là mã đã hỏi. Điều kiện cuối chặn cả trường hợp
  /// build() chạy lại (palletProvider bị invalidate) làm state reset giữa chừng.
  bool _isTargetResultFresh(String code, int seq) =>
      ref.mounted && seq == _targetSeq && state.targetLotNo == code;

  Future<void> _loadTarget(String code, int seq) async {
    state = state.copyWith(targetLoading: true);
    try {
      // createIfMissing: false — BẮT BUỘC. Mặc định của getByLotNo là true:
      // gặp 404 nó gọi /from-foss và TẠO pallet. Ở đây mã do người dùng gõ,
      // sai một số là tự sinh pallet rác trong kho.
      final target = await _repo.getByLotNo(code, createIfMissing: false);
      if (!_isTargetResultFresh(code, seq)) return;
      state = state.copyWith(targetPallet: target, targetLoading: false);
    } catch (_) {
      // 404 (mã không có) và lỗi mạng gộp chung: chỉ hiện gợi ý mờ, không
      // chặn submit. Lệnh tách vẫn đi và server trả lỗi đúng nếu mã sai.
      if (!_isTargetResultFresh(code, seq)) return;
      state = state.copyWith(targetLoading: false, targetError: true);
    }
  }

  /// Gọi API tách. Null nếu chưa đủ điều kiện hoặc API lỗi (đã toast).
  ///
  /// [confirmModelMismatch]: người dùng đã bấm đồng ý trên dialog cảnh báo
  /// pallet đích khác model. Không truyền thì server chặn như trước.
  Future<SplitResult?> submit({bool confirmModelMismatch = false}) async {
    if (!state.canSubmit) return null;

    final result = await ref.read(appActionProvider.notifier).run(() {
      return _repo.split(
        sourceLotNo: lotNo,
        boxIds: state.byQty ? const [] : state.pickedIds.toList(),
        boxQty: state.byQty ? state.qty : null,
        toNewLot: state.targetKind == SplitTargetKind.newLot,
        targetLotNo: state.targetLotNo.trim(),
        confirmModelMismatch: confirmModelMismatch,
      );
    });

    if (result != null) {
      // Lot gốc (và lot đích nếu có sẵn) đã đổi thùng -> nạp lại.
      ref.invalidate(palletProvider(lotNo));
      if (!result.targetIsNew) ref.invalidate(palletProvider(result.targetLotNo));
    }
    return result;
  }
}
