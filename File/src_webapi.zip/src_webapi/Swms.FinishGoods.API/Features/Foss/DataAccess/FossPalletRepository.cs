using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Foss.DataAccess;

public class FossPalletRepository : IFossPalletRepository
{
    private readonly IFossDbConnectionFactory _factory;

    public FossPalletRepository(IFossDbConnectionFactory factory)
        => _factory = factory;

    public async Task<IReadOnlyList<FossPalletRow>> GetByBarcodeAsync(
        FossCategory category, string barcode)
    {
        var tableName = ResolveTableName(category);
        var tableProductName = ResolveProductTableName(category);

        // tableName sinh từ enum (whitelist) -> an toàn nội suy.
        // barcode LUÔN đi qua tham số @Barcode -> không injection.
        var sql = $"""
            SELECT
                pc.Source_pallet AS PalletNo,
                pc.SERIAL_OUTER  AS BoxNo,
                pc.sModelNo      AS ModelNo,
                pc.sSerialNo     AS SerialNo,
                pc.dShrinkDate   AS ProductionDate,
                pc.dShrinkBy     AS ShrinkBy,
                p.STATUS_FA      AS OQCStatus,
                p.COD_SCALE_NO   AS Line,
                p.LOT_NAME       AS LotName,
                p.TMR_DATE       AS DateInsert
            FROM dbo.[{tableName}] AS pc
            OUTER APPLY (
                SELECT TOP 1 t.STATUS_FA, t.COD_SCALE_NO, t.LOT_NAME, t.TMR_DATE
                FROM dbo.[{tableProductName}] AS t
                WHERE t.STR_SERIAL = pc.sSerialNo
                  AND t.STR_PROCESS_FACTORY = pc.sModelNo
                ORDER BY t.TMR_DATE DESC
            ) AS p
            WHERE pc.Source_pallet = @Barcode AND pc.Status = 0
            ORDER BY pc.SERIAL_OUTER, pc.sSerialNo;
            """;

        using var conn = _factory.Create();

        var rows = await conn.QueryAsync<FossPalletRow>(
            sql,
            new { Barcode = barcode },
            commandTimeout: 60);

        return rows.ToList();
    }

    // --- Dựng tên bảng: thuộc data access ------------------------------------

    /// <summary>Tên bảng đầy đủ tblPalletCombine{suffix}.</summary>
    private static string ResolveTableName(FossCategory category)
        => $"tblPalletCombine{TableSuffix(category)}";

    private static string ResolveProductTableName(FossCategory category)
    => $"TBLPRODUCT{TableSuffix(category)}";

    /// <summary>Hậu tố tên bảng. Default -> chuỗi rỗng.</summary>
    private static string TableSuffix(FossCategory category)
        => category == FossCategory.Default ? string.Empty : $"_{category}";

    public async Task<IReadOnlyList<string>> GetTodayPalletsAsync()
    {
        const string sql = """
        SELECT DISTINCT Source_pallet
        FROM
        (
            SELECT Source_pallet
            FROM dbo.tblPalletCombine_DP
            WHERE dShrinkDate >= CAST(GETDATE() AS DATE)
              AND dShrinkDate < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))

            UNION ALL

            SELECT Source_pallet
            FROM dbo.tblPalletCombine_CAM
            WHERE dShrinkDate >= CAST(GETDATE() AS DATE)
              AND dShrinkDate < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))

            UNION ALL

            SELECT Source_pallet
            FROM dbo.tblPalletCombine_HP
            WHERE dShrinkDate >= CAST(GETDATE() AS DATE)
              AND dShrinkDate < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))

            UNION ALL

            SELECT Source_pallet
            FROM dbo.tblPalletCombine_MW
            WHERE dShrinkDate >= CAST(GETDATE() AS DATE)
              AND dShrinkDate < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))

            UNION ALL
        
            SELECT Source_pallet
            FROM dbo.tblPalletCombine_PEWVN
            WHERE dShrinkDate >= CAST(GETDATE() AS DATE)
              AND dShrinkDate < DATEADD(DAY, 1, CAST(GETDATE() AS DATE))
        ) P
        ORDER BY Source_pallet;
        """;

        using var conn = _factory.Create();

        var pallets = await conn.QueryAsync<string>(
            sql,
            commandTimeout: 60);

        return pallets.ToList();
    }

    public async Task<IReadOnlyList<FossPalletSummary>> GetPalletSummariesAsync(
    FossCategory category, IReadOnlyCollection<string> barcodes)
    {
        if (barcodes.Count == 0) return [];

        var tableName = ResolveTableName(category);

        // Chỉ đếm trên tblPalletCombine — không join TBLPRODUCT nên rất nhẹ.
        var sql = $"""
        SELECT pc.Source_pallet                 AS PalletNo,
               COUNT(DISTINCT pc.SERIAL_OUTER)  AS BoxCount,
               COUNT(DISTINCT pc.sSerialNo)     AS SerialCount,
               MAX(pc.dShrinkDate)              AS LastShrinkDate
        FROM dbo.[{tableName}] AS pc
        WHERE pc.Source_pallet IN @Barcodes AND pc.Status = 0
        GROUP BY pc.Source_pallet;
        """;

        using var conn = _factory.Create();
        var result = new List<FossPalletSummary>(barcodes.Count);

        // IN @list: chia khối để không vượt 2100 tham số.
        foreach (var chunk in barcodes.Chunk(1000))
            result.AddRange(await conn.QueryAsync<FossPalletSummary>(
                sql, new { Barcodes = chunk }, commandTimeout: 60));

        return result;
    }
}
