import 'package:swms_finish_goods/features/stocktake/data/datasources/stocktake_remote_data_source.dart';
import 'package:swms_finish_goods/features/stocktake/data/models/stocktake_models.dart';
import 'package:swms_finish_goods/features/stocktake/domain/entities/stocktake_entities.dart';
import 'package:swms_finish_goods/features/stocktake/domain/repositories/stocktake_repository.dart';

class StocktakeRepositoryImpl implements StocktakeRepository {
  final StocktakeRemoteDataSource _remote;
  StocktakeRepositoryImpl(this._remote);

  @override
  Future<List<CountSummary>> fetchCounts({String? type}) async {
    final rows = await _remote.fetchCounts(type: type);
    return rows.map((e) => e.toEntity()).toList();
  }

  @override
  Future<CountDetail> fetchCount(int id) async {
    final d = await _remote.fetchCount(id);
    return d.toEntity();
  }

  @override
  Future<void> setCount(int lineId, int qty, {String? note, int? boxCount}) =>
      _remote.setCount(
        lineId,
        SetCountRequestModel(
          qtyCount: qty,
          note: note,
          boxCountCounted: boxCount,
        ),
      );

  @override
  Future<void> closeCount(int id) => _remote.closeCount(id);

  @override
  Future<int> addFound(int countId, int locatorId, String palletId) async {
    final r = await _remote.addFound(
      countId,
      AddFoundRequestModel(locatorId: locatorId, palletId: palletId),
    );
    return r.lineId;
  }
}
