import 'package:dio/dio.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';

// ─────────────────────────────────────────────────────────────────────────────
// BaseNotifierMixin  —  dùng với Notifier<T>  (state kiểu T)
//
// Covers:
//   ① executePartial<F>  — update 1 field AsyncValue<F> trong state phức hợp
//   ② applyOptimistic    — không loading, update ngay, rollback nếu lỗi
//
// Dùng cho: HomeNotifier
// ─────────────────────────────────────────────────────────────────────────────
mixin BaseNotifierMixin<T> {
  T get state;
  set state(T value);

  /// Chỉ 1 field AsyncValue\<F> trong state phức hợp chuyển loading → data|error.
  /// Phần còn lại của state giữ nguyên.
  Future<void> executePartial<F>({
    required Future<F> Function() action,
    required AsyncValue<F> Function(T state) getField,
    required T Function(T state, AsyncValue<F> field) setField,
  }) async {
    state = setField(state, const AsyncValue.loading());
    try {
      final result = await action();
      state = setField(state, AsyncValue.data(result));
    } on AppException catch (e, st) {
      state = setField(state, AsyncValue.error(e, st));
    } on DioException catch (e, st) {
      state = setField(state, AsyncValue.error(e.error ?? e, st));
    } catch (e, st) {
      state = setField(state, AsyncValue.error(UnknownException(e.toString()), st));
    }
  }

  /// Không loading. Cập nhật state ngay (optimistic), rollback về prev nếu lỗi.
  Future<void> applyOptimistic(
      T next,
      Future<void> Function(T next) save, {
        void Function(Object error, StackTrace st)? onError,
      }) async {
    final prev = state;
    state = next;
    try {
      await save(next);
    } catch (e, st) {
      state = prev;
      onError?.call(e, st);
      rethrow;
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// BaseAsyncNotifierMixin  —  dùng với AsyncNotifier<T>  (state kiểu AsyncValue<T>)
//
// Covers:
//   ① execute            — cả state chuyển loading → data | error
//   ② applyOptimistic    — không loading, update ngay, rollback nếu lỗi
//
// Dùng cho: AuthNotifier, SettingsNotifier
// ─────────────────────────────────────────────────────────────────────────────
mixin BaseAsyncNotifierMixin<T> {
  AsyncValue<T> get state;
  set state(AsyncValue<T> value);

  /// Cả state chuyển loading → data | error.
  Future<void> execute(Future<T> Function() action) async {
    state = const AsyncValue.loading();
    try {
      state = AsyncValue.data(await action());
    } on AppException catch (e, st) {
      state = AsyncValue.error(e, st);
    } on DioException catch (e, st) {
      state = AsyncValue.error(e.error ?? e, st);
    } catch (e, st) {
      state = AsyncValue.error(UnknownException(e.toString()), st);
    }
  }

  /// Không loading. Cập nhật data ngay (optimistic), rollback nếu lỗi.
  /// Chỉ hoạt động khi state hiện tại đang là AsyncData (đã load xong).
  Future<void> applyOptimistic(
      T next,
      Future<void> Function(T next) save, {
        void Function(Object error, StackTrace st)? onError,
      }) async {
    final prev = state; // snapshot toàn bộ AsyncValue (kể cả error)
    state = AsyncValue.data(next);
    try {
      await save(next);
    } catch (e, st) {
      state = prev; // rollback về đúng snapshot cũ
      onError?.call(e, st);
      rethrow;
    }
  }
}