import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';

/// Chip màu lot: ô màu + tên màu. Ghi kèm tên vì công nhân mù màu / màn
/// PDA ngoài nắng khó phân biệt đỏ – cam.
class LotChip extends StatelessWidget {
  final LotColor lot;
  const LotChip({super.key, required this.lot});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: c.card,
        border: Border.all(color: c.border),
        borderRadius: BorderRadius.circular(AppDimens.rInput),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 10,
            height: 10,
            decoration: BoxDecoration(
              color: lot.swatch,
              borderRadius: BorderRadius.circular(3),
            ),
          ),
          const SizedBox(width: 5),
          Text(
            lot.labelKey.tr(),
            style: AppTextStyles.caption.copyWith(
              color: c.text2,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
