﻿using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.TempLocMap.Api;

// ---------- Response ----------

/// <summary>Một ô trên map trả về cho client.</summary>
public record MapCellResponse(
    long Id,
    string? Code,
    string CellType,
    int GridX, int GridY, int GridW, int GridH,
    string? Arrow,
    string? Color,
    string? Label,
    string Status,
    string? Model,
    string? LotNo,
    int SortOrder,
    IReadOnlyList<LotInfo>? Lots = null,   // các lot đang nằm trên pallet (null nếu zone/không có)
    bool IsUrgent = false)                 // cờ khẩn độc lập (từ is_urgent của lot)
{
    // Id gửi cho client = locator_map.id (MapId): là id round-trip khi lưu layout.
    // Việc ghép lot vào ô dùng MapLocator.Id (=locator id) và được xử lý ở service.
    public static MapCellResponse From(MapLocator l) => new(
        l.MapId, l.LocatorCode, l.CellType,
        l.GridX, l.GridY, l.GridW, l.GridH,
        l.Arrow, l.Color, l.Label,
        l.CurrentStatus, null, null, l.SortOrder);
}

/// <summary>Thông tin 1 lot hiển thị trên panel khi click pallet.</summary>
public record LotInfo(
    long LotId,
    string LotNo,
    string InspectionStatus,   // giá trị thô từ wms.pallets
    string MappedStatus,       // đã map sang 7 trạng thái màu
    bool IsUrgent,
    int? BoxCount,
    string? Models,
    DateTime? ProductionDate,

    /// <summary>rework | refurbish | null — dấu RW/RB cạnh Pallet ID.</summary>
    string? Disposition)
{
    public static LotInfo From(PalletLot p, string mapped) => new(
        p.LotId, p.LotNo, p.InspectionStatus, mapped,
        p.IsUrgent, p.BoxCount, p.Models, p.ProductionDate, p.Disposition);
}

/// <summary>Layout đầy đủ của 1 khu (khung lưới + toàn bộ ô).</summary>
public record MapLayoutResponse(
    long AreaId,
    string AreaCode,
    string AreaName,
    int Cols,
    int Rows,
    decimal CellMeters,
    IReadOnlyList<MapCellResponse> Cells);

public record AreaSummaryResponse(
    long Id, string AreaCode, string AreaName, int Cols, int Rows, decimal CellMeters, bool IsActive)
{
    public static AreaSummaryResponse From(WarehouseArea a) =>
        new(a.Id, a.AreaCode, a.AreaName, a.Cols, a.Rows, a.CellMeters, a.IsActive);
}

// ---------- Request ----------

/// <summary>1 ô khi client lưu layout. Id=null ⇒ ô mới.</summary>
public record SaveCellRequest(
    long? Id,
    string? Code,
    [Required] string CellType,
    int GridX, int GridY,
    [Range(1, 10000)] int GridW,
    [Range(1, 10000)] int GridH,
    string? Arrow,
    string? Color,
    [MaxLength(200)] string? Label,
    string? Status,
    [MaxLength(100)] string? Model,
    [MaxLength(50)] string? LotNo,
    int SortOrder);

/// <summary>Lưu toàn bộ layout của 1 khu (thay thế danh sách ô).</summary>
public record SaveLayoutRequest(
    [Range(1, 10000)] int Cols,
    [Range(1, 10000)] int Rows,
    [Range(0.01, 100)] decimal CellMeters,
    [Required] List<SaveCellRequest> Cells);

/// <summary>Đổi trạng thái nhanh 1 vị trí pallet (ghi lịch sử).</summary>
public record ChangeStatusRequest(
    [Required] string Status,
    [MaxLength(100)] string? Model,
    [MaxLength(50)] string? LotNo);

/// <summary>Tạo khu mới (lưới trống).</summary>
public record CreateAreaRequest(
    [Required, MaxLength(50)] string AreaCode,
    [Required, MaxLength(200)] string AreaName,
    [Range(1, 10000)] int Cols,
    [Range(1, 10000)] int Rows,
    [Range(0.01, 100)] decimal CellMeters);

/// <summary>Thông tin vị trí, khu vực và danh sách pallet_id đang chứa.</summary>
public record LocatorPalletsResponse(
    long LocatorId,
    string LocatorCode,
    string? AreaCode,
    string? AreaName,
    string? MapType,
    IReadOnlyList<string> Pallets)
{
    public static LocatorPalletsResponse From(LocatorOccupancy o) => new(
        o.LocatorId, o.LocatorCode, o.AreaCode, o.AreaName, o.MapType, o.Pallets);
}