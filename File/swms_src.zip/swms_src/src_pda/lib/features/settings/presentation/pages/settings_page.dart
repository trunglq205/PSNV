import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/utils/app_launcher.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_switch.dart';
import 'package:swms_finish_goods/features/settings/domain/settings_entity.dart';
import 'package:swms_finish_goods/features/settings/presentation/dialogs/language_dialog.dart';
import 'package:swms_finish_goods/features/settings/presentation/providers/settings_notifier.dart';
import 'package:swms_finish_goods/features/settings/presentation/widgets/update_card.dart';

/// Màn hình Cài đặt & Hồ sơ người dùng (PDA).
@RoutePage()
class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(settingsProvider);
    final notifier = ref.read(settingsProvider.notifier);

    final stack = context.router.stack;
    final hasLoginRoute = stack.any((route) => route.name == LoginRoute.name);

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.settings_title.tr(),
        subtitle: LocaleKeys.settings_subtitle.tr(),
      ),
      body: async.when(
        loading: () => const AppLoading(),
        error: (e, _) =>
            AppErrorView.page(message: LocaleKeys.settings_load_error.tr()),
        data: (s) => ListView(
          padding: const EdgeInsets.all(AppDimens.md),
          children: [
            _SettingsCard(settings: s, notifier: notifier),
            const SizedBox(height: AppDimens.sm),
            const _LauncherCard(),
            const SizedBox(height: AppDimens.sm),
            const UpdateCard(),

            if (!hasLoginRoute) ...[
              const SizedBox(height: AppDimens.sm),
              AppButton(
                label: LocaleKeys.settings_logout.tr(),
                variant: AppButtonVariant.danger,
                onPressed: () async {
                  await notifier.logout();

                  if (context.mounted) {
                    await context.router.replaceAll([const LoginRoute()]);
                  }
                },
              ),
            ],
          ],
        ),
      ),
    );
  }
}

/// Card "Cài đặt" — danh sách hàng key/value, có switch cho mục bật/tắt.
class _SettingsCard extends StatelessWidget {
  final SettingsEntity settings;
  final SettingsNotifier notifier;

  const _SettingsCard({required this.settings, required this.notifier});

  @override
  Widget build(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _CardHeader(title: LocaleKeys.settings_general.tr()),
          _NavRow(
            label: LocaleKeys.settings_language.tr(),
            value: settings.language.name,
            onTap: () async {
              final picked = await showLanguageMenu(
                context,
                current: settings.language,
              );
              if (context.mounted && picked != null) {
                await context.setLocale(Locale(picked.code));
                await notifier.setLanguage(picked);
              }
            },
          ),
          const Divider(),
          _SwitchRow(
            label: LocaleKeys.settings_sound_alert.tr(),
            value: settings.soundAlert,
            onChanged: notifier.setSoundAlert,
          ),
        ],
      ),
    );
  }
}

/// Card "Ứng dụng khác" — lưới launcher 4 cột mở app hệ thống qua intent.
class _LauncherCard extends StatelessWidget {
  const _LauncherCard();

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final apps = <_LauncherApp>[
      _LauncherApp(
        LocaleKeys.apps_settings.tr(),
        Icons.settings,
        const Color(0xFF5B6470),
        () {
          AppLauncher.openSettings();
        },
      ),
      _LauncherApp('apps.wifi'.tr(), Icons.wifi, AppColors.primary, () {
        AppLauncher.openWifi();
      }),
      _LauncherApp(
        LocaleKeys.apps_datawedge.tr(),
        Icons.qr_code_scanner,
        const Color(0xFF1F8A5B),
        () {
          AppLauncher.openDataWedge();
        },
      ),
      _LauncherApp(
        LocaleKeys.apps_smart_warehouse.tr(),
        Icons.warehouse_outlined,
        const Color(0xFF7A4DD0),
        () {
          AppLauncher.openSmartWarehouse();
        },
      ),
    ];

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.settings_other_apps.tr(),
            style: AppTextStyles.h2.copyWith(color: swms.text1),
          ),
          const SizedBox(height: AppDimens.sm),
          GridView.count(
            crossAxisCount: 4,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 10,
            crossAxisSpacing: 6,
            childAspectRatio: 0.78,
            children: [for (final a in apps) _LauncherTile(app: a)],
          ),
        ],
      ),
    );
  }
}

// ── Sub-components ──

class _CardHeader extends StatelessWidget {
  final String title;

  const _CardHeader({required this.title});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppDimens.sm),
      child: Text(
        title,
        style: AppTextStyles.title.copyWith(color: context.swms.text1),
      ),
    );
  }
}

/// Hàng điều hướng: label trái, value + chevron phải.
class _NavRow extends StatelessWidget {
  final String label;
  final String value;
  final VoidCallback onTap;

  const _NavRow({
    required this.label,
    required this.value,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return InkWell(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.symmetric(vertical: AppDimens.xs),
        child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(label, style: AppTextStyles.body.copyWith(color: swms.text1)),
            Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Text(
                  value,
                  style: AppTextStyles.label.copyWith(color: swms.text3),
                ),
                const SizedBox(width: 2),
                Icon(Icons.chevron_right, size: 16, color: swms.text3),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Hàng có công tắc bật/tắt.
class _SwitchRow extends StatelessWidget {
  final String label;
  final bool value;
  final ValueChanged<bool> onChanged;

  const _SwitchRow({
    required this.label,
    required this.value,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceBetween,
      children: [
        Expanded(
          child: Text(
            label,
            style: AppTextStyles.body.copyWith(color: swms.text1),
          ),
        ),
        AppSwitch(value: value, onChanged: onChanged),
      ],
    );
  }
}

class _LauncherApp {
  final String label;
  final IconData icon;
  final Color color;
  final VoidCallback launcherApp;

  const _LauncherApp(this.label, this.icon, this.color, this.launcherApp);
}

class _LauncherTile extends StatelessWidget {
  final _LauncherApp app;

  const _LauncherTile({required this.app});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return InkWell(
      onTap: app.launcherApp,
      borderRadius: BorderRadius.circular(13),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Container(
            width: 46,
            height: 46,
            decoration: BoxDecoration(
              color: app.color.withValues(alpha: 0.08),
              borderRadius: BorderRadius.circular(13),
              border: Border.all(color: app.color.withValues(alpha: 0.15)),
            ),
            child: Icon(app.icon, size: 22, color: app.color),
          ),
          const SizedBox(height: 6),
          Text(
            app.label,
            textAlign: TextAlign.center,
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.caption.copyWith(
              fontSize: 10.5,
              fontWeight: FontWeight.w600,
              color: swms.text2,
            ),
          ),
        ],
      ),
    );
  }
}
