namespace Swms.FinishGoods.API.Shared.Models;

public class User
{
    public int Id { get; set; }
    public string FullName { get; set; } = string.Empty;
    public string? Email { get; set; }
    public string Department { get; set; } = string.Empty;   // SCS | FA | OQC | SEC | IT
    public string EmployeeCode { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public bool IsDeleted { get; set; }
    public DateTime? LastLoginAt { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public string? UpdatedBy { get; set; }

    // Đa vai trò: nạp từ master.user_roles JOIN master.roles
    public List<string> RoleCodes { get; set; } = new();
}

public class Role
{
    public int Id { get; set; }
    public string Code { get; set; } = string.Empty;   // admin | manager | operator | viewer | security_guard
    public string Name { get; set; } = string.Empty;
    public string? Description { get; set; }
    public string Dot { get; set; } = "info";          // màu chip hiển thị trên UI
}