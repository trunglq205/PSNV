import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/router/app_router.dart';

part 'router_provider.g.dart';

@Riverpod(keepAlive: true)
AppRouter appRouter(Ref ref) => AppRouter();

/// Theo dõi vòng đời route — để màn pause/resume scan khi bị che/quay lại.
@Riverpod(keepAlive: true)
RouteObserver<ModalRoute<void>> routeObserver(Ref ref) =>
    RouteObserver<ModalRoute<void>>();
