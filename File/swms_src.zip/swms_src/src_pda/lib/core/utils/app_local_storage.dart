import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Quản lý toàn bộ việc đọc/ghi dữ liệu cục bộ của app.
/// - Dữ liệu nhạy cảm (token...) → [FlutterSecureStorage]
/// - Dữ liệu thường (settings, preferences...) → [SharedPreferences]
class AppLocalStorage {
  final FlutterSecureStorage _secure;
  final SharedPreferences _prefs;

  const AppLocalStorage(this._secure, this._prefs);

  // ─── Secure ──────────────────────────────────────────────────────────────

  Future<void> writeSecure(String key, String value) =>
      _secure.write(key: key, value: value);

  Future<String?> readSecure(String key) =>
      _secure.read(key: key);

  Future<void> deleteSecure(String key) =>
      _secure.delete(key: key);

  // ─── Preferences ─────────────────────────────────────────────────────────

  Future<void> writeString(String key, String value) =>
      _prefs.setString(key, value);

  String? readString(String key) => _prefs.getString(key);

  Future<void> writeBool(String key, bool value) =>
      _prefs.setBool(key, value);

  bool? readBool(String key) => _prefs.getBool(key);

  Future<void> writeInt(String key, int value) =>
      _prefs.setInt(key, value);

  int? readInt(String key) => _prefs.getInt(key);

  Future<void> writeStringList(String key, List<String> value) =>
      _prefs.setStringList(key, value);

  List<String>? readStringList(String key) => _prefs.getStringList(key);

  Future<void> remove(String key) => _prefs.remove(key);

  // ─── Clear all ───────────────────────────────────────────────────────────

  Future<void> clearAll() async {
    await _secure.deleteAll();
    await _prefs.clear();
  }
}