﻿using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.Models.Requests
{
    public class UpdateSupplyRequest
    {
        public Int64 ID { get; set; }
        public string Reason { get; set; }
        public byte? Status { get; set; }
    }
}
