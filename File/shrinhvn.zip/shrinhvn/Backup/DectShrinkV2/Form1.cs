﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Diagnostics;
using Microsoft.VisualBasic;
namespace DectShrinkV2
{
    public partial class Form1 : Form
    {
        WebService objService = new WebService();
        public Form1()
        {
            InitializeComponent();

            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized; KeyPreview = true;

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        


        private void btnAccept_Click(object sender, EventArgs e)
        {
            string s = objService.TBLUSER_Login(txtPic.Text.Trim());
            if (s == "1")
            {
                lblStatus.ForeColor = Color.Black;
                lblStatus.ForeColor = Color.Gray; ;

                lblStatus.Text = "OK";
                MainFunction objMain = new MainFunction(txtPic.Text.Trim());
                objMain.ShowDialog();
                this.Hide();

            }
            else
            {
                lblStatus.Text = "KHÔNG TỒN TẠI NGƯỜI DÙNG";
                lblStatus.BackColor = Color.Red;
                lblStatus.ForeColor = Color.Black;
                txtPic.Text = "";
                txtPic.Focus();


            }
        }

        private void txtPic_KeyDown(object sender, KeyEventArgs e)
        {
         
            if (e.KeyCode == Keys.Enter)
            {
                //e.Handled = true;
                //e.SuppressKeyPress = true;
                btnAccept_Click(sender, e);
               
                
            }

        }
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Escape)
            {
                e.Handled = true;   // stop annoying beep
            }

            // call base handler...
            base.OnKeyPress(e);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
           
             txtPic.Focus();
           
        }

        
    }
}
