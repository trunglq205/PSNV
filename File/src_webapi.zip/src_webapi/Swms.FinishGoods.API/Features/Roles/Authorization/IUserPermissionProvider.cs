using System.Security.Claims;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Nguồn quyền hiệu lực của user. Trừu tượng hóa để đổi chiến lược
/// (JWT claims / DB + cache) mà không sửa handler.
/// </summary>
public interface IUserPermissionProvider
{
    Task<IReadOnlySet<string>> GetPermissionsAsync(ClaimsPrincipal user);
}
