﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.TempLocMap.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.TempLocMap.Api;

[ApiController]
[Route("api/temploc")]
public class TempLocMapController : ControllerBase
{
    private readonly ITempLocMapService _service;

    public TempLocMapController(ITempLocMapService service) => _service = service;

    /// <summary>Danh sách khu vực.</summary>
    [HttpGet("areas")]
    [RequirePermission<Perms.Receiving.Temploc.View>]
    public async Task<ActionResult<IReadOnlyList<AreaSummaryResponse>>> GetAreas()
        => Ok(await _service.GetAreasAsync());

    /// <summary>Tạo khu vực mới (lưới trống).</summary>
    [HttpPost("areas")]
    [RequirePermission<Perms.Receiving.Temploc.Edit>]
    public async Task<ActionResult<AreaSummaryResponse>> CreateArea(CreateAreaRequest request)
    {
        var created = await _service.CreateAreaAsync(request);
        return CreatedAtAction(nameof(GetLayout), new { areaCode = created.AreaCode }, created);
    }

    /// <summary>Lấy layout đầy đủ của 1 khu (khung lưới + toàn bộ ô + trạng thái).</summary>
    [HttpGet("areas/{areaCode}/layout")]
    [AllowAnonymous]   // Vận hành/màn chiếu (LAN nội bộ) đọc layout không cần đăng nhập
    public async Task<ActionResult<MapLayoutResponse>> GetLayout(string areaCode)
    {
        var layout = await _service.GetLayoutAsync(areaCode);
        return layout is null ? NotFound() : Ok(layout);
    }

    /// <summary>Lưu toàn bộ layout của khu (thay danh sách ô).</summary>
    [HttpPut("areas/{areaCode}/layout")]
    [RequirePermission<Perms.Receiving.Temploc.Edit>]
    public async Task<IActionResult> SaveLayout(string areaCode, SaveLayoutRequest request)
    {
        await _service.SaveLayoutAsync(areaCode, request);
        return NoContent();
    }

    /// <summary>Đổi trạng thái nhanh 1 vị trí pallet (ghi lịch sử).</summary>
    [HttpPatch("locators/{locatorCode}/status")]
    [RequirePermission<Perms.Receiving.Temploc.Assign>]
    public async Task<IActionResult> ChangeStatus(string locatorCode, ChangeStatusRequest request)
    {
        await _service.ChangeStatusAsync(locatorCode, request);
        return NoContent();
    }

    /// <summary>Thông tin vị trí, khu vực và danh sách pallet đang chứa.</summary>
    [HttpGet("locators/{locatorCode}/pallets")]
    [RequirePermission<Perms.Receiving.Temploc.View>]
    public async Task<ActionResult<LocatorPalletsResponse>> GetLocatorPallets(string locatorCode)
        => Ok(await _service.GetLocatorPalletsAsync(locatorCode));
}