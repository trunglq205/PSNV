import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';

/// Thẻ pallet vừa quét ở bước 2 (dùng chung Vị trí tạm / Lưu kho / Chuyển-Out):
/// mã pallet, cờ khẩn, model + số thùng/pcs, vị trí hiện tại.
class PalletFlowPalletCard extends StatelessWidget {
  const PalletFlowPalletCard({super.key, required this.pallet});

  final Pallet pallet;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    // Nhiều model trên 1 pallet: số thùng/tổng qty là số của cả pallet nên
    // không thể gắn vào từng dòng model -> giữ lại ở hàng chip bên dưới.
    final showAggregate = pallet.modelQtys.length > 1;

    return Container(
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: swms.border),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Hàng 1: mã pallet + cờ khẩn
          Row(
            spacing: AppDimens.sm,
            children: [
              Expanded(
                child: Text(
                  pallet.lotNo,
                  style: AppTextStyles.title.copyWith(
                    fontWeight: FontWeight.w800,
                    color: swms.text1,
                  ),
                ),
              ),
              if (pallet.isUrgent)
                Container(
                  padding: const EdgeInsets.symmetric(
                    horizontal: AppDimens.sm,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: swms.danger,
                    borderRadius: BorderRadius.circular(AppDimens.rBtn),
                  ),
                  child: Text(
                    LocaleKeys.pallet_flow_urgent.tr(),
                    style: AppTextStyles.caption.copyWith(
                      color: Colors.white,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppDimens.sm,
                  vertical: 2,
                ),
                decoration: BoxDecoration(
                  color: pallet.inspectionStatus.color.bg,
                  borderRadius: BorderRadius.circular(AppDimens.rBtn),
                ),
                child: Text(
                  pallet.inspectionStatus.toString(),
                  style: AppTextStyles.caption.copyWith(
                    color: pallet.inspectionStatus.color.fg,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
            ],
          ),

          // Model + số thùng + pcs trên cùng 1 hàng.
          // Lot mức box_count chỉ có `models` -> dùng số tổng của pallet.
          if (pallet.modelQtys.isNotEmpty) ...[
            const SizedBox(height: AppDimens.sm),
            for (final mq in pallet.modelQtys)
              Padding(
                padding: const EdgeInsets.only(bottom: AppDimens.xs),
                child: _ModelLine(
                  model: mq.model,
                  boxCount: showAggregate ? null : pallet.boxCount,
                  qty: mq.totalQty,
                ),
              ),
          ] else if (pallet.displayModels.isNotEmpty) ...[
            const SizedBox(height: AppDimens.xs),
            _ModelLine(
              model: pallet.displayModels,
              boxCount: pallet.boxCount,
              qty: pallet.displayTotalQty,
            ),
          ],

          const SizedBox(height: AppDimens.sm),
          Divider(height: 1, color: swms.border),
          const SizedBox(height: AppDimens.sm),

          // Vị trí hiện tại — thứ quyết định hành động nào khả dụng.
          Row(
            children: [
              Icon(
                pallet.hasLocator ? Icons.place : Icons.location_off_outlined,
                size: 18,
                color: pallet.hasLocator ? swms.primary : swms.text4,
              ),
              const SizedBox(width: AppDimens.sm),
              Text(
                LocaleKeys.pallet_flow_current_location.tr(),
                style: AppTextStyles.caption.copyWith(color: swms.text3),
              ),
              const SizedBox(width: AppDimens.xs),
              Expanded(
                child: Text(
                  pallet.hasLocator
                      ? '${pallet.areaCode!} - ${pallet.locatorCode!}'
                      : LocaleKeys.pallet_flow_no_location.tr(),
                  style: AppTextStyles.bodyStrong.copyWith(
                    color: pallet.hasLocator ? swms.primary : swms.text4,
                  ),
                ),
              ),
            ],
          ),

          // Tổng của cả pallet — chỉ hiện khi có nhiều model.
          if (showAggregate) ...[
            const SizedBox(height: AppDimens.sm),
            Wrap(
              spacing: AppDimens.md,
              runSpacing: AppDimens.xs,
              children: [
                _MetaChip(
                  icon: Icons.summarize_outlined,
                  label: LocaleKeys.pallet_flow_total_qty.tr(
                    args: ['${pallet.displayTotalQty}'],
                  ),
                ),
                if (pallet.boxCount != null)
                  _MetaChip(
                    icon: Icons.inventory_2_outlined,
                    label: LocaleKeys.pallet_flow_box_count.tr(
                      args: ['${pallet.boxCount}'],
                    ),
                  ),
              ],
            ),
          ],
        ],
      ),
    );
  }
}

/// Một dòng model: `[icon] MODEL ......  [icon] N thùng  [icon] M pcs`
/// Số thùng / pcs cố ý để cỡ caption cho nhẹ mắt, model vẫn là thông tin chính.
class _ModelLine extends StatelessWidget {
  const _ModelLine({required this.model, required this.qty, this.boxCount});

  final String model;
  final num qty;
  final num? boxCount;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final countStyle = AppTextStyles.caption.copyWith(
      color: swms.text3,
      fontWeight: FontWeight.w700,
    );

    return Row(
      children: [
        Icon(Icons.widgets_outlined, size: 15, color: swms.text4),
        const SizedBox(width: AppDimens.xs),
        Expanded(
          child: Text(
            model,
            style: AppTextStyles.body.copyWith(color: swms.text2),
            overflow: TextOverflow.ellipsis,
          ),
        ),
        if (boxCount != null) ...[
          const SizedBox(width: AppDimens.sm),
          Icon(Icons.inventory_2_outlined, size: 13, color: swms.text4),
          const SizedBox(width: 3),
          Text(
            LocaleKeys.pallet_flow_box_count.tr(args: ['$boxCount']),
            style: countStyle,
          ),
        ],
        const SizedBox(width: AppDimens.sm),
        Icon(Icons.summarize_outlined, size: 13, color: swms.text4),
        const SizedBox(width: 3),
        Text(
          LocaleKeys.pallet_flow_qty_value.tr(args: ['$qty']),
          style: countStyle,
        ),
      ],
    );
  }
}

class _MetaChip extends StatelessWidget {
  const _MetaChip({required this.icon, required this.label});

  final IconData icon;
  final String label;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(icon, size: 14, color: swms.text4),
        const SizedBox(width: 4),
        Text(label, style: AppTextStyles.caption.copyWith(color: swms.text3)),
      ],
    );
  }
}