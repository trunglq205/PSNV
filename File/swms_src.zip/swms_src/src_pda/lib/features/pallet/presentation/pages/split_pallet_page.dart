﻿import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/qr_label.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/back_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_stepper_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/common/printer_status_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_alert_dialog_helper.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/presentation/dialogs/split_success_dialog.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_providers.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/split_notifier.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/flow/pallet_flow_parts.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_bottom_hint.dart';
import 'package:swms_finish_goods/shared/presentation/label_print_dialog.dart';
import 'package:swms_finish_goods/shared/presentation/printer_picker_dialog.dart';

// ─────────────────────────────────────────────────────────────
//  Tách pallet — wizard 3 bước:
//   B1 (đã xong khi vào): quét pallet gốc → route truyền lotNo
//   B2: chọn thùng cần tách (quét box)
//   B3: pallet đích (lot đã có / lot mới) → xác nhận
//
//  Thùng lấy từ palletProvider(lotNo); lỗi API tách do
//  appActionProvider toast, submit() trả null khi thất bại.
//
//  Lot mới: bắt buộc chọn máy in ở B3; tách xong in ngay tem pallet
//  (QR + Lot No). In lỗi KHÔNG huỷ lệnh tách (đã commit ở server) —
//  dialog thành công có nút "In lại tem".
// ─────────────────────────────────────────────────────────────

@RoutePage()
class SplitPalletScreen extends ConsumerStatefulWidget {
  final String lotNo;

  /// Mở từ Soạn hàng: id các thùng đã lấy — chọn sẵn và khoá.
  final Set<int>? pickedBoxIds;

  const SplitPalletScreen({super.key, required this.lotNo, this.pickedBoxIds});

  @override
  ConsumerState<SplitPalletScreen> createState() => _SplitPalletScreenState();
}

class _SplitPalletScreenState extends ConsumerState<SplitPalletScreen> {
  StreamSubscription<String>? _sub;
  final _targetCtrl = TextEditingController();

  bool _preselected = false;

  /// Chặn bấm 2 lần khi đang gọi API tách / in tem
  /// (overlay do appActionProvider lo).
  bool _submitting = false;

  SplitNotifierProvider get _provider => splitProvider(widget.lotNo);

  SplitNotifier get _notifier => ref.read(_provider.notifier);

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _targetCtrl.dispose();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Await xong mới gán: page đã dispose trong lúc chờ thì subscription
    // sẽ không bao giờ được cancel → rò listener.
    if (!mounted) return;
    _sub = pda.scanStream.listen(_onScan);
  }

  void _onScan(String code) {
    if (!mounted) return;
    final s = ref.read(_provider);

    if (s.step == 1) {
      if (s.locked) return;
      // Pallet box_count không có thùng nào để quét. Không chặn ở đây thì mọi
      // lần quét đều rơi vào nhánh `foreign` và báo "thùng lạ" — sai hẳn
      // nguyên nhân, người dùng sẽ tưởng quét nhầm mã.
      if (s.byQty) {
        _toast(LocaleKeys.pallet_split_qty_no_scan.tr(), isError: false);
        return;
      }
      // Bước chọn thùng.
      final out = _notifier.onScanBox(code);
      if (!mounted) return;
      switch (out) {
        case ScanPickOutcome.picked:
          break;
        case ScanPickOutcome.already:
          _toast(LocaleKeys.pallet_split_already_picked.tr(), isError: false);
        case ScanPickOutcome.foreign:
          _toast(
            LocaleKeys.pallet_split_foreign_box.tr(args: [code.trim()]),
            isError: true,
          );
      }
    } else if (s.step == 2 && s.targetKind == SplitTargetKind.existing) {
      // Bước đích: quét lot đích điền vào ô.
      _notifier.setTargetLotNo(code.trim());
      _targetCtrl.text = code.trim();
    }
  }

  void _toast(String msg, {required bool isError}) {
    AppToastHelper.toast(context, message: msg, type: isError ? .error : .info);
  }

  /// Áp thùng chọn sẵn 1 lần, sau khi thùng của lot gốc đã nạp xong.
  void _applyPreselect() {
    final ids = widget.pickedBoxIds;
    if (ids == null || _preselected) return;
    _preselected = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _notifier.preselect(ids);
    });
  }

  // ── Máy in ────────────────────────────────────────────────
  /// Ngưng listener của page trong lúc chọn máy — dialog chọn máy tự nghe
  /// scan (quét MAC) — xong thì nghe lại.
  Future<void> _pickPrinter() async {
    await _sub?.cancel();
    _sub = null;
    if (!mounted) {
      return;
    }
    try {
      await pickPrinter(context, ref);
    } finally {
      if (mounted) await _listen();
    }
  }

  /// Tem pallet con sau khi tách.
  ///
  /// Badge RW / RB lấy theo PALLET GỐC: server clone `disposition` sang lot mới
  /// (xem `ExecuteSplitAsync`), nên tách một pallet hàng back ra thì pallet con
  /// vẫn là hàng đó và tem phải ghi đúng như vậy. Thiếu badge ở đây thì pallet
  /// con nằm trên giá trông y như hàng thường.
  Future<bool> _printPalletLabel(String lotNo) => printLabel(
        ref,
        QrLabelData.pallet(
          lotNo,
          badge: QrLabelData.badgeForDisposition(
            ref.read(_provider).sourcePallet?.disposition,
          ),
        ),
      );

  /// Hỏi lại khi pallet đích khác model. Trả false = người dùng huỷ.
  ///
  /// Cảnh báo đã hiện sẵn ở bước 3 ngay khi nạp được pallet đích; dialog này
  /// là cửa chốt cuối để việc gộp khác model luôn là một lựa chọn có ý thức.
  ///
  /// NGƯNG listener quét trong lúc dialog mở — cùng cách [_pickPrinter] làm.
  /// Súng quét PDA rất dễ bị bóp nhầm; một mã pallet khác lọt vào state khi
  /// dialog đang chờ sẽ khiến cái người dùng vừa đồng ý không còn là cái được
  /// tách, tức là cảnh báo bị vượt qua mà họ chưa từng thấy.
  Future<bool> _confirmModelMismatch(SplitState s) async {
    await _sub?.cancel();
    _sub = null;
    if (!mounted) return false;
    try {
      return await AppDialogHelper.confirm(
        context,
        title: LocaleKeys.pallet_split_model_mismatch_title.tr(),
        message: LocaleKeys.pallet_split_model_mismatch_body.tr(
          args: [
            // pallet_id thật, không phải mã đã quét: quét mã xe Stocky cũng ra
            // đúng pallet, mà lịch sử ghi pallet_id — dialog phải gọi cùng tên
            // với thứ sẽ xuất hiện trong lịch sử.
            s.targetPallet?.lotNo ?? s.targetLotNo.trim(),
            s.targetModels.join(', '),
            s.foreignModels.join(', '),
          ],
        ),
        confirmText: LocaleKeys.pallet_split_model_mismatch_ok.tr(),
        cancelText: LocaleKeys.common_cancel.tr(),
      );
    } finally {
      if (mounted) await _listen();
    }
  }

  Future<void> _submit() async {
    if (_submitting) return;
    // Chốt trước khi submit — notifier có thể reset state sau khi tách xong.
    final s = ref.read(_provider);
    final isNewLot = s.targetKind == SplitTargetKind.newLot;

    // Khác model: phải được xác nhận mới gửi cờ cho server. Không xác nhận thì
    // dừng hẳn — gửi với cờ false chỉ để nhận lỗi Split.ModelMismatch.
    var confirmedModel = false;
    if (s.hasModelMismatch) {
      confirmedModel = await _confirmModelMismatch(s);
      if (!confirmedModel || !mounted) return;
    }

    setState(() => _submitting = true);
    try {
      // Lỗi API đã được appActionProvider bắt + toast -> null.
      final result = await _notifier.submit(
        confirmModelMismatch: confirmedModel,
      );
      if (result == null || !mounted) return;

      final printed = isNewLot && await _printPalletLabel(result.targetLotNo);
      if (!mounted) return;

      final done = await showSplitSuccessDialog(
        context,
        result: result,
        printed: printed,
        onReprint: isNewLot
            ? () => _printPalletLabel(result.targetLotNo)
            : null,
      );
      if (done == true && mounted) await context.router.maybePop(true);
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    // Thùng đến từ palletProvider -> chờ/nhắc lỗi ở đây.
    final palletAsync = ref.watch(palletProvider(widget.lotNo));

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.pallet_split_title.tr(),
        subtitle: LocaleKeys.pallet_split_subtitle.tr(),
      ),
      body: palletAsync.when(
        loading: () => const AppLoading(),
        error: (e, _) => AppErrorView.page(
          message: LocaleKeys.pallet_split_load_error.tr(),
          onRetry: () => ref.invalidate(palletProvider(widget.lotNo)),
        ),
        data: (_) {
          _applyPreselect();
          return _buildContent();
        },
      ),
    );
  }

  Widget _buildContent() {
    final state = ref.watch(_provider);
    final printer = ref.watch(selectedPrinterProvider);

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.all(AppDimens.md),
          child: _SplitStepper(step: state.step),
        ),
        Expanded(
          child: state.step == 1
              ? _PickStep(notifier: _notifier, state: state)
              : _TargetStep(
                  notifier: _notifier,
                  state: state,
                  printer: printer,
                  onChangePrinter: _submitting ? null : _pickPrinter,
                ),
        ),
        _BottomBar(
          state: state,
          submitting: _submitting,
          printerReady: printer != null,
          onBack: () {
            if (state.step > 1) {
              _notifier.goToStep(1);
            } else {
              Navigator.of(context).maybePop();
            }
          },
          onNext: () => _notifier.goToStep(2),
          onSubmit: _submit,
        ),
      ],
    );
  }
}

/// Stepper 3 bước; bước gốc đã xong trước khi vào màn.
/// notifier dùng step 1/2 -> hiển thị +1.
class _SplitStepper extends StatelessWidget {
  final int step;

  const _SplitStepper({required this.step});

  @override
  Widget build(BuildContext context) {
    return AppStepperBar(
      current: step + 1,
      steps: [
        StepItem(LocaleKeys.pallet_split_step_source.tr()),
        StepItem(LocaleKeys.pallet_split_step_pick.tr()),
        StepItem(LocaleKeys.pallet_split_step_target.tr()),
      ],
    );
  }
}

// ─── Bước 2: chọn thùng (quét) ───────────────────────────────
class _PickStep extends StatelessWidget {
  final SplitNotifier notifier;
  final SplitState state;

  const _PickStep({required this.notifier, required this.state});

  @override
  Widget build(BuildContext context) {
    // Pallet chỉ biết SỐ thùng: nhập số, không quét. Không có nút quét ở đây
    // vì bấm vào cũng chẳng quét được gì.
    if (state.byQty) {
      return ListView(
        padding: const EdgeInsets.symmetric(horizontal: AppDimens.md),
        children: [
          _QtyPickCard(notifier: notifier, state: state),
          const SizedBox(height: AppDimens.md),
        ],
      );
    }

    return ListView(
      padding: const EdgeInsets.symmetric(horizontal: AppDimens.md),
      children: [
        BarcodeScannerButton(
          scanningLabel: LocaleKeys.pallet_split_scan_box_hint.tr(),
        ),
        const SizedBox(height: AppDimens.md),
        _SummaryCard(state: state),
        const SizedBox(height: AppDimens.md),
        _BoxPickList(notifier: notifier, state: state),
        const SizedBox(height: AppDimens.md),
      ],
    );
  }
}

/// Bước chọn thùng cho pallet `box_count`: nhập SỐ thùng cần tách.
///
/// Pallet loại này không có dòng nào trong wms.boxes nên không có gì để quét
/// và cũng không có số pcs theo từng thùng — chỉ hiện số thùng.
class _QtyPickCard extends StatefulWidget {
  final SplitNotifier notifier;
  final SplitState state;

  const _QtyPickCard({required this.notifier, required this.state});

  @override
  State<_QtyPickCard> createState() => _QtyPickCardState();
}

class _QtyPickCardState extends State<_QtyPickCard> {
  late final TextEditingController _ctrl =
      TextEditingController(text: widget.state.qty > 0 ? '${widget.state.qty}' : '');

  @override
  void dispose() {
    _ctrl.dispose();
    super.dispose();
  }

  /// Dùng cho nút +/-: đổi số rồi ghi lại vào ô nhập.
  ///
  /// Kẹp ngay tại đây thay vì đọc ngược giá trị notifier đã kẹp — đọc ngược
  /// buộc phải biết tham số family của provider, mà widget này không có.
  /// Notifier vẫn kẹp lần nữa, nên hai lớp bảo vệ chứ không phải thừa.
  void _apply(int v) {
    final total = widget.state.totalBoxCount;
    final clamped = v < 0 ? 0 : (v > total ? total : v);
    widget.notifier.setQty(clamped);

    final text = clamped == 0 ? '' : '$clamped';
    if (_ctrl.text != text) {
      _ctrl.text = text;
      _ctrl.selection = TextSelection.collapsed(offset: text.length);
    }
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final s = widget.state;
    final remaining = s.totalBoxCount - s.qty;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        PalletFlowHintBox(
          icon: Icons.info_outline,
          tone: swms.text2,
          bg: swms.card2,
          text: LocaleKeys.pallet_split_qty_hint.tr(),
        ),
        const SizedBox(height: AppDimens.md),
        Container(
          padding: const EdgeInsets.all(AppDimens.md),
          decoration: BoxDecoration(
            color: swms.card2,
            borderRadius: BorderRadius.circular(AppDimens.rCard),
            border: Border.all(color: swms.border),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Text(
                LocaleKeys.pallet_split_qty_label.tr(args: ['${s.totalBoxCount}']),
                style: AppTextStyles.label.copyWith(color: swms.text3),
              ),
              const SizedBox(height: AppDimens.sm),
              Row(
                children: [
                  _StepBtn(
                    icon: Icons.remove,
                    onTap: s.qty > 0 ? () => _apply(s.qty - 1) : null,
                  ),
                  const SizedBox(width: AppDimens.sm),
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      keyboardType: TextInputType.number,
                      textAlign: TextAlign.center,
                      style: AppTextStyles.h2.copyWith(color: swms.text1),
                      decoration: InputDecoration(
                        isDense: true,
                        hintText: '0',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(AppDimens.rInput),
                        ),
                      ),
                      onChanged: (v) =>
                          widget.notifier.setQty(int.tryParse(v.trim()) ?? 0),
                    ),
                  ),
                  const SizedBox(width: AppDimens.sm),
                  _StepBtn(
                    icon: Icons.add,
                    onTap: s.qty < s.totalBoxCount ? () => _apply(s.qty + 1) : null,
                  ),
                ],
              ),
              const SizedBox(height: AppDimens.md),
              Row(
                children: [
                  Expanded(
                    child: _Metric(
                      label: LocaleKeys.pallet_split_to_split.tr(),
                      value: LocaleKeys.pallet_split_box_only.tr(args: ['${s.qty}']),
                      color: swms.primary,
                    ),
                  ),
                  Container(width: 1, height: 34, color: swms.border),
                  Expanded(
                    child: _Metric(
                      label: LocaleKeys.pallet_split_remaining.tr(),
                      value: LocaleKeys.pallet_split_box_only.tr(args: ['$remaining']),
                      color: remaining > 0 ? swms.success : swms.danger,
                    ),
                  ),
                ],
              ),
              if (s.qty >= s.totalBoxCount && s.totalBoxCount > 0) ...[
                const SizedBox(height: AppDimens.sm),
                Text(
                  LocaleKeys.pallet_split_qty_keep_one.tr(),
                  style: AppTextStyles.caption.copyWith(color: swms.danger),
                ),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

/// Nút +/- vuông cạnh ô nhập số.
class _StepBtn extends StatelessWidget {
  final IconData icon;
  final VoidCallback? onTap;

  const _StepBtn({required this.icon, this.onTap});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final on = onTap != null;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppDimens.rInput),
      child: Container(
        width: 46,
        height: 46,
        decoration: BoxDecoration(
          color: on ? swms.card : swms.card2,
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          border: Border.all(color: swms.border),
        ),
        child: Icon(icon, color: on ? swms.text1 : swms.text3),
      ),
    );
  }
}

/// Thẻ gốc: Tách ra / Còn lại.
class _SummaryCard extends StatelessWidget {
  final SplitState state;

  const _SummaryCard({required this.state});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: _Metric(
              label: LocaleKeys.pallet_split_to_split.tr(),
              value: LocaleKeys.pallet_split_box_pcs.tr(
                args: ['${state.pickedCount}', '${state.pickedPcs}'],
              ),
              color: swms.primary,
            ),
          ),
          Container(width: 1, height: 34, color: swms.border),
          Expanded(
            child: _Metric(
              label: LocaleKeys.pallet_split_remaining.tr(),
              value: LocaleKeys.pallet_split_box_pcs.tr(
                args: ['${state.remainingCount}', '${state.remainingPcs}'],
              ),
              color: swms.success,
            ),
          ),
        ],
      ),
    );
  }
}

class _Metric extends StatelessWidget {
  final String label;
  final String value;
  final Color color;

  const _Metric({
    required this.label,
    required this.value,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Column(
      children: [
        Text(label, style: AppTextStyles.caption.copyWith(color: swms.text3)),
        const SizedBox(height: 2),
        Text(value, style: AppTextStyles.bodyStrong.copyWith(color: color)),
      ],
    );
  }
}

/// Danh sách thùng — thùng đã chọn tô sáng, bấm để bỏ chọn.
class _BoxPickList extends StatelessWidget {
  final SplitNotifier notifier;
  final SplitState state;

  const _BoxPickList({required this.notifier, required this.state});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(
            left: AppDimens.xs,
            bottom: AppDimens.xs,
          ),
          child: Text(
            LocaleKeys.pallet_split_box_list.tr(args: ['${state.totalBoxes}']),
            style: AppTextStyles.label.copyWith(color: swms.text3),
          ),
        ),
        for (int i = 0; i < state.allBoxes.length; i++)
          _BoxRow(
            index: i + 1,
            box: state.allBoxes[i],
            picked: state.isPicked(state.allBoxes[i].id),
            onTap: state.locked
                ? null
                : () {
                    final b = state.allBoxes[i];
                    if (state.isPicked(b.id)) {
                      notifier.unpick(b.id);
                    } else {
                      notifier.onScanBox(b.boxNo);
                    }
                  },
          ),
      ],
    );
  }
}

class _BoxRow extends StatelessWidget {
  final int index;
  final PalletBox box;
  final bool picked;
  final VoidCallback? onTap;

  const _BoxRow({
    required this.index,
    required this.box,
    required this.picked,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.xs),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        child: Container(
          padding: const EdgeInsets.all(AppDimens.sm),
          decoration: BoxDecoration(
            color: picked ? swms.primaryTint : swms.card2,
            borderRadius: BorderRadius.circular(AppDimens.rCard),
            border: Border.all(
              color: picked ? swms.primary : swms.border,
              width: picked ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 22,
                height: 22,
                decoration: BoxDecoration(
                  color: picked ? swms.primary : Colors.transparent,
                  borderRadius: BorderRadius.circular(6),
                  border: Border.all(
                    color: picked ? swms.primary : swms.text4,
                    width: 1.5,
                  ),
                ),
                child: picked
                    ? const Icon(Icons.check, color: Colors.white, size: 14)
                    : null,
              ),
              const SizedBox(width: AppDimens.sm),
              Text(
                index.toString().padLeft(2, '0'),
                style: AppTextStyles.caption.copyWith(color: swms.text4),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Text(
                  box.boxNo,
                  style: AppTextStyles.bodyStrong.copyWith(
                    color: picked ? swms.primary : swms.text2,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: AppDimens.sm,
                  vertical: 2,
                ),
                decoration: BoxDecoration(
                  color: swms.successBg,
                  borderRadius: BorderRadius.circular(AppDimens.rBtn),
                ),
                child: Text(
                  LocaleKeys.pallet_split_pcs.tr(args: ['${box.totalQty}']),
                  style: AppTextStyles.caption.copyWith(color: swms.success),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

// ─── Bước 3: pallet đích ─────────────────────────────────────
class _TargetStep extends StatelessWidget {
  final SplitNotifier notifier;
  final SplitState state;

  /// Máy in đang chọn — chỉ dùng khi lot mới (in tem pallet).
  final PrinterDevice? printer;
  final VoidCallback? onChangePrinter;

  const _TargetStep({
    required this.notifier,
    required this.state,
    required this.printer,
    required this.onChangePrinter,
  });

  /// Lý do KHÔNG tách được sang pallet đích — hai trường hợp chặn cứng.
  /// Null = không chặn. Khác MODEL không nằm ở đây: đó là cảnh báo xác nhận
  /// được, xem [_targetStatus].
  ///
  /// Dùng `!` an toàn: hai getter mismatch đã đòi cả source và target khác null.
  static String? _blockReason(SplitState s) {
    if (s.categoryMismatch) {
      return LocaleKeys.pallet_split_category_mismatch.tr(
        args: [
          '${s.targetPallet!.categoryCode}',
          '${s.sourcePallet!.categoryCode}',
        ],
      );
    }
    if (s.detailLevelMismatch) {
      return LocaleKeys.pallet_split_detail_mismatch.tr(
        args: [s.targetPallet!.detailLevel, s.sourcePallet!.detailLevel],
      );
    }
    return null;
  }

  /// Trạng thái đọc pallet đích: đang nạp · không đọc được · thông tin pallet
  /// đích kèm cảnh báo khác model.
  List<Widget> _targetStatus(BuildContext context, SplitState s) {
    final swms = context.swms;

    if (s.targetLoading) {
      return [
        PalletFlowHintBox(
          icon: Icons.hourglass_empty,
          tone: swms.primary,
          bg: swms.primaryTint,
          text: LocaleKeys.pallet_split_target_loading.tr(),
        ),
        const SizedBox(height: AppDimens.md),
      ];
    }

    if (s.targetError) {
      return [
        PalletFlowHintBox(
          icon: Icons.help_outline,
          tone: swms.warning,
          bg: swms.warningBg,
          text: LocaleKeys.pallet_split_target_unreadable.tr(),
        ),
        // Phải có đường thử lại: quét lại cùng mã đã bị chốt chống lặp, mà
        // không đọc được pallet đích thì cảnh báo khác model không hiện và
        // người dùng không có cách nào xác nhận để tách tiếp.
        Align(
          alignment: Alignment.centerRight,
          child: TextButton.icon(
            onPressed: notifier.retryTargetLookup,
            icon: const Icon(Icons.refresh, size: 18),
            label: Text(LocaleKeys.common_retry.tr()),
          ),
        ),
        const SizedBox(height: AppDimens.sm),
      ];
    }

    final t = s.targetPallet;
    if (t == null) return const [];

    final models = s.targetModels;
    // Pallet đích box_count không có pcs theo thùng -> chỉ nói số thùng,
    // cùng lý do với thẻ tóm tắt bên dưới.
    final qtyText = t.detailLevel == kDetailLevelBoxCount
        ? LocaleKeys.pallet_split_box_only.tr(args: ['${t.boxCount ?? 0}'])
        : LocaleKeys.pallet_split_box_pcs.tr(
            args: ['${t.boxCount ?? 0}', '${t.totalQty ?? 0}'],
          );

    return [
      PalletFlowHintBox(
        icon: Icons.inventory_2_outlined,
        tone: swms.primary,
        bg: swms.primaryTint,
        text: LocaleKeys.pallet_split_target_contains.tr(
          args: [models.isEmpty ? '—' : models.join(', '), qtyText],
        ),
      ),
      const SizedBox(height: AppDimens.md),
      // !targetBlocked: lệch category / detail_level đã chặn cứng và nút Tách
      // đang tắt. Hiện kèm cảnh báo "bấm Xác nhận tách để tiếp tục" thì thành
      // bảo người dùng bấm một cái nút bấm không được.
      if (s.hasModelMismatch && !s.targetBlocked) ...[
        PalletFlowHintBox(
          icon: Icons.warning_amber_rounded,
          tone: swms.warning,
          bg: swms.warningBg,
          text: LocaleKeys.pallet_split_model_mismatch_hint.tr(
            args: [models.join(', '), s.foreignModels.join(', ')],
          ),
        ),
        const SizedBox(height: AppDimens.md),
      ],
    ];
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final isExisting = state.targetKind == SplitTargetKind.existing;
    final isNew = state.targetKind == SplitTargetKind.newLot;
    final target = state.targetLotNo.trim();

    return SingleChildScrollView(
      padding: const EdgeInsets.all(AppDimens.md),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── Chọn loại pallet đích ──
          PalletFlowSectionLabel(LocaleKeys.pallet_split_choose_target.tr()),
          const SizedBox(height: AppDimens.sm),
          Row(
            children: [
              Expanded(
                child: PalletFlowChoiceButton(
                  icon: Icons.inventory_2_outlined,
                  label: LocaleKeys.pallet_split_target_existing.tr(),
                  selected: isExisting,
                  onTap: () =>
                      notifier.chooseTargetKind(SplitTargetKind.existing),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: PalletFlowChoiceButton(
                  icon: Icons.add_box_outlined,
                  label: LocaleKeys.pallet_split_target_new.tr(),
                  selected: isNew,
                  onTap: () =>
                      notifier.chooseTargetKind(SplitTargetKind.newLot),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimens.md),

          // ── Lot đã có: quét lot đích ──
          if (isExisting) ...[
            PalletFlowSectionLabel(
              LocaleKeys.pallet_split_target_lot_label.tr(),
            ),
            const SizedBox(height: AppDimens.sm),
            if (target.isEmpty)
              BarcodeScannerButton(
                scanningLabel: LocaleKeys.pallet_split_scan_target_hint.tr(),
              )
            else
              PalletFlowScannedCode(
                label: LocaleKeys.pallet_split_target_existing.tr(),
                code: target,
                onClear: () => notifier.setTargetLotNo(''),
                clearTooltip: LocaleKeys.pallet_flow_rescan.tr(),
                // Có warning -> ô mã đổi sang đỏ. Chỉ dùng cho hai trường hợp
                // CHẶN CỨNG; khác model là cảnh báo nên để riêng bên dưới.
                warning: _blockReason(state),
              ),
            const SizedBox(height: AppDimens.md),
            ..._targetStatus(context, state),
          ]
          // ── Lot mới: nhắc + chọn máy in tem pallet ──
          else if (isNew) ...[
            PalletFlowHintBox(
              icon: Icons.add_box_outlined,
              tone: swms.primary,
              bg: swms.primaryTint,
              text: LocaleKeys.pallet_split_target_new_sub.tr(),
            ),
            const SizedBox(height: AppDimens.md),
            PalletFlowSectionLabel(
              LocaleKeys.pallet_split_print_label_title.tr(),
            ),
            const SizedBox(height: AppDimens.sm),
            PrinterStatusBar(device: printer, onChange: onChangePrinter),
            const SizedBox(height: AppDimens.md),
          ],

          // ── Tóm tắt số thùng sẽ tách ──
          // Pallet box_count không có số pcs theo từng thùng (pickedPcs luôn
          // bằng 0), nên chỉ nói số thùng — in "0 pcs" ra là sai sự thật.
          PalletFlowHintBox(
            icon: Icons.call_split,
            tone: swms.primary,
            bg: swms.primaryTint,
            text: state.byQty
                ? LocaleKeys.pallet_split_box_only.tr(args: ['${state.qty}'])
                : LocaleKeys.pallet_split_summary.tr(
                    args: ['${state.pickedCount}', '${state.pickedPcs}'],
                  ),
          ),
        ],
      ),
    );
  }
}

// ─── Thanh dưới ──────────────────────────────────────────────
class _BottomBar extends StatelessWidget {
  final SplitState state;
  final bool submitting;

  /// Lot mới bắt buộc có máy in — tách xong in tem ngay.
  final bool printerReady;
  final VoidCallback onBack;
  final VoidCallback onNext;
  final VoidCallback onSubmit;

  const _BottomBar({
    required this.state,
    required this.submitting,
    required this.printerReady,
    required this.onBack,
    required this.onNext,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    final isPick = state.step == 1;
    final needsPrinter = state.targetKind == SplitTargetKind.newLot;
    final canConfirm =
        state.canSubmit && !submitting && (!needsPrinter || printerReady);

    return ReceivingBottomHint(
      child: Row(
        children: [
          BackIconButton(onPressed: submitting ? null : onBack),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: isPick
                ? AppButton(
                    label: LocaleKeys.pallet_split_continue.tr(),
                    isFullWidth: false,
                    onPressed: state.canGoToTarget ? onNext : null,
                  )
                : AppButton(
                    label: submitting
                        ? LocaleKeys.pallet_split_processing.tr()
                        : LocaleKeys.pallet_split_confirm.tr(),
                    variant: AppButtonVariant.success,
                    isFullWidth: false,
                    onPressed: canConfirm ? onSubmit : null,
                  ),
          ),
        ],
      ),
    );
  }
}
