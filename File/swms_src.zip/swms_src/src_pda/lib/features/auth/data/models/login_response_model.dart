import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/auth/domain/auth_entity.dart';

part 'login_response_model.g.dart';

@JsonSerializable(fieldRename: FieldRename.none)
class LoginResponseModel {
  final String accessToken;
  final DateTime expiresAtUtc;
  final String username;
  final String fullName;

  const LoginResponseModel({
    required this.accessToken,
    required this.expiresAtUtc,
    required this.username,
    required this.fullName,
  });

  factory LoginResponseModel.fromJson(Map<String, dynamic> json) =>
      _$LoginResponseModelFromJson(json);

  Map<String, dynamic> toJson() => _$LoginResponseModelToJson(this);

  // Map sang domain entity
  AuthEntity toEntity() => AuthEntity(
    accessToken: accessToken,
    expiresAtUtc: expiresAtUtc,
    username: username,
    fullName: fullName,
  );
}