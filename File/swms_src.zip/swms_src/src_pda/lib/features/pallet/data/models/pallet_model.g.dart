// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pallet_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PalletModel _$PalletModelFromJson(Map<String, dynamic> json) => PalletModel(
  id: (json['id'] as num).toInt(),
  lotNo: json['lotNo'] as String,
  categoryCode: (json['categoryCode'] as num).toInt(),
  lotType: json['lotType'] as String,
  detailLevel: json['detailLevel'] as String,
  inspectionStatus: json['inspectionStatus'] as String,
  isUrgent: json['isUrgent'] as bool,
  categoryName: json['categoryName'] as String?,
  stockyCode: json['stockyCode'] as String?,
  disposition: json['disposition'] as String?,
  allowedActions:
      (json['allowedActions'] as List<dynamic>?)
          ?.map((e) => e as String)
          .toList() ??
      [],
  boxCount: (json['boxCount'] as num?)?.toInt(),
  totalQty: (json['totalQty'] as num?)?.toInt(),
  sapStatus: (json['sapStatus'] as num?)?.toInt(),
  sapPushedAt: json['sapPushedAt'] == null
      ? null
      : DateTime.parse(json['sapPushedAt'] as String),
  productionDate: json['productionDate'] == null
      ? null
      : DateTime.parse(json['productionDate'] as String),
  models: json['models'] as String?,
  modelQtys:
      (json['modelSummary'] as List<dynamic>?)
          ?.map((e) => PalletModelQtyModel.fromJson(e as Map<String, dynamic>))
          .toList() ??
      [],
  locatorId: (json['locatorId'] as num?)?.toInt(),
  locatorCode: json['locatorCode'] as String?,
  areaCode: json['areaCode'] as String?,
  areaName: json['areaName'] as String?,
  suggestedLocator: json['suggestedLocator'] == null
      ? null
      : LocatorSuggestionModel.fromJson(
          json['suggestedLocator'] as Map<String, dynamic>,
        ),
  boxes:
      (json['boxes'] as List<dynamic>?)
          ?.map((e) => PalletBoxModel.fromJson(e as Map<String, dynamic>))
          .toList() ??
      [],
  history:
      (json['history'] as List<dynamic>?)
          ?.map(
            (e) => PalletEventBriefModel.fromJson(e as Map<String, dynamic>),
          )
          .toList() ??
      [],
);

Map<String, dynamic> _$PalletModelToJson(PalletModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'lotNo': instance.lotNo,
      'categoryCode': instance.categoryCode,
      'categoryName': ?instance.categoryName,
      'lotType': instance.lotType,
      'stockyCode': ?instance.stockyCode,
      'detailLevel': instance.detailLevel,
      'boxCount': ?instance.boxCount,
      'totalQty': ?instance.totalQty,
      'inspectionStatus': instance.inspectionStatus,
      'disposition': ?instance.disposition,
      'isUrgent': instance.isUrgent,
      'sapStatus': ?instance.sapStatus,
      'sapPushedAt': ?instance.sapPushedAt?.toIso8601String(),
      'productionDate': ?instance.productionDate?.toIso8601String(),
      'models': ?instance.models,
      'modelSummary': instance.modelQtys,
      'locatorId': ?instance.locatorId,
      'locatorCode': ?instance.locatorCode,
      'areaCode': ?instance.areaCode,
      'areaName': ?instance.areaName,
      'allowedActions': instance.allowedActions,
      'suggestedLocator': ?instance.suggestedLocator,
      'boxes': instance.boxes,
      'history': instance.history,
    };

LocatorSuggestionModel _$LocatorSuggestionModelFromJson(
  Map<String, dynamic> json,
) => LocatorSuggestionModel(
  locatorId: (json['locatorId'] as num).toInt(),
  locatorCode: json['locatorCode'] as String,
  areaCode: json['areaCode'] as String?,
  areaName: json['areaName'] as String?,
  reason: json['reason'] as String?,
);

Map<String, dynamic> _$LocatorSuggestionModelToJson(
  LocatorSuggestionModel instance,
) => <String, dynamic>{
  'locatorId': instance.locatorId,
  'locatorCode': instance.locatorCode,
  'areaCode': ?instance.areaCode,
  'areaName': ?instance.areaName,
  'reason': ?instance.reason,
};

PalletModelQtyModel _$PalletModelQtyModelFromJson(Map<String, dynamic> json) =>
    PalletModelQtyModel(
      model: json['model'] as String,
      totalQty: (json['qty'] as num).toInt(),
      boxCount: (json['boxCount'] as num?)?.toInt() ?? 0,
    );

Map<String, dynamic> _$PalletModelQtyModelToJson(
  PalletModelQtyModel instance,
) => <String, dynamic>{
  'model': instance.model,
  'qty': instance.totalQty,
  'boxCount': instance.boxCount,
};

PalletBoxModel _$PalletBoxModelFromJson(Map<String, dynamic> json) =>
    PalletBoxModel(
      id: (json['id'] as num).toInt(),
      boxNo: json['boxNo'] as String,
      payload: json['payload'] as String,
      lines:
          (json['lines'] as List<dynamic>?)
              ?.map(
                (e) => PalletBoxLineModel.fromJson(e as Map<String, dynamic>),
              )
              .toList() ??
          [],
    );

Map<String, dynamic> _$PalletBoxModelToJson(PalletBoxModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'boxNo': instance.boxNo,
      'payload': instance.payload,
      'lines': instance.lines,
    };

PalletBoxLineModel _$PalletBoxLineModelFromJson(Map<String, dynamic> json) =>
    PalletBoxLineModel(
      id: (json['id'] as num).toInt(),
      model: json['model'] as String,
      qty: PalletBoxLineModel._qtyFromJson(json['qty']),
      serialNo: json['serialNo'] as String?,
    );

Map<String, dynamic> _$PalletBoxLineModelToJson(PalletBoxLineModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'model': instance.model,
      'qty': instance.qty,
      'serialNo': ?instance.serialNo,
    };

PalletEventBriefModel _$PalletEventBriefModelFromJson(
  Map<String, dynamic> json,
) => PalletEventBriefModel(
  eventCode: json['eventCode'] as String,
  eventAt: DateTime.parse(json['eventAt'] as String),
  actor: json['actor'] as String?,
  toLocatorCode: json['toLocatorCode'] as String?,
);

Map<String, dynamic> _$PalletEventBriefModelToJson(
  PalletEventBriefModel instance,
) => <String, dynamic>{
  'eventCode': instance.eventCode,
  'eventAt': instance.eventAt.toIso8601String(),
  'actor': ?instance.actor,
  'toLocatorCode': ?instance.toLocatorCode,
};
