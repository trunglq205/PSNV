﻿using System.Reflection.Metadata;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using Refit;
using SWMS_API.SWMS.Core.BusinessDomain;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Layout;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;
using Wkhtmltopdf.NetCore;

namespace SWMS_WebTool.Controllers
{
    public class KittingEmapController : BaseController
    {
        private readonly ApiService _apiService;

        private EmapGrid? emapGrid;
        private Floor? floorDetail;

        public KittingEmapController(ApiService apiService)
        {
            _apiService = apiService;
        }

        // GET: /<controller>/
        public async Task<IActionResult> Index([FromQuery] int SelectedFloor = 1, KittingEmapFilter? filter = null)
        {
            try
            {
                var nameIdentifier = User.FindFirst(ClaimTypes.NameIdentifier)?.Value;

                KittingEmapFilter _filter = filter ?? new KittingEmapFilter();

                

                _filter.PIC ??= nameIdentifier;






                var suggestKittingRequest = new GetListSuggestKittingRequest()
                {
                    KittingType =  5, //int.Parse(_filter.SelectedTab.ToEnumMemberAttrValue()),
                    PicUser = null, //_filter.PIC,
                    DeliveryDate = _filter.Date?.ToString("yyyy-MM-dd") ?? "",
                    KittingTimeType = _filter.KittingType?.ToEnumMemberAttrValue(),
                    PageNumber = 1,
                    PageSize = 200,
                };
                var kittingSuggestList = await _apiService.GetListSuggestKitting(suggestKittingRequest);

                var floors = await _apiService.GetFloors();

                var selectedFloor = SelectedFloor >= floors.Count ? 0 : SelectedFloor;


                // lỗi sequence no element do  kittingSuggestList.Records null
                var floorCode = kittingSuggestList.Records.First().LocationName.First().ToString();

                var floorId = floors.Find(e => e.FloorCode == floorCode).FloorId;

                var floorDetail = this.floorDetail ?? await _apiService.GetLayoutDetail(floorId);
                this.floorDetail ??= floorDetail;

               

                // ------------------------------
                //var trolleyTV = new Node(Constants.TROLLEY_TV_LOCATION.Item1, Constants.TROLLEY_TV_LOCATION.Item2, "Trolley TV");
                //var kittingPoint = floorDetail.FindRackBoundingBoxs(kittingSuggestList.Records.Where(e => e.PickedQuantity < e.Quantity).Select(e => e.LocationName).Distinct().ToList());

                //emapGrid ??= new EmapGrid(floorDetail);
                //emapGrid.MapKittingLocation(floorDetail, kittingPoint);

                //var suggestPath = new Pathfinding(emapGrid).FindOptimalPath(trolleyTV, trolleyTV, kittingPoint.ToList());
                //var sortedNodes = suggestPath.VisitedWaypoints.Select(e => e.Name).ToList();
                //kittingSuggestList.Records = kittingSuggestList.Records.OrderBy(e => sortedNodes.IndexOf(e.LocationName)).ToList();
                //kittingSuggestList.SuggestPath = suggestPath.OptimalPath;
                //kittingSuggestList.OrderBlock = suggestPath.VisitedWaypoints;
                // ------------------------------

                Node oldNode = kittingSuggestList.SuggestPath.FirstOrDefault();

                kittingSuggestList.SuggestPath?.ForEach(e =>
                {
                    floorDetail.Widgets.Add(new Line()
                    {
                        Points = new List<Point> { new Point(oldNode.X, oldNode.Y), new Point(e.X, e.Y) },
                        Border = "red",
                        BorderWidth = 10,
                    });

                    oldNode = e;
                });

                var list = kittingSuggestList.OrderBlock?.Distinct().ToList();
                for (var i = (list?.Count - 1) ?? 0; i >= 0; i--)
                {
                    var value = list[i];
                    floorDetail.Widgets.Add(new Circle()
                    {
                        X = value.X,
                        Y = value.Y,
                        Radius = 30,
                        Fill = "black"
                    });
                    floorDetail.Widgets.Add(new Text()
                    {
                        X = value.X - 16,
                        Y = value.Y - 16,
                        Fill = "white",
                        Label = (i + 1).ToString(),
                        Align = "center",
                        VertialAlign = "middle",
                        FontSize = 32,
                    });
                }

                var model = new KittingEmapViewModel()
                {
                    Items = kittingSuggestList.Records,
                    Floors = floors,
                    FloorLayout = floorDetail,
                    EmapGrid = emapGrid,
                    Filter = filter,
                };
                return View("Views/KittingEmap/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        public async Task<IActionResult> Demo([FromQuery] string kittingPos, int SelectedFloor = 0, bool showRoad = false, bool showObstacle = false)
        {
            try
            {
                var kittingPoints = kittingPos?.Split(",").ToList() ?? new List<string>() { "2.B40B.1.01", "2.B40B.1.02" };
                var res = await _apiService.SuggestKitting(kittingPoints);
                var floorLayout = res.LayoutMap;

                Node oldNode = res.SuggestPath.FirstOrDefault();

                res.SuggestPath?.ForEach(e =>
                {
                    floorLayout.Widgets.Add(new Line()
                    {
                        Points = new List<Point> { new Point(oldNode.X * 10, oldNode.Y *10), new Point(e.X *10, e.Y * 10) },
                        Border = "red",
                        BorderWidth = 10,
                    });

                    oldNode = e;
                });

                var model = new KittingEmapViewModel()
                {
                    FloorLayout = floorLayout,
                    //EmapGrid = emapGrid,
                    //KittingPoint = kittingPoint
                };
                return View("Views/KittingEmap/Demo.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public IActionResult GetBlockBoundingBox([FromQuery] string block, KonvaObject konvaObject)
        {
            var floor = WidgetFactory.BuildWidget(konvaObject) as Floor;
            if (string.IsNullOrWhiteSpace(block))
            {
                return BadRequest(new { message = _loc.Get("Msg_BlockParamRequired") });
            }

            var boundingBox = floor.FindRackBoundingBoxs(new List<string>() { block }).First()?.BoundingBox;

            if (boundingBox == null)
            {
                return NotFound(new { message = _loc.Get("Msg_BoundingBoxNotFound") });
            }

            return Json(new { data = boundingBox });
        }
    }
}
