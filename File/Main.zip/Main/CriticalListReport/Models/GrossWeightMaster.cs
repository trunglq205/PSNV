﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("GrossWeightMaster")]
    public class GrossWeightMaster
    {
        public int ID { get; set; }
        public string? Material { get; set; }
        [Column(TypeName = "decimal(18,5)")]
        public decimal? GrossWeight { get; set; }
        public string? UnitOfPacking { get; set; }
    }
}
