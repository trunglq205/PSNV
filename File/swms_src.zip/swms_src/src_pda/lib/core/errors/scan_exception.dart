part of 'exceptions.dart';

/// Lỗi nghiệp vụ khi quét thùng / model (trước bước tạo lot).
sealed class ScanException extends AppException {
  const ScanException(super.message, {required super.code});
}

class DuplicateCartonException extends ScanException {
  const DuplicateCartonException()
      : super('Thùng này đã được quét rồi', code: 'error.duplicate_carton');
}

class NotDuplicateModelException extends ScanException {
  const NotDuplicateModelException()
      : super('Model phải giống nhau', code: 'error.not_duplicate_model');
}

class NotDuplicateCategoryException extends ScanException {
  const NotDuplicateCategoryException()
      : super('Category phải giống nhau', code: 'error.not_duplicate_category');
}

class CateMismatchException extends ScanException {
  const CateMismatchException({required this.expected, required this.actual})
      : super(
    'Thùng thuộc Cate "$actual", không khớp với pallet đang quét (Cate "$expected")',
    code: 'error.cate_mismatch',
  );

  final String expected;
  final String actual;

  @override
  Map<String, String> get namedArgs => {
    'expected': expected,
    'actual': actual,
  };
}

class NoModelInfoException extends ScanException {
  const NoModelInfoException()
      : super('Chưa có thông tin của model', code: 'error.no_model_info');
}

class NoPartCardException extends ScanException {
  const NoPartCardException()
      : super('Chưa có part card nào được quét', code: 'error.no_part_card');
}

class NoSerialException extends ScanException {
  const NoSerialException()
      : super('Chưa có serial nào được quét', code: 'error.no_serial');
}

class NoCategoryException extends ScanException {
  const NoCategoryException()
      : super('Chưa có serial nào được quét', code: 'error.cate_mismatch');
}

class InvalidBoxCountException extends ScanException {
  const InvalidBoxCountException()
      : super('Số hộp phải lớn hơn 0', code: 'error.invalid_box_count');
}

class ModelNotMatchException extends ScanException {
  const ModelNotMatchException()
      : super('Mã model không khớp', code: 'error.model_not_match');
}