using Swms.FinishGoods.Api.Features.Models.Business;
using Swms.FinishGoods.Api.Features.Models.DataAccess;

namespace Swms.FinishGoods.Api.Features.Models;

public static class ModelModule
{
    public static IServiceCollection AddModelFeature(this IServiceCollection services)
    {
        services.AddScoped<IModelService, ModelService>();
        services.AddScoped<IModelRepository, ModelRepository>();
        return services;
    }
}

// Program.cs:
//   builder.Services.AddModelFeature();
