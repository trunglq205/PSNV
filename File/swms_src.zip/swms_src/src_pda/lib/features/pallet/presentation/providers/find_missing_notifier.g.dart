// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'find_missing_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Phiên "tìm thùng bị mất" — client thuần, không gọi API.
/// Family theo lot_no; danh sách thùng lấy từ [palletProvider] (đã cache
/// bởi màn Detail) nên route không cần truyền `boxes` nữa.

@ProviderFor(FindMissingNotifier)
final findMissingProvider = FindMissingNotifierFamily._();

/// Phiên "tìm thùng bị mất" — client thuần, không gọi API.
/// Family theo lot_no; danh sách thùng lấy từ [palletProvider] (đã cache
/// bởi màn Detail) nên route không cần truyền `boxes` nữa.
final class FindMissingNotifierProvider
    extends $NotifierProvider<FindMissingNotifier, FindMissingState> {
  /// Phiên "tìm thùng bị mất" — client thuần, không gọi API.
  /// Family theo lot_no; danh sách thùng lấy từ [palletProvider] (đã cache
  /// bởi màn Detail) nên route không cần truyền `boxes` nữa.
  FindMissingNotifierProvider._({
    required FindMissingNotifierFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'findMissingProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$findMissingNotifierHash();

  @override
  String toString() {
    return r'findMissingProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  FindMissingNotifier create() => FindMissingNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(FindMissingState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<FindMissingState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is FindMissingNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$findMissingNotifierHash() =>
    r'778d06386e8c3d5564fd580cd57c04336872acc9';

/// Phiên "tìm thùng bị mất" — client thuần, không gọi API.
/// Family theo lot_no; danh sách thùng lấy từ [palletProvider] (đã cache
/// bởi màn Detail) nên route không cần truyền `boxes` nữa.

final class FindMissingNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          FindMissingNotifier,
          FindMissingState,
          FindMissingState,
          FindMissingState,
          String
        > {
  FindMissingNotifierFamily._()
    : super(
        retry: null,
        name: r'findMissingProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Phiên "tìm thùng bị mất" — client thuần, không gọi API.
  /// Family theo lot_no; danh sách thùng lấy từ [palletProvider] (đã cache
  /// bởi màn Detail) nên route không cần truyền `boxes` nữa.

  FindMissingNotifierProvider call(String lotNo) =>
      FindMissingNotifierProvider._(argument: lotNo, from: this);

  @override
  String toString() => r'findMissingProvider';
}

/// Phiên "tìm thùng bị mất" — client thuần, không gọi API.
/// Family theo lot_no; danh sách thùng lấy từ [palletProvider] (đã cache
/// bởi màn Detail) nên route không cần truyền `boxes` nữa.

abstract class _$FindMissingNotifier extends $Notifier<FindMissingState> {
  late final _$args = ref.$arg as String;
  String get lotNo => _$args;

  FindMissingState build(String lotNo);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<FindMissingState, FindMissingState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<FindMissingState, FindMissingState>,
              FindMissingState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
