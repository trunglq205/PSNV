namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

// Entity đọc/ghi bằng Dapper — tên property khớp alias trong SQL của ShipmentTripRepository.

/// <summary>1 dòng wms.shipment_trips.</summary>
public class TripRow
{
    public long Id { get; set; }
    public string TripNo { get; set; } = "";
    public string VehicleType { get; set; } = "";       // container | truck
    public string? PlateNo { get; set; }
    public string? ContainerNo { get; set; }
    public string? ContainerSize { get; set; }
    public string? SealNo { get; set; }
    public string? DriverName { get; set; }
    public string? DriverPhone { get; set; }
    public string? DriverIdType { get; set; }           // "cccd" khi có DriverIdNo (cột cũ, giữ cho constraint / client cũ)
    public string? DriverIdNo { get; set; }             // số CCCD
    public string? DriverLicenseNo { get; set; }        // số GPLX
    public string? ForwarderCode { get; set; }
    public DateTime? PlannedArrivalAt { get; set; }

    public string Status { get; set; } = "planned";
    public DateTime? ArrivedAt { get; set; }
    public string? ArrivedBy { get; set; }
    public DateTime? SealedAt { get; set; }
    public string? SealedBy { get; set; }
    public DateTime? DepartedAt { get; set; }
    public string? DepartedBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelledBy { get; set; }
    public string? CancelReason { get; set; }

    public string? Note { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>1 SI trên 1 chuyến, kèm thông tin SI để hiển thị.</summary>
public class TripSiRow
{
    public long TripId { get; set; }
    public long SiId { get; set; }
    public string SiNo { get; set; } = "";
    public string DocNo { get; set; } = "";
    public string DocStatus { get; set; } = "";
    public string? ShipMode { get; set; }
    /// <summary>COALESCE(vanning_date, etd_date) — cùng định nghĩa màn SI.</summary>
    public DateTime VanningDate { get; set; }
    public int? PltPlanned { get; set; }
    /// <summary>Tổng package_plt các dòng SI.</summary>
    public int SiPltTotal { get; set; }
    /// <summary>Tổng plt_planned của SI trên mọi chuyến chưa huỷ.</summary>
    public int SiPltPlannedAll { get; set; }
}

/// <summary>Thông tin SI dùng để kiểm tra khi gắn vào chuyến.</summary>
public class SiLinkInfo
{
    public long SiId { get; set; }
    public string SiNo { get; set; } = "";
    public string DocStatus { get; set; } = "";
}

/// <summary>SI đang nằm trên 1 chuyến chưa huỷ / chưa xoá.</summary>
public class SiActiveTrip
{
    public long SiId { get; set; }
    public long TripId { get; set; }
    public string VehicleType { get; set; } = "";
    public string Status { get; set; } = "";
}

public record TripSiLink(long SiId, int? PltPlanned);