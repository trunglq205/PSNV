﻿namespace SWMS_WebTool.Models.DataKitting
{
    public class DataKittingDIP : DataKittingPL
    {
        public Int64 DataKittingDIPID { get; set; }
        public string Assembly { get; set; }
        public string Urgent { get; set; }
        public string Lvl { get; set; }
        public string MovingType { get; set; }
        public string Description { get; set; }
        public DateTime? ProductDate { get; set; }
        public string SlocDIP { get; set; }
        public string KittingTimeType { get; set; }
        public double AssemblyQuantity { get; set; }
        public double MaterialQuantity { get; set; }
        public string Vendor { get; set; }
        public string Sloc { get; set; }
    }
}
