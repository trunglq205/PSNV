﻿using SWMS_WebTool.Controllers;

namespace SWMS_WebTool.Models.Responses
{
    public class SearchResponse<T>
    {
        public List<T>? Records { get; set; }
        public int TotalRecord { get; set; }
    }
}
