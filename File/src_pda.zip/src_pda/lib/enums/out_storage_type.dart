enum OutStorageType {
  oneByOne,
  all,
}
