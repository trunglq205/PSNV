﻿using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.Models
{
    public class Supply
    {
        public string TrolleyName { get; set; }
        public string BarCode { get; set; }
        public ActionStatusEnum? ActionStatus { get; set; }
        public string Description { get; set; }
        public string Time { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Model { get; set; }
        public string Line { get; set; }
        public int? ModelQuantity { get; set; }
        public string? Category { get; set; }
        public string? KittingTimeType { get; set; }
        public string? PIC { get; set; }
    }
}
