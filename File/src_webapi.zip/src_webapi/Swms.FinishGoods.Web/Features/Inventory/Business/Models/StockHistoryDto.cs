using System.Text.Json.Serialization;

namespace Swms.FinishGoods.Web.Features.Inventory.Business.Models;

// ══════════════════════════════════════════════════════════════
//  DTO — khớp response của API (Features/StockEvents/Api)
// ══════════════════════════════════════════════════════════════

/// <summary>Vị trí + khu. Null khi event không đổi vị trí.</summary>
public class LocatorRefDto
{
    public string LocatorCode { get; set; } = "";
    public string? AreaCode { get; set; }
}

/// <summary>
/// Một dòng timeline. API KHÔNG trả nhãn/màu/icon — chỉ có 29 tổ hợp nên chúng
/// nằm ở catalog tải riêng một lần (<see cref="StockEventCatalog"/>).
/// </summary>
public class StockEventDto
{
    public long Id { get; set; }
    public string EventCode { get; set; } = "";
    public DateTime EventAt { get; set; }
    public string? Actor { get; set; }

    // API trả "from"/"to" (LocatorRef). Giữ tên property C# rõ nghĩa,
    // map tên JSON tường minh — thiếu attribute này 2 field luôn null.
    [JsonPropertyName("from")]
    public LocatorRefDto? FromLocator { get; set; }

    [JsonPropertyName("to")]
    public LocatorRefDto? ToLocator { get; set; }

    public string? RefNo { get; set; }
    public string? RelatedPalletCode { get; set; }
    public int? BoxCountBefore { get; set; }
    public int? BoxCountAfter { get; set; }
    public string? Note { get; set; }
    public string? Payload { get; set; }

    public static AppStockEvent ToViewModel(StockEventDto d, StockEventCatalog catalog)
    {
        var type = catalog.Get(d.EventCode);

        return new AppStockEvent
        {
            Id = d.Id,
            EventCode = d.EventCode,
            // Catalog chưa tải kịp / code lạ -> ghép key theo quy ước để vẫn ra
            // đúng chuỗi i18n thay vì hiện mã trần.
            NameKey = type?.NameKey ?? $"stock_event.{d.EventCode}",
            GroupCode = type?.GroupCode,
            ColorToken = type?.ColorToken ?? "dim",
            EventAt = d.EventAt.ToString("dd/MM/yyyy HH:mm"),
            Actor = d.Actor,
            Initials = Initials(d.Actor),
            FromText = Where(d.FromLocator),
            ToText = Where(d.ToLocator),
            RelatedPalletCode = d.RelatedPalletCode,
            BoxCountBefore = d.BoxCountBefore,
            BoxCountAfter = d.BoxCountAfter,
            RefNo = d.RefNo,
            Note = d.Note,
        };
    }

    /// <summary>"FA · A-03-02-01" — khu đứng trước để đọc từ to đến nhỏ.</summary>
    private static string? Where(LocatorRefDto? l)
        => l is null ? null
         : string.IsNullOrWhiteSpace(l.AreaCode) ? l.LocatorCode
         : $"{l.AreaCode} · {l.LocatorCode}";

    /// <summary>Chữ cái đầu cho avatar: "Nguyễn Văn A" -> "VA".</summary>
    private static string Initials(string? name)
    {
        var parts = (name ?? "").Split(' ', StringSplitOptions.RemoveEmptyEntries);
        return parts.Length switch
        {
            0 => "?",
            1 => parts[0][..1].ToUpperInvariant(),
            _ => $"{parts[^2][..1]}{parts[^1][..1]}".ToUpperInvariant(),
        };
    }
}

/// <summary>Header của lịch sử. Dialog dùng AppInventoryItem có sẵn nên chưa đọc tới.</summary>
public class StockHistoryHeaderDto
{
    public long PalletId { get; set; }
    public string PalletCode { get; set; } = "";
    public string? StockyCode { get; set; }
    public string? Model { get; set; }
    public int? BoxCount { get; set; }
    public string InspectionStatus { get; set; } = "";
    public DateTime? ProductionDate { get; set; }
    public LocatorRefDto? CurrentLocator { get; set; }
    public bool IsDeleted { get; set; }
}

public class StockHistoryDto
{
    public StockHistoryHeaderDto Header { get; set; } = new();
    public List<StockEventDto> Events { get; set; } = new();
}

/// <summary>Một loại event trong catalog.</summary>
public class StockEventTypeDto
{
    public string Code { get; set; } = "";
    public string NameKey { get; set; } = "";
    public string SubjectType { get; set; } = "";
    public string GroupCode { get; set; } = "";
    public string ColorToken { get; set; } = "dim";
    public string? Icon { get; set; }
    public int SortOrder { get; set; }
}

/// <summary>Catalog + mốc phiên bản (ETag) để biết khi nào phải tải lại.</summary>
public class StockEventTypeListDto
{
    public string Version { get; set; } = "";
    public List<StockEventTypeDto> Types { get; set; } = new();
}

// ══════════════════════════════════════════════════════════════
//  View model
// ══════════════════════════════════════════════════════════════

/// <summary>Một mốc trên timeline, đã format sẵn để render.</summary>
public class AppStockEvent
{
    public long Id { get; set; }
    public string EventCode { get; set; } = "";

    /// <summary>Key i18n, vd "stock_event.STORAGE_IN". Component gọi L[NameKey].</summary>
    public string NameKey { get; set; } = "";

    public string? GroupCode { get; set; }
    public string ColorToken { get; set; } = "dim";

    public string EventAt { get; set; } = "";
    public string? Actor { get; set; }
    public string Initials { get; set; } = "?";

    /// <summary>"FA · A-03-02-01". Null khi event không có chiều tương ứng.</summary>
    public string? FromText { get; set; }
    public string? ToText { get; set; }

    public string? RelatedPalletCode { get; set; }
    public int? BoxCountBefore { get; set; }
    public int? BoxCountAfter { get; set; }
    public string? RefNo { get; set; }
    public string? Note { get; set; }

    /// <summary>Vị trí hiển thị cạnh tiêu đề: ưu tiên đích, không có thì lấy nguồn.</summary>
    public string? PlaceText => ToText ?? FromText;

    /// <summary>Có cả nguồn lẫn đích -> vẽ mũi tên A → B.</summary>
    public bool HasMovePath => FromText is not null && ToText is not null;

    public bool HasBoxChange => BoxCountBefore is not null && BoxCountAfter is not null;
}

/// <summary>Helper hiển thị timeline.</summary>
public static class StockEventDisplay
{
    /// <summary>
    /// color_token của catalog -> biến màu trong swms-components.css.
    /// Không tự chế màu mới: mọi giá trị đều là token đã có trong design system.
    /// </summary>
    public static string ColorVar(string? token) => token switch
    {
        "success" => "var(--success)",
        "warning" => "var(--warning)",
        "danger" => "var(--danger)",
        "info" => "var(--info)",
        _ => "var(--text-4)",
    };

    public static string DotColor(string? token) => token switch
    {
        "success" => "var(--success)",
        "warning" => "var(--warning)",
        "danger" => "var(--danger)",
        _ => "var(--border-2)",
    };
}
