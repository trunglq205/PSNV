﻿using Swms.FinishGoods.API.Features.Scan.Business;
using Swms.FinishGoods.API.Features.Scan.DataAccess;

namespace Swms.FinishGoods.API.Features.Scan
{
    public static class ScanModule
    {
        public static IServiceCollection AddScanFeature(this IServiceCollection services)
        {
            services.AddScoped<IScanService, ScanService>();
            services.AddScoped<IScanRepository, ScanRepository>();
            return services;
        }
    }
}