import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';

@immutable
class StockyState {
  final StockyMode mode;

  /// Xe đã quét, xe mới nhất ở đầu — vừa quét là thấy ngay trên cùng.
  final List<StockyCart> carts;

  /// Đang tra xe vừa quét — khoá quét tiếp để không chồng request.
  final bool lookingUp;
  final bool submitting;

  const StockyState({
    this.mode = StockyMode.receive,
    this.carts = const [],
    this.lookingUp = false,
    this.submitting = false,
  });

  bool get busy => lookingUp || submitting;
  bool get canSubmit => carts.isNotEmpty && !busy;

  int get totalQty => carts.fold(0, (s, c) => s + c.qty);

  bool contains(String code) => carts.any((c) => c.code == code);

  StockyState copyWith({
    StockyMode? mode,
    List<StockyCart>? carts,
    bool? lookingUp,
    bool? submitting,
  }) =>
      StockyState(
        mode: mode ?? this.mode,
        carts: carts ?? this.carts,
        lookingUp: lookingUp ?? this.lookingUp,
        submitting: submitting ?? this.submitting,
      );
}
