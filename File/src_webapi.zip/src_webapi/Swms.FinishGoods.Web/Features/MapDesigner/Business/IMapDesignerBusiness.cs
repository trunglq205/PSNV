using Swms.FinishGoods.Web.Features.MapDesigner.Business.Models;
using Swms.FinishGoods.Web.Shared.Business.Models;

namespace Swms.FinishGoods.Web.Features.MapDesigner.Business;

public interface IMapDesignerBusiness
{
    Task<Result<MapLayoutDto>> GetLayoutAsync(string areaCode);
    Task<Result> SaveLayoutAsync(string areaCode, List<MapBlockDto> blocks);
    Task<Result<long>> CreateRackAsync(string areaCode, CreateRackInputDto input);
    Task<Result> DeleteRackAsync(string areaCode, string rackCode);
}
