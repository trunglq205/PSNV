# API Core — Feature Models (`master.models`)

Backend cho `/api/models`, viết theo kiến trúc vertical slice của feature `Users`
(xem "Hướng dẫn viết API Core (SWMS Finish Goods)"). Cặp với feature Web đã scaffold trước đó.

## Cấu trúc

```
Features/Models/
├── Api/
│   ├── ModelsController.cs        route api/models, mỏng, chỉ gọi service
│   └── ModelModels.cs             Query / Request / Response DTOs + DuplicateModelInfo
├── Business/
│   ├── IModelService.cs
│   ├── ModelService.cs            validate, check trùng, build entity, gọi repo
│   └── BulkModelConflictException.cs
├── DataAccess/
│   ├── IModelRepository.cs
│   └── ModelRepository.cs         Dapper + SQL thuần
├── ModelEntity.cs                 domain entity (không lộ ra ngoài)
├── ModelModule.cs                 AddModelFeature() — DI
├── models_schema.sql              DDL master.categories + master.models
└── SharedResource_Models_backend_keys.txt
```

## Endpoint

| Method | Route | Status | Permission |
|---|---|---|---|
| GET | `/api/models` | 200 | `Models.View` |
| GET | `/api/models/{id}` | 200 / 404 | `Models.View` |
| POST | `/api/models` | 201 / 409 | `Models.Create` |
| POST | `/api/models/bulk` | 200 / 409 | `Models.Create` |
| PUT | `/api/models/{id}` | 204 / 404 / 409 | `Models.Update` |
| DELETE | `/api/models/{id}` | 204 / 404 | `Models.Delete` |
| GET | `/api/models/category-options` | 200 | `Models.View` |

## Tích hợp

1. **DDL**: chạy `models_schema.sql` (cần có `master.categories` trước, hoặc bảng category tương đương trong project — sửa lại tên bảng/cột trong Repository nếu khác).

2. **Permission**: khai báo nhóm quyền trong `Perms` (Roles.Catalog) trước khi build:
   ```csharp
   public static partial class Perms
   {
       public static partial class Master
       {
           public static class Models
           {
               public sealed class View   : IPermission { public static string Code => "master.models.view"; }
               public sealed class Create : IPermission { public static string Code => "master.models.create"; }
               public sealed class Update : IPermission { public static string Code => "master.models.update"; }
               public sealed class Delete : IPermission { public static string Code => "master.models.delete"; }
           }
       }
   }
   ```
   (Điều chỉnh theo đúng shape `IPermission`/`Perms` thật trong project — tên `Perms.Master.Models.*` trong Controller phải khớp.)

3. **DI** (`Program.cs`):
   ```csharp
   builder.Services.AddModelFeature();
   ```

4. **Resx**: paste `SharedResource_Models_backend_keys.txt` vào cả 4 file resx
   (các key `Models.NotFound`, `Models.CodeExists`, `Models.CategoryNotFound`,
   `Models.Bulk.*`). Không trùng với key tầng Web.

5. **BulkModelConflictException → HTTP 409**: đảm bảo middleware exception→status
   có nhánh map exception này sang 409 kèm body chứa `Conflicts` (để FE đọc
   `ErrorCode.BulkConflict` + `ConflictDetail`). Nếu middleware của project dùng
   cơ chế khác (vd `ConflictException` mang details), đổi `BulkModelConflictException`
   thành cách project đang dùng cho bulk conflict ở feature Users.

## Điểm cần chỉnh theo project thật

- **Namespace/`using` Shared**: `IDbConnectionFactory`, `PagedQuery`, `PagedResult`,
  `NotFoundException`/`ConflictException`/`BusinessRuleException`, `ICurrentUser`,
  `SharedResource`, `RequirePermission`/`Perms` — đang dùng namespace giả định
  `Swms.FinishGoods.Api.Shared.*`. Sửa cho khớp namespace thật (copy đúng `using`
  từ `UsersController.cs` / `UserService.cs`).
- **Kiểu khoá `int`**: theo đúng guide (`{id:int}`, `AddAsync → int`). DB là BIGINT;
  nếu base project dùng `long`, đổi đồng loạt `int Id` → `long Id` cả API lẫn Web.
- **`ICurrentUser.FullName`**: dùng ghi `created_by`/`updated_by` dạng string. Nếu
  project ghi `created_by` là FK `BIGINT → master.users.id`, đổi cột + kiểu tương ứng.
- **Category**: nếu project chưa có `master.categories` mà dùng bảng khác (vd
  `attribute_sets`), trỏ lại JOIN + `CategoryExistsAsync`/`GetCategoryOptionsAsync`.

## Checklist nghiệm thu

- [ ] 4 tầng: Api (Controller + Models), Business (Interface + Service + Exception), DataAccess (Interface + Repository), Module
- [ ] Controller mỏng, không logic, không try/catch, status REST đúng (200/201/204/404/409)
- [ ] Mỗi action gắn `[RequirePermission<Perms.Master.Models.*>]`
- [ ] DTO tách Query/Create/Update/Response; entity không lộ ra ngoài; có `From`
- [ ] Validate hình thức bằng DataAnnotations; nghiệp vụ (trùng code, category) trong Service
- [ ] Mọi query có `is_deleted = 0`; xoá là soft delete
- [ ] Bulk: validate trùng (batch + DB) + category trước, insert trong 1 transaction, trả conflict chi tiết
- [ ] Phân trang clamp Page/Size; SQL OFFSET/FETCH + COUNT cùng query
- [ ] `AddModelFeature()` gọi trong Program.cs
- [ ] Error key `Models.*` ở cả 4 resx
