﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class frmContinue : Form
    {
        private ConnectSQL objConnect = new ConnectSQL();
        String strModelNumber = String.Empty;
        String strShrinkID = String.Empty;
        String employee_id;
        String shrink_Id = String.Empty;
        String quantity1 = String.Empty;

        public frmContinue(string employee_id)
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            this.employee_id = employee_id;
            txtSerial.Focus();

        }

        private void frmContinue_Load(object sender, EventArgs e)
        {
            txtModel.Focus();
        }



        //private void txtPallet_KeyUp(object sender, KeyEventArgs e)
        //{
        //    if (e.KeyCode == Keys.Enter)
        //    {
        //        //
        //        string pallet_no = txtSerial.Text.Trim();

        //        if (pallet_no.Length != 12)
        //        {

        //            lblStatus.Text = "SAI ĐỊNH DẠNG SỐ PALLET";
        //            txtSerial.Focus();
        //            txtSerial.SelectAll();
        //            return;

        //        }


        //        else
        //        {
        //            if (pallet_no.Trim().Substring(0, 3) != "110")
        //            {
        //                lblStatus.Text = "SAI ĐỊNH DẠNG SỐ PALLET";
        //                txtSerial.Focus();
        //                txtSerial.SelectAll();
        //                return;
        //            }
        //            DataTable objTb = objConnect.GetTableWithCommandText("select * from TBLSHRINKPRE where sPalletNo='" + pallet_no + "'");
        //            if (objTb.Rows.Count > 0)
        //            {
        //                string strPalletNo = txtSerial.Text.Trim();
        //                string quantiy = objConnect.GetExcuteScalar("SELECT  count (*)  FROM [dbo].[TBLSHRINKEXE] where ShrinkID in (select ShrinkID from TBLSHRINKPRE where sPalletNo='" + strPalletNo + "')").ToString();
        //                this.quantity1 = quantiy;
        //                DataTable objTB = objConnect.GetTableWithCommandText("select * from TBLSHRINKPRE where  sPalletNo='" + strPalletNo + "')");

        //                strModelNumber = objTb.Rows[0]["sModelNo"].ToString();
        //                strShrinkID = objTb.Rows[0]["ShrinkID"].ToString();
        //                shrink_Id = strShrinkID;
        //                string strQuantityStd = objConnect.GetExcuteScalar("select top 1 QuantityStd from TBLSHRINKSTD where sModelNo='" + strModelNumber + "'").ToString();

        //                if (int.Parse(quantiy) >= int.Parse(strQuantityStd))
        //                {
        //                    lblStatus.Text = "Pallet này đã đầy rồi, Đừng quét nữa!!!";
        //                    txtSerial.Focus();
        //                }
        //                else
        //                {
        //                    txtModelSample.Focus();
        //                    lblStatus.Text = "";
        //                }

        //            }
        //            else
        //            {

        //                lblStatus.Text = "Pallet không tồn tại";
        //                txtSerial.Clear();
        //                txtSerial.Focus();
        //            }
        //        }
        //    }
        //}

        private void txtModelSample_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string strPalletNo = txtPallet.Text.Trim().ToUpper();
                string quantiy = objConnect.
                    GetExcuteScalar
 ("SELECT  count (*)  FROM TBLSHRINKEXE where ShrinkID in (select ShrinkID from TBLSHRINKPRE where sPalletNo='" + strPalletNo + "')").ToString();

                DataTable objTB = objConnect.GetTableWithCommandText("select * from TBLSHRINKPRE where  sPalletNo='" + strPalletNo + "'");

                strModelNumber = objTB.Rows[0]["sModelNo"].ToString();
                strShrinkID = objTB.Rows[0]["ShrinkID"].ToString();

                string strQuantityStd = objConnect.GetExcuteScalar("select top 1 QuantityStd from TBLSHRINKSTD where sModelNo='" + strModelNumber + "'").ToString();

                if (int.Parse(quantiy) >= int.Parse(strQuantityStd))
                {
                    lblStatus.Text = "Pallet này đã đầy rồi, Đừng quét nữa!!!";
                    txtSerial.Focus();
                    return;
                }
                else
                {
                    txtModelSample.Focus();
                    lblStatus.Text = "";



                    string model = txtModelSample.Text.Trim();
                    string process_factory = txtModelSample.Text.Trim() + "-" + txtExtension.Text;
                    if (process_factory.ToUpper() == strModelNumber.ToUpper())
                    {
                        frmStep4cs st4 = new frmStep4cs(employee_id, model, txtExtension.Text, strShrinkID, txtPallet.Text.Trim(), true, int.Parse(quantiy));
                        st4.ShowDialog();
                        txtSerial.Text = "";
                        txtModelSample.Text = "";
                        lblStatus.Text = "";
                        txtSerial.Focus();
                    }
                    else
                    {
                        lblStatus.Text = "MODEL này không đúng trên Pallet " + txtPallet.Text;
                        txtModelSample.Clear();
                        txtModelSample.Focus();
                    }
                }

            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void txtSerial_TextChanged(object sender, EventArgs e)
        {
            string data = txtSerial.Text;
            if (data.Contains('%'))
            {
                data = data.Replace('%', ' ');
            }
            if (data.Contains('*'))
            {
                data = data.Replace('*', ' ');
            }
            data = data.Trim();
            txtSerial.Text = data;
        }

        private void txtModel_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtSerial.Focus();
            }
        }

        private void txtModel_TextChanged(object sender, EventArgs e)
        {
            string data = txtModel.Text;
            if (data.Contains('%'))
            {
                data = data.Replace('%', ' ');
            }
            if (data.Contains('*'))
            {
                data = data.Replace('*', ' ');
            }
            data = data.Trim();
            txtModel.Text = data;
        }

        private void txtSerial_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string serial = txtSerial.Text.Trim();
                string query = "select sPalletNo from TBLSHRINKPRE A,TBLSHRINKEXE B where A.ShrinkID = B.ShrinkID and A.sModelNo ='" + txtModel.Text + "-" + txtExtension.Text + "' and B.sSerialNo = '" + serial + "'";
               
                string apllet ="";
                try {apllet=objConnect.GetExcuteScalar(query).ToString();
                }
                catch{};
                if (!String.IsNullOrEmpty(apllet))
                {
                    txtPallet.Text = apllet;
                    txtModelSample.Focus();
                }
                else {
                    txtSerial.Focus();
                    txtSerial.Clear();
                    txtPallet.Clear();
                    
                    lblStatus.Text = "KHONG TON TAI";
                }

            }
        }

        private void txtModelSample_TextChanged(object sender, EventArgs e)
        {
            string data = txtModelSample.Text;
            if (data.Contains('%'))
            {
                data = data.Replace('%', ' ');
            }
            if (data.Contains('*'))
            {
                data = data.Replace('*', ' ');
            }
            data = data.Trim();
            txtModelSample.Text = data;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            this.Close();
        }

    }
}
