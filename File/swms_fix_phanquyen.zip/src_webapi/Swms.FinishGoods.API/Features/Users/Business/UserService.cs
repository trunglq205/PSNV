using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.Users.Api;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.Models;
using System.Reflection.Emit;

namespace Swms.FinishGoods.API.Features.Users.Business;

public class UserService : IUserService
{
    private readonly IUserRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    /// <summary>
    /// Vô hiệu bộ đệm quyền khi role của user thay đổi — xem
    /// <see cref="PermissionCacheVersion"/>. Đổi role là đổi quyền hiệu lực,
    /// y như sửa quyền của chính role đó.
    /// </summary>
    private readonly PermissionCacheVersion _permVersion;

    // Phòng ban hợp lệ — khớp danh sách bên FE (UserCsv.Footer).
    private static readonly HashSet<string> ValidDepartments =
        new(StringComparer.OrdinalIgnoreCase) { "SCS", "FA", "OQC", "SEC", "IT" };

    public UserService(
       IUserRepository repo,
       ICurrentUser currentUser,
       IStringLocalizer<SharedResource> localizer,
       PermissionCacheVersion permVersion
    )
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
        _permVersion = permVersion;
    }

    public async Task<UserResponse> GetByIdAsync(int id)
    {
        var entity = await _repo.GetByIdAsync(id);

        if (entity is null)
            throw new NotFoundException(_localizer["User.NotFound", id]);
        return UserResponse.From(entity);
    }

    public async Task<PagedResult<UserResponse>> GetPagedAsync(UserQuery query)
    {
        if (query.Page < 1) query.Page = 1;
        if (query.Size < 1 || query.Size > 100) query.Size = 20;

        var (rows, total) = await _repo.GetPagedAsync(query);
        var items = rows.Select(UserResponse.From).ToList();
        return new PagedResult<UserResponse>(items, total, query.Page, query.Size);
    }

    public async Task<UserResponse> CreateAsync(CreateUserRequest request)
    {
        var empCode = request.EmployeeCode.Trim();

        // Validate
        ValidateDepartment(request.Department);
        var roleCodes = NormalizeRoles(request.RoleCodes);
        await EnsureRolesExistAsync(roleCodes);
        if (await _repo.EmployeeCodeExistsAsync(empCode, excludeId: null))
            throw new ConflictException(_localizer["User.EmployeeCodeExists", empCode]);

        // Build + insert
        var entity = BuildNewUser(request, empCode, roleCodes);
        entity.Id = await _repo.AddAsync(entity, entity.RoleCodes);

        // User mới có thể trùng id với một user đã xoá trước đó; rẻ hơn là cứ
        // vô hiệu bộ đệm chứ không lý luận xem có trùng hay không.
        _permVersion.Bump();

        return UserResponse.From(entity);
    }

    public async Task<List<UserResponse>> BulkCreateAsync(IReadOnlyList<CreateUserRequest> requests)
    {
        var empCodes = requests.Select(r => r.EmployeeCode.Trim()).ToList();

        // Validate từng request (department + role)
        foreach (var request in requests)
        {
            ValidateDepartment(request.Department);
            await EnsureRolesExistAsync(NormalizeRoles(request.RoleCodes));
        }

        // Validate trùng mã: DB + nội bộ batch
        var existingInDb = await _repo.GetExistingEmployeeCodesAsync(empCodes);
        var dupInBatch = empCodes
            .GroupBy(c => c, StringComparer.OrdinalIgnoreCase)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();

        var conflicts = new List<DuplicateUserInfo>();
        conflicts.AddRange(existingInDb.Select(x =>
            new DuplicateUserInfo(x.Id, x.EmployeeCode, _localizer["User.DuplicateInSystem"])));
        var inDbCodes = new HashSet<string>(
            existingInDb.Select(x => x.EmployeeCode), StringComparer.OrdinalIgnoreCase);
        conflicts.AddRange(dupInBatch
            .Where(c => !inDbCodes.Contains(c))
            .Select(c => new DuplicateUserInfo(null, c, _localizer["User.DuplicateInBatch"])));

        if (conflicts.Count > 0)
            throw new BulkUserConflictException(_localizer["User.BulkConflict", conflicts.Count], conflicts);

        // Build + insert trong 1 transaction
        var entities = requests
            .Select(r => BuildNewUser(r, r.EmployeeCode.Trim(), NormalizeRoles(r.RoleCodes)))
            .ToList();

        var ids = await _repo.AddManyAsync(entities);

        _permVersion.Bump();

        var results = new List<UserResponse>(entities.Count);
        for (int i = 0; i < entities.Count; i++)
        {
            entities[i].Id = ids[i];
            results.Add(UserResponse.From(entities[i]));
        }
        return results;
    }

    public async Task UpdateAsync(int id, UpdateUserRequest request)
    {
        ValidateDepartment(request.Department);

        var empCode = request.EmployeeCode.Trim();
        if (await _repo.EmployeeCodeExistsAsync(empCode, excludeId: id))
            throw new ConflictException(_localizer["User.EmployeeCodeExists", empCode]);

        var roleCodes = NormalizeRoles(request.RoleCodes);
        await EnsureRolesExistAsync(roleCodes);

        var entity = new User
        {
            Id = id,
            FullName = request.FullName.Trim(),
            Email = request.Email?.Trim(),
            Department = request.Department.Trim().ToUpperInvariant(),
            EmployeeCode = empCode,
            IsActive = request.IsActive,
            UpdatedAt = DateTime.UtcNow,
            UpdatedBy = _currentUser.FullName,
            RoleCodes = roleCodes,
        };

        if (!await _repo.UpdateAsync(entity, roleCodes))
            throw new NotFoundException("User");

        // Role của user vừa đổi ⇒ quyền hiệu lực đổi theo.
        _permVersion.Bump();
    }

    public async Task DeleteAsync(int id)
    {
        // Soft delete (master.users.is_deleted).
        if (!await _repo.SoftDeleteAsync(id, _currentUser.FullName))
            throw new NotFoundException("User");

        _permVersion.Bump();
    }

    public async Task<UserDeptCountResponse> GetDeptCountsAsync()
    {
        var counts = await _repo.GetDeptCountsAsync();
        return new UserDeptCountResponse(counts);
    }

    public async Task ResetPasswordAsync(int id)
    {
        var user = await _repo.GetByIdAsync(id)
            ?? throw new NotFoundException("User");

        var hasher = new PasswordHasher();


        // Reset = đặt lại mật khẩu mặc định bằng mã nhân viên.
        var hash = hasher.Hash(user.EmployeeCode);
        await _repo.UpdatePasswordHashAsync(id, hash, _currentUser.FullName);
    }

    public async Task<List<RoleOptionResponse>> GetRoleOptionsAsync()
    {
        var roles = await _repo.GetAllRolesAsync();
        return roles.Select(RoleOptionResponse.From).ToList();
    }

    // ---- helpers ----

    private User BuildNewUser(CreateUserRequest request, string empCode, IReadOnlyList<string> roleCodes)
    {
        var rawPassword = string.IsNullOrWhiteSpace(request.Password) ? empCode : request.Password;
        var hasher = new PasswordHasher();
        return new User
        {
            FullName = request.FullName.Trim(),
            Email = request.Email?.Trim(),
            Department = request.Department.Trim().ToUpperInvariant(),
            EmployeeCode = empCode,
            PasswordHash = hasher.Hash(rawPassword),
            IsActive = request.IsActive,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = _currentUser.FullName,
            RoleCodes = roleCodes.ToList(),
        };
    }

    private void ValidateDepartment(string department)
    {
        if (!ValidDepartments.Contains(department.Trim()))
            throw new BusinessRuleException(
                _localizer["User.DepartmentInvalid", department, string.Join(", ", ValidDepartments)]);
    }

    private static List<string> NormalizeRoles(IEnumerable<string>? roleCodes)
        => roleCodes?
            .Where(r => !string.IsNullOrWhiteSpace(r))
            .Select(r => r.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList() ?? new();

    private async Task EnsureRolesExistAsync(List<string> roleCodes)
    {
        if (roleCodes.Count == 0) return;

        var known = (await _repo.GetAllRolesAsync())
            .Select(r => r.Code)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var unknown = roleCodes.Where(c => !known.Contains(c)).ToList();
        if (unknown.Count > 0)
            throw new BusinessRuleException(
                _localizer["User.RolesInvalid", string.Join(", ", unknown)]);
    }
}