using Swms.FinishGoods.API.Features.ReturnInstructions.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

public interface IReturnInstructionService
{
    /// <summary>Danh sách chỉ thị back hàng theo bộ lọc. Dùng cho cả Web và PDA.</summary>
    Task<IReadOnlyList<ReturnInstructionResponse>> GetListAsync(ReturnInstructionQuery query);

    /// <summary>Một phiếu kèm chi tiết dòng.</summary>
    Task<ReturnInstructionResponse> GetByIdAsync(long id);

    /// <summary>
    /// SCS Office tạo chỉ thị. Tạo xong gửi mail báo FA — mail hỏng KHÔNG làm
    /// hỏng việc tạo phiếu, chỉ là <c>MailSentAt</c> để trống.
    /// </summary>
    Task<ReturnInstructionResponse> CreateAsync(ReturnInstructionRequest request);

    /// <summary>
    /// Sửa phiếu. KHÔNG gửi lại mail: FA đã nhận thông tin ban đầu, bắn thêm
    /// mail cho mỗi lần sửa chính tả sẽ làm người nhận bỏ qua cả loại mail này.
    /// </summary>
    Task<ReturnInstructionResponse> UpdateAsync(long id, ReturnInstructionRequest request);

    /// <summary>Xoá mềm phiếu và toàn bộ dòng.</summary>
    Task DeleteAsync(long id);

    /// <summary>
    /// Mục 2a — SCS WH nhận một pallet hàng return vào phiếu: quét từng thùng,
    /// quét serial trong thùng, hệ thống cấp Pallet ID và đăng ký toàn bộ serial
    /// vào sổ của phiếu.
    ///
    /// Pallet + sổ serial ghi trong CÙNG MỘT transaction, nên không có cảnh
    /// pallet đã tạo mà serial chưa vào sổ.
    ///
    /// Quét vượt SL chỉ thị KHÔNG bị chặn — chỉ bật cờ
    /// <c>OverReceived</c>: hàng về nhiều hơn khách báo là chuyện thường, và
    /// mục 2b có nhiệm vụ mail cho FA đúng số thực tế.
    /// </summary>
    Task<ReceiveReturnResponse> ReceiveAsync(long docId, ReceiveReturnRequest request);

    /// <summary>
    /// Mục 2b — WH quét xong thì chốt SL thực nhận: đóng phiếu, đóng dấu thời
    /// điểm chốt, và tự gửi mail báo FA số thực tế kèm bảng lệch so với chỉ thị.
    ///
    /// Lệch thiếu hay lệch vượt đều KHÔNG chặn: việc của hệ thống là báo đúng
    /// số thực, không phải bắt hàng về cho khớp chỉ thị. Chỉ chặn khi chưa nhận
    /// được con nào — hàng không về thì huỷ phiếu, không phải chốt nó.
    ///
    /// Mail hỏng không làm đổ việc chốt; khi đó <c>ActualMailSentAt</c> để trống.
    /// </summary>
    Task<ReturnInstructionResponse> CloseAsync(long docId);

    /// <summary>
    /// Office mở lại phiếu đã chốt để WH quét tiếp phần hàng về sau. Chốt lại
    /// sẽ gửi FA một mail mới với số đã cập nhật.
    /// </summary>
    Task<ReturnInstructionResponse> ReopenAsync(long docId);

    /// <summary>Các pallet hàng return đã nhận vào phiếu.</summary>
    Task<IReadOnlyList<ReturnPalletResponse>> GetPalletsAsync(long docId);

    /// <summary>
    /// Huỷ một lần nhận: xoá mềm pallet và GIẢI PHÓNG serial khỏi sổ.
    ///
    /// Cần có đường này vì serial bị giữ trên phạm vi toàn hệ thống — WH quét
    /// sai một pallet mà không tháo được thì những con hàng đó không bao giờ
    /// quét lại được vào pallet mới.
    /// </summary>
    /// <returns>Phiếu sau khi huỷ, đã trừ SL thực nhận.</returns>
    Task<ReturnInstructionResponse> ReleasePalletAsync(long docId, long palletId);

    /// <summary>Toàn bộ serial trong sổ của phiếu.</summary>
    Task<IReadOnlyList<ReturnSerialResponse>> GetSerialsAsync(long docId);
}
