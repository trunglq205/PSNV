﻿using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.OqcSamples.Business;

namespace Swms.FinishGoods.API.Features.OqcSamples.Api
{
    /// <summary>OQC lấy mẫu / trả mẫu / cập nhật trạng thái theo payload (part_cards).</summary>
    [ApiController]
    [Route("api/oqcsamples")]
    public class OqcSampleController : ControllerBase
    {
        private readonly IOqcSampleService _service;
        public OqcSampleController(IOqcSampleService service) => _service = service;

        /// <summary>
        /// Tra pallet + vị trí để trả mẫu về.
        /// - payload đã thuộc 1 pallet → trả pallet + vị trí hiện có.
        /// - chưa → tìm pallet cùng model + ngày SX.
        /// Dùng POST vì có body (GET không mang được body qua fetch/trình duyệt).
        /// </summary>
        [HttpPost("get-locations")]
        [RequirePermission<Perms.Receiving.OQC.Sample>]
        public async Task<ActionResult<OqcLocationResponse>> GetLocations(
            [FromBody] OqcGetLocationsRequest request)
            => Ok(await _service.GetLocationsAsync(request));

        /// <summary>Lấy mẫu (mượn) theo danh sách payload.</summary>
        [HttpPut("sample")]
        [RequirePermission<Perms.Receiving.OQC.Sample>]
        public async Task<ActionResult<OqcOkResponse>> Sample(
            [FromBody] OqcSampleActionRequest request)
            => Ok(await _service.SampleAsync(request));

        /// <summary>Trả mẫu theo danh sách payload.</summary>
        [HttpPut("return")]
        [RequirePermission<Perms.Receiving.OQC.Return>]
        public async Task<ActionResult<OqcOkResponse>> Return(
            [FromBody] OqcReturnRequest request)
            => Ok(await _service.ReturnAsync(request));

        /// <summary>Cập nhật trạng thái OQC (ok|ng...) theo danh sách payload.</summary>
        [HttpPut("update-status")]
        [RequirePermission<Perms.Receiving.OQC.Return>]
        public async Task<ActionResult<OqcOkResponse>> UpdateStatus(
            [FromBody] OqcUpdateStatusRequest request)
            => Ok(await _service.UpdateStatusAsync(request));
    }
}