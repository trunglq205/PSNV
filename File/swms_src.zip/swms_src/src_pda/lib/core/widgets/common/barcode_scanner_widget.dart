import 'package:barcode/barcode.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_svg/svg.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_shadows.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';

/// Ba trạng thái của nút quét thẻ.
enum ScannerState {
  /// Đang chờ quét — barcode + scan line đỏ chạy.
  scanning,

  /// Đã quét xong, đang gọi API / xử lý — spinner.
  loading,

  /// Thành công — tick xanh.
  success,
}

/// Nút quét thẻ nhân viên với máy trạng thái scanning / loading / success.
///
/// Dùng [AnimatedSwitcher] để chuyển mượt giữa 3 trạng thái, tái sử dụng
/// toàn bộ token (màu, bóng, padding, text style) trong core/resources.
class BarcodeScannerButton extends StatefulWidget {
  const BarcodeScannerButton({
    super.key,
    this.state = ScannerState.scanning,
    required this.scanningLabel,
    this.loadingLabel,
    this.successLabel,
    this.height = 72,
  });

  final ScannerState state;
  final String scanningLabel;
  final String? loadingLabel;
  final String? successLabel;
  final double height;

  @override
  State<BarcodeScannerButton> createState() => _BarcodeScannerButtonState();
}

class _BarcodeScannerButtonState extends State<BarcodeScannerButton>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scanAnim;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 800),
    );
    _scanAnim = CurvedAnimation(parent: _controller, curve: Curves.easeInOut);
    _syncAnimation();
  }

  @override
  void didUpdateWidget(covariant BarcodeScannerButton oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.state != widget.state) _syncAnimation();
  }

  /// Chỉ chạy scan line khi đang ở trạng thái scanning (tiết kiệm pin TC25).
  void _syncAnimation() {
    if (widget.state == ScannerState.scanning) {
      if (!_controller.isAnimating) _controller.repeat(reverse: true);
    } else {
      _controller.stop();
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedContainer(
      duration: const Duration(milliseconds: 250),
      curve: Curves.easeInOut,
      width: double.infinity,
      height: widget.height,
      decoration: _decorationFor(widget.state),
      child: ClipRRect(
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
        child: AnimatedSwitcher(
          duration: const Duration(milliseconds: 250),
          child: _buildContent(context),
        ),
      ),
    );
  }

  // ── Nền gradient + bóng theo trạng thái ──────────────────────────────────
  BoxDecoration _decorationFor(ScannerState state) {
    return BoxDecoration(
      gradient: LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: _gradientColors(state),
      ),
      borderRadius: BorderRadius.circular(AppDimens.rBtn),
      boxShadow: AppShadows.s2,
    );
  }

  List<Color> _gradientColors(ScannerState state) {
    switch (state) {
      case ScannerState.scanning:
        return const [Color(0xFF0A0A0A), Color(0xFF1A1A1A), Color(0xFF111111)];
      case ScannerState.loading:
        return const [
          AppColors.primaryDark,
          AppColors.primary,
          AppColors.primaryLight,
        ];
      case ScannerState.success:
        return const [
          Color(0xFF1B5E20),
          AppColors.success,
          Color(0xFF43A047),
        ];
    }
  }

  Widget _buildContent(BuildContext context) {
    switch (widget.state) {
      case ScannerState.scanning:
        return _ScanningContent(
          key: const ValueKey('scanning'),
          label: widget.scanningLabel,
          height: widget.height,
          scanAnim: _scanAnim,
        );
      case ScannerState.loading:
        return _LoadingContent(
          key: const ValueKey('loading'),
          label: widget.loadingLabel ?? LocaleKeys.common_card_processing.tr(),
        );
      case ScannerState.success:
        return _SuccessContent(
          key: const ValueKey('success'),
          label: widget.successLabel ?? LocaleKeys.common_card_success.tr(),
        );
    }
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SCANNING — barcode + scan line đỏ (logic gốc giữ nguyên)
// ─────────────────────────────────────────────────────────────────────────────
class _ScanningContent extends StatelessWidget {
  const _ScanningContent({
    super.key,
    required this.label,
    required this.height,
    required this.scanAnim,
  });

  final String label;
  final double height;
  final Animation<double> scanAnim;

  @override
  Widget build(BuildContext context) {
    return Stack(
      alignment: Alignment.center,
      children: [
        Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            SizedBox(
              height: height * 0.4,
              child: SvgPicture.string(
                Barcode.code128().toSvg(
                  'data',
                  width: 300,
                  drawText: false,
                  color: Colors.white.toARGB32(),
                ),
              ),
            ),
            const SizedBox(height: AppDimens.xs),
            Text(
              label,
              style: AppTextStyles.caption.copyWith(
                color: const Color(0xFFCCCCCC),
                letterSpacing: 1.5,
              ),
            ),
          ],
        ),
        RepaintBoundary(
          child: AnimatedBuilder(
            animation: scanAnim,
            builder: (context, _) => CustomPaint(
              size: Size.infinite,
              painter: _ScannerOverlayPainter(scanProgress: scanAnim.value),
            ),
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// LOADING — spinner trên nền gradient xanh dương
// ─────────────────────────────────────────────────────────────────────────────
class _LoadingContent extends StatelessWidget {
  const _LoadingContent({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const SizedBox(
          width: 18,
          height: 18,
          child: CircularProgressIndicator(
            strokeWidth: 2,
            valueColor: AlwaysStoppedAnimation(Colors.white),
          ),
        ),
        const SizedBox(width: AppDimens.sm + AppDimens.xs),
        Text(
          label,
          style: AppTextStyles.caption.copyWith(
            color: Colors.white,
            letterSpacing: 1.5,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// SUCCESS — tick + label chữ trắng trên nền gradient xanh lá
// ─────────────────────────────────────────────────────────────────────────────
class _SuccessContent extends StatelessWidget {
  const _SuccessContent({super.key, required this.label});

  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        const Icon(Icons.check_circle_rounded, color: Colors.white, size: 24),
        const SizedBox(width: AppDimens.sm),
        Text(
          label,
          style: AppTextStyles.bodyStrong.copyWith(
            color: Colors.white,
            letterSpacing: 1.2,
          ),
        ),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// CustomPainter: scan line đỏ + 4 góc xanh (giữ nguyên từ bản gốc)
// ─────────────────────────────────────────────────────────────────────────────
class _ScannerOverlayPainter extends CustomPainter {
  const _ScannerOverlayPainter({required this.scanProgress});

  final double scanProgress;

  static const _cornerLen = 8.0;
  static const _cornerStroke = 1.0;
  static const _cornerRadius = 3.0;
  static const _cornerColor = Color(0xFF00FF88);
  static const _cornerPadding = 8.0;

  @override
  void paint(Canvas canvas, Size size) {
    _drawCorners(canvas, size);
    _drawScanLine(canvas, size);
  }

  void _drawCorners(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = _cornerColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = _cornerStroke
      ..strokeCap = StrokeCap.round
      ..strokeJoin = StrokeJoin.round;

    const p = _cornerPadding;
    const l = _cornerLen;
    const r = _cornerRadius;

    final path = Path()
      ..moveTo(p, p + l)
      ..lineTo(p, p + r)
      ..quadraticBezierTo(p, p, p + r, p)
      ..lineTo(p + l, p)
      ..moveTo(size.width - p - l, p)
      ..lineTo(size.width - p - r, p)
      ..quadraticBezierTo(size.width - p, p, size.width - p, p + r)
      ..lineTo(size.width - p, p + l)
      ..moveTo(p, size.height - p - l)
      ..lineTo(p, size.height - p - r)
      ..quadraticBezierTo(p, size.height - p, p + r, size.height - p)
      ..lineTo(p + l, size.height - p)
      ..moveTo(size.width - p - l, size.height - p)
      ..lineTo(size.width - p - r, size.height - p)
      ..quadraticBezierTo(
        size.width - p,
        size.height - p,
        size.width - p,
        size.height - p - r,
      )
      ..lineTo(size.width - p, size.height - p - l);

    canvas.drawPath(path, paint);
  }

  void _drawScanLine(Canvas canvas, Size size) {
    const topPad = 10.0;
    const bottomPad = 28.0;
    final scanY = topPad + (size.height - topPad - bottomPad) * scanProgress;

    final layers = [
      (width: 6.0, opacity: 0.15, blur: 8.0),
      (width: 2.5, opacity: 0.45, blur: 4.0),
      (width: 1.2, opacity: 0.95, blur: 0.0),
    ];

    for (final layer in layers) {
      final paint = Paint()
        ..shader = LinearGradient(
          colors: [
            Colors.transparent,
            Color.fromRGBO(255, 50, 50, layer.opacity),
            Color.fromRGBO(255, 80, 80, layer.opacity),
            Color.fromRGBO(255, 50, 50, layer.opacity),
            Colors.transparent,
          ],
        ).createShader(Rect.fromLTWH(0, scanY, size.width, 1))
        ..strokeWidth = layer.width
        ..style = PaintingStyle.stroke;

      if (layer.blur > 0) {
        paint.maskFilter = MaskFilter.blur(BlurStyle.normal, layer.blur);
      }

      canvas.drawLine(Offset(12, scanY), Offset(size.width - 12, scanY), paint);
    }
  }

  @override
  bool shouldRepaint(_ScannerOverlayPainter oldDelegate) =>
      oldDelegate.scanProgress != scanProgress;
}