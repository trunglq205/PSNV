# Feature `OqcSamples` — OQC lấy mẫu / trả mẫu theo payload

Vertical slice độc lập. Định danh bằng **chuỗi payload** (không cần lot-id),
phục vụ OQC lấy mẫu **trước hoặc sau** khi tạo pallet. Thao tác trên
`wms.part_cards` (nguồn chính) và cập nhật `wms.boxes.oqc_status` **nếu payload
đã có trong boxes**.

```
Features/OqcSamples/
├── Api/
│   ├── OqcSampleController.cs      (api/oqcsamples: get-locations, sample, return, update-status)
│   └── OqcSampleModels.cs          (DTO + OqcErrors)
├── Business/
│   ├── IOqcSampleService.cs
│   ├── OqcSampleService.cs
│   └── Entities/
│       └── OqcSampleEntities.cs    (OqcStatusCode, PalletLocationResult)
├── DataAccess/
│   ├── IOqcSampleRepository.cs
│   └── OqcSampleRepository.cs
├── OqcSampleModule.cs              (AddOqcSampleFeature)
└── migrations/20260821_add_boxes_oqc_status.sql
```

## Endpoint

| Method | Route | Ý nghĩa |
|--------|-------|---------|
| GET | `/api/oqcsamples/get-locations` | Tra pallet + vị trí để trả mẫu |
| PUT | `/api/oqcsamples/sample` | Lấy mẫu → status = Sampling(2) |
| PUT | `/api/oqcsamples/return` | Trả mẫu (vật lý) → **không đổi trạng thái**, chỉ trả ok |
| PUT | `/api/oqcsamples/update-status` | Đặt status ok\|ng → Pass(5)\|Ng(4) |

### get-locations
- Có `payload` và payload đã thuộc 1 box/pallet → trả `pallet_id` + `locator` hiện có.
- Chưa → tìm pallet cùng `model` + `production_date`, ưu tiên pallet **đã có vị trí**,
  mới nhất trước. Không thấy → 404 `Lot.Oqc.PalletNotFound`.
- `production_date` nhận `dd/MM/yyyy` (spec) và ISO `yyyy-MM-dd`.

### sample / return / update-status
- `payloads[]` bắt buộc; lọc trùng/rỗng.
- `sample` / `update-status`: cập nhật `part_cards.Status_OQC` (lọc theo `model`),
  rồi `boxes.oqc_status` cho payload nào có trong boxes.
- `return`: không đổi trạng thái (kết quả do `update-status` quyết) — chỉ trả `{ "result": "ok" }`.

## Mã trạng thái (tinyint) — `OqcStatusCode`

| Mã | Ý nghĩa | Nguồn |
|----|---------|-------|
| 1 | chưa kiểm | (không set tự động) |
| 2 | đang lấy mẫu | sample |
| 4 | NG | update-status `ng` |
| 5 | Pass | update-status `ok` |

Bám theo `FossPalletMapper` (2/4/5). Sửa map chuỗi trong `OqcStatusCode.FromString` nếu khác.

## Ráp vào project
1. Chạy `migrations/20260821_add_boxes_oqc_status.sql` (thêm `wms.boxes.oqc_status`).
   `part_cards.Status_OQC` đã có sẵn.
2. DI: `builder.Services.AddOqcSampleFeature();`
3. Resx (4 file): thêm `Lot.Oqc.PayloadsRequired`, `Lot.Oqc.ProductionDateInvalid`,
   `Lot.Oqc.StatusInvalid`, `Lot.Oqc.PalletNotFound`.

## ⚠ Cần xác nhận
1. **update-status** `"ok"→Pass(5)`, `"ng"→Ng(4)`. Khác thì sửa `OqcStatusCode.FromString`.
2. **get-locations tie-break** nhiều pallet cùng model+ngày: đang ưu tiên có vị trí,
   mới nhất. Muốn FIFO → đổi `ORDER BY` trong `FindPalletByModelDateAsync`.
3. **GET có body**: `get-locations` nhận `[FromBody]`. Nếu hạ tầng chặn → đổi `[HttpPost]`.