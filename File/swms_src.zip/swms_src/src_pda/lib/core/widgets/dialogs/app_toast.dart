import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';

enum AppToastType { success, error, info, warning }

extension AppToastTypeX on AppToastType {
  Color get color => switch (this) {
    AppToastType.success => AppColors.success,
    AppToastType.error => AppColors.danger,
    AppToastType.warning => AppColors.warning,
    AppToastType.info => AppColors.primary,
  };

  IconData get icon => switch (this) {
    AppToastType.success => Icons.check_circle,
    AppToastType.error => Icons.error,
    AppToastType.warning => Icons.warning_amber_rounded,
    AppToastType.info => Icons.info,
  };
}