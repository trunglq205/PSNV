using System.Text.RegularExpressions;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.ShipmentTrips.Api;
using Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

/*  Chuyến xe lấy hàng — văn phòng nhập theo thông tin FWD gửi.

    Quan hệ SI ↔ chuyến:
      - 1 SI chỉ đi 1 chuyến CONTAINER (1 container ghép được nhiều SI)
      - 1 SI đi được nhiều chuyến XE TẢI
      - SI đã có container thì không gắn xe tải, và ngược lại
    Không còn nhập pallet cho từng SI trên chuyến (plt_planned để trống) — số pallet lấy theo SI.

    Trạng thái:  planned -> arrived -> sealed (chỉ container) -> departed
                 planned | arrived | sealed -> cancelled
    Chuyến đã xuất cổng / huỷ: khoá, không sửa được.                                  */
public class ShipmentTripService : IShipmentTripService
{
    public const string Container = "container";
    public const string Truck = "truck";
    public const string Motorbike = "motorbike";

    private const string Planned = "planned";
    private const string Arrived = "arrived";
    private const string Sealed = "sealed";
    private const string Departed = "departed";
    private const string Cancelled = "cancelled";

    private const int MaxList = 500;
    private const int MaxRangeDays = 93;

    // Chỉ gắn SI còn đang làm; SI đã gắn từ trước thì sửa chuyến vẫn được dù SI đã hoàn thành
    private static readonly HashSet<string> OpenSiStatuses = new() { "released", "picking" };

    private readonly IShipmentTripRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public ShipmentTripService(
        IShipmentTripRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Đọc
    // ═══════════════════════════════════════════════════════════════

    public async Task<List<TripResponse>> GetListAsync(TripQuery query)
    {
        DateTime? from = null, toExclusive = null;
        if (query.From is not null || query.To is not null)
        {
            var f = (query.From ?? query.To!.Value).Date;
            var t = (query.To ?? query.From!.Value).Date;
            if (t < f)
                throw new BusinessRuleException(_localizer["Trip.RangeInvalid"]);
            if ((t - f).TotalDays + 1 > MaxRangeDays)
                throw new BusinessRuleException(_localizer["Trip.RangeTooWide", MaxRangeDays]);
            from = f;
            toExclusive = t.AddDays(1);
        }

        var rows = await _repo.GetListAsync(
            from, toExclusive, Clean(query.Status)?.ToLowerInvariant(), Clean(query.Q), MaxList);
        return await BuildAsync(rows, maskDriverId: true);
    }

    public async Task<TripResponse> GetAsync(long id, bool fullDriverId)
    {
        var row = await _repo.GetAsync(id)
            ?? throw new NotFoundException(_localizer["Trip.NotFound", id]);
        return (await BuildAsync(new[] { row }, maskDriverId: !fullDriverId))[0];
    }

    public async Task<List<TripResponse>> GetBySiAsync(long siId)
    {
        var ids = await _repo.GetIdsBySiAsync(siId);
        return await BuildAsync(await _repo.GetByIdsAsync(ids), maskDriverId: true);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Ghi
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripResponse> CreateAsync(TripSaveRequest request)
    {
        var row = ToRow(request);
        var links = ToLinks(request.Sis)
            ?? throw new BusinessRuleException(_localizer["Trip.SisRequired"]);

        await ValidateSisAsync(row.VehicleType, links, tripId: null, alreadyLinked: new HashSet<long>());
        await EnsureContainerFreeAsync(row.ContainerNo, tripId: null);

        row.CreatedAt = DateTime.Now;
        row.CreatedBy = _currentUser.FullName;
        var id = await _repo.AddAsync(row, links);
        return await GetAsync(id, fullDriverId: true);
    }

    public async Task<TripResponse> UpdateAsync(long id, TripSaveRequest request)
    {
        var cur = await _repo.GetAsync(id)
            ?? throw new NotFoundException(_localizer["Trip.NotFound", id]);
        EnsureOpen(cur);

        var row = ToRow(request);
        row.Id = id;

        // Đã đóng chì: vẫn là xe container và vẫn phải có số cont + chì
        if (cur.Status == Sealed)
        {
            if (row.VehicleType != Container)
                throw new BusinessRuleException(_localizer["Trip.SealedTypeLocked"]);
            if (row.ContainerNo is null || row.SealNo is null)
                throw new BusinessRuleException(_localizer["Trip.SealDataRequired"]);
        }

        var current = (await _repo.GetSisByTripIdsAsync(new[] { id }))
            .Select(s => new TripSiLink(s.SiId, s.PltPlanned))
            .ToList();
        IReadOnlyList<TripSiLink> links = request.Sis is null
            ? current
            : ToLinks(request.Sis) ?? throw new BusinessRuleException(_localizer["Trip.SisRequired"]);

        // Kiểm lại cả khi chỉ đổi loại xe (container <-> xe tải) — quy tắc SI phụ thuộc loại xe
        await ValidateSisAsync(row.VehicleType, links, tripId: id,
            alreadyLinked: current.Select(s => s.SiId).ToHashSet());
        await EnsureContainerFreeAsync(row.ContainerNo, tripId: id);

        row.UpdatedAt = DateTime.Now;
        row.UpdatedBy = _currentUser.FullName;
        if (!await _repo.UpdateAsync(row, request.Sis is null ? null : links))
            throw new BusinessRuleException(_localizer["Trip.StatusChanged"]);

        return await GetAsync(id, fullDriverId: true);
    }

    public async Task<TripResponse> ChangeStatusAsync(long id, TripStatusRequest request)
    {
        var cur = await _repo.GetAsync(id)
            ?? throw new NotFoundException(_localizer["Trip.NotFound", id]);
        var isContainer = cur.VehicleType == Container;
        var action = Clean(request.Action)?.ToLowerInvariant() ?? "";

        var (from, to) = action switch
        {
            "arrive" => (new[] { Planned }, Arrived),
            "seal" => isContainer
                ? (new[] { Arrived }, Sealed)
                : throw new BusinessRuleException(_localizer["Trip.SealTruck"]),
            "depart" => (isContainer ? new[] { Sealed } : new[] { Arrived }, Departed),
            "cancel" => (new[] { Planned, Arrived, Sealed }, Cancelled),
            _ => throw new BusinessRuleException(_localizer["Trip.ActionInvalid", action]),
        };

        if (!from.Contains(cur.Status))
            throw new BusinessRuleException(_localizer["Trip.StatusInvalid", action, cur.Status]);
        if (to == Arrived && cur.PlateNo is null)
            throw new BusinessRuleException(_localizer["Trip.PlateRequired"]);
        if (to == Sealed && (cur.ContainerNo is null || cur.SealNo is null))
            throw new BusinessRuleException(_localizer["Trip.SealDataRequired"]);

        var reason = Clean(request.Reason);
        if (to == Cancelled && reason is null)
            throw new BusinessRuleException(_localizer["Trip.CancelReasonRequired"]);

        if (!await _repo.TransitionAsync(id, from, to, reason, _currentUser.FullName))
            throw new BusinessRuleException(_localizer["Trip.StatusChanged"]);

        return await GetAsync(id, fullDriverId: true);
    }

    public async Task DeleteAsync(long id)
    {
        var cur = await _repo.GetAsync(id)
            ?? throw new NotFoundException(_localizer["Trip.NotFound", id]);
        if (cur.Status != Planned)
            throw new BusinessRuleException(_localizer["Trip.DeleteNotPlanned"]);

        if (!await _repo.SoftDeleteAsync(id, _currentUser.FullName))
            throw new BusinessRuleException(_localizer["Trip.StatusChanged"]);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Kiểm tra
    // ═══════════════════════════════════════════════════════════════

    private void EnsureOpen(TripRow t)
    {
        if (t.Status is Departed or Cancelled)
            throw new BusinessRuleException(_localizer["Trip.Closed", t.Status]);
    }

    private async Task EnsureContainerFreeAsync(string? containerNo, long? tripId)
    {
        if (containerNo is not null && await _repo.ContainerInUseAsync(containerNo, tripId))
            throw new ConflictException(_localizer["Trip.ContainerInUse", containerNo]);
    }

    /// <summary>alreadyLinked: SI đang có sẵn trên chuyến — không kiểm trạng thái SI (SI có thể đã hoàn thành).</summary>
    private async Task ValidateSisAsync(
        string vehicleType, IReadOnlyList<TripSiLink> links, long? tripId, HashSet<long> alreadyLinked)
    {
        var ids = links.Select(l => l.SiId).ToList();
        var infos = (await _repo.GetSiInfosAsync(ids)).ToDictionary(x => x.SiId);

        foreach (var l in links)
        {
            if (!infos.TryGetValue(l.SiId, out var si))
                throw new NotFoundException(_localizer["Trip.SiNotFound", l.SiId]);
            if (!alreadyLinked.Contains(l.SiId) && !OpenSiStatuses.Contains(si.DocStatus))
                throw new BusinessRuleException(_localizer["Trip.SiClosed", si.SiNo, si.DocStatus]);
        }

        // Container: SI không được nằm trên chuyến nào khác. Xe tải: SI không được có container.
        foreach (var o in await _repo.GetActiveTripsOfSisAsync(ids, tripId))
        {
            var siNo = infos[o.SiId].SiNo;
            if (o.VehicleType == Container)
                throw new ConflictException(_localizer["Trip.SiHasContainer", siNo]);
            if (vehicleType == Container)
                throw new ConflictException(_localizer["Trip.SiHasTruck", siNo]);
        }
    }

    // ═══════════════════════════════════════════════════════════════
    //  Map
    // ═══════════════════════════════════════════════════════════════

    private TripRow ToRow(TripSaveRequest r)
    {
        var type = Clean(r.VehicleType)?.ToLowerInvariant();
        if (type is not (Container or Truck or Motorbike))
            throw new BusinessRuleException(_localizer["Trip.VehicleTypeInvalid"]);

        // Tài xế: nhập được cả số CCCD lẫn số GPLX (2 cột riêng)
        var idNo = Clean(r.DriverIdNo);
        var licenseNo = Clean(r.DriverLicenseNo);

        // Xe tải: không có container / chì (CK_trips_truck_no_container)
        var isContainer = type == Container;
        return new TripRow
        {
            VehicleType = type,
            PlateNo = Upper(r.PlateNo),
            ContainerNo = isContainer ? ContainerNo.Normalize(r.ContainerNo) : null,
            ContainerSize = isContainer ? Upper(r.ContainerSize) : null,
            SealNo = isContainer ? Upper(r.SealNo) : null,
            DriverName = Clean(r.DriverName),
            DriverPhone = Clean(r.DriverPhone),
            DriverIdType = idNo is null ? null : "cccd",       // cột cũ: chỉ còn mang nghĩa "có CCCD"
            DriverIdNo = idNo,
            DriverLicenseNo = licenseNo,
            ForwarderCode = Clean(r.ForwarderCode),
            PlannedArrivalAt = r.PlannedArrivalAt,
            Note = Clean(r.Note),
        };
    }

    /// <summary>null / rỗng -> null. SI trùng trong cùng request -> lỗi.</summary>
    private List<TripSiLink>? ToLinks(List<TripSiRequest>? sis)
    {
        if (sis is null || sis.Count == 0) return null;

        var dup = sis.GroupBy(s => s.SiId).FirstOrDefault(g => g.Count() > 1);
        if (dup is not null)
            throw new BusinessRuleException(_localizer["Trip.SiDuplicate", dup.Key]);

        return sis.Select(s => new TripSiLink(s.SiId, s.PltPlanned)).ToList();
    }

    private async Task<List<TripResponse>> BuildAsync(IReadOnlyList<TripRow> rows, bool maskDriverId)
    {
        if (rows.Count == 0) return new();

        var sis = (await _repo.GetSisByTripIdsAsync(rows.Select(r => r.Id).ToList()))
            .ToLookup(s => s.TripId);

        return rows.Select(r =>
        {
            var list = sis[r.Id].ToList();
            return TripResponse.From(r, list.Select(TripSiResponse.From).ToList(), Warnings(r, list), maskDriverId);
        }).ToList();
    }

    /// <summary>Cảnh báo không chặn — hiện ngay trên thẻ chuyến.</summary>
    private List<string> Warnings(TripRow t, List<TripSiRow> sis)
    {
        var w = new List<string>();
        if (t.ContainerNo is { } c && !ContainerNo.IsValid(c))
            w.Add(_localizer["Trip.WarnContainerCheck", c]);

        return w;
    }

    private static string? Clean(string? v) => string.IsNullOrWhiteSpace(v) ? null : v.Trim();
    private static string? Upper(string? v) => Clean(v)?.ToUpperInvariant();
}

/// <summary>Số container ISO 6346: 4 chữ (mã chủ + loại) + 6 số + 1 số kiểm tra. VD MSKU1234565.</summary>
internal static class ContainerNo
{
    private static readonly Regex Format = new(@"^[A-Z]{4}\d{7}$", RegexOptions.Compiled);

    /// <summary>Viết hoa, bỏ khoảng trắng / gạch / chấm: "mscu 123456-5" -> "MSCU1234565".</summary>
    public static string? Normalize(string? v)
    {
        if (string.IsNullOrWhiteSpace(v)) return null;
        var t = new string(v.Where(ch => !char.IsWhiteSpace(ch) && ch is not ('-' or '.' or '/')).ToArray())
            .ToUpperInvariant();
        return t.Length == 0 ? null : t;
    }

    /// <summary>Đúng định dạng và đúng số kiểm tra. Sai chỉ cảnh báo (số in trên thùng đôi khi lệch).</summary>
    public static bool IsValid(string no)
    {
        if (!Format.IsMatch(no)) return false;
        var sum = 0;
        for (var i = 0; i < 10; i++)
        {
            var ch = no[i];
            var v = char.IsDigit(ch) ? ch - '0' : LetterValue(ch);
            sum += v << i;
        }
        return sum % 11 % 10 == no[10] - '0';
    }

    // A=10, B=12 … bỏ các bội số của 11 (11, 22, 33)
    private static int LetterValue(char c)
    {
        var v = 10;
        for (var ch = 'A'; ch < c; ch++)
        {
            v++;
            if (v % 11 == 0) v++;
        }
        return v;
    }
}