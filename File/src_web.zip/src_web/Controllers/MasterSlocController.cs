﻿using System.Data;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class MasterSlocController : BaseController
    {
        private readonly ApiService _apiService;

        public MasterSlocController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] MasterSlocFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var response = await _apiService.GetAllMasterSloc(filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var item = response.Records ?? new List<MasterSloc>();

                var model = new MasterSlocViewModel()
                {
                    Items = item,
                    Filter = new MasterSlocFilter(),
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };

                return View("Views/MasterSloc/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportMasterSloc(IFormFile file)
        {
            try
            {
                if (file == null && file?.Length == 0)
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }

                var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads");
                if (!Directory.Exists(uploadDirectory))
                {
                    Directory.CreateDirectory(uploadDirectory);
                }

                var fileextension = Path.GetExtension(file.FileName);
                var filename = Guid.NewGuid().ToString() + fileextension;
                var filepath = Path.Combine(uploadDirectory, filename);
                using (FileStream fs = System.IO.File.Create(filepath))
                {
                    await file.CopyToAsync(fs);
                }
                DataTable? dt = new DataTable();

                if (!Function.CheckHeaderExcel(filepath, "sheet1", Constants.MasterSlocCheck))
                {
                    ViewBag.Error = _loc.Get("Msg_TheFileSFormatIsIncorectPleaseCheckAgain");
                }

                dt = Function.GetDataTableFromExcel(filepath, "sheet1", Constants.MasterSlocCheck);

                if (dt == null && dt?.Columns.Count != Constants.MasterSlocCheck.Count)
                {
                    ViewBag.Error = _loc.Get("Msg_ErrorOccurred");
                }

                List<ImportMasterSlocViewModel>? entities = Function.DataTatbleToMasterSloc(dt);
                if (entities != null && entities.Count > 0)
                {
                    return PartialView("~/Views/MasterSloc/_ImportMasterSlocModel.cshtml", entities);
                }

                return View();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportMasterSloc([FromBody] List<ImportMasterSlocViewModel> requests)
        {
            try
            {
                await _apiService.ImportMasterSloc(requests);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
