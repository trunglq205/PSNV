import 'package:swms_finish_goods/features/stocky/data/datasources/stocky_remote_data_source.dart';
import 'package:swms_finish_goods/features/stocky/data/models/stocky_cart_model.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';
import 'package:swms_finish_goods/features/stocky/domain/repositories/stocky_repository.dart';

class StockyRepositoryImpl implements StockyRepository {
  final StockyRemoteDataSource _remote;
  const StockyRepositoryImpl(this._remote);

  @override
  Future<StockyCart> lookup({
    required String code,
    required StockyMode mode,
  }) async {
    // KHÔNG bắt DioException để đổi thành lỗi của riêng feature.
    // ErrorInterceptor đã lấy câu thông báo của server (`title`/`details`) và
    // bọc thành ServerException, mà ErrorHandler hiện nguyên câu đó. Câu của
    // server nói rõ "Xe STK-0218 đã ở trong kho, không nhận lại được" — bọc
    // lại ở đây chỉ còn câu chung "không thể thao tác ở tab này", mất thông tin.
    final model = await _remote.lookup(code, mode.code);
    return model.toEntity();
  }

  @override
  Future<StockySubmitResult> submit({
    required StockyMode mode,
    required List<String> codes,
  }) async {
    final body = StockyBatchRequest(codes: codes);

    // Chiều nằm ở ĐƯỜNG DẪN chứ không ở thân request: mỗi chiều một quyền
    // riêng bên server (stocky.create / stocky.transfer).
    final r = switch (mode) {
      StockyMode.receive => await _remote.receive(body),
      // Xuất FA và trả vendor là HAI endpoint khác nhau. Trước đây cả hai nhập
      // làm một: nút "Xuất sang FA" gọi /return nên xe bị ghi nhận đã trả
      // vendor và rơi khỏi danh sách theo dõi.
      StockyMode.exportFa => await _remote.exportFa(body),
      StockyMode.returnVendor => await _remote.returnCarts(body),
    };
    return r.toEntity();
  }

  @override
  Future<List<StockyCart>> fetchList({bool? hasGoods, String? keyword}) async {
    final rows = await _remote.list(
      // Lọc theo "còn được quản lý", KHÔNG phải theo vị trí: xe đẩy sang FA
      // vẫn mang status in_warehouse nên vẫn nằm trong danh sách này — đúng
      // yêu cầu "mọi xe trong hệ thống đều phải theo dõi được". Chỉ xe đã trả
      // về vendor (`returned`) mới rời danh sách.
      status: StockyStatus.inWarehouse,
      hasGoods: hasGoods,
      keyword: (keyword == null || keyword.trim().isEmpty) ? null : keyword.trim(),
    );
    return rows.map((e) => e.toEntity()).toList();
  }
}
