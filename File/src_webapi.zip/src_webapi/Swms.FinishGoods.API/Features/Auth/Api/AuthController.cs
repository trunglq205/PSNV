using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Business;

namespace Swms.FinishGoods.API.Features.Auth;

[ApiController]
[Route("api/auth")]
public class AuthController : ControllerBase
{
    private readonly IAuthService _service;
    private readonly IRoleService _roleService;

    public AuthController(IAuthService service, IRoleService roleService)
    {
        _service = service;
        _roleService = roleService;
    }

    [HttpPost("login")]
    [AllowAnonymous]
    public async Task<ActionResult<LoginResponse>> Login(LoginRequest request)
    {
        var result = await _service.LoginAsync(request);
        return Ok(result);
    }

    [HttpGet("me")]
    [Authorize]
    public async Task<ActionResult<List<string>>> GetMyPermissions()
        => Ok(new
        {
            Username = User.Identity?.Name,
            Role = await _roleService.GetMyPermissionsAsync()
        });
}
