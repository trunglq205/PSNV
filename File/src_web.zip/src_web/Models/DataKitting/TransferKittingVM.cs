﻿using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.Models.DataKitting
{
    public class TransferKittingVM
    {
        public SearchKittingListDetails filter { get; set; }
        public string UserCurrent { get; set; }
        public string UserId { get; set; }
        public IEnumerable<SelectListItem> NewPicUser { get; set; }
        public IEnumerable<KittingListTransfer>? kittingListDetails { get; set; }
    }

    public class KittingListTransfer
    {
        public List<Int64> ID { get; set; }
        public string LstID { get; set; }
        public string Material { get; set; }
        public double Quantity { get; set; }
        public string PicUser { get; set; }
        public string LocationName { get; set; }
        public string Category { get; set; }
        public string Unit { get; set; }
        public string Model { get; set; }
        public byte KittingStatus { get; set; }
        public Int64 GroupID { get; set; }
    }
}
