using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>Một dòng FA xin: model + SL.</summary>
public record BackRequestLineRequest(
    [Required, StringLength(100)] string Model,
    [Range(1, 1_000_000)] int Qty,
    [StringLength(500)] string? Note);

/// <summary>B1 — FA tạo yêu cầu back từ một chỉ thị nhận hàng.</summary>
public record CreateBackRequestRequest(
    [Required] long DocId,
    [StringLength(500)] string? Note,
    [Required, MinLength(1)] List<BackRequestLineRequest> Lines);

/// <summary>Sửa yêu cầu khi còn mở (FA sửa, hoặc SCS WH sửa ở bước B3).</summary>
public record UpdateBackRequestRequest(
    [StringLength(500)] string? Note,
    [Required, MinLength(1)] List<BackRequestLineRequest> Lines);

/// <summary>Duyệt / huỷ — dùng chung cho cả hai cấp.</summary>
public record BackRequestDecisionRequest([StringLength(500)] string? Comment);

public record BackRequestLineResponse(
    long Id,
    int LineNo,
    string Model,
    int Qty,
    int AssignedQty,
    int ReturnedQty,
    int AvailableQty,
    bool Short,
    string? Note)
{
    public static BackRequestLineResponse From(ReturnBackRequestLine l) => new(
        l.Id, l.LineNo, l.Model, l.Qty, l.AssignedQty, l.ReturnedQty,
        l.AvailableQty, l.Short, l.Note);
}

public record BackRequestResponse(
    long Id,
    long DocId,
    string? DocNo,
    string? GoodsType,
    string ReqNo,
    string ReqStatus,
    string CurrentStep,
    string? Note,
    int ModelCount,
    int TotalQty,
    int AssignedQty,
    int ReturnedQty,
    int AtFaQty,
    bool IsOpen,
    bool IsApproved,
    bool IsCancelled,
    string? RequestedBy,
    DateTime RequestedAt,
    string? FaApprovedBy,
    DateTime? FaApprovedAt,
    string? FaComment,
    string? ScsInstructedBy,
    DateTime? ScsInstructedAt,
    string? ScsApprovedBy,
    DateTime? ScsApprovedAt,
    string? ScsComment,
    string? CancelledBy,
    DateTime? CancelledAt,
    string? CancelReason,
    List<BackRequestLineResponse> Lines)
{
    public static BackRequestResponse From(ReturnBackRequest r) => new(
        r.Id, r.DocId, r.DocNo, r.GoodsType, r.ReqNo, r.ReqStatus, r.CurrentStep,
        r.Note, r.ModelCount, r.TotalQty, r.AssignedQty, r.ReturnedQty, r.AtFaQty,
        r.IsOpen, r.IsApproved, r.IsCancelled,
        r.RequestedBy, r.RequestedAt,
        r.FaApprovedBy, r.FaApprovedAt, r.FaComment,
        r.ScsInstructedBy, r.ScsInstructedAt,
        r.ScsApprovedBy, r.ScsApprovedAt, r.ScsComment,
        r.CancelledBy, r.CancelledAt, r.CancelReason,
        r.Lines.Select(BackRequestLineResponse.From).ToList());
}

/// <summary>Bộ lọc danh sách yêu cầu back.</summary>
public record BackRequestQuery(
    long? DocId,
    string? Status,
    string? Step,
    string? Keyword);

/// <summary>
/// SL kho còn gắp được theo model, cho màn soạn yêu cầu: FA thấy ngay xin được
/// tối đa bao nhiêu thay vì xin bừa rồi bị B4 báo thiếu.
/// </summary>
public record BackAvailableModelResponse(string Model, int AvailableQty);

/// <summary>
/// Khoá resource cho thông báo lỗi của mục 2c. Giữ ở một chỗ để resx và code
/// không lệch nhau — cùng cách <c>ReturnMsg</c> làm.
/// </summary>
public static class BackMsg
{
    public const string NotFound = "Return.Back.Err.NotFound";
    public const string DocNotFound = "Return.Back.Err.DocNotFound";
    public const string DocCancelled = "Return.Back.Err.DocCancelled";
    public const string LinesRequired = "Return.Back.Err.LinesRequired";
    public const string ModelDuplicated = "Return.Back.Err.ModelDuplicated";
    public const string ModelNotInDoc = "Return.Back.Err.ModelNotInDoc";
    public const string QtyOverAvailable = "Return.Back.Err.QtyOverAvailable";
    public const string NotEditable = "Return.Back.Err.NotEditable";
    public const string WrongStep = "Return.Back.Err.WrongStep";
    public const string AlreadyCancelled = "Return.Back.Err.AlreadyCancelled";
    public const string AlreadyApproved = "Return.Back.Err.AlreadyApproved";
    public const string TooManyLines = "Return.Back.Err.TooManyLines";
    public const string ValueTooLong = "Return.Back.Err.ValueTooLong";
}
