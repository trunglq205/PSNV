import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';
import 'package:swms_finish_goods/features/abnormal_report/presentation/pages/ng_list_page.dart'
    show ngStatusPill;
import 'package:swms_finish_goods/features/abnormal_report/presentation/providers/ng_providers.dart';

/// Chi tiết phiếu — CHỈ ĐỌC.
///
/// PDA không duyệt phiếu: công nhân SCS gửi báo cáo rồi theo dõi tiến trình ở
/// đây. Mọi thao tác duyệt (Leader, OQC, FA, chốt) làm trên Web.
@RoutePage()
class NgDetailPage extends ConsumerStatefulWidget {
  final int id;
  const NgDetailPage({super.key, @PathParam('id') required this.id});

  @override
  ConsumerState<NgDetailPage> createState() => _NgDetailPageState();
}

class _NgDetailPageState extends ConsumerState<NgDetailPage> {
  @override
  Widget build(BuildContext context) {
    final async = ref.watch(ngDetailProvider(widget.id));

    return Scaffold(
      appBar: AppBar(title: Text(LocaleKeys.ng_title.tr())),
      body: async.when(
        loading: () => const AppLoading(),
        error: (e, _) => AppErrorView.page(
          message: '$e',
          onRetry: () => ref.invalidate(ngDetailProvider(widget.id)),
        ),
        data: (d) => ListView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
          children: [
            _header(d),
            if (d.description != null && d.description!.isNotEmpty) ...[
              const SizedBox(height: 10),
              _descBox(d.description!),
            ],
            _section('${LocaleKeys.ng_items.tr()} (${d.items.length})'),
            ...d.items.map(_itemRow),
            if (d.header.photoCount > 0) ...[
              _section('${LocaleKeys.ng_photos.tr()} (${d.header.photoCount})'),
              _photoHint(d.header.photoCount),
            ],
            _section(LocaleKeys.ng_timeline.tr()),
            AppTimeline(items: _timeline(d), emphasizeFirst: false),
          ],
        ),
      ),
    );
  }

  Widget _header(NgDetail d) {
    final swms = context.swms;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  d.header.docNo,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    color: swms.text1,
                  ),
                ),
              ),
              ngStatusPill(context, d.header.docStatus),
            ],
          ),
          const SizedBox(height: 6),
          // Lỗi cả pallet thì số lượng vô nghĩa (mỗi mục lưu 1), hiện "1 cái"
          // làm người đọc tưởng chỉ 1 sản phẩm bị lỗi. Tách ra biến chứ không
          // viết lồng trong chuỗi nội suy — lồng 3 tầng rất dễ vỡ khi sửa.
          Builder(builder: (_) {
            final qty = d.header.isWholePallet
                ? LocaleKeys.ng_whole_pallet.tr()
                : '${d.header.qtyAffected} ${LocaleKeys.ng_qty_word.tr()}';
            return Text(
              '${ngTypeName(ngTypesOf(ref.watch(ngTypesProvider)), d.header.ngType)} · '
              '${d.header.itemCount} ${LocaleKeys.ng_item_word.tr()} · '
              '$qty',
              style: TextStyle(fontSize: 12.5, color: swms.text2),
            );
          }),
          const SizedBox(height: 4),
          Text(
            '${d.header.palletCode ?? ''} · ${d.header.model ?? ''}',
            style: TextStyle(fontSize: 12, color: swms.text3),
          ),
        ],
      ),
    );
  }

  Widget _descBox(String text) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text, style: TextStyle(fontSize: 13, color: swms.text2)),
    );
  }

  /// Ảnh xem trên Web; PDA chỉ cho biết có bao nhiêu ảnh để người duyệt biết
  /// đã có bằng chứng kèm theo.
  Widget _photoHint(int count) {
    final swms = context.swms;
    return Row(
      children: [
        Icon(Icons.photo_library_outlined, size: 16, color: swms.text3),
        const SizedBox(width: 6),
        Text(
          LocaleKeys.ng_photo_count.tr(args: ['$count']),
          style: TextStyle(fontSize: 12.5, color: swms.text3),
        ),
      ],
    );
  }

  Widget _section(String text) {
    final swms = context.swms;
    return Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 6),
      child: Text(
        text.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: .4,
          color: swms.text3,
        ),
      ),
    );
  }

  Widget _itemRow(NgItem it) {
    final swms = context.swms;
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Text(
            'ng.scope.${it.scope}'.tr(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: swms.text3,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  it.code ?? '—',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: swms.text1,
                  ),
                ),
                if (it.note != null && it.note!.isNotEmpty)
                  Text(
                    it.note!,
                    style: TextStyle(fontSize: 11.5, color: swms.text3),
                  ),
              ],
            ),
          ),
          Text(
            it.scope == 'pallet'
                ? LocaleKeys.ng_whole_pallet.tr()
                : '${it.qtyAffected}',
            style: TextStyle(
              fontWeight: it.scope == 'pallet' ? FontWeight.w600 : FontWeight.w800,
              fontSize: it.scope == 'pallet' ? 11.5 : null,
              color: swms.text1,
            ),
          ),
        ],
      ),
    );
  }

  /// 5 mốc theo thứ tự quy trình: SCS tạo -> Leader -> OQC -> FA ->
  /// SCS supervisor chốt. Mốc chưa tới để màu trung tính + mờ.
  List<AppTimelineItem> _timeline(NgDetail d) {
    final h = d.header;
    String meta(String? by, DateTime? at) => by == null
        ? LocaleKeys.ng_not_yet.tr()
        : '$by · ${DateFormat('dd/MM/yyyy HH:mm').format(at!)}';

    return [
      AppTimelineItem(
        title: LocaleKeys.ng_step_created.tr(),
        meta: meta(h.createdBy, h.discoveredAt),
        tone: AppTimelineTone.success,
      ),
      AppTimelineItem(
        title: LocaleKeys.ng_step_leader.tr(),
        meta: meta(d.leaderBy, d.leaderAt),
        description: d.leaderComment,
        tone: switch (h.leaderStatus) {
          'submitted' => AppTimelineTone.success,
          'cancelled' => AppTimelineTone.danger,
          _ => AppTimelineTone.neutral,
        },
        muted: h.leaderStatus == 'pending',
      ),
      AppTimelineItem(
        title: LocaleKeys.ng_step_oqc.tr(),
        // 'skipped' = model không phải qua OQC, server chốt lúc leader duyệt.
        // Để nguyên toUpperCase() thì hiện chữ thô "SKIPPED"; và meta rỗng để
        // không in "Chưa thực hiện" — bước này không ai phải làm, in dòng đó
        // người dùng tưởng phiếu đang treo chờ OQC.
        code: switch (h.oqcStatus) {
          'pending' => null,
          'skipped' => LocaleKeys.ng_oqc_skipped.tr(),
          _ => h.oqcStatus.toUpperCase(),
        },
        meta: h.oqcStatus == 'skipped' ? '' : meta(d.oqcBy, d.oqcAt),
        description: d.oqcComment,
        tone: switch (h.oqcStatus) {
          'ok' => AppTimelineTone.success,
          'ng' => AppTimelineTone.danger,
          _ => AppTimelineTone.neutral,
        },
        muted: h.oqcStatus == 'pending' || h.oqcStatus == 'skipped',
      ),
      AppTimelineItem(
        title: LocaleKeys.ng_step_fa.tr(),
        code: h.faResolution == null ? null : 'ng.res.${h.faResolution}'.tr(),
        meta: meta(d.faBy, d.faAt),
        description: d.faComment,
        tone: h.faStatus == 'approved'
            ? AppTimelineTone.success
            : AppTimelineTone.neutral,
        muted: h.faStatus != 'approved',
      ),
      AppTimelineItem(
        title: LocaleKeys.ng_step_finalize.tr(),
        code: h.resolution == 'pending' ? null : 'ng.res.${h.resolution}'.tr(),
        meta: h.docStatus == 'cancelled'
            ? meta(d.cancelledBy, d.cancelledAt)
            : meta(d.finalizedBy, d.finalizedAt),
        description: d.finalComment ?? d.cancelReason,
        tone: switch (h.docStatus) {
          'finalized' => AppTimelineTone.success,
          'cancelled' => AppTimelineTone.danger,
          _ => AppTimelineTone.neutral,
        },
        muted: !h.isClosed,
      ),
    ];
  }

}
