﻿namespace SWMS_WebTool.Models.DataKitting
{
    public class DataKittingPL : AuditableEntity
    {
        public string Type { get; set; }
        public KittingTab Tab { get; set; }
        public DateTime? ProDate { get; set; }
        public string KittingTimeType { get; set; }
        public string KittingFrom { get; set; }
        public string Barcode { get; set; }
        public string Plant { get; set; }
        public string Category { get; set; }
        public double Quantity { get; set; }
        public string SpecialPart { get; set; }
        public string Model { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Descriptions { get; set; }
        public string FinishGoods { get; set; }
        public string Issue_Sloc { get; set; }
        public string Material { get; set; }
        public string PositionFA { get; set; }
        public string Unit { get; set; }
        public DateTime? DeliveryDate { get; set; }
        public int ModelQuantity { get; set; }
        public Int64 GroupID { get; set; }
        public List<DataKittingPL>? KittingPlans { get; set; }
    }
}
