using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.WarehouseAreas.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.WarehouseAreas.Api;

[ApiController]
[Route("api/warehouse-areas")]
public class WarehouseAreasController : ControllerBase
{
    private readonly IWarehouseAreasService _service;
    public WarehouseAreasController(IWarehouseAreasService service) => _service = service;

    /// <summary>List bản đồ. Filter theo type (storing|receiving|vanning) tuỳ chọn.</summary>
    [HttpGet]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<IReadOnlyList<WarehouseAreaSummary>>> List(
        [FromQuery] string? type,
        [FromQuery] bool includeInactive = false)
        => Ok(await _service.ListAsync(type, includeInactive));

    /// <summary>Chi tiết 1 bản đồ.</summary>
    [HttpGet("{id:long}")]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<WarehouseAreaSummary>> Get(long id)
    {
        var x = await _service.GetAsync(id);
        return x is null ? NotFound() : Ok(x);
    }

    /// <summary>Tạo bản đồ mới. map_type cố định, không đổi được.</summary>
    [HttpPost]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<ActionResult<long>> Create([FromBody] CreateWarehouseAreaRequest req)
        => Ok(await _service.CreateAsync(req, User.Identity?.Name));

    /// <summary>Sửa bản đồ (tên, kích thước). Không đổi được area_code và map_type.</summary>
    [HttpPatch("{id:long}")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> Update(long id, [FromBody] UpdateWarehouseAreaRequest req)
    {
        await _service.UpdateAsync(id, req, User.Identity?.Name);
        return NoContent();
    }

    /// <summary>Bật/tắt hiển thị bản đồ (ẩn khỏi dropdown mà không xoá).</summary>
    [HttpPatch("{id:long}/active")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> SetActive(long id, [FromQuery] bool value)
    {
        await _service.SetActiveAsync(id, value, User.Identity?.Name);
        return NoContent();
    }

    /// <summary>Xoá mềm bản đồ.</summary>
    [HttpDelete("{id:long}")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> Delete(long id)
    {
        await _service.SoftDeleteAsync(id, User.Identity?.Name);
        return NoContent();
    }
}
