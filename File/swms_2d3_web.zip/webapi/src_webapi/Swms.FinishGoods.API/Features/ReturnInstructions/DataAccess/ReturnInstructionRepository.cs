using Dapper;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

public class ReturnInstructionRepository : IReturnInstructionRepository
{
    /// <summary>
    /// Số id phiếu mỗi câu khi nạp dòng / đếm SL thực nhận. Dapper trải
    /// <c>IN</c> thành từng parameter và SQL Server chỉ cho 2100 parameter một
    /// câu, nên danh sách phiếu dài phải chia lô.
    /// </summary>
    private const int DocIdChunk = 1000;

    private readonly IDbConnectionFactory _factory;
    public ReturnInstructionRepository(IDbConnectionFactory factory) => _factory = factory;

    /// <summary>
    /// Header + số dòng + tổng SL. Hai con số tổng tính bằng OUTER APPLY sang
    /// bảng dòng chứ KHÔNG lưu sẵn trên header: lưu sẵn là phải nhớ cập nhật ở
    /// mọi đường sửa dòng, và chỉ cần quên một đường là tổng sai vĩnh viễn.
    /// </summary>
    private const string HeaderSql = """
        SELECT  d.id            AS [Id],
                d.doc_no        AS [DocNo],
                d.goods_type    AS [GoodsType],
                d.customer      AS [Customer],
                d.expected_date AS [ExpectedDate],
                d.doc_status    AS [DocStatus],
                d.note          AS [Note],
                d.mail_sent_at  AS [MailSentAt],
                d.mail_sent_to  AS [MailSentTo],
                -- 4 cột của mục 2b. DB chưa chạy return_actual_schema.sql thì
                -- câu này lỗi 207 và CẢ màn danh sách phiếu chết — script là
                -- bắt buộc trước khi publish API, không phải tuỳ chọn.
                d.closed_at           AS [ClosedAt],
                d.closed_by           AS [ClosedBy],
                d.actual_mail_sent_at AS [ActualMailSentAt],
                d.actual_mail_sent_to AS [ActualMailSentTo],
                d.created_at    AS [CreatedAt],
                d.created_by    AS [CreatedBy],
                d.updated_at    AS [UpdatedAt],
                d.updated_by    AS [UpdatedBy]
        FROM wms.return_instructions d
        WHERE d.is_deleted = 0
        """;

    public async Task<IReadOnlyList<ReturnInstruction>> GetListAsync(ReturnInstructionQuery query)
    {
        // Loại hàng nằm NGAY TRÊN PHIẾU nên lọc thẳng. Chỉ từ khoá model mới
        // phải nhìn sang bảng dòng, và dùng EXISTS chứ không JOIN: JOIN sẽ
        // nhân dòng phiếu lên theo số dòng khớp.
        //
        // Sắp theo NGÀY TẠO phiếu giảm dần, không theo expected_date: phiếu vừa
        // tạo phải nằm đầu danh sách, vì đó là phiếu người dùng vừa làm và đang
        // tìm. Sắp theo expected_date thì một phiếu tạo từ tuần trước mà hẹn
        // hàng về tháng sau lại chen lên trên phiếu vừa tạo, còn phiếu chưa khai
        // ngày dự kiến (NULL) thì nhảy hẳn lên đỉnh.
        //
        // id DESC chỉ để phá thế hoà: created_at là DATETIME2(0) nên hai phiếu
        // tạo trong cùng một giây bằng nhau, lúc đó id lớn hơn là phiếu sau.
        var sql = HeaderSql + """

              AND (@status    IS NULL OR d.doc_status = @status)
              AND (@goodsType IS NULL OR d.goods_type = @goodsType)
              AND (@fromDate  IS NULL OR d.expected_date >= @fromDate)
              AND (@toDate    IS NULL OR d.expected_date <= @toDate)
              AND (@kw IS NULL OR d.doc_no LIKE @kw OR d.customer LIKE @kw
                   OR EXISTS (SELECT 1 FROM wms.return_instruction_lines l2
                              WHERE l2.doc_id = d.id AND l2.is_deleted = 0
                                AND l2.model LIKE @kw))
            ORDER BY d.created_at DESC, d.id DESC;
            """;

        using var conn = _factory.Create();
        var rows = (await conn.QueryAsync<ReturnInstruction>(sql, new
        {
            status = Blank(query.Status),
            goodsType = Blank(query.GoodsType),
            fromDate = query.FromDate?.Date,
            toDate = query.ToDate?.Date,
            kw = Blank(query.Keyword) is { } k ? $"%{k}%" : null,
        })).ToList();

        if (rows.Count == 0) return rows;

        // Nạp dòng của TẤT CẢ phiếu bằng MỘT câu, rồi gom vào từng phiếu —
        // tránh N+1. Danh sách cần Lines để tính ModelCount/TotalQty, nhưng
        // không trả chi tiết ra response danh sách.
        var lines = await LoadLinesAsync(conn, rows.Select(r => r.Id).ToList());
        foreach (var r in rows)
            r.Lines = lines.TryGetValue(r.Id, out var ls) ? ls : [];

        return rows;
    }

    public async Task<ReturnInstruction?> GetByIdAsync(long id)
    {
        using var conn = _factory.Create();
        var doc = await conn.QuerySingleOrDefaultAsync<ReturnInstruction>(
            HeaderSql + "\n  AND d.id = @id;", new { id });
        if (doc is null) return null;

        doc.Lines = (await LoadLinesAsync(conn, [id])).TryGetValue(id, out var ls) ? ls : [];
        return doc;
    }

    private static async Task<Dictionary<long, List<ReturnInstructionLine>>> LoadLinesAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> docIds)
    {
        const string sql = """
            SELECT  l.id         AS [Id],
                    l.doc_id     AS [DocId],
                    l.line_no    AS [LineNo],
                    l.model      AS [Model],
                    l.qty        AS [Qty],
                    l.note       AS [Note]
            FROM wms.return_instruction_lines l
            WHERE l.is_deleted = 0 AND l.doc_id IN @docIds
            ORDER BY l.doc_id, l.line_no, l.id;
            """;
        // Chia lô: Dapper trải IN thành từng parameter, SQL Server chỉ cho 2100
        // parameter một câu. Endpoint danh sách KHÔNG phân trang nên số phiếu
        // khớp bộ lọc có thể vượt ngưỡng đó, và lúc ấy cả màn hình chết.
        var rows = new List<ReturnInstructionLine>();
        foreach (var chunk in docIds.Chunk(DocIdChunk))
            rows.AddRange(
                await conn.QueryAsync<ReturnInstructionLine>(sql, new { docIds = chunk.ToList() }));

        // SL thực nhận + đang ở FA + đã giao lại: đếm sang sổ serial, không lưu
        // sẵn trên dòng. Cả ba con số lấy trong MỘT câu query.
        var received = await LoadReceivedAsync(conn, docIds);
        foreach (var r in rows)
            if (received.TryGetValue(r.DocId, out var byModel)
                && byModel.TryGetValue(r.Model, out var q))
            {
                r.ReceivedQty = q.Received;
                r.AtFaQty = q.AtFa;
                r.ReturnedQty = q.Returned;
            }

        return rows.GroupBy(r => r.DocId).ToDictionary(g => g.Key, g => g.ToList());
    }

    /// <summary>Ba con số đếm được của một (phiếu, model).</summary>
    private readonly record struct ModelQty(int Received, int AtFa, int Returned);

    /// <summary>
    /// SL thực nhận theo (phiếu, model) = số serial đã đăng ký. Đếm MỌI trạng
    /// thái: con hàng đang ở FA hay đã trả về thì vẫn là đã nhận.
    ///
    /// Kèm luôn hai con số của vòng đi–về với FA — <c>at_fa</c> (mục 2c đã giao,
    /// chưa về) và <c>returned</c> (mục 3 đã nhận lại) — trong CÙNG câu query:
    /// thêm một câu nữa cho hai con số này là thêm một vòng round-trip cho mỗi
    /// lần mở màn danh sách, mà dữ liệu thì cùng một bảng.
    ///
    /// Nuốt riêng lỗi 208 (Invalid object name): DB chưa chạy
    /// <c>return_receiving_schema.sql</c> thì màn danh sách phiếu vẫn phải mở
    /// được với SL thực nhận = 0, chứ không trả 500 cho một màn hình vốn đã
    /// chạy tốt trước khi có mục 2a.
    /// </summary>
    private static async Task<Dictionary<long, Dictionary<string, ModelQty>>> LoadReceivedAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> docIds)
    {
        // Đếm theo status bằng SUM(CASE…) chứ không GROUP BY thêm status: gom
        // theo status sẽ ra nhiều dòng cho một model và chỗ gọi phải tự cộng
        // lại, còn ở đây một model đúng một dòng với đủ ba con số.
        const string sql = """
            SELECT  s.doc_id AS [DocId],
                    s.model  AS [Model],
                    COUNT(*) AS [Qty],
                    SUM(CASE WHEN s.status = N'at_fa'    THEN 1 ELSE 0 END) AS [AtFa],
                    SUM(CASE WHEN s.status = N'returned' THEN 1 ELSE 0 END) AS [Returned]
            FROM wms.return_instruction_serials s
            WHERE s.is_deleted = 0 AND s.doc_id IN @docIds
            GROUP BY s.doc_id, s.model;
            """;

        var result = new Dictionary<long, Dictionary<string, ModelQty>>();
        try
        {
            // Chia lô vì cùng lý do với LoadLinesAsync — xem ghi chú ở đó.
            foreach (var chunk in docIds.Chunk(DocIdChunk))
            {
                var rows = await conn.QueryAsync<ReceivedRow>(
                    sql, new { docIds = chunk.ToList() });

                foreach (var r in rows)
                {
                    if (!result.TryGetValue(r.DocId, out var byModel))
                        result[r.DocId] = byModel =
                            new Dictionary<string, ModelQty>(StringComparer.OrdinalIgnoreCase);
                    byModel[r.Model] = new ModelQty(r.Qty, r.AtFa, r.Returned);
                }
            }
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 208)
        {
            return result;
        }
        return result;
    }

    private sealed class ReceivedRow
    {
        public long DocId { get; set; }
        public string Model { get; set; } = string.Empty;
        public int Qty { get; set; }

        /// <summary>Đang ở FA (mục 2c đã giao, chưa nhận lại).</summary>
        public int AtFa { get; set; }

        /// <summary>FA đã giao lại, SCS đã nhận (mục 3).</summary>
        public int Returned { get; set; }
    }

    public async Task<long> CreateAsync(ReturnInstruction doc, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var docNo = await NextDocNoAsync(conn, tx, ReturnGoodsType.DocPrefix(doc.GoodsType));

            var id = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.return_instructions
                    (doc_no, goods_type, customer, expected_date, doc_status, note,
                     is_deleted, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@docNo, @goodsType, @customer, @expectedDate, @status, @note,
                        0, SYSDATETIME(), @user);
                """,
                new
                {
                    docNo,
                    goodsType = doc.GoodsType,
                    customer = doc.Customer,
                    expectedDate = doc.ExpectedDate,
                    status = doc.DocStatus,
                    note = doc.Note,
                    user,
                }, tx);

            await InsertLinesAsync(conn, tx, id, doc.Lines, user);

            tx.Commit();
            doc.Id = id;
            doc.DocNo = docNo;
            return id;
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>
    /// Số phiếu kế tiếp trong ngày: <c>{prefix}-yyyyMMdd-###</c>, với prefix là
    /// <c>RW</c> (rework) hoặc <c>RB</c> (refurbish).
    ///
    /// Mỗi loại một dãy số riêng: bộ đếm chỉ nhìn các phiếu CÙNG tiền tố, nên
    /// RW-…-001 và RB-…-001 cùng tồn tại trong một ngày là bình thường.
    ///
    /// Tính trong CÙNG transaction với INSERT và khoá dải bằng
    /// <c>UPDLOCK, HOLDLOCK</c>: hai người bấm Lưu cùng lúc mà không khoá thì
    /// cả hai đọc ra cùng một số, người sau sẽ đâm vào
    /// <c>ux_return_instructions_doc_no</c>. Kể cả thế, unique index vẫn là
    /// lưới an toàn cuối — khoá chỉ để chuyện đó đừng xảy ra.
    ///
    /// Đọc cả dòng đã xoá mềm (không lọc is_deleted): xoá một phiếu rồi cấp
    /// lại đúng số đó cho phiếu mới sẽ làm hai phiếu khác nhau trùng số trong
    /// lịch sử và trong hộp thư của FA.
    /// </summary>
    private static async Task<string> NextDocNoAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx, string typePrefix)
    {
        var prefix = $"{typePrefix}-{DateTime.Now:yyyyMMdd}-";
        var next = await conn.ExecuteScalarAsync<int>("""
            SELECT ISNULL(MAX(TRY_CONVERT(int, RIGHT(doc_no, 3))), 0) + 1
            FROM   wms.return_instructions WITH (UPDLOCK, HOLDLOCK)
            WHERE  doc_no LIKE @prefix + '[0-9][0-9][0-9]';
            """, new { prefix }, tx);
        return prefix + next.ToString("D3");
    }

    private static async Task InsertLinesAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx,
        long docId, IReadOnlyList<ReturnInstructionLine> lines, string? user)
    {
        const string sql = """
            INSERT INTO wms.return_instruction_lines
                (doc_id, line_no, model, qty, note,
                 is_deleted, created_at, created_by)
            VALUES (@docId, @lineNo, @model, @qty, @note,
                    0, SYSDATETIME(), @user);
            """;

        var n = 0;
        foreach (var l in lines)
            await conn.ExecuteAsync(sql, new
            {
                docId,
                lineNo = ++n,
                model = l.Model,
                qty = l.Qty,
                note = l.Note,
                user,
            }, tx);
    }

    public async Task<bool> UpdateAsync(ReturnInstruction doc, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var n = await conn.ExecuteAsync("""
                UPDATE wms.return_instructions
                SET    customer      = @customer,
                       expected_date = @expectedDate,
                       note          = @note,
                       updated_at    = SYSDATETIME(),
                       updated_by    = @user
                WHERE  id = @id AND is_deleted = 0;
                """,
                new
                {
                    id = doc.Id,
                    customer = doc.Customer,
                    expectedDate = doc.ExpectedDate,
                    note = doc.Note,
                    user,
                }, tx);

            if (n == 0) { tx.Rollback(); return false; }

            // Xoá mềm rồi chèn lại thay vì so từng dòng: danh sách ngắn (vài
            // chục dòng), và so khớp từng dòng để quyết thêm/sửa/xoá là chỗ dễ
            // sai hơn nhiều so với cái nó tiết kiệm được.
            //
            // Xoá MỀM vì mục 2 trở đi sẽ trỏ ngược về dòng chỉ thị — một dòng
            // từng tồn tại phải còn đọc được.
            await conn.ExecuteAsync("""
                UPDATE wms.return_instruction_lines
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  doc_id = @id AND is_deleted = 0;
                """, new { id = doc.Id, user }, tx);

            await InsertLinesAsync(conn, tx, doc.Id, doc.Lines, user);

            tx.Commit();
            return true;
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<bool> SoftDeleteAsync(long id, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var n = await conn.ExecuteAsync("""
                UPDATE wms.return_instructions
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  id = @id AND is_deleted = 0;
                """, new { id, user }, tx);

            if (n == 0) { tx.Rollback(); return false; }

            await conn.ExecuteAsync("""
                UPDATE wms.return_instruction_lines
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  doc_id = @id AND is_deleted = 0;
                """, new { id, user }, tx);

            tx.Commit();
            return true;
        }
        catch { tx.Rollback(); throw; }
    }

    // ===================== Mục 2b: chốt thực nhận =====================

    public async Task<bool> CloseAsync(long id, string? user)
    {
        using var conn = _factory.Create();
        // Điều kiện doc_status = 'open' nằm TRONG câu UPDATE, không kiểm trước
        // rồi ghi sau: hai người cùng bấm Chốt thì người sau phải thấy 0 dòng
        // bị đổi, chứ không chốt lại và gửi FA hai lá mail.
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    doc_status = @completed,
                   closed_at  = SYSDATETIME(),
                   closed_by  = @user,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  id = @id AND is_deleted = 0 AND doc_status = @open;
            """, new
        {
            id,
            user,
            open = ReturnDocStatus.Open,
            completed = ReturnDocStatus.Completed,
        });
        return n > 0;
    }

    public async Task<bool> ReopenAsync(long id, string? user)
    {
        using var conn = _factory.Create();
        // KHÔNG xoá closed_at / actual_mail_sent_at: đó là dấu vết FA đã nhận
        // số nào, lúc nào. Chốt lại sẽ ghi đè bằng mốc mới.
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    doc_status = @open,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  id = @id AND is_deleted = 0 AND doc_status = @completed;
            """, new
        {
            id,
            user,
            open = ReturnDocStatus.Open,
            completed = ReturnDocStatus.Completed,
        });
        return n > 0;
    }

    public async Task MarkActualMailSentAsync(long id, string recipients)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    actual_mail_sent_at = SYSDATETIME(), actual_mail_sent_to = @recipients
            WHERE  id = @id;
            """, new { id, recipients });
    }

    public async Task MarkMailSentAsync(long id, string recipients)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    mail_sent_at = SYSDATETIME(), mail_sent_to = @recipients
            WHERE  id = @id;
            """, new { id, recipients });
    }

    public async Task<IReadOnlyList<string>> FindUnknownModelsAsync(IReadOnlyList<string> models)
    {
        if (models.Count == 0) return [];

        using var conn = _factory.Create();
        // Trả về mã CÓ trong danh mục rồi lấy phần bù ở C#, thay vì nhét bảng
        // tạm vào SQL để lấy phần thiếu — danh sách chỉ vài chục mã.
        var known = (await conn.QueryAsync<string>("""
            SELECT m.code FROM master.models m
            WHERE m.is_deleted = 0 AND m.code IN @models;
            """, new { models })).ToHashSet(StringComparer.OrdinalIgnoreCase);

        return models.Where(m => !known.Contains(m)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    public async Task<List<MailRecipient>> GetMailRecipientsAsync(string eventCode)
    {
        using var conn = _factory.Create();

        // ⚠ KHÔNG truyền NULL cho department.
        //
        // master.fn_email_recipients so KHỚP department, nên gọi với NULL thì
        // mọi dòng cấu hình có department (vd 'FA' — đúng cái sẽ khai cho FA
        // nhận mail) KHÔNG trả về, và mail im lặng không gửi.
        //
        // Cách đúng: liệt kê các BỘ PHẬN đang được cấu hình cho sự kiện này
        // rồi CROSS APPLY vào hàm tra. Nhờ vậy danh sách bộ phận nằm trong DỮ
        // LIỆU chứ không trong code — khai thêm một bộ phận trong màn Cấu hình
        // email là nó tự nhận mail, không phải build lại.
        //
        // Đây đúng khuôn đã dùng ở ShortageRepository.GetEventRecipientsAsync
        // và NgReportRepository.GetMailRecipientsAsync.
        const string sql = """
            SELECT DISTINCT
                   r.recipient_type AS Type, r.email AS Email, r.display_name AS DisplayName
            FROM   (SELECT DISTINCT c.department
                    FROM   master.email_config c
                    WHERE  c.event_code = @eventCode
                           AND c.is_active = 1 AND c.is_deleted = 0) d
            CROSS APPLY master.fn_email_recipients(
                            @eventCode, d.department, NULL, NULL, NULL, NULL) r;
            """;

        var rows = await conn.QueryAsync<MailRecipient>(sql, new { eventCode });

        // Normalize: một ô email được phép chứa nhiều địa chỉ ngăn bởi ',' hoặc
        // ';' (khai theo nhóm thay vì mỗi người một dòng), đã ở TO thì bỏ khỏi
        // CC/BCC, và khử trùng. Để nguyên cả cụm chuỗi thì SmtpMailSender nhận
        // một "địa chỉ" không hợp lệ và cả lá mail không đi.
        return MailRecipientList.Normalize(rows);
    }

    public async Task<MailTemplateRow?> GetMailTemplateAsync(string eventCode)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<MailTemplateRow>("""
            SELECT subject_template AS [Subject], body_template AS [Body]
            FROM   master.email_events
            WHERE  code = @eventCode AND is_active = 1;
            """, new { eventCode });
    }

    public async Task<string?> GetUserEmailAsync(string? employeeCode)
    {
        if (string.IsNullOrWhiteSpace(employeeCode)) return null;

        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<string?>("""
            SELECT TOP 1 u.email
            FROM   master.users u
            WHERE  u.employee_code = @employeeCode AND u.is_deleted = 0;
            """, new { employeeCode });
    }

    // ===================== Mục 2a: sổ serial =====================

    public async Task<IReadOnlyDictionary<string, int>> GetCategoryByModelAsync(
        IReadOnlyList<string> models)
    {
        var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        if (models.Count == 0) return result;

        using var conn = _factory.Create();
        // category_id của master.models là MÃ category (JOIN master.categories.code),
        // không phải khoá nội bộ — xem ModelRepository. Pallet ID nhúng chính mã này.
        // JOIN master.categories, không chỉ kiểm category_id IS NOT NULL: model
        // mang mã category không còn trong danh mục thì phải rơi vào thông báo
        // "chưa khai category" của chính feature này, chứ không đi tới
        // GenerateNextLotNoAsync rồi trả 404 "Lot.CategoryNotFound" — một câu
        // nói về lot, giữa màn nhận hàng, không ai hiểu phải sửa ở đâu.
        var rows = await conn.QueryAsync<ModelCategoryRow>("""
            SELECT m.code        AS [Code],
                   m.category_id AS [CategoryCode]
            FROM   master.models     m
            JOIN   master.categories c ON c.code = m.category_id AND c.is_deleted = 0
            WHERE  m.is_deleted = 0 AND m.category_id IS NOT NULL
              AND  m.code IN @models;
            """, new { models = models.Distinct(StringComparer.OrdinalIgnoreCase).ToList() });

        foreach (var r in rows) result.TryAdd(r.Code, r.CategoryCode);
        return result;
    }

    private sealed class ModelCategoryRow
    {
        public string Code { get; set; } = string.Empty;
        public int CategoryCode { get; set; }
    }

    /// <summary>
    /// Chia lô 1000 mã mỗi câu: Dapper trải IN thành từng parameter, mà SQL
    /// Server chỉ cho 2100 parameter một câu — quét một pallet lớn là vượt.
    /// </summary>
    private const int SerialLookupChunk = 1000;

    public async Task<IReadOnlyList<ReturnSerialOwnerRow>> FindSerialOwnersAsync(
        IReadOnlyList<string> serials)
    {
        if (serials.Count == 0) return [];

        const string sql = """
            SELECT  s.serial_no AS [SerialNo],
                    s.doc_id    AS [DocId],
                    d.doc_no    AS [DocNo],
                    s.status    AS [Status]
            FROM wms.return_instruction_serials s
            -- d.is_deleted = 0 là BẮT BUỘC: thiếu nó thì WH nhận thông báo
            -- "serial này đang thuộc phiếu RW-…" trỏ vào một phiếu đã xoá mềm,
            -- mở ra thì 404 — bế tắc hoàn toàn ở cầu cảng.
            JOIN wms.return_instructions d ON d.id = s.doc_id AND d.is_deleted = 0
            WHERE s.is_deleted = 0
              -- Đã xuất cho khách thì thôi giữ chỗ: cùng một sản phẩm có thể bị
              -- trả về lần nữa và phải đăng ký được vào phiếu mới. Cùng điều kiện
              -- với unique index ux_ris_serial_open.
              AND s.status <> N'shipped'
              AND s.serial_no IN @serials;
            """;

        using var conn = _factory.Create();
        var all = new List<ReturnSerialOwnerRow>();

        foreach (var chunk in serials.Chunk(SerialLookupChunk))
            all.AddRange(await conn.QueryAsync<ReturnSerialOwnerRow>(
                sql, new { serials = chunk.ToList() }));

        return all;
    }

    public async Task RegisterSerialsAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletDbId,
        string disposition,
        IReadOnlyList<ReturnSerial> serials,
        string? user)
    {
        // Đóng dấu pallet là hàng return. disposition dùng CHUNG từ vựng với
        // return_instructions.goods_type (rework | refurbish) nên bản đồ kho vẽ
        // được badge RW/RE mà không cần lớp quy đổi nào.
        //
        // inspection_exempt: hàng khách trả về không đi qua OQC. Để nguyên
        // not_inspected (giá trị PalletService đặt cho mọi pallet mức serial) là
        // pallet hàng return sẽ nằm chờ trong hàng đợi kiểm mãi không ai gọi.
        await conn.ExecuteAsync("""
            UPDATE wms.pallets
            SET    disposition       = @disposition,
                   inspection_status = N'inspection_exempt',
                   updated_at        = SYSDATETIME(),
                   updated_by        = @user
            WHERE  id = @palletDbId;
            """, new { disposition, palletDbId, user }, tx);

        if (serials.Count == 0) return;

        const string insert = """
            INSERT INTO wms.return_instruction_serials
                (doc_id, model, serial_no, box_no, pallet_id, status,
                 received_at, is_deleted, created_at, created_by)
            VALUES
                (@docId, @model, @serialNo, @boxNo, @palletDbId, @status,
                 SYSDATETIME(), 0, SYSDATETIME(), @user);
            """;

        await conn.ExecuteAsync(insert, serials.Select(s => new
        {
            docId,
            model = s.Model,
            serialNo = s.SerialNo,
            boxNo = s.BoxNo,
            palletDbId,
            status = ReturnSerialStatus.Received,
            user,
        }), tx);
    }

    public async Task<IReadOnlyList<ReturnPallet>> GetPalletsByDocAsync(long docId)
    {
        using var conn = _factory.Create();

        // Pallet của phiếu suy ra TỪ SỔ SERIAL, không từ một cột trên wms.pallets:
        // xem ghi chú ix_ris_pallet trong return_receiving_schema.sql.
        const string palletSql = """
            SELECT  p.id               AS [Id],
                    RTRIM(p.pallet_id) AS [LotNo],
                    loc.locator_code   AS [LocatorCode],
                    -- box_count nullable trong DB; pallet mức serial thì server
                    -- luôn tính nên không null, vẫn ISNULL cho chắc vì Dapper
                    -- map NULL vào int là ném lỗi.
                    ISNULL(p.box_count, 0) AS [BoxCount],
                    p.created_at        AS [CreatedAt],
                    p.created_by        AS [CreatedBy],
                    s.cnt              AS [SerialCount]
            FROM (
                SELECT pallet_id, COUNT(*) AS cnt
                FROM   wms.return_instruction_serials
                WHERE  doc_id = @docId AND is_deleted = 0 AND pallet_id IS NOT NULL
                GROUP BY pallet_id
            ) s
            -- p.is_deleted = 0: pallet đã xoá thì đừng còn hiện trong danh sách
            -- pallet của phiếu.
            JOIN      wms.pallets     p   ON p.id = s.pallet_id AND p.is_deleted = 0
            LEFT JOIN master.locators loc ON loc.id = p.locator_id
            ORDER BY p.id DESC;
            """;

        const string modelSql = """
            SELECT  pallet_id AS [PalletDbId],
                    model     AS [Model],
                    COUNT(*)  AS [Qty]
            FROM   wms.return_instruction_serials
            WHERE  doc_id = @docId AND is_deleted = 0 AND pallet_id IS NOT NULL
            GROUP BY pallet_id, model;
            """;

        var pallets = (await conn.QueryAsync<ReturnPallet>(palletSql, new { docId })).ToList();
        if (pallets.Count == 0) return pallets;

        var models = await conn.QueryAsync<PalletModelRow>(modelSql, new { docId });
        var byPallet = models.GroupBy(m => m.PalletDbId)
                             .ToDictionary(g => g.Key, g => g.ToList());

        foreach (var p in pallets)
            if (byPallet.TryGetValue(p.Id, out var rows))
                p.ModelCounts = rows.ToDictionary(r => r.Model, r => r.Qty, StringComparer.OrdinalIgnoreCase);

        return pallets;
    }

    private sealed class PalletModelRow
    {
        public long PalletDbId { get; set; }
        public string Model { get; set; } = string.Empty;
        public int Qty { get; set; }
    }

    public async Task<int> ReleasePalletAsync(long docId, long palletDbId, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // Xoá MỀM dòng sổ serial của đúng pallet đó trong đúng phiếu đó.
            // Phải giải phóng serial, nếu không ux_ris_serial_open giữ chúng
            // mãi và không bao giờ quét lại được vào pallet mới.
            var n = await conn.ExecuteAsync("""
                UPDATE wms.return_instruction_serials
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  doc_id = @docId AND pallet_id = @palletDbId AND is_deleted = 0;
                """, new { docId, palletDbId, user }, tx);

            // Pallet cũng xoá mềm, cùng transaction: để lại một pallet rỗng mà
            // serial đã tháo khỏi sổ là hai nguồn sự thật nói khác nhau.
            await conn.ExecuteAsync("""
                UPDATE wms.pallets
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  id = @palletDbId AND is_deleted = 0;
                """, new { palletDbId, user }, tx);

            await conn.ExecuteAsync("""
                UPDATE wms.boxes
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  lot_id = @palletDbId AND is_deleted = 0;
                """, new { palletDbId, user }, tx);

            await conn.ExecuteAsync("""
                UPDATE bl
                SET    bl.is_deleted = 1, bl.updated_at = SYSDATETIME(), bl.updated_by = @user
                FROM   wms.box_lines bl
                JOIN   wms.boxes b ON b.id = bl.box_id
                WHERE  b.lot_id = @palletDbId AND bl.is_deleted = 0;
                """, new { palletDbId, user }, tx);

            tx.Commit();
            return n;
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<IReadOnlyList<ReturnSerial>> GetSerialsByDocAsync(long docId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<ReturnSerial>("""
            SELECT  s.id          AS [Id],
                    s.doc_id      AS [DocId],
                    s.model       AS [Model],
                    s.serial_no   AS [SerialNo],
                    s.box_no      AS [BoxNo],
                    s.pallet_id   AS [PalletDbId],
                    RTRIM(p.pallet_id) AS [PalletNo],
                    s.status      AS [Status],
                    s.received_at AS [ReceivedAt],
                    s.created_by  AS [CreatedBy]
            FROM      wms.return_instruction_serials s
            LEFT JOIN wms.pallets p ON p.id = s.pallet_id
            WHERE  s.doc_id = @docId AND s.is_deleted = 0
            ORDER BY s.model, s.serial_no;
            """, new { docId })).ToList();
    }


    // ═══════════════════ Mục 2d — FA đóng pallet sau rework ═══════════════════

    /// <summary>
    /// Sổ serial dạng GỌN để PDA kiểm trên máy. Ba trường, không join gì.
    ///
    /// Trả CẢ serial đã về / đã xuất chứ không chỉ `at_fa`: PDA cần phân biệt
    /// "con này không thuộc phiếu" với "con này thuộc phiếu nhưng đã về rồi" —
    /// hai câu cảnh báo khác nhau, và FA xử lý khác nhau.
    /// </summary>
    public async Task<IReadOnlyList<ReturnSerialIndexRow>> GetSerialIndexAsync(long docId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<ReturnSerialIndexRow>("""
            SELECT s.serial_no AS [SerialNo],
                   s.model     AS [Model],
                   s.status    AS [Status]
            FROM   wms.return_instruction_serials s
            WHERE  s.doc_id = @docId AND s.is_deleted = 0
            ORDER BY s.serial_no;
            """, new { docId })).ToList();
    }

    /// <summary>
    /// Tra chủ của từng serial, KHÔNG lọc trạng thái.
    ///
    /// Khác <see cref="FindSerialOwnersAsync"/> ở hai điểm, nên là method riêng
    /// chứ không thêm cờ: hàm kia lọc `status &lt;&gt; 'shipped'` (đúng cho mục
    /// 2a — hàng đã xuất thì thôi giữ chỗ), còn ở đây một con ĐÃ XUẤT mà FA quét
    /// ra là chuyện phải nói rõ, không được rơi vào nhóm "không có trong phiếu".
    /// Hàm này cũng trả thêm model để PDA khỏi tra lần nữa.
    /// </summary>
    public async Task<IReadOnlyList<ReturnSerialResolution>> ResolveSerialsAsync(
        IReadOnlyList<string> serials)
    {
        if (serials.Count == 0) return [];

        const string sql = """
            SELECT  s.serial_no AS [SerialNo],
                    s.doc_id    AS [DocId],
                    d.doc_no    AS [DocNo],
                    s.model     AS [Model],
                    s.status    AS [Status]
            FROM wms.return_instruction_serials s
            -- d.is_deleted = 0: thiếu nó thì cảnh báo trỏ vào phiếu đã xoá mềm,
            -- mở ra 404 — bế tắc. Cùng lý do đã ghi ở FindSerialOwnersAsync.
            JOIN wms.return_instructions d ON d.id = s.doc_id AND d.is_deleted = 0
            WHERE s.is_deleted = 0
              AND s.serial_no IN @serials;
            """;

        using var conn = _factory.Create();
        var all = new List<ReturnSerialResolution>();
        foreach (var chunk in serials.Chunk(SerialLookupChunk))
            all.AddRange(await conn.QueryAsync<ReturnSerialResolution>(
                sql, new { serials = chunk.ToList() }));
        return all;
    }

    /// <summary>
    /// Gắn pallet FA vừa đóng vào các serial ĐÃ CÓ trong sổ.
    ///
    /// Khác <see cref="RegisterSerialsAsync"/> ở bản chất: mục 2a CHÈN dòng mới,
    /// còn ở đây chỉ CẬP NHẬT `pallet_id` + `box_no` của dòng sẵn có. Trạng thái
    /// giữ nguyên `at_fa` — hàng vẫn đang ở FA, chỉ là đã đóng pallet chờ giao.
    /// Mốc "đã về" là mục 3, do SCS quét nhận.
    ///
    /// Điều kiện `status = at_fa` nằm TRONG câu UPDATE: con vừa bị người khác
    /// nhận về trong lúc FA đang quét thì không ăn, thay vì bị kéo ngược trạng
    /// thái về at_fa.
    /// </summary>
    public async Task AttachFaPalletAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletDbId,
        string disposition,
        IReadOnlyList<ReturnFaSerialRow> rows,
        string? user)
    {
        // Đóng dấu pallet là hàng return, cùng từ vựng goods_type. Tem pallet
        // của FA phải có badge RW/RB y như tem của SCS — xem QrLabelData.
        await conn.ExecuteAsync("""
            UPDATE wms.pallets
            SET    disposition       = @disposition,
                   inspection_status = N'inspection_exempt',
                   updated_at        = SYSDATETIME(),
                   updated_by        = @user
            WHERE  id = @palletDbId;
            """, new { disposition, palletDbId, user }, tx);

        if (rows.Count == 0) return;

        const string sql = """
            UPDATE wms.return_instruction_serials
            SET    pallet_id  = @palletDbId,
                   box_no     = @boxNo,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  doc_id    = @docId
              AND  serial_no = @serialNo
              AND  status    = N'at_fa'
              AND  is_deleted = 0;
            """;

        await conn.ExecuteAsync(sql, rows.Select(r => new
        {
            palletDbId,
            boxNo = r.BoxNo,
            docId,
            serialNo = r.SerialNo,
            user,
        }), tx);
    }

    /// <summary>
    /// Ghi nhật ký serial không khớp. Chỉ GHI THÊM.
    ///
    /// Có hai đường gọi: trong transaction tạo pallet (kèm pallet_id), và đứng
    /// một mình khi KHÔNG con nào khớp — lúc đó không có pallet, nhưng nhật ký
    /// vẫn phải lưu, vì nó chính là danh sách SCS cần để đặt hàng riêng ra.
    /// </summary>
    public async Task AddMismatchesAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction? tx,
        long docId,
        long? palletDbId,
        IReadOnlyList<ReturnSerialMismatch> rows,
        string? user)
    {
        if (rows.Count == 0) return;

        const string sql = """
            INSERT INTO wms.return_serial_mismatches
                (doc_id, pallet_id, serial_no, model, reason, found_status,
                 other_doc_no, scanned_at, scanned_by,
                 is_deleted, created_at, created_by)
            VALUES
                (@docId, @palletDbId, @serialNo, @model, @reason, @foundStatus,
                 @otherDocNo, SYSDATETIME(), @user,
                 0, SYSDATETIME(), @user);
            """;

        await conn.ExecuteAsync(sql, rows.Select(r => new
        {
            docId,
            palletDbId,
            serialNo = r.SerialNo,
            model = r.Model,
            reason = r.Reason,
            foundStatus = r.FoundStatus,
            otherDocNo = r.OtherDocNo,
            user,
        }), tx);
    }

    /// <summary>
    /// Bản ghi độc lập — mở connection riêng. Dùng khi không con nào khớp nên
    /// không có transaction tạo pallet để bám vào.
    /// </summary>
    public async Task AddMismatchesAsync(
        long docId, IReadOnlyList<ReturnSerialMismatch> rows, string? user)
    {
        if (rows.Count == 0) return;
        using var conn = _factory.Create();
        await AddMismatchesAsync(conn, null, docId, null, rows, user);
    }

    /// <summary>Nhật ký serial lệch của một phiếu.</summary>
    public async Task<IReadOnlyList<ReturnSerialMismatch>> GetMismatchesAsync(
        long docId, bool openOnly)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<ReturnSerialMismatch>($"""
            SELECT  m.id            AS [Id],
                    m.doc_id        AS [DocId],
                    m.pallet_id     AS [PalletId],
                    RTRIM(p.pallet_id) AS [LotNo],
                    m.serial_no     AS [SerialNo],
                    m.model         AS [Model],
                    m.reason        AS [Reason],
                    m.found_status  AS [FoundStatus],
                    m.other_doc_no  AS [OtherDocNo],
                    m.scanned_at    AS [ScannedAt],
                    m.scanned_by    AS [ScannedBy],
                    m.resolved_at   AS [ResolvedAt],
                    m.resolved_by   AS [ResolvedBy],
                    m.resolve_note  AS [ResolveNote]
            FROM      wms.return_serial_mismatches m
            LEFT JOIN wms.pallets p ON p.id = m.pallet_id
            WHERE  m.doc_id = @docId AND m.is_deleted = 0
                   {(openOnly ? "AND m.resolved_at IS NULL" : "")}
            ORDER BY m.scanned_at DESC, m.id DESC;
            """, new { docId })).ToList();
    }

    /// <summary>Một dòng nhật ký theo id.</summary>
    public async Task<ReturnSerialMismatch?> GetMismatchByIdAsync(long id)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<ReturnSerialMismatch>("""
            SELECT  m.id            AS [Id],
                    m.doc_id        AS [DocId],
                    m.pallet_id     AS [PalletId],
                    RTRIM(p.pallet_id) AS [LotNo],
                    m.serial_no     AS [SerialNo],
                    m.model         AS [Model],
                    m.reason        AS [Reason],
                    m.found_status  AS [FoundStatus],
                    m.other_doc_no  AS [OtherDocNo],
                    m.scanned_at    AS [ScannedAt],
                    m.scanned_by    AS [ScannedBy],
                    m.resolved_at   AS [ResolvedAt],
                    m.resolved_by   AS [ResolvedBy],
                    m.resolve_note  AS [ResolveNote]
            FROM      wms.return_serial_mismatches m
            LEFT JOIN wms.pallets p ON p.id = m.pallet_id
            WHERE  m.id = @id AND m.is_deleted = 0;
            """, new { id });
    }

    /// <summary>
    /// Đánh dấu đã xử lý. Điều kiện `resolved_at IS NULL` nằm TRONG câu UPDATE
    /// để hai người bấm cùng lúc thì người sau biết là đã có người làm.
    /// </summary>
    public async Task<bool> ResolveMismatchAsync(long id, string? note, string? user)
    {
        using var conn = _factory.Create();
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_serial_mismatches
            SET    resolved_at  = SYSDATETIME(),
                   resolved_by  = @user,
                   resolve_note = @note,
                   updated_at   = SYSDATETIME(),
                   updated_by   = @user
            WHERE  id = @id AND is_deleted = 0 AND resolved_at IS NULL;
            """, new { id, note, user });
        return n > 0;
    }


    // ══════════════════ Mục 3 — SCS nhận lại pallet từ FA ══════════════════

    /// <summary>
    /// Nhận lại CẢ pallet bằng MỘT lần quét mã: mọi serial của pallet đó đang
    /// <c>at_fa</c> và thuộc phiếu này chuyển sang <c>returned</c>.
    ///
    /// Trả (số nhận được, số bỏ qua, có thấy pallet không). "Bỏ qua" = con nằm
    /// trên pallet nhưng không đổi được trạng thái: đã về trước đó, hoặc thuộc
    /// phiếu khác. KHÔNG coi đó là lỗi — nói ra con số để WH đối chiếu.
    ///
    /// Điều kiện `status = at_fa` nằm TRONG câu UPDATE: quét hai lần thì lần
    /// sau nhận 0 con, thay vì ghi đè mốc `returned_at` của lần đầu.
    /// </summary>
    public async Task<ReturnReceiveBackResult> ReceiveBackPalletAsync(
        long docId, string lotNo, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // RTRIM: pallet_id là cột cố định chiều dài ở một số DB, mã quét
            // được thì không có khoảng trắng đuôi.
            var palletId = await conn.ExecuteScalarAsync<long?>("""
                SELECT TOP (1) p.id
                FROM   wms.pallets p
                WHERE  RTRIM(p.pallet_id) = @lotNo AND p.is_deleted = 0;
                """, new { lotNo }, tx);

            if (palletId is null)
            {
                tx.Rollback();
                return new ReturnReceiveBackResult { PalletFound = false };
            }

            // Tổng serial của pallet thuộc sổ hàng back — dùng để tính "bỏ qua".
            var onPallet = await conn.ExecuteScalarAsync<int>("""
                SELECT COUNT(*)
                FROM   wms.return_instruction_serials s
                WHERE  s.pallet_id = @palletId AND s.is_deleted = 0;
                """, new { palletId }, tx);

            var received = await conn.ExecuteAsync("""
                UPDATE wms.return_instruction_serials
                SET    status      = N'returned',
                       returned_at = SYSDATETIME(),
                       updated_at  = SYSDATETIME(),
                       updated_by  = @user
                WHERE  pallet_id = @palletId
                  AND  doc_id    = @docId
                  AND  status    = N'at_fa'
                  AND  is_deleted = 0;
                """, new { palletId, docId, user }, tx);

            tx.Commit();
            return new ReturnReceiveBackResult
            {
                PalletFound = true,
                PalletDbId = palletId,
                Received = received,
                Skipped = onPallet - received,
                OnPallet = onPallet,
            };
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}
