using Swms.FinishGoods.API.Features.HdSoft.Business;
using Swms.FinishGoods.API.Features.HdSoft.PalletSync.Api;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business;

namespace Swms.FinishGoods.API.Features.HdSoft.PalletSync.Business
{
    /// <summary>Đồng bộ vị trí / si_no của pallet SWMS theo HD soft.</summary>
    public interface IPalletHdSoftSyncService
    {
        // ── API (PDA / Web): theo VỊ TRÍ ĐANG TỒN (M_StorageOnhand) ──
        Task<HdSoftSyncResponse> SyncFromHdSoftAsync(string lotNo, PalletInclude include);
        Task<List<HdSoftSyncBatchItem>> SyncFromHdSoftBatchAsync(IReadOnlyList<string> lotNos);

        // ── Job nền: theo GIAO DỊCH MỚI NHẤT (M_Transaction) ──
        Task<HdSoftApplyResult> ApplyHdSoftAsync(
            PalletLocationInfo info, HdSoftLastMovementRow last, IntegrationSyncContext sync);
    }
}
