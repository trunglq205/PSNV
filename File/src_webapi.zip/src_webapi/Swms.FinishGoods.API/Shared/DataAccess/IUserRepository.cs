using Swms.FinishGoods.API.Shared.Models;
using Swms.FinishGoods.API.Features.Users.Api;

namespace Swms.FinishGoods.API.Shared.DataAccess;

public interface IUserRepository
{
    Task<User?> GetByIdAsync(int id);
    Task<User?> GetByEmployeeCodeAsync(string code);
    Task<(IReadOnlyList<User> Items, int Total)> GetPagedAsync(UserQuery query);
    Task<int> AddAsync(User entity, IReadOnlyList<string> roleCodes);
    Task<List<int>> AddManyAsync(IReadOnlyList<User> entities);
    Task<bool> UpdateAsync(User entity, IReadOnlyList<string> roleCodes);
    Task<bool> UpdateLastLoginAsync(long id, DateTime lastLoginAt);
    Task<bool> SoftDeleteAsync(int id, string? userId);
    Task<bool> EmployeeCodeExistsAsync(string employeeCode, int? excludeId);
    Task<IReadOnlyList<(int Id, string EmployeeCode)>> GetExistingEmployeeCodesAsync(IReadOnlyList<string> empCodes);
    Task UpdatePasswordHashAsync(int id, string passwordHash, string? userId);
    Task<Dictionary<string, int>> GetDeptCountsAsync();
    Task<IReadOnlyList<Role>> GetAllRolesAsync();
}
