import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_skeleton.dart';

/// Skeleton loading cho khối cụm chức năng (Home).
class PermissionsShimmer extends StatelessWidget {
  /// Số cụm giả hiển thị khi loading.
  final int count;

  const PermissionsShimmer({super.key, this.count = 3});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (int i = 0; i < count; i++) ...[
          const _GroupSkeleton(),
          if (i != count - 1) const SizedBox(height: AppDimens.sm),
        ],
      ],
    );
  }
}

class _GroupSkeleton extends StatelessWidget {
  const _GroupSkeleton();

  @override
  Widget build(BuildContext context) {
    return const SkeletonCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Header: badge số + tên cụm + chip đếm + pin
          Row(
            children: [
              Bone(width: 18, height: 18, radius: 4),
              SizedBox(width: 8),
              Bone(width: 100),
              SizedBox(width: 8),
              Bone(width: 24, height: 18, radius: 8),
              Spacer(),
              Bone.circle(size: 24),
            ],
          ),
          SizedBox(height: AppDimens.sm),
          // 2 mini-card: vẽ nguyên khối, không lồng AppCard trong shimmer.
          Row(
            children: [
              Expanded(child: Bone(height: 44, radius: 12)),
              SizedBox(width: AppDimens.sm),
              Expanded(child: Bone(height: 44, radius: 12)),
            ],
          ),
        ],
      ),
    );
  }
}
