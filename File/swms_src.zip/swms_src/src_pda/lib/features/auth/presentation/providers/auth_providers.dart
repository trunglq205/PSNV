import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/auth/data/datasouces/auth_remote_datasource.dart';
import 'package:swms_finish_goods/features/auth/data/repositories/auth_repository_impl.dart';
import 'package:swms_finish_goods/features/auth/domain/auth_repository.dart';

part 'auth_providers.g.dart';

@riverpod
AuthRemoteDataSource authRemoteDataSource(Ref ref) =>
    AuthRemoteDataSource(ref.watch(dioProvider));

@riverpod
AuthRepository authRepository(Ref ref) => AuthRepositoryImpl(
  ref.watch(authRemoteDataSourceProvider),
  ref.watch(secureStorageProvider),
);
