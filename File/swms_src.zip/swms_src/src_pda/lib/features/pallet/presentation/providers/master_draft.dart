/// Khai báo master mà thao tác viên vừa nhập TRONG PHIÊN — chỉ để mở lại dialog
/// không phải chọn lại từ đầu, không phải nguồn sự thật.
///
/// Nguồn sự thật vẫn là `master.models` trên server; sau khi PATCH thành công
/// thì gợi ý đã nạp lại và phản ánh giá trị mới. Cái này chỉ vá đúng một khe:
/// giữa lúc lưu xong và lúc mở lại dialog, không có chỗ nào giữ lựa chọn cũ nên
/// các ô hiện về trắng, trông như vừa lưu hụt.
///
/// [modelCode] để tầng UI đối chiếu: quét sang pallet model khác thì bản nháp
/// này không còn liên quan, đem chọn sẵn sẽ khai nhầm master cho model đó.
class MasterDraft {
  const MasterDraft({
    required this.modelCode,
    this.areaId,
    this.rackRows,
  });

  final String modelCode;

  /// FK -> master.warehouse_areas(id).
  final int? areaId;

  /// Tầng rack, vd [2, 3].
  final List<int>? rackRows;

  /// Bản nháp này có phải của [code] không.
  bool matches(String? code) =>
      code != null && code.trim().isNotEmpty && code.trim() == modelCode;
}
