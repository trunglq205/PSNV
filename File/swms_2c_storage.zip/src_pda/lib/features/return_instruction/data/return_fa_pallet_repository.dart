import 'package:dio/dio.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_fa_pallet_model.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_pallet_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2d — truy cập API, gọi Dio TRỰC TIẾP thay vì qua retrofit.
//
//  Cùng lý do đã ghi ở return_fa_pallet_model.dart: bộ mục 2d làm sao để KHÔNG
//  cần chạy build_runner, mà `@RestApi` thì buộc sinh `.g.dart`.
//
//  Vẫn đi qua Dio CHUNG của app (`dioProvider`) nên giữ nguyên baseUrl, token
//  và ErrorInterceptor — câu thông báo lỗi của server tới được ErrorHandler y
//  như mọi màn khác.
//
//  Route treo trên PHIẾU: `/api/return-instructions/{docId}/…`. Tiền tố `/api`
//  là BẮT BUỘC — BASE_URL trong `config/*.json` chỉ tới host + port.
// ─────────────────────────────────────────────────────────────

class ReturnFaPalletRepository {
  final Dio _dio;
  const ReturnFaPalletRepository(this._dio);

  static String _base(int docId) => '/api/return-instructions/$docId';

  /// Sổ serial của phiếu, dạng gọn. Tải MỘT LẦN rồi tra tại máy.
  ///
  /// KHÔNG bắt DioException để bọc lại: ErrorInterceptor đã lấy câu thông báo
  /// của server và ErrorHandler hiện nguyên câu đó — bọc lại là mất thông tin.
  Future<List<FaSerialIndexRow>> fetchSerialIndex(int docId) async {
    final res = await _dio.get<Object?>('${_base(docId)}/serial-index');
    return faSerialIndexFromJson(res.data);
  }

  /// Nhật ký serial lệch của phiếu.
  ///
  /// `openOnly = false` lấy cả dòng đã xử lý: màn hình lọc ở client để con số
  /// "còn n chưa xử lý" vẫn đúng khi người dùng bật xem hết.
  Future<List<FaMismatch>> fetchMismatches(int docId,
      {bool openOnly = true}) async {
    final res = await _dio.get<Object?>(
      '${_base(docId)}/mismatches',
      queryParameters: {'openOnly': openOnly},
    );
    return faMismatchesFromJson(res.data);
  }

  /// FA đóng pallet mới: gửi CẢ CỤM thùng trong một request.
  ///
  /// Gửi cả cụm chứ không mỗi thùng một lần: pallet chỉ sinh ra MỘT Pallet ID
  /// cho cả cụm, và cả việc tạo pallet + chuyển sổ serial + ghi nhật ký lệch
  /// nằm trong MỘT transaction bên server. Bắn từng thùng là mỗi thùng một
  /// pallet, sai hẳn nghiệp vụ.
  ///
  /// KHÔNG gửi model: sổ serial đã biết mỗi con thuộc model nào, và server lấy
  /// model TỪ SỔ. FA không nhập model ở bước này.
  ///
  /// Gửi CẢ serial mà máy đã biết là lệch: chính server là bên ghi nhật ký, nên
  /// lọc bớt ở PDA là SCS không bao giờ biết FA đã quét ra con đó.
  Future<FaPalletResult> createPallet({
    required int docId,
    required List<FaScanBox> boxes,
  }) async {
    final res = await _dio.post<Object?>(
      '${_base(docId)}/fa-pallets',
      data: {
        'boxes': boxes
            .map((b) => {
                  // Thùng không có mã thì BỎ HẲN khoá, không gửi chuỗi rỗng:
                  // `[StringLength(50)] string? BoxNo` nhận null, còn chuỗi
                  // rỗng sẽ thành mã thùng rỗng trong DB.
                  if (b.boxNo != null && b.boxNo!.isNotEmpty) 'boxNo': b.boxNo,
                  'serials': b.serials.map((s) => s.serial).toList(),
                })
            .toList(),
      },
    );

    final data = res.data;
    if (data is! Map) {
      throw DioException(
        requestOptions: res.requestOptions,
        response: res,
        message: 'fa-pallets tra ve du lieu khong doc duoc',
      );
    }
    return faPalletResultFromJson(data.cast<String, Object?>());
  }
}
