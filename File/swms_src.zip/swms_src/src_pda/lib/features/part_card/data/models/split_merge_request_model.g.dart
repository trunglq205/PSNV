// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'split_merge_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SplitPrintRequestModel _$SplitPrintRequestModelFromJson(
  Map<String, dynamic> json,
) => SplitPrintRequestModel(
  sourcePayload: json['sourcePayload'] as String,
  items: (json['items'] as List<dynamic>)
      .map((e) => PrintHistoryRequestModel.fromJson(e as Map<String, dynamic>))
      .toList(),
);

Map<String, dynamic> _$SplitPrintRequestModelToJson(
  SplitPrintRequestModel instance,
) => <String, dynamic>{
  'sourcePayload': instance.sourcePayload,
  'items': instance.items.map((e) => e.toJson()).toList(),
};

MergePrintRequestModel _$MergePrintRequestModelFromJson(
  Map<String, dynamic> json,
) => MergePrintRequestModel(
  sourcePayloads: (json['sourcePayloads'] as List<dynamic>)
      .map((e) => e as String)
      .toList(),
  item: PrintHistoryRequestModel.fromJson(json['item'] as Map<String, dynamic>),
);

Map<String, dynamic> _$MergePrintRequestModelToJson(
  MergePrintRequestModel instance,
) => <String, dynamic>{
  'sourcePayloads': instance.sourcePayloads,
  'item': instance.item.toJson(),
};
