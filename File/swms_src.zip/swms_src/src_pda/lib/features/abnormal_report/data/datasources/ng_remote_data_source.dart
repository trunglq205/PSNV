import 'dart:io';

import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/abnormal_report/data/models/ng_models.dart';

part 'ng_remote_data_source.g.dart';

@RestApi()
abstract class NgRemoteDataSource {
  factory NgRemoteDataSource(Dio dio, {String baseUrl}) = _NgRemoteDataSource;

  /// Danh sách phiếu hàng bất thường. [from]/[to] lọc theo ngày phát hiện.
  @GET('/api/abnormal-reports')
  Future<List<NgReportModel>> fetchList({
    @Query('status') String? status,
    @Query('ngType') String? ngType,
    @Query('from') String? from,
    @Query('to') String? to,
    @Query('keyword') String? keyword,
  });

  /// Danh mục loại lỗi (master.ng_types). Nhãn đã được API dịch theo ngôn ngữ
  /// của request, nên app không cần khoá dịch riêng cho từng loại.
  @GET('/api/abnormal-reports/types')
  Future<List<NgTypeModel>> fetchTypes();

  /// Chi tiết 1 phiếu: phạm vi ảnh hưởng, ảnh, nhật ký duyệt.
  @GET('/api/abnormal-reports/{id}')
  Future<NgDetailModel> fetchDetail(@Path('id') int id);

  /// Tra pallet ngay lúc quét, trước khi điền phiếu. 404 = mã không có trong
  /// hệ thống. Endpoint riêng của NG: KHÔNG tạo pallet mới, khác với
  /// /api/pallets/by-lot-no/{lotNo} vốn dựng lot từ Foss khi thiếu.
  @GET('/api/abnormal-reports/pallet-check')
  Future<NgPalletCheckModel> checkPallet(@Query('code') String code);

  /// Bước 1 — SCS tạo phiếu nháp trên pallet đã quét.
  @POST('/api/abnormal-reports')
  Future<CreateNgResultModel> create(@Body() CreateNgReportModel body);

  /// Thêm 1 ảnh lỗi (tối đa 5 ảnh mỗi phiếu).
  @POST('/api/abnormal-reports/{id}/photos')
  @MultiPart()
  Future<void> uploadPhoto(@Path('id') int id, @Part(name: 'file') File file);

}
