﻿using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.OqcSamples.Api;
using Swms.FinishGoods.API.Features.OqcSamples.Business.Entities;
using Swms.FinishGoods.API.Features.OqcSamples.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;
using System.Globalization;

namespace Swms.FinishGoods.API.Features.OqcSamples.Business
{
    public class OqcSampleService : IOqcSampleService
    {
        private readonly IOqcSampleRepository _repo;
        private readonly ICurrentUser _currentUser;
        private readonly IStringLocalizer<SharedResource> _localizer;

        public OqcSampleService(
            IOqcSampleRepository repo,
            ICurrentUser currentUser,
            IStringLocalizer<SharedResource> localizer)
        {
            _repo = repo;
            _currentUser = currentUser;
            _localizer = localizer;
        }

        private static readonly string[] DateFormats = ["dd/MM/yyyy", "yyyy-MM-dd", "d/M/yyyy"];

        public async Task<OqcLocationResponse> GetLocationsAsync(OqcGetLocationsRequest request)
        {
            var model = (request.Model ?? "").Trim();
            var payload = request.Payload?.Trim();
            DateTime? prodDate = TryParseDate(request.ProductionDate, out var d) ? d : null;

            if (string.IsNullOrEmpty(payload) && prodDate is null)
                throw new BusinessRuleException(
                    _localizer[OqcErrors.ProductionDateInvalid, request.ProductionDate ?? ""]);

            var res = await _repo.GetLocationAsync(model, prodDate, payload)
                ?? throw new NotFoundException(
                    _localizer[OqcErrors.PalletNotFound, model, request.ProductionDate ?? ""]);

            return new OqcLocationResponse(res.Locator, res.PalletId);
        }

        public async Task<OqcOkResponse> SampleAsync(OqcSampleActionRequest request)
        {
            var iso = RequireIsoDate(request.ProductionDate);
            var affected = await _repo.SampleAsync(
                request.Model.Trim(), iso, request.LotName, _currentUser.FullName,
                request.Payload);

            // SP trả 0 khi không có card nào để lấy mẫu (đã 4/5 hoặc không tồn tại).
            if (affected == 0)
                throw new BusinessRuleException(_localizer[OqcErrors.NothingToSample, request.Model, request.ProductionDate]);

            return new OqcOkResponse("ok");
        }

        // Trả mẫu theo box (barcode): card của box 2 → 3 qua wms.usp_oqc_return.
        public async Task<OqcOkResponse> ReturnAsync(OqcReturnRequest request)
        {
            var iso = RequireIsoDate(request.ProductionDate);
            await _repo.ReturnAsync(request.Model.Trim(), iso, request.Payload, _currentUser.FullName);
            return new OqcOkResponse("ok");
        }

        public async Task<OqcOkResponse> UpdateStatusAsync(OqcUpdateStatusRequest request)
        {
            var code = OqcStatusCode.FromString(request.Status)
                ?? throw new BusinessRuleException(
                    _localizer[OqcErrors.StatusInvalid, request.Status ?? ""]);

            await _repo.UpdateStatusAsync(request.Model.Trim(), code, request.LotName, _currentUser.FullName);

            return new OqcOkResponse("ok");
        }

        // SP dùng CONVERT(date, @x) theo ISO -> chuẩn hoá về yyyy-MM-dd trước khi gọi.
        private string RequireIsoDate(string? raw)
        {
            if (!TryParseDate(raw, out var d))
                throw new BusinessRuleException(_localizer[OqcErrors.ProductionDateInvalid, raw ?? ""]);
            return d.ToString("yyyy-MM-dd");
        }

        private static bool TryParseDate(string? raw, out DateTime date)
            => DateTime.TryParseExact(
                (raw ?? "").Trim(), DateFormats, CultureInfo.InvariantCulture,
                DateTimeStyles.None, out date);
    }
}