using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.Foss.PalletSync.Business;
using Swms.FinishGoods.API.Features.Pallets.Api;

namespace Swms.FinishGoods.API.Features.Foss.PalletSync.Api
{
    /// <summary>
    /// Đồng bộ Foss -> pallet SWMS. Tách khỏi PalletController nhưng giữ prefix
    /// api/pallets nên PDA / Web không phải đổi URL.
    /// </summary>
    [ApiController]
    [Route("api/pallets")]
    public class PalletFossController : ControllerBase
    {
        private readonly IPalletFossSyncService _service;
        public PalletFossController(IPalletFossSyncService service) => _service = service;

        /// <summary>
        /// Tạo lot từ dữ liệu Foss theo mã quét, trả về đúng shape của GET by-lot-no.
        /// Trước đây việc tạo này nằm ẩn trong GET .../location — tách ra thành POST
        /// vì đây là thao tác ghi (GET phải idempotent) và cần quyền tạo lot.
        /// Idempotent: lot đã tồn tại thì chỉ bổ sung thùng còn thiếu rồi trả về.
        /// PDA: gọi GET trước, gặp 404 thì gọi endpoint này.
        /// </summary>
        [HttpPost("by-lot-no/{lotNo}/from-foss")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<PalletDetailResponse>> CreateFromFoss(
            string lotNo, [FromQuery] string? include)
            => Ok(await _service.CreateFromFossAsync(lotNo, PalletIncludeParser.Parse(include)));

        /// <summary>
        /// Bổ sung thùng / serial còn thiếu từ Foss cho pallet đã có trong SWMS
        /// (SWMS tạo pallet khi Foss chưa đóng xong).
        /// </summary>
        /// <response code="200">Đã bổ sung (hoặc không còn gì thiếu — xem boxesAdded).</response>
        /// <response code="404">Pallet không có trong SWMS hoặc không có trên Foss.</response>
        /// <response code="422">Pallet box_count / thẻ in / đã xuất — không bổ sung từ Foss.</response>
        [HttpPost("by-lot-no/{lotNo}/foss-top-up")]
        public async Task<ActionResult<FossTopUpResponse>> TopUpFromFoss(
            string lotNo, [FromQuery] PalletInclude include)
            => Ok(await _service.TopUpFromFossAsync(lotNo, include));

        /// <summary>
        /// Đồng bộ trạng thái OQC của pallet. Nguồn theo từng thùng:
        /// payload "Card_ID=..." -> part_cards.Status_OQC, còn lại -> Foss STATUS_FA.
        /// Trả về cùng shape GET by-lot-no.
        /// </summary>
        [HttpPost("by-lot-no/{lotNo}/oqc-sync")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<PalletDetailResponse>> SyncOqc(
            string lotNo, [FromQuery] string? include)
            => Ok(await _service.SyncOqcStatusAsync(lotNo, PalletIncludeParser.Parse(include)));
    }
}
