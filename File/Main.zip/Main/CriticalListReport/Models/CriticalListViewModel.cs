﻿namespace CriticalListReport.Models
{
    public class CriticalListViewModel
    {
        public List<CriticalItem> Items { get; set; }
        public int TotalCount { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
        public string? Plant { get; set; }
        public string? PartNo { get; set; }
        public string? VendorCode { get; set; }
        public string? PIC { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public string? DataType { get; set; }
        public bool Cos { get; set; }
    }
}
