namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

// Cọc + xếp cont trên PDA theo Stowage Plan của chuyến. Tên property khớp alias SQL của TripStowageRepository.

public static class TripStowageRules
{
    /// <summary>"C07" -> 7: số cọc dùng làm unit_no ảnh "Cọc pallet". Mã không có số -> 0.</summary>
    public static int CocNoOf(string? code)
    {
        var digits = new string((code ?? "").Where(char.IsDigit).ToArray());
        return int.TryParse(digits, out var n) ? n : 0;
    }
}

/// <summary>Plan + container của chuyến (stowage_plan_containers.trip_id).</summary>
public class TripPlanRow
{
    public long PlanId { get; set; }
    public string PlanNo { get; set; } = "";
    public string Status { get; set; } = "";
    public string ShipMode { get; set; } = "";
    public string ContainerType { get; set; } = "";
    public int ContainerIndex { get; set; }
}

/// <summary>1 tầng của 1 cọc trong plan (cọc chưa có pallet thì Tier = 0, các cột pallet NULL).
/// Chỉ cọc đã đặt vào container của chuyến (container_index = của chuyến).</summary>
public class PlanColumnRow
{
    public long ColumnId { get; set; }
    public string Code { get; set; } = "";
    public int? RowNo { get; set; }
    public int? LaneNo { get; set; }
    public int Tier { get; set; }
    public string? PlanPalletCode { get; set; }
    public long? SiId { get; set; }
    public string? SiNo { get; set; }
    public string? PalletSize { get; set; }
}

/// <summary>Kết quả ghi cọc đã ghép.</summary>
public enum StackSaveResult
{
    Ok,
    /// <summary>Cọc đã xếp vào cont — phải gỡ xếp trước khi ghép lại.</summary>
    Placed,
    /// <summary>1 trong 2 pallet đã nằm ở cọc khác của chuyến.</summary>
    PalletUsed,
}

/// <summary>Pallet soạn (stowage_pallets) của plan đang chứa thùng nằm trên 1 pallet thật.
/// Matched = số thùng của pallet thật thuộc pallet soạn này.</summary>
public class PlanPalletMatchRow
{
    public long StowagePalletId { get; set; }
    public string Code { get; set; } = "";
    public string? SiNo { get; set; }
    public string? PalletSize { get; set; }
    public string? ColumnCode { get; set; }
    public int Tier { get; set; }
    public int Matched { get; set; }
}

/// <summary>1 thùng của pallet soạn, đúng thứ tự Web lưu (BoxNos = stowage_pallet_boxes ORDER BY id).
/// BoxId null = chưa có box thật (thùng dự kiến / SI chưa lấy hàng).</summary>
public class PlanPalletBoxRow
{
    public long PlanBoxId { get; set; }
    public long? SiBoxId { get; set; }
    public string? PlanBoxNo { get; set; }
    public string? SiNo { get; set; }
    public int? LineNo { get; set; }
    public int? CartonSeq { get; set; }
    public string? Model { get; set; }
    public bool IsEstimated { get; set; }
    public long? BoxId { get; set; }
    public string? BoxNo { get; set; }
    public long? PalletId { get; set; }
    public string? PalletCode { get; set; }
    public string? LocatorCode { get; set; }
    /// <summary>Tổng số thùng đang nằm trên pallet thật chứa thùng này.</summary>
    public int PalletBoxCount { get; set; }
    public int Pcs { get; set; }
}

/// <summary>1 thùng thật đang nằm trên pallet.</summary>
public class PalletBoxRow
{
    public long Id { get; set; }
    public string BoxNo { get; set; } = "";
}