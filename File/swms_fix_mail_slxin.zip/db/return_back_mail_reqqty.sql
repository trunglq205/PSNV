/* ============================================================================
   Sửa mẫu thư RETURN_BACK_FA_APPROVED: "số lượng cần giao" phải là SL FA XIN
                                                                       (11/11)
   VẤN ĐỀ:
     Mẫu thư viết ngày 09/11, lúc đó "đã đề nghị là lấy hết" nên nó dùng
     {RemainQty} (SL CÒN Ở KHO) làm "Số lượng cần giao", và {LinesTable}
     (bảng tồn kho) làm chi tiết theo model.

     Ngày 10/11 nghiệp vụ đổi: FA xin được MỘT PHẦN, số đó nằm ở
     wms.return_back_lines. Mẫu thư KHÔNG được sửa theo. Hậu quả: FA xin 20 con
     trên 500 con đang ở kho thì thư vẫn báo quản lý SCS "số lượng cần giao:
     500" — sai hẳn con số mà cả hai bên dùng để chuẩn bị hàng.

   BẢN SỬA DÙNG HAI BIẾN MỚI (API 11/11 trở đi):
     {ReqQty}        SL FA xin — con số CẦN GIAO
     {ReqLinesTable} bảng model + SL FA xin

     {RemainQty} / {LinesTable} GIỮ NGUYÊN ý nghĩa cũ (tồn kho) và vẫn dùng
     được, nhưng từ nay chỉ để tham chiếu, không phải con số cần giao.

     Phiếu không khai dòng nào = xin toàn bộ phần còn ở kho (nghĩa cũ, và mọi
     phiếu trước 10/11 đều không có dòng). Lúc đó {ReqQty} = {RemainQty}, nên
     thư của phiếu cũ vẫn đọc đúng như trước.

   ⚠ PHẢI DEPLOY API TRƯỚC. Chạy script này trên bản API cũ thì thư in ra chuỗi
     "{ReqQty}" nguyên văn.

   CHẠY:
     @WhatIf = 1 (mặc định) chỉ IN RA mẫu hiện tại, KHÔNG ghi.
     Nếu mẫu đã bị sửa tay thì xem bản in, chép lại phần sửa của mình vào, rồi
     mới đặt @WhatIf = 0.
   ========================================================================= */

SET NOCOUNT ON;

DECLARE @WhatIf bit = 1;        -- <<< đổi thành 0 để ghi thật

DECLARE @code NVARCHAR(100) = N'RETURN_BACK_FA_APPROVED';

IF NOT EXISTS (SELECT 1 FROM master.email_events WHERE code = @code)
BEGIN
    PRINT N'Khong co su kien ' + @code + N' trong master.email_events.';
    PRINT N'Chay return_back_merge_schema.sql truoc.';
    RETURN;
END

/* ---------- 1. In mẫu hiện tại ---------- */

DECLARE @oldSubj NVARCHAR(500), @oldBody NVARCHAR(MAX), @upd DATETIME2(0);

SELECT  @oldSubj = subject_template,
        @oldBody = body_template,
        @upd     = updated_at
FROM    master.email_events
WHERE   code = @code;

PRINT N'--- MAU HIEN TAI ---';
PRINT N'updated_at = ' + ISNULL(CONVERT(NVARCHAR(30), @upd, 120), N'NULL (chua ai sua tay)');
PRINT N'';
PRINT N'[subject]';
PRINT @oldSubj;
PRINT N'';
PRINT N'[body]';
PRINT @oldBody;
PRINT N'';

IF @upd IS NOT NULL
BEGIN
    PRINT N'>>> CANH BAO: mau nay DA BI SUA TAY.';
    PRINT N'>>> Script se GHI DE. Chep lai phan sua cua minh tu ban in o tren';
    PRINT N'>>> truoc khi dat @WhatIf = 0.';
    PRINT N'';
END

/* ---------- 2. Mẫu mới ---------- */

DECLARE @subj NVARCHAR(500) =
    N'[SWMS] FA đề nghị nhận lại hàng {GoodsType} — chỉ thị {DocNo} ({ReqQty} con)';

DECLARE @body NVARCHAR(MAX) = N'Kính gửi SCS Office,

Quản lý FA đã xác nhận đề nghị nhận lại hàng của chỉ thị **{DocNo}**.
Nhờ SCS thông báo kho chuẩn bị giao **{ReqQty}** con.

| Thông tin | Nội dung |
|---|---|
| Chỉ thị nhận hàng | **{DocNo}** ({GoodsType}) |
| Khách hàng | {Customer} |
| Số model | {ModelCount} |
| **Số lượng cần giao** | **{ReqQty}** |
| SL còn ở kho | {RemainQty} |
| Người đề nghị | {RequestedBy} — {RequestedAt} |
| Quản lý FA xác nhận | {ApprovedBy} — {ApprovedAt} |

**Chi tiết FA xin theo model:**
{ReqLinesTable}
Ghi chú của FA: {BackNote}

Ý kiến quản lý FA: {FaComment}

Hàng chỉ được out kho sau khi quản lý SCS duyệt.

Xem trên hệ thống: {Link}

*Mail tự động từ SWMS Finish Goods — {Now}*';

PRINT N'--- MAU MOI ---';
PRINT N'[subject]';
PRINT @subj;
PRINT N'';
PRINT N'[body]';
PRINT @body;
PRINT N'';

/* ---------- 3. Ghi ---------- */

IF @WhatIf = 1
BEGIN
    PRINT N'@WhatIf = 1 — KHONG ghi gi. Dat @WhatIf = 0 roi chay lai.';
END
ELSE
BEGIN
    UPDATE  master.email_events
    SET     subject_template = @subj,
            body_template    = @body,
            updated_at       = SYSDATETIME(),
            updated_by       = N'migrate 11/11'
    WHERE   code = @code;

    PRINT N'Da cap nhat mau thu ' + @code + N'.';
END
GO
