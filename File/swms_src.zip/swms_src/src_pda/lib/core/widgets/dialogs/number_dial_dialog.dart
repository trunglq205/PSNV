import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';

/// Dialog nhập số bằng bàn phím số. Trả về null nếu huỷ.
///
/// Giá trị trả về là [int] khi [decimalDigits] = 0, ngược lại là [double].
///
/// Mở lên, giá trị cũ được "chọn sẵn": bấm số đầu tiên là gõ đè, bấm xoá là
/// sửa tiếp từ giá trị cũ.
///
/// Nút Xác nhận bị khoá khi ô trống hoặc giá trị ngoài [minValue]–[maxValue],
/// kèm dòng nhắc trần/sàn.
Future<num?> showNumberDialDialog(
    BuildContext context, {
      required String title,
      required num value,
      String? unit,
      int decimalDigits = 0,
      num minValue = 0,
      num? maxValue,
    }) {
  return showAppDialog<num>(
    context,
    builder: (_) => _NumberPadDialog(
      title: title,
      initialValue: value,
      unit: unit,
      decimalDigits: decimalDigits,
      minValue: minValue,
      maxValue: maxValue,
    ),
  );
}

class _NumberPadDialog extends StatefulWidget {
  const _NumberPadDialog({
    required this.title,
    required this.initialValue,
    required this.decimalDigits,
    required this.minValue,
    this.unit,
    this.maxValue,
  });

  final String title;
  final num initialValue;
  final String? unit;
  final int decimalDigits;
  final num minValue;
  final num? maxValue;

  @override
  State<_NumberPadDialog> createState() => _NumberPadDialogState();
}

class _NumberPadDialogState extends State<_NumberPadDialog> {
  late String _text = _format(widget.initialValue);

  /// true = đang hiện giá trị cũ, phím số đầu tiên sẽ gõ đè.
  bool _fresh = true;

  bool get _hasDecimal => widget.decimalDigits > 0;

  /// Số chữ số phần nguyên tối đa — theo trần, không có trần thì 7.
  int get _maxIntDigits => widget.maxValue == null
      ? 7
      : widget.maxValue!.truncate().abs().toString().length;

  String _format(num v) => v.toStringAsFixed(widget.decimalDigits);

  num? get _value {
    if (_text.isEmpty) return null;
    final d = double.tryParse(_text);
    if (d == null) return null;
    return _hasDecimal ? d : d.truncate();
  }

  /// Dòng nhắc khi ngoài khoảng, null nếu hợp lệ (hoặc đang trống).
  String? _hint(num? v) {
    if (v == null) return null;
    final unit = widget.unit == null ? '' : ' ${widget.unit}';
    if (v < widget.minValue) {
      return LocaleKeys.common_value_min.tr(
        namedArgs: {'value': '${_format(widget.minValue)}$unit'},
      );
    }
    if (widget.maxValue != null && v > widget.maxValue!) {
      return LocaleKeys.common_value_max.tr(
        namedArgs: {'value': '${_format(widget.maxValue!)}$unit'},
      );
    }
    return null;
  }

  // ── Phím ───────────────────────────────────────────────────
  /// Tính chuỗi mới từ [base]; null = phím không có tác dụng (đủ chữ số…).
  void _type(String? Function(String base) edit) {
    final next = edit(_fresh ? '' : _text);
    if (next == null) return;
    setState(() {
      _text = next;
      _fresh = false;
    });
  }

  void _digit(String d) => _type((t) {
    final dot = t.indexOf('.');
    if (dot >= 0) {
      return t.length - dot - 1 < widget.decimalDigits ? t + d : null;
    }
    if (t == '0') t = ''; // bỏ số 0 đầu
    return t.length < _maxIntDigits ? t + d : null;
  });

  void _dot() => _type((t) {
    if (t.contains('.')) return null;
    return t.isEmpty ? '0.' : '$t.';
  });

  void _clear() => setState(() {
    _text = '';
    _fresh = false;
  });

  void _backspace() => setState(() {
    _fresh = false;
    if (_text.isNotEmpty) _text = _text.substring(0, _text.length - 1);
  });

  @override
  Widget build(BuildContext context) {
    final value = _value;
    final hint = _hint(value);
    final canConfirm = value != null && hint == null;

    return AppDialog(
      title: widget.title,
      maxTextScaleFactor: 1.3,
      actions: [
        AppDialogAction.cancel(context),
        AppDialogAction.confirm(
          onPressed: canConfirm ? () => Navigator.pop(context, value) : null,
        ),
      ],
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _Display(text: _text, unit: widget.unit, fresh: _fresh),
          // Chỗ trống cố định: dòng nhắc hiện/ẩn không làm dialog nhảy.
          SizedBox(
            height: 18,
            child: hint == null
                ? null
                : Text(
              hint,
              textAlign: TextAlign.center,
              style: AppTextStyles.caption.copyWith(
                color: context.swms.danger,
                fontWeight: FontWeight.w700,
              ),
            ),
          ),
          const SizedBox(height: AppDimens.xs),
          _pad(),
        ],
      ),
    );
  }

  Widget _pad() {
    Widget digitRow(List<String> digits) => _PadRow(
      children: [
        for (final d in digits)
          _PadKey(label: d, onTap: () => _digit(d)),
      ],
    );

    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        digitRow(const ['1', '2', '3']),
        digitRow(const ['4', '5', '6']),
        digitRow(const ['7', '8', '9']),
        _PadRow(
          children: [
            // Có thập phân → phím ".", không thì phím xoá hết.
            _hasDecimal
                ? _PadKey(label: '.', onTap: _dot)
                : _PadKey(label: 'C', muted: true, onTap: _clear),
            _PadKey(label: '0', onTap: () => _digit('0')),
            _PadKey(
              icon: Icons.backspace_outlined,
              muted: true,
              onTap: _text.isEmpty ? null : _backspace,
            ),
          ],
        ),
      ],
    );
  }
}

/// Ô hiển thị giá trị đang nhập.
class _Display extends StatelessWidget {
  const _Display({required this.text, required this.fresh, this.unit});

  final String text;
  final bool fresh;
  final String? unit;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final empty = text.isEmpty;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.end,
        crossAxisAlignment: CrossAxisAlignment.baseline,
        textBaseline: TextBaseline.alphabetic,
        children: [
          // Nền tint = giá trị cũ đang được "chọn", gõ số là đè.
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            decoration: BoxDecoration(
              color: fresh && !empty ? swms.primaryTint : null,
              borderRadius: BorderRadius.circular(6),
            ),
            child: Text(
              empty ? '0' : text,
              style: AppTextStyles.code.copyWith(
                fontSize: 30,
                fontWeight: FontWeight.w900,
                color: empty ? swms.text4 : swms.text1,
              ),
            ),
          ),
          if (unit != null) ...[
            const SizedBox(width: 6),
            Text(
              unit!,
              style: AppTextStyles.caption.copyWith(
                fontWeight: FontWeight.w700,
                color: swms.text3,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _PadRow extends StatelessWidget {
  const _PadRow({required this.children});

  final List<Widget> children;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.xs),
      child: Row(
        children: [
          for (var i = 0; i < children.length; i++) ...[
            if (i > 0) const SizedBox(width: AppDimens.xs),
            Expanded(child: children[i]),
          ],
        ],
      ),
    );
  }
}

/// Phím bàn số — cao [AppDimens.hitLg] cho bấm bằng găng tay.
class _PadKey extends StatelessWidget {
  const _PadKey({this.label, this.icon, this.onTap, this.muted = false})
      : assert(label != null || icon != null);

  final String? label;
  final IconData? icon;
  final VoidCallback? onTap;

  /// Phím chức năng (C / xoá): nền nhạt, chữ nhạt hơn phím số.
  final bool muted;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final enabled = onTap != null;
    final fg = !enabled ? swms.text4 : (muted ? swms.text2 : swms.text1);

    return Material(
      color: muted ? swms.card2 : swms.card,
      borderRadius: BorderRadius.circular(AppDimens.rBtn),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
        child: Container(
          height: AppDimens.hitLg,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppDimens.rBtn),
            border: Border.all(color: swms.border),
          ),
          child: icon != null
              ? Icon(icon, size: 22, color: fg)
              : Text(
            label!,
            style: AppTextStyles.code.copyWith(
              fontSize: 22,
              fontWeight: FontWeight.w800,
              color: fg,
            ),
          ),
        ),
      ),
    );
  }
}