import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/part_card/data/models/part_card_response_model.dart';
import 'package:swms_finish_goods/features/part_card/data/models/print_history_request_model.dart';
import 'package:swms_finish_goods/features/part_card/data/models/split_merge_request_model.dart';

part 'part_card_remote_data_source.g.dart';

@RestApi()
abstract class PartCardRemoteDataSource {
  factory PartCardRemoteDataSource(Dio dio, {String baseUrl}) =
  _PartCardRemoteDataSource;

  /// GET lịch sử in theo model (mới nhất trước) — dùng để gợi ý hộp.
  @GET('/api/part-cards/print-history')
  Future<PartCardHistoryPageModel> getPrintHistory(
      @Query('model') String model,
      @Query('page') int page,
      @Query('size') int size,
      );

  /// GET phiếu theo đúng payload QR (khớp tuyệt đối) — tìm id của phiếu cũ
  /// cần sửa.
  @GET('/api/part-cards/print-history')
  Future<PartCardHistoryPageModel> findByPayload(
      @Query('payload') String payload,
      @Query('page') int page,
      @Query('size') int size,
      );

  /// PUT sửa toàn bộ 1 phiếu đã in (body giống lúc lưu).
  @PUT('/api/part-cards/print-history/{id}')
  Future<PartCardResponseModel> updatePrintHistory(
      @Path('id') int id,
      @Body() PrintHistoryRequestModel body,
      );

  /// POST lưu lịch sử in — 1 hoặc nhiều phiếu trong 1 lần gọi
  /// (bấm "In" xong mới gọi).
  @POST('/api/part-cards/print-history/bulk')
  Future<List<PartCardResponseModel>> savePrintHistoryBulk(
      @Body() List<PrintHistoryRequestModel> body,
      );

  /// POST tách 1 tem 1 mã thành N tem — tạo mới + huỷ tem nguồn (1 transaction).
  @POST('/api/part-cards/split')
  Future<List<PartCardResponseModel>> splitPrintHistory(
      @Body() SplitPrintRequestModel body,
      );

  /// POST gộp N tem thành 1 tem nhiều mã — tạo mới + huỷ tem nguồn
  /// (1 transaction).
  @POST('/api/part-cards/merge')
  Future<PartCardResponseModel> mergePrintHistory(
      @Body() MergePrintRequestModel body,
      );
}