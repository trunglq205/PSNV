﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.Data.OleDb;
using System.Data.SqlClient;


namespace DectShrinkV2
{
    public partial class frmUploadMasterPallet : Form
    {
        ConnectSQL conn = new ConnectSQL();
        public frmUploadMasterPallet(string id )
        {
            
            //this.id = id;

            InitializeComponent();
            lblUser.Text = id;
            //sender = new sendID();
        }

        

        


        public DataTable exceldata(string part)
        //public DataTable exceldata()
        
        {
            //string _sheet = "select * from[" + cmbNames.Text.Trim() + "$]";
            String sConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0; Data Source='" + part + "'; Extended Properties =Excel 8.0;";
            OleDbConnection objConn = new OleDbConnection(sConnectionString);
            objConn.Open();
            //OleDbCommand objCmdSelect = new OleDbCommand("SELECT * from [Email for register$A8:I50]", objConn);
            // OleDbCommand objCmdSelect = new OleDbCommand("SELECT * from [Shipment Plan(PSCS)$C4:L]", objConn); //Plant
            OleDbCommand objCmdSelect = new OleDbCommand("select * from[Sheet1$]", objConn);// ModelFA_DIP

            OleDbDataAdapter objAdapter1 = new OleDbDataAdapter();
            objAdapter1.SelectCommand = objCmdSelect;
            DataTable objDataset1 = new DataTable();
            objAdapter1.Fill(objDataset1);
            objConn.Close();
            return objDataset1;

        }

        private void btnBrrow_Click(object sender, EventArgs e)
        {
            OpenFileDialog fdlg = new OpenFileDialog();
            fdlg.Title = "Open";
            fdlg.InitialDirectory = @"C:\";
            fdlg.Filter = "All File (*.xlsx)|*.xlsx|All files (*.xls)|*.*";
            fdlg.FilterIndex = 2;
            fdlg.RestoreDirectory = true;
            if (fdlg.ShowDialog() == DialogResult.OK)
            {
                textBox1.Text = fdlg.FileName;
                DataTable ds = new DataTable();
                ds = exceldata(textBox1.Text);

               // ds = exceldata();
                dataGridView1.DataSource = ds;

                //LoadSheetsName(textBox1.Text.Trim());
            }
        }

        private void frmUploadMasterPallet_Load(object sender, EventArgs e)
        {
            
        }

        private void btnUpload_Click(object sender, EventArgs e)
        {


           
            //try
            //{
                if (dataGridView1.Rows.Count == 0)
                {
                    MessageBox.Show("Bạn chưa chọn đúng file Upload");
                    return;
                }
                else
                {
                    //_uploadstd.Delete();
                    for (int i = 0; i < dataGridView1.Rows.Count; i++)
                    {
                        if (dataGridView1[0, i].Value!= null)
                        {
                            string _sModelNo = dataGridView1[0, i].Value.ToString().Trim();
                            string _SModelName = dataGridView1[1, i].Value.ToString().Trim();
                            string _QuantityStd = dataGridView1[2, i].Value.ToString().Trim();
                            string _sUsername = lblUser.Text;
                            string _sCreateBy = lblUser.Text;
                            string _sModifiedBy = "";
                            string _dCreated = "";
                            string _dModified = "";
                            //conn.TableWithParameter(_sModelNo, _SModelName, Convert.ToInt16(_QuantityStd), _sUsername, _sCreateBy, _sModifiedBy, DateTime.Now, DateTime.Now);

                            string[] arrParam = { "@sModelNo", "@SModelName", "@QuantityStd", "@sUsername", "@sCreateBy", "@sModifiedBy", "dCreated", "@dModified" };
                            object[] arrValue = { _sModelNo, _SModelName, Convert.ToInt16(_QuantityStd), _sUsername, _sCreateBy, _sModifiedBy, DateTime.Now, DateTime.Now };

                            DataTable dt = conn.TableWithParameter("TBLSHRINKSTD_add", arrParam, arrValue);
                        }
                        //MessageBox.Show("Success");
                    
                    //frmUploadSTD_Load(sender, e);
                }
                    DialogResult result=MessageBox.Show("Success","Thông báo",MessageBoxButtons.OKCancel);
                    if(result ==DialogResult.OK)

                    {
                        MainFunction frmMain = new MainFunction(lblUser.Text);
                        frmMain.Show();
                        this.Hide();

                    }
            }
            //catch
            //{
            //    MessageBox.Show("Không đúng định dạng file Upload", "Message");
            //}
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }



    }
}
