import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/mini_card.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/pin_button.dart';

/// Một cụm chức năng: header (số + tên + đếm + ghim) và lưới mini-card 2 cột.
class GroupSection extends StatelessWidget {
  final int index;
  final FeatureGroup group;
  final bool pinned;
  final VoidCallback onTogglePin;
  final void Function(FeatureItem)? onTapItem;

  const GroupSection({
    super.key,
    required this.index,
    required this.group,
    required this.pinned,
    required this.onTogglePin,
    this.onTapItem,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      child: Column(
        children: [
          // Header cụm
          Row(
            children: [
              Container(
                width: 18,
                height: 18,
                decoration: BoxDecoration(
                  color: group.toneBg,
                  borderRadius: BorderRadius.circular(4),
                ),
                alignment: Alignment.center,
                child: Text(
                  '$index',
                  style: AppTextStyles.caption.copyWith(
                    color: group.tone,
                    fontWeight: FontWeight.w800,
                    fontSize: 10,
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Row(
                  children: [
                    Flexible(
                      child: Text(
                        group.titleKey.tr(),
                        style: AppTextStyles.bodyStrong.copyWith(
                          color: swms.text1,
                        ),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                      ),
                    ),
                    const SizedBox(width: 8),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 6,
                        vertical: 1,
                      ),
                      decoration: BoxDecoration(
                        color: Theme.of(context).scaffoldBackgroundColor,
                        borderRadius: BorderRadius.circular(8),
                      ),
                      child: Text(
                        '${group.items.length}',
                        style: AppTextStyles.caption.copyWith(
                          color: swms.text3,
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 4),
              PinButton(
                pinned: pinned,
                tone: group.tone,
                onTap: onTogglePin,
              ),
            ],
          ),
          const SizedBox(height: 4),
          // Lưới mini-card 2 cột
          LayoutBuilder(
            builder: (context, c) {
              const gap = AppDimens.sm;
              final w = (c.maxWidth - gap) / 2;
              return Wrap(
                spacing: gap,
                runSpacing: gap,
                children: [
                  for (final it in group.items)
                    SizedBox(
                      width: w,
                      child: MiniCard(
                        item: it,
                        tone: group.tone,
                        toneBg: group.toneBg,
                        onTap: () => onTapItem?.call(it),
                      ),
                    ),
                ],
              );
            },
          ),
        ],
      ),
    );
  }
}
