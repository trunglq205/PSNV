/// Tóm tắt 1 phiếu kiểm kê (danh sách).
class CountSummary {
  final int id;
  final String docNo;
  final String? countType; // morning | monthly | shipment
  final DateTime countDate;
  final String docStatus;  // pending | counting | closed
  final String? description;
  final int totalLines;
  final int countedLines;
  final int discrepancyLines;

  const CountSummary({
    required this.id,
    required this.docNo,
    required this.countType,
    required this.countDate,
    required this.docStatus,
    required this.description,
    required this.totalLines,
    required this.countedLines,
    required this.discrepancyLines,
  });

  double get progress => totalLines == 0 ? 0 : countedLines / totalLines;
}

/// 1 dòng kiểm kê = 1 pallet tại 1 vị trí.
class CountLine {
  final int id;
  final int lineNo;
  final int productId;
  final String? productName;
  final int locatorId;
  final String locatorCode;
  final int? lotId;
  final String? palletId;
  final String? model;
  final int qtySystem;
  final int? qtyCount;

  /// Số box theo hệ thống. Số lượng = box x [standardPacking].
  final int? boxCountSystem;

  /// Số box người kiểm đếm được tại ô.
  final int? boxCountCounted;

  /// Quy cách đóng gói (số cái/box) chụp từ master.models lúc tạo phiếu.
  /// null hoặc 0 = model chưa khai quy cách, phải nhập thẳng số lượng.
  final int? standardPacking;

  /// Thứ tự đi kiểm kê theo bản đồ (1 = kiểm đầu tiên). Server đã tính sẵn.
  final int walkSeq;
  final String? areaCode;
  final String? areaName;

  /// Pallet phát sinh: tìm thấy ở ô này khi kiểm, hệ thống ghi ở [systemLocatorCode].
  final bool isFound;
  final String? systemLocatorCode;

  const CountLine({
    required this.id,
    required this.lineNo,
    required this.productId,
    required this.productName,
    required this.locatorId,
    required this.locatorCode,
    required this.lotId,
    required this.palletId,
    required this.model,
    required this.qtySystem,
    required this.qtyCount,
    this.boxCountSystem,
    this.boxCountCounted,
    this.standardPacking,
    this.walkSeq = 0,
    this.areaCode,
    this.areaName,
    this.isFound = false,
    this.systemLocatorCode,
  });

  /// Dòng "ô trống" (kiểm cuối tháng theo ô): hệ thống không có pallet nào ở ô này.
  bool get isEmptySlot => lotId == null;

  bool get isCounted => qtyCount != null;
  bool get isDiscrepancy => qtyCount != null && qtyCount != qtySystem;

  /// Đếm được theo box: model đã khai quy cách thì chỉ cần đếm số box,
  /// hệ thống tự nhân ra số lượng.
  bool get hasPacking => (standardPacking ?? 0) > 0;
}

class CountDetail {
  final CountSummary header;
  final List<CountLine> lines;
  const CountDetail({required this.header, required this.lines});
}
