﻿using Swms.FinishGoods.API.Features.OqcSamples.Business.Entities;

namespace Swms.FinishGoods.API.Features.OqcSamples.DataAccess
{
    /// <summary>Toàn bộ SQL nằm trong stored procedure (wms.usp_oqc_*); repo chỉ gọi SP.</summary>
    public interface IOqcSampleRepository
    {
        /// <summary>wms.usp_oqc_get_locations(@model,@production_date,@payload). Null nếu không có.</summary>
        Task<PalletLocationResult?> GetLocationAsync(
            string model, DateTime? productionDate, string? payload);

        /// <summary>wms.usp_oqc_sample(@model,@production_date,@line,@lot_name,@user,@barcode). Trả 1/0.</summary>
        Task<int> SampleAsync(
            string model, string productionDate, string? lotName, string? user,
            string? barcode, string? line = null);

        /// <summary>wms.usp_oqc_return(@model,@user,@barcode). Trả số card đã trả.</summary>
        Task<int> ReturnAsync(string model, string productionDate, string? barcode, string? user);

        /// <summary>wms.usp_oqc_update_status(@model,@status,@lot_name,@user). Trả 1.</summary>
        Task<int> UpdateStatusAsync(string model, int statusCode, string? lotName, string? user);
    }
}