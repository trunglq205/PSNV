/* ============================================================================
   Soi: bản đồ khu Nhận hàng có dữ liệu để vẽ dấu RW/RB không?        (12/11)

   CHỈ ĐỌC. Trả về ĐÚNG những gì câu SQL của bản đồ tính ra, cho mọi pallet
   đang nằm ở các khu có map_type = 'receiving'.

   ĐỌC CỘT CUỐI (`api_tra_ve`):
     · 'rework' / 'refurbish'  -> API trả dấu. Không thấy dấu trên màn hình thì
                                  lỗi nằm ở bản build đang chạy (Web/API chưa
                                  deploy) hoặc cache js/css của trình duyệt.
     · NULL                    -> API không có gì để trả. Pallet này vừa KHÔNG
                                  có dấu `disposition`, vừa KHÔNG có dòng serial
                                  nào của phiếu back trỏ vào.
                                  Xem hai cột trước nó để biết thiếu bên nào.
   ========================================================================= */

SET NOCOUNT ON;

SELECT      a.area_name                AS khu,
            loc.locator_code           AS vi_tri,
            RTRIM(p.pallet_id)         AS pallet_id,
            p.inspection_status        AS trang_thai_kiem,

            /* 1. Dấu đóng trên chính pallet. */
            p.disposition              AS cot_dau,

            /* 2. Loại hàng của phiếu back đang giữ serial trên pallet này —
                  chỗ để lùi về khi cột dấu rỗng. */
            rb.goods_type              AS lui_ve_phieu,
            rb.doc_no                  AS phieu,
            rb.so_serial               AS so_serial_cua_phieu,

            /* 3. Thứ API THẬT SỰ trả ra cho bản đồ. */
            COALESCE(p.disposition, rb.goods_type) AS api_tra_ve

FROM        wms.pallets p
JOIN        master.locators loc
            ON loc.id = p.locator_id AND loc.is_deleted = 0
JOIN        master.warehouse_areas a
            ON a.id = loc.area_id AND a.is_deleted = 0
           AND a.map_type = N'receiving'
OUTER APPLY (
    SELECT TOP 1
           d.goods_type AS goods_type,
           d.doc_no     AS doc_no,
           (SELECT COUNT(*) FROM wms.return_instruction_serials s2
            WHERE s2.pallet_id = p.id AND s2.is_deleted = 0) AS so_serial
    FROM   wms.return_instruction_serials ris
    JOIN   wms.return_instructions d
           ON d.id = ris.doc_id AND d.is_deleted = 0
    WHERE  ris.pallet_id = p.id
      AND  ris.is_deleted = 0
    ORDER BY ris.id DESC
) rb
WHERE       p.is_deleted = 0
ORDER BY    a.area_name, loc.locator_code, p.pallet_id;
