using Dapper;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

public class TripVanningRepository : ITripVanningRepository
{
    private readonly IDbConnectionFactory _factory;
    public TripVanningRepository(IDbConnectionFactory factory) => _factory = factory;

    // ═══════════════════════════════════════════════════════════════
    //  Kiểm container
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripInspectionRow?> GetLatestInspectionAsync(long tripId)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<TripInspectionRow>("""
            SELECT TOP 1 id AS Id, trip_id AS TripId, result AS Result, passed_conditions AS PassedConditions,
                   note AS Note, container_no AS ContainerNo, inspected_at AS InspectedAt, inspected_by AS InspectedBy
            FROM wms.shipment_trip_inspections
            WHERE trip_id = @tripId
            ORDER BY id DESC;
            """, new { tripId });
    }

    public async Task<long> AddInspectionAsync(TripInspectionRow r)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<long>("""
            INSERT INTO wms.shipment_trip_inspections
                (trip_id, result, passed_conditions, note, container_no, inspected_at, inspected_by)
            OUTPUT INSERTED.id
            VALUES (@TripId, @Result, @PassedConditions, @Note, @ContainerNo, SYSDATETIME(), @InspectedBy);
            """, r);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Pallet / thùng thuộc chuyến
    // ═══════════════════════════════════════════════════════════════

    /*  "Thuộc chuyến" = pallet được phân cho 1 dòng của 1 SI đang gắn chuyến
        (shipment_instruction_pallets, chưa skipped), HOẶC đã dùng làm Pallet List của
        chuyến (shipment_trip_pallets — pallet gốc rỗng lấy ra để gộp, không thuộc SI nào).
        Cùng 1 điều kiện cho gợi ý gộp, tra pallet lẻ, tra thùng, ghép cọc và ảnh theo pallet
        — lệch nhau là PDA gợi ý 1 đằng, server chặn 1 nẻo.                                  */
    private const string InScopePalletSql = """
        (EXISTS (SELECT 1
                 FROM wms.shipment_trip_sis ts
                 JOIN wms.shipment_instruction_lines sl ON sl.si_id = ts.si_id
                 JOIN wms.shipment_instruction_pallets sp ON sp.line_id = sl.id
                 WHERE ts.trip_id = @tripId AND sp.pallet_id = p.id AND sp.shipment_status <> N'skipped')
         OR EXISTS (SELECT 1 FROM wms.shipment_trip_pallets tp
                    WHERE tp.trip_id = @tripId AND tp.pallet_id = p.id AND tp.is_deleted = 0))
        """;

    /// <summary>SL theo pallet: box_count -> box_count × standard_packing; còn lại -> SUM(box_lines.qty).
    /// Số thùng: pallet box_count lấy cột box_count; còn lại đếm thùng thật (sau khi gộp / tách mới đúng).</summary>
    private const string PalletColumns = """
        p.id AS Id, RTRIM(p.pallet_id) AS Code, p.si_no AS SiNo, ISNULL(p.category_id, 0) AS CategoryCode,
        p.detail_level AS DetailLevel,
        CASE WHEN p.detail_level = N'box_count' THEN ISNULL(p.box_count, 0) ELSE ISNULL(bc.cnt, 0) END AS BoxCount,
        CASE WHEN p.detail_level = N'box_count'
             THEN ISNULL(p.box_count, 0) * ISNULL(p.standard_packing, 0)
             ELSE ISNULL(q.qty, 0) END AS Pcs,
        loc.locator_code AS LocatorCode
        """;

    private const string PalletJoins = """
        LEFT JOIN master.locators loc ON loc.id = p.locator_id
        OUTER APPLY (SELECT SUM(bl.qty) AS qty
                     FROM wms.boxes b
                     JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                     WHERE b.lot_id = p.id AND b.is_deleted = 0) q
        OUTER APPLY (SELECT COUNT(1) AS cnt
                     FROM wms.boxes b
                     WHERE b.lot_id = p.id AND b.is_deleted = 0) bc
        """;

    public async Task<List<TripPalletInfo>> GetTripPalletsAsync(long tripId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<TripPalletInfo>($"""
            SELECT {PalletColumns}, CAST(1 AS bit) AS InScope
            FROM wms.pallets p
            {PalletJoins}
            WHERE p.is_deleted = 0 AND {InScopePalletSql}
            ORDER BY loc.locator_code, p.pallet_id;
            """, new { tripId })).ToList();
    }

    public async Task<TripPalletInfo?> FindPalletAsync(long tripId, string code)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<TripPalletInfo>($"""
            SELECT TOP 1 {PalletColumns},
                   CAST(CASE WHEN {InScopePalletSql} THEN 1 ELSE 0 END AS bit) AS InScope
            FROM wms.pallets p
            {PalletJoins}
            WHERE RTRIM(p.pallet_id) = @code AND p.is_deleted = 0
            ORDER BY p.id DESC;
            """, new { tripId, code });
    }

    public async Task<List<TripBoxInfo>> FindBoxesAsync(long tripId, string boxNo)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<TripBoxInfo>($"""
            SELECT b.id AS Id, b.box_no AS BoxNo, b.lot_id AS LotId, RTRIM(p.pallet_id) AS LotCode,
                   ISNULL((SELECT SUM(bl.qty) FROM wms.box_lines bl WHERE bl.box_id = b.id AND bl.is_deleted = 0), 0) AS Pcs,
                   loc.locator_code AS LocatorCode,
                   CAST(CASE WHEN {InScopePalletSql}
                               OR EXISTS (SELECT 1
                                          FROM wms.shipment_instruction_boxes sb
                                          JOIN wms.shipment_instruction_lines sl ON sl.id = sb.line_id
                                          JOIN wms.shipment_trip_sis ts ON ts.si_id = sl.si_id
                                          WHERE ts.trip_id = @tripId
                                            AND (sb.box_id = b.id OR sb.box_no = b.box_no))
                             THEN 1 ELSE 0 END AS bit) AS InScope
            FROM wms.boxes b
            JOIN wms.pallets p ON p.id = b.lot_id AND p.is_deleted = 0
            LEFT JOIN master.locators loc ON loc.id = p.locator_id
            WHERE b.box_no = @boxNo AND b.is_deleted = 0;
            """, new { tripId, boxNo })).ToList();
    }

    public async Task<List<long>> GetBoxIdsAsync(long palletId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<long>(
            "SELECT id FROM wms.boxes WHERE lot_id = @palletId AND is_deleted = 0 ORDER BY id;",
            new { palletId })).ToList();
    }

    /// <summary>Ghi pallet gốc vào Pallet List của chuyến (đã có thì thôi).</summary>
    public async Task AddTripPalletAsync(long tripId, long palletId, string? user)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            IF NOT EXISTS (SELECT 1 FROM wms.shipment_trip_pallets WITH (UPDLOCK, HOLDLOCK)
                           WHERE trip_id = @tripId AND pallet_id = @palletId AND is_deleted = 0)
                INSERT INTO wms.shipment_trip_pallets (trip_id, pallet_id, is_deleted, created_at, created_by)
                VALUES (@tripId, @palletId, 0, SYSDATETIME(), @user);
            """, new { tripId, palletId, user });
    }

    public async Task<List<long>> GetOpenTripIdsBySisAsync(IReadOnlyCollection<long> siIds)
    {
        if (siIds.Count == 0) return new();
        using var conn = _factory.Create();
        return (await conn.QueryAsync<long>("""
            SELECT DISTINCT t.id
            FROM wms.shipment_trips t
            JOIN wms.shipment_trip_sis ts ON ts.trip_id = t.id
            WHERE t.is_deleted = 0
              AND t.status IN (N'planned', N'arrived', N'sealed')
              AND ts.si_id IN @siIds;
            """, new { siIds })).ToList();
    }

    // ═══════════════════════════════════════════════════════════════
    //  Pallet đôi (cọc)
    // ═══════════════════════════════════════════════════════════════

    /// <summary>Cọc đã ghép thật của chuyến (theo cọc Stowage Plan) — wms.shipment_trip_columns.</summary>
    public async Task<List<TripStackRow>> GetStacksAsync(long tripId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<TripStackRow>("""
            SELECT s.id AS Id, s.trip_id AS TripId, s.column_code AS ColumnCode,
                   s.bottom_pallet_id AS BottomPalletId, RTRIM(pb.pallet_id) AS BottomCode,
                   s.top_pallet_id AS TopPalletId, RTRIM(pt.pallet_id) AS TopCode,
                   s.stacked_at AS CreatedAt, s.stacked_by AS CreatedBy,
                   s.placed_at AS PlacedAt, s.placed_by AS PlacedBy
            FROM wms.shipment_trip_columns s
            JOIN wms.pallets pb ON pb.id = s.bottom_pallet_id
            LEFT JOIN wms.pallets pt ON pt.id = s.top_pallet_id
            WHERE s.trip_id = @tripId AND s.is_deleted = 0
            ORDER BY s.column_code;
            """, new { tripId })).ToList();
    }
}