/// Ngôn ngữ hỗ trợ — cờ vẽ tay, mã 2 chữ (theo mẫu lang-menu).
enum AppLanguage {
  vi('vi', 'VI', 'Tiếng Việt'),
  en('en', 'EN', 'English'),
  ja('ja', 'JA', '日本語'),
  zh('zh', 'ZH', '中文');

  final String code; // mã cờ
  final String label; // mã hiển thị 2 chữ
  final String name; // tên bản ngữ
  const AppLanguage(this.code, this.label, this.name);

  factory AppLanguage.fromCode(String? code) {
    return AppLanguage.values.firstWhere(
      (e) => e.code == code,
      orElse: () => vi,
    );
  }
}
