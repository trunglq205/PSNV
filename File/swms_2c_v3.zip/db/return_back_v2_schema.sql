/* =====================================================================
   return_back_v2_schema.sql
   Mục 2c — chuyển luồng chỉ thị back hàng từ 4 BƯỚC sang 3 BƯỚC.

   CHẠY SAU return_back_request_schema.sql.
   Chạy lại nhiều lần không sao.

   ---------------------------------------------------------------------
   LUỒNG MỚI (quyết định 09/11)

     B1  FA tạo yêu cầu — chọn phiếu là xong, lấy TOÀN BỘ phiếu.
         Model + SL suy từ phiếu, FA không nhập không sửa.
         req_status = fa_requested   current_step = fa_approve
         (KHÔNG gửi mail)

     B2  Quản lý FA xác nhận
         req_status = fa_approved    current_step = scs_deliver
         -> mail SCS Office, CC FA
         SCS Office tự thông báo cho SCS WH (ngoài hệ thống)

     B3  SCS WH quét Pallet ID giao hàng cho FA (PDA), nhiều pallet một
         lượt rồi xác nhận MỘT lần.
         serial trên pallet -> at_fa, back_request_id, sent_fa_at
         Hết con nào ở 'received' thì req_status = delivered, step = done
         -> mail FA, CC SCS

   BỎ bước "quản lý SCS duyệt cho back": khi SCS WH chuyển hàng là đã có
   thông báo của SCS Office, và lúc chuyển cũng đã bắn mail — thêm một
   lớp duyệt nữa chỉ làm chậm.

   ⇒ Quyền rework_refurbish.approve_scs KHÔNG còn chỗ dùng. KHÔNG xoá
     khỏi Perms.cs: PermissionCatalogSeeder MERGE theo code, xoá rồi khai
     lại đúng tên cũ sẽ làm sống lại quyền của mọi role từng được gán.
     Để nguyên, đừng gán cho ai.
   ---------------------------------------------------------------------
   GIAO THEO PALLET, không theo số lượng: đã yêu cầu lấy về là lấy hết,
   nên hàng đi theo cả pallet. Vì thế không còn gắp serial FIFO theo số
   lượng — serial lấy đúng theo pallet SCS WH quét.
   ===================================================================== */

SET NOCOUNT ON;
SET XACT_ABORT ON;

/* 1 = chỉ xem sẽ làm gì, không ghi. */
DECLARE @WhatIf bit = 0;

/* 1 = cho phép XOÁ và dựng lại bảng khi đang có dữ liệu thật.
   Để 0 thì script chỉ ALTER, giữ nguyên mọi dòng. */
DECLARE @DropOldData bit = 0;

/* ---------- 0. Tiền đề ---------- */
IF OBJECT_ID(N'wms.return_back_requests', N'U') IS NULL
BEGIN
    RAISERROR(N'Khong tim thay wms.return_back_requests — chay return_back_request_schema.sql truoc.', 16, 1);
    RETURN;
END

DECLARE @rows int =
    (SELECT COUNT(*) FROM wms.return_back_requests WHERE is_deleted = 0);

DECLARE @old_shape bit = IIF(EXISTS (
    SELECT 1 FROM sys.check_constraints
    WHERE name = N'ck_rbr_step'
      AND OBJECT_NAME(parent_object_id) = N'return_back_requests'
      AND definition LIKE N'%scs_approve%'), 1, 0);

DECLARE @has_deliv bit = IIF(COL_LENGTH(N'wms.return_back_requests', N'delivered_at') IS NULL, 0, 1);

SELECT N'0. Hien trang' AS section;
SELECT  so_yeu_cau_that = @rows,
        dang_4_buoc     = IIF(@old_shape = 1, N'CO — se chuyen sang 3 buoc', N'khong'),
        co_cot_giao     = IIF(@has_deliv = 1, N'DA CO', N'chua co'),
        bang_pallet_giao = IIF(OBJECT_ID(N'wms.return_back_deliveries', N'U') IS NULL,
                               N'chua co', N'DA CO'),
        che_do          = IIF(@WhatIf = 1, N'WhatIf — chua ghi gi', N'GHI THAT');

IF @WhatIf = 1 RETURN;

BEGIN TRAN;

/* =====================================================================
   1. Bảng NHẬT KÝ PALLET ĐÃ GIAO

   Mỗi lần SCS WH quét một Pallet ID giao cho FA là một dòng. Đây là thứ
   trả lời "pallet nào đã đi, lúc nào, ai giao" — và là nguồn cho bảng
   trong mail báo FA.

   KHÔNG có FK sang wms.pallets: đến mục 2d thì FA đóng lại pallet MỚI,
   pallet cũ có thể bị tách hoặc biến mất, mà nhật ký phải sống lâu hơn
   pallet. Vì vậy lưu cả lot_no dạng chữ, không chỉ id.
   ===================================================================== */
IF OBJECT_ID(N'wms.return_back_deliveries', N'U') IS NULL
BEGIN
    CREATE TABLE wms.return_back_deliveries
    (
        id           BIGINT IDENTITY(1,1) NOT NULL,
        request_id   BIGINT         NOT NULL,

        /* id pallet lúc giao. Có thể trỏ tới pallet sau này không còn. */
        pallet_id    BIGINT         NULL,

        /* Mã pallet 12 ký tự — giữ dạng chữ để nhật ký đọc được mãi. */
        lot_no       NVARCHAR(30)   NOT NULL,

        /* Số serial chuyển sang at_fa trong lần quét pallet này. */
        serial_count INT            NOT NULL CONSTRAINT df_rbd_cnt DEFAULT (0),

        delivered_at DATETIME2(0)   NOT NULL CONSTRAINT df_rbd_at DEFAULT (SYSDATETIME()),
        delivered_by NVARCHAR(100)  NULL,

        CONSTRAINT pk_return_back_deliveries PRIMARY KEY CLUSTERED (id),
        CONSTRAINT fk_rbd_req FOREIGN KEY (request_id)
            REFERENCES wms.return_back_requests (id)
    );

    /* Tra nhật ký theo yêu cầu — đường đọc duy nhất của bảng này. */
    CREATE NONCLUSTERED INDEX ix_rbd_req
        ON wms.return_back_deliveries (request_id, delivered_at)
        INCLUDE (lot_no, serial_count, delivered_by);

    /* KHÔNG unique (request_id, lot_no): quét lại cùng một pallet là một
       SỰ KIỆN khác (lần sau 0 con) — chặn ở DB thì mất dấu lần quét đó. */

    PRINT N'+ Da tao bang wms.return_back_deliveries.';
END
ELSE PRINT N'= wms.return_back_deliveries da co.';

/* =====================================================================
   2. Hai cột mốc giao hàng trên bảng yêu cầu

   ⚠ BỌC TRONG EXEC: batch không có GO sẽ bind tên CỘT lúc compile, nên
   cột vừa ALTER thêm mà dùng ngay trong cùng batch là lỗi 207 và CẢ
   SCRIPT không chạy dòng nào. Tên BẢNG thì có deferred name resolution
   nên phần trên không cần bọc.
   ===================================================================== */
IF COL_LENGTH(N'wms.return_back_requests', N'delivered_at') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_back_requests ADD delivered_at DATETIME2(0) NULL;');
    PRINT N'+ Da them cot delivered_at.';
END
ELSE PRINT N'= Cot delivered_at da co.';

IF COL_LENGTH(N'wms.return_back_requests', N'delivered_by') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_back_requests ADD delivered_by NVARCHAR(100) NULL;');
    PRINT N'+ Da them cot delivered_by.';
END
ELSE PRINT N'= Cot delivered_by da co.';

/* =====================================================================
   3. Chuyển dữ liệu cũ sang từ vựng 3 bước

   Chạy TRƯỚC khi đổi CHECK, vì CHECK mới không cho giá trị cũ tồn tại.
   ===================================================================== */
IF @old_shape = 1 AND @rows > 0
BEGIN
    /* scs_instructed (SCS WH đã tạo chỉ thị, chờ QL SCS) -> vẫn đang chờ
       SCS WH giao hàng. Bước duyệt của QL SCS không còn nữa. */
    EXEC(N'
        UPDATE wms.return_back_requests
        SET    req_status   = N''fa_approved'',
               current_step = N''scs_deliver''
        WHERE  req_status = N''scs_instructed'';');

    /* scs_approved (đã cho back — serial đã sang at_fa) -> đã giao xong.
       Mốc giao hàng lấy theo mốc duyệt cũ, giữ đúng lịch sử. */
    EXEC(N'
        UPDATE wms.return_back_requests
        SET    req_status    = N''delivered'',
               current_step  = N''done'',
               delivered_at  = ISNULL(delivered_at, scs_approved_at),
               delivered_by  = ISNULL(delivered_by, scs_approved_by)
        WHERE  req_status = N''scs_approved'';');

    /* Dòng đang chờ SCS WH tạo chỉ thị, nhưng status còn fa_approved. */
    EXEC(N'
        UPDATE wms.return_back_requests
        SET    current_step = N''scs_deliver''
        WHERE  current_step IN (N''scs_instruct'', N''scs_approve'');');

    PRINT N'+ Da chuyen du lieu cu sang tu vung 3 buoc.';
END

/* =====================================================================
   4. Đổi hai CHECK sang bộ giá trị mới
   ===================================================================== */
IF @old_shape = 1
BEGIN
    IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'ck_rbr_status')
        ALTER TABLE wms.return_back_requests DROP CONSTRAINT ck_rbr_status;

    IF EXISTS (SELECT 1 FROM sys.check_constraints WHERE name = N'ck_rbr_step')
        ALTER TABLE wms.return_back_requests DROP CONSTRAINT ck_rbr_step;

    /* fa_requested = FA vừa tạo, chờ quản lý FA xác nhận
       fa_approved  = quản lý FA đã xác nhận, chờ SCS WH giao hàng
       delivered    = SCS WH đã giao xong — serial đã sang at_fa
       cancelled    = huỷ ở bất kỳ bước nào trước khi giao */
    ALTER TABLE wms.return_back_requests
        ADD CONSTRAINT ck_rbr_status CHECK (req_status IN
            (N'fa_requested', N'fa_approved', N'delivered', N'cancelled'));

    /* fa_approve  = chờ quản lý FA
       scs_deliver = chờ SCS WH quét pallet giao hàng
       done        = xong (đã giao, hoặc đã huỷ) */
    ALTER TABLE wms.return_back_requests
        ADD CONSTRAINT ck_rbr_step CHECK (current_step IN
            (N'fa_approve', N'scs_deliver', N'done'));

    PRINT N'+ Da doi ck_rbr_status / ck_rbr_step sang bo 3 buoc.';
END
ELSE PRINT N'= Hai CHECK da dung bo 3 buoc.';

/* =====================================================================
   5. Hai cột của bước duyệt đã bỏ

   scs_instructed_by/at và scs_approved_by/at KHÔNG còn chỗ ghi. Giữ
   nguyên chứ không DROP: bảng có thể đang giữ lịch sử của những yêu cầu
   đã đi qua luồng 4 bước, và DROP COLUMN là một chiều.

   scs_comment thì GIỮ LẠI VÀ DÙNG TIẾP — nay là ghi chú lúc SCS WH xác
   nhận giao hàng.
   ===================================================================== */
IF @old_shape = 1 AND @rows > 0
    PRINT N'! Hai cap cot scs_instructed_* / scs_approved_* gio khong con ghi nua '
        + N'(giu lai de khong mat lich su). Khong con code nao doc chung.';

COMMIT;

/* ---------- 6. Kiểm lại ---------- */
SELECT N'1. Ket qua' AS section;
SELECT  rang_buoc = c.name, dinh_nghia = c.definition
FROM    sys.check_constraints c
WHERE   OBJECT_NAME(c.parent_object_id) = N'return_back_requests'
ORDER BY c.name;

SELECT N'2. Phan bo trang thai' AS section;
SELECT  req_status, current_step, so_dong = COUNT(*)
FROM    wms.return_back_requests
WHERE   is_deleted = 0
GROUP BY req_status, current_step
ORDER BY req_status, current_step;

SELECT N'3. Viec con phai lam' AS section;
SELECT N'Chay return_back_mail_schema.sql (ban 2 su kien) de khai lai mau mail.' AS ghi_chu
UNION ALL
SELECT N'Khong gan quyen rework_refurbish.approve_scs cho role nao — buoc do da bo.'
UNION ALL
SELECT N'Hang da giao cho FA van con pallet trong wms.pallets: quyet dinh co tru ton '
     + N'kho SCS hay khong thi CHUA lam, dang de nguyen nhu truoc.';
