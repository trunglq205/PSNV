import 'package:json_annotation/json_annotation.dart';

import 'package:swms_finish_goods/features/vanning/domain/vanning_entities.dart';

part 'merge_session_model.g.dart';

// Khớp TripMerge*Response / TripMergeRequest (TripVanningModels.cs). JSON camelCase.

@JsonSerializable(createToJson: false)
class MergeCandidateModel {
  final String code;

  /// 'pallet' | 'box'
  final String type;
  final String? locatorCode;
  final int boxCount;
  final int pcs;

  const MergeCandidateModel({
    required this.code,
    required this.type,
    this.locatorCode,
    required this.boxCount,
    required this.pcs,
  });

  factory MergeCandidateModel.fromJson(Map<String, dynamic> json) =>
      _$MergeCandidateModelFromJson(json);

  MergeCandidate toEntity() => MergeCandidate(
    code: code,
    // Loại lạ coi như pallet: an toàn hơn vì pallet đôi chỉ nhận pallet.
    type: type.toLowerCase() == 'box'
        ? MergeItemType.box
        : MergeItemType.pallet,
    locatorCode: locatorCode ?? '-',
    boxCount: boxCount,
    pcs: pcs,
  );
}

@JsonSerializable(createToJson: false)
class TripStackModel {
  final int cocNo;
  final String? code;
  final String bottomCode;
  final String? topCode;
  final DateTime? placedAt;

  const TripStackModel({
    required this.cocNo,
    this.code,
    required this.bottomCode,
    this.topCode,
    this.placedAt,
  });

  factory TripStackModel.fromJson(Map<String, dynamic> json) =>
      _$TripStackModelFromJson(json);

  TripStack toEntity() => TripStack(
    cocNo: cocNo,
    code: code,
    bottomCode: bottomCode,
    topCode: topCode,
    placed: placedAt != null,
  );
}

@JsonSerializable(createToJson: false)
class MergePlanBoxModel {
  final int seq;
  final String boxNo;
  final String? model;

  /// 'base' | 'source' | 'missing'
  final String status;
  final String? palletCode;
  final String? locatorCode;
  final int pcs;

  const MergePlanBoxModel({
    required this.seq,
    required this.boxNo,
    this.model,
    required this.status,
    this.palletCode,
    this.locatorCode,
    this.pcs = 0,
  });

  factory MergePlanBoxModel.fromJson(Map<String, dynamic> json) =>
      _$MergePlanBoxModelFromJson(json);

  MergePlanBox toEntity() => MergePlanBox(
    seq: seq,
    boxNo: boxNo,
    model: model,
    status: PlanBoxStatus.parse(status),
    palletCode: palletCode,
    locatorCode: locatorCode,
    pcs: pcs,
  );
}

@JsonSerializable(createToJson: false)
class MergeSourceModel {
  final String palletCode;
  final String? locatorCode;
  final int needed;
  final int boxCount;
  final bool whole;

  const MergeSourceModel({
    required this.palletCode,
    this.locatorCode,
    required this.needed,
    required this.boxCount,
    required this.whole,
  });

  factory MergeSourceModel.fromJson(Map<String, dynamic> json) =>
      _$MergeSourceModelFromJson(json);

  MergeSource toEntity() => MergeSource(
    palletCode: palletCode,
    locatorCode: locatorCode,
    needed: needed,
    boxCount: boxCount,
    whole: whole,
  );
}

@JsonSerializable(createToJson: false)
class MergeTierModel {
  final int tier;
  final String planPalletCode;
  final String? palletCode;
  final bool complete;
  final bool isThis;
  final int done;
  final int total;

  const MergeTierModel({
    required this.tier,
    required this.planPalletCode,
    this.palletCode,
    this.complete = false,
    this.isThis = false,
    this.done = 0,
    this.total = 0,
  });

  factory MergeTierModel.fromJson(Map<String, dynamic> json) =>
      _$MergeTierModelFromJson(json);

  MergeTier toEntity() => MergeTier(
    tier: tier,
    planPalletCode: planPalletCode,
    palletCode: palletCode,
    complete: complete,
    isThis: isThis,
    done: done,
    total: total,
  );
}

/// Khớp TripMergeColumnResponse.
@JsonSerializable(createToJson: false)
class MergeColumnModel {
  final String code;
  final int cocNo;
  final List<MergeTierModel> tiers;
  final String? stackedBottom;
  final String? stackedTop;
  final bool placed;

  const MergeColumnModel({
    required this.code,
    required this.cocNo,
    this.tiers = const <MergeTierModel>[],
    this.stackedBottom,
    this.stackedTop,
    this.placed = false,
  });

  factory MergeColumnModel.fromJson(Map<String, dynamic> json) =>
      _$MergeColumnModelFromJson(json);

  MergeColumn toEntity() => MergeColumn(
    code: code,
    cocNo: cocNo,
    tiers: tiers.map((t) => t.toEntity()).toList(),
    stackedBottom: stackedBottom,
    stackedTop: stackedTop,
    placed: placed,
  );
}

/// Khớp TripMergePlanResponse.
@JsonSerializable(createToJson: false)
class MergePlanModel {
  final String planNo;
  final String palletCode;
  final String? columnCode;
  final int tier;
  final String? siNo;
  final String? palletSize;
  final List<MergePlanBoxModel> boxes;
  final List<MergeSourceModel> sources;
  final List<String> extra;
  final MergeColumnModel? column;

  const MergePlanModel({
    required this.planNo,
    required this.palletCode,
    this.columnCode,
    this.tier = 1,
    this.siNo,
    this.palletSize,
    this.boxes = const <MergePlanBoxModel>[],
    this.sources = const <MergeSourceModel>[],
    this.extra = const <String>[],
    this.column,
  });

  factory MergePlanModel.fromJson(Map<String, dynamic> json) =>
      _$MergePlanModelFromJson(json);

  MergePlan toEntity() => MergePlan(
    planNo: planNo,
    palletCode: palletCode,
    columnCode: columnCode,
    tier: tier,
    siNo: siNo,
    palletSize: palletSize,
    boxes: boxes.map((b) => b.toEntity()).toList(),
    sources: sources.map((s) => s.toEntity()).toList(),
    extra: extra,
    column: column?.toEntity(),
  );
}

@JsonSerializable(createToJson: false)
class MergeSessionModel {
  final String baseCode;
  final bool isNewList;
  final String? siCode;
  final String? route;
  final int baseBoxCount;
  final int basePcs;
  final List<MergeCandidateModel> candidates;
  final List<TripStackModel> stacks;
  final MergePlanModel? plan;

  const MergeSessionModel({
    required this.baseCode,
    this.isNewList = false,
    this.siCode,
    this.route,
    this.baseBoxCount = 0,
    this.basePcs = 0,
    this.candidates = const [],
    this.stacks = const [],
    this.plan,
  });

  factory MergeSessionModel.fromJson(Map<String, dynamic> json) =>
      _$MergeSessionModelFromJson(json);

  MergeSession toEntity() => MergeSession(
    base: BasePallet(
      code: baseCode,
      isNewList: isNewList,
      siCode: siCode,
      route: route,
      boxCount: baseBoxCount,
      pcs: basePcs,
    ),
    candidates: candidates.map((c) => c.toEntity()).toList(),
    stacks: stacks.map((s) => s.toEntity()).toList(),
    plan: plan?.toEntity(),
  );
}

@JsonSerializable(createFactory: false)
class MergeRequestModel {
  final String baseCode;
  final List<String> palletCodes;
  final List<String> boxCodes;
  final bool doublePallet;
  final bool confirmModelMismatch;

  const MergeRequestModel({
    required this.baseCode,
    required this.palletCodes,
    required this.boxCodes,
    required this.doublePallet,
    this.confirmModelMismatch = false,
  });

  Map<String, dynamic> toJson() => _$MergeRequestModelToJson(this);
}

@JsonSerializable(createToJson: false)
class MergeResultModel {
  final String palletListCode;
  final int boxCount;
  final int pcs;
  final int? cocNo;

  const MergeResultModel({
    required this.palletListCode,
    required this.boxCount,
    required this.pcs,
    this.cocNo,
  });

  factory MergeResultModel.fromJson(Map<String, dynamic> json) =>
      _$MergeResultModelFromJson(json);

  MergeResult toEntity() => MergeResult(
    palletListCode: palletListCode,
    boxCount: boxCount,
    pcs: pcs,
    cocNo: cocNo,
  );
}