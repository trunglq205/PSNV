import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2d — FA đóng lại Pallet ID sau rework.
//
//  FA chọn phiếu → máy tải TOÀN BỘ sổ serial của phiếu → quét mã thùng → quét
//  serial từng sản phẩm. Mỗi serial được kiểm NGAY TRÊN MÁY:
//    · đang ở FA của phiếu này  → nhận, model tự suy từ sổ
//    · thuộc phiếu này nhưng sai trạng thái → cảnh báo vàng, ĐẶT RIÊNG
//    · không thuộc phiếu / thuộc phiếu khác → cảnh báo đỏ, ĐẶT RIÊNG
//
//  Khác mục 2a: serial lạ VẪN cho quét tiếp (chỉ không vào pallet), và FA
//  KHÔNG phải chọn model — sổ đã biết mỗi con thuộc model nào.
// ─────────────────────────────────────────────────────────────

/// Một dòng trong sổ serial, dạng gọn để kiểm trên máy.
@immutable
class ReturnSerialIndexEntry {
  final String serial;
  final String model;

  /// `received` | `at_fa` | `returned` | `shipped` | `ng`.
  final String status;

  const ReturnSerialIndexEntry({
    required this.serial,
    required this.model,
    required this.status,
  });

  /// Đang ở FA — con duy nhất được nhận vào pallet.
  bool get isAtFa => status == 'at_fa';
}

/// Lý do một serial bị loại. Khớp `ReturnMismatchReason` bên API.
enum FaMismatchKind {
  /// Không có trong sổ của phiếu nào.
  notInDoc,

  /// Có trong phiếu này nhưng không ở `at_fa`.
  wrongStatus,

  /// Đang thuộc một phiếu khác.
  otherDoc,
}

/// Một serial FA quét ra mà không khớp — giữ trên máy để hiện ngay, và server
/// cũng ghi vào nhật ký khi Lưu.
@immutable
class FaMismatch {
  final String serial;
  final FaMismatchKind kind;

  /// Model tra được từ sổ; null với serial hoàn toàn lạ.
  final String? model;

  /// Trạng thái con đó đang mang, khi tra được.
  final String? foundStatus;

  const FaMismatch({
    required this.serial,
    required this.kind,
    this.model,
    this.foundStatus,
  });
}

/// Một thùng FA đang đóng dở trên máy, CHƯA gửi server.
///
/// KHÔNG có `model` như [ReturnBoxDraft] của mục 2a: một thùng FA có thể chứa
/// nhiều model (phiếu nhiều model cùng category), và model của từng con đã
/// biết từ sổ.
@immutable
class FaBoxDraft {
  /// Mã thùng quét được. `null` = không quét được mã; server đặt tên theo
  /// Pallet ID.
  final String? boxNo;

  final List<String> serials;

  const FaBoxDraft({this.boxNo, this.serials = const []});

  FaBoxDraft copyWith({String? boxNo, List<String>? serials}) =>
      FaBoxDraft(boxNo: boxNo ?? this.boxNo, serials: serials ?? this.serials);
}

/// Kết quả một lần FA đóng pallet.
@immutable
class FaPalletResult {
  final int palletId;

  /// Pallet ID 12 số, để in tem.
  final String lotNo;

  final int categoryCode;
  final int boxCount;
  final int serialCount;

  /// Số serial bị loại trong lần quét này.
  final int mismatchCount;

  /// Phiếu sau khi đóng pallet.
  final ReturnInstruction doc;

  const FaPalletResult({
    required this.palletId,
    required this.lotNo,
    required this.categoryCode,
    required this.boxCount,
    required this.serialCount,
    required this.mismatchCount,
    required this.doc,
  });
}

/// Kết quả SCS nhận lại một pallet từ FA (mục 3).
@immutable
class ReceiveBackResult {
  final String lotNo;

  /// Số con chuyển được sang "đã về".
  final int received;

  /// Số con nằm trên pallet nhưng không chuyển được: đã về trước đó, hoặc
  /// thuộc phiếu khác. KHÔNG phải lỗi — là con số để WH đối chiếu.
  final int skipped;

  final ReturnInstruction doc;

  const ReceiveBackResult({
    required this.lotNo,
    required this.received,
    required this.skipped,
    required this.doc,
  });
}
