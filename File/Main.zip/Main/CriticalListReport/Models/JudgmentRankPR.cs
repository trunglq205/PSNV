﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("tblRequirementRank")]
    public class JudgmentRankPR
    {
        [Key]
        public int Id { get; set; }
        public string? Plant { get; set; }
        public string? Material { get; set; }
        public string? ShortText { get; set; }
        public DateTime? DelivDate { get; set; }
        public string? FixVendor { get; set; }
        public string? VendorName { get; set; }
        public string? MRPC { get; set; }
        public string? PIC { get; set; }
        public decimal? InboundQty { get; set; }
        public int? Leadtime { get; set; }
        public int? ShortLT { get; set; }
        public string? MaterialType { get; set; }
        public string? JudgmentRank { get; set; }
        public string? FreightUnit { get; set; }
        public decimal? GWAir { get; set; }
        public byte? DataSource { get; set; }  // 0 = SAP, 1 = TCode
        public DateTime CreatedAt { get; set; }
        public string? RoundingVal { get; set; }
        public string? GWPer1Pcs { get; set; }
        public string? UnitPacking { get; set; }
    }
}