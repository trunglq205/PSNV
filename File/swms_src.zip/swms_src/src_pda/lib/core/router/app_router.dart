﻿import 'package:auto_route/auto_route.dart';
import 'package:swms_finish_goods/core/router/app_route_paths.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';

@AutoRouterConfig()
class AppRouter extends RootStackRouter {
  @override
  List<AutoRoute> get routes => [
    AutoRoute(page: LoginRoute.page, path: AppRoutePaths.login, initial: true),
    AutoRoute(page: HomeRoute.page, path: AppRoutePaths.home),
    AutoRoute(page: PartCardRoute.page, path: AppRoutePaths.partCard),
    AutoRoute(page: PartCardActionRoute.page, path: AppRoutePaths.partCardAction),
    AutoRoute(page: ReceivingRoute.page, path: AppRoutePaths.receiving),
    AutoRoute(page: TempLocationRoute.page, path: AppRoutePaths.tempLocation),
    AutoRoute(page: PalletDetailRoute.page, path: AppRoutePaths.palletDetail),
    AutoRoute(page: FindMissingBoxRoute.page, path: AppRoutePaths.findMissingBox),
    AutoRoute(page: BoxDetailRoute.page, path: AppRoutePaths.boxDetail),
    AutoRoute(page: SplitPalletRoute.page, path: AppRoutePaths.splitPallet),
    AutoRoute(page: GalleryRoute.page, path: AppRoutePaths.gallery),
    AutoRoute(page: SettingsRoute.page, path: AppRoutePaths.settings),
    AutoRoute(page: StoringRoute.page, path: AppRoutePaths.storing),
    AutoRoute(page: StorageMapRoute.page, path: AppRoutePaths.storageMap),
    AutoRoute(page: NgListRoute.page, path: AppRoutePaths.abnormalReport),
    AutoRoute(page: NgCreateRoute.page, path: AppRoutePaths.abnormalReportCreate),
    AutoRoute(page: NgDetailRoute.page, path: AppRoutePaths.abnormalReportDetail),
    AutoRoute(page: StocktakeMorningRoute.page, path: AppRoutePaths.stocktakeMorning),
    AutoRoute(page: StocktakeMonthlyRoute.page, path: AppRoutePaths.stocktakeMonthly),
    AutoRoute(page: StocktakeShipmentRoute.page, path: AppRoutePaths.stocktakeShipment),
    AutoRoute(page: StocktakeDetailRoute.page, path: AppRoutePaths.stocktakeDetail),
    AutoRoute(page: WarehouseMoveRoute.page, path: AppRoutePaths.warehouseMove),
    AutoRoute(page: VanningAreaRoute.page, path: AppRoutePaths.vanningArea),
    AutoRoute(page: ShipmentInstructionListRoute.page, path: AppRoutePaths.shipmentInstruction),
    AutoRoute(page: ShipmentInstructionDetailRoute.page, path: AppRoutePaths.shipmentInstructionDetail),
    AutoRoute(page: KittingRoute.page, path: AppRoutePaths.kitting),
    AutoRoute(page: KittingTaskRoute.page, path: AppRoutePaths.kittingDetail),
    AutoRoute(page: StockyRoute.page, path: AppRoutePaths.stocky),
    AutoRoute(page: ModelDetailRoute.page, path: AppRoutePaths.modelDetail),
    AutoRoute(page: StockyListRoute.page, path: AppRoutePaths.stockyInWarehouse),
    AutoRoute(page: VanningRoute.page, path: AppRoutePaths.palletVanning),
    AutoRoute(page: TripPalletPhotosRoute.page, path: AppRoutePaths.palletPhotos),
    AutoRoute(page: TripStowageRoute.page, path: AppRoutePaths.stowagePlan),
    AutoRoute(page: ContainerCheckRoute.page, path: AppRoutePaths.containerCheck),
    AutoRoute(page: ContainerFinishRoute.page, path: AppRoutePaths.containerFinish),
    AutoRoute(page: ReturnInstructionListRoute.page, path: AppRoutePaths.returnInstruction),
    AutoRoute(page: ReturnReceiveRoute.page, path: AppRoutePaths.returnReceive),
  ];
}