import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';

/// State của màn Home — ĐỒNG BỘ.
/// Groups + pinned có ngay (hiển thị tức thì); assignments là AsyncValue
/// riêng để chỉ phần "Việc của tôi" có loading/error, không che cả màn.
@immutable
class HomeState {
  final AsyncValue<List<AssignmentData>> assignments;
  final AsyncValue<List<String>> permissions;
  final List<FeatureGroup> groups;
  final Set<String> pinned;
  final String fullName;
  final String employeeCode;

  const HomeState({
    this.assignments = const AsyncValue.loading(),
    this.permissions = const AsyncValue.loading(),
    this.groups = const [],
    this.pinned = const {},
    this.fullName = '',
    this.employeeCode = '',
  });

  /// Cụm theo thứ tự hiển thị: cụm ghim nổi lên đầu, GIỮ số thứ tự gốc.
  List<OrderedGroup> get displayGroups {
    final permList = switch (permissions) {
      AsyncData(:final value) => value,
      _ => <String>[],
    };

    final filtered = groups
        .map((group) {
          final visibleItems = group.items
              .where((item) => item.alwaysVisible || permList.contains(item.key))
              .toList();
          return (group: group, items: visibleItems);
        })
        .where((e) => e.items.isNotEmpty)
        .toList();

    final indexed = [
      for (int i = 0; i < filtered.length; i++)
        OrderedGroup(
          i + 1,
          filtered[i].group.copyWith(items: filtered[i].items),
        ),
    ];

    indexed.sort((a, b) {
      final pa = pinned.contains(a.group.key) ? 0 : 1;
      final pb = pinned.contains(b.group.key) ? 0 : 1;
      if (pa != pb) return pa - pb;
      return a.order - b.order;
    });

    return indexed;
  }

  bool isPinned(String key) => pinned.contains(key);

  /// User có quyền [key] (đã tải xong quyền). Đang tải / lỗi → `false`.
  bool can(String key) => switch (permissions) {
    AsyncData(:final value) => value.contains(key),
    _ => false,
  };

  HomeState copyWith({
    AsyncValue<List<AssignmentData>>? assignments,
    AsyncValue<List<String>>? permissions,
    List<FeatureGroup>? groups,
    Set<String>? pinned,
    String? fullName,
    String? employeeCode,
  }) {
    return HomeState(
      assignments: assignments ?? this.assignments,
      permissions: permissions ?? this.permissions,
      groups: groups ?? this.groups,
      pinned: pinned ?? this.pinned,
      fullName: fullName ?? this.fullName,
      employeeCode: employeeCode ?? this.employeeCode,
    );
  }
}
