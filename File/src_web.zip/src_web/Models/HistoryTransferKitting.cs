﻿namespace SWMS_WebTool.Models
{
    public class HistoryTransferKitting
    {
        public int IndexID { get; set; }
        public int DetailID { get; set; }
        public string Material { get; set; }
        public string PicUser { get; set; }
        public string NewPicUser { get; set; }
        public byte? Status { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
    }
}
