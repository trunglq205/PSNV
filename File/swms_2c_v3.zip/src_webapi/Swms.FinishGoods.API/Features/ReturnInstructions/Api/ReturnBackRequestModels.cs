using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// B1 — FA tạo đề nghị nhận lại hàng từ một chỉ thị nhận hàng.
///
/// CHỈ CHỌN PHIẾU, không gửi dòng model + SL: lấy là lấy HẾT phần phiếu còn ở
/// kho, nên service tự suy dòng từ sổ serial. Form chỉ cho XEM số đó.
///
/// Vì vậy ở đây không còn <c>Lines</c>. Trước kia có, và một ô SL nhập được
/// chính là chỗ sinh ra tình huống "xin một phần" mà nghiệp vụ không cho.
/// </summary>
public record CreateBackRequestRequest(
    [Required] long DocId,
    [StringLength(500)] string? Note);

/// <summary>
/// Sửa đề nghị — chỉ còn sửa được GHI CHÚ, và chỉ khi còn chờ quản lý FA.
/// Dòng model + SL vẫn suy lại từ phiếu lúc lưu (phiếu có thể vừa nhận thêm
/// hàng), không nhận từ client.
/// </summary>
public record UpdateBackRequestRequest([StringLength(500)] string? Note);

/// <summary>Xác nhận / huỷ — một ô ý kiến, dùng chung.</summary>
public record BackRequestDecisionRequest([StringLength(500)] string? Comment);

/// <summary>
/// B3 — SCS WH quét Pallet ID giao hàng cho FA.
///
/// Nhận NHIỀU mã trong một lượt: WH quét 5 pallet rồi bấm xác nhận một lần, và
/// FA nhận MỘT lá thư liệt kê 5 pallet thay vì 5 lá.
/// </summary>
public record DeliverBackRequest(
    [Required, MinLength(1)] List<string>? LotNos,
    [StringLength(500)] string? Comment);

public record BackRequestLineResponse(
    long Id,
    int LineNo,
    string Model,
    int Qty,
    int AssignedQty,
    int ReturnedQty,
    int AvailableQty,
    bool Short,
    string? Note)
{
    public static BackRequestLineResponse From(ReturnBackRequestLine l) => new(
        l.Id, l.LineNo, l.Model, l.Qty, l.AssignedQty, l.ReturnedQty,
        l.AvailableQty, l.Short, l.Note);
}

public record BackRequestResponse(
    long Id,
    long DocId,
    string? DocNo,
    string? GoodsType,
    string ReqNo,
    string ReqStatus,
    string CurrentStep,
    string? Note,
    int ModelCount,
    int TotalQty,
    int AssignedQty,
    int ReturnedQty,
    int AtFaQty,
    int RemainQty,
    bool IsOpen,
    bool IsDelivered,
    bool IsPartlyDelivered,
    bool IsCancelled,
    string? RequestedBy,
    DateTime RequestedAt,
    string? FaApprovedBy,
    DateTime? FaApprovedAt,
    string? FaComment,
    string? DeliveredBy,
    DateTime? DeliveredAt,
    string? ScsComment,
    string? CancelledBy,
    DateTime? CancelledAt,
    string? CancelReason,
    List<BackRequestLineResponse> Lines)
{
    public static BackRequestResponse From(ReturnBackRequest r) => new(
        r.Id, r.DocId, r.DocNo, r.GoodsType, r.ReqNo, r.ReqStatus, r.CurrentStep,
        r.Note, r.ModelCount, r.TotalQty, r.AssignedQty, r.ReturnedQty, r.AtFaQty,
        r.RemainQty,
        r.IsOpen, r.IsDelivered, r.IsPartlyDelivered, r.IsCancelled,
        r.RequestedBy, r.RequestedAt,
        r.FaApprovedBy, r.FaApprovedAt, r.FaComment,
        r.DeliveredBy, r.DeliveredAt, r.ScsComment,
        r.CancelledBy, r.CancelledAt, r.CancelReason,
        r.Lines.Select(BackRequestLineResponse.From).ToList());
}

/// <summary>Một pallet đã giao trong lượt quét.</summary>
public record BackDeliveryResponse(
    string LotNo,
    int SerialCount,
    DateTime DeliveredAt,
    string? DeliveredBy)
{
    public static BackDeliveryResponse From(ReturnBackDelivery d) => new(
        d.LotNo, d.SerialCount, d.DeliveredAt, d.DeliveredBy);
}

/// <summary>
/// Kết quả MỘT lượt quét giao hàng.
///
/// Trả cả <c>Request</c> đã cập nhật để PDA không phải gọi thêm một lần GET chỉ
/// để biết còn bao nhiêu con chưa giao — máy quét thường ở chỗ sóng kém.
///
/// <c>NotFoundLots</c> là mã quét ra mà hệ thống không có, <c>EmptyLots</c> là
/// pallet có thật nhưng không chuyển được con nào (hàng trên đó đã đi rồi).
/// Tách hai danh sách vì cách xử lý khác nhau: cái đầu là quét sai, cái sau là
/// pallet đã rỗng.
/// </summary>
public record BackDeliverResponse(
    int DeliveredQty,
    int RemainQty,
    bool Completed,
    List<BackDeliveryResponse> Pallets,
    List<string> NotFoundLots,
    List<string> EmptyLots,
    BackRequestResponse Request)
{
    public static BackDeliverResponse From(
        ReturnBackDeliverResult result, ReturnBackRequest req) => new(
        result.DeliveredQty,
        result.RemainQty,
        result.Completed,
        result.Pallets.Where(p => p.SerialCount > 0)
                      .Select(BackDeliveryResponse.From).ToList(),
        result.NotFoundLots.ToList(),
        result.Pallets.Where(p => p.SerialCount == 0).Select(p => p.LotNo).ToList(),
        BackRequestResponse.From(req));
}

/// <summary>Bộ lọc danh sách đề nghị.</summary>
public record BackRequestQuery(
    long? DocId,
    string? Status,
    string? Step,
    string? Keyword);

/// <summary>
/// SL kho còn gắp được theo model. Màn soạn đề nghị gọi để HIỂN THỊ (chỉ xem)
/// phần hàng sẽ lấy về, và service dùng đúng số này để dựng dòng.
/// </summary>
public record BackAvailableModelResponse(string Model, int AvailableQty);

/// <summary>
/// Khoá resource cho thông báo lỗi của mục 2c. Giữ ở một chỗ để resx và code
/// không lệch nhau — cùng cách <c>ReturnMsg</c> làm.
/// </summary>
public static class BackMsg
{
    public const string NotFound = "Return.Back.Err.NotFound";
    public const string DocNotFound = "Return.Back.Err.DocNotFound";
    public const string DocCancelled = "Return.Back.Err.DocCancelled";
    public const string NotEditable = "Return.Back.Err.NotEditable";
    public const string WrongStep = "Return.Back.Err.WrongStep";
    public const string AlreadyCancelled = "Return.Back.Err.AlreadyCancelled";
    public const string TooManyLines = "Return.Back.Err.TooManyLines";
    public const string ValueTooLong = "Return.Back.Err.ValueTooLong";

    /// <summary>Phiếu không còn con nào ở kho để lấy về.</summary>
    public const string NothingAvailable = "Return.Back.Err.NothingAvailable";

    /// <summary>Lượt giao không có mã pallet nào.</summary>
    public const string LotsRequired = "Return.Back.Err.LotsRequired";

    public const string TooManyLots = "Return.Back.Err.TooManyLots";

    /// <summary>Mọi mã pallet quét ra đều không có trong hệ thống.</summary>
    public const string LotNotFound = "Return.Back.Err.LotNotFound";

    /// <summary>Pallet có thật nhưng không còn con nào của phiếu này trên đó.</summary>
    public const string NothingToDeliver = "Return.Back.Err.NothingToDeliver";

    /// <summary>Đã giao xong — không sửa, không huỷ được nữa.</summary>
    public const string AlreadyDelivered = "Return.Back.Err.AlreadyDelivered";

    /// <summary>Đã giao dở dang — hàng đang ở FA, không huỷ được.</summary>
    public const string PartlyDelivered = "Return.Back.Err.PartlyDelivered";
}
