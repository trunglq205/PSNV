using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Shortages.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.Shortages.Api;

[ApiController]
[Route("api/shortages")]
public class ShortagesController : ControllerBase
{
    private readonly IShortageService _service;
    public ShortagesController(IShortageService service) => _service = service;

    [HttpGet]
    [RequirePermission<Perms.Outbound.Shortage.View>]
    public async Task<ActionResult<PagedResult<ShortageItemResponse>>> GetAll([FromQuery] ShortageQuery query)
        => Ok(await _service.GetPagedAsync(query));

    /// <summary>Tổng theo nguyên nhân cho dải thẻ — bỏ qua ReasonCode của bộ lọc.</summary>
    [HttpGet("summary")]
    [RequirePermission<Perms.Outbound.Shortage.View>]
    public async Task<ActionResult<ShortageSummaryResponse>> GetSummary([FromQuery] ShortageQuery query)
        => Ok(await _service.GetSummaryAsync(query));

    /// <summary>Model qua query string: mã hàng có thể chứa ký tự không an toàn trên path.</summary>
    [HttpGet("stock")]
    [RequirePermission<Perms.Outbound.Shortage.View>]
    public async Task<ActionResult<List<StockPalletResponse>>> GetStock([FromQuery] string model)
        => Ok(await _service.GetStockAsync(model));

    [HttpGet("recipients")]
    [RequirePermission<Perms.Outbound.Shortage.View>]
    public async Task<ActionResult<List<RecipientResponse>>> GetRecipients(
        [FromQuery] string eventCode, [FromQuery] string? department, [FromQuery] string? subCode,
        [FromQuery] string? category, [FromQuery] string? model)
        => Ok(await _service.GetRecipientsAsync(eventCode, department, subCode, category, model));

    /// <summary>
    /// Ai sẽ nhận mail nếu bấm Gửi — gọi khi mở hộp gửi và mỗi lần đổi bộ phận.
    /// Chỉ đọc. Quyền Request (người sắp gửi), không phải quyền cấu hình email.
    /// departments lặp lại: ?departments=FA&amp;departments=OQC.
    /// </summary>
    [HttpGet("mail-preview")]
    [RequirePermission<Perms.Outbound.Shortage.Request>]
    public async Task<ActionResult<ShortageMailPreviewResponse>> GetMailPreview([FromQuery] ShortageMailPreviewQuery query)
        => Ok(await _service.GetMailPreviewAsync(query));

    /// <summary>
    /// Báo cáo hàng thiếu hằng ngày (mẫu SHORTAGE_DAILY) — worker gọi mỗi sáng ngày làm việc.
    /// dryRun = true: tính và render nhưng KHÔNG gửi, trả Subject / Body / người nhận để kiểm.
    /// skipIfEmpty = true (mặc định): không còn hàng thiếu thì không gửi mail "0 mã".
    /// Luôn trả 200 kèm Sent / Skipped; chỉ lỗi gửi mail thật mới ra 5xx để worker thử lại.
    /// Quyền: tài khoản dịch vụ của worker cần quyền Shortage.Request.
    /// </summary>
    [HttpPost("daily-report")]
    [RequirePermission<Perms.Outbound.Shortage.Request>]
    public async Task<ActionResult<DailyReportResponse>> SendDailyReport(
        [FromQuery] bool dryRun = false, [FromQuery] bool skipIfEmpty = true)
        => Ok(await _service.SendDailyReportAsync(dryRun, skipIfEmpty));

    /// <summary>Yêu cầu bổ sung (SHORTAGE_REQUEST) hoặc báo VP (SHORTAGE_ESCALATE).</summary>
    [HttpPost("requests")]
    [RequirePermission<Perms.Outbound.Shortage.Request>]
    public async Task<ActionResult<SendRequestResponse>> Send(ShortageSendRequest request)
        => Ok(await _service.SendAsync(request));
}
