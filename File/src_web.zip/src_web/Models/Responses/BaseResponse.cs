﻿using Refit;

namespace SWMS_WebTool.Models.Responses
{
    public class BaseResponse
    {
        public int Status { get; set; }
        public object? Data { get; set; }
        public string? Detail { get; set; }
    }
}
