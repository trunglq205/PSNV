import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/home/domain/scan_result.dart';

part 'scan_result_model.g.dart';

/// Khớp `ScanResolveResponse` của API (GET /api/scan/resolve).
@JsonSerializable(explicitToJson: true)
class ScanResultModel {
  final String code;
  final String type;
  final int? id;
  final String? areaCode;

  /// Chỉ có khi `type = "part_card"`.
  final PartCardScanInfoModel? partCard;

  const ScanResultModel({
    required this.code,
    required this.type,
    this.id,
    this.areaCode,
    this.partCard,
  });

  factory ScanResultModel.fromJson(Map<String, dynamic> json) =>
      _$ScanResultModelFromJson(json);

  Map<String, dynamic> toJson() => _$ScanResultModelToJson(this);

  ScanResult toEntity() => ScanResult(
    code: code,
    type: ScanType.fromApi(type),
    id: id,
    areaCode: areaCode,
    partCard: partCard?.toEntity(),
  );
}

/// Khớp `ScanPartCardInfo` của API.
@JsonSerializable()
class PartCardScanInfoModel {
  final String? cardId;
  final int? modelCount;
  final int? boxCount;
  final bool? isLocked;
  final int? statusOqc;
  final bool? canEdit;
  final bool? canSplit;
  final bool? canMerge;

  const PartCardScanInfoModel({
    this.cardId,
    this.modelCount,
    this.boxCount,
    this.isLocked,
    this.statusOqc,
    this.canEdit,
    this.canSplit,
    this.canMerge,
  });

  factory PartCardScanInfoModel.fromJson(Map<String, dynamic> json) =>
      _$PartCardScanInfoModelFromJson(json);

  Map<String, dynamic> toJson() => _$PartCardScanInfoModelToJson(this);

  /// Thiếu cờ → coi như KHÔNG được làm (an toàn hơn cho thao tác xoá tem).
  PartCardScanInfo toEntity() => PartCardScanInfo(
    cardId: cardId ?? '',
    modelCount: modelCount ?? 0,
    boxCount: boxCount ?? 0,
    isLocked: isLocked ?? false,
    statusOqc: statusOqc ?? 0,
    canEdit: canEdit ?? false,
    canSplit: canSplit ?? false,
    canMerge: canMerge ?? false,
  );
}