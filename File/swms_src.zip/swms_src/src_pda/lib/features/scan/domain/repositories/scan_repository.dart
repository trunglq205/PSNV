import 'package:swms_finish_goods/features/scan/domain/entities/scan_result.dart';

abstract class ScanRepository {
  /// Phân loại mã quét → loại đối tượng để mở đúng màn.
  Future<ScanResult> resolve(String code);
}
