import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/extensions/datetime_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';

/// Bước 2: xác nhận các part card (carton) vừa quét.
class ReceivingConfirmBoxBody extends StatelessWidget {
  const ReceivingConfirmBoxBody({
    super.key,
    required this.partCards,
    this.onRemoveCarton,
  });

  final List<PartCard> partCards;
  final void Function(int index)? onRemoveCarton;

  @override
  Widget build(BuildContext context) {
    final lastScanned = partCards.lastOrNull;
    return Column(
      children: [
        const SizedBox(height: AppDimens.sm),
        BarcodeScannerButton(
          scanningLabel: LocaleKeys.receiving_scan_next_box.tr(),
        ),
        const SizedBox(height: AppDimens.sm),
        if (lastScanned != null) ...[
          _LastScannedBar(
            code: lastScanned.cardId,
            category: lastScanned.category.key,
          ),
          const SizedBox(height: AppDimens.sm),
        ],
        _SectionHeader(count: partCards.length),
        const SizedBox(height: AppDimens.sm),
        Expanded(
          child: ListView.separated(
            itemBuilder: (_, index) {
              return _CartonCard(
                index: partCards.length - index,
                partCard: partCards[index],
                onRemove: onRemoveCarton == null
                    ? null
                    : () => onRemoveCarton?.call(index),
              );
            },
            separatorBuilder: (_, _) => const SizedBox(height: AppDimens.sm),
            itemCount: partCards.length,
          ),
        ),
      ],
    );
  }
}

/// Thanh "Vừa quét CTN-xxxx".
class _LastScannedBar extends StatelessWidget {
  const _LastScannedBar({required this.code, required this.category});

  final String code;
  final String category;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Icon(Icons.check, size: 12, color: swms.success),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text.rich(
              TextSpan(
                style: AppTextStyles.caption.copyWith(
                  fontSize: 11,
                  color: swms.text3,
                ),
                children: [
                  TextSpan(text: '${LocaleKeys.receiving_just_scanned.tr()} '),
                  TextSpan(
                    text: '$code - $category',
                    style: AppTextStyles.code.copyWith(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: swms.text1,
                      letterSpacing: 0,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Nhãn "CARTON ĐÃ QUÉT TRÊN PALLET" + badge đếm.
class _SectionHeader extends StatelessWidget {
  const _SectionHeader({required this.count});

  final int count;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Row(
      children: [
        Expanded(
          child: Text(
            LocaleKeys.receiving_cartons_on_pallet.tr(),
            style: AppTextStyles.caption.copyWith(
              color: swms.text3,
              fontWeight: FontWeight.w700,
              letterSpacing: .4,
            ),
          ),
        ),
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 1),
          decoration: BoxDecoration(
            color: AppColors.primary,
            borderRadius: BorderRadius.circular(10),
          ),
          child: Text(
            '$count',
            style: AppTextStyles.caption.copyWith(
              color: Colors.white,
              fontWeight: FontWeight.w700,
            ),
          ),
        ),
      ],
    );
  }
}

/// Thẻ 1 carton: header (STT, Card_ID, nút xóa) + body (từng model: mã, ngày SX, qty).
class _CartonCard extends StatelessWidget {
  const _CartonCard({
    required this.index,
    required this.partCard,
    this.onRemove,
  });

  final int index;
  final PartCard partCard;
  final VoidCallback? onRemove;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.success.withValues(alpha: .10)),
        boxShadow: AppShadows.s1,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _CartonHeader(
            index: index,
            code: partCard.cardId,
            onRemove: onRemove,
          ),
          for (final m in partCard.models)
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              child: Row(
                children: [
                  _ModelChip(text: m.model),
                  const SizedBox(width: 5),
                  _LotChip(productionDate: partCard.productionDate),
                  const Spacer(),
                  _QtyChip(qty: m.quantity),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

class _CartonHeader extends StatelessWidget {
  const _CartonHeader({required this.index, required this.code, this.onRemove});

  final int index;
  final String code;
  final VoidCallback? onRemove;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
      decoration: BoxDecoration(
        color: swms.successBg,
        borderRadius: const BorderRadius.vertical(
          top: Radius.circular(AppDimens.rInput),
        ),
        border: Border(
          bottom: BorderSide(color: swms.success.withValues(alpha: .15)),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 20,
            height: 20,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: swms.card2,
              borderRadius: BorderRadius.circular(5),
              boxShadow: AppShadows.s1,
            ),
            child: Text(
              index.toString().padLeft(2, '0'),
              style: AppTextStyles.code.copyWith(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                color: swms.success,
                letterSpacing: 0,
              ),
            ),
          ),
          const SizedBox(width: 7),
          Expanded(
            child: Text(
              code,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.code.copyWith(
                fontSize: 12,
                fontWeight: FontWeight.w800,
                color: swms.text1,
                letterSpacing: -.1,
              ),
            ),
          ),
          if (onRemove != null)
            SizedBox(
              width: 20,
              height: 20,
              child: IconButton(
                onPressed: onRemove,
                padding: EdgeInsets.zero,
                iconSize: 11,
                splashRadius: 14,
                tooltip: LocaleKeys.receiving_remove_carton.tr(),
                icon: Icon(Icons.close_rounded, color: swms.text3),
              ),
            ),
        ],
      ),
    );
  }
}

class _ModelChip extends StatelessWidget {
  const _ModelChip({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: AppColors.accentBlueTint,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(
        text,
        style: AppTextStyles.code.copyWith(
          fontSize: 10.5,
          fontWeight: FontWeight.w800,
          color: AppColors.accentBlueFg,
          letterSpacing: 0,
        ),
      ),
    );
  }
}

class _LotChip extends StatelessWidget {
  const _LotChip({required this.productionDate});

  final DateTime productionDate;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final isOutDate = DateTime.now().difference(productionDate).inDays > 90;
    final color = isOutDate ? swms.dangerBg : swms.primary;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
      decoration: BoxDecoration(
        color: isOutDate ? swms.dangerBg: swms.card2,
        borderRadius: BorderRadius.circular(5),
        border: Border.all(color: color.withValues(alpha: .25)),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.calendar_today_outlined, size: 9, color: color),
          const SizedBox(width: 3),
          Flexible(
            child: Text(
              productionDate.mmYYYY,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.caption.copyWith(
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _QtyChip extends StatelessWidget {
  const _QtyChip({required this.qty});

  final int qty;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
      decoration: BoxDecoration(
        color: swms.successBg,
        borderRadius: BorderRadius.circular(7),
      ),
      child: Text(
        '$qty ${LocaleKeys.receiving_pcs_unit.tr()}',
        style: AppTextStyles.label.copyWith(
          fontWeight: FontWeight.w800,
          color: AppColors.primaryDark,
        ),
      ),
    );
  }
}