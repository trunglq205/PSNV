﻿using Swms.FinishGoods.API.Features.OqcSamples.Business;
using Swms.FinishGoods.API.Features.OqcSamples.DataAccess;

namespace Swms.FinishGoods.API.Features.OqcSamples
{
    public static class OqcSampleModule
    {
        public static IServiceCollection AddOqcSampleFeature(this IServiceCollection services)
        {
            services.AddScoped<IOqcSampleService, OqcSampleService>();
            services.AddScoped<IOqcSampleRepository, OqcSampleRepository>();
            return services;
        }
    }
}