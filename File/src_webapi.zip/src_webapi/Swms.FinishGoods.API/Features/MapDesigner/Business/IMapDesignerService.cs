namespace Swms.FinishGoods.API.Features.MapDesigner.Business;

public interface IMapDesignerService
{
    Task<MapLayout> GetLayoutAsync(string areaCode);
    Task SaveLayoutAsync(string areaCode, IReadOnlyList<MapBlock> blocks, string? user);
    Task<long> CreateRackAsync(string areaCode, CreateRackInput input, string? user);
    Task DeleteRackAsync(string areaCode, string rackCode, string? user);
}
