using System.Globalization;
using System.Text;
using ClosedXML.Excel;

namespace ShippingScs.Web.Services;

/// <summary>Một dòng hợp lệ đọc từ file Excel lịch làm việc.</summary>
public class CalendarImportRow
{
    public int RowNumber { get; set; }
    public DateOnly Date { get; set; }
    public string DayType { get; set; } = "";
    public string? Note { get; set; }
}

public class CalendarImportResult
{
    public List<CalendarImportRow> Rows { get; } = new();
    public List<string> Errors { get; } = new();
    public bool IsValid => Errors.Count == 0 && Rows.Count > 0;
}

/// <summary>
/// Đọc/ghi file Excel lịch làm việc.
///
/// Format (sheet đầu tiên, dòng 1 là tiêu đề):
///   A: Ngày     – ô kiểu ngày, hoặc chữ dd/MM/yyyy hay yyyy-MM-dd
///   B: Loại     – Làm việc | Cuối tuần | Nghỉ lễ | Làm bù (hoặc Workday/Weekend/Holiday/ExtraWorkday)
///   C: Ghi chú  – tuỳ chọn, tối đa 200 ký tự
/// Chỉ cần liệt kê ngày ĐẶC BIỆT (lễ, làm bù...). Ngày không có trong file giữ nguyên.
/// Có thể dùng chính file xuất ra từ hệ thống (đủ 365 ngày) để sửa rồi import lại.
/// Tìm cột theo tên tiêu đề; không thấy thì lấy cột A, B, C.
/// </summary>
public class CalendarExcelService
{
    public const int MaxRows = 2000;
    private const int MaxNoteLength = 200;

    private static readonly string[] DateFormats = { "dd/MM/yyyy", "d/M/yyyy", "yyyy-MM-dd", "dd-MM-yyyy", "d-M-yyyy" };

    public static readonly Dictionary<string, string> Labels = new()
    {
        [DayTypes.Workday] = "Làm việc",
        [DayTypes.Weekend] = "Cuối tuần",
        [DayTypes.Holiday] = "Nghỉ lễ",
        [DayTypes.ExtraWorkday] = "Làm bù",
    };

    // Khoá đã bỏ dấu, viết thường, bỏ khoảng trắng -> DayType
    private static readonly Dictionary<string, string> TypeAliases = new()
    {
        ["lamviec"] = DayTypes.Workday,
        ["workday"] = DayTypes.Workday,
        ["cuoituan"] = DayTypes.Weekend,
        ["weekend"] = DayTypes.Weekend,
        ["nghile"] = DayTypes.Holiday,
        ["le"] = DayTypes.Holiday,
        ["holiday"] = DayTypes.Holiday,
        ["lambu"] = DayTypes.ExtraWorkday,
        ["extraworkday"] = DayTypes.ExtraWorkday,
    };

    /// <summary>Đọc file. Không ném lỗi với dữ liệu sai: gom hết vào Errors kèm số dòng.</summary>
    public CalendarImportResult Parse(Stream stream)
    {
        var result = new CalendarImportResult();

        XLWorkbook wb;
        try
        {
            wb = new XLWorkbook(stream);
        }
        catch (Exception)
        {
            result.Errors.Add("Không đọc được file. Hãy dùng file .xlsx (Excel 2007 trở lên), không dùng .xls hay .csv.");
            return result;
        }

        using (wb)
        {
            var ws = wb.Worksheets.First();
            var lastRow = ws.LastRowUsed()?.RowNumber() ?? 0;
            if (lastRow < 2)
            {
                result.Errors.Add("File không có dữ liệu (dòng 1 là tiêu đề, dữ liệu từ dòng 2).");
                return result;
            }
            if (lastRow - 1 > MaxRows)
            {
                result.Errors.Add($"File có {lastRow - 1} dòng, tối đa {MaxRows} dòng mỗi lần import.");
                return result;
            }

            var (colDate, colType, colNote) = FindColumns(ws.Row(1));
            var seen = new Dictionary<DateOnly, int>();

            for (var r = 2; r <= lastRow; r++)
            {
                var dateCell = ws.Cell(r, colDate);
                var typeText = ws.Cell(r, colType).GetString().Trim();
                var noteText = ws.Cell(r, colNote).GetString().Trim();

                if (dateCell.Value.IsBlank && typeText == "" && noteText == "") continue; // dòng trống

                var date = ReadDate(dateCell);
                if (date == null)
                {
                    result.Errors.Add($"Dòng {r}: ngày '{dateCell.GetString()}' không hợp lệ (dùng dd/MM/yyyy).");
                    continue;
                }
                if (date.Value.Year < 2000 || date.Value.Year > 2100)
                {
                    result.Errors.Add($"Dòng {r}: năm {date.Value.Year} ngoài khoảng 2000–2100.");
                    continue;
                }

                if (!TypeAliases.TryGetValue(Key(typeText), out var dayType))
                {
                    result.Errors.Add(typeText == ""
                        ? $"Dòng {r}: chưa điền Loại ngày."
                        : $"Dòng {r}: Loại '{typeText}' không hợp lệ. Dùng: Làm việc, Cuối tuần, Nghỉ lễ, Làm bù.");
                    continue;
                }

                if (noteText.Length > MaxNoteLength)
                {
                    result.Errors.Add($"Dòng {r}: ghi chú dài {noteText.Length} ký tự, tối đa {MaxNoteLength}.");
                    continue;
                }

                if (seen.TryGetValue(date.Value, out var firstRow))
                {
                    result.Errors.Add($"Dòng {r}: ngày {date.Value:dd/MM/yyyy} bị trùng với dòng {firstRow}.");
                    continue;
                }
                seen[date.Value] = r;

                result.Rows.Add(new CalendarImportRow
                {
                    RowNumber = r,
                    Date = date.Value,
                    DayType = dayType,
                    Note = noteText == "" ? null : noteText,
                });
            }

            if (result.Rows.Count == 0 && result.Errors.Count == 0)
                result.Errors.Add("File không có dòng dữ liệu nào.");
        }

        return result;
    }

    /// <summary>File mẫu: tiêu đề, dropdown Loại, vài dòng ví dụ và sheet hướng dẫn.</summary>
    public byte[] BuildTemplate(int year)
    {
        var samples = new List<(DateOnly, string, string)>
        {
            (new DateOnly(year, 1, 1), DayTypes.Holiday, "Tết Dương lịch"),
            (new DateOnly(year, 4, 30), DayTypes.Holiday, "Giải phóng miền Nam"),
            (new DateOnly(year, 5, 1), DayTypes.Holiday, "Quốc tế Lao động"),
            (new DateOnly(year, 9, 2), DayTypes.Holiday, "Quốc khánh"),
        };
        return Build(samples, $"Lịch {year}", includeGuide: true);
    }

    /// <summary>Xuất lịch đang có trong DB ra Excel, đúng format import.</summary>
    public byte[] BuildExport(IEnumerable<WorkingDay> days, string calendarCode, int year)
    {
        var rows = days.Select(d => (DateOnly.FromDateTime(d.Date), d.DayType, d.Note ?? "")).ToList();
        return Build(rows, $"{calendarCode} {year}", includeGuide: true);
    }

    private static byte[] Build(List<(DateOnly Date, string Type, string Note)> rows, string sheetName, bool includeGuide)
    {
        using var wb = new XLWorkbook();
        var ws = wb.Worksheets.Add(SafeSheetName(sheetName));

        ws.Cell(1, 1).Value = "Ngày";
        ws.Cell(1, 2).Value = "Loại";
        ws.Cell(1, 3).Value = "Ghi chú";
        ws.Cell(1, 4).Value = "Thứ";
        var header = ws.Range(1, 1, 1, 4);
        header.Style.Font.Bold = true;
        header.Style.Font.FontColor = XLColor.White;
        header.Style.Fill.BackgroundColor = XLColor.FromHtml("#1E293B");

        var r = 2;
        foreach (var row in rows)
        {
            ws.Cell(r, 1).Value = row.Date.ToDateTime(TimeOnly.MinValue);
            ws.Cell(r, 2).Value = Labels.TryGetValue(row.Type, out var label) ? label : row.Type;
            ws.Cell(r, 3).Value = row.Note;
            // Cột "Thứ" chỉ để người dùng dễ nhìn, lúc import bỏ qua
            ws.Cell(r, 4).FormulaA1 = $"=IF(A{r}=\"\",\"\",CHOOSE(WEEKDAY(A{r},2),\"T2\",\"T3\",\"T4\",\"T5\",\"T6\",\"T7\",\"CN\"))";

            var fill = row.Type switch
            {
                DayTypes.Holiday => "#FECACA",
                DayTypes.ExtraWorkday => "#BBF7D0",
                DayTypes.Weekend => "#E2E8F0",
                _ => null,
            };
            if (fill != null) ws.Range(r, 1, r, 4).Style.Fill.BackgroundColor = XLColor.FromHtml(fill);
            r++;
        }

        ws.Column(1).Style.DateFormat.Format = "dd/MM/yyyy";
        // Dropdown cho cột Loại, đủ chỗ cho người dùng thêm dòng
        ws.Range(2, 2, Math.Max(r, 2) + 500, 2).CreateDataValidation()
            .List("\"Làm việc,Cuối tuần,Nghỉ lễ,Làm bù\"", true);

        ws.Column(1).Width = 14;
        ws.Column(2).Width = 14;
        ws.Column(3).Width = 40;
        ws.Column(4).Width = 7;
        ws.SheetView.FreezeRows(1);

        if (includeGuide)
        {
            var g = wb.Worksheets.Add("Huong dan");
            var lines = new[]
            {
                "HƯỚNG DẪN IMPORT LỊCH LÀM VIỆC",
                "",
                "• Hệ thống đọc SHEET ĐẦU TIÊN. Dòng 1 là tiêu đề, dữ liệu từ dòng 2.",
                "• Cột Ngày: định dạng ngày, hoặc gõ dd/MM/yyyy (VD 02/09/2027).",
                "• Cột Loại: chọn trong danh sách: Làm việc, Cuối tuần, Nghỉ lễ, Làm bù.",
                "• Cột Ghi chú: tuỳ chọn, tối đa 200 ký tự. Cột Thứ chỉ để xem, không cần điền.",
                "",
                "• CHỈ CẦN liệt kê các ngày đặc biệt: ngày lễ, ngày làm bù, Thứ Bảy đi làm...",
                "  Ngày không có trong file giữ nguyên như đang có trên hệ thống.",
                "• Nếu năm đó chưa sinh lịch, tick 'Tự sinh phần còn lại của năm' khi import:",
                "  hệ thống tạo T2–T6 làm việc, CN nghỉ (T7 tuỳ chọn), rồi áp các ngày trong file.",
                "• Ngày trùng nhau trong file, ngày sai hoặc loại sai: hệ thống báo lỗi theo số dòng",
                "  và KHÔNG import dòng nào, sửa xong upload lại.",
                "• Có thể bấm 'Tải Excel' trên màn Lịch làm việc để lấy lịch cả năm, sửa, rồi import lại.",
                "• Tết Nguyên đán, Giỗ Tổ Hùng Vương theo âm lịch: điền ngày dương lịch tương ứng từng năm.",
            };
            for (var i = 0; i < lines.Length; i++) g.Cell(i + 1, 1).Value = lines[i];
            g.Cell(1, 1).Style.Font.Bold = true;
            g.Cell(1, 1).Style.Font.FontSize = 13;
            g.Column(1).Width = 95;
        }

        using var ms = new MemoryStream();
        wb.SaveAs(ms);
        return ms.ToArray();
    }

    private static (int Date, int Type, int Note) FindColumns(IXLRow header)
    {
        int date = 0, type = 0, note = 0;
        var last = header.LastCellUsed()?.Address.ColumnNumber ?? 0;
        for (var c = 1; c <= last; c++)
        {
            var k = Key(header.Cell(c).GetString());
            if (date == 0 && (k == "ngay" || k == "date")) date = c;
            else if (type == 0 && (k == "loai" || k == "loaingay" || k == "type" || k == "daytype")) type = c;
            else if (note == 0 && (k == "ghichu" || k == "note")) note = c;
        }
        return (date == 0 ? 1 : date, type == 0 ? 2 : type, note == 0 ? 3 : note);
    }

    private static DateOnly? ReadDate(IXLCell cell)
    {
        var v = cell.Value;
        if (v.IsDateTime) return DateOnly.FromDateTime(v.GetDateTime());
        if (v.IsNumber)
        {
            var n = v.GetNumber();
            // Số serial ngày của Excel (ô ngày bị định dạng thành số)
            if (n >= 1 && n < 2958466) return DateOnly.FromDateTime(DateTime.FromOADate(n));
            return null;
        }
        if (v.IsText &&
            DateTime.TryParseExact(v.GetText().Trim(), DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var dt))
            return DateOnly.FromDateTime(dt);
        return null;
    }

    /// <summary>Bỏ dấu tiếng Việt, khoảng trắng, viết thường: "Nghỉ lễ" -> "nghile".</summary>
    internal static string Key(string text)
    {
        var normalized = text.Trim().ToLowerInvariant().Replace('đ', 'd').Normalize(NormalizationForm.FormD);
        var sb = new StringBuilder(normalized.Length);
        foreach (var ch in normalized)
        {
            if (CharUnicodeInfo.GetUnicodeCategory(ch) == UnicodeCategory.NonSpacingMark) continue;
            if (char.IsWhiteSpace(ch) || ch == '_' || ch == '-') continue;
            sb.Append(ch);
        }
        return sb.ToString();
    }

    private static string SafeSheetName(string name)
    {
        foreach (var ch in new[] { ':', '\\', '/', '?', '*', '[', ']' }) name = name.Replace(ch, ' ');
        return name.Length > 31 ? name.Substring(0, 31) : name;
    }
}
