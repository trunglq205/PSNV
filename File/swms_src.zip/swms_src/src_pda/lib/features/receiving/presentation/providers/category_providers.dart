import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/receiving/data/datasources/category_remote_data_source.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';

part 'category_providers.g.dart';

/// Danh mục Cate — tải 1 lần, giữ suốt phiên.
/// KHÔNG `read(.future)` trực tiếp — dùng [CategoriesRefX.readCategories]
/// để lỗi lần trước không bị cache vĩnh viễn.
@Riverpod(keepAlive: true)
Future<List<Category>> categories(Ref ref) async {
  final remote = CategoryRemoteDataSource(ref.watch(dioProvider));
  final items = await remote.getOptions();
  return items.map((e) => e.toEntity()).toList(growable: false)
    ..sort((a, b) => a.value.compareTo(b.value));
}

/// Dùng trong Notifier.
extension CategoriesRefX on Ref {
  /// Lần tải trước lỗi → tải lại; đang có dữ liệu → trả ngay từ cache.
  Future<List<Category>> readCategories() {
    if (read(categoriesProvider).hasError) invalidate(categoriesProvider);
    return read(categoriesProvider.future);
  }
}

/// Dùng trong Widget.
extension CategoriesWidgetRefX on WidgetRef {
  Future<List<Category>> readCategories() {
    if (read(categoriesProvider).hasError) invalidate(categoriesProvider);
    return read(categoriesProvider.future);
  }
}