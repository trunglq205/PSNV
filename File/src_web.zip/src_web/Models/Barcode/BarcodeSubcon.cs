﻿namespace SWMS_WebTool.Models.Barcode
{
    public class BarcodeSubcon
    {
        public string Model { get; set; }
        public string DeleveryDate { get; set; }
        public string Plant { get; set; }
        public string Kitting { get; set; } = "KittingList";
    }
}
