﻿namespace SWMS_WebTool.Models.Requests
{
    public class ComfirmJPTRequest
    {
        public List<int>? Ids { get; set; }
    }
}
