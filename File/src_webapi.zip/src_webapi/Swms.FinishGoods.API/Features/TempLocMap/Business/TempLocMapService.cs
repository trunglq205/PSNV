﻿using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.TempLocMap.Api;
using Swms.FinishGoods.API.Features.TempLocMap.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.TempLocMap.Business;

public class TempLocMapService : ITempLocMapService
{
    private readonly ITempLocMapRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    // Trạng thái màu hợp lệ của map — dùng CHUNG bộ mã với domain OQC (InspectionStatus).
    // ('is_urgent' là cờ độc lập/lớp phủ viền, không phải trạng thái nền nên không nằm ở đây.)
    private static readonly HashSet<string> ValidStatuses =
        new(StringComparer.OrdinalIgnoreCase)
        { "empty", "not_inspected", "under_inspection", "pending_result",
          "inspection_exempt", "pass", "ng" };

    private static readonly HashSet<string> ValidCellTypes =
        new(StringComparer.OrdinalIgnoreCase) { "pallet", "zone" };

    public TempLocMapService(
        ITempLocMapRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    public async Task<IReadOnlyList<AreaSummaryResponse>> GetAreasAsync()
    {
        var areas = await _repo.GetAreasAsync();
        return areas.Select(AreaSummaryResponse.From).ToList();
    }

    // ---- Ánh xạ inspection_status (wms.pallets) -> trạng thái màu của map ----
    // Domain OQC đã ghi inspection_status bằng đúng bộ mã chuẩn (InspectionStatus),
    // nên gần như ánh xạ 1-1; vẫn chấp nhận vài bí danh cũ để an toàn với dữ liệu lịch sử.
    // 'not_required' (mặc định DB) và mọi giá trị lạ -> not_inspected (an toàn: coi như CHƯA kiểm,
    //  không cho di chuyển nhầm một pallet chưa phân loại).
    private static string MapInspectionStatus(string? raw)
    {
        var s = (raw ?? "").Trim().ToLowerInvariant();
        return s switch
        {
            "ng" or "failed" or "fail" or "reject" or "rejected" or "fail_lot" => "ng",
            "pass" or "passed" or "ok" or "accepted" or "ok_lot" or "approved" => "pass",
            "under_inspection" or "checking" or "inspecting" or "in_progress" or "processing" => "under_inspection",
            "pending_result" or "pending" or "waiting" or "wait" => "pending_result",
            "inspection_exempt" or "exempt" => "inspection_exempt",
            _ => "not_inspected"
        };
    }

    // Thứ tự ƯU TIÊN màu inspection khi 1 pallet có nhiều lot (số nhỏ = ưu tiên cao).
    // Ưu tiên trạng thái "đáng chú ý/chặn" nhất:
    // ng > under_inspection > not_inspected > pending_result > inspection_exempt > pass.
    // (is_urgent KHÔNG nằm đây — là cờ độc lập, trả riêng dưới dạng viền.)
    private static readonly Dictionary<string, int> StatusPriority = new()
    {
        ["ng"] = 1,
        ["under_inspection"] = 2,
        ["not_inspected"] = 3,
        ["pending_result"] = 4,
        ["inspection_exempt"] = 5,
        ["pass"] = 6,
        ["empty"] = 99
    };

    /// <summary>
    /// Màu nền pallet = trạng thái kiểm (inspection) đáng chú ý nhất trong các lot.
    /// KHÔNG xét is_urgent ở đây — urgent là lớp phủ độc lập (viền), trả riêng.
    /// </summary>
    private static string DeriveStatus(IEnumerable<PalletLot> lots)
    {
        var list = lots.ToList();
        if (list.Count == 0) return "empty";
        return list
            .Select(l => MapInspectionStatus(l.InspectionStatus))
            .OrderBy(s => StatusPriority.GetValueOrDefault(s, 50))
            .First();
    }

    public async Task<MapLayoutResponse?> GetLayoutAsync(string areaCode)
    {
        var area = await _repo.GetAreaByCodeAsync(areaCode);
        if (area is null) return null;

        var locators = await _repo.GetLocatorsByAreaAsync(area.Id);
        var lots = await _repo.GetLotsByAreaAsync(area.Id);
        var lotsByLocator = lots.GroupBy(l => l.LocatorId).ToDictionary(g => g.Key, g => g.ToList());

        var cells = locators.Select(l =>
        {
            var baseCell = MapCellResponse.From(l);
            if (l.CellType != "pallet") return baseCell;   // zone giữ nguyên

            var myLots = lotsByLocator.GetValueOrDefault(l.Id) ?? new List<PalletLot>();
            var lotInfos = myLots
                .Select(p => LotInfo.From(p, MapInspectionStatus(p.InspectionStatus)))
                .ToList();

            // Màu nền = trạng thái kiểm dẫn xuất từ lot (không override tay).
            var status = DeriveStatus(myLots);
            // Cờ khẩn độc lập: bất kỳ lot nào is_urgent -> pallet có lớp phủ "khẩn".
            var isUrgent = myLots.Any(x => x.IsUrgent);

            return baseCell with
            {
                Status = status,
                IsUrgent = isUrgent,
                Lots = lotInfos,
                Model = lotInfos.FirstOrDefault()?.Models,
                LotNo = lotInfos.FirstOrDefault()?.LotNo
            };
        }).ToList();

        return new MapLayoutResponse(
            area.Id, area.AreaCode, area.AreaName,
            area.Cols, area.Rows, area.CellMeters, cells);
    }

    public async Task<AreaSummaryResponse> CreateAreaAsync(CreateAreaRequest request)
    {
        var existing = await _repo.GetAreaByCodeAsync(request.AreaCode);
        if (existing is not null)
            throw new ConflictException(_localizer["TempLoc.Err.AreaExists", request.AreaCode]);

        var area = new WarehouseArea
        {
            AreaCode = request.AreaCode.Trim(),
            AreaName = request.AreaName.Trim(),
            Cols = request.Cols,
            Rows = request.Rows,
            CellMeters = request.CellMeters
        };
        area.Id = await _repo.CreateAreaAsync(area, _currentUser.FullName);
        return AreaSummaryResponse.From(area);
    }

    public async Task SaveLayoutAsync(string areaCode, SaveLayoutRequest request)
    {
        var area = await _repo.GetAreaByCodeAsync(areaCode)
                   ?? throw new NotFoundException(_localizer["TempLoc.Err.AreaNotFound"]);

        foreach (var c in request.Cells)
        {
            if (!ValidCellTypes.Contains(c.CellType))
                throw new BusinessRuleException(_localizer["TempLoc.Err.InvalidCellType", c.CellType]);

            if (c.CellType.Equals("pallet", StringComparison.OrdinalIgnoreCase))
            {
                if (string.IsNullOrWhiteSpace(c.Code))
                    throw new BusinessRuleException(_localizer["TempLoc.Err.PalletCodeRequired"]);
                var st = string.IsNullOrWhiteSpace(c.Status) ? "empty" : c.Status;
                if (!ValidStatuses.Contains(st))
                    throw new BusinessRuleException(_localizer["TempLoc.Err.InvalidStatus", c.Status ?? ""]);
            }

            if (c.GridX < 0 || c.GridY < 0 ||
                c.GridX + c.GridW > request.Cols ||
                c.GridY + c.GridH > request.Rows)
                throw new BusinessRuleException(
                    _localizer["TempLoc.Err.CellOutOfGrid", c.Code ?? c.Label ?? "", request.Cols, request.Rows]);
        }

        // Chặn TRÙNG mã pallet trong cùng một lần lưu (không cho 2 ô cùng code, vd 2 x PL1).
        var dupCodes = request.Cells
            .Where(c => c.CellType.Equals("pallet", StringComparison.OrdinalIgnoreCase)
                        && !string.IsNullOrWhiteSpace(c.Code))
            .GroupBy(c => c.Code!.Trim(), StringComparer.OrdinalIgnoreCase)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();
        if (dupCodes.Count > 0)
            throw new BusinessRuleException(
                _localizer["TempLoc.Err.DuplicateCode", string.Join(", ", dupCodes)]);

        await _repo.SaveLayoutAsync(area.Id, request, _currentUser.FullName);
    }

    public async Task ChangeStatusAsync(string locatorCode, ChangeStatusRequest request)
    {
        if (!ValidStatuses.Contains(request.Status))
            throw new BusinessRuleException(_localizer["TempLoc.Err.InvalidStatus", request.Status]);

        var ok = await _repo.ChangeStatusAsync(locatorCode, request, _currentUser.FullName);
        if (!ok) throw new NotFoundException(_localizer["TempLoc.Err.LocatorNotFound"]);
    }

    public async Task<LocatorPalletsResponse> GetLocatorPalletsAsync(string locatorCode)
    {
        var loc = await _repo.GetLocatorOccupancyAsync((locatorCode ?? string.Empty).Trim())
                  ?? throw new NotFoundException(_localizer["TempLoc.Err.LocatorNotFound"]);
        return LocatorPalletsResponse.From(loc);
    }
}