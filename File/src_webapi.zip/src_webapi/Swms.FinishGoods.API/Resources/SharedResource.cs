﻿namespace Swms.FinishGoods.API.Resource;

/// <summary>
/// Class "neo" cho localization. Không chứa code — chỉ dùng làm type tham chiếu
/// cho IStringLocalizer&lt;SharedResource&gt;. File .resx tương ứng nằm tại
/// Resources/SharedResource.{culture}.resx
/// </summary>
public class SharedResource
{
}
