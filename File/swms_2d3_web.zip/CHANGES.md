# Màn Web của 2d + 3 — nhật ký serial lệch & vòng đi–về với FA

Đây là hai thứ tôi hẹn ở CHANGES của gói 2d và gói 3. Không có SQL mới.

> **Áp SAU gói `swms_3_receive_back.zip`.** Gói này ghi đè
> `ReturnInstructionRepository.cs` của gói đó (thêm hai con số đếm) — giải nén
> gói 3 trước rồi mới giải nén gói này.

---

## 1. “Còn ở FA” — con số thiếu nhất từ trước tới giờ

Trước gói này, nhìn màn Web không có cách nào biết còn bao nhiêu hàng đang ở
FA. Phiếu đã chốt ở mục 2b trông như xong việc, trong khi 300 con có thể còn
nằm ngoài kho chờ FA giao lại.

Thêm ở ba chỗ:

| Chỗ | Nội dung |
|---|---|
| Bảng phiếu | cột **Còn ở FA**, ngay cạnh **Thực nhận** — hai con số đọc cùng nhau mới ra “về bao nhiêu, còn bao nhiêu ngoài kho” |
| Bảng dòng (bung chi tiết) | hai cột **Còn ở FA** và **Đã giao lại** theo TỪNG MODEL — biết tổng còn 300 con chưa đủ để đi đòi, phải biết model nào |
| Dải tóm tắt dưới bảng dòng | `Còn ở FA: 120 · FA đã giao lại: 180 · Còn 120 con chưa về` |

Dải tóm tắt chỉ hiện khi vòng FA **đã bắt đầu** (`AtFaQty > 0 || ReturnedQty > 0`):
phiếu chưa giao FA lần nào thì nó là ba số 0, chiếm chỗ mà không nói gì. Khi
`AtFaQty == 0` dải đổi sang tông xanh và nói **“Đã về hết”** — kết luận bằng
chữ, vì “còn 0 ở FA” và “đã về hết” là cùng một việc nhưng câu thứ hai mới là
thứ người ta muốn biết.

Màu: tím (`#5a3ea8`), **không** dùng lại ba màu lệch (cam vượt / đỏ thiếu /
xanh đủ). “Còn ở FA” không phải lệch — dùng chung màu là bắt người đọc dừng
lại phân biệt.

### Hai con số đó lấy ở đâu

Không thêm cột DB. Mở rộng đúng câu query đang đếm SL thực nhận:

```sql
SELECT  s.doc_id, s.model,
        COUNT(*)                                                AS [Qty],
        SUM(CASE WHEN s.status = N'at_fa'    THEN 1 ELSE 0 END) AS [AtFa],
        SUM(CASE WHEN s.status = N'returned' THEN 1 ELSE 0 END) AS [Returned]
FROM wms.return_instruction_serials s
WHERE s.is_deleted = 0 AND s.doc_id IN @docIds
GROUP BY s.doc_id, s.model;
```

`SUM(CASE…)` chứ không `GROUP BY` thêm `status`: gom theo status sẽ ra nhiều
dòng cho một model và chỗ gọi phải tự cộng lại. **Không thêm round-trip nào** —
cùng một câu, thêm hai cột.

## 2. Nhật ký serial lệch — SCS xem và đóng việc

Ở mục 2d, FA quét ra con không khớp sổ thì **không bị chặn**: server ghi vào
`wms.return_serial_mismatches` rồi cho FA đóng pallet tiếp. Nhưng cho tới giờ
không có màn nào xem cái nhật ký đó, nên nó ghi vào rồi nằm im.

Khối mới nằm trong phần chi tiết của phiếu, dưới bảng pallet:

| Cột | Nội dung |
|---|---|
| Serial · Model | con hàng FA quét ra |
| Lý do lệch | pill 3 màu: `Thuộc phiếu khác` (đỏ) · `Sai trạng thái` (cam) · `Không có trong phiếu nào` (xám), kèm **số phiếu đang giữ con đó** nếu có |
| Trạng thái thực | con đó đang mang trạng thái gì |
| Pallet | pallet FA đang đóng lúc quét ra |
| Người quét · lúc | FA nào, mấy giờ |
| Xử lý | pill “Chưa xử lý” / mốc đã xử lý + ghi chú |

- Dòng **chưa xử lý** tô nền đỏ nhạt — đây là việc còn phải làm.
- Dòng **đã xử lý** làm mờ hẳn, nó chỉ còn là dấu vết.
- Tiêu đề khối mang pill **“{n} chưa xử lý”** khi còn việc.
- Công tắc **“Xem cả dòng đã xử lý”** chỉ hiện khi *có* dòng đã xử lý — một
  checkbox không bao giờ đổi được gì là thứ gây nhầm.

Nút **“Đã xử lý”** mở dialog có ô ghi chú (**không bắt buộc** — bắt gõ lý do
cho từng con thì người dùng sẽ gõ “ok” cho nhanh, và cột đó thành vô nghĩa).
Dialog nói rõ một điều dễ hiểu sai:

> Chỉ đóng dòng nhật ký — **KHÔNG** đổi trạng thái con serial. Serial thuộc
> phiếu khác thì việc của nó nằm ở phiếu đó.

Quyền nút: `process` **hoặc** `create`, khớp
`RequireAnyPermission<Process, Create>` của
`POST {docId}/mismatches/{id}/resolve` — người đặt hàng riêng ra là SCS WH,
nhưng Office cũng phải đóng được một dòng đã xử lý xong.

### Nạp dữ liệu

Nạp **lazy** khi bung phiếu, song song với bảng pallet (`Task.WhenAll`) — hai
bảng không phụ thuộc nhau, nối tiếp là bắt người dùng chờ hai vòng mạng.

Luôn xin **cả** dòng đã xử lý (`openOnly: false`) rồi lọc ở client: con số cần
hiện là “còn bao nhiêu chưa xử lý”, mà muốn vẫn có con số đó khi người dùng bật
xem hết thì phải có cả hai nhóm trong tay. Nhật ký một phiếu nhiều lắm vài chục
dòng — không đáng một request nữa mỗi lần bật/tắt.

Lỗi thì coi như nhật ký rỗng, **không** làm chết cả màn hình: DB chưa chạy
`return_fa_pallet_schema.sql` thì endpoint này 500, mà màn Tái gia công vốn đã
chạy tốt từ trước mục 2d.

---

## 3. File trong gói

### API

| File | Việc |
|---|---|
| `Features/ReturnInstructions/ReturnInstructionEntity.cs` | + `AtFaQty` / `ReturnedQty` trên dòng và trên phiếu |
| `Features/ReturnInstructions/Api/ReturnInstructionModels.cs` | + 2 trường vào `ReturnInstructionResponse` (26 tham số) và `ReturnInstructionLineResponse` (10 tham số) |
| `Features/ReturnInstructions/DataAccess/ReturnInstructionRepository.cs` | mở rộng câu đếm serial + `ModelQty` |

**Không** thêm endpoint — `GET {docId}/mismatches` và
`POST {docId}/mismatches/{id}/resolve` đã có từ gói 2d.

### Web

| File | Việc |
|---|---|
| `Features/ReturnInstructions/Business/Models/ReturnInstructionModels.cs` | + `AtFaQty` / `ReturnedQty` / `HasFaFlow`, + `ReturnMismatchDto`, `ResolveMismatchRequestDto`, `ReturnMismatchReason` |
| `Features/ReturnInstructions/Client/IReturnInstructionApi.cs` | + `GetMismatchesAsync`, `ResolveMismatchAsync` |
| `App/Pages/ReworkRefurbish.razor` | cột Còn ở FA, 2 cột trên bảng dòng, dải vòng FA, khối nhật ký lệch, dialog đánh dấu đã xử lý |
| `App/Pages/ReworkRefurbish.razor.cs` | `LoadDetail` / `LoadMismatches` / `VisibleMismatches` / `OpenMismatchCount` / `ConfirmResolveMismatch` + `AtFaClass` / `MismatchPill` |
| `App/Pages/ReworkRefurbish.razor.css` | `.ri-atfa`, `.ri-faflow`, `.ri-mm-*` |
| `Resources/SharedResource.{vi,en,zh,ja}.resx` | **+31 khoá** mỗi file |

Lưu ý một chỗ dễ sai: route resolve nằm **trong** nhánh `{docId}`
(`/api/return-instructions/{docId}/mismatches/{id}/resolve`), nên client phải
truyền **cả hai** id — thiếu docId là 404. Server xử lý theo id dòng nhật ký.

---

## 4. Thứ tự áp

1. Giải nén `swms_3_receive_back.zip` (nếu chưa).
2. Giải nén gói này lên source, ghi đè.
3. Build API → build Web. **Không chạy SQL.**

Không cần gán quyền mới.

---

## 5. Đã kiểm

- cân `{}` `()` của 3 file API + 3 file Web C#, cân `{}` của CSS
- **đếm cột bảng**: bảng phiếu 13 `<th>` ↔ 13 `<td>` ↔ `colspan="13"`; bảng dòng
  9 ↔ 9, tfoot 8 ô + 1 `colspan=2` = 9; bảng nhật ký 8 ↔ 8
- cặp thẻ đóng/mở của `table/thead/tbody/tfoot/tr/td/th/div/span/label` — khớp hết
- `ReturnInstructionResponse` 26 tham số ↔ 26 đối số trong `From()`;
  `ReturnInstructionLineResponse` 10 ↔ 10
- **91 khoá dịch** màn này dùng: có đủ trong cả 4 file resx; số `{0}`/`{1}` khớp
  số đối số ở từng chỗ gọi; 4 tiền tố nội suy (`Return.GoodsType.`,
  `Return.Status.`, `Return.Mismatch.Reason.`, `Return.SerialStatus.`) đủ giá trị
- 4 resx well-formed, 2754 khoá (en 2741 — xem mục 6)
- chỉ `From()` dựng hai record đó, không có chỗ nào dựng theo thứ tự tham số

**Chưa build, chưa chạy** (container không có .NET SDK).

---

## 6. Một lỗi i18n CÓ TỪ TRƯỚC, không phải của gói này

Lúc kiểm resx tôi thấy bản Web của anh đang lệch khoá giữa các ngôn ngữ:

| File | Thiếu | Có thừa |
|---|---|---|
| `en` | 13 khoá `Inventory.Cmp.*` + `Inventory.Action.HdSync`, và `Nav.PdaLog` | `Nav.EmapKitting` |
| `zh`, `ja` | `Nav.PdaLog` | `Nav.EmapKitting` |

Hậu quả thật: **menu “PDA Log” hiện ra chữ `Nav.PdaLog`** ở cả 3 ngôn ngữ ngoài
tiếng Việt, và màn so sánh tồn kho hiện toàn khoá thô khi dùng tiếng Anh. Tôi
**không** sửa trong gói này vì nó ngoài phạm vi mục 2d/3 — nói để anh biết; cần
thì tôi làm một gói riêng.

---

## 7. Điểm còn mở

- `POST /api/pallets/split` vẫn **chưa** cập nhật
  `return_instruction_serials.pallet_id` — tách pallet RW/RB xong thì sổ serial
  còn trỏ pallet cũ.
- Toạ độ badge RW/RB trên tem TSPL (MJ8001) **chưa in thử thật**.
- Luật xử lý hàng **NG tại FA** vẫn chưa rõ — chưa có đường đi cho con `ng`,
  nên nó chỉ được đếm vào “thực nhận”, không vào “còn ở FA” lẫn “đã giao lại”.
- Mục 2c chưa khai mail event nào.
- Màn Tái gia công dùng API thô (`IReturnInstructionApi`), còn màn Chỉ thị back
  (2c) dùng lớp business — hai lối trong cùng một feature. Nên thống nhất một
  lần, nhưng không nên gộp vào gói đang làm dở quy trình.
