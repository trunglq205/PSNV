namespace Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business.Models;

// DTO khớp API (Features/ShipmentInstructions/Api/SiHdSoftCompareModels.cs bên server).
// Màn hình không dùng trực tiếp — SiHdSoftCompareBusiness map sang App* qua ToViewModel.

public class SiCompareSummaryDto
{
    public string SiNo { get; set; } = "";
    public string Result { get; set; } = "";            // match | mismatch | only_swms | only_hdsoft
    public int IssueCount { get; set; }
    public string? FirstIssue { get; set; }
    public bool IsCancelled { get; set; }
    public DateTime? EtdDate { get; set; }
    public DateTime? VanningDate { get; set; }

    public long? SwmsId { get; set; }
    public string? SwmsDocNo { get; set; }
    public string? SwmsStatus { get; set; }
    public DateTime? SwmsCreatedAt { get; set; }
    public int SwmsLineCount { get; set; }
    public int SwmsTotalQty { get; set; }

    public long? HdSoftOrderId { get; set; }
    public string? HdSoftDocNo { get; set; }
    public string? HdSoftStatus { get; set; }
    public string? HdSoftStatusName { get; set; }
    public DateTime? HdSoftCreatedAt { get; set; }
    public int HdSoftLineCount { get; set; }
    public decimal HdSoftTotalQty { get; set; }

    public static AppSiCompareSummary ToViewModel(SiCompareSummaryDto d) => new()
    {
        SiNo = d.SiNo,
        Result = d.Result,
        IssueCount = d.IssueCount,
        FirstIssue = d.FirstIssue,
        IsCancelled = d.IsCancelled,
        EtdDate = d.EtdDate,
        VanningDate = d.VanningDate,
        SwmsId = d.SwmsId,
        SwmsDocNo = d.SwmsDocNo,
        SwmsStatus = d.SwmsStatus,
        SwmsCreatedAt = d.SwmsCreatedAt,
        SwmsLineCount = d.SwmsLineCount,
        SwmsTotalQty = d.SwmsTotalQty,
        HdSoftOrderId = d.HdSoftOrderId,
        HdSoftDocNo = d.HdSoftDocNo,
        HdSoftStatus = d.HdSoftStatus,
        HdSoftStatusName = d.HdSoftStatusName,
        HdSoftCreatedAt = d.HdSoftCreatedAt,
        HdSoftLineCount = d.HdSoftLineCount,
        HdSoftTotalQty = d.HdSoftTotalQty,
    };
}

public class SiCompareFieldDto
{
    public string Field { get; set; } = "";
    public string Label { get; set; } = "";
    public string? Swms { get; set; }
    public string? HdSoft { get; set; }
    public string Status { get; set; } = "";            // match | diff | only_swms | only_hdsoft

    public static AppSiCompareField ToViewModel(SiCompareFieldDto d) => new(d.Field, d.Label, d.Swms, d.HdSoft, d.Status);
}

public class SiCompareLineDto
{
    public string Key { get; set; } = "";
    public string Model { get; set; } = "";
    public string? PackingListNo { get; set; }
    public string? PackingItemNo { get; set; }
    public string Status { get; set; } = "";            // match | qty_diff | field_diff | only_swms | only_hdsoft
    public int? SwmsQty { get; set; }
    public decimal? HdSoftQty { get; set; }
    public List<int>? SwmsLineNos { get; set; }
    public List<int>? HdSoftLineNos { get; set; }
    public int SwmsQtyPicked { get; set; }
    public int SwmsQtyCut { get; set; }
    public decimal HdSoftQtyDelivered { get; set; }
    public List<SiCompareFieldDto>? Fields { get; set; }
    public string? Note { get; set; }

    public static AppSiCompareLine ToViewModel(SiCompareLineDto d) => new()
    {
        Key = d.Key,
        Model = d.Model,
        PackingListNo = d.PackingListNo,
        PackingItemNo = d.PackingItemNo,
        Status = d.Status,
        SwmsQty = d.SwmsQty,
        HdSoftQty = d.HdSoftQty,
        SwmsLineNos = d.SwmsLineNos ?? new(),
        HdSoftLineNos = d.HdSoftLineNos ?? new(),
        SwmsQtyPicked = d.SwmsQtyPicked,
        SwmsQtyCut = d.SwmsQtyCut,
        HdSoftQtyDelivered = d.HdSoftQtyDelivered,
        Fields = (d.Fields ?? new()).Select(SiCompareFieldDto.ToViewModel).ToList(),
        Note = d.Note,
    };
}

public class SiCompareDetailDto
{
    public SiCompareSummaryDto Summary { get; set; } = new();
    public string LineKeyMode { get; set; } = "";       // packing | model
    public List<SiCompareFieldDto>? Header { get; set; }
    public List<SiCompareLineDto>? Lines { get; set; }
    public List<string>? Notes { get; set; }
    public DateTime ComparedAt { get; set; }

    public static AppSiCompare ToViewModel(SiCompareDetailDto d) => new()
    {
        Summary = SiCompareSummaryDto.ToViewModel(d.Summary),
        LineKeyMode = d.LineKeyMode,
        Header = (d.Header ?? new()).Select(SiCompareFieldDto.ToViewModel).ToList(),
        Lines = (d.Lines ?? new()).Select(SiCompareLineDto.ToViewModel).ToList(),
        Notes = d.Notes ?? new(),
        ComparedAt = d.ComparedAt,
    };
}

public class SiCompareListDto
{
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public string? Warehouse { get; set; }
    public int Total { get; set; }
    public int Matched { get; set; }
    public int Mismatched { get; set; }
    public int OnlySwms { get; set; }
    public int OnlyHdSoft { get; set; }
    public List<SiCompareSummaryDto>? Items { get; set; }
    public DateTime ComparedAt { get; set; }

    public static AppSiCompareList ToViewModel(SiCompareListDto d) => new()
    {
        From = d.From,
        To = d.To,
        Warehouse = d.Warehouse,
        Total = d.Total,
        Matched = d.Matched,
        Mismatched = d.Mismatched,
        OnlySwms = d.OnlySwms,
        OnlyHdSoft = d.OnlyHdSoft,
        Items = (d.Items ?? new()).Select(SiCompareSummaryDto.ToViewModel).ToList(),
        ComparedAt = d.ComparedAt,
    };
}
