using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.Stocktake.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.Stocktake.Api;

[ApiController]
[Route("api/stocktake")]
public class StocktakeController : ControllerBase
{
    private readonly IStocktakeService _service;
    public StocktakeController(IStocktakeService service) => _service = service;

    /// <summary>Danh sách phiếu kiểm kê (kèm số dòng / đã đếm / chênh lệch).</summary>
    [HttpGet("counts")]
    [RequirePermission<Perms.Storage.Stocktake.View>]
    public async Task<ActionResult<IReadOnlyList<CountSummaryResponse>>> GetCounts(
        [FromQuery] string? type, [FromQuery] string? status,
        [FromQuery] DateTime? from, [FromQuery] DateTime? to)
        => Ok(await _service.GetCountsAsync(type, status, from, to));

    /// <summary>Chi tiết 1 phiếu: header + các dòng (vị trí × pallet).</summary>
    [HttpGet("counts/{id:long}")]
    [RequirePermission<Perms.Storage.Stocktake.View>]
    public async Task<ActionResult<CountDetailResponse>> GetCount(long id)
        => Ok(await _service.GetCountAsync(id));

    /// <summary>Xem trước số vị trí/pallet sẽ kiểm (không tạo phiếu).</summary>
    [HttpGet("preview")]
    [RequirePermission<Perms.Storage.Stocktake.Create>]
    public async Task<ActionResult<CountPreviewResponse>> Preview(
        [FromQuery] string type, [FromQuery] string[]? areaCodes = null)
        => Ok(await _service.PreviewAsync(type, areaCodes));

    /// <summary>
    /// Tạo phiếu kiểm kê. morning = ô có biến động hôm qua trên mọi bản đồ lưu kho;
    /// monthly = các ô đang có hàng của những bản đồ được chọn, rỗng = mọi bản đồ lưu kho.
    /// </summary>
    [HttpPost("counts")]
    [RequirePermission<Perms.Storage.Stocktake.Create>]
    public async Task<ActionResult<CreateCountResult>> Create([FromBody] CreateCountRequest request)
        => Ok(await _service.CreateAsync(request));

    /// <summary>Xuất báo cáo Excel (.xlsx) của phiếu kiểm kê.</summary>
    [HttpGet("counts/{id:long}/report.xlsx")]
    [RequirePermission<Perms.Storage.Stocktake.View>]
    public async Task<IActionResult> Report(long id)
    {
        var (bytes, fileName) = await _service.BuildReportAsync(id);
        return File(bytes, "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", fileName);
    }

    /// <summary>Đóng phiếu khi PDA xác nhận kiểm xong (pending/counting → closed).</summary>
    [HttpPost("counts/{id:long}/close")]
    [RequirePermission<Perms.Storage.Stocktake.Count>]
    public async Task<IActionResult> Close(long id)
    {
        await _service.CloseAsync(id);
        return NoContent();
    }

    /// <summary>Ghi pallet phát sinh: pallet tìm thấy ở ô này nhưng hệ thống không ghi ở đây.</summary>
    [HttpPost("counts/{id:long}/found")]
    [RequirePermission<Perms.Storage.Stocktake.Count>]
    public async Task<ActionResult<AddFoundResponse>> AddFound(long id, [FromBody] AddFoundRequest request)
        => Ok(await _service.AddFoundAsync(id, request));

    /// <summary>Ghi chú cho 1 dòng — lý do lệch, tình trạng thực tế. Không đụng số đếm.</summary>
    [HttpPost("counts/lines/{lineId:long}/note")]
    [RequirePermission<Perms.Storage.Stocktake.Count>]
    public async Task<IActionResult> SetNote(long lineId, [FromBody] SetNoteRequest request)
    {
        await _service.SetNoteAsync(lineId, request);
        return Ok();
    }

    /// <summary>Nhập/sửa số đếm cho 1 dòng (thường từ PDA).</summary>
    [HttpPost("counts/lines/{lineId:long}/count")]
    [RequirePermission<Perms.Storage.Stocktake.Count>]
    public async Task<IActionResult> SetCount(long lineId, [FromBody] SetCountRequest request)
    {
        await _service.SetCountAsync(lineId, request);
        return NoContent();
    }
}
