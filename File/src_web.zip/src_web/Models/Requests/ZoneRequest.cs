﻿namespace SWMS_WebTool.Models.Requests
{
    public record ZoneRequest
    {
        public long ZoneId { get; set; } = 0;
        public string ZoneName { get; set; }
        public long FloorId { get; set; }             
        public int Height { get; set; }
        public int Width { get; set; }
        public int X { get; set; }
        public int Y { get; set; }
        public string ZoneType { get; set; }

        public string Category { get; set; } = string.Empty;

        public string ImageName { get; set; } = string.Empty;
        public bool IsActive { get; set; }
        public bool IsJIT { get; set; }
    }
}
