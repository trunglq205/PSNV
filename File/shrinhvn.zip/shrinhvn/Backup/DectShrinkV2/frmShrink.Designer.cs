﻿namespace DectShrinkV2
{
    partial class frmShrink
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmShrink));
            this.btnResetText = new System.Windows.Forms.Button();
            this.txtQuantyStanddard = new System.Windows.Forms.TextBox();
            this.btnClose = new System.Windows.Forms.Button();
            this.txtPallet = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.lblSerialDouble = new System.Windows.Forms.Label();
            this.listView1 = new System.Windows.Forms.ListView();
            this.lblStatus = new System.Windows.Forms.Label();
            this.txtExtension = new System.Windows.Forms.ComboBox();
            this.txtSerial = new System.Windows.Forms.TextBox();
            this.txtRescan = new System.Windows.Forms.TextBox();
            this.txtByHand = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.lblSerial = new System.Windows.Forms.Label();
            this.lbl_ScanModelAgain = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lblSTT = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.lblYear = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.txtScanned = new System.Windows.Forms.TextBox();
            this.mdaShrink = new AxWMPLib.AxWindowsMediaPlayer();
            this.txtQtyPalletFix = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.btnEditQty = new System.Windows.Forms.Button();
            this.label10 = new System.Windows.Forms.Label();
            this.numericUpDown1 = new System.Windows.Forms.NumericUpDown();
            this.chk_Outer_carton = new System.Windows.Forms.CheckBox();
            this.button1 = new System.Windows.Forms.Button();
            this.lblCategory = new System.Windows.Forms.Label();
            this.groupBox2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mdaShrink)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).BeginInit();
            this.SuspendLayout();
            // 
            // btnResetText
            // 
            this.btnResetText.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResetText.Location = new System.Drawing.Point(714, 89);
            this.btnResetText.Name = "btnResetText";
            this.btnResetText.Size = new System.Drawing.Size(304, 48);
            this.btnResetText.TabIndex = 23;
            this.btnResetText.Text = "Xóa trắng và quét lại";
            this.btnResetText.UseVisualStyleBackColor = true;
            this.btnResetText.Click += new System.EventHandler(this.btnResetText_Click_1);
            // 
            // txtQuantyStanddard
            // 
            this.txtQuantyStanddard.Enabled = false;
            this.txtQuantyStanddard.Font = new System.Drawing.Font("Courier New", 20F, System.Drawing.FontStyle.Bold);
            this.txtQuantyStanddard.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtQuantyStanddard.Location = new System.Drawing.Point(338, 95);
            this.txtQuantyStanddard.Name = "txtQuantyStanddard";
            this.txtQuantyStanddard.Size = new System.Drawing.Size(150, 38);
            this.txtQuantyStanddard.TabIndex = 22;
            // 
            // btnClose
            // 
            this.btnClose.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClose.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnClose.Location = new System.Drawing.Point(573, 92);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(112, 49);
            this.btnClose.TabIndex = 21;
            this.btnClose.Text = "Quay lại";
            this.btnClose.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtPallet
            // 
            this.txtPallet.Enabled = false;
            this.txtPallet.Font = new System.Drawing.Font("Courier New", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtPallet.Location = new System.Drawing.Point(1072, 12);
            this.txtPallet.Name = "txtPallet";
            this.txtPallet.Size = new System.Drawing.Size(276, 49);
            this.txtPallet.TabIndex = 19;
            this.txtPallet.Visible = false;
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.lblSerialDouble);
            this.groupBox2.Controls.Add(this.listView1);
            this.groupBox2.Controls.Add(this.lblStatus);
            this.groupBox2.Controls.Add(this.txtExtension);
            this.groupBox2.Controls.Add(this.txtSerial);
            this.groupBox2.Controls.Add(this.txtRescan);
            this.groupBox2.Controls.Add(this.txtByHand);
            this.groupBox2.Controls.Add(this.label4);
            this.groupBox2.Controls.Add(this.lblSerial);
            this.groupBox2.Controls.Add(this.lbl_ScanModelAgain);
            this.groupBox2.Controls.Add(this.label1);
            this.groupBox2.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(72, 376);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(1262, 418);
            this.groupBox2.TabIndex = 18;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "MODEL";
            // 
            // lblSerialDouble
            // 
            this.lblSerialDouble.AutoSize = true;
            this.lblSerialDouble.Font = new System.Drawing.Font("Courier New", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSerialDouble.Location = new System.Drawing.Point(425, 200);
            this.lblSerialDouble.Name = "lblSerialDouble";
            this.lblSerialDouble.Size = new System.Drawing.Size(0, 73);
            this.lblSerialDouble.TabIndex = 29;
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(940, 26);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(311, 386);
            this.listView1.TabIndex = 28;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // lblStatus
            // 
            this.lblStatus.BackColor = System.Drawing.Color.WhiteSmoke;
            this.lblStatus.Font = new System.Drawing.Font("Courier New", 50F, System.Drawing.FontStyle.Bold);
            this.lblStatus.Location = new System.Drawing.Point(19, 239);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(912, 163);
            this.lblStatus.TabIndex = 26;
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // txtExtension
            // 
            this.txtExtension.Enabled = false;
            this.txtExtension.Font = new System.Drawing.Font("Courier New", 20F, System.Drawing.FontStyle.Bold);
            this.txtExtension.FormattingEnabled = true;
            this.txtExtension.Location = new System.Drawing.Point(802, 28);
            this.txtExtension.Name = "txtExtension";
            this.txtExtension.Size = new System.Drawing.Size(121, 39);
            this.txtExtension.TabIndex = 25;
            // 
            // txtSerial
            // 
            this.txtSerial.Font = new System.Drawing.Font("Courier New", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtSerial.Location = new System.Drawing.Point(298, 148);
            this.txtSerial.Name = "txtSerial";
            this.txtSerial.Size = new System.Drawing.Size(495, 49);
            this.txtSerial.TabIndex = 1;
            this.txtSerial.TextChanged += new System.EventHandler(this.txtSerial_TextChanged);
            this.txtSerial.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSerial_KeyUp);
            // 
            // txtRescan
            // 
            this.txtRescan.Font = new System.Drawing.Font("Courier New", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtRescan.Location = new System.Drawing.Point(298, 87);
            this.txtRescan.Name = "txtRescan";
            this.txtRescan.Size = new System.Drawing.Size(495, 49);
            this.txtRescan.TabIndex = 0;
            this.txtRescan.TextChanged += new System.EventHandler(this.txtRescan_TextChanged);
            this.txtRescan.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtRescan_KeyUp);
            // 
            // txtByHand
            // 
            this.txtByHand.Enabled = false;
            this.txtByHand.Font = new System.Drawing.Font("Courier New", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtByHand.Location = new System.Drawing.Point(298, 28);
            this.txtByHand.Name = "txtByHand";
            this.txtByHand.Size = new System.Drawing.Size(495, 49);
            this.txtByHand.TabIndex = 0;
            this.txtByHand.TextChanged += new System.EventHandler(this.txtByHand_TextChanged);
            this.txtByHand.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtByHand_KeyUp);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(22, 162);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(0, 22);
            this.label4.TabIndex = 0;
            // 
            // lblSerial
            // 
            this.lblSerial.AutoSize = true;
            this.lblSerial.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSerial.Location = new System.Drawing.Point(18, 156);
            this.lblSerial.Name = "lblSerial";
            this.lblSerial.Size = new System.Drawing.Size(138, 27);
            this.lblSerial.TabIndex = 0;
            this.lblSerial.Text = "Số SERIAL";
            // 
            // lbl_ScanModelAgain
            // 
            this.lbl_ScanModelAgain.AutoSize = true;
            this.lbl_ScanModelAgain.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_ScanModelAgain.Location = new System.Drawing.Point(18, 96);
            this.lbl_ScanModelAgain.Name = "lbl_ScanModelAgain";
            this.lbl_ScanModelAgain.Size = new System.Drawing.Size(208, 27);
            this.lbl_ScanModelAgain.TabIndex = 0;
            this.lbl_ScanModelAgain.Text = "Scan lại model";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(18, 36);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 27);
            this.label1.TabIndex = 0;
            this.label1.Text = "MODEL";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(77, 102);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(219, 22);
            this.label3.TabIndex = 13;
            this.label3.Text = "Số lượng Tiêu chuẩn";
            // 
            // lblSTT
            // 
            this.lblSTT.AutoSize = true;
            this.lblSTT.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSTT.Location = new System.Drawing.Point(421, 29);
            this.lblSTT.Name = "lblSTT";
            this.lblSTT.Size = new System.Drawing.Size(0, 27);
            this.lblSTT.TabIndex = 15;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(389, 29);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(26, 27);
            this.label8.TabIndex = 17;
            this.label8.Text = "/";
            // 
            // lblYear
            // 
            this.lblYear.AutoSize = true;
            this.lblYear.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblYear.Location = new System.Drawing.Point(220, 29);
            this.lblYear.Name = "lblYear";
            this.lblYear.Size = new System.Drawing.Size(0, 27);
            this.lblYear.TabIndex = 16;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Courier New", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(80, 29);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(96, 27);
            this.label6.TabIndex = 14;
            this.label6.Text = "PALLET";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(77, 144);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(87, 22);
            this.label7.TabIndex = 13;
            this.label7.Text = "Đã quét";
            // 
            // txtScanned
            // 
            this.txtScanned.Enabled = false;
            this.txtScanned.Font = new System.Drawing.Font("Courier New", 20F, System.Drawing.FontStyle.Bold);
            this.txtScanned.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtScanned.Location = new System.Drawing.Point(338, 142);
            this.txtScanned.Name = "txtScanned";
            this.txtScanned.Size = new System.Drawing.Size(150, 38);
            this.txtScanned.TabIndex = 22;
            // 
            // mdaShrink
            // 
            this.mdaShrink.Enabled = true;
            this.mdaShrink.Location = new System.Drawing.Point(1340, 688);
            this.mdaShrink.Name = "mdaShrink";
            this.mdaShrink.OcxState = ((System.Windows.Forms.AxHost.State)(resources.GetObject("mdaShrink.OcxState")));
            this.mdaShrink.Size = new System.Drawing.Size(8, 47);
            this.mdaShrink.TabIndex = 24;
            // 
            // txtQtyPalletFix
            // 
            this.txtQtyPalletFix.Font = new System.Drawing.Font("Courier New", 30F, System.Drawing.FontStyle.Bold);
            this.txtQtyPalletFix.ForeColor = System.Drawing.SystemColors.MenuHighlight;
            this.txtQtyPalletFix.Location = new System.Drawing.Point(338, 191);
            this.txtQtyPalletFix.Name = "txtQtyPalletFix";
            this.txtQtyPalletFix.Size = new System.Drawing.Size(150, 53);
            this.txtQtyPalletFix.TabIndex = 26;
            this.txtQtyPalletFix.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtQtyPalletFix_KeyDown);
            this.txtQtyPalletFix.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtQtyPalletFix_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(77, 194);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(252, 22);
            this.label9.TabIndex = 25;
            this.label9.Text = "Số lượng Pallet(Fixed)";
            // 
            // btnEditQty
            // 
            this.btnEditQty.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnEditQty.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnEditQty.Location = new System.Drawing.Point(714, 199);
            this.btnEditQty.Name = "btnEditQty";
            this.btnEditQty.Size = new System.Drawing.Size(304, 49);
            this.btnEditQty.TabIndex = 27;
            this.btnEditQty.Text = "Sửa Số lượng Pallet";
            this.btnEditQty.UseVisualStyleBackColor = true;
            this.btnEditQty.Click += new System.EventHandler(this.btnEditQty_Click);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Courier New", 20F, System.Drawing.FontStyle.Bold);
            this.label10.ForeColor = System.Drawing.Color.Blue;
            this.label10.Location = new System.Drawing.Point(523, 292);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(110, 31);
            this.label10.TabIndex = 33;
            this.label10.Text = "/Outer";
            // 
            // numericUpDown1
            // 
            this.numericUpDown1.Font = new System.Drawing.Font("Courier New", 20F, System.Drawing.FontStyle.Bold);
            this.numericUpDown1.ForeColor = System.Drawing.Color.Blue;
            this.numericUpDown1.Location = new System.Drawing.Point(430, 288);
            this.numericUpDown1.Name = "numericUpDown1";
            this.numericUpDown1.Size = new System.Drawing.Size(87, 38);
            this.numericUpDown1.TabIndex = 32;
            this.numericUpDown1.KeyDown += new System.Windows.Forms.KeyEventHandler(this.numericUpDown1_KeyDown);
            // 
            // chk_Outer_carton
            // 
            this.chk_Outer_carton.AutoSize = true;
            this.chk_Outer_carton.Font = new System.Drawing.Font("Courier New", 20F, System.Drawing.FontStyle.Bold);
            this.chk_Outer_carton.ForeColor = System.Drawing.Color.Blue;
            this.chk_Outer_carton.Location = new System.Drawing.Point(72, 291);
            this.chk_Outer_carton.Name = "chk_Outer_carton";
            this.chk_Outer_carton.Size = new System.Drawing.Size(305, 35);
            this.chk_Outer_carton.TabIndex = 31;
            this.chk_Outer_carton.Text = "Scan Outer Carton";
            this.chk_Outer_carton.UseVisualStyleBackColor = true;
            this.chk_Outer_carton.CheckedChanged += new System.EventHandler(this.chk_Outer_carton_CheckedChanged);
            // 
            // button1
            // 
            this.button1.Font = new System.Drawing.Font("Courier New", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.button1.Location = new System.Drawing.Point(714, 284);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(304, 49);
            this.button1.TabIndex = 34;
            this.button1.Text = "Sửa Số lượng Outer Carton";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // lblCategory
            // 
            this.lblCategory.AutoSize = true;
            this.lblCategory.Font = new System.Drawing.Font("Courier New", 30F, System.Drawing.FontStyle.Bold);
            this.lblCategory.Location = new System.Drawing.Point(799, 15);
            this.lblCategory.Name = "lblCategory";
            this.lblCategory.Size = new System.Drawing.Size(212, 46);
            this.lblCategory.TabIndex = 35;
            this.lblCategory.Text = "Category";
            // 
            // frmShrink
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1368, 806);
            this.Controls.Add(this.lblCategory);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.numericUpDown1);
            this.Controls.Add(this.chk_Outer_carton);
            this.Controls.Add(this.btnEditQty);
            this.Controls.Add(this.txtQtyPalletFix);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.mdaShrink);
            this.Controls.Add(this.btnResetText);
            this.Controls.Add(this.txtScanned);
            this.Controls.Add(this.txtQuantyStanddard);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtPallet);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.lblSTT);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.lblYear);
            this.Controls.Add(this.label6);
            this.KeyPreview = true;
            this.Name = "frmShrink";
            this.Text = "Shrink";
            this.Load += new System.EventHandler(this.frmShrink_Load);
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.mdaShrink)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.numericUpDown1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnResetText;
        private System.Windows.Forms.TextBox txtQuantyStanddard;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtPallet;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox txtSerial;
        private System.Windows.Forms.TextBox txtRescan;
        private System.Windows.Forms.TextBox txtByHand;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label lblSerial;
        private System.Windows.Forms.Label lbl_ScanModelAgain;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lblSTT;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lblYear;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txtScanned;
        private AxWMPLib.AxWindowsMediaPlayer mdaShrink;
        private System.Windows.Forms.ComboBox txtExtension;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.TextBox txtQtyPalletFix;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Button btnEditQty;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.NumericUpDown numericUpDown1;
        private System.Windows.Forms.CheckBox chk_Outer_carton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label lblCategory;
        private System.Windows.Forms.Label lblSerialDouble;
    }
}