﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;

namespace SWMS_WebTool.ViewModels
{
    public class UserViewModel : TableViewModel<User, UserFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, UserFilter? filter = null)
        {
            return new
            {
                Id = filter?.UId ?? Filter.UId,
                FullName = filter?.FullName ?? Filter.FullName,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
    public class CreateUpdateUserViewModel
    {
        public string ID { get; set; }           // ID của người dùng
        public string FullName { get; set; }      // Tên đầy đủ của người dùng
        public int Section { get; set; }            // Mã của Section (bộ phận)
        public int Role { get; set; }    // Vai trò người dùng
        public List<string> WebRole { get; set; }     // Danh sách các vai trò WebRole của người dùng
        public List<string> PDARole { get; set; }     // Danh sách các vai trò PDARole của người dùng

        public CreateUpdateUserViewModel()
        {
            WebRole = new List<string>();             // Khởi tạo danh sách trống cho WebRole
            PDARole = new List<string>();             // Khởi tạo danh sách trống cho PDARole
        }
    }
}
