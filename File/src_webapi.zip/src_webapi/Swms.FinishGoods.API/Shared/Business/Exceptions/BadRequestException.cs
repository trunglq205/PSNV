namespace Swms.FinishGoods.API.Common.Business.Exceptions;

public class BadRequestException : Exception
{
    public BadRequestException(string message) : base(message) { }
}
