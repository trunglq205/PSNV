﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.Extensions.Localization;
using Microsoft.JSInterop;
using Swms.FinishGoods.Web.Features.MapView.Business;
using Swms.FinishGoods.Web.Features.MapView.Business.Models;
using Swms.FinishGoods.Web.Features.StorageMap.Business;
using Swms.FinishGoods.Web.Features.StorageMap.Business.Models;
using Swms.FinishGoods.Web.Features.WarehouseAreas.Business;
using Swms.FinishGoods.Web.Features.WarehouseAreas.Business.Models;
using Swms.FinishGoods.Web.Resources;

namespace Swms.FinishGoods.Web.Features.MapView.App.Components;

/// <summary>
/// Canvas XEM bản đồ dùng chung cho Storage / Receiving / Vanning.
/// Chỉ khác nhau ở tham số MapType (lọc dropdown).
/// </summary>
public partial class MapViewCanvas : ComponentBase, IAsyncDisposable
{
    /// <summary>storing | receiving | vanning</summary>
    [Parameter, EditorRequired] public string MapType { get; set; } = "storing";

    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private IWarehouseAreasBusiness Maps { get; set; } = default!;
    [Inject] private IMapViewBusiness ViewApi { get; set; } = default!;
    [Inject] private IStorageMapBusiness StorageMap { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;

    private ElementReference _el;
    private DotNetObjectReference<MapViewCanvas>? _ref;
    private bool _inited;

    private List<WarehouseAreaSummaryDto> _maps = new();
    private string _areaCode = string.Empty;
    private MapViewLayoutDto? _layout;
    private string? _error;

    // Modal mặt đứng kệ (chỉ xem)
    private bool _showElev, _loadingElev;
    private string? _elevRack;
    private RackElevationDto? _elev;

    private string StorageKey => $"swms.mapview.{MapType}";

    protected override async Task OnInitializedAsync()
    {
        _maps = await Maps.ListAsync(MapType);
        if (_maps.Count > 0) _areaCode = _maps[0].AreaCode;
    }

    /// <summary>Lấy map đã chọn lần trước (theo từng loại) từ localStorage.</summary>
    private async Task RestoreLastMapAsync()
    {
        try
        {
            var saved = await JS.InvokeAsync<string?>("localStorage.getItem", StorageKey);
            if (!string.IsNullOrWhiteSpace(saved) && _maps.Any(m => m.AreaCode == saved))
                _areaCode = saved!;
        }
        catch { /* trình duyệt chặn storage -> dùng map đầu danh sách */ }
    }

    private async Task RememberMapAsync()
    {
        try { await JS.InvokeVoidAsync("localStorage.setItem", StorageKey, _areaCode); }
        catch { }
    }

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (_inited || _maps.Count == 0 || _error is not null) return;
        _inited = true;
        _ref = DotNetObjectReference.Create(this);
        await RestoreLastMapAsync();
        StateHasChanged();              // dropdown hiển thị đúng map đã nhớ
        await LoadAndInitAsync();
    }

    private async Task LoadAndInitAsync()
    {
        var r = await ViewApi.GetAsync(_areaCode);
        if (!r.IsSuccess || r.Value is null)
        {
            _error = r.ErrorMessage ?? L["MapDesign.Err.LoadFailed"];
            StateHasChanged();
            return;
        }
        _layout = r.Value;
        try
        {
            await JS.InvokeVoidAsync("swmsTempLocMap.init", _el, _ref, new
            {
                layout = ToTempLocLayout(_layout!),
                i18n = BuildI18n(),
                canEdit = false,                       // trang xem: không sửa layout
                areaCode = _areaCode,
                mapType = MapType,                     // vanning: chú thích chỉ hiện trạng thái đang có
                // Panel trái của engine dựng dropdown chọn bản đồ + thống kê chiếm chỗ.
                maps = _maps.Select(m => new { areaCode = m.AreaCode, areaName = m.AreaName }).ToList(),
                summary = _layout?.Summary,
                refreshUrl = $"/receiving-map/refresh?area={_areaCode}",
                refreshIntervalMs = 120000
            });
        }
        catch (JSException ex) { _error = $"[MapView] {ex.Message}"; }
        StateHasChanged();
    }

    /// <summary>Engine gọi khi đổi bản đồ trong panel trái.</summary>
    [JSInvokable]
    public async Task OnMapSelectedJs(string areaCode)
    {
        if (string.IsNullOrWhiteSpace(areaCode) || areaCode == _areaCode) return;
        _areaCode = areaCode;
        await OnMapChanged();
    }

    /// <summary>Người dùng đổi bản đồ trong dropdown.</summary>
    private async Task OnMapSelected(ChangeEventArgs e)
    {
        var code = e.Value?.ToString();
        if (string.IsNullOrWhiteSpace(code) || code == _areaCode) return;
        _areaCode = code;
        await OnMapChanged();
    }

    private async Task OnMapChanged()
    {
        _error = null;
        await RememberMapAsync();
        var r = await ViewApi.GetAsync(_areaCode);
        if (!r.IsSuccess || r.Value is null)
        {
            _error = r.ErrorMessage ?? L["MapDesign.Err.LoadFailed"];
            return;
        }
        _layout = r.Value;
        // Engine TempLoc dựng lại toàn bộ khi đổi map.
        try { await JS.InvokeVoidAsync("swmsTempLocMap.destroy", _el); } catch { }
        _inited = false;
        await LoadAndInitAsync();
    }

    [JSInvokable]
    public async Task OnOpenRack(string rackCode)
    {
        if (string.IsNullOrWhiteSpace(rackCode)) return;
        _elevRack = rackCode; _elev = null; _showElev = true; _loadingElev = true;
        StateHasChanged();

        var r = await StorageMap.GetElevationAsync(rackCode, _areaCode);
        _elev = r.IsSuccess ? r.Value : null;
        _loadingElev = false;
        StateHasChanged();
    }

    [JSInvokable]
    public Task OnOpenPallet(string locatorCode)
    {
        // Chỗ này có thể mở panel lot chi tiết ở bước sau.
        return Task.CompletedTask;
    }

    private void CloseElev() { _showElev = false; _elev = null; _elevRack = null; }

    /// <summary>Chuyển layout chung sang format cell mà engine TempLoc hiểu (thêm loại rack).</summary>
    private static object ToTempLocLayout(MapViewLayoutDto l) => new
    {
        areaCode = l.AreaCode,
        cols = l.Cols,
        rows = l.Rows,
        cellMeters = l.CellMeters,
        summary = l.Summary,
        cells = l.Blocks.Select(b => new
        {
            id = b.Id,
            code = b.Kind == "rack" ? b.RackCode : b.LocatorCode,
            cellType = b.Kind,                    // rack | pallet | zone
            gridX = b.GridX, gridY = b.GridY, gridW = b.GridW, gridH = b.GridH,
            arrow = b.Arrow,
            color = b.Color,
            label = b.Label,
            status = b.Status,
            model = b.Model,
            lotNo = (string?)null,
            sortOrder = 0,
            isUrgent = b.IsUrgent,
            disposition = b.Disposition,
            // riêng cho khối kệ
            rackCode = b.RackCode,
            totalSlots = b.TotalSlots,
            occupiedSlots = b.OccupiedSlots,
            positions = b.Positions.Select(p => new
            {
                position = p.Position, total = p.Total, occupied = p.Occupied
            }),
            lots = b.Lots.Select(x => new
            {
                lotId = x.LotId,
                lotNo = x.PalletId,
                inspectionStatus = x.Status,
                mappedStatus = x.Status,
                isUrgent = x.IsUrgent,
                boxCount = x.BoxCount,
                models = x.Model,
                productionDate = x.ProductionDate,
                // Dấu RW/RB — mọi bản đồ dùng chung component này đều vẽ được
                // chip cạnh Pallet ID. Pallet tái gia công mang 'ng' y hệt
                // pallet OQC đánh fail nên không có dấu thì không phân biệt nổi.
                disposition = x.Disposition
            })
        })
    };

    private Dictionary<string, string> BuildI18n()
    {
        var keys = new[]
        {
            // nhãn khối thống kê chiếm chỗ ở panel trái
            "MapView.Sum.Title","MapView.Sum.Occupied","MapView.Sum.Free","MapView.Sum.Total",
            "TempLoc.Title","TempLoc.Subtitle","TempLoc.ModeView","TempLoc.ModeEdit",
            "TempLoc.Lots.Title","TempLoc.Lots.Empty","TempLoc.Lots.Boxes","TempLoc.Lots.DblClickHint","TempLoc.Lots.BoxCol","TempLoc.Lots.DateCol","TempLoc.Op.ModelSearch","TempLoc.Op.ModelPlaceholder","TempLoc.Op.StatusTitle","TempLoc.Op.NewLotsTitle","TempLoc.Op.NoNewLots","TempLoc.Op.FoundAt","TempLoc.Op.NotFound","TempLoc.Rt.Fresh","TempLoc.Rt.Stale",
            "TempLoc.PrintQR","TempLoc.New","TempLoc.Save","TempLoc.Saved",
            "TempLoc.Tool.Section","TempLoc.Tool.Select","TempLoc.Tool.Erase","TempLoc.Tool.DrawSection",
            "TempLoc.Tool.Pallet","TempLoc.Tool.Zone","TempLoc.Tool.PalletRow","TempLoc.Tool.UtilSection",
            "TempLoc.Tool.Renumber","TempLoc.Tool.Hint",
            "TempLoc.Insp.Title","TempLoc.Insp.CellInfo","TempLoc.Insp.Hint","TempLoc.Insp.Empty","TempLoc.Insp.ClickHint",
            "TempLoc.Field.CellType","TempLoc.Field.Status","TempLoc.Field.StatusQuick","TempLoc.Field.PlName",
            "TempLoc.Field.Model","TempLoc.Field.Arrow","TempLoc.Field.ZoneColor","TempLoc.Field.ZoneLabel",
            "TempLoc.Field.Pos","TempLoc.Field.Size","TempLoc.Field.Position","TempLoc.Field.DirLabel",
            "TempLoc.ZonePlaceholder","TempLoc.ZoneCell","TempLoc.ZoneNoPallet",
            "TempLoc.Btn.Dup","TempLoc.Btn.Del","TempLoc.Btn.PrintOne","TempLoc.Btn.PrintThis",
            "TempLoc.Status.Empty","TempLoc.Status.Urgent","TempLoc.Status.NotInspected","TempLoc.Status.UnderInspection",
            "TempLoc.Status.Ng","TempLoc.Status.PendingResult","TempLoc.Status.InspectionExempt","TempLoc.Status.Pass",
            "TempLoc.Dir.Up","TempLoc.Dir.Down","TempLoc.Dir.Left","TempLoc.Dir.Right",
            "TempLoc.TotalCells","TempLoc.Legend",
            "TempLoc.Toast.Undo","TempLoc.Toast.SampleLoaded","TempLoc.Toast.BlankCreated","TempLoc.Toast.NoPrint",
            "TempLoc.Toast.Created","TempLoc.Toast.Renumbered",
            "TempLoc.Modal.New","TempLoc.Modal.AreaName","TempLoc.Modal.Size","TempLoc.Modal.NewHint",
            "TempLoc.Modal.LoadSample","TempLoc.Modal.CreateBlank","TempLoc.Modal.Cancel",
            "TempLoc.Row.Title","TempLoc.Row.Count","TempLoc.Row.Direction","TempLoc.Row.Vertical",
            "TempLoc.Row.Horizontal","TempLoc.Row.StartName","TempLoc.Row.ArrowDir","TempLoc.Row.Create","TempLoc.Arrow.None",
            "TempLoc.Print.Title","TempLoc.Print.Hint","TempLoc.Print.Scope","TempLoc.Print.ScopeAll",
            "TempLoc.Print.ScopeSel","TempLoc.Print.ScopeRange","TempLoc.Print.RangeLabel","TempLoc.Print.Go",
        };
        var d = new Dictionary<string, string>(keys.Length);
        foreach (var k in keys) d[k] = L[k];
        return d;
    }

    public async ValueTask DisposeAsync()
    {
        try { await JS.InvokeVoidAsync("swmsTempLocMap.destroy", _el); } catch { }
        _ref?.Dispose();
    }
}
