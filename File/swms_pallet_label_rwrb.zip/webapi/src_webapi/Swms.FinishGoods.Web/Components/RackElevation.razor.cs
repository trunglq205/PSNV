using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Microsoft.JSInterop;
using Swms.FinishGoods.Web.Features.StorageMap.Business.Models;
using Swms.FinishGoods.Web.Features.StorageMap.Client;
using Swms.FinishGoods.Web.Resources;

namespace Swms.FinishGoods.Web.Features.StorageMap.App.Components;

// Mặt cắt 1 kệ. Lưới = vị trí × tầng. Ô pallet = 1 ô to; ô GIÁ LỬNG = 1 ô chia ngang
// 2 ngăn (locator rack_level 'A' dưới / 'B' trên); ô không có locator = X.
public partial class RackElevation
{
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private IStorageMapApi Api { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;

    [Parameter] public RackElevationDto? Elev { get; set; }
    /// <summary>Map đang xem — để sửa ô đúng bản đồ khi hệ có nhiều map.</summary>
    [Parameter] public string? AreaCode { get; set; }
    /// <summary>Cho phép sửa cấu trúc ô (pallet/giá lửng/không dùng). Chỉ bật ở Map Designer.</summary>
    [Parameter] public bool CanEdit { get; set; }

    private Dictionary<(int Loc, int Floor), List<ElevationCellDto>> _cellMap = new();
    private int _totalSlots, _occupied, _empty, _shelf;
    private string? _filter;                 // null | "empty" | "occ" | "shelf"
    private int? _selLoc, _selFl;
    private string? _selLevel;               // null=ô pallet/cả ô; 'A'/'B'=ngăn giá lửng
    private string? _selCode;                 // mã locator đang chọn (cho QR)
    private string? _selQr;                   // ảnh QR (data-uri) của mã đang chọn
    private ElevationCellDto? _selData;       // dữ liệu ô/ngăn đang chọn (model, số lượng, disposition…)

    private static string DispLabel(string? d) => d switch
    {
        "refurbish" => "Refurbish",
        "rework" => "Rework",
        _ => ""
    };
    private static string DispClass(string? d) => d switch
    {
        "refurbish" => "refurb",
        "rework" => "rework",
        _ => ""
    };
    /// <summary>
    /// Ký hiệu 2 chữ trên ô giá. GIỮ KHỚP với badge in trên TEM PALLET
    /// (<c>QrLabelData.badgeForDisposition</c> bên PDA) — người trong kho đọc
    /// tem rồi đối chiếu bản đồ, hai chỗ ghi khác nhau là họ phải dịch trong
    /// đầu. Trước đây chỗ này ghi RE cho refurbish, đã đổi về RB.
    /// </summary>
    private static string DispCode(ElevationCellDto? c) => c is { Occupied: true }
        ? c.Disposition switch { "refurbish" => "RB", "rework" => "RW", _ => "" } : "";
    private static bool IsStop(ElevationCellDto? c) => c is { Occupied: true, StopShipment: true };

    /// <summary>Thứ tự hiển thị trạng thái trong chú thích.</summary>
    private static readonly string[] StatusOrder =
        { "not_inspected", "under_inspection", "pending_result", "inspection_exempt", "pass", "ng" };

    /// <summary>Trạng thái đang thật sự có trong kệ này (chú thích không liệt kê trạng thái không dùng).</summary>
    private IEnumerable<string> StatusesInRack()
    {
        // Elev là [Parameter] nullable: lần render đầu, hoặc khi màn ngoài chưa
        // tải xong kệ, nó là null. Dùng cùng cách phòng null như BuildCellMap().
        var cells = Elev?.Cells ?? new List<ElevationCellDto>();
        return StatusOrder.Where(st => cells.Any(c => c.Occupied && c.Status == st));
    }

    private string StatusLabel(string status) => status switch
    {
        "not_inspected"     => L["TempLoc.Status.NotInspected"],
        "under_inspection"  => L["TempLoc.Status.UnderInspection"],
        "pending_result"    => L["TempLoc.Status.PendingResult"],
        "inspection_exempt" => L["TempLoc.Status.InspectionExempt"],
        "pass"              => L["TempLoc.Status.Pass"],
        "ng"                => L["TempLoc.Status.Ng"],
        _                   => status
    };

    // Màu ô theo trạng thái kiểm của pallet — cùng bảng màu bản đồ Receiving.
    private static string StatusClass(ElevationCellDto? c) => c is { Occupied: true } && !string.IsNullOrEmpty(c.Status)
        ? " st-" + c.Status
        : "";

    // Khung màu ô: ưu tiên Stop (đỏ), rồi refurbish/rework.
    private static string DispCellClass(ElevationCellDto? c)
    {
        if (c is not { Occupied: true }) return "";
        if (c.StopShipment) return " disp-stop";
        return c.Disposition switch { "refurbish" => " disp-refurb", "rework" => " disp-rework", _ => "" };
    }

    // sửa giá lửng trong mặt cắt
    private bool _edit;
    private bool _busy;
    private string? _editMsg;

    protected override void OnParametersSet()
    {
        BuildMap();
        _filter = null; _selLoc = null; _selFl = null; _selLevel = null; _selCode = null; _selQr = null; _selData = null;
    }

    private void BuildMap()
    {
        var cells = Elev?.Cells ?? new List<ElevationCellDto>();
        _cellMap = cells.GroupBy(c => (c.Location, c.Floor))
                        .ToDictionary(g => g.Key, g => g.ToList());
        _totalSlots = cells.Count;
        _occupied = cells.Count(c => c.Occupied);
        _empty = _totalSlots - _occupied;
        _shelf = cells.Count(c => c.SlotKind == "shelf");
    }

    private void ToggleEdit() { if (!CanEdit) return; _edit = !_edit; _editMsg = null; }

    private bool CanEditSel()
        => _edit && _selLoc is not null && _selFl is not null
           && !(At(_selLoc.Value, _selFl.Value)?.Any(x => x.Occupied) ?? false);

    private string CurrentKind()   // "pallet" | "shelf" | "none"
    {
        if (_selLoc is null || _selFl is null) return "none";
        if (!Exists(_selLoc.Value, _selFl.Value)) return "none";
        return IsShelf(_selLoc.Value, _selFl.Value) ? "shelf" : "pallet";
    }

    private async Task SetKind(string kind)
    {
        if (Elev is null || _selLoc is null || _selFl is null) return;
        _busy = true; _editMsg = null; StateHasChanged();
        try
        {
            await Api.SetCellKindAsync(new SetCellKindRequestDto
            {
                RackCode = Elev.RackCode,
                Position = _selLoc.Value,
                Floor = _selFl.Value,
                Kind = kind,
                AreaCode = AreaCode
            });
            Elev = await Api.GetElevationAsync(Elev.RackCode, AreaCode);
            BuildMap();
            _selLevel = null; _selQr = null; _selCode = null;
            _editMsg = L["Storage.MsgUpdated"];
        }
        catch (Exception ex) { _editMsg = ex.Message; }
        finally { _busy = false; StateHasChanged(); }
    }

    private void SetFilter(string? f) => _filter = _filter == f ? null : f;
    private int RowOf(int floor) => (Elev?.MaxFloor ?? floor) - floor + 1;

    // Liệt kê ô theo (vị trí, tầng) — dùng foreach để mỗi @onclick bắt đúng biến (tránh bug closure của for).
    private IEnumerable<(int Loc, int Fl)> GridCells()
    {
        if (Elev is null) yield break;
        for (int fl = Elev.MaxFloor; fl >= 1; fl--)
            for (int loc = 1; loc <= Elev.MaxLocation; loc++)
                yield return (loc, fl);
    }

    private List<ElevationCellDto>? At(int loc, int fl)
        => _cellMap.TryGetValue((loc, fl), out var v) ? v : null;

    private bool Exists(int loc, int fl) => _cellMap.ContainsKey((loc, fl));
    private bool IsShelf(int loc, int fl) { var v = At(loc, fl); return v is { Count: > 0 } && v[0].SlotKind == "shelf"; }
    private ElevationCellDto? Pallet(int loc, int fl) { var v = At(loc, fl); return v is { Count: > 0 } && v[0].SlotKind != "shelf" ? v[0] : null; }
    /// <summary>Pallet trong ô đang chọn. Ô nhiều pallet -> trả cả danh sách; ô cũ chưa có list -> dựng từ trường đơn.</summary>
    private List<ElevationPalletDto> SelectedPallets()
    {
        if (_selData is null || !_selData.Occupied) return new();
        if (_selData.Pallets.Count > 0) return _selData.Pallets;

        return new List<ElevationPalletDto>
        {
            new()
            {
                PalletId = _selData.PalletId,
                Model = _selData.Model,
                BoxCount = _selData.BoxCount,
                ProductionDate = _selData.ProductionDate,
                Disposition = _selData.Disposition,
                StopShipment = _selData.StopShipment
            }
        };
    }

    /// <summary>
    /// Mã ô lấy thẳng từ dữ liệu — mỗi kho có quy ước riêng
    /// (E1-5-1 hay 1.B12A.1.01), không được tự ghép bằng dấu gạch.
    /// </summary>
    private string CellCode(int loc, int fl, string? level = null)
    {
        var c = level is null ? Pallet(loc, fl) : Sub(loc, fl, level);
        if (!string.IsNullOrEmpty(c?.LocatorCode)) return c!.LocatorCode!;

        // Ô chưa tồn tại trong DB: dựng tạm theo quy ước của chính kệ này.
        var rc = Elev?.RackCode ?? "";
        var sep = rc.Contains('.') ? "." : "-";
        return rc + sep + loc + sep + fl + (level is null ? "" : sep + level);
    }

    private ElevationCellDto? Sub(int loc, int fl, string level) => At(loc, fl)?.FirstOrDefault(x => x.Level == level);

    private bool CellMatches(int loc, int fl)
    {
        var v = At(loc, fl);
        if (v is null) return _filter is null;   // ô X chỉ hiện khi không lọc
        return _filter switch
        {
            null => true,
            "empty" => v.Any(x => !x.Occupied),
            "occ" => v.Any(x => x.Occupied),
            "shelf" => v[0].SlotKind == "shelf",
            _ => true
        };
    }

    private bool IsSel(int loc, int fl) => _selLoc == loc && _selFl == fl;
    // Serial theo mã pallet — nạp khi chọn ô, không kèm sẵn trong dữ liệu mặt cắt
    // (một kệ có thể vài nghìn serial).
    private readonly Dictionary<string, List<PalletSerialDto>> _serials = new();
    private string? _serialsBusy;

    private List<PalletSerialDto>? SerialsOf(string? palletCode)
        => string.IsNullOrWhiteSpace(palletCode) ? null
            : _serials.TryGetValue(palletCode, out var v) ? v : null;

    private bool SerialsLoading(string? palletCode) => _serialsBusy == palletCode;

    private void SelectCell(int loc, int fl, string? level = null)
    {
        _selLoc = loc; _selFl = fl; _selLevel = level;
        _selData = level is not null ? Sub(loc, fl, level) : Pallet(loc, fl);
        _selCode = _selData?.LocatorCode;
        _selQr = string.IsNullOrWhiteSpace(_selCode) ? null : Swms.FinishGoods.Web.Shared.App.QrService.GeneratePngDataUri(_selCode);
        _serialsOpen.Clear();   // chọn ô mới thì thu gọn danh sách serial
    }

    /// <summary>Pallet nào đang mở danh sách serial. Chỉ tải khi người dùng bấm mở.</summary>
    private readonly HashSet<string> _serialsOpen = new();

    private bool SerialsExpanded(string? palletCode)
        => !string.IsNullOrWhiteSpace(palletCode) && _serialsOpen.Contains(palletCode!);

    private async Task ToggleSerials(string? palletCode)
    {
        if (string.IsNullOrWhiteSpace(palletCode)) return;

        if (!_serialsOpen.Add(palletCode!)) { _serialsOpen.Remove(palletCode!); return; }
        if (_serials.ContainsKey(palletCode!)) return;   // đã có trong bộ nhớ

        _serialsBusy = palletCode;
        try { _serials[palletCode!] = await Api.GetSerialsAsync(palletCode!); }
        catch { _serials[palletCode!] = new List<PalletSerialDto>(); }
        _serialsBusy = null;
    }

    /// <summary>In tem QR cho MỌI ô của kệ đang mở, theo thứ tự vị trí rồi tầng.</summary>
    private Task PrintRack()
    {
        // Elev là [Parameter] nullable. Chặn sớm giống SetKind() và GridCells().
        if (Elev is null) return Task.CompletedTask;

        var codes = Elev.Cells
            .OrderBy(c => c.Location).ThenBy(c => c.Floor).ThenBy(c => c.Level ?? string.Empty, StringComparer.Ordinal)
            .Select(c => c.LocatorCode)
            .Where(c => !string.IsNullOrWhiteSpace(c))
            .ToList();
        return PrintCodes(codes);
    }

    /// <summary>In tem QR cho riêng ô đang chọn.</summary>
    private Task PrintCell()
    {
        // lấy từ dữ liệu ô đang chọn, phòng khi _selCode chưa kịp cập nhật
        var code = _selData?.LocatorCode ?? _selCode;
        return PrintCodes(string.IsNullOrWhiteSpace(code) ? new List<string>() : new List<string> { code! });
    }

    /// <summary>Dựng tem rồi gọi JS in — dùng chung cho in cả kệ và in 1 ô.</summary>
    private async Task PrintCodes(List<string> codes)
    {
        if (codes.Count == 0)
        {
            await JS.InvokeVoidAsync("console.warn", "[RackElevation] không có mã nào để in");
            return;
        }

        var items = codes.Select(c => new PrintLabel(c, QrOf(c))).ToList();
        try
        {
            await JS.InvokeVoidAsync("storagePrint.labels", items);
        }
        catch (Exception ex)
        {
            await JS.InvokeVoidAsync("console.error", "[RackElevation] in tem lỗi: " + ex.Message);
        }
    }

    /// <summary>1 tem: mã vị trí + ảnh QR dạng data-uri.</summary>
    private sealed record PrintLabel(string code, string qr);

    private static string QrOf(string code)
        => Swms.FinishGoods.Web.Shared.App.QrService.GeneratePngDataUri(code);

    private async Task DownloadQr()
    {
        if (string.IsNullOrEmpty(_selQr)) return;
        try { await JS.InvokeVoidAsync("qrHelper.download", _selQr, $"{_selCode}.png"); }
        catch { /* qrHelper chưa nạp — bỏ qua */ }
    }

    private string SlotClassAt(int loc, int fl)
    {
        var v = At(loc, fl);
        string cls;
        if (v is null) cls = "rk-slot x";
        else if (v[0].SlotKind == "shelf") cls = "rk-slot shelf";
        // Ở Map Designer chỉ quan tâm CẤU TRÚC ô, không tô theo trạng thái hàng.
        else if (CanEdit) cls = "rk-slot empty";
        else cls = "rk-slot " + (v[0].Occupied ? "occ" : "empty") + StatusClass(v[0]) + DispCellClass(v[0]);

        if (loc > 1 && loc % 2 == 1) cls += " kstart";   // cột ngăn khoang (cứ 2 ô 1 cột)
        if (!CellMatches(loc, fl)) cls += " dim";
        if (IsSel(loc, fl)) cls += " sel";
        return cls;
    }

    private string SubClass(int loc, int fl, string level)
    {
        var s = Sub(loc, fl, level);
        var sel = (IsSel(loc, fl) && _selLevel == level) ? " sel" : "";

        // Lọc phải xét TỪNG NGĂN. Trước đây chỉ ô cha mang class dim, mà
        // CellMatches dùng v.Any(...) nên chỉ cần 1 trong 2 ngăn khớp là CẢ ô
        // sáng lên — chọn "Đang dùng" thì ngăn trống bên cạnh cũng sáng theo.
        // Chỉ mờ ngăn khi ô cha đang hiện: cha đã mờ rồi mà mờ tiếp thì hai lớp
        // opacity nhân nhau, nhìn như biến mất.
        var dim = (CellMatches(loc, fl) && !SubMatches(s)) ? " dim" : "";

        if (CanEdit) return "rk-sub empty" + sel + dim;   // designer: chỉ cấu trúc
        return "rk-sub " + (s?.Occupied == true ? "occ" : "empty") + StatusClass(s) + DispCellClass(s) + sel + dim;
    }

    /// <summary>Một ngăn giá lửng có khớp bộ lọc đang chọn không.</summary>
    private bool SubMatches(ElevationCellDto? s) => _filter switch
    {
        null => true,
        "empty" => s?.Occupied != true,
        "occ" => s?.Occupied == true,
        "shelf" => true,   // đang lọc giá lửng thì cả hai ngăn đều là giá lửng
        _ => true,
    };

    // ---- Tooltip -----------------------------------------------------------
    // Dòng đầu là mã ô, các dòng sau là hàng đang nằm trong đó: mỗi pallet một
    // dòng dạng "mã pallet · model (số thùng)". Dùng \n để trình duyệt tự xuống
    // dòng trong tooltip. Chữ lấy từ resx sẵn có, không thêm khoá mới.

    private string TitleAt(int loc, int fl)
    {
        var v = At(loc, fl);
        if (v is null) return $"{CellCode(loc, fl)} · {L["Storage.CellUnusable"]}";

        if (v[0].SlotKind == "shelf")
        {
            var sb = new System.Text.StringBuilder();
            sb.Append(CellCode(loc, fl)).Append(" · ").Append(L["Storage.Shelf"].Value);
            foreach (var lv in new[] { "B", "A" })
            {
                var tag = lv == "B" ? L["Storage.UpperB"].Value : L["Storage.LowerA"].Value;
                sb.Append('\n').Append(tag).Append(" · ").Append(CellBody(Sub(loc, fl, lv)));
            }
            return sb.ToString();
        }

        return $"{CellCode(loc, fl)}\n{CellBody(v[0])}";
    }

    /// <summary>Tooltip riêng cho 1 ngăn giá lửng — thẻ con đè tooltip của ô cha.</summary>
    private string SubTitle(int loc, int fl, string level)
    {
        var tag = level == "B" ? L["Storage.UpperB"].Value : L["Storage.LowerA"].Value;
        return $"{CellCode(loc, fl, level)} · {tag}\n{CellBody(Sub(loc, fl, level))}";
    }

    /// <summary>Phần hàng trong 1 ô: mỗi pallet một dòng. Ô trống thì ghi "Trống".</summary>
    private string CellBody(ElevationCellDto? c)
    {
        if (c is null || !c.Occupied) return L["Storage.Empty"].Value;

        // Ô nhiều pallet -> đi theo danh sách; ô cũ chưa có list -> dựng từ
        // trường đơn, đúng cách SelectedPallets() đang làm cho panel chi tiết.
        var lines = c.Pallets.Count > 0
            ? c.Pallets.Select(p => OneLine(p.PalletId, p.Model, p.BoxCount))
            : new[] { OneLine(c.PalletId, c.Model, c.BoxCount) };

        var text = string.Join("\n", lines.Where(x => x.Length > 0));
        return text.Length > 0 ? text : L["Storage.NoPallet"].Value;

        static string OneLine(string? palletId, string? model, int? qty)
        {
            var s = (palletId ?? "").Trim();
            var m = (model ?? "").Trim();
            if (m.Length > 0) s += (s.Length > 0 ? " · " : "") + m;
            if (qty is > 0) s += $" ({qty})";
            return s;
        }
    }
}
