namespace Swms.FinishGoods.API.Features.Stocktake.Api;

public record CountSummaryResponse(
    long Id, string DocNo, string? CountType, DateTime CountDate, string DocStatus,
    string? SourceRef, string? Description,
    int TotalLines, int CountedLines, int DiscrepancyLines, DateTime CreatedAt,
    int RequiredLines, int CountedRequiredLines)
{
    public static CountSummaryResponse From(CountSummary c) => new(
        c.Id, c.DocNo, c.CountType, c.CountDate, c.DocStatus, c.SourceRef, c.Description,
        c.TotalLines, c.CountedLines, c.DiscrepancyLines, c.CreatedAt,
        c.RequiredLines, c.CountedRequiredLines);
}

public record CountLineResponse(
    long Id, int LineNo, int ProductId, string? ProductName, long LocatorId, string LocatorCode,
    long? LotId, string? PalletId, string? Model, int QtySystem, int? QtyCount,
    bool IsAdjusted, string? Note,
    int? BoxCountSystem, int? BoxCountCounted, int? StandardPacking,
    int WalkSeq, string? AreaCode, string? AreaName,
    bool IsFound, string? SystemLocatorCode, bool IsRequired)
{
    public static CountLineResponse From(CountLine l) => new(
        l.Id, l.LineNo, l.ProductId, l.ProductName, l.LocatorId, l.LocatorCode, l.LotId,
        l.PalletId, l.Model, l.QtySystem, l.QtyCount, l.IsAdjusted, l.Note,
        l.BoxCountSystem, l.BoxCountCounted, l.StandardPacking,
        l.WalkSeq, l.AreaCode, l.AreaName,
        l.IsFound, l.SystemLocatorCode, l.IsRequired);
}

public record CountDetailResponse(CountSummaryResponse Header, IReadOnlyList<CountLineResponse> Lines);

/// <summary>
/// Tạo phiếu: countType = 'morning' | 'monthly' (shipment làm sau khi có allocation).
/// areaCodes: chỉ dùng cho 'monthly' — chọn 1 hay nhiều bản đồ lưu kho;
/// rỗng hoặc chọn hết = mọi bản đồ lưu kho.
/// </summary>
public record CreateCountRequest(string CountType, string? Description, List<string>? AreaCodes = null);

/// <summary>Nhập/sửa số đếm cho 1 dòng.</summary>
/// <summary>Ghi chú của 1 dòng kiểm kê (lý do lệch).</summary>
public record SetNoteRequest(string? Note);

/// <summary>
/// Ghi số đếm 1 dòng. BoxCountCounted = số box người kiểm đếm được;
/// null khi họ nhập thẳng số lượng (model chưa khai quy cách, hoặc thực tế
/// lệch quy cách).
/// </summary>
public record SetCountRequest(int QtyCount, string? Note, int? BoxCountCounted = null);

/// <summary>Xem trước phạm vi phiếu sắp tạo (không ghi DB).</summary>
public record CountPreviewResponse(string CountType, int LocatorCount, int LineCount);

/// <summary>Ghi pallet phát sinh: quét mã pallet tại một ô trong phiếu.</summary>
public record AddFoundRequest(long LocatorId, string PalletId);

public record AddFoundResponse(long LineId, bool Created);
