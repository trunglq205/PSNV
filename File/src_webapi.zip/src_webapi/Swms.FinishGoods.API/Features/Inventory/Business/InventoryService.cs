using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Inventory.Api;
using Swms.FinishGoods.API.Features.Inventory.Business.Entities;
using Swms.FinishGoods.API.Features.Inventory.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.Inventory.Business
{
    public class InventoryService : IInventoryService
    {
        private readonly IInventoryRepository _repo;
        private readonly ICurrentUser _currentUser;
        private readonly IStringLocalizer<SharedResource> _localizer;
        private readonly ILogger<InventoryService> _logger;

        public InventoryService(
            IInventoryRepository repo,
            ICurrentUser currentUser,
            IStringLocalizer<SharedResource> localizer,
            ILogger<InventoryService> logger)
        {
            _repo = repo;
            _currentUser = currentUser;
            _localizer = localizer;
            _logger = logger;
        }

        // ── Read ──────────────────────────────────────────────────────
        public async Task<PagedResult<InventoryItemResponse>> GetPagedAsync(InventoryQuery query)
        {
            Normalize(query);
            var paged = await _repo.GetPagedAsync(query, ToOrderBy(query.Sort));
            return new PagedResult<InventoryItemResponse>(
                paged.Items.Select(InventoryItemResponse.From).ToList(),
                paged.TotalCount, paged.Page, paged.Size);
        }

        public async Task<IReadOnlyList<InventoryAreaStatResponse>> GetAreaStatsAsync(InventoryQuery query)
        {
            Normalize(query);
            var stats = (await _repo.GetAreaStatsAsync(query)).ToDictionary(s => s.AreaKey);

            // Luôn trả đủ 5 khu (khu không có hàng = 0) để client khỏi tự điền.
            return InventoryArea.All
                .Select(k => stats.TryGetValue(k, out var s) ? s : new InventoryAreaStat { AreaKey = k })
                .Select(InventoryAreaStatResponse.From)
                .ToList();
        }

        public async Task<IReadOnlyList<InventoryAgingBucketResponse>> GetAgingAsync(InventoryQuery query)
        {
            Normalize(query);
            return (await _repo.GetAgingAsync(query)).Select(InventoryAgingBucketResponse.From).ToList();
        }

        // ── Helpers ───────────────────────────────────────────────────
        private void Normalize(InventoryQuery q)
        {
            if (q.Page < 1) q.Page = 1;
            if (q.Size < 1 || q.Size > 9999) q.Size = 20;

            q.LotNo = Trim(q.LotNo);
            q.Model = Trim(q.Model);
            q.LotType = NormalizeLotType(q.LotType);
            q.BoxOrSerial = Trim(q.BoxOrSerial);
            q.Area = Trim(q.Area)?.ToLowerInvariant();
            q.Sort = Trim(q.Sort)?.ToLowerInvariant();

            // Chọn nhiều: list + giá trị đơn cũ gộp lại, rồi bỏ giá trị đơn để SQL chỉ đọc list.
            q.CategoryList = Merge(SplitInts(q.Categories), q.CategoryCode);
            q.InspectionList = SplitText(q.Inspections)
                .Concat(Trim(q.InspectionStatus) is { } ins ? new[] { ins.ToLowerInvariant() } : Array.Empty<string>())
                .Distinct()
                .ToList();
            q.SapStatusList = Merge(SplitInts(q.SapStatuses), q.SapStatus);
            q.CategoryCode = null;
            q.InspectionStatus = null;
            q.SapStatus = null;

            if (q.Area is not null && !InventoryArea.IsValid(q.Area))
                throw new BusinessRuleException(_localizer[InventoryErrors.AreaInvalid, q.Area]);
            if (q.Sort is not null && !InventorySort.All.Contains(q.Sort))
                throw new BusinessRuleException(_localizer[InventoryErrors.SortInvalid, q.Sort]);
            if (q.QtyMin is < 0 || q.QtyMax is < 0 || (q.QtyMin is { } a && q.QtyMax is { } b && a > b))
                throw new BusinessRuleException(_localizer[InventoryErrors.QtyRangeInvalid]);
        }

        private static string? Trim(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

        /// <summary>"a, b,,c" -> [a, b, c] (chữ thường). Rỗng -> [].</summary>
        private static IEnumerable<string> SplitText(string? raw)
            => (raw ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                          .Select(x => x.ToLowerInvariant());

        /// <summary>Giá trị không phải số bị bỏ qua — tham số URL sai không làm vỡ màn hình.</summary>
        private static IEnumerable<int> SplitInts(string? raw)
            => SplitText(raw).Select(x => int.TryParse(x, out var v) ? (int?)v : null)
                             .Where(v => v is not null)
                             .Select(v => v!.Value);

        private static List<int> Merge(IEnumerable<int> list, int? single)
            => (single is { } v ? list.Append(v) : list).Distinct().ToList();

        /// <summary>
        /// Chuẩn hoá lot_type về ĐÚNG giá trị trong DB.
        ///
        /// Giá trị DB là <c>pallet</c> | <c>stocky</c> (xem
        /// <c>PalletType.ToDbValue()</c>), nhưng bên Web lại gửi
        /// <c>stocky_cart</c>. Cột này được so bằng dấu = trong câu SQL
        /// (<c>l.lot_type = @LotType</c>) và <c>LotType</c> chỉ là string
        /// thuần — KHÔNG đi qua converter của PalletType — nên bộ lọc
        /// "Xe stocky" trên màn Tồn kho luôn trả 0 dòng.
        ///
        /// Dùng đúng cách nhận diện của <c>PalletType.Parse</c>: bỏ _ và -
        /// rồi so không phân biệt hoa thường. Nhờ vậy stocky_cart, StockyCart,
        /// stocky-cart đều về được 'stocky'.
        /// </summary>
        private static string? NormalizeLotType(string? raw)
        {
            var s = Trim(raw);
            if (s is null) return null;

            var key = s.Replace("_", "").Replace("-", "").ToLowerInvariant();
            return key switch
            {
                "pallet" => "pallet",
                "stocky" or "stockycart" => "stocky",
                // Giá trị lạ thì giữ nguyên: câu SQL sẽ không khớp dòng nào,
                // đúng ý "lọc theo thứ không tồn tại", chứ không ném lỗi 400
                // làm vỡ màn hình chỉ vì một tham số URL sai.
                _ => s,
            };
        }

        // Whitelist → không bao giờ nối chuỗi user input vào ORDER BY.
        private static string ToOrderBy(string? sort) => sort switch
        {
            InventorySort.PdAsc   => "x.ProductionDate ASC, x.CreatedAt ASC, x.Id ASC",
            InventorySort.PdDesc  => "x.ProductionDate DESC, x.CreatedAt DESC, x.Id DESC",
            InventorySort.QtyDesc => "x.TotalQtySql DESC, x.CreatedAt DESC, x.Id DESC",
            _                     => "x.CreatedAt DESC, x.Id DESC",
        };
    }
}
