using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business;
using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business.Models;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.App.Toast;

namespace Swms.FinishGoods.Web.Features.HdSoft.SiCompare.App;

public partial class SiHdSoftCompareView
{
    /// <summary>Có gán: bấm 1 SI chỉ báo ra ngoài (dialog chứa view tự mở SiCompareDialog
    /// bên ngoài khung modal). Không gán: view tự mở SiCompareDialog.</summary>
    [Parameter] public EventCallback<string> OnOpenDetail { get; set; }

    [Inject] private ISiHdSoftCompareBusiness Business { get; set; } = default!;
    [Inject] private ToastService Toast { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;

    private const int MaxRangeDays = 62;     // khớp giới hạn của API
    private const int PageChunk = 200;       // số dòng vẽ mỗi lần — API trả tối đa 2000 SI

    private const int DefaultDays = 14;      // mặc định: ETD từ hôm nay tới 14 ngày tới

    // "issues" = mọi SI chưa khớp — tab mặc định: thứ người xem cần thấy đầu tiên
    private static readonly (string Key, string LabelKey)[] Tabs =
    {
        ("issues", "SiCmp.Tab.Issues"),
        (SiCompareDisplay.Mismatch, "SiCmp.Result.mismatch"),
        (SiCompareDisplay.OnlyHdSoft, "SiCmp.Result.only_hdsoft"),
        (SiCompareDisplay.OnlySwms, "SiCmp.Result.only_swms"),
        (SiCompareDisplay.Match, "SiCmp.Result.match"),
        ("all", "Si.F.All"),
    };

    private DateTime _from = DateTime.Today;
    private DateTime _to = DateTime.Today.AddDays(DefaultDays - 1);

    /// <summary>min cho ô ngày — không chọn ngày đã qua.</summary>
    private const string Warehouse = "PSNV"; // kho phía HD soft — cố định, không cho chọn

    private string _tab = "issues";
    private string _q = "";
    private int _limit = PageChunk;

    private bool _loading;
    private AppSiCompareList? _data;
    private string? _openSiNo;

    // Nạp sau lần vẽ đầu (không chạy ở prerender) — truy vấn HD soft có thể mất vài giây.
    // Mặc định: SI có ETD từ hôm nay tới 14 ngày tới.
    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (firstRender) await RunAsync();
    }

    private async Task RunAsync()
    {
        // Không xem lại quá khứ: ngày đã qua kéo về hôm nay (trang để mở qua đêm, gõ tay…)
        if (_from < DateTime.Today) _from = DateTime.Today;
        if (_to < DateTime.Today) _to = DateTime.Today;
        if (_to < _from)
        {
            Toast.Error(L["SiCmp.Err.Range"]);
            return;
        }
        if ((_to - _from).TotalDays + 1 > MaxRangeDays)
        {
            Toast.Error(L["SiCmp.Err.TooWide", MaxRangeDays]);
            return;
        }

        _loading = true;
        StateHasChanged();

        var r = await Business.GetListAsync(_from, _to, Warehouse);
        _loading = false;
        if (r.IsSuccess && r.Value is not null)
        {
            _data = r.Value;
            _limit = PageChunk;
            // Khớp hết thì tab "có vấn đề" trống trơn -> chuyển sang tất cả cho đỡ hụt hẫng
            if (_tab == "issues" && _data.IssueCount == 0 && _data.Total > 0) _tab = "all";
        }
        else
        {
            Toast.Error(r.ErrorMessage ?? L["SiCmp.Err.Load"]);
        }
        StateHasChanged();
    }

    /// <summary>So lại riêng 1 SI rồi thay dòng + chỉnh số đếm. Public: dialog chi tiết gọi sau khi tạo / hoàn thành SI.</summary>
    public async Task RefreshRowAsync(string siNo)
    {
        if (_data is null) return;
        var r = await Business.GetDetailAsync(siNo);
        if (!r.IsSuccess || r.Value is null) return;          // giữ dòng cũ; lần so sau sẽ đúng

        var i = _data.Items.FindIndex(x => string.Equals(x.SiNo, siNo, StringComparison.OrdinalIgnoreCase));
        if (i < 0) return;

        var old = _data.Items[i];
        var now = r.Value.Summary;
        _data.Items[i] = now;
        AddCount(old.Result, -1);
        AddCount(now.Result, +1);
        await InvokeAsync(StateHasChanged);
    }

    private void AddCount(string result, int d)
    {
        if (_data is null) return;
        switch (result)
        {
            case SiCompareDisplay.Match: _data.Matched += d; break;
            case SiCompareDisplay.Mismatch: _data.Mismatched += d; break;
            case SiCompareDisplay.OnlySwms: _data.OnlySwms += d; break;
            case SiCompareDisplay.OnlyHdSoft: _data.OnlyHdSoft += d; break;
        }
    }

    private async Task SetTodayAsync()
    {
        _from = _to = DateTime.Today;
        await RunAsync();
    }

    private bool IsToday => _from == DateTime.Today && _to == DateTime.Today;

    // ── Lọc trên client ─────────────────────────────────────
    private void SetTab(string key)
    {
        _tab = key;
        _limit = PageChunk;
    }

    private void OnSearch(ChangeEventArgs e)
    {
        _q = e.Value?.ToString() ?? "";
        _limit = PageChunk;
    }

    private void ShowMore() => _limit += PageChunk;

    private int TabCount(string key) => _data is null ? 0 : key switch
    {
        "issues" => _data.IssueCount,
        "all" => _data.Total,
        SiCompareDisplay.Match => _data.Matched,
        SiCompareDisplay.Mismatch => _data.Mismatched,
        SiCompareDisplay.OnlySwms => _data.OnlySwms,
        SiCompareDisplay.OnlyHdSoft => _data.OnlyHdSoft,
        _ => 0,
    };

    private IEnumerable<AppSiCompareSummary> Filtered()
    {
        if (_data is null) return Enumerable.Empty<AppSiCompareSummary>();
        var q = _data.Items.AsEnumerable();

        q = _tab switch
        {
            "all" => q,
            "issues" => q.Where(x => !x.IsMatch),
            _ => q.Where(x => x.Result == _tab),
        };

        if (!string.IsNullOrWhiteSpace(_q))
        {
            var k = _q.Trim();
            q = q.Where(x => x.SiNo.Contains(k, StringComparison.OrdinalIgnoreCase)
                          || (x.SwmsDocNo?.Contains(k, StringComparison.OrdinalIgnoreCase) ?? false)
                          || (x.HdSoftDocNo?.Contains(k, StringComparison.OrdinalIgnoreCase) ?? false));
        }
        return q;
    }

    private int FilteredCount => Filtered().Count();

    private IEnumerable<AppSiCompareSummary> Shown => Filtered().Take(_limit);

    private string EmptyText()
    {
        if (!string.IsNullOrWhiteSpace(_q)) return L["SiCmp.EmptySearch", _q.Trim()];
        if (_data is { Total: 0 }) return L["SiCmp.EmptyRange"];
        if (_tab == "issues") return L["SiCmp.AllMatch", _data?.Total ?? 0];
        return L["SiCmp.EmptyTab"];
    }

    // ── Thanh phân bố kết quả ───────────────────────────────
    private static IEnumerable<(string Key, int Count)> Dist(AppSiCompareList d)
    {
        if (d.Matched > 0) yield return (SiCompareDisplay.Match, d.Matched);
        if (d.Mismatched > 0) yield return (SiCompareDisplay.Mismatch, d.Mismatched);
        if (d.OnlyHdSoft > 0) yield return (SiCompareDisplay.OnlyHdSoft, d.OnlyHdSoft);
        if (d.OnlySwms > 0) yield return (SiCompareDisplay.OnlySwms, d.OnlySwms);
    }

    private string DistTooltip(AppSiCompareList d)
        => string.Join(" · ", Dist(d).Select(x => $"{SiCompareDisplay.ResultLabel(x.Key, L)} {x.Count:N0}"));

    // ── Chi tiết ────────────────────────────────────────────
    private async Task OpenDetail(string siNo)
    {
        if (OnOpenDetail.HasDelegate) await OnOpenDetail.InvokeAsync(siNo);
        else _openSiNo = siNo;
    }
}