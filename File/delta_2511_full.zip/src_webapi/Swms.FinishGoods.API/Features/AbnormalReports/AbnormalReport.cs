﻿namespace Swms.FinishGoods.API.Features.AbnormalReports;

/// <summary>
/// Phiếu hàng bất thường (ngoại quan). Luồng 5 bước TUẦN TỰ:
///   1. SCS tạo phiếu
///   2. Leader SCS duyệt  -> gửi mail cho OQC và FA cùng lúc
///   3. OQC kết luận      -> bắt buộc trước FA
///   4. FA chọn hướng xử lý
///   5. SCS Supervisor chốt
/// Mỗi bước một quyền riêng, xem Perms.Receiving.AbnormalReport.
/// </summary>
public class NgReport
{
    public long Id { get; set; }
    public string DocNo { get; set; } = string.Empty;

    public long? LotId { get; set; }
    public string? PalletCode { get; set; }     // wms.pallets.pallet_id
    public string? Model { get; set; }
    /// <summary>
    /// Mã cate của pallet (master.categories.code). Là CHUỖI chứ không phải số:
    /// mọi feature khác đều join master.categories.code = p.category_id. Trước
    /// đây NG đọc cột này vào int? — chưa lỗi vì mã cate đang toàn số, nhưng
    /// thêm một mã kiểu 'BD01' là màn chi tiết ném lỗi ngay.
    /// Dùng để tra người nhận mail theo cate và tra quy tắc bỏ OQC.
    /// </summary>
    public string? CategoryCode { get; set; }

    /// <summary>
    /// Tên cate (master.categories.name) — để HIỆN ra màn hình. Null khi mã
    /// cate của pallet chưa khai trong master.categories; nơi hiển thị tự quay
    /// về dùng <see cref="CategoryCode"/>. Việc tra người nhận mail và tra quy
    /// tắc bỏ OQC vẫn đi bằng mã, không bao giờ bằng tên.
    /// </summary>
    public string? CategoryName { get; set; }

    public string NgType { get; set; } = string.Empty;
    public string? Description { get; set; }
    public DateTime DiscoveredAt { get; set; }

    public string DocStatus { get; set; } = "draft";
    public string CurrentStep { get; set; } = "created";

    public string LeaderStatus { get; set; } = "pending";

    /// <summary>Tên hiển thị của người duyệt bước 2 — chỉ để hiện ra, đừng đem so sánh.</summary>
    public string? LeaderBy { get; set; }

    /// <summary>
    /// Mã nhân viên của người duyệt bước 2. Dùng để so xem người đang chốt
    /// bước 5 có phải chính người đã duyệt bước 2 — mã nhân viên là duy nhất
    /// và cũng là tên đăng nhập, nên so bằng cột này mới chính xác. So bằng
    /// LeaderBy (họ tên) sẽ báo nhầm khi hai người trùng tên.
    /// </summary>
    public string? LeaderByCode { get; set; }

    public DateTime? LeaderAt { get; set; }
    public string? LeaderComment { get; set; }

    public string FaStatus { get; set; } = "pending";

    /// <summary>
    /// Kết luận OK/NG của FA — <c>ok</c> | <c>ng</c> | null (chưa đánh giá).
    ///
    /// TÁCH khỏi <see cref="FaResolution"/> vì hai thứ trả lời hai câu khác
    /// nhau. Trước đây FA chỉ chọn hướng xử lý, nên không có gì để so với kết
    /// luận của OQC; suy "chấp nhận = OK" là sai, vì trả lại hàng cũng có thể
    /// là hàng OK mà khách không lấy nữa.
    /// </summary>
    public string? FaResult { get; set; }

    /// <summary>Hướng xử lý khi FA kết luận NG — replace | accept | return | scrap.</summary>
    public string? FaResolution { get; set; }
    public string? FaBy { get; set; }
    public DateTime? FaAt { get; set; }
    public string? FaComment { get; set; }

    public string OqcStatus { get; set; } = "pending";
    public string? OqcBy { get; set; }
    public DateTime? OqcAt { get; set; }
    public string? OqcComment { get; set; }

    public string Resolution { get; set; } = "pending";
    public string? FinalizedBy { get; set; }
    public DateTime? FinalizedAt { get; set; }
    public string? FinalComment { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }

    /// <summary>
    /// Vòng đánh giá thứ mấy. OQC và FA đẩy qua đẩy lại được nhiều vòng; ba
    /// cột *_by/*_at chỉ giữ được LẦN CUỐI của mỗi bên, nên không có số vòng
    /// thì nhìn phiếu không biết nó đã quay mấy lượt. Nhật ký từng lượt vẫn
    /// đủ ở wms.ng_inspection_approvals.
    /// </summary>
    public int ReviewRound { get; set; } = 1;

    /// <summary>
    /// inspection_status của pallet TRƯỚC khi phiếu đóng dấu 'ng'. Giữ để
    /// hoàn nguyên: đặt bừa 'pass' sẽ âm thầm đổi nghĩa một pallet vốn mang
    /// 'inspection_exempt' (miễn kiểm) hay 'not_inspected'.
    /// </summary>
    public string? PalletStatusBefore { get; set; }

    public int ItemCount { get; set; }
    public int QtyAffected { get; set; }
    public int PhotoCount { get; set; }

    /// <summary>
    /// Mọi mục phạm vi của phiếu đều là scope='pallet' ⟹ lỗi cả pallet.
    /// Khi đó qty_affected (=1 mỗi mục) vô nghĩa, giao diện hiện "cả pallet"
    /// thay vì "1 cái" — vì "1 cái" làm người đọc tưởng chỉ 1 sản phẩm bị lỗi.
    /// </summary>
    public bool IsWholePallet { get; set; }
}

/// <summary>Phạm vi ảnh hưởng: cả pallet, cả thùng, hoặc 1 dòng serial.</summary>
public class NgItem
{
    public long Id { get; set; }
    public long NgId { get; set; }
    public string Scope { get; set; } = "serial";   // pallet | box | serial
    public long? PalletId { get; set; }
    public long? BoxId { get; set; }
    public long? BoxLineId { get; set; }
    public string? Code { get; set; }
    public int QtyAffected { get; set; }
    public string? Note { get; set; }
}

/// <summary>Ảnh lỗi. File gốc nằm trên đĩa; DB giữ đường dẫn tương đối.</summary>
public class NgPhoto
{
    public long Id { get; set; }
    public long NgId { get; set; }
    public long? ItemId { get; set; }
    public string FilePath { get; set; } = string.Empty;
    public string FileName { get; set; } = string.Empty;
    public string? ContentType { get; set; }
    public long? SizeBytes { get; set; }
    public string? Caption { get; set; }
    public int SortOrder { get; set; }
}

/// <summary>Nhật ký thao tác từng bước — không ghi đè.</summary>
public class NgApproval
{
    public long Id { get; set; }
    public long NgId { get; set; }
    public string Step { get; set; } = string.Empty;    // leader | fa | oqc | finalize
    public string Action { get; set; } = string.Empty;  // submit | cancel | approve | ok | ng | finalize
    public string? Resolution { get; set; }
    public string? Comment { get; set; }
    public string? ActedBy { get; set; }
    public DateTime ActedAt { get; set; }
}

/// <summary>Phiếu + các phần phụ, dùng cho màn chi tiết.</summary>
public class NgReportDetail
{
    public NgReport Header { get; set; } = new();
    public IReadOnlyList<NgItem> Items { get; set; } = Array.Empty<NgItem>();
    public IReadOnlyList<NgPhoto> Photos { get; set; } = Array.Empty<NgPhoto>();
    public IReadOnlyList<NgApproval> Approvals { get; set; } = Array.Empty<NgApproval>();
}

/// <summary>
/// Thông tin tóm tắt của pallet, trả về khi PDA quét mã ở màn tạo phiếu.
/// Đủ để công nhân nhận ra mình quét đúng pallet trước khi điền tiếp.
/// </summary>
public class NgPalletBrief
{
    public long Id { get; set; }
    public string Code { get; set; } = "";
    public string? Model { get; set; }
    public int? BoxCount { get; set; }
    public string? InspectionStatus { get; set; }
    public bool IsUrgent { get; set; }
    public DateTime? ProductionDate { get; set; }
    public string? LocatorCode { get; set; }
    public string? AreaName { get; set; }
}

/// <summary>
/// Một loại lỗi trong master.ng_types. Tên và mô tả lưu sẵn 4 ngôn ngữ ngay
/// trong bảng, nên thêm một loại lỗi chỉ là một dòng INSERT — không phải sửa
/// resx của Web, JSON của PDA rồi build lại cả ba.
///
/// requires_oqc nằm luôn ở đây: "có cần OQC kết luận không" là thuộc tính của
/// loại lỗi, để ở bảng riêng thì sớm muộn hai nơi nói hai kiểu.
/// </summary>
public class NgTypeRow
{
    public string Code { get; set; } = "";

    public string NameVi { get; set; } = "";
    public string? NameEn { get; set; }
    public string? NameJa { get; set; }
    public string? NameZh { get; set; }

    public string? NoteVi { get; set; }
    public string? NoteEn { get; set; }
    public string? NoteJa { get; set; }
    public string? NoteZh { get; set; }

    public bool RequiresOqc { get; set; }
    public int SortOrder { get; set; }

    /// <summary>
    /// Chỉ màn quản trị đọc tới. Truy vấn danh mục cho người lập phiếu đã lọc
    /// is_active = 1 nên không select cột này — Dapper để nguyên giá trị mặc định.
    /// </summary>
    public bool IsActive { get; set; } = true;

    /// <summary>
    /// Số phiếu đang mang mã này. Dùng để chặn xoá: xoá một loại lỗi còn phiếu
    /// tham chiếu thì tên loại biến mất khỏi những phiếu cũ.
    /// </summary>
    public int UsedByReports { get; set; }

    /// <summary>
    /// Nhãn theo mã ngôn ngữ 2 ký tự. Thiếu bản dịch thì lùi về tiếng Việt chứ
    /// KHÔNG hiện mã thô: người dùng đọc "Bao bì" vẫn hơn đọc "packaging".
    /// </summary>
    public string NameFor(string lang) => (lang switch
    {
        "en" => NameEn,
        "ja" => NameJa,
        "zh" => NameZh,
        _    => NameVi,
    }) ?? NameVi;

    /// <summary>Mô tả ngắn, cùng quy tắc lùi về tiếng Việt. Có thể rỗng.</summary>
    public string? NoteFor(string lang) => (lang switch
    {
        "en" => NoteEn,
        "ja" => NoteJa,
        "zh" => NoteZh,
        _    => NoteVi,
    }) ?? NoteVi;
}
