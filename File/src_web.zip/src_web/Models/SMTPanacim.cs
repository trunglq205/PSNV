﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace SWMS_WebTool.Models
{
    public enum SMTPanacimStatus
    {
        [EnumMember(Value = "0")]
        [Description("Status_NotYetPrint")]
        NotYetPrint,
        [EnumMember(Value = "1")]
        [Description("Status_NotPrintPanacim")]
        NotPrintPanacim,
        [EnumMember(Value = "2")]
        [Description("Status_Printed")]
        Printed,
        [EnumMember(Value = "3")]
        [Description("Status_Checked")]
        Checked,
        [EnumMember(Value = "4")]
        [Description("Status_Checking")]
        Checking,
    }

    public class SMTPanacim
    {
        public string sReelID { get; set; }
        public string sPartNoID { get; set; }
        public int? iQuantity { get; set; }
        public string? sBarcode { get; set; }
        public string? sPlant { get; set; }
        public string? sCategory { get; set; }
        public string? sLocation { get; set; }
        public string? KI_PL { get; set; }
        public string? sVenderCode { get; set; }
        public string? sRemark { get; set; }
        public int? iStatus { get; set; }
        public DateTime? dCreated { get; set; }
        public DateTime? dModified { get; set; }
        public string? sUserCreated { get; set; }
        public bool? bDeleted { get; set; }
        public string? sBarcodeID { get; set; }
        public DateTime? PstgDate { get; set; }
        public byte? iStatusPrint { get; set; }
        public byte? mayin { get; set; }
        public bool? CheckPanacim { get; set; }
        public string UserChecked { get; set; }
    }
}
