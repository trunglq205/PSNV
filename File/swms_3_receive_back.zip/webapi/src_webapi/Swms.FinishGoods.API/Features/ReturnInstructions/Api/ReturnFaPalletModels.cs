using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// Một thùng FA đóng: mã thùng + serial đã quét.
///
/// KHÔNG có trường model — khác mục 2a. Sổ serial đã biết mỗi con thuộc model
/// nào, nên FA không phải chọn model: quét mã thùng rồi quét serial là xong.
/// </summary>
public record FaPalletBoxRequest(
    [StringLength(50)] string? BoxNo,
    [Required, MinLength(1)] List<string> Serials);

/// <summary>
/// Mục 2d — FA đóng pallet mới sau rework, quét vào một phiếu đã chọn trước.
/// </summary>
public record CreateFaPalletRequest(
    [Required, MinLength(1)] List<FaPalletBoxRequest> Boxes);

public record ReturnSerialIndexResponse(string Serial, string Model, string Status)
{
    public static ReturnSerialIndexResponse From(ReturnSerialIndexRow r)
        => new(r.SerialNo, r.Model, r.Status);
}

public record ReturnMismatchResponse(
    long Id,
    long DocId,
    long? PalletId,
    string? LotNo,
    string Serial,
    string? Model,
    string Reason,
    string? FoundStatus,
    string? OtherDocNo,
    DateTime ScannedAt,
    string? ScannedBy,
    DateTime? ResolvedAt,
    string? ResolvedBy,
    string? ResolveNote,
    bool IsResolved)
{
    public static ReturnMismatchResponse From(ReturnSerialMismatch m) => new(
        m.Id, m.DocId, m.PalletId, m.LotNo, m.SerialNo, m.Model, m.Reason,
        m.FoundStatus, m.OtherDocNo, m.ScannedAt, m.ScannedBy,
        m.ResolvedAt, m.ResolvedBy, m.ResolveNote, m.IsResolved);
}

/// <summary>SCS đánh dấu đã đặt riêng / đã trả về đúng phiếu.</summary>
public record ResolveMismatchRequest([StringLength(500)] string? Note);

/// <summary>
/// Kết quả FA đóng pallet. Trả cả danh sách bị loại để PDA hiện ngay — người
/// quét là FA, nên họ phải thấy con nào không vào pallet TRƯỚC khi rời bàn.
/// </summary>
public record CreateFaPalletResponse(
    long PalletId,
    string LotNo,
    int CategoryCode,
    int BoxCount,
    int SerialCount,
    int MismatchCount,
    List<ReturnMismatchResponse> Mismatches,
    ReturnInstructionResponse Doc);

/// <summary>
/// Mục 3 — SCS nhận lại một pallet FA đã giao.
///
/// Chỉ cần MÃ PALLET: FA đã quét serial khi đóng pallet (mục 2d), nên ở đây
/// quét lại 400 con là làm hai lần một việc. Một lần quét mã pallet là xong.
/// </summary>
public record ReceiveBackRequest(
    [Required, StringLength(30)] string LotNo);

/// <summary>
/// Kết quả nhận lại. <paramref name="Received"/> là số con thực sự chuyển
/// <c>returned</c>; <paramref name="Skipped"/> là số con trên pallet KHÔNG
/// chuyển được (đã về trước đó, hoặc không thuộc phiếu này).
/// </summary>
public record ReceiveBackResponse(
    string LotNo,
    int Received,
    int Skipped,
    ReturnInstructionResponse Doc);

/// <summary>Khoá resource cho thông báo lỗi của mục 3.</summary>
public static class BackReceiveMsg
{
    public const string PalletNotFound = "Return.Recv.Err.PalletNotFound";
    public const string PalletNotOfDoc = "Return.Recv.Err.PalletNotOfDoc";
    public const string NothingToReceive = "Return.Recv.Err.NothingToReceive";
}

/// <summary>Khoá resource cho thông báo lỗi của mục 2d.</summary>
public static class FaMsg
{
    public const string BoxesRequired = "Return.Fa.Err.BoxesRequired";
    public const string SerialRequired = "Return.Fa.Err.SerialRequired";
    public const string TooManySerials = "Return.Fa.Err.TooManySerials";
    public const string TooManyBoxes = "Return.Fa.Err.TooManyBoxes";
    public const string SerialDuplicatedInRequest = "Return.Fa.Err.SerialDuplicatedInRequest";
    public const string BoxNoDuplicated = "Return.Fa.Err.BoxNoDuplicated";
    public const string ValueTooLong = "Return.Fa.Err.ValueTooLong";
    public const string NothingMatched = "Return.Fa.Err.NothingMatched";
    public const string CategoryUnknown = "Return.Fa.Err.CategoryUnknown";
    public const string CategoryMixed = "Return.Fa.Err.CategoryMixed";
    public const string MismatchNotFound = "Return.Fa.Err.MismatchNotFound";
    public const string AlreadyResolved = "Return.Fa.Err.AlreadyResolved";
}
