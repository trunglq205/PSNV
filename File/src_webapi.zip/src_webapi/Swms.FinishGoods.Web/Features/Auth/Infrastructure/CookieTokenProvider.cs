using Microsoft.AspNetCore.Http;
using Swms.FinishGoods.Web.Shared.Application.Interfaces;
using Swms.FinishGoods.Web.Shared.Infrastructure.Auth;

namespace Swms.FinishGoods.Web.Shared.Infrastructure.Http;

// Đọc token từ cookie qua HttpContext. Khác TokenProvider cũ (localStorage + JS):
// cookie ĐỌC ĐƯỢC ngay lúc prerender vì nó nằm trong request -> không cần JS interop,
// không còn lỗi "JavaScript interop calls cannot be issued".
//
// LƯU Ý: chỉ GHI cookie qua endpoint /auth/set-cookie (xem AuthCookieEndpoints).
// Provider này chỉ ĐỌC; Set/Clear gọi endpoint qua HttpClient ở tầng Business.
public class CookieTokenProvider : ITokenProvider
{
    private readonly IHttpContextAccessor _http;

    public CookieTokenProvider(IHttpContextAccessor http) => _http = http;

    public Task<string?> GetTokenAsync(CancellationToken ct = default)
    {
        var ctx = _http.HttpContext;
        var token = ctx?.Request.Cookies[AuthCookieEndpoints.CookieName];
        return Task.FromResult(string.IsNullOrEmpty(token) ? null : token);
    }
}
