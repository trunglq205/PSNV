﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.ImportModel
{
    public class ActualPlanImport
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string SlocDIP { get; set; }
        public string Model { get; set; }
        public double Quantity { get; set; }
        public string Blog { get; set; }
        public DateTime? ProductDate { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Note { get; set; }
        public string ModelFA { get; set; }
        public string UploadNo { get; set; }
        public bool IsUrgent { get; set; }
    }

    public class ActualPlanImportDIPViewModel
    {
        [Display(Name = "Plant")]
        public string? Plant { get; set; }

        [Display(Name = "Category")]
        public string? Category { get; set; }

        [Display(Name = "UploadNo")]
        public string? UploadNo { get; set; }

        public IEnumerable<ActualPlanImport> ActualPlanImports { get; set; }
    }
}