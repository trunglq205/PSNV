﻿using Microsoft.AspNetCore.Mvc.Rendering;
using Refit;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class ReceivingCardStorageFilter : BaseFilter
    {        
        public string Plant { get; set; } 
        public string Category { get; set; } 
        public string Sloc { get; set; } 
        public string Material { get; set; }
        [Display(Name = "Vendor")]
        public string VendorCode { get; set; }
        [Display(Name = "IV/DA")]
        public string DANo { get; set; }

        [Display(Name = "Inspection")]
        public bool IsInspection { get; set; }

        [Display(Name = "JIT")]
        public bool IsJIT { get; set; }
        [Display(Name = "Status")]
        public string StatusStorage { get; set; }

        [Display(Name = "Date Receive")]
        [Query(Format = "yyyy-MM-dd")]
        public DateTime? DateReceive { get; set; }

        [Display(Name = "Date Storage")]
        [Query(Format = "yyyy-MM-dd")]
        public DateTime? DateStorage { get; set; }
        
    }
}
