// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'callamr_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$CallAMRState {
  PageStatus get pageStatus => throw _privateConstructorUsedError;
  bool get processing => throw _privateConstructorUsedError;
  ErrorEntity? get errorEntity => throw _privateConstructorUsedError;
  RobotLocationStart? get robotLocationStart =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $CallAMRStateCopyWith<CallAMRState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $CallAMRStateCopyWith<$Res> {
  factory $CallAMRStateCopyWith(
          CallAMRState value, $Res Function(CallAMRState) then) =
      _$CallAMRStateCopyWithImpl<$Res, CallAMRState>;
  @useResult
  $Res call(
      {PageStatus pageStatus,
      bool processing,
      ErrorEntity? errorEntity,
      RobotLocationStart? robotLocationStart});
}

/// @nodoc
class _$CallAMRStateCopyWithImpl<$Res, $Val extends CallAMRState>
    implements $CallAMRStateCopyWith<$Res> {
  _$CallAMRStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pageStatus = null,
    Object? processing = null,
    Object? errorEntity = freezed,
    Object? robotLocationStart = freezed,
  }) {
    return _then(_value.copyWith(
      pageStatus: null == pageStatus
          ? _value.pageStatus
          : pageStatus // ignore: cast_nullable_to_non_nullable
              as PageStatus,
      processing: null == processing
          ? _value.processing
          : processing // ignore: cast_nullable_to_non_nullable
              as bool,
      errorEntity: freezed == errorEntity
          ? _value.errorEntity
          : errorEntity // ignore: cast_nullable_to_non_nullable
              as ErrorEntity?,
      robotLocationStart: freezed == robotLocationStart
          ? _value.robotLocationStart
          : robotLocationStart // ignore: cast_nullable_to_non_nullable
              as RobotLocationStart?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$CallAMRStateImplCopyWith<$Res>
    implements $CallAMRStateCopyWith<$Res> {
  factory _$$CallAMRStateImplCopyWith(
          _$CallAMRStateImpl value, $Res Function(_$CallAMRStateImpl) then) =
      __$$CallAMRStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {PageStatus pageStatus,
      bool processing,
      ErrorEntity? errorEntity,
      RobotLocationStart? robotLocationStart});
}

/// @nodoc
class __$$CallAMRStateImplCopyWithImpl<$Res>
    extends _$CallAMRStateCopyWithImpl<$Res, _$CallAMRStateImpl>
    implements _$$CallAMRStateImplCopyWith<$Res> {
  __$$CallAMRStateImplCopyWithImpl(
      _$CallAMRStateImpl _value, $Res Function(_$CallAMRStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pageStatus = null,
    Object? processing = null,
    Object? errorEntity = freezed,
    Object? robotLocationStart = freezed,
  }) {
    return _then(_$CallAMRStateImpl(
      pageStatus: null == pageStatus
          ? _value.pageStatus
          : pageStatus // ignore: cast_nullable_to_non_nullable
              as PageStatus,
      processing: null == processing
          ? _value.processing
          : processing // ignore: cast_nullable_to_non_nullable
              as bool,
      errorEntity: freezed == errorEntity
          ? _value.errorEntity
          : errorEntity // ignore: cast_nullable_to_non_nullable
              as ErrorEntity?,
      robotLocationStart: freezed == robotLocationStart
          ? _value.robotLocationStart
          : robotLocationStart // ignore: cast_nullable_to_non_nullable
              as RobotLocationStart?,
    ));
  }
}

/// @nodoc

class _$CallAMRStateImpl implements _CallAMRState {
  _$CallAMRStateImpl(
      {this.pageStatus = PageStatus.initial,
      this.processing = false,
      this.errorEntity = null,
      this.robotLocationStart = null});

  @override
  @JsonKey()
  final PageStatus pageStatus;
  @override
  @JsonKey()
  final bool processing;
  @override
  @JsonKey()
  final ErrorEntity? errorEntity;
  @override
  @JsonKey()
  final RobotLocationStart? robotLocationStart;

  @override
  String toString() {
    return 'CallAMRState(pageStatus: $pageStatus, processing: $processing, errorEntity: $errorEntity, robotLocationStart: $robotLocationStart)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$CallAMRStateImpl &&
            (identical(other.pageStatus, pageStatus) ||
                other.pageStatus == pageStatus) &&
            (identical(other.processing, processing) ||
                other.processing == processing) &&
            (identical(other.errorEntity, errorEntity) ||
                other.errorEntity == errorEntity) &&
            (identical(other.robotLocationStart, robotLocationStart) ||
                other.robotLocationStart == robotLocationStart));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, pageStatus, processing, errorEntity, robotLocationStart);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$CallAMRStateImplCopyWith<_$CallAMRStateImpl> get copyWith =>
      __$$CallAMRStateImplCopyWithImpl<_$CallAMRStateImpl>(this, _$identity);
}

abstract class _CallAMRState implements CallAMRState {
  factory _CallAMRState(
      {final PageStatus pageStatus,
      final bool processing,
      final ErrorEntity? errorEntity,
      final RobotLocationStart? robotLocationStart}) = _$CallAMRStateImpl;

  @override
  PageStatus get pageStatus;
  @override
  bool get processing;
  @override
  ErrorEntity? get errorEntity;
  @override
  RobotLocationStart? get robotLocationStart;
  @override
  @JsonKey(ignore: true)
  _$$CallAMRStateImplCopyWith<_$CallAMRStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
