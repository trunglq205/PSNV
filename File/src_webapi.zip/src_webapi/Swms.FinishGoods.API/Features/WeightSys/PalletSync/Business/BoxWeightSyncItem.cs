﻿namespace Swms.FinishGoods.API.Features.WeightSys.PalletSync.DataAccess;

public sealed record SerialItem(
    long BoxId,
    string Serial,
    string Model);