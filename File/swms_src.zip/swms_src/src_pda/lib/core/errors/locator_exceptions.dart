part of 'exceptions.dart';

/// Lỗi nghiệp vụ khi quét mã vị trí ở bước 2 (gán / lưu kho / tập kết).
sealed class LocatorException extends AppException {
  const LocatorException(super.message, {required super.code});
}

/// Vị trí quét được không thuộc loại khu của màn đang thao tác.
class LocatorWrongAreaException extends LocatorException {
  const LocatorWrongAreaException({
    required this.locatorCode,
    required this.area,
  }) : super(
    'Vị trí "$locatorCode" thuộc khu "$area", không đúng khu của màn này',
    code: 'error.locator_wrong_area',
  );

  final String locatorCode;
  final String area;

  @override
  Map<String, String> get namedArgs => {
    'locator': locatorCode,
    'area': area,
  };
}