﻿namespace SWMS_WebTool.Models.Barcode
{
    public class BarcodeLineFA
    {
        public string Model { get; set; }
        public string Line { get; set; }
        public string DeliveryDate { get; set; }
    }
}
