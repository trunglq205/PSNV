
import 'package:injectable/injectable.dart';
import 'package:smart_warehouse/shared/base/base_cubit.dart';
import '../../../../entities/Robot/robot_location_start.dart';
import '../../../../repositories/robot_repository.dart';
import '../../../../services/models/request/robot_call_request_model.dart';
import '../../../../shared/common/error_entity.dart';
import 'callamr_state.dart';

@injectable
class CallAMRController extends BaseCubit<CallAMRState>
{
  CallAMRController(this._robotRepository) : super(CallAMRState());
  final RobotRepository _robotRepository;
  @override
  Future<void> initData() {
    return launch(() async {

    });
  }
  Future<void> Robot_Call(String barcode, bool isUrgent, bool isCancel) {
    return launch(() async {
      try{
        final request = RobotCallRequestModel(qrcode: barcode, isUgent: isUrgent, isCancel: isCancel);
        final respone =  await _robotRepository.CallRobot(request);
        if(respone!.contains('Error'))
        {
          throw ValidationError(
            type: ValidationErrorType.barcodeExisted,
            message: respone.replaceAll('Error', ''),
          );
        }
      }
      catch(e)
      {
        throw ValidationError(
          type: ValidationErrorType.canNotEmpty,
          message: e.toString(),
        );
      }
    });
  }
}



