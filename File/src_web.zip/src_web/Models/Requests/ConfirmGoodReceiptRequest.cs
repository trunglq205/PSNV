﻿namespace SWMS_WebTool.Models.Requests
{
    public class ConfirmGoodReceiptRequest
    {
        public List<int> ItemDetailIds { get; set; }
        public int Type { get; set; }

    }

    public class ConfirmGoodReceiptResponse
    {
        public int Id { get; set; }
        public int Type { get; set; }
    }
}
