﻿using System.Diagnostics;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.ViewModels;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Controllers;

public class AuthController : BaseController
{
    private readonly ILogger<AuthController> _logger;
    private readonly ApiService _apiService;
    
    public AuthController(ILogger<AuthController> logger, ApiService apiService)
    {
        _logger = logger;
        _apiService = apiService;
    }

    [HttpGet]
    public IActionResult Login(string ReturnUrl)
    {
        var model = new LoginViewModel();
        if (!String.IsNullOrEmpty(ReturnUrl))
        {
            ViewBag.ReturnUrl = ReturnUrl;
        }
        return View("Views/Login/Index.cshtml", model);
    }

    [HttpPost]
    public async Task<IActionResult> Login(LoginViewModel model, string? ReturnUrl)
    {
        if (!ModelState.IsValid)
        {
            return View("Views/Login/Index.cshtml", model);
        }

        try
        {
            var request = new LoginRequest
            {
                UserId = model.ID,
                Password = model.Password
            };
            var response = await _apiService.Login(request);

            var claims = new List<Claim>
            {
                new Claim(ClaimTypes.Name, response.UserFullName ?? ""),
                new Claim(ClaimTypes.Role, response.Role.ToString() ?? ""),
                new Claim(ClaimTypes.GroupSid, response.Section.ToString() ?? ""),
                new Claim(ClaimTypes.NameIdentifier, response.UserID.ToString() ?? ""),
            };

            var claimsIdentity = new ClaimsIdentity(
                claims,
                CookieAuthenticationDefaults.AuthenticationScheme);

            await HttpContext.SignInAsync(
                CookieAuthenticationDefaults.AuthenticationScheme,
               new ClaimsPrincipal(claimsIdentity),
                new AuthenticationProperties
                {
                    IsPersistent = true,
                    ExpiresUtc = DateTime.UtcNow.AddDays(30)
                });
            HttpContext.Session.SetObject("IsAdmin", response.Role == Role.Leader ? "Admin" : "");
            HttpContext.Session.SetObject("WebRoles", response.WebRole);
            HttpContext.Session.SetString("SWMSToken", response.AssessToken ?? "");
            if (!string.IsNullOrEmpty(ReturnUrl))
            {
                return Redirect(ReturnUrl); 
            }
            return RedirectToAction("Index", "Home");
        } catch (Exception e)
        {
            ModelState.AddModelError("LoginError", e.Message);
            return View("Views/Login/Index.cshtml", model);
        }
     
    }

    [HttpGet]
    public IActionResult ChangePassword()
    {
        return View("Views/ChangePassword/Index.cshtml", new ChangePasswordViewModel());
    }

    [HttpPost]
    public async Task<IActionResult> ChangePassword(ChangePasswordViewModel model)
    {
        if (!ModelState.IsValid)
        {
            return View("Views/ChangePassword/Index.cshtml", model);
        }

        try
        {
            var request = new ChangePasswordRequest
            {
                PasswordOld = model.OldPassword,
                PasswordNew = model.NewPassword
            };
            await _apiService.ChangePassword(request);

            return RedirectToAction("Index", "Home");
        }
        catch (Exception e)
        {
            ModelState.AddModelError("LoginError", e.Message);
            return View("Views/ChangePassword/Index.cshtml", model);
        }

    }


    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        try
        {
            //await _apiService.Logout();
            await HttpContext.SignOutAsync(
                CookieAuthenticationDefaults.AuthenticationScheme);
            HttpContext.Session.Clear();
            return RedirectToAction("Login");
        } catch
        {
            return RedirectToAction("Login");
        }
    }

    [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
    public IActionResult Error()
    {
        return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
    }
}

