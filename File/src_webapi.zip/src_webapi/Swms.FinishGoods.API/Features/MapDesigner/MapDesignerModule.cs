using Swms.FinishGoods.API.Features.MapDesigner.Business;
using Swms.FinishGoods.API.Features.MapDesigner.DataAccess;

namespace Swms.FinishGoods.API.Features.MapDesigner;

public static class MapDesignerModule
{
    public static IServiceCollection AddMapDesignerFeature(this IServiceCollection services)
    {
        services.AddScoped<IMapDesignerService, MapDesignerService>();
        services.AddScoped<IMapDesignerRepository, MapDesignerRepository>();
        return services;
    }
}
