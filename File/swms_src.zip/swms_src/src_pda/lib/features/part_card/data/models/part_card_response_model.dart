import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_suggestion.dart';

part 'part_card_response_model.g.dart';

/// Khớp `PartCardRowResponse` phía API.
@JsonSerializable()
class PartCardRowResponseModel {
  final String? g21Part;
  final String? model;
  final String? innerBox;
  final int? qty;
  final String? origin;
  final bool? oqcChecked;
  final double? innerLength;
  final double? innerWidth;
  final double? innerHeight;
  final double? innerWeight;

  const PartCardRowResponseModel({
    this.g21Part,
    this.model,
    this.innerBox,
    this.qty,
    this.origin,
    this.oqcChecked,
    this.innerLength,
    this.innerWidth,
    this.innerHeight,
    this.innerWeight,
  });

  factory PartCardRowResponseModel.fromJson(Map<String, dynamic> json) =>
      _$PartCardRowResponseModelFromJson(json);

  Map<String, dynamic> toJson() => _$PartCardRowResponseModelToJson(this);
}

/// Khớp `PartCardResponse` phía API.
///
/// Lưu ý: response KHÔNG trả `payload` và không có `cardId` riêng — Card_ID
/// nằm trong payload lúc gửi lên, muốn đối chiếu thì giữ ở client.
@JsonSerializable()
class PartCardResponseModel {
  final int? id;
  final String? poNo;
  final String? customerPoNo;
  final DateTime? productionDate;
  final String? packer;
  final String? checker;

  /// Mã số category (`Category.value`).
  final int? category;

  final String? model;
  final int? qty;
  final String? origin;

  final double? length;
  final double? width;
  final double? height;
  final double? weight;

  final bool? isOverseaService;
  final List<PartCardRowResponseModel>? rows;

  final DateTime? printedAt;
  final String? printedBy;

  const PartCardResponseModel({
    this.id,
    this.poNo,
    this.customerPoNo,
    this.productionDate,
    this.packer,
    this.checker,
    this.category,
    this.model,
    this.qty,
    this.origin,
    this.length,
    this.width,
    this.height,
    this.weight,
    this.isOverseaService,
    this.rows,
    this.printedAt,
    this.printedBy,
  });

  factory PartCardResponseModel.fromJson(Map<String, dynamic> json) =>
      _$PartCardResponseModelFromJson(json);

  Map<String, dynamic> toJson() => _$PartCardResponseModelToJson(this);
}

/// Khớp `PagedResult<PartCardResponse>` phía API.
@JsonSerializable()
class PartCardHistoryPageModel {
  final List<PartCardResponseModel>? items;
  final int? total;

  const PartCardHistoryPageModel({this.items, this.total});

  factory PartCardHistoryPageModel.fromJson(Map<String, dynamic> json) =>
      _$PartCardHistoryPageModelFromJson(json);

  Map<String, dynamic> toJson() => _$PartCardHistoryPageModelToJson(this);
}

extension PartCardRowResponseModelX on PartCardRowResponseModel {
  PartCardHistoryRow toEntity() => PartCardHistoryRow(
    model: model ?? '',
    g21Part: g21Part,
    innerBox: innerBox,
    qty: qty,
    origin: origin,
    oqcChecked: oqcChecked ?? false,
  );
}

extension PartCardResponseModelX on PartCardResponseModel {
  PartCardPrintHistory toEntity() => PartCardPrintHistory(
    id: id,
    poNo: poNo,
    customerPoNo: customerPoNo,
    productionDate: productionDate,
    packer: packer,
    checker: checker,
    model: model,
    qty: qty,
    origin: origin,
    isMulti: isOverseaService ?? false,
    rows: rows?.map((e) => e.toEntity()).toList() ?? const [],
    printedAt: printedAt,
    printedBy: printedBy,
  );

  /// Rút phiếu thành mẫu thống kê cho model [key] (đã trim + upper).
  ///
  /// - API lọc model theo TIỀN TỐ → ở đây khớp lại TUYỆT ĐỐI.
  /// - Phiếu 1 mã: origin / qty ở header. Nhiều mã: lấy ở dòng của đúng model.
  /// - Phiếu không có đủ kích thước thì không tính.
  PartCardHistorySample? toSample(String key) {
    final l = length, w = width, h = height;
    if (l == null || w == null || h == null || l <= 0 || w <= 0 || h <= 0) {
      return null;
    }

    String? org;
    int? q;
    if (isOverseaService ?? false) {
      final row = rows?.where((r) => _sameModel(r.model, key)).firstOrNull;
      if (row == null) return null;
      org = row.origin;
      q = row.qty;
    } else {
      if (!_sameModel(model, key)) return null;
      org = origin;
      q = qty;
    }

    return PartCardHistorySample(
      length: l,
      width: w,
      height: h,
      weight: weight ?? 0,
      qty: q ?? 0,
      category: category,
      origin: (org == null || org.trim().isEmpty) ? null : org.trim(),
    );
  }
}

bool _sameModel(String? value, String key) =>
    value != null && value.trim().toUpperCase() == key;

extension PartCardResponseModelListX on List<PartCardResponseModel> {
  List<PartCardPrintHistory> toEntities() => map((e) => e.toEntity()).toList();
}