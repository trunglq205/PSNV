import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';
import 'package:swms_finish_goods/features/abnormal_report/presentation/providers/ng_providers.dart';

/// Danh sách phiếu hàng bất thường theo NGÀY phát hiện (mặc định hôm nay),
/// kèm nút tạo phiếu mới. Trạng thái phiếu vẫn hiện trên từng thẻ, nhưng
/// không dùng để lọc — công nhân tìm phiếu theo ngày mình làm.
@RoutePage()
class NgListPage extends ConsumerStatefulWidget {
  const NgListPage({super.key});

  @override
  ConsumerState<NgListPage> createState() => _NgListPageState();
}

class _NgListPageState extends ConsumerState<NgListPage> {
  late DateTime _day = _today;

  static DateTime get _today {
    final n = DateTime.now();
    return DateTime(n.year, n.month, n.day);
  }

  String get _key =>
      '${_day.year.toString().padLeft(4, '0')}-'
      '${_day.month.toString().padLeft(2, '0')}-'
      '${_day.day.toString().padLeft(2, '0')}';

  bool get _isToday => _day == _today;

  void _shift(int days) =>
      setState(() => _day = _day.add(Duration(days: days)));

  Future<void> _pick() async {
    final picked = await showDatePicker(
      context: context,
      initialDate: _day,
      firstDate: DateTime(2024),
      // Không cho chọn tương lai: phiếu chỉ ghi được cho hôm nay trở về trước.
      lastDate: _today,
      // Không truyền locale: để hộp lịch thừa hưởng Localizations của app như
      // mọi dialog khác, thay vì tự ép một locale có thể chưa có delegate.
    );
    if (picked != null) {
      setState(() => _day = DateTime(picked.year, picked.month, picked.day));
    }
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(ngListProvider(_key));

    // Danh mục loại lỗi để dịch mã sang tên. null = chưa tải xong; lúc đó
    // ngTypeName() trả về chính cái mã, danh sách vẫn hiện được chứ không
    // phải chờ thêm một lượt gọi mạng nữa mới thấy phiếu.
    final types = ngTypesOf(ref.watch(ngTypesProvider));

    return Scaffold(
      appBar: AppBar(
        title: Text(LocaleKeys.ng_title.tr()),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.invalidate(ngListProvider),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () async {
          final created = await context.router.push(const NgCreateRoute());
          if (created == true) ref.invalidate(ngListProvider);
        },
        icon: const Icon(Icons.add),
        label: Text(LocaleKeys.ng_new.tr()),
      ),
      body: Column(
        children: [
          _DayBar(
            day: _day,
            isToday: _isToday,
            onPrev: () => _shift(-1),
            onNext: _isToday ? null : () => _shift(1),
            onPick: _pick,
            onToday: _isToday ? null : () => setState(() => _day = _today),
            count: async.value?.length,
          ),
          Expanded(
            child: async.when(
              loading: () => const AppLoading(),
              error: (e, _) => AppErrorView.page(
                message: '$e',
                onRetry: () => ref.invalidate(ngListProvider),
              ),
              data: (rows) => rows.isEmpty
                  ? _Empty(text: LocaleKeys.ng_empty_day.tr())
                  : RefreshIndicator(
                      onRefresh: () async => ref.invalidate(ngListProvider),
                      child: ListView.builder(
                        padding: const EdgeInsets.fromLTRB(12, 0, 12, 92),
                        itemCount: rows.length,
                        itemBuilder: (_, i) => Padding(
                          padding: const EdgeInsets.only(bottom: 8),
                          child: _NgCard(
                            report: rows[i],
                            typeName: ngTypeName(types, rows[i].ngType),
                            onTap: () async {
                              await context.router
                                  .push(NgDetailRoute(id: rows[i].id));
                              ref.invalidate(ngListProvider);
                            },
                          ),
                        ),
                      ),
                    ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Dải chọn ngày: lùi / tiến 1 ngày, chạm vào ngày để mở lịch.
class _DayBar extends StatelessWidget {
  final DateTime day;
  final bool isToday;
  final VoidCallback onPrev;
  final VoidCallback? onNext;
  final VoidCallback onPick;
  final VoidCallback? onToday;
  final int? count;

  const _DayBar({
    required this.day,
    required this.isToday,
    required this.onPrev,
    required this.onNext,
    required this.onPick,
    required this.onToday,
    required this.count,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.fromLTRB(4, 6, 8, 6),
      decoration: BoxDecoration(
        color: swms.card,
        border: Border(bottom: BorderSide(color: swms.border)),
      ),
      child: Row(
        children: [
          IconButton(
            icon: const Icon(Icons.chevron_left),
            visualDensity: VisualDensity.compact,
            onPressed: onPrev,
          ),
          Expanded(
            child: InkWell(
              onTap: onPick,
              borderRadius: BorderRadius.circular(8),
              child: Padding(
                padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 6),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Icon(Icons.event, size: 16, color: swms.text3),
                    const SizedBox(width: 6),
                    Flexible(
                      child: Text(
                        // Chỉ dùng mẫu toàn chữ số, không truyền locale: dự án
                        // chưa gọi initializeDateFormatting() nên DateFormat
                        // với tên thứ/tháng theo locale sẽ ném
                        // LocaleDataException ngay khi đổi ngày.
                        isToday
                            ? '${LocaleKeys.ng_date_today.tr()} · '
                                '${DateFormat('dd/MM/yyyy').format(day)}'
                            : DateFormat('dd/MM/yyyy').format(day),
                        overflow: TextOverflow.ellipsis,
                        style: TextStyle(
                          fontSize: 13,
                          fontWeight: FontWeight.w800,
                          color: swms.text1,
                        ),
                      ),
                    ),
                    if (count != null) ...[
                      const SizedBox(width: 6),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 7, vertical: 1),
                        decoration: BoxDecoration(
                          color: swms.primaryTint,
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(
                          '$count',
                          style: TextStyle(
                            fontSize: 11,
                            fontWeight: FontWeight.w800,
                            color: swms.primaryDark,
                          ),
                        ),
                      ),
                    ],
                  ],
                ),
              ),
            ),
          ),
          IconButton(
            icon: const Icon(Icons.chevron_right),
            visualDensity: VisualDensity.compact,
            onPressed: onNext,
          ),
          // Chỉ hiện khi đang xem ngày khác — bấm là về hôm nay.
          if (onToday != null)
            TextButton(
              onPressed: onToday,
              style: TextButton.styleFrom(
                visualDensity: VisualDensity.compact,
                padding: const EdgeInsets.symmetric(horizontal: 8),
              ),
              child: Text(
                LocaleKeys.ng_date_today.tr(),
                style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
              ),
            ),
        ],
      ),
    );
  }
}

class _Empty extends StatelessWidget {
  final String text;
  const _Empty({required this.text});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: Text(
          text,
          textAlign: TextAlign.center,
          style: TextStyle(color: swms.text3, fontSize: 13),
        ),
      ),
    );
  }
}

class _NgCard extends StatelessWidget {
  final NgReport report;
  final VoidCallback onTap;

  /// Nhãn loại lỗi, truyền từ ngoài vào: widget này là StatelessWidget nên
  /// không đọc được provider, mà nhãn giờ đến từ danh mục trên server.
  final String typeName;

  const _NgCard({
    required this.report,
    required this.onTap,
    required this.typeName,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  report.docNo,
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    fontSize: 14,
                    color: swms.text1,
                  ),
                ),
              ),
              ngStatusPill(context, report.docStatus),
            ],
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              if (report.palletCode != null)
                Text(
                  report.palletCode!,
                  style: TextStyle(fontSize: 12, color: swms.text2),
                ),
              if (report.model != null) ...[
                Text(' · ', style: TextStyle(color: swms.text4)),
                Expanded(
                  child: Text(
                    report.model!,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(fontSize: 12, color: swms.text3),
                  ),
                ),
              ],
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: Wrap(
                  spacing: 6,
                  runSpacing: 6,
                  children: [
                    _Tag(
                      text: typeName,
                      bg: swms.card2,
                      fg: swms.text2,
                    ),
                    _Tag(
                      // Lỗi cả pallet thì số lượng vô nghĩa (mỗi mục lưu 1),
                      // hiện "1 cái" làm người đọc tưởng chỉ 1 sản phẩm bị lỗi.
                      text: report.isWholePallet
                          ? LocaleKeys.ng_whole_pallet.tr()
                          : '${report.qtyAffected} ${LocaleKeys.ng_qty_word.tr()}',
                      bg: swms.warningBg,
                      fg: swms.warning,
                    ),
                    if (report.photoCount > 0)
                      _Tag(
                        text: '📷 ${report.photoCount}',
                        bg: swms.card2,
                        fg: swms.text3,
                      ),
                  ],
                ),
              ),
              // Danh sách đã lọc theo ngày nên chỉ cần giờ.
              Text(
                DateFormat('HH:mm').format(report.discoveredAt),
                style: TextStyle(fontSize: 11, color: swms.text4),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _Tag extends StatelessWidget {
  final String text;
  final Color bg;
  final Color fg;
  const _Tag({required this.text, required this.bg, required this.fg});

  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
        decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(10)),
        child: Text(
          text,
          style: TextStyle(fontSize: 11, fontWeight: FontWeight.w700, color: fg),
        ),
      );
}

/// Nhãn trạng thái phiếu — dùng chung cho danh sách và màn chi tiết.
StatusPill ngStatusPill(BuildContext context, String status) {
  final label = 'ng.status.$status'.tr();
  return switch (status) {
    'finalized' => StatusPill.success(context, label: label),
    'ready_to_finalize' => StatusPill.warning(context, label: label),
    'submitted' || 'in_review' => StatusPill.info(context, label: label),
    'cancelled' => StatusPill.danger(context, label: label),
    _ => StatusPill.neutral(context, label: label),
  };
}
