﻿using Refit;
using Swms.FinishGoods.Web.Shared.Client.Http;
using Swms.FinishGoods.Web.Shared.Infrastructure.Http;

namespace Swms.FinishGoods.Web.Extensions;

public static class RefitClientExtensions
{
    public static IServiceCollection AddApiClient<T>(
        this IServiceCollection services, ApiClientContext api, bool withAuth = true)
        where T : class
    {
        var builder = services.AddRefitClient<T>(api.RefitSettings)
            .ConfigureHttpClient(api.ConfigureClient);

        if (withAuth)
            builder.AddHttpMessageHandler<AuthTokenHandler>();

        builder.AddHttpMessageHandler<LanguageHandler>();
        return services;
    }
}