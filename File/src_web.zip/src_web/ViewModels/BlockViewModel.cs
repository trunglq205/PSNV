﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class BlockViewModel : TableViewModel<BlockEntity, BlockFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, BlockFilter? filter = null)
        {
            return new
            { 
                RackId = filter?.RackId ?? Filter.RackId,
                Name = filter?.Name ?? Filter.Name,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class QRCodeBlockViewModel
    {
        public string Name { get; set; }
        public string QRCode { get; set; }
    }

    public class ListQRCodeBlockViewModel
    {
        public List<QRCodeBlockViewModel> QRCodeBlockViewModels { get; set; }
    }
}
