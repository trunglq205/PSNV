﻿using Swms.FinishGoods.Api.Features.Categories.Business;
using Swms.FinishGoods.Api.Features.Categories.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.Api.Features.Categories;

public static class CategoryModule
{
    public static IServiceCollection AddCategoryFeature(this IServiceCollection services)
    {
        services.AddScoped<ICategoryService, CategoryService>();
        services.AddScoped<ICategoryRepository, CategoryRepository>();
        return services;
    }
}