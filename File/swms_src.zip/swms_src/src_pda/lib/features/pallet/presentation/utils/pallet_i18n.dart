import 'package:easy_localization/easy_localization.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow.dart';

// ─────────────────────────────────────────────────────────────
//  Cầu nối enum ↔ LocaleKeys.
//  Trước đây key được ghép chuỗi ('pallet.flow.action_${action.name}'),
//  đổi tên key trong JSON là hỏng ngầm lúc chạy. Gom về switch trên enum
//  để trình biên dịch bắt lỗi ngay khi thiếu nhánh hoặc sai hằng.
// ─────────────────────────────────────────────────────────────

extension PalletActionI18n on PalletAction {
  /// Nhãn nút chọn hành động.
  String get labelKey => switch (this) {
    PalletAction.assign => LocaleKeys.pallet_flow_action_assign,
    PalletAction.moveReceiving ||
    PalletAction.moveStoring ||
    PalletAction.moveVanning => LocaleKeys.pallet_flow_action_move,
    PalletAction.store => LocaleKeys.pallet_flow_action_store,
    PalletAction.vanning => LocaleKeys.pallet_flow_action_vanning,
  };

  /// Nhãn nút xác nhận ở thanh dưới.
  String get submitKey => switch (this) {
    PalletAction.assign => LocaleKeys.pallet_flow_submit_assign,
    PalletAction.moveReceiving ||
    PalletAction.moveStoring ||
    PalletAction.moveVanning => LocaleKeys.pallet_flow_submit_move,
    PalletAction.store => LocaleKeys.pallet_flow_submit_store,
    PalletAction.vanning => LocaleKeys.pallet_flow_submit_vanning,
  };

  /// Nhãn khung quét vị trí đích; null với hành động không cần quét (rời/out).
  String? get scanLocatorKey => switch (this) {
    PalletAction.assign => LocaleKeys.pallet_flow_scan_locator_assign,
    PalletAction.moveReceiving ||
    PalletAction.moveStoring ||
    PalletAction.moveVanning => LocaleKeys.pallet_flow_scan_locator_move,
    PalletAction.store => LocaleKeys.pallet_flow_scan_locator_store,
    PalletAction.vanning => LocaleKeys.pallet_flow_scan_locator_vanning,
  };
}

extension PalletFlowI18n on PalletFlow {
  String get titleKey => switch (this) {
    PalletFlow.tempLocation => LocaleKeys.pallet_temp_location_title,
    PalletFlow.storing => LocaleKeys.pallet_storing_title,
    PalletFlow.warehouseMove => LocaleKeys.pallet_warehouse_move_title,
    PalletFlow.vanningArea => LocaleKeys.pallet_vanning_area_title,
  };

  String get subtitleKey => switch (this) {
    PalletFlow.tempLocation => LocaleKeys.pallet_temp_location_subtitle,
    PalletFlow.storing => LocaleKeys.pallet_storing_subtitle,
    PalletFlow.warehouseMove => LocaleKeys.pallet_warehouse_move_subtitle,
    PalletFlow.vanningArea => LocaleKeys.pallet_vanning_area_subtitle,
  };
}

// ── Hai nhãn phụ thuộc dữ liệu server, không thể dùng LocaleKeys ──
// Giá trị đến từ DB (area_code, trạng thái lịch sử) nên key chỉ biết lúc chạy;
// LocaleKeys lại chỉ sinh hằng cho nút lá nên phải giữ 2 tiền tố dạng chuỗi.
// Đây là NƠI DUY NHẤT trong feature còn viết tay đường dẫn key — đổi cấu trúc
// JSON thì sửa 2 hằng dưới đây.
const _statusPrefix = 'pallet.detail.status';

/// Tên khu theo `area_code`: ưu tiên bản dịch `pallet.flow.area.<code>`,
/// rồi `area_name` của DB (master chỉ lưu 1 ngôn ngữ), cuối cùng là chính mã.
/// Tên khu hiển thị. Bản đồ do người dùng tự tạo trong Map Design nên tên
/// lấy thẳng từ DB (area_name); chỉ lùi về mã khu khi server không trả tên.
String palletAreaLabel(String code, {String? dbName}) {
  if (dbName != null && dbName.isNotEmpty) return dbName;
  return code;
}

/// Nhãn trạng thái trong timeline lịch sử; fallback về chuỗi thô của server.
String palletStatusLabel(String? status) {
  if (status == null || status.isEmpty) {
    return LocaleKeys.pallet_detail_hist_changed.tr();
  }
  final key = '$_statusPrefix.$status';
  final translated = key.tr();
  return translated == key ? status : translated;
}
