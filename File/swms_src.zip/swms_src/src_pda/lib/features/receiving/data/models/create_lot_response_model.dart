import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/lot_entities.dart';

part 'create_lot_response_model.g.dart';

@JsonSerializable()
class CreateLotResponseModel {
  final int id;
  final String lotNo; // 310 + yymmdd + seq(3)
  final String detailLevel; // serial | box_line | box_count
  final int boxCount;
  final int lineCount;

  const CreateLotResponseModel({
    required this.id,
    required this.lotNo,
    required this.detailLevel,
    required this.boxCount,
    required this.lineCount,
  });

  CreatedLot toEntity() => CreatedLot(
    id: id,
    lotNo: lotNo,
    detailLevel: detailLevel,
    boxCount: boxCount,
    lineCount: lineCount,
  );

  factory CreateLotResponseModel.fromJson(Map<String, dynamic> json) =>
      _$CreateLotResponseModelFromJson(json);

  Map<String, dynamic> toJson() => _$CreateLotResponseModelToJson(this);
}