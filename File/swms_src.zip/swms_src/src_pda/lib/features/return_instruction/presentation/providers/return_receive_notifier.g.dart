// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_receive_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ReturnReceiveNotifier)
final returnReceiveProvider = ReturnReceiveNotifierProvider._();

final class ReturnReceiveNotifierProvider
    extends $NotifierProvider<ReturnReceiveNotifier, ReturnReceiveState> {
  ReturnReceiveNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'returnReceiveProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$returnReceiveNotifierHash();

  @$internal
  @override
  ReturnReceiveNotifier create() => ReturnReceiveNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReturnReceiveState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReturnReceiveState>(value),
    );
  }
}

String _$returnReceiveNotifierHash() =>
    r'0000000000000000000000000000000000000000';

abstract class _$ReturnReceiveNotifier extends $Notifier<ReturnReceiveState> {
  ReturnReceiveState build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<ReturnReceiveState, ReturnReceiveState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ReturnReceiveState, ReturnReceiveState>,
              ReturnReceiveState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
