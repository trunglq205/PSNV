﻿namespace SWMS_WebTool.Models.Requests
{
    public class CreateReceivingCardByDAInvID
    {
        public int Type { get; set; }
        public Int64 Id { get; set; }
        public bool IsPreview { get; set; } = true;
    }
}
