using Swms.FinishGoods.API.Common.Business;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;

namespace Swms.FinishGoods.API.Features.Sync.Business;

/// <summary>
/// Chạy song song có giới hạn cho các job đồng bộ (FossSyncJob, HdSoftSyncJob).
/// Mỗi phần tử 1 scope riêng: service/repo scoped không bị dùng chung giữa các luồng.
/// Lỗi của 1 pallet không làm hỏng cả bước.
/// </summary>
/// <typeparam name="TService">Service xử lý 1 pallet, lấy mới trong từng scope.</typeparam>
public sealed class SyncBatch<TService> where TService : notnull
{
    private readonly IServiceScopeFactory _scopes;
    private readonly ILogger _log;

    public SyncBatch(IServiceScopeFactory scopes, ILogger log)
    {
        _scopes = scopes;
        _log = log;
    }

    public Task ForEachAsync<T>(
        IReadOnlyList<T> items,
        Func<T, string> lotOf,
        int parallel,
        string step,
        SyncProgress p,
        CancellationToken ct,
        Func<TService, T, Task> body)
        => Parallel.ForEachAsync(
            items,
            new ParallelOptions { MaxDegreeOfParallelism = Math.Max(1, parallel), CancellationToken = ct },
            async (item, _) =>
            {
                var lot = lotOf(item);
                await using var scope = _scopes.CreateAsyncScope();
                var svc = scope.ServiceProvider.GetRequiredService<TService>();
                try
                {
                    await body(svc, item);
                }
                catch (NotFoundException ex) { p.Warn(step, lot, ex.Message); }
                catch (BusinessRuleException ex) { p.Warn(step, lot, ex.Message); }
                catch (Exception ex) when (ex is not OperationCanceledException)
                {
                    _log.LogWarning(ex, "[{Step}] {Lot} failed", step, lot);
                    p.Fail(step, lot, ex.Message);
                }
                finally
                {
                    Interlocked.Increment(ref p.StepProcessed);
                }
            });
}

/// <summary>Tiện ích dùng chung của các job đồng bộ.</summary>
public static class SyncLots
{
    /// <summary>Mã lot bỏ qua — thay cho RemoveAll(... Contains("3102608") ...) đang hard-code ở Web.</summary>
    private static readonly string[] ExcludeLotContains = ["3102608", "3102607"];

    /// <summary>Trim, bỏ rỗng, bỏ lot trong danh sách loại trừ, bỏ trùng.</summary>
    public static List<string> Clean(IEnumerable<string?> lots) => lots
        .Select(x => (x ?? "").Trim())
        .Where(x => x.Length > 0)
        .Where(x => !ExcludeLotContains.Any(e => x.Contains(e, StringComparison.Ordinal)))
        .Distinct(StringComparer.OrdinalIgnoreCase)
        .ToList();

    /// <summary>Context ghi event cho 1 pallet trong lượt đồng bộ. Actor mặc định = người bấm nút.</summary>
    public static IntegrationSyncContext NewSync(string source, Guid batchId, string? actor = null)
        => new(source, actor ?? ActorScope.Current) { BatchId = batchId };
}
