using System.Net;
using System.Text.RegularExpressions;
using Markdig;
using Markdig.Renderers;
using Markdig.Syntax;
using Markdig.Syntax.Inlines;

namespace Swms.FinishGoods.API.Shared.Business.Mail;

/*  Dựng HTML mail từ nội dung MARKDOWN (mẫu ở màn Cấu hình email) — DÙNG CHUNG cho
    mail hàng thiếu và mail phiếu bất thường.

    Dùng được: **đậm**, *nghiêng*, ~~gạch~~, # tiêu đề, - danh sách, 1. danh sách số,
    | bảng | kiểu pipe |, [link](https://…), > trích dẫn. Xuống 1 dòng là xuống dòng
    (không cần 2 dấu cách cuối dòng như markdown gốc).

    AN TOÀN — nội dung đi từ client lên (có cả Ghi chú người dùng gõ):
      - DisableHtml: thẻ HTML gõ vào hiện thành chữ, không thành thẻ.
      - Ảnh ![](…) đổi thành link thường: không cho chèn ảnh theo dõi vào mail.
      - Link chỉ giữ http / https / mailto; còn lại (javascript:, data:…) thành "#".

    Markdig sinh thẻ trần, không style. Outlook bỏ qua CSS class nên gắn style
    INLINE vào từng thẻ sau khi render (bảng có viền, đoạn có khoảng cách…).
    GIỮ KHỚP pipeline với MailMarkdown bên Web (Shared) để xem trước đúng như mail gửi. */
public static class MarkdownMail
{
    private static readonly MarkdownPipeline Pipeline = new MarkdownPipelineBuilder()
        .UsePipeTables()
        .UseEmphasisExtras()
        .UseAutoLinks()
        .UseSoftlineBreakAsHardlineBreak()
        .DisableHtml()
        .Build();

    /// <summary>Màu dải tiêu đề.</summary>
    public const string Blue = "#1565c0", Red = "#c62828", Orange = "#e65100";

    private const string Font = "'Segoe UI',Arial,Helvetica,sans-serif";
    private const string Border = "#e3e6ea";

    public static string Render(string subject, string markdown, string accent = Blue)
    {
        var content = Style(ToHtml(markdown));

        return $"""
            <table role="presentation" width="100%" cellpadding="0" cellspacing="0" style="background:#f3f5f7">
            <tr><td align="center" style="padding:20px 12px">
            <table role="presentation" width="640" cellpadding="0" cellspacing="0" style="width:100%;max-width:640px;background:#ffffff;border:1px solid {Border};font-family:{Font};font-size:14px;line-height:1.55;color:#1f2933">
            <tr><td style="background:{accent};color:#ffffff;padding:14px 20px;font-size:16px;font-weight:600">{WebUtility.HtmlEncode(subject)}</td></tr>
            <tr><td style="padding:18px 20px 6px">{content}</td></tr>
            <tr><td style="padding:12px 20px;border-top:1px solid {Border};color:#8a94a1;font-size:12px">Mail gửi tự động từ hệ thống SWMS – Kho thành phẩm.</td></tr>
            </table>
            </td></tr>
            </table>
            """;
    }

    /// <summary>
    /// Thoát ký tự markdown trong CHỮ NGƯỜI DÙNG GÕ (mô tả, tên…) trước khi điền vào mẫu:
    /// "*" trong mô tả không được biến thành in nghiêng, "# " đầu dòng không thành tiêu đề.
    /// Thoát mọi dấu câu ASCII bằng '\' — hợp lệ trong CommonMark, hiện ra y nguyên ký tự.
    /// KHÔNG dùng cho link (thoát làm hỏng địa chỉ).
    /// </summary>
    public static string Escape(string? text)
    {
        if (string.IsNullOrEmpty(text)) return "";
        var sb = new System.Text.StringBuilder(text.Length + 8);
        foreach (var ch in text)
        {
            if (ch < 128 && char.IsPunctuation(ch) || ch is '`' or '^' or '|' or '~' or '<' or '>' or '+' or '=' or '$')
                sb.Append('\\');
            sb.Append(ch);
        }
        return sb.ToString();
    }

    /// <summary>Markdown → HTML thẻ trần, đã chặn ảnh và link nguy hiểm.</summary>
    private static string ToHtml(string? markdown)
    {
        var doc = Markdown.Parse(markdown ?? "", Pipeline);
        foreach (var link in doc.Descendants<LinkInline>())
        {
            link.IsImage = false;
            if (!IsSafeUrl(link.Url)) link.Url = "#";
        }
        foreach (var auto in doc.Descendants<AutolinkInline>())
            if (!IsSafeUrl(auto.Url)) auto.Url = "#";

        using var sw = new StringWriter();
        var renderer = new HtmlRenderer(sw);
        Pipeline.Setup(renderer);
        renderer.Render(doc);
        sw.Flush();
        return sw.ToString();
    }

    private static bool IsSafeUrl(string? url)
        => !string.IsNullOrWhiteSpace(url)
           && (url.StartsWith("http://", StringComparison.OrdinalIgnoreCase)
               || url.StartsWith("https://", StringComparison.OrdinalIgnoreCase)
               || url.StartsWith("mailto:", StringComparison.OrdinalIgnoreCase));

    // ── Style inline cho thẻ Markdig sinh ra ─────────────────────────
    private static readonly Regex Cell = new(@"<(th|td)(?: style=""([^""]*)"")?>");

    private static string Style(string html)
    {
        html = Cell.Replace(html, m =>
        {
            var head = m.Groups[1].Value == "th";
            var css = $"border:1px solid {Border};padding:7px 12px;vertical-align:top;text-align:left;"
                      + (head ? "background:#f6f8fa;color:#5f6b7a;font-weight:600;" : "")
                      + m.Groups[2].Value;                    // giữ căn lề từ |:---:| nếu có
            return $"<{m.Groups[1].Value} style=\"{css}\">";
        });

        return html
            .Replace("<table>", "<table style=\"width:100%;border-collapse:collapse;margin:2px 0 16px\">")
            .Replace("<p>", "<p style=\"margin:0 0 12px\">")
            .Replace("<ul>", "<ul style=\"margin:0 0 12px;padding-left:22px\">")
            .Replace("<ol>", "<ol style=\"margin:0 0 12px;padding-left:22px\">")
            .Replace("<blockquote>", $"<blockquote style=\"margin:0 0 12px;padding:8px 12px;border-left:3px solid {Border};background:#f6f8fa;color:#5f6b7a\">")
            .Replace("<h1>", "<h1 style=\"margin:0 0 12px;font-size:20px\">")
            .Replace("<h2>", "<h2 style=\"margin:0 0 10px;font-size:17px\">")
            .Replace("<h3>", "<h3 style=\"margin:0 0 8px;font-size:15px\">")
            .Replace("<a href=", "<a style=\"color:#1565c0\" href=");
    }
}
