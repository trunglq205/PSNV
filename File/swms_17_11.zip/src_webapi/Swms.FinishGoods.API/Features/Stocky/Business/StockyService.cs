using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.Stocky.Api;
using Swms.FinishGoods.API.Features.Stocky.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.Stocky.Business;

public class StockyService : IStockyService
{
    /// <summary>
    /// Trần số xe một lần chốt. PDA quét tay nên thực tế vài chục; đặt trần để
    /// một request lỗi không ghi hàng nghìn dòng trong một transaction.
    /// </summary>
    private const int MaxCodesPerBatch = 200;

    private readonly IStockyRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    /// <summary>
    /// Dùng để chuyển ô cho hàng NẰM TRÊN xe khi đặt xe vào ô.
    ///
    /// ⚠ Vì sao gọi sang slice Pallets chứ không tự UPDATE wms.pallets ở đây:
    /// đường chuyển ô của pallet còn gánh ba việc khác mà một câu UPDATE không
    /// có — ghi LỊCH SỬ vị trí, ghi SỰ KIỆN kho, và CỔNG DUYỆT hàng RW/RB
    /// (đưa hàng tái gia công sang khu Nhận hàng = giao cho FA, phải có duyệt
    /// của quản lý SCS). Tự ghi thẳng bảng là mở một đường lách cả ba.
    ///
    /// Chiều phụ thuộc Stocky -> Pallets là chiều mới, nhưng không tạo vòng:
    /// slice Pallets không tham chiếu Stocky ở đâu (đã soát toàn bộ source).
    /// </summary>
    private readonly IPalletService _pallets;

    /// <summary>
    /// Mã 2 ô đọc từ appsettings, KHÔNG có mặc định trong source — xem
    /// <see cref="StockyOptions"/>.
    ///
    /// Đọc trong constructor của một service Scoped, tức mỗi request một lần.
    /// Host bật <c>reloadOnChange</c> cho appsettings.json, nên sửa mã ô trên
    /// server là request kế tiếp đã dùng giá trị mới — không build lại, cũng
    /// không restart.
    /// </summary>
    private readonly StockyOptions _options;

    public StockyService(
        IStockyRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        IConfiguration config,
        IPalletService pallets)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
        _options = StockyOptions.Validated(config);
        _pallets = pallets;
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    /// <summary>
    /// Xe có đang đứng ở FA không.
    ///
    /// So trên <see cref="StockyCart.CartLocatorCode"/> (ô RIÊNG của xe) chứ
    /// không phải <see cref="StockyCart.LocatorCode"/> — cái sau ưu tiên ô của
    /// pallet trên xe, nên với xe còn hàng nó nói về hàng chứ không nói về xe.
    /// </summary>
    private bool IsAtFa(StockyCart c) =>
        !string.IsNullOrWhiteSpace(c.CartLocatorCode)
        && string.Equals(c.CartLocatorCode, _options.FaLocatorCode, StringComparison.OrdinalIgnoreCase);

    public async Task<IReadOnlyList<StockyCartResponse>> GetListAsync(StockyQuery query)
    {
        var status = Normalize(query.Status);
        if (status is not null && !StockyCartStatus.IsValid(status))
            throw new BusinessRuleException(_localizer[StockyMsg.StatusInvalid]);

        var rows = await _repo.GetListAsync(status, query.HasGoods, query.Keyword);
        return rows.Select(r => StockyCartResponse.From(r, IsAtFa(r))).ToList();
    }

    public async Task<StockyLookupResponse> LookupAsync(string code, string? mode)
    {
        var c = NormalizeCode(code)
                ?? throw new BusinessRuleException(_localizer[StockyMsg.CodeRequired]);

        var m = Normalize(mode) ?? StockyScanMode.In;
        if (!StockyScanMode.IsValid(m))
            throw new BusinessRuleException(_localizer[StockyMsg.ModeInvalid]);

        var cart = await _repo.GetByCodeAsync(c);

        if (m == StockyScanMode.In)
        {
            // Chưa có trong danh mục = xe mới, lần nhận này chính là lúc khai
            // xe. KHÔNG phải lỗi: QR đã mang mã xe nên không cần khai tay trước.
            if (cart is null) return StockyLookupResponse.NewCart(c);

            // Xe đang ở FA thì quét ở tab "Nhập xe" CHÍNH LÀ đưa xe về kho —
            // không phải sai chiều. Phải xét nhánh này TRƯỚC nhánh
            // AlreadyInWarehouse, vì xe ở FA vẫn mang status in_warehouse.
            if (cart.Status == StockyCartStatus.InWarehouse && IsAtFa(cart))
                return StockyLookupResponse.From(cart, atFa: true);

            // Đã ở trong kho rồi thì nhận lại là sai chiều.
            if (cart.Status == StockyCartStatus.InWarehouse)
                throw new ConflictException(_localizer[StockyMsg.AlreadyInWarehouse, c]);

            return StockyLookupResponse.From(cart);
        }

        // Hai chiều còn lại đều đòi xe có thật và đang được quản lý.
        if (cart is null)
            throw new ConflictException(_localizer[StockyMsg.NotFound, c]);

        if (cart.Status != StockyCartStatus.InWarehouse)
            throw new ConflictException(_localizer[StockyMsg.NotInWarehouse, c]);

        var atFa = IsAtFa(cart);

        if (m == StockyScanMode.Fa)
        {
            // ----- mode = fa: đẩy xe sang FA -----
            if (atFa)
                throw new ConflictException(_localizer[StockyMsg.AlreadyAtFa, c]);

            // Chỉ xe RỖNG mới sang FA (luật nghiệp vụ đã chốt). Xe còn pallet
            // mà đẩy đi thì pallet vẫn ghi ô trong kho dù hàng đã rời kho.
            if (cart.HasGoods)
                throw new ConflictException(
                    _localizer[StockyMsg.HasGoodsCannotExportFa, c, cart.PalletCode ?? "?"]);

            return StockyLookupResponse.From(cart, atFa: false);
        }

        // ----- mode = out: TRẢ VỀ VENDOR, xe rời hệ thống -----

        // Vendor nhận xe tại kho. Xe đang ở FA phải đưa về kho trước, nếu không
        // hệ thống ghi "đã trả vendor" trong khi xe vẫn nằm ở FA.
        if (atFa)
            throw new ConflictException(_localizer[StockyMsg.AtFaCannotReturnVendor, c]);

        // Xe còn hàng thì không cho trả: trả xe đi là mất dấu pallet đang nằm
        // trên nó. Phải dỡ hàng khỏi xe trước.
        if (cart.HasGoods)
            throw new ConflictException(
                _localizer[StockyMsg.HasGoodsCannotReturn, c, cart.PalletCode ?? "?"]);

        return StockyLookupResponse.From(cart);
    }

    public async Task<StockySubmitResponse> ReceiveAsync(StockyBatchRequest request)
    {
        var codes = CleanCodes(request);

        // Ô đậu xe tra MỘT LẦN cho cả lô, không tra theo từng xe.
        // NULL = chưa tạo ô đó: vẫn nhận xe, chỉ là chưa có vị trí — chặn ở đây
        // thì một bảng chưa cấu hình xong sẽ làm cả tính năng không dùng được.
        var parkLocatorId = await _repo.FindLocatorIdAsync(_options.ParkLocatorCode);

        // Ô FA tra để NHẬN BIẾT xe đang ở FA mà kéo về bãi đậu. Chưa khai ô FA
        // thì truyền NULL: nhận xe vẫn chạy bình thường, chỉ là không có xe nào
        // ở FA để kéo về.
        var faLocatorId = await _repo.FindLocatorIdAsync(_options.FaLocatorCode);

        var n = await _repo.ReceiveAsync(codes, parkLocatorId, faLocatorId, Actor);
        return new StockySubmitResponse(n, 0);
    }

    public async Task<StockySubmitResponse> ExportToFaAsync(StockyBatchRequest request)
    {
        var codes = CleanCodes(request);

        // Mã ô FA chắc chắn có (StockyOptions.Validated), nhưng DÒNG ô đó có
        // tồn tại trong master.locators hay không là chuyện khác — chặn cứng
        // nếu không có, vì mục đích cả luồng này là BIẾT xe đang ở FA.
        var faLocatorId = await _repo.FindLocatorIdAsync(_options.FaLocatorCode)
            ?? throw new BusinessRuleException(
                _localizer[StockyMsg.FaLocatorMissing, _options.FaLocatorCode]);

        // Kiểm lại ở bước chốt, không chỉ ở bước quét: giữa lúc quét và lúc
        // chốt, hàng có thể vừa được xếp lên xe.
        foreach (var code in codes)
        {
            var cart = await _repo.GetByCodeAsync(code);
            if (cart is null)
                throw new ConflictException(_localizer[StockyMsg.NotFound, code]);
            if (cart.Status != StockyCartStatus.InWarehouse)
                throw new ConflictException(_localizer[StockyMsg.NotInWarehouse, code]);
            if (IsAtFa(cart))
                throw new ConflictException(_localizer[StockyMsg.AlreadyAtFa, code]);
            if (cart.HasGoods)
                throw new ConflictException(
                    _localizer[StockyMsg.HasGoodsCannotExportFa, code, cart.PalletCode ?? "?"]);
        }

        var n = await RunAsync(() => _repo.ExportToFaAsync(codes, faLocatorId, Actor));
        return new StockySubmitResponse(n, 0);
    }

    /// <summary>
    /// Đặt một xe vào một ô trong kho — HÀNG TRÊN XE ĐI THEO (chốt 17/11).
    ///
    /// KHÔNG giới hạn khu: xe Stocky đứng được ở khu lưu trữ, khu nhận hàng,
    /// đâu cũng được (chốt 17/11). Ô trong kho vốn cho nhiều thứ cùng ô —
    /// pallet trùng ô chỉ cảnh báo, không chặn — nên đặt xe vào ô kệ không phá
    /// luật nào đang có.
    ///
    /// ⚠ THỨ TỰ: chuyển hàng TRƯỚC, ghi ô của xe SAU. Lý do: hàng chuyển qua
    /// slice Pallets nên mỗi pallet là một transaction riêng, không gộp được
    /// với câu UPDATE xe. Nếu hàng lỗi giữa đường (ví dụ pallet RW/RB chưa
    /// được quản lý SCS duyệt cho ra khu Nhận hàng) thì ném ra và ô của xe
    /// GIỮ NGUYÊN — sổ nói xe vẫn ở chỗ cũ, đi tìm là thấy. Làm ngược lại thì
    /// sổ ghi xe đã sang ô mới trong khi hàng còn nằm chỗ cũ, và không ai biết
    /// nửa nào đúng.
    /// </summary>
    public async Task<StockyPlaceResponse> PlaceAsync(StockyPlaceRequest request)
    {
        var code = request.Code?.Trim() ?? string.Empty;
        if (code.Length == 0)
            throw new BusinessRuleException(_localizer[StockyMsg.CodeRequired]);

        var locatorCode = request.LocatorCode?.Trim() ?? string.Empty;
        if (locatorCode.Length == 0)
            throw new BusinessRuleException(_localizer[StockyMsg.LocatorRequired]);

        var cart = await _repo.GetByCodeAsync(code)
            ?? throw new ConflictException(_localizer[StockyMsg.NotFound, code]);

        // Xe đã trả vendor thì không còn gì để đặt. Xe đang ở FA thì ĐẶT ĐƯỢC:
        // đó chính là thao tác kéo xe từ FA về một ô trong kho.
        if (cart.Status != StockyCartStatus.InWarehouse)
            throw new ConflictException(_localizer[StockyMsg.NotInWarehouse, code]);

        var locatorId = await _repo.FindLocatorIdAsync(locatorCode)
            ?? throw new BusinessRuleException(
                _localizer[StockyMsg.LocatorNotFound, locatorCode]);

        var lotIds = await _repo.GetLotIdsOnCartAsync(code);
        foreach (var lotId in lotIds)
        {
            // allowedMapType = null: không giới hạn khu, đúng như màn Chuyển /
            // Out vị trí của pallet. Mọi cổng nghiệp vụ khác vẫn chạy.
            await _pallets.AssignLocatorAsync(lotId, locatorCode);
        }

        var changed = await _repo.PlaceAsync(code, locatorId);
        if (changed == 0)
            throw new ConflictException(_localizer[StockyMsg.NotInWarehouse, code]);

        // Đọc lại để trả về đúng khu của ô — client hiện "PL07 · khu Lưu trữ".
        var after = await _repo.GetByCodeAsync(code);
        return new StockyPlaceResponse(code, locatorCode, after?.AreaCode, lotIds.Count);
    }

    public async Task<StockySubmitResponse> ReturnAsync(StockyBatchRequest request)
    {
        var codes = CleanCodes(request);

        // Chặn lại ở bước chốt, không chỉ ở bước quét: giữa lúc quét và lúc
        // chốt, hàng có thể vừa được xếp lên xe.
        foreach (var code in codes)
        {
            var cart = await _repo.GetByCodeAsync(code);
            if (cart is null)
                throw new ConflictException(_localizer[StockyMsg.NotFound, code]);
            if (cart.Status != StockyCartStatus.InWarehouse)
                throw new ConflictException(_localizer[StockyMsg.NotInWarehouse, code]);
            if (IsAtFa(cart))
                throw new ConflictException(_localizer[StockyMsg.AtFaCannotReturnVendor, code]);
            if (cart.HasGoods)
                throw new ConflictException(
                    _localizer[StockyMsg.HasGoodsCannotReturn, code, cart.PalletCode ?? "?"]);
        }

        var faLocatorId = await _repo.FindLocatorIdAsync(_options.FaLocatorCode);

        var n = await RunAsync(() => _repo.ReturnAsync(codes, faLocatorId, Actor));
        return new StockySubmitResponse(n, 0);
    }

    // ===================== dùng chung =====================

    /// <summary>
    /// Đổi <see cref="StockyConcurrencyException"/> của lớp DataAccess thành
    /// 409 kèm câu đã dịch. Repository đã rollback cả lô, nên khi người vận
    /// hành quét lại sẽ thấy trạng thái thật chứ không phải một lô ghi dở.
    /// </summary>
    private async Task<int> RunAsync(Func<Task<int>> write)
    {
        try
        {
            return await write();
        }
        catch (StockyConcurrencyException ex)
        {
            throw new ConflictException(
                _localizer[StockyMsg.ConcurrentChange, ex.Applied, ex.Requested]);
        }
    }

    private static string? Normalize(string? s) =>
        string.IsNullOrWhiteSpace(s) ? null : s.Trim().ToLowerInvariant();

    /// <summary>
    /// Mã xe chuẩn hoá: bỏ khoảng trắng, VIẾT HOA. Phải chuẩn hoá ở một chỗ
    /// duy nhất, vì mã này vừa dùng để so với <c>wms.pallets.stocky_code</c>
    /// vừa là khoá duy nhất của bảng xe.
    /// </summary>
    private static string? NormalizeCode(string? s) =>
        string.IsNullOrWhiteSpace(s) ? null : s.Trim().ToUpperInvariant();

    private List<string> CleanCodes(StockyBatchRequest request)
    {
        var codes = (request.Codes ?? new List<string>())
            .Select(NormalizeCode)
            .Where(x => x is not null)
            .Select(x => x!)
            .Distinct(StringComparer.Ordinal)   // đã viết hoa nên so thẳng
            .ToList();

        if (codes.Count == 0)
            throw new BusinessRuleException(_localizer[StockyMsg.CodeRequired]);
        if (codes.Count > MaxCodesPerBatch)
            throw new BusinessRuleException(_localizer[StockyMsg.TooManyCodes, MaxCodesPerBatch]);

        return codes;
    }
}
