﻿using Dapper;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Data;

namespace Swms.FinishGoods.API.Features.StockEvents.DataAccess
{
    /// <summary>
    /// Đọc lịch sử. Tách khỏi IStockEventWriter vì đọc và ghi có vòng đời khác
    /// nhau: ghi luôn nằm trong transaction của nghiệp vụ, đọc thì không.
    /// </summary>
    public interface IStockEventRepository
    {
        /// <summary>Lịch sử pallet theo khoá số. Null nếu không có pallet.</summary>
        Task<PalletHistory?> GetPalletHistoryAsync(long palletId, StockEventFilter? filter = null);

        /// <summary>
        /// Lịch sử pallet theo mã quét. Khớp CẢ pallet_id LẪN stocky_code —
        /// khác với GetHistoryByLotNoAsync cũ chỉ so pallet_id nên xe stocky
        /// luôn ra lịch sử rỗng.
        /// </summary>
        Task<PalletHistory?> GetPalletHistoryByLotNoAsync(string lotNo, StockEventFilter? filter = null);

        /// <summary>
        /// Timeline RÚT GỌN cho ?include=history khi quét trên PDA — 4 cột,
        /// mặc định 10 dòng gần nhất. Không trả toàn bộ lịch sử của pallet đã
        /// nằm kho nhiều tháng.
        /// </summary>
        Task<IReadOnlyList<PalletEventBrief>> GetPalletEventsBriefAsync(string lotNo, int take = 10);

        /// <summary>Lịch sử box theo khoá số.</summary>
        Task<BoxHistory?> GetBoxHistoryAsync(long boxId, bool ownOnly = false);

        /// <summary>
        /// Lịch sử box theo box_no. box_no chỉ unique trong phạm vi 1 pallet nên
        /// palletCode là cần thiết trên thực tế.
        /// </summary>
        Task<BoxHistory?> GetBoxHistoryByBoxNoAsync(string boxNo, string? palletCode, bool ownOnly = false);

        /// <summary>
        /// Catalog loại event. Client cache; ở đây không cache để đổi seed là
        /// thấy ngay — truy vấn chỉ 29 dòng từ một bảng master.
        /// </summary>
        Task<IReadOnlyList<StockEventType>> GetEventTypesAsync(string? subjectType = null);
    }

    public class StockEventRepository : IStockEventRepository
    {
        private const string PalletProc = "wms.usp_pallet_history_get";
        private const string PalletBriefProc = "wms.usp_pallet_events_brief";
        private const string BoxProc = "wms.usp_box_history_get";
        private const string TypesProc = "master.usp_stock_event_types_get";

        private readonly IDbConnectionFactory _factory;
        public StockEventRepository(IDbConnectionFactory factory) => _factory = factory;

        // ── Pallet ────────────────────────────────────────────────────

        public Task<PalletHistory?> GetPalletHistoryAsync(long palletId, StockEventFilter? filter = null)
            => ReadPalletAsync(BuildPalletParams(palletId, null, filter));

        public Task<PalletHistory?> GetPalletHistoryByLotNoAsync(string lotNo, StockEventFilter? filter = null)
        {
            lotNo = (lotNo ?? "").Trim();
            return lotNo.Length == 0
                ? Task.FromResult<PalletHistory?>(null)
                : ReadPalletAsync(BuildPalletParams(null, lotNo, filter));
        }

        public async Task<IReadOnlyList<PalletEventBrief>> GetPalletEventsBriefAsync(
            string lotNo, int take = 10)
        {
            lotNo = (lotNo ?? "").Trim();
            if (lotNo.Length == 0) return [];

            using var conn = _factory.Create();

            var p = new DynamicParameters();
            p.Add("@lot_no", lotNo);
            p.Add("@take", Math.Clamp(take, 1, 100));

            var rows = await conn.QueryAsync<PalletEventBrief>(
                PalletBriefProc, p, commandType: CommandType.StoredProcedure);

            return rows.ToList();
        }

        private static DynamicParameters BuildPalletParams(
            long? palletId, string? lotNo, StockEventFilter? filter)
        {
            var p = new DynamicParameters();
            p.Add("@pallet_id", palletId);
            p.Add("@lot_no", lotNo);
            p.Add("@from_date", filter?.From);
            p.Add("@to_date", filter?.To);
            p.Add("@event_codes", NullIfBlank(filter?.Codes));
            p.Add("@groups", NullIfBlank(filter?.Groups));
            return p;
        }

        private async Task<PalletHistory?> ReadPalletAsync(DynamicParameters p)
        {
            using var conn = _factory.Create();
            using var multi = await conn.QueryMultipleAsync(
                PalletProc, p, commandType: CommandType.StoredProcedure);

            // Proc RETURN sớm khi không tìm thấy -> không có result set nào.
            if (multi.IsConsumed) return null;

            var header = await multi.ReadFirstOrDefaultAsync<PalletHistoryHeader>();
            if (header is null) return null;

            var events = (await multi.ReadAsync<PalletEventRow>()).ToList();
            return new PalletHistory { Header = header, Events = events };
        }

        // ── Box ───────────────────────────────────────────────────────

        public Task<BoxHistory?> GetBoxHistoryAsync(long boxId, bool ownOnly = false)
        {
            var p = new DynamicParameters();
            p.Add("@box_id", boxId);
            p.Add("@box_no", null);
            p.Add("@pallet_code", null);
            p.Add("@own_only", ownOnly ? 1 : 0);
            return ReadBoxAsync(p);
        }

        public Task<BoxHistory?> GetBoxHistoryByBoxNoAsync(
            string boxNo, string? palletCode, bool ownOnly = false)
        {
            boxNo = (boxNo ?? "").Trim();
            if (boxNo.Length == 0) return Task.FromResult<BoxHistory?>(null);

            var p = new DynamicParameters();
            p.Add("@box_id", null);
            p.Add("@box_no", boxNo);
            p.Add("@pallet_code", NullIfBlank(palletCode));
            p.Add("@own_only", ownOnly ? 1 : 0);
            return ReadBoxAsync(p);
        }

        private async Task<BoxHistory?> ReadBoxAsync(DynamicParameters p)
        {
            using var conn = _factory.Create();
            using var multi = await conn.QueryMultipleAsync(
                BoxProc, p, commandType: CommandType.StoredProcedure);

            if (multi.IsConsumed) return null;

            var header = await multi.ReadFirstOrDefaultAsync<BoxHistoryHeader>();
            if (header is null) return null;

            var events = (await multi.ReadAsync<BoxEventRow>()).ToList();
            return new BoxHistory { Header = header, Events = events };
        }

        // ── Catalog ───────────────────────────────────────────────────

        public async Task<IReadOnlyList<StockEventType>> GetEventTypesAsync(string? subjectType = null)
        {
            using var conn = _factory.Create();

            var p = new DynamicParameters();
            p.Add("@subject_type", NullIfBlank(subjectType));

            var rows = await conn.QueryAsync<StockEventType>(
                TypesProc, p, commandType: CommandType.StoredProcedure);

            return rows.ToList();
        }

        private static string? NullIfBlank(string? value)
        {
            var v = (value ?? "").Trim();
            return v.Length == 0 ? null : v;
        }
    }
}