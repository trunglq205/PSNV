using Swms.FinishGoods.API.Features.WarehouseAreas.Business;
using Swms.FinishGoods.API.Features.WarehouseAreas.DataAccess;

namespace Swms.FinishGoods.API.Features.WarehouseAreas;

public static class WarehouseAreasModule
{
    public static IServiceCollection AddWarehouseAreasFeature(this IServiceCollection services)
    {
        services.AddScoped<IWarehouseAreasService, WarehouseAreasService>();
        services.AddScoped<IWarehouseAreasRepository, WarehouseAreasRepository>();
        return services;
    }
}
