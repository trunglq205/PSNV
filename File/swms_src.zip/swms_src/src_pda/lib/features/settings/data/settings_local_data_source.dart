import 'package:swms_finish_goods/core/utils/app_local_storage.dart';
import 'package:swms_finish_goods/core/utils/constants.dart';
import 'package:swms_finish_goods/features/settings/domain/app_language.dart';
import 'package:swms_finish_goods/features/settings/domain/settings_entity.dart';

abstract interface class SettingsLocalDataSource {
  Future<SettingsEntity> read();
  Future<void> write(SettingsEntity settings);
}

class SettingsLocalDataSourceImpl implements SettingsLocalDataSource {
  final AppLocalStorage _storage;

  const SettingsLocalDataSourceImpl(this._storage);

  @override
  Future<SettingsEntity> read() async {
    return SettingsEntity(
      language: AppLanguage.fromCode(_storage.readString(SettingsKeys.language)),
      soundAlert: _storage.readBool(SettingsKeys.soundAlert) ?? true,
      pushNotify: _storage.readBool(SettingsKeys.pushNotify) ?? true,
    );
  }

  @override
  Future<void> write(SettingsEntity s) async {
    await _storage.writeString(SettingsKeys.language, s.language.code);
    await _storage.writeBool(SettingsKeys.soundAlert, s.soundAlert);
    await _storage.writeBool(SettingsKeys.pushNotify, s.pushNotify);
  }
}