﻿using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Categories.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.Api.Features.Categories.Api;

[ApiController]
[Route("api/categories")]
public class CategoriesController : ControllerBase
{
    private readonly ICategoryService _service;
    public CategoriesController(ICategoryService service) => _service = service;

    // Danh sách toàn bộ (có filter tùy chọn), không phân trang.
    [HttpGet]
    [RequirePermission<Perms.System.Models.View>]
    public async Task<ActionResult<List<CategoryResponse>>> GetAll([FromQuery] CategoryQuery query)
        => Ok(await _service.GetAllAsync(query));

    // Option gọn cho dropdown FE (code + name).
    [HttpGet("options")]
    [RequirePermission<Perms.System.Models.View>]
    public async Task<ActionResult<List<CategoryOptionResponse>>> GetOptions()
        => Ok(await _service.GetOptionsAsync());

    [HttpGet("{code}")]
    [RequirePermission<Perms.System.Models.View>]
    public async Task<ActionResult<CategoryResponse>> GetByCode(int code)
        => Ok(await _service.GetByCodeAsync(code));

    [HttpPost]
    [RequirePermission<Perms.System.Models.Create>]
    public async Task<ActionResult<CategoryResponse>> Create(CreateCategoryRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(GetByCode), new { code = created.Code }, created);
    }

    [HttpPut("{code}")]
    [RequirePermission<Perms.System.Models.Update>]
    public async Task<IActionResult> Update(int code, UpdateCategoryRequest request)
    {
        await _service.UpdateAsync(code, request);
        return NoContent();
    }

    [HttpDelete("{code}")]
    [RequirePermission<Perms.System.Models.Delete>]
    public async Task<IActionResult> Delete(int code)
    {
        await _service.DeleteAsync(code);
        return NoContent();
    }
}