﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("StockOtherFactory")]
    public class StockOtherFactory
    {
        public int ID { get; set; }
        public string? Plant { get; set; }
        public string? Material { get; set; }
        [Column(TypeName = "decimal(18,3)")]
        public decimal Stock { get; set; }
    }
}
