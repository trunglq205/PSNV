import 'package:swms_finish_goods/features/return_instruction/data/datasources/return_instruction_remote_data_source.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_receive_model.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_receive_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/repositories/return_instruction_repository.dart';

class ReturnInstructionRepositoryImpl implements ReturnInstructionRepository {
  final ReturnInstructionRemoteDataSource _remote;
  const ReturnInstructionRepositoryImpl(this._remote);

  @override
  Future<List<ReturnInstruction>> fetchList({ReturnDocStatus? status}) async {
    // KHÔNG bắt DioException để bọc lại: ErrorInterceptor đã lấy câu thông báo
    // của server và ErrorHandler hiện nguyên câu đó — bọc lại chỉ còn câu
    // chung chung, mất thông tin.
    final rows = await _remote.list(status: status?.code);
    return rows.map((e) => e.toEntity()).toList();
  }

  @override
  Future<ReturnInstruction> fetchById(int id) async =>
      (await _remote.getById(id)).toEntity();

  @override
  Future<ReturnReceiveResult> receive({
    required int docId,
    required List<ReturnBoxDraft> boxes,
  }) async {
    final res = await _remote.receive(
      docId,
      ReceiveReturnRequestModel.fromDrafts(boxes),
    );
    return res.toEntity();
  }

  @override
  Future<ReturnInstruction> close(int docId) async =>
      (await _remote.close(docId)).toEntity();
}
