﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace SWMS_WebTool.Models
{ 
    public enum BarcodeType
    {
        [EnumMember(Value = "0")]
        [Description("Status_Local")]
        Local,
        [EnumMember(Value = "1")]
        [Description("Status_Oversea")]
        Oversea,
        [EnumMember(Value = "2")]
        [Description("Status_Standard")]
        Standard,
        [EnumMember(Value = "3")]
        [Description("Status_PMD")]
        PMD,
        [EnumMember(Value = "4")]
        [Description("Status_Simple")]
        Simple
    }
}
