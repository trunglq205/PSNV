﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class CheckStorageFilter : BaseFilter
    {
        
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Sloc { get; set; }        
        public string Material { get; set; }

    }
}
