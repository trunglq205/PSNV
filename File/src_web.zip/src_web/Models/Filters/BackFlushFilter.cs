﻿using Refit;

namespace SWMS_WebTool.Models.Filters
{
    public class BackFlushFilter : BaseFilter
    {
        public BackFlushFilter() { }

        public string? PlanOderNumber { get; set; }
        public string? Material { get; set; }
        public string? Plant { get; set;}
        public string? Sloc { get; set;}
        public string? ProductionVersion { get; set; }
        public DeliveryPlanStatus? Status { get; set; }
        [Query(Format = "yyyy-MM-dd")]
        public DateTime? Date { get; set; } = DateTime.Now;
    }
}
