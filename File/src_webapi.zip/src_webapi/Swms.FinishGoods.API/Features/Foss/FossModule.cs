using Swms.FinishGoods.API.Features.Foss.Business;
using Swms.FinishGoods.API.Features.Foss.DataAccess;
using Swms.FinishGoods.API.Features.Foss.PalletSync.Business;
using Swms.FinishGoods.API.Features.Foss.PalletSync.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Foss;

public static class FossModule
{
    public static IServiceCollection AddFossFeature(this IServiceCollection services)
    {
        // ── Đọc Foss (read-only) ──
        // Connection factory tới Foss DB — Singleton vì chỉ giữ connection string.
        services.AddSingleton<IFossDbConnectionFactory, FossDbConnectionFactory>();
        services.AddScoped<IFossPalletRepository, FossPalletRepository>();
        services.AddScoped<IFossService, FossService>();

        // ── Foss -> pallet SWMS ──
        services.AddScoped<IPalletFossRepository, PalletFossRepository>();
        services.AddScoped<IPalletFossSyncService, PalletFossSyncService>();
        return services;
    }
}
