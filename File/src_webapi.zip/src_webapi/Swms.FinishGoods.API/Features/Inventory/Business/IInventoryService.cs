using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Inventory.Api;

namespace Swms.FinishGoods.API.Features.Inventory.Business
{
    public interface IInventoryService
    {
        Task<PagedResult<InventoryItemResponse>> GetPagedAsync(InventoryQuery query);
        Task<IReadOnlyList<InventoryAreaStatResponse>> GetAreaStatsAsync(InventoryQuery query);
        Task<IReadOnlyList<InventoryAgingBucketResponse>> GetAgingAsync(InventoryQuery query);
    }
}
