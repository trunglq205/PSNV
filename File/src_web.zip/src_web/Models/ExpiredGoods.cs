﻿namespace SWMS_WebTool.Models
{
    public class ExpiredGoods
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Sloc { get; set; }
        public string Barcode { get; set; }
        public int? TimeCheck { get; set; }
        public DateTime? DateCheck { get; set; }
        public DateTime ComingDate { get; set; }
        public string Material { get; set; }
        public string Location { get; set; }
        public int? Stock { get; set; }
        public double Quantity { get; set; }
    }
}
