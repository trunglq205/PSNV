﻿namespace SWMS_WebTool.Models.Requests
{
    public class UpdateTrackingNoByVendorCodeRequest
    {
        public List<int> Id { get; set; }
        public int Type { get; set; }
        public string TrackingNumber { get; set; }
    }
}
