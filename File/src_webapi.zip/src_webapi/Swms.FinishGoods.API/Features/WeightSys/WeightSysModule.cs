using Swms.FinishGoods.API.Features.WeightSys.Business;
using Swms.FinishGoods.API.Features.WeightSys.DataAccess;
using Swms.FinishGoods.API.Features.WeightSys.PalletSync.Business;
using Swms.FinishGoods.API.Features.WeightSys.PalletSync.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Foss;

public static class WeightSysModule
{
    public static IServiceCollection AddWeightSysFeature(this IServiceCollection services)
    {
        // ── Đọc Foss (read-only) ──
        // Connection factory tới Foss DB — Singleton vì chỉ giữ connection string.
        services.AddSingleton<IWeightSysConnectionFactory, WeightSysDbConnectionFactory>();
        services.AddScoped<IWeightSysRepository, WeightSysRepository>();
        services.AddScoped<IWeightSysService, WeightSysService>();

        // ── Foss -> pallet SWMS ──
        services.AddScoped<IPalletWeightRepository, PalletWeightRepository>();
        services.AddScoped<IPalletWeightSyncService, PalletWeightSyncService>();
        return services;
    }
}
