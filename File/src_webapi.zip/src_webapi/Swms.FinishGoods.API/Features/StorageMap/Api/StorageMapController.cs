using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.StorageMap.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.StorageMap.Api;

[ApiController]
[Route("api/storage")]
public class StorageMapController : ControllerBase
{
    private readonly IStorageMapService _service;

    public StorageMapController(IStorageMapService service) => _service = service;

    /// <summary>Danh sách kệ khu Storing + đếm slot/chiếm chỗ (cho top-down/điều hướng).</summary>
    [HttpGet("racks")]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<IReadOnlyList<RackSummaryResponse>>> GetRacks(
        [FromQuery] string? areaCode = null)
        => Ok(await _service.GetRacksAsync(areaCode));

    /// <summary>Mặt đứng 1 kệ: lưới Location × Floor + tình trạng chiếm chỗ.</summary>
    [HttpGet("racks/{rackCode}/elevation")]
    [RequirePermission<Perms.Storage.Map.Detail>]
    public async Task<ActionResult<RackElevationResponse>> GetElevation(
        string rackCode, [FromQuery] string? areaCode = null)
        => Ok(await _service.GetElevationAsync(rackCode, areaCode));

    /// <summary>Sơ đồ top-down khu Storing (khối kệ/decor + tỉ lệ chiếm chỗ).</summary>
    [HttpGet("top-map")]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<TopMapResponse>> GetTopMap(
        [FromQuery] string? areaCode = null)
        => Ok(await _service.GetTopMapAsync(areaCode));

    /// <summary>Tra một mã vị trí nằm ở bản đồ nào, kệ nào — PDA dùng để focus trên sơ đồ.</summary>
    [HttpGet("locate/{locatorCode}")]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<LocatorLocationResponse>> Locate(string locatorCode)
        => Ok(await _service.LocateAsync(locatorCode));

    /// <summary>Serial của từng thùng trong 1 pallet — xem chi tiết ô trên mặt cắt kệ.</summary>
    [HttpGet("pallets/{palletCode}/serials")]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<IReadOnlyList<PalletSerialResponse>>> Serials(string palletCode)
        => Ok(await _service.GetSerialsAsync(palletCode));

    /// <summary>Lưu vị trí/kích thước khối top-down (editor admin).</summary>
    [HttpPost("top-map")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> SaveTopMap([FromBody] SaveTopMapRequest request)
    {
        await _service.SaveTopMapAsync(request, User?.Identity?.Name);
        return NoContent();
    }

    /// <summary>Tạo kệ mới (editor).</summary>
    [HttpPost("racks")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> CreateRack([FromBody] CreateRackRequest request)
    {
        await _service.CreateRackAsync(request, User?.Identity?.Name);
        return NoContent();
    }

    /// <summary>Xoá kệ (editor).</summary>
    [HttpDelete("racks/{rackCode}")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> DeleteRack(string rackCode)
    {
        await _service.DeleteRackAsync(rackCode, User?.Identity?.Name);
        return NoContent();
    }

    /// <summary>Đổi 1 ô pallet ⇄ giá lửng (editor).</summary>
    [HttpPost("cells/set-kind")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> SetCellKind([FromBody] SetCellKindRequest request)
    {
        await _service.SetCellKindAsync(request, User?.Identity?.Name);
        return NoContent();
    }
}
