import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image_picker/image_picker.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';
import 'package:swms_finish_goods/features/container_check/presentation/dialog/fail_reason_sheet.dart';
import 'package:swms_finish_goods/features/container_check/presentation/providers/container_check_notifier.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/container_inspect_view.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/container_list_view.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Container Check — kiểm container & seal trước khi đóng hàng.
//  Một màn, hai chế độ:
//  - Danh sách: quét QR trên cửa container hoặc chạm thẻ để mở.
//  - Kiểm: tick 4 hạng mục + chụp 4 góc → "Xác nhận đạt"; hoặc "Không đạt"
//    kèm lý do → container trả về đi rửa. Lưu xong tự về danh sách và tải lại.
//  Nút X / back khi đang kiểm = về danh sách (hỏi trước nếu đã tick / chụp),
//  KHÔNG thoát màn.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class ContainerCheckPage extends ConsumerStatefulWidget {
  const ContainerCheckPage({super.key});

  @override
  ConsumerState<ContainerCheckPage> createState() => _ContainerCheckPageState();
}

class _ContainerCheckPageState extends ConsumerState<ContainerCheckPage> {
  StreamSubscription<String>? _sub;
  final _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    _listen();
    WidgetsBinding.instance.addPostFrameCallback(
      (_) => ref.read(containerCheckProvider.notifier).initData(),
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Await xong mới gán: nếu page đã dispose trong lúc chờ thì subscription
    // sẽ không bao giờ được cancel → rò listener.
    if (!mounted) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      ref.read(containerCheckProvider.notifier).onScan(data);
    });
  }

  /// Ngưng nghe khi sheet / camera đè lên màn — quét lúc đó không được lọt
  /// xuống thành "mở container".
  Future<T> _paused<T>(Future<T> Function() action) async {
    await _sub?.cancel();
    _sub = null;
    try {
      return await action();
    } finally {
      if (mounted) await _listen();
    }
  }

  // ── Chế độ kiểm ────────────────────────────────────────────
  /// Về danh sách. Đã tick / chụp mà chưa chốt → hỏi trước, ảnh chụp ngoài
  /// bãi mất là phải ra chụp lại.
  Future<void> _closeInspection() async {
    final state = ref.read(containerCheckProvider);
    if (state.submitting) return;
    if (state.dirty) {
      final ok = await showConfirmDialog(
        context,
        title: LocaleKeys.container_check_leave_title.tr(),
        message: LocaleKeys.container_check_leave_message.tr(),
        confirmVariant: AppButtonVariant.danger,
      );
      if (!ok || !mounted) return;
    }
    ref.read(containerCheckProvider.notifier).close();
  }

  Future<void> _capture(ContainerPhotoSlot slot) async {
    final file = await _paused(
      () => _picker.pickImage(
        source: ImageSource.camera,
        imageQuality: 70,
        maxWidth: 1600,
      ),
    );
    if (file == null || !mounted) return;
    ref.read(containerCheckProvider.notifier).setPhoto(slot, file.path);
  }

  Future<void> _pass() async {
    final code = ref.read(containerCheckProvider).current?.containerNo ?? '';
    final ok = await showConfirmDialog(
      context,
      title: LocaleKeys.container_check_pass_confirm_title.tr(),
      message: LocaleKeys.container_check_pass_confirm_message.tr(
        namedArgs: {'code': code},
      ),
      confirmVariant: AppButtonVariant.success,
    );
    if (!ok || !mounted) return;

    final saved = await ref.read(containerCheckProvider.notifier).submitPass();
    if (!saved || !mounted) return;
    AppToastHelper.toastSuccess(
      context,
      LocaleKeys.container_check_pass_done.tr(),
    );
  }

  Future<void> _fail() async {
    final checked = ref.read(containerCheckProvider).checked;
    final note = await _paused(
      () => showFailReasonSheet(
        context,
        unchecked: ContainerCondition.values.toSet().difference(checked),
      ),
    );
    if (note == null || !mounted) return;

    final saved = await ref
        .read(containerCheckProvider.notifier)
        .submitFail(note);
    if (!saved || !mounted) return;
    AppToastHelper.toastWarning(
      context,
      LocaleKeys.container_check_fail_done.tr(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(containerCheckProvider);
    final notifier = ref.read(containerCheckProvider.notifier);
    final item = state.current;

    return PopScope(
      // Đang kiểm thì back cứng của PDA = về danh sách, không thoát màn.
      canPop: !state.inspecting,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) _closeInspection();
      },
      child: Scaffold(
        appBar: item == null
            ? AppTopBar(
                title: LocaleKeys.container_check_title.tr(),
                subtitle: LocaleKeys.container_check_subtitle.tr(),
              )
            : AppTopBar(
                title: item.containerNo,
                subtitle: LocaleKeys.container_check_inspect_subtitle.tr(
                  namedArgs: {'type': item.type, 'si': item.siCode},
                ),
                onBack: _closeInspection,
                actions: [
                  IconButton(
                    icon: const Icon(Icons.close_rounded),
                    onPressed: state.submitting ? null : _closeInspection,
                  ),
                ],
              ),
        body: item == null
            ? ContainerListView(
                state: state,
                onRefresh: notifier.refresh,
                onOpen: notifier.open,
              )
            : ContainerInspectView(
                state: state,
                item: item,
                onRetry: notifier.reloadDetail,
                onToggle: notifier.toggle,
                onCapture: _capture,
                onRemovePhoto: notifier.removePhoto,
              ),
        // Chỉ container "chờ kiểm" (đã tải xong chi tiết) mới có nút chốt.
        bottomNavigationBar: state.detailValue?.status == ContainerStatus.verify
            ? AppBottomHint(
                child: ContainerInspectActions(
                  state: state,
                  onFail: _fail,
                  onPass: _pass,
                ),
              )
            : null,
      ),
    );
  }
}
