using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.Pallets.Business
{
    /// <summary>
    /// Chuẩn hoá mã pallet quét từ tem. Dùng chung cho nghiệp vụ SWMS và các luồng
    /// đồng bộ Foss / HD soft để cả ba trả cùng một lỗi khi mã rỗng.
    /// </summary>
    public static class PalletLotNo
    {
        public static string Normalize(string? lotNo, IStringLocalizer<SharedResource> localizer)
        {
            lotNo = (lotNo ?? "").Trim();
            if (lotNo.Length == 0)
                throw new BusinessRuleException(localizer["Lot.LotNoRequired"]);
            return lotNo;
        }
    }
}
