import 'dart:convert';

class JwtClaims {
  static const name =
      'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/name';

  static const nameIdentifier =
      'http://schemas.xmlsoap.org/ws/2005/05/identity/claims/nameidentifier';

  static const employeeCode = 'employee_code';
}

extension JwtExtension on String {
  Map<String, Object?> get claims {
    final parts = split('.');

    if (parts.length != 3) {
      throw const FormatException('Invalid JWT');
    }

    final normalized = base64Url.normalize(parts[1]);
    final payload = utf8.decode(base64Url.decode(normalized));

    return Map<String, Object?>.from(
      json.decode(payload) as Map,
    );
  }

  bool get isExpired {
    final exp = claims['exp'];

    if (exp == null) {
      return false;
    }

    final expiry = DateTime.fromMillisecondsSinceEpoch(
      (exp as num).toInt() * 1000,
    );

    return DateTime.now().isAfter(expiry);
  }
}