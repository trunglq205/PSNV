using System.Data;

namespace Swms.FinishGoods.API.Features.Pallets.Business
{
    /// <summary>
    /// Phiếu chỉ thị back hàng đang gắn với pallet sắp chuyển vị trí, kèm số
    /// serial còn đang ở trạng thái "đã nhận, chưa giao" trên chính pallet đó.
    /// </summary>
    /// <param name="DocId">wms.return_instructions.id.</param>
    /// <param name="DocNo">Số phiếu — chỉ để dựng thông báo cho người quét.</param>
    /// <param name="ReceivedQty">
    /// Số serial của phiếu đang ở status = 'received' trên pallet này. Lớn hơn 0
    /// nghĩa là chuyển pallet sang khu Nhận hàng sẽ được tính là giao cho FA.
    /// </param>
    public sealed record ReturnBackMove(long DocId, string DocNo, int ReceivedQty);

    /// <summary>
    /// Cổng kiểm soát việc đưa pallet hàng tái gia công ra khỏi kho.
    ///
    /// KHAI Ở SLICE PALLETS, HIỆN THỰC Ở SLICE RETURNINSTRUCTIONS. Chiều phụ
    /// thuộc giữa hai slice đang là ReturnInstructions → Pallets; nếu PalletService
    /// gọi thẳng service của ReturnInstructions thì thành vòng. Pallets chỉ biết
    /// "có một cổng chặn trước khi đặt pallet vào khu Nhận hàng", không biết
    /// phiếu back hàng tồn tại.
    ///
    /// Vì sao phải nằm trong luồng chuyển vị trí, chứ không là một API giao hàng
    /// riêng: nghiệp vụ đã chốt rằng ĐẶT PALLET VÀO VỊ TRÍ NHẬN HÀNG CHÍNH LÀ
    /// hành động giao cho FA. Còn một API giao hàng song song nữa thì sẽ có
    /// đường giao hàng không đi qua vị trí kho, tức là lọt cổng duyệt này.
    /// </summary>
    public interface IReturnBackMoveGate
    {
        /// <summary>
        /// Gọi TRƯỚC khi OUT KHO: chuyển pallet từ một vị trí thuộc bản đồ lưu
        /// trữ sang một vị trí thuộc bản đồ Nhận hàng.
        ///
        /// KHÔNG gọi cho mọi lượt chuyển vào khu nhận hàng — gán pallet mới vào
        /// khu nhận hàng (mục 2a) và xếp lại trong khu nhận hàng đều không phải
        /// giao hàng, pallet chưa rời kho. Xem PalletService.MoveToLocatorAsync.
        ///
        /// Trả null khi pallet không mang hàng chờ giao của phiếu nào — khi đó
        /// out kho là việc bình thường của hàng thường, không liên quan.
        ///
        /// Ném <see cref="Swms.FinishGoods.API.Common.Business.Exceptions.BusinessRuleException"/> khi
        /// pallet có hàng chờ giao mà phiếu CHƯA được quản lý SCS duyệt: lúc đó
        /// hàng chỉ được chuyển nội bộ trong kho.
        /// </summary>
        Task<ReturnBackMove?> CheckDeliverableAsync(long palletId);

        /// <summary>
        /// Ghi sổ giao hàng, chạy TRONG transaction đổi vị trí (hook onMoved của
        /// <see cref="DataAccess.ILotRepository.ChangeLocatorAsync"/>): serial
        /// sang at_fa, thêm dòng nhật ký giao hàng, và đóng phiếu nếu phiếu
        /// không còn serial nào chờ giao.
        ///
        /// Khoá lại phiếu và kiểm trạng thái lần nữa ở đây, vì giữa
        /// <see cref="CheckDeliverableAsync"/> và transaction này quản lý SCS có
        /// thể đã huỷ duyệt.
        /// </summary>
        Task MarkDeliveredAsync(
            IDbConnection conn,
            IDbTransaction tx,
            ReturnBackMove move,
            long palletId,
            string lotNo,
            string? user);
    }
}
