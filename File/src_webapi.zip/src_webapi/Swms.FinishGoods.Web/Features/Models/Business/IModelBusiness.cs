using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.Models.Business;

public interface IModelBusiness
    : ICrudBusiness<ModelQuery, ModelDto, ModelDto, CreateModelRequest, UpdateModelRequest, int>
{
    Task<Result<List<CategoryDto>>> GetCategoriesAsync(CategoryQuery? query = null);

    // Category CRUD — code (int) la khoa, khong cho doi khi sua.
    Task<Result<CategoryDto>> CreateCategoryAsync(CreateCategoryRequest request);
    Task<Result> UpdateCategoryAsync(int code, UpdateCategoryRequest request);
    Task<Result> DeleteCategoryAsync(int code);

    Task<Result<List<WarehouseAreaDto>>> GetWarehouseAreasAsync();
    Task<Result<List<ModelDto>>> BulkCreateAsync(IReadOnlyList<CreateModelRequest> request);
    Task<Result<BulkUpsertResult>> BulkUpsertAsync(IReadOnlyList<UpsertModelRequest> items);
}
