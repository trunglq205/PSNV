using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Business;

public interface ISiHdSoftCompareService
{
    /// <summary>So 1 SI theo SI_No (có ở 1 bên cũng được). Không có ở cả 2 -> NotFound.</summary>
    Task<SiCompareDetailResponse> CompareAsync(string siNo);

    /// <summary>Mọi SI tạo trong khoảng ngày ở SWMS hoặc HD soft — tìm SI thiếu bên nào, lệch ở đâu.</summary>
    Task<SiCompareListResponse> CompareRangeAsync(SiCompareQuery query);
}
