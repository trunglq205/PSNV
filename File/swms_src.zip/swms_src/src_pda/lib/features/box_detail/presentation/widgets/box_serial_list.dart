import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';

/// Danh sách serial trong box.
class BoxSerialList extends StatelessWidget {
  final List<BoxSerial> serials;
  final int collapsedCount;
  final VoidCallback? onFindMissing;

  const BoxSerialList({
    super.key,
    required this.serials,
    this.collapsedCount = 5,
    this.onFindMissing,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppExpandableList<BoxSerial>(
      items: serials,
      grouped: true,
      collapsedCount: collapsedCount,
      title: 'box_detail.serial_list'.tr(args: ['${serials.length}']),
      showMoreLabel: (hidden) =>
          LocaleKeys.box_detail_show_more.tr(args: ['$hidden']),
      headerAction: onFindMissing == null
          ? null
          : AppButton(
        label: LocaleKeys.box_detail_find_missing_serial.tr(),
        icon: Icons.search,
        variant: AppButtonVariant.subtle,
        size: AppButtonSize.sm,
        isFullWidth: false,
        onPressed: onFindMissing,
      ),
      itemBuilder: (context, serial, index) => AppExpandableRow(
        icon: Icons.qr_code_2,
        iconColor: swms.warning,
        iconBackground: swms.warningBg,
        leadingText: (index + 1).toString().padLeft(2, '0'),
        title: serial.serialNo,
      ),
    );
  }
}