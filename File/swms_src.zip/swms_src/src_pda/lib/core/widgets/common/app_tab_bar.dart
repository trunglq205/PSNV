import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';

/// Một tab trong [AppTabBar].
class AppTabItem<T> {
  final T value;
  final String label;

  /// Badge số đếm. null = không hiện badge.
  final int? count;

  const AppTabItem({required this.value, required this.label, this.count});
}

/// Thanh tab dạng segmented.
///
/// - Mặc định: tab co theo nhãn, cuộn ngang khi không đủ chỗ — hợp với list
///   filter trạng thái nhiều tab.
/// - [expanded] = true: các tab chia đều chiều ngang, không cuộn — hợp với
///   2–3 chế độ cố định của một màn. Nhãn dài bị cắt `…` thay vì tràn.
///
/// Generic theo [T] — dùng được với enum trạng thái, kể cả kiểu nullable
/// (vd `AppTabBar<SiStatus?>` với `null` = "Tất cả").
class AppTabBar<T> extends StatelessWidget {
  final List<AppTabItem<T>> items;
  final T selected;
  final ValueChanged<T> onChanged;
  final bool expanded;

  const AppTabBar({
    super.key,
    required this.items,
    required this.selected,
    required this.onChanged,
    this.expanded = false,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: swms.card2,
        border: Border.all(color: swms.border),
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
      ),
      child: expanded
          ? Row(children: _tabs(fill: true))
          : SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: Row(children: _tabs(fill: false)),
      ),
    );
  }

  List<Widget> _tabs({required bool fill}) => [
    for (var i = 0; i < items.length; i++)
      _wrap(
        fill: fill,
        child: Padding(
          padding: EdgeInsets.only(
            right: i == items.length - 1 ? 0 : AppDimens.xs,
          ),
          child: _Tab(
            label: items[i].label,
            count: items[i].count,
            selected: items[i].value == selected,
            fill: fill,
            onTap: () => onChanged(items[i].value),
          ),
        ),
      ),
  ];

  /// Trong ScrollView ngang chiều rộng là vô hạn → không được bọc Expanded.
  Widget _wrap({required bool fill, required Widget child}) =>
      fill ? Expanded(child: child) : child;
}

class _Tab extends StatelessWidget {
  final String label;
  final int? count;
  final bool selected;

  /// true = chiếm hết phần được chia, nội dung canh giữa.
  final bool fill;
  final VoidCallback onTap;

  const _Tab({
    required this.label,
    required this.count,
    required this.selected,
    required this.fill,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final radius = BorderRadius.circular(AppDimens.rInput - 2);

    final text = Text(
      label,
      maxLines: 1,
      overflow: fill ? TextOverflow.ellipsis : TextOverflow.visible,
      style: AppTextStyles.label.copyWith(
        color: selected ? swms.primary : swms.text3,
        fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
      ),
    );

    return DecoratedBox(
      decoration: BoxDecoration(
        color: selected ? swms.card : Colors.transparent,
        borderRadius: radius,
        boxShadow: selected ? AppShadows.s1 : null,
      ),
      child: Material(
        type: MaterialType.transparency,
        child: InkWell(
          onTap: onTap,
          borderRadius: radius,
          child: ConstrainedBox(
            // Vùng chạm đủ cho tay đeo găng.
            constraints: const BoxConstraints(minHeight: AppDimens.hitSm),
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 12),
              child: Row(
                mainAxisSize: fill ? MainAxisSize.max : MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  // Flexible để nhãn dài co lại (ellipsis) thay vì đẩy tràn badge.
                  fill ? Flexible(child: text) : text,
                  if (count != null) ...[
                    const SizedBox(width: 5),
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 5,
                        vertical: 1,
                      ),
                      decoration: BoxDecoration(
                        color: selected ? swms.primaryTint : swms.border,
                        borderRadius: BorderRadius.circular(AppDimens.sm),
                      ),
                      child: Text(
                        '$count',
                        style: AppTextStyles.caption.copyWith(
                          fontWeight: FontWeight.w800,
                          color: selected ? swms.primaryDark : swms.text3,
                          fontFeatures: const [FontFeature.tabularFigures()],
                        ),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}