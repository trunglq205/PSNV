namespace Swms.FinishGoods.API.Features.Balance.DataAccess;

public interface IBalanceRepository
{
    Task<IReadOnlyList<BalanceDocSummary>> GetDocsAsync(string? status);
    Task<BalanceDocDetail?> GetDocAsync(long id);
    Task SetLinesResolutionAsync(long docId, IReadOnlyList<long> lineIds, string resolution, long? userId);
    /// <summary>Tính lại và trả về (fa_ref, adjustedPallets, moveDocNo). Cập nhật pallets.box_count, sinh inventory_moves/lines, đóng phiếu CB.</summary>
    Task<IssueFaResult> IssueFaAsync(long docId, long? userId);
}
