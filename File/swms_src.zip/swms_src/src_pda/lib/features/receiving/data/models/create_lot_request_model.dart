import 'dart:convert';

import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/create_lot_params.dart'
as domain;

part 'create_lot_request_model.g.dart';

// ── Date-only: API dùng "2026-07-16", không phải ISO-8601 kèm giờ ──
String? _dateToJson(DateTime? d) => d == null
    ? null
    : '${d.year.toString().padLeft(4, '0')}-'
    '${d.month.toString().padLeft(2, '0')}-'
    '${d.day.toString().padLeft(2, '0')}';

DateTime? _dateFromJson(String? s) =>
    (s == null || s.isEmpty) ? null : DateTime.parse(s);

/// Khớp enum LotDetailLevel phía API — snake_case.
enum LotDetailLevel {
  @JsonValue('serial')
  serial,
  @JsonValue('box_line')
  boxLine,
  @JsonValue('box_count')
  boxCount,
}

enum LotType {
  @JsonValue('pallet')
  pallet,
  @JsonValue('stocky')
  stocky,
}

@JsonSerializable(includeIfNull: false)
class CreateLotRequestModel {
  final LotDetailLevel detailLevel;

  /// Số, không phải chuỗi (310 chứ không phải "310").
  final int categoryCode;

  final LotType lotType;

  /// Client tự sinh, 12 chữ số. Server chỉ check format + trùng.
  final String lotNo;

  /// Bắt buộc khi lotType = stocky, cấm khi lotType = pallet.
  final String? stockyCode;

  /// Chỉ gửi khi detailLevel = box_count.
  final int? boxCount;

  /// Chỉ gửi khi detailLevel = box_count.
  final String? model;

  /// Chỉ gửi khi detailLevel = box_count.
  final int? standardPacking;

  /// Chỉ gửi khi detailLevel = box_count.
  @JsonKey(fromJson: _dateFromJson, toJson: _dateToJson)
  final DateTime? productionDate;

  /// Null khi detailLevel = box_count.
  final List<CreateLotBoxModel>? boxes;

  const CreateLotRequestModel({
    required this.detailLevel,
    required this.categoryCode,
    required this.lotType,
    required this.lotNo,
    this.stockyCode,
    this.boxCount,
    this.model,
    this.standardPacking,
    this.productionDate,
    this.boxes,
  });

  /// Map từ domain params → request model.
  factory CreateLotRequestModel.fromParams(domain.CreateLotParams p) {
    final isBoxCount = p.detailLevel == domain.LotDetailLevel.boxCount;
    final isStocky = p.lotType == domain.LotType.stocky;

    return CreateLotRequestModel(
      detailLevel: switch (p.detailLevel) {
        domain.LotDetailLevel.serial => LotDetailLevel.serial,
        domain.LotDetailLevel.boxLine => LotDetailLevel.boxLine,
        domain.LotDetailLevel.boxCount => LotDetailLevel.boxCount,
      },
      lotType: switch (p.lotType) {
        domain.LotType.pallet => LotType.pallet,
        domain.LotType.stocky => LotType.stocky,
      },
      categoryCode: p.categoryCode,
      lotNo: p.lotNo,
      // pallet mà gửi stockyCode → Lot.StockyCodeNotAllowed.
      stockyCode: isStocky ? p.stockyCode?.trim() : null,
      // serial | box_line: server luôn ép boxCount = boxes.Count.
      boxCount: isBoxCount ? p.boxCount : null,
      model: p.model,
      standardPacking: isBoxCount ? p.standardPacking : null,
      boxes: isBoxCount
          ? null
          : [
        for (final b in p.boxes)
          CreateLotBoxModel.fromParams(b, p.detailLevel),
      ],
    );
  }

  factory CreateLotRequestModel.fromJson(Map<String, dynamic> json) =>
      _$CreateLotRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$CreateLotRequestModelToJson(this);

  @override
  String toString() => jsonEncode(toJson());
}

@JsonSerializable(includeIfNull: false)
class CreateLotBoxModel {
  final String boxNo;
  final String? psnvPo;
  final String? customerPo;

  @JsonKey(fromJson: _dateFromJson, toJson: _dateToJson)
  final DateTime? productionDate;

  final String? rawPayload;
  final List<CreateBoxLineModel> lines;

  const CreateLotBoxModel({
    required this.boxNo,
    required this.lines,
    this.psnvPo,
    this.customerPo,
    this.productionDate,
    this.rawPayload,
  });

  factory CreateLotBoxModel.fromParams(
      domain.CreateLotBoxParams b,
      domain.LotDetailLevel level,
      ) => CreateLotBoxModel(
    boxNo: b.boxNo,
    psnvPo: b.psnvPo,
    customerPo: b.customerPo,
    productionDate: b.productionDate,
    rawPayload: b.rawPayload,
    lines: [
      for (final l in b.lines) CreateBoxLineModel.fromParams(l, level),
    ],
  );

  factory CreateLotBoxModel.fromJson(Map<String, dynamic> json) =>
      _$CreateLotBoxModelFromJson(json);

  Map<String, dynamic> toJson() => _$CreateLotBoxModelToJson(this)
    ..removeWhere((k, v) => v is String && v.trim().isEmpty);

  @override
  String toString() => jsonEncode(toJson());
}

@JsonSerializable(includeIfNull: false)
class CreateBoxLineModel {
  final String model;
  final int qty;
  final String? serialNo;

  @JsonKey(fromJson: _dateFromJson, toJson: _dateToJson)
  final DateTime? productionDate;

  /// Số lượng inner carton trong box (chỉ dùng ở mức box_line).
  final int? cartonCount;

  const CreateBoxLineModel({
    required this.model,
    required this.qty,
    this.serialNo,
    this.productionDate,
    this.cartonCount,
  });

  factory CreateBoxLineModel.fromParams(
      domain.CreateBoxLineParams l,
      domain.LotDetailLevel level,
      ) {
    final isSerial = level == domain.LotDetailLevel.serial;
    return CreateBoxLineModel(
      model: l.model,
      // Mức serial: mỗi dòng 1 serial, server ép qty = 1.
      qty: isSerial ? 1 : l.qty,
      // box_line có serialNo → Lot.SerialNotAllowed.
      serialNo: isSerial ? l.serialNo?.trim() : null,
      productionDate: l.productionDate,
      // cartonCount không dùng ở mức serial.
      cartonCount: isSerial ? null : l.cartonCount,
    );
  }

  factory CreateBoxLineModel.fromJson(Map<String, dynamic> json) =>
      _$CreateBoxLineModelFromJson(json);

  Map<String, dynamic> toJson() => _$CreateBoxLineModelToJson(this);

  @override
  String toString() => jsonEncode(toJson());
}