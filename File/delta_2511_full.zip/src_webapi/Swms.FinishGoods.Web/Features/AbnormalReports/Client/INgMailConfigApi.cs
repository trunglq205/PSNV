using Refit;
using Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;

namespace Swms.FinishGoods.Web.Features.AbnormalReports.Client;

/// <summary>
/// Gọi thẳng các endpoint cấu hình email dùng chung (/api/email-configs/*).
/// Quyền phía API là System.EmailConfig.View / .Update — không phải quyền riêng
/// của Hàng bất thường, nên ai sửa được mail của module khác cũng sửa được ở đây.
/// </summary>
public interface INgMailConfigApi
{
    /// <summary>module = null -> mọi module. Truyền module để thu hẹp danh sách.</summary>
    [Get("/api/email-configs/events")]
    Task<List<NgEmailEventDto>> GetEventsAsync([Query] string? module);

    [Put("/api/email-configs/events/{code}/template")]
    Task SaveTemplateAsync(string code, [Body] SaveNgTemplateRequestDto request);

    /// <summary>
    /// Gợi ý cho ô Bộ phận / Danh mục. Gọi endpoint của chính email-configs
    /// chứ không gọi /api/categories/options — cái kia gác bằng models.view,
    /// người chỉ có quyền cấu hình email sẽ ăn 403.
    /// </summary>
    [Get("/api/email-configs/scope-options")]
    Task<NgEmailScopeOptionsDto> GetScopeOptionsAsync();

    [Get("/api/email-configs/events/{code}/recipients")]
    Task<List<NgEmailConfigDto>> GetConfigsAsync(string code);

    [Post("/api/email-configs/recipients")]
    Task<NgEmailConfigDto> CreateConfigAsync([Body] SaveNgEmailConfigRequestDto request);

    [Put("/api/email-configs/recipients/{id}")]
    Task UpdateConfigAsync(long id, [Body] SaveNgEmailConfigRequestDto request);

    [Delete("/api/email-configs/recipients/{id}")]
    Task DeleteConfigAsync(long id);
}
