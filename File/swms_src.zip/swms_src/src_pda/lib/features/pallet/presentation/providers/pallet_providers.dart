import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/pallet/data/datasources/pallet_remote_data_source.dart';
import 'package:swms_finish_goods/features/pallet/data/pallet_repository_impl.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/repositories/pallet_repository.dart';

part 'pallet_providers.g.dart';

@riverpod
PalletRemoteDataSource palletRemoteDataSource(Ref ref) =>
    PalletRemoteDataSource(ref.watch(dioProvider));

@riverpod
PalletRepository palletRepository(Ref ref) =>
    PalletRepositoryImpl(ref.watch(palletRemoteDataSourceProvider));

/// Chi tiết pallet đầy đủ (thùng + lịch sử) — dùng cho màn Pallet Detail,
/// Tìm thùng bị mất, Tách pallet. Family theo lot_no để mỗi mã 1 lần gọi;
/// sau mutation (lưu kho, tách...) các notifier `ref.invalidate` provider này.
@riverpod
Future<Pallet> pallet(Ref ref, String lotNo) => ref
    .watch(palletRepositoryProvider)
    .getByLotNo(
      lotNo,
      include: const {PalletInclude.boxes, PalletInclude.history},
    );
