﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class frmQTTycs : Form
    {
        WebService objService = new WebService();
        string id;
        string rs_indentity;
        
        public frmQTTycs(string id)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Normal;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            KeyPreview = true;
            lblUser.Text = id;

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmStep4cs_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Back:
                    if (!(txtmodel.Focus() || txtPalletID.Focus() || txtPalletID.Focus()))
                        btnClose_Click(sender, e);
                    break;
                case Keys.Escape:
                    btnClose_Click(sender, e);
                    break;


            }
        }

        private void txtModel_KeyDown(object sender, KeyEventArgs e)
        {
            

        }

        private void txtSerial_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string text = txtPalletID.Text.Trim();
                string createdate = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss");
                if (text.Contains("*"))
                    text = text.Replace("*", string.Empty);
                if (text.Contains("%"))
                    text = text.Replace("%", string.Empty);
                if (txtPalletID.Text.Trim().Length != 12)
                {
                    txtPalletID.Text = string.Empty;
                    MessageBox.Show("Pallet khong tont tai");
                    return;
                }
                Cursor.Current = Cursors.WaitCursor;                
                DataSet dtCheck = objService.spCheckQtyByPalletID_PalletID(txtPalletID.Text.Trim(), cmbCat.Text.Trim(), lblUser.Text, createdate);
                Cursor.Current = Cursors.Default;
                if (dtCheck.Tables[0].Rows.Count > 0)
                {
                    txtmodel.Text = dtCheck.Tables[0].Rows[0]["Model"].ToString();
                    txtQtt.Text = dtCheck.Tables[0].Rows[0]["ACTUAL"].ToString();
                    //txtStandard.Text = dtCheck.Rows[0]["STD"].ToString();
                    dataGridView1.DataSource = dtCheck.Tables[1];
                }
                txtPalletID.SelectAll();
                
            }            
               
           
        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void frmQTTycs_Load(object sender, EventArgs e)
        {
            DataTable dt_Cate = new DataTable();
            dt_Cate = objService.Get_Category();
            cmbCat.DataSource = dt_Cate;
            cmbCat.DisplayMember = "Description";
            cmbCat.ValueMember = "Description";
        }


    }
}
