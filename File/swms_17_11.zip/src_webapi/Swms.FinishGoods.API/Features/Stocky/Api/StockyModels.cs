using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.Stocky.Api;

/// <summary>Bộ lọc danh sách xe Stocky.</summary>
public record StockyQuery
{
    /// <summary>in_warehouse | returned. Bỏ trống = cả hai.</summary>
    public string? Status { get; init; }

    /// <summary>true = chỉ xe có hàng, false = chỉ xe rỗng, bỏ trống = cả hai.</summary>
    public bool? HasGoods { get; init; }

    /// <summary>Khớp mã xe, tên xe, mã pallet hoặc model.</summary>
    public string? Keyword { get; init; }
}

/// <summary>
/// Nhận hoặc trả một LÔ xe trong một lần — PDA cho quét nhiều xe rồi chốt một
/// lần, nên gửi cả danh sách thay vì mỗi xe một request.
/// </summary>
public record StockyBatchRequest
{
    [Required]
    [MinLength(1, ErrorMessage = "Danh sách mã xe không được rỗng.")]
    public List<string> Codes { get; init; } = new();
}

public record StockySubmitResponse(int CartCount, int Qty);

/// <summary>
/// Đặt MỘT xe vào MỘT ô. Khác <see cref="StockyBatchRequest"/> ở chỗ không gửi
/// cả lô: mỗi xe đứng một ô khác nhau, gộp lô ở đây là mời người dùng đặt cả
/// chục xe vào cùng một ô vì bấm nhanh.
/// </summary>
public record StockyPlaceRequest
{
    [Required]
    public string Code { get; init; } = string.Empty;

    /// <summary>Mã ô đích, lấy từ <c>master.locators.locator_code</c>.</summary>
    [Required]
    public string LocatorCode { get; init; } = string.Empty;
}

/// <param name="LotCount">Số pallet trên xe đã được chuyển theo.</param>
public record StockyPlaceResponse(
    string Code,
    string LocatorCode,
    string? AreaCode,
    int LotCount);

public record StockyCartResponse(
    long Id,
    string Code,
    string? Name,
    string? Vendor,
    string Status,
    long? LocatorId,
    string? LocatorCode,
    string? AreaCode,
    bool HasGoods,
    string? PalletCode,
    string? Model,
    int LotCount,
    int Qty,
    string? SiNo,
    DateTime? ReceivedAt,
    string? ReceivedBy,
    DateTime? ReturnedAt,
    string? ReturnedBy,
    string? Note,
    bool AtFa)
{
    /// <param name="atFa">
    /// Xe đang đứng ở FA. Service tính bằng cách so ô riêng của xe với ô FA
    /// khai trong cấu hình — client KHÔNG tự suy ra được vì không biết mã ô đó.
    /// </param>
    public static StockyCartResponse From(StockyCart c, bool atFa = false) => new(
        c.Id, c.Code, c.Name, c.Vendor, c.Status,
        c.LocatorId, c.LocatorCode, c.AreaCode,
        c.HasGoods, c.PalletCode, c.Model, c.LotCount, c.Qty, c.SiNo,
        c.ReceivedAt, c.ReceivedBy, c.ReturnedAt, c.ReturnedBy, c.Note, atFa);
}

/// <summary>
/// Kết quả tra một xe vừa quét. Giữ ĐÚNG hình dạng mà PDA đang chờ
/// (<c>StockyCartModel</c>: code / model / qty / lot_count) — thêm trường thì
/// được, đổi tên trường là PDA vỡ.
/// </summary>
public record StockyLookupResponse(
    string Code,
    string? Name,
    string? Model,
    int Qty,
    int LotCount,
    string? LocatorCode,
    bool HasGoods,
    bool AtFa)
{
    public static StockyLookupResponse From(StockyCart c, bool atFa = false) => new(
        c.Code, c.Name, c.Model, c.Qty, c.LotCount, c.LocatorCode, c.HasGoods, atFa);

    /// <summary>
    /// Xe CHƯA có trong danh mục. Lần nhận đầu tiên chính là lúc khai xe (QR
    /// đã mang mã xe), nên không coi là lỗi — trả về xe rỗng để PDA đưa vào
    /// danh sách chờ chốt.
    /// </summary>
    public static StockyLookupResponse NewCart(string code) =>
        new(code, null, null, 0, 0, null, false, false);
}

/// <summary>Khoá dịch thông báo lỗi của riêng feature này.</summary>
public static class StockyMsg
{
    public const string CodeRequired = "Stocky.Err.CodeRequired";
    public const string ModeInvalid = "Stocky.Err.ModeInvalid";
    public const string StatusInvalid = "Stocky.Err.StatusInvalid";
    public const string TooManyCodes = "Stocky.Err.TooManyCodes";
    public const string AlreadyInWarehouse = "Stocky.Err.AlreadyInWarehouse";
    public const string NotInWarehouse = "Stocky.Err.NotInWarehouse";
    public const string HasGoodsCannotReturn = "Stocky.Err.HasGoodsCannotReturn";
    public const string NotFound = "Stocky.Err.NotFound";

    /// <summary>Xe đã đứng ở FA rồi, đẩy sang FA lần nữa là vô nghĩa.</summary>
    public const string AlreadyAtFa = "Stocky.Err.AlreadyAtFa";

    /// <summary>
    /// Chỉ xe RỖNG mới sang FA. Xe còn pallet mà đẩy đi thì pallet vẫn ghi ô
    /// trong kho trong khi hàng đã rời kho — tồn kho sai im lặng.
    /// </summary>
    public const string HasGoodsCannotExportFa = "Stocky.Err.HasGoodsCannotExportFa";

    /// <summary>
    /// Xe đang ở FA thì phải nhận về kho trước khi trả vendor — vendor nhận xe
    /// tại kho, không nhận ở FA.
    /// </summary>
    public const string AtFaCannotReturnVendor = "Stocky.Err.AtFaCannotReturnVendor";

    /// <summary>
    /// Chưa khai ô FA trong <c>master.locators</c>. Chặn cứng chứ không cho qua
    /// như ô đậu xe: mục đích của luồng này là BIẾT xe đang ở FA, gán NULL thì
    /// xe thành "chưa gán ô" và mất đúng cái thông tin cần theo dõi.
    /// </summary>
    public const string FaLocatorMissing = "Stocky.Err.FaLocatorMissing";

    /// <summary>
    /// Giữa lúc quét và lúc chốt, trạng thái xe đã đổi ở nơi khác nên không
    /// phải mã nào cũng ghi được. Cả lô đã rollback.
    /// </summary>
    public const string ConcurrentChange = "Stocky.Err.ConcurrentChange";

    /// <summary>Chưa quét ô đích.</summary>
    public const string LocatorRequired = "Stocky.Err.LocatorRequired";

    /// <summary>Mã ô quét được không có trong danh mục ô.</summary>
    public const string LocatorNotFound = "Stocky.Err.LocatorNotFound";
}
