﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class InvoiceItemDetailImport
    {
        public string? InvoiceItem { get; set; }
        public string? PONo { get; set; }
        public string? POItem { get; set; }
        public double PlanQuantity { get; set; }
        public int Status { get; set; }

    }
}
