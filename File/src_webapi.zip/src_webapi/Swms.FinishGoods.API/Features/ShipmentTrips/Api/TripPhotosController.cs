using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

/// <summary>
/// Ảnh minh chứng hàng xuất theo chuyến. PDA chụp và upload, Web chỉ xem.
///
/// Xem = Trip.View: tài khoản PDA vốn đã cần quyền này để lấy danh sách chuyến trong ngày.
/// Upload / xoá = Trip.PhotoUpload: công nhân chụp ảnh không được có quyền sửa chuyến (Trip.Update).
/// </summary>
[ApiController]
[Route("api/shipment-trips")]
public class TripPhotosController : ControllerBase
{
    private readonly ITripPhotoService _service;
    public TripPhotosController(ITripPhotoService service) => _service = service;

    /// <summary>Bộ ảnh bắt buộc (theo loại xe) + ảnh đã có của 1 chuyến.</summary>
    [HttpGet("{id:long}/photos")]
    [RequirePermission<Perms.Outbound.Trip.View>]
    public async Task<ActionResult<TripPhotoListResponse>> GetList(long id)
        => Ok(await _service.GetAsync(id));

    /// <summary>
    /// PDA gửi 1 ảnh (multipart/form-data: file, itemKey, unitNo, slotNo).
    /// Cùng itemKey + unitNo + slotNo đã có ảnh thì ảnh mới thay ảnh cũ.
    /// </summary>
    [HttpPost("{id:long}/photos")]
    [RequirePermission<Perms.Outbound.Trip.PhotoUpload>]
    [RequestSizeLimit(30_000_000)]
    public async Task<ActionResult<TripPhotoResponse>> Upload(long id, [FromForm] TripPhotoUploadRequest request)
        => Ok(await _service.UploadAsync(id, request));

    /// <summary>Tải ảnh: size = original | view | thumb.</summary>
    [HttpGet("photos/{photoId:long}")]
    [RequirePermission<Perms.Outbound.Trip.View>]
    public async Task<IActionResult> GetPhoto(long photoId, [FromQuery] string size = "view")
    {
        var (content, contentType, fileName) = await _service.GetFileAsync(photoId, size);
        return File(content, contentType, fileName);
    }

    /// <summary>PDA xoá ảnh chụp nhầm. Chỉ khi chuyến chưa xuất cổng / chưa huỷ.</summary>
    [HttpDelete("photos/{photoId:long}")]
    [RequirePermission<Perms.Outbound.Trip.PhotoUpload>]
    public async Task<IActionResult> Delete(long photoId)
    {
        await _service.DeleteAsync(photoId);
        return NoContent();
    }
}