﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace SWMS_WebTool.Models
{
    public enum DeliveryPlanStatus
    {
        [EnumMember(Value = "0")]
        [Description("Status_NotReceive")]
        NotGoodReceipt,
        [EnumMember(Value = "1")]
        [Description("Status_ReceiptLack")]
        ReceiptLack,
        [EnumMember(Value = "2")]
        [Description("Status_ReceiptEnough")]
        ReceiptEnough,
        [EnumMember(Value = "3")]
        [Description("Status_AutoSap")]
        AutoSAP,
        [EnumMember(Value = "4")]
        [Description("Status_AutoSapError")]
        AutoSAPError
    }

    public enum DeliveryPlanType
    {
        [EnumMember(Value = "0")]
        [Description("Status_DispatchAdvice")]
        DispatchAdvice,
        [EnumMember(Value = "1")]
        [Description("Status_Invoice")]
        Invoice,
        [EnumMember(Value = "2")]
        [Description("Status_OrderPlan")]
        OrderPlan,
        [EnumMember(Value = "13")]
        [Description("Status_NG")]
        NG,
        [EnumMember(Value = "20")]
        [Description("Status_PMDReturn")]
        PMDReturn,
        [EnumMember(Value = "21")]
        [Description("Status_PMDRecycle")]
        PMDRecycle,
        //[EnumMember(Value = "3")]
        //TransferPlan
    }

    public class DeliveryPlan : AuditableEntity
    {
        public DeliveryPlanType Type;
    }
}
