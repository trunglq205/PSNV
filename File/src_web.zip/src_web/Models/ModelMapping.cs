﻿namespace SWMS_WebTool.Models
{
    public class ModelMapping
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string ModelJTF { get; set; }
        public string ModelSWMS { get; set; }
        public string Note { get; set; }
    }
}
