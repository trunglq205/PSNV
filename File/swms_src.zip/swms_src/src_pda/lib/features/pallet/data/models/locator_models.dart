import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';

part 'locator_models.g.dart';

/// Body `{ locatorCode }` — dùng chung cho
/// `PUT /api/pallets/{id}/locator` (AssignLocatorRequest) và
/// `PUT /api/pallets/{id}/storing` (StoreRequest).
@JsonSerializable()
class LocatorRequestModel {
  final String locatorCode;

  /// Chỉ cho gán vào vị trí thuộc loại bản đồ này (receiving/storing/vanning).
  /// null = không giới hạn — dùng cho màn Chuyển/Out vị trí.
  final String? allowedMapType;

  const LocatorRequestModel({
    required this.locatorCode,
    this.allowedMapType,
  });

  factory LocatorRequestModel.fromJson(Map<String, dynamic> json) =>
      _$LocatorRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$LocatorRequestModelToJson(this);
}

/// Khớp `LocatorChangeResponse` (PUT /locator) và `StoringResponse`
/// (PUT /storing — không có from*, parse thành null).
@JsonSerializable()
class LocatorChangeResponseModel {
  final int lotId;
  final String lotNo;
  final int? fromLocatorId;
  final String? fromLocatorCode;
  final int? toLocatorId;
  final String? toLocatorCode;
  final String? warning;

  const LocatorChangeResponseModel({
    required this.lotId,
    required this.lotNo,
    this.fromLocatorId,
    this.fromLocatorCode,
    this.toLocatorId,
    this.toLocatorCode,
    this.warning,
  });

  factory LocatorChangeResponseModel.fromJson(Map<String, dynamic> json) =>
      _$LocatorChangeResponseModelFromJson(json);

  Map<String, dynamic> toJson() => _$LocatorChangeResponseModelToJson(this);

  LocatorChangeResult toEntity() => LocatorChangeResult(
        lotId: lotId,
        lotNo: lotNo,
        fromLocatorId: fromLocatorId,
        fromLocatorCode: fromLocatorCode,
        toLocatorId: toLocatorId,
        toLocatorCode: toLocatorCode,
        warning: warning,
      );
}
