/* ============================================================================
   Chỉ thị back hàng (hàng return / refurbish khách trả về PSNV) — mục 1.

   MỘT PHIẾU = MỘT LOẠI HÀNG. goods_type nằm ở ĐẦU PHIẾU, không phải ở dòng;
   dòng chỉ còn model + số lượng. Số phiếu nói luôn loại:
       RW-yyyyMMdd-###  → rework
       RB-yyyyMMdd-###  → refurbish
   Khách báo cả hai loại trong một lần thì SCS Office tạo hai phiếu.

   Script tự nhận ra bảng đang ở dạng CŨ (goods_type ở dòng) và dựng lại cho
   đúng — xem mục 1. Chạy @WhatIf = 1 trước. Chạy lại nhiều lần vô hại.
   ============================================================================ */
SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @WhatIf bit = 1;   -- 1 = chỉ xem, 0 = ghi thật

/* Chỉ cần khi bảng đang ở dạng CŨ và CÓ dữ liệu thật trong đó.
   1 = chấp nhận XOÁ hết dữ liệu cũ để dựng lại đúng cấu trúc mới.            */
DECLARE @DropOldData bit = 0;

/* ---------- 0. Hiện trạng ---------- */
DECLARE @has_doc  bit = IIF(OBJECT_ID(N'wms.return_instructions') IS NULL, 0, 1);
DECLARE @has_line bit = IIF(OBJECT_ID(N'wms.return_instruction_lines') IS NULL, 0, 1);

/* Dạng CŨ nhận ra bằng: cột goods_type nằm ở bảng DÒNG. */
DECLARE @old_shape bit = IIF(
    @has_line = 1
    AND COL_LENGTH(N'wms.return_instruction_lines', N'goods_type') IS NOT NULL, 1, 0);

DECLARE @rows_doc  int = 0, @rows_real int = 0;
IF @has_doc = 1
BEGIN
    SELECT @rows_doc  = COUNT(*) FROM wms.return_instructions;
    SELECT @rows_real = COUNT(*) FROM wms.return_instructions WHERE ISNULL(created_by, N'') <> N'DUMMY';
END

SELECT N'0. Hien trang' AS section;
SELECT bang_phieu   = IIF(@has_doc = 1, N'DA CO', N'chua co'),
       bang_dong    = IIF(@has_line = 1, N'DA CO', N'chua co'),
       dang_cau_truc= CASE WHEN @has_doc = 0 THEN N'(chua tao)'
                           WHEN @old_shape = 1 THEN N'CU — goods_type o DONG'
                           ELSE N'MOI — goods_type o PHIEU' END,
       so_phieu     = @rows_doc,
       trong_do_that= @rows_real,
       su_kien_mail = IIF(EXISTS (SELECT 1 FROM master.email_events
                                  WHERE code = N'RETURN_INSTRUCTION_CREATED'), N'DA CO', N'chua co');

DECLARE @plan nvarchar(400) =
    CASE
      WHEN @has_doc = 0            THEN N'TAO MOI 2 bang theo cau truc moi.'
      WHEN @old_shape = 0          THEN N'Bang da dung cau truc moi — khong lam gi.'
      WHEN @rows_real = 0          THEN N'Bang dang dang CU nhung khong co du lieu that '
                                      + N'-> XOA va dung lai theo cau truc moi.'
      WHEN @DropOldData = 1        THEN N'Bang dang dang CU va CO ' + CAST(@rows_real AS nvarchar(10))
                                      + N' phieu that -> XOA HET roi dung lai (ban da dong y).'
      ELSE N'>>> DUNG LAI: bang dang dang CU va dang giu ' + CAST(@rows_real AS nvarchar(10))
         + N' phieu that. Mot phieu cu co the chua CA HAI loai nen khong tu tach duoc. '
         + N'Hoac tu tach tay, hoac dat @DropOldData = 1 neu chap nhan mat du lieu do.'
    END;

SELECT N'1. Se lam gi' AS section;
SELECT se_lam = @plan, che_do = IIF(@WhatIf = 1, N'WhatIf — chua ghi gi', N'GHI THAT');

IF @WhatIf = 1 RETURN;
IF @has_doc = 1 AND @old_shape = 1 AND @rows_real > 0 AND @DropOldData = 0 RETURN;

BEGIN TRAN;

/* ---------- 2. Dọn bảng dạng cũ ---------- */
IF @old_shape = 1
BEGIN
    DROP TABLE wms.return_instruction_lines;
    DROP TABLE wms.return_instructions;
    SET @has_doc = 0; SET @has_line = 0;
    PRINT 'Da xoa 2 bang dang cu';
END

/* ---------- 3. Bảng phiếu ---------- */
IF @has_doc = 0
BEGIN
    CREATE TABLE wms.return_instructions
    (
        id             bigint         IDENTITY(1,1) NOT NULL,

        /* RW-yyyyMMdd-### (rework) | RB-yyyyMMdd-### (refurbish).
           Tiền tố suy ra từ goods_type, server sinh. */
        doc_no         nvarchar(30)   NOT NULL,

        /* MỘT PHIẾU MỘT LOẠI. Dùng chung bộ giá trị với
           wms.pallets.disposition ('rework' | 'refurbish') — cố ý trùng chuỗi:
           mục 2 trở đi phải đối chiếu phiếu với pallet WH tạo, và bản đồ kho
           đã vẽ badge RW/RE theo đúng hai chuỗi này. Thêm bộ từ vựng thứ hai
           là chuốc lỗi quy đổi. */
        goods_type     nvarchar(20)   NOT NULL,

        customer       nvarchar(200)  NULL,

        /* Ngày hàng dự kiến về PSNV — thông tin khách hàng báo. */
        expected_date  date           NULL,

        /* open = đang theo dõi; completed = đã nhận đủ; cancelled = huỷ.
           Bước 1 chỉ sinh 'open'; hai giá trị kia khai sẵn trong CHECK để mục
           2 trở đi không phải ALTER. */
        doc_status     nvarchar(20)   NOT NULL CONSTRAINT df_return_instructions_status DEFAULT N'open',

        note           nvarchar(500)  NULL,

        /* Dấu vết đã báo FA. NULL = chưa gửi được (Mail:Enabled = false, hoặc
           chưa khai người nhận). Tạo phiếu KHÔNG hỏng vì mail hỏng. */
        mail_sent_at   datetime2(0)   NULL,
        mail_sent_to   nvarchar(2000) NULL,

        is_deleted     bit            NOT NULL CONSTRAINT df_return_instructions_isdel DEFAULT 0,
        created_at     datetime2(0)   NOT NULL CONSTRAINT df_return_instructions_crat DEFAULT SYSDATETIME(),
        created_by     nvarchar(100)  NULL,
        updated_at     datetime2(0)   NULL,
        updated_by     nvarchar(100)  NULL,

        CONSTRAINT pk_return_instructions PRIMARY KEY CLUSTERED (id),
        CONSTRAINT ck_return_instructions_status
            CHECK (doc_status IN (N'open', N'completed', N'cancelled')),
        CONSTRAINT ck_return_instructions_goods_type
            CHECK (goods_type IN (N'rework', N'refurbish'))
    );

    CREATE UNIQUE INDEX ux_return_instructions_doc_no
        ON wms.return_instructions(doc_no) WHERE is_deleted = 0;

    /* Màn danh sách lọc theo loại + trạng thái rồi sắp theo ngày về. */
    CREATE INDEX ix_return_instructions_type_status_date
        ON wms.return_instructions(goods_type, doc_status, expected_date DESC)
        WHERE is_deleted = 0;

    PRINT 'Da tao wms.return_instructions';
END
ELSE PRINT 'wms.return_instructions da dung cau truc moi — bo qua';

/* ---------- 4. Bảng dòng ---------- */
IF @has_line = 0
BEGIN
    CREATE TABLE wms.return_instruction_lines
    (
        id          bigint        IDENTITY(1,1) NOT NULL,
        doc_id      bigint        NOT NULL,

        /* Thứ tự hiện trên màn hình. Không dùng làm khoá. */
        line_no     int           NOT NULL CONSTRAINT df_ri_lines_lineno DEFAULT 1,

        /* Khớp master.models.code — server kiểm khi tạo/sửa. Lưu CHUỖI chứ
           không FK sang models.id: hàng trả về có thể là model cũ, sau này
           model bị xoá mềm khỏi danh mục thì phiếu lịch sử vẫn đọc được. */
        model       nvarchar(100) NOT NULL,

        qty         int           NOT NULL,
        note        nvarchar(500) NULL,

        is_deleted  bit           NOT NULL CONSTRAINT df_ri_lines_isdel DEFAULT 0,
        created_at  datetime2(0)  NOT NULL CONSTRAINT df_ri_lines_crat DEFAULT SYSDATETIME(),
        created_by  nvarchar(100) NULL,
        updated_at  datetime2(0)  NULL,
        updated_by  nvarchar(100) NULL,

        CONSTRAINT pk_return_instruction_lines PRIMARY KEY CLUSTERED (id),
        CONSTRAINT fk_ri_lines_doc FOREIGN KEY (doc_id)
            REFERENCES wms.return_instructions(id),
        CONSTRAINT ck_ri_lines_qty CHECK (qty > 0)
    );

    CREATE INDEX ix_ri_lines_doc ON wms.return_instruction_lines(doc_id) WHERE is_deleted = 0;

    /* Một model chỉ một dòng trong cùng phiếu. Hai dòng trùng sẽ làm SL kỳ
       vọng cộng đôi, và bước đối chiếu SL thực nhận ở mục 2 báo lệch mà không
       ai hiểu vì sao. Loại hàng đã nằm ở phiếu nên không còn trong khoá này. */
    CREATE UNIQUE INDEX ux_ri_lines_doc_model
        ON wms.return_instruction_lines(doc_id, model) WHERE is_deleted = 0;

    /* Tra "model này đang có chỉ thị nào" — dùng ở mục 2 khi WH tạo pallet ID. */
    CREATE INDEX ix_ri_lines_model ON wms.return_instruction_lines(model)
        WHERE is_deleted = 0;

    PRINT 'Da tao wms.return_instruction_lines';
END
ELSE PRINT 'wms.return_instruction_lines da dung cau truc moi — bo qua';

/* ---------- 5. Sự kiện mail báo FA ---------- */
/* Người nhận KHÔNG khai ở đây — khai trong màn Cấu hình email
   (master.email_config) với event_code = 'RETURN_INSTRUCTION_CREATED' và
   department = 'FA'. Nhờ vậy đổi người nhận không phải sửa code lẫn script. */
/* Mẫu viết bằng MARKDOWN, không phải HTML — đúng quy ước của hệ thống (giống
   mail hàng thiếu và hàng bất thường): API dựng HTML từ markdown lúc gửi
   (Shared/Business/Mail/MarkdownMail.cs), còn màn Cấu hình email trên web
   render cùng một pipeline để XEM TRƯỚC ra đúng lá mail sẽ gửi. Nhét thẻ HTML
   vào đây thì phần xem trước hiện ra nguyên thẻ cho người dùng đọc.

   Khai mẫu vào biến một lần rồi dùng cho cả hai nhánh: trước đây mẫu bị chép
   đôi, sửa một nhánh quên nhánh kia là chuyện sớm muộn. */
DECLARE @subject_created NVARCHAR(500) =
    N'[SWMS] Chỉ thị back hàng {DocNo} ({GoodsType}) — hàng về dự kiến {ExpectedDate}';

DECLARE @body_created NVARCHAR(MAX) = N'Kính gửi FA,

SCS Office vừa tạo chỉ thị back hàng **{DocNo}**.

| Thông tin | Nội dung |
|---|---|
| Loại hàng | **{GoodsType}** |
| Khách hàng | {Customer} |
| Ngày hàng về dự kiến | {ExpectedDate} |
| Số model | {ModelCount} |
| Tổng số lượng | {TotalQty} |

**Chi tiết:**
{LinesTable}
Ghi chú: {Note}

Xem trên hệ thống: {Link}

*Mail tự động từ SWMS Finish Goods — {Now}*';

IF NOT EXISTS (SELECT 1 FROM master.email_events WHERE code = N'RETURN_INSTRUCTION_CREATED')
BEGIN
    INSERT INTO master.email_events
        (code, module, name_key, description, subject_template, body_template,
         is_active, sort_order)
    VALUES
        (N'RETURN_INSTRUCTION_CREATED',
         N'RECEIVING',
         N'email.RETURN_INSTRUCTION_CREATED',
         N'Báo FA khi SCS Office tạo chỉ thị back hàng rework / refurbish',
         @subject_created,
         @body_created,
         1,
         /* Đặt cuối nhóm RECEIVING đang có, không chen vào giữa. */
         (SELECT ISNULL(MAX(sort_order), 0) + 1 FROM master.email_events WHERE module = N'RECEIVING'));

    PRINT 'Da them su kien mail RETURN_INSTRUCTION_CREATED';
END
ELSE
BEGIN
    /* Đã có từ bản trước (mẫu cũ viết bằng HTML, và không có {GoodsType} /
       {ModelCount}) — cập nhật lại mẫu, nhưng CHỈ khi chưa ai sửa tay
       (updated_at còn NULL).                                                 */
    UPDATE master.email_events
    SET subject_template = @subject_created,
        body_template    = @body_created
    WHERE code = N'RETURN_INSTRUCTION_CREATED' AND updated_at IS NULL;

    PRINT 'Su kien mail da co — da cap nhat lai mau markdown (neu chua ai sua tay)';
END

COMMIT;

/* ---------- 6. Kết quả ---------- */
SELECT N'6. Ket qua' AS section;
SELECT bang = N'wms.return_instructions',
       so_dong = COUNT(*),
       co_cot_goods_type = IIF(COL_LENGTH(N'wms.return_instructions', N'goods_type') IS NULL, N'KHONG', N'co')
FROM wms.return_instructions
UNION ALL
SELECT N'wms.return_instruction_lines', COUNT(*),
       IIF(COL_LENGTH(N'wms.return_instruction_lines', N'goods_type') IS NULL, N'khong (dung)', N'VAN CON — SAI')
FROM wms.return_instruction_lines;

SELECT code, module, is_active, sort_order
FROM master.email_events WHERE code = N'RETURN_INSTRUCTION_CREATED';

/* ---------- 7. Việc còn phải làm bằng tay ---------- */
SELECT N'7. Con phai lam tay' AS section;
SELECT viec = N'Khai nguoi nhan mail cho FA: man Cau hinh email -> su kien '
            + N'"RETURN_INSTRUCTION_CREATED", department = FA, recipient_type = TO. '
            + N'Chua khai thi tao phieu van thanh cong, chi la khong ai nhan mail.'
UNION ALL
SELECT N'Cap quyen rework_refurbish.view cho ca SCS Office lan SCS WH, '
     + N'.create chi cho SCS Office (quyen da co san trong cay Perms).';
