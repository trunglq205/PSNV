﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using Microsoft.CSharp;

namespace SWMS_WebTool.ViewModels
{
    public class POPendingViewModel : TableViewModel<PurchaseOrderPending, POPendingFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, POPendingFilter? filter = null)
        {
            return new
            {
                PONo = filter?.PONo ?? Filter.PONo,
                POItem = filter?.POItem ?? Filter.POItem,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
