using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Balance.DataAccess;

public class BalanceRepository : IBalanceRepository
{
    private readonly IDbConnectionFactory _factory;
    public BalanceRepository(IDbConnectionFactory factory) => _factory = factory;

    // Chỉ đếm các dòng LỆCH (đã đếm + qty_count <> qty_system + chưa adjust)
    private const string DiscWhere = "cl.is_deleted = 0 AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system AND cl.is_adjusted = 0";

    public async Task<IReadOnlyList<BalanceDocSummary>> GetDocsAsync(string? status)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT b.id AS [Id], b.doc_no AS [DocNo], b.count_id AS [CountId],
                   c.doc_no AS [CountDocNo], c.count_type AS [CountType], c.count_date AS [CountDate],
                   b.doc_status AS [DocStatus], b.fa_ref AS [FaRef],
                   b.created_at AS [CreatedAt], b.issued_at AS [IssuedAt],
                   ISNULL(a.total, 0) AS [TotalLines], ISNULL(a.resolved, 0) AS [ResolvedLines],
                   ISNULL(a.netDelta, 0) AS [NetDelta]
            FROM wms.balance_docs b
            JOIN wms.inventory_counts c ON c.id = b.count_id
            OUTER APPLY (
                SELECT COUNT(*) AS total,
                       SUM(CASE WHEN cl.resolution IS NOT NULL THEN 1 ELSE 0 END) AS resolved,
                       SUM(cl.qty_count - cl.qty_system) AS netDelta
                FROM wms.inventory_count_lines cl
                WHERE cl.count_id = b.count_id
                  AND cl.is_deleted = 0
                  AND cl.qty_count IS NOT NULL
                  AND cl.qty_count <> cl.qty_system
            ) a
            WHERE b.is_deleted = 0
              AND (@status IS NULL OR b.doc_status = @status)
            ORDER BY b.id DESC;
            """;
        var rows = await conn.QueryAsync<BalanceDocSummary>(sql, new { status });
        return rows.ToList();
    }

    public async Task<BalanceDocDetail?> GetDocAsync(long id)
    {
        using var conn = _factory.Create();
        const string headSql = """
            SELECT b.id AS [Id], b.doc_no AS [DocNo], b.count_id AS [CountId],
                   c.doc_no AS [CountDocNo], c.count_type AS [CountType], c.count_date AS [CountDate],
                   b.doc_status AS [DocStatus], b.fa_ref AS [FaRef],
                   b.created_at AS [CreatedAt], b.issued_at AS [IssuedAt],
                   (SELECT COUNT(*) FROM wms.inventory_count_lines cl
                     WHERE cl.count_id = b.count_id AND cl.is_deleted = 0
                       AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system) AS [TotalLines],
                   (SELECT COUNT(*) FROM wms.inventory_count_lines cl
                     WHERE cl.count_id = b.count_id AND cl.is_deleted = 0
                       AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system
                       AND cl.resolution IS NOT NULL) AS [ResolvedLines],
                   ISNULL((SELECT SUM(cl.qty_count - cl.qty_system) FROM wms.inventory_count_lines cl
                            WHERE cl.count_id = b.count_id AND cl.is_deleted = 0
                              AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system), 0) AS [NetDelta]
            FROM wms.balance_docs b
            JOIN wms.inventory_counts c ON c.id = b.count_id
            WHERE b.id = @id AND b.is_deleted = 0;
            """;
        var header = await conn.QuerySingleOrDefaultAsync<BalanceDocSummary>(headSql, new { id });
        if (header is null) return null;

        const string lineSql = """
            SELECT cl.id AS [LineId], cl.line_no AS [LineNo], ISNULL(CAST(cl.product_id AS int), 0) AS [ProductId],
                   cat.name AS [ProductName], cl.locator_id AS [LocatorId], l.locator_code AS [LocatorCode],
                   cl.lot_id AS [LotId], RTRIM(p.pallet_id) AS [PalletId],
                   -- Pallet serial / box_line KHÔNG ghi cột pallets.model (model
                   -- nằm ở box_lines) nên đọc thẳng p.model làm dòng phiếu cân
                   -- bằng của hai loại đó trống cột Model. Cùng quy ước COALESCE
                   -- với LocationInfoSql. Dòng không có pallet vẫn ra NULL.
                   COALESCE(
                       (SELECT STRING_AGG(z.model, ', ')
                        FROM (SELECT DISTINCT bl.model
                              FROM wms.boxes bx
                              JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                              WHERE bx.lot_id = p.id AND bx.is_deleted = 0) z),
                       p.model) AS [Model],
                   cl.qty_system AS [QtySystem], cl.qty_count AS [QtyCount],
                   cl.resolution AS [Resolution], cl.note AS [Note],
                   cl.is_found AS [IsFound], sl.locator_code AS [SystemLocatorCode]
            FROM wms.inventory_count_lines cl
            JOIN master.locators l ON l.id = cl.locator_id
            LEFT JOIN wms.pallets p ON p.id = cl.lot_id
            LEFT JOIN master.categories cat ON cat.code = cl.product_id
            LEFT JOIN master.locators sl ON sl.id = cl.system_locator_id
            WHERE cl.count_id = @cid AND cl.is_deleted = 0
              AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system
            ORDER BY cl.line_no;
            """;
        var lines = (await conn.QueryAsync<BalanceLine>(lineSql, new { cid = header.CountId })).ToList();
        return new BalanceDocDetail { Header = header, Lines = lines };
    }

    public async Task SetLinesResolutionAsync(long docId, IReadOnlyList<long> lineIds, string resolution, long? userId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // xác nhận các line thuộc phiếu CB này (count_id)
            var countId = await conn.ExecuteScalarAsync<long>(
                "SELECT count_id FROM wms.balance_docs WHERE id = @docId AND is_deleted = 0;",
                new { docId }, tx);

            await conn.ExecuteAsync("""
                UPDATE cl SET resolution = @resolution,
                              updated_at = SYSDATETIME(), updated_by = @userId
                FROM wms.inventory_count_lines cl
                WHERE cl.count_id = @countId
                  AND cl.id IN @ids
                  AND cl.is_deleted = 0
                  AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system
                  AND cl.is_adjusted = 0;
                """, new { resolution, userId, countId, ids = lineIds }, tx);

            // Pallet phát sinh ở ô B và dòng "thiếu" của CHÍNH pallet đó ở ô A là hai mặt của
            // một sự việc (pallet nằm sai chỗ) -> luôn cùng một hướng xử lý.
            await conn.ExecuteAsync("""
                UPDATE x SET resolution = @resolution,
                             updated_at = SYSDATETIME(), updated_by = @userId
                FROM wms.inventory_count_lines x
                JOIN wms.inventory_count_lines cl
                  ON cl.count_id = x.count_id AND cl.lot_id = x.lot_id AND cl.id <> x.id
                WHERE cl.count_id = @countId
                  AND cl.id IN @ids
                  AND cl.lot_id IS NOT NULL
                  AND (cl.is_found = 1 OR x.is_found = 1)
                  AND x.is_deleted = 0 AND x.is_adjusted = 0
                  AND x.qty_count IS NOT NULL AND x.qty_count <> x.qty_system;
                """, new { resolution, userId, countId, ids = lineIds }, tx);

            // pending -> processing khi có dòng đầu tiên được chọn hướng
            await conn.ExecuteAsync("""
                UPDATE wms.balance_docs SET doc_status = N'processing',
                       updated_at = SYSDATETIME(), updated_by = @userId
                WHERE id = @docId AND doc_status = N'pending';
                """, new { docId, userId }, tx);

            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<IssueFaResult> IssueFaAsync(long docId, long? userId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var countId = await conn.ExecuteScalarAsync<long>(
                "SELECT count_id FROM wms.balance_docs WHERE id = @docId AND is_deleted = 0;",
                new { docId }, tx);

            // 1) Đảm bảo mọi dòng lệch đã có resolution
            var unresolved = await conn.ExecuteScalarAsync<int>("""
                SELECT COUNT(*) FROM wms.inventory_count_lines
                WHERE count_id = @countId AND is_deleted = 0
                  AND qty_count IS NOT NULL AND qty_count <> qty_system
                  AND is_adjusted = 0 AND resolution IS NULL;
                """, new { countId }, tx);
            if (unresolved > 0)
                throw new InvalidOperationException($"Còn {unresolved} dòng lệch chưa chọn hướng xử lý.");

            // 2) Tạo phiếu inventory_moves (bút toán adjust)
            var moveDocNo = $"ADJ-{DateTime.Now:yyyyMMdd}-{DateTime.Now:HHmmss}";
            var moveId = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.inventory_moves
                    (doc_no, move_date, move_type, doc_status, description,
                     created_at, created_by, updated_at, updated_by, confirmed_at, confirmed_by, is_deleted)
                OUTPUT INSERTED.id
                VALUES (@moveDocNo, CAST(GETDATE() AS date), N'adjust', N'confirmed',
                        N'Bút toán từ phiếu cân bằng #' + CAST(@docId AS nvarchar(20)),
                        SYSDATETIME(), @userId, SYSDATETIME(), @userId, SYSDATETIME(), @userId, 0);
                """, new { moveDocNo, docId, userId }, tx);

            // 3) Với dòng resolution = 'count': update pallets.box_count = qty_count,
            //    sinh move_line ghi Δ (từ = đến = cùng locator_id, qty = Δ).
            int adjusted = await conn.ExecuteAsync("""
                INSERT INTO wms.inventory_move_lines
                    (move_id, line_no, product_id, lot_id, from_locator_id, to_locator_id, qty, note,
                     created_at, created_by, updated_at, updated_by, is_deleted)
                SELECT @moveId,
                       ROW_NUMBER() OVER (ORDER BY cl.line_no),
                       cl.product_id, cl.lot_id, cl.locator_id, cl.locator_id,
                       (cl.qty_count - cl.qty_system),
                       CONCAT(N'From count_line=', cl.id),
                       SYSDATETIME(), @userId, SYSDATETIME(), @userId, 0
                FROM wms.inventory_count_lines cl
                WHERE cl.count_id = @countId AND cl.is_deleted = 0
                  AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system
                  AND cl.is_adjusted = 0 AND cl.resolution = N'count';
                """, new { moveId, countId, userId }, tx);

            // 3a) Pallet phát sinh, theo đếm: DỜI pallet về ô tìm thấy + lấy số thùng đếm được.
            //     (Bút toán Δ ở trên đã ghi -N tại ô cũ và +M tại ô mới, khớp theo từng ô.)
            await conn.ExecuteAsync("""
                -- qty_count là SỐ LƯỢNG MODEL; số thùng của pallet lấy từ box_count_counted
                UPDATE p SET p.locator_id = cl.locator_id,
                             p.box_count = ISNULL(cl.box_count_counted, p.box_count),
                             p.updated_at = SYSDATETIME(), p.updated_by = @userId
                FROM wms.pallets p
                JOIN wms.inventory_count_lines cl ON cl.lot_id = p.id
                WHERE cl.count_id = @countId AND cl.is_deleted = 0 AND cl.is_found = 1
                  AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system
                  AND cl.is_adjusted = 0 AND cl.resolution = N'count';
                """, new { countId, userId }, tx);

            // 3b) Các dòng còn lại theo đếm: chỉ sửa số thùng. Bỏ qua pallet đã được dời ở 3a —
            //     dòng "thiếu" của nó ở ô cũ không được đưa pallet về 0.
            await conn.ExecuteAsync("""
                UPDATE p SET p.box_count = ISNULL(cl.box_count_counted, p.box_count),
                             p.updated_at = SYSDATETIME(), p.updated_by = @userId
                FROM wms.pallets p
                JOIN wms.inventory_count_lines cl ON cl.lot_id = p.id
                WHERE cl.count_id = @countId AND cl.is_deleted = 0 AND cl.is_found = 0
                  AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system
                  AND cl.is_adjusted = 0 AND cl.resolution = N'count'
                  AND cl.lot_id IS NOT NULL
                  AND NOT EXISTS (
                      SELECT 1 FROM wms.inventory_count_lines f
                      WHERE f.count_id = cl.count_id AND f.lot_id = cl.lot_id AND f.is_found = 1
                        AND f.is_deleted = 0 AND f.is_adjusted = 0 AND f.resolution = N'count'
                        AND f.qty_count IS NOT NULL AND f.qty_count <> f.qty_system);
                """, new { countId, userId }, tx);

            // 4) Đánh dấu tất cả dòng lệch là đã adjust (cả 'count' và 'system')
            await conn.ExecuteAsync("""
                UPDATE cl SET is_adjusted = 1, updated_at = SYSDATETIME(), updated_by = @userId
                FROM wms.inventory_count_lines cl
                WHERE cl.count_id = @countId AND cl.is_deleted = 0
                  AND cl.qty_count IS NOT NULL AND cl.qty_count <> cl.qty_system
                  AND cl.is_adjusted = 0 AND cl.resolution IS NOT NULL;
                """, new { countId, userId }, tx);

            // 5) Sinh mã FA + đóng phiếu CB
            var faRef = $"FA-{DateTime.Now:yyyyMM}-{docId:000}";
            await conn.ExecuteAsync("""
                UPDATE wms.balance_docs SET doc_status = N'issued', fa_ref = @faRef,
                       issued_at = SYSDATETIME(), issued_by = @userId,
                       updated_at = SYSDATETIME(), updated_by = @userId
                WHERE id = @docId;
                """, new { faRef, docId, userId }, tx);

            tx.Commit();
            return new IssueFaResult { FaRef = faRef, AdjustedPallets = adjusted, MoveDocNo = moveDocNo };
        }
        catch { tx.Rollback(); throw; }
    }
}
