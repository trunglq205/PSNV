// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'box_detail_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(boxDetailRemoteDataSource)
final boxDetailRemoteDataSourceProvider = BoxDetailRemoteDataSourceProvider._();

final class BoxDetailRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          BoxDetailRemoteDataSource,
          BoxDetailRemoteDataSource,
          BoxDetailRemoteDataSource
        >
    with $Provider<BoxDetailRemoteDataSource> {
  BoxDetailRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'boxDetailRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$boxDetailRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<BoxDetailRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  BoxDetailRemoteDataSource create(Ref ref) {
    return boxDetailRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(BoxDetailRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<BoxDetailRemoteDataSource>(value),
    );
  }
}

String _$boxDetailRemoteDataSourceHash() =>
    r'4b52bc7de0e025dfa46db41e8ff8441995726ef0';

@ProviderFor(boxDetailRepository)
final boxDetailRepositoryProvider = BoxDetailRepositoryProvider._();

final class BoxDetailRepositoryProvider
    extends
        $FunctionalProvider<
          BoxDetailRepository,
          BoxDetailRepository,
          BoxDetailRepository
        >
    with $Provider<BoxDetailRepository> {
  BoxDetailRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'boxDetailRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$boxDetailRepositoryHash();

  @$internal
  @override
  $ProviderElement<BoxDetailRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  BoxDetailRepository create(Ref ref) {
    return boxDetailRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(BoxDetailRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<BoxDetailRepository>(value),
    );
  }
}

String _$boxDetailRepositoryHash() =>
    r'2494adf3dd4d3274f5d60bcc76732cf26d53d404';
