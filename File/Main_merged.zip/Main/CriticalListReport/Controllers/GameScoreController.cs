﻿using System.Collections.Concurrent;
using System.Security.Cryptography;
using System.Text.Json.Serialization;
using CriticalListReport.Helpers;
using CriticalListReport.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace CriticalListReport.Controllers
{
    /// <summary>
    /// Mini game "Flappy Santa" mùa Giáng sinh + bảng xếp hạng (1 bảng cho cả mùa).
    ///
    ///   POST /GameScore/Start        — server cấp mã lượt chơi + seed (quyết định vị trí các cột người tuyết)
    ///   POST /GameScore/Begin        — trình duyệt báo "đã bắt đầu bay" (để server bấm giờ)
    ///   POST /GameScore/Submit       — gửi danh sách tick bấm bay; SERVER TỰ CHƠI LẠI để tính điểm
    ///   GET  /GameScore/Leaderboard  — BXH cả mùa
    ///
    /// CHỐNG GIAN LẬN:
    ///   - Trình duyệt không gửi điểm. Server lấy seed của chính nó + các tick bấm bay, chạy lại toàn bộ
    ///     lượt chơi bằng Helpers/XmasFlappySim (giống hệt bản JS) để ra điểm. Sửa điểm bằng F12 vô tác dụng.
    ///   - Mỗi mã lượt chơi chỉ dùng 1 lần, gắn với đúng tài khoản, hết hạn sau 30 phút;
    ///     mỗi người chỉ có 1 lượt đang mở → không gửi lại / không chơi song song nhiều tab để "chọn lượt đẹp".
    ///   - Thời gian thật (server bấm giờ từ Begin tới Submit) phải khớp với thời gian bay mô phỏng:
    ///     không thể tua nhanh (gửi kết quả ngay) hay chơi chậm (làm chậm game để dễ né).
    ///   - Lượt không khớp vẫn được lưu (UsedAuto = 1) để Ban tổ chức xem, nhưng KHÔNG xếp hạng.
    ///
    /// Luật xếp hạng: điểm cao nhất (số cột người tuyết vượt qua); bằng điểm thì ai đạt trước xếp trên.
    /// Mùa + giải thưởng: Helpers/SeasonTheme (mặc định 27/11 → 12:00 trưa 25/12). Top 1 và Top 2 lần lượt đấu 1vs1
    /// với Admin chiều 25/12; thắng mới được quay ngẫu nhiên (bước 50k): Top 1 = 50k → 300k, Top 2 = 50k → 200k.
    /// </summary>
    [Authorize]
    public class GameScoreController : Controller
    {
        private const string Theme = "christmas";
        private const int MaxFlaps = 30000;
        private static readonly TimeSpan SessionTtl = TimeSpan.FromMinutes(30);

        private class GameSession
        {
            public string Id { get; init; } = string.Empty;
            public string Username { get; init; } = string.Empty;
            public uint Seed { get; init; }
            public DateTime CreatedUtc { get; init; }
            public DateTime? BeganUtc { get; set; }
        }

        // Lượt chơi đang mở (giữ trong RAM; IIS recycle thì lượt đang chơi dở không lưu được — chấp nhận được)
        private static readonly ConcurrentDictionary<string, GameSession> Sessions = new();

        private readonly AppDbContext _context;
        private readonly IConfiguration _config;

        public GameScoreController(AppDbContext context, IConfiguration config)
        {
            _context = context;
            _config = config;
        }

        private string CurrentUser => User.Identity?.Name ?? string.Empty;

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Start()
        {
            var username = CurrentUser;
            if (string.IsNullOrEmpty(username)) return Unauthorized();

            var now = DateTime.UtcNow;
            // dọn lượt hết hạn + mỗi người chỉ giữ 1 lượt đang mở
            foreach (var kv in Sessions)
            {
                if (now - kv.Value.CreatedUtc > SessionTtl
                    || string.Equals(kv.Value.Username, username, StringComparison.OrdinalIgnoreCase))
                    Sessions.TryRemove(kv.Key, out _);
            }

            var session = new GameSession
            {
                Id = Guid.NewGuid().ToString("N"),
                Username = username,
                Seed = BitConverter.ToUInt32(RandomNumberGenerator.GetBytes(4), 0),
                CreatedUtc = now
            };
            Sessions[session.Id] = session;

            return Json(new { sessionId = session.Id, seed = session.Seed });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Begin([FromBody] GameSessionRequest model)
        {
            if (model?.SessionId != null && Sessions.TryGetValue(model.SessionId, out var s)
                && string.Equals(s.Username, CurrentUser, StringComparison.OrdinalIgnoreCase)
                && s.BeganUtc == null)
            {
                s.BeganUtc = DateTime.UtcNow;
            }
            return Json(new { ok = true });
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        [RequestSizeLimit(512 * 1024)]
        public async Task<IActionResult> Submit([FromBody] GameScoreSubmit model)
        {
            var username = CurrentUser;
            if (string.IsNullOrEmpty(username)) return Unauthorized();

            // 1. mã lượt chơi: phải có, đúng người, chưa dùng, chưa hết hạn — dùng xong xoá luôn
            if (model?.SessionId == null || !Sessions.TryRemove(model.SessionId, out var session))
                return BadRequest(new { message = "Lượt chơi không hợp lệ hoặc đã hết hạn — bấm Chơi lại nhé." });
            if (!string.Equals(session.Username, username, StringComparison.OrdinalIgnoreCase))
                return BadRequest(new { message = "Lượt chơi không thuộc tài khoản này." });
            var nowUtc = DateTime.UtcNow;
            if (nowUtc - session.CreatedUtc > SessionTtl)
                return BadRequest(new { message = "Lượt chơi đã hết hạn — bấm Chơi lại nhé." });

            // 2. kiểm tra định dạng các tick bấm bay
            var flaps = model.Flaps ?? new List<int>();
            string? reason = null;
            if (flaps.Count == 0 || flaps.Count > MaxFlaps || flaps[0] != 0
                || model.EndTick < 0 || model.EndTick >= XmasFlappySim.MAX_TICKS)
                reason = "Dữ liệu lượt chơi không hợp lệ.";
            else
            {
                for (int i = 1; i < flaps.Count; i++)
                {
                    if (flaps[i] - flaps[i - 1] < XmasFlappySim.MIN_FLAP_GAP) { reason = "Dữ liệu lượt chơi không hợp lệ."; break; }
                }
                if (reason == null && flaps[^1] > model.EndTick) reason = "Dữ liệu lượt chơi không hợp lệ.";
            }

            // 3. server tự chơi lại để tính điểm
            var sim = reason == null
                ? XmasFlappySim.Replay(session.Seed, flaps)
                : new XmasFlappySim.Result();
            if (reason == null && (!sim.Dead || sim.EndTick != model.EndTick || sim.FlapsUsed != flaps.Count))
                reason = "Kết quả không khớp với lượt chơi.";

            // 4. thời gian thật phải khớp thời gian bay
            var simMs = (int)((long)sim.EndTick * 1000 / XmasFlappySim.TPS);
            if (reason == null)
            {
                var since = session.BeganUtc ?? session.CreatedUtc;
                var elapsedMs = (nowUtc - since).TotalMilliseconds;
                if (elapsedMs < simMs * 0.9 - 400)
                    reason = "Thời gian chơi bất thường (nhanh hơn thực tế).";
                else if (session.BeganUtc != null && elapsedMs > simMs * 1.5 + 10000)
                    reason = "Thời gian chơi bất thường (game bị làm chậm).";
            }

            var valid = reason == null;
            var (from, to) = SeasonTheme.ChristmasSeason(_config);

            // kỷ lục cũ của người này trong mùa (để báo "kỷ lục cá nhân mới")
            var prevBest = await _context.GameScores
                .Where(g => g.Theme == Theme && !g.UsedAuto && g.Username == username && g.PlayedAt >= from && g.PlayedAt < to)
                .Select(g => (int?)g.Hits)
                .MaxAsync() ?? 0;

            var score = new GameScore
            {
                Username = username,
                FullName = User.FindFirst("FullName")?.Value,
                Theme = Theme,
                Hits = sim.Score,
                DurationMs = simMs,
                Throws = flaps.Count,
                UsedAuto = !valid,
                PlayedAt = DateTime.Now
            };
            _context.GameScores.Add(score);
            await _context.SaveChangesAsync();

            var inSeason = score.PlayedAt >= from && score.PlayedAt < to;
            var board = await BuildBoard();
            var me = board.FirstOrDefault(r => string.Equals(r.Username, username, StringComparison.OrdinalIgnoreCase));

            return Json(new
            {
                saved = true,
                valid,
                reason,
                score = sim.Score,
                inSeason,
                ranked = valid && inSeason && sim.Score > 0,
                rank = me?.Rank,
                total = board.Count,
                best = me?.Score,
                personalBest = valid && inSeason && sim.Score > prevBest,
                prizes = SeasonTheme.Prizes(_config),
                seasonTo = SeasonTheme.CloseText(to).time + " " + SeasonTheme.CloseText(to).day
            });
        }

        [HttpGet]
        public async Task<IActionResult> Leaderboard(int top = 20)
        {
            top = Math.Clamp(top, 3, 100);
            var board = await BuildBoard();
            var me = board.FirstOrDefault(r => string.Equals(r.Username, CurrentUser, StringComparison.OrdinalIgnoreCase));
            var (from, to) = SeasonTheme.ChristmasSeason(_config);
            var today = DateTime.Today;

            return Json(new
            {
                from = from.ToString("dd/MM"),
                to = SeasonTheme.CloseText(to).day,
                closeTime = SeasonTheme.CloseText(to).time,
                started = today >= from,
                closed = DateTime.Now >= to,
                daysLeft = DateTime.Now >= to ? 0 : (int)Math.Ceiling((to - today).TotalDays),
                prizes = SeasonTheme.Prizes(_config),
                total = board.Count,
                rows = board.Take(top),
                me
            });
        }

        // ===== helpers =====

        private async Task<List<BoardRow>> BuildBoard()
        {
            var (from, to) = SeasonTheme.ChristmasSeason(_config);

            var scores = await _context.GameScores
                .AsNoTracking()
                .Where(g => g.Theme == Theme && !g.UsedAuto && g.Hits > 0 && g.PlayedAt >= from && g.PlayedAt < to)
                .Select(g => new { g.Username, g.FullName, g.Hits, g.PlayedAt })
                .ToListAsync();

            var rows = scores
                .GroupBy(g => g.Username)
                .Select(grp =>
                {
                    var best = grp.OrderByDescending(g => g.Hits).ThenBy(g => g.PlayedAt).First();
                    return new BoardRow
                    {
                        Username = grp.Key,
                        FullName = grp.OrderByDescending(g => g.PlayedAt).Select(g => g.FullName).FirstOrDefault() ?? grp.Key,
                        Score = best.Hits,
                        BestAt = best.PlayedAt.ToString("dd/MM HH:mm"),
                        BestAtTime = best.PlayedAt
                    };
                })
                .OrderByDescending(r => r.Score).ThenBy(r => r.BestAtTime)
                .ToList();

            for (int i = 0; i < rows.Count; i++) rows[i].Rank = i + 1;
            return rows;
        }

        public class BoardRow
        {
            public int Rank { get; set; }
            public string Username { get; set; } = string.Empty;
            public string FullName { get; set; } = string.Empty;
            public int Score { get; set; }
            public string BestAt { get; set; } = string.Empty;
            [JsonIgnore] public DateTime BestAtTime { get; set; }
        }
    }
}
