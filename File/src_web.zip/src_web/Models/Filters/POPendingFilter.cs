﻿using Microsoft.AspNetCore.Mvc;
using Refit;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class POPendingFilter : BaseFilter
    {
        [Display(Name = "PO No")]
        [AliasAs("PONo")]
        public string? PONo { get; set; }
        [Display(Name = "PO Item")]
        [AliasAs("Item")]
        public string? POItem { get; set; }
    }
}
