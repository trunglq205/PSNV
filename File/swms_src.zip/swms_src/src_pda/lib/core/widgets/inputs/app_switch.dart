import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Công tắc bật/tắt — track bo tròn, núm trắng, đủ vùng chạm 44px.
/// Bật: primary. Tắt: viền/nền theo token. Hỗ trợ disabled.
class AppSwitch extends StatelessWidget {
  final bool value;
  final ValueChanged<bool>? onChanged;

  const AppSwitch({super.key, required this.value, this.onChanged});

  static const double _trackW = 44;
  static const double _trackH = 26;
  static const double _thumb = 20;
  static const double _pad = 3;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final enabled = onChanged != null;

    const trackOn = AppColors.primary;
    final trackOff = swms.border2;
    final track = value ? trackOn : trackOff;

    return Semantics(
      toggled: value,
      enabled: enabled,
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTap: enabled ? () => onChanged!(!value) : null,
        child: Opacity(
          opacity: enabled ? 1 : 0.4,
          // Vùng chạm tối thiểu 44px, thị giác chỉ 26px
          child: SizedBox(
            width: 44,
            height: 44,
            child: Center(
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 160),
                curve: Curves.easeOut,
                width: _trackW,
                height: _trackH,
                padding: const EdgeInsets.all(_pad),
                decoration: BoxDecoration(
                  color: track,
                  borderRadius: BorderRadius.circular(_trackH / 2),
                ),
                child: AnimatedAlign(
                  duration: const Duration(milliseconds: 160),
                  curve: Curves.easeOut,
                  alignment:
                  value ? Alignment.centerRight : Alignment.centerLeft,
                  child: Container(
                    width: _thumb,
                    height: _thumb,
                    decoration: const BoxDecoration(
                      color: Colors.white,
                      shape: BoxShape.circle,
                      boxShadow: [
                        BoxShadow(
                          color: Color(0x33000000),
                          offset: Offset(0, 1),
                          blurRadius: 2,
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}