﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class LayoutCapacityFilter : BaseFilter
    {
        public string? Plant { get; set; }
        public string? Category { get; set; }
        [Display(Name = "Kind")]
        public string? TypeSloc { get; set; }
        [Display(Name = "PIC")]
        public string? PicUser { get; set; }
    }
}
