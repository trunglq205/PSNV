import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';

part 'ng_models.g.dart';

@JsonSerializable(createToJson: false)
class NgReportModel {
  final int id;
  final String docNo;
  final String? palletCode;
  final String? model;
  final String ngType;
  final DateTime discoveredAt;
  final String docStatus;
  final String currentStep;
  final String leaderStatus;
  final String faStatus;
  final String? faResolution;
  final String oqcStatus;
  final String resolution;
  final int itemCount;
  final int qtyAffected;
  final int photoCount;
  final String? createdBy;

  /// Mọi mục phạm vi đều là cả pallet. Server tính, app chỉ hiển thị.
  /// Mặc định false để phiếu từ API cũ không vỡ.
  final bool isWholePallet;

  const NgReportModel({
    required this.id,
    required this.docNo,
    required this.ngType,
    required this.discoveredAt,
    required this.docStatus,
    required this.currentStep,
    required this.leaderStatus,
    required this.faStatus,
    required this.oqcStatus,
    required this.resolution,
    required this.itemCount,
    required this.qtyAffected,
    required this.photoCount,
    this.isWholePallet = false,
    this.palletCode,
    this.model,
    this.faResolution,
    this.createdBy,
  });

  factory NgReportModel.fromJson(Map<String, dynamic> json) =>
      _$NgReportModelFromJson(json);

  NgReport toEntity() => NgReport(
        id: id,
        docNo: docNo,
        palletCode: palletCode,
        model: model,
        ngType: ngType,
        discoveredAt: discoveredAt,
        docStatus: docStatus,
        currentStep: currentStep,
        leaderStatus: leaderStatus,
        faStatus: faStatus,
        faResolution: faResolution,
        oqcStatus: oqcStatus,
        resolution: resolution,
        itemCount: itemCount,
        qtyAffected: qtyAffected,
        isWholePallet: isWholePallet,
        photoCount: photoCount,
        createdBy: createdBy,
      );
}

@JsonSerializable(createToJson: false)
class NgItemModel {
  final int id;
  final String scope;
  final String? code;
  final int qtyAffected;
  final String? note;

  const NgItemModel({
    required this.id,
    required this.scope,
    required this.qtyAffected,
    this.code,
    this.note,
  });

  factory NgItemModel.fromJson(Map<String, dynamic> json) =>
      _$NgItemModelFromJson(json);

  NgItem toEntity() =>
      NgItem(id: id, scope: scope, code: code, qtyAffected: qtyAffected, note: note);
}

@JsonSerializable(createToJson: false)
class NgPhotoModel {
  final int id;
  final String fileName;
  final String? caption;
  final int sortOrder;

  const NgPhotoModel({
    required this.id,
    required this.fileName,
    required this.sortOrder,
    this.caption,
  });

  factory NgPhotoModel.fromJson(Map<String, dynamic> json) =>
      _$NgPhotoModelFromJson(json);

  NgPhoto toEntity() =>
      NgPhoto(id: id, fileName: fileName, caption: caption, sortOrder: sortOrder);
}

@JsonSerializable(createToJson: false)
class NgApprovalModel {
  final int id;
  final String step;
  final String action;
  final String? resolution;
  final String? comment;
  final String? actedBy;
  final DateTime actedAt;

  const NgApprovalModel({
    required this.id,
    required this.step,
    required this.action,
    required this.actedAt,
    this.resolution,
    this.comment,
    this.actedBy,
  });

  factory NgApprovalModel.fromJson(Map<String, dynamic> json) =>
      _$NgApprovalModelFromJson(json);

  NgApproval toEntity() => NgApproval(
        id: id,
        step: step,
        action: action,
        resolution: resolution,
        comment: comment,
        actedBy: actedBy,
        actedAt: actedAt,
      );
}

@JsonSerializable(createToJson: false)
class NgDetailModel {
  final NgReportModel header;
  final String? description;
  final String? leaderBy;
  final DateTime? leaderAt;
  final String? leaderComment;
  final String? faBy;
  final DateTime? faAt;
  final String? faComment;
  final String? oqcBy;
  final DateTime? oqcAt;
  final String? oqcComment;
  final String? finalizedBy;
  final DateTime? finalizedAt;
  final String? finalComment;
  final String? cancelledBy;
  final DateTime? cancelledAt;
  final String? cancelReason;
  final List<NgItemModel> items;
  final List<NgPhotoModel> photos;
  final List<NgApprovalModel> approvals;

  const NgDetailModel({
    required this.header,
    required this.items,
    required this.photos,
    required this.approvals,
    this.description,
    this.leaderBy,
    this.leaderAt,
    this.leaderComment,
    this.faBy,
    this.faAt,
    this.faComment,
    this.oqcBy,
    this.oqcAt,
    this.oqcComment,
    this.finalizedBy,
    this.finalizedAt,
    this.finalComment,
    this.cancelledBy,
    this.cancelledAt,
    this.cancelReason,
  });

  factory NgDetailModel.fromJson(Map<String, dynamic> json) =>
      _$NgDetailModelFromJson(json);

  NgDetail toEntity() => NgDetail(
        header: header.toEntity(),
        description: description,
        leaderBy: leaderBy,
        leaderAt: leaderAt,
        leaderComment: leaderComment,
        faBy: faBy,
        faAt: faAt,
        faComment: faComment,
        oqcBy: oqcBy,
        oqcAt: oqcAt,
        oqcComment: oqcComment,
        finalizedBy: finalizedBy,
        finalizedAt: finalizedAt,
        finalComment: finalComment,
        cancelledBy: cancelledBy,
        cancelledAt: cancelledAt,
        cancelReason: cancelReason,
        items: items.map((e) => e.toEntity()).toList(),
        photos: photos.map((e) => e.toEntity()).toList(),
        approvals: approvals.map((e) => e.toEntity()).toList(),
      );
}

@JsonSerializable(createFactory: false)
class CreateNgItemModel {
  final String scope;
  final String? code;
  final int? qtyAffected;
  final String? note;

  const CreateNgItemModel({required this.scope, this.code, this.qtyAffected, this.note});

  Map<String, dynamic> toJson() => _$CreateNgItemModelToJson(this);
}

@JsonSerializable(createFactory: false)
class CreateNgReportModel {
  final String palletCode;
  final String ngType;
  final String? description;
  final List<CreateNgItemModel> items;

  const CreateNgReportModel({
    required this.palletCode,
    required this.ngType,
    required this.items,
    this.description,
  });

  Map<String, dynamic> toJson() => _$CreateNgReportModelToJson(this);
}

@JsonSerializable(createToJson: false)
class CreateNgResultModel {
  final int id;
  final String docNo;

  const CreateNgResultModel({required this.id, required this.docNo});

  factory CreateNgResultModel.fromJson(Map<String, dynamic> json) =>
      _$CreateNgResultModelFromJson(json);
}

@JsonSerializable(createToJson: false)
class NgPalletCheckModel {
  final int id;
  final String code;
  final String? model;
  final int? boxCount;
  final String? inspectionStatus;
  @JsonKey(defaultValue: false)
  final bool isUrgent;
  final DateTime? productionDate;
  final String? locatorCode;
  final String? areaName;

  const NgPalletCheckModel({
    required this.id,
    required this.code,
    this.isUrgent = false,
    this.model,
    this.boxCount,
    this.inspectionStatus,
    this.productionDate,
    this.locatorCode,
    this.areaName,
  });

  factory NgPalletCheckModel.fromJson(Map<String, dynamic> json) =>
      _$NgPalletCheckModelFromJson(json);

  NgPalletBrief toEntity() => NgPalletBrief(
        id: id,
        code: code,
        model: model,
        boxCount: boxCount,
        inspectionStatus: inspectionStatus,
        isUrgent: isUrgent,
        productionDate: productionDate,
        locatorCode: locatorCode,
        areaName: areaName,
      );
}

/// Khớp `NgTypeResponse(string Code, string Name, string? Note, bool RequiresOqc)`
/// phía API.
@JsonSerializable(createToJson: false)
class NgTypeModel {
  final String code;
  final String name;
  final String? note;
  final bool requiresOqc;

  const NgTypeModel({
    required this.code,
    required this.name,
    this.note,
    this.requiresOqc = true,
  });

  factory NgTypeModel.fromJson(Map<String, dynamic> json) =>
      _$NgTypeModelFromJson(json);

  NgType toEntity() => NgType(
        code: code,
        name: name,
        note: note,
        requiresOqc: requiresOqc,
      );
}
