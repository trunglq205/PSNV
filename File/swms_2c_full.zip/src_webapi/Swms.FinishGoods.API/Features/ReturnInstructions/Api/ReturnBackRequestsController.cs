using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.ReturnInstructions.Business;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// Yêu cầu back hàng sang FA — mục 2c.
///
/// Bốn bước, MỖI BƯỚC MỘT QUYỀN, để một người không gánh được hai bước liền
/// nhau (cùng khuôn với màn Hàng bất thường):
///   B1 FA tạo yêu cầu                      → <c>RequestBack</c>
///   B2 quản lý FA duyệt                    → <c>ApproveFa</c>
///   B3 SCS WH xác nhận + tạo chỉ thị back   → <c>Process</c>
///   B4 quản lý SCS duyệt cho back          → <c>ApproveScs</c>
///
/// Serial chỉ chuyển <c>at_fa</c> ở B4. Trước đó yêu cầu chỉ là model + SL —
/// không ai tick 100 serial trên web, và gắp sớm là giữ hàng trong khi yêu cầu
/// còn có thể bị huỷ.
/// </summary>
[ApiController]
[Route("api/return-back-requests")]
public class ReturnBackRequestsController : ControllerBase
{
    private readonly IReturnBackRequestService _service;
    public ReturnBackRequestsController(IReturnBackRequestService service) => _service = service;

    /// <summary>
    /// Danh sách yêu cầu. Lọc được theo <c>step</c> để mỗi bên mở ra là thấy
    /// hàng đợi của mình, không phải tự lọc bằng mắt.
    /// </summary>
    [HttpGet]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<BackRequestResponse>>> GetList(
        [FromQuery] BackRequestQuery query)
        => Ok(await _service.GetListAsync(query));

    [HttpGet("{id:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<BackRequestResponse>> GetById(long id)
        => Ok(await _service.GetByIdAsync(id));

    /// <summary>
    /// SL còn gắp được theo model của một chỉ thị — màn soạn yêu cầu gọi để FA
    /// biết xin tối đa bao nhiêu. Chỉ cần quyền xem.
    /// </summary>
    [HttpGet("available/{docId:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<BackAvailableModelResponse>>> GetAvailable(long docId)
        => Ok(await _service.GetAvailableAsync(docId));

    /// <summary>B1 — FA tạo yêu cầu back.</summary>
    [HttpPost]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.RequestBack>]
    public async Task<ActionResult<BackRequestResponse>> Create(
        [FromBody] CreateBackRequestRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    /// <summary>
    /// Sửa dòng khi còn ở bước B1 hoặc B3.
    ///
    /// Nhận CẢ HAI quyền: FA sửa yêu cầu của mình (<c>RequestBack</c>), và SCS
    /// WH chỉnh số ở bước xác nhận (<c>Process</c>) — xác nhận mà không sửa
    /// được thì gặp số sai họ chỉ còn cách bắt FA làm lại từ đầu.
    /// Service chặn theo BƯỚC, nên quyền rộng ở đây không cho ai vượt bước.
    /// </summary>
    [HttpPut("{id:long}")]
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.RequestBack,
                          Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<BackRequestResponse>> Update(
        long id, [FromBody] UpdateBackRequestRequest request)
        => Ok(await _service.UpdateAsync(id, request));

    /// <summary>B2 — quản lý FA duyệt.</summary>
    [HttpPost("{id:long}/approve-fa")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ApproveFa>]
    public async Task<ActionResult<BackRequestResponse>> ApproveFa(
        long id, [FromBody] BackRequestDecisionRequest request)
        => Ok(await _service.ApproveFaAsync(id, request));

    /// <summary>B3 — SCS WH xác nhận thông tin và tạo chỉ thị back.</summary>
    [HttpPost("{id:long}/instruct")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<BackRequestResponse>> Instruct(
        long id, [FromBody] BackRequestDecisionRequest request)
        => Ok(await _service.InstructAsync(id, request));

    /// <summary>
    /// B4 — quản lý SCS duyệt cho back. Bước này GẮP SERIAL và chuyển
    /// <c>at_fa</c>, nên nó là mốc hàng rời kho SCS.
    /// </summary>
    [HttpPost("{id:long}/approve-scs")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ApproveScs>]
    public async Task<ActionResult<BackRequestResponse>> ApproveScs(
        long id, [FromBody] BackRequestDecisionRequest request)
        => Ok(await _service.ApproveScsAsync(id, request));

    /// <summary>
    /// Huỷ yêu cầu. Nhận cả ba quyền của ba bên: ai đang giữ bước cũng phải
    /// dừng được, chứ không phải chờ bên kia. Service chặn khi đã duyệt xong B4
    /// — lúc đó hàng ở FA rồi, huỷ là mất dấu lô hàng.
    /// </summary>
    [HttpPost("{id:long}/cancel")]
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.RequestBack,
                          Perms.Receiving.ReworkRefurbish.ApproveFa,
                          Perms.Receiving.ReworkRefurbish.ApproveScs>]
    public async Task<ActionResult<BackRequestResponse>> Cancel(
        long id, [FromBody] BackRequestDecisionRequest request)
        => Ok(await _service.CancelAsync(id, request));
}
