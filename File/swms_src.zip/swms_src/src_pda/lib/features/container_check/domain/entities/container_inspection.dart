import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';

/// Hạng mục kiểm tình trạng container. [code] gửi lên server — đổi nhãn
/// thoải mái nhưng KHÔNG đổi code, báo cáo phía web đang group theo nó.
enum ContainerCondition {
  floor('floor', LocaleKeys.container_check_cond_floor),
  dry('dry', LocaleKeys.container_check_cond_dry),
  intact('intact', LocaleKeys.container_check_cond_intact),
  door('door', LocaleKeys.container_check_cond_door);

  const ContainerCondition(this.code, this.labelKey);
  final String code;
  final String labelKey;
}

/// 4 góc chụp bắt buộc — mỗi góc đúng 1 ảnh để QA đối chiếu cùng một khung
/// hình giữa các container.
enum ContainerPhotoSlot {
  outside('outside', LocaleKeys.container_check_photo_outside),
  inside('inside', LocaleKeys.container_check_photo_inside),
  floor('floor', LocaleKeys.container_check_photo_floor),
  doorSeal('door_seal', LocaleKeys.container_check_photo_door_seal);

  const ContainerPhotoSlot(this.code, this.labelKey);
  final String code;
  final String labelKey;
}

enum InspectionResult {
  pass('pass'),

  /// Không đạt → container bị trả về đi rửa, hãng tàu cấp lại.
  fail('fail');

  const InspectionResult(this.code);
  final String code;
}

/// Dữ liệu gửi khi chốt kết quả kiểm.
class ContainerInspection {
  final int containerId;
  final InspectionResult result;
  final Set<ContainerCondition> passedConditions;
  final Map<ContainerPhotoSlot, String> photos;

  /// Bắt buộc khi [InspectionResult.fail] — lý do để hãng tàu xử lý.
  final String? note;

  const ContainerInspection({
    required this.containerId,
    required this.result,
    required this.passedConditions,
    required this.photos,
    this.note,
  });
}
