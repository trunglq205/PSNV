using Swms.FinishGoods.API.Features.StorageMap.Business;
using Swms.FinishGoods.API.Features.StorageMap.DataAccess;

namespace Swms.FinishGoods.API.Features.StorageMap;

public static class StorageMapModule
{
    public static IServiceCollection AddStorageMapFeature(this IServiceCollection services)
    {
        services.AddScoped<IStorageMapService, StorageMapService>();
        services.AddScoped<IStorageMapRepository, StorageMapRepository>();
        return services;
    }
}
