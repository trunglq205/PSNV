using Swms.FinishGoods.API.Features.Stocktake.Business;
using Swms.FinishGoods.API.Features.Stocktake.DataAccess;

namespace Swms.FinishGoods.API.Features.Stocktake;

public static class StocktakeModule
{
    public static IServiceCollection AddStocktakeFeature(this IServiceCollection services)
    {
        services.AddScoped<IStocktakeService, StocktakeService>();
        services.AddScoped<IStocktakeRepository, StocktakeRepository>();
        return services;
    }
}
