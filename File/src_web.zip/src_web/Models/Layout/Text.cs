﻿namespace SWMS_WebTool.Models.Layout
{
    public class Text: Widget
    {
        public Text() { }

        public Text(KonvaObject konvaObject) : base(konvaObject) {
            Label = konvaObject.Attrs.Text ?? "";
            FontSize = konvaObject.Attrs.FontSize ?? 150;
            FontStyle = konvaObject.Attrs.FontStyle ?? "bold";
            Align = konvaObject.Attrs.Align;
            VertialAlign = konvaObject.Attrs.VertialAlign;
        }
        public override WidgetType Type => WidgetType.Text;
        protected override KonvaClassType ClassName => KonvaClassType.Text;


        public string Label { get; set; }
        public double FontSize { get; set; } = 150;
        public string FontStyle  { get; set; } = "bold";
        public string? Align  { get; set; }
        public string? VertialAlign  { get; set; }
        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.Text = Label;
            attrs.FontSize = FontSize;
            attrs.FontStyle = FontStyle;
            attrs.Align = Align;
            attrs.VertialAlign = VertialAlign;
            return attrs;
        }
    }
}
