using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.Auth;

public record LoginRequest(
    [Required] string Username,
    [Required] string Password);

// access token + thông tin tối thiểu để web hiển thị / phân quyền.
public record LoginResponse(
    string AccessToken,
    DateTime ExpiresAtUtc,
    string Username,
    string FullName);
