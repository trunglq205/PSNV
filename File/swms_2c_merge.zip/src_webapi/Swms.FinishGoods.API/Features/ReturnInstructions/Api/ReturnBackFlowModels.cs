using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// B1 — FA đề nghị nhận lại hàng. CHỈ CÓ ghi chú.
///
/// Không có model, không có số lượng, không có danh sách dòng: đã đề nghị lấy
/// hàng về là lấy TOÀN BỘ phần phiếu còn ở kho. Không có ô nào để nhập một
/// phần, kể cả khi gọi API trực tiếp.
/// </summary>
public record RequestBackRequest([StringLength(500)] string? Note);

/// <summary>Xác nhận / huỷ — một ô ý kiến, dùng chung.</summary>
public record BackDecisionRequest([StringLength(500)] string? Comment);

/// <summary>
/// B3 — SCS WH quét Pallet ID giao hàng cho FA.
///
/// Nhận NHIỀU mã trong một lượt: WH quét cả xe rồi bấm xác nhận một lần, và FA
/// nhận MỘT lá thư liệt kê đủ pallet thay vì mỗi pallet một lá.
/// </summary>
public record DeliverBackRequest(
    [Required, MinLength(1)] List<string>? LotNos,
    [StringLength(500)] string? Comment);

/// <summary>
/// Trạng thái luồng nhận lại hàng của một phiếu.
///
/// Đi KÈM response của phiếu (<c>ReturnInstructionResponse.Back</c>) chứ không
/// phải một tài nguyên riêng: sau khi gộp thì nó là một mặt của phiếu, và tách
/// response là buộc màn hình gọi hai lần cho một dòng.
///
/// <see cref="Step"/> null = FA chưa đề nghị gì. Màn hình cần phân biệt chuyện
/// đó với "đang chờ quản lý FA", nên không quy về chuỗi rỗng.
/// </summary>
public record BackFlowResponse(
    string? Status,
    string? Step,
    bool Requested,
    bool IsOpen,
    bool IsDelivered,
    bool IsPartlyDelivered,
    bool IsCancelled,
    bool CanRequest,
    int RemainQty,
    int SentQty,
    int AtFaQty,
    int ReturnedQty,
    string? Note,
    string? RequestedBy,
    DateTime? RequestedAt,
    string? ApprovedBy,
    DateTime? ApprovedAt,
    string? FaComment,
    string? DeliveredBy,
    DateTime? DeliveredAt,
    string? ScsComment,
    string? CancelledBy,
    DateTime? CancelledAt,
    string? CancelReason)
{
    public static BackFlowResponse From(ReturnInstruction d) => new(
        d.BackStatus, d.BackStep,
        d.BackRequested, d.BackIsOpen, d.BackIsDelivered,
        d.BackIsPartlyDelivered, d.BackIsCancelled, d.CanRequestBack,
        d.BackRemainQty, d.BackSentQty, d.AtFaQty, d.BackReturnedQty,
        d.BackNote,
        d.BackRequestedBy, d.BackRequestedAt,
        d.BackApprovedBy, d.BackApprovedAt, d.BackFaComment,
        d.BackDeliveredBy, d.BackDeliveredAt, d.BackScsComment,
        d.BackCancelledBy, d.BackCancelledAt, d.BackCancelReason);
}

/// <summary>Một pallet đã giao.</summary>
public record BackDeliveryResponse(
    string LotNo,
    int SerialCount,
    DateTime DeliveredAt,
    string? DeliveredBy)
{
    public static BackDeliveryResponse From(ReturnBackDelivery d) => new(
        d.LotNo, d.SerialCount, d.DeliveredAt, d.DeliveredBy);
}

/// <summary>SL còn ở kho theo model — màn đề nghị gọi để CHO XEM.</summary>
public record BackRemainModelResponse(string Model, int Qty)
{
    public static BackRemainModelResponse From(BackModelQty m) => new(m.Model, m.Qty);
}

/// <summary>
/// Kết quả MỘT lượt quét giao hàng.
///
/// Trả cả <see cref="Back"/> đã cập nhật để PDA không phải gọi thêm một lần GET
/// chỉ để biết còn bao nhiêu con — máy quét thường ở chỗ sóng kém.
///
/// <see cref="NotFoundLots"/> là mã hệ thống không có; <see cref="EmptyLots"/>
/// là pallet có thật nhưng không còn con nào của phiếu. Hai danh sách riêng vì
/// WH xử lý khác nhau: cái đầu là quét sai mã, cái sau là pallet đã rỗng.
/// </summary>
public record BackDeliverResponse(
    int DeliveredQty,
    int RemainQty,
    bool Completed,
    List<BackDeliveryResponse> Pallets,
    List<string> NotFoundLots,
    List<string> EmptyLots,
    BackFlowResponse Back)
{
    public static BackDeliverResponse From(
        ReturnBackDeliverResult r, ReturnInstruction doc) => new(
        r.DeliveredQty,
        r.RemainQty,
        r.Completed,
        r.Pallets.Where(p => p.SerialCount > 0).Select(BackDeliveryResponse.From).ToList(),
        r.NotFoundLots.ToList(),
        r.Pallets.Where(p => p.SerialCount == 0).Select(p => p.LotNo).ToList(),
        BackFlowResponse.From(doc));
}

/// <summary>
/// Khoá resource cho thông báo của luồng nhận lại hàng. Giữ ở một chỗ để resx
/// và code không lệch nhau — cùng cách <c>ReturnMsg</c> làm.
/// </summary>
public static class BackMsg
{
    /// <summary>Phiếu không tồn tại.</summary>
    public const string DocNotFound = "Return.Back.Err.DocNotFound";

    /// <summary>Phiếu đã huỷ — không đề nghị được.</summary>
    public const string DocCancelled = "Return.Back.Err.DocCancelled";

    /// <summary>Phiếu không còn con nào ở kho để lấy về.</summary>
    public const string NothingAvailable = "Return.Back.Err.NothingAvailable";

    /// <summary>Đã có luồng back đang chạy hoặc đã xong.</summary>
    public const string AlreadyRequested = "Return.Back.Err.AlreadyRequested";

    /// <summary>Chưa ai đề nghị nhận lại hàng cho phiếu này.</summary>
    public const string NotRequested = "Return.Back.Err.NotRequested";

    /// <summary>Không ở đúng bước — thường là có người vừa xử lý trước.</summary>
    public const string WrongStep = "Return.Back.Err.WrongStep";

    /// <summary>Chỉ sửa được ghi chú khi còn chờ quản lý FA.</summary>
    public const string NotEditable = "Return.Back.Err.NotEditable";

    /// <summary>Đã giao xong — không sửa, không huỷ được nữa.</summary>
    public const string AlreadyDelivered = "Return.Back.Err.AlreadyDelivered";

    /// <summary>Đã giao dở — hàng ở FA rồi, không huỷ được.</summary>
    public const string PartlyDelivered = "Return.Back.Err.PartlyDelivered";

    /// <summary>Lượt giao không có mã pallet nào.</summary>
    public const string LotsRequired = "Return.Back.Err.LotsRequired";

    public const string TooManyLots = "Return.Back.Err.TooManyLots";

    /// <summary>Mọi mã quét ra đều không có trong hệ thống.</summary>
    public const string LotNotFound = "Return.Back.Err.LotNotFound";

    /// <summary>Pallet có thật nhưng không còn con nào của phiếu này.</summary>
    public const string NothingToDeliver = "Return.Back.Err.NothingToDeliver";

    public const string ValueTooLong = "Return.Back.Err.ValueTooLong";
}
