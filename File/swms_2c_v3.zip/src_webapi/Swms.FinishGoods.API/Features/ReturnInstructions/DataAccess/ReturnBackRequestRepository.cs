using Dapper;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

public class ReturnBackRequestRepository : IReturnBackRequestRepository
{
    /// <summary>
    /// Số id mỗi câu khi nạp dòng. Dapper trải <c>IN</c> thành từng parameter
    /// và SQL Server chỉ cho 2100 parameter một câu.
    /// </summary>
    private const int IdChunk = 1000;

    private readonly IDbConnectionFactory _factory;
    public ReturnBackRequestRepository(IDbConnectionFactory factory) => _factory = factory;

    /// <summary>
    /// Header + hai con số đếm từ SỔ SERIAL (đã gắp / đã về). Đếm bằng OUTER
    /// APPLY chứ không lưu cột: lưu là phải nhớ cập nhật ở mọi đường ghi serial
    /// — gắp, giao lại, huỷ lần nhận — và quên một đường là lệch vĩnh viễn.
    /// </summary>
    private const string HeaderSql = """
        SELECT  r.id                AS [Id],
                r.doc_id            AS [DocId],
                d.doc_no            AS [DocNo],
                d.goods_type        AS [GoodsType],
                r.req_no            AS [ReqNo],
                r.req_status        AS [ReqStatus],
                r.current_step      AS [CurrentStep],
                r.note              AS [Note],
                r.requested_by      AS [RequestedBy],
                r.requested_at      AS [RequestedAt],
                r.fa_approved_by    AS [FaApprovedBy],
                r.fa_approved_at    AS [FaApprovedAt],
                r.fa_comment        AS [FaComment],
                r.scs_comment       AS [ScsComment],
                r.delivered_by      AS [DeliveredBy],
                r.delivered_at      AS [DeliveredAt],
                r.cancelled_by      AS [CancelledBy],
                r.cancelled_at      AS [CancelledAt],
                r.cancel_reason     AS [CancelReason],
                r.created_at        AS [CreatedAt],
                r.created_by        AS [CreatedBy],
                r.updated_at        AS [UpdatedAt],
                r.updated_by        AS [UpdatedBy],
                ISNULL(s.assigned, 0) AS [AssignedQty],
                ISNULL(s.returned, 0) AS [ReturnedQty],
                ISNULL(s.at_fa,    0) AS [AtFaQty]
        FROM wms.return_back_requests r
        JOIN wms.return_instructions  d ON d.id = r.doc_id
        OUTER APPLY (
            -- assigned = đã từng giao FA (gồm cả đã về và đã đánh ng)
            -- returned = FA đã giao lại và SCS đã nhận
            -- at_fa    = ĐANG ở FA. Đếm thẳng status thay vì lấy
            --            assigned - returned: con đánh `ng` không còn chờ về,
            --            trừ kiểu kia sẽ cộng nó vào "đang ở FA" và SCS đi
            --            đòi một lô hàng không bao giờ tới.
            SELECT assigned = COUNT(*),
                   returned = SUM(IIF(x.status = N'returned', 1, 0)),
                   at_fa    = SUM(IIF(x.status = N'at_fa',    1, 0))
            FROM   wms.return_instruction_serials x
            WHERE  x.back_request_id = r.id AND x.is_deleted = 0
        ) s
        WHERE r.is_deleted = 0
        """;

    public async Task<IReadOnlyList<ReturnBackRequest>> GetListAsync(BackRequestQuery query)
    {
        var sql = HeaderSql + """

              AND (@docId  IS NULL OR r.doc_id = @docId)
              AND (@status IS NULL OR r.req_status = @status)
              AND (@step   IS NULL OR r.current_step = @step)
              AND (@kw IS NULL OR r.req_no LIKE @kw OR d.doc_no LIKE @kw
                   OR EXISTS (SELECT 1 FROM wms.return_back_request_lines l2
                              WHERE l2.request_id = r.id AND l2.is_deleted = 0
                                AND l2.model LIKE @kw))
            ORDER BY r.requested_at DESC, r.id DESC;
            """;

        using var conn = _factory.Create();
        var rows = (await conn.QueryAsync<ReturnBackRequest>(sql, new
        {
            docId = query.DocId,
            status = Blank(query.Status),
            step = Blank(query.Step),
            kw = Blank(query.Keyword) is { } k ? $"%{k}%" : null,
        })).ToList();

        if (rows.Count == 0) return rows;

        var lines = await LoadLinesAsync(conn, rows.Select(r => r.Id).ToList());
        foreach (var r in rows)
            r.Lines = lines.TryGetValue(r.Id, out var ls) ? ls : [];

        return rows;
    }

    public async Task<ReturnBackRequest?> GetByIdAsync(long id)
    {
        using var conn = _factory.Create();
        var req = await conn.QuerySingleOrDefaultAsync<ReturnBackRequest>(
            HeaderSql + "\n  AND r.id = @id;", new { id });
        if (req is null) return null;

        var lines = await LoadLinesAsync(conn, [id]);
        req.Lines = lines.TryGetValue(id, out var ls) ? ls : [];
        return req;
    }

    /// <summary>
    /// Dòng của nhiều yêu cầu bằng MỘT câu (tránh N+1), kèm hai con số đếm từ
    /// sổ serial theo từng model.
    /// </summary>
    private static async Task<Dictionary<long, List<ReturnBackRequestLine>>> LoadLinesAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> ids)
    {
        var map = new Dictionary<long, List<ReturnBackRequestLine>>();
        if (ids.Count == 0) return map;

        const string sql = """
            SELECT  l.id          AS [Id],
                    l.request_id  AS [RequestId],
                    l.line_no     AS [LineNo],
                    l.model       AS [Model],
                    l.qty         AS [Qty],
                    l.note        AS [Note],
                    ISNULL(s.assigned, 0) AS [AssignedQty],
                    ISNULL(s.returned, 0) AS [ReturnedQty]
            FROM wms.return_back_request_lines l
            OUTER APPLY (
                SELECT assigned = COUNT(*),
                       returned = SUM(IIF(x.status = N'returned', 1, 0))
                FROM   wms.return_instruction_serials x
                WHERE  x.back_request_id = l.request_id
                  AND  x.model = l.model
                  AND  x.is_deleted = 0
            ) s
            WHERE l.request_id IN @ids AND l.is_deleted = 0
            ORDER BY l.request_id, l.line_no, l.id;
            """;

        for (var i = 0; i < ids.Count; i += IdChunk)
        {
            var chunk = ids.Skip(i).Take(IdChunk).ToList();
            var rows = await conn.QueryAsync<ReturnBackRequestLine>(sql, new { ids = chunk });
            foreach (var r in rows)
            {
                if (!map.TryGetValue(r.RequestId, out var list))
                    map[r.RequestId] = list = [];
                list.Add(r);
            }
        }
        return map;
    }

    public async Task<long> AddAsync(ReturnBackRequest req, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var reqNo = await NextReqNoAsync(conn, tx);

            var id = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.return_back_requests
                    (doc_id, req_no, req_status, current_step, note,
                     requested_by, requested_at, is_deleted, created_at, created_by)
                VALUES
                    (@docId, @reqNo, @status, @step, @note,
                     @user, SYSDATETIME(), 0, SYSDATETIME(), @user);
                SELECT CAST(SCOPE_IDENTITY() AS bigint);
                """, new
            {
                docId = req.DocId,
                reqNo,
                status = ReturnBackStatus.FaRequested,
                step = ReturnBackStep.FaApprove,
                note = req.Note,
                user,
            }, tx);

            await InsertLinesAsync(conn, tx, id, req.Lines, user);

            tx.Commit();
            return id;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    /// <summary>
    /// Số yêu cầu dạng <c>BK-yyyyMMdd-001</c>. Cùng khuôn với doc_no của chỉ
    /// thị nhận hàng.
    ///
    /// UPDLOCK + HOLDLOCK trong transaction: hai người bấm Tạo cùng lúc mà
    /// không khoá thì cả hai đọc cùng số lớn nhất rồi cùng ghi, và
    /// <c>ux_rbr_req_no</c> cho một người ăn lỗi 2601 giữa màn hình.
    ///
    /// Đọc CẢ dòng đã xoá mềm: xoá rồi cấp lại đúng số đó sẽ làm hai yêu cầu
    /// khác nhau trùng số trong lịch sử.
    /// </summary>
    private static async Task<string> NextReqNoAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx)
    {
        var prefix = $"{ReturnBackStatus.ReqPrefix}-{DateTime.Now:yyyyMMdd}-";
        var next = await conn.ExecuteScalarAsync<int>("""
            SELECT ISNULL(MAX(TRY_CONVERT(int, RIGHT(req_no, 3))), 0) + 1
            FROM   wms.return_back_requests WITH (UPDLOCK, HOLDLOCK)
            WHERE  req_no LIKE @prefix + '[0-9][0-9][0-9]';
            """, new { prefix }, tx);
        return prefix + next.ToString("D3");
    }

    private static async Task InsertLinesAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx,
        long requestId, IReadOnlyList<ReturnBackRequestLine> lines, string? user)
    {
        const string sql = """
            INSERT INTO wms.return_back_request_lines
                (request_id, line_no, model, qty, note,
                 is_deleted, created_at, created_by)
            VALUES (@requestId, @lineNo, @model, @qty, @note,
                    0, SYSDATETIME(), @user);
            """;

        var n = 0;
        foreach (var l in lines)
        {
            n++;
            await conn.ExecuteAsync(sql, new
            {
                requestId,
                lineNo = n,
                model = l.Model,
                qty = l.Qty,
                note = l.Note,
                user,
            }, tx);
        }
    }

    public async Task UpdateLinesAsync(
        long id, string? note, IReadOnlyList<ReturnBackRequestLine> lines, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            await conn.ExecuteAsync("""
                UPDATE wms.return_back_requests
                SET    note = @note, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  id = @id AND is_deleted = 0;
                """, new { id, note, user }, tx);

            // Xoá MỀM dòng cũ rồi chèn mới, không UPDATE từng dòng: dòng có thể
            // bị bỏ hẳn hoặc đổi model, mà sổ serial khớp theo MODEL chứ không
            // theo line_id nên xoá mềm không làm mất liên kết nào.
            await conn.ExecuteAsync("""
                UPDATE wms.return_back_request_lines
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  request_id = @id AND is_deleted = 0;
                """, new { id, user }, tx);

            await InsertLinesAsync(conn, tx, id, lines, user);

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public async Task<bool> ApplyStepAsync(
        long id, string fromStep, string toStep, string toStatus,
        string actorColumnPrefix, string? comment, string? user)
    {
        // actorColumnPrefix chỉ nhận giá trị từ hằng số trong service (fa_approved
        // / scs_instructed / scs_approved) nên nội suy vào SQL là an toàn; vẫn
        // kiểm lại ở đây để không bao giờ có đường nào nối chuỗi từ request.
        if (actorColumnPrefix is not "fa_approved")
            throw new ArgumentOutOfRangeException(nameof(actorColumnPrefix), actorColumnPrefix,
                "Cột người thao tác không hợp lệ.");

        var commentColumn = actorColumnPrefix switch
        {
            "fa_approved" => ", fa_comment = @comment",
            _ => "",
        };

        var sql = $"""
            UPDATE wms.return_back_requests
            SET    req_status            = @toStatus,
                   current_step          = @toStep,
                   {actorColumnPrefix}_by = @user,
                   {actorColumnPrefix}_at = SYSDATETIME(){commentColumn},
                   updated_at            = SYSDATETIME(),
                   updated_by            = @user
            WHERE  id = @id
              AND  is_deleted   = 0
              AND  current_step = @fromStep
              AND  req_status  <> N'cancelled';
            """;

        using var conn = _factory.Create();
        var n = await conn.ExecuteAsync(sql, new
        {
            id, fromStep, toStep, toStatus, comment, user,
        });
        return n > 0;
    }

    public async Task<bool> CancelAsync(long id, string? reason, string? user)
    {
        using var conn = _factory.Create();
        // Điều kiện nằm TRONG câu UPDATE: huỷ một yêu cầu đã cho back là mất
        // dấu hàng đang ở FA, nên chặn bằng chính câu ghi chứ không kiểm trước.
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_back_requests
            SET    req_status    = N'cancelled',
                   current_step  = N'done',
                   cancelled_by  = @user,
                   cancelled_at  = SYSDATETIME(),
                   cancel_reason = @reason,
                   updated_at    = SYSDATETIME(),
                   updated_by    = @user
            WHERE  id = @id
              AND  is_deleted = 0
              AND  req_status NOT IN (N'delivered', N'cancelled');
            """, new { id, reason, user });
        return n > 0;
    }

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA.
    ///
    /// GIAO THEO PALLET, không gắp FIFO theo số lượng: đã đề nghị lấy về là lấy
    /// hết, nên hàng đi theo cả pallet và serial lấy đúng theo pallet đã quét.
    ///
    /// Mọi pallet trong một lượt nằm trong MỘT transaction: quét 5 pallet mà
    /// pallet thứ 4 lỗi thì không được để 3 pallet đã chuyển còn 2 thì không —
    /// FA sẽ nhận một lô hàng mà hệ thống nói khác.
    /// </summary>
    public async Task<ReturnBackDeliverResult> DeliverPalletsAsync(
        long id, IReadOnlyList<string> lotNos, string? comment, string? user)
    {
        var result = new ReturnBackDeliverResult();

        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // 1) Khoá dòng yêu cầu và kiểm bước NGAY TRONG câu đọc: hai người
            //    cùng giao một lúc thì người thứ hai chờ ở đây chứ không chuyển
            //    trùng serial.
            var head = await conn.QuerySingleOrDefaultAsync<(long DocId, string Step, string Status)>("""
                SELECT doc_id, current_step, req_status
                FROM   wms.return_back_requests WITH (UPDLOCK, HOLDLOCK)
                WHERE  id = @id AND is_deleted = 0;
                """, new { id }, tx);

            if (head.DocId == 0)
            {
                tx.Rollback();
                result.NotFound = true;
                return result;
            }

            if (head.Step != ReturnBackStep.ScsDeliver || head.Status == ReturnBackStatus.Cancelled)
            {
                tx.Rollback();
                result.WrongStep = true;
                return result;
            }

            // 2) Từng pallet một. Điều kiện status = 'received' nằm TRONG WHERE
            //    nên quét lại cùng một pallet chuyển 0 con thay vì ghi đè
            //    sent_fa_at của lần giao thật.
            const string move = """
                UPDATE s
                SET    s.back_request_id = @id,
                       s.status          = N'at_fa',
                       s.sent_fa_at      = SYSDATETIME(),
                       s.updated_at      = SYSDATETIME(),
                       s.updated_by      = @user
                FROM   wms.return_instruction_serials s
                JOIN   wms.pallets p ON p.id = s.pallet_id
                WHERE  s.doc_id     = @docId
                  AND  RTRIM(p.pallet_id) = @lotNo
                  AND  s.status     = N'received'
                  AND  s.is_deleted = 0;
                """;

            foreach (var raw in lotNos)
            {
                var lotNo = raw?.Trim() ?? "";
                if (lotNo.Length == 0) continue;

                var palletId = await conn.ExecuteScalarAsync<long?>("""
                    SELECT TOP 1 p.id
                    FROM   wms.pallets p
                    WHERE  RTRIM(p.pallet_id) = @lotNo AND p.is_deleted = 0;
                    """, new { lotNo }, tx);

                if (palletId is null)
                {
                    result.NotFoundLots.Add(lotNo);
                    continue;
                }

                var n = await conn.ExecuteAsync(move, new { id, docId = head.DocId, lotNo, user }, tx);

                // Ghi nhật ký CẢ KHI 0 con: "đã quét pallet này mà không có gì
                // chuyển" là thông tin, không phải chuyện bỏ qua.
                await conn.ExecuteAsync("""
                    INSERT INTO wms.return_back_deliveries
                        (request_id, pallet_id, lot_no, serial_count, delivered_by)
                    VALUES (@id, @palletId, @lotNo, @n, @user);
                    """, new { id, palletId, lotNo, n, user }, tx);

                result.Pallets.Add(new ReturnBackDelivery
                {
                    RequestId = id,
                    PalletId = palletId,
                    LotNo = lotNo,
                    SerialCount = n,
                    DeliveredAt = DateTime.Now,
                    DeliveredBy = user,
                });
                result.DeliveredQty += n;
            }

            // 3) Hết con nào ở 'received' thì đóng đề nghị.
            //
            //    Đếm theo DOC, không theo dòng đề nghị: đề nghị bao trọn phần
            //    còn lại của phiếu, nên "còn con received" và "còn hàng chưa
            //    giao" là cùng một câu hỏi.
            result.RemainQty = await conn.ExecuteScalarAsync<int>("""
                SELECT COUNT(*)
                FROM   wms.return_instruction_serials s
                WHERE  s.doc_id          = @docId
                  AND  s.status          = N'received'
                  AND  s.back_request_id IS NULL
                  AND  s.is_deleted      = 0;
                """, new { docId = head.DocId }, tx);

            if (result.RemainQty == 0)
            {
                await conn.ExecuteAsync("""
                    UPDATE wms.return_back_requests
                    SET    req_status   = N'delivered',
                           current_step = N'done',
                           delivered_by = @user,
                           delivered_at = SYSDATETIME(),
                           scs_comment  = @comment,
                           updated_at   = SYSDATETIME(),
                           updated_by   = @user
                    WHERE  id = @id;
                    """, new { id, comment, user }, tx);
                result.Completed = true;
            }
            else if (!string.IsNullOrWhiteSpace(comment))
            {
                // Chưa xong nhưng kho có ghi chú — giữ lại, đừng để nó rơi.
                await conn.ExecuteAsync("""
                    UPDATE wms.return_back_requests
                    SET    scs_comment = @comment,
                           updated_at  = SYSDATETIME(),
                           updated_by  = @user
                    WHERE  id = @id;
                    """, new { id, comment, user }, tx);
            }

            tx.Commit();
            return result;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    /// <summary>Nhật ký pallet đã giao của một đề nghị, mới nhất trước.</summary>
    public async Task<IReadOnlyList<ReturnBackDelivery>> GetDeliveriesAsync(long requestId)
    {
        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<ReturnBackDelivery>("""
            SELECT id           AS [Id],
                   request_id   AS [RequestId],
                   pallet_id    AS [PalletId],
                   lot_no       AS [LotNo],
                   serial_count AS [SerialCount],
                   delivered_at AS [DeliveredAt],
                   delivered_by AS [DeliveredBy]
            FROM   wms.return_back_deliveries
            WHERE  request_id = @requestId
            ORDER BY delivered_at DESC, id DESC;
            """, new { requestId });
        return rows.ToList();
    }

    public async Task<IReadOnlyList<BackAvailableModelResponse>> GetAvailableAsync(long docId)
    {
        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<BackAvailableModelResponse>("""
            SELECT s.model          AS Model,
                   COUNT(*)         AS AvailableQty
            FROM   wms.return_instruction_serials s
            WHERE  s.doc_id          = @docId
              AND  s.status          = N'received'
              AND  s.back_request_id IS NULL
              AND  s.is_deleted      = 0
            GROUP BY s.model
            ORDER BY s.model;
            """, new { docId });
        return rows.ToList();
    }

    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}
