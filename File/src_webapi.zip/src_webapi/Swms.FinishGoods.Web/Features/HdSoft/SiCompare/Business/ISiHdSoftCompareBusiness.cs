using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business.Models;
using Swms.FinishGoods.Web.Features.ShipmentInstruction.Business.Models;

namespace Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business;

public interface ISiHdSoftCompareBusiness
{
    /// <summary>SI có vanning trong [from, to] ở SWMS hoặc HD soft. warehouse "" = mọi kho.</summary>
    Task<Result<AppSiCompareList>> GetListAsync(DateTime from, DateTime to, string warehouse);

    /// <summary>Chi tiết đối chiếu 1 SI.</summary>
    Task<Result<AppSiCompare>> GetDetailAsync(string siNo);

    /// <summary>Tạo SI SWMS từ kết quả so (đã qua SiHdSoftCreate.Check). Gọi POST /api/shipment-instructions.</summary>
    Task<Result<AppShipmentInstruction>> CreateFromHdSoftAsync(AppSiCompare detail);

    /// <summary>Hoàn thành SI phía SWMS (POST /api/shipment-instructions/{id}/complete) — cùng API nút Hoàn thành ở danh sách SI.</summary>
    Task<Result> CompleteSwmsAsync(long swmsId);
}