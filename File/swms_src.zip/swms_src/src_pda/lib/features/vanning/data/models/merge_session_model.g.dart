// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'merge_session_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

MergeCandidateModel _$MergeCandidateModelFromJson(Map<String, dynamic> json) =>
    MergeCandidateModel(
      code: json['code'] as String,
      type: json['type'] as String,
      locatorCode: json['locatorCode'] as String?,
      boxCount: (json['boxCount'] as num).toInt(),
      pcs: (json['pcs'] as num).toInt(),
    );

TripStackModel _$TripStackModelFromJson(Map<String, dynamic> json) =>
    TripStackModel(
      cocNo: (json['cocNo'] as num).toInt(),
      code: json['code'] as String?,
      bottomCode: json['bottomCode'] as String,
      topCode: json['topCode'] as String?,
      placedAt: json['placedAt'] == null
          ? null
          : DateTime.parse(json['placedAt'] as String),
    );

MergePlanBoxModel _$MergePlanBoxModelFromJson(Map<String, dynamic> json) =>
    MergePlanBoxModel(
      seq: (json['seq'] as num).toInt(),
      boxNo: json['boxNo'] as String,
      model: json['model'] as String?,
      status: json['status'] as String,
      palletCode: json['palletCode'] as String?,
      locatorCode: json['locatorCode'] as String?,
      pcs: (json['pcs'] as num?)?.toInt() ?? 0,
    );

MergeSourceModel _$MergeSourceModelFromJson(Map<String, dynamic> json) =>
    MergeSourceModel(
      palletCode: json['palletCode'] as String,
      locatorCode: json['locatorCode'] as String?,
      needed: (json['needed'] as num).toInt(),
      boxCount: (json['boxCount'] as num).toInt(),
      whole: json['whole'] as bool,
    );

MergeTierModel _$MergeTierModelFromJson(Map<String, dynamic> json) =>
    MergeTierModel(
      tier: (json['tier'] as num).toInt(),
      planPalletCode: json['planPalletCode'] as String,
      palletCode: json['palletCode'] as String?,
      complete: json['complete'] as bool? ?? false,
      isThis: json['isThis'] as bool? ?? false,
      done: (json['done'] as num?)?.toInt() ?? 0,
      total: (json['total'] as num?)?.toInt() ?? 0,
    );

MergeColumnModel _$MergeColumnModelFromJson(Map<String, dynamic> json) =>
    MergeColumnModel(
      code: json['code'] as String,
      cocNo: (json['cocNo'] as num).toInt(),
      tiers:
          (json['tiers'] as List<dynamic>?)
              ?.map((e) => MergeTierModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const <MergeTierModel>[],
      stackedBottom: json['stackedBottom'] as String?,
      stackedTop: json['stackedTop'] as String?,
      placed: json['placed'] as bool? ?? false,
    );

MergePlanModel _$MergePlanModelFromJson(Map<String, dynamic> json) =>
    MergePlanModel(
      planNo: json['planNo'] as String,
      palletCode: json['palletCode'] as String,
      columnCode: json['columnCode'] as String?,
      tier: (json['tier'] as num?)?.toInt() ?? 1,
      siNo: json['siNo'] as String?,
      palletSize: json['palletSize'] as String?,
      boxes:
          (json['boxes'] as List<dynamic>?)
              ?.map(
                (e) => MergePlanBoxModel.fromJson(e as Map<String, dynamic>),
              )
              .toList() ??
          const <MergePlanBoxModel>[],
      sources:
          (json['sources'] as List<dynamic>?)
              ?.map((e) => MergeSourceModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const <MergeSourceModel>[],
      extra:
          (json['extra'] as List<dynamic>?)?.map((e) => e as String).toList() ??
          const <String>[],
      column: json['column'] == null
          ? null
          : MergeColumnModel.fromJson(json['column'] as Map<String, dynamic>),
    );

MergeSessionModel _$MergeSessionModelFromJson(Map<String, dynamic> json) =>
    MergeSessionModel(
      baseCode: json['baseCode'] as String,
      isNewList: json['isNewList'] as bool? ?? false,
      siCode: json['siCode'] as String?,
      route: json['route'] as String?,
      baseBoxCount: (json['baseBoxCount'] as num?)?.toInt() ?? 0,
      basePcs: (json['basePcs'] as num?)?.toInt() ?? 0,
      candidates:
          (json['candidates'] as List<dynamic>?)
              ?.map(
                (e) => MergeCandidateModel.fromJson(e as Map<String, dynamic>),
              )
              .toList() ??
          const [],
      stacks:
          (json['stacks'] as List<dynamic>?)
              ?.map((e) => TripStackModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
      plan: json['plan'] == null
          ? null
          : MergePlanModel.fromJson(json['plan'] as Map<String, dynamic>),
    );

Map<String, dynamic> _$MergeRequestModelToJson(MergeRequestModel instance) =>
    <String, dynamic>{
      'baseCode': instance.baseCode,
      'palletCodes': instance.palletCodes,
      'boxCodes': instance.boxCodes,
      'doublePallet': instance.doublePallet,
      'confirmModelMismatch': instance.confirmModelMismatch,
    };

MergeResultModel _$MergeResultModelFromJson(Map<String, dynamic> json) =>
    MergeResultModel(
      palletListCode: json['palletListCode'] as String,
      boxCount: (json['boxCount'] as num).toInt(),
      pcs: (json['pcs'] as num).toInt(),
      cocNo: (json['cocNo'] as num?)?.toInt(),
    );
