using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.MapView.DataAccess;

/// <summary>
/// Đọc layout + trạng thái hàng của 1 bản đồ — DÙNG CHUNG cho mọi map_type.
/// Gộp 2 nguồn: kệ (tỉ lệ chiếm chỗ theo locator con) và ô pallet (trạng thái kiểm theo lot).
/// </summary>
public class MapViewRepository : IMapViewRepository
{
    private readonly IDbConnectionFactory _factory;
    public MapViewRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<MapViewLayout?> GetLayoutAsync(string areaCode)
    {
        using var conn = _factory.Create();

        const string areaSql = """
            SELECT id AS AreaId, area_code AS AreaCode, area_name AS AreaName,
                   map_type AS MapType, cols AS Cols, rows AS Rows, cell_meters AS CellMeters
            FROM master.warehouse_areas
            WHERE area_code = @areaCode AND is_deleted = 0;
            """;
        var layout = await conn.QueryFirstOrDefaultAsync<MapViewLayout>(areaSql, new { areaCode });
        if (layout is null) return null;

        // 1) Khối trên lưới + tổng/chiếm chỗ của kệ + trạng thái ô pallet.
        const string blocksSql = """
            SELECT  m.id            AS Id,
                    m.target_type   AS Kind,
                    m.grid_x        AS GridX,
                    m.grid_y        AS GridY,
                    m.grid_w        AS GridW,
                    m.grid_h        AS GridH,
                    m.label         AS Label,
                    m.color         AS Color,
                    m.arrow         AS Arrow,
                    r.id            AS RackId,
                    r.rack_code     AS RackCode,
                    ISNULL(rc.TotalSlots, 0)    AS TotalSlots,
                    ISNULL(rc.OccupiedSlots, 0) AS OccupiedSlots,
                    l.id            AS LocatorId,
                    l.locator_code  AS LocatorCode
            FROM        master.locator_map m
            LEFT JOIN   master.racks    r ON r.id = m.rack_id    AND r.is_deleted = 0
            LEFT JOIN   master.locators l ON l.id = m.locator_id AND l.is_deleted = 0
            OUTER APPLY (
                /* Đếm theo Ô, không theo LÔ: một ô chứa được nhiều lô
                   (wms.pallets nhiều dòng cùng locator_id), LEFT JOIN nhân ô
                   đó ra nhiều dòng nên COUNT/SUM thường sẽ đếm lô. Xem ghi chú
                   dài ở posSql bên dưới. */
                SELECT COUNT(DISTINCT x.id) AS TotalSlots,
                       COUNT(DISTINCT CASE WHEN p.id IS NOT NULL THEN x.id END) AS OccupiedSlots
                FROM      master.locators x
                LEFT JOIN wms.pallets p ON p.locator_id = x.id AND p.is_deleted = 0
                WHERE x.rack_id = m.rack_id AND x.is_deleted = 0
            ) rc
            WHERE m.parent_type = N'area' AND m.parent_id = @areaId AND m.is_deleted = 0
            ORDER BY m.sort_order, m.id;
            """;
        var blocks = (await conn.QueryAsync<MapViewBlock>(blocksSql, new { areaId = layout.AreaId })).ToList();

        // DB dùng target_type = 'locator'; UI gọi là 'pallet'.
        foreach (var b in blocks)
            if (b.Kind == "locator") b.Kind = "pallet";

        // 2) Tồn theo từng vị trí (cột) của mọi kệ -> tô từng khoang trên khối kệ.
        const string posSql = """
            SELECT  l.rack_id  AS RackId,
                    l.rack_col AS Position,
                    /* PHẢI là COUNT(DISTINCT l.id), KHÔNG phải COUNT(l.id).
                       Một ô có thể chứa NHIỀU lô. LEFT JOIN nhân ô đó ra nhiều
                       dòng, nên COUNT(l.id) đếm số LÔ chứ không đếm số Ô: vị
                       trí 5 tầng mà 2 tầng mỗi tầng 2 lô sẽ ra 7, và vì tầng
                       nào cũng có hàng nên Occupied cũng 7 -> hiện "7/7". */
                    COUNT(DISTINCT l.id) AS Total,
                    /* Ô CÓ HÀNG, đếm theo ô. CASE trả NULL cho ô trống và
                       COUNT bỏ qua NULL nên ô trống không bị tính. */
                    COUNT(DISTINCT CASE WHEN p.id IS NOT NULL THEN l.id END) AS Occupied
            FROM        master.locators l
            JOIN        master.racks r ON r.id = l.rack_id AND r.is_deleted = 0
            LEFT JOIN   wms.pallets  p ON p.locator_id = l.id AND p.is_deleted = 0
            WHERE r.area_id = @areaId AND l.is_deleted = 0
            GROUP BY l.rack_id, l.rack_col;
            """;
        var posList = (await conn.QueryAsync<RackPositionOcc>(posSql, new { areaId = layout.AreaId })).ToList();
        var byRack = posList.GroupBy(x => x.RackId)
                            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Position).ToList());
        foreach (var b in blocks)
            if (b.RackId is long rid && byRack.TryGetValue(rid, out var ps))
                b.Positions = ps;

        // 3) Lot trên các ô pallet của khu.
        const string lotsSql = """
            SELECT  p.locator_id       AS LocatorId,
                    p.id               AS LotId,
                    p.pallet_id        AS PalletId,
                    p.inspection_status AS Status,
                    p.is_urgent        AS IsUrgent,
                    p.box_count        AS BoxCount,
                    p.production_date  AS ProductionDate,
                    -- Pallet box_count không có box_lines -> model nằm ở cột
                    -- pallets.model. Thiếu COALESCE thì loại này hiện model trống
                    -- trên bản đồ Vanning. Cùng quy ước với LocationInfoSql.
                    COALESCE(mo.models, p.model) AS Model,
                    -- Dấu RW/RB. Pallet tái gia công mang inspection_status 'ng'
                    -- suốt vòng đời nên trên bản đồ nó trông y hệt pallet bị OQC
                    -- đánh fail — mà một bên là hàng chờ giao cho FA, một bên là
                    -- hàng lỗi phải xử lý.
                    --
                    -- Lùi về goods_type của phiếu khi cột disposition chưa có dấu
                    -- (dữ liệu cũ) — cùng cách với LocationInfoSql.
                    --
                    -- ⚠ Dapper map ValueTuple theo THỨ TỰ CỘT, nên cột này phải
                    -- nằm CUỐI và thành viên tuple cũng phải thêm vào cuối.
                    COALESCE(p.disposition, rb.goods_type) AS Disposition
            FROM        wms.pallets p
            JOIN        master.locators l ON l.id = p.locator_id AND l.is_deleted = 0
            OUTER APPLY (
                SELECT TOP 1 d.goods_type AS goods_type
                FROM   wms.return_instruction_serials ris
                JOIN   wms.return_instructions d
                       ON d.id = ris.doc_id AND d.is_deleted = 0
                WHERE  ris.pallet_id = p.id
                  AND  ris.is_deleted = 0
                ORDER BY ris.id DESC
            ) rb
            OUTER APPLY (
                SELECT STRING_AGG(x.model, ', ') AS models
                FROM (
                    SELECT DISTINCT bl.model
                    FROM wms.boxes lb
                    JOIN wms.box_lines bl ON bl.box_id = lb.id AND bl.is_deleted = 0
                    -- lb.is_deleted: thiếu thì thùng đã xoá mềm vẫn góp model.
                    WHERE lb.lot_id = p.id AND lb.is_deleted = 0
                ) x
            ) mo
            WHERE l.area_id = @areaId AND p.is_deleted = 0;
            """;
        var lots = (await conn.QueryAsync<(long LocatorId, long LotId, string? PalletId,
                                           string? Status, bool IsUrgent, int? BoxCount,
                                           DateTime? ProductionDate, string? Model,
                                           string? Disposition)>(
            lotsSql, new { areaId = layout.AreaId })).ToList();

        var lotsByLocator = lots.GroupBy(x => x.LocatorId)
            .ToDictionary(g => g.Key, g => g.Select(x => new MapViewLot
            {
                LotId = x.LotId,
                PalletId = x.PalletId,
                Model = x.Model,
                BoxCount = x.BoxCount,
                ProductionDate = x.ProductionDate,
                Status = MapStatus(x.Status),
                IsUrgent = x.IsUrgent,
                Disposition = x.Disposition
            }).ToList());

        foreach (var b in blocks.Where(b => b.Kind == "pallet" && b.LocatorId is not null))
        {
            if (!lotsByLocator.TryGetValue(b.LocatorId!.Value, out var my) || my.Count == 0) continue;
            b.Lots = my;
            b.Status = DeriveStatus(my);
            b.IsUrgent = my.Any(x => x.IsUrgent);
            b.Model = my.FirstOrDefault()?.Model;
        }

        layout.Blocks = blocks;
        layout.Summary = BuildSummary(blocks);
        return layout;
    }

    /// <summary>Thống kê chiếm chỗ: kệ tính theo locator con (đã gồm giá lửng A/B), pallet tính 1 ô = 1 slot.</summary>
    private static MapViewSummary BuildSummary(List<MapViewBlock> blocks)
    {
        var s = new MapViewSummary();
        foreach (var b in blocks)
        {
            if (b.Kind == "rack")
            {
                s.RackTotalSlots += b.TotalSlots;
                s.RackOccupiedSlots += b.OccupiedSlots;
            }
            else if (b.Kind == "pallet")
            {
                s.PalletTotalSlots += 1;
                if (b.Lots.Count > 0) s.PalletOccupiedSlots += 1;
            }
        }
        s.TotalSlots = s.RackTotalSlots + s.PalletTotalSlots;
        s.OccupiedSlots = s.RackOccupiedSlots + s.PalletOccupiedSlots;
        return s;
    }

    // Key phải khớp STATUS_META của engine bản đồ (swms-temploc-map.js).
    private static readonly Dictionary<string, int> StatusPriority = new()
    {
        ["ng"] = 1, ["under_inspection"] = 2, ["pending_result"] = 3,
        ["not_inspected"] = 4, ["inspection_exempt"] = 5, ["pass"] = 6
    };

    private static string DeriveStatus(List<MapViewLot> lots)
        => lots.Count == 0 ? "empty"
         : lots.Select(l => l.Status)
               .OrderBy(x => StatusPriority.GetValueOrDefault(x, 50))
               .First();

    private static string MapStatus(string? s) => (s ?? "").ToLowerInvariant() switch
    {
        "pass" or "ok" => "pass",
        "ng" or "fail" => "ng",
        "under_inspection" or "inspecting" or "checking" => "under_inspection",
        "pending_result" or "waiting" or "wait_result" => "pending_result",
        "inspection_exempt" or "exempt" or "skip" => "inspection_exempt",
        "" => "not_inspected",
        var v => v
    };
}
