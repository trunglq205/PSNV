import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/common/app_bottom_hint.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/find_missing_notifier.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_providers.dart';

// ─────────────────────────────────────────────────────────────
//  Tìm box bị mất — client thuần, không gọi API.
//  Hiện list box của lot, quét từng box thực tế. Box không quét
//  được = mất. Quét box lạ (khác lot) -> báo lỗi.
//
//  Danh sách thùng lấy từ palletProvider(lotNo) (đã cache bởi màn
//  Detail) nên route chỉ cần lotNo.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class FindMissingBoxScreen extends ConsumerStatefulWidget {
  final String lotNo;

  const FindMissingBoxScreen({super.key, required this.lotNo});

  @override
  ConsumerState<FindMissingBoxScreen> createState() =>
      _FindMissingBoxScreenState();
}

class _FindMissingBoxScreenState extends ConsumerState<FindMissingBoxScreen> {
  StreamSubscription<String>? _sub;

  FindMissingNotifierProvider get _provider =>
      findMissingProvider(widget.lotNo);

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    _sub = pda.scanStream.listen(_onScan);
  }

  void _onScan(String code) {
    if (!mounted) return;
    final outcome = ref.read(_provider.notifier).onScan(code);
    if (!mounted) return;

    switch (outcome) {
      case ScanBoxOutcome.matched:
        break; // im lặng, UI tự cập nhật
      case ScanBoxOutcome.already:
        _toast(
          LocaleKeys.pallet_find_missing_already_scanned.tr(),
          isError: false,
        );
      case ScanBoxOutcome.foreign:
        _toast(
          LocaleKeys.pallet_find_missing_foreign_box.tr(args: [code.trim()]),
          isError: true,
        );
    }
  }

  void _toast(String msg, {required bool isError}) {
    AppToastHelper.toast(
      context,
      message: msg,
      type: isError ? .error : .success,
    );
  }

  @override
  Widget build(BuildContext context) {
    // Thùng đến từ palletProvider -> chờ/nhắc lỗi ở đây, phần dưới
    // chắc chắn đã có dữ liệu.
    final palletAsync = ref.watch(palletProvider(widget.lotNo));

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.pallet_find_missing_title.tr(),
        subtitle: LocaleKeys.pallet_find_missing_subtitle.tr(
          args: [widget.lotNo],
        ),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.read(_provider.notifier).reset(),
          ),
        ],
      ),
      body: palletAsync.when(
        loading: () => const AppLoading(),
        error: (e, _) => AppErrorView.page(
          message: LocaleKeys.pallet_find_missing_load_error.tr(),
          onRetry: () => ref.invalidate(palletProvider(widget.lotNo)),
        ),
        data: (_) => _buildContent(),
      ),
    );
  }

  Widget _buildContent() {
    final state = ref.watch(_provider);

    return Column(
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(AppDimens.md),
            children: [
              _CountCard(state: state),
              const SizedBox(height: AppDimens.md),
              BarcodeScannerButton(
                scanningLabel: LocaleKeys.pallet_find_missing_scan_hint.tr(),
              ),
              const SizedBox(height: AppDimens.md),
              _BoxChecklist(
                state: state,
                onBoxTap: (box) =>
                    context.router.push(BoxDetailRoute(boxId: box.id)),
              ),
            ],
          ),
        ),
        _BottomBar(
          state: state,
          onCancel: () => Navigator.of(context).maybePop(),
        ),
      ],
    );
  }
}

/// Card kiểm đếm: Tổng / Đã quét / Còn lại + progress.
class _CountCard extends StatelessWidget {
  final FindMissingState state;

  const _CountCard({required this.state});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 38,
                height: 38,
                decoration: BoxDecoration(
                  color: swms.primaryTint,
                  borderRadius: BorderRadius.circular(AppDimens.rBtn),
                ),
                child: Icon(Icons.search, color: swms.primary, size: 20),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      LocaleKeys.pallet_find_missing_count_title.tr(),
                      style: AppTextStyles.bodyStrong.copyWith(
                        color: swms.text1,
                      ),
                    ),
                    Text(
                      LocaleKeys.pallet_find_missing_count_hint.tr(),
                      style: AppTextStyles.caption.copyWith(color: swms.text3),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimens.md),
          Row(
            children: [
              Expanded(
                child: _Stat(
                  label: LocaleKeys.pallet_find_missing_total.tr(),
                  value: '${state.total}',
                  color: swms.text1,
                  bg: swms.card2,
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _Stat(
                  label: LocaleKeys.pallet_find_missing_scanned.tr(),
                  value: '${state.scannedCount}',
                  color: swms.success,
                  bg: swms.successBg,
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _Stat(
                  label: LocaleKeys.pallet_find_missing_remaining.tr(),
                  value: '${state.remaining}',
                  color: state.remaining > 0 ? swms.danger : swms.success,
                  bg: state.remaining > 0 ? swms.dangerBg : swms.successBg,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimens.sm),
          SizedBox(
            width: double.infinity,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(4),
              child: LinearProgressIndicator(
                value: state.progress,
                minHeight: 6,
                backgroundColor: swms.card2,
                valueColor: AlwaysStoppedAnimation(swms.primary),
              ),
            ),
          ),
          const SizedBox(height: AppDimens.xs),
          Text(
            '${(state.progress * 100).round()}%',
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
        ],
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  final String label;
  final String value;
  final Color color;
  final Color bg;

  const _Stat({
    required this.label,
    required this.value,
    required this.color,
    required this.bg,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: AppDimens.sm),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(value, style: AppTextStyles.h2.copyWith(color: color)),
          Text(label, style: AppTextStyles.caption.copyWith(color: color)),
        ],
      ),
    );
  }
}

/// Danh sách box với ô tick (đã quét = tích tím, chưa = viền nhạt).
class _BoxChecklist extends StatelessWidget {
  final FindMissingState state;
  final void Function(PalletBox box)? onBoxTap;

  const _BoxChecklist({required this.state, this.onBoxTap});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(
            left: AppDimens.xs,
            bottom: AppDimens.xs,
          ),
          child: Text(
            LocaleKeys.pallet_find_missing_box_list.tr(
              args: ['${state.total}'],
            ),
            style: AppTextStyles.label.copyWith(color: swms.text3),
          ),
        ),
        for (int i = 0; i < state.boxes.length; i++)
          _BoxRow(
            index: i + 1,
            box: state.boxes[i],
            scanned: state.isScanned(state.boxes[i].boxNo),
            onTap: onBoxTap == null ? null : () => onBoxTap!(state.boxes[i]),
          ),
      ],
    );
  }
}

class _BoxRow extends StatelessWidget {
  final int index;
  final PalletBox box;
  final bool scanned;
  final VoidCallback? onTap;

  const _BoxRow({
    required this.index,
    required this.box,
    required this.scanned,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    // Màu tím theo mockup (box đã quét "sáng tím").
    const purple = Color(0xFF8E24AA);
    const purpleTint = Color(0x148E24AA); // nền tím rất nhạt

    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.xs),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        child: Container(
          padding: const EdgeInsets.all(AppDimens.sm),
          decoration: BoxDecoration(
            color: scanned ? purpleTint : swms.card2,
            borderRadius: BorderRadius.circular(AppDimens.rCard),
            border: Border.all(
              color: scanned ? purple : swms.border,
              width: scanned ? 1.5 : 1,
            ),
          ),
          child: Row(
            children: [
              // ô tick
              Container(
                width: 24,
                height: 24,
                decoration: BoxDecoration(
                  color: scanned ? purple : Colors.transparent,
                  shape: BoxShape.circle,
                  border: Border.all(
                    color: scanned ? purple : swms.text4,
                    width: 1.5,
                  ),
                ),
                child: scanned
                    ? const Icon(Icons.check, color: Colors.white, size: 15)
                    : null,
              ),
              const SizedBox(width: AppDimens.sm),
              Text(
                index.toString().padLeft(2, '0'),
                style: AppTextStyles.caption.copyWith(
                  color: scanned ? purple : swms.text4,
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Text(
                  box.boxNo,
                  style: AppTextStyles.bodyStrong.copyWith(
                    color: scanned ? purple : swms.text3,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Thanh dưới: Hủy + kết quả kiểm đếm (không có nút in — in thuộc Box Detail).
class _BottomBar extends StatelessWidget {
  final FindMissingState state;
  final VoidCallback onCancel;

  const _BottomBar({required this.state, required this.onCancel});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final hasScanned = state.scannedCount > 0;
    final missingCount = state.missingBoxes.length;

    return AppBottomHint(
      child: _resultBanner(context, hasScanned, missingCount, swms),
    );
  }

  Widget _resultBanner(
    BuildContext context,
    bool hasScanned,
    int missingCount,
    SwmsColors swms,
  ) {
    // Chưa quét box nào.
    if (!hasScanned) {
      return _Banner(
        text: LocaleKeys.pallet_find_missing_scan_at_least_one.tr(),
        color: swms.text3,
        bg: swms.card2,
        icon: Icons.qr_code_scanner,
      );
    }
    // Có box mất.
    if (missingCount > 0) {
      return _Banner(
        text: LocaleKeys.pallet_find_missing_missing_count.tr(
          args: ['$missingCount'],
        ),
        color: swms.danger,
        bg: swms.dangerBg,
        icon: Icons.report_gmailerrorred_outlined,
      );
    }
    // Đủ box.
    return _Banner(
      text: LocaleKeys.pallet_find_missing_all_present.tr(),
      color: swms.success,
      bg: swms.successBg,
      icon: Icons.check_circle_outline,
    );
  }
}

class _Banner extends StatelessWidget {
  final String text;
  final Color color;
  final Color bg;
  final IconData icon;

  const _Banner({
    required this.text,
    required this.color,
    required this.bg,
    required this.icon,
  });

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, color: color, size: 18),
        const SizedBox(width: AppDimens.xs),
        Flexible(
          child: Text(
            text,
            style: AppTextStyles.bodyStrong.copyWith(color: color),
            textAlign: TextAlign.center,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }
}
