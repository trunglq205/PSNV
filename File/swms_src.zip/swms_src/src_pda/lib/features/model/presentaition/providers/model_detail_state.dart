import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';

/// State phức hợp của màn Model Detail — tách sẵn để thêm field khác
/// (tồn kho theo model, lịch sử…) mà không đổi cấu trúc.
class ModelDetailState {
  final AsyncValue<ModelDetail> detail;

  const ModelDetailState({this.detail = const AsyncValue.loading()});

  ModelDetailState copyWith({AsyncValue<ModelDetail>? detail}) =>
      ModelDetailState(detail: detail ?? this.detail);
}
