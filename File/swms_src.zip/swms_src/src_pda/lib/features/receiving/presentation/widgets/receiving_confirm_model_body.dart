import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

enum ReceivingInputMode { none, manual, serial }

/// Bước 2: xác nhận model vừa quét.
///
/// Widget này là **controlled component**: toàn bộ state (mode, boxCount,
/// serials) do parent nắm giữ và truyền xuống qua constructor. Widget chỉ
/// hiển thị và bắn callback (`onBoxChange`, `onSerialRemove`) khi user thao tác.
class ReceivingConfirmModelBody extends StatelessWidget {
  const ReceivingConfirmModelBody({
    super.key,
    required this.modelInfo,
    required this.serials,
    required this.onSerialRemove,
  });

  final ModelInfo modelInfo;

  /// Danh sách serial đã quét (dùng khi mode == serial).
  final List<String> serials;

  /// Bắn INDEX của serial cần xóa.
  final ValueChanged<int> onSerialRemove;

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        _ModelInfoCard(modelInfo: modelInfo),
        const SizedBox(height: AppDimens.sm),
        _buildSerial(context),
      ],
    );
  }

  // ── Quét serial ────────────────────────────────────────────
  Widget _buildSerial(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _SectionLabel('receiving.scan_serial'.tr()),
          const SizedBox(height: 10),
          BarcodeScannerButton(
            scanningLabel: LocaleKeys.receiving_scan_serial_hint.tr(),
          ),
          const SizedBox(height: 10),
          if (serials.isNotEmpty)
            Column(
              children: [
                for (var i = 0; i < serials.length; i++)
                  Container(
                    height: AppDimens.rowH,
                    margin: const EdgeInsets.only(bottom: AppDimens.xs),
                    padding: const EdgeInsets.only(left: 10, right: 4),
                    decoration: BoxDecoration(
                      color: swms.card2,
                      borderRadius: BorderRadius.circular(AppDimens.rInput),
                      border: Border.all(color: swms.border),
                    ),
                    child: Row(
                      children: [
                        SizedBox(
                          width: 22,
                          child: Text(
                            '${i + 1}',
                            style: AppTextStyles.caption.copyWith(
                              color: swms.text4,
                            ),
                          ),
                        ),
                        Expanded(
                          child: Text(
                            serials[i],
                            style: AppTextStyles.code.copyWith(
                              fontSize: 13,
                              color: swms.text1,
                            ),
                            overflow: TextOverflow.ellipsis,
                          ),
                        ),
                        IconButton(
                          constraints: const BoxConstraints.tightFor(
                            width: AppDimens.hitSm,
                            height: AppDimens.hitSm,
                          ),
                          padding: EdgeInsets.zero,
                          icon: Icon(
                            Icons.close_rounded,
                            size: 18,
                            color: swms.danger,
                          ),
                          tooltip: 'common.remove'.tr(),
                          onPressed: () => onSerialRemove(i),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          const SizedBox(height: AppDimens.xs),
        ],
      ),
    );
  }
}

// ── Sub-widgets ──────────────────────────────────────────────

class _ModelInfoCard extends StatelessWidget {
  const _ModelInfoCard({required this.modelInfo});

  final ModelInfo modelInfo;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionLabel(LocaleKeys.receiving_model_info.tr()),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(
                'receiving.model_code'.tr(),
                style: AppTextStyles.caption.copyWith(color: swms.text3),
              ),
              Expanded(
                child: Text(
                  modelInfo.model,
                  style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                  textAlign: TextAlign.end,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text.toUpperCase(),
      style: AppTextStyles.caption.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: .3,
        color: context.swms.text3,
      ),
    );
  }
}
