﻿namespace CriticalListReport.Models
{
    public class AirCostRow
    {
        public string? Vendor { get; set; }
        public string? Maker { get; set; }
        public string? Plant { get; set; }
        public string? Material { get; set; }
        public string? ShortText { get; set; }
        public DateTime? NecDate { get; set; }
        public DateTime? MonthDate { get; set; }
        public decimal? GWAir { get; set; }
        public decimal FreightUnit { get; set; }
        public decimal? TotalFreight { get; set; }
        public DateTime? ETABySea { get; set; }
    }
}
