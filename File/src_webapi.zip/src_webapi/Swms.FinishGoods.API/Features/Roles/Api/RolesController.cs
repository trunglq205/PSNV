using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.Api.Features.Roles.Api;

[ApiController]
[Route("api/roles")]
public class RolesController : ControllerBase
{
    private readonly IRoleService _service;
    public RolesController(IRoleService service) => _service = service;

    // GET /api/roles/permission-catalog
    [HttpGet("permission-catalog")]
    [RequirePermission<Perms.System.Roles.View>]
    public async Task<ActionResult<List<PermissionModuleResponse>>> GetPermissionCatalog()
        => Ok(await _service.GetPermissionCatalogAsync());

    // GET /api/roles
    [HttpGet]
    [RequirePermission<Perms.System.Roles.View>]
    public async Task<ActionResult<List<RoleResponse>>> GetRoles()
        => Ok(await _service.GetRolesAsync());

    // POST /api/roles
    [HttpPost]
    [RequirePermission<Perms.System.Roles.Create>]
    public async Task<ActionResult<RoleResponse>> Create(CreateRoleRequest request)
        => Ok(await _service.CreateRoleAsync(request));

    // PUT /api/roles
    [HttpPut]
    [RequirePermission<Perms.System.Roles.Update>]
    public async Task<IActionResult> Update(UpdateRoleRequest request)
    {
        await _service.UpdateRoleAsync(request);
        return NoContent();
    }

    // PUT /api/roles/permissions
    [HttpPut("permissions")]
    [RequirePermission<Perms.System.Roles.Update>]
    public async Task<IActionResult> UpdatePerms(UpdateRolePermsRequest request)
    {
        await _service.UpdateRolePermsAsync(request);
        return NoContent();
    }

    // DELETE /api/roles/{code}
    [HttpDelete("{code}")]
    [RequirePermission<Perms.System.Roles.Delete>]
    public async Task<IActionResult> Delete(string code)
    {
        await _service.DeleteRoleAsync(code);
        return NoContent();
    }
}