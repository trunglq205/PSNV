import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/utils/app_version.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/shared/presentation/providers/update_providers.dart';

class UpdateCard extends ConsumerStatefulWidget {
  const UpdateCard({super.key});

  @override
  ConsumerState<UpdateCard> createState() => UpdateCardState();
}

class UpdateCardState extends ConsumerState<UpdateCard> {
  bool _checking = false;

  Future<void> _onCheckUpdate() async {
    if (_checking) return;
    setState(() => _checking = true);
    try {
      await ref.read(updateFlowProvider).start(context, manual: true);
    } finally {
      if (mounted) setState(() => _checking = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.update_section_title.tr(),
            style: AppTextStyles.h2.copyWith(color: swms.text1),
          ),
          const SizedBox(height: AppDimens.xs),
          Text(
            LocaleKeys.update_current_version.tr(
              args: [AppVersion.fullVersion],
            ),
            style: AppTextStyles.label.copyWith(color: swms.text3),
          ),
          const SizedBox(height: AppDimens.sm),
          AppButton(
            label: LocaleKeys.update_check_button.tr(),
            icon: Icons.system_update,
            isLoading: _checking,
            onPressed: _onCheckUpdate,
          ),
        ],
      ),
    );
  }
}