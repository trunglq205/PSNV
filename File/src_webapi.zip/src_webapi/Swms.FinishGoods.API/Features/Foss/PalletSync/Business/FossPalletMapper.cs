using Swms.FinishGoods.API.Features.Foss.Api;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;

namespace Swms.FinishGoods.API.Features.Foss.PalletSync.Business;

/// <summary>Dòng serial Foss -> entity Pallet của SWMS. Chỉ luồng đồng bộ Foss dùng.</summary>
public static class FossPalletMapper
{
    /// <summary>
    /// Mã OQC (0/2/3/4/5) -> inspection_status của pallet.
    /// Dùng chung cho tạo lot từ Foss và đồng bộ OQC.
    /// </summary>
    public static string ToInspectionStatus(int oqcStatus, bool isEvenLot) => oqcStatus switch
    {
        2 => isEvenLot ? InspectionStatus.PendingResult : InspectionStatus.UnderInspection,
        4 => InspectionStatus.Ng,
        5 => InspectionStatus.Pass,
        _ => InspectionStatus.NotInspected
    };

    /// <summary>
    /// Convert list phẳng serial (SP Foss) → Lot mức detailLevel = serial.
    /// Giả định toàn bộ items thuộc cùng 1 pallet (1 lot).
    /// </summary>
    /// <param name="items">Danh sách dòng serial từ Foss.</param>
    /// <param name="lotNo">LotNo client tự sinh: &lt;CategoryCode&gt;&lt;YYMMDD&gt;&lt;Seq&gt; (12 số).</param>
    /// <param name="categoryCode">Code số của category (vd 310).</param>
    /// <param name="createdBy">User tạo (tuỳ chọn).</param>
    public static Pallet ToLot(
        this IReadOnlyCollection<FossPalletItemResponse> items,
        string lotNo,
        int categoryCode,
        bool isEvenLot,
        int oqcStatus,
        string? createdBy = null)
    {
        if (items is null || items.Count == 0)
            throw new ArgumentException("Danh sách serial rỗng.", nameof(items));

        // Cảnh báo sớm nếu list chứa nhiều pallet khác nhau
        var palletNos = items.Select(i => i.PalletNo).Distinct().ToList();
        if (palletNos.Count > 1)
            throw new InvalidOperationException(
                $"List chứa {palletNos.Count} pallet khác nhau: {string.Join(", ", palletNos)}. Mỗi lần convert chỉ 1 pallet.");

        // Chống trùng serial trong cùng lot (Lot.SerialDuplicated)
        var dupSerials = items
            .GroupBy(i => i.SerialNo)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key)
            .ToList();
        if (dupSerials.Count > 0)
            throw new InvalidOperationException(
                $"Serial trùng trong lot: {string.Join(", ", dupSerials)}");

        // GIỜ NHÀ MÁY, không phải UTC.
        //
        // Đổi từ DateTime.UtcNow: `now` giờ chỉ còn là DỰ PHÒNG cho khi Foss
        // không có DATEINSERT, nên nó phải cùng hệ quy chiếu với DATEINSERT —
        // vốn là giờ local của Foss. Trộn hai loại thì trong cùng một pallet sẽ
        // có box lệch nhau 7 tiếng, và sắp xếp theo created_at ra sai thứ tự.
        // Cũng khớp với SYSDATETIME() mà LotRepository đang dùng.
        var now = DateTime.Now;

        var boxes = items
            .GroupBy(i => i.BoxNo)
            .Select(g =>
            {
                var lines = g.Select(i => new BoxLine
                {
                    Model = i.ModelNo,
                    Qty = 1,                              // serial: qty luôn = 1
                    SerialNo = i.SerialNo,
                    ProductionDate = i.ProductionDate,
                    // Thời điểm Foss ghi nhận serial này (TBLPRODUCT_*.DATEINSERT).
                    // Null khi serial không khớp bản ghi nào bên TBLPRODUCT (LEFT JOIN).
                    CreatedAt = i.DateInsert ?? now,
                    CreatedBy = createdBy,
                }).ToList();

                return new Box
                {
                    BoxNo = g.Key,
                    RawPayload = g.Key,
                    Line = g.First().Line,
                    OQCStatus = g.First().OQCStatus,
                    LotName = g.First().LotName,
                    ProductionDate = lines
                        .Where(l => l.ProductionDate.HasValue)
                        .Min(l => l.ProductionDate),
                    // box.created_at = serial ĐƯỢC GHI SỚM NHẤT trong thùng.
                    // MIN chứ không MAX: thùng "có" kể từ lúc chiếc đầu tiên vào,
                    // cùng nguyên tắc với production_date.
                    CreatedAt = g.Where(i => i.DateInsert.HasValue)
                                 .Min(i => i.DateInsert) ?? now,
                    Lines = lines,
                    CreatedBy = createdBy,
                };
            })
            .ToList();

        var inspectionStatus = ToInspectionStatus(oqcStatus, isEvenLot);

        return new Pallet
        {
            LotNo = lotNo,
            CategoryCode = categoryCode,
            LotType = "pallet",          // Foss là pallet → stockyCode phải NULL
            StockyCode = null,
            DetailLevel = "serial",
            EvenLot = isEvenLot,
            Model = items.Select((e) => e.ModelNo).Distinct().SingleOrDefault(),
            BoxCount = boxes.Count,      // server tự tính, nhưng set sẵn cho nhất quán
            // lot.production_date = MIN(boxes), null nếu tất cả box null
            ProductionDate = boxes
                .Where(b => b.ProductionDate.HasValue)
                .Min(b => b.ProductionDate),
            InspectionStatus = inspectionStatus,
            Boxes = boxes,
            // Pallet là bản ghi của SWMS, KHÔNG lấy theo Foss: nó được tạo lúc
            // thao tác viên quét mã, không phải lúc Foss ghi serial.
            CreatedAt = now,
            CreatedBy = createdBy,
        };
    }
}
