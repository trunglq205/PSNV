import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';
import 'package:swms_finish_goods/features/model/presentaition/widgets/model_field_grid.dart';

/// Thẻ đầu màn: mã model + trạng thái, GTIN, category, kích thước thùng.
class ModelInfoCard extends StatelessWidget {
  const ModelInfoCard({super.key, required this.model});

  final ModelDetail model;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'model_detail.model'.tr(),
                      style: AppTextStyles.caption.copyWith(color: swms.text3),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      model.code,
                      style: AppTextStyles.h2.copyWith(color: swms.text1),
                    ),
                  ],
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              if (model.isActive)
                StatusPill.success(
                  context,
                  label: 'model_detail.active'.tr(),
                  icon: Icons.check_circle_outline,
                )
              else
                StatusPill.neutral(
                  context,
                  label: 'model_detail.inactive'.tr(),
                  icon: Icons.block,
                ),
            ],
          ),
          const SizedBox(height: AppDimens.md),
          ModelFieldGrid(
            columns: 2,
            fields: [
              ModelField('model_detail.gtin'.tr(), model.gtin),
              ModelField(
                'model_detail.category'.tr(),
                model.categoryName.isEmpty
                    ? '${model.categoryCode}'
                    : '${model.categoryCode} · ${model.categoryName}',
              ),
            ],
          ),
          Padding(
            padding: const EdgeInsets.symmetric(vertical: AppDimens.sm),
            child: Divider(height: 1, color: swms.border),
          ),
          ModelFieldGrid(
            columns: 4,
            fields: [
              ModelField.number(
                'model_detail.length'.tr(),
                model.length,
                unit: 'mm',
              ),
              ModelField.number(
                'model_detail.width'.tr(),
                model.width,
                unit: 'mm',
              ),
              ModelField.number(
                'model_detail.height'.tr(),
                model.height,
                unit: 'mm',
              ),
              ModelField.number(
                'model_detail.standard_packing'.tr(),
                model.standardPacking,
                unit: 'pcs',
              ),
            ],
          ),
        ],
      ),
    );
  }
}
