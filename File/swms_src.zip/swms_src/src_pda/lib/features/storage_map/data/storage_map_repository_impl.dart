import 'package:swms_finish_goods/features/storage_map/data/datasources/storage_map_remote_data_source.dart';
import 'package:swms_finish_goods/features/storage_map/domain/entities/storage_map_entities.dart';
import 'package:swms_finish_goods/features/storage_map/domain/repositories/storage_map_repository.dart';

class StorageMapRepositoryImpl implements StorageMapRepository {
  final StorageMapRemoteDataSource _remote;

  const StorageMapRepositoryImpl(this._remote);

  @override
  Future<List<WarehouseArea>> fetchAreas({String? type}) async {
    final res = await _remote.fetchAreas(type: type);
    return res.map((e) => e.toEntity()).toList();
  }

  @override
  Future<StorageTopMap> fetchTopMap({String? areaCode}) async {
    final res = await _remote.fetchTopMap(areaCode: areaCode);
    return res.toEntity();
  }

  @override
  Future<RackElevation> fetchElevation(String rackCode, {String? areaCode}) async {
    final res = await _remote.fetchElevation(rackCode.trim(), areaCode: areaCode);
    return res.toEntity();
  }

  @override
  Future<LocatorLocation> locate(String locatorCode) async {
    final res = await _remote.locate(locatorCode);
    return res.toEntity();
  }

  @override
  Future<List<PalletSerial>> serials(String palletCode) async {
    final res = await _remote.serials(palletCode);
    return res.map((e) => e.toEntity()).toList();
  }
}
