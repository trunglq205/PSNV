import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_line.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_mapper.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_origin.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_suggestion.dart';
import 'package:swms_finish_goods/features/part_card/domain/repositories/part_card_repository.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_label_printer.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_providers.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_state.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/category_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';
import 'package:swms_finish_goods/shared/presentation/providers/model_provider.dart';

part 'part_card_notifier.g.dart';

/// Màn IN MỚI Part Card. Tem đã in (sửa / tách / gộp) đi từ Home →
/// `PartCardActionNotifier`.
@riverpod
class PartCardNotifier extends _$PartCardNotifier
    with BaseNotifierMixin<PartCardState> {
  PartCardRepository get _repo => ref.read(partCardRepositoryProvider);

  /// Tăng mỗi lần tra model mới → kết quả lịch sử về muộn của lần tra cũ
  /// bị bỏ qua.
  int _suggestSeq = 0;

  /// Danh mục Cate đã tải — để đổi mã trong lịch sử in sang [Category].
  List<Category> _categories = const [];

  /// Origin lấy từ master model. Dùng làm dự phòng khi lịch sử thiếu origin.
  PartCardOrigin? _masterOrigin;

  /// Không bao giờ ném lỗi: thiếu danh mục chỉ làm mất phần tự điền Cate,
  /// user vẫn chọn tay được (picker tự báo lỗi + thử lại).
  Future<List<Category>> _loadCategories() async {
    try {
      return await ref.readCategories();
    } catch (_) {
      return const [];
    }
  }

  @override
  PartCardState build() => const PartCardState();

  /// Cate [partCardMultiCategories] ⇒ tự bật chế độ nhiều mã.
  ///
  /// MỘT CHIỀU: đổi sang cate khác KHÔNG tự kéo về 1 mã — lúc đó phiếu có thể
  /// đã có nhiều dòng, tự rút xuống 1 dòng là âm thầm xoá dữ liệu user vừa
  /// nhập. Muốn về 1 mã thì bấm switch (có cảnh báo).
  PartCardMode _modeFor(Category? category) =>
      partCardMultiCategories.contains(category?.value)
          ? PartCardMode.multi
          : state.mode;

  /// Lỗi / không có model → null, không chặn bước 2.
  Future<PartCardOrigin?> _loadMasterOrigin(String model) async {
    try {
      final info = await ref.read(modelRepositoryProvider).getByCode(model);
      return PartCardOrigin.tryParse(info.origin);
    } catch (_) {
      return null;
    }
  }

  // ── Chế độ phiếu ───────────────────────────────────────────
  /// Đổi 1 mã ↔ nhiều mã ngay tại bước xác nhận — GIỮ dữ liệu đang nhập.
  /// Phần card-level (Dim / Weight / Cate / MFD / PO) hợp lệ cho cả 2 layout
  /// nên không phải nhập lại; PSNV PO / CUS PO giữ nguyên kể cả khi về chế độ
  /// 1 mã (không in ra, nhưng chuyển qua lại không mất).
  ///
  /// Nhiều → 1: tem 1 mã chỉ in được 1 dòng, `box` luôn = 1 → chỉ giữ DÒNG ĐẦU
  /// và reset box. UI phải hỏi xác nhận trước khi gọi
  /// (xem [PartCardState.droppedOnSingle]).
  void setMode(PartCardMode mode) {
    if (state.mode == mode) return;

    // Đã ra giấy mà chưa lưu lịch sử → không cho đổi layout, phải lưu xong lô
    // đang dở đã. UI cũng đã disable switch, đây là chốt chặn thứ hai.
    if (state.hasPrinted) return;

    final form = state.form?.copyWith(mode: mode);
    state = state.copyWith(
      mode: mode,
      form: mode.isSingle && form != null ? _toSingle(form) : form,
    );
  }

  /// Giữ đúng dòng đầu, ép `box = 1` theo bất biến của chế độ 1 mã.
  PartCardForm _toSingle(PartCardForm form) {
    if (form.lines.isEmpty) return form;
    return form.singleLine(form.lines.first.copyWith(box: 1));
  }

  // ── Điều hướng bước ────────────────────────────────────────
  void goStep(int number) {
    state = state.copyWith(step: PartCardStepX.fromNumber(number));
  }

  // ── Bước 1: nhập tay hoặc quét ─────────────────────────────
  void onModelInputChanged(String value) {
    state = state.copyWith(modelInput: value);
  }

  /// Nhận model rồi sang bước 2 NGAY (không tra master), sau đó tải lịch sử
  /// in ở nền để tự điền + hiện chip hộp.
  /// [raw] = chuỗi vừa quét (kitting card hoặc model). Bỏ trống → lấy
  /// [PartCardState.modelInput] (trường hợp nhập tay + bấm nút).
  Future<void> lookupModel([String? raw]) async {
    final model = raw == null
        ? state.modelInput.trim().toUpperCase()
        : modelFromScan(raw);

    final next = await ref.read(appActionProvider.notifier).run(() async {
      if (model == null || model.isEmpty) {
        throw const PartCardEmptyModelException();
      }

      return state.copyWith(
        modelInput: model,
        form: PartCardForm.empty(model: model, mode: state.mode),
        suggestions: PartCardSuggestions.empty,
        loadingSuggestions: true,
        step: PartCardStep.confirm,
        clearPending: true,
      );
    });

    if (next == null) return;
    state = next;
    await _loadSuggestions(model!);
  }

  // ── Nhân bản: điền sẵn từ tem đã in ───────────────────────
  /// Dựng form từ payload tem đã in rồi sang thẳng bước 2. In + lưu như in mới
  /// (Card_ID mới, `bulk`) — tem gốc không đụng tới.
  ///
  /// `false` = tem không đọc được (lỗi đã báo) → page đóng.
  Future<bool> loadForClone(String payload) async {
    final next = await ref.read(appActionProvider.notifier).run(() async {
      _categories = await ref.readCategories();
      final PartCard card;
      try {
        card = PartCard.fromPayload(payload.trim(), _categories);
      } catch (_) {
        throw const PartCardInvalidException();
      }
      if (card.models.isEmpty) throw const PartCardInvalidException();

      final mode = PartCardMapper.modeOf(card);
      final form = PartCardMapper.formOf(card, mode);
      return PartCardState(
        mode: mode,
        step: PartCardStep.confirm,
        modelInput: form.model,
        form: form,
      );
    });

    if (next == null) return false;
    _suggestSeq++;
    _masterOrigin = null;
    state = next;

    // Vẫn tải lịch sử để có chip hộp, nhưng KHÔNG điền đè dữ liệu tem.
    await _loadSuggestions(next.modelInput, autofill: false);
    return true;
  }

  /// Tải lịch sử in → thống kê → tự điền (nếu user chưa sửa form) + chip.
  ///
  /// [autofill] = false (nhân bản): chỉ lấy chip, giữ nguyên dữ liệu tem.
  ///
  /// KHÔNG đi qua `appActionProvider`: đây là gợi ý, lỗi mạng không được
  /// chặn thao tác — user vẫn nhập tay và in bình thường.
  Future<void> _loadSuggestions(String model, {bool autofill = true}) async {
    final seq = ++_suggestSeq;
    final formAtStart = state.form;

    final samplesFuture = _repo.getHistorySamples(model);
    final categoriesFuture = _loadCategories();
    final masterOriginFuture = _loadMasterOrigin(model);

    PartCardSuggestions result;
    try {
      final samples = await samplesFuture;
      result = PartCardSuggestions.fromSamples(samples);
    } catch (_) {
      result = PartCardSuggestions.empty;
    }
    _categories = await categoriesFuture;
    final masterOrigin = await masterOriginFuture;

    if (seq != _suggestSeq || state.modelInput != model) return;
    _masterOrigin = masterOrigin;

    var next = state.copyWith(suggestions: result, loadingSuggestions: false);

    final form = state.form;
    if (autofill && form != null && identical(form, formAtStart)) {
      // Áp hộp + cate + qty + weight từ lịch sử; origin ưu tiên master.
      final best = result.best;
      final boxFilled = best != null ? _applySuggestion(form, best) : form;
      final filled = masterOrigin != null
          ? boxFilled.copyWith(origin: masterOrigin)
          : boxFilled;

      if (!identical(filled, form)) {
        next = next.copyWith(form: filled, mode: _modeFor(filled.category));
      }
    }

    state = next;
  }

  /// Bấm chip hộp → điền kích thước + cate / origin / qty / weight đi kèm.
  void applySuggestion(PartCardSuggestion suggestion) {
    final form = state.form;
    if (form == null || state.hasPrinted) return;

    final next = _applySuggestion(form, suggestion);
    state = state.copyWith(form: next, mode: _modeFor(next.category));
  }

  /// Qty / Origin áp vào DÒNG ĐẦU (= model vừa quét, chủ thể của lịch sử).
  /// Weight / Qty = 0 nghĩa là lịch sử thiếu → để trống bắt user nhập.
  PartCardForm _applySuggestion(PartCardForm form, PartCardSuggestion s) =>
      form.copyWith(
        length: s.length,
        width: s.width,
        height: s.height,
        weight: s.weight,
        quantity: s.qty,
        category: _toCategory(s.category),
        origin: _masterOrigin ?? PartCardOrigin.tryParse(s.origin),
      );

  /// Mã không còn trong danh mục → null = giữ nguyên Cate đang có trên form.
  Category? _toCategory(int? value) => _categories.byValue(value);

  // ── Bước 2: sửa dữ liệu ────────────────────────────────────
  void onFormChanged(PartCardForm form) {
    state = state.copyWith(form: form, mode: _modeFor(form.category));
  }

  /// Thêm 1 mã vào phiếu (chỉ chế độ nhiều mã).
  ///
  /// - Quét/nhập TRÙNG mã đã có → cộng thêm 1 thùng cho dòng cũ.
  /// - Đủ [PartCardForm.maxLines] dòng → bỏ qua (UI đã disable nút `+` và
  ///   hiển thị bộ đếm `n/max`).
  Future<void> addLine(String raw) async {
    final form = state.form;
    if (form == null || state.mode.isSingle) return;

    final code = modelFromScan(raw);
    if (code == null || code.isEmpty) return;

    if (form.hasModel(code)) {
      state = state.copyWith(form: form.bumpBox(code));
      return;
    }
    if (!form.canAddLine) return;

    // Origin theo dòng trước cho đỡ phải sửa tay từng dòng.
    state = state.copyWith(
      form: form.addLine(
        PartCardLine.empty(code).copyWith(origin: form.lines.last.origin),
      ),
    );
  }

  /// Thiếu field thì không cho qua (UI đã disable nút + liệt kê field thiếu).
  void confirmForm() {
    final form = state.form;
    if (form == null || !form.isComplete) return;
    state = state.copyWith(step: PartCardStep.printCard);
  }

  // ── Bước 3: số phiếu + in ──────────────────────────────────
  void setCopies(int value) {
    state = state.copyWith(copies: value.clamp(1, 999));
  }

  /// In nhãn → in xong mới gọi API lưu lịch sử.
  ///
  /// Tách 2 pha: nếu API fail thì [PartCardState.pendingHistory] còn giữ
  /// các phiếu đã in, bấm lại chỉ gọi API (không in trùng ra giấy).
  ///
  /// Nếu in fail GIỮA lô, [_printLabels] cũng ghi phần đã ra giấy vào
  /// pendingHistory — nên lần bấm sau chỉ lưu lịch sử cho đúng số phiếu
  /// thật, không in lại từ đầu.
  Future<void> printAndSave() async {
    final form = state.form?.copyWith(mode: state.mode);
    if (form == null) return;

    final action = ref.read(appActionProvider.notifier);

    // Pha 1 — in giấy.
    var pending = state.pendingHistory;
    if (pending.isEmpty) {
      final printed = await action.run(
            () => _printLabels(form, state.copies),
      );
      if (printed == null) return; // in fail → giữ state cho retry

      pending = printed;
      state = state.copyWith(pendingHistory: printed);
    }
    if (pending.isEmpty) return;

    // Pha 2 — lưu lịch sử.
    final saved = await action.run(() => _repo.savePrintHistory(pending));
    if (saved == null) return; // save fail → giữ pending, cho gọi lại

    // Xong → về bước 1 cho phiếu tiếp theo, GIỮ chế độ đang chọn.
    reset();
  }

  /// In [copies] nhãn, mỗi nhãn 1 Card_ID mới. Chỉ ghi nhận nhãn đã được
  /// máy xác nhận — nhãn chưa xác nhận là chưa ra giấy.
  Future<List<PartCardPrintParams>> _printLabels(
      PartCardForm form,
      int copies,
      ) async {
    final jobs = List.generate(
      copies,
          (_) => PartCardPrintJob(form: form, cardId: PartCardId.generate()),
    );
    final printed = <PartCardPrintParams>[];

    try {
      await printPartCardJobs(
        ref,
        jobs,
        onPrinted: (i) => printed.add(jobs[i].toParams()),
      );
    } on PrinterException {
      // Nhãn đã xác nhận là đã ra giấy THẬT. Giữ lại để lần bấm sau chỉ lưu
      // lịch sử cho đúng số phiếu đó, không in trùng.
      if (printed.isNotEmpty) {
        state = state.copyWith(pendingHistory: printed);
      }
      rethrow; // KHÔNG nuốt lỗi — appActionProvider hiện message cho user.
    }

    return printed;
  }

  /// Quét chung — định tuyến theo bước hiện tại + chế độ phiếu.
  Future<void> onScan(String raw) async {
    if (state.step == PartCardStep.printCard) return;

    // Tem đã in → màn này không xử lý, chỉ báo user sang Home.
    if (isPartCardPayload(raw)) {
      await ref.read(appActionProvider.notifier).run<void>(() async {
        throw const PartCardUseHomeException();
      });
      return;
    }

    if (state.step == PartCardStep.confirm && state.mode.isMulti) {
      await addLine(raw);
    } else {
      await lookupModel(raw);
    }
  }

  void reset() {
    _suggestSeq++;
    _masterOrigin = null;
    state = PartCardState(mode: state.mode);
  }
}