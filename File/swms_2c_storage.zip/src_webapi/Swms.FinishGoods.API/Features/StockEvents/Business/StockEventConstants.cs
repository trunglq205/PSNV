﻿namespace Swms.FinishGoods.API.Features.StockEvents.Business
{
    /// <summary>
    /// Mã event ghi vào wms.stock_events. PHẢI khớp master.stock_event_types.code.
    ///
    /// Cố tình là hằng string chứ không phải enum: catalog (nhãn, màu, icon, nhóm)
    /// nằm ở DB để thêm loại event mới không phải build lại cả 3 codebase.
    /// </summary>
    public static class StockEventCodes
    {
        // ── Pallet · CREATE ──
        public const string PalletCreated = "PALLET_CREATED";

        // ── Pallet · EDIT  ──
        public const string QtyAdjusted = "QTY_ADJUSTED";
        public const string PalletBoxesAdded = "PALLET_BOXES_ADDED";

        // ── Pallet · OQC ──
        public const string OqcSampled = "OQC_SAMPLED";
        public const string OqcReturned = "OQC_RETURNED";
        public const string OqcStatusChanged = "OQC_STATUS_CHANGED";

        // ── Pallet · MOVE ──
        // Gọi tên theo KHU chứ không theo hành động: nhìn nhãn là biết pallet ở đâu.
        // IN/MOVED lấy tên khu ĐÍCH, OUT lấy tên khu NGUỒN.
        public const string ReceivingIn = "RECEIVING_IN";
        public const string ReceivingMoved = "RECEIVING_MOVED";
        public const string ReceivingOut = "RECEIVING_OUT";
        public const string StorageIn = "STORAGE_IN";
        public const string StorageMoved = "STORAGE_MOVED";
        public const string StorageTransferred = "STORAGE_TRANSFERRED";
        public const string StorageOut = "STORAGE_OUT";
        public const string CustomerReturned = "CUSTOMER_RETURNED";

        // ── Pallet · SPLIT ──
        public const string PalletSplitOut = "PALLET_SPLIT_OUT";
        public const string PalletSplitIn = "PALLET_SPLIT_IN";

        // ── Pallet · SHIP ──
        public const string KittingPicked = "KITTING_PICKED";
        public const string PalletListCreated = "PALLET_LIST_CREATED";
        public const string PalletColumnCreated = "PALLET_COLUMN_CREATED";
        public const string VanningIn = "VANNING_IN";
        public const string VanningMoved = "VANNING_MOVED";
        public const string VanningOut = "VANNING_OUT";
        public const string ContainerClosed = "CONTAINER_CLOSED";

        // ── Pallet · SYSTEM ──
        public const string SapPushed = "SAP_PUSHED";
        public const string StopShipmentSet = "STOP_SHIPMENT_SET";
        public const string StopShipmentCleared = "STOP_SHIPMENT_CLEARED";
        public const string PalletDeleted = "PALLET_DELETED";

        // ── Box ──
        public const string BoxCreated = "BOX_CREATED";
        public const string BoxMovedPallet = "BOX_MOVED_PALLET";
        public const string BoxPoChanged = "BOX_PO_CHANGED";
        public const string BoxOqcSampled = "BOX_OQC_SAMPLED";
        public const string BoxOqcReturned = "BOX_OQC_RETURNED";
        public const string BoxOqcStatusChanged = "BOX_OQC_STATUS_CHANGED";
        public const string BoxDeleted = "BOX_DELETED";
        public const string PalletBoxesRemoved = "PALLET_BOXES_REMOVED";

        public const string OqcSynced = "OQC_SYNCED";      // đồng bộ OQC làm đổi trạng thái box/pallet
        public const string SiNoAssigned = "SI_NO_ASSIGNED";  // HD soft M-/C- -> si_no = CUSTOMER
    }

    /// <summary>Nhóm event — dùng cho bộ lọc trên UI (master.stock_event_types.group_code).</summary>
    public static class StockEventGroups
    {
        public const string Create = "CREATE";
        public const string Oqc = "OQC";
        public const string Move = "MOVE";
        public const string Split = "SPLIT";
        public const string Ship = "SHIP";
        public const string Box = "BOX";
        public const string System = "SYSTEM";
    }

    /// <summary>Chủ thể của event (wms.stock_events.subject_type).</summary>
    public static class StockEventSubjects
    {
        public const string Pallet = "pallet";
        public const string Box = "box";
    }

    /// <summary>
    /// Nguồn phát sinh event (wms.stock_events.source).
    ///
    /// LƯU Ý: hiện API không có cách phân biệt request đến từ Web hay PDA
    /// (ICurrentUser chỉ có thông tin user). Mặc định là WEB. Muốn phân biệt
    /// thật thì client phải gửi header (vd X-Client: PDA) và đọc ở middleware —
    /// xem StockEventContext.Source.
    /// </summary>
    public static class StockEventSources
    {
        public const string Web = "WEB";
        public const string Pda = "PDA";
        public const string Api = "API";
        public const string Job = "JOB";
        public const string Sap = "SAP";
        public const string Foss = "FOSS";
        public const string HdSoft = "HDSOFT";
    }

    /// <summary>Loại đối tượng tham chiếu (wms.stock_events.ref_type).</summary>
    public static class StockEventRefTypes
    {
        public const string OqcSample = "OQC_SAMPLE";
        public const string PalletList = "PALLET_LIST";
        public const string PalletColumn = "PALLET_COLUMN";
        public const string Container = "CONTAINER";
        public const string Kitting = "KITTING";

        /// <summary>
        /// Phiếu chỉ thị hàng return (<c>wms.return_instructions</c>). Dùng khi
        /// một thao tác trên pallet thật ra là thao tác của phiếu — ví dụ huỷ
        /// một lần nhận: pallet bị xoá, và dòng lịch sử phải chỉ được về phiếu
        /// nào đã xoá nó.
        /// </summary>
        public const string ReturnInstruction = "RETURN_INSTRUCTION";
    }

    /// <summary>Nguồn tạo pallet — ghi vào payload {"origin":"..."} của PALLET_CREATED.</summary>
    public static class PalletOrigins
    {
        public const string Manual = "manual";   // POST /api/pallets
        public const string Foss = "foss";     // POST /api/pallets/by-lot-no/{lotNo}/from-foss
        public const string Split = "split";    // tách pallet sang lot mới
    }
}