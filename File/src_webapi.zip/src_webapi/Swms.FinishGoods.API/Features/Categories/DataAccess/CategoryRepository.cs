﻿using Dapper;
using Swms.FinishGoods.Api.Features.Categories.Api;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.Api.Features.Categories.DataAccess;

public class CategoryRepository : ICategoryRepository
{
    private readonly IDbConnectionFactory _factory;
    public CategoryRepository(IDbConnectionFactory factory) => _factory = factory;

    // Alias snake_case → PascalCase. code là business key/PK.
    private const string SelectColumns = """
        code                AS Code,
        name                AS Name,
        description         AS Description,
        bd                  AS Bd,
        plant_code          AS PlantCode,
        product             AS Product,
        slock_pmd           AS SlockPmd,
        slock_fa            AS SlockFa,
        slock_scs           AS SlockScs,
        slock_jpt           AS SlockJpt,
        slock_port          AS SlockPort,
        production_version  AS ProductionVersion,
        is_deleted          AS IsDeleted,
        created_at          AS CreatedAt,
        created_by          AS CreatedBy,
        updated_at          AS UpdatedAt,
        updated_by          AS UpdatedBy
        """;

    public async Task<IReadOnlyList<CategoryEntity>> GetAllAsync(CategoryQuery query)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {SelectColumns}
            FROM master.categories
            WHERE is_deleted = 0
              AND (@Code IS NULL OR code LIKE '%' + @Code + '%')
              AND (@Name IS NULL OR name LIKE '%' + @Name + '%')
              AND (@PlantCode IS NULL OR plant_code = @PlantCode)
              AND (@Product IS NULL OR product = @Product)
            ORDER BY code;
            """;
        var rows = await conn.QueryAsync<CategoryEntity>(sql, new
        {
            query.Code,
            query.Name,
            query.PlantCode,
            query.Product,
        });
        return rows.ToList();
    }

    public async Task<CategoryEntity?> GetByCodeAsync(int code)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {SelectColumns}
            FROM master.categories
            WHERE code = @code AND is_deleted = 0;
            """;
        return await conn.QuerySingleOrDefaultAsync<CategoryEntity>(sql, new { code });
    }

    public async Task AddAsync(CategoryEntity e)
    {
        using var conn = _factory.Create();
        var sql = """
            INSERT INTO master.categories
                (code, name, description, bd, plant_code, product,
                 slock_pmd, slock_fa, slock_scs, slock_jpt, slock_port,
                 production_version, is_deleted, created_at, created_by)
            VALUES
                (@Code, @Name, @Description, @Bd, @PlantCode, @Product,
                 @SlockPmd, @SlockFa, @SlockScs, @SlockJpt, @SlockPort,
                 @ProductionVersion, 0, SYSUTCDATETIME(), @CreatedBy);
            """;
        await conn.ExecuteAsync(sql, e);
    }

    public async Task UpdateAsync(CategoryEntity e)
    {
        using var conn = _factory.Create();
        var sql = """
            UPDATE master.categories SET
                name               = @Name,
                description        = @Description,
                bd                 = @Bd,
                plant_code         = @PlantCode,
                product            = @Product,
                slock_pmd          = @SlockPmd,
                slock_fa           = @SlockFa,
                slock_scs          = @SlockScs,
                slock_jpt          = @SlockJpt,
                slock_port         = @SlockPort,
                production_version = @ProductionVersion,
                updated_at         = SYSUTCDATETIME(),
                updated_by         = @UpdatedBy
            WHERE code = @Code AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(sql, e);
    }

    public async Task SoftDeleteAsync(int code, string? deletedBy)
    {
        using var conn = _factory.Create();
        var sql = """
            UPDATE master.categories
            SET is_deleted = 1, updated_at = SYSUTCDATETIME(), updated_by = @deletedBy
            WHERE code = @code AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(sql, new { code, deletedBy });
    }

    public async Task<bool> CodeExistsAsync(int code)
    {
        using var conn = _factory.Create();
        var sql = """
            SELECT COUNT(1) FROM master.categories
            WHERE code = @code AND is_deleted = 0;
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { code }) > 0;
    }
}