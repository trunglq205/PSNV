﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;

namespace SWMS_WebTool.ViewModels
{
    public class KittingListViewModel : TableViewModel<KittingList, KittingListFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, KittingListFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Tab = filter?.Tab ?? Filter.Tab,
                ProDate = filter?.ProDate ?? Filter.ProDate,
                Cate = filter?.Cate ?? Filter.Cate,
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                PartNo = filter?.SpecialPart ?? Filter.SpecialPart,
                Reservation = filter?.Reservation ?? Filter.Reservation,
                Status = filter?.Status ?? Filter.Status,
                KittingDate = filter?.KittingDate ?? Filter.KittingDate,
                SubplyDate = filter?.SupplyDate ?? Filter.SupplyDate,
                FromTime = filter?.FromTime ?? Filter.FromTime,
                FinishTime = filter?.FinishTime ?? Filter.FinishTime,
                Quantity = filter?.Quantity ?? Filter.Quantity,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
