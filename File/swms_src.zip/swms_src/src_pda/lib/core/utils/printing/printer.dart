import 'package:swms_finish_goods/core/errors/exceptions.dart'
    show PrinterBatchException;

export 'package:swms_finish_goods/core/errors/exceptions.dart'
    show PrinterErrorType, PrinterException, PrinterBatchException;

/// Ngôn ngữ lệnh của máy in.
///
/// Quyết định hai thứ ĐỘC LẬP nhau:
/// - RENDERER: dữ liệu tem → bytes (`LabelRenderer`).
/// - DRIVER: cách gửi và bắt tay (`Printer` — SATO chờ ACK, TSPL không có).
///
/// Gắn vào [PrinterDevice] lúc chọn máy, lưu cùng MAC.
enum PrinterLanguage {
  /// SATO Barcode Printer Language — máy SATO, có ENQ/ACK từng tem.
  sbpl,

  /// TSC Printer Language — MJ8001 và các máy nhiệt giá rẻ. KHÔNG có ACK.
  tspl;

  /// Dữ liệu đã lưu trước khi có field này không có `lang` → SATO như cũ.
  static PrinterLanguage fromJson(String? value) => switch (value) {
    'tspl' => PrinterLanguage.tspl,
    _ => PrinterLanguage.sbpl,
  };

  /// Đoán theo tên Bluetooth — CHỈ để điền mặc định trong UI chọn máy,
  /// người dùng vẫn phải sửa được. Tên không nhận ra → SATO (hành vi cũ).
  static PrinterLanguage guessFromName(String name) {
    final n = name.toUpperCase();
    if (n.contains('SATO')) {
      return PrinterLanguage.sbpl;
    }
    return PrinterLanguage.tspl;
  }
}

/// Thiết bị máy in Bluetooth đã ghép đôi.
class PrinterDevice {
  const PrinterDevice({
    required this.name,
    required this.macAddress,
    this.language = PrinterLanguage.sbpl,
  });

  factory PrinterDevice.fromMac(String macAddress) =>
      PrinterDevice(name: macAddress, macAddress: macAddress);

  factory PrinterDevice.fromJson(Map<String, dynamic> json) => PrinterDevice(
    name: (json['name'] as String?) ?? '',
    macAddress: json['mac'] as String,
    language: PrinterLanguage.fromJson(json['lang'] as String?),
  );

  final String name;
  final String macAddress;

  /// Ngôn ngữ lệnh — chọn driver và renderer lúc in.
  final PrinterLanguage language;

  Map<String, dynamic> toJson() => {
    'name': name,
    'mac': macAddress,
    'lang': language.name,
  };

  PrinterDevice copyWith({
    String? name,
    String? macAddress,
    PrinterLanguage? language,
  }) => PrinterDevice(
    name: name ?? this.name,
    macAddress: macAddress ?? this.macAddress,
    language: language ?? this.language,
  );

  /// Danh tính = MAC. Đổi ngôn ngữ của cùng một máy vẫn là cùng thiết bị.
  @override
  bool operator ==(Object other) =>
      other is PrinterDevice && other.macAddress == macAddress;

  @override
  int get hashCode => macAddress.hashCode;

  @override
  String toString() => 'PrinterDevice($name, $macAddress, ${language.name})';
}

/// Máy in chỉ biết nhận BYTES thô đã được label renderer chuẩn bị sẵn.
///
/// Vòng đời kết nối nằm HẲN bên trong mỗi method: mở kết nối → gửi →
/// đóng, kể cả khi lỗi. Không expose connect/disconnect ra ngoài để
/// caller không thể làm rò session hoặc gọi lệch thứ tự.
abstract interface class Printer {
  /// True khi đang có một job in chạy.
  bool get isBusy;

  /// In một payload.
  Future<void> printBytes(PrinterDevice device, List<int> bytes);

  /// Gửi nhiều payload trong MỘT phiên kết nối, xác nhận RIÊNG từng cái.
  ///
  /// [onPrinted] được gọi ngay sau mỗi lần xác nhận — dùng nó để tích luỹ
  /// dữ liệu lịch sử, vì khi lỗi giữa lô thì chỉ những nhãn đã xác nhận là
  /// thật sự ra giấy.
  ///
  /// Throw [PrinterBatchException] nếu dừng giữa chừng.
  Future<void> printBatch(
      PrinterDevice device,
      List<List<int>> payloads, {
        void Function(int index)? onPrinted,
      });

  Future<void> dispose();
}