import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Một bước trong [AppStepperBar].
class StepItem {
  const StepItem(this.label);
  final String label;
}

/// Thanh các bước (step bar) — số tròn + nhãn, nối bằng đường kẻ.
///
/// Bước hiện tại (current) tô primary; các bước khác nền bg, viền border2,
/// chữ text4. Có thể bấm để nhảy bước qua [onStepTap].
///
/// ```dart
/// AppStepBar(
///   current: step,                    // 1-based
///   steps: const [
///     StepItem('Quét Pallet'),
///     StepItem('Xác nhận'),
///     StepItem('Quét vị trí'),
///   ],
///   onStepTap: (i) => goStep(i),       // i là 1-based
/// );
/// ```
class AppStepperBar extends StatelessWidget {
  const AppStepperBar({
    super.key,
    required this.current,
    required this.steps,
    this.onStepTap,
  });

  /// Bước đang chọn, đếm từ 1.
  final int current;
  final List<StepItem> steps;

  /// Callback khi bấm vào một bước (truyền số bước 1-based). Null = không bấm.
  final ValueChanged<int>? onStepTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final children = <Widget>[];
    for (var i = 0; i < steps.length; i++) {
      final stepNo = i + 1;
      children.add(
        _StepButton(
          number: stepNo,
          label: steps[i].label,
          isCurrent: stepNo == current,
          onTap: onStepTap == null ? null : () => onStepTap!(stepNo),
        ),
      );
      // Đường nối giữa các bước
      if (i < steps.length - 1) {
        children.add(
          Expanded(
            child: Container(
              height: 2,
              margin: const EdgeInsets.symmetric(horizontal: AppDimens.xs),
              decoration: BoxDecoration(
                color: swms.border,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
          ),
        );
      }
    }

    return Row(children: children);
  }
}

/// Nút một bước: số tròn 20px + nhãn.
class _StepButton extends StatelessWidget {
  const _StepButton({
    required this.number,
    required this.label,
    required this.isCurrent,
    required this.onTap,
  });

  final int number;
  final String label;
  final bool isCurrent;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final circleColor = isCurrent ? AppColors.primary : swms.border2;
    final circleFill = isCurrent ? AppColors.primary : Theme.of(context).colorScheme.surface;
    final numberColor = isCurrent ? Colors.white : swms.text4;
    final labelColor = isCurrent ? swms.text1 : swms.text4;

    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTap: onTap,
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          AnimatedContainer(
            duration: const Duration(milliseconds: 200),
            width: 20,
            height: 20,
            alignment: Alignment.center,
            decoration: BoxDecoration(
              color: circleFill,
              shape: BoxShape.circle,
              border: isCurrent ? null : Border.all(color: circleColor),
            ),
            child: Text(
              '$number',
              style: AppTextStyles.caption.copyWith(
                fontWeight: FontWeight.w800,
                color: numberColor,
                height: 1,
              ),
            ),
          ),
          const SizedBox(width: AppDimens.xs),
          Text(
            label,
            maxLines: 1,
            overflow: TextOverflow.clip,
            style: AppTextStyles.label.copyWith(
              fontWeight: isCurrent ? FontWeight.w800 : FontWeight.w700,
              color: labelColor,
              height: 1,            ),
          ),
        ],
      ),
    );
  }
}