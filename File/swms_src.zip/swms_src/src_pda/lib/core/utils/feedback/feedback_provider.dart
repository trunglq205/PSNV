import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/utils/feedback/app_feedback.dart';
import 'package:swms_finish_goods/core/utils/feedback/audio_feedback.dart';

final appFeedbackProvider = Provider<AppFeedback>((ref) => AudioFeedback(ref));