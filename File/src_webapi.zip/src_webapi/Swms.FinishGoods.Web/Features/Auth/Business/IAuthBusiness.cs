using Swms.FinishGoods.Web.Features.Auth.Business.Models;

namespace Swms.FinishGoods.Web.Features.Auth.Business;

public interface IAuthBusiness
{
    Task<Result<LoginResponse>> LoginAsync(string username, string password, bool remember);
}
