namespace Swms.FinishGoods.API.Features.ReturnInstructions;

/// <summary>
/// Chỉ thị back hàng (<c>wms.return_instructions</c>) — SCS Office ghi nhận
/// thông tin khách hàng báo trả hàng về PSNV: model nào, bao nhiêu, về ngày nào.
///
/// Phiếu này là GỐC của cả luồng return / refurbish: mục 2 đối chiếu số lượng
/// thực nhận với <see cref="Lines"/>, mục 7 phát sinh SI đuôi -RE / -R theo
/// <see cref="GoodsType"/> của chính phiếu.
/// </summary>
public class ReturnInstruction
{
    public long Id { get; set; }

    /// <summary>
    /// Sinh ở server. Tiền tố nói luôn loại hàng:
    /// <c>RW-yyyyMMdd-###</c> (rework) | <c>RB-yyyyMMdd-###</c> (refurbish).
    /// </summary>
    public string DocNo { get; set; } = string.Empty;

    /// <summary>
    /// MỘT PHIẾU MỘT LOẠI: <c>rework</c> | <c>refurbish</c>.
    ///
    /// Nằm ở phiếu chứ không ở dòng. Khách báo cả hai loại trong một lần thì
    /// SCS Office tạo hai phiếu — nhờ vậy số phiếu nói luôn loại, và bước 7
    /// (SI đuôi -RE / -R định tuyến theo loại) bám thẳng vào phiếu được.
    /// </summary>
    public string GoodsType { get; set; } = string.Empty;

    public string? Customer { get; set; }

    /// <summary>Ngày hàng dự kiến về PSNV, theo thông tin khách hàng.</summary>
    public DateTime? ExpectedDate { get; set; }

    /// <summary><c>open</c> | <c>completed</c> | <c>cancelled</c>.</summary>
    public string DocStatus { get; set; } = ReturnDocStatus.Open;

    public string? Note { get; set; }

    /// <summary>
    /// Đã báo FA lúc nào. NULL = chưa gửi được — mail bị tắt
    /// (<c>Mail:Enabled</c>), hoặc chưa khai người nhận trong
    /// <c>master.email_config</c>. Tạo phiếu KHÔNG hỏng vì mail hỏng.
    /// </summary>
    public DateTime? MailSentAt { get; set; }
    public string? MailSentTo { get; set; }

    /// <summary>
    /// WH đã chốt SL thực nhận lúc nào (mục 2b). NULL = chưa chốt.
    ///
    /// Tách khỏi <see cref="DocStatus"/> dù chốt là đóng phiếu: Office mở lại
    /// phiếu thì trạng thái về <c>open</c>, còn mốc chốt lần trước vẫn đọc được
    /// để biết FA đã nhận số nào.
    /// </summary>
    public DateTime? ClosedAt { get; set; }
    public string? ClosedBy { get; set; }

    /// <summary>
    /// Đã báo FA SỐ THỰC NHẬN lúc nào. Khác <see cref="MailSentAt"/> (mail lúc
    /// TẠO phiếu) — "FA đã biết phiếu" và "FA đã biết số thực nhận" là hai việc.
    /// </summary>
    public DateTime? ActualMailSentAt { get; set; }
    public string? ActualMailSentTo { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    // ─────────────────────────────────────────────────────────────
    //  LUỒNG NHẬN LẠI HÀNG VỀ FA (mục 2c) — gộp vào chính phiếu này.
    //
    //  Vì sao gộp chứ không để bảng đề nghị riêng: hàng về nhiều đợt thì mỗi
    //  đợt một chỉ thị, nên MỘT PHIẾU CHỈ CÓ MỘT LUỒNG BACK. Bảng riêng chỉ
    //  thêm một số phiếu (BK-…) để người ta phải đối chiếu, và một bảng dòng
    //  model + SL mà từ lúc chốt "lấy là lấy hết" thì chỉ còn là ẢNH CHỤP của
    //  sổ serial — ảnh chụp không ai sửa được thì chỉ còn mỗi việc lệch dần.
    //
    //  KHÔNG có cột "bước đang chờ": với ba bước thì bước suy được từ
    //  <see cref="BackStatus"/> một-đối-một (xem <see cref="BackStep"/>). Hai
    //  cột nói cùng một việc là hai cột sớm muộn lệch nhau.
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// NULL = FA chưa đề nghị nhận lại hàng. Ngoài ra:
    /// <c>fa_requested</c> | <c>fa_approved</c> | <c>delivered</c> | <c>cancelled</c>.
    /// </summary>
    public string? BackStatus { get; set; }

    /// <summary>
    /// LẦN đề nghị đang mở (<c>wms.return_instructions.back_round</c>).
    /// 0 = FA chưa đề nghị lần nào.
    ///
    /// Thêm 12/11. Trước đó một phiếu chỉ đi được MỘT lượt back: FA xin 20
    /// trên 500, giao xong 20 là API chặn "phiếu đã có đề nghị" và 480 con còn
    /// lại không có đường nào xin tiếp. Nay mỗi lượt một số, phiếu đi lại bốn
    /// bước bao nhiêu lần cũng được miễn còn hàng ở kho.
    ///
    /// Các cột <c>back_*</c> còn lại là của LẦN NÀY. Mốc của những lần đã xong
    /// nằm ở <see cref="BackRounds"/>.
    /// </summary>
    public int BackRound { get; set; }

    /// <summary>
    /// Mốc của TỪNG lần đề nghị (<c>wms.return_back_rounds</c>), cũ trước mới.
    /// Repository chỉ nạp khi lấy CHI TIẾT phiếu — màn danh sách không cần.
    ///
    /// Dòng của lần đang mở là BẢN SAO của các cột <c>back_*</c>; xem câu soát
    /// lệch ở <c>return_back_round_schema.sql</c> mục 7.
    /// </summary>
    public List<ReturnBackRoundRow> BackRounds { get; set; } = new();

    /// <summary>Ghi chú của FA lúc đề nghị.</summary>
    public string? BackNote { get; set; }

    public string? BackRequestedBy { get; set; }
    public DateTime? BackRequestedAt { get; set; }

    /// <summary>Quản lý FA xác nhận — mốc lá mail sang SCS Office đi.</summary>
    public string? BackApprovedBy { get; set; }
    public DateTime? BackApprovedAt { get; set; }
    public string? BackFaComment { get; set; }

    /// <summary>
    /// Quản lý SCS xác nhận (thêm 10/11) — mốc SCS WH được phép tách pallet và
    /// giao. KHÔNG bắn mail: chính bước duyệt này thay cho lá mail lúc giao đã
    /// bỏ, vì duyệt xong là cả hai bên đã biết.
    /// </summary>
    public string? BackScsApprovedBy { get; set; }
    public DateTime? BackScsApprovedAt { get; set; }

    /// <summary>SCS WH bấm xác nhận ở lượt giao làm XONG cả phiếu.</summary>
    public string? BackDeliveredBy { get; set; }
    public DateTime? BackDeliveredAt { get; set; }

    /// <summary>
    /// Ý kiến phía SCS. Dùng cho CẢ bước quản lý SCS duyệt lẫn lượt giao cuối —
    /// một ô ghi chú của một bên, không tách hai cột cho hai bước của cùng bộ
    /// phận.
    /// </summary>
    public string? BackScsComment { get; set; }

    /// <summary>
    /// SL FA xin lấy về, theo model. Repository nạp kèm header.
    ///
    /// Rỗng khi FA chưa đề nghị, hoặc khi phiếu được đề nghị từ TRƯỚC 10/11 —
    /// lúc đó đề nghị là "lấy toàn bộ phần còn ở kho" nên không có dòng nào.
    /// Màn hình phải chịu được danh sách rỗng, đừng coi rỗng là lỗi.
    /// </summary>
    public List<BackReqLine> BackLines { get; set; } = new();

    public string? BackCancelledBy { get; set; }
    public DateTime? BackCancelledAt { get; set; }
    public string? BackCancelReason { get; set; }

    // ── Bốn con số của luồng back ──
    //
    // Repository ĐẾM TỪ SỔ SERIAL rồi gán vào, không lưu cột tổng nào trên
    // header. Lưu sẵn là phải nhớ cập nhật ở mọi đường ghi, và chỉ cần quên
    // một đường là tổng sai vĩnh viễn — đúng lỗi đã xảy ra với bảng đề nghị cũ.

    /// <summary>Còn ở kho SCS, chưa giao lần nào: <c>status = 'received'</c>.</summary>
    public int BackRemainQty { get; set; }

    /// <summary>
    /// Đã TỪNG giao sang FA: <c>sent_fa_at IS NOT NULL</c>.
    ///
    /// Bám mốc thời gian chứ không bám <c>status = 'at_fa'</c>: hàng giao rồi
    /// FA trả lại hết (mục 3) thì status về <c>returned</c>, mà lượt giao đó
    /// vẫn đã xảy ra.
    /// </summary>
    public int BackSentQty { get; set; }

    /// <summary>Đang ở FA lúc này: <c>status = 'at_fa'</c>.</summary>
    public int AtFaQty { get; set; }

    /// <summary>FA đã trả về SCS: <c>status = 'returned'</c>.</summary>
    public int BackReturnedQty { get; set; }

    public List<ReturnInstructionLine> Lines { get; set; } = [];

    /// <summary>Tổng SL kỳ vọng của cả phiếu — dùng ở danh sách và trong mail.</summary>
    public int TotalQty => Lines.Sum(l => l.Qty);

    /// <summary>
    /// Tổng SL THỰC NHẬN = số serial đã đăng ký vào phiếu (mục 2a). Suy ra từ
    /// dòng chứ không lưu trên header, cùng lý do với <see cref="TotalQty"/>.
    /// </summary>
    public int ReceivedQty => Lines.Sum(l => l.ReceivedQty);

    /// <summary>
    /// Đã nhận nhiều hơn chỉ thị ở ít nhất một model. KHÔNG phải lỗi: hàng về
    /// nhiều hơn khách báo là chuyện thường, và mục 2b có nhiệm vụ mail cho FA
    /// đúng số thực tế. Màn hình chỉ cần hiện cảnh báo.
    /// </summary>
    public bool OverReceived => Lines.Any(l => l.ReceivedQty > l.Qty);

    /// <summary>
    /// Đã nhận ÍT hơn chỉ thị ở ít nhất một model. Cũng không phải lỗi — khách
    /// báo 100 mà về 94 là chuyện thường; việc của hệ thống là báo FA số thực.
    /// </summary>
    public bool ShortReceived => Lines.Any(l => l.ReceivedQty < l.Qty);

    /// <summary>
    /// Lệch của cả phiếu = thực nhận − chỉ thị. Dương là nhận vượt, âm là thiếu.
    ///
    /// Tính từ hai con số chứ KHÔNG ghi SL thực nhận đè lên
    /// <c>return_instruction_lines.qty</c>: qty là mốc để so, ghi đè nó là mất
    /// luôn cái để so và từ đó bảng lệch luôn báo 0.
    /// </summary>
    public int DiffQty => ReceivedQty - TotalQty;

    /// <summary>Đã chốt thực nhận. Mở lại phiếu KHÔNG xoá mốc này.</summary>
    public bool IsClosed => ClosedAt is not null;

    /// <summary>
    /// Số model trong phiếu. Mỗi dòng đúng một model (unique theo
    /// <c>(doc_id, model)</c>) nên đếm dòng chính là đếm model — đặt tên theo
    /// thứ người dùng đọc, không theo cách lưu.
    /// </summary>
    public int ModelCount => Lines.Count;

    // ── Luồng back: trạng thái suy ra ──

    /// <summary>FA đã đề nghị nhận lại hàng (kể cả đã xong hoặc đã huỷ).</summary>
    public bool BackRequested => BackStatus is not null;

    public bool BackIsCancelled => BackStatus == ReturnBackStatus.Cancelled;

    /// <summary>Đã giao xong — không còn con nào ở kho để giao.</summary>
    public bool BackIsDelivered => BackStatus == ReturnBackStatus.Delivered;

    /// <summary>Luồng back đang chạy, chưa xong chưa huỷ.</summary>
    public bool BackIsOpen => BackRequested && !BackIsDelivered && !BackIsCancelled;

    /// <summary>
    /// Đã giao được con nào nhưng chưa xong. Đây là mốc KHÔNG CÒN HUỶ ĐƯỢC:
    /// hàng đã ở FA thì huỷ là để lại một lô hàng ở FA không ai đứng tên.
    /// </summary>
    public bool BackIsPartlyDelivered => !BackIsDelivered && BackSentQty > 0;

    /// <summary>
    /// Bước đang chờ ai — SUY RA từ <see cref="BackStatus"/>, không phải cột.
    ///
    /// Trả <c>null</c> khi FA chưa đề nghị gì: màn hình cần phân biệt "chưa ai
    /// đề nghị" với "đang chờ quản lý FA", mà một chuỗi rỗng thì không nói
    /// được chuyện đó.
    /// </summary>
    public string? BackStep => BackStatus switch
    {
        ReturnBackStatus.FaRequested => ReturnBackStep.FaApprove,
        ReturnBackStatus.FaApproved => ReturnBackStep.ScsApprove,
        ReturnBackStatus.ScsApproved => ReturnBackStep.ScsDeliver,
        ReturnBackStatus.Delivered or ReturnBackStatus.Cancelled => ReturnBackStep.Done,
        _ => null,
    };

    /// <summary>
    /// SCS WH được phép tách pallet và quét giao chưa.
    ///
    /// CHỈ sau khi quản lý SCS duyệt (10/11). Trước đó chỉ cần
    /// <c>fa_approved</c> — đổi ở MỘT chỗ này để ba nơi gác nút (controller,
    /// màn Web, màn PDA) không ai tự suy lại theo cách riêng.
    ///
    /// Còn phải CÒN hàng ở kho: duyệt xong mà hàng đã đi hết bằng đường khác
    /// thì không có gì để giao.
    /// </summary>
    public bool CanDeliverBack
        => BackStatus == ReturnBackStatus.ScsApproved && BackRemainQty > 0;

    /// <summary>
    /// FA có thể đề nghị (hoặc ĐỀ NGHỊ TIẾP) được chưa: phiếu chưa huỷ, CÒN
    /// hàng ở kho, và KHÔNG có lần đề nghị nào đang chạy.
    ///
    /// Ba trạng thái mở đường: chưa đề nghị lần nào · lần trước đã huỷ · lần
    /// trước đã giao xong (thêm 12/11 — đây là "đề nghị tiếp"). Huỷ và giao
    /// xong đều là lần ĐÃ ĐÓNG, không có gì phải chờ nữa.
    /// </summary>
    public bool CanRequestBack
        => DocStatus != ReturnDocStatus.Cancelled
           && BackRemainQty > 0
           && (BackStatus is null || BackIsCancelled || BackIsDelivered);

    /// <summary>
    /// Đây là lượt ĐỀ NGHỊ TIẾP (lần 2 trở đi) chứ không phải lần đầu — màn
    /// hình đổi nhãn nút và câu nhắc theo cờ này.
    /// </summary>
    public bool CanRequestBackAgain => CanRequestBack && BackRound > 0;
}

/// <summary>
/// Mốc của MỘT lần đề nghị (<c>wms.return_back_rounds</c>) + hai con số của
/// riêng lần đó. Mỗi dòng vẽ thành MỘT tiến trình con trên màn chi tiết phiếu.
/// </summary>
public class ReturnBackRoundRow
{
    public long Id { get; set; }
    public long DocId { get; set; }

    /// <summary>Số lần, đếm từ 1.</summary>
    public int Round { get; set; }

    /// <summary>
    /// SL FA xin ở lần này — ẢNH CHỤP lúc đề nghị.
    /// NULL = xin TOÀN BỘ phần còn ở kho lúc đó (FA không khai dòng nào).
    ///
    /// Không suy lại từ dòng đề nghị: "toàn bộ" là con số thay đổi theo thời
    /// gian, suy lại sau một lượt giao là ra số khác.
    /// </summary>
    public int? AskedQty { get; set; }

    /// <summary>Đã giao trong RIÊNG lần này — cộng từ nhật ký giao của lần.</summary>
    public int DeliveredQty { get; set; }

    public string? Note { get; set; }
    public string? RequestedBy { get; set; }
    public DateTime? RequestedAt { get; set; }

    public string? FaApprovedBy { get; set; }
    public DateTime? FaApprovedAt { get; set; }
    public string? FaComment { get; set; }

    public string? ScsApprovedBy { get; set; }
    public DateTime? ScsApprovedAt { get; set; }
    public string? ScsComment { get; set; }

    public string? DeliveredBy { get; set; }
    public DateTime? DeliveredAt { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    /// <summary>Lần này đã đóng chưa — giao xong hoặc bị huỷ.</summary>
    public bool IsClosed => DeliveredAt is not null || CancelledAt is not null;
}

/// <summary>Một dòng model + số lượng trong chỉ thị (<c>wms.return_instruction_lines</c>).</summary>
public class ReturnInstructionLine
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public int LineNo { get; set; }

    /// <summary>Khớp <c>master.models.code</c> — service kiểm trước khi ghi.</summary>
    public string Model { get; set; } = string.Empty;

    public int Qty { get; set; }
    public string? Note { get; set; }

    /// <summary>
    /// SL thực nhận = số serial của model này đã đăng ký trong
    /// <c>wms.return_instruction_serials</c>. KHÔNG phải cột trong bảng dòng:
    /// repository đếm sang bảng sổ serial rồi gán vào đây.
    ///
    /// Lưu sẵn một con số đếm được là phải nhớ cập nhật ở mọi đường ghi serial
    /// (nhận hàng, giao FA, nhận lại, xuất) — quên một đường là lệch vĩnh viễn.
    /// </summary>
    public int ReceivedQty { get; set; }

    /// <summary>Còn phải nhận bao nhiêu. Âm thì đã nhận vượt — xem OverReceived.</summary>
    public int RemainingQty => Qty - ReceivedQty;

    /// <summary>
    /// Lệch của dòng = thực nhận − chỉ thị. Dương là vượt, âm là thiếu, 0 là đủ.
    ///
    /// Cùng con số với <see cref="RemainingQty"/> nhưng ĐỔI DẤU, và để riêng có
    /// chủ ý: màn hình đọc "còn phải nhận 6" khi đang nhận, còn bảng đối chiếu
    /// và mail báo FA đọc "lệch −6". Bắt một chỗ tự đổi dấu của chỗ kia là nơi
    /// sớm muộn sẽ có người quên.
    /// </summary>
    public int DiffQty => ReceivedQty - Qty;
}

/// <summary>
/// Một serial hàng return đã đăng ký vào phiếu
/// (<c>wms.return_instruction_serials</c>).
///
/// Đây là SỔ của phiếu, không phải ảnh chụp pallet: một serial sẽ đi qua nhiều
/// Pallet ID trong suốt chu trình (WH nhận → giao FA → FA trả → xuất), còn
/// dòng sổ này thì sống từ lúc quét tới lúc xuất xong.
/// </summary>
public class ReturnSerial
{
    public long Id { get; set; }
    public long DocId { get; set; }

    /// <summary>Khớp model của một dòng trong phiếu.</summary>
    public string Model { get; set; } = string.Empty;

    public string SerialNo { get; set; } = string.Empty;

    /// <summary>Mã thùng lúc nhận. NULL khi hàng về rời, không có thùng để quét.</summary>
    public string? BoxNo { get; set; }

    /// <summary>Id <c>wms.pallets</c> ĐANG giữ serial (không phải pallet_id dạng chuỗi).</summary>
    public long? PalletDbId { get; set; }

    /// <summary>Mã pallet dạng người đọc — JOIN sang <c>wms.pallets.pallet_id</c>.</summary>
    public string? PalletNo { get; set; }

    public string Status { get; set; } = ReturnSerialStatus.Received;

    public DateTime ReceivedAt { get; set; }
    public string? CreatedBy { get; set; }
}

/// <summary>
/// Một pallet hàng return của phiếu — gom từ sổ serial, không phải một bảng.
/// </summary>
public class ReturnPallet
{
    public long Id { get; set; }
    public string LotNo { get; set; } = string.Empty;
    public string? LocatorCode { get; set; }
    public int SerialCount { get; set; }
    public int BoxCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }

    /// <summary>Model → số serial trên pallet này.</summary>
    public Dictionary<string, int> ModelCounts { get; set; } = [];
}

/// <summary>
/// Trạng thái của MỘT serial trong chu trình return. Khai đủ ngay từ mục 2a để
/// các mục sau không phải ALTER bảng; CHECK của
/// <c>wms.return_instruction_serials</c> giữ đúng bộ giá trị này.
/// </summary>
public static class ReturnSerialStatus
{
    /// <summary>WH đã nhận vào kho SCS. Mục 2a chỉ sinh ra giá trị này.</summary>
    public const string Received = "received";

    /// <summary>Đã giao sang FA (mục 2c / 3).</summary>
    public const string AtFa = "at_fa";

    /// <summary>FA đã trả về SCS (mục 5).</summary>
    public const string Returned = "returned";

    /// <summary>Đã xuất cho khách (mục 10).</summary>
    public const string Shipped = "shipped";

    /// <summary>Kiểm lại không đạt (nhánh NG của mục 5).</summary>
    public const string Ng = "ng";

    public static bool IsValid(string? s) =>
        s is Received or AtFa or Returned or Shipped or Ng;
}

/// <summary>
/// Giá trị cột <c>wms.return_instructions.back_status</c>.
///
/// NULL (không có hằng nào ở đây) = FA chưa đề nghị gì. Dùng <c>null</c> chứ
/// không thêm một hằng <c>"none"</c>: một dòng chưa bước vào luồng thì không
/// có trạng thái, mà đặt tên cho cái không có là mời người ta đi lọc nó.
/// </summary>
public static class ReturnBackStatus
{
    /// <summary>B1 xong — đang chờ quản lý FA xác nhận.</summary>
    public const string FaRequested = "fa_requested";

    /// <summary>B2 xong — đang chờ quản lý SCS xác nhận.</summary>
    public const string FaApproved = "fa_approved";

    /// <summary>
    /// B3 xong — đang chờ SCS WH tách pallet rồi giao hàng.
    ///
    /// Thêm 10/11. Trước đó <c>fa_approved</c> là giao được ngay; nay phải qua
    /// quản lý SCS. Script nâng cấp đẩy mọi phiếu đang <c>fa_approved</c> sang
    /// đây để chúng không kẹt lại ở một bước vừa mới sinh ra.
    /// </summary>
    public const string ScsApproved = "scs_approved";

    /// <summary>B4 xong — không còn con nào ở kho để giao.</summary>
    public const string Delivered = "delivered";

    public const string Cancelled = "cancelled";

    public static bool IsValid(string? s) =>
        s is FaRequested or FaApproved or ScsApproved or Delivered or Cancelled;
}

/// <summary>
/// Bước đang chờ ai. KHÔNG phải cột trong DB — suy ra từ
/// <see cref="ReturnBackStatus"/> (xem <c>ReturnInstruction.BackStep</c>).
///
/// Vẫn để thành hằng vì web lọc hàng đợi theo đúng ba chuỗi này, và một chuỗi
/// gõ tay ở hai phía là một tab rỗng không báo lỗi gì.
/// </summary>
public static class ReturnBackStep
{
    public const string FaApprove = "fa_approve";

    /// <summary>Chờ quản lý SCS xác nhận (thêm 10/11).</summary>
    public const string ScsApprove = "scs_approve";

    public const string ScsDeliver = "scs_deliver";
    public const string Done = "done";

    public static bool IsValid(string? s) =>
        s is FaApprove or ScsApprove or ScsDeliver or Done;
}

/// <summary>
/// Một dòng đề nghị: FA xin lấy về bao nhiêu con của model nào
/// (<c>wms.return_back_lines</c>).
///
/// Có lại từ 10/11. Bản gộp 09/11 đã bỏ hẳn vì lúc đó đề nghị là "lấy toàn bộ
/// phần còn ở kho"; nay FA đề nghị được MỘT PHẦN nên phải có chỗ ghi SL, và
/// SCS WH tách Pallet ID cho khớp đúng SL này trước khi giao.
///
/// Khớp theo <c>model</c>, không theo id dòng chỉ thị: mỗi lần Office sửa phiếu
/// là xoá mềm toàn bộ dòng rồi chèn lại với id mới.
/// </summary>
public class BackReqLine
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public string Model { get; set; } = string.Empty;

    /// <summary>SL FA xin lấy về. Luôn &gt; 0 (<c>ck_rbl_qty</c>).</summary>
    public int ReqQty { get; set; }

    /// <summary>
    /// Dòng này thuộc LẦN đề nghị nào. Dữ liệu trước 12/11 là 1.
    /// Chỉ mục duy nhất là (doc_id, round, model) — không phải (doc_id, model)
    /// như bản cũ, nếu không lần 2 xin lại cùng model là chèn không vào được.
    /// </summary>
    public int Round { get; set; }

    /// <summary>Đã giao được bao nhiêu con của model này TRONG lần này.</summary>
    public int DeliveredQty { get; set; }
}

/// <summary>
/// Một lượt SCS WH quét pallet giao hàng cho FA
/// (<c>wms.return_back_deliveries</c>).
///
/// Bảng DUY NHẤT còn lại của luồng back sau khi gộp, và nó phải ở lại: giao
/// dần nhiều lượt thì không có nó thì không ai trả lời được "đã đẩy những
/// pallet nào rồi".
/// </summary>
public class ReturnBackDelivery
{
    public long Id { get; set; }
    public long DocId { get; set; }

    /// <summary>
    /// Khoá của pallet lúc giao. NULL khi pallet đã bị tách / gộp / xoá sau đó
    /// — dòng nhật ký vẫn phải còn, nên bảng KHÔNG đặt FK sang wms.pallets.
    /// </summary>
    public long? PalletId { get; set; }

    /// <summary>Pallet ID dạng chữ, giữ lại kể cả khi pallet không còn.</summary>
    public string LotNo { get; set; } = string.Empty;

    /// <summary>Số serial chuyển được ở riêng pallet này, trong riêng lượt này.</summary>
    public int SerialCount { get; set; }

    public DateTime DeliveredAt { get; set; }
    public string? DeliveredBy { get; set; }
}

/// <summary>
/// SL còn ở kho của một model trong phiếu.
///
/// Đặt ở namespace CHA (<c>…ReturnInstructions</c>), không ở
/// <c>…DataAccess</c>: Api và DataAccess là hai namespace CON ngang hàng nên
/// không thấy nhau, và lần trước để ở DataAccess đã cho CS0246 ngay tại
/// <c>BackRemainModelResponse.From</c>. Một type "một model một số lượng" cũng
/// không thuộc riêng tầng nào.
///
/// Khai CLASS có property set được, không dùng positional record: mọi type
/// Dapper map trong solution này đều là class như vậy, và record positional
/// cần Dapper khớp đúng tên tham số constructor — một thứ dễ vỡ im lặng khi ai
/// đó đổi alias trong câu SQL.
/// </summary>
public class BackModelQty
{
    public string Model { get; set; } = string.Empty;
    public int Qty { get; set; }
}

// ReturnBackDeliverResult đã XOÁ (11/11) cùng đường quét giao. Kết quả ghi sổ
// cho MỘT pallet giờ là ReturnBackMoveDelivered bên dưới.

/// <summary>
/// Kết quả huỷ một lần nhận.
///
/// Trả cờ thay vì ném từ repository: repository không có localizer, mà ba tình
/// huống dưới đây đều cần câu thông báo cho người đứng ở PDA.
/// </summary>
public class ReturnReleaseResult
{
    /// <summary>Pallet không tồn tại / đã xoá mềm.</summary>
    public bool NotFound { get; set; }

    /// <summary>Pallet không có dòng sổ serial nào của phiếu này.</summary>
    public bool NotOfDoc { get; set; }

    /// <summary>
    /// Pallet còn serial KHÔNG ở trạng thái <c>received</c> — hàng đã rời kho
    /// SCS (sang FA, đã trả về, đã xuất…). Lúc đó huỷ lần nhận không còn là
    /// sửa một lượt quét sai nữa, nên CHẶN.
    /// </summary>
    public bool HasLeftWarehouse { get; set; }

    /// <summary>Trạng thái đang chặn và số con của nó — để thông báo nói rõ.</summary>
    public string? BlockingStatus { get; set; }
    public int BlockingQty { get; set; }

    /// <summary>Số serial đã giải phóng khỏi sổ.</summary>
    public int FreedSerials { get; set; }

    /// <summary>Mã vị trí pallet đang nằm trước khi xoá (null = chưa gán vị trí).</summary>
    public string? LocatorCode { get; set; }

    public bool Blocked => NotFound || NotOfDoc || HasLeftWarehouse;
}

/// <summary>
/// Phiếu đang giữ hàng chờ giao trên một pallet — trả lời câu "chuyển pallet
/// này ra khu Nhận hàng có phải là giao hàng cho FA không".
/// </summary>
public class ReturnBackPalletTarget
{
    public long DocId { get; set; }

    /// <summary>Số phiếu — chỉ dùng dựng thông báo cho người quét.</summary>
    public string DocNo { get; set; } = default!;

    /// <summary>
    /// Trạng thái luồng back lúc đọc. Repository KHÔNG tự phán xét: chặn hay cho
    /// đi là quyết định của tầng nghiệp vụ.
    /// </summary>
    public string? BackStatus { get; set; }

    /// <summary>Số serial của phiếu đang ở <c>received</c> trên pallet này.</summary>
    public int ReceivedQty { get; set; }
}

/// <summary>
/// Kết quả ghi sổ giao hàng cho một pallet, chạy trong transaction đổi vị trí.
///
/// Hai cờ <see cref="DocGone"/> / <see cref="WrongStep"/> nghĩa là KHÔNG ghi gì
/// cả — tầng nghiệp vụ đọc rồi ném lỗi đã dịch, và cú ném đó mới là thứ làm
/// pallet không bị chuyển.
/// </summary>
public class ReturnBackMoveDelivered
{
    /// <summary>Phiếu vừa bị xoá mềm giữa lúc kiểm và lúc ghi.</summary>
    public bool DocGone { get; set; }

    /// <summary>
    /// Phiếu không còn ở <c>scs_approved</c> — quản lý SCS vừa huỷ duyệt, hoặc
    /// phiếu đã bị huỷ. Hàng chỉ được chuyển nội bộ trong kho.
    /// </summary>
    public bool WrongStep { get; set; }

    /// <summary>Trạng thái thực tế đọc được, để thông báo nói rõ phiếu đang ở đâu.</summary>
    public string? BackStatus { get; set; }

    /// <summary>Số serial chuyển sang <c>at_fa</c> trong lượt này.</summary>
    public int DeliveredQty { get; set; }

    /// <summary>Còn bao nhiêu con ở kho sau lượt này (đếm theo phiếu).</summary>
    public int RemainQty { get; set; }

    /// <summary>Lượt này làm XONG LẦN ĐỀ NGHỊ đang mở.</summary>
    public bool Completed { get; set; }

    /// <summary>Lần đề nghị mà lượt giao này thuộc về.</summary>
    public int Round { get; set; }

    // ── Chặn vì pallet nhiều hơn SL lần này xin (chốt 12/11) ──────────
    //
    // FA xin theo model nên trần xét theo model. Pallet 500 con mà lần này chỉ
    // xin 20 thì phải TÁCH PALLET trước; cho đi cả pallet là sổ ghi giao 500 và
    // lần đề nghị đóng luôn — đúng lỗi của bản trước 12/11.

    /// <summary>Pallet có nhiều hơn SL lần này còn cần.</summary>
    public bool TooMany { get; set; }

    /// <summary>Model đầu tiên vượt trần — thông báo gọi đúng tên nó.</summary>
    public string? TooManyModel { get; set; }

    /// <summary>SL của model đó đang nằm trên pallet.</summary>
    public int TooManyOnPallet { get; set; }

    /// <summary>SL của model đó mà lần này CÒN CẦN (có thể là 0).</summary>
    public int TooManyNeed { get; set; }

    public bool Blocked => DocGone || WrongStep || TooMany;
}

/// <summary>
/// Loại hàng trả về. Để hằng chuỗi vì giá trị này đi thẳng vào cột
/// <c>nvarchar</c>, và cũng là hậu tố khoá dịch (<c>Return.GoodsType.*</c>).
///
/// ⚠ TRÙNG CÓ CHỦ Ý với <c>wms.pallets.disposition</c>. Mục 2 phải đối chiếu
/// dòng chỉ thị với pallet WH đã tạo, và bản đồ kho đã vẽ badge RW/RE theo
/// đúng hai chuỗi này — đặt bộ từ vựng thứ hai là chuốc thêm một lớp quy đổi
/// và sớm muộn sẽ lệch.
/// </summary>
public static class ReturnGoodsType
{
    /// <summary>Hàng rework. SI xuất mang đuôi <c>-RE</c>.</summary>
    public const string Rework = "rework";

    /// <summary>Hàng refurbish. SI xuất mang đuôi <c>-R</c>.</summary>
    public const string Refurbish = "refurbish";

    public static bool IsValid(string? s) => s is Rework or Refurbish;

    /// <summary>
    /// Tiền tố số phiếu theo loại. Giữ ở ĐÂY cạnh chính hai hằng loại hàng:
    /// thêm loại thứ ba mà quên tiền tố thì lỗi lộ ra ngay tại đây, thay vì
    /// âm thầm sinh ra một phiếu mang tiền tố của loại khác.
    /// </summary>
    public static string DocPrefix(string goodsType) => goodsType switch
    {
        Rework => "RW",
        Refurbish => "RB",
        _ => throw new ArgumentOutOfRangeException(nameof(goodsType), goodsType,
            "Loại hàng không hợp lệ — không suy ra được tiền tố số phiếu."),
    };
}

/// <summary>
/// Trạng thái phiếu. Mục 1 chỉ sinh ra <see cref="Open"/>; hai giá trị còn lại
/// đã khai sẵn trong CHECK của bảng để mục 2 trở đi không phải ALTER.
/// </summary>
public static class ReturnDocStatus
{
    /// <summary>Đang theo dõi — hàng chưa về đủ.</summary>
    public const string Open = "open";

    /// <summary>Đã nhận đủ hàng.</summary>
    public const string Completed = "completed";

    public const string Cancelled = "cancelled";

    public static bool IsValid(string? s) => s is Open or Completed or Cancelled;
}
