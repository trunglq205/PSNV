// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'container_check_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ContainerCheckNotifier)
final containerCheckProvider = ContainerCheckNotifierProvider._();

final class ContainerCheckNotifierProvider
    extends $NotifierProvider<ContainerCheckNotifier, ContainerCheckState> {
  ContainerCheckNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'containerCheckProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$containerCheckNotifierHash();

  @$internal
  @override
  ContainerCheckNotifier create() => ContainerCheckNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ContainerCheckState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ContainerCheckState>(value),
    );
  }
}

String _$containerCheckNotifierHash() =>
    r'7ce48ddaaef94c783800f29feebad03adb923695';

abstract class _$ContainerCheckNotifier extends $Notifier<ContainerCheckState> {
  ContainerCheckState build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<ContainerCheckState, ContainerCheckState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ContainerCheckState, ContainerCheckState>,
              ContainerCheckState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
