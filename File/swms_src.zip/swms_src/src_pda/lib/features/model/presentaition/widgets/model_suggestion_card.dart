import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';
import 'package:swms_finish_goods/features/model/presentaition/widgets/model_field_grid.dart';

/// Gợi ý lưu kho: khu + tầng rack, chạm từng dòng để sửa.
class ModelSuggestionCard extends StatelessWidget {
  const ModelSuggestionCard({
    super.key,
    required this.model,
    this.onEditArea,
    this.onEditRackRows,
  });

  final ModelDetail model;

  /// null = không cho sửa khu.
  final VoidCallback? onEditArea;

  /// null = không cho sửa tầng rack.
  final VoidCallback? onEditRackRows;

  String? get _areaText {
    if (!model.hasSuggestArea) return null;
    final code = model.suggestAreaCode ?? '';
    final name = model.suggestAreaName ?? '';
    if (code.isEmpty) return name;
    return name.isEmpty ? code : '$code · $name';
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final rows = model.suggestRackRow;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ModelSectionLabel('model_detail.suggestion'.tr()),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              InkWell(
                onTap: onEditArea,
                borderRadius: BorderRadius.circular(AppDimens.rInput),
                child: Row(
                  children: [
                    Expanded(
                      child: ModelFieldGrid(
                        columns: 1,
                        fields: [
                          ModelField(
                            'model_detail.suggest_area'.tr(),
                            _areaText,
                          ),
                        ],
                      ),
                    ),
                    if (onEditArea != null)
                      Icon(Icons.edit_outlined, size: 18, color: swms.primary),
                  ],
                ),
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: AppDimens.sm),
                child: Divider(height: 1, color: swms.border),
              ),
              InkWell(
                onTap: onEditRackRows,
                borderRadius: BorderRadius.circular(AppDimens.rInput),
                child: Row(
                  children: [
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'model_detail.suggest_rack_row'.tr(),
                            style: AppTextStyles.caption.copyWith(
                              color: swms.text3,
                            ),
                          ),
                          const SizedBox(height: AppDimens.xs),
                          if (rows.isEmpty)
                            Text(
                              '—',
                              style: AppTextStyles.code.copyWith(
                                fontWeight: FontWeight.w700,
                                color: swms.text4,
                              ),
                            )
                          else
                            Wrap(
                              spacing: AppDimens.xs,
                              runSpacing: AppDimens.xs,
                              children: [
                                for (final row in rows) _RowChip(row: row),
                              ],
                            ),
                        ],
                      ),
                    ),
                    if (onEditRackRows != null)
                      Icon(Icons.edit_outlined, size: 18, color: swms.primary),
                  ],
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class _RowChip extends StatelessWidget {
  const _RowChip({required this.row});

  final int row;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: swms.primaryTint,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
      ),
      child: Text(
        'model_detail.rack_row_n'.tr(args: ['$row']),
        style: AppTextStyles.caption.copyWith(
          fontWeight: FontWeight.w700,
          color: swms.primaryDark,
        ),
      ),
    );
  }
}