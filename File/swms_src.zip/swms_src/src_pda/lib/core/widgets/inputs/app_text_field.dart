import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';

/// Loại dữ liệu của ô nhập — quyết định viết hoa, formatter, bàn phím.
enum AppInputKind {
  /// Chữ tự do: tên, ghi chú, PO gõ tay.
  text,

  /// Mã: model / lot / box / barcode. Viết hoa, cấm khoảng trắng.
  code,

  /// Số nguyên: số lượng đếm, số box.
  number,
}

/// Ô nhập liệu chuẩn của app.
///
/// Mọi biến thể đều là một constructor, khác nhau ở [kind] + vài cờ:
/// ```dart
/// AppTextField(label: 'Ghi chú')                                   // form thường
/// AppTextField(kind: AppInputKind.code, hint: 'MODEL')             // ô mã
/// AppTextField(kind: AppInputKind.number, label: 'SL')             // ô số
/// AppTextField(softKeyboard: false, clearable: true, filled: true) // ô máy quét
/// ```
///
/// Ba điểm hay sai khi tự viết, widget này lo sẵn:
/// 1. Đổi [softKeyboard] phải nhả focus rồi focus lại thì input connection
///    mới được tạo lại với keyboardType mới — xử lý trong [didUpdateWidget].
/// 2. Nút xoá phải giữ lại focus, nếu không PDA quét tiếp sẽ rơi ra ngoài.
/// 3. Giá trị đổi từ ngoài (vừa quét ghi vào state) — truyền [value] để
///    tự đồng bộ vào controller, con trỏ về cuối.
class AppTextField extends StatefulWidget {
  const AppTextField({
    super.key,
    this.kind = AppInputKind.text,
    this.controller,
    this.focusNode,
    this.value,
    this.label,
    this.hint,
    this.helperText,
    this.errorText,
    this.dense = false,
    this.filled = false,
    this.enabled = true,
    this.readOnly = false,
    this.autofocus = false,
    this.obscureText = false,
    this.clearable = false,
    this.softKeyboard = true,
    this.keyboardType,
    this.textInputAction,
    this.textCapitalization,
    this.textAlign = TextAlign.start,
    this.autocorrect,
    this.inputFormatters,
    this.maxLines = 1,
    this.maxLength,
    this.fontSize,
    this.borderRadius,
    this.prefixIcon,
    this.suffixIcon,
    this.suffixText,
    this.onChanged,
    this.onSubmitted,
    this.onTap,
  });

  final AppInputKind kind;

  final TextEditingController? controller;
  final FocusNode? focusNode;

  /// Giá trị do state ngoài giữ (controlled). Khác text hiện tại → ghi đè.
  final String? value;

  final String? label;
  final String? hint;
  final String? helperText;
  final String? errorText;

  /// Padding gọn — dùng trong card / list dày đặc.
  final bool dense;

  /// Nền đặc (card2), bỏ viền ở trạng thái thường.
  final bool filled;

  final bool enabled;
  final bool readOnly;
  final bool autofocus;
  final bool obscureText;

  /// Hiện nút xoá khi có nội dung; xoá xong giữ nguyên focus.
  final bool clearable;

  /// false → `TextInputType.none`: vẫn focus + con trỏ để nhận máy quét,
  /// nhưng không bung bàn phím mềm.
  final bool softKeyboard;

  // Ba cái dưới null = lấy mặc định theo [kind].
  final TextInputType? keyboardType;
  final TextCapitalization? textCapitalization;
  final bool? autocorrect;

  final TextInputAction? textInputAction;
  final TextAlign textAlign;

  /// Formatter thêm — formatter của [kind] luôn chạy trước.
  final List<TextInputFormatter>? inputFormatters;

  final int maxLines;
  final int? maxLength;

  final double? fontSize;
  final double? borderRadius;

  final Widget? prefixIcon;
  final Widget? suffixIcon;
  final String? suffixText;

  final ValueChanged<String>? onChanged;
  final ValueChanged<String>? onSubmitted;
  final VoidCallback? onTap;

  @override
  State<AppTextField> createState() => _AppTextFieldState();
}

class _AppTextFieldState extends State<AppTextField> {
  TextEditingController? _ownController;
  FocusNode? _ownFocus;

  TextEditingController get _controller =>
      widget.controller ?? (_ownController ??= TextEditingController());

  FocusNode get _focus => widget.focusNode ?? (_ownFocus ??= FocusNode());

  @override
  void initState() {
    super.initState();
    final v = widget.value;
    if (v != null && v != _controller.text) _controller.text = v;
  }

  @override
  void didUpdateWidget(AppTextField oldWidget) {
    super.didUpdateWidget(oldWidget);

    // Giá trị đổi từ ngoài (vừa quét) → đồng bộ, con trỏ về cuối.
    final v = widget.value;
    if (v != null && v != _controller.text) {
      _controller.value = TextEditingValue(
        text: v,
        selection: TextSelection.collapsed(offset: v.length),
      );
    }

    // Đổi chế độ bàn phím: phải nhả focus rồi focus lại thì input connection
    // mới được tạo lại với keyboardType mới.
    if (oldWidget.softKeyboard != widget.softKeyboard && _focus.hasFocus) {
      _focus.unfocus();
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _focus.requestFocus();
        if (!widget.softKeyboard) {
          SystemChannels.textInput.invokeMethod('TextInput.hide');
        }
      });
    }
  }

  @override
  void dispose() {
    _ownController?.dispose();
    _ownFocus?.dispose();
    super.dispose();
  }

  // ── Mặc định theo kind (tham số truyền vào luôn thắng) ─────
  bool get _isText => widget.kind == AppInputKind.text;

  TextInputType? get _keyboardType {
    if (!widget.softKeyboard) return TextInputType.none;
    if (widget.keyboardType != null) return widget.keyboardType;
    return widget.kind == AppInputKind.number ? TextInputType.number : null;
  }

  TextCapitalization get _capitalization =>
      widget.textCapitalization ??
          (widget.kind == AppInputKind.code
              ? TextCapitalization.characters
              : TextCapitalization.none);

  bool get _autocorrect => widget.autocorrect ?? _isText;

  List<TextInputFormatter> _formatters() => [
    if (widget.kind == AppInputKind.number)
      FilteringTextInputFormatter.digitsOnly,
    if (widget.kind == AppInputKind.code)
      FilteringTextInputFormatter.deny(RegExp(r'\s')),
    ...?widget.inputFormatters,
  ];

  double get _radius => widget.borderRadius ?? AppDimens.rInput;

  OutlineInputBorder _border(
      Color color, {
        double width = 1,
        bool none = false,
      }) {
    return OutlineInputBorder(
      borderRadius: BorderRadius.circular(_radius),
      borderSide:
      none ? BorderSide.none : BorderSide(color: color, width: width),
    );
  }

  Widget? _buildSuffix() {
    if (!widget.clearable) return widget.suffixIcon;

    return ValueListenableBuilder<TextEditingValue>(
      valueListenable: _controller,
      builder: (context, value, _) {
        if (value.text.isEmpty) {
          return widget.suffixIcon ?? const SizedBox.shrink();
        }
        return IconButton(
          icon: const Icon(Icons.clear, size: 18),
          color: context.swms.text4,
          onPressed: () {
            _controller.clear();
            widget.onChanged?.call('');
            // Giữ focus để máy quét bắn tiếp là vào thẳng ô này.
            _focus.requestFocus();
          },
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final textStyle = AppTextStyles.bodyStrong.copyWith(
      fontSize: widget.fontSize,
      color: widget.enabled ? swms.text1 : swms.text3,
    );

    return TextField(
      controller: _controller,
      focusNode: _focus,
      enabled: widget.enabled,
      readOnly: widget.readOnly,
      autofocus: widget.autofocus,
      obscureText: widget.obscureText,
      // Giữ con trỏ cả khi bàn phím mềm tắt (chế độ máy quét).
      showCursor: true,
      keyboardType: _keyboardType,
      textInputAction: widget.textInputAction ?? TextInputAction.done,
      textCapitalization: _capitalization,
      textAlign: widget.textAlign,
      autocorrect: _autocorrect,
      enableSuggestions: _autocorrect,
      inputFormatters: _formatters(),
      maxLines: widget.obscureText ? 1 : widget.maxLines,
      maxLength: widget.maxLength,
      style: textStyle,
      onChanged: widget.onChanged,
      onSubmitted: widget.onSubmitted,
      onTap: widget.onTap,
      decoration: InputDecoration(
        isDense: widget.dense,
        labelText: widget.label,
        labelStyle: AppTextStyles.caption.copyWith(color: swms.text3),
        hintText: widget.hint,
        hintStyle: textStyle.copyWith(
          fontWeight: FontWeight.w400,
          color: swms.text4,
        ),
        helperText: widget.helperText,
        helperStyle: AppTextStyles.caption.copyWith(color: swms.text3),
        errorText: widget.errorText,
        errorStyle: AppTextStyles.caption.copyWith(color: swms.danger),
        counterText: widget.maxLength == null ? null : '',
        filled: widget.filled,
        fillColor: swms.card2,
        prefixIcon: widget.prefixIcon,
        suffixIcon: _buildSuffix(),
        suffixText: widget.suffixText,
        suffixStyle: AppTextStyles.caption.copyWith(color: swms.text3),
        contentPadding: widget.dense
            ? const EdgeInsets.symmetric(horizontal: 10, vertical: 10)
            : const EdgeInsets.symmetric(
          horizontal: AppDimens.md,
          vertical: AppDimens.md,
        ),
        border: _border(swms.border, none: widget.filled),
        enabledBorder: _border(swms.border, none: widget.filled),
        disabledBorder: _border(
          swms.border.withValues(alpha: .5),
          none: widget.filled,
        ),
        focusedBorder: _border(swms.primary, width: 1.4),
        errorBorder: _border(swms.danger),
        focusedErrorBorder: _border(swms.danger, width: 1.4),
      ),
    );
  }
}