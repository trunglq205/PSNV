﻿namespace SWMS_WebTool.Models.Filters
{
    public class MaterialDetailFilter : BaseFilter
    {
    }
}
