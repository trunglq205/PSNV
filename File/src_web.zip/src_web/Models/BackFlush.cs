﻿namespace SWMS_WebTool.Models
{
    public class BackFlush
    {
        public Int64? ReceivingCardId { get; set; }
        public string? PlanOrderNumber { get; set; }
        public string? Plant { get; set; }
        public string? Material { get; set; }
        public string? Sloc { get; set; }
        public string? ProductionVersion { get; set; }
        public int PlanOrderQuantity { get; set; }
        public int GRQuantity { get; set; }
        public int TodayQuantity { get; set; }
        public DateTime CreatedDate { get; set; }
        public DateTime? PrintDate { get; set; }
        public DateTime? ReceiveDate { get; set; }
        public DateTime? StoreDate { get; set; }
        public DeliveryPlanStatus Status { get; set; }
        public string? ReceivingCardTime { get; set; }
        public double ReceivedProcess
        {
            get { return (double)GRQuantity / PlanOrderQuantity * 100; }
        }
    }
}
