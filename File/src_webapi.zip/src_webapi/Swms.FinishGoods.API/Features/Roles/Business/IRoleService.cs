using Swms.FinishGoods.Api.Features.Roles.Api;

namespace Swms.FinishGoods.Api.Features.Roles.Business;

public interface IRoleService
{
    /// <summary>Cây catalog dựng từ PermissionCatalog (C#), tên đa ngôn ngữ tra resx theo culture hiện tại.</summary>
    Task<List<PermissionModuleResponse>> GetPermissionCatalogAsync();

    Task<List<RoleResponse>> GetRolesAsync();
    Task<RoleResponse> CreateRoleAsync(CreateRoleRequest request);
    Task UpdateRoleAsync(UpdateRoleRequest request);
    Task UpdateRolePermsAsync(UpdateRolePermsRequest request);
    Task DeleteRoleAsync(string code);

    /// <summary>Quyền hiệu lực của user đang đăng nhập. System role ⟹ toàn quyền (PermissionCatalog.AllCodes).</summary>
    Task<List<string>> GetMyPermissionsAsync();
}
