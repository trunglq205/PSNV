import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_bottom_sheet.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_text_field.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';

/// Hỏi lý do "không đạt · gửi đi rửa". Trả lý do đã trim, `null` nếu huỷ.
///
/// Các hạng mục CHƯA tick được gợi ý sẵn làm lý do — thường là đúng chỗ
/// hỏng, công nhân chỉ cần bổ sung. Dùng bottom sheet để bàn phím không che ô.
Future<String?> showFailReasonSheet(
  BuildContext context, {
  required Set<ContainerCondition> unchecked,
}) => showAppBottomSheet<String>(
  context,
  builder: (_) => _FailReasonSheet(unchecked: unchecked),
);

class _FailReasonSheet extends StatefulWidget {
  final Set<ContainerCondition> unchecked;

  const _FailReasonSheet({required this.unchecked});

  @override
  State<_FailReasonSheet> createState() => _FailReasonSheetState();
}

class _FailReasonSheetState extends State<_FailReasonSheet> {
  late String _note = widget.unchecked
      .map((c) => '- ${c.labelKey.tr()}')
      .join('\n');

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final valid = _note.trim().isNotEmpty;

    return AppBottomSheet(
      icon: Icons.warning_amber_rounded,
      title: LocaleKeys.container_check_fail_title.tr(),
      subtitle: LocaleKeys.container_check_fail_subtitle.tr(),
      actions: [
        AppDialogAction.cancel(context),
        AppDialogAction.confirm(
          label: LocaleKeys.container_check_btn_fail.tr(),
          variant: AppButtonVariant.danger,
          onPressed: valid
              ? () => Navigator.of(context).pop(_note.trim())
              : null,
        ),
      ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          AppTextField(
            value: _note,
            autofocus: true,
            maxLines: 4,
            textInputAction: TextInputAction.newline,
            label: LocaleKeys.container_check_fail_reason.tr(),
            hint: LocaleKeys.container_check_fail_hint.tr(),
            onChanged: (v) => setState(() => _note = v),
          ),
          const SizedBox(height: AppDimens.xs),
          Text(
            LocaleKeys.container_check_fail_note.tr(),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
        ],
      ),
    );
  }
}
