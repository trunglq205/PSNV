﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class InvoiceDetailImport
    {
        public string? DeliveryDate { get; set; }
        public string? Material { get; set; }
        public double TotalQuantity { get; set; }
        public string? Unit { get; set; }
        public string? Category { get; set; }
        public string? Plant { get; set; }
        public string? Sloc { get; set; }

        public List<InvoiceItemDetailImport>? DetailItems {  get; set; }

    }
}
