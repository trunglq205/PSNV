﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class ImportNoPrintPanacim
    {
        public string? Plant { get; set; }
        public string? Sloc { get; set; }
        public string? Material { get; set; }
    }
}
