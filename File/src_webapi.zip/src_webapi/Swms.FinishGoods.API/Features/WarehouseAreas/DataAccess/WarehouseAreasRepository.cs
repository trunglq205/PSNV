using System.Data;
using Dapper;
using Swms.FinishGoods.API.Features.WarehouseAreas.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.WarehouseAreas.DataAccess;

public class WarehouseAreasRepository : IWarehouseAreasRepository
{
    private readonly IDbConnectionFactory _factory;
    public WarehouseAreasRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<IReadOnlyList<WarehouseAreaSummary>> ListAsync(string? mapType, bool includeInactive)
    {
        using var conn = _factory.Create();
        var sql = """
            SELECT
                a.id AS Id, a.area_code AS AreaCode, a.area_name AS AreaName,
                a.map_type AS MapType,
                a.cols AS Cols, a.rows AS Rows, a.cell_meters AS CellMeters,
                a.is_active AS IsActive,
                (SELECT COUNT(1) FROM master.locator_map m
                   WHERE m.parent_type = N'area' AND m.parent_id = a.id AND m.is_deleted = 0) AS CellCount,
                a.created_at AS CreatedAt, a.updated_at AS UpdatedAt
            FROM master.warehouse_areas a
            WHERE a.is_deleted = 0
              AND (@MapType IS NULL OR a.map_type = @MapType)
              AND (@IncludeInactive = 1 OR a.is_active = 1)
            ORDER BY a.map_type, a.area_code;
            """;
        var rows = await conn.QueryAsync<WarehouseAreaSummary>(sql,
            new { MapType = mapType, IncludeInactive = includeInactive ? 1 : 0 });
        return rows.AsList();
    }

    public async Task<WarehouseAreaSummary?> GetAsync(long id)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT
                a.id AS Id, a.area_code AS AreaCode, a.area_name AS AreaName,
                a.map_type AS MapType,
                a.cols AS Cols, a.rows AS Rows, a.cell_meters AS CellMeters,
                a.is_active AS IsActive,
                (SELECT COUNT(1) FROM master.locator_map m
                   WHERE m.parent_type = N'area' AND m.parent_id = a.id AND m.is_deleted = 0) AS CellCount,
                a.created_at AS CreatedAt, a.updated_at AS UpdatedAt
            FROM master.warehouse_areas a
            WHERE a.id = @Id AND a.is_deleted = 0;
            """;
        return await conn.QueryFirstOrDefaultAsync<WarehouseAreaSummary>(sql, new { Id = id });
    }

    public async Task<bool> AreaCodeExistsAsync(string areaCode)
    {
        using var conn = _factory.Create();
        var cnt = await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM master.warehouse_areas WHERE area_code = @c AND is_deleted = 0",
            new { c = areaCode });
        return cnt > 0;
    }

    public async Task<long> CreateAsync(CreateWarehouseAreaRequest req, string? user)
    {
        using var conn = _factory.Create();
        const string sql = """
            INSERT INTO master.warehouse_areas
                (area_code, area_name, map_type, cols, rows, cell_meters,
                 is_active, is_deleted, created_at, created_by)
            OUTPUT INSERTED.id
            VALUES
                (@AreaCode, @AreaName, @MapType, @Cols, @Rows, @CellMeters,
                 1, 0, SYSDATETIME(), @User);
            """;
        return await conn.ExecuteScalarAsync<long>(sql, new
        {
            req.AreaCode, req.AreaName, req.MapType,
            req.Cols, req.Rows,
            CellMeters = req.CellMeters ?? 0.2m,
            User = user
        });
    }

    public async Task UpdateAsync(long id, UpdateWarehouseAreaRequest req, string? user)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.warehouse_areas
            SET area_name = @AreaName,
                cols = @Cols, rows = @Rows,
                cell_meters = @CellMeters,
                updated_at = SYSDATETIME(),
                updated_by = @User
            WHERE id = @Id AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(sql, new
        {
            Id = id, req.AreaName, req.Cols, req.Rows,
            CellMeters = req.CellMeters ?? 0.2m,
            User = user
        });
    }

    public async Task SetActiveAsync(long id, bool active, string? user)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            UPDATE master.warehouse_areas
            SET is_active = @A, updated_at = SYSDATETIME(), updated_by = @User
            WHERE id = @Id AND is_deleted = 0;
            """, new { Id = id, A = active ? 1 : 0, User = user });
    }

    public async Task SoftDeleteAsync(long id, string? user)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            UPDATE master.warehouse_areas
            SET is_deleted = 1, is_active = 0, updated_at = SYSDATETIME(), updated_by = @User
            WHERE id = @Id AND is_deleted = 0;
            """, new { Id = id, User = user });
    }
}
