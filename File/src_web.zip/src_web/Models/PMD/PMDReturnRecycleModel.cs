﻿namespace SWMS_WebTool.Models.PMD
{
    public class PMDReturnRecycleModel
    {
        public Int64 ID { get; set; }
        public string? Lot { get; set; }
        public string? From { get; set; }
        public string? Plant { get; set; }
        public string? Material { get; set; }
        public double? PlanQuantity { get; set; }
        public double? ActualQuantity { get; set; }
        public string? IssueSloc { get; set; }
        public string? ReceiveSloc { get; set; }
        public string? Status { get; set; }
        public string? UserCreate { get; set;}
        public DateTime? TimeCreate { get; set; }

    }
}
