import 'package:swms_finish_goods/core/utils/printing/labels/label.dart';
import 'package:swms_finish_goods/core/utils/printing/sato/sbpl.dart';
import 'package:swms_finish_goods/core/utils/printing/tspl/tspl.dart';

/// Tem pallet 50×50 mm: QR = Lot No + Lot No dạng chữ dọc bên trái.
///
/// In khi tạo pallet mới (Tách pallet → lot mới). QR chỉ chứa đúng [lotNo]
/// để quét lại ở mọi màn đang nhận lot (Tách, Soạn hàng, Chi tiết pallet...).
class PalletLabelData extends Label {
  const PalletLabelData({required this.lotNo});

  final String lotNo;

  // ═══ SBPL ════════════════════════════════════════════════════════════════

  /// Thứ tự PHẢI khớp với thứ tự `%s` xuất hiện trong [_sbplBody].
  List<String> get _sbplValues => [
    ...qrPair(lotNo), // 1-2: DN<len>,<data> — H0084 V00064 size 10
    lotNo, // 3: H0044 V00320
  ];

  @override
  String get sbplSetup => _sbplSetup;

  @override
  String toSbpl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    return buildSbpl(_sbplBody, _sbplValues) +
        Sbpl.quantity(copies) +
        Sbpl.end +
        Sbpl.etx;
  }

  // Block 1 — cấu hình khổ tem 50×50 (V00400 H0400), gửi một lần mỗi phiên.
  static const _sbplSetup =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00400H0400\x1BZ';

  // Block 2 — nội dung nhãn, 3 chỗ `%s`. Đã CẮT đuôi `ESC Q1 ESC Z ETX` của
  // template gốc: [toSbpl] tự sinh để đổi được số bản in.
  static const _sbplBody =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00400H0400\x1BZ\x03\x02\x1BA\x1BPS\x1BW'
      'KNewLabel\x1B%0\x1BH0084\x1BV00064\x1B2D30,L,10,1,0\x1BDN%s,%s\x1B%0\x1BH0044\x1BV00320'
      '\x1BP02\x1BRH0,SATOSANS.ttf,1,042,044,%s';

  // ═══ TSPL ════════════════════════════════════════════════════════════════
  //
  // CHƯA in thử trên MJ8001 — toạ độ ước từ bản SBPL, căn lại bằng các hằng
  // bên dưới. Khổ 51×50 mm = 408×400 dot (203 dpi).
  //
  // Text rotation 90: điểm (x,y) là góc trên-trái TRƯỚC khi xoay ⇒ chữ chạy
  // xuống dưới theo y, thân chữ lấn sang TRÁI của x. Nên x là mép PHẢI
  // của cột chữ.

  /// QR: 21 module (lot ≤ ~14 ký tự) × cell 10 = 210 dot.
  /// Lot dài hơn lên version 2 (25 module = 250 dot) — vẫn vừa khổ 408.
  static const _qrX = 150;
  static const _qrY = 95;
  static const _qrCell = 10;

  /// Font "4" = 24×32 dot/ký tự ⇒ 12 ký tự dài 288 dot theo trục y.
  static const _lotX = 70;
  static const _lotY = 120;
  static const _lotFont = '8';

  @override
  List<String> get tsplSetup => _tsplSetup;

  static const _tsplSetup = [
    'SIZE 51 mm,50 mm',
    'GAP 0,0',
    'DIRECTION 1,0',
    'REFERENCE 0,0',
    'DENSITY 8',
    'SPEED 4',
  ];

  @override
  List<String> toTspl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    return [
      Tspl.cls,
      Tspl.qrcode(_qrX, _qrY, 'L', _qrCell, 'A', 0, lotNo),
      // In 2 lần lệch 1 dot = giả đậm (font bitmap không có bold).
      Tspl.text(_lotX, _lotY, _lotFont, 90, 1, 1, lotNo),
      Tspl.text(_lotX, _lotY + 1, _lotFont, 90, 1, 1, lotNo),
      Tspl.print(copies),
    ];
  }
}
