import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/features/stocktake/domain/entities/stocktake_entities.dart';
import 'package:swms_finish_goods/features/stocktake/presentation/providers/stocktake_providers.dart';

/// Danh sách phiếu kiểm kê theo loại (morning | monthly | shipment).
/// KHÔNG là route trực tiếp — dùng qua 3 wrapper: StocktakeMorning/Monthly/Shipment.
class StocktakeListPage extends ConsumerWidget {
  final String type;
  const StocktakeListPage({super.key, required this.type});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final async = ref.watch(stocktakeCountsProvider(type));

    return Scaffold(
      appBar: AppBar(
        title: Text(_title(type)),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.invalidate(stocktakeCountsProvider(type)),
          ),
        ],
      ),
      body: async.when(
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Padding(padding: const EdgeInsets.all(24), child: Text('$e')),
        ),
        data: (rows) {
          final active =
              rows.where((c) => c.docStatus == 'pending' || c.docStatus == 'counting').toList();
          final closed = rows.where((c) => c.docStatus == 'closed').toList();

          if (rows.isEmpty) {
            return Center(
              child: Text(LocaleKeys.stocktake_empty.tr(),
                  style: const TextStyle(color: Colors.black45)),
            );
          }

          return RefreshIndicator(
            onRefresh: () async => ref.invalidate(stocktakeCountsProvider(type)),
            child: ListView(
              padding: const EdgeInsets.fromLTRB(12, 8, 12, 24),
              children: [
                if (active.isNotEmpty) ...[
                  _GroupLabel(LocaleKeys.stocktake_group_active.tr()),
                  ...active.map((c) => _CountCard(count: c)),
                  const SizedBox(height: 12),
                ],
                if (closed.isNotEmpty) ...[
                  _GroupLabel(LocaleKeys.stocktake_group_closed.tr()),
                  ...closed.map((c) => _CountCard(count: c)),
                ],
              ],
            ),
          );
        },
      ),
    );
  }

  String _title(String t) => switch (t) {
        'morning' => LocaleKeys.home_feature_stocktake_morning.tr(),
        'monthly' => LocaleKeys.home_feature_stocktake_monthly.tr(),
        'shipment' => LocaleKeys.home_feature_stocktake_shipment.tr(),
        _ => LocaleKeys.stocktake_title.tr(),
      };
}

class _GroupLabel extends StatelessWidget {
  final String text;
  const _GroupLabel(this.text);
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 8, 4, 6),
        child: Text(text,
            style: const TextStyle(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                letterSpacing: .5,
                color: Colors.black54)),
      );
}

class _CountCard extends StatelessWidget {
  final CountSummary count;
  const _CountCard({required this.count});

  @override
  Widget build(BuildContext context) {
    final pct = (count.progress * 100).round();
    final (label, color) = _statusMeta(count.docStatus);
    final locked = count.docStatus == 'closed';

    return Card(
      margin: const EdgeInsets.only(bottom: 10),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: locked
            ? null
            : () => context.router.push(StocktakeDetailRoute(id: count.id)),
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(children: [
                Text(count.docNo,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13)),
                const SizedBox(width: 8),
                _pill(label, color),
                if (count.discrepancyLines > 0) ...[
                  const SizedBox(width: 6),
                  _pill(
                      '${count.discrepancyLines} ${LocaleKeys.stocktake_diff_short.tr()}',
                      const Color(0xFFD9534F)),
                ],
                const Spacer(),
                Text('$pct%',
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w800,
                        color: Color(0xFF2F6FB0))),
              ]),
              const SizedBox(height: 6),
              Text(count.description ?? count.docNo,
                  style: const TextStyle(fontSize: 14, fontWeight: FontWeight.w600)),
              const SizedBox(height: 3),
              Text(
                '${count.totalLines} ${LocaleKeys.stocktake_pallets_word.tr()} · '
                '${count.countedLines}/${count.totalLines} ${LocaleKeys.stocktake_counted_word.tr()} · '
                '${_fmtDate(count.countDate)}',
                style: const TextStyle(fontSize: 12, color: Colors.black45),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _pill(String text, Color color) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
        decoration: BoxDecoration(
            color: color.withValues(alpha: .14),
            borderRadius: BorderRadius.circular(999)),
        child: Text(text,
            style: TextStyle(color: color, fontWeight: FontWeight.w700, fontSize: 11)),
      );

  (String, Color) _statusMeta(String s) => switch (s) {
        'pending' => (LocaleKeys.stocktake_status_pending.tr(), const Color(0xFF8A97A5)),
        'counting' => (LocaleKeys.stocktake_status_counting.tr(), const Color(0xFFB7791F)),
        'closed' => (LocaleKeys.stocktake_status_closed.tr(), const Color(0xFF2E8650)),
        _ => (s, const Color(0xFF8A97A5)),
      };

  String _fmtDate(DateTime d) =>
      '${d.day.toString().padLeft(2, '0')}/${d.month.toString().padLeft(2, '0')}/${d.year}';
}
