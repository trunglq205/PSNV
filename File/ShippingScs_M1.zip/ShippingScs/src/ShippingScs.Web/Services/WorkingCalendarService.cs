using Dapper;
using ShippingScs.Web.Data;

namespace ShippingScs.Web.Services;

public static class DayTypes
{
    public const string Workday = "Workday";
    public const string Weekend = "Weekend";
    public const string Holiday = "Holiday";
    public const string ExtraWorkday = "ExtraWorkday";

    public static readonly string[] All = { Workday, Weekend, Holiday, ExtraWorkday };

    public static bool IsWorking(string dayType) => dayType == Workday || dayType == ExtraWorkday;
}

public class WorkingCalendar
{
    public string Code { get; set; } = "";
    public string Name { get; set; } = "";
    public bool IsDefault { get; set; }
}

public class WorkingDay
{
    public string CalendarCode { get; set; } = "";
    // Dapper đọc cột date ra DateTime; đổi sang DateOnly bằng DateOnly.FromDateTime khi cần.
    public DateTime Date { get; set; }
    public bool IsWorking { get; set; }
    public string DayType { get; set; } = "";
    public string? Note { get; set; }
}

public class WorkingCalendarService
{
    // Một lượt tính lịch không cần quá 3 năm; chặn để tránh nạp nhầm khoảng quá lớn.
    private const int MaxRangeDays = 366 * 3;

    private readonly Db _db;
    private readonly ChangeLogService _log;

    public WorkingCalendarService(Db db, ChangeLogService log)
    {
        _db = db;
        _log = log;
    }

    public async Task<List<WorkingCalendar>> ListCalendarsAsync()
    {
        using var conn = _db.Connection();
        var rows = await conn.QueryAsync<WorkingCalendar>(
            "SELECT Code, Name, IsDefault FROM dbo.WorkingCalendars ORDER BY IsDefault DESC, Code");
        return rows.AsList();
    }

    public async Task<List<WorkingDay>> GetDaysAsync(string calendarCode, DateOnly from, DateOnly to)
    {
        using var conn = _db.Connection();
        var rows = await conn.QueryAsync<WorkingDay>(@"
            SELECT CalendarCode, [Date], IsWorking, DayType, Note
            FROM dbo.WorkingDays
            WHERE CalendarCode = @calendarCode AND [Date] BETWEEN @from AND @to
            ORDER BY [Date]",
            new { calendarCode, from = ToDb(from), to = ToDb(to) });
        return rows.AsList();
    }

    /// <summary>
    /// Nạp lịch cho [from, to] để Schedule Engine dùng. Gọi 1 lần cho cả lượt tính,
    /// lấy rộng ra (ví dụ từ tháng N-2 đến hết 12 tháng FC + leadtime).
    /// calendarCode null = lịch mặc định.
    /// </summary>
    public async Task<WorkingCalendarSnapshot> LoadSnapshotAsync(string? calendarCode, DateOnly from, DateOnly to)
    {
        if (to < from) throw new ArgumentException("to must be >= from", nameof(to));
        if (to.DayNumber - from.DayNumber > MaxRangeDays)
            throw new ArgumentException($"Khoảng ngày vượt quá {MaxRangeDays} ngày.", nameof(to));

        var code = await ResolveCodeAsync(calendarCode);
        var days = await GetDaysAsync(code, from, to);
        var map = days.ToDictionary(d => DateOnly.FromDateTime(d.Date), d => d.IsWorking);
        return new WorkingCalendarSnapshot(code, from, to, map);
    }

    /// <summary>
    /// Sinh ngày cho cả năm: T2–T6 làm việc, CN nghỉ, T7 tuỳ tham số.
    /// Chỉ THÊM ngày chưa có, không ghi đè ngày lễ đã nhập -> bấm lại nhiều lần vẫn an toàn.
    /// </summary>
    public async Task<int> GenerateYearAsync(string calendarCode, int year, bool saturdayIsWorking)
    {
        if (year < 2000 || year > 2100) throw new BusinessException("Năm không hợp lệ.");
        var code = await ResolveCodeAsync(calendarCode);

        var rows = BuildYear(code, year, saturdayIsWorking);

        int inserted;
        using (var conn = _db.Connection())
        {
            conn.Open();
            using var tx = conn.BeginTransaction();
            inserted = await conn.ExecuteAsync(@"
                INSERT INTO dbo.WorkingDays (CalendarCode, [Date], IsWorking, DayType)
                SELECT @CalendarCode, @Date, @IsWorking, @DayType
                WHERE NOT EXISTS (
                    SELECT 1 FROM dbo.WorkingDays WHERE CalendarCode = @CalendarCode AND [Date] = @Date
                )", rows, tx);
            tx.Commit();
        }

        await _log.WriteAsync("Calendar", $"{code}/{year}", "Generate",
            $"Sinh lịch {code} năm {year}: thêm {inserted} ngày (Thứ Bảy {(saturdayIsWorking ? "làm" : "nghỉ")})");
        return inserted;
    }

    /// <summary>Đổi loại một ngày (đánh dấu lễ, làm bù...). Ngày chưa có thì tạo mới.</summary>
    public async Task SetDayAsync(string calendarCode, DateOnly date, string dayType, string? note)
    {
        if (!DayTypes.All.Contains(dayType)) throw new BusinessException("Loại ngày không hợp lệ.");
        var code = await ResolveCodeAsync(calendarCode);
        var isWorking = DayTypes.IsWorking(dayType);
        note = string.IsNullOrWhiteSpace(note) ? null : note.Trim();

        WorkingDay? old;
        using (var conn = _db.Connection())
        {
            old = await conn.QuerySingleOrDefaultAsync<WorkingDay>(
                "SELECT CalendarCode, [Date], IsWorking, DayType, Note FROM dbo.WorkingDays WHERE CalendarCode = @code AND [Date] = @date",
                new { code, date = ToDb(date) });

            await conn.ExecuteAsync(@"
                UPDATE dbo.WorkingDays SET IsWorking = @isWorking, DayType = @dayType, Note = @note
                 WHERE CalendarCode = @code AND [Date] = @date;
                IF @@ROWCOUNT = 0
                    INSERT INTO dbo.WorkingDays (CalendarCode, [Date], IsWorking, DayType, Note)
                    VALUES (@code, @date, @isWorking, @dayType, @note);",
                new { code, date = ToDb(date), isWorking, dayType, note });
        }

        await _log.WriteAsync("Calendar", $"{code}/{date:yyyy-MM-dd}", "SetDay",
            $"{code} {date:dd/MM/yyyy}: {old?.DayType ?? "(chưa có)"} -> {dayType}",
            new { oldType = old?.DayType, newType = dayType, note });
    }

    /// <summary>Tạo danh sách ngày của một năm. Tách riêng để unit test không cần DB.</summary>
    internal static List<WorkingDay> BuildYear(string code, int year, bool saturdayIsWorking)
    {
        var list = new List<WorkingDay>();
        for (var d = new DateOnly(year, 1, 1); d.Year == year; d = d.AddDays(1))
        {
            var off = d.DayOfWeek == DayOfWeek.Sunday
                      || (d.DayOfWeek == DayOfWeek.Saturday && !saturdayIsWorking);
            list.Add(new WorkingDay
            {
                CalendarCode = code,
                Date = ToDb(d),
                IsWorking = !off,
                DayType = off ? DayTypes.Weekend : DayTypes.Workday,
            });
        }
        return list;
    }

    private async Task<string> ResolveCodeAsync(string? calendarCode)
    {
        using var conn = _db.Connection();
        string? code;
        if (string.IsNullOrWhiteSpace(calendarCode))
        {
            code = await conn.ExecuteScalarAsync<string?>(
                "SELECT TOP (1) Code FROM dbo.WorkingCalendars WHERE IsDefault = 1");
            if (code == null) throw new BusinessException("Chưa cấu hình lịch làm việc mặc định.");
        }
        else
        {
            code = await conn.ExecuteScalarAsync<string?>(
                "SELECT Code FROM dbo.WorkingCalendars WHERE Code = @c", new { c = calendarCode.Trim() });
            if (code == null) throw new BusinessException($"Không có lịch làm việc '{calendarCode}'.");
        }
        return code;
    }

    private static DateTime ToDb(DateOnly d) => d.ToDateTime(TimeOnly.MinValue);
}
