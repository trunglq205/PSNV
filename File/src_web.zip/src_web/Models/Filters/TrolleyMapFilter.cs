﻿namespace SWMS_WebTool.Models.Filters
{
    public class TrolleyMapFilter : BaseFilter
    {
        public string Modal { get; set; }
        public string Line { get; set; }
        public DateTime? Date { get; set; } 
        public string Time { get; set; }
        public string Material { get; set; }
    }
}
