import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/part_card_multi.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';

/// 1 dòng model trong bảng của nhãn.
@immutable
class PartCardPreviewRow {
  const PartCardPreviewRow({
    required this.no,
    required this.psnvModel,
    required this.box,
    required this.quantity,
    required this.origin,
    required this.oqc,
  });

  final String no;
  final String psnvModel;
  final String box;
  final String quantity;
  final String origin;
  final String oqc;
}

/// Preview nhãn Part Card — dựng theo layout bản web (`.pcd-card`).
///
/// Hai layout theo [PartCardMode]:
///
/// ```
/// single                              multi
/// ─────────────────────────────       ─────────────────────────────
/// [QR] Part Card         [QR]         [QR] Part Card         [QR]
///      Dim | Weight                        Dim | Weight
/// Pro.Date      | Category            PSNV PO      | CUS PO
/// ┌────────┬─────┬────────┐           MFD          | Cate
/// │ Model  │ Qty │ Origin │           ┌──┬───────┬───┬───┬──────┐
/// └────────┴─────┴────────┘           │ #│ Model │Box│Qty│Origin│
///                                     ├──┴───────┼───┼───┼──────┤
///                                     │  Total   │ n │ m │      │
///                                     └──────────┴───┴───┴──────┘
/// ```
///
/// Luôn vẽ trên nền giấy trắng / mực đen (không theo theme sáng-tối) để giống
/// nhãn in thật.
class PartCardPreview extends StatelessWidget {
  const PartCardPreview({
    super.key,
    required this.form,
    this.mode = PartCardMode.single,
    this.cardId,
    this.rows,
  });

  final PartCardForm form;

  final PartCardMode mode;

  /// Card_ID dùng cho QR. Null → hiển thị chỗ trống (sinh lúc in).
  final String? cardId;

  /// Bảng model. Null → tự dựng từ [form].
  final List<PartCardPreviewRow>? rows;

  // Màu "giấy" — cố định, không lấy từ theme.
  static const Color _ink = Color(0xFF111111);
  static const Color _inkSoft = Color(0xFF555555);
  static const Color _line = Color(0xFFB0B0B0);
  static const Color _headBg = Color(0xFFF0F0F0);

  static const TextStyle _base = TextStyle(
    fontSize: 9.5,
    height: 1.25,
    color: _ink,
  );

  List<PartCardPreviewRow> get _rows =>
      rows ??
      [
        for (var i = 0; i < form.lines.length; i++)
          PartCardPreviewRow(
            no: '${i + 1}',
            psnvModel: form.lines[i].model,
            box: '${form.lines[i].box}',
            quantity: '${form.lines[i].quantity}',
            origin: form.lines[i].origin?.code ?? '',
            oqc: PartCardMultiData.oqcMark(form.lines[i].oqcChecked),
          ),
      ];

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        border: Border.all(color: _line),
      ),
      child: Column(
        children: [
          _buildHead(),
          const Divider(height: 1, thickness: .5, color: _line),
          if (mode.isMulti) ...[
            _buildPairRow(
              leftLabel: 'PSNV PO',
              leftValue: form.psnvPo,
              rightLabel: 'CUS PO',
              rightValue: form.cusPo,
            ),
            const Divider(height: 1, thickness: .5, color: _line),
          ],
          _buildPairRow(
            leftLabel: 'MFD',
            leftValue: form.productionDateText,
            rightLabel: 'Cate',
            rightValue: form.categoryText,
          ),
          if (mode.isMulti) _buildMultiTable() else _buildSingleTable(),
        ],
      ),
    );
  }

  // ── Đầu nhãn ───────────────────────────────────────────────
  Widget _buildHead() {
    return SizedBox(
      height: 64,
      child: Row(
        children: [
          Expanded(
            child: Stack(
              fit: StackFit.expand,
              children: [
                const Positioned(left: 0, top: 0, child: _QrBox(size: 34)),
                const Positioned(
                  top: 16,
                  left: 0,
                  right: 0,
                  child: Text(
                    'Part Card',
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 15,
                      fontWeight: FontWeight.w800,
                      height: 1.1,
                      color: _ink,
                    ),
                  ),
                ),
                Positioned(
                  bottom: 4,
                  left: 8,
                  child: Text.rich(
                    TextSpan(
                      style: _base,
                      children: [
                        const TextSpan(
                          text: 'Dim: ',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                        TextSpan(text: form.dimension),
                        const TextSpan(text: ' cm³  |  '),
                        const TextSpan(
                          text: 'Weight: ',
                          style: TextStyle(fontWeight: FontWeight.w700),
                        ),
                        TextSpan(text: '${form.weightText} kg'),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),
          const VerticalDivider(width: 1, thickness: .5, color: _line),
          const _QrBox(size: 64),
        ],
      ),
    );
  }

  // ── 1 hàng 2 ô: nhãn trái | nhãn phải ──────────────────────
  Widget _buildPairRow({
    required String leftLabel,
    required String? leftValue,
    required String rightLabel,
    required String? rightValue,
  }) {
    return SizedBox(
      height: 18,
      child: Row(
        children: [
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 8),
              child: _Cell(label: leftLabel, value: leftValue),
            ),
          ),
          const VerticalDivider(width: 1, thickness: .5, color: _line),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.only(left: 8),
              child: _Cell(label: rightLabel, value: rightValue),
            ),
          ),
        ],
      ),
    );
  }

  // ── Bảng 1 mã ──────────────────────────────────────────────
  Widget _buildSingleTable() {
    return Table(
      border: TableBorder.all(color: _line, width: .5),
      columnWidths: const {
        0: FlexColumnWidth(2),
        1: FlexColumnWidth(),
        2: FlexColumnWidth(),
      },
      children: [
        const TableRow(
          decoration: BoxDecoration(color: _headBg),
          children: [_HeadCell('Model'), _HeadCell('Qty'), _HeadCell('Origin')],
        ),
        for (final r in _rows)
          TableRow(
            children: [
              _BodyCell(r.psnvModel, align: TextAlign.left),
              _BodyCell(r.quantity),
              _BodyCell(r.origin),
            ],
          ),
      ],
    );
  }

  // ── Bảng nhiều mã ──────────────────────────────────────────
  Widget _buildMultiTable() {
    final totalBox = form.totalBox;
    final totalPcs = form.totalPcs;

    return Table(
      border: TableBorder.all(color: _line, width: .5),
      columnWidths: const {
        0: FixedColumnWidth(18),
        1: FlexColumnWidth(3),
        2: FlexColumnWidth(),
        3: FlexColumnWidth(),
        4: FlexColumnWidth(1.4),
        5: FlexColumnWidth(),
      },
      children: [
        const TableRow(
          decoration: BoxDecoration(color: _headBg),
          children: [
            _HeadCell('#'),
            _HeadCell('Model'),
            _HeadCell('Box'),
            _HeadCell('Qty'),
            _HeadCell('COO'),
            _HeadCell('OQC'),
          ],
        ),
        for (final r in _rows)
          TableRow(
            children: [
              _BodyCell(r.no),
              _BodyCell(r.psnvModel, align: TextAlign.left),
              _BodyCell(r.box),
              _BodyCell(r.quantity),
              _BodyCell(r.origin),
              _BodyCell(r.oqc),
            ],
          ),
        TableRow(
          children: [
            const _BodyCell(''),
            const _BodyCell('Total', align: TextAlign.right, bold: true),
            _BodyCell('$totalBox', bold: true),
            _BodyCell('$totalPcs', bold: true),
            const _BodyCell(''),
            _BodyCell(
              PartCardMultiData.oqcMark(form.anyOqcChecked),
              bold: true,
            ),
          ],
        ),
      ],
    );
  }
}

/// Ô QR. Cần package `qr_flutter` để render thật.
class _QrBox extends StatelessWidget {
  const _QrBox({required this.size});

  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      child: Icon(
        Icons.qr_code_2,
        size: size * .8,
        color: PartCardPreview._inkSoft,
      ),
    );
  }
}

class _Cell extends StatelessWidget {
  const _Cell({required this.label, required this.value});

  final String label;
  final String? value;

  @override
  Widget build(BuildContext context) {
    return Text.rich(
      TextSpan(
        style: PartCardPreview._base,
        children: [
          TextSpan(
            text: '$label: ',
            style: const TextStyle(fontWeight: FontWeight.w700),
          ),
          TextSpan(
            // Chưa có dữ liệu → gạch ngang cho thấy rõ chỗ trống.
            text: (value == null || value!.isEmpty) ? '—' : value,
            style: value == null || value!.isEmpty
                ? const TextStyle(color: PartCardPreview._inkSoft)
                : null,
          ),
        ],
      ),
      maxLines: 1,
      overflow: TextOverflow.ellipsis,
    );
  }
}

class _HeadCell extends StatelessWidget {
  const _HeadCell(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 3, horizontal: 4),
      child: Text(
        text,
        textAlign: TextAlign.center,
        style: PartCardPreview._base.copyWith(
          fontSize: 9,
          fontWeight: FontWeight.w800,
        ),
      ),
    );
  }
}

class _BodyCell extends StatelessWidget {
  const _BodyCell(
    this.text, {
    this.align = TextAlign.center,
    this.bold = false,
  });

  final String text;
  final TextAlign align;
  final bool bold;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 4),
      child: Text(
        text,
        textAlign: align,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: PartCardPreview._base.copyWith(
          fontWeight: bold ? FontWeight.w800 : FontWeight.w600,
        ),
      ),
    );
  }
}
