import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';

part 'shipment_instruction_model.g.dart';

// ─────────────────────────────────────────────────────────────
//  LIST — GET /api/shipment-instructions
// ─────────────────────────────────────────────────────────────

@JsonSerializable(createToJson: false)
class ShipmentInstructionPageModel {
  final List<ShipmentInstructionListItemModel> items;
  final int totalCount;
  final int page;
  final int size;
  final int totalPages;

  /// Tuỳ chọn: {"released": 2, "picking": 2, ...}. Server chưa trả thì null.
  final Map<String, int>? statusCounts;

  const ShipmentInstructionPageModel({
    this.items = const [],
    this.totalCount = 0,
    this.page = 1,
    this.size = 20,
    this.totalPages = 0,
    this.statusCounts,
  });

  factory ShipmentInstructionPageModel.fromJson(Map<String, dynamic> json) =>
      _$ShipmentInstructionPageModelFromJson(json);

  ShipmentInstructionPage toEntity() => ShipmentInstructionPage(
    items: items.map((e) => e.toEntity()).toList(),
    totalCount: totalCount,
    page: page,
    size: size,
    totalPages: totalPages,
    statusCounts: statusCounts == null ? null : _mapCounts(statusCounts!),
  );

  // Bỏ key lạ thay vì ném lỗi.
  static Map<SiStatus, int> _mapCounts(Map<String, int> raw) => {
    for (final e in raw.entries) ?SiStatus.fromKey(e.key): e.value,
  };
}

@JsonSerializable(createToJson: false)
class ShipmentInstructionListItemModel {
  final int id;
  final String docNo;
  final String siNo;
  final String? revision;
  final String? category;
  final String? shipMode;
  final String? docStatus;
  final DateTime? etdDate;
  final DateTime? etaDate;
  final DateTime? vanningDate;
  final DateTime? cutOffAt;
  final String? consigneeCode;
  final String? countryCode;
  final String? forwarderCode;
  final String? picName;
  final bool isSerialRequired;
  final int lineCount;
  final int packingListCount;
  final int modelCount;
  final String? modelsPreview;
  final String? poNos;
  final int qtyRequired;
  final int qtyFulfilled;
  final int qtyCut;
  final int qtyShort;
  final int totalPlt;
  final int totalCtn;
  final int unmatchedBoxCount;

  const ShipmentInstructionListItemModel({
    required this.id,
    required this.docNo,
    required this.siNo,
    this.revision,
    this.category,
    this.shipMode,
    this.docStatus,
    this.etdDate,
    this.etaDate,
    this.vanningDate,
    this.cutOffAt,
    this.consigneeCode,
    this.countryCode,
    this.forwarderCode,
    this.picName,
    this.isSerialRequired = false,
    this.lineCount = 0,
    this.packingListCount = 0,
    this.modelCount = 0,
    this.modelsPreview,
    this.poNos,
    this.qtyRequired = 0,
    this.qtyFulfilled = 0,
    this.qtyCut = 0,
    this.qtyShort = 0,
    this.totalPlt = 0,
    this.totalCtn = 0,
    this.unmatchedBoxCount = 0,
  });

  factory ShipmentInstructionListItemModel.fromJson(
      Map<String, dynamic> json,
      ) => _$ShipmentInstructionListItemModelFromJson(json);

  ShipmentInstructionSummary toEntity() => ShipmentInstructionSummary(
    id: id,
    docNo: docNo,
    siNo: siNo,
    revision: revision,
    category: category,
    shipMode: shipMode,
    status: SiStatus.fromKey(docStatus),
    statusKey: docStatus,
    etdDate: etdDate,
    etaDate: etaDate,
    vanningDate: vanningDate,
    cutOffAt: cutOffAt,
    consigneeCode: consigneeCode,
    countryCode: countryCode,
    forwarderCode: forwarderCode,
    picName: picName,
    isSerialRequired: isSerialRequired,
    lineCount: lineCount,
    modelCount: modelCount,
    modelsPreview: modelsPreview,
    poNos: poNos,
    qtyRequired: qtyRequired,
    qtyFulfilled: qtyFulfilled,
    qtyCut: qtyCut,
    qtyShort: qtyShort,
    totalPlt: totalPlt,
    totalCtn: totalCtn,
    unmatchedBoxCount: unmatchedBoxCount,
  );
}

// ─────────────────────────────────────────────────────────────
//  DETAIL — GET /api/shipment-instructions/{id}
// ─────────────────────────────────────────────────────────────

@JsonSerializable(createToJson: false)
class ShipmentInstructionDetailModel {
  final int id;
  final String docNo;
  final String siNo;
  final String? revision;
  final String? category;
  final String? shipMode;
  final String? docStatus;
  final DateTime? etdDate;
  final DateTime? etaDate;
  final DateTime? vanningDate;
  final DateTime? cutOffAt;
  final String? portOfLoading;
  final String? portOfDischarge;
  final String? countryCode;
  final String? forwarderCode;
  final String? carrierCode;
  final String? consigneeCode;
  final String? packingType;
  final bool isWhiteFilm;
  final bool isCaseMark;
  final bool isSerialRequired;
  final String? picName;
  final int? toAreaId;
  final String? description;
  final Map<String, dynamic>? headerNote;
  final DateTime? createdAt;
  final String? createdBy;
  final List<ShipmentInstructionLineModel> lines;

  // `designatedBoxes` của từng dòng CHƯA map: API đang trả mảng rỗng,
  // chưa chốt cấu trúc. Thêm khi cần.

  const ShipmentInstructionDetailModel({
    required this.id,
    required this.docNo,
    required this.siNo,
    this.revision,
    this.category,
    this.shipMode,
    this.docStatus,
    this.etdDate,
    this.etaDate,
    this.vanningDate,
    this.cutOffAt,
    this.portOfLoading,
    this.portOfDischarge,
    this.countryCode,
    this.forwarderCode,
    this.carrierCode,
    this.consigneeCode,
    this.packingType,
    this.isWhiteFilm = false,
    this.isCaseMark = false,
    this.isSerialRequired = false,
    this.picName,
    this.toAreaId,
    this.description,
    this.headerNote,
    this.createdAt,
    this.createdBy,
    this.lines = const [],
  });

  factory ShipmentInstructionDetailModel.fromJson(Map<String, dynamic> json) =>
      _$ShipmentInstructionDetailModelFromJson(json);

  ShipmentInstructionDetail toEntity() => ShipmentInstructionDetail(
    id: id,
    docNo: docNo,
    siNo: siNo,
    revision: revision,
    category: category,
    shipMode: shipMode,
    status: SiStatus.fromKey(docStatus),
    statusKey: docStatus,
    etdDate: etdDate,
    etaDate: etaDate,
    vanningDate: vanningDate,
    cutOffAt: cutOffAt,
    portOfLoading: portOfLoading,
    portOfDischarge: portOfDischarge,
    countryCode: countryCode,
    forwarderCode: forwarderCode,
    carrierCode: carrierCode,
    consigneeCode: consigneeCode,
    packingType: packingType,
    isWhiteFilm: isWhiteFilm,
    isCaseMark: isCaseMark,
    isSerialRequired: isSerialRequired,
    picName: picName,
    toAreaId: toAreaId,
    description: description,
    headerNote: headerNote ?? const {},
    createdAt: createdAt,
    createdBy: createdBy,
    lines: lines.map((e) => e.toEntity()).toList(),
  );
}

@JsonSerializable(createToJson: false)
class ShipmentInstructionLineModel {
  final int id;
  final int lineNo;
  final String model;
  final String? customerMaterial;
  final String? poNo;
  final String? packingListNo;
  final String? packingItemNo;
  final String? invoiceNo;
  final String? soNo;
  final String? soItemNo;
  final int qtyRequired;
  final String? uom;
  final int plt;
  final int ctn;
  final int? qtyCut;
  final String? cutBy;
  final DateTime? cutAt;
  final int qtyPending;
  final int qtyPicked;
  final int qtyShort;
  final List<PickTaskModel> tasks;

  const ShipmentInstructionLineModel({
    required this.id,
    required this.lineNo,
    required this.model,
    this.customerMaterial,
    this.poNo,
    this.packingListNo,
    this.packingItemNo,
    this.invoiceNo,
    this.soNo,
    this.soItemNo,
    this.qtyRequired = 0,
    this.uom,
    this.plt = 0,
    this.ctn = 0,
    this.qtyCut,
    this.cutBy,
    this.cutAt,
    this.qtyPending = 0,
    this.qtyPicked = 0,
    this.qtyShort = 0,
    this.tasks = const [],
  });

  factory ShipmentInstructionLineModel.fromJson(Map<String, dynamic> json) =>
      _$ShipmentInstructionLineModelFromJson(json);

  ShipmentInstructionLine toEntity() => ShipmentInstructionLine(
    id: id,
    lineNo: lineNo,
    model: model,
    customerMaterial: customerMaterial,
    poNo: poNo,
    packingListNo: packingListNo,
    packingItemNo: packingItemNo,
    invoiceNo: invoiceNo,
    soNo: soNo,
    soItemNo: soItemNo,
    qtyRequired: qtyRequired,
    uom: uom,
    plt: plt,
    ctn: ctn,
    qtyCut: qtyCut,
    cutBy: cutBy,
    cutAt: cutAt,
    qtyPending: qtyPending,
    qtyPicked: qtyPicked,
    qtyShort: qtyShort,
    // Model / PO lấy từ dòng — task từ API không lặp lại hai field này.
    tasks: tasks.map((t) => t.toEntity(model: model, poNo: poNo)).toList(),
  );
}

/// 1 nhiệm vụ lấy hàng trong `lines[].tasks` của API chi tiết SI, và
/// `task` của API màn lấy hàng.
@JsonSerializable(createToJson: false)
class PickTaskModel {
  final int id;
  final int lineId;
  final int? seq;
  final String? locatorCode;
  final String? areaCode;
  final String? palletCode;
  final String? pickMode;
  final String? unitType;
  final bool isFifo;

  /// Vị trí vanning chỉ định. null = bất kỳ trong khu vanning.
  final String? toLocatorCode;

  /// Vị trí vanning đã lưu. null = chưa lưu.
  final String? stagedLocatorCode;
  final DateTime? stagedAt;

  final int boxPlanned;
  final int boxPicked;
  final int qtyPlanned;
  final String? shipmentStatus;
  final DateTime? productionDate;
  final DateTime? pickedAt;
  final String? pickedBy;
  final String? skipReason;

  const PickTaskModel({
    required this.id,
    required this.lineId,
    this.seq,
    this.locatorCode,
    this.areaCode,
    this.palletCode,
    this.pickMode,
    this.unitType,
    this.isFifo = false,
    this.toLocatorCode,
    this.stagedLocatorCode,
    this.stagedAt,
    this.boxPlanned = 0,
    this.boxPicked = 0,
    this.qtyPlanned = 0,
    this.shipmentStatus,
    this.productionDate,
    this.pickedAt,
    this.pickedBy,
    this.skipReason,
  });

  factory PickTaskModel.fromJson(Map<String, dynamic> json) =>
      _$PickTaskModelFromJson(json);

  PickTask toEntity({required String model, String? poNo}) => PickTask(
    id: id,
    lineId: lineId,
    seq: seq,
    locatorCode: locatorCode,
    areaCode: areaCode,
    palletCode: palletCode,
    mode: PickMode.fromKey(pickMode),
    modeKey: pickMode,
    unitType: unitType,
    isFifo: isFifo,
    toLocatorCode: toLocatorCode,
    stagedLocatorCode: stagedLocatorCode,
    stagedAt: stagedAt,
    boxPlanned: boxPlanned,
    boxPicked: boxPicked,
    qtyPlanned: qtyPlanned,
    status: PickTaskStatus.fromKey(shipmentStatus),
    statusKey: shipmentStatus,
    productionDate: productionDate,
    pickedAt: pickedAt,
    pickedBy: pickedBy,
    skipReason: skipReason,
    model: model,
    poNo: poNo,
  );
}