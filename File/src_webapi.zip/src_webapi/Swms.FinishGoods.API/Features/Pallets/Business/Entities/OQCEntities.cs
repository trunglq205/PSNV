namespace Swms.FinishGoods.API.Features.Pallets.Business.Entities
{
    /// <summary>
    /// Một box mẫu OQC rút khỏi pallet. Vòng đời: taken → returned.
    /// Lot mức box_count không có box vật lý để tham chiếu → BoxId = null.
    /// </summary>
    public class OqcEntities
    {
        public long Id { get; set; }
        public long LotId { get; set; }
        public long? BoxId { get; set; }

        public string SampleStatus { get; set; } = OqcSampleStatus.Taken;  // taken | returned
        public string? Result { get; set; }                                // pass | ng
        public string SourceSystem { get; set; } = "QMS";
        public string? Remark { get; set; }

        public DateTime TakenAt { get; set; }
        public string? TakenBy { get; set; }
        public DateTime? ReturnedAt { get; set; }
        public string? ReturnedBy { get; set; }

        public bool IsDeleted { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }
    }

    /// <summary>Trạng thái vòng đời của một box mẫu OQC.</summary>
    public static class OqcSampleStatus
    {
        public const string Taken = "taken";
        public const string Returned = "returned";
    }

    /// <summary>Kết quả kiểm OQC khi trả hàng.</summary>
    public static class OqcResult
    {
        public const string Pass = "pass";
        public const string Ng = "ng";

        public static bool IsValid(string? value) => value is Pass or Ng;
    }

    /// <summary>Tham số thực thi lấy mẫu trong transaction.</summary>
    public sealed class TakeSamplesParams
    {
        public long LotId { get; init; }

        /// <summary>Box vật lý rút ra (serial | box_line). Rỗng khi box_count.</summary>
        public IReadOnlyList<long> BoxIds { get; init; } = [];

        /// <summary>Số box mẫu khi box_count (không có box id để tham chiếu).</summary>
        public int? SampleBoxCount { get; init; }

        /// <summary>Trạng thái kiểm mới của lot: under_inspection | pending_result.</summary>
        public string NewInspectionStatus { get; init; } = default!;

        public string SourceSystem { get; init; } = "QMS";
        public string? Remark { get; init; }
        public string? User { get; init; }
    }

    /// <summary>Tham số thực thi trả hàng trong transaction.</summary>
    public sealed class ReturnSamplesParams
    {
        public long LotId { get; init; }

        /// <summary>Kết quả kiểm: pass | ng — cũng là inspection_status mới của lot.</summary>
        public string Result { get; init; } = default!;

        public string? Remark { get; init; }
        public string? User { get; init; }
    }
}
