﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using System.Data;

namespace SWMS_WebTool.Controllers
{
    public class MaterialDetailController : BaseController
    {
        private readonly ApiService _apiService;

        public MaterialDetailController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var response = await _apiService.GetAllMaterialDetail(pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<MaterialDetail>();

                var model = new MaterialDetailViewModel()
                {
                    Items = items,
                    Filter = new MaterialDetailFilter(),
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };

                return View("Views/MaterialDetail/Index.cshtml", model);

            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Detail(long id)
        {
            try
            {
                var model = await _apiService.GetMaterialDetailById(id);
                model.Name = model.Name == null ? "UNKNOW" : model.Name;

                return PartialView("Views/MaterialDetail/_GetMaterialDetailModel.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Update(long id)
        {
            try
            {
                var model = await _apiService.GetMaterialDetailById(id);
                return PartialView("Views/MaterialDetail/_CreateOrUpdateModel.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public IActionResult Create()
        {
            var model = new MaterialDetail();
            return PartialView("Views/MaterialDetail/_CreateOrUpdateModel.cshtml", model);
        }

        [HttpPost]
        public async Task<ActionResult> Save(MaterialDetail request)
        {
            try
            {
                var model = new MaterialDetailRequest()
                {
                    Id = request.Id,
                    Name = request.Name,
                    Material = request.Material,
                    Description = request.Description,
                    FilePath = request.FilePath,
                };

                await _apiService.CreateOrUpdateMaterialDetail(model);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public IActionResult DeleteMaterialDetail(long id)
        {
            try
            {
                var model = new DeleteObject()
                {
                    Id = id.ToString(),
                    Action = "ConfirmDeleteMaterialDetail",
                    Controller = "MaterialDetail"
                };
                return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteMaterialDetail(long id)
        {
            try
            {
                await _apiService.DeleteMaterialDetail(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportMaterialDetail(IFormFile file)
        {
            try
            {
                if (file == null && file?.Length == 0)
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }

                var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads");
                if (!Directory.Exists(uploadDirectory))
                {
                    Directory.CreateDirectory(uploadDirectory);
                }

                var fileextension = Path.GetExtension(file.FileName);
                var filename = Guid.NewGuid().ToString() + fileextension;
                var filepath = Path.Combine(uploadDirectory, filename);
                using (FileStream fs = System.IO.File.Create(filepath))
                {
                    await file.CopyToAsync(fs);
                }
                DataTable? dt = new DataTable();

                if (!Function.CheckHeaderExcel(filepath, "sheet1", Constants.MaterialDetailCheck))
                {
                    ViewBag.Error = _loc.Get("Msg_TheFileSFormatIsIncorectPleaseCheckAgain");
                }

                dt = Function.GetDataTableFromExcel(filepath, "sheet1", Constants.MaterialDetailCheck);

                if (dt == null && dt?.Columns.Count != Constants.MaterialDetailCheck.Count)
                {
                    ViewBag.Error = _loc.Get("Msg_ErrorOccurred");
                }

                List<ImportMaterialDetailViewModel>? entities = Function.DataTatbleToMaterialDetail(dt);
                if (entities != null && entities.Count > 0)
                {
                    return PartialView("~/Views/MaterialDetail/_ImportMaterialDetailModel.cshtml", entities);
                }

                return View();
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportMaterailDetail([FromBody] List<ImportMaterialDetailViewModel> requests)
        {
            try
            {
                await _apiService.ImportMaterialDetail(requests);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> UploadImageMaterialDetail(UploadImageRequest request)
        {
            try
            {
                using (var ms = new MemoryStream())
                {
                    request.FileUpload.CopyTo(ms);
                    request.ByteImageUpload = ms.ToArray().ToList();
                    request.FileName = request.FileUpload.FileName;
                }

                await _apiService.UploadImageMaterialDetail(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public ActionResult UploadMultipleImageMaterialDetail(IFormFile[] Images)
        {
            try
            {
                var entities = new UploadMultipleRequestVM()
                {
                    UploadImageRequests = new List<UploadImageRequestVM>(),
                };

                foreach (var item in Images)
                {
                    using (var ms = new MemoryStream())
                    {
                        item.CopyTo(ms);
                        var entity = new UploadImageRequestVM()
                        {
                            ByteImageUpload = ms.ToArray().ToList(),
                            FileName = item.FileName,
                            Material = item.FileName.Split(".")[0],
                        };

                        entities.UploadImageRequests.Add(entity);
                    }
                }

                return PartialView("~/Views/MaterialDetail/_UploadMulitpleImage.cshtml", entities);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmUploadMultipleImageMaterialDetail([FromBody] UploadMultipleRequestVM requests)
        {
            try
            {
                await _apiService.UploadImageMaterialDetail(requests);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
