namespace Swms.FinishGoods.Api.Features.PdaApp.Business;

/// <summary>
/// Đọc versionName/versionCode từ file APK (từ AndroidManifest trong APK).
/// Tách interface để service không phụ thuộc cách parse cụ thể (aapt/apk-parser/…),
/// và dễ mock khi test. Implementation mặc định: <see cref="ApkInspector"/>.
/// </summary>
public interface IApkInspector
{
    /// <summary>Đọc metadata từ stream APK. Ném <see cref="InvalidApkException"/> nếu không hợp lệ.</summary>
    Task<ApkInfo> ReadAsync(Stream apk, CancellationToken ct = default);
}

/// <summary>
/// Lưu file APK vào storage (thư mục nội bộ / blob / share) và trả về (path nội bộ, URL công khai).
/// Đây cũng là chỗ tích hợp "updateapp" của hệ thống phát hành xuống thiết bị.
/// </summary>
public interface IApkStorage
{
    /// <summary>
    /// Lưu APK theo version, trả về đường dẫn nội bộ + URL công khai để tải/QR.
    /// </summary>
    Task<(string Path, string Url)> SaveAsync(Stream apk, string version, string fileName, CancellationToken ct = default);
}

/// <summary>APK không hợp lệ / không đọc được manifest.</summary>
public sealed class InvalidApkException : Exception
{
    public InvalidApkException(string message) : base(message) { }
}
