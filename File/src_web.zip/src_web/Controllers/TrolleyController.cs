using System.Data;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Layout;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;
using Wkhtmltopdf.NetCore;
using Wkhtmltopdf.NetCore.Options;

namespace SWMS_WebTool.Controllers
{
    public class TrolleyController : BaseController
    {
        private readonly ApiService _apiService;
        readonly IGeneratePdf _generatePdf;

        public TrolleyController(ApiService apiService, IGeneratePdf generatePdf)
        {
            _apiService = apiService;
            _generatePdf = generatePdf;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] TrolleyFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            return View("Views/Trolley/TrolleyMap.cshtml");
        }

        [HttpGet]
        public async Task<IActionResult> TrolleyMapDetail(string category, TrolleyMapFilter? filter = null)
        {
            try
            {
                var listFloor = await _apiService.GetFloors();

                var floorId = listFloor.Find(e => e.FloorCode == category)?.FloorId;

                if (floorId == null)
                {
                    throw new Exception(_loc.Get("Msg_TrolleyMapNotFound"));
                }
                var floor = await _apiService.GetLayoutDetail(floorId ?? 0);

                var entities = await _apiService.GetAllTrolleyKitting(category);

                var trolleyFiltered = new List<TrolleyKitting>();

                if (filter?.Modal != null || filter?.Line != null || filter?.Material != null || filter?.Date != null || filter?.Time != null)
                {
                    trolleyFiltered = await _apiService.GetAllTrolleyKitting(category, filter?.Modal, filter?.Date?.ToString("yyyy-MM-dd"), filter?.Time, filter?.Line, filter?.Material);
                }
                entities = entities.OrderBy(e => e.ActionStatus).ToList();
                var viewModel = new TrolleyMapDetailViewModel()
                {
                    Floor = floor,
                    Items = entities,
                    TrolleyFiltered = trolleyFiltered,
                    Filter = new TrolleyMapFilter()
                };

                return View("Views/Trolley/TrolleyMapDetail.cshtml", viewModel);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> GetDataTrolleyKitting(string category)
        {
            var entities = await _apiService.GetAllTrolleyKitting(category);

            var trolleyFiltered = new List<TrolleyKitting>();

            entities = entities.OrderBy(e => e.ActionStatus).ToList();

            return Json(new { data = entities });
        }


        [HttpGet]
        public async Task<IActionResult> ViewTrolleyKittingDetail(string category, string trolley)
        {
            try
            {
                var troleyKittings = await _apiService.GetAllTrolleyKitting(category);
                troleyKittings = troleyKittings.Where(e => e.TrolleyCode == trolley && e.Model != null).ToList();
                troleyKittings = troleyKittings.OrderBy(e => e.ActionStatus).ToList();
                return PartialView("~/Views/Trolley/_KittingTrolleyDetailModal.cshtml", (trolley, troleyKittings));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> GenQRTrolley(string category)
        {
            try
            {
                var listFloor = await _apiService.GetFloors();

                var floorId = listFloor.Find(e => e.FloorCode == category)?.FloorId;

                if (floorId == null)
                {
                    throw new Exception(_loc.Get("Msg_TrolleyMapNotFound"));
                }

                var filter = new TrolleyFilter() { Category = category };   

                var res = await _apiService.GetAllTrolley(filter, 1, Constants.PageMaximum);

                var entities = res.Records?.OrderBy(o => int.Parse(o.Code.Substring(2))).ToList();

                var dataGenCode = new List<GenQRCodeLocation>();

                foreach (var item in entities)
                {
                    var qrCode = StringExtensions.GenerateQR(item.Barcode);
                    dataGenCode.Add(new GenQRCodeLocation()
                    {
                        Name = item.Code,
                        QRCode = qrCode
                    });
                }

                // Thiết lập tùy chọn căn lề
                var pdfOptions = new ConvertOptions
                {
                    PageMargins = new Margins
                    {
                        Top = 1,    // Lề trên 0mm
                        Right = 1,  // Lề phải 0mm
                        Bottom = 1, // Lề dưới 0mm
                        Left = 1    // Lề trái 0mm
                    },
                    PageOrientation = Orientation.Portrait,
                    PageSize = Size.A4
                };

                _generatePdf.SetConvertOptions(pdfOptions);

                byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/Trolley/_TrolleyQRCode.cshtml", dataGenCode);
                return File(bytesRC, "application/pdf", string.Format("QR_Trolley_{0}.pdf", category));

                //return View("Views/Trolley/TrolleyMapDetail.cshtml", (floor, entities));
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }
    }
}
