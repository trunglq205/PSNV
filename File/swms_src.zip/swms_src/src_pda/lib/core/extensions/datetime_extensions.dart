import 'package:easy_localization/easy_localization.dart';

extension DateTimeExtension on DateTime {
  String format(String pattern) => DateFormat(pattern).format(this);

  String get mmYYYY => format('MM-yyyy');
  String get yyMMdd => format('yyMMdd');
  String get yyyyMMdd => format('yyyyMMdd');
  String get ddMMyyyy => format('dd/MM/yyyy');
  String get hhMMDDMM => format('HH:mm dd/MM');
}

final _dmyDate = RegExp(r'^(\d{1,2})/(\d{1,2})/(\d{4})$');

/// Chiều ngược lại của [DateTimeExtension]: chuỗi → ngày.
/// Khai báo trên `String?` để gọi thẳng được trên giá trị có thể null
/// (vd `map['MFD'].toDateOrNull()`), không cần `?.` hay `!`.
extension DateStringExtension on String? {
  /// Nhận 2 dạng:
  ///   • `2026-10-08` — ISO yyyy-MM-dd (`DateTime.tryParse` lo, kèm giờ cũng được);
  ///   • `08/10/2026` — dd/MM/yyyy, NGÀY đứng trước (cùng dạng với [DateTimeExtension.ddMMyyyy]).
  /// Trả null khi null / rỗng / không đúng dạng nào / ngày không tồn tại.
  DateTime? toDateOrNull() {
    final s = this?.trim() ?? '';
    if (s.isEmpty) return null;

    final m = _dmyDate.firstMatch(s);
    if (m == null) return DateTime.tryParse(s);

    final day = int.parse(m[1]!);
    final month = int.parse(m[2]!);
    final year = int.parse(m[3]!);
    final date = DateTime(year, month, day);

    // DateTime(2026, 2, 31) không lỗi mà tự "tràn" sang 03/03 → so lại để loại
    // ngày không tồn tại (31/02, 08/13/2026…).
    final valid = date.year == year && date.month == month && date.day == day;
    return valid ? date : null;
  }
}