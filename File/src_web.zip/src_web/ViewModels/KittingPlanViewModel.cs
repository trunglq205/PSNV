﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.ViewModels
{
    public class KittingPlanViewModel : TableViewModel<KittingPlan, KittingPlanFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, KittingPlanFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Tab = filter?.Tab ?? Filter.Tab,
                ProDate = filter?.ProDate ?? Filter.ProDate,
                Cate = filter?.Cate ?? Filter.Cate,
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                PartNo = filter?.SpecialPart ?? Filter.SpecialPart,
                Reservation = filter?.Reservation ?? Filter.Reservation,
                KittingDate = filter?.KittingDate ?? Filter.KittingDate,
                FromTime = filter?.FromTime ?? Filter.FromTime,
                FinishTime = filter?.FinishTime ?? Filter.FinishTime,
                UploadNo = filter?.UploadNo ?? Filter.UploadNo,
                Quantity = filter?.Quantity ?? Filter.Quantity,
                //Date = (filter?.Date ?? Filter.Date)?.ToString("yyyy-MM-dd"),
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
    
    public class BlockSchedulePlanViewModel : TableViewModel<BlockSapSchedulePlan, MasterBlockSapScheduleFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, MasterBlockSapScheduleFilter? filter = null)
        {
            return new
            {
                Tab = filter?.Tab ?? Filter.Tab,
                Cate = filter?.Category ?? Filter.Category,
                Plant = filter?.Plant ?? Filter.Plant,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
