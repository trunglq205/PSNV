import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Nhãn đầu mục trong các màn flow pallet.
class PalletFlowSectionLabel extends StatelessWidget {
  const PalletFlowSectionLabel(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: AppTextStyles.label.copyWith(
        fontWeight: FontWeight.w700,
        color: context.swms.text3,
      ),
    );
  }
}

/// Hộp nhắc có icon + tông màu.
class PalletFlowHintBox extends StatelessWidget {
  const PalletFlowHintBox({
    super.key,
    required this.icon,
    required this.tone,
    required this.bg,
    required this.text,
  });

  final IconData icon;
  final Color tone;
  final Color bg;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: tone.withValues(alpha: .35)),
      ),
      child: Row(
        children: [
          Icon(icon, size: 18, color: tone),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text(text, style: AppTextStyles.caption.copyWith(color: tone)),
          ),
        ],
      ),
    );
  }
}

/// Nút chọn dạng ô vuông: icon trên, nhãn dưới.
class PalletFlowChoiceButton extends StatelessWidget {
  const PalletFlowChoiceButton({
    super.key,
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
    this.tone,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  /// Mặc định `swms.primary`.
  final Color? tone;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final t = tone ?? swms.primary;

    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppDimens.rBtn),
      child: Container(
        padding: const EdgeInsets.symmetric(
          vertical: AppDimens.md,
          horizontal: AppDimens.sm,
        ),
        decoration: BoxDecoration(
          color: selected ? t.withValues(alpha: .10) : swms.card2,
          borderRadius: BorderRadius.circular(AppDimens.rBtn),
          border: Border.all(
            color: selected ? t : swms.border,
            width: selected ? 1.6 : 1,
          ),
        ),
        child: Column(
          children: [
            Icon(icon, size: 22, color: selected ? t : swms.text3),
            const SizedBox(height: AppDimens.xs),
            Text(
              label,
              textAlign: TextAlign.center,
              style: AppTextStyles.caption.copyWith(
                color: selected ? t : swms.text2,
                fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Mã đã quét (vị trí / lot…), có nút xoá để quét lại.
/// [warning] khác null → đổi tông đỏ + hiện dòng nhắc.
class PalletFlowScannedCode extends StatelessWidget {
  const PalletFlowScannedCode({
    super.key,
    required this.label,
    required this.code,
    required this.onClear,
    this.clearTooltip,
    this.warning,
  });

  final String label;
  final String code;
  final VoidCallback onClear;
  final String? clearTooltip;
  final String? warning;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final bad = warning != null;
    final tone = bad ? swms.danger : swms.success;
    final bg = bad ? swms.dangerBg : swms.successBg;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Container(
          padding: const EdgeInsets.all(AppDimens.md),
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(AppDimens.rCard),
            border: Border.all(color: tone),
          ),
          child: Row(
            children: [
              Icon(Icons.check_circle, color: tone),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      label,
                      style: AppTextStyles.caption.copyWith(color: swms.text3),
                    ),
                    Text(
                      code,
                      style: AppTextStyles.title.copyWith(
                        fontWeight: FontWeight.w800,
                        color: tone,
                      ),
                    ),
                  ],
                ),
              ),
              IconButton(
                onPressed: onClear,
                icon: const Icon(Icons.close),
                color: swms.text3,
                tooltip: clearTooltip,
              ),
            ],
          ),
        ),
        if (bad) ...[
          const SizedBox(height: AppDimens.xs),
          Row(
            children: [
              Icon(Icons.info_outline, size: 14, color: swms.danger),
              const SizedBox(width: AppDimens.xs),
              Expanded(
                child: Text(
                  warning!,
                  style: AppTextStyles.caption.copyWith(color: swms.danger),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }
}