using System.ComponentModel.DataAnnotations;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

// Vanning trên PDA: kiểm container + gộp pallet / pallet đôi theo chuyến.
// Khớp VanningRemoteDataSource (retrofit) bên PDA.

// ── Kiểm container ──────────────────────────────────────────
/// <summary>
/// Result: pass | fail. PassedConditions: mã hạng mục đạt (floor | dry | intact | door).
/// Pass: đủ 4 hạng mục + đủ ảnh bước "Tình trạng container". Fail: Note bắt buộc.
/// </summary>
public class TripInspectionRequest
{
    [Required, MaxLength(10)] public string Result { get; set; } = "";
    public List<string>? PassedConditions { get; set; }
    [MaxLength(1000)] public string? Note { get; set; }
}

public record TripInspectionResponse(
    long Id, string Result, List<string> PassedConditions, string? Note,
    string? ContainerNo, DateTime InspectedAt, string? InspectedBy)
{
    public static TripInspectionResponse From(TripInspectionRow r) => new(
        r.Id, r.Result,
        (r.PassedConditions ?? "").Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries).ToList(),
        r.Note, r.ContainerNo, r.InspectedAt, r.InspectedBy);
}

// ── Gộp pallet ──────────────────────────────────────────────
/// <summary>1 mục gộp được: Type = pallet | box.</summary>
public record TripMergeCandidateResponse(
    string Code, string Type, string? LocatorCode, int BoxCount, int Pcs);

/// <summary>
/// Phiên gộp mở khi PDA quét pallet gốc. IsNewList = pallet gốc đang rỗng (Pallet List mới).
/// Candidates = pallet khác cùng chuyến còn hàng. Stacks = các cọc đã ghép của chuyến.
/// </summary>
public record TripMergeSessionResponse(
    string BaseCode, bool IsNewList, string? SiCode, string? Route,
    int BaseBoxCount, int BasePcs,
    List<TripMergeCandidateResponse> Candidates,
    List<TripStackResponse> Stacks,
    TripMergePlanResponse? Plan = null);

/// <summary>
/// Kế hoạch vanning của pallet vừa quét: pallet soạn (stowage_pallets) trên Stowage Plan của chuyến.
/// Boxes theo đúng thứ tự xếp của Web (BoxNos). Sources = pallet thật cần ghép vào (Whole = lấy cả pallet,
/// không thì quét từng thùng). Extra = thùng đang trên pallet gốc nhưng không thuộc pallet soạn này (cần tách ra).
/// </summary>
public record TripMergePlanResponse(
    string PlanNo, string PalletCode, string? ColumnCode, int Tier, string? SiNo, string? PalletSize,
    int Total, int OnBase,
    List<TripMergePlanBoxResponse> Boxes,
    List<TripMergeSourceResponse> Sources,
    List<string> Extra,
    TripMergeColumnResponse? Column = null);

/// <summary>Cọc của pallet soạn trong plan — để ghép cọc ngay trên màn Pallet List.
/// StackedBottom / StackedTop: Pallet List thật đã ghép (null = chưa ghép). Placed = đã xếp vào cont.</summary>
public record TripMergeColumnResponse(
    string Code, int CocNo, List<TripMergeTierResponse> Tiers,
    string? StackedBottom, string? StackedTop, bool Placed);

/// <summary>1 tầng của cọc. PalletCode = Pallet List thật đang giữ nhiều thùng nhất của pallet soạn tầng này
/// (tầng đang làm = pallet gốc). Complete = đủ mọi thùng trên đúng pallet đó. IsThis = tầng của pallet gốc.</summary>
public record TripMergeTierResponse(
    int Tier, string PlanPalletCode, string? PalletCode, bool Complete, bool IsThis, int Done, int Total);

/// <summary>1 thùng của pallet soạn. Seq = thứ tự xếp (1 = xếp trước).
/// Status: base (đã trên pallet gốc) | source (nằm ở PalletCode, cần ghép) | missing (chưa có box thật / chưa lấy hàng).</summary>
public record TripMergePlanBoxResponse(
    int Seq, string BoxNo, string? Model, string Status, string? PalletCode, string? LocatorCode, int Pcs);

/// <summary>Pallet thật đang giữ thùng cần ghép. Whole = mọi thùng trên pallet đều thuộc kế hoạch → quét mã pallet.</summary>
public record TripMergeSourceResponse(
    string PalletCode, string? LocatorCode, int Needed, int BoxCount, bool Whole);

/// <summary>1 cọc đã ghép thật. Code = mã cọc trong Stowage Plan (C07); CocNo = 7 (unit_no ảnh cọc).
/// TopCode null = cọc 1 tầng. PlacedAt null = chưa xếp vào cont.</summary>
public record TripStackResponse(
    int CocNo, string BottomCode, string? TopCode, DateTime CreatedAt, string? CreatedBy,
    string? Code = null, DateTime? PlacedAt = null)
{
    public static TripStackResponse From(TripStackRow r) => new(
        r.CocNo, r.BottomCode, r.TopCode, r.CreatedAt, r.CreatedBy, r.ColumnCode, r.PlacedAt);
}

/// <summary>
/// DoublePallet = false (Pallet List): chuyển MỌI thùng của PalletCodes + các thùng BoxCodes
/// sang pallet gốc — đúng thao tác "tách pallet sang pallet có sẵn" (POST /api/pallets/split).
/// DoublePallet: đã bỏ — ghép cọc theo Stowage Plan qua POST {id}/stowage/columns/{code}/stack. Gửi true bị từ chối.
/// ConfirmModelMismatch: người dùng đã đồng ý gộp khác model (như màn Tách pallet).
/// </summary>
public class TripMergeRequest
{
    [Required, MaxLength(50)] public string BaseCode { get; set; } = "";
    public List<string>? PalletCodes { get; set; }
    public List<string>? BoxCodes { get; set; }
    public bool DoublePallet { get; set; }
    public bool ConfirmModelMismatch { get; set; }
}

/// <summary>PalletListCode: mã pallet gốc (Pallet List). CocNo luôn null (giữ cho client cũ).</summary>
public record TripMergeResultResponse(string PalletListCode, int BoxCount, int Pcs, int? CocNo);