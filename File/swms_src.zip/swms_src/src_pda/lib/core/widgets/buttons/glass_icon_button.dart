import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart';

class AppGlassIconButton extends StatelessWidget {
  const AppGlassIconButton({super.key, required this.icon, required this.onTap});
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GlassIconButton(
      icon: Icon(
        icon,
        size: 18,
        color: Colors.white.withValues(alpha: 0.8),
      ),
      onPressed: onTap,
    );
  }
}