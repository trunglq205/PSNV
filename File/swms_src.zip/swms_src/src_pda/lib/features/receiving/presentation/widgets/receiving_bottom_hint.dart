import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Thanh nhắc cố định dưới đáy — nền kính mờ, viền trên mảnh.
/// Hiển thị icon + dòng nhắc; có thể truyền [child] để thay bằng nút.
class ReceivingBottomHint extends StatelessWidget {
  const ReceivingBottomHint({super.key, this.text, this.child})
      : assert(text != null || child != null);

  final String? text;
  final Widget? child;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final cs = Theme.of(context).colorScheme;
    final bottomPad = MediaQuery.of(context).padding.bottom;

    return Container(
      padding: EdgeInsets.fromLTRB(
        AppDimens.md,
        AppDimens.sm,
        AppDimens.md,
        AppDimens.sm + bottomPad,
      ),
      decoration: BoxDecoration(
        color: cs.surface.withValues(alpha: 0.92),
        border: Border(top: BorderSide(color: swms.border)),
        boxShadow: const [
          BoxShadow(
            color: Color(0x0F000000),
            offset: Offset(0, -4),
            blurRadius: 16,
            spreadRadius: -4,
          ),
        ],
      ),
      child: child ??
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.info_outline_rounded, size: 14, color: swms.text3),
              const SizedBox(width: AppDimens.sm),
              Flexible(
                child: Text(
                  text!,
                  style: AppTextStyles.caption.copyWith(
                    fontSize: 11,
                    fontWeight: FontWeight.w500,
                    color: swms.text3,
                  ),
                ),
              ),
            ],
          ),
    );
  }
}
