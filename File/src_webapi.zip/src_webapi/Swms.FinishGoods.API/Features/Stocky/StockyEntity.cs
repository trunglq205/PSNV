namespace Swms.FinishGoods.API.Features.Stocky;

/// <summary>
/// Một xe Stocky trong danh mục (<c>wms.stocky_carts</c>), kèm thông tin HÀNG
/// đang nằm trên xe — phần hàng không lưu trong bảng xe mà SUY RA từ
/// <c>wms.pallets</c> qua <c>stocky_code</c>, nên không bao giờ lệch nhau.
/// </summary>
public class StockyCart
{
    public long Id { get; set; }

    /// <summary>Mã trên QR dán sẵn trên xe. Duy nhất trong số xe chưa xoá mềm.</summary>
    public string Code { get; set; } = string.Empty;

    /// <summary>Tên xe đọc từ QR. Có thể trống.</summary>
    public string? Name { get; set; }
    public string? Vendor { get; set; }

    /// <summary><c>in_warehouse</c> | <c>returned</c>.</summary>
    public string Status { get; set; } = StockyCartStatus.InWarehouse;

    /// <summary>
    /// VỊ TRÍ HIỆU LỰC của xe: ô của pallet đang nằm trên xe; xe rỗng thì là ô
    /// đậu xe của chính nó. NULL = chưa gán ô nào (chưa chạy phần 2 của
    /// <c>db/stocky_schema.sql</c>, hoặc pallet trên xe chưa được xếp vào ô).
    /// </summary>
    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string? AreaCode { get; set; }

    /// <summary>
    /// Ô RIÊNG của xe (<c>wms.stocky_carts.locator_id</c>), KHÔNG phải ô của
    /// pallet trên xe.
    ///
    /// Vì sao phải tách khỏi <see cref="LocatorId"/>: <see cref="LocatorId"/>
    /// ưu tiên ô của pallet, nên với xe đang chở hàng nó nói về HÀNG chứ không
    /// nói về XE. Muốn biết "xe này đang ở FA hay ở kho" thì phải đọc ô của
    /// chính xe — đó là thứ luồng xuất FA ghi vào.
    /// </summary>
    public long? CartLocatorId { get; set; }
    public string? CartLocatorCode { get; set; }

    /// <summary>true = hệ thống đang ghi có hàng trên xe này.</summary>
    public bool HasGoods { get; set; }

    /// <summary>Pallet mới nhất đang nằm trên xe. NULL khi xe rỗng.</summary>
    public string? PalletCode { get; set; }
    public string? Model { get; set; }

    /// <summary>Số pallet đang ghi trên xe. 0 = xe rỗng.</summary>
    public int LotCount { get; set; }

    /// <summary>Tổng số cái (pcs) trên xe.</summary>
    public int Qty { get; set; }

    /// <summary>
    /// Số phiếu xuất của pallet trên xe, nếu hàng đã được đặt lệnh xuất.
    /// Có giá trị mà <see cref="LocatorCode"/> trống nghĩa là hàng đã rời kho
    /// nhưng hệ thống vẫn ghi nằm trên xe — dấu hiệu cần đối chiếu thực tế.
    /// </summary>
    public string? SiNo { get; set; }

    public DateTime? ReceivedAt { get; set; }
    public string? ReceivedBy { get; set; }
    public DateTime? ReturnedAt { get; set; }
    public string? ReturnedBy { get; set; }
    public string? Note { get; set; }
}

/// <summary>
/// Trạng thái xe. Để hằng chuỗi chứ không dùng enum: giá trị này đi thẳng vào
/// cột <c>nvarchar</c> và cũng là hậu tố khoá dịch (<c>Stocky.Status.*</c>),
/// nên một chỗ đổi là cả hệ đổi theo.
///
/// ⚠ ĐỌC KỸ NGHĨA — hai giá trị này nói về việc xe CÓ CÒN ĐƯỢC QUẢN LÝ KHÔNG,
/// KHÔNG nói xe đang đứng ở đâu:
///
///   <c>in_warehouse</c> — xe đang trong hệ thống. Vị trí có thể là bãi đậu ở
///   kho SCS, một ô Receiving (PLxx…), hoặc đã đẩy sang FA. Vị trí đọc ở
///   <see cref="StockyCart.CartLocatorCode"/>, KHÔNG đọc ở trạng thái này.
///
///   <c>returned</c> — đã trả về vendor, xe rời hệ thống. ĐÂY là trạng thái
///   duy nhất khiến xe biến mất khỏi danh sách theo dõi.
///
/// Tên <c>in_warehouse</c> giữ nguyên chuỗi cũ để khỏi phải migrate dữ liệu và
/// khỏi đụng khoá dịch <c>Stocky.Status.*</c>; đọc nó là "đang được quản lý".
/// </summary>
public static class StockyCartStatus
{
    public const string InWarehouse = "in_warehouse";
    public const string Returned = "returned";

    public static bool IsValid(string? s) => s is InWarehouse or Returned;
}

/// <summary>
/// Chiều của một lần quét. Chuỗi khớp với <c>StockyMode.code</c> bên PDA —
/// đổi ở đây là phải đổi cả PDA.
///
///   <c>in</c>  — nhận xe vào kho: xe mới từ vendor, xe cũ vendor giao lại,
///                HOẶC xe đang ở FA được đưa về kho.
///   <c>fa</c>  — đẩy xe sang FA. Xe VẪN được quản lý, chỉ đổi vị trí.
///   <c>out</c> — trả xe về vendor. Xe RỜI hệ thống.
///
/// ⚠ <c>out</c> giữ nguyên chuỗi cũ nhưng NGHĨA đã đổi: trước đây nút
/// "Xuất sang FA" bên PDA gửi <c>out</c> và server xoá xe khỏi danh sách theo
/// dõi. Bản PDA cũ còn chạy ngoài hiện trường sẽ trả nhầm xe về vendor, nên
/// PHẢI cập nhật PDA cùng lúc với API.
/// </summary>
public static class StockyScanMode
{
    public const string In = "in";
    public const string Fa = "fa";
    public const string Out = "out";

    public static bool IsValid(string? s) => s is In or Fa or Out;
}
