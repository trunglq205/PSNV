# Mục 2c — Chỉ thị back hàng (bản sửa, thay thế `swms_2c_wiring.zip`)

**Giải nén lên source, ghi đè, rồi build.** 28 file + 1 script SQL.

> **Xoá gói cũ `swms_2c_wiring.zip` đi, đừng giải nén lại.** Gói này bao trùm
> toàn bộ nội dung gói đó.

---

## 1. Tôi sai ở đâu

Gói trước chỉ gồm phần **nối dây** (quyền, DI, menu, resx), vì tôi kết luận
rằng 14 file feature của mục 2c **đã có** trong source — kết luận đó dựa **chỉ**
vào file zip anh gửi.

Zip có những file đó. **Máy anh thì không.** Nên `ReturnInstructionModule.cs`
của tôi đăng ký những type không tồn tại ⇒ CS0246, đúng 9 lỗi anh gửi.

Bằng chứng khớp chính xác: lỗi **chỉ** nằm ở hai file `ReturnInstructionModule.cs`.
Nếu `ReturnBackRequestsController.cs` có trên đĩa mà thiếu service, nó sẽ đầy lỗi
— mà nó không có lỗi nào, tức là nó không tồn tại.

Tôi cũng kiểm lại và thấy **zip anh gửi tự nó không build được**:
`ReturnFaPalletService.cs` trong zip gọi 7 phương thức
(`GetSerialIndexAsync`, `AttachFaPalletAsync`, `AddMismatchesAsync`,
`GetMismatchesAsync`, `GetMismatchByIdAsync`, `ResolveMismatchAsync`,
`ResolveSerialsAsync`) mà chính `IReturnInstructionRepository.cs` trong zip
không khai. Nghĩa là zip là một bản **trộn** — không phải cây source thật của
anh. Lần sau nếu zip được xuất từ thư mục khác thư mục đang build, nói tôi biết
để tôi không tin nó.

Nhưng đó không phải lý do bào chữa: tôi có cách an toàn mà không chọn —
**gửi luôn file feature**, dù tin là đã có. Lần này gói tự chứa đủ.

## 2. Gói này có gì

### 14 file feature của mục 2c — **đây là phần bị thiếu**

**API** (7)
```
Features/ReturnInstructions/Api/ReturnBackRequestModels.cs
Features/ReturnInstructions/Api/ReturnBackRequestsController.cs
Features/ReturnInstructions/ReturnBackRequestEntity.cs
Features/ReturnInstructions/Business/IReturnBackRequestService.cs
Features/ReturnInstructions/Business/ReturnBackRequestService.cs
Features/ReturnInstructions/DataAccess/IReturnBackRequestRepository.cs
Features/ReturnInstructions/DataAccess/ReturnBackRequestRepository.cs
```

**Web** (7)
```
Features/ReturnInstructions/App/Pages/ReturnBackRequests.razor
Features/ReturnInstructions/App/Pages/ReturnBackRequests.razor.cs
Features/ReturnInstructions/App/Pages/ReturnBackRequests.razor.css
Features/ReturnInstructions/Business/IReturnBackRequestBusiness.cs
Features/ReturnInstructions/Business/ReturnBackRequestBusiness.cs
Features/ReturnInstructions/Business/Models/ReturnBackRequestModels.cs
Features/ReturnInstructions/Client/IReturnBackRequestApi.cs
```

### 14 file dùng chung — **sửa lại so với gói trước, không giống hệt**

| File | Thay đổi |
|---|---|
| API `Features/Roles/Catalog/Perms.cs` | `ReworkRefurbish` +3 lá: `RequestBack`, `ApproveFa`, `ApproveScs`. **Bỏ `ProcessFa`** so với gói cũ |
| API `Features/Roles/Authorization/RequirePermissionAttribute.cs` | + `RequireAnyPermissionAttribute<T1,T2,T3>` (endpoint `cancel` của 2c cần) |
| API `Features/ReturnInstructions/ReturnInstructionModule.cs` | +2 dòng `AddScoped`. **Bỏ dòng `IReturnFaPalletService`** so với gói cũ |
| Web `Shared/Auth/Perms.cs` | +3 enum **và** +3 case tường minh trong `Key()` |
| Web `Shared/App/Model/NavModel.cs` | + menu `Nav.ReworkBack` → `/rework-back` |
| Web `Features/ReturnInstructions/ReturnInstructionModule.cs` | +2 dòng đăng ký |
| 8 file resx | API **+13** khoá, Web **+43** khoá, đồng đều 4 ngôn ngữ |

**Hai chỗ tôi cắt bớt so với gói cũ**, vì file mục 2d không có trên đĩa anh:
`ProcessFa` và `AddScoped<IReturnFaPalletService…>`. Để lại thì sẽ seed một
quyền chết vào DB và đăng ký một service không tồn tại.

Tương tự, resx lần này **không còn 12 khoá `Return.Fa.Err.*`** (của mục 2d).
Nếu anh đã giải nén gói cũ thì chúng đang nằm trong resx; gói này ghi đè sẽ bỏ
chúng ra. Không sao — không có dòng code nào dùng tới.

### 1 script SQL

`return_back_request_schema.sql`

---

## 3. ⚠️ Nếu trên đĩa anh CÓ file `ReturnFaPallet*` thì xoá đi

Bộ file mục 2d trong zip anh gửi **không đầy đủ** (thiếu 7 phương thức
repository như mục 1 đã nói), nên nếu có trên đĩa thì chính nó sẽ làm vỡ build.
Xoá 6 file này:

```
API/Features/ReturnInstructions/Api/ReturnFaPalletModels.cs
API/Features/ReturnInstructions/Api/ReturnFaPalletsController.cs
API/Features/ReturnInstructions/ReturnFaPalletEntity.cs
API/Features/ReturnInstructions/Business/IReturnFaPalletService.cs
API/Features/ReturnInstructions/Business/ReturnFaPalletService.cs
API/Features/ReturnInstructions/Business/ReturnPalletRequestFactory.cs
```

Theo danh sách lỗi anh gửi thì chúng **không** có trên đĩa, nên anh có thể bỏ
qua mục này. Khi nào làm mục 2d tôi sẽ gửi lại bộ đầy đủ.

---

## 4. Thứ tự áp

1. **Chạy SQL** `return_back_request_schema.sql`. Chạy sau
   `return_instruction_schema.sql` → `return_receiving_schema.sql` →
   `return_actual_schema.sql`. Chạy lại nhiều lần không sao.
2. **Giải nén** gói này lên source, ghi đè.
3. **Build API → build Web.**
4. **Gán quyền cho role** ở màn `/roles` (xem mục 6).

---

## 5. Tôi đã kiểm gì — lần này kiểm trên trạng thái ĐĨA THẬT

Tôi dựng lại một bản mô phỏng đúng như đĩa của anh (xoá 6 file mục 2d ra khỏi
cây source), rồi quét trên đó:

| Kiểm | Kết quả |
|---|---|
| **Mọi type được tiêm (DI / `[Inject]`) trong feature đều có định nghĩa** | 14/14 (trừ `IConfiguration`, `NavigationManager` là của .NET) |
| **Type đăng ký trong `ReturnInstructionModule` đều tồn tại** | API 8/8 · Web 7/7 |
| Mọi interface của feature đều được đăng ký DI | API 4/4 · Web 5/5 |
| Quét **toàn bộ API**: `Perms.<Module>.<Screen>.<Action>` treo | **0** |
| `ReworkRefurbish` khai `{View, Create, Process, Approve, Print, RequestBack, ApproveFa, ApproveScs}`, endpoint dùng `{View, Create, Process, RequestBack, ApproveFa, ApproveScs}` | khớp, **không khai quyền chết** |
| Quét **toàn bộ Web**: `Perms.<x>` không có trong enum | **0** |
| Enum có gạch dưới ⇒ có case tường minh trong `Key()` | 3/3 |
| `RequireAnyPermission`: code dùng {2,3} / có {2,3} | khớp |
| Refit route ↔ route controller | **9/9**, không thừa không thiếu |
| Gương quyền controller ↔ nút trên màn | 6/6 |
| Mọi khoá resx màn này dùng, đủ **cả 4** ngôn ngữ | đủ |
| resx: chỉ thêm, không mất / không đổi giá trị cũ của anh | 0 mất, 0 đổi |
| resx 4 ngôn ngữ bằng nhau | API 733 × 4 ✔ |
| Cân `{}` `()` `[]` sau khi bỏ chuỗi + chú thích | 0 lỗi |
| CSS class màn 2c đều có định nghĩa | 40/40 |
| Business interface ↔ chỗ gọi trên màn | 8/8 |
| `@page "/rework-back"` ↔ href trong NavModel | khớp |
| Line ending + BOM | 28/28 giữ nguyên CRLF/BOM của anh |

**Vẫn chưa build được ở đây** — container không có .NET SDK. Nhưng lỗi CS0246
lần trước là loại lỗi kiểm tĩnh bắt được, và lần này tôi kiểm đúng nó.

---

## 6. Gán quyền cho role

Màn web **Quản lý role** (`/roles`) → chọn role → mở nhóm **receiving** → dòng
`rework_refurbish` → tick → Lưu. Không cần SQL.

| Role | Tick thêm |
|---|---|
| FA | `request_back` |
| Quản lý FA | `approve_fa` |
| Quản lý SCS | `approve_scs` |
| SCS WH | — (đã có `process` từ mục 2a) |

Cả bốn đều phải có `view`, không thì không thấy menu và gọi API cũng 403.

- **Role `is_system = 1` được toàn bộ catalog**, không qua `role_permissions` —
  test nhanh thì dùng account đó, thấy ngay sau khi build.
- **Quyền cache 5 phút** phía API. Tick rồi vẫn 403 thì chờ.
- ⚠ Seeder **MERGE theo code và set lại `is_deleted = 0`**: sau này xoá một lá
  quyền khỏi `Perms.cs` rồi khai lại đúng tên cũ sẽ làm sống lại quyền của mọi
  role từng được gán. Muốn bỏ thật phải chạy script như `db/ng_perms_split.sql`.

---

## 7. Màn hình hoạt động thế nào

Menu **Chỉ thị back hàng** (`/rework-back`), gác bằng `rework_refurbish.view`:
cả bốn bên đều THẤY màn này, ai bấm được nút nào thì màn tự lọc theo
`quyền AND bước hiện tại`.

```
B1 FA tạo yêu cầu          → req_status=fa_requested   current_step=fa_approve
B2 Quản lý FA duyệt        → fa_approved               scs_instruct
B3 SCS WH tạo chỉ thị back → scs_instructed            scs_approve
B4 Quản lý SCS duyệt       → scs_approved              done  ← serial đổi sang at_fa
```

- **Hai cột trạng thái, không phải một**: `req_status` là *kết quả*,
  `current_step` là *việc đang chờ ai*. Gộp một cột thì không trả lời được
  "yêu cầu này đang nằm trên bàn ai".
- **Serial chỉ bị chọn ở B4**, không khoá trước. Yêu cầu back chỉ mang dòng
  `model + qty`; sổ serial của phiếu đã là mốc để so, không cần phiếu riêng.
- **B4 chọn FIFO** `WITH (UPDLOCK, READPAST)` theo `received_at, id`, đổi
  `status` sang `at_fa` và **xoá `pallet_id`** (hàng rời kho SCS). Chọn được
  **ít hơn** số xin thì **ghi log, không throw** — hàng có thể vừa bị phiếu
  khác lấy, chặn ở đây là treo cả yêu cầu.
- **Điều kiện bước nằm TRONG câu UPDATE**, không SELECT-rồi-UPDATE: hai người
  duyệt cùng lúc thì người thứ hai cập nhật 0 dòng, không ghi đè.
- **6 tab hàng đợi**: 4 tab đầu theo `current_step`, 2 tab cuối theo
  `req_status`, lọc ở client để con số trên tab còn đúng.

⚠ **Mục 2c chưa khai mail event nào.** Cần mail ở các bước duyệt thì nói tôi
thêm tab thứ 3 vào dialog bánh răng của màn Tái gia công.
