using Swms.FinishGoods.API.Features.Pallets.Api;

namespace Swms.FinishGoods.API.Features.Foss.PalletSync.Api
{
    /// <summary>1 thùng Foss không được thêm vào pallet.</summary>
    /// <param name="Reason">BOX_ON_OTHER_PALLET | SERIALS_ON_OTHER_PALLET | ALREADY_ON_THIS_PALLET</param>
    /// <param name="HeldByPalletId">pallet_id đang giữ thùng / serial.</param>
    /// <param name="Message">Lý do đã dịch theo ngôn ngữ request.</param>
    public sealed record FossSkippedBoxResponse(
        string BoxNo,
        string Reason,
        string? HeldByPalletId,
        string Message);

    /// <summary>Gom số thùng bị bỏ qua theo pallet đang giữ — đọc nhanh khi bỏ qua nhiều thùng.</summary>
    public sealed record FossSkippedGroupResponse(
        string? HeldByPalletId,
        string Reason,
        int Count);

    public sealed record FossTopUpResponse(
        PalletDetailResponse Pallet,
        string Message,
        int FossBoxCount,
        int BoxesAdded,
        int LinesAdded,
        int SkippedBoxes,
        IReadOnlyList<FossSkippedGroupResponse> SkippedByPallet,
        IReadOnlyList<FossSkippedBoxResponse> Skipped,
        bool OqcChanged);
}
