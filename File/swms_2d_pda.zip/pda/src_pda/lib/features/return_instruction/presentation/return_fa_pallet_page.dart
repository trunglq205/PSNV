import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/qr_label.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/core/widgets/common/printer_status_bar.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_fa_notifier.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_instruction_providers.dart';
import 'package:swms_finish_goods/shared/presentation/label_print_dialog.dart';
import 'package:swms_finish_goods/shared/presentation/printer_picker_dialog.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2d — FA đóng lại Pallet ID sau rework.
//
//  Trình tự: quét mã thùng → quét serial từng sản phẩm → Xong thùng → thùng
//  tiếp → Lưu. Server cấp Pallet ID, máy in tem có badge RW / RB.
//
//  ĐƠN GIẢN HƠN màn 2a một bậc: FA không phải chọn model, vì sổ serial đã biết
//  mỗi con thuộc model nào. Chỉ còn hai bước.
//
//  Mỗi serial được kiểm NGAY TRÊN MÁY (sổ tải sẵn khi mở màn) và serial không
//  khớp VẪN cho quét tiếp — chỉ hiện cảnh báo để FA đặt riêng ra tại bàn. Chốt
//  cuối là server: nó đối chiếu lại và tự ghi nhật ký lệch cho SCS.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class ReturnFaPalletPage extends ConsumerStatefulWidget {
  const ReturnFaPalletPage({super.key, required this.docId});

  final int docId;

  @override
  ConsumerState<ReturnFaPalletPage> createState() => _ReturnFaPalletPageState();
}

class _ReturnFaPalletPageState extends ConsumerState<ReturnFaPalletPage> {
  StreamSubscription<String>? _sub;

  /// Chặn bấm hai lần khi đang lưu / in (overlay do appActionProvider lo).
  bool _saving = false;

  /// Đang tải sổ serial. Chưa xong thì chưa kiểm được nên chưa cho quét.
  bool _loadingIndex = true;

  @override
  void initState() {
    super.initState();
    _listen();
    // Tải sổ SAU frame đầu: đọc provider trong initState thì Riverpod chưa
    // sẵn sàng cho một lượt gọi mạng kèm overlay.
    WidgetsBinding.instance.addPostFrameCallback((_) => _loadIndex());
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _loadIndex() async {
    final ok = await ref
        .read(faScanProvider.notifier)
        .loadIndex(widget.docId);
    if (!mounted) return;
    setState(() => _loadingIndex = false);
    // Lỗi đã được appActionProvider toast; _body sẽ hiện nút thử lại.
    if (!ok) return;
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      // Chưa tải xong sổ thì BỎ mã quét được: nhận vào lúc này là nhận mà
      // không kiểm, và FA sẽ tưởng con hàng lạ là hàng tốt.
      if (!ref.read(faScanProvider).isReady) return;
      _guard(() => ref.read(faScanProvider.notifier).onScan(data));
    });
  }

  /// Ngưng listener của page khi mở dialog tự nghe scan (chọn máy in = quét
  /// MAC) — nếu không, mã MAC rơi vào notifier như một serial.
  Future<T> _withScanPaused<T>(Future<T> Function() action) async {
    await _sub?.cancel();
    _sub = null;
    try {
      return await action();
    } finally {
      if (mounted) await _listen();
    }
  }

  Future<void> _pickPrinter() => _withScanPaused(() async {
        if (!mounted) return;
        await pickPrinter(context, ref);
      });

  /// Bọc các lệnh ném exception nghiệp vụ (quét trùng, thùng rỗng…) để chúng
  /// ra toast thay vì nổ lên trên.
  void _guard(void Function() action) {
    try {
      action();
    } catch (e) {
      if (!mounted) return;
      AppToastHelper.toastError(
        context,
        ref.read(errorHandlerProvider).getMessage(e),
      );
    }
  }

  Future<void> _save(ReturnInstruction doc) async {
    if (_saving) return;

    final draft = ref.read(faScanProvider);

    // Có cảnh báo thì hỏi lại một lần: con lạ sẽ KHÔNG vào pallet, và FA phải
    // nhớ đặt chúng riêng ra trước khi rời bàn.
    if (draft.mismatches.isNotEmpty) {
      final ok = await AppDialogHelper.confirm(
        context,
        title: LocaleKeys.return_fa_confirm_save_title.tr(),
        message: LocaleKeys.return_fa_confirm_save_message.tr(namedArgs: {
          'matched': '${draft.matchedCount}',
          'mismatch': '${draft.mismatches.length}',
        }),
        confirmText: LocaleKeys.return_fa_confirm_save_ok.tr(),
      );
      if (!ok || !mounted) return;
    }

    setState(() => _saving = true);
    try {
      final result =
          await ref.read(faScanProvider.notifier).submit(widget.docId);
      if (!mounted || result == null) return;

      ref.invalidate(returnInstructionDetailProvider(doc.id));
      ref.invalidate(returnInstructionListProvider);

      await _printOrOffer(result);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  /// Pallet ĐÃ tạo ở server — in lỗi không rollback được gì, nên chỉ báo và
  /// mời in lại. Cùng cách xử lý với màn 2a.
  Future<void> _printOrOffer(FaPalletResult result) async {
    final badge = QrLabelData.badgeForDisposition(result.doc.goodsType);
    final label = QrLabelData.pallet(result.lotNo, badge: badge);
    final subtitle =
        badge == null ? result.lotNo : '${result.lotNo} · $badge';

    final printed = await printLabel(ref, label);
    if (!mounted) return;

    if (printed) {
      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_fa_toast_saved_printed.tr(namedArgs: {
          'lotNo': result.lotNo,
          'count': '${result.serialCount}',
        }),
      );
    } else {
      final retry = await AppDialogHelper.confirm(
        context,
        title: LocaleKeys.return_fa_print_failed_title.tr(),
        message: LocaleKeys.return_fa_print_failed_message
            .tr(namedArgs: {'lotNo': result.lotNo}),
        confirmText: LocaleKeys.return_fa_print_retry.tr(),
        cancelText: LocaleKeys.return_fa_print_later.tr(),
      );
      if (!mounted) return;
      if (retry) {
        await _withScanPaused(() async {
          if (!mounted) return;
          await showLabelPrintDialog(
            context,
            title: LocaleKeys.label_print_title.tr(),
            subtitle: subtitle,
            label: label,
          );
        });
        if (!mounted) return;
      }
    }

    // Server mới là chốt cuối: nó có thể loại thêm con mà máy tưởng là khớp
    // (sổ tải về đã cũ). Nói ra con số của SERVER, không phải con số của máy.
    if (result.mismatchCount > 0 && mounted) {
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_fa_toast_mismatch
            .tr(namedArgs: {'count': '${result.mismatchCount}'}),
      );
    }
  }

  int _stepOf(FaScanState draft) => draft.isScanningSerials ? 2 : 1;

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(returnInstructionDetailProvider(widget.docId));
    final doc = async is AsyncData<ReturnInstruction> ? async.value : null;
    final draft = ref.watch(faScanProvider);

    return Scaffold(
      appBar: AppBar(
        title: Text(LocaleKeys.return_fa_title.tr()),
        leading: BackIconButton(onPressed: _saving ? () {} : null),
      ),
      body: switch (async) {
        AsyncLoading() => const AppLoading(),
        AsyncError(:final error) => AppErrorView.page(
            message: ref.read(errorHandlerProvider).getMessage(error),
            onRetry: () =>
                ref.invalidate(returnInstructionDetailProvider(widget.docId)),
          ),
        _ => _body(doc!),
      },
      bottomNavigationBar: doc == null || !doc.isOpen
          ? null
          : SafeArea(
              child: Padding(
                padding: const EdgeInsets.all(AppDimens.md),
                child: AppButton(
                  label: LocaleKeys.return_fa_btn_save.tr(namedArgs: {
                    'count': '${draft.matchedCount}',
                  }),
                  variant: AppButtonVariant.primary,
                  icon: Icons.save_outlined,
                  isLoading: _saving,
                  onPressed: draft.hasAnything && !_saving
                      ? () => _save(doc)
                      : null,
                ),
              ),
            ),
    );
  }

  Widget _body(ReturnInstruction doc) {
    final draft = ref.watch(faScanProvider);
    final notifier = ref.read(faScanProvider.notifier);
    final printer = ref.watch(selectedPrinterProvider);
    final step = _stepOf(draft);

    if (!doc.isOpen) {
      return Padding(
        padding: const EdgeInsets.all(AppDimens.md),
        child: AppErrorView.widget(
          message: LocaleKeys.return_fa_doc_closed.tr(),
        ),
      );
    }

    if (_loadingIndex) {
      return const AppLoading();
    }

    // Tải sổ hỏng: KHÔNG cho quét. Quét mà không có sổ là nhận mà không kiểm.
    if (!draft.isReady) {
      return Padding(
        padding: const EdgeInsets.all(AppDimens.md),
        child: AppErrorView.widget(
          message: LocaleKeys.return_fa_index_failed.tr(),
          onRetry: () {
            setState(() => _loadingIndex = true);
            _loadIndex();
          },
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(AppDimens.md),
      children: [
        AppStepperBar(
          current: step,
          steps: [
            StepItem(LocaleKeys.return_fa_step_box.tr()),
            StepItem(LocaleKeys.return_fa_step_serial.tr()),
          ],
        ),
        const SizedBox(height: AppDimens.sm),

        _FaProgressCard(doc: doc, draft: draft),
        const SizedBox(height: AppDimens.md),

        BarcodeScannerButton(
          state: _saving ? ScannerState.loading : ScannerState.scanning,
          scanningLabel: step == 1
              ? LocaleKeys.return_fa_scan_box_label.tr()
              : LocaleKeys.return_fa_scan_serial_label.tr(),
          loadingLabel: LocaleKeys.return_fa_scan_saving.tr(),
        ),
        const SizedBox(height: AppDimens.sm),
        _FaScanHint(
          text: step == 1
              ? LocaleKeys.return_fa_hint_scan_box.tr()
              : LocaleKeys.return_fa_hint_scan_serial.tr(),
        ),
        const SizedBox(height: AppDimens.sm),

        if (draft.isScanningSerials)
          _FaCurrentBoxCard(
            draft: draft,
            onRemoveSerial: notifier.removeSerial,
            onFinish: () => _guard(notifier.finishBox),
            onCancel: notifier.cancelCurrentBox,
          )
        else
          Center(
            child: AppButton(
              label: LocaleKeys.return_fa_box_no_code.tr(),
              variant: AppButtonVariant.subtle,
              size: AppButtonSize.sm,
              icon: Icons.inbox_outlined,
              isFullWidth: false,
              onPressed: () => _guard(notifier.openBoxWithoutCode),
            ),
          ),

        if (draft.mismatches.isNotEmpty) ...[
          const SizedBox(height: AppDimens.sm),
          _FaMismatchCard(items: draft.mismatches),
        ],

        if (draft.boxes.isNotEmpty) ...[
          const SizedBox(height: AppDimens.sm),
          _FaDoneBoxList(
            draft: draft,
            onRemove: notifier.removeBox,
          ),
        ],

        const SizedBox(height: AppDimens.sm),
        PrinterStatusBar(
          device: printer,
          onChange: _saving ? null : _pickPrinter,
        ),
        const SizedBox(height: AppDimens.lg),
      ],
    );
  }
}

/// Tiến độ: còn bao nhiêu con đang ở FA, đã quét được bao nhiêu con KHỚP.
class _FaProgressCard extends StatelessWidget {
  const _FaProgressCard({required this.doc, required this.draft});

  final ReturnInstruction doc;
  final FaScanState draft;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.sm + 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text(doc.docNo, style: AppTextStyles.code),
                const SizedBox(width: 6),
                Text(
                  doc.goodsType,
                  style: AppTextStyles.caption.copyWith(color: c.text3),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Row(
              children: [
                Expanded(
                  child: _Stat(
                    label: LocaleKeys.return_fa_progress_at_fa.tr(),
                    value: '${draft.atFaTotal}',
                  ),
                ),
                Expanded(
                  child: _Stat(
                    label: LocaleKeys.return_fa_progress_matched.tr(),
                    value: '${draft.matchedCount}',
                    tone: draft.matchedCount > 0 ? c.success : null,
                  ),
                ),
                Expanded(
                  child: _Stat(
                    label: LocaleKeys.return_fa_progress_mismatch.tr(),
                    value: '${draft.mismatches.length}',
                    tone: draft.mismatches.isEmpty ? null : c.danger,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _Stat extends StatelessWidget {
  const _Stat({required this.label, required this.value, this.tone});

  final String label;
  final String value;
  final Color? tone;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label, style: AppTextStyles.caption.copyWith(color: c.text3)),
        Text(
          value,
          style: AppTextStyles.title.copyWith(color: tone ?? c.text1),
        ),
      ],
    );
  }
}

/// Một dòng nói ĐANG CHỜ QUÉT GÌ — cùng kiểu với màn 2a.
class _FaScanHint extends StatelessWidget {
  const _FaScanHint({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.qr_code_scanner_rounded, size: 15, color: c.text3),
        const SizedBox(width: 6),
        Text(text, style: AppTextStyles.caption.copyWith(color: c.text2)),
      ],
    );
  }
}

/// Thùng đang quét dở. Serial có cảnh báo được tô khác hẳn.
class _FaCurrentBoxCard extends StatelessWidget {
  const _FaCurrentBoxCard({
    required this.draft,
    required this.onRemoveSerial,
    required this.onFinish,
    required this.onCancel,
  });

  final FaScanState draft;
  final ValueChanged<String> onRemoveSerial;
  final VoidCallback onFinish;
  final VoidCallback onCancel;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final box = draft.current!;

    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.sm + 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.inbox_rounded, size: 16, color: c.primary),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    box.boxNo ?? LocaleKeys.return_fa_box_auto.tr(),
                    style: AppTextStyles.code,
                  ),
                ),
                Text(
                  LocaleKeys.return_fa_serial_count
                      .tr(namedArgs: {'count': '${box.serials.length}'}),
                  style: AppTextStyles.caption.copyWith(color: c.text3),
                ),
              ],
            ),
            const Divider(height: 14),
            for (final s in box.serials)
              _FaSerialRow(
                serial: s,
                mismatch: draft.mismatchOf(s),
                onRemove: () => onRemoveSerial(s),
              ),
            const SizedBox(height: AppDimens.sm),
            Row(
              children: [
                Expanded(
                  child: AppButton(
                    label: LocaleKeys.return_fa_btn_cancel_box.tr(),
                    variant: AppButtonVariant.subtle,
                    size: AppButtonSize.sm,
                    isFullWidth: false,
                    onPressed: onCancel,
                  ),
                ),
                const SizedBox(width: AppDimens.sm),
                Expanded(
                  child: AppButton(
                    label: LocaleKeys.return_fa_btn_finish_box.tr(),
                    variant: AppButtonVariant.primary,
                    size: AppButtonSize.sm,
                    isFullWidth: false,
                    onPressed: onFinish,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _FaSerialRow extends StatelessWidget {
  const _FaSerialRow({
    required this.serial,
    required this.mismatch,
    required this.onRemove,
  });

  final String serial;
  final FaMismatch? mismatch;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final bad = mismatch != null;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(
            bad ? Icons.error_outline_rounded : Icons.check_circle_outline,
            size: 15,
            color: bad ? c.danger : c.success,
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  serial,
                  style: AppTextStyles.code.copyWith(
                    color: bad ? c.danger : c.text1,
                  ),
                ),
                if (bad)
                  Text(
                    _reasonText(mismatch!),
                    style: AppTextStyles.caption.copyWith(color: c.danger),
                  ),
              ],
            ),
          ),
          IconButton(
            icon: const Icon(Icons.close_rounded, size: 16),
            visualDensity: VisualDensity.compact,
            onPressed: onRemove,
          ),
        ],
      ),
    );
  }
}

/// Khối cảnh báo gom tất cả serial cần ĐẶT RIÊNG, để FA không phải cuộn tìm.
class _FaMismatchCard extends StatelessWidget {
  const _FaMismatchCard({required this.items});

  final List<FaMismatch> items;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return Container(
      padding: const EdgeInsets.all(AppDimens.sm + 4),
      decoration: BoxDecoration(
        color: c.dangerBg,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: c.danger),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.report_problem_outlined, size: 16, color: c.danger),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  LocaleKeys.return_fa_mismatch_title
                      .tr(namedArgs: {'count': '${items.length}'}),
                  style: AppTextStyles.label.copyWith(
                    color: c.danger,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            LocaleKeys.return_fa_mismatch_hint.tr(),
            style: AppTextStyles.caption.copyWith(color: c.text2),
          ),
          const SizedBox(height: 6),
          for (final m in items)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 1),
              child: Row(
                children: [
                  Expanded(
                    child: Text(m.serial, style: AppTextStyles.code),
                  ),
                  Text(
                    _reasonText(m),
                    style: AppTextStyles.caption.copyWith(color: c.danger),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Các thùng đã xong.
class _FaDoneBoxList extends StatelessWidget {
  const _FaDoneBoxList({required this.draft, required this.onRemove});

  final FaScanState draft;
  final ValueChanged<int> onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.sm + 4),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              LocaleKeys.return_fa_done_boxes
                  .tr(namedArgs: {'count': '${draft.boxes.length}'}),
              style: AppTextStyles.caption.copyWith(color: c.text3),
            ),
            const SizedBox(height: 4),
            for (var i = 0; i < draft.boxes.length; i++)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  children: [
                    Icon(Icons.inbox_outlined, size: 15, color: c.text3),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        draft.boxes[i].boxNo ??
                            LocaleKeys.return_fa_box_auto.tr(),
                        style: AppTextStyles.code,
                      ),
                    ),
                    Text(
                      LocaleKeys.return_fa_serial_count.tr(namedArgs: {
                        'count': '${draft.boxes[i].serials.length}',
                      }),
                      style: AppTextStyles.caption.copyWith(color: c.text3),
                    ),
                    IconButton(
                      icon: const Icon(Icons.close_rounded, size: 16),
                      visualDensity: VisualDensity.compact,
                      onPressed: () => onRemove(i),
                    ),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// Câu cảnh báo theo loại. Ba loại ba câu — FA xử lý khác nhau.
String _reasonText(FaMismatch m) => switch (m.kind) {
      FaMismatchKind.notInDoc => LocaleKeys.return_fa_mismatch_not_in_doc.tr(),
      FaMismatchKind.wrongStatus =>
        LocaleKeys.return_fa_mismatch_wrong_status.tr(namedArgs: {
          'status': m.foundStatus ?? '?',
        }),
      FaMismatchKind.otherDoc => LocaleKeys.return_fa_mismatch_other_doc.tr(),
    };
