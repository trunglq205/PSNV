using System.Globalization;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Shared.App.CsvIo;

namespace Swms.FinishGoods.Web.Features.Inventory.App.Csv;

/// <summary>1 dòng CSV tồn kho: lot + (box) + (line/serial). Box/Line null khi không có.</summary>
public sealed record InventoryCsvRow(AppInventoryItem Lot, AppInventoryBox? Box, AppInventoryBoxLine? Line);

/// <summary>
/// Schema CSV chỉ dùng cho EXPORT tồn kho (không import) — chi tiết đến cấp box / serial.
/// Mỗi dòng = 1 line trong thùng; thùng không có line hoặc lot không có thùng vẫn ra 1 dòng.
/// Cột cấp lot lặp lại trên mọi dòng của lot đó.
/// </summary>
public static class InventoryCsvSchema
{
    public static CsvSchema<InventoryCsvRow> BuildSchema(IStringLocalizer L) => new()
    {
        FileBaseName = "swms_inventory",
        Columns = new List<CsvColumn<InventoryCsvRow>>
        {
            // ── Lot (giữ nguyên các cột cũ) ──
            new() { Key = "lot_no",         Description = L["InventoryCsv.Col.LotNo"],        Get = r => r.Lot.LotNo,                                  IncludeInImport = false },
            new() { Key = "stocky_code",    Description = L["InventoryCsv.Col.StockyCode"],   Get = r => r.Lot.StockyCode ?? "",                       IncludeInImport = false },
            new() { Key = "category",       Description = L["InventoryCsv.Col.Category"],     Get = r => $"{r.Lot.CategoryCode} {r.Lot.CategoryName}", IncludeInImport = false },
            new() { Key = "lot_type",       Description = L["InventoryCsv.Col.LotType"],      Get = r => r.Lot.LotType,                                IncludeInImport = false },
            new() { Key = "level",          Description = L["InventoryCsv.Col.Level"],        Get = r => r.Lot.DetailLevel,                            IncludeInImport = false },
            new() { Key = "box_count",      Description = L["InventoryCsv.Col.BoxCount"],     Get = r => r.Lot.BoxCount.ToString(CultureInfo.InvariantCulture), IncludeInImport = false },
            new() { Key = "total_qty",      Description = L["InventoryCsv.Col.TotalQty"],     Get = r => r.Lot.TotalQty.ToString(CultureInfo.InvariantCulture), IncludeInImport = false },
            new() { Key = "inspection",     Description = L["InventoryCsv.Col.Inspection"],   Get = r => r.Lot.InspectionStatus,                       IncludeInImport = false },
            new() { Key = "sap_status",     Description = L["InventoryCsv.Col.Sap"],          Get = r => r.Lot.SapStatus?.ToString() ?? "",            IncludeInImport = false },
            new() { Key = "area",           Description = L["InventoryCsv.Col.Area"],         Get = r => r.Lot.AreaKey,                                IncludeInImport = false },
            new() { Key = "locator",        Description = L["InventoryCsv.Col.Locator"],      Get = r => r.Lot.LocatorName ?? r.Lot.LocatorCode ?? "", IncludeInImport = false },
            new() { Key = "prod_date",      Description = L["InventoryCsv.Col.ProdDate"],     Get = r => Txt(r.Lot.ProductionDate),                    IncludeInImport = false },
            new() { Key = "urgent",         Description = L["InventoryCsv.Col.Urgent"],       Get = r => r.Lot.IsUrgent ? "1" : "0",                   IncludeInImport = false },
            new() { Key = "created_at",     Description = L["InventoryCsv.Col.CreatedAt"],    Get = r => r.Lot.CreatedAt,                              IncludeInImport = false },
            new() { Key = "created_by",     Description = L["InventoryCsv.Col.CreatedBy"],    Get = r => r.Lot.CreatedBy,                              IncludeInImport = false },

            // ── Box ──
            new() { Key = "box_no",         Description = L["InventoryCsv.Col.BoxNo"],        Get = r => r.Box?.BoxNo ?? "",                           IncludeInImport = false },
            new() { Key = "spec_code",      Description = L["InventoryCsv.Col.SpecCode"],     Get = r => r.Box?.SpecCode ?? "",                        IncludeInImport = false },
            new() { Key = "box_dim",        Description = L["InventoryCsv.Col.BoxDim"],       Get = r => Txt(r.Box?.Dimension),                        IncludeInImport = false },
            new() { Key = "gross_weight",   Description = L["InventoryCsv.Col.GrossWeight"],  Get = r => Num(r.Box?.GrossWeight),                     IncludeInImport = false },
            new() { Key = "psnv_po",        Description = L["InventoryCsv.Col.PsnvPo"],       Get = r => r.Box?.PsnvPo ?? "",                          IncludeInImport = false },
            new() { Key = "customer_po",    Description = L["InventoryCsv.Col.CustomerPo"],   Get = r => r.Box?.CustomerPo ?? "",                      IncludeInImport = false },
            new() { Key = "line",           Description = L["InventoryCsv.Col.Line"],         Get = r => r.Box?.Line ?? "",                            IncludeInImport = false },
            new() { Key = "box_oqc",        Description = L["InventoryCsv.Col.BoxOqc"],       Get = r => InventoryDisplay.BoxOqcToInspection(r.Box?.OqcStatus) ?? "", IncludeInImport = false },
            new() { Key = "box_prod_date",  Description = L["InventoryCsv.Col.BoxProdDate"],  Get = r => Txt(r.Box?.ProductionDate),                   IncludeInImport = false },

            // ── Line / serial ──
            new() { Key = "model",          Description = L["InventoryCsv.Col.Model"],        Get = ModelOf,                                           IncludeInImport = false },
            new() { Key = "qty",            Description = L["InventoryCsv.Col.Qty"],          Get = r => Num(r.Line?.Qty),                             IncludeInImport = false },
            new() { Key = "serial_no",      Description = L["InventoryCsv.Col.SerialNo"],     Get = r => r.Line?.SerialNo ?? "",                       IncludeInImport = false },
            new() { Key = "origin",         Description = L["InventoryCsv.Col.Origin"],       Get = r => r.Line?.OriginCountry ?? "",                  IncludeInImport = false },
            new() { Key = "carton_qty",     Description = L["InventoryCsv.Col.CartonQty"],    Get = r => Num(r.Line?.CartonQty),                       IncludeInImport = false },
        },
    };

    /// <summary>Lot → box → line thành dòng phẳng; thiếu cấp nào vẫn giữ 1 dòng.</summary>
    public static IEnumerable<InventoryCsvRow> Flatten(
        IEnumerable<(AppInventoryItem Lot, IReadOnlyList<AppInventoryBox> Boxes)> data)
    {
        foreach (var (lot, boxes) in data)
        {
            if (boxes.Count == 0) { yield return new(lot, null, null); continue; }

            foreach (var b in boxes)
            {
                if (b.Lines.Count == 0) { yield return new(lot, b, null); continue; }
                foreach (var l in b.Lines) yield return new(lot, b, l);
            }
        }
    }

    // Có line -> model của line; không có (lot box_count) -> model lot như CSV cũ.
    private static string ModelOf(InventoryCsvRow r)
        => r.Line?.Model ?? r.Lot.Model ?? string.Join(", ", r.Lot.Models);

    // View model dùng "—" cho trống -> để ô rỗng trong CSV.
    private static string Txt(string? s) => s is null || s == "—" ? "" : s;

    // Invariant để số thập phân luôn dùng dấu chấm, không lẫn với dấu phẩy phân cách CSV.
    private static string Num(decimal? v) => v?.ToString("0.###", CultureInfo.InvariantCulture) ?? "";
    private static string Num(int? v) => v?.ToString(CultureInfo.InvariantCulture) ?? "";
}
