class Robotlocationtarget{
  Robotlocationtarget({required this.Qrcode});
  final String Qrcode;
}