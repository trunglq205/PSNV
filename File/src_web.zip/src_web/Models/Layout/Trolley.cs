﻿using System.ComponentModel;
using System.Runtime.Serialization;
using System.Security.AccessControl;
using System.Text;
using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Models.Layout
{
    public enum TrolleyCategory
    {
        [EnumMember(Value = "MW")]
        [Description("Status_MW")]
        MW,
        [EnumMember(Value = "TV-PAP")]
        [Description("Status_TV")]
        TV,
        [EnumMember(Value = "PJ")]
        [Description("Status_PJ")]
        PJ,
        [EnumMember(Value = "SB-DP-DECT")]
        [Description("Status_SBDPDECT")]
        SBDPDECT,
        [EnumMember(Value = "DIP")]
        [Description("Status_DIP")]
        DIP,
        [EnumMember(Value = "PAP")]
        [Description("Status_PAP")]
        PAP,
    }

    public class Trolley : Widget
    {
        public Trolley() { }

        public Trolley(KonvaObject konvaObject) : base(konvaObject)
        {
            var arr = konvaObject.Attrs.CustomData?.Split(";");

            if (arr?.Length != 4)
            {
                return;
            }

            TrolleyID = arr[0];
            TrolleyName = arr[1];
            TrolleyCode = arr[2];
            TrolleyCategory = arr[3].ToEnum<TrolleyCategory>();
            TrolleyBarcode = $"{TrolleyCategory};{TrolleyCode}";
        }

        public string TrolleyID;
        public string TrolleyName;
        public string TrolleyCode;
        public string TrolleyBarcode;
        public TrolleyCategory? TrolleyCategory;


        public override WidgetType Type => WidgetType.Trolley;
        protected override KonvaClassType ClassName => KonvaClassType.Group;

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();

            attrs.CustomData = $"{TrolleyID};{TrolleyName};{TrolleyCode};{TrolleyCategory.GetString()}";
            attrs.Fill = "#FFFFFF";
            attrs.Stroke = "#000000";
            attrs.StrokeWidth = 3;
            attrs.Width = Width * (ScaleX ?? 1);
            attrs.Height = Height * (ScaleY ?? 1);
            attrs.ScaleX = 1;
            attrs.ScaleY = 1;
            return attrs;
        }

        public override KonvaObject ToKonvaObject()
        {
            var attr = ToKonvaAttr();
            var fontSize = attr.Width > 200 ? 70 : attr.Width > 100 ? 30 : attr.Width > 60 ? 20 : 12;
            var children = new List<KonvaObject>()
            {
                new KonvaObject()
                {
                    ClassName = KonvaClassType.Rect.GetString(),
                    Attrs = new KonvaAttr() {
                        Width = attr.Width,
                        Height = attr.Height,
                        Fill = Fill,
                        Stroke = Border ?? "#000000",
                        StrokeWidth = BorderWidth ?? 2,
                        Name = WidgetType.Wall.GetString(),
                        StrokeScaleEnabled = true,
                        Locked = true,
                    }
                },
                new KonvaObject()
                {
                    ClassName = KonvaClassType.Text.GetString(),
                    Attrs = new KonvaAttr()
                    {
                        Text = TrolleyCode,
                        Y = attr.Height / 2 - 7,
                        Width = attr.Width,
                        Height = fontSize,
                        FontSize = fontSize,
                        FontStyle = "bold",
                        Fill = "#000000",
                        Align = "center",
                        Locked = true,
                        Name = WidgetType.Wall.GetString(),
                    }
                },
                      new KonvaObject()
                {
                    ClassName = KonvaClassType.Text.GetString(),
                    Attrs = new KonvaAttr()
                    {
                        Text = TrolleyCode,
                        Y = attr.Height / 2 + 7,
                        Width = attr.Width,
                        Height = fontSize,
                        FontSize = fontSize,
                        FontStyle = "bold",
                        Fill = "#000000",
                        Align = "center",
                        Locked = true,
                        Name = WidgetType.Wall.GetString(),
                        Visible = false,
                    }
                },
            };

            return new KonvaObject()
            {
                ClassName = ClassName.GetString(),
                Attrs = ToKonvaAttr(),
                Children = children
            };
        }

    }
}
