using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Inventory.Api;
using Swms.FinishGoods.API.Features.Inventory.Business.Entities;

namespace Swms.FinishGoods.API.Features.Inventory.DataAccess
{
    public interface IInventoryRepository
    {
        /// <summary>Danh sách lot đang tồn (không nạp box/line).</summary>
        Task<PagedResult<InventoryItem>> GetPagedAsync(InventoryQuery query, string orderBy);

        /// <summary>Thống kê 5 khu vực theo filter (bỏ qua query.Area).</summary>
        Task<IReadOnlyList<InventoryAreaStat>> GetAreaStatsAsync(InventoryQuery query);

        /// <summary>Phân bố tuổi tồn theo bucket, theo filter (kể cả Area).</summary>
        Task<IReadOnlyList<InventoryAgingBucket>> GetAgingAsync(InventoryQuery query);
    }
}
