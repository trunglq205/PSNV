using System.Data;
using Microsoft.Data.SqlClient;

namespace Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

/// <summary>
/// Tạo IDbConnection trỏ tới database của hệ thống Foss (khác instance với DB chính SWMS).
/// Tách riêng khỏi IDbConnectionFactory mặc định để không nhầm connection string.
/// </summary>
public interface IFossDbConnectionFactory
{
    IDbConnection Create();
}

public class FossDbConnectionFactory : IFossDbConnectionFactory
{
    private readonly string _connStr;

    public FossDbConnectionFactory(IConfiguration cfg)
        => _connStr = cfg.GetConnectionString("FossDb")
                      ?? throw new InvalidOperationException(
                          "Missing connection string 'FossDb' in configuration.");

    public IDbConnection Create() => new SqlConnection(_connStr);
}
