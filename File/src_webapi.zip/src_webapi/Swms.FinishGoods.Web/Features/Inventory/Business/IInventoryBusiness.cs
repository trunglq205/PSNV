using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.Business;

/// <summary>
/// Nghiệp vụ màn Tồn kho — phần SWMS thuần.
/// So / xử lý chênh lệch HD soft: IHdSoftCompareBusiness. Job đồng bộ: ISyncBusiness.
/// </summary>
public interface IInventoryBusiness
{
    Task<Result<PagedResult<InventoryItemDto>>> GetPagedAsync(InventoryQuery query);
    Task<Result<List<InventoryAreaDto>>> GetAreasAsync(InventoryQuery query);
    Task<Result<List<InventoryAgingBucketDto>>> GetAgingAsync(InventoryQuery query);

    /// <summary>Chi tiết lot kèm box/line. Trước đây gọi qua IPalletBusiness.</summary>
    Task<Result<InventoryItemDto>> GetByIdAsync(long id);

    /// <summary>
    /// Timeline của lot, đã map sang view model (nhãn/màu tra từ catalog).
    /// Tự bảo đảm catalog được tải trước khi map.
    /// </summary>
    Task<Result<List<AppStockEvent>>> GetHistoryAsync(long id);

    /// <summary>Option category. Trước đây gọi qua IPalletBusiness.</summary>
    Task<Result<List<CategoryOptionDto>>> GetCategoryOptionsAsync();
}
