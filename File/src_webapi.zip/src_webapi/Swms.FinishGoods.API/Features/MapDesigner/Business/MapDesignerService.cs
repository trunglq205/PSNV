using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.MapDesigner.DataAccess;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.MapDesigner.Business;

/// <summary>Nghiệp vụ thiết kế bản đồ — dùng chung mọi map_type.</summary>
public class MapDesignerService : IMapDesignerService
{
    private static readonly HashSet<string> AllowedKinds =
        new(StringComparer.OrdinalIgnoreCase) { "rack", "pallet", "zone" };

    private readonly IMapDesignerRepository _repo;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public MapDesignerService(
        IMapDesignerRepository repo,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _localizer = localizer;
    }

    public async Task<MapLayout> GetLayoutAsync(string areaCode)
    {
        var code = (areaCode ?? "").Trim().ToUpperInvariant();
        return await _repo.GetLayoutAsync(code)
            ?? throw new NotFoundException(_localizer["MapDesign.Err.AreaNotFound", code]);
    }

    public async Task SaveLayoutAsync(string areaCode, IReadOnlyList<MapBlock> blocks, string? user)
    {
        var code = (areaCode ?? "").Trim().ToUpperInvariant();
        blocks ??= Array.Empty<MapBlock>();

        var layout = await _repo.GetLayoutAsync(code)
            ?? throw new NotFoundException(_localizer["MapDesign.Err.AreaNotFound", code]);

        // Mã pallet phải duy nhất trong chính lượt lưu này.
        var palletCodes = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var b in blocks)
        {
            var kind = (b.Kind ?? "").Trim().ToLowerInvariant();
            if (!AllowedKinds.Contains(kind))
                throw new BusinessRuleException(_localizer["MapDesign.Err.InvalidBlockKind", b.Kind ?? ""]);

            if (b.GridW <= 0 || b.GridH <= 0)
                throw new BusinessRuleException(_localizer["MapDesign.Err.BlockSizePositive"]);

            if (b.GridX < 0 || b.GridY < 0 ||
                b.GridX + b.GridW > layout.Cols || b.GridY + b.GridH > layout.Rows)
                throw new BusinessRuleException(_localizer["MapDesign.Err.BlockOutOfGrid"]);

            if (kind == "rack" && b.RackId is null)
                throw new BusinessRuleException(_localizer["MapDesign.Err.RackIdRequired"]);

            if (kind == "pallet")
            {
                var pcode = (b.LocatorCode ?? "").Trim().ToUpperInvariant();
                if (pcode.Length == 0)
                    throw new BusinessRuleException(_localizer["MapDesign.Err.PalletCodeRequired"]);
                if (!palletCodes.Add(pcode))
                    throw new ConflictException(_localizer["MapDesign.Err.PalletCodeDuplicated", pcode]);

                // Mã pallet duy nhất TOÀN HỆ (PDA chỉ quét mã, hệ tự suy ra map).
                if (await _repo.LocatorCodeExistsAsync(pcode, b.LocatorId))
                    throw new ConflictException(_localizer["MapDesign.Err.PalletCodeExists", pcode]);
            }
        }

        await _repo.SaveLayoutAsync(code, blocks, user);
    }

    public async Task<long> CreateRackAsync(string areaCode, CreateRackInput input, string? user)
    {
        var code = (areaCode ?? "").Trim().ToUpperInvariant();
        var rackCode = (input.RackCode ?? "").Trim().ToUpperInvariant();

        if (rackCode.Length == 0)
            throw new BusinessRuleException(_localizer["Storage.Err.RackCodeRequired"]);
        if (input.Positions <= 0)
            throw new BusinessRuleException(_localizer["Storage.Err.PositionsPositive"]);
        if (input.Floors is < 1 or > 10)
            throw new BusinessRuleException(_localizer["MapDesign.Err.FloorsRange"]);

        var shelf = (input.ShelfPositions ?? Array.Empty<int>())
            .Where(p => p >= 1 && p <= input.Positions).Distinct().ToArray();

        return await _repo.CreateRackAsync(code, new CreateRackInput
        {
            RackCode = rackCode,
            RackName = input.RackName,
            Positions = input.Positions,
            Floors = input.Floors,
            ShelfPositions = shelf,
            GridX = input.GridX,
            GridY = input.GridY,
            GridW = input.GridW,
            GridH = input.GridH
        }, user);
    }

    public async Task DeleteRackAsync(string areaCode, string rackCode, string? user)
    {
        var code = (areaCode ?? "").Trim().ToUpperInvariant();
        var rack = (rackCode ?? "").Trim().ToUpperInvariant();
        if (rack.Length == 0)
            throw new BusinessRuleException(_localizer["Storage.Err.RackCodeRequired"]);

        if (await _repo.RackHasStockAsync(code, rack))
            throw new BusinessRuleException(_localizer["Storage.Err.RackHasStock"]);

        await _repo.DeleteRackAsync(code, rack, user);
    }
}
