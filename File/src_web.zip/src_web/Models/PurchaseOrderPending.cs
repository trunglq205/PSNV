﻿using Newtonsoft.Json;

namespace SWMS_WebTool.Models
{
    public class PurchaseOrderPending
    {
        public string PONo { get; set; }
        public string Item { get; set; }
        public int PlanQuantity { get; set; }
        public int GRQuantity { get; set; }
        public double ReceivedProcess
        {
            get { return (double)GRQuantity / PlanQuantity * 100; }
        }
    }
}
