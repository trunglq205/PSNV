﻿using System;
using System.Collections;
using System.Linq;
using System.Web;


using System.Xml.Linq;
using System.Data;

public class WebService
{

    public WebService()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }


    public string HelloWorld()
    {
        return "Hello World";
    }
    ConnectSQL objConnect = new ConnectSQL();

    public string veryModelandSerial(string STR_PROCESS, string STR_SERIAL, string SHRINKID)
    {
        string[] para = new string[] { "@STR_PROCESS", "@STR_SERIAL", "SHRINKID" };
        object[] objV = { STR_PROCESS, STR_SERIAL, SHRINKID };
        return objConnect.GetExcuteScalar("veryModelandSerial", para, objV).ToString();


    }

    public int updatetotal_TBLSHRINKPRE(string ShrinkID)
    {
        string[] para = { "@ShrinkID" };
        object[] objV = { ShrinkID };
        return objConnect.ExcuteStored("updatetotal_TBLSHRINKPRE", para, objV);

    }


    public string count_model(string STR_PROCESS)
    {
        try
        {
            string[] para = { "@STR_PROCESS" };
            object[] objV = { STR_PROCESS };
            return objConnect.GetExcuteScalar("count_model", para, objV).ToString();
        }
        catch
        {
            return "";
        }
    }

    public int TBLSHRINKPRE_UpdateTotal(int ShrinkID, int Total)
    {
        try
        {
            string[] para = { "@ShrinkID", "@Total" };
            object[] objV = { ShrinkID, Total };
            return objConnect.ExcuteStored("TBLSHRINKPRE_UpdateTotal", para, objV);
        }
        catch
        {
            return 0;
        }
    }



    public string TBLUSER_Login(string sUsername)
    {

        string[] para = { "@sUsername" };
        object[] objV = { sUsername };
        return objConnect.GetExcuteScalar("TBLUSER_Login", para, objV).ToString();
    }


    public string TBLSHRINKPRE_Insert(string sUsername, string sModelNo, string sLineNo, string sPalletNo)
    {
        try
        {
            string[] para = { "@sUsername", "@sModelNo", "@sLineNo", "@sPalletNo" };
            object[] objV = { sUsername, sModelNo, sLineNo, sPalletNo };
            return objConnect.GetExcuteScalar("TBLSHRINKPRE_Insert2", para, objV).ToString();
        }
        catch (Exception)
        {
            return "";


        }

    }
    /// <summary>
    /// </summary>
    /// <returns>0: mean OK, 1 mean overflow </returns>
    public string verifyOverFlow(string sModelNo, string sPalletNo,string Category)
    {
        return objConnect.GetExcuteScalar("verifyOverFlow_PalletID", new string[] { "@sModelNo", "@sPalletNo","@Category" }, new object[] { sModelNo, sPalletNo,Category });
    }

    public string viewquantity(string sModelNo, string sSerialNo)
    {
        try
        {
            string[] para = { "@sModelNo", "@sSerialNo" };
            object[] objV = { sModelNo, sSerialNo };
            return objConnect.GetExcuteScalar("viewquantity", para, objV).ToString();
        }
        catch (Exception)
        {
            return "";
        }

    }

    public DataTable Get_category()
    {

        return objConnect.TableWithoutParameter("Get_Category").Tables[0];
        

    }

    public string confirmExitsModel(string STR_PROCESS_FACTORY, string Category)
    {
        try
        {
            string[] para = { "@STR_PROCESS_FACTORY", "@Category" };
            object[] objV = { STR_PROCESS_FACTORY, Category };
            return objConnect.GetExcuteScalar("confirmExitsModel_PalletID", para, objV).ToString();
        }
        catch (Exception)
        {
            return "";
        }
    }
    public string LoadModeByPostCode(string STR_PostCode) // PostCode by Model
    {
        try
        {
            string[] para = { "@PostCode" };
            object[] objV = { STR_PostCode };
            return objConnect.GetExcuteScalar("CheckOutCarton_PalletID_DP", para, objV).ToString();
        }
        catch (Exception)
        {
            return "";
        }
    }
    //public string confirmExitsModel(string STR_PROCESS_FACTORY, string Category)
    //{
    //    try
    //    {
    //        string[] para = { "@STR_PROCESS_FACTORY", "@Category" };
    //        object[] objV = { STR_PROCESS_FACTORY, Category };
    //        return objConnect.GetExcuteScalar("confirmExitsModel_PalletID", para, objV).ToString();
    //    }
    //    catch (Exception)
    //    {
    //        return "";
    //    }
    //}

    ///Hàm này mục đích là để đưa 1 sản phầm vào Pallet lúc đóng Shrink
    ///
    //    alter proc InsertToPallet
    //@sModelNo nvarchar(50),
    //@sPalletNo nvarchar(50),
    //@sSerialNo nvarchar(30),
    //@sUsername nvarchar(50)
    public string InsertToPallet(string sModelNo, string sPalletNo, string sSerialNo,
        string sUsername)
    {
        // Nhu the nay da da Dua duoc vao Pallet
        string[] para = { "@sModelNo", "@sPalletNo", "@sSerialNo", "@sUsername" };
        object[] objV = { sModelNo, sPalletNo, sSerialNo, sUsername };
        return objConnect.GetExcuteScalar("InsertToPallet", para, objV);


    }
    //InsertToPallet_PalletID
    public string InsertToPallet_PalletID(string sModelNo, string sPalletNo, string sSerialNo,
       string sUsername, string Category)
    {
        // Nhu the nay da da Dua duoc vao Pallet
        string[] para = { "@sModelNo", "@sPalletNo", "@sSerialNo", "@sUsername", "@Category" };
        object[] objV = { sModelNo, sPalletNo, sSerialNo, sUsername, Category };
        return objConnect.GetExcuteScalar("InsertToPallet_PalletID", para, objV);


    }
    public string InsertToPallet_PalletID_TV(string sModelNo, string sPalletNo, string sSerialNo,
       string sUsername, string Category)
    {
        // Nhu the nay da da Dua duoc vao Pallet
        string[] para = { "@sModelNo", "@sPalletNo", "@sSerialNo", "@sUsername", "@Category" };
        object[] objV = { sModelNo, sPalletNo, sSerialNo, sUsername, Category };
        return objConnect.GetExcuteScalar("InsertToPallet_PalletID_TV", para, objV);


    }

    //   @sModelNo nvarchar(500),
    //@sSerialNo nvarchar(30),
    //@Source_pallet nvarchar(50),
    //@dShrinkBy nvarchar(50)
    public int tblPalletCombine_Insert2(string sModelNo, string sSerialNo,
      string Source_pallet, string dShrinkBy)
    {

        string[] para = { "@sModelNo", "@sSerialNo", "@Source_pallet", "@dShrinkBy" };
        object[] objV = { sModelNo, sSerialNo, Source_pallet, dShrinkBy };
        return objConnect.ExcuteStored("tblPalletCombine_Insert2", para, objV);
    }
    public DataTable FactCode_GetAll()
    {
        return objConnect.TableWithoutParameter("FactCode_GetAll").Tables[0];
    }

    public DataTable Get_Category()
    {
        return objConnect.TableWithoutParameter("Get_Category").Tables[0];
    }

    //public DataTable spCheckQtyByPalletID_PalletID(string PALLET_ID, string Category, string employee_id, string createdate)
    //{
    //    return objConnect.TableWithParameter("spCheckQtyByPalletID_PalletID_FA", new string[] { "@PALLET_ID", "@Category", "@employee_id", "@createdate" }, new object[] { PALLET_ID, Category, employee_id, createdate });
    //}
    public DataSet spCheckQtyByPalletID_PalletID(string PALLET_ID, string Category, string employee_id, string createdate)
    {
        return objConnect.DataSetWithParameter("spCheckQtyByPalletID_PalletID_FA", new string[] { "@PALLET_ID", "@Category", "@employee_id", "@createdate" }, new object[] { PALLET_ID, Category, employee_id, createdate });
    }
}

