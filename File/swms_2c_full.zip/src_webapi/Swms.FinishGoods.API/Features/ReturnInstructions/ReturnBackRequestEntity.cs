namespace Swms.FinishGoods.API.Features.ReturnInstructions;

/// <summary>
/// Yêu cầu back hàng sang FA (mục 2c). Bốn bước tuần tự, mỗi bước MỘT QUYỀN:
///   B1 FA tạo yêu cầu                      → request_back
///   B2 quản lý FA duyệt                    → approve_fa
///   B3 SCS WH xác nhận + tạo chỉ thị back  → process
///   B4 quản lý SCS duyệt cho back          → approve_scs
///
/// Serial CHỈ được gắp và chuyển <c>at_fa</c> ở B4. Trước đó yêu cầu chỉ là
/// model + SL: không ai tick 100 serial trên web, và gắp sớm thì hàng bị giữ
/// trong khi yêu cầu còn có thể bị huỷ.
/// </summary>
public sealed class ReturnBackRequest
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public string ReqNo { get; set; } = default!;
    public string ReqStatus { get; set; } = ReturnBackStatus.FaRequested;
    public string CurrentStep { get; set; } = ReturnBackStep.FaApprove;
    public string? Note { get; set; }

    public string? RequestedBy { get; set; }
    public DateTime RequestedAt { get; set; }

    public string? FaApprovedBy { get; set; }
    public DateTime? FaApprovedAt { get; set; }
    public string? FaComment { get; set; }

    public string? ScsInstructedBy { get; set; }
    public DateTime? ScsInstructedAt { get; set; }

    public string? ScsApprovedBy { get; set; }
    public DateTime? ScsApprovedAt { get; set; }
    public string? ScsComment { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    /// <summary>Số phiếu của chỉ thị nhận hàng — tiện cho màn hình và mail.</summary>
    public string? DocNo { get; set; }

    /// <summary>Loại hàng của chỉ thị (<c>rework</c> | <c>refurbish</c>).</summary>
    public string? GoodsType { get; set; }

    public List<ReturnBackRequestLine> Lines { get; set; } = [];

    /// <summary>Tổng SL FA xin.</summary>
    public int TotalQty => Lines.Sum(l => l.Qty);

    public int ModelCount => Lines.Count;

    /// <summary>
    /// Số serial ĐÃ gắp cho yêu cầu này. Đếm từ sổ serial, KHÔNG lưu cột —
    /// cùng nguyên tắc với SL thực nhận ở mục 2b. Bằng 0 trước khi B4 chạy.
    /// </summary>
    public int AssignedQty { get; set; }

    /// <summary>Số serial của yêu cầu này FA đã giao lại (mục 3).</summary>
    public int ReturnedQty { get; set; }

    /// <summary>
    /// Số con ĐANG ở FA chưa về. Đếm thẳng <c>status = at_fa</c> chứ KHÔNG lấy
    /// <see cref="AssignedQty"/> − <see cref="ReturnedQty"/>: con đã đánh
    /// <c>ng</c> không còn chờ về, trừ kiểu kia sẽ cộng nó vào đây và SCS đi
    /// đòi một lô hàng không bao giờ tới.
    /// </summary>
    public int AtFaQty { get; set; }

    public bool IsCancelled => ReqStatus == ReturnBackStatus.Cancelled;

    /// <summary>Đã cho back — hàng đang (hoặc đã từng) ở FA.</summary>
    public bool IsApproved => ReqStatus == ReturnBackStatus.ScsApproved;

    /// <summary>Còn sửa / huỷ được: chưa duyệt xong và chưa huỷ.</summary>
    public bool IsOpen => !IsApproved && !IsCancelled;
}

public sealed class ReturnBackRequestLine
{
    public long Id { get; set; }
    public long RequestId { get; set; }
    public int LineNo { get; set; }
    public string Model { get; set; } = default!;

    /// <summary>SL FA XIN. Số thực gắp được nằm ở <see cref="AssignedQty"/>.</summary>
    public int Qty { get; set; }

    public string? Note { get; set; }

    /// <summary>Số serial đã gắp cho model này — đếm từ sổ serial.</summary>
    public int AssignedQty { get; set; }

    /// <summary>Số serial của model này FA đã giao lại.</summary>
    public int ReturnedQty { get; set; }

    /// <summary>
    /// SL kho CÒN gắp được cho model này (serial <c>received</c>, chưa thuộc
    /// lượt back nào). Chỉ điền ở màn soạn yêu cầu để FA không xin quá hàng có.
    /// </summary>
    public int AvailableQty { get; set; }

    /// <summary>Thiếu hàng để gắp đủ SL đã xin.</summary>
    public bool Short => AssignedQty < Qty;
}

/// <summary>
/// Trạng thái yêu cầu back. Khớp CHECK <c>ck_rbr_status</c>.
/// </summary>
public static class ReturnBackStatus
{
    public const string FaRequested = "fa_requested";
    public const string FaApproved = "fa_approved";
    public const string ScsInstructed = "scs_instructed";
    public const string ScsApproved = "scs_approved";
    public const string Cancelled = "cancelled";

    public const string ReqPrefix = "BK";
}

/// <summary>
/// ĐANG CHỜ AI. Khớp CHECK <c>ck_rbr_step</c>.
///
/// Tách khỏi <see cref="ReturnBackStatus"/> vì màn hình lọc hàng đợi theo bước
/// ("đang chờ tôi"), còn trạng thái là để đọc lịch sử. Cùng cách
/// <c>ng_reports</c> tách <c>doc_status</c> và <c>current_step</c>.
/// </summary>
public static class ReturnBackStep
{
    public const string FaApprove = "fa_approve";
    public const string ScsInstruct = "scs_instruct";
    public const string ScsApprove = "scs_approve";
    public const string Done = "done";
}
