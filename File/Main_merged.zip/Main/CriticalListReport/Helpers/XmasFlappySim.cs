namespace CriticalListReport.Helpers
{
    /// <summary>
    /// Bộ mô phỏng game Flappy Santa phía server — GIỐNG HỆT wwwroot/js/xmas-flappy-sim.js.
    /// Server không tin điểm do trình duyệt gửi lên: nó lấy seed (do server cấp) + danh sách tick
    /// người chơi bấm bay rồi tự chơi lại toàn bộ lượt chơi để tính điểm.
    /// Chỉ dùng số nguyên → kết quả trùng khớp tuyệt đối với bản JS.
    /// Độ khó: EASY cột đầu dễ (khe rộng, bay chậm, cột đầu ngang tầm xuất phát), sau đó khó lên nhanh theo từng cột / từng điểm.
    /// Sửa hằng số ở đây thì PHẢI sửa y hệt bên file JS (và ngược lại).
    /// </summary>
    public static class XmasFlappySim
    {
        public const int TPS = 60;
        public const int GROUND = 56000;
        public const int BIRD_X = 22000;
        public const int HB_W = 2350;
        public const int HB_H = 1660;
        public const int START_Y = 28000;
        public const int G = 35;
        public const int FLAP = -624;
        public const int MAX_FALL = 693;
        public const int PW = 7200;
        public const int SPACING = 23000;
        public const int FIRST_X = 80000;
        public const int SPAWN_X = 200000;
        public const int TOP_MIN = 11200;
        public const int GAP_BOTTOM_MAX = 44800;
        public const int EASY = 5;
        public const int GAP0 = 23000;
        public const int GAP_MIN = 18000;
        public const int GAP_DEC = 300;
        public const int SPEED0 = 200;
        public const int SPEED_INC = 3;
        public const int SPEED_MAX = 240;
        public const int MIN_FLAP_GAP = 3;
        public const int MAX_TICKS = 72000;

        public class Result
        {
            public int Score { get; set; }
            public int EndTick { get; set; }
            public bool Dead { get; set; }
            /// <summary>Số lần bấm bay hợp lệ đã dùng (để kiểm tra không có tick bấm nào sau khi thua).</summary>
            public int FlapsUsed { get; set; }
        }

        private class Pipe
        {
            public int X;
            public int Top;
            public int Gap;
            public bool Passed;
        }

        /// <summary>Chơi lại 1 lượt. flaps phải tăng dần, cách nhau ≥ MIN_FLAP_GAP tick.</summary>
        public static Result Replay(uint seed, IReadOnlyList<int> flaps)
        {
            uint s = seed;
            uint Rng()
            {
                // mulberry32
                s += 0x6D2B79F5u;
                uint r = s;
                r = (r ^ (r >> 15)) * (r | 1u);
                r ^= r + (r ^ (r >> 7)) * (r | 61u);
                return r ^ (r >> 14);
            }

            int y = START_Y, vy = 0, score = 0, t = 0, lastFlap = -1000, k = 0, used = 0, n = 0;
            bool dead = false;
            var pipes = new List<Pipe>();

            while (!dead && t < MAX_TICKS)
            {
                bool flap = k < flaps.Count && flaps[k] == t;
                if (flap) k++;

                if (flap && t - lastFlap >= MIN_FLAP_GAP)
                {
                    vy = FLAP;
                    lastFlap = t;
                    used++;
                }
                vy += G;
                if (vy > MAX_FALL) vy = MAX_FALL;
                y += vy;
                if (y < HB_H) { y = HB_H; vy = 0; }

                int speed = score < EASY ? SPEED0 : SPEED0 + (score - EASY + 1) * SPEED_INC;
                if (speed > SPEED_MAX) speed = SPEED_MAX;
                foreach (var p in pipes) p.X -= speed;
                while (pipes.Count > 0 && pipes[0].X + PW < -30000) pipes.RemoveAt(0);

                int lastX = pipes.Count > 0 ? pipes[pipes.Count - 1].X : FIRST_X - SPACING;
                while (lastX < SPAWN_X)
                {
                    lastX += SPACING;
                    int gap = n < EASY ? GAP0 : GAP0 - (n - EASY + 1) * GAP_DEC;
                    if (gap < GAP_MIN) gap = GAP_MIN;
                    int top = n == 0
                        ? START_Y - (gap >> 1)                                            // cột đầu: khe ngang tầm xuất phát
                        : TOP_MIN + (int)(Rng() % (uint)(GAP_BOTTOM_MAX - TOP_MIN - gap + 1));
                    n++;
                    pipes.Add(new Pipe { X = lastX, Top = top, Gap = gap });
                }

                foreach (var p in pipes)
                {
                    if (!p.Passed && p.X * 2 + PW <= BIRD_X * 2) { p.Passed = true; score++; }
                }

                bool hit = y + HB_H >= GROUND;
                for (int i = 0; i < pipes.Count && !hit; i++)
                {
                    var p = pipes[i];
                    if (BIRD_X + HB_W > p.X && BIRD_X - HB_W < p.X + PW &&
                        (y - HB_H < p.Top || y + HB_H > p.Top + p.Gap)) hit = true;
                }
                if (hit) { dead = true; break; }
                t++;
            }

            return new Result { Score = score, EndTick = t, Dead = dead, FlapsUsed = used };
        }
    }
}
