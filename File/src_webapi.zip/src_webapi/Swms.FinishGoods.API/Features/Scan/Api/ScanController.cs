﻿using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.Scan.Business;

namespace Swms.FinishGoods.API.Features.Scan.Api
{
    /// <summary>
    /// Quét nhanh (Quick Scan) — điểm vào chung: nhận mã, phân loại,
    /// trả về loại đối tượng để app mở đúng màn chi tiết.
    /// </summary>
    [ApiController]
    [Route("api/scan")]
    public class ScanController : ControllerBase
    {
        private readonly IScanService _service;
        public ScanController(IScanService service) => _service = service;

        /// <summary>
        /// Phân loại 1 mã quét. Luôn trả 200 kèm type (kể cả "not_found")
        /// để app xử lý thống nhất, không phải bắt lỗi 404.
        /// </summary>
        [HttpGet("resolve")]
        public async Task<ActionResult<ScanResolveResponse>> Resolve([FromQuery] string code)
            => Ok(await _service.ResolveAsync(code));
    }
}