using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.PdaApp.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.Api.Features.PdaApp.Api;

[ApiController]
[Route("api/pda-app")]
public class PdaAppController : ControllerBase
{
    private readonly IPdaAppService _service;
    public PdaAppController(IPdaAppService service) => _service = service;

    /// <summary>Lịch sử phiên bản PDA app (mới nhất trước). Bản đang phát hành có IsCurrent = true.</summary>
    [HttpGet("versions")]
    [AllowAnonymous]
    public async Task<ActionResult<List<PdaAppVersionResponse>>> GetVersions()
        => Ok(await _service.GetVersionsAsync());

    /// <summary>Tải file APK của bản đang phát hành (is_current = 1). Hỗ trợ Range để tải tiếp.</summary>
    [HttpGet("download")]
    [AllowAnonymous]
    public async Task<IActionResult> Download()
    {
        var (content, fileName, version) = await _service.DownloadCurrentAsync();

        Response.Headers.CacheControl = "no-store";
        Response.Headers["X-App-Version"] = version;

        // FileStreamResult tự dispose stream sau khi gửi xong.
        return File(content, "application/vnd.android.package-archive", fileName,
                    enableRangeProcessing: true);
    }

    /// <summary>
    /// Công bố phiên bản mới. Nhận multipart/form-data: file (APK) + releaseNote + forceUpdate.
    /// versionName/versionCode server tự đọc từ file APK.
    /// </summary>
    [HttpPost("versions")]
    [RequirePermission<Perms.System.PdaApp.Publish>]
    [RequestSizeLimit(150_000_000)] // ~150 MB
    public async Task<ActionResult<PdaAppVersionResponse>> Publish([FromForm] PublishPdaAppRequest request)
    {
        var created = await _service.PublishAsync(request);
        return CreatedAtAction(nameof(GetVersions), null, created);
    }
}
