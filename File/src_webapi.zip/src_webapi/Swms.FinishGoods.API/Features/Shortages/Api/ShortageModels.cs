using System.ComponentModel.DataAnnotations;
using Swms.FinishGoods.API.Common.Models;

namespace Swms.FinishGoods.API.Features.Shortages.Api;

// Request / response DTOs màn Hàng thiếu. Khớp IShortageApi (Refit) bên Web.

public class ShortageQuery : PagedQuery
{
    public string? Model { get; set; }
    public string? SiNo { get; set; }
    public string? PoNo { get; set; }
    public string? Category { get; set; }
    public string? VanningPlace { get; set; }      // = forwarder_code
    public string? ShipMode { get; set; }
    public string? ReasonCode { get; set; }        // RECEIVING | OQC | FA_UNDELIVERED | FA_PRODUCING | NO_PLAN
    public string? Stage { get; set; }             // none | requested | escalate
    public DateTime? VanningFrom { get; set; }
    public DateTime? VanningTo { get; set; }
    public string? ConsigneeCode { get; set; }
    public string? CountryCode { get; set; }
    public string? Department { get; set; }        // FA | OQC
    public string? Urgency { get; set; }           // overdue | d2 | d7
    public int? MinQty { get; set; }
    public int? CategoryId { get; set; }
}

// ── Response ────────────────────────────────────────────────

/// <summary>Lần đòi gần nhất của 1 nguyên nhân. Đã bỏ luồng ETA: chỉ còn "đòi lúc nào".</summary>
public record FollowUpResponse(DateTime NotifiedAt);

public record ShortageBySiResponse(string SiNo, string? ShipMode, DateTime VanningDate, int QtyShort);

public record ShortageItemResponse(
    long Id,
    string Model,
    int QtyShort,                                  // phần THẬT SỰ thiếu (đã trừ tồn chưa phân bổ)
    int QtyUnallocated,                            // tồn có sẵn nhưng SI chưa phân bổ — bấm phân bổ là đủ
    string? Category,
    List<string> SiNos,
    string? VanningPlace,
    DateTime VanningDate,
    List<string> ShipModes,
    List<string> PoNos,
    List<string> ConsigneeCodes,
    List<string> CountryCodes,
    Dictionary<string, int> ByReason,
    List<ShortageBySiResponse> BySi,
    Dictionary<string, FollowUpResponse> FollowUps,
    int? CategoryId = null);                       // master.categories.code của model — để tra người nhận mail

/// <summary>Key = ReasonCode, "" = tổng thiếu, "UNALLOCATED" = tồn chưa phân bổ.</summary>
public record ShortageSummaryResponse(Dictionary<string, int> Totals);

public record StockPalletResponse(
    string PalletCode, string? LocatorCode, string? AreaCode, DateTime? ProductionDate,
    int Qty, string Bucket, string? HeldBySi);

public record RecipientResponse(string Type, string Email, string? DisplayName);

/// <param name="MailSent">
/// false = Mail:Enabled đang tắt nên KHÔNG có mail nào đi, dù theo dõi vẫn được ghi.
/// Web phải báo rõ, đừng hiện "đã gửi" — đây là cách mail lặng lẽ không tới nơi.
/// Thêm ở CUỐI record nên Web chưa cập nhật vẫn đọc được.
/// </param>
public record SendRequestResponse(List<RecipientResponse> Recipients, int FollowUpCount, bool MailSent = true);

/// <summary>
/// Xem trước khi bấm Gửi: ai sẽ nhận, và mail có thật sự đi không. Trả cờ chứ
/// không chỉ danh sách, để màn hình nói được LÝ DO thay vì chỉ hiện ô trống:
/// MailEnabled = false (cấu hình tắt) khác hẳn Recipients không có TO (chưa khai).
/// Dùng CHUNG đường tra với lúc gửi thật nên không thể lệch nhau.
/// </summary>
public record ShortageMailPreviewResponse(
    string Model,
    string? Category,
    bool MailEnabled,
    bool HasTo,
    List<RecipientResponse> Recipients);

/// <summary>
/// Kết quả POST /api/shortages/daily-report.
/// Sent = false không phải lỗi: Skipped cho biết lý do để worker ghi log
/// (NoShortage | NoTemplate | NoRecipient | MailDisabled | DryRun).
/// Subject / Body trả về để xem thử khi dryRun — Body là markdown TRƯỚC khi dựng HTML.
/// </summary>
public record DailyReportResponse(
    bool Sent,
    string? Skipped,
    DateTime GeneratedAt,
    int ModelCount,
    int TotalQty,
    int UrgentCount,
    int EscalateCount,
    string? Subject,
    string? Body,
    List<RecipientResponse> Recipients);

// ── Request ─────────────────────────────────────────────────

public class ShortageSendRequest
{
    /// <summary>SHORTAGE_REQUEST (đòi FA/OQC) | SHORTAGE_ESCALATE (báo VP).</summary>
    [Required, MaxLength(40)] public string EventCode { get; set; } = "SHORTAGE_REQUEST";
    [Required, MaxLength(50)] public string Model { get; set; } = "";
    [MinLength(1)] public List<string> Departments { get; set; } = new();
    [MaxLength(500)] public string? Note { get; set; }
    [Required, MaxLength(300)] public string Subject { get; set; } = "";
    [Required] public string Body { get; set; } = "";
}

/// <summary>Query của GET api/shortages/mail-preview — cùng 3 trường quyết định người nhận của ShortageSendRequest.</summary>
public class ShortageMailPreviewQuery
{
    [Required, MaxLength(40)] public string EventCode { get; set; } = "SHORTAGE_REQUEST";
    [Required, MaxLength(50)] public string Model { get; set; } = "";
    public List<string> Departments { get; set; } = new();
}
