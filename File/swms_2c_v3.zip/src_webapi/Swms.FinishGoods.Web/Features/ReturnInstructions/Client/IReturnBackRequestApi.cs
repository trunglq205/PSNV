using Refit;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Client;

/// <summary>
/// Đề nghị nhận lại hàng về FA — mục 2c.
///
/// Tên query là camelCase: ASP.NET model binding KHÔNG phân biệt hoa thường
/// nhưng CÓ phân biệt dấu gạch dưới, nên <c>doc_id</c> sẽ không khớp vào
/// <c>BackRequestQuery.DocId</c>.
/// </summary>
public interface IReturnBackRequestApi
{
    [Get("/api/return-back-requests")]
    Task<List<ReturnBackRequestDto>> GetListAsync(
        [AliasAs("docId")] long? docId = null,
        [Query] string? status = null,
        [Query] string? step = null,
        [Query] string? keyword = null);

    [Get("/api/return-back-requests/{id}")]
    Task<ReturnBackRequestDto> GetByIdAsync(long id);

    /// <summary>SL còn gắp được theo model — màn soạn đề nghị dùng để CHO XEM.</summary>
    [Get("/api/return-back-requests/available/{docId}")]
    Task<List<BackAvailableModelDto>> GetAvailableAsync(long docId);

    [Post("/api/return-back-requests")]
    Task<ReturnBackRequestDto> CreateAsync([Body] CreateBackRequestRequestDto request);

    [Put("/api/return-back-requests/{id}")]
    Task<ReturnBackRequestDto> UpdateAsync(long id, [Body] UpdateBackRequestRequestDto request);

    /// <summary>Nhật ký pallet đã giao, mới nhất trước.</summary>
    [Get("/api/return-back-requests/{id}/deliveries")]
    Task<List<BackDeliveryDto>> GetDeliveriesAsync(long id);

    /// <summary>B2 — quản lý FA xác nhận. Mail sang SCS Office đi từ đây.</summary>
    [Post("/api/return-back-requests/{id}/approve-fa")]
    Task<ReturnBackRequestDto> ApproveFaAsync(long id, [Body] BackRequestDecisionRequestDto request);

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA. Bước này chuyển serial sang
    /// <c>at_fa</c>, nên nó là mốc hàng rời kho SCS. Gọi được nhiều lần cho một
    /// đề nghị; mail báo FA chỉ đi ở lượt làm xong cả đề nghị.
    /// </summary>
    [Post("/api/return-back-requests/{id}/deliver")]
    Task<BackDeliverResultDto> DeliverAsync(long id, [Body] DeliverBackRequestDto request);

    [Post("/api/return-back-requests/{id}/cancel")]
    Task<ReturnBackRequestDto> CancelAsync(long id, [Body] BackRequestDecisionRequestDto request);
}
