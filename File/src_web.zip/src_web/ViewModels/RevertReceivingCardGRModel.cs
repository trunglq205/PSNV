﻿using SWMS_WebTool.Models;

namespace SWMS_WebTool.ViewModels
{
    public class RevertReceivingCardGRModel
    {
        public string Material { get; set; }
        public string DeliveryPlanNo { get; set; }
        public DeliveryPlanType Type { get; set; }
    }

    public class RevertReceivingCardGRModelNew
    {
        public string Material { get; set; }
        public string DeliveryPlanNo { get; set; }
        public byte Type { get; set; }
    }

}
