﻿using Newtonsoft.Json;
using Newtonsoft.Json;

namespace SWMS_WebTool.Models
{
    public class BarcodeNG
    {
        [JsonProperty("historyId")]
        public int Id { get; set; }
        [JsonProperty("daInvNo")]
        public string DeliveryPlanNo { get; set; }
        [JsonProperty("daInvItem")]
        public string? DeliveryPlanItem { get; set; }
        [JsonProperty("poNo")]
        public string PurchaseOrderNo { get; set; }
        [JsonProperty("poItem")]
        public string PurchaseOrderItem { get; set; }
        [JsonProperty("vendorCode")]
        public string Vendor { get; set; }
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Material { get; set; }
        public string Sloc { get; set; }
        [JsonProperty("datePrint")]
        public DateTime DateReprint { get; set; }
        [JsonProperty("currentQuantity")]
        public int Quantity { get; set; }
        [JsonProperty("totalQuantity")]
        public int? PlanQuantity { get; set; }
        public int? TotalBox { get; set; }
        public string UnitNo { get; set; }
        public string Reason { get; set; }
    }
}
