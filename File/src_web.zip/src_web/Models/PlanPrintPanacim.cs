﻿namespace SWMS_WebTool.Models
{
    public class PlanPrintPanacim
    {
        public string? sMaterial { get; set; }
        public string? sPlan {  get; set; }
        public string? sDeliveryDate { get; set; }
        public double? GRQuantity { get; set; }
        public double? ProjectorQuantity { get; set; }
        public double? SoundbizQuantity { get; set; }
        public string? Invoice { get; set; }
        public string? sCate { get; set; }
    }
}
