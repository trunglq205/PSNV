import 'package:flutter/foundation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_instruction_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'return_fa_notifier.g.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2d — bản nháp quét của màn FA đóng pallet sau rework.
//
//  Máy KHÔNG đoán mã quét được là thùng hay serial: phân biệt theo GIAI ĐOẠN,
//  cùng cách màn 2a làm. Chưa mở thùng nào thì mã quét là MÃ THÙNG; đang mở
//  một thùng thì mọi mã quét là SERIAL, tới khi bấm "Xong thùng".
//
//  Khác màn 2a ở hai chỗ:
//    · FA không chọn model — sổ serial đã biết mỗi con thuộc model nào.
//    · Serial không khớp VẪN được nhận vào bản nháp và VẪN gửi lên server;
//      nó chỉ bị gắn cờ cảnh báo để FA đặt riêng ra tại bàn. Server mới là nơi
//      quyết định loại con nào và ghi nhật ký — lọc ở máy thì nhật ký lệch
//      luôn rỗng và SCS không bao giờ biết có hàng lạ.
// ─────────────────────────────────────────────────────────────

@immutable
class FaScanState {
  /// Sổ serial của phiếu, khoá theo serial VIẾT HOA để tra không phân biệt
  /// hoa thường. Rỗng = chưa tải xong; lúc đó chưa cho quét.
  final Map<String, ReturnSerialIndexEntry> index;

  /// Các thùng đã quét xong, chờ lưu.
  final List<FaBoxDraft> boxes;

  /// Thùng đang quét serial. `null` = đang chờ quét mã thùng mới.
  final FaBoxDraft? current;

  /// Serial đã quét mà KHÔNG khớp sổ — hiện ngay để FA đặt riêng ra.
  final List<FaMismatch> mismatches;

  const FaScanState({
    this.index = const {},
    this.boxes = const [],
    this.current,
    this.mismatches = const [],
  });

  /// Đã tải xong sổ serial — chưa xong thì chưa kiểm được, nên chưa cho quét.
  bool get isReady => index.isNotEmpty;

  /// Đang mở một thùng → mã quét tiếp theo là serial.
  bool get isScanningSerials => current != null;

  /// Tổng serial trong bản nháp, tính cả thùng đang mở.
  int get serialCount =>
      boxes.fold(0, (s, b) => s + b.serials.length) +
      (current?.serials.length ?? 0);

  /// Số serial KHỚP — con sẽ thật sự vào pallet.
  int get matchedCount => serialCount - mismatches.length;

  bool get hasAnything => serialCount > 0;

  /// Số con trong sổ đang ở FA — mốc để hiện "còn phải đóng bao nhiêu".
  int get atFaTotal => index.values.where((e) => e.isAtFa).length;

  /// Serial đã nằm trong bản nháp (so không phân biệt hoa thường).
  bool hasSerial(String serial) {
    final k = serial.toUpperCase();
    for (final b in boxes) {
      if (b.serials.any((s) => s.toUpperCase() == k)) return true;
    }
    return current?.serials.any((s) => s.toUpperCase() == k) ?? false;
  }

  /// Mã thùng đã dùng trong bản nháp.
  bool hasBoxNo(String boxNo) {
    final k = boxNo.toUpperCase();
    if (boxes.any((b) => (b.boxNo ?? '').toUpperCase() == k)) return true;
    return (current?.boxNo ?? '').toUpperCase() == k;
  }

  /// Cảnh báo của một serial trong bản nháp, nếu có.
  FaMismatch? mismatchOf(String serial) {
    final k = serial.toUpperCase();
    for (final m in mismatches) {
      if (m.serial.toUpperCase() == k) return m;
    }
    return null;
  }

  FaScanState copyWith({
    Map<String, ReturnSerialIndexEntry>? index,
    List<FaBoxDraft>? boxes,
    List<FaMismatch>? mismatches,
    FaBoxDraft? current,
    bool clearCurrent = false,
  }) =>
      FaScanState(
        index: index ?? this.index,
        boxes: boxes ?? this.boxes,
        mismatches: mismatches ?? this.mismatches,
        current: clearCurrent ? null : (current ?? this.current),
      );
}

@riverpod
class FaScanNotifier extends _$FaScanNotifier {
  @override
  FaScanState build() => const FaScanState();

  /// Tải sổ serial của phiếu. Phải gọi trước khi quét.
  Future<bool> loadIndex(int docId) async {
    final rows = await ref.read(appActionProvider.notifier).run(
          () => ref
              .read(returnInstructionRepositoryProvider)
              .fetchSerialIndex(docId),
        );
    if (rows == null) return false;

    state = state.copyWith(
      index: {for (final r in rows) r.serial.toUpperCase(): r},
    );
    return true;
  }

  /// Một mã vừa quét. Giai đoạn quyết định nó là thùng hay serial.
  void onScan(String raw) {
    final code = raw.trim();
    if (code.isEmpty) return;

    if (state.isScanningSerials) {
      _addSerial(code);
    } else {
      _openBox(code);
    }
  }

  void _openBox(String boxNo) {
    if (state.hasBoxNo(boxNo)) {
      throw ReturnDuplicateSerialException(boxNo);
    }
    state = state.copyWith(current: FaBoxDraft(boxNo: boxNo));
  }

  /// Thùng không quét được mã — server đặt tên theo Pallet ID.
  void openBoxWithoutCode() {
    if (state.isScanningSerials) return;
    state = state.copyWith(current: const FaBoxDraft());
  }

  /// Thêm một serial vào thùng đang mở, kèm kiểm trên máy.
  ///
  /// Quét trùng trong CÙNG bản nháp thì chặn — đó là lỗi tay, không phải hàng
  /// lạ. Còn không khớp sổ thì VẪN nhận, chỉ gắn cờ.
  void _addSerial(String serial) {
    final box = state.current;
    if (box == null) return;

    if (state.hasSerial(serial)) {
      throw ReturnDuplicateSerialException(serial);
    }

    final found = state.index[serial.toUpperCase()];
    final mismatch = _classify(serial, found);

    state = state.copyWith(
      current: box.copyWith(serials: [...box.serials, serial]),
      mismatches:
          mismatch == null ? null : [...state.mismatches, mismatch],
    );
  }

  /// Ba kết cục, ba câu cảnh báo khác nhau — FA xử lý khác nhau.
  ///
  /// Sổ tải về chỉ chứa serial của PHIẾU NÀY, nên một con thuộc phiếu khác sẽ
  /// không có trong sổ và rơi vào [FaMismatchKind.notInDoc]. Server tra toàn
  /// hệ thống nên nó phân biệt được `other_doc` và nói rõ số phiếu — đó là
  /// một lý do nữa phải gửi hết lên server.
  FaMismatch? _classify(String serial, ReturnSerialIndexEntry? found) {
    if (found == null) {
      return FaMismatch(serial: serial, kind: FaMismatchKind.notInDoc);
    }
    if (!found.isAtFa) {
      return FaMismatch(
        serial: serial,
        kind: FaMismatchKind.wrongStatus,
        model: found.model,
        foundStatus: found.status,
      );
    }
    return null;
  }

  /// Đóng thùng đang mở. Thùng rỗng thì không nhận.
  void finishBox() {
    final box = state.current;
    if (box == null) return;
    if (box.serials.isEmpty) {
      throw const ReturnBoxEmptyException();
    }
    state = state.copyWith(
      boxes: [...state.boxes, box],
      clearCurrent: true,
    );
  }

  /// Bỏ thùng đang mở — kéo theo cảnh báo của chính các serial trong đó.
  void cancelCurrentBox() {
    final box = state.current;
    if (box == null) return;
    state = state.copyWith(
      clearCurrent: true,
      mismatches: _without(state.mismatches, box.serials),
    );
  }

  void removeSerial(String serial) {
    final box = state.current;
    if (box == null) return;
    final k = serial.toUpperCase();
    state = state.copyWith(
      current: box.copyWith(
        serials: box.serials.where((s) => s.toUpperCase() != k).toList(),
      ),
      mismatches: _without(state.mismatches, [serial]),
    );
  }

  void removeBox(int i) {
    if (i < 0 || i >= state.boxes.length) return;
    final gone = state.boxes[i];
    final rest = [...state.boxes]..removeAt(i);
    state = state.copyWith(
      boxes: rest,
      mismatches: _without(state.mismatches, gone.serials),
    );
  }

  /// Gửi bản nháp lên server. Tự đóng thùng đang mở nếu có serial.
  ///
  /// Gửi TOÀN BỘ serial, kể cả con đã gắn cờ: server đối chiếu lại, tự loại và
  /// tự ghi nhật ký lệch. Xem ghi chú ở đầu file.
  Future<FaPalletResult?> submit(int docId) async {
    var boxes = state.boxes;
    final open = state.current;
    if (open != null && open.serials.isNotEmpty) {
      boxes = [...boxes, open];
    }
    if (boxes.isEmpty) {
      throw const ReturnNothingToSaveException();
    }

    final res = await ref.read(appActionProvider.notifier).run(
          () => ref
              .read(returnInstructionRepositoryProvider)
              .createFaPallet(docId: docId, boxes: boxes),
        );

    // Lưu xong thì xoá bản nháp nhưng GIỮ sổ serial: FA thường đóng liền mấy
    // pallet một lượt, tải lại sổ mỗi lần là một nhịp chờ vô ích. Trạng thái
    // trong sổ có thể đã cũ sau lần lưu, nhưng con vừa đóng đã nằm trong
    // mismatch của bản nháp mới nếu quét lại — và server vẫn là chốt cuối.
    if (res != null) {
      state = FaScanState(index: state.index);
    }
    return res;
  }

  void reset() => state = FaScanState(index: state.index);

  static List<FaMismatch> _without(
          List<FaMismatch> list, List<String> serials) =>
      list
          .where((m) => !serials
              .any((s) => s.toUpperCase() == m.serial.toUpperCase()))
          .toList();
}
