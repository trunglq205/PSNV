﻿using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Models.Layout
{
    public class Zone : Layout
    {
        public Zone() { }

        public Zone(KonvaObject konvaObject) : base(konvaObject)
        {
            KonvaObject? wall;

            if (konvaObject.ClassName.ToEnum<KonvaClassType>() == KonvaClassType.Stage)
            {
                wall = konvaObject.Children?.First().Children?.FirstOrDefault();
                var children = konvaObject.Children?.First().Children?.SkipWhile(e => e.Attrs.Name.ToEnum<WidgetType>() == WidgetType.Wall);

                Widgets = children?.Select(e => WidgetFactory.BuildWidget(e)).ToList() ?? new List<Widget>();
            } else
            {
                wall = konvaObject.Children?.FirstOrDefault();
                var children = konvaObject.Children?.SkipWhile(e => e.Attrs.Name.ToEnum<WidgetType>() == WidgetType.Wall);

                Widgets = children?.Select(e => WidgetFactory.BuildWidget(e)).ToList() ?? new List<Widget>();
            }

            Fill = konvaObject?.Attrs.Fill ?? wall?.Attrs.Fill;
            Border = konvaObject?.Attrs.Stroke ?? wall?.Attrs.Stroke ?? "#000000";
            BorderWidth = konvaObject?.Attrs.StrokeWidth ?? wall?.Attrs.StrokeWidth ?? 5;

            string[] arr = konvaObject?.Attrs.CustomData?.Split(";") ?? new string[3];

            if (arr.Length !=  3)
            {
                return;
            }

            ZoneId = arr[0]?.ToInt() ?? 0;
            ZoneName = arr[1];
            IsJIT = arr[2].ToBool();
        }

        public string ZoneName { get; set; }
        public int ZoneId { get; set; }
        public bool IsJIT { get; set; }

        public override WidgetType Type => WidgetType.Zone;
        protected override KonvaClassType ClassName => KonvaClassType.Group;

        public override KonvaObject ToKonvaObject()
        {
            var children = new List<KonvaObject>()
            {
                new KonvaObject()
                {
                    ClassName = KonvaClassType.Rect.GetString(),
                    Attrs = new KonvaAttr() {
                        X = 0,
                        Y = 0,
                        Width = Width,
                        Height = Height,
                        Fill = Fill,
                        Stroke = Border ?? "#000000",
                        StrokeWidth = BorderWidth ?? 5,
                        Name = WidgetType.Wall.GetString(),
                        StrokeScaleEnabled = true,
                    }
                },
            };

            if (Widgets != null)
            {
                children.AddRange(Widgets.Select((e) => e.ToKonvaObject()));
            }

            return new KonvaObject()
            {
                ClassName = ClassName.GetString(),
                Attrs = ToKonvaAttr(),
                Children = children
            };
        }

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.CustomData = $"{ZoneId};{ZoneName};{IsJIT}";
            return attrs;
        }
    }
}
