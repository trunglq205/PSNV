import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Nút ghim cụm — đặc + tone khi đã ghim, viền + xám khi chưa.
class PinButton extends StatelessWidget {
  final bool pinned;
  final Color tone;
  final VoidCallback onTap;

  const PinButton({
    super.key,
    required this.pinned,
    required this.tone,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return GestureDetector(
      onTap: onTap,
      child: Padding(
        padding: const EdgeInsets.fromLTRB(8, 0, 0, 8),
        child: Icon(
          pinned ? Icons.push_pin : Icons.push_pin_outlined,
          size: 16,
          color: pinned ? tone : swms.text4,
        ),
      ),
    );
  }
}
