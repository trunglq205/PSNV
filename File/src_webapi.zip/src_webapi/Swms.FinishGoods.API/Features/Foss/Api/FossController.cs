using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.Foss.Business;

namespace Swms.FinishGoods.API.Features.Foss.Api;

[ApiController]
[Route("api/foss")]
public class FossController : ControllerBase
{
    private readonly IFossService _service;
    public FossController(IFossService service) => _service = service;

    /// <summary>
    /// Lấy danh sách serial trong pallet từ Foss theo barcode.
    /// VD: GET /api/foss/pallet/210261000123
    /// </summary>
    [HttpGet("pallet/{barcode}")]
    public async Task<ActionResult<List<FossPalletItemResponse>>> GetPallet(string barcode)
        => Ok(await _service.GetPalletByBarcodeAsync(barcode));

    [HttpGet("pallet/today")]
    public async Task<ActionResult<List<string>>> GetTodayPallets()
    => Ok(await _service.GetTodayPalletsAsync());
}
