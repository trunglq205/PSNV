import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/widgets/common/printer_status_bar.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_preview_card.dart';

/// Bước in màn Sửa / Tách / Gộp: máy in + preview từng nhãn sẽ in.
/// Không có ô số phiếu — số nhãn do thao tác quyết định.
class PartCardActionPrintBody extends StatelessWidget {
  const PartCardActionPrintBody({
    super.key,
    required this.printer,
    required this.forms,
    required this.saved,
    this.onChangePrinter,
  });

  final PrinterDevice? printer;

  /// Nhãn sẽ in (đã lưu thì là phần CÒN LẠI chưa ra giấy).
  final List<PartCardForm> forms;

  /// Đã lưu server — chỉ còn in nốt.
  final bool saved;

  final VoidCallback? onChangePrinter;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final waiting = LocaleKeys.part_card_print_status_waiting.tr();

    return ListView(
      children: [
        PrinterStatusBar(device: printer, onChange: onChangePrinter),
        const SizedBox(height: AppDimens.sm),
        if (saved) ...[
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
            decoration: BoxDecoration(
              color: swms.success.withValues(alpha: .08),
              borderRadius: BorderRadius.circular(AppDimens.rInput),
              border: Border.all(color: swms.success.withValues(alpha: .35)),
            ),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Icon(Icons.cloud_done_outlined, size: 14, color: swms.success),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    LocaleKeys.part_card_action_saved_hint.tr(),
                    style: AppTextStyles.caption.copyWith(
                      fontSize: 11,
                      fontWeight: FontWeight.w700,
                      color: swms.success,
                    ),
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppDimens.sm),
        ],
        for (var i = 0; i < forms.length; i++) ...[
          PartCardPreviewCard(
            form: forms[i],
            mode: forms[i].mode,
            status: forms.length > 1
                ? '${i + 1}/${forms.length} · $waiting'
                : waiting,
          ),
          const SizedBox(height: AppDimens.sm),
        ],
      ],
    );
  }
}
