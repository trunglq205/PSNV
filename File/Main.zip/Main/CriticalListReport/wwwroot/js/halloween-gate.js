/* =========================================================
   MÀN "MỞ CỔNG" HALLOWEEN SAU ĐĂNG NHẬP
   Drop-in: wwwroot/js/halloween-gate.js (nạp bởi Views/Shared/_HalloweenGate.cshtml)

   Cách chơi: những con ma bay lượn lờ (thỉnh thoảng mờ đi). Click / chạm vào
   đâu thì quả bí ngô được ném tới đó theo đường vòng cung. Ném trúng đủ
   HITS_REQUIRED con ma → 2 cánh cổng sắt mở ra, vào trang Home.
   Bàn phím: Space / Enter = ném tự ngắm (giữ phím = ném liên tục).
   ========================================================= */
(function () {
    "use strict";

    /* ---------- CẤU HÌNH ---------- */
    var HITS_REQUIRED = 3;       // số con ma cần ném trúng
    var GHOSTS_ON_FIELD = 3;     // số con ma cùng lúc trên màn
    var SKIP_AFTER_MS = 0;       // hiện nút "Bỏ qua" sau n ms (0 = hiện ngay; -1 = không cho bỏ qua, bắt buộc chơi)
    var THROW_COOLDOWN_MS = 220; // chống spam click
    var SPEED_MULT = 1.8;        // hệ số tốc độ bay ngang (0.5 = dễ)
    var LEVEL_UP = 0.22;         // mỗi lần trúng, ma nhanh thêm bao nhiêu (0.08 = dễ)
    var DASH = true;             // true: ma thỉnh thoảng lao vụt đi
    var FLICKER = true;          // true: ma thỉnh thoảng mờ đi rồi hiện lại
    var AIM_ASSIST = 0;          // "nam châm": >0 thì click trong bán kính n × cỡ con ma là bí ngô tự bay theo và trúng (1.8 = dễ; 0 = tắt)
    var Y_MIN = 0.44, Y_MAX = 0.86; // vùng ma bay theo chiều dọc (tỉ lệ chiều cao màn)
    var VSPEED = 0.0045;         // tốc độ bay lên/xuống tối đa
    var HOP = 0.16;              // độ bồng bềnh lên xuống
    var GHOST_SIZE = 1.4;        // kích thước con ma
    var PUMPKIN_SIZE = 1.8;      // kích thước quả bí ngô ném
    var WITCH_FIRST_MS = 1500;   // phù thủy bay qua lần đầu sau n ms
    var WITCH_EVERY_MS = [6000, 10000]; // khoảng nghỉ giữa các lượt bay
    var WITCH_CROSS_MS = 6500;   // thời gian bay hết chiều ngang màn
    var WITCH_SIZE = 1.15;       // phóng to/thu nhỏ phù thủy
    var RESULT_SHOW_MS = 0;      // 0 = KHÔNG tự vào: đứng ở màn kết quả chờ người chơi chọn "Chơi lại" / "Vào hệ thống". >0 = tự vào sau n ms (có đếm ngược)

    var gate = document.getElementById("halloweenGate");
    if (!gate) return;

    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var root = document.documentElement;
    root.classList.add("hg-lock");

    var hud = gate.querySelector(".hg-hud");
    var dots = [];
    var progress = gate.querySelector(".hg-progress");
    for (var d = 0; d < HITS_REQUIRED; d++) {
        var sp = document.createElement("span");
        sp.textContent = "👻";
        progress.appendChild(sp);
        dots.push(sp);
    }
    /* ---------- DÒNG MẸO PHÍM SPACE (luôn hiện rõ) ---------- */
    (function buildTip() {
        if (!document.getElementById("hg-tip-style")) {
            var st = document.createElement("style");
            st.id = "hg-tip-style";
            st.textContent =
                ".hg-tip{display:block!important;margin:14px auto 0;padding:10px 16px;border-radius:12px;" +
                "background:linear-gradient(180deg,#ffb04a,#ff7a1a);color:#2a0f00;border:2px solid #ffe2b8;" +
                "font:800 16.5px/1.4 'Be Vietnam Pro','Segoe UI',sans-serif;letter-spacing:.1px;" +
                "box-shadow:0 0 0 4px rgba(255,122,26,.35),0 8px 22px rgba(0,0,0,.45);" +
                "animation:hgTipPulse 1.4s ease-in-out infinite;transform-origin:center}" +
                ".hg-tip kbd{display:inline-block;padding:2px 12px;margin:0 3px;border-radius:7px;background:#2a1244;" +
                "color:#fff;font:800 15px 'Be Vietnam Pro','Segoe UI',sans-serif;box-shadow:0 3px 0 #000;vertical-align:1px}" +
                ".hg-hud{width:min(660px,calc(100% - 24px))!important}" +
                ".hg-hud.done .hg-tip{display:none!important}" +
                ".hg-hud p b{color:#ffb347}" +
                ".hg-result{margin-top:10px;pointer-events:auto}" +
                ".hg-rank{font:700 15px/1.5 'Be Vietnam Pro','Segoe UI',sans-serif;color:#efe4ff}" +
                ".hg-rank b{color:#9dff7a;font-size:17px}" +
                ".hg-pb{color:#ffe066;font-weight:800}" +
                ".hg-actions{display:flex;gap:10px;justify-content:center;margin-top:12px}" +
                ".hg-actions button{border:none;border-radius:999px;padding:8px 18px;font:800 14px 'Be Vietnam Pro','Segoe UI',sans-serif;cursor:pointer}" +
                ".hg-go{background:linear-gradient(180deg,#ff8a2a,#b9470a);color:#fff;box-shadow:0 4px 14px rgba(185,71,10,.5)}" +
                ".hg-board{background:rgba(255,255,255,.14);color:#fff;border:1px solid rgba(255,255,255,.4)!important}" +
                ".hg-actions button:focus-visible{outline:3px solid #9dff7a;outline-offset:2px}" +
                ".hg-replay{background:linear-gradient(180deg,#8a55c8,#5b2a8c);color:#fff;box-shadow:0 4px 14px rgba(91,42,140,.5)}" +
                ".hg-gate .hg-skip.show{display:block}" +
                ".hg-gate .hg-skip{z-index:6;right:22px;bottom:22px;padding:14px 26px;font:800 19px/1.2 'Be Vietnam Pro','Segoe UI',sans-serif;" +
                "background:linear-gradient(180deg,#ffffff,#efe4ff);color:#3b1a60;border:3px solid #ff8a1f;border-radius:999px;cursor:pointer;" +
                "box-shadow:0 0 0 5px rgba(255,138,31,.25),0 8px 22px rgba(0,0,0,.5);animation:hgSkipPulse 2.2s ease-in-out infinite}" +
                ".hg-gate .hg-skip:hover{background:#fff;transform:scale(1.05)}" +
                ".hg-gate .hg-skip kbd{font:800 13px 'Be Vietnam Pro',sans-serif;background:#3b1a60;color:#fff;border-radius:6px;padding:2px 7px;margin-left:8px;vertical-align:2px}" +
                "@keyframes hgSkipPulse{0%,100%{box-shadow:0 0 0 5px rgba(255,138,31,.25),0 8px 22px rgba(0,0,0,.5)}50%{box-shadow:0 0 0 10px rgba(255,138,31,.12),0 8px 22px rgba(0,0,0,.5)}}" +
                "@media (prefers-reduced-motion:reduce){.hg-gate .hg-skip{animation:none}}" +
                "@keyframes hgTipPulse{0%,100%{transform:scale(1);box-shadow:0 0 0 4px rgba(255,122,26,.35),0 8px 22px rgba(0,0,0,.45)}" +
                "50%{transform:scale(1.07);box-shadow:0 0 0 8px rgba(255,160,60,.55),0 0 26px rgba(255,140,40,.95)}}" +
                "@media (prefers-reduced-motion:reduce){.hg-tip{animation:none}}";
            document.head.appendChild(st);
        }
        if (!gate.querySelector(".hg-tip")) {
            var tip = document.createElement("div");
            tip.className = "hg-tip";
            tip.innerHTML = "💡 Mẹo: nhấn liên tục hoặc giữ phím <kbd>Space</kbd> để qua nhanh";
            progress.parentNode.appendChild(tip);
        }
    })();

    /* ---------- SLOGAN CHẠY NGANG TRÊN CÙNG MÀN NÉM MA ---------- */
    var SLOGAN = '"Đứa nào mải chơi làm critical chậm chếc với bà =))"';
    var sloganBar = null;
    function sloganH() { return sloganBar && sloganBar.isConnected ? sloganBar.offsetHeight : 0; }
    (function buildSlogan() {
        if (!document.getElementById("hg-slogan-style")) {
            var st = document.createElement("style");
            st.id = "hg-slogan-style";
            st.textContent =
                // dải slogan TO ở đáy màn
                ".hg-slogan{position:absolute;z-index:5;left:0;right:0;bottom:0;height:64px;overflow:hidden;pointer-events:none;" +
                "background:linear-gradient(90deg,rgba(20,8,34,.94),rgba(59,26,96,.94),rgba(20,8,34,.94));" +
                "border-top:3px solid #ff8a1f;box-shadow:0 -6px 22px rgba(0,0,0,.5);transition:opacity .5s ease}" +
                ".hg-gate.opening .hg-slogan{opacity:0}" +
                ".hg-slogan .trk{display:inline-flex;white-space:nowrap;height:100%;align-items:center;" +
                "animation:hgSlogan 30s linear infinite;will-change:transform}" +
                ".hg-slogan span{padding:0 40px;font:800 30px/1 'Be Vietnam Pro','Segoe UI',sans-serif;color:#ffd27a;" +
                "letter-spacing:.3px;text-shadow:0 0 14px rgba(255,120,20,.75),0 2px 2px rgba(0,0,0,.6)}" +
                ".hg-slogan i{font-style:normal;font-size:30px}" +
                "@keyframes hgSlogan{from{transform:translateX(0)}to{transform:translateX(-50%)}}" +
                // nút Bỏ qua nằm trên dải slogan
                ".hg-gate .hg-skip{bottom:84px!important}" +
                "@media (max-width:900px),(max-height:620px){.hg-slogan{height:50px}.hg-slogan span,.hg-slogan i{font-size:22px}" +
                ".hg-slogan span{padding:0 26px}.hg-gate .hg-skip{bottom:62px!important;font-size:16px;padding:10px 18px}}" +
                "@media (prefers-reduced-motion:reduce){.hg-slogan .trk{animation:none}}";
            document.head.appendChild(st);
        }
        var bar = document.createElement("div");
        bar.className = "hg-slogan";
        bar.setAttribute("role", "marquee");
        bar.setAttribute("aria-label", SLOGAN);
        var trk = document.createElement("div");
        trk.className = "trk";
        // 2 nửa giống hệt nhau để chạy vòng liền mạch; mỗi nửa lặp vài lần cho phủ kín màn rộng
        for (var half = 0; half < 2; half++) {
            for (var k = 0; k < 3; k++) {
                var sp = document.createElement("span");
                sp.textContent = SLOGAN;          // textContent: giữ nguyên nháy kép và "=))"
                trk.appendChild(sp);
                var ic = document.createElement("i");
                ic.textContent = ["👻", "🎃", "🦇"][k];
                ic.setAttribute("aria-hidden", "true");
                trk.appendChild(ic);
            }
        }
        bar.appendChild(trk);
        gate.appendChild(bar);
        sloganBar = bar;
    })();

    /* ---------- BẢNG XẾP HẠNG NGAY TRÊN MÀN NÉM MA (góc phải) ---------- */
    var lb = (function buildLiveBoard() {
        var url = gate.getAttribute("data-board-url");
        if (!url) {
            var m = document.querySelector('meta[name="game-board-url"]');
            url = m ? m.getAttribute("content") : null;
        }
        if (!url || !window.fetch) return null;

        if (!document.getElementById("hg-lb-style")) {
            var st = document.createElement("style");
            st.id = "hg-lb-style";
            st.textContent =
                ".hg-lb{position:absolute;z-index:4;top:max(20px,4vh);right:18px;width:272px;padding:14px 14px 12px;border-radius:16px;" +
                "background:rgba(22,10,38,.72);backdrop-filter:blur(6px);border:1px solid rgba(255,180,90,.35);" +
                "box-shadow:0 10px 30px rgba(0,0,0,.45);color:#efe4ff;font:600 13px/1.4 'Be Vietnam Pro','Segoe UI',sans-serif;" +
                "pointer-events:none;transition:opacity .5s ease}" +
                ".hg-gate.opening .hg-lb{opacity:0}" +
                ".hg-lb h4{margin:0;font:400 22px/1.1 'Creepster','Be Vietnam Pro',cursive;letter-spacing:1px;color:#ff9a3c;" +
                "text-shadow:0 0 10px rgba(255,120,20,.5)}" +
                ".hg-lb .sub{font-size:11.5px;color:#c9b8e0;margin:3px 0 8px}" +
                ".hg-lb .sub b{color:#ffb347}" +
                ".hg-lb ol{list-style:none;margin:0;padding:0}" +
                ".hg-lb li{display:flex;align-items:center;gap:8px;padding:5px 6px;border-radius:8px}" +
                ".hg-lb li+li{margin-top:2px}" +
                ".hg-lb li .rk{width:24px;text-align:center;font-weight:800;color:#c9b8e0}" +
                ".hg-lb li .nm{flex:1;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-weight:700;color:#fff}" +
                ".hg-lb li .tm{font-weight:800;color:#9dff7a;font-variant-numeric:tabular-nums}" +
                ".hg-lb li.me{background:rgba(157,255,122,.16);outline:1px solid rgba(157,255,122,.5)}" +
                ".hg-lb li.flash{animation:hgLbFlash 1.2s ease 2}" +
                "@keyframes hgLbFlash{50%{background:rgba(255,224,102,.35)}}" +
                ".hg-lb .gap{justify-content:center;color:#c9b8e0;padding:0}" +
                ".hg-lb .mine{margin-top:9px;padding-top:8px;border-top:1px dashed rgba(255,255,255,.25);font-size:12.5px;color:#efe4ff}" +
                ".hg-lb .mine b{color:#ffe066}" +
                ".hg-lb .empty{padding:6px 2px;color:#c9b8e0}" +
                ".hg-lb .rule{margin-top:8px;font-size:10.5px;color:#a996c4}" +
                ".hg-lb .prize{margin:2px 0 8px;padding:6px 9px;border-radius:10px;background:linear-gradient(90deg,#ff9a3c,#b9470a);" +
                "color:#fff;font-weight:800;font-size:13px;text-align:center;box-shadow:0 3px 10px rgba(185,71,10,.4)}" +
                ".hg-lb .prize b{color:#fff3c4;font-size:15px}" +
                ".hg-lb .rules{pointer-events:auto;display:block;width:100%;margin-top:9px;padding:6px 10px;border-radius:999px;" +
                "border:1px solid rgba(255,255,255,.45);background:rgba(255,255,255,.12);color:#fff;" +
                "font:800 12.5px 'Be Vietnam Pro','Segoe UI',sans-serif;cursor:pointer}" +
                ".hg-lb .rules:hover{background:rgba(255,255,255,.24)}" +
                ".hg-lb .rules:focus-visible{outline:2px solid #9dff7a;outline-offset:2px}" +
                "@media (max-width:1100px){.hg-lb{width:230px;right:10px;padding:10px}.hg-lb h4{font-size:19px}}" +
                "@media (max-width:1300px) and (min-width:861px){.hg-hud{width:min(600px,calc(100% - 540px))!important;left:calc(50% - 125px)!important}}" +
                "@media (max-width:860px){.hg-lb{display:none}}";
            document.head.appendChild(st);
        }

        var box = document.createElement("div");
        box.className = "hg-lb";
        box.setAttribute("aria-live", "polite");
        box.innerHTML = '<h4>🏆 BXH ném ma</h4><div class="sub">Đang tải…</div>';
        gate.appendChild(box);

        function esc(t) {
            return String(t == null ? "" : t).replace(/[&<>"']/g, function (ch) {
                return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
            });
        }
        function sec(ms) { return (ms / 1000).toFixed(2) + "s"; }

        function prizeText(d) {
            if (d && d.prize) return d.prize;
            var m = document.querySelector('meta[name="game-prize"]');
            return (m && m.getAttribute("content")) || "200.000đ";
        }

        // nút "Thể lệ" — mở hộp thể lệ của halloween.js (nằm trên màn ném ma)
        box.addEventListener("click", function (e) {
            var b = e.target.closest ? e.target.closest(".rules") : null;
            if (!b) return;
            e.stopPropagation();
            if (window.Halloween && window.Halloween.openRules) window.Halloween.openRules();
        });

        function render(d, flash) {
            var rows = (d.rows || []).slice(0, 5);
            var myName = d.me ? d.me.username : null;
            var medal = ["🥇", "🥈", "🥉"];
            var html = '<h4>🏆 BXH ném ma</h4><div class="sub">Mùa Halloween ' + d.from + " – " + d.to + " · " +
                (d.closed ? "<b>đã chốt</b>" : "còn <b>" + d.daysLeft + " ngày</b>") + " · " + d.total + " người</div>" +
                '<div class="prize">🎁 Top 1 nhận <b>' + esc(prizeText(d)) + "</b></div>";
            if (!rows.length) {
                html += '<div class="empty">Chưa ai lên bảng — hạ 3 con ma thật nhanh để làm người đầu tiên! 👻</div>';
            } else {
                html += "<ol>";
                function li(r) {
                    var me = r.username === myName;
                    return '<li class="' + (me ? "me" + (flash ? " flash" : "") : "") + '"><span class="rk">' + (medal[r.rank - 1] || r.rank) +
                        '</span><span class="nm">' + esc(r.fullName) + '</span><span class="tm">' + sec(r.durationMs) + "</span></li>";
                }
                rows.forEach(function (r) { html += li(r); });
                if (d.me && d.me.rank > rows.length) html += '<li class="gap">⋯</li>' + li(d.me);
                html += "</ol>";
            }
            if (d.me) {
                var target = d.me.rank > 1 && d.rows[d.me.rank - 2]
                    ? " · nhanh hơn <b>" + sec(d.rows[d.me.rank - 2].durationMs) + "</b> để lên #" + (d.me.rank - 1)
                    : d.me.rank === 1 ? " · bạn đang dẫn đầu! 👑" : "";
                html += '<div class="mine">Kỷ lục của bạn: <b>' + sec(d.me.durationMs) + "</b> (hạng #" + d.me.rank + ")" + target + "</div>";
            } else if (rows.length) {
                html += '<div class="mine">Bạn chưa có thành tích — vượt <b>' + sec(rows[Math.min(rows.length, 5) - 1].durationMs) +
                    "</b> để vào top " + Math.min(rows.length, 5) + "!</div>";
            }
            html += '<div class="rule">Tính thời gian nhanh nhất · lượt dùng Space/Enter không được tính</div>' +
                '<button type="button" class="rules">📜 Xem thể lệ &amp; giải thưởng</button>';
            box.innerHTML = html;
        }

        function load(flash) {
            var u = url + (url.indexOf("?") < 0 ? "?" : "&") + "theme=" + (gate.getAttribute("data-theme") || "halloween") + "&top=20";
            return fetch(u, { credentials: "same-origin", headers: { "Accept": "application/json" } })
                .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
                .then(function (d) { render(d, flash); })
                .catch(function () { box.innerHTML = '<h4>🏆 BXH ném ma</h4><div class="sub">Không tải được bảng xếp hạng.</div>'; });
        }

        load(false);
        return { reload: function () { return load(true); } };
    })();

    var skip = gate.querySelector(".hg-skip");
    var hudH2 = hud.querySelector("h2").innerHTML, hudP = hud.querySelector("p").innerHTML; // để "Chơi lại" khôi phục
    var countEl = gate.querySelector("[data-hg-count]");
    if (countEl) countEl.textContent = String(HITS_REQUIRED);

    var cv = document.createElement("canvas");
    cv.className = "hg-canvas";
    cv.setAttribute("aria-hidden", "true");
    gate.insertBefore(cv, hud);
    var ctx = cv.getContext("2d");

    var W = 0, H = 0, DPR = Math.min(window.devicePixelRatio || 1, 2);

    var ghosts = [], balls = [], parts = [], texts = [], flakes = [];
    var witch = null, witchAt = performance.now() + WITCH_FIRST_MS, dust = [];
    var hits = 0, finished = false, lastThrow = 0, aim = null, reloadAt = 0;
    // số liệu cho bảng xếp hạng
    var startAt = 0, throwsCount = 0, usedAuto = false, resultReady = false, opened = false, openTimer = 0, countTimer = 0;

    function resize() {
        var oldW = W || 1;
        W = gate.clientWidth; H = gate.clientHeight;
        cv.width = W * DPR; cv.height = H * DPR;
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        ghosts.forEach(function (s) { s.x = s.x * W / oldW; });
        var target = Math.round(Math.min(60, (W * H) / 30000));
        while (flakes.length < target) flakes.push(makeFlake());
        flakes.length = target;
    }

    function baseUnit() { return Math.max(52, Math.min(140, H * 0.13)); }
    function unit() { return baseUnit() * GHOST_SIZE; }
    function ballR0() { return Math.max(18, baseUnit() * 0.2 * PUMPKIN_SIZE); }  // cỡ lúc vừa ném (gần)
    function ballR1() { return Math.max(9, baseUnit() * 0.1 * PUMPKIN_SIZE); }   // cỡ lúc chạm đích (xa)
    // phối cảnh: càng lên cao (xa) càng nhỏ, càng xuống thấp (gần) càng to
    function depthOf(s) { return (s.gy - Y_MIN) / (Y_MAX - Y_MIN); }
    function sizeOf(s) { return unit() * (0.68 + depthOf(s) * 0.45); }
    function groundOf(s) { return H * s.gy; }

    /* ---------- CON MA ---------- */
    function spawnGhost() {
        var dir = Math.random() < 0.5 ? 1 : -1;
        var level = 1 + hits * LEVEL_UP;                          // mỗi lần trúng, con ma nhanh hơn
        var speed = (2.0 + Math.random() * 1.6) * SPEED_MULT * level * (REDUCED ? 0.5 : 1);
        // chia vùng dọc thành các dải để con ma không dồn một chỗ
        var band = ghosts.filter(function (s) { return s.alive; }).length % 3;
        var gy = Y_MIN + (Y_MAX - Y_MIN) * ((band + Math.random()) / 3);
        ghosts.push({
            x: dir > 0 ? -60 : W + 60,
            gy: gy,
            dir: dir,
            speed: speed,
            vy: randVy() * level,
            phase: Math.random() * 6.28,
            alive: true,
            nextTurn: 900 + Math.random() * 2200,
            nextVy: 600 + Math.random() * 1400,
            dash: 0,
            hat: Math.random() < 0.6,
            alpha: 0, fadeTo: 1, fadeT: 1500 + Math.random() * 3000
        });
    }

    function randVy() { return (Math.random() < 0.5 ? -1 : 1) * VSPEED * (0.35 + Math.random() * 0.65) * (REDUCED ? 0.5 : 1); }

    function hitCircles(s) {
        var u = sizeOf(s), g = groundOf(s) + hop(s);
        return [
            { x: s.x, y: g - u * 0.2, r: u * 0.32 },
            { x: s.x, y: g - u * 0.45, r: u * 0.34 },
            { x: s.x, y: g - u * 0.68, r: u * 0.3 }
        ];
    }

    // ma bay bồng bềnh lên xuống (không chạm đất)
    function hop(s) { return Math.sin(s.phase) * sizeOf(s) * HOP * 0.7 - sizeOf(s) * 0.08; }

    function drawGhost(s) {
        var u = sizeOf(s), g = groundOf(s), h = hop(s);
        var t = s.phase, dir = s.dir;
        var tail = -dir * u * 0.12;
        var R = u * 0.34, top = -u * 0.62;

        // bóng mờ dưới đất
        ctx.save();
        ctx.globalAlpha = 0.16 * s.alpha;
        ctx.fillStyle = "#120a1f";
        ctx.beginPath();
        ctx.ellipse(s.x, g + u * 0.1, R * (0.9 - h / u), R * 0.18, 0, 0, 6.2832);
        ctx.fill();
        ctx.restore();

        ctx.save();
        ctx.globalAlpha = s.alpha;
        ctx.translate(s.x, g + h);
        ctx.rotate(Math.sin(t) * 0.07 * dir);

        // tay ngắn vẫy
        ctx.fillStyle = "#f4f0ff";
        [-1, 1].forEach(function (side) {
            ctx.save();
            ctx.translate(side * R * 0.95, -u * 0.4);
            ctx.rotate(side * (0.5 + Math.sin(t * 2 + side) * 0.35));
            ctx.beginPath(); ctx.ellipse(side * u * 0.06, 0, u * 0.11, u * 0.055, 0, 0, 6.2832); ctx.fill();
            ctx.restore();
        });

        // thân ma: đầu tròn + vạt dưới lượn sóng bay theo gió
        var gr = ctx.createRadialGradient(-R * 0.35, top - R * 0.3, R * 0.1, 0, -u * 0.35, u * 0.7);
        gr.addColorStop(0, "#ffffff");
        gr.addColorStop(0.65, "#f3efff");
        gr.addColorStop(1, "#cfc4ec");
        ctx.fillStyle = gr;
        ctx.shadowColor = "rgba(190, 210, 255, .75)";
        ctx.shadowBlur = u * 0.22;
        ctx.beginPath();
        ctx.moveTo(-R, top);
        ctx.arc(0, top, R, Math.PI, 0);
        ctx.quadraticCurveTo(R * 1.02, -u * 0.25, R + tail, 0);
        var n = 4, w = (2 * R) / n;
        for (var i = 0; i < n; i++) {
            var x0 = R + tail - i * w, x1 = x0 - w;
            var dip = (i % 2 === 0 ? 1 : -1) * u * 0.07 * (0.6 + 0.4 * Math.sin(t * 2.4 + i));
            ctx.quadraticCurveTo((x0 + x1) / 2, dip + u * 0.04, x1, 0);
        }
        ctx.quadraticCurveTo(-R * 1.02, -u * 0.25, -R, top);
        ctx.closePath();
        ctx.fill();
        ctx.shadowBlur = 0;
        ctx.lineWidth = Math.max(1, u * 0.012);
        ctx.strokeStyle = "rgba(70, 40, 110, .35)";
        ctx.stroke();

        // mặt
        var fx = dir * u * 0.05;
        ctx.fillStyle = "#1c1230";
        ctx.beginPath(); ctx.ellipse(fx - u * 0.11, top - u * 0.02, u * 0.045, u * 0.065, 0, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.ellipse(fx + u * 0.11, top - u * 0.02, u * 0.045, u * 0.065, 0, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.arc(fx - u * 0.1, top - u * 0.045, u * 0.015, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(fx + u * 0.12, top - u * 0.045, u * 0.015, 0, 6.2832); ctx.fill();
        // miệng "Ú òa" mở to dần theo nhịp
        ctx.fillStyle = "#3a1d4f";
        ctx.beginPath(); ctx.ellipse(fx, top + u * 0.13, u * 0.05, u * (0.035 + 0.03 * Math.abs(Math.sin(t * 1.5))), 0, 0, 6.2832); ctx.fill();
        // má hồng
        ctx.fillStyle = "rgba(255, 130, 170, .45)";
        ctx.beginPath(); ctx.arc(fx - u * 0.19, top + u * 0.07, u * 0.04, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(fx + u * 0.19, top + u * 0.07, u * 0.04, 0, 6.2832); ctx.fill();

        // mũ phù thủy
        if (s.hat) {
            var hy = top - R * 0.82;
            ctx.fillStyle = "#3b1d5e";
            ctx.beginPath();
            ctx.moveTo(-u * 0.17, hy);
            ctx.quadraticCurveTo(-u * 0.05, hy - u * 0.25, -dir * u * 0.16, hy - u * 0.42 + Math.sin(t) * u * 0.02);
            ctx.quadraticCurveTo(u * 0.06, hy - u * 0.2, u * 0.17, hy);
            ctx.closePath();
            ctx.fill();
            ctx.fillStyle = "#ff8a1f";
            ctx.fillRect(-u * 0.155, hy - u * 0.06, u * 0.31, u * 0.05);
            ctx.fillStyle = "#2a1244";
            ctx.beginPath(); ctx.ellipse(0, hy, u * 0.3, u * 0.05, 0, 0, 6.2832); ctx.fill();
        }
        ctx.restore();
    }

    // quả bí ngô (đạn ném) — có mặt cười phát sáng khi đủ to
    function drawPumpkin(x, y, r, rot) {
        ctx.save();
        ctx.translate(x, y);
        ctx.rotate(rot || 0);
        var gr = ctx.createRadialGradient(-r * 0.3, -r * 0.35, r * 0.1, 0, 0, r * 1.1);
        gr.addColorStop(0, "#ffb347");
        gr.addColorStop(0.7, "#ff7a1a");
        gr.addColorStop(1, "#c4500a");
        ctx.fillStyle = gr;
        ctx.beginPath(); ctx.ellipse(0, 0, r * 1.12, r, 0, 0, 6.2832); ctx.fill();
        // múi bí
        ctx.strokeStyle = "rgba(150, 60, 0, .55)";
        ctx.lineWidth = Math.max(1, r * 0.08);
        ctx.beginPath(); ctx.ellipse(0, 0, r * 0.38, r * 0.98, 0, 0, 6.2832); ctx.stroke();
        ctx.beginPath(); ctx.moveTo(0, -r * 0.98); ctx.lineTo(0, r * 0.98); ctx.stroke();
        // cuống
        ctx.fillStyle = "#4f7a2a";
        ctx.beginPath();
        ctx.moveTo(-r * 0.12, -r * 0.92); ctx.lineTo(-r * 0.05, -r * 1.35); ctx.lineTo(r * 0.16, -r * 1.3); ctx.lineTo(r * 0.12, -r * 0.92);
        ctx.closePath(); ctx.fill();
        // mặt khắc
        if (r > 11) {
            ctx.fillStyle = "#ffe066";
            ctx.shadowColor = "rgba(255, 200, 60, .9)";
            ctx.shadowBlur = r * 0.4;
            [-1, 1].forEach(function (sd) {
                ctx.beginPath();
                ctx.moveTo(sd * r * 0.5, -r * 0.08); ctx.lineTo(sd * r * 0.32, -r * 0.42); ctx.lineTo(sd * r * 0.14, -r * 0.08);
                ctx.closePath(); ctx.fill();
            });
            ctx.beginPath();
            ctx.moveTo(-r * 0.6, r * 0.15);
            ctx.lineTo(-r * 0.4, r * 0.3); ctx.lineTo(-r * 0.25, r * 0.18); ctx.lineTo(-r * 0.1, r * 0.34);
            ctx.lineTo(r * 0.1, r * 0.2); ctx.lineTo(r * 0.25, r * 0.36); ctx.lineTo(r * 0.4, r * 0.22); ctx.lineTo(r * 0.6, r * 0.15);
            ctx.quadraticCurveTo(0, r * 0.75, -r * 0.6, r * 0.15);
            ctx.fill();
            ctx.shadowBlur = 0;
        }
        ctx.restore();
    }

    /* ---------- QUẢ BÍ NGÔ ---------- */
    function origin() { return { x: W / 2, y: H - sloganH() - ballR0() - 10 }; }  // quả bí ngô chờ ném nằm ngay trên dải slogan

    function throwAt(tx, ty) {
        if (finished) return;
        var now = performance.now();
        if (now - lastThrow < THROW_COOLDOWN_MS) return;
        lastThrow = now;
        reloadAt = now + THROW_COOLDOWN_MS;
        if (!startAt) startAt = now;   // tính giờ từ quả ném đầu tiên
        throwsCount++;
        var o = origin();
        var dist = Math.hypot(tx - o.x, ty - o.y);
        balls.push({
            x0: o.x, y0: o.y, x1: tx, y1: ty,
            homing: pickAssist(tx, ty),
            t0: now,
            dur: 330 + dist * 0.32,
            arc: Math.min(220, dist * 0.28),
            r0: ballR0(),
            r1: ballR1()
        });
    }

    // tìm con ma gần điểm click nhất (trong bán kính hút) để bí ngô tự bay theo
    function pickAssist(tx, ty) {
        if (!(AIM_ASSIST > 0)) return null;
        var best = null, bestD = 1e9;
        ghosts.forEach(function (s) {
            if (!s.alive) return;
            var c = hitCircles(s)[1];
            var dd = Math.hypot(tx - c.x, ty - c.y);
            if (dd < sizeOf(s) * AIM_ASSIST && dd < bestD) { bestD = dd; best = s; }
        });
        return best;
    }

    function flightTime(tx, ty) {
        var o = origin();
        return 330 + Math.hypot(tx - o.x, ty - o.y) * 0.32;
    }

    // Space / Enter: tự ngắm (có tính trước đường đi của con ma)
    function autoThrow() {
        var best = null, bestD = 1e9, o = origin();
        ghosts.forEach(function (s) {
            if (!s.alive || s.x < 0 || s.x > W) return;
            var c = hitCircles(s)[1];
            var dd = Math.hypot(c.x - o.x, c.y - o.y);
            if (dd < bestD) { bestD = dd; best = s; }
        });
        if (!best) return;
        usedAuto = true;               // dùng Space → lượt này không được xếp hạng
        var c = hitCircles(best)[1];
        var t = flightTime(c.x, c.y);
        var frames = t / 16.67;
        var boost = best.dash > 0 ? 1.9 : 1;
        throwAt(c.x + best.dir * best.speed * boost * frames, c.y + best.vy * H * frames);
    }

    function landBall(b) {
        if (b.homing && b.homing.alive) { knockDown(b.homing, b.x1, b.y1); return; }
        var target = null;
        ghosts.forEach(function (s) {
            if (!s.alive || target) return;
            hitCircles(s).forEach(function (c) {
                if (Math.hypot(b.x1 - c.x, b.y1 - c.y) <= c.r * 1.12 + b.r1) target = s;
            });
        });
        if (target) knockDown(target, b.x1, b.y1);
        else if (witchHit(b.x1, b.y1)) {
            splat(b.x1, b.y1, 14, "#9dff7a", 2.5);
            texts.push({ x: b.x1, y: b.y1 - 30, t: 0, label: "Trick! 🧹" });
        }
        else splat(b.x1, b.y1, 12, "#ff8a1f", 3);
    }

    function knockDown(s, x, y) {
        s.alive = false;
        hits++;
        var u = sizeOf(s);
        // tan thành khói tím + kẹo văng ra
        smoke(s.x, hitCircles(s)[1].y, u);
        splat(x, y, 16, "#f4f0ff", u * 0.05);
        for (var c = 0; c < 4; c++) {
            parts.push(piece(s.x, hitCircles(s)[1].y, ["#ff8a1f", "#9dff7a", "#d3a6ff", "#ff5c8a"][c], u * 0.07, "candy"));
        }
        if (s.hat) parts.push(piece(s.x, hitCircles(s)[2].y - u * 0.2, "#3b1d5e", u * 0.14, "hat"));
        texts.push({ x: s.x, y: hitCircles(s)[2].y - u * 0.4, t: 0, label: hits >= HITS_REQUIRED ? "Tuyệt vời!" : "Boo!" });

        if (dots[hits - 1]) dots[hits - 1].classList.add("on");
        if (hits >= HITS_REQUIRED) finish();
        else setTimeout(spawnGhost, 500);
    }

    function piece(x, y, color, size, kind) {
        return {
            x: x, y: y, vx: (Math.random() - 0.5) * 6, vy: -7 - Math.random() * 4,
            rot: 0, vr: (Math.random() - 0.5) * 0.4, r: size, color: color, kind: kind, life: 1, g: 0.32
        };
    }

    function smoke(x, y, u) {
        for (var i = 0; i < 12; i++) {
            var a = Math.random() * 6.2832, v = 0.6 + Math.random() * 1.6;
            parts.push({
                x: x + Math.cos(a) * u * 0.15, y: y + Math.sin(a) * u * 0.15,
                vx: Math.cos(a) * v, vy: Math.sin(a) * v - 0.8,
                r: u * (0.12 + Math.random() * 0.1), grow: u * 0.012,
                color: Math.random() < 0.5 ? "rgba(150,90,220,.55)" : "rgba(230,220,255,.6)",
                kind: "smoke", life: 1, g: -0.02, rot: 0, vr: 0
            });
        }
    }

    function splat(x, y, n, color, size) {
        for (var i = 0; i < n; i++) {
            var a = Math.random() * 6.2832, v = 1.5 + Math.random() * 4.5;
            parts.push({
                x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 2,
                r: (size || 3) * (0.5 + Math.random()), color: color, kind: "dot", life: 1, g: 0.22, rot: 0, vr: 0
            });
        }
    }

    /* ---------- PHÙ THỦY CƯỠI CHỔI (trang trí, bay ngang bầu trời) ---------- */
    function witchScale() { return Math.max(0.8, Math.min(1.7, W / 1000)) * WITCH_SIZE; }

    function startWitch(now) {
        var dir = Math.random() < 0.5 ? 1 : -1;
        var k = witchScale();
        var len = 130 * k;
        var hudBottom = hud.getBoundingClientRect().bottom - gate.getBoundingClientRect().top;
        var base = Math.min(0.5, (hudBottom + 60 * k) / H + 0.05);
        witch = {
            dir: dir, t0: now, k: k, len: len,
            dur: WITCH_CROSS_MS * (REDUCED ? 1.4 : 1) * (0.9 + Math.random() * 0.25),
            base: base + Math.random() * 0.07,
            climb: Math.random() * 0.05,
            wave: 0.015 + Math.random() * 0.02,
            ho: false, x: -9999, y: -9999
        };
    }

    function witchPos(S, p) {
        var span = W + S.len * 2;
        var x = S.dir > 0 ? -S.len + span * p : W + S.len - span * p;
        var y = H * (S.base - S.climb * p) + Math.sin(p * Math.PI * 4) * H * S.wave;
        return { x: x, y: y };
    }

    function updateWitch(now, dt) {
        if (!witch) {
            if (now >= witchAt && !finished) startWitch(now);
            return;
        }
        var S = witch;
        var p = (now - S.t0) / S.dur;
        if (p >= 1.05) {
            witch = null;
            witchAt = now + WITCH_EVERY_MS[0] + Math.random() * (WITCH_EVERY_MS[1] - WITCH_EVERY_MS[0]);
            return;
        }
        var a = witchPos(S, p), b = witchPos(S, p + 0.004);
        S.x = a.x; S.y = a.y;
        S.tilt = Math.atan2(b.y - a.y, Math.abs(b.x - a.x) + 0.001) * 0.8;

        // bụi phép thuật xanh/tím phía sau đuôi chổi
        if (!REDUCED || Math.random() < 0.3) {
            for (var i = 0; i < 2; i++) {
                dust.push({
                    x: S.x - S.dir * 72 * S.k + (Math.random() - 0.5) * 12,
                    y: S.y + 6 * S.k + (Math.random() - 0.5) * 12,
                    vx: -S.dir * (0.2 + Math.random() * 0.5), vy: 0.1 + Math.random() * 0.3,
                    r: (1.2 + Math.random() * 2.2) * S.k, life: 1,
                    c: Math.random() < 0.55 ? "#9dff7a" : "#d3a6ff"
                });
            }
        }
        if (!S.ho && Math.abs(S.x - W / 2) < W * 0.08) {
            S.ho = true;
            texts.push({ x: S.x, y: S.y - 70 * S.k, t: 0, label: "Hehehe!" });
        }
    }

    function drawDust(dt) {
        for (var i = dust.length - 1; i >= 0; i--) {
            var d = dust[i];
            d.x += d.vx * dt; d.y += d.vy * dt; d.life -= 0.012 * dt;
            if (d.life <= 0) { dust.splice(i, 1); continue; }
            ctx.globalAlpha = d.life * (0.6 + Math.random() * 0.4);
            ctx.fillStyle = d.c;
            star4(d.x, d.y, d.r * (0.6 + d.life * 0.6));
        }
        ctx.globalAlpha = 1;
    }

    function star4(x, y, r) {
        ctx.beginPath();
        ctx.moveTo(x, y - r * 2);
        ctx.quadraticCurveTo(x, y, x + r * 2, y);
        ctx.quadraticCurveTo(x, y, x, y + r * 2);
        ctx.quadraticCurveTo(x, y, x - r * 2, y);
        ctx.quadraticCurveTo(x, y, x, y - r * 2);
        ctx.fill();
    }

    function drawWitch(now) {
        var S = witch;
        if (!S) return;
        var t = now / 1000;
        ctx.save();
        ctx.translate(S.x, S.y);
        ctx.scale(S.dir * S.k, S.k);   // vẽ hướng sang phải, lật khi bay sang trái
        ctx.rotate(-S.tilt * S.dir);
        ctx.lineCap = "round";
        ctx.lineJoin = "round";

        // đuôi chổi rơm
        ctx.strokeStyle = "#c9a14a";
        ctx.lineWidth = 1.6;
        for (var i = -5; i <= 5; i++) {
            ctx.beginPath();
            ctx.moveTo(-46, 6);
            ctx.quadraticCurveTo(-60, 6 + i * 1.6, -76 - Math.abs(i) * 0.6, 6 + i * 2.6 + Math.sin(t * 9 + i) * 1.2);
            ctx.stroke();
        }
        ctx.strokeStyle = "#7a2fb3";
        ctx.lineWidth = 3;
        ctx.beginPath(); ctx.moveTo(-47, 2); ctx.lineTo(-47, 10); ctx.stroke();
        // cán chổi
        ctx.strokeStyle = "#6b4226";
        ctx.lineWidth = 3.2;
        ctx.beginPath(); ctx.moveTo(-48, 6); ctx.lineTo(46, -3); ctx.stroke();

        // mèo đen ngồi sau
        ctx.fillStyle = "#121018";
        ctx.beginPath(); ctx.ellipse(-30, -2, 7, 6, 0, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(-27, -11, 5, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.moveTo(-31, -14); ctx.lineTo(-30, -20); ctx.lineTo(-27, -15); ctx.fill();
        ctx.beginPath(); ctx.moveTo(-26, -15); ctx.lineTo(-23, -20); ctx.lineTo(-23, -13); ctx.fill();
        ctx.strokeStyle = "#121018"; ctx.lineWidth = 2.2;
        ctx.beginPath(); ctx.moveTo(-36, 0); ctx.quadraticCurveTo(-44, -6 + Math.sin(t * 4) * 3, -40, -14); ctx.stroke();
        ctx.fillStyle = "#ffe066";
        ctx.beginPath(); ctx.arc(-25.5, -12, 1.1, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(-28.5, -12, 1.1, 0, 6.2832); ctx.fill();

        // áo choàng bay phần phật về sau
        var flap = Math.sin(t * 7);
        ctx.fillStyle = "#2a1244";
        ctx.beginPath();
        ctx.moveTo(4, -24);
        ctx.quadraticCurveTo(-14, -18 + flap * 3, -22, -4 + flap * 4);
        ctx.quadraticCurveTo(-10, -2, 0, 4);
        ctx.closePath();
        ctx.fill();
        // thân váy tím
        ctx.fillStyle = "#4b2378";
        ctx.beginPath();
        ctx.moveTo(-2, -24); ctx.lineTo(12, -22); ctx.lineTo(14, 4); ctx.lineTo(-8, 5);
        ctx.closePath(); ctx.fill();
        // chân tất sọc + giày
        ctx.strokeStyle = "#1c1230"; ctx.lineWidth = 3.4;
        ctx.beginPath(); ctx.moveTo(8, 3); ctx.lineTo(16, 15); ctx.stroke();
        ctx.strokeStyle = "#ff8a1f"; ctx.lineWidth = 3.4;
        ctx.setLineDash([2.5, 2.5]);
        ctx.beginPath(); ctx.moveTo(8, 3); ctx.lineTo(16, 15); ctx.stroke();
        ctx.setLineDash([]);
        ctx.fillStyle = "#121018";
        ctx.beginPath(); ctx.ellipse(18, 16, 4.5, 2.2, 0.3, 0, 6.2832); ctx.fill();
        // tay nắm chổi
        ctx.strokeStyle = "#4b2378"; ctx.lineWidth = 3.6;
        ctx.beginPath(); ctx.moveTo(8, -18); ctx.lineTo(22, -3); ctx.stroke();
        ctx.fillStyle = "#8fd16a";
        ctx.beginPath(); ctx.arc(23, -2.5, 2.4, 0, 6.2832); ctx.fill();

        // tóc + mặt xanh + mũi khoằm
        ctx.strokeStyle = "#1c1230"; ctx.lineWidth = 2;
        for (var hI = 0; hI < 4; hI++) {
            ctx.beginPath(); ctx.moveTo(4, -32 + hI * 2);
            ctx.quadraticCurveTo(-6, -30 + hI * 3 + flap * 2, -12 - hI, -24 + hI * 3 + flap * 3);
            ctx.stroke();
        }
        ctx.fillStyle = "#8fd16a";
        ctx.beginPath(); ctx.arc(8, -31, 6.2, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.moveTo(12, -33); ctx.quadraticCurveTo(19, -31, 17, -27); ctx.lineTo(12, -29); ctx.fill();
        ctx.fillStyle = "#1c1230";
        ctx.beginPath(); ctx.arc(10.5, -33, 0.9, 0, 6.2832); ctx.fill();
        ctx.strokeStyle = "#1c1230"; ctx.lineWidth = 1;
        ctx.beginPath(); ctx.arc(10, -28.5, 2.2, 0.2, 1.6); ctx.stroke();

        // mũ chóp nhọn gãy về sau
        ctx.fillStyle = "#2a1244";
        ctx.beginPath(); ctx.ellipse(7, -37, 13, 2.8, -0.08, 0, 6.2832); ctx.fill();
        ctx.beginPath();
        ctx.moveTo(1, -38);
        ctx.quadraticCurveTo(3, -52, -4, -58 + flap);
        ctx.lineTo(-12, -55 + flap * 1.5);
        ctx.quadraticCurveTo(4, -54, 13, -38);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#ff8a1f";
        ctx.fillRect(2, -42, 10.5, 3);
        ctx.restore();
    }

    function witchHit(x, y) {
        if (!witch) return false;
        var S = witch, k = S.k;
        var x0 = S.x - S.dir * 78 * k, x1 = S.x + S.dir * 48 * k;
        var lo = Math.min(x0, x1), hi = Math.max(x0, x1);
        return x >= lo && x <= hi && Math.abs(y - (S.y - 18 * k)) < 40 * k;
    }

    /* ---------- ĐOM ĐÓM LẬP LÒE TRÊN MÀN ---------- */
    function makeFlake() {
        return {
            x: Math.random() * W, y: H * (0.35 + Math.random() * 0.65),
            vx: (Math.random() - 0.5) * 0.4, vy: -(0.1 + Math.random() * 0.35),
            r: 1.2 + Math.random() * 1.8, ph: Math.random() * 6.28,
            c: Math.random() < 0.7 ? "255,214,106" : "182,255,122"
        };
    }

    /* ---------- VÒNG LẶP ---------- */
    var last = performance.now();
    function frame(now) {
        if (!gate.isConnected) return;
        var dt = Math.min((now - last) / 16.67, 3);
        last = now;
        ctx.clearRect(0, 0, W, H);

        // đom đóm lập lòe
        if (!REDUCED) {
            for (var i = 0; i < flakes.length; i++) {
                var f = flakes[i];
                f.x += f.vx * dt; f.y += f.vy * dt; f.ph += 0.05 * dt;
                if (f.y < H * 0.25 || f.x < -10 || f.x > W + 10) { flakes[i] = makeFlake(); flakes[i].y = H + 5; continue; }
                var al = 0.35 + 0.65 * Math.abs(Math.sin(f.ph));
                ctx.fillStyle = "rgba(" + f.c + "," + (al * 0.25) + ")";
                ctx.beginPath(); ctx.arc(f.x, f.y, f.r * 3.2, 0, 6.2832); ctx.fill();
                ctx.fillStyle = "rgba(" + f.c + "," + al + ")";
                ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, 6.2832); ctx.fill();
            }
        }

        // phù thủy bay ngang bầu trời (vẽ trước ma → nằm phía sau)
        updateWitch(now, dt);
        drawDust(dt);
        drawWitch(now);

        // con ma: đi, thỉnh thoảng quay đầu, dội lại ở mép
        var alive = ghosts.filter(function (s) { return s.alive; });
        ghosts = alive;
        alive.sort(function (a, b) { return a.gy - b.gy; });   // xa vẽ trước, gần vẽ sau
        alive.forEach(function (s) {
            var ms = 16.67 * dt;
            // thỉnh thoảng lao nhanh (dash) trong chốc lát
            if (s.dash > 0) s.dash -= ms;
            else if (DASH && Math.random() < 0.004 * dt) s.dash = 450 + Math.random() * 500;
            var boost = s.dash > 0 ? 1.9 : 1;

            s.x += s.dir * s.speed * boost * dt;
            s.gy += s.vy * dt;
            s.phase += 0.13 * dt * (0.8 + s.speed * 0.12) * boost;
            s.nextTurn -= ms;
            s.nextVy -= ms;

            // dội lại ở mép trái/phải và biên trên/dưới
            var margin = sizeOf(s) * 0.5;
            if (s.x < margin && s.dir < 0) s.dir = 1;
            else if (s.x > W - margin && s.dir > 0) s.dir = -1;
            else if (s.nextTurn <= 0 && s.x > margin * 2 && s.x < W - margin * 2) {
                s.dir *= -1;
                s.nextTurn = 900 + Math.random() * 2400;
            }
            if (s.gy < Y_MIN) { s.gy = Y_MIN; s.vy = Math.abs(s.vy); }
            else if (s.gy > Y_MAX) { s.gy = Y_MAX; s.vy = -Math.abs(s.vy); }
            if (s.nextVy <= 0) { s.vy = randVy() * (1 + hits * LEVEL_UP); s.nextVy = 500 + Math.random() * 1500; }

            // lúc ẩn lúc hiện cho khó ngắm
            s.fadeT -= ms;
            if (s.fadeT <= 0) {
                if (FLICKER && s.fadeTo === 1) { s.fadeTo = 0.22; s.fadeT = 500 + Math.random() * 700; }
                else { s.fadeTo = 1; s.fadeT = 1800 + Math.random() * 3200; }
            }
            s.alpha += (s.fadeTo - s.alpha) * Math.min(1, 0.08 * dt);

            drawGhost(s);
        });

        // đường ngắm
        if (aim && !finished) {
            var o = origin();
            var dist = Math.hypot(aim.x - o.x, aim.y - o.y);
            var arc = Math.min(220, dist * 0.28);
            ctx.fillStyle = "rgba(255,170,80,.7)";
            for (var k = 1; k < 14; k++) {
                var tt = k / 14;
                var px = o.x + (aim.x - o.x) * tt;
                var py = o.y + (aim.y - o.y) * tt - Math.sin(Math.PI * tt) * arc;
                ctx.beginPath(); ctx.arc(px, py, 2.2, 0, 6.2832); ctx.fill();
            }
            ctx.strokeStyle = "rgba(255,170,80,.9)";
            ctx.lineWidth = 2;
            ctx.beginPath(); ctx.arc(aim.x, aim.y, 12, 0, 6.2832); ctx.stroke();
        }

        // quả bí ngô đang bay
        for (var bI = balls.length - 1; bI >= 0; bI--) {
            var b = balls[bI];
            var p = Math.min(1, (now - b.t0) / b.dur);
            if (b.homing && b.homing.alive) {           // bí ngô bám theo con ma đã chọn
                var hc = hitCircles(b.homing)[1];
                b.x1 = hc.x; b.y1 = hc.y;
            }
            b.x = b.x0 + (b.x1 - b.x0) * p;
            b.y = b.y0 + (b.y1 - b.y0) * p - Math.sin(Math.PI * p) * b.arc;
            var r = b.r0 + (b.r1 - b.r0) * p;
            drawPumpkin(b.x, b.y, r, (now - b.t0) / 120 * (b.x1 > b.x0 ? 1 : -1));
            if (p >= 1) { balls.splice(bI, 1); landBall(b); }
        }

        // quả bí ngô chờ ném ở dưới giữa màn
        if (!finished) {
            var oo = origin();
            var ready = now >= reloadAt;
            var rr = ballR0() * (ready ? 1 : 0.6);
            ctx.globalAlpha = ready ? 1 : 0.6;
            drawPumpkin(oo.x, oo.y + Math.sin(now / 300) * 2, rr, Math.sin(now / 500) * 0.12);
            ctx.globalAlpha = 1;
        }

        // mảnh vỡ
        for (var q = parts.length - 1; q >= 0; q--) {
            var pt = parts[q];
            pt.vy += pt.g * dt; pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.rot += pt.vr * dt;
            pt.life -= 0.018 * dt;
            if (pt.life <= 0 || pt.y > H + 40) { parts.splice(q, 1); continue; }
            ctx.save();
            ctx.globalAlpha = Math.max(0, pt.life);
            ctx.translate(pt.x, pt.y);
            ctx.rotate(pt.rot);
            ctx.fillStyle = pt.color;
            if (pt.kind === "candy") {
                ctx.fillRect(-pt.r, -pt.r * 0.55, pt.r * 2, pt.r * 1.1);
                ctx.beginPath(); ctx.moveTo(-pt.r, 0); ctx.lineTo(-pt.r * 1.7, -pt.r * 0.6); ctx.lineTo(-pt.r * 1.7, pt.r * 0.6); ctx.fill();
                ctx.beginPath(); ctx.moveTo(pt.r, 0); ctx.lineTo(pt.r * 1.7, -pt.r * 0.6); ctx.lineTo(pt.r * 1.7, pt.r * 0.6); ctx.fill();
            } else if (pt.kind === "hat") {
                ctx.beginPath(); ctx.moveTo(-pt.r * 0.6, pt.r * 0.3); ctx.lineTo(-pt.r * 0.3, -pt.r * 1.3); ctx.lineTo(pt.r * 0.6, pt.r * 0.3); ctx.closePath(); ctx.fill();
                ctx.beginPath(); ctx.ellipse(0, pt.r * 0.35, pt.r * 1.1, pt.r * 0.2, 0, 0, 6.2832); ctx.fill();
            } else if (pt.kind === "smoke") {
                pt.r += pt.grow * dt;
                ctx.beginPath(); ctx.arc(0, 0, pt.r, 0, 6.2832); ctx.fill();            } else {
                ctx.beginPath(); ctx.arc(0, 0, pt.r, 0, 6.2832); ctx.fill();
            }
            ctx.restore();
        }

        // chữ nổi
        for (var tI = texts.length - 1; tI >= 0; tI--) {
            var tx = texts[tI];
            tx.t += 0.02 * dt;
            if (tx.t >= 1) { texts.splice(tI, 1); continue; }
            ctx.globalAlpha = 1 - tx.t;
            var vn = /[À-ỹ]/.test(tx.label);
            ctx.font = vn ? "800 " + Math.round(unit() * 0.26) + "px 'Be Vietnam Pro', 'Segoe UI', sans-serif"
                          : Math.round(unit() * 0.36) + "px 'Creepster', 'Be Vietnam Pro', cursive";
            ctx.textAlign = "center";
            ctx.lineWidth = 4;
            ctx.strokeStyle = "rgba(30,10,45,.8)";
            ctx.strokeText(tx.label, tx.x, tx.y - tx.t * 50);
            ctx.fillStyle = tx.label.indexOf("Hehehe") === 0 || tx.label.indexOf("Trick") === 0 ? "#b6ff7a" : "#ffb347";
            ctx.fillText(tx.label, tx.x, tx.y - tx.t * 50);
            ctx.globalAlpha = 1;
        }

        requestAnimationFrame(frame);
    }

    /* ---------- MỞ MÀN ---------- */
    function finish() {
        if (finished) return;
        finished = true;
        aim = null;
        holding = false;
        var durationMs = Math.max(0, Math.round(performance.now() - (startAt || performance.now())));
        var acc = throwsCount > 0 ? Math.round(100 * hits / throwsCount) : 0;

        hud.classList.add("done");
        hud.querySelector("h2").textContent = "Happy Halloween!";
        hud.querySelector("p").innerHTML =
            "⏱ <b>" + (durationMs / 1000).toFixed(2) + " giây</b> · 🎃 <b>" + throwsCount + "</b> lần ném · 🎯 <b>" + acc + "%</b>";

        var box = document.createElement("div");
        box.className = "hg-result";
        box.innerHTML = '<div class="hg-rank">Đang lưu kết quả…</div>' +
            '<div class="hg-actions"><button type="button" class="hg-replay">🔁 Chơi lại</button>' +
            '<button type="button" class="hg-go">Vào hệ thống ▶</button>' +
            '<button type="button" class="hg-board">🏆 Xem BXH</button></div>';
        hud.appendChild(box);
        if (skip) skip.classList.remove("show");
        box.querySelector(".hg-replay").addEventListener("click", replay);
        box.querySelector(".hg-go").addEventListener("click", openNow);
        box.querySelector(".hg-board").addEventListener("click", function () { openNow(true); });

        var rankEl = box.querySelector(".hg-rank");
        submitScore(durationMs).then(function (r) {
            if (!r) {
                rankEl.textContent = "Không lưu được kết quả lần này (mất kết nối?).";
            } else if (!r.inSeason) {
                rankEl.innerHTML = "BXH mùa Halloween đã chốt ngày <b>" + r.seasonTo + "</b> — lượt này không tính hạng nữa 🎃";
            } else if (!r.ranked) {
                rankEl.innerHTML = "Lượt này có dùng phím <b>Space/Enter</b> nên không tính vào BXH 😉<br />Tự tay ném để leo hạng nhé!";
            } else {
                rankEl.innerHTML =
                    (r.personalBest ? '<span class="hg-pb">✨ Kỷ lục cá nhân mới!</span><br />'
                                    : "Kỷ lục của bạn vẫn là <b>" + (r.bestMs / 1000).toFixed(2) + " giây</b><br />") +
                    "🏆 Hạng <b>#" + r.rank + "</b>/" + r.total + " mùa Halloween (chốt " + r.seasonTo + ")" +
                    (r.rank === 1 ? '<br /><span class="hg-pb">🎁 Bạn đang giữ giải ' + (r.prize || "200.000đ") + " — giữ vững tới " + r.seasonTo + " nhé!</span>" : "");
            }
        }).then(function () {
            resultReady = true;
            if (lb) lb.reload();          // cập nhật BXH góc phải ngay sau khi lưu kết quả
            if (finished && !opened && RESULT_SHOW_MS > 0) startCountdown(box.querySelector(".hg-go"));
        });
    }

    // đếm ngược trên nút "Vào hệ thống" rồi tự mở cổng
    function startCountdown(btn) {
        var left = Math.ceil(RESULT_SHOW_MS / 1000);
        btn.textContent = "Vào hệ thống (" + left + ") ▶";
        countTimer = setInterval(function () {
            left--;
            if (left <= 0) { clearInterval(countTimer); openNow(); return; }
            btn.textContent = "Vào hệ thống (" + left + ") ▶";
        }, 1000);
    }

    // chơi lại ngay tại chỗ, không cần đăng xuất / tải lại trang
    function replay() {
        if (!finished || opened) return;
        clearTimeout(openTimer);
        clearInterval(countTimer);
        finished = false; resultReady = false; holding = false;
        hits = 0; startAt = 0; throwsCount = 0; usedAuto = false;
        ghosts = []; balls.length = 0; parts.length = 0; texts.length = 0;
        dots.forEach(function (d) { d.classList.remove("on"); });
        var old = hud.querySelector(".hg-result");
        if (old) old.remove();
        hud.classList.remove("done");
        hud.querySelector("h2").innerHTML = hudH2;
        hud.querySelector("p").innerHTML = hudP;
        if (skip && SKIP_AFTER_MS >= 0) skip.classList.add("show");
        for (var i = 0; i < GHOSTS_ON_FIELD; i++) {
            (function (delay) { setTimeout(function () { if (!finished) spawnGhost(); }, delay); })(i * 500);
        }
        gate.focus({ preventScroll: true });
    }

    // gửi kết quả lên server (GameScoreController.Submit). Trả về null nếu lỗi.
    function submitScore(durationMs) {
        var url = gate.getAttribute("data-submit-url");
        var tokenEl = gate.querySelector('input[name="__RequestVerificationToken"]');
        if (!url || !window.fetch) return Promise.resolve(null);
        var req = fetch(url, {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "RequestVerificationToken": tokenEl ? tokenEl.value : ""
            },
            body: JSON.stringify({
                theme: gate.getAttribute("data-theme") || "halloween",
                durationMs: durationMs,
                throws: throwsCount,
                hits: hits,
                usedAuto: usedAuto
            })
        }).then(function (res) { return res.ok ? res.json() : null; })
          .catch(function () { return null; });
        // không để người dùng chờ quá 4 giây nếu mạng chậm
        var timeout = new Promise(function (resolve) { setTimeout(function () { resolve(null); }, 4000); });
        return Promise.race([req, timeout]);
    }

    function openNow(showBoard) {
        if (opened) return;
        opened = true;
        clearTimeout(openTimer);
        clearInterval(countTimer);
        openCurtains();
        if (showBoard === true) {
            setTimeout(function () {
                if (window.Halloween && window.Halloween.openBoard) window.Halloween.openBoard();
            }, REDUCED ? 750 : 2050);
        }
    }

    function openCurtains() {
        gate.classList.add("opening");
        if (window.Halloween && window.Halloween.burst) {
            window.Halloween.burst(window.innerWidth / 2, window.innerHeight / 2, 24);
        }
        setTimeout(function () {
            gate.remove();
            root.classList.remove("hg-lock");
            var main = document.querySelector("main");
            if (main) { main.setAttribute("tabindex", "-1"); main.focus({ preventScroll: true }); }
            // báo cho trang biết màn đã mở (vd. DataTables cần adjust cột)
            window.dispatchEvent(new Event("resize"));
            document.dispatchEvent(new CustomEvent("halloween-gate-opened"));
            // bỏ ?themegate=1 khỏi thanh địa chỉ để F5 không hiện lại màn chơi
            try {
                var u = new URL(location.href);
                if (u.searchParams.has("themegate")) {
                    u.searchParams.delete("themegate");
                    history.replaceState(history.state, "", u.pathname + u.search + u.hash);
                }
            } catch (err) { }
        }, REDUCED ? 700 : 2000);
    }

    /* ---------- SỰ KIỆN ---------- */
    function localPoint(e) {
        var r = cv.getBoundingClientRect();
        return { x: e.clientX - r.left, y: e.clientY - r.top };
    }

    cv.addEventListener("pointerdown", function (e) {
        e.preventDefault();
        if (finished) return;            // đã thắng: chỉ vào hệ thống khi bấm nút, click nhầm ra ngoài không tính
        var p = localPoint(e);
        throwAt(p.x, p.y);
    });
    cv.addEventListener("pointermove", function (e) {
        if (e.pointerType === "mouse") aim = localPoint(e);
    });
    cv.addEventListener("pointerleave", function () { aim = null; });

    // Space / Enter: nhấn liên tục hoặc GIỮ phím đều được (giữ phím → tự ném mỗi khi hồi xong)
    var holding = false;
    function isThrowKey(e) { return e.key === " " || e.key === "Spacebar" || e.key === "Enter"; }
    gate.addEventListener("keydown", function (e) {
        if (e.key === "Escape" && !finished && skip && skip.classList.contains("show")) { e.preventDefault(); skipNow(); return; }
        if ((e.key === "r" || e.key === "R") && finished && !opened) { e.preventDefault(); replay(); return; }
        if (!isThrowKey(e)) return;
        e.preventDefault();
        if (finished) { if (resultReady && !e.repeat && e.key === "Enter") openNow(); return; }
        if (!e.repeat) autoThrow();
        holding = true;
    });
    gate.addEventListener("keyup", function (e) { if (isThrowKey(e)) holding = false; });
    window.addEventListener("blur", function () { holding = false; });
    (function holdLoop() {
        if (!gate.isConnected) return;
        if (holding && !finished && balls.length < 2) autoThrow();
        setTimeout(holdLoop, THROW_COOLDOWN_MS + 30);
    })();

    function skipNow() {
        if (finished || opened) return;
        finished = true; opened = true;
        openCurtains();
    }
    if (skip) {
        skip.innerHTML = "Không chơi? Bỏ qua, vào làm việc ▶<kbd>Esc</kbd>";
        skip.addEventListener("click", skipNow);
        if (SKIP_AFTER_MS === 0) skip.classList.add("show");
        else if (SKIP_AFTER_MS > 0) setTimeout(function () { if (!finished) skip.classList.add("show"); }, SKIP_AFTER_MS);
    }

    window.addEventListener("resize", resize);
    resize();
    for (var n = 0; n < GHOSTS_ON_FIELD; n++) {
        (function (delay) { setTimeout(spawnGhost, delay); })(n * 700);
    }
    gate.focus({ preventScroll: true });
    requestAnimationFrame(frame);
})();
