using Dapper;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

public class TripPhotoRepository : ITripPhotoRepository
{
    private readonly IDbConnectionFactory _factory;
    public TripPhotoRepository(IDbConnectionFactory factory) => _factory = factory;

    private const string Columns = """
        f.id AS Id, f.trip_id AS TripId, f.item_key AS ItemKey, f.unit_no AS UnitNo, f.pallet_id AS PalletId,
        RTRIM(pl.pallet_id) AS PalletCode, f.slot_no AS SlotNo,
        f.file_path AS FilePath, f.file_name AS FileName, f.content_type AS ContentType, f.size_bytes AS SizeBytes,
        f.created_at AS CreatedAt, f.created_by AS CreatedBy
        """;

    public async Task<List<TripPhotoRow>> GetByTripAsync(long tripId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<TripPhotoRow>($"""
            SELECT {Columns}
            FROM wms.shipment_trip_photos f
            LEFT JOIN wms.pallets pl ON pl.id = f.pallet_id
            WHERE f.trip_id = @tripId AND f.is_deleted = 0
            ORDER BY f.item_key, f.unit_no, pl.pallet_id, f.slot_no;
            """, new { tripId })).ToList();
    }

    public async Task<TripPhotoRow?> GetAsync(long photoId)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<TripPhotoRow>($"""
            SELECT {Columns}
            FROM wms.shipment_trip_photos f
            LEFT JOIN wms.pallets pl ON pl.id = f.pallet_id
            WHERE f.id = @photoId AND f.is_deleted = 0;
            """, new { photoId });
    }

    /*  UPDLOCK + HOLDLOCK trên câu xoá ảnh cũ: 2 máy PDA gửi cùng 1 ô cùng lúc thì
        máy sau phải chờ máy trước commit, rồi thay đúng ảnh máy trước vừa ghi —
        không đụng index UX_trip_photos_slot.
        unit_no / pallet_id so bằng "cùng NULL hoặc bằng nhau": ảnh theo chuyến có cả 2 NULL,
        ảnh theo pallet có unit_no NULL + pallet_id.                                      */
    public async Task<(long Id, int Replaced)> ReplaceSlotAsync(TripPhotoRow p)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var replaced = await conn.ExecuteAsync("""
                UPDATE wms.shipment_trip_photos WITH (UPDLOCK, HOLDLOCK)
                SET is_deleted = 1, deleted_at = SYSDATETIME(), deleted_by = @CreatedBy
                WHERE trip_id = @TripId AND item_key = @ItemKey AND slot_no = @SlotNo
                  AND ((unit_no IS NULL AND @UnitNo IS NULL) OR unit_no = @UnitNo)
                  AND ((pallet_id IS NULL AND @PalletId IS NULL) OR pallet_id = @PalletId)
                  AND is_deleted = 0;
                """, p, tx);

            var id = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.shipment_trip_photos
                    (trip_id, item_key, unit_no, pallet_id, slot_no, file_path, file_name, content_type, size_bytes,
                     is_deleted, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@TripId, @ItemKey, @UnitNo, @PalletId, @SlotNo, @FilePath, @FileName, @ContentType, @SizeBytes,
                        0, SYSDATETIME(), @CreatedBy);
                """, p, tx);

            tx.Commit();
            return (id, replaced);
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>File trên đĩa giữ lại, giống ảnh phiếu bất thường.</summary>
    public async Task<bool> SoftDeleteAsync(long photoId, string? user)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteAsync("""
            UPDATE wms.shipment_trip_photos
            SET is_deleted = 1, deleted_at = SYSDATETIME(), deleted_by = @user
            WHERE id = @photoId AND is_deleted = 0;
            """, new { photoId, user }) > 0;
    }
}
