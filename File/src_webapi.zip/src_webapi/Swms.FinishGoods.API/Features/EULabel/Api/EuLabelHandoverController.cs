using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.EuLabel.Api;
using Swms.FinishGoods.API.Features.EuLabel.Business;

namespace Swms.FinishGoods.API.Features.EuLabel.Api;

/// <summary>
/// Bàn giao tem EU (In tem EU) — endpoint cho PDA Zebra scan xác nhận tem đã dán.
/// Ghi vào DB EuLabel qua stored procedure dùng chung với tool desktop.
/// PDA tự đăng nhập bằng tài khoản DB In tem (endpoint login bên dưới), KHÔNG dùng
/// JWT của project -> cho phép AllowAnonymous để không vướng FallbackPolicy.
/// Chạy trong LAN nội bộ nhà máy.
/// </summary>
[ApiController]
[AllowAnonymous]
[Route("api/eulabel/handover")]
public class EuLabelHandoverController : ControllerBase
{
    private readonly IEuLabelService _service;
    public EuLabelHandoverController(IEuLabelService service) => _service = service;

    /// <summary>
    /// Đăng nhập PDA — check tài khoản/mật khẩu trong DB In tem.
    /// Trả UserId để PDA gửi kèm mỗi lần confirm. Không dùng JWT.
    /// </summary>
    [HttpPost("login")]
    public async Task<ActionResult<EuLabelLoginResponse>> Login(
        [FromBody] EuLabelLoginRequest req)
        => Ok(await _service.LoginAsync(req.UserName, req.Password));

    /// <summary>
    /// Đăng nhập bằng thẻ nhân viên — quét barcode thẻ (mã thẻ = UserName),
    /// KHÔNG cần mật khẩu. Success=false nếu thẻ không có trong hệ thống.
    /// </summary>
    [HttpPost("login-by-card")]
    public async Task<ActionResult<EuLabelLoginResponse>> LoginByCard(
        [FromBody] CardLoginRequest req)
        => Ok(await _service.LoginByCardAsync(req.CardCode));

    /// <summary>
    /// Từ 1 QR/serial tem bất kỳ -> tìm lô chứa nó, trả tổng kết + toàn bộ serial.
    /// Nhân viên không cần nhớ PrintJobId, chỉ quét 1 tem của lô.
    /// </summary>
    [HttpGet("job-by-tag")]
    public async Task<ActionResult<JobByTagResponse>> JobByTag([FromQuery] string key)
        => Ok(await _service.FindJobByTagAsync(key));

    /// <summary>
    /// Xác nhận 1 tem đã dán. Luôn trả 200 kèm Result (1/-1/0) để PDA xử lý thống nhất:
    ///   1  = OK
    ///  -1  = đã xác nhận trước đó
    ///   0  = không tìm thấy tem trong hệ thống
    /// </summary>
    [HttpPost("confirm")]
    public async Task<ActionResult<HandoverConfirmResponse>> Confirm(
        [FromBody] HandoverConfirmRequest req)
        => Ok(await _service.ConfirmFromPdaAsync(req.Key, req.ConfirmedBy));

    /// <summary>Tổng kết đối chiếu 1 lô: tổng in / đã dán / chưa dán.</summary>
    [HttpGet("job/{printJobId:int}/summary")]
    public async Task<ActionResult<HandoverJobSummaryResponse>> JobSummary(int printJobId)
    {
        var r = await _service.JobSummaryAsync(printJobId);
        return r is null ? NotFound() : Ok(r);
    }
}