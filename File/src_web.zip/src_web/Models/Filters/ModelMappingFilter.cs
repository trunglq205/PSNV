﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class ModelMappingFilter : BaseFilter
    {
        [Display(Name = "Plant")]
        public string? Plant { get; set; }

        [Display(Name = "Category")]
        public string? Cate { get; set; }
        public string ProductDate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");
        public string Model { get; set; }
        public bool IsUrgentDIP { get; set; }
    }
}
