using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.MapView.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.MapView.Api;

/// <summary>Xem bản đồ + trạng thái hàng — dùng chung cho storing/receiving/vanning.</summary>
[ApiController]
[Route("api/map-view")]
public class MapViewController : ControllerBase
{
    private readonly IMapViewService _service;
    public MapViewController(IMapViewService service) => _service = service;

    [HttpGet("{areaCode}")]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<MapViewLayout>> Get(string areaCode)
        => Ok(await _service.GetLayoutAsync(areaCode));
}
