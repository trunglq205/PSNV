import 'package:flutter/foundation.dart' hide Category;
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// Sinh và kiểm tra `lotNo` — **client tự sinh**, server chỉ check format,
/// khớp category và trùng.
///
/// ```
/// <CategoryCode(3)><YYMMDD><Sequence(3)>   →  310260717001
/// ```
abstract final class LotNo {
  static final RegExp _format = RegExp(r'^\d{12}$');

  /// [sequence] là số thứ tự trong ngày (1..999) — phải lấy từ bộ đếm local
  /// (theo category + ngày) để không đụng nhau giữa các lần quét.
  static String build({
    required int categoryCode,
    required int sequence,
    DateTime? date,
  }) {
    final cat = categoryCode.toString().padLeft(3, '0');
    if (cat.length != 3) {
      throw const LotNoInvalidFormatException();
    }
    if (sequence < 1 || sequence > 999) {
      throw const LotNoInvalidFormatException();
    }
    final d = date ?? DateTime.now();
    final ymd = '${_two(d.year % 100)}${_two(d.month)}${_two(d.day)}';
    return '$cat$ymd${sequence.toString().padLeft(3, '0')}';
  }

  static bool isValidFormat(String value) => _format.hasMatch(value);

  static bool matchesCategory(String lotNo, int categoryCode) =>
      lotNo.length >= 3 &&
      lotNo.substring(0, 3) == categoryCode.toString().padLeft(3, '0');

  static String _two(int v) => v.toString().padLeft(2, '0');
}

/// Mức chi tiết của Lot — khớp enum phía API (POST /api/pallets).
enum LotDetailLevel {
  /// Pallet → Box → Serial (mỗi serial 1 dòng, server ép qty = 1).
  serial,

  /// Pallet → Box → Model (có hoặc không có inner carton).
  boxLine,

  /// Chỉ biết số lượng box — KHÔNG gửi boxes.
  boxCount,
}

enum LotType { pallet, stocky }

/// Params tạo Lot — domain layer, map sang `CreateLotRequestModel` ở data layer.
///
/// Lot được tạo **active ngay**, không có bước draft/confirm.
@immutable
class CreateLotParams {
  final LotDetailLevel detailLevel;
  final int categoryCode;
  final LotType lotType;

  /// Bắt buộc — client tự sinh, 12 chữ số, 3 ký tự đầu = [categoryCode].
  final String lotNo;

  /// Bắt buộc khi [LotType.stocky], cấm khi [LotType.pallet].
  final String? stockyCode;

  /// Chỉ dùng cho [LotDetailLevel.boxCount].
  final int? boxCount;

  /// Chỉ dùng cho [LotDetailLevel.boxCount] — lưu thẳng vào `pallets.model`.
  final String? model;

  /// Xác nhận pallet đủ hộp chưa
  final bool isEvenLot;

  /// Chỉ dùng cho [LotDetailLevel.boxCount] — lưu thẳng vào
  /// `pallets.production_date`. Với serial/boxLine server tự tính từ box/line.
  final DateTime? productionDate;

  /// Chỉ dùng cho [LotDetailLevel.boxCount] — quy cách đóng gói (pcs/box).
  final int? standardPacking;

  /// Rỗng khi [LotDetailLevel.boxCount].
  final List<CreateLotBoxParams> boxes;

  const CreateLotParams({
    required this.detailLevel,
    required this.categoryCode,
    required this.lotNo,
    this.lotType = LotType.pallet,
    this.stockyCode,
    this.boxCount,
    this.model,
    this.standardPacking,
    this.isEvenLot = false,
    this.productionDate,
    this.boxes = const [],
  });

  // ─────────────────────────────────────────────────────────
  //  Kiểm tra trước khi gửi — chặn sớm các lỗi 422 của server
  // ─────────────────────────────────────────────────────────

  void validate() {
    _validateLotNo();
    _validateStocky();

    switch (detailLevel) {
      case LotDetailLevel.boxCount:
        _validateBoxCount();
      case LotDetailLevel.serial:
      case LotDetailLevel.boxLine:
        _validateBoxes();
    }
  }

  void _validateLotNo() {
    final isPapVn = categoryCode == CategoryCodes.pap;
    if (!isPapVn && !LotNo.isValidFormat(lotNo)) {
      throw const LotNoInvalidFormatException();
    }
    if (!isPapVn && !LotNo.matchesCategory(lotNo, categoryCode)) {
      throw const LotNoCategoryMismatchException();
    }
  }

  void _validateStocky() {
    final code = stockyCode?.trim();
    switch (lotType) {
      case LotType.stocky:
        if (code == null || code.isEmpty) {
          throw const StockyCodeRequiredException();
        }
      case LotType.pallet:
        if (code != null && code.isNotEmpty) {
          throw const StockyCodeNotAllowedException();
        }
    }
  }

  void _validateBoxCount() {
    if (boxes.isNotEmpty) {
      throw const BoxesNotAllowedForBoxCountException();
    }
    if (boxCount == null || boxCount! <= 0) {
      throw const BoxCountRequiredException();
    }
  }

  void _validateBoxes() {
    if (boxes.isEmpty) {
      throw const BoxesRequiredException();
    }

    final seenBoxNo = <String>{};
    final seenSerial = <String>{};

    for (var i = 0; i < boxes.length; i++) {
      final box = boxes[i];

      if (!seenBoxNo.add(box.boxNo)) {
        throw const BoxNoDuplicatedException();
      }
      if (box.lines.isEmpty) {
        throw const BoxLinesRequiredException();
      }

      for (var j = 0; j < box.lines.length; j++) {
        _validateLine(box.lines[j], seenSerial);
      }
    }
  }

  void _validateLine(CreateBoxLineParams line, Set<String> seenSerial) {
    final serial = line.serialNo?.trim();

    if (detailLevel == LotDetailLevel.serial) {
      if (serial == null || serial.isEmpty) {
        throw const SerialNoRequiredException();
      }
      if (!seenSerial.add(serial)) {
        throw const SerialDuplicatedException();
      }
      return;
    }

    // box_line
    if (serial != null && serial.isNotEmpty) {
      throw const SerialNotAllowedException();
    }
    if (line.qty < 1) {
      throw const QtyRequiredException();
    }
    final carton = line.cartonCount;
    if (carton != null && (carton <= 0 || line.qty % carton != 0)) {
      throw const QtyNotDivisibleByCartonCountException();
    }
  }

  // ─────────────────────────────────────────────────────────
  //  Mode BOX: build từ danh sách PartCard đã quét
  // ─────────────────────────────────────────────────────────

  /// Mỗi part card = 1 box; mỗi model trên card = 1 line.
  /// - [LotDetailLevel.boxLine]: line KHÔNG mang serialNo.
  /// - [LotDetailLevel.serial]: card phải mang serial (mỗi serial 1 dòng).
  factory CreateLotParams.fromCards({
    required String lotNo,
    required List<PartCard> cards,
    required LotDetailLevel detailLevel,
    LotType lotType = LotType.pallet,
    String? stockyCode,
    bool isUrgent = false,
    bool isEvenLot = true,
    String? inspectionStatus,
  }) {
    if (cards.isEmpty) {
      throw const NoPartCardException();
    }
    assert(
      detailLevel != LotDetailLevel.boxCount,
      'fromCards không dùng cho detailLevel.boxCount — dùng fromModelBoxCount.',
    );

    return CreateLotParams(
      detailLevel: detailLevel,
      categoryCode: cards.first.category.value,
      lotType: lotType,
      stockyCode: stockyCode,
      lotNo: lotNo,
      model: cards.map((e) => e.model).toSet().singleOrNull,
      isEvenLot: isEvenLot,
      boxes: [
        for (final c in cards)
          CreateLotBoxParams(
            boxNo: c.cardId,
            psnvPo: c.psnvPo,
            customerPo: c.customerPo,
            productionDate: c.productionDate,
            rawPayload: c.payload,
            lines: [
              for (final m in c.models)
                CreateBoxLineParams(
                  model: m.model,
                  qty: m.quantity,
                  originCountry: m.country,
                  cartonCount: m.cartonQty,
                ),
            ],
          ),
      ],
    );
  }

  // ─────────────────────────────────────────────────────────
  //  Mode MODEL/GTIN: nhập tay số hộp → Case 3 (box_count)
  // ─────────────────────────────────────────────────────────

  /// Chỉ gửi `boxCount`, KHÔNG gửi `boxes` (API trả
  /// `Lot.BoxesNotAllowedForBoxCount` nếu gửi kèm).
  /// `model` và `productionDate` lưu thẳng vào `pallets` vì không có line để suy ra.
  factory CreateLotParams.fromModelBoxCount({
    required ModelInfo modelInfo,
    required int boxCount,
    required String lotNo,
    DateTime? productionDate,
    LotType lotType = LotType.pallet,
    String? stockyCode,
    bool isUrgent = false,
    bool isEvenLot = true,
    String? inspectionStatus,
  }) {
    if (boxCount <= 0) {
      throw const InvalidBoxCountException();
    }

    final category = modelInfo.category;
    if (category == null) {
      throw const NoCategoryException();
    }

    return CreateLotParams(
      detailLevel: LotDetailLevel.boxCount,
      categoryCode: category.value,
      lotType: lotType,
      stockyCode: stockyCode,
      lotNo: lotNo,
      isEvenLot: isEvenLot,
      boxCount: boxCount,
      model: modelInfo.model,
      standardPacking: modelInfo.standardPacking,
      productionDate: productionDate,
    );
  }

  // ─────────────────────────────────────────────────────────
  //  Mode MODEL: quét mã hộp → Case 2 (box_line)
  // ─────────────────────────────────────────────────────────

  /// Mỗi mã quét được = 1 box chứa đúng [ModelInfo.standardPacking] pcs.
  /// Line KHÔNG set serialNo (box_line → `Lot.SerialNotAllowed`); mã quét
  /// dùng làm `boxNo`. Không gửi `boxCount` — server tự đếm từ boxes.
  factory CreateLotParams.fromModelSerials({
    required ModelInfo modelInfo,
    required List<String> serials,
    required String lotNo,
    DateTime? productionDate,
    LotType lotType = LotType.pallet,
    String? stockyCode,
    bool isUrgent = false,
    bool isEvenLot = true,
    String? inspectionStatus,
  }) {
    if (serials.isEmpty) {
      throw const NoSerialException();
    }

    final category = modelInfo.category;
    if (category == null) {
      throw const NoCategoryException();
    }

    return CreateLotParams(
      detailLevel: LotDetailLevel.boxLine,
      categoryCode: category.value,
      lotType: lotType,
      stockyCode: stockyCode,
      lotNo: lotNo,
      isEvenLot: isEvenLot,
      boxes: [
        for (final sn in serials)
          CreateLotBoxParams(
            boxNo: sn,
            productionDate: productionDate,
            lines: [
              CreateBoxLineParams(
                model: modelInfo.model,
                qty: modelInfo.standardPacking,
              ),
            ],
          ),
      ],
    );
  }

  /// Tổng pcs của toàn lot (0 nếu detailLevel == boxCount — không có lines).
  int get totalQty =>
      boxes.fold(0, (sum, b) => sum + b.lines.fold(0, (s, l) => s + l.qty));
}

/// 1 box vật lý trong pallet.
@immutable
class CreateLotBoxParams {
  final String boxNo;
  final String? psnvPo;
  final String? customerPo;

  /// Không gửi thì server tính `MIN(lines.productionDate)`.
  final DateTime? productionDate;

  /// Chuỗi quét gốc từ PDA — server lưu nguyên văn, không parse.
  final String? rawPayload;

  String? get model => lines.singleOrNull?.model;

  final List<CreateBoxLineParams> lines;

  const CreateLotBoxParams({
    required this.boxNo,
    required this.lines,
    this.psnvPo,
    this.customerPo,
    this.productionDate,
    this.rawPayload,
  });
}

/// 1 dòng trong box: 1 serial (mức serial) hoặc 1 model (mức box_line).
@immutable
class CreateBoxLineParams {
  final String model;

  /// Mức serial: server ép = 1. Mức box_line: bắt buộc >= 1.
  final int qty;

  /// Chỉ dùng khi [LotDetailLevel.serial].
  final String? serialNo;

  final DateTime? productionDate;

  /// Chỉ nằm trong `rawPayload` phía server — không có cột riêng.
  final String? originCountry;

  /// Số lượng **inner carton** trong box (không phải pcs/carton).
  /// Chỉ dùng ở mức box_line, và `qty % cartonCount == 0`.
  final int? cartonCount;

  const CreateBoxLineParams({
    required this.model,
    required this.qty,
    this.serialNo,
    this.productionDate,
    this.originCountry,
    this.cartonCount,
  });
}
