using Dapper;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Shortages.DataAccess;

public class ShortageRepository : IShortageRepository
{
    private readonly IDbConnectionFactory _factory;

    public ShortageRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    // Danh sách model truyền vào SQL bằng 1 chuỗi thay vì IN @list: tránh giới hạn
    // 2100 tham số của SQL Server khi số model lớn. Mã model không chứa '|'.
    private static string Join(IEnumerable<string> models) => string.Join('|', models.Distinct());

    public async Task<List<OpenShortLine>> GetOpenShortLinesAsync(int? categoryId = null)
    {
        using var conn = _factory.Create();
        /*  Số đã đáp ứng — GIỮ KHỚP ShipmentInstructionRepository.LineAggSql:
              pending                       -> qty_planned
              picked + pallet               -> qty_planned
              picked + fifo / designated    -> pcs thực tế của thùng đã quét                */
        const string sql = """
            SELECT x.* FROM (
                SELECT l.id AS LineId, s.id AS SiId, s.si_no AS SiNo, l.model AS Model,
                       s.category AS Category, md.category_id AS CategoryId,
                       s.ship_mode AS ShipMode,
                       COALESCE(s.vanning_date, s.etd_date) AS VanningDate,
                       s.forwarder_code AS ForwarderCode, s.consignee_code AS ConsigneeCode,
                       s.country_code AS CountryCode, l.po_no AS PoNo,
                       l.qty_required - ISNULL(l.qty_cut, 0)
                         - ISNULL(t.qty_pending, 0) - ISNULL(t.qty_picked_pallet, 0)
                         - ISNULL(bx.qty_picked_box, 0) AS QtyShort
                FROM wms.shipment_instruction_lines l
                JOIN wms.shipment_instructions s
                  ON s.id = l.si_id AND s.is_deleted = 0 AND s.doc_status IN (N'released', N'picking')
                OUTER APPLY (
                    SELECT TOP 1 m.category_id
                    FROM master.models m
                    WHERE m.code = l.model AND m.is_deleted = 0
                    ORDER BY m.is_active DESC, m.id DESC
                ) md
                OUTER APPLY (
                    SELECT SUM(CASE WHEN sp.shipment_status = N'pending' THEN sp.qty_planned END) AS qty_pending,
                           SUM(CASE WHEN sp.shipment_status = N'picked' AND sp.pick_mode = N'pallet'
                                    THEN sp.qty_planned END) AS qty_picked_pallet
                    FROM wms.shipment_instruction_pallets sp
                    WHERE sp.line_id = l.id
                ) t
                OUTER APPLY (
                    SELECT SUM(bl.qty) AS qty_picked_box
                    FROM wms.shipment_instruction_boxes sb
                    JOIN wms.shipment_instruction_pallets sp ON sp.id = sb.si_pallet_id AND sp.shipment_status = N'picked'
                    JOIN wms.box_lines bl ON bl.box_id = sb.box_id AND bl.is_deleted = 0 AND bl.model = l.model
                    WHERE sb.line_id = l.id AND sb.picked_at IS NOT NULL
                ) bx
            ) x
            WHERE x.QtyShort > 0 AND (@CategoryId IS NULL OR x.CategoryId = @CategoryId);
            """;
        return (await conn.QueryAsync<OpenShortLine>(sql, new { CategoryId = categoryId })).ToList();
    }

    public async Task<List<ReasonRow>> GetReasonsAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT code AS Code, department AS Department, is_plan_only AS IsPlanOnly, sort_order AS SortOrder
            FROM master.shortage_reasons
            WHERE is_active = 1
            ORDER BY sort_order;
            """;
        return (await conn.QueryAsync<ReasonRow>(sql)).ToList();
    }

    /*  Phân loại từng pallet có hàng của model — thứ tự CASE là thứ tự ưu tiên:
          NG              stop_shipment / OQC NG — không xuất được
          FA_UNDELIVERED  đã có pallet nhưng chưa có vị trí = FA đóng gói xong, chưa giao
          RECEIVING       nằm ở khu nhận hàng
          OQC             ở kho nhưng chưa có kết quả kiểm
          ALLOCATED       pallet đã bị giữ NGUYÊN cho SI khác
          AVAILABLE       ở khu storing, lấy được — phần Reserved là đã hứa cho dòng fifo pending
          null            khu vanning / khu khác: đã tập kết đi xuất, không tính
        Thùng đã có dòng _boxes (chỉ định / đã quét) bị loại khỏi Qty ngay từ đầu.
        Pallet locator_id IS NULL mà đã có si_no bị loại khỏi danh sách. */
    public async Task<List<StockPalletRow>> GetStockAsync(IReadOnlyCollection<string> models)
    {
        if (models.Count == 0) return new();
        using var conn = _factory.Create();
        const string sql = """
            WITH m AS (SELECT value AS model FROM STRING_SPLIT(@Models, N'|')),
            -- Dòng SI còn hiệu lực: SI đã xóa không được giữ thùng / pallet / số lượng
            sil AS (
                SELECT l.id, l.model, s.si_no
                FROM wms.shipment_instruction_lines l
                JOIN wms.shipment_instructions s ON s.id = l.si_id AND s.is_deleted = 0
            ),
            bx AS (
                SELECT b.lot_id AS pallet_id, bl.model, SUM(bl.qty) AS qty
                FROM wms.boxes b
                JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                JOIN m ON m.model = bl.model
                WHERE b.is_deleted = 0
                  AND NOT EXISTS (SELECT 1
                                  FROM wms.shipment_instruction_boxes sb
                                  JOIN sil ON sil.id = sb.line_id
                                  WHERE sb.box_id = b.id)
                GROUP BY b.lot_id, bl.model
            ),
            rsv AS (
                SELECT sp.pallet_id, sil.model, SUM(sp.qty_planned) AS qty
                FROM wms.shipment_instruction_pallets sp
                JOIN sil ON sil.id = sp.line_id
                JOIN m ON m.model = sil.model
                WHERE sp.shipment_status = N'pending' AND sp.pick_mode = N'fifo'
                GROUP BY sp.pallet_id, sil.model
            )
            SELECT bx.model AS Model, p.id AS PalletId, p.pallet_id AS PalletCode,
                   loc.locator_code AS LocatorCode, a.area_code AS AreaCode,
                   p.production_date AS ProductionDate,
                   bx.qty AS Qty, ISNULL(rsv.qty, 0) AS Reserved,
                   CASE
                     WHEN p.stop_shipment = 1 OR p.inspection_status = N'ng' THEN N'NG'
                     WHEN p.locator_id IS NULL THEN N'FA_UNDELIVERED'
                     WHEN a.map_type = N'receiving' THEN N'RECEIVING'
                     WHEN p.inspection_status IN (N'not_inspected', N'under_inspection', N'pending_result') THEN N'OQC'
                     WHEN held.si_no IS NOT NULL AND held.pick_mode = N'pallet' THEN N'ALLOCATED'
                     WHEN a.map_type = N'storing' THEN N'AVAILABLE'
                     ELSE NULL
                   END AS Bucket,
                   held.si_no AS HeldBySi
            FROM bx
            JOIN wms.pallets p ON p.id = bx.pallet_id AND p.is_deleted = 0
            LEFT JOIN master.locators loc ON loc.id = p.locator_id
            LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id
            LEFT JOIN rsv ON rsv.pallet_id = p.id AND rsv.model = bx.model
            OUTER APPLY (
                SELECT TOP 1 sil.si_no, sp.pick_mode
                FROM wms.shipment_instruction_pallets sp
                JOIN sil ON sil.id = sp.line_id
                WHERE sp.pallet_id = p.id AND sp.shipment_status IN (N'pending', N'picked')
                ORDER BY CASE WHEN sp.pick_mode = N'pallet' THEN 0 ELSE 1 END, sp.id DESC
            ) held
            -- Pallet chưa có vị trí nhưng đã gắn si_no (HD soft đã xếp cho SI / đã xuất)
            -- không còn là nguồn bù thiếu -> loại hẳn, không tính FA_UNDELIVERED.
            WHERE NOT (p.locator_id IS NULL AND NULLIF(LTRIM(RTRIM(p.si_no)), N'') IS NOT NULL)
            ORDER BY bx.model, p.production_date, p.id;
            """;
        return (await conn.QueryAsync<StockPalletRow>(sql, new { Models = Join(models) })).ToList();
    }

    public async Task<List<ProducingRow>> GetProducingAsync(IReadOnlyCollection<string> models)
    {
        if (models.Count == 0) return new();
        using var conn = _factory.Create();
        const string sql = """
            SELECT pp.model AS Model,
                   SUM(CASE WHEN pp.planned_qty > pp.produced_qty THEN pp.planned_qty - pp.produced_qty ELSE 0 END) AS Qty
            FROM wms.production_plans pp
            JOIN STRING_SPLIT(@Models, N'|') m ON m.value = pp.model
            WHERE pp.status = N'producing'
            GROUP BY pp.model;
            """;
        return (await conn.QueryAsync<ProducingRow>(sql, new { Models = Join(models) })).ToList();
    }

    public async Task<List<FollowUpRow>> GetFollowUpsAsync(IReadOnlyCollection<long> lineIds)
    {
        if (lineIds.Count == 0) return new();
        using var conn = _factory.Create();
        const string sql = """
            SELECT sh.line_id AS LineId, sh.reason_code AS ReasonCode, sh.qty_short AS QtyShort,
                   sh.notified_at AS NotifiedAt
            FROM wms.shipment_instruction_shortages sh
            JOIN STRING_SPLIT(@Ids, N',') x ON TRY_CONVERT(bigint, x.value) = sh.line_id;
            """;
        return (await conn.QueryAsync<FollowUpRow>(sql, new { Ids = string.Join(',', lineIds) })).ToList();
    }

    public async Task<List<MailRecipient>> GetRecipientsAsync(
        string eventCode, string? department, string? subCode, string? category, string? model)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT recipient_type AS Type, email AS Email, display_name AS DisplayName
            FROM master.fn_email_recipients(@eventCode, @department, @subCode, @category, @model, NULL);
            """;
        var rows = await conn.QueryAsync<MailRecipient>(sql, new { eventCode, department, subCode, category, model });
        // Cùng quy tắc với phiếu bất thường: ô "a@x; b@x" thành 2 người nhận.
        return MailRecipientList.Normalize(rows);
    }

    public async Task<List<MailRecipient>> GetEventRecipientsAsync(string eventCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT DISTINCT
                   r.recipient_type AS Type, r.email AS Email, r.display_name AS DisplayName
            FROM   (SELECT DISTINCT c.department
                    FROM   master.email_config c
                    WHERE  c.event_code = @eventCode
                           AND c.is_active = 1 AND c.is_deleted = 0) d
            CROSS APPLY master.fn_email_recipients(@eventCode, d.department, NULL, NULL, NULL, NULL) r;
            """;
        var rows = await conn.QueryAsync<MailRecipient>(sql, new { eventCode });
        return MailRecipientList.Normalize(rows);
    }

    public async Task<ShortageMailTemplateRow?> GetMailTemplateAsync(string eventCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT subject_template AS [Subject], body_template AS [Body]
            FROM   master.email_events
            WHERE  code = @eventCode AND is_active = 1;
            """;
        return await conn.QuerySingleOrDefaultAsync<ShortageMailTemplateRow>(sql, new { eventCode });
    }

    public async Task<string?> GetUserEmailAsync(string? employeeCode)
    {
        if (string.IsNullOrWhiteSpace(employeeCode)) return null;
        using var conn = _factory.Create();
        const string sql = """
            SELECT TOP 1 u.email
            FROM   master.users u
            WHERE  u.employee_code = @employeeCode AND u.is_deleted = 0;
            """;
        return await conn.ExecuteScalarAsync<string?>(sql, new { employeeCode });
    }

    public async Task UpsertFollowUpsAsync(IReadOnlyList<(long LineId, string ReasonCode, int Qty)> rows)
    {
        if (rows.Count == 0) return;
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        // Cột due_at / eta_at / confirmed_* / reason để NULL (đã bỏ luồng ETA).
        const string sql = """
            MERGE wms.shipment_instruction_shortages AS t
            USING (SELECT @LineId AS line_id, @ReasonCode AS reason_code) AS s
               ON t.line_id = s.line_id AND t.reason_code = s.reason_code
            WHEN MATCHED THEN
                UPDATE SET qty_short = @Qty, notified_at = SYSDATETIME()
            WHEN NOT MATCHED THEN
                INSERT (line_id, reason_code, qty_short, notified_at)
                VALUES (@LineId, @ReasonCode, @Qty, SYSDATETIME());
            """;
        foreach (var r in rows)
            await conn.ExecuteAsync(sql, new { r.LineId, r.ReasonCode, r.Qty }, tx);
        tx.Commit();
    }
}
