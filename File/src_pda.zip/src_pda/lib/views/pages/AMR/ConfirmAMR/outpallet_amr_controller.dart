import 'package:injectable/injectable.dart';
import 'package:smart_warehouse/services/models/request/robot_outpallet_request_model.dart';
import '../../../../entities/Robot/RobotLocationTarget.dart';
import '../../../../repositories/robot_repository.dart';
import '../../../../shared/base/base_cubit.dart';
import '../../../../shared/common/error_entity.dart';
import 'outpallet_amr_state.dart';

@injectable
class OutpalletAmrController extends BaseCubit<OutpalletAmrState>
{
  OutpalletAmrController(this._robotRepository) : super(OutpalletAmrState());
  final RobotRepository _robotRepository;
  @override
  Future<void> initData() {
    return launch(() async {
    });
  }
  Future<void> Robot_OutPallet(String barcode) {
    return launch(() async {
      try{
        final request = RobotOutpalletRequestModel(qrcode: barcode);
        final respone =  await _robotRepository.Outpallet(request);
        if(respone!.contains('Error'))
        {
          throw ValidationError(
            type: ValidationErrorType.barcodeExisted,
            message: respone.replaceAll('Error', ''),
          );
        }
      }
      catch(e)
      {
        throw ValidationError(
          type: ValidationErrorType.canNotEmpty,
          message: e.toString(),
        );
      }
    });
  }
}