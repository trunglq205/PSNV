using Swms.FinishGoods.API.Features.ReturnInstructions.Business;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions;

public static class ReturnInstructionModule
{
    public static IServiceCollection AddReturnInstructionFeature(this IServiceCollection services)
    {
        services.AddScoped<IReturnInstructionService, ReturnInstructionService>();
        services.AddScoped<IReturnInstructionRepository, ReturnInstructionRepository>();

        // Mục 2c — yêu cầu back sang FA. CÙNG slice vì cùng đọc ghi
        // wms.return_instruction_serials: sổ serial phải có một chủ.
        services.AddScoped<IReturnBackRequestService, ReturnBackRequestService>();
        services.AddScoped<IReturnBackRequestRepository, ReturnBackRequestRepository>();
        return services;
    }
}

// ServiceCollectionExtensions.AddFeatures():
//   .AddReturnInstructionFeature()
