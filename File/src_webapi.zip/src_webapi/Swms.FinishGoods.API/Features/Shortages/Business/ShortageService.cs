using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.Shortages.Api;
using Swms.FinishGoods.API.Features.Shortages.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.Shortages.Business;

/*  CÁCH TÍNH HÀNG THIẾU
    1. Lấy MỌI dòng SI đang mở còn thiếu (chưa lọc).
    2. Với mỗi model, xếp dòng theo ưu tiên: vanning sớm trước, rồi SI, rồi dòng.
    3. Đổ nguồn lần lượt vào các dòng theo thứ tự:
         UNALLOCATED     tồn lấy được ngay nhưng SI chưa phân bổ -> KHÔNG tính là thiếu
         RECEIVING, OQC, FA_UNDELIVERED   (pallet đã có — tầng 1)
         FA_PRODUCING    lệnh SX đang chạy                        (tầng 2)
         NO_PLAN         phần còn lại
       Thứ tự 3 nguyên nhân tầng 1 lấy từ master.shortage_reasons.sort_order.
    4. Lọc theo dòng (SI, PO, CAT, vanning…) SAU khi đã chia, rồi gộp theo model.
    Chia trước lọc sau để SI vanning sớm luôn được ưu tiên nguồn, dù người dùng
    đang lọc xem SI khác — nếu không, cùng 1 thùng sẽ được đếm là "đủ" cho 2 SI.
    Toàn bộ chạy trong RAM: số dòng SI đang mở thường vài trăm, đủ nhanh. */
public partial class ShortageService : IShortageService
{
    private readonly IShortageRepository _repo;
    private readonly IMailSender _mail;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly ILogger<ShortageService> _logger;

    /// <summary>appsettings "Web:BaseUrl" — cùng khoá phiếu bất thường dùng để dựng link trong mail.</summary>
    private readonly string? _webBaseUrl;

    private const string Unallocated = "UNALLOCATED";
    private static readonly HashSet<string> EventCodes = new() { "SHORTAGE_REQUEST", "SHORTAGE_ESCALATE" };

    public ShortageService(
        IShortageRepository repo,
        IMailSender mail,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        ILogger<ShortageService> logger,
        IConfiguration config)
    {
        _webBaseUrl = config["Web:BaseUrl"]?.Trim().TrimEnd('/');
        _repo = repo;
        _mail = mail;
        _currentUser = currentUser;
        _localizer = localizer;
        _logger = logger;
    }

    /// <summary>Tên hiển thị — ghi vào confirmed_by, làm tên người gửi trên mail.</summary>
    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    /// <summary>Mã nhân viên — để tra email người gửi (CC + Reply-To).</summary>
    private string? ActorCode => _currentUser.EmployeeCode;

    // ═══════════════════════════════════════════════════════════════
    //  Đọc
    // ═══════════════════════════════════════════════════════════════

    public async Task<PagedResult<ShortageItemResponse>> GetPagedAsync(ShortageQuery query)
    {
        if (query.Page < 1) query.Page = 1;
        if (query.Size < 1 || query.Size > 100) query.Size = 20;

        var calc = await CalculateAsync(query.CategoryId);
        var items = Filter(calc, query, applyReason: true)
            .OrderBy(x => x.VanningDate).ThenByDescending(x => x.QtyShort)
            .ToList();

        var page = items.Skip((query.Page - 1) * query.Size).Take(query.Size)
                        .Select(x => x.ToResponse()).ToList();
        return new PagedResult<ShortageItemResponse>(page, items.Count, query.Page, query.Size);
    }

    /// <summary>Tính trên bộ lọc hiện tại nhưng BỎ QUA ReasonCode — nếu không, chọn 1
    /// nguyên nhân sẽ làm các ô khác về 0 và không bấm qua lại được.</summary>
    public async Task<ShortageSummaryResponse> GetSummaryAsync(ShortageQuery query)
    {
        var calc = await CalculateAsync(query.CategoryId);
        var items = Filter(calc, query, applyReason: false).ToList();

        var totals = calc.Reasons.ToDictionary(
            r => r.Code, r => items.Sum(x => x.ByReason.GetValueOrDefault(r.Code)));
        totals[""] = items.Sum(x => x.QtyShort);
        totals[Unallocated] = items.Sum(x => x.QtyUnallocated);
        return new ShortageSummaryResponse(totals);
    }

    public async Task<List<StockPalletResponse>> GetStockAsync(string model)
    {
        var rows = await _repo.GetStockAsync(new[] { model.Trim() });
        var result = new List<StockPalletResponse>();

        foreach (var r in rows.Where(x => x.Bucket is not null && x.Qty > 0))
        {
            var code = r.PalletCode.Trim();
            if (r.Bucket == "AVAILABLE")
            {
                // Phần đã hứa cho dòng fifo pending hiện thành 1 dòng ALLOCATED riêng
                var reserved = Math.Min(r.Qty, r.Reserved);
                var free = r.Qty - reserved;
                if (free > 0)
                    result.Add(new(code, r.LocatorCode, r.AreaCode, r.ProductionDate, free, "AVAILABLE", null));
                if (reserved > 0)
                    result.Add(new(code, r.LocatorCode, r.AreaCode, r.ProductionDate, reserved, "ALLOCATED", r.HeldBySi));
            }
            else
            {
                result.Add(new(code, r.LocatorCode, r.AreaCode, r.ProductionDate, r.Qty, r.Bucket!,
                               r.Bucket == "ALLOCATED" ? r.HeldBySi : null));
            }
        }
        return result;
    }

    public async Task<List<RecipientResponse>> GetRecipientsAsync(
        string eventCode, string? department, string? subCode, string? category, string? model)
        => (await _repo.GetRecipientsAsync(eventCode, Clean(department), Clean(subCode), Clean(category), Clean(model)))
            .Select(ToResponse).ToList();

    /// <summary>
    /// Xem trước người nhận. Đi ĐÚNG đường <see cref="PrepareMailAsync"/> mà
    /// <see cref="SendAsync"/> dùng — xem trước và gửi thật mà tra hai kiểu thì
    /// sớm muộn lệch nhau, và màn xem trước khi đó còn tệ hơn không có.
    /// Không ném lỗi "chưa có người nhận": trả HasTo = false để màn hình nói lý do.
    /// </summary>
    public async Task<ShortageMailPreviewResponse> GetMailPreviewAsync(ShortageMailPreviewQuery query)
    {
        var p = await PrepareMailAsync(query.EventCode, query.Model, query.Departments);
        return new ShortageMailPreviewResponse(
            p.Item.Model, p.Item.Category, _mail.Enabled,
            p.Recipients.Any(r => r.Type == "TO"),
            p.Recipients.Select(ToResponse).ToList());
    }

    // ═══════════════════════════════════════════════════════════════
    //  Ghi
    // ═══════════════════════════════════════════════════════════════

    public async Task<SendRequestResponse> SendAsync(ShortageSendRequest request)
    {
        var p = await PrepareMailAsync(request.EventCode, request.Model, request.Departments);
        if (p.Recipients.All(r => r.Type != "TO"))
            throw new BusinessRuleException(_localizer["Shortage.NoRecipient"]);

        /*  THỨ TỰ: gửi mail TRƯỚC, ghi theo dõi SAU — ngược với phiếu bất thường.
            Phiếu bất thường ghi bước duyệt trước rồi mới gửi, nên lỗi mail phải
            nuốt (để lỗi vọt lên thì Leader bấm lại và bị chặn vì phiếu đã qua
            draft). Ở đây theo dõi có nghĩa là "đã đòi FA/OQC": mail chưa đi mà
            đã ghi notified_at thì màn hình đếm hạn trả lời cho một yêu cầu không
            ai nhận được. Nên lỗi mail ĐƯỢC báo lên, chưa có gì ghi, bấm lại an toàn. */
        var mailSent = _mail.Enabled;
        if (mailSent)
        {
            // From cố định là địa chỉ hệ thống; tên hiển thị + Reply-To mang
            // người gửi, để FA/OQC bấm Trả lời là về đúng người đang đòi hàng.
            var replyTo = await _repo.GetUserEmailAsync(ActorCode);
            try
            {
                await _mail.SendAsync(p.Recipients, request.Subject.Trim(),
                    ShortageMailLayout.Render(request.Subject.Trim(), request.Body, p.Escalate), Actor, replyTo);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Loi gui mail {Event} cho model {Model} — chua ghi theo doi.",
                    request.EventCode, p.Item.Model);
                throw new BusinessRuleException(_localizer["Shortage.MailFailed"]);
            }
        }
        else
        {
            // Môi trường test thường tắt mail: vẫn cho chạy luồng theo dõi, nhưng
            // trả MailSent = false để Web báo rõ thay vì hiện "đã gửi".
            _logger.LogWarning(
                "Mail:Enabled dang tat — KHONG gui mail {Event} cho model {Model}, theo doi van duoc ghi.",
                request.EventCode, p.Item.Model);
        }

        // Báo VP không đụng tới theo dõi của FA / OQC
        var count = 0;
        if (!p.Escalate)
        {
            var reasonCodes = p.Reasons.Where(r => p.Departments.Contains(r.Department)).Select(r => r.Code).ToHashSet();
            var rows = p.Item.Lines
                .SelectMany(l => l.Splits
                    .Where(s => reasonCodes.Contains(s.Key) && s.Value > 0)
                    .Select(s => (l.Line.LineId, s.Key, s.Value)))
                .ToList();
            await _repo.UpsertFollowUpsAsync(rows);
            count = rows.Count;
        }

        return new SendRequestResponse(p.Recipients.Select(ToResponse).ToList(), count, mailSent);
    }

    private sealed record MailPlan(
        ItemCalc Item, List<ReasonRow> Reasons, bool Escalate,
        List<string> Departments, List<MailRecipient> Recipients);

    /// <summary>
    /// Kiểm request và tra người nhận — dùng CHUNG cho xem trước và gửi thật.
    ///
    /// Người nhận lấy từ master.email_config, KHÔNG nhận danh sách từ client.
    /// sub_code = nguyên nhân chiếm nhiều pcs nhất của bộ phận, để cấu hình theo
    /// nguyên nhân (vd NO_PLAN -> FA PPC) được ưu tiên.
    ///
    /// Gộp người nhận của nhiều bộ phận rồi Normalize LẠI một lần: một người là
    /// TO của FA và CC của OQC thì chỉ còn ở TO (trước đây nhận 2 dòng).
    /// Cuối cùng CC chính người gửi, giống phiếu bất thường.
    /// </summary>
    private async Task<MailPlan> PrepareMailAsync(string eventCode, string model, IEnumerable<string>? departments)
    {
        eventCode = (eventCode ?? "").Trim();
        if (!EventCodes.Contains(eventCode))
            throw new BusinessRuleException(_localizer["Shortage.EventInvalid", eventCode]);

        var calc = await CalculateAsync();
        var item = calc.Items.FirstOrDefault(x => x.Model == (model ?? "").Trim())
            ?? throw new NotFoundException(_localizer["Shortage.ModelNotFound", model ?? ""]);

        var escalate = eventCode == "SHORTAGE_ESCALATE";
        var allowed = escalate
            ? new HashSet<string> { "VP" }
            : calc.Reasons.Select(r => r.Department).ToHashSet();
        var depts = (departments ?? Enumerable.Empty<string>())
            .Where(d => !string.IsNullOrWhiteSpace(d))
            .Select(d => d.Trim().ToUpperInvariant()).Distinct().ToList();
        var bad = depts.Where(d => !allowed.Contains(d)).ToList();
        if (bad.Count > 0)
            throw new BusinessRuleException(_localizer["Shortage.DepartmentInvalid", string.Join(", ", bad)]);

        var all = new List<MailRecipient>();
        foreach (var d in depts)
        {
            var sub = escalate ? null : calc.Reasons
                .Where(r => r.Department == d)
                .OrderByDescending(r => item.ByReason.GetValueOrDefault(r.Code))
                .Select(r => r.Code).FirstOrDefault();
            // Tra theo MÃ cate (master.categories.code), cùng giá trị màn Cấu hình email lưu
            // và cùng cách phiếu bất thường tra — không theo chữ category của SI.
            all.AddRange(await _repo.GetRecipientsAsync(
                eventCode, d, sub, item.CategoryId?.ToString(), item.Model));
        }

        var recipients = MailRecipientList.WithActorCc(
            MailRecipientList.Normalize(all), await _repo.GetUserEmailAsync(ActorCode), Actor);

        return new MailPlan(item, calc.Reasons, escalate, depts, recipients);
    }

    private static RecipientResponse ToResponse(MailRecipient r) => new(r.Type, r.Email, r.DisplayName);

    // ═══════════════════════════════════════════════════════════════
    //  Bộ tính
    // ═══════════════════════════════════════════════════════════════

    private sealed class LineCalc
    {
        public OpenShortLine Line { get; init; } = default!;
        public Dictionary<string, int> Splits { get; } = new();   // reason / UNALLOCATED -> pcs
        public int Net => Splits.Where(s => s.Key != Unallocated).Sum(s => s.Value);
    }

    private sealed class ItemCalc
    {
        public long Id { get; init; }
        public string Model { get; init; } = "";
        public List<LineCalc> Lines { get; init; } = new();
        public Dictionary<string, FollowUpResponse> FollowUps { get; init; } = new();
        public string? Category => Lines.Select(l => l.Line.Category).FirstOrDefault(c => c is not null);
        /// <summary>Mã cate (master.categories.code) của model — giá trị lưu ở email_config.category.</summary>
        public int? CategoryId => Lines.Select(l => l.Line.CategoryId).FirstOrDefault(c => c is not null);
        public DateTime VanningDate => Lines.Min(l => l.Line.VanningDate);
        public int QtyShort => Lines.Sum(l => l.Net);
        public int QtyUnallocated => Lines.Sum(l => l.Splits.GetValueOrDefault(Unallocated));
        public Dictionary<string, int> ByReason => Lines
            .SelectMany(l => l.Splits).Where(s => s.Key != Unallocated && s.Value > 0)
            .GroupBy(s => s.Key).ToDictionary(g => g.Key, g => g.Sum(s => s.Value));
        public int DaysLeft => (VanningDate.Date - DateTime.Today).Days;

        public ShortageItemResponse ToResponse() => new(
            Id, Model, QtyShort, QtyUnallocated, Category,
            Distinct(l => l.SiNo), Lines.Select(l => l.Line.ForwarderCode).FirstOrDefault(x => x is not null),
            VanningDate, Distinct(l => l.ShipMode), Distinct(l => l.PoNo),
            Distinct(l => l.ConsigneeCode), Distinct(l => l.CountryCode),
            ByReason,
            Lines.Where(l => l.Net > 0)
                 .GroupBy(l => (l.Line.SiNo, l.Line.ShipMode, l.Line.VanningDate))
                 .Select(g => new ShortageBySiResponse(g.Key.SiNo, g.Key.ShipMode, g.Key.VanningDate, g.Sum(l => l.Net)))
                 .OrderBy(x => x.VanningDate).ToList(),
            FollowUps.Where(f => ByReason.ContainsKey(f.Key)).ToDictionary(f => f.Key, f => f.Value),
            CategoryId);

        private List<string> Distinct(Func<OpenShortLine, string?> get)
            => Lines.Select(l => get(l.Line)).Where(x => !string.IsNullOrEmpty(x)).Distinct().ToList()!;
    }

    private sealed record CalcResult(List<ItemCalc> Items, List<ReasonRow> Reasons);

    private async Task<CalcResult> CalculateAsync(int? categoryId = null)
    {
        var reasons = await _repo.GetReasonsAsync();
        var lines = await _repo.GetOpenShortLinesAsync(categoryId);
        if (lines.Count == 0) return new(new(), reasons);

        var models = lines.Select(l => l.Model).Distinct().ToList();
        var stock = await _repo.GetStockAsync(models);
        var producing = (await _repo.GetProducingAsync(models)).ToDictionary(p => p.Model, p => p.Qty);
        var followUps = await _repo.GetFollowUpsAsync(lines.Select(l => l.LineId).ToList());

        var items = new List<ItemCalc>();
        foreach (var g in lines.GroupBy(l => l.Model))
        {
            var model = g.Key;
            var st = stock.Where(s => s.Model == model).ToList();

            // Hàng đợi nguồn theo thứ tự đổ vào dòng
            var queue = new List<(string Code, int Qty)>
            {
                (Unallocated, st.Where(s => s.Bucket == "AVAILABLE").Sum(s => Math.Max(0, s.Qty - s.Reserved))),
            };
            foreach (var r in reasons)
            {
                var qty = r.Code switch
                {
                    "FA_PRODUCING" => producing.GetValueOrDefault(model),
                    "NO_PLAN" => int.MaxValue,                     // hứng phần còn lại
                    _ => st.Where(s => s.Bucket == r.Code).Sum(s => s.Qty),
                };
                queue.Add((r.Code, qty));
            }
            if (reasons.All(r => r.Code != "NO_PLAN")) queue.Add(("NO_PLAN", int.MaxValue));

            var calcLines = new List<LineCalc>();
            var qi = 0;
            var left = queue[0].Qty;
            foreach (var line in g.OrderBy(l => l.VanningDate).ThenBy(l => l.SiId).ThenBy(l => l.LineId))
            {
                var lc = new LineCalc { Line = line };
                var need = line.QtyShort;
                while (need > 0 && qi < queue.Count)
                {
                    if (left <= 0) { qi++; if (qi < queue.Count) left = queue[qi].Qty; continue; }
                    var take = Math.Min(need, left);
                    lc.Splits[queue[qi].Code] = lc.Splits.GetValueOrDefault(queue[qi].Code) + take;
                    need -= take;
                    if (left != int.MaxValue) left -= take;
                }
                calcLines.Add(lc);
            }

            // Theo dõi theo nguyên nhân: lấy lần đòi GẦN NHẤT trong các dòng của model
            var lineIds = calcLines.Select(l => l.Line.LineId).ToHashSet();
            var fu = followUps.Where(f => lineIds.Contains(f.LineId))
                .GroupBy(f => f.ReasonCode)
                .ToDictionary(x => x.Key, x =>
                {
                    var f = x.OrderByDescending(y => y.NotifiedAt).First();
                    return new FollowUpResponse(f.NotifiedAt);
                });

            items.Add(new ItemCalc
            {
                Id = calcLines.Min(l => l.Line.LineId),
                Model = model,
                Lines = calcLines,
                FollowUps = fu,
            });
        }
        return new(items, reasons);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Lọc
    // ═══════════════════════════════════════════════════════════════

    private static IEnumerable<ItemCalc> Filter(CalcResult calc, ShortageQuery q, bool applyReason)
    {
        var depByReason = calc.Reasons.ToDictionary(r => r.Code, r => r.Department);

        foreach (var src in calc.Items)
        {
            if (!Like(src.Model, q.Model)) continue;

            // Lọc theo DÒNG — sau khi đã chia nguồn
            var lines = src.Lines.Where(l =>
                   Like(l.Line.SiNo, q.SiNo)
                && Like(l.Line.PoNo, q.PoNo)
                && Like(l.Line.ConsigneeCode, q.ConsigneeCode)
                && Like(l.Line.CountryCode, q.CountryCode)
                && (q.CategoryId is null || l.Line.CategoryId == q.CategoryId)
                && Eq(l.Line.ForwarderCode, q.VanningPlace)
                && Eq(l.Line.ShipMode, q.ShipMode)
                && (q.VanningFrom is null || l.Line.VanningDate >= q.VanningFrom.Value.Date)
                && (q.VanningTo is null || l.Line.VanningDate <= q.VanningTo.Value.Date)).ToList();

            if (lines.Count == 0) continue;
            var it = new ItemCalc { Id = src.Id, Model = src.Model, Lines = lines, FollowUps = src.FollowUps };
            if (it.QtyShort <= 0) continue;              // chỉ thiếu vì chưa phân bổ -> không phải hàng thiếu

            var parts = it.ByReason;
            if (applyReason && !string.IsNullOrWhiteSpace(q.ReasonCode) && !parts.ContainsKey(q.ReasonCode)) continue;
            if (!string.IsNullOrWhiteSpace(q.Department)
                && !parts.Keys.Any(k => depByReason.GetValueOrDefault(k) == q.Department)) continue;
            if (q.MinQty is { } mq && it.QtyShort < mq) continue;

            var ok = q.Urgency switch
            {
                "overdue" => it.DaysLeft < 0,
                "d2" => it.DaysLeft is >= 0 and <= 2,
                "d7" => it.DaysLeft is >= 0 and <= 7,
                _ => true,
            };
            if (!ok) continue;

            if (!string.IsNullOrWhiteSpace(q.Stage))
            {
                var stages = parts.Keys.Select(k => StageOf(it.FollowUps.GetValueOrDefault(k))).ToList();
                if (q.Stage == "escalate")
                {
                    // Gần vanning mà có phần không kế hoạch, hoặc có nguyên nhân chưa đòi
                    var need = it.DaysLeft <= 2
                        && (parts.ContainsKey("NO_PLAN") || stages.Any(s => s == "none"));
                    if (!need) continue;
                }
                else if (stages.OrderByDescending(StageRank).FirstOrDefault() != q.Stage) continue;
            }

            yield return it;
        }
    }

    // Khớp ReasonFollowUp.Stage bên Web: none = chưa đòi, requested = đã đòi
    private static string StageOf(FollowUpResponse? f) => f is null ? "none" : "requested";

    private static int StageRank(string s) => s switch { "none" => 2, "requested" => 1, _ => 0 };

    private static bool Like(string? value, string? term)
        => string.IsNullOrWhiteSpace(term) || (value ?? "").Contains(term.Trim(), StringComparison.OrdinalIgnoreCase);

    private static bool Eq(string? value, string? term)
        => string.IsNullOrWhiteSpace(term) || string.Equals(value, term.Trim(), StringComparison.OrdinalIgnoreCase);

    private static string? Clean(string? v) => string.IsNullOrWhiteSpace(v) ? null : v.Trim();
}
