using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.MapDesigner.Business;
using Swms.FinishGoods.Web.Features.MapDesigner.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.MapDesigner;

public static class MapDesignerModule
{
    public static IServiceCollection AddMapDesignerFeature(this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<IMapDesignerApi>(api);
        services.AddScoped<IMapDesignerBusiness, MapDesignerBusiness>();
        return services;
    }
}
