import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/features/receiving/presentation/dialogs/std_pack_dialog.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// Bước 2: xác nhận model vừa quét.
///
/// Widget này là **controlled component**: toàn bộ state (mode, boxCount,
/// serials) do parent nắm giữ và truyền xuống qua constructor. Widget chỉ
/// hiển thị và bắn callback (`onBoxChange`, `onSerialRemove`) khi user thao tác.
class ReceivingConfirmGTINBody extends StatelessWidget {
  const ReceivingConfirmGTINBody({
    super.key,
    required this.modelInfo,
    required this.boxCount,
    required this.stdPack,
    required this.onBoxChange,
    required this.onStdPackChange,
    required this.onSerialRemove,
  });

  final ModelInfo modelInfo;

  /// Số hộp nhập tay (dùng khi mode != serial).
  final int boxCount;

  /// Bắn giá trị boxCount MỚI (đã clamp 0–999) khi user bấm +/-.
  final ValueChanged<int> onBoxChange;

  /// Bắn INDEX của serial cần xóa.
  final ValueChanged<int> onSerialRemove;

  final int stdPack;

  final ValueChanged<int> onStdPackChange;

  int get _qty => boxCount;

  int get _totalPcs => _qty * stdPack;

  void _adjust(int delta) =>
      onBoxChange((boxCount + delta).clamp(0, 999));

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        _ModelInfoCard(modelInfo: modelInfo),
        const SizedBox(height: AppDimens.sm),
        _buildManual(context),
        const SizedBox(height: AppDimens.sm),
        _buildSerial(context),
      ],
    );
  }

  // ── Nhập số hộp ────────────────────────────────────────────
  Widget _buildManual(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _SectionLabel('receiving.enter_box_count'.tr()),
          const SizedBox(height: 10),
          Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              _StepButton(
                icon: Icons.remove_rounded,
                tooltip: 'receiving.minus_one_box'.tr(),
                onTap: () => _adjust(-1),
              ),
              const SizedBox(width: 10),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: 16),
                child: Column(
                  children: [
                    Text(
                      '$boxCount',
                      style: AppTextStyles.code.copyWith(
                        fontSize: 28,
                        fontWeight: FontWeight.w900,
                        height: 1,
                        letterSpacing: 0,
                        color: swms.success,
                        fontFeatures: const [FontFeature.tabularFigures()],
                      ),
                    ),
                    const SizedBox(height: 2),
                    Text(
                      'receiving.box_unit'.tr(),
                      style: AppTextStyles.caption.copyWith(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: swms.text3,
                      ),
                    ),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          _FormulaBar(
            qty: boxCount,
            stdPack: stdPack,
            total: _totalPcs,
            onEditStdPack: () => _openStdPackDialog(context),
          ),
          const SizedBox(height: 9),
          const _StdPackHint(),
        ],
      ),
    );
  }

  // ── Dialog sửa standard packing ────────────────────────────
  Future<void> _openStdPackDialog(BuildContext context) async {
    final result = await showStdPackDialog(context, value: stdPack);
    if (result != null && result != stdPack) {
      onStdPackChange(result);
    }
  }

  // ── Quét serial ────────────────────────────────────────────
  Widget _buildSerial(BuildContext context) {
    return AppCard(
      padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _SectionLabel('receiving.scan_serial'.tr()),
          const SizedBox(height: AppDimens.xs),
          BarcodeScannerButton(
            scanningLabel: LocaleKeys.receiving_scan_serial_hint.tr(),
          ),
          const SizedBox(height: AppDimens.xs),
        ],
      ),
    );
  }
}

// ── Sub-widgets ──────────────────────────────────────────────

class _ModelInfoCard extends StatelessWidget {
  const _ModelInfoCard({required this.modelInfo});

  final ModelInfo modelInfo;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: const EdgeInsets.all(10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          _SectionLabel(LocaleKeys.receiving_model_info.tr()),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(
                'receiving.model_code'.tr(),
                style: AppTextStyles.caption.copyWith(color: swms.text3),
              ),
              Expanded(
                child: Text(
                  modelInfo.model,
                  style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                  textAlign: TextAlign.end,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text.toUpperCase(),
      style: AppTextStyles.caption.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: .3,
        color: context.swms.text3,
      ),
    );
  }
}

class _StepButton extends StatelessWidget {
  const _StepButton({
    required this.icon,
    required this.onTap,
    required this.tooltip,
  });

  final IconData icon;
  final VoidCallback onTap;
  final String tooltip;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Tooltip(
      message: tooltip,
      child: Semantics(
        button: true,
        label: tooltip,
        child: Material(
          color: swms.card2,
          borderRadius: BorderRadius.circular(AppDimens.rCard),
          child: InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(AppDimens.rCard),
            child: SizedBox(
              width: AppDimens.hitMd,
              height: AppDimens.hitMd,
              child: Icon(
                icon,
                size: 28,
                color: swms.text2,
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _FormulaBar extends StatelessWidget {
  const _FormulaBar({
    required this.qty,
    required this.stdPack,
    required this.total,
    required this.onEditStdPack,
  });

  final int qty;
  final int stdPack;
  final int total;
  final VoidCallback onEditStdPack;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final strong = AppTextStyles.bodyStrong.copyWith(color: swms.text1);
    final normal = AppTextStyles.body.copyWith(color: swms.text2);
    final op = AppTextStyles.bodyStrong.copyWith(
      color: swms.text4,
      fontWeight: FontWeight.w800,
    );

    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 10),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
      ),
      child: Wrap(
        alignment: WrapAlignment.center,
        crossAxisAlignment: WrapCrossAlignment.center,
        spacing: AppDimens.sm,
        runSpacing: AppDimens.xs,
        children: [
          Text.rich(
            TextSpan(
              children: [
                TextSpan(text: '$qty', style: strong),
                TextSpan(text: ' ${'receiving.box_unit'.tr()}', style: normal),
              ],
            ),
          ),
          Text('×', style: op),
          // std pack có thể sửa → bấm mở dialog
          Semantics(
            button: true,
            label: 'receiving.edit_std_pack'.tr(),
            child: Material(
              color: Colors.transparent,
              borderRadius: BorderRadius.circular(AppDimens.rInput),
              child: InkWell(
                onTap: onEditStdPack,
                borderRadius: BorderRadius.circular(AppDimens.rInput),
                child: Padding(
                  padding:
                  const EdgeInsets.symmetric(vertical: 2, horizontal: 6),
                  child: Row(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      Text.rich(
                        TextSpan(
                          children: [
                            TextSpan(text: '$stdPack', style: strong),
                            TextSpan(
                              text: ' ${'receiving.pcs_per_box'.tr()}',
                              style: normal,
                            ),
                          ],
                        ),
                      ),
                      const SizedBox(width: 4),
                      Icon(
                        Icons.edit_rounded,
                        size: 14,
                        color: swms.primary,
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ),
          Text('=', style: op),
          Text(
            '$total ${'receiving.pcs_unit'.tr()}',
            style: AppTextStyles.bodyStrong.copyWith(
              fontWeight: FontWeight.w900,
              color: swms.success,
            ),
          ),
        ],
      ),
    );
  }
}

class _StdPackHint extends StatelessWidget {
  const _StdPackHint();

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 1),
          child: Icon(
            Icons.info_outline_rounded,
            size: 12,
            color: swms.primary,
          ),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            'receiving.std_pack_hint'.tr(),
            style: AppTextStyles.caption.copyWith(
              fontSize: 10.5,
              height: 1.4,
              color: swms.text3,
            ),
          ),
        ),
      ],
    );
  }
}