import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';

part 'container_model.g.dart';

@JsonSerializable(fieldRename: FieldRename.snake)
class ContainerModel {
  final int id;
  final String containerNo;
  final String sealNo;
  final String siCode;
  final String type;
  final String? lot;

  /// 'verify' | 'loading' | 'done'
  final String status;

  const ContainerModel({
    required this.id,
    required this.containerNo,
    required this.sealNo,
    required this.siCode,
    required this.type,
    this.lot,
    required this.status,
  });

  factory ContainerModel.fromJson(Map<String, dynamic> json) =>
      _$ContainerModelFromJson(json);

  Map<String, dynamic> toJson() => _$ContainerModelToJson(this);

  ContainerItem toEntity() => ContainerItem(
    id: id,
    containerNo: containerNo,
    sealNo: sealNo,
    siCode: siCode,
    type: type,
    lot: LotColor.fromCode(lot),
    status: ContainerStatus.fromCode(status),
  );
}

/// Body POST kết quả kiểm. Ảnh gửi multipart riêng, field theo slot code.
@JsonSerializable(fieldRename: FieldRename.snake)
class ContainerInspectionRequest {
  final String result;
  final List<String> passedConditions;
  final String? note;

  const ContainerInspectionRequest({
    required this.result,
    required this.passedConditions,
    this.note,
  });

  factory ContainerInspectionRequest.fromEntity(ContainerInspection i) =>
      ContainerInspectionRequest(
        result: i.result.code,
        passedConditions: i.passedConditions.map((c) => c.code).toList(),
        note: i.note,
      );

  factory ContainerInspectionRequest.fromJson(Map<String, dynamic> json) =>
      _$ContainerInspectionRequestFromJson(json);

  Map<String, dynamic> toJson() => _$ContainerInspectionRequestToJson(this);
}
