import 'package:dio/dio.dart';
import 'package:swms_finish_goods/core/utils/app_local_storage.dart';

class LocaleInterceptor extends Interceptor {
  final AppLocalStorage _storage;

  static const _kLanguage = 'settings.language';

  LocaleInterceptor(this._storage);

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    final lang = _storage.readString(_kLanguage) ?? 'vi';
    options.headers['Accept-Language'] = lang;
    handler.next(options);
  }
}
