﻿using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.Auth.Business;

// Yêu cầu cấp key mới cho một hệ thống ngoài.
public record CreateApiKeyRequest(
    [Required] string ClientName,           // 'QMS', 'SAP_PROD', 'HRM'
    List<string> Permissions,               // ['o_q_c.sample', 'o_q_c.return']
    DateTime? ExpiresAt);                    // null = không hết hạn; nếu có phải là mốc tương lai (UTC)

// Trả về khi CẤP hoặc ROTATE. FullKey chỉ xuất hiện MỘT lần ở đây.
public record ApiKeyIssuedResponse(
    long Id,
    string ClientName,
    string FullKey,                          // đưa cho hệ thống ngoài lưu, không lấy lại được
    string KeyPrefix,
    IReadOnlyList<string> Permissions,
    DateTime? ExpiresAt);

// Thông tin key để liệt kê (KHÔNG chứa key gốc).
public record ApiKeyInfo(
    long Id,
    string ClientName,
    string KeyPrefix,
    IReadOnlyList<string> Permissions,
    bool IsActive,
    DateTime? ExpiresAt,
    DateTime CreatedAt,
    DateTime? LastUsedAt,
    DateTime? RevokedAt);