﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class frmConfirm : Form
    {
        string Model, Serial, Pallet;
        WebService objService = new WebService();

        String ShrinkBy;
        public frmConfirm(string Model, string Serial, string Pallet, string ShrinkBy)
        {
            InitializeComponent();
            txtModel.Text = Model;
            txtSerial.Text = Serial;
            txtPallet.Text = Pallet;
            this.ShrinkBy = ShrinkBy;

        }
        private void btnCancel_Click(object sender, EventArgs e)
        {
            frmShrink objShrink = (frmShrink)Application.OpenForms["frmShrink"];
            objShrink.STATUS = "";
            Close();
        }

        private void frmConfirm_Load(object sender, EventArgs e)
        {
            KeyPreview = true;
        }

        private void btnYes_Click(object sender, EventArgs e)
        {
            if (txtOK.Text.ToUpper() == "OK")
            {
                int a = objService.tblPalletCombine_Insert2(txtModel.Text, txtSerial.Text, txtPallet.Text.Trim(), ShrinkBy.Trim());
                if (a > 0)
                {
                    frmShrink objShrink = (frmShrink)Application.OpenForms["frmShrink"];
                    objShrink.STATUS = "OK";
                    Close();
                }
            }
            else
            {
                txtOK.Focus();
            }

        }

        private void txtOK_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                btnYes_Click(sender, e);
            }
        }
    }
}
