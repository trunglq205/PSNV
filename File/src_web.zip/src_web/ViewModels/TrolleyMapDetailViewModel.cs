﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Layout;

namespace SWMS_WebTool.ViewModels
{
    public class TrolleyMapDetailViewModel : TableViewModel<TrolleyKitting, TrolleyMapFilter>
    {
        public Floor Floor;

        public List<TrolleyKitting> TrolleyFiltered;

        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, TrolleyMapFilter? filter = null)
        {
            return new
            {
                Modal = filter?.Modal.ToUpper() ?? Filter.Modal,
                Line = filter?.Line.ToUpper() ?? Filter.Line,
                Date = filter?.Date ?? Filter.Date,
                Time = filter?.Time.ToUpper() ?? Filter.Time,
                Material = filter?.Material.ToUpper() ?? Filter.Material,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
