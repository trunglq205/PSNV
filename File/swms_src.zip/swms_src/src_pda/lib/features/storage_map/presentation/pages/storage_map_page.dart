import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/features/storage_map/domain/entities/storage_map_entities.dart';
import 'package:swms_finish_goods/features/storage_map/presentation/providers/storage_map_providers.dart';
import 'package:swms_finish_goods/features/storage_map/presentation/widgets/rack_elevation_sheet.dart';
import 'package:swms_finish_goods/features/storage_map/presentation/widgets/status_colors.dart';

/// Xem bản đồ Storage (chỉ xem) — công nhân xem trước vị trí có hàng không / trạng thái.
@RoutePage()
class StorageMapPage extends ConsumerStatefulWidget {
  /// Mã vị trí cần chỉ trên bản đồ (mở từ gợi ý ở màn Lưu kho). Null = mở bình thường.
  final String? locator;

  const StorageMapPage({super.key, @QueryParam('locator') this.locator});

  /// px mỗi ô lưới ở scale 1.0 (InteractiveViewer cho phóng to/thu nhỏ thêm).
  static const double _cell = 7.0;

  @override
  ConsumerState<StorageMapPage> createState() => _StorageMapPageState();
}

class _StorageMapPageState extends ConsumerState<StorageMapPage> {
  /// Vị trí đang được chỉ ra trên bản đồ.
  LocatorLocation? _focus;

  /// Tăng lên mỗi lần bấm "căn lại" để khung xem quay về vị trí đích.
  int _recenter = 0;

  @override
  void initState() {
    super.initState();
    final code = widget.locator?.trim();
    if (code != null && code.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _resolveFocus(code));
    }
  }

  /// Tra vị trí -> đổi dropdown sang đúng bản đồ -> khung xem sẽ tự căn giữa khi tải xong.
  Future<void> _resolveFocus(String code) async {
    try {
      final loc = await ref.read(storageMapRepositoryProvider).locate(code);
      final areas = await ref.read(storageAreasProvider.future);
      if (!mounted) return;

      final onStorageMap = loc.areaCode != null && areas.any((a) => a.areaCode == loc.areaCode);
      if (!onStorageMap) {
        _toast(LocaleKeys.storage_map_focus_not_storing.tr(args: [code]));
        return;
      }
      ref.read(selectedStorageAreaProvider.notifier).select(loc.areaCode);
      setState(() => _focus = loc);
    } catch (_) {
      if (mounted) _toast(LocaleKeys.storage_map_focus_not_found.tr(args: [code]));
    }
  }

  void _toast(String msg) =>
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(storageTopMapProvider);
    final areas = ref.watch(storageAreasProvider);
    // Mã khu thực tế đang hiển thị (đã tính cả trường hợp chưa chọn).
    final effective = ref.watch(effectiveStorageAreaProvider).value;

    return Scaffold(
      appBar: AppBar(
        title: Text(LocaleKeys.storage_map_title.tr()),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => ref.invalidate(storageTopMapProvider),
          ),
        ],
      ),
      body: Column(
        children: [
          // Chọn bản đồ — chỉ hiện khi có nhiều hơn 1 kho lưu trữ.
          areas.maybeWhen(
            data: (list) => list.length <= 1
                ? const SizedBox.shrink()
                : _AreaPicker(
                    areas: list,
                    selected: effective ?? list.first.areaCode,
                    onChanged: (code) {
                      ref.read(selectedStorageAreaProvider.notifier).select(code);
                    },
                  ),
            orElse: () => const SizedBox.shrink(),
          ),
          if (_focus != null)
            _FocusBanner(
              focus: _focus!,
              onRecenter: () {
                // Người dùng đã đổi sang bản đồ khác thì quay về bản đồ của vị trí đích.
                if (effective != _focus!.areaCode) {
                  ref.read(selectedStorageAreaProvider.notifier).select(_focus!.areaCode);
                }
                setState(() => _recenter++);
              },
              onClose: () => setState(() => _focus = null),
            ),
          Expanded(
            child: async.when(
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, _) => _ErrorView(
                message: '$e',
                onRetry: () => ref.invalidate(storageTopMapProvider),
              ),
              data: (map) => _TopMapView(
                map: map,
                cell: StorageMapPage._cell,
                focus: _focus,
                recenter: _recenter,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Dải thông tin vị trí đang chỉ: mã ô + bản đồ, nút căn lại và nút tắt.
class _FocusBanner extends StatelessWidget {
  final LocatorLocation focus;
  final VoidCallback onRecenter;
  final VoidCallback onClose;
  const _FocusBanner({required this.focus, required this.onRecenter, required this.onClose});

  @override
  Widget build(BuildContext context) {
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 4),
      padding: const EdgeInsets.fromLTRB(12, 4, 4, 4),
      decoration: BoxDecoration(
        color: const Color(0xFFFDE8F3),
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: const Color(0xFFF4A6CF)),
      ),
      child: Row(
        children: [
          const Icon(Icons.place, size: 18, color: _focusColor),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              LocaleKeys.storage_map_focus_label.tr(args: [focus.locatorCode]),
              style: const TextStyle(fontWeight: FontWeight.w700, color: Color(0xFF9C0055)),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            tooltip: LocaleKeys.storage_map_focus_recenter.tr(),
            icon: const Icon(Icons.center_focus_strong, color: _focusColor),
            onPressed: onRecenter,
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            icon: const Icon(Icons.close, size: 18, color: Color(0xFF5A6B7D)),
            onPressed: onClose,
          ),
        ],
      ),
    );
  }
}

/// Màu chỉ vị trí đích: hồng cánh sen — không trùng màu nào đang có trên sơ đồ
/// (xanh dương = độ đầy kệ; vàng/cam/xanh/chàm/xanh lá/đỏ = trạng thái kiểm; nâu = khối chức năng).
const Color _focusColor = Color(0xFFE6007E);

/// Mở mặt cắt kệ; [focusLocator] = ô cần chọn sẵn và đánh dấu.
void _openRackSheet(BuildContext context, String rackCode, {String? focusLocator}) {
  showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    builder: (_) => RackElevationSheet(rackCode: rackCode, focusLocatorCode: focusLocator),
  );
}

/// Dropdown chọn bản đồ kho lưu trữ.
class _AreaPicker extends StatelessWidget {
  final List<WarehouseArea> areas;
  final String selected;
  final ValueChanged<String> onChanged;

  const _AreaPicker({
    required this.areas,
    required this.selected,
    required this.onChanged,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(bottom: BorderSide(color: Color(0xFFE4E9EF))),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          isExpanded: true,
          value: areas.any((a) => a.areaCode == selected)
              ? selected
              : areas.first.areaCode,
          items: areas
              .map((a) => DropdownMenuItem(
                    value: a.areaCode,
                    child: Text(
                      a.areaName,
                      style: const TextStyle(
                          fontSize: 15, fontWeight: FontWeight.w600),
                    ),
                  ))
              .toList(),
          onChanged: (v) { if (v != null) onChanged(v); },
        ),
      ),
    );
  }
}

class _TopMapView extends StatefulWidget {
  final StorageTopMap map;
  final double cell;
  final LocatorLocation? focus;
  final int recenter;
  const _TopMapView({
    required this.map,
    required this.cell,
    this.focus,
    this.recenter = 0,
  });

  @override
  State<_TopMapView> createState() => _TopMapViewState();
}

class _TopMapViewState extends State<_TopMapView> {
  final _tc = TransformationController();
  Size _viewport = Size.zero;

  /// Đã căn giữa + mở mặt cắt cho vị trí này chưa (tránh làm lại mỗi lần rebuild).
  String? _doneFor;
  int _lastRecenter = 0;

  static const double _focusScale = 1.8;

  @override
  void dispose() {
    _tc.dispose();
    super.dispose();
  }

  /// Khối chứa vị trí đích trên bản đồ đang hiển thị (null nếu đang xem bản đồ khác).
  TopMapBlock? _target() {
    final f = widget.focus;
    if (f == null) return null;
    for (final b in widget.map.blocks) {
      final hit = f.inRack
          ? b.isRack && b.rackCode == f.rackCode
          : b.isPallet && b.locatorCode == f.locatorCode;
      if (hit) return b;
    }
    return null;
  }

  /// Vùng cần đánh dấu: với kệ là đúng ngăn vị trí trong kệ, với ô sàn là cả ô.
  Rect _targetRect(TopMapBlock b) {
    final c = widget.cell;
    final r = Rect.fromLTWH(b.gridX * c, b.gridY * c, b.gridW * c, b.gridH * c);
    final f = widget.focus!;
    final n = b.positions.length;
    if (!f.inRack || n == 0 || f.rackCol == null) return r;

    // Khớp cách _RackBlock vẽ: danh sách vị trí đảo ngược, vị trí cuối nằm ở đầu.
    final idx = b.positions.reversed.toList().indexWhere((p) => p.position == f.rackCol);
    if (idx < 0) return r;
    return b.gridH >= b.gridW
        ? Rect.fromLTWH(r.left, r.top + r.height * idx / n, r.width, r.height / n)
        : Rect.fromLTWH(r.left + r.width * idx / n, r.top, r.width / n, r.height);
  }

  /// Phóng to và đưa vùng đích vào giữa khung xem.
  void _centerOn(Rect rect) {
    if (_viewport.isEmpty) return;
    const s = _focusScale;
    final tx = _viewport.width / 2 - rect.center.dx * s;
    final ty = _viewport.height / 2 - rect.center.dy * s;
    _tc.value = Matrix4.identity()
      ..setEntry(0, 0, s)
      ..setEntry(1, 1, s)
      ..setEntry(0, 3, tx)
      ..setEntry(1, 3, ty);
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.map.cols * widget.cell;
    final h = widget.map.rows * widget.cell;
    final target = _target();
    final targetRect = target == null ? null : _targetRect(target);

    if (target != null && targetRect != null) {
      final f = widget.focus!;
      final key = '${f.areaCode}|${f.locatorCode}';
      if (key != _doneFor) {
        // Lần đầu thấy vị trí đích trên bản đồ: chỉ căn giữa và nhấp nháy.
        // Mặt cắt kệ chỉ mở khi người dùng bấm vào kệ (khi đó ô đích được chọn sẵn).
        _doneFor = key;
        _lastRecenter = widget.recenter;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _centerOn(targetRect);
        });
      } else if (widget.recenter != _lastRecenter) {
        _lastRecenter = widget.recenter;
        WidgetsBinding.instance.addPostFrameCallback((_) {
          if (mounted) _centerOn(targetRect);
        });
      }
    }

    return Column(
      children: [
        _Legend(
          hasRack: widget.map.blocks.any((b) => b.isRack),
          hasPallet: widget.map.blocks.any((b) => b.isPallet),
        ),
        Expanded(
          child: LayoutBuilder(
            builder: (_, constraints) {
              _viewport = constraints.biggest;
              return InteractiveViewer(
                transformationController: _tc,
                constrained: false,
                minScale: 0.4,
                maxScale: 3.0,
                boundaryMargin: const EdgeInsets.all(80),
                child: SizedBox(
                  width: w,
                  height: h,
                  child: Stack(
                    children: [
                      // Stack vẽ theo thứ tự: khối chức năng nằm dưới, kệ ở giữa,
                      // ô pallet trên cùng — trùng thứ bậc hiển thị của bản đồ web.
                      for (final b in _ordered(widget.map.blocks))
                        Positioned(
                          left: b.gridX * widget.cell,
                          top: b.gridY * widget.cell,
                          width: b.gridW * widget.cell,
                          height: b.gridH * widget.cell,
                          child: b.isRack
                              ? _RackBlock(
                                  block: b,
                                  cell: widget.cell,
                                  focusLocator: b == target ? widget.focus!.locatorCode : null,
                                )
                              : b.isPallet
                                  ? _PalletBlock(block: b)
                                  : _DecorBlock(block: b),
                        ),
                      // Viền cả kệ chứa vị trí đích — nằm hoàn toàn phía ngoài kệ,
                      // ruột trong suốt nên các ngăn và màu độ đầy vẫn giữ nguyên.
                      if (target != null && target.isRack)
                        Positioned(
                          left: target.gridX * widget.cell - 3.5,
                          top: target.gridY * widget.cell - 3.5,
                          width: target.gridW * widget.cell + 7,
                          height: target.gridH * widget.cell + 7,
                          child: const IgnorePointer(
                            child: _Outline(inner: 2, outer: 1.5),
                          ),
                        ),
                      // Vòng nhấp nháy đúng vị trí đích
                      if (targetRect != null)
                        Positioned.fromRect(
                          rect: targetRect.inflate(1.5),
                          child: const IgnorePointer(child: _FocusRing()),
                        ),
                    ],
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

/// Viền 2 lớp: trắng phía ngoài (tách khỏi nền xanh của kệ) + hồng phía trong.
/// Chỉ vẽ nét viền — KHÔNG dùng BoxShadow vì Flutter tô đặc cả hình dưới shadow,
/// làm che mất các ngăn và màu bên dưới.
class _Outline extends StatelessWidget {
  final double inner;
  final double outer;
  final Color? fill;
  const _Outline({required this.inner, required this.outer, this.fill});

  @override
  Widget build(BuildContext context) {
    return DecoratedBox(
      decoration: BoxDecoration(
        border: Border.all(color: Colors.white, width: outer),
        borderRadius: BorderRadius.circular(3),
      ),
      child: Padding(
        padding: EdgeInsets.all(outer),
        child: DecoratedBox(
          decoration: BoxDecoration(
            color: fill,
            border: Border.all(color: _focusColor, width: inner),
            borderRadius: BorderRadius.circular(2),
          ),
        ),
      ),
    );
  }
}

/// Vòng nhấp nháy đánh dấu vị trí đích.
class _FocusRing extends StatefulWidget {
  const _FocusRing();

  @override
  State<_FocusRing> createState() => _FocusRingState();
}

class _FocusRingState extends State<_FocusRing> with SingleTickerProviderStateMixin {
  late final AnimationController _ac = AnimationController(
    vsync: this,
    duration: const Duration(milliseconds: 800),
  )..repeat(reverse: true);

  @override
  void dispose() {
    _ac.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _ac,
      // Chỉ tô trong phạm vi đúng ngăn đích; nhịp nhạt -> đậm để vẫn thấy màu gốc của ngăn.
      builder: (_, _) => _Outline(
        inner: 1.5 + 1.5 * _ac.value,
        outer: 1,
        fill: _focusColor.withValues(alpha: 0.12 + 0.43 * _ac.value),
      ),
    );
  }
}

/// Kệ: chia theo vị trí (đảo để vị trí cuối ở đầu như bản vẽ), tô theo độ chứa. Chạm → mặt cắt.
class _RackBlock extends StatelessWidget {
  final TopMapBlock block;
  final double cell;

  /// Có giá trị khi kệ này chứa vị trí đích: mở mặt cắt sẽ chọn sẵn ô đó.
  final String? focusLocator;
  const _RackBlock({required this.block, required this.cell, this.focusLocator});

  @override
  Widget build(BuildContext context) {
    final vertical = block.gridH >= block.gridW;
    final positions = block.positions.reversed.toList();
    return GestureDetector(
      onTap: () {
        final code = block.rackCode;
        if (code != null) _openRackSheet(context, code, focusLocator: focusLocator);
      },
      child: Container(
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFF7A8899)),
          color: Colors.white,
        ),
        child: Column(
          children: [
            Expanded(
              child: positions.isEmpty
                  ? Container(color: _fillFor(block.ratio))
                  : Flex(
                      direction: vertical ? Axis.vertical : Axis.horizontal,
                      children: [
                        for (int i = 0; i < positions.length; i++)
                          Expanded(
                            child: Container(
                              decoration: BoxDecoration(
                                color: _fillFor(positions[i].ratio),
                                border: Border(
                                  bottom: (vertical && i < positions.length - 1)
                                      ? const BorderSide(
                                          color: Color(0xFFAEBAC6), width: .5)
                                      : BorderSide.none,
                                  right: (!vertical && i < positions.length - 1)
                                      ? const BorderSide(
                                          color: Color(0xFFAEBAC6), width: .5)
                                      : BorderSide.none,
                                ),
                              ),
                            ),
                          ),
                      ],
                    ),
            ),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 1),
              color: const Color(0xFFEDF1F5),
              child: Text(
                block.rackCode ?? '',
                textAlign: TextAlign.center,
                style: const TextStyle(fontSize: 8, fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _DecorBlock extends StatelessWidget {
  final TopMapBlock block;
  const _DecorBlock({required this.block});

  @override
  Widget build(BuildContext context) {
    Color bg = const Color(0xFFEAD9B8);
    final c = block.color;
    if (c != null && c.startsWith('#') && (c.length == 7)) {
      bg = Color(int.parse('FF${c.substring(1)}', radix: 16));
    }
    return Container(
      decoration: BoxDecoration(
        color: bg,
        border: Border.all(color: const Color(0xFFC9B896)),
      ),
      alignment: Alignment.center,
      child: Padding(
        padding: const EdgeInsets.all(2),
        child: Text(
          block.label ?? '',
          textAlign: TextAlign.center,
          maxLines: 3,
          overflow: TextOverflow.ellipsis,
          style: const TextStyle(fontSize: 8, color: Color(0xFF6B5B37)),
        ),
      ),
    );
  }
}

/// Khối chức năng -> kệ -> ô pallet (vẽ sau nằm trên).
List<TopMapBlock> _ordered(List<TopMapBlock> blocks) {
  int rank(TopMapBlock b) => b.isPallet ? 2 : (b.isRack ? 1 : 0);
  return [...blocks]..sort((a, b) => rank(a).compareTo(rank(b)));
}

/// Nhãn trạng thái; trống/không rõ thì hiện "Trống".
String _statusLabel(String? status) {
  const known = {
    'not_inspected', 'under_inspection', 'pending_result',
    'inspection_exempt', 'pass', 'ng',
  };
  if (status != null && known.contains(status)) {
    return 'inspection_status.$status'.tr();
  }
  return LocaleKeys.storage_map_empty.tr();
}

/// Ô pallet đặt trên sàn: tô theo trạng thái kiểm, viền đỏ nếu khẩn. Chạm -> chi tiết.
class _PalletBlock extends StatelessWidget {
  final TopMapBlock block;
  const _PalletBlock({required this.block});

  @override
  Widget build(BuildContext context) {
    final c = statusColors(block.hasStock ? block.status : null);
    return GestureDetector(
      onTap: () => showModalBottomSheet<void>(
        context: context,
        backgroundColor: Colors.transparent,
        builder: (_) => _PalletDetailSheet(block: block),
      ),
      child: Container(
        decoration: BoxDecoration(
          color: c.bg,
          borderRadius: BorderRadius.circular(3),
          border: Border.all(
            // Viền hàng xuất khẩn: xanh nước biển, đúng map Receiving (--st-urgent-frame)
            color: block.isUrgent ? kUrgentFrame : c.border,
            width: block.isUrgent ? 2 : 1.2,
          ),
        ),
        alignment: Alignment.center,
        padding: const EdgeInsets.all(1),
        child: Text(
          block.locatorCode ?? '',
          textAlign: TextAlign.center,
          maxLines: 2,
          overflow: TextOverflow.ellipsis,
          style: TextStyle(fontSize: 8, fontWeight: FontWeight.w700, color: c.fg),
        ),
      ),
    );
  }
}

/// Bảng chi tiết ô pallet: trạng thái + thông tin hàng đang để.
class _PalletDetailSheet extends StatelessWidget {
  final TopMapBlock block;
  const _PalletDetailSheet({required this.block});

  @override
  Widget build(BuildContext context) {
    final c = statusColors(block.hasStock ? block.status : null);
    final month = block.productionDate == null
        ? '—'
        : '${block.productionDate!.month.toString().padLeft(2, '0')}/${block.productionDate!.year}';

    Widget row(String k, String v, {bool mono = false}) => Padding(
          padding: const EdgeInsets.symmetric(vertical: 7),
          child: Row(children: [
            Expanded(
              child: Text(k, style: const TextStyle(fontSize: 13, color: Color(0xFF6B7C8E))),
            ),
            Text(v,
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.w700,
                  fontFamily: mono ? 'monospace' : null,
                )),
          ]),
        );

    return Container(
      decoration: const BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.vertical(top: Radius.circular(16)),
      ),
      padding: const EdgeInsets.fromLTRB(20, 12, 20, 24),
      child: SafeArea(
        top: false,
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40, height: 4,
                decoration: BoxDecoration(
                  color: const Color(0xFFDDE4EC),
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
            ),
            const SizedBox(height: 14),
            Text(block.locatorCode ?? '',
                style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800)),
            const SizedBox(height: 10),
            Wrap(spacing: 8, children: [
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
                decoration: BoxDecoration(
                  color: c.bg,
                  border: Border.all(color: c.border, width: 1.5),
                  borderRadius: BorderRadius.circular(999),
                ),
                child: Text(_statusLabel(block.hasStock ? block.status : null),
                    style: TextStyle(fontSize: 13, fontWeight: FontWeight.w700, color: c.fg)),
              ),
              if (block.isUrgent)
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                  decoration: BoxDecoration(
                    // Nhãn xuất khẩn: cùng màu viền khẩn của map Receiving
                    color: kUrgentFrame,
                    borderRadius: BorderRadius.circular(999),
                  ),
                  child: Text(LocaleKeys.storage_map_urgent.tr(),
                      style: const TextStyle(
                          fontSize: 12, fontWeight: FontWeight.w800, color: Colors.white)),
                ),
            ]),
            const SizedBox(height: 14),
            if (!block.hasStock)
              Container(
                width: double.infinity,
                padding: const EdgeInsets.all(20),
                decoration: BoxDecoration(
                  color: const Color(0xFFF7F9FB),
                  borderRadius: BorderRadius.circular(10),
                ),
                child: Text(LocaleKeys.storage_map_no_pallet.tr(),
                    textAlign: TextAlign.center,
                    style: const TextStyle(color: Color(0xFF93A1B1))),
              )
            else ...[
              Text(LocaleKeys.storage_map_current_pallet.tr(),
                  style: const TextStyle(
                      fontSize: 11, fontWeight: FontWeight.w800,
                      color: Color(0xFF6B7C8E), letterSpacing: .4)),
              const Divider(height: 12),
              row(LocaleKeys.storage_map_model.tr(), block.model ?? '—'),
              row(LocaleKeys.storage_map_qty.tr(), block.boxCount?.toString() ?? '—'),
              row(LocaleKeys.storage_map_pallet_id.tr(), block.palletId ?? '—', mono: true),
              row(LocaleKeys.storage_map_prod_month.tr(), month),
            ],
          ],
        ),
      ),
    );
  }
}

Color _fillFor(double ratio) {
  if (ratio <= 0.001) return const Color(0xFFEAF7EF);
  if (ratio < 0.5) return const Color(0xFFCDE8F5);
  if (ratio < 1.0) return const Color(0xFF8CC6E6);
  return const Color(0xFF3E9AD1);
}

class _Legend extends StatelessWidget {
  final bool hasRack;
  final bool hasPallet;
  const _Legend({required this.hasRack, required this.hasPallet});

  @override
  Widget build(BuildContext context) {
    Widget item(Color c, String t, {Color? border}) => Padding(
          padding: const EdgeInsets.symmetric(horizontal: 5),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Container(
              width: 12, height: 12,
              decoration: BoxDecoration(
                color: c,
                borderRadius: BorderRadius.circular(2),
                border: border == null ? null : Border.all(color: border, width: 1.2),
              ),
            ),
            const SizedBox(width: 4),
            Text(t, style: const TextStyle(fontSize: 11)),
          ]),
        );

    Widget group(String title, List<Widget> items) => Container(
          margin: const EdgeInsets.only(right: 8),
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          decoration: BoxDecoration(
            color: const Color(0xFFF4F6F9),
            borderRadius: BorderRadius.circular(6),
          ),
          child: Row(mainAxisSize: MainAxisSize.min, children: [
            Text(title,
                style: const TextStyle(
                    fontSize: 10, fontWeight: FontWeight.w800, color: Color(0xFF5A6B7D))),
            const SizedBox(width: 4),
            ...items,
          ]),
        );

    Widget status(String key) {
      final c = statusColors(key);
      return item(c.bg, _statusLabel(key), border: c.border);
    }

    return SingleChildScrollView(
      scrollDirection: Axis.horizontal,
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(children: [
        if (hasRack)
          group(LocaleKeys.storage_map_rack_word.tr(), [
            item(const Color(0xFFEAF7EF), LocaleKeys.storage_map_empty.tr()),
            item(const Color(0xFF8CC6E6), '< 100%'),
            item(const Color(0xFF3E9AD1), '100%'),
          ]),
        if (hasPallet)
          group(LocaleKeys.storage_map_pallet_word.tr(), [
            status('empty'),
            status('not_inspected'),
            status('under_inspection'),
            status('pending_result'),
            status('inspection_exempt'),
            status('pass'),
            status('ng'),
          ]),
        item(const Color(0xFFEAD9B8), LocaleKeys.storage_map_zone.tr()),
      ]),
    );
  }
}

class _ErrorView extends StatelessWidget {
  final String message;
  final VoidCallback onRetry;
  const _ErrorView({required this.message, required this.onRetry});
  @override
  Widget build(BuildContext context) => Center(
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          const Icon(Icons.error_outline, size: 40, color: Colors.redAccent),
          const SizedBox(height: 8),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 24),
            child: Text(message, textAlign: TextAlign.center),
          ),
          const SizedBox(height: 12),
          FilledButton(onPressed: onRetry, child: Text(LocaleKeys.storage_map_retry.tr())),
        ]),
      );
}
