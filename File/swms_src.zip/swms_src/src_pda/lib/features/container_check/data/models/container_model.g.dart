// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'container_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ContainerModel _$ContainerModelFromJson(Map<String, dynamic> json) =>
    ContainerModel(
      id: (json['id'] as num).toInt(),
      containerNo: json['container_no'] as String,
      sealNo: json['seal_no'] as String,
      siCode: json['si_code'] as String,
      type: json['type'] as String,
      lot: json['lot'] as String?,
      status: json['status'] as String,
    );

Map<String, dynamic> _$ContainerModelToJson(ContainerModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'container_no': instance.containerNo,
      'seal_no': instance.sealNo,
      'si_code': instance.siCode,
      'type': instance.type,
      'lot': ?instance.lot,
      'status': instance.status,
    };

ContainerInspectionRequest _$ContainerInspectionRequestFromJson(
  Map<String, dynamic> json,
) => ContainerInspectionRequest(
  result: json['result'] as String,
  passedConditions: (json['passed_conditions'] as List<dynamic>)
      .map((e) => e as String)
      .toList(),
  note: json['note'] as String?,
);

Map<String, dynamic> _$ContainerInspectionRequestToJson(
  ContainerInspectionRequest instance,
) => <String, dynamic>{
  'result': instance.result,
  'passed_conditions': instance.passedConditions,
  'note': ?instance.note,
};
