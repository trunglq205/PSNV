import 'package:swms_finish_goods/features/model/data/model_detail_model.dart';
import 'package:swms_finish_goods/features/model/data/model_detail_remote_data_source.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_repository.dart';

class ModelDetailRepositoryImpl implements ModelDetailRepository {
  final ModelDetailRemoteDataSource _remote;
  const ModelDetailRepositoryImpl(this._remote);

  @override
  Future<ModelDetail> getDetail(int id) async {
    final res = await _remote.fetchModelDetail(id);
    return res.toEntity();
  }

  @override
  Future<ModelDetail> update(int id, ModelEdit edit) async {
    await _remote.updateModel(id, ModelUpdateRequest.fromEdit(edit));
    // PUT trả 204 -> đọc lại để lấy các số server tính (thùng/pallet, kiện...).
    final res = await _remote.fetchModelDetail(id);
    return res.toEntity();
  }

  @override
  Future<ModelDetail> updateSuggestion({
    required int id,
    required int? suggestAreaId,
    required List<int> suggestRackRow,
  }) async {
    // Chuẩn hoá giống RackRowRule.ToStorage: distinct + tăng dần, rỗng => null.
    final rows = suggestRackRow.toSet().toList()..sort();
    final res = await _remote.patchSuggestion(
      id,
      ModelSuggestionPatchRequest(
        suggestAreaId: suggestAreaId,
        suggestRackRow: rows.isEmpty ? null : rows,
      ),
    );
    return res.toEntity();
  }
}