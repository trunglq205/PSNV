using Microsoft.Extensions.Localization;
using Microsoft.IdentityModel.Tokens;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.Models;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;

namespace Swms.FinishGoods.API.Features.Auth;

public class AuthService : IAuthService
{
    private readonly IUserRepository _repo;
    private readonly IPasswordHasher _hasher;
    private readonly JwtOptions _jwt;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public AuthService(IUserRepository repo, IPasswordHasher hasher, JwtOptions jwt, IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _hasher = hasher;
        _jwt = jwt;
        _localizer = localizer;
    }

    public async Task<LoginResponse> LoginAsync(LoginRequest request)
    {
        var user = await _repo.GetByEmployeeCodeAsync(request.Username.Trim());

        if (user?.IsActive == false) 
            throw new UnauthorizedException(_localizer["Login.AccountLocked"]);

        if (user is null) 
            throw new UnauthorizedException(_localizer["Login.AccountNotExist"]);

        if (!_hasher.Verify(request.Password, user.PasswordHash)) 
            throw new UnauthorizedException(_localizer["Login.LoginFailed"]); ;
        
        await _repo.UpdateLastLoginAsync(user.Id, DateTime.UtcNow);

        var expires = DateTime.UtcNow.AddMinutes(_jwt.ExpiryMinutes);
        var token = BuildToken(user, expires);

        return new LoginResponse(token, expires, user.EmployeeCode, user.FullName);
    }

    private string BuildToken(User user, DateTime expires)
    {
        var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_jwt.Secret));
        var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

        var claims = new[]
        {
            new Claim(JwtRegisteredClaimNames.Sub, user.Id.ToString()),
            new Claim(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new Claim("employee_code", user.EmployeeCode),
            new Claim(ClaimTypes.Name, user.FullName),
            new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString())
        };

        var token = new JwtSecurityToken(
            issuer: _jwt.Issuer,
            audience: _jwt.Audience,
            claims: claims,
            expires: expires,
            signingCredentials: creds);

        return new JwtSecurityTokenHandler().WriteToken(token);
    }
}
