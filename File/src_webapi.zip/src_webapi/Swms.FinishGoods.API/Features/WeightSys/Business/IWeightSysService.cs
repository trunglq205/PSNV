using Swms.FinishGoods.API.Features.Foss.DataAccess;
using Swms.FinishGoods.API.Features.WeightSys.DataAccess;

namespace Swms.FinishGoods.API.Features.WeightSys.Business;

public interface IWeightSysService
{
    Task<IReadOnlyCollection<WeightDto>> GetSerialWeightAsync(
        FossCategory category,
        string modelNo,
        List<string> serialNos);
}