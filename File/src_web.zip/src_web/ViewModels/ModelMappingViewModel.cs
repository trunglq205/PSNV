﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using System.Drawing.Printing;

namespace SWMS_WebTool.ViewModels
{
    public class ModelMappingViewModel : TableViewModel<ModelMapping, ModelMappingFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, ModelMappingFilter? filter = null)
        {
            return new
            {
                Type = filter?.Plant ?? Filter.Plant,
                Material = filter?.Cate ?? Filter.Cate,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
