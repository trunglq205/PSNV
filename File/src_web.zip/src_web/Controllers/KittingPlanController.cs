﻿using System.Data;
using System.Security.Principal;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class KittingPlanController : BaseController
    {
        private readonly ApiService _apiService;
        public KittingPlanController(ApiService apiService)
        {
            _apiService = apiService;
        }
        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] KittingPlanFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new KittingPlanFilter();


                if (User.Identity.Name != null)
                {
                    if (User.Identity.Name.Contains("-PMD"))
                    {
                        _filter.Tab = KittingTab.KittingOutside;
                        filter.Cate = "PMD";
                    }
                }
                int total = 10;
                var dropdownData = await _apiService.GetCategoryPlanMaster();
                var dropdownDataKitting = await _apiService.GetCategoryKittingtype();
                ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
                ViewBag.Categorys = new SelectList(dropdownData.Where(s => !string.IsNullOrEmpty(_filter.Plant) ? s.Plant == _filter.Plant : s.Plant == "").Select(x => x.Category).Distinct().ToList());
                ViewBag.SpecialParts = new SelectList(dropdownData.Select(x => x.SpecialPart).Distinct().ToList());
                ViewBag.KittingTypes = dropdownDataKitting.Select(x => x.KittingType).Distinct().Select(s => new SelectListItem { Text = Function.MapNameKittingType(s), Value = s }).ToList();
                IEnumerable<KittingPlan> items = new List<KittingPlan>();
                switch (filter?.Tab)
                {
                    case KittingTab.KittingFA:
                        var responseData = await _apiService.GetDataKittingPlanFA(_filter, pageNumber, _pageSize);
                        total = responseData.TotalRecord;
                        items = responseData.Records ?? new List<KittingPlan>();
                        break;
                    case KittingTab.KittingDIP:
                        var dropdownUploadno = await _apiService.GetUploadNoKittingPlan(1, _filter.ProDate);
                        ViewBag.UploadNos = new SelectList(dropdownUploadno.Distinct().ToList());
                        var responseDataDIP = await _apiService.GetDataKittingPlanDIP(_filter, pageNumber, _pageSize);
                        total = responseDataDIP.TotalRecord;
                        items = responseDataDIP.Records ?? new List<KittingPlan>();
                        break;
                    case KittingTab.KittingSubcon:
                        var responseDataSubcon = await _apiService.GetDataKittingSubcon(_filter, pageNumber, _pageSize);
                        total = responseDataSubcon.TotalRecord;
                        items = responseDataSubcon.Records ?? new List<KittingPlan>();
                        break;
                    case KittingTab.KittingOutside:
                        var responseDataOutside = await _apiService.GetDataKittingOutside(_filter, pageNumber, _pageSize);
                        total = responseDataOutside.TotalRecord;
                        items = responseDataOutside.Records ?? new List<KittingPlan>();
                        break;
                }
                var model = new KittingPlanViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,

                };
                return View("Views/KittingPlan/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportActualPlan(IFormFile file, KittingTab tab, string urgent)
        {
            try
            {
                var dropdownData = await _apiService.GetCategoryPlanMaster();
                ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
                ViewBag.Categorys = new SelectList(dropdownData.Select(x => x.Category).Distinct().ToList());
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.ActualPlanDIPHeader, Constants.IndexActualPlanDIPHeader);
                        if (dt != null && dt.Columns.Count == Constants.ActualPlanDIPHeader.Count)
                        {
                            List<ActualPlanImport>? planImports = Function.DataTatbleToActualPlanDIP(dt);
                            if (planImports != null && planImports.Count > 0)
                            {
                                if (urgent == "1")
                                {
                                    var dateSelect = planImports.Select(s => s.ProductDate).First()?.ToString(Constants.YYYY_MM_DD);
                                    var dropdownUploadno = await _apiService.GetUploadNoKittingPlan(1, dateSelect);
                                    ViewBag.UploadNos = new SelectList(dropdownUploadno.Distinct().ToList());
                                }
                                var importActual = new ActualPlanImportDIPViewModel()
                                {
                                    ActualPlanImports = planImports
                                };
                                var tupple = new Tuple<ActualPlanImportDIPViewModel, string>(importActual, urgent);
                                return PartialView("~/Views/KittingPlan/_UploadActualPlanModal.cshtml", tupple);
                            }
                        }
                    }

                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportActualPlan([FromBody] List<ActualPlanImport> request, string category, string uploadno, string urgent)
        {
            try
            {
                if (string.IsNullOrEmpty(category) || (string.IsNullOrEmpty(uploadno) && urgent == "1"))
                {
                    return BadRequest(Constants.REQUIRED_CATEGORY);
                }
                var newRequest = request.Select(rs =>
                {
                    rs.IsUrgent = urgent == "1" ? true : false;
                    rs.Plant = rs.Plant.ToUpper();
                    rs.Category = category;
                    rs.UploadNo = (!string.IsNullOrEmpty(uploadno) && urgent == "1") ? uploadno : "0";

                    return rs;
                }).ToList();

                await _apiService.ImportActualPlanDIP(newRequest);
                var countData = request.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> ImportKittingPlan(IFormFile file, KittingTab tab, string urgent)
        {
            try
            {
                var dropdownData = await _apiService.GetCategoryPlanMaster();
                ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
                ViewBag.Categorys = new SelectList(dropdownData.Select(x => x.Category).Distinct().ToList());
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        switch (tab)
                        {
                            case KittingTab.KittingFA:
                                dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.KittingPlanFAHeader, Constants.IndexKittingFAHeader);
                                if (dt != null && dt.Columns.Count == Constants.KittingPlanFAHeader.Count)
                                {
                                    List<KittingPlanImport>? planImports = Function.DataTatbleToKittingPlan(dt);
                                    var importKittingFA = new ImportKittingListViewModel()
                                    {
                                        KittingPlanImports = planImports
                                    };
                                    if (planImports != null && planImports.Count > 0)
                                    {
                                        return PartialView("~/Views/KittingPlan/_ImportKittingPlanModal.cshtml", importKittingFA);
                                    }
                                }
                                break;

                            case KittingTab.KittingDIP:
                                dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.KittingPlanDIPHeader, Constants.IndexKittingDIPHeader);
                                if (dt != null && dt.Columns.Count == Constants.KittingPlanDIPHeader.Count)
                                {
                                    List<KittingPlanDIPImport>? planImports = Function.DataTatbleToKittingPlanDIP(dt);
                                    var grData = planImports.GroupBy(g => new { g.Plant, g.Sloc, g.Material, g.FinishGoods, g.IsUrgent }).Select(s => new KittingPlanDIPImport
                                    {
                                        FinishGoods = s.Key.FinishGoods,
                                        Descriptions = s.First().Descriptions,
                                        Assembly = s.First().Assembly,
                                        AssemblyQuantity = s.Sum(x => x.AssemblyQuantity),
                                        MaterialQuantity = s.Sum(x => x.MaterialQuantity),
                                        Plant = s.Key.Plant,
                                        Sloc = s.Key.Sloc,
                                        IsUrgent = s.Key.IsUrgent,
                                        Lvl = s.First().Lvl,
                                        Material = s.Key.Material,
                                        MovingType = s.First().MovingType,
                                        Vendor = s.First().Vendor
                                    }).ToList();
                                    var importKittingDIP = new ImportKittingListDIPViewModel()
                                    {
                                        KittingPlanDIPImports = grData
                                    };
                                    if (grData != null && grData.Count > 0)
                                    {
                                        var tupple = new Tuple<ImportKittingListDIPViewModel, string>(importKittingDIP, urgent);
                                        return PartialView("~/Views/KittingPlan/_ImportKittingPlanDIPModal.cshtml", tupple);
                                    }
                                }
                                break;

                            case KittingTab.KittingSubcon:
                                dt = Function.GetDataTableFromExcel(filepath, "In PC", Constants.KittingPlanSubconHeader, Constants.IndexKittingPlanSubconHeader);
                                if (dt != null && dt.Columns.Count == Constants.KittingPlanSubconHeader.Count)
                                {
                                    List<KittingPlanImport>? planImports = Function.DataTatbleToKittingPlanSubcon(dt);
                                    var importKittingSubcon = new ImportKittingListSubconViewModel()
                                    {
                                        KittingPlanImports = planImports
                                    };
                                    if (planImports != null && planImports.Count > 0)
                                    {
                                        var tupple = new Tuple<ImportKittingListSubconViewModel, string>(importKittingSubcon, urgent);
                                        return PartialView("~/Views/KittingPlan/_ImportKittingPlanSubconModal.cshtml", tupple);
                                    }
                                }
                                break;

                            case KittingTab.KittingOutside:
                                dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.KittingPlanOtherHeader, Constants.IndexKittingPlanOtherHeader);
                                if (dt != null && dt.Columns.Count == Constants.KittingPlanOtherHeader.Count)
                                {
                                    List<KittingPlanImport>? planImports = Function.DataTatbleToKittingPlanOther(dt);
                                    var importKittingOutside = new ImportKittingListViewModel()
                                    {
                                        KittingPlanImports = planImports
                                    };
                                    if (planImports != null && planImports.Count > 0)
                                    {
                                        var tupple = new Tuple<ImportKittingListViewModel, string>(importKittingOutside, urgent);
                                        return PartialView("~/Views/KittingPlan/_ImportKittingPlanOutsideModal.cshtml", tupple);
                                    }
                                }
                                break;
                        }
                    }

                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportLKittingPlan([FromBody] List<KittingPlanImport> request, string plant, string cate)
        {
            try
            {
                if (string.IsNullOrEmpty(cate))
                {
                    return BadRequest(Constants.REQUIRED_CATEGORY);
                }
                var newRequest = request.Select(rs =>
                {
                    rs.Category = cate;
                    return rs;
                }).ToList();
                await _apiService.ImportKittingPlanFA(newRequest);
                var countData = request.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportLKittingPlanSubcon([FromBody] List<KittingPlanImport> request, string plant, string cate, string kittingfrom, string urgent)
        {
            try
            {
                if (string.IsNullOrEmpty(cate))
                {
                    return BadRequest(Constants.REQUIRED_CATEGORY);
                }
                var newrequest = request.Select(x => new KittingPlanImport
                {
                    Plant = x.Plant,
                    Issue_Sloc = x.Issue_Sloc,
                    ReceiptSloc = x.ReceiptSloc,
                    Material = x.Material,
                    Quantity = x.Quantity,
                    MaterialDescription = x.MaterialDescription,
                    RequirementsDate = x.RequirementsDate,
                    Line = x.Line,
                    PSNVStock = x.PSNVStock,
                    KittingFrom = kittingfrom ?? "",
                    Category = cate ?? "",
                    KHFAN7 = x.KHFAN7,
                    VenderName = x.VenderName,
                    QuantityActual = x.QuantityActual,
                    Pallet = x.Pallet,
                    STT = x.STT

                }).ToList();
                await _apiService.ImportKittingPlanSubcon(newrequest);
                var countData = request.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportLKittingPlanOutside([FromBody] List<KittingPlanImport> request, string plant, string cate)
        {
            try
            {
                if (string.IsNullOrEmpty(cate))
                {
                    return BadRequest(Constants.REQUIRED_CATEGORY);
                }
                var newRequest = request.Select(rs =>
                {
                    rs.Category = cate;
                    return rs;
                }).ToList();
                await _apiService.ImportKittingPlanOutside(newRequest);
                var countData = request.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportLKittingPlanDIP([FromBody] List<KittingPlanDIPImport> request, string plant, string cate, string deleverydate, string urgent)
        {
            try
            {
                if (string.IsNullOrEmpty(cate))
                {
                    return BadRequest(Constants.REQUIRED_CATEGORY);
                }
                var newRequest = request.Select(x => new KittingPlanDIPImport
                {
                    Vendor = x.Vendor,
                    Assembly = x.Assembly,
                    AssemblyQuantity = x.AssemblyQuantity,
                    Deliverydate = Convert.ToDateTime(deleverydate),
                    Descriptions = x.Descriptions,
                    FinishGoods = x.FinishGoods,
                    Lvl = x.Lvl,
                    Material = x.Material,
                    MaterialQuantity = x.MaterialQuantity,
                    MovingType = x.MovingType,
                    Plant = x.Plant.ToUpper(),
                    Sloc = x.Sloc,
                    Category = cate,
                    IsUrgent = urgent == "1" ? true : false
                }).ToList();
                await _apiService.ImportKittingPlanDIP(newRequest);
                var countData = request.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult DeleteKittingPlan([FromBody] DeleteKittingRequest request)
        {
            var model = new DeletePlanObject()
            {
                Id = string.Join(",", request.SelectedItems),
                Tab = request.Tab,
                Action = "ConfirmDeleteKittingPlan",
                Controller = "KittingPlan",
            };
            return PartialView("~/Views/KittingPlan/_DeletePlanModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteKittingPlan(string id, string tab)
        {
            try
            {
                var lstID = id.Split(",").Select(int.Parse).ToList();
                if (tab == "0")
                {
                    await _apiService.DeleteKittingPlanFA(lstID);
                }
                else if (tab == "1")
                {
                    await _apiService.DeleteKittingPlanDIP(lstID);
                }
                else if (tab == "2")
                {
                    await _apiService.DeleteKittingPlanSubcon(lstID);
                }
                else if (tab == "3")
                {
                    await _apiService.DeleteKittingPlanOutside(lstID);
                }

                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewModelKittingDIP([FromQuery] string plant, string model, string proDate, bool? isUrgentDIP)
        {
            try
            {
                var _filter = new ModelMappingFilter()
                {
                    Plant = plant,
                    Model = model,
                    ProductDate = proDate ?? DateTime.Now.ToString("yyyy-MM-dd"),
                    IsUrgentDIP = isUrgentDIP ?? false
                };
                var dropdownData = await _apiService.GetCategoryPlanMaster();
                ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
                IEnumerable<DataKittingDIPModel> items = new List<DataKittingDIPModel>();
                var responseDataOutside = await _apiService.GetModelKittingDIP(_filter, Constants.PagingDefault, Constants.PageMaximum);
                items = responseDataOutside.Records ?? new List<DataKittingDIPModel>();
                var rs = new Tuple<IEnumerable<DataKittingDIPModel>, ModelMappingFilter>(items, _filter);
                return PartialView("Views/KittingPlan/_DeleteActualPlanModal.cshtml", rs);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public IActionResult DeleteKittingModelDip(string id, string tab)
        {
            var model = new DeletePlanObject()
            {
                Id = id,
                Tab = "1",
                Action = "ConfirmDeleteKittingModelDip",
                Controller = "KittingPlan",
            };
            return PartialView("~/Views/KittingPlan/_DeletePlanModal2.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteKittingModelDip(string id, string tab)
        {
            try
            {
                var lstID = id.Split(";").Select(int.Parse).ToList();

                await _apiService.DeleteModelKittingDIP(lstID);

                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> BlockSapSchedulePlan([FromQuery] MasterBlockSapScheduleFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new MasterBlockSapScheduleFilter();
                var response = await _apiService.GetALlBlockSapSchedulePlan();

                var total = 10;
                var items = response ?? new List<BlockSapSchedulePlan>();


                var model = new BlockSchedulePlanViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/KittingPlan/BlockSapSchedulePlan.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportBlockSchedule(IFormFile file)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.BlockScheduleHeader, Constants.BlockScheduleIndex);
                        if (dt != null && dt.Columns.Count == Constants.BlockScheduleHeader.Count)
                        {

                            List<BlockSapSchedulePlanRequest>? schedule = Function.DataTatbleToBlockSchedule(dt);
                            if (schedule != null && schedule.Count > 0)
                            {
                                return PartialView("~/Views/KittingPlan/_ImportBlockScheduleModal.cshtml", schedule);
                            }
                        }
                    }
                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportBlockSchedule([FromBody] List<BlockSapSchedulePlanRequest> request)
        {
            try
            {
                await _apiService.CreateBlockSapSchedulePlan(request);
                var countData = request.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
