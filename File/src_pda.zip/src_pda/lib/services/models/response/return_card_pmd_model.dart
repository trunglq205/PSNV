import 'package:json_annotation/json_annotation.dart';
import 'package:smart_warehouse/services/models/request/receiving_card_model.dart';

import 'base_response_model.dart';

part 'return_card_pmd_model.g.dart';

@JsonSerializable()
class ReturnCardPmdModel extends BaseResponseModel  {
  ReturnCardPmdModel({
    required this.id,
    required this.section,
    required this.material,
    required this.model,
    required this.machine,
    required this.typeCard,
    required this.statusRecycle,
    required this.barcode,
    required this.quantity,
    required this.unit,
    required this.sloc,
    required this.kittingCardID,
    required this.dateTimeInsert,
    required this.userIDInsert,
    this.dateTimeUpdate,
    this.userIDUpdate,
    this.statusTranferSAP,
    this.dateTimeTranferSAP,
    required this.flagDelete,
  });

  factory ReturnCardPmdModel.fromJson(Map<String, dynamic> json) =>
      _$ReturnCardPmdModelFromJson(json);

  final int id;
  final String? section;
  final String? material;
  final String? model;
  final String? machine;
  final String? typeCard;
  final String? statusRecycle;
  final String? barcode;
  final double quantity;
  final String? unit;
  final String? sloc;
  final int kittingCardID;
  final DateTime dateTimeInsert;
  final String? userIDInsert;
  final DateTime? dateTimeUpdate;
  final String? userIDUpdate;
  final int? statusTranferSAP;
  final DateTime? dateTimeTranferSAP;
  final int flagDelete;

  @override
  Map<String, dynamic> toJson() => _$ReturnCardPmdModelToJson(this);
}