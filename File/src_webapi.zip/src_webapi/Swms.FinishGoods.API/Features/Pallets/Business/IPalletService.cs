using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business;

namespace Swms.FinishGoods.API.Features.Pallets.Business
{
    /// <summary>
    /// Nghiệp vụ pallet thuần SWMS. Đồng bộ với hệ thống ngoài KHÔNG nằm ở đây:
    ///   Foss    -> Features/Foss/PalletSync/IPalletFossSyncService
    ///   HD soft -> Features/HdSoft/PalletSync/IPalletHdSoftSyncService
    /// </summary>
    public interface IPalletService
    {
        // ── Pallet ──
        Task<PagedResult<PalletResponse>> GetPagedAsync(PalletQuery query);
        Task<PalletResponse> GetByIdAsync(long id);
        /// <param name="onInserted">
        /// Chạy trong CÙNG transaction tạo pallet, sau khi pallet + box + line đã
        /// insert — nhận (conn, tx, lotId). Để feature khác ghi thêm dữ liệu của
        /// mình mà không mở transaction thứ hai; ném lỗi trong hook là rollback
        /// cả pallet. Xem <see cref="DataAccess.ILotRepository.AddAsync"/>.
        /// </param>
        Task<CreatePalletResponse> CreateAsync(
            CreatePalletRequest request,
            Func<System.Data.IDbConnection, System.Data.IDbTransaction, long, Task>? onInserted = null);
        Task DeleteAsync(long id);
        Task<UpdateBoxCountResponse> UpdateBoxCountAsync(long id, UpdateBoxCountRequest request);

        /// <summary>
        /// Xoá thùng khỏi pallet serial / box_line (vd thùng không còn bên HD soft).
        /// Không cho xoá hết thùng — muốn bỏ cả pallet thì dùng DELETE pallet.
        /// </summary>
        Task<DeleteBoxesResponse> DeleteBoxesAsync(long id, DeleteBoxesRequest request);
        Task<NextLotNoResponse> GenerateNextLotNoAsync(int categoryCode);

        // ── Quét pallet (PDA): dùng chung Vị trí tạm / Quick Scan / Lưu kho ──

        /// <summary>
        /// Quét mã pallet → thông tin lot + vị trí + tổng hợp model + allowedActions.
        /// <paramref name="include"/> quyết định có nạp thêm thùng / lịch sử.
        /// Không tìm thấy → NotFound (PDA gọi tiếp POST .../from-foss).
        /// </summary>
        Task<PalletDetailResponse> GetDetailByLotNoAsync(string lotNo, PalletInclude include);

        /// <summary>
        /// Như trên nhưng từ thông tin vị trí đã nạp sẵn — các luồng đồng bộ dùng để trả
        /// cùng shape GET by-lot-no mà không đọc lại pallet.
        /// </summary>
        Task<PalletDetailResponse> BuildDetailAsync(PalletLocationInfo info, PalletInclude include);

        // ── Vị trí (PDA / Web) ──

        /// <summary>
        /// Gán (lot chưa có vị trí) hoặc chuyển (lot đã có) sang vị trí tạm mới.
        /// Cùng thân xử lý với StoreAsync — chỉ khác tiền điều kiện và mã lỗi.
        /// </summary>
        /// <param name="allowedMapType">
        /// Chỉ cho gán vào vị trí thuộc loại bản đồ này (receiving/storing/vanning).
        /// null = không giới hạn (dùng cho màn Chuyển/Out vị trí).
        /// </param>
        Task<LocatorChangeResponse> AssignLocatorAsync(
            long lotId, string locatorCode, string? allowedMapType = null);

        /// <summary>Rời vị trí: gỡ lot khỏi vị trí đang đứng.</summary>
        Task<LocatorChangeResponse> ReleaseLocatorAsync(long lotId);

        /// <summary>
        /// Xác nhận lưu kho: đặt pallet vào vị trí đích. Thêm điều kiện pallet phải
        /// đang ở khu vị trí tạm; còn lại giống AssignLocatorAsync.
        /// </summary>
        Task<LocatorChangeResponse> StoreAsync(long lotId, string locatorCode);

        // ── Vị trí — chỉ dành cho luồng đồng bộ (Foss / HD soft) ──

        /// <summary>Gán / chuyển vị trí theo hệ thống ngoài; event mang source / actor của <paramref name="sync"/>.</summary>
        Task<LocatorChangeResponse> AssignLocatorBySyncAsync(
            long lotId, string locatorCode, IntegrationSyncContext sync, object? extra = null);

        /// <summary>Rời vị trí theo hệ thống ngoài; event mang source / actor của <paramref name="sync"/>.</summary>
        Task<LocatorChangeResponse> ReleaseLocatorBySyncAsync(
            long lotId, IntegrationSyncContext sync, object? extra = null);

        // ── Tách pallet ──
        Task<SplitPalletResponse> SplitAsync(SplitPalletRequest req);
    }
}
