using Swms.FinishGoods.Web.Features.Inventory.Business.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;

/*  Nút xử lý trên TỪNG dòng của bảng so SWMS ↔ HD soft — chỉ gọi API sẵn có:

      create : POST   /api/pallets                         (box_count, quy cách mặc định = SL / người dùng nhập)
               PUT    /api/pallets/{id}/locator            (đặt vị trí theo HD soft)
      delete : DELETE /api/pallets/{id}
      qty    : PUT    /api/pallets/{id}/box-count          (giữ ID + lịch sử, chống ghi đè bằng expectedQty)
      sync   : POST   /api/pallets/by-lot-no/{lotNo}/hdsoft-sync
               (mã pallet có ở cả 2 bên nhưng KHÁC vị trí -> chuyển vị trí, không tạo/xoá)
      boxes  : POST   /api/pallets/{id}/boxes/delete
               (SWMS thừa trên pallet serial / box_line: mở dialog chi tiết pallet, người dùng tìm đúng
                thùng không còn bên HD soft rồi xoá. Không chạy hàng loạt — phải chọn thùng bằng tay.)
      topup  : POST   /api/pallets/by-lot-no/{lotNo}/foss-top-up
               (lệch SL ÂM — SWMS ít hơn HD soft — trên pallet serial / box_line: không sửa SL tay được,
                kéo thùng / serial Foss còn thiếu về. Thay cho các trường hợp trước đây bắt xử lý tay.)

    create / qty cần quy cách (pcs/thùng): tạo mặc định = SL, sửa SL mặc định = UCLN(SL trước, SL sau);
    người dùng sửa được trong hộp xác nhận.
    SL phải chia hết quy cách vì pallet box_count lưu SL = box_count × standard_packing.

    Dòng nào không xử lý tự động được thì vẫn có mục, Kind = null + lý do (hiện mờ, tooltip). */

public static class HdActKind
{
    public const string Create = "create";
    public const string Delete = "delete";
    public const string Qty = "qty";
    public const string Sync = "sync";
    public const string TopUp = "topup";
    public const string Boxes = "boxes";

    /// <summary>Hành động trên cả pallet (không theo dòng): pallet nhiều model hiện ở nhiều dòng chỉ chạy 1 lần.</summary>
    public static bool IsPerPallet(string? kind) => kind is Sync or TopUp;
}

public class HdRowAction
{
    /// <summary>null = không xử lý tự động được, xem ReasonKey.</summary>
    public string? Kind { get; init; }
    public string? ReasonKey { get; init; }

    /// <summary>Mã pallet hiển thị / dùng cho create, sync.</summary>
    public string Pallet { get; init; } = "";
    /// <summary>Pallet SWMS (delete, qty).</summary>
    public AppInventoryItem? Lot { get; init; }

    public string Model { get; init; } = "";
    /// <summary>Vị trí SWMS đích cho create — đúng mã HD soft (PSNV giữ là PSNV), rỗng -> SCS.</summary>
    public string? Locator { get; init; }
    /// <summary>create: SL HD soft. qty: SL mới.</summary>
    public int Qty { get; init; }
    /// <summary>qty: SL SWMS lúc so.</summary>
    public int OldQty { get; init; }
    /// <summary>qty: quy cách hiện tại của pallet (TotalQty / BoxCount), null nếu không suy ra được.</summary>
    public int? CurrentPacking { get; init; }

    public bool Enabled => Kind is not null;
    public string Key => $"{Kind ?? "none"}|{Pallet}|{Lot?.Id}";
}

public static class HdSoftRowActions
{
    private const string TempLocator = "SCS";       // = PalletHdSoftSyncService.TempLocatorCode (API)
    private const string BoxCountLevel = "box_count";

    // Cùng định nghĩa "ngoài kho" với InventoryHdSoftCompareDialog.IsOutside
    private static readonly HashSet<string> OutsideAreas = new(StringComparer.OrdinalIgnoreCase) { "fa", "customer" };

    /// <summary>Tính hành động cho mọi dòng chưa khớp. Gọi 1 lần sau mỗi lần so.</summary>
    public static Dictionary<AppStockCompareRow, List<HdRowAction>> Build(AppStockCompareResult data)
    {
        var cmp = StringComparer.OrdinalIgnoreCase;

        var swmsCodes = new HashSet<string>(cmp);
        var rowsOfPallet = new Dictionary<long, List<AppStockCompareRow>>();
        foreach (var row in data.Rows)
            foreach (var p in row.SwmsPallets)
            {
                swmsCodes.Add(p.LotNo.Trim());
                if (!string.IsNullOrWhiteSpace(p.StockyCode)) swmsCodes.Add(p.StockyCode.Trim());
                if (!rowsOfPallet.TryGetValue(p.Id, out var list)) rowsOfPallet[p.Id] = list = new();
                list.Add(row);
            }

        var hdCodes = data.Rows.SelectMany(r => r.HdItems)
                               .Select(h => (h.PalletNo ?? "").Trim())
                               .Where(s => s.Length > 0)
                               .ToHashSet(cmp);

        var map = new Dictionary<AppStockCompareRow, List<HdRowAction>>();
        foreach (var row in data.Rows)
        {
            var acts = row.Result switch
            {
                StockCmp.OnlyHdSoft => ForMissing(row, swmsCodes),
                StockCmp.OnlySwms => ForExtra(row, hdCodes, rowsOfPallet),
                StockCmp.QtyDiff => ForQty(row, swmsCodes, hdCodes),
                _ => new List<HdRowAction>(),
            };
            if (acts.Count > 0) map[row] = acts;
        }
        return map;
    }

    // ── Thiếu ở SWMS: tạo từng pallet HD soft ──
    private static List<HdRowAction> ForMissing(AppStockCompareRow row, HashSet<string> swmsCodes)
        => HdPallets(row)
            .Select(x => CreateOrSync(row, x.Code, x.Qty, swmsCodes))
            .ToList();

    /// <summary>Pallet HD soft của dòng, gộp SL theo mã.</summary>
    private static IEnumerable<(string Code, decimal Qty)> HdPallets(AppStockCompareRow row)
        => row.HdItems
            .GroupBy(h => (h.PalletNo ?? "").Trim(), StringComparer.OrdinalIgnoreCase)
            .Select(g => (g.Key, g.Sum(h => h.QtyOnHand)));

    /// <summary>
    /// Pallet HD soft chưa có ở dòng này của SWMS:
    ///   mã đã có trong SWMS (ở vị trí / model khác) -> đồng bộ vị trí
    ///   chưa có                                     -> tạo pallet box_count với SL của pallet HD soft đó
    /// </summary>
    private static HdRowAction CreateOrSync(AppStockCompareRow row, string code, decimal qty, HashSet<string> swmsCodes)
    {
        if (code.Length > 0 && swmsCodes.Contains(code))
            return new HdRowAction { Kind = HdActKind.Sync, Pallet = code, Model = row.Model };

        var reason = code.Length == 0 ? "NoPalletNo"
            : !IsLotNo(code) ? "LotNoFormat"
            : row.Model.Length == 0 ? "NoModel"
            : !IsPositiveInt(qty) ? "QtyInvalid"
            : null;

        return new HdRowAction
        {
            Kind = reason is null ? HdActKind.Create : null,
            ReasonKey = reason is null ? null : "Inventory.Act.Reason." + reason,
            Pallet = code.Length == 0 ? "—" : code,
            Model = row.Model,
            Locator = MapLocator(row.LocKey),
            Qty = reason is null ? (int)qty : 0,
        };
    }

    // ── Thừa ở SWMS: xoá từng pallet ──
    private static List<HdRowAction> ForExtra(
        AppStockCompareRow row, HashSet<string> hdCodes, Dictionary<long, List<AppStockCompareRow>> rowsOfPallet)
        => row.SwmsPallets
            .Where(p => !IsOutside(p))       // chưa vào kho / đã giao: đương nhiên không có ở HD soft
            .Select(p =>
            {
                var code = Code(p);
                var inHd = hdCodes.Contains(p.LotNo.Trim())
                           || (!string.IsNullOrWhiteSpace(p.StockyCode) && hdCodes.Contains(p.StockyCode.Trim()));

                if (inHd) return new HdRowAction { Kind = HdActKind.Sync, Pallet = p.LotNo, Lot = p, Model = row.Model };

                // Pallet nhiều model: chỉ xoá cả pallet khi MỌI model đều thừa.
                // Một phần thừa trên pallet có thùng -> xoá thùng của model này (cả phần này đều thừa).
                var partial = rowsOfPallet[p.Id].Any(r => r.Result != StockCmp.OnlySwms);
                if (partial && HasBoxes(p))
                    return Boxes(row, p, row.SwmsItems.Where(u => u.Pallet.Id == p.Id).Sum(u => u.Qty), 0);

                var reason = partial ? "PartialMatch" : null;

                return new HdRowAction
                {
                    Kind = reason is null ? HdActKind.Delete : null,
                    ReasonKey = reason is null ? null : "Inventory.Act.Reason." + reason,
                    Pallet = code,
                    Lot = p,
                    Model = row.Model,
                    OldQty = p.TotalQty,
                };
            })
            .ToList();

    // ── Lệch SL: so theo TỪNG PALLET trong dòng (vị trí, model) ──
    //   pallet có ở HD soft, chưa có ở dòng này của SWMS -> tạo (SL của pallet HD soft) / đồng bộ vị trí nếu đã có ở chỗ khác
    //   pallet có ở cả 2 bên nhưng SL khác             -> cập nhật SL (chỉ pallet box_count)
    //   pallet chỉ có ở dòng SWMS                      -> đồng bộ vị trí nếu HD soft có ở chỗ khác, không thì xử lý tay
    // Thiếu pallet thường giải thích hết phần lệch: tạo xong là dòng khớp, không cần sửa SL pallet chung.
    private static List<HdRowAction> ForQty(AppStockCompareRow row, HashSet<string> swmsCodes, HashSet<string> hdCodes)
    {
        var cmp = StringComparer.OrdinalIgnoreCase;
        var acts = new List<HdRowAction>();
        var hd = HdPallets(row).ToList();

        // Lệch SL âm = SWMS ít hơn HD soft. Pallet serial / box_line không sửa SL tay được
        // -> bổ sung từ Foss thay vì bắt xử lý tay. box_count không có thùng Foss nên loại.
        var swmsShort = row.Diff < 0;
        bool CanTopUp(AppInventoryItem p)
            => swmsShort && !string.Equals(p.DetailLevel, BoxCountLevel, StringComparison.OrdinalIgnoreCase);

        // SL SWMS theo pallet cho đúng model của dòng (pallet nhiều model chỉ tính phần model này)
        var swmsQty = row.SwmsItems
            .GroupBy(u => u.Pallet.Id)
            .ToDictionary(g => g.Key, g => g.Sum(u => u.Qty));

        bool InRow(AppInventoryItem p, string code)
            => string.Equals(p.LotNo.Trim(), code, StringComparison.OrdinalIgnoreCase)
               || string.Equals(p.StockyCode?.Trim(), code, StringComparison.OrdinalIgnoreCase);

        // 1) Pallet HD soft
        foreach (var (code, qty) in hd)
        {
            var p = code.Length == 0 ? null : row.SwmsPallets.FirstOrDefault(x => InRow(x, code));
            if (p is null)
            {
                acts.Add(CreateOrSync(row, code, qty, swmsCodes));
                continue;
            }

            var cur = swmsQty.GetValueOrDefault(p.Id);
            if (cur == qty) continue;                 // pallet chung đã khớp SL

            if (CanTopUp(p))
            {
                acts.Add(TopUp(row, p, cur, qty));
                continue;
            }

            // SWMS nhiều hơn trên pallet có thùng -> chọn thùng để xoá, đích = SL HD soft của chính pallet này.
            if (cur > qty && HasBoxes(p))
            {
                acts.Add(Boxes(row, p, cur, (int)Math.Max(0, Math.Floor(qty))));
                continue;
            }

            string? reason = !string.Equals(p.DetailLevel, BoxCountLevel, StringComparison.OrdinalIgnoreCase) ? "NotBoxCount"
                : p.Models.Count > 1 ? "MultiModel"
                : !IsPositiveInt(qty) ? "QtyInvalid"
                : null;

            acts.Add(new HdRowAction
            {
                Kind = reason is null ? HdActKind.Qty : null,
                ReasonKey = reason is null ? null : "Inventory.Act.Reason." + reason,
                Pallet = Code(p),
                Lot = p,
                Model = row.Model,
                Locator = p.LocatorCode,
                Qty = reason is null ? (int)qty : 0,
                OldQty = cur,
                CurrentPacking = p is { BoxCount: > 0 } && p.TotalQty > 0 && p.TotalQty % p.BoxCount == 0
                    ? p.TotalQty / p.BoxCount
                    : null,
            });
        }

        // 2) Pallet chỉ có ở dòng SWMS
        var hdHere = hd.Select(x => x.Code).ToHashSet(cmp);
        foreach (var p in row.SwmsPallets)
        {
            if (hdHere.Contains(p.LotNo.Trim()) || (p.StockyCode is { } sc && hdHere.Contains(sc.Trim()))) continue;

            var inHdElsewhere = hdCodes.Contains(p.LotNo.Trim())
                                || (!string.IsNullOrWhiteSpace(p.StockyCode) && hdCodes.Contains(p.StockyCode.Trim()));

            acts.Add(inHdElsewhere
                ? new HdRowAction { Kind = HdActKind.Sync, Pallet = p.LotNo, Lot = p, Model = row.Model }
                : CanTopUp(p)
                ? TopUp(row, p, swmsQty.GetValueOrDefault(p.Id), 0)
                : row.Diff > 0 && HasBoxes(p)
                ? BoxesForRow(row, p, swmsQty.GetValueOrDefault(p.Id))
                : new HdRowAction
                {
                    ReasonKey = "Inventory.Act.Reason.ExtraInQtyRow",
                    Pallet = Code(p),
                    Lot = p,
                    Model = row.Model,
                    OldQty = swmsQty.GetValueOrDefault(p.Id),
                });
        }

        // Không tìm ra pallet nào để xử lý (vd HD soft không có mã pallet):
        // SWMS thiếu -> bổ sung từ Foss cho các pallet SWMS của dòng; không được thì báo xử lý tay.
        if (acts.Count == 0)
            acts.AddRange(row.SwmsPallets.Where(CanTopUp)
                .Select(p => TopUp(row, p, swmsQty.GetValueOrDefault(p.Id), 0)));

        // SWMS thừa -> chọn thùng để xoá trên các pallet có thùng của dòng.
        if (acts.Count == 0 && row.Diff > 0)
            acts.AddRange(row.SwmsPallets.Where(HasBoxes)
                .Select(p => BoxesForRow(row, p, swmsQty.GetValueOrDefault(p.Id))));

        if (acts.Count == 0)
            acts.Add(new HdRowAction
            {
                ReasonKey = "Inventory.Act.Reason.QtyUnexplained",
                Pallet = string.Join(", ", row.SwmsPallets.Select(Code)),
                Model = row.Model,
            });

        return acts;
    }

    /// <summary>Pallet có dòng thùng để chọn xoá (serial / box_line).</summary>
    private static bool HasBoxes(AppInventoryItem p)
        => !string.Equals(p.DetailLevel, BoxCountLevel, StringComparison.OrdinalIgnoreCase);

    /// <summary>
    /// Mở dialog chọn thùng để xoá. OldQty = SL SWMS của model dòng trên pallet,
    /// Qty = SL nên còn lại -> dialog gợi ý cần bớt OldQty - Qty.
    /// </summary>
    private static HdRowAction Boxes(AppStockCompareRow row, AppInventoryItem p, int swmsQty, int targetQty)
        => new()
        {
            Kind = HdActKind.Boxes,
            Pallet = Code(p),
            Lot = p,
            Model = row.Model,
            Locator = p.LocatorCode,
            OldQty = swmsQty,
            Qty = Math.Min(swmsQty, Math.Max(0, targetQty)),
        };

    /// <summary>Không biết SL HD soft của riêng pallet: bớt tối đa phần thừa của cả dòng.</summary>
    private static HdRowAction BoxesForRow(AppStockCompareRow row, AppInventoryItem p, int swmsQty)
    {
        var surplus = (int)Math.Ceiling(Math.Max(0, row.Diff));
        return Boxes(row, p, swmsQty, swmsQty - Math.Min(swmsQty, surplus));
    }

    /// <summary>Bổ sung thùng / serial từ Foss. Pallet = pallet_id (foss-top-up tra theo mã pallet, không theo mã xe stocky).</summary>
    private static HdRowAction TopUp(AppStockCompareRow row, AppInventoryItem p, int swmsQty, decimal hdQty)
        => new()
        {
            Kind = HdActKind.TopUp,
            Pallet = p.LotNo.Trim(),
            Lot = p,
            Model = row.Model,
            Locator = p.LocatorCode,
            OldQty = swmsQty,
            Qty = IsPositiveInt(hdQty) ? (int)hdQty : 0,
        };

    /// <summary>LocKey (đã bỏ tiền tố "PSNV-") -> mã vị trí SWMS: giữ nguyên, rỗng -> SCS. Như PalletHdSoftSyncService.MapHdSoftLocator (API).</summary>
    public static string MapLocator(string? locKey)
    {
        var s = (locKey ?? "").Trim();
        return s.Length == 0 ? TempLocator : s;
    }

    /// <summary>Format pallet_id SWMS: 12 chữ số — POST /api/pallets chỉ nhận dạng này.</summary>
    public static bool IsLotNo(string s) => s.Length == 12 && s.All(char.IsAsciiDigit);

    private static bool IsOutside(AppInventoryItem p)
        => string.IsNullOrWhiteSpace(p.LocatorCode) || OutsideAreas.Contains(p.AreaKey);

    private static bool IsPositiveInt(decimal q) => q > 0 && q == decimal.Truncate(q) && q <= int.MaxValue;

    private static string Code(AppInventoryItem p) => (p.StockyCode ?? p.LotNo).Trim();
}
