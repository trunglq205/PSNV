import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';

/// Chọn các tầng rack gợi ý (chọn nhiều).
///
/// Trả null nếu huỷ; trả danh sách RỖNG nếu bỏ chọn hết (= xoá gợi ý tầng).
Future<List<int>?> showRackRowPickDialog(
  BuildContext context, {
  required List<int> selected,
}) {
  return showAppDialog<List<int>>(
    context,
    builder: (_) => _RackRowPickDialog(initial: selected),
  );
}

class _RackRowPickDialog extends StatefulWidget {
  const _RackRowPickDialog({required this.initial});

  final List<int> initial;

  @override
  State<_RackRowPickDialog> createState() => _RackRowPickDialogState();
}

class _RackRowPickDialogState extends State<_RackRowPickDialog> {
  late final Set<int> _selected = widget.initial.toSet();

  void _toggle(int row) => setState(() {
    if (!_selected.remove(row)) _selected.add(row);
  });

  void _submit() => Navigator.pop(context, _selected.toList()..sort());

  @override
  Widget build(BuildContext context) {
    return AppDialog(
      title: 'model_detail.rack_row_dialog_title'.tr(),
      subtitle: 'model_detail.rack_row_dialog_sub'.tr(),
      actions: [
        AppDialogAction.cancel(context),
        AppDialogAction.confirm(onPressed: _submit),
      ],
      child: Row(
        children: [
          for (
            var row = ModelDetail.rackRowMin;
            row <= ModelDetail.rackRowMax;
            row++
          ) ...[
            if (row > ModelDetail.rackRowMin) const SizedBox(width: AppDimens.sm),
            Expanded(
              child: _RowTile(
                row: row,
                selected: _selected.contains(row),
                onTap: () => _toggle(row),
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _RowTile extends StatelessWidget {
  const _RowTile({
    required this.row,
    required this.selected,
    required this.onTap,
  });

  final int row;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Material(
      color: selected ? swms.primaryTint : swms.card2,
      borderRadius: BorderRadius.circular(AppDimens.rInput),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        child: Container(
          height: AppDimens.hitLg,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(AppDimens.rInput),
            border: Border.all(
              color: selected ? swms.primary : swms.border,
              width: selected ? 1.5 : 1,
            ),
          ),
          child: Text(
            '$row',
            style: AppTextStyles.h2.copyWith(
              color: selected ? swms.primaryDark : swms.text2,
            ),
          ),
        ),
      ),
    );
  }
}
