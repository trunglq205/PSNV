/* ============================================================================
   MỤC 2c — Yêu cầu back hàng sang FA, hai cấp duyệt.

   Chạy SAU return_receiving_schema.sql và return_actual_schema.sql.

   Script tạo:
     1. 3 cột mới trên wms.return_instruction_serials:
          back_request_id — yêu cầu back đã "mua" con serial này
          sent_fa_at      — mốc giao sang FA
          returned_at     — mốc FA giao lại và SCS nhận (mục 3 dùng)
     2. wms.return_back_requests      — phiếu yêu cầu back (header)
     3. wms.return_back_request_lines — model + SL FA xin làm

   VÌ SAO YÊU CẦU BACK CÓ DÒNG (model + qty) MÀ KHÔNG PHẢI DANH SÁCH SERIAL:
     FA xin "100 con model X để rework", không ai ngồi tick 100 serial trên web.
     Serial chỉ được CHỐT ở bước quản lý SCS duyệt: lúc đó hệ thống tự gắp đủ
     số serial đang `received` của model đó, đóng dấu back_request_id và chuyển
     at_fa. Từ sau mốc đó, SỔ SERIAL là nguồn sự thật duy nhất cho tiến độ —
     dòng ở đây chỉ còn là bản ghi "FA đã xin bao nhiêu".

   VÌ SAO KHÔNG GỘP VÀO wms.return_instructions:
     Một chỉ thị nhận hàng có thể sinh NHIỀU lượt back (FA xin dần theo năng
     lực xưởng). Nhét thành trạng thái của phiếu nhận là mất lượt thứ hai.

   LUỒNG — bốn bước, mỗi bước MỘT QUYỀN (khuôn của màn Hàng bất thường):
     B1  FA tạo yêu cầu              → rework_refurbish.request_back
     B2  quản lý FA duyệt            → rework_refurbish.approve_fa
     B3  SCS WH xác nhận + tạo chỉ thị back → rework_refurbish.process
     B4  quản lý SCS duyệt cho back  → rework_refurbish.approve_scs
                                       ⇒ serial chuyển at_fa tại đây
   ============================================================================ */
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ---------- 0. Tiền đề ---------- */
IF OBJECT_ID(N'wms.return_instructions', N'U') IS NULL
   OR OBJECT_ID(N'wms.return_instruction_serials', N'U') IS NULL
BEGIN
    RAISERROR(N'Thieu wms.return_instructions / wms.return_instruction_serials — chay return_receiving_schema.sql truoc.', 16, 1);
    RETURN;
END;

BEGIN TRAN;

/* ---------- 1. wms.return_back_requests ---------- */
IF OBJECT_ID(N'wms.return_back_requests', N'U') IS NULL
BEGIN
    CREATE TABLE wms.return_back_requests
    (
        id        BIGINT IDENTITY(1,1) NOT NULL,

        /* Chỉ thị nhận hàng mà lượt back này lấy hàng ra. */
        doc_id    BIGINT         NOT NULL,

        /* Số phiếu người đọc được, dạng BK-yyyyMMdd-001. Cùng khuôn với
           doc_no của chỉ thị nhận hàng (RW-/RB-yyyyMMdd-001). */
        req_no    NVARCHAR(30)   NOT NULL,

        /* fa_requested   = FA vừa tạo, chờ quản lý FA
           fa_approved    = quản lý FA đã duyệt, chờ SCS WH
           scs_instructed = SCS WH đã tạo chỉ thị back, chờ quản lý SCS
           scs_approved   = đã cho back — serial đã chuyển at_fa
           cancelled      = huỷ ở bất kỳ bước nào trước scs_approved
           Khai đủ ngay để mục 2d / 3 không phải ALTER. */
        req_status NVARCHAR(20)  NOT NULL
            CONSTRAINT df_rbr_status DEFAULT (N'fa_requested'),

        /* ĐANG CHỜ AI — thứ màn hình lọc hàng đợi theo, và là thứ làm cho
           "duyệt" có nghĩa: nút chỉ hiện khi (quyền AND đúng bước).
           Cùng ý với ng_reports.current_step. */
        current_step NVARCHAR(20) NOT NULL
            CONSTRAINT df_rbr_step DEFAULT (N'fa_approve'),

        note      NVARCHAR(500)  NULL,

        requested_by      NVARCHAR(100) NULL,
        requested_at      DATETIME2(0)  NOT NULL
            CONSTRAINT df_rbr_req_at DEFAULT (SYSDATETIME()),

        fa_approved_by    NVARCHAR(100) NULL,
        fa_approved_at    DATETIME2(0)  NULL,
        fa_comment        NVARCHAR(500) NULL,

        scs_instructed_by NVARCHAR(100) NULL,
        scs_instructed_at DATETIME2(0)  NULL,

        scs_approved_by   NVARCHAR(100) NULL,
        scs_approved_at   DATETIME2(0)  NULL,
        scs_comment       NVARCHAR(500) NULL,

        cancelled_by      NVARCHAR(100) NULL,
        cancelled_at      DATETIME2(0)  NULL,
        cancel_reason     NVARCHAR(500) NULL,

        is_deleted BIT           NOT NULL CONSTRAINT df_rbr_is_deleted DEFAULT (0),
        created_at DATETIME2(0)  NOT NULL CONSTRAINT df_rbr_created_at DEFAULT (SYSDATETIME()),
        created_by NVARCHAR(100) NULL,
        updated_at DATETIME2(0)  NULL,
        updated_by NVARCHAR(100) NULL,

        CONSTRAINT pk_return_back_requests PRIMARY KEY CLUSTERED (id),

        CONSTRAINT ck_rbr_status CHECK (req_status IN
            (N'fa_requested', N'fa_approved', N'scs_instructed',
             N'scs_approved', N'cancelled')),

        CONSTRAINT ck_rbr_step CHECK (current_step IN
            (N'fa_approve', N'scs_instruct', N'scs_approve', N'done')),

        CONSTRAINT fk_rbr_doc FOREIGN KEY (doc_id)
            REFERENCES wms.return_instructions (id)
    );
    PRINT N'+ Da tao bang wms.return_back_requests.';
END
ELSE PRINT N'= wms.return_back_requests da co.';

/* req_no duy nhất. KHÔNG lọc is_deleted: xoá mềm một yêu cầu rồi cấp lại đúng
   số đó cho yêu cầu mới sẽ làm hai phiếu khác nhau trùng số trong lịch sử. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_back_requests')
                 AND name = N'ux_rbr_req_no')
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX ux_rbr_req_no
        ON wms.return_back_requests (req_no);
    PRINT N'+ ux_rbr_req_no';
END;

/* Hàng đợi theo bước — màn hình lọc "đang chờ tôi" bằng cặp này. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_back_requests')
                 AND name = N'ix_rbr_step')
BEGIN
    CREATE NONCLUSTERED INDEX ix_rbr_step
        ON wms.return_back_requests (current_step, doc_id)
        INCLUDE (req_no, req_status, requested_at)
        WHERE is_deleted = 0;
    PRINT N'+ ix_rbr_step';
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_back_requests')
                 AND name = N'ix_rbr_doc')
BEGIN
    CREATE NONCLUSTERED INDEX ix_rbr_doc
        ON wms.return_back_requests (doc_id)
        INCLUDE (req_no, req_status, current_step)
        WHERE is_deleted = 0;
    PRINT N'+ ix_rbr_doc';
END;

/* ---------- 2. wms.return_back_request_lines ---------- */
IF OBJECT_ID(N'wms.return_back_request_lines', N'U') IS NULL
BEGIN
    CREATE TABLE wms.return_back_request_lines
    (
        id         BIGINT IDENTITY(1,1) NOT NULL,
        request_id BIGINT         NOT NULL,
        line_no    INT            NOT NULL,

        /* Khớp master.models.code VÀ khớp model của một dòng trong chỉ thị
           nhận hàng — không lưu line_id, cùng lý do đã ghi ở sổ serial: mỗi
           lần Office sửa phiếu là xoá mềm toàn bộ dòng rồi chèn lại id mới. */
        model      NVARCHAR(100)  NOT NULL,

        /* SL FA XIN. Số thực sự giao sang FA = đếm serial có back_request_id
           này — KHÔNG lưu thành cột, cùng nguyên tắc với SL thực nhận. */
        qty        INT            NOT NULL,

        note       NVARCHAR(500)  NULL,

        is_deleted BIT            NOT NULL CONSTRAINT df_rbrl_is_deleted DEFAULT (0),
        created_at DATETIME2(0)   NOT NULL CONSTRAINT df_rbrl_created_at DEFAULT (SYSDATETIME()),
        created_by NVARCHAR(100)  NULL,
        updated_at DATETIME2(0)   NULL,
        updated_by NVARCHAR(100)  NULL,

        CONSTRAINT pk_return_back_request_lines PRIMARY KEY CLUSTERED (id),
        CONSTRAINT ck_rbrl_qty CHECK (qty > 0),
        CONSTRAINT fk_rbrl_req FOREIGN KEY (request_id)
            REFERENCES wms.return_back_requests (id)
    );
    PRINT N'+ Da tao bang wms.return_back_request_lines.';
END
ELSE PRINT N'= wms.return_back_request_lines da co.';

/* Một model một dòng trong một yêu cầu — để "xin thêm" là sửa qty chứ không
   sinh hai dòng cùng model rồi cộng nhầm. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_back_request_lines')
                 AND name = N'ux_rbrl_req_model')
BEGIN
    CREATE UNIQUE NONCLUSTERED INDEX ux_rbrl_req_model
        ON wms.return_back_request_lines (request_id, model)
        WHERE is_deleted = 0;
    PRINT N'+ ux_rbrl_req_model';
END;

/* ---------- 3. Ba cột mới trên sổ serial ---------- */
/* ⚠ MỌI câu nhắc tới ba cột này phải nằm trong EXEC(N'...').

   Cả file là MỘT batch. SQL Server bind tên cột theo cấu trúc bảng tại lúc
   compile CẢ batch, nên trên DB chưa có cột, câu ALTER phía dưới chưa kịp chạy
   thì batch đã lỗi 207 "Invalid column name" và KHÔNG CÂU NÀO được thực thi,
   kể cả CREATE TABLE ở trên. EXEC compile chuỗi SQL ở thời điểm GỌI nên nó
   thấy cột vừa thêm. Cùng cái bẫy đã trả giá ở return_receiving_schema.sql. */

IF COL_LENGTH(N'wms.return_instruction_serials', N'back_request_id') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_instruction_serials ADD back_request_id BIGINT NULL');
    PRINT N'+ back_request_id';
END
ELSE PRINT N'= back_request_id da co';

IF COL_LENGTH(N'wms.return_instruction_serials', N'sent_fa_at') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_instruction_serials ADD sent_fa_at DATETIME2(0) NULL');
    PRINT N'+ sent_fa_at';
END
ELSE PRINT N'= sent_fa_at da co';

/* returned_at dùng ở MỤC 3 (FA giao lại). Thêm luôn ở đây để mục 3 không phải
   ALTER lần nữa — một lần dừng DB là một lần xin phép. */
IF COL_LENGTH(N'wms.return_instruction_serials', N'returned_at') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_instruction_serials ADD returned_at DATETIME2(0) NULL');
    PRINT N'+ returned_at';
END
ELSE PRINT N'= returned_at da co';

/* FK + index cho back_request_id. Bọc EXEC vì nhắc tên cột. */
IF NOT EXISTS (SELECT 1 FROM sys.foreign_keys WHERE name = N'fk_ris_back_request')
BEGIN
    EXEC(N'
        ALTER TABLE wms.return_instruction_serials
        ADD CONSTRAINT fk_ris_back_request FOREIGN KEY (back_request_id)
            REFERENCES wms.return_back_requests (id)');
    PRINT N'+ fk_ris_back_request';
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_instruction_serials')
                 AND name = N'ix_ris_back_request')
BEGIN
    /* Lọc IS NOT NULL: phần lớn serial chưa thuộc lượt back nào, index lọc nhỏ
       hơn hẳn mà vẫn đủ cho câu "lượt back này gồm những con nào". */
    EXEC(N'
        CREATE NONCLUSTERED INDEX ix_ris_back_request
            ON wms.return_instruction_serials (back_request_id)
            INCLUDE (model, serial_no, status, pallet_id)
            WHERE is_deleted = 0 AND back_request_id IS NOT NULL');
    PRINT N'+ ix_ris_back_request';
END;

/* Index cho bước GẮP SERIAL lúc quản lý SCS duyệt: tìm serial đang `received`,
   chưa thuộc lượt back nào, theo (doc_id, model). */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_instruction_serials')
                 AND name = N'ix_ris_pickable')
BEGIN
    EXEC(N'
        CREATE NONCLUSTERED INDEX ix_ris_pickable
            ON wms.return_instruction_serials (doc_id, model, status)
            INCLUDE (serial_no, back_request_id)
            WHERE is_deleted = 0 AND back_request_id IS NULL');
    PRINT N'+ ix_ris_pickable';
END;

COMMIT;

/* ---------- 4. Kiểm lại ---------- */
SELECT N'4a. Bang moi' AS section;

SELECT bang = N'wms.return_back_requests',      so_dong = COUNT(*) FROM wms.return_back_requests
UNION ALL
SELECT N'wms.return_back_request_lines',        COUNT(*) FROM wms.return_back_request_lines;

SELECT N'4b. Cot moi tren so serial' AS section;

SELECT c.name, t.name AS kieu, c.is_nullable
FROM   sys.columns c
JOIN   sys.types   t ON t.user_type_id = c.user_type_id
WHERE  c.object_id = OBJECT_ID(N'wms.return_instruction_serials')
  AND  c.name IN (N'back_request_id', N'sent_fa_at', N'returned_at')
ORDER BY c.name;

SELECT N'4c. Index' AS section;

SELECT i.name, i.is_unique, i.has_filter
FROM   sys.indexes i
WHERE  i.object_id IN (OBJECT_ID(N'wms.return_back_requests'),
                       OBJECT_ID(N'wms.return_back_request_lines'),
                       OBJECT_ID(N'wms.return_instruction_serials'))
  AND  i.name IN (N'ux_rbr_req_no', N'ix_rbr_step', N'ix_rbr_doc',
                  N'ux_rbrl_req_model', N'ix_ris_back_request', N'ix_ris_pickable')
ORDER BY i.name;

/* ---------- 5. Việc còn phải làm bằng tay ---------- */
SELECT N'5. Con phai lam tay' AS section;
SELECT viec = N'Khai quyen cho role: rework_refurbish.request_back (FA), '
            + N'.approve_fa (quan ly FA), .approve_scs (quan ly SCS) — man Roles.'
UNION ALL
SELECT N'Quyen moi tu xuat hien trong matrix sau khi BUILD LAI API '
     + N'(PermissionCatalogSeeder doc Perms.cs luc khoi dong).';
