import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_receive_entities.dart';

abstract interface class ReturnInstructionRepository {
  /// Danh sách chỉ thị back hàng kèm chi tiết dòng và SL thực nhận.
  ///
  /// SCS Office nhập phiếu bên Web; SCS WH xem ở đây rồi mở màn Nhận hàng để
  /// quét thùng + serial (mục 2a).
  Future<List<ReturnInstruction>> fetchList({ReturnDocStatus? status});

  /// Một phiếu, đọc lại để lấy SL thực nhận mới nhất.
  Future<ReturnInstruction> fetchById(int id);

  /// Nhận một pallet hàng return vào phiếu.
  ///
  /// Server cấp Pallet ID (hàng khách trả về không có nhãn in sẵn), tạo pallet
  /// mức serial và đăng ký toàn bộ serial vào sổ của phiếu trong cùng một
  /// transaction — thành công là cả hai, hỏng là không gì cả.
  Future<ReturnReceiveResult> receive({
    required int docId,
    required List<ReturnBoxDraft> boxes,
  });

  /// Chốt SL thực nhận (mục 2b): đóng phiếu và server tự gửi mail báo FA số
  /// thực tế kèm bảng lệch.
  ///
  /// Trả về phiếu sau khi chốt — `actualMailSentAt` cho biết mail đã đi chưa.
  Future<ReturnInstruction> close(int docId);

  // ── Mục 2d — FA đóng lại pallet sau rework ──────────────────────

  /// Sổ serial của phiếu, dạng gọn, để kiểm NGAY TRÊN MÁY lúc quét.
  Future<List<ReturnSerialIndexEntry>> fetchSerialIndex(int docId);

  /// FA đóng pallet mới. Gửi TOÀN BỘ serial đã quét — server đối chiếu lại,
  /// tự loại con không khớp và tự ghi nhật ký lệch.
  Future<FaPalletResult> createFaPallet({
    required int docId,
    required List<FaBoxDraft> boxes,
  });
}
