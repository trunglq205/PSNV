﻿
namespace SWMS_WebTool.Models
{
    public record CheckStorage
    {
        public double TotalTemp { get; set; }
        public double TotalStorage { get; set; }
        public double TotalQuantity { get; set; }
        public double QtyKitting { get; set; }
        public string Plant { get; set; }
        public string Material { get; set; }
        public string MaterialType { get; set; }
        public string MaterialFrequency { get; set; }
        public string Sloc { get; set; }
        public string Category { get; set; }
        public string LocationName { get; set; }
        public string PositionTemp { get; set; }
        public int Total { get; set; }
    }
}
