import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/model/data/model_detail_remote_data_source.dart';
import 'package:swms_finish_goods/features/model/data/model_detail_repository_impl.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_repository.dart';

part 'model_detail_providers.g.dart';

@riverpod
ModelDetailRemoteDataSource modelDetailRemoteDataSource(Ref ref) {
  return ModelDetailRemoteDataSource(ref.watch(dioProvider));
}

@riverpod
ModelDetailRepository modelDetailRepository(Ref ref) {
  return ModelDetailRepositoryImpl(
    ref.watch(modelDetailRemoteDataSourceProvider),
  );
}
