using Dapper;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Boxes;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Data;
using System.Linq;
using System.Text.Json;

namespace Swms.FinishGoods.API.Features.Pallets.DataAccess
{
    /// <summary>
    /// SQL / thao tác ghi dùng chung giữa LotRepository (SWMS) và PalletFossRepository
    /// (Foss/PalletSync). Internal: chỉ tầng DataAccess trong cùng project được dùng.
    /// </summary>
    internal static class PalletSqlShared
    {
        /// <summary>"Đã xuất cho khách" = có si_no và đã rời vị trí — cùng định nghĩa với màn Tồn kho.</summary>
        internal const string NotShippedSql =
            "NOT (NULLIF(LTRIM(RTRIM(l.si_no)), '') IS NOT NULL AND l.locator_id IS NULL)";

        /// <summary>
        /// Insert 1 box + toàn bộ line của nó. Dùng chung cho LotRepository.AddAsync và PalletFossRepository.AppendFossBoxesAsync
        /// để thùng bổ sung sau có đúng cùng shape với thùng lúc tạo.
        /// </summary>
        internal static async Task InsertBoxWithLinesAsync(
            IDbConnection conn, IDbTransaction tx, long lotId, Box box)
        {
            const string insertBox = """
                INSERT INTO wms.boxes
                    (lot_id, box_no, psnv_po, customer_po, line, model, oqc_status, lot_name, production_date, raw_payload,
                     is_deleted, created_at, created_by)
                VALUES
                    (@LotId, @BoxNo, @PsnvPo, @CustomerPo, @Line, @Model, @OQCStatus, @LotName, @ProductionDate, @RawPayload,
                     0, SYSDATETIME(), @CreatedBy);
                SELECT CAST(SCOPE_IDENTITY() AS bigint);
                """;

            // boxes.model: chỉ set khi box đúng 1 model; box đa model -> NULL (tra qua box_lines)
            var boxModel = box.Lines.Select(l => l.Model).Distinct().Count() == 1
                ? box.Lines[0].Model
                : null;

            var boxId = await conn.ExecuteScalarAsync<long>(insertBox, new
            {
                LotId = lotId,
                box.BoxNo,
                box.PsnvPo,
                box.CustomerPo,
                box.Line,
                Model = boxModel,
                box.OQCStatus,
                box.LotName,
                box.ProductionDate,
                box.RawPayload,
                box.CreatedBy
            }, tx);

            box.Id = boxId;
            box.LotId = lotId;

            await InsertLinesAsync(conn, tx, boxId, box.Lines);
        }

        internal static Task InsertLinesAsync(
            IDbConnection conn, IDbTransaction tx, long boxId, IEnumerable<BoxLine> lines)
        {
            const string insertLine = """
                INSERT INTO wms.box_lines
                    (box_id, model, qty, serial_no, production_date, carton_qty,
                     is_deleted, created_at, created_by)
                VALUES
                    (@BoxId, @Model, @Qty, @SerialNo, @ProductionDate, @CartonCount,
                     0, SYSDATETIME(), @CreatedBy);
                """;
            return conn.ExecuteAsync(insertLine,
                lines.Select(l => new
                {
                    BoxId = boxId,
                    l.Model,
                    l.Qty,
                    l.SerialNo,
                    l.ProductionDate,
                    l.CartonCount,
                    l.CreatedBy
                }), tx);
        }

    }
}
