/// Phiếu hàng bất thường — 1 dòng trong danh sách.
///
/// Luồng 4 bước: SCS tạo -> Leader SCS duyệt -> FA + OQC xác nhận song song
/// -> SCS supervisor chốt.
class NgReport {
  final int id;
  final String docNo;
  final String? palletCode;
  final String? model;
  final String ngType;
  final DateTime discoveredAt;

  /// draft | submitted | in_review | ready_to_finalize | finalized | cancelled
  final String docStatus;
  final String currentStep;

  final String leaderStatus;
  final String faStatus;

  /// replace | accept | return | scrap
  final String? faResolution;
  final String oqcStatus;
  final String resolution;

  /// FA đề xuất Accept nhưng OQC kết luận NG — phiếu dừng chờ FA chỉnh lại.

  final int itemCount;
  final int qtyAffected;

  /// Lỗi cả pallet ⟹ qtyAffected vô nghĩa, hiện chữ "cả pallet".
  final bool isWholePallet;
  final int photoCount;
  final String? createdBy;

  const NgReport({
    required this.id,
    required this.docNo,
    required this.ngType,
    required this.discoveredAt,
    required this.docStatus,
    required this.currentStep,
    required this.leaderStatus,
    required this.faStatus,
    required this.oqcStatus,
    required this.resolution,
    required this.itemCount,
    required this.qtyAffected,
    this.isWholePallet = false,
    required this.photoCount,
    this.palletCode,
    this.model,
    this.faResolution,
    this.createdBy,
  });

  bool get isDraft => docStatus == 'draft';
  bool get waitingFaOqc => docStatus == 'in_review' || docStatus == 'submitted';

  /// Luồng tuần tự: OQC kết luận trước, FA mới tới lượt chọn hướng xử lý.
  bool get waitingOqc => waitingFaOqc && oqcStatus == 'pending';
  bool get waitingFa =>
      waitingFaOqc && oqcStatus != 'pending' && faStatus != 'approved';
  bool get readyToFinalize => docStatus == 'ready_to_finalize';
  bool get isClosed => docStatus == 'finalized' || docStatus == 'cancelled';
}

/// Phạm vi ảnh hưởng: cả pallet, cả thùng, hoặc 1 dòng serial.
class NgItem {
  final int id;
  final String scope; // pallet | box | serial
  final String? code;
  final int qtyAffected;
  final String? note;

  const NgItem({
    required this.id,
    required this.scope,
    required this.qtyAffected,
    this.code,
    this.note,
  });
}

class NgPhoto {
  final int id;
  final String fileName;
  final String? caption;
  final int sortOrder;

  const NgPhoto({
    required this.id,
    required this.fileName,
    required this.sortOrder,
    this.caption,
  });
}

class NgApproval {
  final int id;
  final String step; // leader | fa | oqc | finalize
  final String action;
  final String? resolution;
  final String? comment;
  final String? actedBy;
  final DateTime actedAt;

  const NgApproval({
    required this.id,
    required this.step,
    required this.action,
    required this.actedAt,
    this.resolution,
    this.comment,
    this.actedBy,
  });
}

class NgDetail {
  final NgReport header;
  final String? description;

  final String? leaderBy;
  final DateTime? leaderAt;
  final String? leaderComment;

  final String? faBy;
  final DateTime? faAt;
  final String? faComment;

  final String? oqcBy;
  final DateTime? oqcAt;
  final String? oqcComment;

  final String? finalizedBy;
  final DateTime? finalizedAt;
  final String? finalComment;

  final String? cancelledBy;
  final DateTime? cancelledAt;
  final String? cancelReason;

  final List<NgItem> items;
  final List<NgPhoto> photos;
  final List<NgApproval> approvals;

  const NgDetail({
    required this.header,
    required this.items,
    required this.photos,
    required this.approvals,
    this.description,
    this.leaderBy,
    this.leaderAt,
    this.leaderComment,
    this.faBy,
    this.faAt,
    this.faComment,
    this.oqcBy,
    this.oqcAt,
    this.oqcComment,
    this.finalizedBy,
    this.finalizedAt,
    this.finalComment,
    this.cancelledBy,
    this.cancelledAt,
    this.cancelReason,
  });
}

/// 1 phạm vi ảnh hưởng người dùng thêm khi tạo phiếu (chưa gửi lên server).
class NgDraftItem {
  final String scope;
  final String? code;
  final int qtyAffected;
  final String? note;

  const NgDraftItem({
    required this.scope,
    this.code,
    this.qtyAffected = 1,
    this.note,
  });
}

/// Hằng số dùng chung cho màn tạo và màn duyệt.
class NgConst {
  static const resolutions = ['replace', 'accept', 'return', 'scrap'];

  static const scopes = ['pallet', 'box', 'serial'];

  const NgConst._();
}

/// Thông tin tóm tắt của pallet, trả về khi quét mã ở màn tạo phiếu.
/// Có đối tượng này nghĩa là mã CÓ trong hệ thống.
class NgPalletBrief {
  final int id;
  final String code;
  final String? model;
  final int? boxCount;
  final String? inspectionStatus;
  final bool isUrgent;
  final DateTime? productionDate;
  final String? locatorCode;
  final String? areaName;

  const NgPalletBrief({
    required this.id,
    required this.code,
    required this.isUrgent,
    this.model,
    this.boxCount,
    this.inspectionStatus,
    this.productionDate,
    this.locatorCode,
    this.areaName,
  });
}

/// Một loại lỗi lấy từ master.ng_types qua API. [name] và [note] đã được API
/// dịch theo ngôn ngữ đang chọn, nên màn hình cứ hiện thẳng — không còn tra
/// khoá dịch theo mã, và thêm loại lỗi mới không phải build lại app.
class NgType {
  final String code;
  final String name;
  final String? note;
  final bool requiresOqc;

  const NgType({
    required this.code,
    required this.name,
    this.note,
    this.requiresOqc = true,
  });
}
