/* ============================================================================
   SOÁT GÁN QUYỀN MÀN TÁI GIA CÔNG  (rework_refurbish)
   ----------------------------------------------------------------------------
   CHỈ ĐỌC. Không INSERT / UPDATE / DELETE một dòng nào — chạy được trên PROD.

   Vì sao cần: luồng tái gia công đi qua NĂM bên (SCS Office · SCS WH · FA ·
   QL FA · QL SCS) và được tách bằng QUYỀN, không bằng cột users.department
   (ICurrentUser và JWT đều không mang department). Nên "FA chỉ làm được step
   của FA" phụ thuộc hoàn toàn vào việc GÁN QUYỀN đúng — không có lớp chặn thứ
   hai nào đỡ cho việc gán sai.

   Script này tìm ra chỗ gán sai. Chạy cả 5 phần, đọc từ PHẦN 3 trở xuống.

   MA TRẬN ĐÚNG — mỗi bên GIỮ ĐÚNG phần của mình:

     Bộ phận      │ Quyền được gán                 │ Làm được gì
     ─────────────┼────────────────────────────────┼──────────────────────────
     SCS Office   │ view, create                   │ tạo/sửa/xoá phiếu,
                  │                                │ chốt thực nhận (trên Web)
     SCS WH       │ view, process                  │ quét nhận hàng, chốt thực
                  │                                │ nhận (trên PDA), giao
                  │                                │ hàng cho FA
     FA           │ view, request_back             │ đề nghị nhận lại hàng
     QL FA        │ view, approve_fa               │ xác nhận đề nghị
     FA (rework)  │ view, process_fa               │ quét tạo lại Pallet ID
     ─────────────┴────────────────────────────────┴──────────────────────────

   KHÔNG GÁN cho ai: approve, print, approve_scs — ba lá này không còn endpoint
   nào dùng (xem chú thích trong Perms.cs). Gán vào chỉ gây hiểu nhầm.

   ⚠ view thì mọi bên đều cần — nó chỉ cho XEM, không cho thao tác gì.
   ⚠ create và process là CỦA SCS. Gán một trong hai cho role có người FA là
     FA chốt thực nhận được — đúng lỗi đang gặp.
============================================================================ */

SET NOCOUNT ON;

DECLARE @screen sysname = N'rework_refurbish';

/* Phân loại từng lá theo bên sở hữu — dùng lại ở các phần dưới. */
DECLARE @own TABLE (
    action  varchar(50)  PRIMARY KEY,
    side    varchar(10),              -- SCS | FA | -
    owner   nvarchar(50),
    note    nvarchar(100)
);
INSERT INTO @own (action, side, owner, note) VALUES
    ('view',         '-',   N'mọi bộ phận', N'chỉ cho xem, không thao tác'),
    ('create',       'SCS', N'SCS Office',  N'tạo/sửa/xoá + chốt thực nhận'),
    ('process',      'SCS', N'SCS WH',      N'quét nhận hàng + giao hàng'),
    ('request_back', 'FA',  N'FA',          N'đề nghị nhận lại hàng'),
    ('approve_fa',   'FA',  N'QL FA',       N'xác nhận đề nghị'),
    ('process_fa',   'FA',  N'FA',          N'quét tạo lại Pallet ID'),
    ('approve',      '-',   N'(không ai)',  N'KHÔNG CÒN DÙNG — đừng gán'),
    ('print',        '-',   N'(không ai)',  N'KHÔNG CÒN DÙNG — đừng gán'),
    ('approve_scs',  '-',   N'(không ai)',  N'ĐÃ BỎ — đừng gán');

/* Các lá đang có trong DB. Lấy qua code = '<screen>.<action>' nên không phụ
   thuộc cột nào của master.permission_screens. */
DECLARE @perm TABLE (
    id      int PRIMARY KEY,
    action  varchar(50),
    code    varchar(100)
);
INSERT INTO @perm (id, action, code)
SELECT  p.id,
        CAST(RIGHT(p.code, LEN(p.code) - LEN(@screen) - 1) AS varchar(50)),
        CAST(p.code AS varchar(100))
FROM    master.permissions p
WHERE   p.is_deleted = 0
        AND p.code LIKE @screen + '.%';

IF NOT EXISTS (SELECT 1 FROM @perm)
BEGIN
    PRINT N'!! Khong thay la quyen nao cua man ' + @screen + N'.';
    PRINT N'   PermissionCatalogSeeder chay luc khoi dong API — hay chay API mot lan roi chay lai script nay.';
    RETURN;
END

PRINT N'=== 1. Cac la quyen cua man dang co trong DB ===';
SELECT  pm.code                          AS [Code],
        ISNULL(o.owner, N'?? KHONG BIET') AS [Thuoc ben],
        ISNULL(o.note,  N'lá lạ — không có trong Perms.cs') AS [Y nghia]
FROM    @perm pm
LEFT JOIN @own o ON o.action = pm.action
ORDER BY CASE ISNULL(o.side, 'z') WHEN 'SCS' THEN 1 WHEN 'FA' THEN 2 ELSE 3 END,
         pm.action;

/* ---------------------------------------------------------------------------
   2. Ma tran role × quyen: role nao dang giu gi.
--------------------------------------------------------------------------- */
PRINT N'';
PRINT N'=== 2. Role nao dang giu quyen gi tren man nay ===';

SELECT  r.code                                   AS [Role],
        r.name                                   AS [Ten role],
        COUNT(DISTINCT ur.user_id)               AS [So user],
        STUFF((SELECT N', ' + pm2.action
               FROM   master.role_permissions rp2
               JOIN   @perm pm2 ON pm2.id = rp2.permission_id
               WHERE  rp2.role_id = r.id
               ORDER BY pm2.action
               FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'')
                                                 AS [Quyen dang giu]
FROM    master.roles r
JOIN    master.role_permissions rp ON rp.role_id = r.id
JOIN    @perm pm                   ON pm.id      = rp.permission_id
LEFT JOIN master.user_roles ur     ON ur.role_id = r.id
WHERE   r.is_deleted = 0
GROUP BY r.id, r.code, r.name
ORDER BY r.code;

/* ---------------------------------------------------------------------------
   3. ROLE GIU QUYEN CUA CA HAI BEN.
      Mot role vua co quyen SCS vua co quyen FA la mot nguoi gom duoc nhieu
      buoc lien nhau — dung muc dich cua viec tach moi buoc mot quyen.
--------------------------------------------------------------------------- */
PRINT N'';
PRINT N'=== 3. [CANH BAO] Role giu quyen CUA CA HAI BEN SCS va FA ===';

;WITH g AS (
    SELECT  r.id, r.code, r.name,
            MAX(CASE WHEN o.side = 'SCS' THEN 1 ELSE 0 END) AS has_scs,
            MAX(CASE WHEN o.side = 'FA'  THEN 1 ELSE 0 END) AS has_fa
    FROM    master.roles r
    JOIN    master.role_permissions rp ON rp.role_id = r.id
    JOIN    @perm pm                   ON pm.id      = rp.permission_id
    JOIN    @own  o                    ON o.action    = pm.action
    WHERE   r.is_deleted = 0
    GROUP BY r.id, r.code, r.name
)
SELECT  g.code AS [Role], g.name AS [Ten role],
        STUFF((SELECT N', ' + pm2.action + N' (' + o2.owner + N')'
               FROM   master.role_permissions rp2
               JOIN   @perm pm2 ON pm2.id    = rp2.permission_id
               JOIN   @own  o2  ON o2.action = pm2.action
               WHERE  rp2.role_id = g.id AND o2.side <> '-'
               ORDER BY o2.side, pm2.action
               FOR XML PATH(''), TYPE).value('.', 'nvarchar(max)'), 1, 2, N'')
                                                 AS [Dang giu ca hai ben],
        N'Tach role nay thanh role SCS va role FA rieng' AS [Nen lam]
FROM    g
WHERE   g.has_scs = 1 AND g.has_fa = 1
ORDER BY g.code;

IF @@ROWCOUNT = 0 PRINT N'   OK — khong co role nao giu quyen ca hai ben.';

/* ---------------------------------------------------------------------------
   4. LECH BO PHAN: user bo phan X nhung giu quyen cua ben Y.
      Day la cho tim ra loi "user FA co quyen view create process".
      Doi chieu users.department voi ben so huu tung la.
--------------------------------------------------------------------------- */
PRINT N'';
PRINT N'=== 4. [CANH BAO] User giu quyen KHONG PHAI cua bo phan minh ===';

SELECT DISTINCT
        u.employee_code                  AS [Ma NV],
        u.full_name                      AS [Ho ten],
        u.department                     AS [Bo phan],
        r.code                           AS [Qua role],
        pm.code                          AS [Quyen],
        o.owner                          AS [La cua ben],
        CASE
          WHEN u.department = 'FA'  AND o.side = 'SCS'
            THEN N'Nguoi FA dang lam duoc viec cua SCS — BO quyen nay'
          WHEN u.department = 'SCS' AND o.side = 'FA'
            THEN N'Nguoi SCS dang lam duoc viec cua FA — BO quyen nay'
          ELSE N'Bo phan ' + u.department + N' khong co viec gi trong luong nay — BO quyen nay'
        END                              AS [Van de]
FROM    master.users u
JOIN    master.user_roles ur       ON ur.user_id = u.id
JOIN    master.roles r             ON r.id       = ur.role_id AND r.is_deleted = 0
JOIN    master.role_permissions rp ON rp.role_id = r.id
JOIN    @perm pm                   ON pm.id      = rp.permission_id
JOIN    @own  o                    ON o.action    = pm.action
WHERE   u.is_deleted = 0
        AND o.side <> '-'                       -- view thi ai cung duoc
        AND (   (u.department = 'FA'  AND o.side = 'SCS')
             OR (u.department = 'SCS' AND o.side = 'FA')
             OR  u.department NOT IN ('SCS', 'FA') )
ORDER BY u.department, u.employee_code, pm.code;

IF @@ROWCOUNT = 0 PRINT N'   OK — khong co user nao giu quyen cua ben khac.';

/* ---------------------------------------------------------------------------
   5. BA LA KHONG CON DUNG ma van duoc gan cho role nao.
--------------------------------------------------------------------------- */
PRINT N'';
PRINT N'=== 5. [CANH BAO] Quyen da bo nhung van con gan ===';

SELECT  r.code AS [Role], r.name AS [Ten role], pm.code AS [Quyen],
        o.note AS [Tinh trang],
        N'Bo gan — khong endpoint nao dung, gan vao chi gay hieu nham' AS [Nen lam]
FROM    master.roles r
JOIN    master.role_permissions rp ON rp.role_id = r.id
JOIN    @perm pm                   ON pm.id      = rp.permission_id
JOIN    @own  o                    ON o.action    = pm.action
WHERE   r.is_deleted = 0
        AND pm.action IN ('approve', 'print', 'approve_scs')
ORDER BY r.code, pm.action;

IF @@ROWCOUNT = 0 PRINT N'   OK — khong role nao giu ba la da bo.';

PRINT N'';
PRINT N'=== Xong. Sua gan quyen o man /roles tren Web, khong UPDATE tay vao master.role_permissions ===';
PRINT N'   (man /roles gio da hien ten bo phan cho tung quyen — khong con doan nhu truoc)';
