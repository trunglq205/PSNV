import 'dart:io';

import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/container_check/data/models/container_model.dart';

part 'container_check_remote_data_source.g.dart';

@RestApi()
abstract class ContainerCheckRemoteDataSource {
  factory ContainerCheckRemoteDataSource(Dio dio, {String baseUrl}) =
      _ContainerCheckRemoteDataSource;

  @GET('/containers')
  Future<List<ContainerModel>> fetchContainers();

  @GET('/containers/by-no/{containerNo}')
  Future<ContainerModel> fetchByContainerNo(
    @Path('containerNo') String containerNo,
  );

  @GET('/containers/{id}')
  Future<ContainerModel> fetchDetail(@Path('id') int id);

  @POST('/containers/{id}/inspection')
  Future<void> submitInspection(
    @Path('id') int id,
    @Body() ContainerInspectionRequest body,
  );

  /// Ảnh gửi sau khi chốt kết quả: kết quả không bị chặn vì mạng chậm lúc
  /// up ảnh ngoài bãi. [slots] cùng thứ tự với [files].
  @POST('/containers/{id}/inspection/photos')
  @MultiPart()
  Future<void> uploadPhotos(
    @Path('id') int id,
    @Part(name: 'slots') List<String> slots,
    @Part(name: 'files') List<File> files,
  );
}
