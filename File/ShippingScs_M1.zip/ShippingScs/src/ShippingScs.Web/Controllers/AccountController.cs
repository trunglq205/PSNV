using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShippingScs.Web.Models;
using ShippingScs.Web.Services;

namespace ShippingScs.Web.Controllers;

public class AccountController : Controller
{
    private readonly UserService _users;

    public AccountController(UserService users) => _users = users;

    [AllowAnonymous, HttpGet]
    public IActionResult Login(string? returnUrl) => View(new LoginModel { ReturnUrl = returnUrl });

    [AllowAnonymous, HttpPost]
    public async Task<IActionResult> Login(LoginModel model)
    {
        if (!ModelState.IsValid) return View(model);

        var user = await _users.ValidateLoginAsync(model.UserName, model.Password);
        if (user == null)
        {
            ModelState.AddModelError("", "Sai tên đăng nhập hoặc mật khẩu, hoặc tài khoản đã bị khoá.");
            model.Password = "";
            return View(model);
        }

        await HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme,
            UserService.ToPrincipal(user));

        // Chỉ cho quay lại URL nội bộ (chặn open redirect)
        if (!string.IsNullOrEmpty(model.ReturnUrl) && Url.IsLocalUrl(model.ReturnUrl))
            return Redirect(model.ReturnUrl);
        return RedirectToAction("Index", "Home");
    }

    [HttpPost]
    public async Task<IActionResult> Logout()
    {
        await HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
        return RedirectToAction(nameof(Login));
    }

    [AllowAnonymous]
    public IActionResult AccessDenied() => View();
}
