namespace Swms.FinishGoods.API.Features.MapDesigner;

/// <summary>
/// Khối trên bản đồ — DÙNG CHUNG cho mọi loại map (storing/receiving/vanning).
/// Ánh xạ 1-1 với master.locator_map. Kind quyết định cột nào có giá trị:
///   rack   -> RackId + RackCode (locator con nằm trong rack, không vẽ riêng)
///   pallet -> LocatorId + LocatorCode (1 ô = 1 vị trí pallet)
///   zone   -> chỉ Label + Color (khối trang trí: cột, thang máy, máy quấn màng...)
/// </summary>
public class MapBlock
{
    public long? Id { get; set; }                 // id trong locator_map (null = block mới)
    public string Kind { get; set; } = "zone";    // rack | pallet | zone

    public long? RackId { get; set; }
    public string? RackCode { get; set; }
    public int? RackRows { get; set; }            // số tầng (chỉ hiển thị)
    public int? RackCols { get; set; }            // số vị trí (chỉ hiển thị)

    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string? CurrentStatus { get; set; }    // empty|not_inspected|pass|ng... (chỉ hiển thị)

    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; } = 1;
    public int GridH { get; set; } = 1;

    public string? Label { get; set; }
    public string? Color { get; set; }
    public string? Arrow { get; set; }            // up|down|left|right
    public int SortOrder { get; set; }
}

/// <summary>Toàn bộ layout 1 bản đồ để vẽ trong Map Designer.</summary>
public class MapLayout
{
    public long AreaId { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public string MapType { get; set; } = "storing";
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public List<MapBlock> Blocks { get; set; } = new();
}

/// <summary>Tham số tạo rack mới (rack sinh ra locator con theo tầng × vị trí).</summary>
public class CreateRackInput
{
    public string RackCode { get; set; } = string.Empty;
    public string? RackName { get; set; }
    public int Positions { get; set; } = 4;       // số vị trí (cột)
    public int Floors { get; set; } = 4;          // số tầng (hàng)
    public int[] ShelfPositions { get; set; } = Array.Empty<int>(); // vị trí có giá lửng
    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; } = 4;
    public int GridH { get; set; } = 2;
}
