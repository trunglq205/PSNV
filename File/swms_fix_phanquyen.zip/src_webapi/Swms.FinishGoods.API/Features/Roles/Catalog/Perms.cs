﻿using System.Security;

namespace Swms.FinishGoods.Api.Features.Roles.Catalog;

/// <summary>
/// ★ NGUỒN SỰ THẬT DUY NHẤT của toàn bộ phân quyền hệ thống. ★
///
/// Cấu trúc 3 tầng record lồng nhau:  Module → Screen → Permission(action).
/// PermissionCatalog đọc cây này bằng reflection — KHÔNG generator, KHÔNG file sinh ra.
///
/// Quy ước tên → code (PascalCase → snake_case):
///   • Module   record "Receiving"   → module code  "receiving"
///   • Screen   record "RecvPallet"  → screen code   "recv_pallet"
///   • Action   record "View"        → action "view", permission code "recv_pallet.view"
///
/// ⚠ Vì convert tách theo chữ HOA: muốn ra "abnormal-report" thì đặt tên "Cartonng"
///   (KHÔNG "CartonNg" — cái đó ra "abnormal-report"). Đặt tên nhất quán PascalCase.
///
/// Thêm/bớt quyền: CHỈ sửa cây này. Dùng để enforce:
///   [RequirePermission&lt;Perms.Receiving.Asn.Create&gt;]   ← strongly-typed, gõ sai compiler báo.
///
/// Tên hiển thị KHÔNG đặt ở đây — tra resx theo convention key từ code:
///   module → "Perm.Module.{code}" · screen → "Perm.Screen.{code}" · perm → "Perm.Item.{code}"
/// </summary>
public static class Perms
{
    public static class Pda
    {
        public static class PdaReceiving { public sealed class Receive;public sealed class AbnormalReport; public sealed class TempLocation; }
        public static class PdaStorage { public sealed class Putaway; public sealed class Move; public sealed class StocktakeMorning; public sealed class StocktakeShipment; public sealed class StocktakeMonthly { } }
        public static class PdaOutbound { public sealed class ShippingInstructions; public sealed class Pick; public sealed class Tally; public sealed class EmapKitting; }
        public static class PdaShipping { public sealed class Vanning; public sealed class Container; public sealed class Stowage; }
    }

    public static class Receiving
    {
        public static class PartCard { public sealed class View; public sealed class Print; public sealed class Delete; public sealed class Lock; public sealed class Unlock; }
        public static class RecvPallet { public sealed class View; public sealed class Scan; public sealed class Undo; public sealed class Force; }
        public static class Temploc { public sealed class View; public sealed class Assign; public sealed class Release; public sealed class Edit; }
        public static class OQC { public sealed class Sample; public sealed class Return; }
        public static class Stocky { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Delete; public sealed class Transfer; }
        /// <summary>
        /// Hàng bất thường — luồng 5 bước, MỖI BƯỚC MỘT QUYỀN RIÊNG để một người
        /// không gánh được hai bước liền nhau:
        ///   B1 SCS tạo phiếu            → create
        ///   B2 Leader SCS duyệt/huỷ     → leader_review
        ///   B3 OQC kết luận             → oqc_confirm
        ///   B4 FA chọn hướng xử lý      → fa_confirm
        ///   B5 SCS Supervisor chốt      → finalize
        /// ⚠ Tên lớp viết PascalCase TỪNG CHỮ: Snake() chèn '_' trước mọi chữ hoa,
        ///   nên "OqcConfirm" ra oqc_confirm, còn "OQCConfirm" ra o_q_c_confirm.
        /// ⚠ Hai quyền gộp cũ (process, approve) đã BỎ — xem db/ng_perms_split.sql.
        ///   Đừng khai lại đúng tên cũ: seeder MERGE theo code sẽ bật is_deleted về 0
        ///   và làm sống lại quyền của mọi role từng được gán.
        /// </summary>
        public static class AbnormalReport
        {
            public sealed class View;
            public sealed class Create;
            public sealed class LeaderReview;
            public sealed class OqcConfirm;
            public sealed class FaConfirm;
            public sealed class Finalize;
            public sealed class Print;

            /// <summary>
            /// Quản trị danh mục loại lỗi (master.ng_types). Tách riêng khỏi 5
            /// quyền duyệt: người duyệt phiếu không đương nhiên được sửa danh mục,
            /// vì đổi cờ requires_oqc là đổi luồng duyệt của mọi phiếu sau đó.
            /// </summary>
            public sealed class ManageTypes;
        }
        // MỖI BƯỚC MỘT QUYỀN RIÊNG — cùng khuôn với AbnormalReport ở trên.
        //
        // Luồng tái gia công đi qua NĂM bên, không phải hai: SCS Office ·
        // SCS WH · quản lý SCS · FA · quản lý FA. Tách bằng quyền chứ không
        // bằng cột users.department, vì ICurrentUser không có department và
        // JWT cũng không có claim đó.
        //
        // ⚠ PermissionCatalogSeeder MERGE theo code và set lại is_deleted = 0:
        // xoá một lá ở đây rồi khai lại đúng tên cũ sẽ LÀM SỐNG LẠI quyền của
        // mọi role từng được gán. Muốn bỏ thật thì chạy script như
        // db/ng_perms_split.sql, đừng sửa bằng tay ở đây.
        public static class ReworkRefurbish
        {
            public sealed class View;
            public sealed class Create;
            public sealed class Process;
            public sealed class Approve;
            public sealed class Print;

            /// <summary>Mục 2c B1 — FA tạo đề nghị nhận lại hàng.</summary>
            public sealed class RequestBack;

            /// <summary>Mục 2c B2 — quản lý FA xác nhận đề nghị.</summary>
            public sealed class ApproveFa;

            /// <summary>
            /// Mục 2c B3 — quản lý SCS duyệt cho back. ĐANG DÙNG THẬT từ
            /// 10/11: gác <c>POST {id}/approve-back-scs</c>, và từ 11/11 là
            /// điều kiện để hàng được out kho sang vị trí nhận hàng (tức giao
            /// cho FA). Chưa duyệt thì pallet chỉ chuyển nội bộ trong kho.
            ///
            /// PHẢI GÁN cho tài khoản quản lý SCS, nếu không luồng back hàng
            /// đứng ở bước 3 không ai đi tiếp được.
            ///
            /// (Chú thích cũ ghi "không còn endpoint nào dùng / đừng gán" là từ
            /// bản thiết kế trước, lúc bước duyệt của quản lý SCS bị cắt. Bước
            /// đó đã được thêm lại ngày 10/11.)
            /// </summary>
            public sealed class ApproveScs;

            /// <summary>
            /// Mục 2d — FA quét tạo lại Pallet ID sau khi rework xong.
            ///
            /// Khai ở đây vì ReturnFaPalletsController.cs ĐANG CÓ trên source
            /// và dùng tới nó: thiếu lá này là file đó không biên dịch được.
            /// </summary>
            public sealed class ProcessFa;
        }
    }

    public static class Storage
    {
        public static class Putaway { public sealed class View; public sealed class Execute; public sealed class Override; }
        public static class Map { public sealed class View; public sealed class Detail; public sealed class Edit; }
        public static class Inventory { public sealed class View; public sealed class Value; public sealed class Export; }
        public static class Stocktake { public sealed class View; public sealed class Create; public sealed class Assign; public sealed class Count; public sealed class Recount; public sealed class Approve; public sealed class Cancel; }
        public static class Balance { public sealed class View; public sealed class Create; public sealed class Approve; }
    }

    public static class Outbound
    {
        public static class Si { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Completed; public sealed class Delete; public sealed class Cancel;  public sealed class Cut; public sealed class Allocate; public sealed class Print; public sealed class Pick;  }
        public static class Trip { public sealed class View; public sealed class Create; public sealed class Update; public sealed class ChangeStatus; public sealed class Delete; public sealed class PhotoUpload; public sealed class Inspect; public sealed class Merge; public sealed class Stow; }
        public static class Picking { public sealed class View; public sealed class Execute; public sealed class Reassign; public sealed class Confirm; }
        public static class Shortage { public sealed class View; public sealed class Request; public sealed class ConfirmEta; }
        public static class Serial { public sealed class View; public sealed class Scan; public sealed class Remove; }
    }

    public static class Shipping
    {
        public static class Vanning { public sealed class View; public sealed class Execute; public sealed class Update; }
        public static class Container { public sealed class View; public sealed class Inspect; public sealed class Seal; public sealed class Gateout; }
        public static class Stowage { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Approve; }
    }

    public static class Analytics
    {
        public static class Reports { public sealed class View; public sealed class Export; public sealed class Schedule; }
        public static class Audit { public sealed class View; public sealed class Export; }
    }

    public static class System
    {
        public static class Models { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Delete; public sealed class Import; }
        public static class Master { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Delete; public sealed class Import; }
        public static class Users { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Lock; public sealed class ResetPwd; public sealed class Delete; }
        public static class Roles { public sealed class View; public sealed class Create; public sealed class Update; public sealed class AssignUser; public sealed class Delete; }
        public static class Settings { public sealed class View; public sealed class Update; public sealed class Integration; }
        public static class PdaApp { public sealed class View; public sealed class Publish; }
        public static class EmailConfig { public sealed class View;  public sealed class Update;  }
    }
}