import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/create_lot_params.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_history_entry.dart';
import 'package:swms_finish_goods/features/receiving/domain/repositories/receiving_history_repository.dart';
import 'package:swms_finish_goods/features/receiving/domain/repositories/receiving_repository.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/category_providers.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/receiving_providers.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/receiving_state.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'receiving_notifier.g.dart';

@riverpod
class ReceivingNotifier extends _$ReceivingNotifier
    with BaseNotifierMixin<ReceivingState> {
  ReceivingRepository get _repo => ref.read(receivingRepositoryProvider);

  ReceivingHistoryRepository get _historyRepo =>
      ref.read(receivingHistoryRepositoryProvider);

  @override
  ReceivingState build() {
    // Nạp bản nháp (nếu còn hạn) ngay khi mở màn — đọc local nên rất nhanh,
    // không cần đưa state sang async.
    _loadHistory();
    return const ReceivingState();
  }

  Future<void> _loadHistory() async {
    final entry = await _historyRepo.read();
    if (entry == null) return;
    state = state.copyWith(historyEntry: entry);
  }

  // ── Điều hướng bước / mode ──────────────────────────────
  void goStep(int number) {
    state = state.copyWith(step: ReceivingStepX.fromNumber(number));
  }

  void setMode(ReceivingMode mode) {
    state = state.copyWith(mode: mode);
  }

  // ── Dispatcher: quét chung, định tuyến theo bước + mode ──
  Future<void> onScan(String raw) async {
    await ref.read(appActionProvider.notifier).run(() async {
      switch (state.step) {
        case ReceivingStep.scan:
          switch (state.mode) {
            case .box:
              state = state.copyWith(partCards: []);
              await _onBoxScanned(raw);
            case .model:
              state = state.copyWith(clearModel: true, serials: []);
              await _onModelScanned(raw);
            case .gtin:
              state = state.copyWith(clearModel: true);
              await _onGTINScanned(raw);
          }
        case ReceivingStep.confirm:
          switch (state.mode) {
            case .box:
              await _onBoxScanned(raw);
            case .model:
              _onSerialScanned(raw);
            case .gtin:
              await _onGTINScanned(raw);
          }
        case ReceivingStep.scanPallet:
          _onPalletScanned(raw);
      }
    });
  }

  // ── Mode: box — quét thùng, đối chiếu, sang bước confirm ─
  Future<void> _onBoxScanned(String barcode) async {
    // Danh mục lỗi → throw, appActionProvider hiện lỗi; quét lại = thử lại.
    final card = PartCard.fromPayload(barcode, await ref.readCategories());

    if (state.partCards.any((e) => e.cardId == card.cardId)) {
      throw const DuplicateCartonException();
    }

    final firstCategory = state.partCards.firstOrNull?.category;

    if (firstCategory != null && firstCategory != card.category) {
      throw const NotDuplicateCategoryException();
    }

    state = state.copyWith(
      category: card.category,
      partCards: [card, ...state.partCards],
      step: ReceivingStep.confirm,
    );
  }

  void onRemoveCarton(int index) {
    // Copy trước khi removeAt — sửa list gốc thì copyWith không nhận ra thay đổi.
    final newPartCards = [...state.partCards]..removeAt(index);
    state = state.copyWith(
      partCards: newPartCards,
      step: newPartCards.isEmpty ? ReceivingStep.scan : ReceivingStep.confirm,
    );
  }

  // ── Mode: model — quét model rồi quét từng mã hộp ────────
  Future<void> _onModelScanned(String raw) async {
    final info = await _repo.getModelInfo(raw);
    state = state.copyWith(modelInfo: info, step: ReceivingStep.confirm);
  }

  void _onSerialScanned(String raw) {
    final code = raw.trim().toUpperCase();
    if (code.isEmpty) return;
    if (state.serials.contains(code)) {
      throw const DuplicateCartonException(); // mã hộp trùng trong cùng lot
    }

    final firstSerial = state.serials.firstOrNull;

    if (firstSerial != null && firstSerial.length != raw.length) {
      throw const NotDuplicateModelException();
    }

    state = state.copyWith(serials: [...state.serials, code]);
  }

  void onSerialRemoved(int index) {
    final next = [...state.serials]..removeAt(index);
    state = state.copyWith(serials: next);
  }

  // ── Mode: gtin — quét mã GTIN trên thùng, đếm số thùng ───
  Future<void> _onGTINScanned(String raw) async {
    if (state.modelInfo == null || state.boxCount == 0) {
      final info = await _repo.getModelInfoByGTIN(raw);
      state = state.copyWith(
        modelInfo: info,
        boxCount: 1,
        step: ReceivingStep.confirm,
      );
      return;
    }

    if (state.modelInfo?.gtin != raw) {
      throw const ModelNotMatchException();
    }

    final code = raw.trim().toUpperCase();
    if (code.isEmpty) return;
    state = state.copyWith(boxCount: state.boxCount + 1);
  }

  void onBoxCountChanged(int count) {
    state = state.copyWith(boxCount: count.clamp(1, 99));
  }

  void onStdPackChanged(int value) {
    state = state.copyWith(stdPackOverride: value.clamp(1, 9999));
  }

  // ── Lịch sử quét ────────────────────────────────────────
  /// Back khỏi bước confirm + LƯU bản nháp (ghi đè bản cũ).
  Future<void> saveDraftAndBackToScan() async {
    final entry = ReceivingHistoryEntry(
      savedAt: DateTime.now(),
      mode: state.mode,
      modelName: state.mode == ReceivingMode.box
          ? state.partCards.firstOrNull?.model
          : state.modelInfo?.model,
      cardPayloads: state.partCards.map((e) => e.payload).toList(),
      modelInfo: state.modelInfo,
      boxCount: state.boxCount,
      stdPackOverride: state.stdPackOverride,
      serials: state.serials,
    );

    await _historyRepo.save(entry);
    state = ReceivingState(historyEntry: entry);
  }

  /// Back khỏi bước confirm, KHÔNG lưu. Bản nháp cũ (nếu có) giữ nguyên.
  void backToScanWithoutSaving() {
    state = ReceivingState(historyEntry: state.historyEntry);
  }

  /// Phục hồi phiên quét dở, quay lại bước confirm.
  Future<void> restoreFromHistory() async {
    final entry = state.historyEntry;
    if (entry == null) return;

    await ref.read(appActionProvider.notifier).run(() async {
      // fromPayload có validate → payload hỏng sẽ throw, appActionProvider
      // bắt và hiện lỗi thay vì crash màn hình.
      final cards = <PartCard>[];
      if (entry.mode == ReceivingMode.box) {
        final categories = await ref.readCategories();
        cards.addAll(
          entry.cardPayloads.map((p) => PartCard.fromPayload(p, categories)),
        );
      }

      state = ReceivingState(
        step: ReceivingStep.confirm,
        mode: entry.mode,
        partCards: cards,
        modelInfo: entry.modelInfo,
        boxCount: entry.boxCount,
        stdPackOverride: entry.stdPackOverride,
        serials: entry.serials,
        historyEntry: entry,
      );
    });
  }

  /// User chủ động xóa bản nháp ở bước scan.
  Future<void> clearHistory() async {
    await _historyRepo.clear();
    state = state.copyWith(clearHistory: true);
  }

  // ── Bước 2 → 3: sang bước quét/nhập số pallet (lotNo) ────
  Future<void> confirmPallet() async {
    state = state.copyWith(clearLot: true, step: .scanPallet);
  }

  // ── Bước 3: chọn quét nhãn có sẵn / tự in nhãn mới ───────
  void setPalletIdSource(PalletIdSource source) {
    if (source == state.palletIdSource) return;
    state = state.copyWith(
      palletIdSource: source,
      // Chuyển sang tự in → bỏ mã đã quét để không tạo nhầm theo nhãn cũ.
      clearLot: source == PalletIdSource.printNew,
    );
  }

  // ── Bước 3: quét nhãn pallet → đây chính là lotNo ────────
  void _onPalletScanned(String raw) {
    final code = raw.trim();
    if (code.isEmpty) return;
    // Có nhãn để quét tức là pallet đã có nhãn → tự về chế độ quét,
    // kể cả khi user đang chọn "Tự in".
    state = state.copyWith(
      lotNo: code,
      palletIdSource: PalletIdSource.scanExisting,
    );
  }

  // ── Lưu: tạo lot (active ngay, không còn bước confirm) ───
  /// Trả lotNo vừa tạo (null = lỗi, appActionProvider đã hiện thông báo).
  Future<String?> submit() async {
    final lotNo = await ref.read(appActionProvider.notifier).run(() async {
      final params = await _buildCreateLotParams()
        ..validate();
      await _repo.createLot(params);
      return params.lotNo;
    });

    // In/tạo lot xong thì bản nháp không còn ý nghĩa.
    if (lotNo != null) await _historyRepo.clear();

    return lotNo;
  }

  /// lotNo + stockyCode cho bước tạo lot.
  /// - PAP: server cấp lotNo, giá trị quét là mã stocky.
  /// - Tự in nhãn: server cấp lotNo theo category.
  /// - Quét nhãn có sẵn: lotNo = giá trị quét.
  Future<({String lotNo, String? stockyCode})> _resolveLotNo() async {
    if (!state.usesAutoLotNo) {
      return (lotNo: state.lotNo ?? '', stockyCode: null);
    }

    final code = state.categoryCode;
    if (code == null) throw const NoModelInfoException();

    final next = (await _repo.getNextLotNo(code)).lotNo;
    return (lotNo: next, stockyCode: state.isPap ? state.lotNo ?? '' : null);
  }

  /// Dựng params theo mode + dữ liệu đã quét.
  ///
  /// Khi làm màn stocky: thêm `stockyCode` vào [ReceivingState] rồi truyền
  /// xuống kèm `lotType: LotType.stocky` (thiếu → API trả
  /// `Lot.StockyCodeRequired`).
  Future<CreateLotParams> _buildCreateLotParams() async {
    final info = state.modelInfo;

    if (state.mode == .box) {
      if (state.partCards.isEmpty) {
        throw const NoPartCardException();
      }
    } else {
      if (info == null) {
        throw const NoModelInfoException();
      }
    }

    final isPapVn = state.isPap;
    final (:lotNo, :stockyCode) = await _resolveLotNo();

    return switch (state.mode) {
    // Card có serial → dùng detailLevel .serial; hiện card chỉ có model+qty.
          .box => CreateLotParams.fromCards(
        lotNo: lotNo,
        stockyCode: stockyCode,
        cards: state.partCards,
        detailLevel: .boxLine,
        isEvenLot: info?.standardPallet == state.partCards.length,
        lotType: isPapVn ? .stocky : .pallet,
      ),
          .model => CreateLotParams.fromModelSerials(
        lotNo: lotNo,
        lotType: isPapVn ? .stocky : .pallet,
        stockyCode: stockyCode ?? state.stockyCode,
        modelInfo: info!,
        isEvenLot: info.standardPallet == state.partCards.length,
        productionDate: DateTime.now(),
        serials: state.serials,
      ),
    // box_count: model + productionDate lưu thẳng vào pallets.
          .gtin => CreateLotParams.fromModelBoxCount(
        lotNo: lotNo,
        modelInfo: info!.copyWith(standardPacking: state.effectiveStdPack),
        boxCount: state.boxCount,
        productionDate: DateTime.now(),
      ),
    };
  }

  /// Reset toàn bộ phiên quét. Giữ lại bản nháp đang lưu để bước scan
  /// vẫn hiển thị được thẻ lịch sử.
  void reset() => state = ReceivingState(historyEntry: state.historyEntry);
}