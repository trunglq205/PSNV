﻿namespace SWMS_WebTool.Models.Responses
{
    public class QtyBalanceResponse
    {
        public Int64 ID { get; set; }
        public string Barcode { get; set; }
        public int? Qty { get; set; }
        public string Material { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public bool IsManual { get; set; }
    }
}
