import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';

/// Map trạng thái → tông StatusPill. Gom một chỗ để danh sách và màn kiểm
/// luôn cùng màu cho cùng trạng thái.
class ContainerStatusPill extends StatelessWidget {
  final ContainerStatus status;
  const ContainerStatusPill({super.key, required this.status});

  @override
  Widget build(BuildContext context) {
    final label = status.labelKey.tr();
    return switch (status) {
      ContainerStatus.verify => StatusPill.warning(context, label: label),
      ContainerStatus.loading => StatusPill.info(context, label: label),
      ContainerStatus.done => StatusPill.success(context, label: label),
    };
  }
}
