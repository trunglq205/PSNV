import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_warehouse/shared/base/base_page.dart';
import 'package:smart_warehouse/shared/extensions/widget_extensions.dart';

import '../../../../gen/assets.gen.dart';
import '../../../../shared/resources/locale_keys.dart';
import '../../../../shared/router/auth_guard.gr.dart';

import '../../../widgets/app_card.dart';

import 'menu_amr_controller.dart';
import 'menu_amr_state.dart';


@RoutePage()
class MenuAmrPage extends BasePage<MenuAmrController, MenuAmrState> {
  const MenuAmrPage({super.key});
  @override
  BasePageState createState() => _MenuAmrPageState();
}
class _MenuAmrPageState
    extends BasePageState<MenuAmrController, MenuAmrState>

{

  @override
  void initState() {
    super.initState();
  }
  @override
  Widget builder(context, cubit, state) {
    return Scaffold(
      appBar: AppBar(title: const Text('Robot')),
      body:  Column(
        children: [
          AppCard(
            title: 'Call Robot',
            image: Assets.images.agvRobot
                .image(width: 48, height: 48),
            onPressed: () {
              context.pushRoute(const CallAMRRoute());
            },
          ).marginOnly(bottom: 15,top: 20,left: 15,right: 15),
          AppCard(
            title: 'Out Pallet',
            image:
            Assets.images.icOutPallet.image(width: 48, height: 48),
            onPressed: () {
              context.pushRoute(const OutpalletAmrRoute());
            },
          ).marginOnly(left: 15,right: 15),
        ],
      ),

    );
  }

}