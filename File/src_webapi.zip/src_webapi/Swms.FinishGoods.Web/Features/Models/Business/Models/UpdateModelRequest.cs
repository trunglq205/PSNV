using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.Web.Features.Models.Business.Models;

/// <summary>
/// Payload cập nhật model. Không cho đổi Code ở đây (business key —
/// tương tự Users không cho đổi EmployeeCode khi sửa).
/// </summary>
public class UpdateModelRequest
{
    [MaxLength(14, ErrorMessage = "GTIN tối đa 14 ký tự")]
    [RegularExpression(@"^(\d{8}|\d{12,14})?$", ErrorMessage = "GTIN phải là 8, 12, 13 hoặc 14 chữ số")]
    public string? GTIN { get; set; }

    /// <summary>Mã xuất xứ 2 chữ cái, vd "VN". Null = xoá xuất xứ.</summary>
    [RegularExpression(OriginRule.Pattern, ErrorMessage = "Xuất xứ phải là 2 chữ cái (vd VN, JP)")]
    public string? Origin { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Danh mục bắt buộc")]
    public int CategoryId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Chiều dài phải > 0")]
    public int Length { get; set; }                  // mm

    [Range(1, int.MaxValue, ErrorMessage = "Chiều rộng phải > 0")]
    public int Width { get; set; }                   // mm

    [Range(1, int.MaxValue, ErrorMessage = "Chiều cao phải > 0")]
    public int Height { get; set; }                  // mm

    [Range(1, int.MaxValue, ErrorMessage = "Quy cách đóng gói phải > 0")]
    public int StandardPacking { get; set; }         // set / box

    // Quy cách xếp pallet — nhập đủ LayerCount/StackingLength/StackingWidth hoặc bỏ trống cả 3.
    [Range(1, StackingRule.MaxLayer, ErrorMessage = "Layer limit không hợp lệ")]
    public int? LayerLimit { get; set; }

    [Range(1, StackingRule.MaxLayer, ErrorMessage = "No of layer không hợp lệ")]
    public int? LayerCount { get; set; }

    [Range(1, StackingRule.MaxStacking, ErrorMessage = "Stacking length không hợp lệ")]
    public int? StackingLength { get; set; }

    [Range(1, StackingRule.MaxStacking, ErrorMessage = "Stacking width không hợp lệ")]
    public int? StackingWidth { get; set; }

    /// <summary>Khu vực gợi ý (FK warehouse_areas.id). Null = xoá gợi ý.</summary>
    [Range(1, int.MaxValue, ErrorMessage = "Khu vực gợi ý không hợp lệ")]
    public int? SuggestAreaId { get; set; }

    /// <summary>Tầng rack gợi ý, vd [2, 3]. Null/rỗng = xoá gợi ý.</summary>
    public List<int>? SuggestRackRow { get; set; }

    public bool IsActive { get; set; } = true;
}

// Payload import upsert — khop UpsertModelRequest ben API core.
// Moi field (tru Code) deu nullable: null = "o khong dien trong file".
//   - Ma da ton tai: API chi cap nhat cac field co gia tri, field null giu nguyen.
//   - Ma moi: can du CategoryId, Length, Width, Height, StandardPacking; thieu thi API bo qua dong do.
public record UpsertModelRequest
{
    public string Code { get; init; } = "";
    public string? GTIN { get; init; }
    public string? Origin { get; init; }
    public int? CategoryId { get; init; }
    public int? Length { get; init; }
    public int? Width { get; init; }
    public int? Height { get; init; }
    public int? StandardPacking { get; init; }
    public int? LayerLimit { get; init; }
    public int? LayerCount { get; init; }
    public int? StackingLength { get; init; }
    public int? StackingWidth { get; init; }
    public int? SuggestAreaId { get; init; }
    public List<int>? SuggestRackRow { get; init; }
    public bool? IsActive { get; init; }
}

// Ket qua upsert: dem so tao moi / cap nhat / bo qua de hien toast tong ket.
// Skipped: dong khong ghi gi — ma moi thieu cot bat buoc, hoac ma da co ma khong dien o nao.
public record BulkUpsertResult(int Created, int Updated, int Skipped = 0, IReadOnlyList<string>? SkippedCodes = null);