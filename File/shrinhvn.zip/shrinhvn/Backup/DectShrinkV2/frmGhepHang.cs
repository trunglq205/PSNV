﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class frmGhepHang : Form
    {
        public int resultInt;

        public string serialouter_secom = "";

        public frmGhepHang(string user)
        {
            InitializeComponent();
            lbluser.Text = user;
            //lblThongbao.Text = "";
            //lblThongbao.BackColor = Color.WhiteSmoke;
            txtChuan.Select();


        }
        ConnectSQL conn =new ConnectSQL();

        private void Design_list()
        {
            //SET LV PROPIETIES
            listView1.View = View.Details;
            listView1.FullRowSelect = true;

            //ADD COLUMNS
            listView1.Columns.Add("Serial", 400);
            //listView1.Columns.Add("Status", 150);
            
        }


        private void add_list(string Serial)
        {
            //ARRAY TO REP A ROW
            String[] row = { Serial };

            ListViewItem item = new ListViewItem(row);

            //ADD ITEMS
            listView1.Items.Add(item);
        }

        private void txtSerialOuter_KeyUp(object sender, KeyEventArgs e)
        {
           
        }

        private void label1_Click(object sender, EventArgs e)
        {
        }

        private void txtSerialProduct_KeyUp(object sender, KeyEventArgs e)
        {
          
        }

        private void cmbCategory_SelectedIndexChanged(object sender, EventArgs e)
        {
            cmbCategory.Enabled = false;
            txtPostCodeOuter.Focus();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmGhepHang_Load(object sender, EventArgs e)
        {
           
            txtChuan.Focus();
            txtChuan.SelectAll();
            //txtChuan.Text = "";


        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void txtmodel_TextChanged(object sender, EventArgs e)
        {

        }

        //private void txtmodel_KeyUp(object sender, KeyEventArgs e)
        //{
        //    //if (e.KeyCode == Keys.Enter)
        //    //{
        //    //    LoadModel_ByPartCode_Partcord_OutCatton();
        //    //}
        //}

        private void LoadModel_ByPartCode_Partcord_OutCatton()
        {
          object[] objV = {  this.txtPostCodeOuter.Text.ToUpper().Trim() };
          DataTable dtResult = conn.StoreFillDTable("SP_PRODUCT_GOPGHEP_CheckModel_PatcodeOuter",CommandType.StoredProcedure, objV);
          if (dtResult.Rows.Count > 0)
          {
              txtModelOuter.Text = dtResult.Rows[0]["STR_PROCESS_FACTORY"].ToString();
              this.txtSerialOuter.Focus();
              txtModelOuter.Enabled = false;
              txtPostCodeOuter.Enabled = false;
          }
          else
          {
             // MessageBox.Show("Kiểm tra lại thông tin PartCode_OutCatton", "Thông báo");

              lblThongbao.Text = "Sai thông tin PostCode vỏ thùng...";
              lblThongbao.BackColor = Color.Red;
              txtPostCodeOuter.Focus();
          }
        }

        private void LoadModel_ByPartCode_Partcord_InnerCatton()
        {

            object[] objV = { this.txtPostCodeInser.Text.ToUpper().Trim() };
            DataTable dtResult2 = conn.StoreFillDTable("SP_PRODUCT_GOPGHEP_CheckModel_PatcodeInner", CommandType.StoredProcedure, objV);
            if (dtResult2.Rows.Count > 0)
            {
                 this.txtModeInser.Text = dtResult2.Rows[0]["STR_PROCESS_FACTORY"].ToString();
                 if (this.txtModelOuter.Text.ToString().Trim() != this.txtModeInser.Text.ToString().Trim()) //12.12.2022 Kiểm tra thuộc 2 model Innse và model Outer có giống hay không
                 {
                     this.lblThongbao.Text = "NG! Model sản phẩm không giống với model vỏ thùng....";
                     DataConn2.ExecuteStore("sp_getContact5", CommandType.StoredProcedure, "QualityWarning", "QualityWarning", "Model SP " +txtModeInser.Text.Trim()+" khac model thung  " + txtModelOuter.Text.Trim() +"...", "Gopghep", "", "");
                     lblThongbao.BackColor = Color.Red;
                     txtPostCodeInser.Focus();
                 }
                 else
                 {
                     this.txtSerialProduct.Focus();
                     txtPostCodeInser.Enabled = false;
                 }
            }
            else
            {

                this.lblThongbao.Text = "NG!Postcode sản phẩm không đúng ...";
                lblThongbao.BackColor = Color.Red;
                txtPostCodeInser.Focus();

            }
        }



        private void txtOuterCarton_KeyUp(object sender, KeyEventArgs e)
        {
           
        }

        private void bttReset_Click(object sender, EventArgs e)
        {
            txtPostCodeOuter.Enabled = true;
            txtModelOuter.Enabled = true;
            txtSerialOuter.Enabled = true;
            txtOuterCarton.Enabled = true;
            txtPostCodeInser.Enabled = true;
            txtSerialProduct.Enabled = true;
            txtModeInser.Enabled = true;
            txtOuterCarton.Text = "";
            txtPostCodeOuter.Text = "";
            txtModelOuter.Text = "";
            txtOuterCarton.Text = "";
            txtPostCodeOuter.Text = "";
            txtModeInser.Text = "";
            txtSerialProduct.Text = "";
            txtPostCodeOuter.Focus();
            txtSerialOuter.Text = "";
            txtModeInser.Text = "";
            txtPostCodeInser.Text = "";
            listView1.Clear();
            lblThongbao.Text = "";
            lblSLActual.Text = "";
            lblThongbao.ForeColor = Color.WhiteSmoke;
            txtChuan.Text = "";
            txtChuan.Enabled = true;
            this.cmbCategory.Focus();
           
        }

        private void txtModeInser_KeyPress(object sender, KeyPressEventArgs e)
        {
            
           
        }

        private void txtPostCodeOuter_KeyDown(object sender, KeyEventArgs e)
        {
            lblThongbao.Text = "";
            lblThongbao.ForeColor = Color.WhiteSmoke;
            if (e.KeyCode == Keys.Enter)
            {
                if (txtPostCodeOuter.Text != "")
                {
                    LoadModel_ByPartCode_Partcord_OutCatton();
                }
                else
                {
                    lblThongbao.Text = "PostCode không để trống.";
                    lblThongbao.BackColor = Color.Red;
                }


            }

        }

       public void LoadData()
       {
           string[] para = { "@SerialOuter", "@category" };
           object[] objV = { txtSerialOuter.Text.ToString().Trim(), cmbCategory.Text.Trim() };
           DataTable dt_serial = conn.TableWithParameter("SP_QSerialOuter_NEW", para, objV);

           if (dt_serial.Rows.Count > 0)
           {
               listView1.Clear();
               Design_list();
               for (int i = 0; i < dt_serial.Rows.Count; i++)
               {
                   add_list(dt_serial.Rows[i]["SerialProduct"].ToString());

               }
               txtPostCodeInser.Enabled = true;
               txtSerialProduct.Enabled = true;
               txtPostCodeInser.Text = "";
               txtModeInser.Text = "";
               txtSerialProduct.Text = "";
               this.txtPostCodeInser.Focus();
               lblSLActual.Text = "Total:" + dt_serial.Rows.Count.ToString();
           }
       }

       public void LoadData_secom(string serialouter_secom)
       {
           string[] para = { "@SerialOuter", "@category" };
           object[] objV = { serialouter_secom, cmbCategory.Text.Trim() };
           DataTable dt_serial = conn.TableWithParameter("SP_QSerialOuter_NEW", para, objV);

           if (dt_serial.Rows.Count > 0)
           {
               listView1.Clear();
               Design_list();
               for (int i = 0; i < dt_serial.Rows.Count; i++)
               {
                   add_list(dt_serial.Rows[i]["SerialProduct"].ToString());

               }
               txtPostCodeInser.Enabled = true;
               txtSerialProduct.Enabled = true;
               txtPostCodeInser.Text = "";
               txtModeInser.Text = "";
               txtSerialProduct.Text = "";
               this.txtPostCodeInser.Focus();
               lblSLActual.Text = "Total:" + dt_serial.Rows.Count.ToString();
           }
       }

        private void txtSerialOuter_KeyDown(object sender, KeyEventArgs e)
        {
            lblThongbao.Text = "";
            lblThongbao.ForeColor = Color.WhiteSmoke;
            if (e.KeyCode == Keys.Enter)
            {
                //2.Insert DP dữ liệu cũ vào bảng shink 
                if (cmbCategory.Text == "DP")
                {
                      if (this.txtPostCodeOuter.Text == "")
                    {
                        lblThongbao.Text = "Không để trống bản ghi trường PostCode";
                        lblThongbao.BackColor = Color.Red;
                        txtPostCodeOuter.Enabled = true;
                        txtPostCodeOuter.Focus();
                       

                    }
                      else if (txtModelOuter.Text == "")
                      {
                          lblThongbao.Text = "Không để trống bản ghi trường Model.";
                          lblThongbao.BackColor = Color.Red;
                          this.txtModelOuter.Enabled = true;
                          txtModelOuter.Focus();
                      }

                      else
                      {

                          string Model_SerialOuter = this.txtSerialOuter.Text.ToString();
                          char[] spearator = { '.', '%',' ' };
                          String[] strlist = Model_SerialOuter.Split(spearator);

                          string ModelSerialOuter = strlist[0].ToString().Trim() + "-V4";
                          string Model = txtModelOuter.Text.ToString() ;

                          if (ModelSerialOuter != Model)
                          {
                              lblThongbao.Text = "NG! Sai thông tin Model.";
                              lblThongbao.BackColor = Color.Red;
                              
                          }
                          else
                          {



                              string[] para = { "@SerialOuter", "@category" };
                              object[] objV = { txtSerialOuter.Text.ToString().Trim(), cmbCategory.Text.Trim() };
                              //eidt cho model DP-ecom
                              //DataTable dt_serial_Original = conn.TableWithParameter("SP_QSerialOuter", para, objV);    
                              DataTable dt_serial_Original = conn.TableWithParameter("SP_QSerialOuter_ecom", para, objV);

                              //if (dt_serial_Original.Rows[0]["STR_PROCESS_FACTORY"].ToString() == "VL-MWH710SCM-V4" || dt_serial_Original.Rows[0]["STR_PROCESS_FACTORY"].ToString() == "VL-VH575SCM-V4")
                              //{
                              //    serialouter_secom = dt_serial_Original.Rows[0][2].ToString();                             
                              //}
                              if (ckModelSecom.Checked == true)
                              {
                                  serialouter_secom = dt_serial_Original.Rows[0][2].ToString();
                              }
                              

                              DataTable dt_serial_New = conn.TableWithParameter("SP_QSerialOuter_NEW", para, objV);
                              if (dt_serial_Original.Rows.Count >= dt_serial_New.Rows.Count)// Trường hợp ban đầu 1 thùng có 2 con ==> load dư liệu cân và còn trường hợp load dữ liệu của bảng new
                              {
                                  listView1.Clear();
                                  Design_list();
                                  int SL_TL = int.Parse(dt_serial_Original.Rows.Count.ToString());
                                  int SL_Plan = int.Parse(txtChuan.Text.ToString());

                                  for (int i = 0; i < dt_serial_Original.Rows.Count; i++)
                                  {
                                      add_list(dt_serial_Original.Rows[i]["STR_SERIAL"].ToString());
                                      //if (dt_serial.Rows[i]["Status"].ToString() == "1")
                                      //{
                                      //    listView1.Items[i].BackColor = Color.Red;
                                      //}

                                  }
                                  lblSLActual.Text = "Total:" + dt_serial_Original.Rows.Count.ToString();
                                  if (SL_TL >= SL_Plan)
                                  {
                                      lblThongbao.Text = "NG!Số lượng vượt quá SL tiêu chuẩn";
                                      lblThongbao.BackColor = Color.Red;
                                      txtOuterCarton.Enabled = false;
                                      txtSerialOuter.Enabled = true;
                                      txtSerialOuter.Focus();

                                  }
                                  else
                                  {
                                      foreach (ListViewItem item in this.listView1.Items) // Insert gias
                                      {
                                          string SerialProduct = item.SubItems[0].Text.ToString();
                                          string PostCodeInser = dt_serial_Original.Rows[0]["STR_PROCESS"].ToString().Trim(); // Lấy giá trị PostCodeInser lấy từ bảng product

                                          //if (txtModelOuter.Text == "VL-MWH710SCM-V4")
                                          if (ckModelSecom.Checked == true)
                                          {
                                              //secom
                                              string[] para1 = { "@Cate", "@ModelOuter", "@SerialOuter", "@PostCodeCarton", "@SerialProduct", "@PostCodeInner", "@ModelInner", "@User_Ghep" };
                                              object[] objV1 = { cmbCategory.Text.Trim(), txtModelOuter.Text.Trim(), serialouter_secom, txtPostCodeOuter.Text.Trim(), SerialProduct, PostCodeInser, txtModeInser.Text.Trim(), lbluser.Text };
                                              resultInt = conn.ExcuteStored("[SP_PRODUCT_GOPGHEP_INSERT]", para1, objV1);
                                          }
                                          else
                                          {
                                              string[] para1 = { "@Cate", "@ModelOuter", "@SerialOuter", "@PostCodeCarton", "@SerialProduct", "@PostCodeInner", "@ModelInner", "@User_Ghep" };
                                              object[] objV1 = { cmbCategory.Text.Trim(), txtModelOuter.Text.Trim(), txtSerialOuter.Text.Trim(), txtPostCodeOuter.Text.Trim(), SerialProduct, PostCodeInser, txtModeInser.Text.Trim(), lbluser.Text };
                                              resultInt = conn.ExcuteStored("[SP_PRODUCT_GOPGHEP_INSERT]", para1, objV1);
                                          }

                                          //normal
                                          //string[] para1 = { "@Cate", "@ModelOuter", "@SerialOuter", "@PostCodeCarton", "@SerialProduct", "@PostCodeInner", "@ModelInner", "@User_Ghep" };
                                          //object[] objV1 = { cmbCategory.Text.Trim(), txtModelOuter.Text.Trim(), txtSerialOuter.Text.Trim(), txtPostCodeOuter.Text.Trim(), SerialProduct, PostCodeInser, txtModeInser.Text.Trim(), lbluser.Text };
                                          //resultInt = conn.ExcuteStored("[SP_PRODUCT_GOPGHEP_INSERT]", para1, objV1);
                                      }
                                      txtSerialOuter.Enabled = false;
                                      this.txtOuterCarton.Focus();
                                  }
                              }


                              if (dt_serial_Original.Rows.Count <= dt_serial_New.Rows.Count)// Trường hợp ban đầu 1 thùng có 2 con ==> load dư liệu cân và còn trường hợp load dữ liệu của bảng new
                              {
                                  listView1.Clear();
                                  Design_list();
                                  int SL_TL = int.Parse(dt_serial_New.Rows.Count.ToString());
                                  int SL_Plan = int.Parse(txtChuan.Text.ToString());
                                  for (int i = 0; i < dt_serial_New.Rows.Count; i++)
                                  {
                                      add_list(dt_serial_New.Rows[i]["SerialProduct"].ToString());
                                      //if (dt_serial.Rows[i]["Status"].ToString() == "1")
                                      //{
                                      //    listView1.Items[i].BackColor = Color.Red;
                                      //}

                                  }
                                  lblSLActual.Text = "Total:" + dt_serial_New.Rows.Count.ToString();
                                  if (SL_TL >= SL_Plan)
                                  {
                                      lblThongbao.Text = "NG! Số lượng vượt quá SL chuẩn";
                                      lblThongbao.BackColor = Color.Red;
                                      txtSerialOuter.Enabled = true;
                                      txtSerialOuter.Focus();
                                      txtOuterCarton.Enabled = false;
                                      

                                  }
                                  else
                                  {
                                      foreach (ListViewItem item in this.listView1.Items) // Insert gias
                                      {
                                          string SerialProduct = item.SubItems[0].Text.ToString();

                                          string[] para1 = { "@Cate", "@ModelOuter", "@SerialOuter", "@PostCodeCarton", "@SerialProduct", "@PostCodeInner", "@ModelInner", "@User_Ghep" };
                                          object[] objV1 = { cmbCategory.Text.Trim(), txtModelOuter.Text.Trim(), txtSerialOuter.Text.Trim(), txtPostCodeOuter.Text.Trim(), SerialProduct, txtPostCodeInser.Text.Trim(), txtModeInser.Text.Trim(), lbluser.Text };

                                          resultInt = conn.ExcuteStored("[SP_PRODUCT_GOPGHEP_INSERT]", para1, objV1);
                                      }

                                      txtSerialOuter.Enabled = false;
                                      this.txtOuterCarton.Focus();

                                  }


                              }



                          }
                      }
                   
                   

                }
                else
                {
                    string[] para = { "@SerialOuter", "@category" };
                    object[] objV = { txtSerialOuter.Text.ToString().Trim(), cmbCategory.Text.Trim() };
                    DataTable dt_serial = conn.TableWithParameter("SP_QSerialOuter", para, objV);

                    if (dt_serial.Rows.Count > 0)
                    {
                        listView1.Clear();
                        Design_list();
                        for (int i = 0; i < dt_serial.Rows.Count; i++)
                        {
                            add_list(dt_serial.Rows[i]["STR_SERIAL"].ToString());
                            //if (dt_serial.Rows[i]["Status"].ToString() == "1")
                            //{
                            //    listView1.Items[i].BackColor = Color.Red;
                            //}

                        }
                        txtSerialOuter.Enabled = false;
                        this.txtOuterCarton.Focus();
                    }

                }

            }
        }

        private void txtOuterCarton_KeyDown(object sender, KeyEventArgs e)
        {
            lblThongbao.Text = "";
            lblThongbao.ForeColor = Color.WhiteSmoke;
            if (e.KeyCode == Keys.Enter)
            {
               
                this.txtOuterCarton.Enabled = false;
                txtPostCodeInser.Focus();
            }
        }

        private void txtPostCodeInser_KeyDown(object sender, KeyEventArgs e)
        {
            lblThongbao.Text = "";
            lblThongbao.ForeColor = Color.WhiteSmoke;
            if (e.KeyCode == Keys.Enter)
            {
                LoadModel_ByPartCode_Partcord_InnerCatton();
                
            }

        }

        private void txtSerialProduct_KeyDown(object sender, KeyEventArgs e)
        {
            lblThongbao.Text = "";
            lblThongbao.ForeColor = Color.WhiteSmoke;
            if (e.KeyCode == Keys.Enter)
            {
                DataTable dtPosition = conn.GetTableWithCommandText("SELECT *  FROM [TBLPOSITION_SERIAL] where MODEL='" + txtModelOuter.Text.Replace("-V4"," ").Trim() + "'");
                if (dtPosition.Rows.Count > 0)
                {
                    txtSerialProduct.Text = txtSerialProduct.Text.Trim().Replace("%", "").Split(' ')[int.Parse(dtPosition.Rows[0]["POSITION_SERIAL"].ToString())];
                }
                else
                {
                    txtSerialProduct.Text = txtSerialProduct.Text.Trim().Replace("%", "");
                }

                //txtSerialProduct.Text = txtSerialProduct.Text.Replace("%", "");
                int lengh = txtSerialProduct.Text.Length;

                if (lengh != 11)
                {
                    //add more ghep serial for sound bussiness  (do dai serial la 6+8 ky tu)
                    if (cmbCategory.Text == "HP")
                    {
                        DialogResult result = MessageBox.Show("Bạn muốn thêm số serial " + txtSerialProduct.Text + " không  ?", "Thông báo", MessageBoxButtons.OKCancel);
                        if (result == DialogResult.OK)
                        {
                            try
                            {
                                string[] para = { "@SerialProduct", "@SerialOuter", "@category", "@userUpdate", "@model", "@OutterCarton" };
                                object[] objV = { txtSerialProduct.Text.ToString().ToUpper(), txtSerialOuter.Text.ToString(), cmbCategory.Text.Trim(), lbluser.Text, txtPostCodeOuter.Text.ToUpper().Trim(), txtOuterCarton.Text.Trim().ToUpper() };
                                //version old
                                //int  resultInt = conn.ExcuteStored("SP_USerialProducttoOuterBox", para, objV);

                                //version new: 19.04.2022
                                //minh edit: loi 2 model khac nhau cung serial van ghep duoc + combine ghep serial vao serial outer cua cate sound biz
                                int resultInt = conn.ExcuteStored("SP_USerialProducttoOuterBox_new", para, objV);
                                if (resultInt > 0)
                                {
                                    //MessageBox.Show("", "Thông báo");

                                    this.lblThongbao.Text = "Thành công";
                                    lblThongbao.BackColor = Color.Blue;


                                    //minh edit //load again list view 
                                    //ListViewItem itm = new ListViewItem(txtSerialProduct.Text.ToString());
                                    //listView1.Items.Add(itm);
                                }
                                else
                                {
                                   // MessageBox.Show("", "Thông báo");
                                    lblThongbao.Text = "Gộp ghép bị lỗi.";
                                    lblThongbao.BackColor = Color.Red;
                                }
                            }
                            catch (Exception ex)
                            {
                                throw ex;
                               // MessageBox.Show("Lỗi", "Thông báo");
                                lblThongbao.Text = "Lỗi.";
                                lblThongbao.BackColor = Color.Red;
                            }

                        }
                    }
                    else
                    {

                        lblThongbao.Text = "Kiểm tra lại số serial.";
                        lblThongbao.BackColor = Color.Red;
                        txtSerialProduct.Focus();
                    }
                }
                else
                {
                    //12.12.2022  Sửa đối với DP
                    if (cmbCategory.Text == "DP")
                    {
                       string[] para1 = { "@SerialOuter", "@category" };
                       object[] objV1 = { txtSerialOuter.Text.ToString().Trim(), cmbCategory.Text.Trim() };
                       DataTable dt_serial = conn.TableWithParameter("SP_QSerialOuter_NEW", para1, objV1);
                       int SL_Actual = int.Parse(dt_serial.Rows.Count.ToString());
                       int SL_Plan = int.Parse(txtChuan.Text.ToString());
                       if (SL_Actual >= SL_Plan)
                       {
                           lblThongbao.Text = "---- NG!Số lượng của Outer caton đã đủ -----";
                           lblThongbao.BackColor = Color.Red;
                           

                       }
                       else if (SL_Actual < SL_Plan)
                       {
                       
                        object[] obj2 = { this.txtModeInser.Text.ToString().Trim(), txtSerialProduct.Text.ToString().Trim() };
                        DataTable dtModeSerial_Inner = conn.StoreFillDTable("[SP_PRODUCT_GOPGHEP_CheckModelSerial]", CommandType.StoredProcedure, obj2);
                        int CHeck_ModelSerial = int.Parse(dtModeSerial_Inner.Rows[0]["Counts"].ToString());
                        if (CHeck_ModelSerial == 0)
                        {
                            lblThongbao.Text = "---- NG!Serial Product và Model không tồn tại công đoạn Weight -----";
                            lblThongbao.BackColor = Color.Red;
                            txtSerialProduct.Focus();

                        }
                        else
                        {
                            object[] obj1 = { this.txtModeInser.Text.ToString().Trim(), txtSerialProduct.Text.ToString().Trim() };
                            DataTable dtResultShink = conn.StoreFillDTable("SP_PRODUCT_GOPGHEP_CheckSerialShink", CommandType.StoredProcedure, obj1);
                            int SLCHECK = int.Parse(dtResultShink.Rows[0]["Counts"].ToString());
                            if (SLCHECK == 0) // Chưa Shink b
                             {

                                DialogResult result = MessageBox.Show("Bạn muốn thêm số serial " + txtSerialProduct.Text + " không  ?", "Thông báo", MessageBoxButtons.OKCancel);

                                 if (result == DialogResult.OK)
                                 {
                                     try
                                     {

                                  //-------------------------------------------------------- Update thông tin bảng Product

                                         //if (txtModeInser.Text == "VL-MWH710SCM-V4")
                                         if (ckModelSecom.Checked == true)
                                         {
                                             //serialouter_secom
                                             string[] para = { "@SerialProduct", "@SerialOuter", "@category", "@userUpdate", "@model", "@OutterCarton" };
                                             object[] objV = { txtSerialProduct.Text.ToString().ToUpper().Trim(), serialouter_secom, cmbCategory.Text.Trim(), lbluser.Text.Trim(), this.txtModelOuter.Text.ToUpper().Trim(), this.txtPostCodeOuter.Text.ToUpper().Trim() };
                                             int resultInt = conn.ExcuteStored("SP_USerialProducttoOuterBox_new", para, objV);
                                         }
                                         else
                                         {
                                             //normal
                                             string[] para = { "@SerialProduct", "@SerialOuter", "@category", "@userUpdate", "@model", "@OutterCarton" };
                                             object[] objV = { txtSerialProduct.Text.ToString().ToUpper().Trim(), txtSerialOuter.Text.ToString().Trim(), cmbCategory.Text.Trim(), lbluser.Text.Trim(), this.txtModelOuter.Text.ToUpper().Trim(), this.txtPostCodeOuter.Text.ToUpper().Trim() };
                                             int resultInt = conn.ExcuteStored("SP_USerialProducttoOuterBox_new", para, objV);
                                         }
                                        //string[] para = { "@SerialProduct", "@SerialOuter", "@category", "@userUpdate", "@model", "@OutterCarton" };
                                        //object[] objV = { txtSerialProduct.Text.ToString().ToUpper().Trim(), txtSerialOuter.Text.ToString().Trim(), cmbCategory.Text.Trim(), lbluser.Text.Trim(), this.txtModelOuter.Text.ToUpper().Trim(), this.txtPostCodeOuter.Text.ToUpper().Trim() };
                                        //int resultInt = conn.ExcuteStored("SP_USerialProducttoOuterBox_new", para, objV);
                                         
                                       
                                     //------------------------------------------------------------- Insert bảng mới Product_Verify
                                         //if (txtModeInser.Text == "VL-MWH710SCM-V4") 
                                         if (ckModelSecom.Checked == true)
                                         {
                                             string Serial_ProductNew = txtSerialProduct.Text.ToString();
                                             string[] para2 = { "@Cate", "@ModelOuter", "@SerialOuter", "@PostCodeCarton", "@SerialProduct", "@PostCodeInner", "@ModelInner", "@User_Ghep" };
                                             object[] objV2 = { cmbCategory.Text.Trim(), txtModelOuter.Text.Trim(), serialouter_secom, txtPostCodeOuter.Text.Trim(), Serial_ProductNew, txtPostCodeInser.Text.Trim(), txtModeInser.Text.Trim(), lbluser.Text };
                                             resultInt = conn.ExcuteStored("[SP_PRODUCT_GOPGHEP_INSERT]", para2, objV2);
                                         }
                                         else
                                         {
                                             string Serial_ProductNew = txtSerialProduct.Text.ToString();
                                             string[] para2 = { "@Cate", "@ModelOuter", "@SerialOuter", "@PostCodeCarton", "@SerialProduct", "@PostCodeInner", "@ModelInner", "@User_Ghep" };
                                             object[] objV2 = { cmbCategory.Text.Trim(), txtModelOuter.Text.Trim(), txtSerialOuter.Text.Trim(), txtPostCodeOuter.Text.Trim(), Serial_ProductNew, txtPostCodeInser.Text.Trim(), txtModeInser.Text.Trim(), lbluser.Text };
                                             resultInt = conn.ExcuteStored("[SP_PRODUCT_GOPGHEP_INSERT]", para2, objV2);
                                         }
                                        //string Serial_ProductNew = txtSerialProduct.Text.ToString();
                                        //string[] para2 = { "@Cate", "@ModelOuter", "@SerialOuter", "@PostCodeCarton", "@SerialProduct", "@PostCodeInner", "@ModelInner", "@User_Ghep" };
                                        //object[] objV2 = { cmbCategory.Text.Trim(), txtModelOuter.Text.Trim(), txtSerialOuter.Text.Trim(), txtPostCodeOuter.Text.Trim(), Serial_ProductNew, txtPostCodeInser.Text.Trim(), txtModeInser.Text.Trim(), lbluser.Text };
                                        //resultInt = conn.ExcuteStored("[SP_PRODUCT_GOPGHEP_INSERT]", para2, objV2);

                                        if (resultInt >0) // Đã Insert thành công
                                        {
                                            //MessageBox.Show("", "Thông báo");                                                                                       
                                            //if(serialouter_secom == "")
                                            if (ckModelSecom.Checked == true)
                                            {
                                                LoadData();
                                                this.lblThongbao.Text = "Gộp ghép thành công.";
                                                lblThongbao.BackColor = Color.Blue;
                                                txtPostCodeInser.Focus();
                                            }
                                            else
                                            {
                                                LoadData_secom(serialouter_secom);
                                                this.lblThongbao.Text = "Gộp ghép thành công.";
                                                lblThongbao.BackColor = Color.Blue;
                                                txtPostCodeInser.Focus();
                                            }
                                           

                                        }
                                        else
                                        {
                                            // MessageBox.Show("Serial đã được gộp ghép. ", "Thông báo");
                                            lblThongbao.Text = "Sản phảm đã được gộp ghép";
                                            lblThongbao.BackColor = Color.Red;


                                        }


                                    }
                                    catch (Exception ex)
                                    {
                                        throw ex;
                                        //MessageBox.Show("Lỗi", "Thông báo");
                                        lblThongbao.Text = "Lỗi";
                                        lblThongbao.BackColor = Color.Red;
                                    }
                                }
                               
                            }
                            else
                            {

                                lblThongbao.Text = "---- NG!Serial Product đã được shink-----";

                                lblThongbao.BackColor = Color.Red;
                                txtSerialProduct.Focus();
                                InsertError("6", lbluser.Text.ToString(), txtSerialProduct.Text.ToString().Trim(), this.cmbCategory.Text.ToString(), txtModeInser.Text.ToString().Trim());
                                ////Fill data to SMS
                                DataConn2.ExecuteStore("sp_getContact5", CommandType.StoredProcedure, "QualityWarning", "QualityWarning", "Serial:" + txtSerialProduct.Text.Trim() + "da shink roi." + txtSerialOuter.Text + "...", "Gopghep", "", "");
                            }
                          }
                       }
                    }
                    else // Update dạng binh thuong
                    {
                        DialogResult result = MessageBox.Show("Bạn muốn thêm số serial " + txtSerialProduct.Text + " không  ?", "Thông báo", MessageBoxButtons.OKCancel);

                        if (result == DialogResult.OK)
                        {
                            try
                            {
                                string[] para = { "@SerialProduct", "@SerialOuter", "@category", "@userUpdate", "@model", "@OutterCarton" };
                                //object[] objV = { txtSerialProduct.Text.ToString().ToUpper(), txtSerialOuter.Text.ToString(), cmbCategory.Text.Trim(), lbluser.Text, txtPostCodeOuter.Text.ToUpper().Trim(), txtOuterCarton.Text.Trim().ToUpper() };
                                object[] objV = { txtSerialProduct.Text.ToString().ToUpper(), txtSerialOuter.Text.ToString(), cmbCategory.Text.Trim(), lbluser.Text, txtPostCodeOuter.Text.ToUpper().Trim(), this.txtModelOuter.Text.Trim().ToUpper() };
                                int resultInt = conn.ExcuteStored("SP_USerialProducttoOuterBox_new", para, objV);
                                if (resultInt > 0)
                                {
                                   // MessageBox.Show("Thành công", "Thông báo");
                                    this.lblThongbao.Text = "Thành công";
                                    lblThongbao.BackColor = Color.Blue;
                                    txtPostCodeInser.Text = "";
                                    txtModeInser.Text = "";
                                    txtSerialProduct.Text = "";

                                }
                                else
                                {
                                    //MessageBox.Show("Kiểm tra lại thông tin ", "Thông báo");
                                    lblThongbao.Text = "Kiểm tra lại thông tin.";
                                    lblThongbao.BackColor = Color.Red;

                                }


                            }
                            catch (Exception ex)
                            {

                                //MessageBox.Show("Lỗi", "Thông báo");
                                lblThongbao.Text = "Lỗi.";
                                lblThongbao.BackColor = Color.Red;
                                throw ex;
                            }

                        }

                    }

                }


            }
        }

        private void txtChuan_KeyPress(object sender, KeyPressEventArgs e)
        {

        }
        public void InsertError(string ErrorID, string UserScan , string SerialOUt, string Cate, string Model )
        {
            string[] para = { "@ErrorID","@UserScan","@SerialOut","@Cate","@Model" };
            object[] obj = { ErrorID, UserScan, SerialOUt, Cate, Model };
            int resultInt = conn.ExcuteStored("SP_InsertError_Detail", para, obj);

        }

        private void txtChuan_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtChuan.Enabled = false;
                
                cmbCategory.Focus();
            }
        }



    }
}
