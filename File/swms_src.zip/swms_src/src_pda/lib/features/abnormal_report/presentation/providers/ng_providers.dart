import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/abnormal_report/data/datasources/ng_remote_data_source.dart';
import 'package:swms_finish_goods/features/abnormal_report/data/ng_repository_impl.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/repositories/ng_repository.dart';

part 'ng_providers.g.dart';

@riverpod
NgRepository ngRepository(Ref ref) {
  final dio = ref.watch(dioProvider);
  return NgRepositoryImpl(NgRemoteDataSource(dio));
}

/// Danh sách phiếu của 1 ngày. [day] dạng 'yyyy-MM-dd'; rỗng = mọi ngày.
///
/// Dùng chuỗi làm tham số thay vì DateTime để Riverpod so sánh được bằng ==
/// (hai DateTime cùng ngày nhưng khác giờ sẽ tạo ra 2 provider khác nhau).
@riverpod
Future<List<NgReport>> ngList(Ref ref, String day) async {
  final repo = ref.watch(ngRepositoryProvider);
  return repo.fetchList(day: day.isEmpty ? null : DateTime.parse(day));
}

/// Chi tiết 1 phiếu.
@riverpod
Future<NgDetail> ngDetail(Ref ref, int id) async {
  final repo = ref.watch(ngRepositoryProvider);
  return repo.fetchDetail(id);
}

/// Danh mục loại lỗi — tải 1 lần, giữ suốt phiên, giống cách danh mục Cate
/// đang làm. Danh sách này đổi rất thưa (thêm một loại lỗi là việc của tháng,
/// không phải của phút) nên không đáng tải lại mỗi lần mở màn hình.
@Riverpod(keepAlive: true)
Future<List<NgType>> ngTypes(Ref ref) async {
  final repo = ref.watch(ngRepositoryProvider);
  return repo.fetchTypes();
}

/// Danh mục đã tải xong, hoặc null nếu đang tải hay tải lỗi.
///
/// Đọc thẳng từ [AsyncData] chứ không qua getter `.value`: riverpod 3 đã bỏ
/// `valueOrNull`, còn khớp mẫu thì đúng ở mọi phiên bản — và chính bản build
/// hiện tại đã chấp nhận cách này ở màn tạo phiếu.
List<NgType>? ngTypesOf(AsyncValue<List<NgType>> state) =>
    state is AsyncData<List<NgType>> ? state.value : null;

/// Nhãn của một mã loại lỗi, lấy từ danh mục đã tải. Chưa tải xong hoặc mã lạ
/// thì trả về chính cái mã: phiếu cũ mang loại lỗi đã ngưng dùng vẫn phải đọc
/// được, và ô trống thì người xem không biết là lỗi gì hay là chưa tải xong.
String ngTypeName(List<NgType>? types, String code) =>
    types?.firstWhere(
      (t) => t.code == code,
      orElse: () => NgType(code: code, name: code),
    ).name ??
    code;
