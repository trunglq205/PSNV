using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// B1 — FA đề nghị nhận lại hàng.
///
/// Từ 10/11 FA đề nghị được MỘT PHẦN, nên có <see cref="Lines"/>. SCS WH tách
/// Pallet ID cho khớp đúng SL đó rồi mới giao.
///
/// <see cref="Lines"/> RỖNG hoặc null = xin TOÀN BỘ phần còn ở kho. Giữ nghĩa
/// này vì "lấy hết" vẫn là trường hợp thường gặp nhất, và vì mọi phiếu đề nghị
/// trước 10/11 đều không có dòng nào.
/// </summary>
public record RequestBackRequest(
    [StringLength(500)] string? Note,
    List<BackReqLineRequest>? Lines = null);

/// <summary>
/// Một dòng FA xin: model + SL.
///
/// KHÔNG nhận trần SL ở đây bằng attribute — trần là SL đang còn ở kho, một số
/// chỉ biết lúc chạy. Service kiểm và ném <c>QtyOverRemain</c>.
/// </summary>
public record BackReqLineRequest(
    [Required, StringLength(100)] string Model,
    [Range(1, int.MaxValue)] int ReqQty);

/// <summary>Xác nhận / huỷ — một ô ý kiến, dùng chung.</summary>
public record BackDecisionRequest([StringLength(500)] string? Comment);

// DeliverBackRequest đã XOÁ (11/11) cùng endpoint deliver-back: giao hàng cho
// FA giờ là việc đặt pallet vào vị trí thuộc bản đồ Nhận hàng, không còn màn
// quét mã riêng. Xem ghi chú ở ReturnBackFlowController.

/// <summary>
/// Trạng thái luồng nhận lại hàng của một phiếu.
///
/// Đi KÈM response của phiếu (<c>ReturnInstructionResponse.Back</c>) chứ không
/// phải một tài nguyên riêng: sau khi gộp thì nó là một mặt của phiếu, và tách
/// response là buộc màn hình gọi hai lần cho một dòng.
///
/// <see cref="Step"/> null = FA chưa đề nghị gì. Màn hình cần phân biệt chuyện
/// đó với "đang chờ quản lý FA", nên không quy về chuỗi rỗng.
/// </summary>
public record BackFlowResponse(
    string? Status,
    string? Step,
    bool Requested,
    bool IsOpen,
    bool IsDelivered,
    bool IsPartlyDelivered,
    bool IsCancelled,
    bool CanRequest,

    /// <summary>
    /// SCS WH được tách pallet và quét giao chưa. Suy từ
    /// <c>ReturnInstruction.CanDeliverBack</c> — MỘT nguồn duy nhất cho cả
    /// controller, màn Web và màn PDA.
    /// </summary>
    bool CanDeliver,

    int RemainQty,
    int SentQty,
    int AtFaQty,
    int ReturnedQty,
    string? Note,
    string? RequestedBy,
    DateTime? RequestedAt,
    string? ApprovedBy,
    DateTime? ApprovedAt,
    string? FaComment,

    /// <summary>Quản lý SCS xác nhận (thêm 10/11).</summary>
    string? ScsApprovedBy,
    DateTime? ScsApprovedAt,

    string? DeliveredBy,
    DateTime? DeliveredAt,
    string? ScsComment,
    string? CancelledBy,
    DateTime? CancelledAt,
    string? CancelReason,

    /// <summary>
    /// SL FA xin lấy về theo model. RỖNG nghĩa là xin toàn bộ phần còn ở kho
    /// (hoặc phiếu được đề nghị trước 10/11) — màn hình phải chịu được rỗng.
    /// </summary>
    List<BackReqLineResponse> Lines)
{
    public static BackFlowResponse From(ReturnInstruction d) => new(
        d.BackStatus, d.BackStep,
        d.BackRequested, d.BackIsOpen, d.BackIsDelivered,
        d.BackIsPartlyDelivered, d.BackIsCancelled, d.CanRequestBack,
        d.CanDeliverBack,
        d.BackRemainQty, d.BackSentQty, d.AtFaQty, d.BackReturnedQty,
        d.BackNote,
        d.BackRequestedBy, d.BackRequestedAt,
        d.BackApprovedBy, d.BackApprovedAt, d.BackFaComment,
        d.BackScsApprovedBy, d.BackScsApprovedAt,
        d.BackDeliveredBy, d.BackDeliveredAt, d.BackScsComment,
        d.BackCancelledBy, d.BackCancelledAt, d.BackCancelReason,
        d.BackLines.Select(BackReqLineResponse.From).ToList());
}

/// <summary>Một pallet đã giao.</summary>
public record BackDeliveryResponse(
    string LotNo,
    int SerialCount,
    DateTime DeliveredAt,
    string? DeliveredBy)
{
    public static BackDeliveryResponse From(ReturnBackDelivery d) => new(
        d.LotNo, d.SerialCount, d.DeliveredAt, d.DeliveredBy);
}

/// <summary>Một dòng FA đã xin (<c>wms.return_back_lines</c>).</summary>
public record BackReqLineResponse(string Model, int ReqQty)
{
    public static BackReqLineResponse From(BackReqLine l) => new(l.Model, l.ReqQty);
}

/// <summary>SL còn ở kho theo model — màn đề nghị gọi để CHO XEM.</summary>
public record BackRemainModelResponse(string Model, int Qty)
{
    public static BackRemainModelResponse From(BackModelQty m) => new(m.Model, m.Qty);
}

// BackDeliverResponse đã XOÁ (11/11) cùng endpoint deliver-back. Không còn
// "một lượt quét giao" để trả kết quả: mỗi pallet đi ra khu nhận hàng là một
// lần chuyển vị trí, và response của chính API chuyển vị trí
// (LocatorChangeResponse) đã là thứ PDA cần.

/// <summary>
/// Khoá resource cho thông báo của luồng nhận lại hàng. Giữ ở một chỗ để resx
/// và code không lệch nhau — cùng cách <c>ReturnMsg</c> làm.
/// </summary>
public static class BackMsg
{
    /// <summary>Phiếu không tồn tại.</summary>
    public const string DocNotFound = "Return.Back.Err.DocNotFound";

    /// <summary>Phiếu đã huỷ — không đề nghị được.</summary>
    public const string DocCancelled = "Return.Back.Err.DocCancelled";

    /// <summary>Phiếu không còn con nào ở kho để lấy về.</summary>
    public const string NothingAvailable = "Return.Back.Err.NothingAvailable";

    /// <summary>Đã có luồng back đang chạy hoặc đã xong.</summary>
    public const string AlreadyRequested = "Return.Back.Err.AlreadyRequested";

    /// <summary>Chưa ai đề nghị nhận lại hàng cho phiếu này.</summary>
    public const string NotRequested = "Return.Back.Err.NotRequested";

    /// <summary>Không ở đúng bước — thường là có người vừa xử lý trước.</summary>
    public const string WrongStep = "Return.Back.Err.WrongStep";

    /// <summary>Chỉ sửa được ghi chú khi còn chờ quản lý FA.</summary>
    public const string NotEditable = "Return.Back.Err.NotEditable";

    /// <summary>Đã giao xong — không sửa, không huỷ được nữa.</summary>
    public const string AlreadyDelivered = "Return.Back.Err.AlreadyDelivered";

    /// <summary>Đã giao dở — hàng ở FA rồi, không huỷ được.</summary>
    public const string PartlyDelivered = "Return.Back.Err.PartlyDelivered";

    /// <summary>Mọi mã quét ra đều không có trong hệ thống.</summary>
    public const string LotNotFound = "Return.Back.Err.LotNotFound";

    /// <summary>Pallet có thật nhưng không còn con nào của phiếu này.</summary>
    public const string NothingToDeliver = "Return.Back.Err.NothingToDeliver";

    public const string ValueTooLong = "Return.Back.Err.ValueTooLong";

    /// <summary>Cùng một model gửi hai dòng trong một đề nghị.</summary>
    public const string ModelDuplicated = "Return.Back.Err.ModelDuplicated";

    /// <summary>Model không có trong phiếu — không lấy về từ phiếu này được.</summary>
    public const string ModelNotInDoc = "Return.Back.Err.ModelNotInDoc";

    /// <summary>Xin nhiều hơn SL đang còn ở kho.</summary>
    public const string QtyOverRemain = "Return.Back.Err.QtyOverRemain";
}
