import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';

/// Thẻ đầu chế độ kiểm: nút đổi container + số container + loại / seal / SI.
/// Cùng bố cục với KittingHeaderCard cho thống nhất.
class ContainerHeaderCard extends StatelessWidget {
  final ContainerItem item;

  /// Về danh sách để chọn container khác. null = khoá (đang gửi kết quả).
  final VoidCallback? onChange;

  const ContainerHeaderCard({super.key, required this.item, this.onChange});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(
        children: [
          Tooltip(
            message: LocaleKeys.container_check_change_container.tr(),
            child: InkWell(
              onTap: onChange,
              customBorder: const CircleBorder(),
              child: SizedBox.square(
                dimension: AppDimens.hitMd,
                child: Center(
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: onChange == null
                          ? swms.warning.withValues(alpha: 0.4)
                          : swms.warning,
                      borderRadius: BorderRadius.circular(AppDimens.rInput - 2),
                    ),
                    child: const Icon(
                      Icons.swap_horiz,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.containerNo,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 15,
                    letterSpacing: 0,
                    fontWeight: FontWeight.w700,
                    color: swms.text1,
                  ),
                ),
                Text(
                  LocaleKeys.container_check_header_meta.tr(namedArgs: {
                    'type': item.type,
                    'seal': item.sealNo,
                    'si': item.siCode,
                  }),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}