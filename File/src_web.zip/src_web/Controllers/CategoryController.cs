﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;


namespace SWMS_WebTool.Controllers
{
    public class CategoryController : BaseController
    {
        private readonly ApiService _apiService;
        public CategoryController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] CategoryFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new CategoryFilter();
                var response = await _apiService.SearchCategory(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<Category>();

                var model = new CategoryViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]     
        public IActionResult CreateCategory()
        {
            Category model = new();
            return PartialView("~/Views/Category/_CreateUpdateCategoryModal.cshtml", model);
        }        

        [HttpPost]
        public async Task<IActionResult> UpdateCategory(long categoryId)
        {
            var model = new Category();
            var data = await _apiService.SearchCategory(new CategoryFilter(), 1, 0);
            var categories = data.Records;
            var categoryObj = categories?.FirstOrDefault(t => t.CategoryID == categoryId);

            if (categoryObj != null) 
            {
                model.CategoryID = categoryObj.CategoryID;
                model.Plant = categoryObj.Plant;
                model.CategoryName = categoryObj.CategoryName;
                model.ShortName = categoryObj.ShortName;
                model.Color = categoryObj.Color;
            }
            
            return PartialView("~/Views/Category/_CreateUpdateCategoryModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> Save(Category model)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var request = new Category()
                {
                    CategoryID = model.CategoryID, 
                    Plant = model.Plant,
                    CategoryName = model.CategoryName,
                    ShortName = model.ShortName,
                    Color = model.Color
                };
                await _apiService.SaveCategory(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }

        [HttpPost]
        public IActionResult Delete(string id)
        {
            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDelete",
                Controller = "Category",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDelete(string id)
        {
            try
            {
                await _apiService.DeleteCategory(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }
    }
}