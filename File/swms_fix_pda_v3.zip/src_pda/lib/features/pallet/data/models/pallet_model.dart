import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/sap_status.dart';
import 'package:swms_finish_goods/shared/domain/entities/stock_event.dart';

part 'pallet_model.g.dart';

/// Khớp `PalletDetailResponse` — cấu trúc chuẩn của
/// `GET /api/pallets/by-lot-no/{lotNo}?include=boxes,history`.
///
/// `boxes` / `history` / `suggestedLocator` là null khi client không yêu cầu
/// qua `include`; list quy về rỗng, suggestion giữ null.
@JsonSerializable()
class PalletModel {
  final int id;
  final String lotNo;
  final int categoryCode;
  final String? categoryName;
  final String lotType;
  final String? stockyCode;
  final String detailLevel;
  final int? boxCount;
  final int? totalQty;
  final String inspectionStatus;

  /// `rework` | `refurbish` | null — hàng back. Dùng để in badge RW / RB
  /// trên tem khi in lại từ màn này.
  final String? disposition;

  final bool isUrgent;
  final int? sapStatus;
  final DateTime? sapPushedAt;
  final DateTime? productionDate;
  final String? models;

  @JsonKey(name: 'modelSummary', defaultValue: <PalletModelQtyModel>[])
  final List<PalletModelQtyModel> modelQtys;

  final int? locatorId;
  final String? locatorCode;
  final String? areaCode;
  final String? areaName;

  /// "assign" | "release" | "move" | "store"
  @JsonKey(defaultValue: <String>[])
  final List<String> allowedActions;

  /// Chỉ có khi `include=suggestion`.
  final LocatorSuggestionModel? suggestedLocator;

  @JsonKey(defaultValue: <PalletBoxModel>[])
  final List<PalletBoxModel> boxes;

  /// BREAKING: shape đã đổi từ `PalletHistoryModel` (locatorCode/fromStatus/
  /// toStatus/changedAt/changedBy) sang [PalletEventBriefModel].
  @JsonKey(defaultValue: <PalletEventBriefModel>[])
  final List<PalletEventBriefModel> history;

  const PalletModel({
    required this.id,
    required this.lotNo,
    required this.categoryCode,
    required this.lotType,
    required this.detailLevel,
    required this.inspectionStatus,
    required this.isUrgent,
    this.categoryName,
    this.stockyCode,
    this.disposition,
    this.allowedActions = const [],
    this.boxCount,
    this.totalQty,
    this.sapStatus,
    this.sapPushedAt,
    this.productionDate,
    this.models,
    this.modelQtys = const [],
    this.locatorId,
    this.locatorCode,
    this.areaCode,
    this.areaName,
    this.suggestedLocator,
    this.boxes = const [],
    this.history = const [],
  });

  factory PalletModel.fromJson(Map<String, dynamic> json) =>
      _$PalletModelFromJson(json);

  Map<String, dynamic> toJson() => _$PalletModelToJson(this);

  Pallet toEntity() => Pallet(
    id: id,
    lotNo: lotNo,
    categoryCode: categoryCode,
    categoryName: categoryName,
    lotType: lotType,
    stockyCode: stockyCode,
    detailLevel: detailLevel,
    boxCount: boxCount,
    totalQty: totalQty,
    inspectionStatus: InspectionStatus.fromKey(inspectionStatus),
    disposition: disposition,
    isUrgent: isUrgent,
    sapStatus: SapStatus.fromCode(sapStatus),
    sapPushedAt: sapPushedAt,
    productionDate: productionDate,
    models: models,
    modelQtys: modelQtys.map((e) => e.toEntity()).toList(),
    locatorId: locatorId,
    locatorCode: locatorCode,
    areaCode: areaCode,
    areaName: areaName,
    // Bỏ mã lạ để UI không vỡ nếu API thêm action mới.
    allowedActions: allowedActions
        .map(PalletAction.fromCode)
        .whereType<PalletAction>()
        .toList(),
    suggestedLocator: suggestedLocator?.toEntity(),
    boxes: boxes.map((e) => e.toEntity()).toList(),
    history: history.map((e) => e.toEntity()).toList(),
  );
}

/// Khớp `LocatorSuggestionResponse`.
@JsonSerializable()
class LocatorSuggestionModel {
  final int locatorId;
  final String locatorCode;
  final String? areaCode;
  final String? areaName;
  final String? reason;

  const LocatorSuggestionModel({
    required this.locatorId,
    required this.locatorCode,
    this.areaCode,
    this.areaName,
    this.reason,
  });

  factory LocatorSuggestionModel.fromJson(Map<String, dynamic> json) =>
      _$LocatorSuggestionModelFromJson(json);

  Map<String, dynamic> toJson() => _$LocatorSuggestionModelToJson(this);

  LocatorSuggestion toEntity() => LocatorSuggestion(
    locatorId: locatorId,
    locatorCode: locatorCode,
    areaCode: areaCode,
    areaName: areaName,
    reason: reason,
  );
}

/// Khớp `PalletModelSummary`: { model, qty, boxCount }.
@JsonSerializable()
class PalletModelQtyModel {
  final String model;

  @JsonKey(name: 'qty')
  final int totalQty;

  @JsonKey(defaultValue: 0)
  final int boxCount;

  const PalletModelQtyModel({
    required this.model,
    required this.totalQty,
    this.boxCount = 0,
  });

  factory PalletModelQtyModel.fromJson(Map<String, dynamic> json) =>
      _$PalletModelQtyModelFromJson(json);

  Map<String, dynamic> toJson() => _$PalletModelQtyModelToJson(this);

  PalletModelQty toEntity() =>
      PalletModelQty(model: model, totalQty: totalQty, boxCount: boxCount);
}

@JsonSerializable()
class PalletBoxModel {
  final int id;
  final String boxNo;
  /// Chuỗi QR quét gốc của thùng. NULL ĐƯỢC.
  ///
  /// API khai `string? RawPayload`, và thùng của pallet hàng return KHÔNG có
  /// payload (`ReturnPalletRequestFactory` tạo thùng với `RawPayload: null`) —
  /// serial do WH quét tay, không có tem QR gốc nào.
  ///
  /// Khai `String` (không null) ở đây làm `json['payload'] as String` ném
  /// TypeError, hỏng CẢ response, và màn hình chỉ hiện "không tải được" dù API
  /// trả 200 đầy đủ. Entity PalletBox từ đầu đã khai nullable — chỗ lệch là
  /// model này.
  final String? payload;

  @JsonKey(defaultValue: <PalletBoxLineModel>[])
  final List<PalletBoxLineModel> lines;

  const PalletBoxModel({
    required this.id,
    required this.boxNo,
    this.payload,
    this.lines = const [],
  });

  factory PalletBoxModel.fromJson(Map<String, dynamic> json) =>
      _$PalletBoxModelFromJson(json);

  Map<String, dynamic> toJson() => _$PalletBoxModelToJson(this);

  PalletBox toEntity() => PalletBox(
    id: id,
    boxNo: boxNo,
    payload: payload,
    lines: lines.map((e) => e.toEntity()).toList(),
  );
}

@JsonSerializable()
class PalletBoxLineModel {
  final int id;
  final String model;

  // API trả decimal -> nhận num rồi ép int.
  @JsonKey(fromJson: _qtyFromJson)
  final int qty;

  final String? serialNo;

  const PalletBoxLineModel({
    required this.id,
    required this.model,
    required this.qty,
    this.serialNo,
  });

  static int _qtyFromJson(dynamic v) => v == null ? 0 : (v as num).round();

  factory PalletBoxLineModel.fromJson(Map<String, dynamic> json) =>
      _$PalletBoxLineModelFromJson(json);

  Map<String, dynamic> toJson() => _$PalletBoxLineModelToJson(this);

  PalletBoxLine toEntity() =>
      PalletBoxLine(id: id, model: model, qty: qty, serialNo: serialNo);
}

/// Khớp `PalletEventBriefResponse` — 4 trường, tối đa 10 mốc gần nhất.
///
/// THAY THẾ `PalletHistoryModel`. Bản cũ đọc `wms.locator_status_history`
/// (đã bỏ) và không phân biệt được gán tạm / lưu kho / vanning vì mọi thao tác
/// đều ghi cùng một trạng thái `assigned`.
@JsonSerializable()
class PalletEventBriefModel {
  /// Mã event, vd `STORAGE_IN`. Nhãn tra qua i18n `stock_event.<CODE>`.
  final String eventCode;

  final DateTime eventAt;

  /// Tên người thao tác.
  final String? actor;

  /// Vị trí đích. Null với event không đổi vị trí.
  final String? toLocatorCode;

  const PalletEventBriefModel({
    required this.eventCode,
    required this.eventAt,
    this.actor,
    this.toLocatorCode,
  });

  factory PalletEventBriefModel.fromJson(Map<String, dynamic> json) =>
      _$PalletEventBriefModelFromJson(json);

  Map<String, dynamic> toJson() => _$PalletEventBriefModelToJson(this);

  PalletEvent toEntity() => PalletEvent(
    eventCode: eventCode,
    eventAt: eventAt,
    actor: actor,
    toLocatorCode: toLocatorCode,
  );
}