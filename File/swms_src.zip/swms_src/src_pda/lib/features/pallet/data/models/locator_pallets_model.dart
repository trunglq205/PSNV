import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/locator_occupancy.dart';

part 'locator_pallets_model.g.dart';

@JsonSerializable()
class LocatorPalletsModel {
  final int locatorId;
  final String locatorCode;
  final String? areaCode;
  final String? areaName;
  final String? mapType;
  final List<String> pallets;

  const LocatorPalletsModel({
    required this.locatorId,
    required this.locatorCode,
    this.areaCode,
    this.areaName,
    this.mapType,
    this.pallets = const [],
  });

  factory LocatorPalletsModel.fromJson(Map<String, dynamic> json) =>
      _$LocatorPalletsModelFromJson(json);

  LocatorOccupancy toEntity() => LocatorOccupancy(
    locatorCode: locatorCode,
    areaCode: areaCode,
    areaName: areaName,
    mapType: mapType,
    pallets: pallets,
  );
}
