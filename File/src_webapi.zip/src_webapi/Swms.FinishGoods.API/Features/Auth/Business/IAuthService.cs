namespace Swms.FinishGoods.API.Features.Auth;

public interface IAuthService
{
    // Trả null nếu sai credential / user bị khóa.
    Task<LoginResponse> LoginAsync(LoginRequest request);
}
