import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';
import 'package:swms_finish_goods/features/container_check/domain/repositories/container_check_repository.dart';
import 'package:swms_finish_goods/features/container_check/presentation/providers/container_check_providers.dart';
import 'package:swms_finish_goods/features/container_check/presentation/providers/container_check_state.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'container_check_notifier.g.dart';

@riverpod
class ContainerCheckNotifier extends _$ContainerCheckNotifier
    with BaseNotifierMixin<ContainerCheckState> {
  ContainerCheckRepository get _repo => ref.read(containerCheckRepositoryProvider);

  /// Tăng mỗi lần mở / đóng container → chi tiết về muộn của container cũ
  /// không đè lên container đang mở.
  int _seq = 0;

  @override
  ContainerCheckState build() => const ContainerCheckState();

  void initData() => _loadContainers();

  // ── Danh sách ──────────────────────────────────────────────
  Future<void> _loadContainers() => executePartial<List<ContainerItem>>(
        action: _repo.getContainers,
        getField: (s) => s.containers,
        setField: (s, v) => s.copyWith(containers: v),
      );

  Future<void> refresh() => _loadContainers();

  /// Quét QR container → mở chế độ kiểm.
  ///
  /// Đang kiểm thì bỏ qua: quét nhầm container khác giữa chừng mà tự nhảy
  /// sang thì mất checklist / ảnh đang làm dở. Muốn đổi thì đóng (X) trước.
  ///
  /// Tìm trong danh sách đang hiển thị trước cho nhanh; không có (danh sách
  /// cũ / chưa tải xong / container ca khác) thì hỏi server.
  Future<void> onScan(String raw) async {
    final code = raw.trim();
    if (code.isEmpty || state.resolving || state.inspecting) return;

    for (final c in state.containers.value ?? const <ContainerItem>[]) {
      if (c.matches(code)) return open(c);
    }

    state = state.copyWith(resolving: true);
    final found = await ref
        .read(appActionProvider.notifier)
        .run(() => _repo.getByContainerNo(code));
    state = state.copyWith(resolving: false);
    if (found != null) await open(found);
  }

  // ── Chế độ kiểm ────────────────────────────────────────────
  Future<void> open(ContainerItem item) async {
    final seq = ++_seq;
    state = state.openInspection(item);
    await _loadDetail(seq);
  }

  /// Thử lại sau lỗi: về loading trước để skeleton hiện lại.
  Future<void> reloadDetail() {
    state = state.copyWith(detail: const AsyncValue.loading());
    return _loadDetail(_seq);
  }

  /// Tự quản loading thay vì executePartial: state đã ở loading từ
  /// openInspection, chỉ cần ghi kết quả — và bỏ kết quả nếu container đã
  /// đóng / đổi trong lúc chờ.
  Future<void> _loadDetail(int seq) async {
    final id = state.selected?.id;
    if (id == null) return;

    final result = await AsyncValue.guard(() => _repo.getDetail(id));
    if (seq != _seq) return;
    state = state.copyWith(detail: result);
  }

  /// Về danh sách. UI hỏi xác nhận trước nếu [ContainerCheckState.dirty].
  void close() {
    if (state.submitting) return;
    _seq++;
    state = state.closeInspection();
  }

  // ── Checklist ──────────────────────────────────────────────
  void toggle(ContainerCondition c) {
    if (!state.editable) return;
    final next = Set<ContainerCondition>.from(state.checked);
    if (!next.remove(c)) next.add(c);
    state = state.copyWith(checked: next);
  }

  // ── Ảnh ────────────────────────────────────────────────────
  /// Chụp lại góc đã có → thay ảnh cũ (mỗi góc đúng 1 ảnh).
  void setPhoto(ContainerPhotoSlot slot, String path) {
    if (!state.editable) return;
    state = state.copyWith(photos: {...state.photos, slot: path});
  }

  void removePhoto(ContainerPhotoSlot slot) {
    if (!state.editable) return;
    state = state.copyWith(photos: {...state.photos}..remove(slot));
  }

  // ── Chốt kết quả ───────────────────────────────────────────
  /// `true` khi đã lưu → đã về danh sách và tải lại để trạng thái cập nhật.
  Future<bool> submitPass() => _submit(InspectionResult.pass);

  Future<bool> submitFail(String note) =>
      _submit(InspectionResult.fail, note: note.trim());

  Future<bool> _submit(InspectionResult result, {String? note}) async {
    final item = state.selected;
    if (item == null || !state.editable) return false;

    state = state.copyWith(submitting: true);
    final ok = await ref.read(appActionProvider.notifier).run(() async {
      if (result == InspectionResult.pass &&
          !(state.allChecked && state.allPhotos)) {
        throw const ContainerInspectionIncompleteException();
      }
      if (result == InspectionResult.fail && (note == null || note.isEmpty)) {
        throw const ContainerFailNoteRequiredException();
      }

      await _repo.submitInspection(ContainerInspection(
        containerId: item.id,
        result: result,
        passedConditions: state.checked,
        photos: state.photos,
        note: note,
      ));
      return true;
    });

    if (ok != true) {
      // Lỗi đã được appActionProvider báo; giữ checklist / ảnh để bấm lại.
      state = state.copyWith(submitting: false);
      return false;
    }

    _seq++;
    state = state.closeInspection();
    await _loadContainers();
    return true;
  }
}
