import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/shipment_instruction/data/models/pick_task_detail_model.dart';
import 'package:swms_finish_goods/features/shipment_instruction/data/models/shipment_instruction_model.dart';

part 'shipment_instruction_remote_data_source.g.dart';

@RestApi()
abstract class ShipmentInstructionRemoteDataSource {
  factory ShipmentInstructionRemoteDataSource(Dio dio, {String baseUrl}) =
  _ShipmentInstructionRemoteDataSource;

  /// Danh sách chỉ thị, phân trang. [status] null = tất cả trạng thái.
  @GET('/api/shipment-instructions')
  Future<ShipmentInstructionPageModel> fetchList({
    @Query('docStatus') String? docStatus,
    @Query('page') int? page,
    @Query('size') int? size,
  });

  /// Chi tiết chỉ thị + dòng hàng.
  @GET('/api/shipment-instructions/{id}')
  Future<ShipmentInstructionDetailModel> fetchDetail(@Path('id') int id);

  // ── Lấy hàng (PDA) ──────────────────────────────────────
  @GET('/api/shipment-instructions/tasks/{taskId}/pick')
  Future<PickTaskDetailModel> fetchPickTask(@Path('taskId') int taskId);

  @POST('/api/shipment-instructions/tasks/{taskId}/confirm-pallet')
  Future<PickTaskDetailModel> confirmPallet(
      @Path('taskId') int taskId,
      @Body() ConfirmPalletRequest body,
      );

  @POST('/api/shipment-instructions/tasks/{taskId}/boxes')
  Future<PickTaskDetailModel> pickBox(
      @Path('taskId') int taskId,
      @Body() PickBoxRequest body,
      );

  @DELETE('/api/shipment-instructions/tasks/{taskId}/boxes/{boxNo}')
  Future<PickTaskDetailModel> unpickBox(
      @Path('taskId') int taskId,
      @Path('boxNo') String boxNo,
      );

  /// Lưu pallet tại vị trí vanning — bước cuối của mọi task.
  @POST('/api/shipment-instructions/tasks/{taskId}/vanning')
  Future<PickTaskDetailModel> stageVanning(
      @Path('taskId') int taskId,
      @Body() StageVanningRequest body,
      );
}