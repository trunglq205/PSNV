import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/return_instruction/data/return_fa_pallet_repository.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_pallet_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Provider của mục 2d — khai THỦ CÔNG, không dùng @riverpod.
//
//  Cùng lý do đã ghi ở return_fa_pallet_model.dart: bộ mục 2d làm sao để không
//  cần chạy build_runner. `@riverpod` sinh `.g.dart`, provider thủ công thì
//  không. Đây là cách `errorHandlerProvider` và `pdaProvider` trong core vẫn
//  đang dùng, nên không phải lối đi lạ trong source này.
// ─────────────────────────────────────────────────────────────

final returnFaPalletRepositoryProvider = Provider<ReturnFaPalletRepository>(
  (ref) => ReturnFaPalletRepository(ref.watch(dioProvider)),
);

/// Sổ serial của phiếu, đã dựng sẵn thành [FaSerialIndex] để tra theo mã.
///
/// Dựng Map NGAY TRONG provider, không để màn hình tự dựng mỗi lần build: một
/// phiếu vài nghìn serial mà dựng lại Map ở mỗi lần vẽ là treo máy PDA.
///
/// `docId` là tham số family nên phải so sánh được bằng `==` — int thì được.
final faSerialIndexProvider =
    FutureProvider.family<FaSerialIndex, int>((ref, docId) async {
  final rows =
      await ref.watch(returnFaPalletRepositoryProvider).fetchSerialIndex(docId);
  return FaSerialIndex(rows);
});

/// Nhật ký serial lệch còn mở của một phiếu.
final faMismatchesProvider =
    FutureProvider.family<List<FaMismatch>, int>((ref, docId) => ref
        .watch(returnFaPalletRepositoryProvider)
        .fetchMismatches(docId, openOnly: true));
