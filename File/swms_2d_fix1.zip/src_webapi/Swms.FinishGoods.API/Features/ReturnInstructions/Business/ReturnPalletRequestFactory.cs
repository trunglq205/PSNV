using Swms.FinishGoods.API.Features.Pallets.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

/// <summary>
/// Dựng <see cref="CreatePalletRequest"/> cho pallet hàng back.
///
/// Tách ra khỏi service vì hai luồng cùng cần ĐÚNG cái khuôn này:
///   mục 2a — SCS WH đóng pallet lúc nhận hàng khách trả
///   mục 2d — FA đóng pallet mới sau khi rework xong
/// Để mỗi service tự dựng thì hai bên sẽ lệch nhau lúc nào không biết, mà pallet
/// hàng back phải luôn ở mức serial và luôn một category — lệch là vỡ Pallet ID.
/// </summary>
internal static class ReturnPalletRequestFactory
{
    /// <summary>
    /// Pallet mức SERIAL: model nằm ở từng dòng box, không nằm trên header; SL
    /// mỗi dòng bị server ép = 1; <c>BoxCount</c> và <c>ProductionDate</c> để
    /// server tự tính từ box.
    /// </summary>
    public static CreatePalletRequest Build(
        string lotNo,
        int categoryCode,
        IReadOnlyList<(string BoxNo, string Model, List<string> Serials)> boxes)
    {
        var now = DateTime.Now;

        return new CreatePalletRequest(
            DetailLevel: PalletDetailLevel.Serial,
            LotNo: lotNo,
            CategoryCode: categoryCode,
            LotType: PalletType.Pallet,
            StockyCode: null,
            Model: null,              // mức serial: model nằm ở từng dòng
            StandardPacking: null,
            ProductionDate: null,     // mức serial: server tính MIN từ box
            BoxCount: null,           // mức serial: server tự đếm
            Boxes: boxes.Select(b => new CreateBoxRequest(
                BoxNo: b.BoxNo,
                PsnvPo: null,
                CustomerPo: null,
                ProductionDate: now,
                RawPayload: null,
                Lines: b.Serials.Select(s => new CreateBoxLineRequest(
                    Model: b.Model,
                    Qty: null,        // mức serial: server ép = 1
                    SerialNo: s,
                    ProductionDate: now,
                    CartonCount: null)).ToList())).ToList());
    }
}
