using Dapper;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Pallets.DataAccess
{
    public class StorageSuggestionRepository : IStorageSuggestionRepository
    {
        private readonly IDbConnectionFactory _factory;
        public StorageSuggestionRepository(IDbConnectionFactory factory) => _factory = factory;

        // ─────────────────────────────────────────────────────────────────
        //  TOẠ ĐỘ BẢN ĐỒ (master.locator_map)
        //
        //  target_type:
        //    'rack'    -> phần tử là 1 rack (khớp master.racks qua rack_id)
        //    'locator' -> phần tử là 1 ô chứa pallet (khớp master.locators qua locator_id)
        //    'zone'    -> chỉ để trang trí bản đồ, KHÔNG tham gia tính toán -> lọc bỏ
        //
        //  Một ô có thể được đặt trong bản đồ RACK (parent_type = 'rack') hoặc đặt
        //  thẳng lên bản đồ KHU. Cột InRack phân biệt hai trường hợp đó, nên không
        //  cần đoán: đặt trong rack thì cộng thêm offset của rack, đặt thẳng lên khu
        //  thì grid_x/grid_y đã là toạ độ tuyệt đối rồi.
        //
        //  Ô chưa có dòng map -> rơi về rack_col/rack_row của chính locator (cộng
        //  offset rack nếu rack có trên bản đồ). Nhờ vậy locator_map trống vẫn chạy.
        // ─────────────────────────────────────────────────────────────────
        private const string MapCtes = """
            rack_pos AS (
                SELECT  lm.rack_id,
                        MIN(lm.grid_x) AS RackX,
                        MIN(lm.grid_y) AS RackY
                FROM master.locator_map lm
                WHERE lm.target_type = 'rack'
                  AND lm.rack_id IS NOT NULL
                  AND lm.is_deleted = 0 AND lm.is_active = 1
                GROUP BY lm.rack_id
            ),
            loc_pos AS (
                SELECT  lm.locator_id,
                        MIN(lm.grid_x) AS LocX,
                        MIN(lm.grid_y) AS LocY,
                        MAX(CASE WHEN lm.parent_type = 'rack' THEN 1 ELSE 0 END) AS InRack
                FROM master.locator_map lm
                WHERE lm.target_type = 'locator'
                  AND lm.locator_id IS NOT NULL
                  AND lm.is_deleted = 0 AND lm.is_active = 1
                GROUP BY lm.locator_id
            )
            """;

        // Toạ độ tuyệt đối của một ô. Dùng chung cho truy vấn last lot lẫn ứng viên.
        private const string PosX = """
            COALESCE(
                CASE WHEN lp.InRack = 1 THEN COALESCE(rp.RackX, 0) + lp.LocX ELSE lp.LocX END,
                COALESCE(rp.RackX, 0) + COALESCE(loc.rack_col, 0))
            """;

        private const string PosY = """
            COALESCE(
                CASE WHEN lp.InRack = 1 THEN COALESCE(rp.RackY, 0) + lp.LocY ELSE lp.LocY END,
                COALESCE(rp.RackY, 0) + COALESCE(loc.rack_row, 0))
            """;

        // ── Pallet context ────────────────────────────────────────────────

        public Task<PalletSuggestionContext?> GetPalletContextAsync(long palletId)
            => GetPalletContextCoreAsync("p.id = @key", palletId);

        public Task<PalletSuggestionContext?> GetPalletContextByLotNoAsync(string lotNo)
            => GetPalletContextCoreAsync("p.pallet_id = @key", lotNo);

        private async Task<PalletSuggestionContext?> GetPalletContextCoreAsync(string whereClause, object key)
        {
            using var conn = _factory.Create();

            // Model đại diện = model có tổng qty lớn nhất trong lot. Lot box_count không
            // có box_lines nên rơi về lots.model (EffectiveModel xử lý thứ tự ưu tiên).
            var sql = $"""
                SELECT  p.id              AS Id,
                        p.pallet_id       AS LotNo,
                        p.category_id     AS CategoryCode,
                        c.name            AS CategoryName,
                        p.detail_level    AS DetailLevel,
                        p.model           AS LotModel,
                        p.locator_id      AS LocatorId,
                        loc.locator_code  AS LocatorCode,
                        a.area_code       AS AreaCode,
                        (
                            SELECT TOP 1 bl.model
                            FROM wms.boxes b
                            JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                            WHERE b.lot_id = p.id AND b.is_deleted = 0
                            GROUP BY bl.model
                            ORDER BY SUM(bl.qty) DESC, bl.model
                        ) AS DominantModel
                FROM wms.pallets p
                LEFT JOIN master.categories c ON c.code = p.category_id
                LEFT JOIN master.locators loc ON loc.id = p.locator_id
                LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id
                WHERE {whereClause} AND p.is_deleted = 0;
                """;

            return await conn.QueryFirstOrDefaultAsync<PalletSuggestionContext>(sql, new { key });
        }

        // ── Cấu hình gợi ý của model ──────────────────────────────────────

        public async Task<ModelStorageSuggestion?> GetModelSuggestionAsync(string modelCode)
        {
            using var conn = _factory.Create();
            const string sql = """
                SELECT  m.code             AS ModelCode,
                        m.suggest_area     AS SuggestAreaId,
                        wa.area_code       AS SuggestAreaCode,
                        wa.area_name       AS SuggestAreaName,
                        m.suggest_rack_row AS SuggestRackRowRaw
                FROM master.models m
                LEFT JOIN master.warehouse_areas wa
                       ON wa.id = m.suggest_area AND wa.is_deleted = 0
                WHERE m.code = @modelCode AND m.is_deleted = 0;
                """;
            return await conn.QueryFirstOrDefaultAsync<ModelStorageSuggestion>(sql, new { modelCode });
        }

        // ── Last lot ──────────────────────────────────────────────────────

        /// <summary>
        /// Khớp theo model nếu truyền model, ngược lại khớp theo category.
        /// Chỉ xét pallet ĐANG đứng ở một vị trí (locator_id NOT NULL).
        ///
        /// "Gần nhất" tính theo NGÀY SẢN XUẤT (FIFO), không theo lịch sử thao tác.
        ///
        /// SỬA 2 LỖI so với bản cũ:
        ///   1. Bản cũ có HAI cột cùng alias StoredAt (p.production_date và
        ///      COALESCE(h.LastAssignedAt, ...)). Dapper map cột ĐẦU TIÊN nên
        ///      LastLotLocation.StoredAt thực tế luôn = production_date, còn dòng
        ///      COALESCE bị vứt đi. Giờ chỉ còn 1 cột, đúng với cái đang được dùng.
        ///   2. Bỏ OUTER APPLY đọc wms.locator_status_history (bảng đã xoá). Nó chỉ
        ///      tham gia ORDER BY ở vị trí thứ BA, sau production_date DESC — hai lot
        ///      phải cùng ngày SX mới đụng tới — nên bỏ đi gần như không đổi kết quả.
        ///      Tie-break giờ dùng COALESCE(p.updated_at, p.created_at).
        /// </summary>
        public async Task<LastLotLocation?> FindLastLotAsync(
        long excludePalletId, string? model, int? categoryCode, long? areaId, string? areaCode)
        {
            var byModel = !string.IsNullOrWhiteSpace(model);
            if (!byModel && categoryCode is null) return null;

            using var conn = _factory.Create();

            var matchClause = byModel
                ? """
                      (
                          p.model = @model
                          OR EXISTS (
                              SELECT 1
                              FROM wms.boxes b
                              JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                              WHERE b.lot_id = p.id AND b.is_deleted = 0 AND bl.model = @model)
                      )
                      """
                            : "p.category_id = @categoryCode";

            var sql = $"""
                    WITH {MapCtes}
                    SELECT TOP 1
                            p.id             AS PalletId,
                            p.pallet_id      AS LotNo,
                            @model           AS Model,
                            loc.id           AS LocatorId,
                            loc.locator_code AS LocatorCode,
                            a.id             AS AreaId,
                            a.area_code      AS AreaCode,
                            a.area_name      AS AreaName,
                            loc.rack_id      AS RackId,
                            r.rack_code      AS RackCode,
                            r.rack_name      AS RackName,
                            loc.rack_row     AS RackRow,
                            loc.rack_col     AS RackCol,
                            loc.rack_level   AS RackLevel,
                            loc.slot_kind    AS SlotKind,
                            {PosX}           AS PosX,
                            {PosY}           AS PosY,
                            p.production_date AS StoredAt
                    FROM wms.pallets p
                    JOIN master.locators loc
                           ON loc.id = p.locator_id AND loc.is_deleted = 0
                    JOIN master.warehouse_areas a
                           ON a.id = loc.area_id AND a.is_deleted = 0
                    LEFT JOIN master.racks r ON r.id = loc.rack_id AND r.is_deleted = 0
                    LEFT JOIN rack_pos rp ON rp.rack_id = loc.rack_id
                    LEFT JOIN loc_pos  lp ON lp.locator_id = loc.id
                    WHERE p.is_deleted = 0
                      AND p.id <> @excludePalletId
                      AND (@areaId   IS NULL OR loc.area_id  = @areaId)
                      AND (@areaCode IS NULL OR a.area_code  = @areaCode)
                      AND {matchClause}
                    ORDER BY CASE WHEN p.production_date IS NULL THEN 1 ELSE 0 END,
                             p.production_date DESC,
                             COALESCE(p.updated_at, p.created_at) DESC,
                             p.id DESC;
                    """;

            var found = await conn.QueryFirstOrDefaultAsync<LastLotLocation>(
                sql, new { excludePalletId, model, categoryCode, areaId, areaCode });

            if (found is not null)
                found.MatchedBy = byModel ? LastLotMatchedBy.Model : LastLotMatchedBy.Category;
            return found;
        }

        // ── Vị trí trống, đã xếp hạng ─────────────────────────────────────

        /// <summary>
        /// Thứ tự ưu tiên (khớp mô tả nghiệp vụ):
        ///   1. SlotMatch — đúng loại ô: giá lửng ↔ rack thường (xem ghi chú dưới)
        ///   2. RowMatch  — đúng tầng theo master / theo chiều cao
        ///   3. SameRack  — cùng rack với last lot
        ///   4. Dy        — cùng hàng ngang trước (trái/phải), rồi mới lệch tầng (trên/dưới)
        ///   5. Dx        — trong cùng hàng thì gần nhất trước
        ///   6. sort_order / locator_code — chốt hạ để kết quả ổn định
        ///
        /// SlotMatch xếp TRƯỚC RowMatch vì loại ô là ràng buộc vật lý hai chiều:
        ///   • nhắm giá lửng (pallet &lt;= 70cm) -> chỉ ô slot_kind = 'shelf' mới khớp
        ///   • nhắm tầng 1..4 (rack thường)     -> ô giá lửng KHÔNG khớp, bị đẩy xuống cuối
        /// Nếu để RowMatch trước, ô lửng (rack_row có thể trùng số tầng) sẽ chen lên
        /// đầu danh sách khi pallet cao — sai vật lý.
        ///
        /// Không có last lot -> @randomize = 1, chèn NEWID() sau 2 tiêu chí đầu để
        /// rải đều thay vì luôn trả cùng một ô. Muốn kết quả tất định thì bỏ nhánh này.
        ///
        /// Tầng và loại ô vẫn là ưu tiên MỀM, không lọc cứng: hết chỗ đúng loại vẫn trả
        /// vị trí khác kèm cảnh báo, để PDA không bị bí. Muốn chặn cứng thì thêm điều
        /// kiện vào mệnh đề WHERE của CTE free.
        /// </summary>
        public async Task<IReadOnlyList<LocatorCandidate>> FindFreeLocatorsAsync(LocatorSearchCriteria c)
        {
            using var conn = _factory.Create();

            var hasRef = c.Reference is not null;
            var hasRowPref = c.RackRows.Count > 0;
            var wantShelf = string.Equals(c.SlotKind, SlotKinds.Shelf, StringComparison.OrdinalIgnoreCase);

            var sql = $"""
                WITH {MapCtes},
                free AS (
                    SELECT  loc.id           AS LocatorId,
                            loc.locator_code AS LocatorCode,
                            a.id             AS AreaId,
                            a.area_code      AS AreaCode,
                            a.area_name      AS AreaName,
                            loc.rack_id      AS RackId,
                            r.rack_code      AS RackCode,
                            r.rack_name      AS RackName,
                            loc.rack_row     AS RackRow,
                            loc.rack_col     AS RackCol,
                            loc.rack_level   AS RackLevel,
                            loc.slot_kind    AS SlotKind,
                            loc.sort_order   AS SortOrder,
                            CAST(CASE WHEN loc.slot_kind = @shelfKind THEN 1 ELSE 0 END AS bit) AS IsShelf,
                            {PosX}           AS PosX,
                            {PosY}           AS PosY
                    FROM master.locators loc
                    JOIN master.warehouse_areas a
                           ON a.id = loc.area_id AND a.is_deleted = 0
                    LEFT JOIN master.racks r ON r.id = loc.rack_id AND r.is_deleted = 0
                    LEFT JOIN rack_pos rp ON rp.rack_id = loc.rack_id
                    LEFT JOIN loc_pos  lp ON lp.locator_id = loc.id
                    WHERE loc.is_deleted = 0
                      AND loc.is_active = 1
                      AND (@areaId   IS NULL OR loc.area_id = @areaId)
                      AND (@areaCode IS NULL OR a.area_code = @areaCode)
                      -- "Trống" = chưa pallet nào chưa xoá trỏ tới. Không dựa vào
                      -- locators.current_status để tránh lệch khi cột đó chưa được đồng bộ.
                      AND NOT EXISTS (
                          SELECT 1 FROM wms.pallets p
                          WHERE p.locator_id = loc.id AND p.is_deleted = 0)
                )
                SELECT TOP (@take)
                        f.LocatorId, f.LocatorCode,
                        f.AreaId, f.AreaCode, f.AreaName,
                        f.RackId, f.RackCode, f.RackName,
                        f.RackRow, f.RackCol, f.RackLevel, f.SlotKind, f.IsShelf,
                        f.PosX, f.PosY,
                        CAST(CASE WHEN @hasRowPref = 1 AND f.RackRow IN @rackRows
                                  THEN 1 ELSE 0 END AS bit) AS RowMatch,
                        CAST(CASE
                                 -- nhắm giá lửng: chỉ ô lửng mới khớp
                                 WHEN @wantShelf  = 1 THEN CASE WHEN f.IsShelf = 1 THEN 1 ELSE 0 END
                                 -- nhắm tầng rack thường: ô lửng không khớp
                                 WHEN @hasRowPref = 1 THEN CASE WHEN f.IsShelf = 1 THEN 0 ELSE 1 END
                                 -- không ràng buộc gì
                                 ELSE 1
                             END AS bit) AS SlotMatch,
                        CAST(CASE WHEN @refRackId IS NOT NULL AND f.RackId = @refRackId
                                  THEN 1 ELSE 0 END AS bit) AS SameRack,
                        ABS(f.PosY - @refY) AS Dy,
                        ABS(f.PosX - @refX) AS Dx
                FROM free f
                ORDER BY
                        SlotMatch DESC,
                        RowMatch  DESC,
                        CASE WHEN @randomize = 1 THEN NEWID() ELSE NULL END,
                        SameRack  DESC,
                        Dy, Dx,
                        f.SortOrder, f.LocatorCode;
                """;

            var rows = await conn.QueryAsync<LocatorCandidate>(sql, new
            {
                areaId = c.AreaId,
                areaCode = c.AreaCode,
                take = Math.Max(1, c.Take),
                shelfKind = SlotKinds.Shelf,
                wantShelf = wantShelf ? 1 : 0,
                hasRowPref = hasRowPref ? 1 : 0,
                // Dapper mở rộng IN @rackRows; list rỗng sinh ra mệnh đề luôn false,
                // đã được @hasRowPref chặn trước nên không ảnh hưởng kết quả.
                rackRows = hasRowPref ? c.RackRows : new List<int> { -1 },
                refRackId = c.Reference?.RackId,
                refX = c.Reference?.PosX ?? 0,
                refY = c.Reference?.PosY ?? 0,
                randomize = hasRef ? 0 : 1,
            });

            return rows.ToList();
        }
    }
}
