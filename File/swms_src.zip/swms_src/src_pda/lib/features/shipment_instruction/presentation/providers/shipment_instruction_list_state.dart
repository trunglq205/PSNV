import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';

class ShipmentInstructionListState {
  /// Các trang đã tải, gộp dần khi cuộn.
  final AsyncValue<ShipmentInstructionPage> page;

  /// Tab đang chọn. null = "Tất cả".
  final SiStatus? filter;

  /// Badge trên thanh lọc. Giữ RIÊNG khỏi [page]: đổi tab thì [page] về
  /// loading, nếu đọc số đếm từ đó badge sẽ nháy mất rồi hiện lại.
  final Map<SiStatus, int>? statusCounts;

  final bool isLoadingMore;
  final bool loadMoreFailed;

  const ShipmentInstructionListState({
    this.page = const AsyncValue.loading(),
    this.filter = SiStatus.picking,
    this.statusCounts,
    this.isLoadingMore = false,
    this.loadMoreFailed = false,
  });

  static const _unset = Object();

  /// [filter] dùng sentinel vì null là giá trị hợp lệ ("Tất cả").
  ShipmentInstructionListState copyWith({
    AsyncValue<ShipmentInstructionPage>? page,
    Object? filter = _unset,
    Map<SiStatus, int>? statusCounts,
    bool? isLoadingMore,
    bool? loadMoreFailed,
  }) => ShipmentInstructionListState(
    page: page ?? this.page,
    filter: identical(filter, _unset) ? this.filter : filter as SiStatus?,
    statusCounts: statusCounts ?? this.statusCounts,
    isLoadingMore: isLoadingMore ?? this.isLoadingMore,
    loadMoreFailed: loadMoreFailed ?? this.loadMoreFailed,
  );
}
