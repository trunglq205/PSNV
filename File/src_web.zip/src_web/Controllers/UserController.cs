using System.Linq;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class UserController : BaseController
    {
        private readonly ApiService _apiService;

        public UserController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] UserFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new UserFilter();
                var response = await _apiService.SearchUsers(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<User>();

                var model = new UserViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/User/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public IActionResult CreateUser()
        {
            return PartialView("~/Views/User/_CreateUpdateUserModal.cshtml", new User());
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmCreateUser(User user)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var request = new CreateUserRequest()
                {
                    UserID = user.ID,
                    UserFullName = user.FullName,
                    SectionID = int.Parse(user.Section.ToEnumMemberAttrValue()),
                    PositionUserID = int.Parse(user.Role.ToEnumMemberAttrValue()),
                    Password = "1",
                    WebRole = string.Join(";", user.WebRole.Select(e => e.GetString())),
                    PdaRole = string.Join(";", user.PDARole.Select(e => e.GetString())),
                };
                await _apiService.CreateUser(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> UpdateUser(string userId)
        {
            try {
                var user = await _apiService.GetUserByUserId(userId);
                return PartialView("~/Views/User/_CreateUpdateUserModal.cshtml", user);
            } catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmUpdateUser(User model)
        {
            try
            {
                var request = new CreateUserRequest()
                {
                    UserID = model.ID,
                    UserFullName = model.FullName,
                    SectionID = int.Parse(model.Section.ToEnumMemberAttrValue()),
                    PositionUserID = int.Parse(model.Role.ToEnumMemberAttrValue()),
                    WebRole = string.Join(";", model.WebRole.Select(e => e.GetString())),
                    PdaRole = string.Join(";", model.PDARole.Select(e => e.GetString())),
                };
                await _apiService.CreateUser(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }

        [HttpPost]
        public IActionResult DeleteUser(string id)
        {
            if (id == "9999999")
            {
                return BadRequest(_loc.Get("Field_ThisUserCannotBeDeleted"));
            }

            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDeleteUser",
                Controller = "User",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteUser(string id)
        {
            try
            {
                await _apiService.DeleteUser(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }
    }
}

