namespace Swms.FinishGoods.API.Features.Pallets.Business.Entities
{
    /// <summary>Giá trị cột master.locators.slot_kind.</summary>
    public static class SlotKinds
    {
        /// <summary>Giá lửng — dành cho pallet thấp (&lt;= 70cm). Ô lửng có rack_level = 'A' | 'B'.</summary>
        public const string Shelf = "shelf";

        /// <summary>Ô rack thường — rack_level IS NULL, tầng nằm ở rack_row (1..4).</summary>
        public const string Rack = "rack";
    }

    /// <summary>
    /// Quy tắc chọn tầng rack theo chiều cao pallet, dùng khi model KHÔNG có
    /// cấu hình suggest_area / suggest_rack_row trong master.models.
    ///
    /// Bảng quy tắc đọc từ trên xuống, gặp ngưỡng đầu tiên thoả là dừng:
    ///   &lt;= 70cm  -> giá lửng (slot_kind = shelf), không xét tầng
    ///   &lt;= 135cm -> tầng 2, 3
    ///   &lt;= 155cm -> tầng 1
    ///   còn lại    -> tầng 4   (tầng trên cùng, không bị chặn nóc)
    ///
    /// Lưu ý "tầng" ở đây là cột master.locators.rack_row — cùng ngữ nghĩa với
    /// master.models.suggest_rack_row.
    ///
    /// Cột rack_level là chuyện KHÁC: nó chỉ có giá trị ('A' | 'B') ở ô giá lửng,
    /// rack thường để NULL. Vì vậy khi nhắm tầng 1..4 phải đẩy ô lửng xuống cuối,
    /// và ngược lại — xem cờ SlotMatch trong StorageSuggestionRepository.
    /// </summary>
    public static class PalletHeightRule
    {
        public const int ShelfMaxCm = 70;
        public const int Row23MaxCm = 135;
        public const int Row1MaxCm = 155;

        /// <summary>Tầng cao nhất — pallet quá cao thì để tầng trên cùng.</summary>
        public const int TopRow = 4;

        public static (string? SlotKind, IReadOnlyList<int> RackRows) Resolve(int? heightCm)
        {
            // Không biết chiều cao -> không ràng buộc tầng, chỉ gợi ý theo khoảng cách.
            if (heightCm is null || heightCm <= 0) return (null, []);

            if (heightCm <= ShelfMaxCm) return (SlotKinds.Shelf, []);
            if (heightCm <= Row23MaxCm) return (null, [2, 3]);
            if (heightCm <= Row1MaxCm) return (null, [1]);
            return (null, [TopRow]);
        }
    }

    /// <summary>Chiến lược đã dùng để ra gợi ý — trả về cho FE để hiển thị / debug.</summary>
    public static class SuggestionStrategies
    {
        /// <summary>Có master model (khu + tầng) và có last lot cùng model.</summary>
        public const string MasterAndLastLot = "master_and_last_lot";

        /// <summary>Có master model nhưng không tìm được last lot.</summary>
        public const string MasterOnly = "master_only";

        /// <summary>Không có master model — chọn tầng theo chiều cao, bám last lot cùng model.</summary>
        public const string HeightAndLastLot = "height_and_last_lot";

        /// <summary>Không có last lot cùng model — bám last lot cùng category.</summary>
        public const string CategoryLastLot = "category_last_lot";

        /// <summary>Không có mốc nào để bám — lấy vị trí trống bất kỳ.</summary>
        public const string Random = "random";
    }

    /// <summary>Cách tìm ra last lot — đi kèm LastLotLocation để FE biết độ tin cậy.</summary>
    public static class LastLotMatchedBy
    {
        public const string Model = "model";
        public const string Category = "category";
    }

    // ── Dữ liệu đọc từ DB ─────────────────────────────────────────────

    /// <summary>Thông tin tối thiểu của pallet cần gợi ý + model đại diện.</summary>
    public sealed class PalletSuggestionContext
    {
        public long Id { get; set; }
        public string LotNo { get; set; } = default!;
        public int CategoryCode { get; set; }
        public string? CategoryName { get; set; }
        public string DetailLevel { get; set; } = default!;

        /// <summary>lots.model — chỉ có với lot box_count.</summary>
        public string? LotModel { get; set; }

        /// <summary>Model chiếm qty lớn nhất trong box_lines. Null với lot box_count.</summary>
        public string? DominantModel { get; set; }

        /// <summary>Model dùng để tra master + tìm last lot.</summary>
        public string? EffectiveModel => LotModel ?? DominantModel;

        // Vị trí hiện tại (để loại chính nó ra khỏi danh sách ứng viên).
        public long? LocatorId { get; set; }
        public string? LocatorCode { get; set; }
        public string? AreaCode { get; set; }
    }

    /// <summary>Cấu hình gợi ý lấy từ master.models (2 cột suggest_area / suggest_rack_row).</summary>
    public sealed class ModelStorageSuggestion
    {
        public string ModelCode { get; set; } = default!;
        public long? SuggestAreaId { get; set; }
        public string? SuggestAreaCode { get; set; }
        public string? SuggestAreaName { get; set; }

        /// <summary>Nguyên văn cột suggest_rack_row, vd "2,3". Parse ở Service.</summary>
        public string? SuggestRackRowRaw { get; set; }

        /// <summary>Có cấu hình khu vực gợi ý hay không.</summary>
        public bool HasArea => SuggestAreaId is not null;
    }

    /// <summary>Vị trí của lot gần nhất đã lưu — mốc để tính khoảng cách.</summary>
    public sealed class LastLotLocation
    {
        public long PalletId { get; set; }
        public string LotNo { get; set; } = default!;
        public string? Model { get; set; }

        public long LocatorId { get; set; }
        public string LocatorCode { get; set; } = default!;
        public long? AreaId { get; set; }
        public string? AreaCode { get; set; }
        public string? AreaName { get; set; }

        public long? RackId { get; set; }
        public string? RackCode { get; set; }
        public string? RackName { get; set; }
        public int? RackRow { get; set; }
        public int? RackCol { get; set; }
        /// <summary>'A' | 'B' với ô giá lửng; NULL với rack thường.</summary>
        public string? RackLevel { get; set; }
        public string? SlotKind { get; set; }

        /// <summary>Toạ độ trên bản đồ (đã cộng offset của rack trong khu).</summary>
        public int PosX { get; set; }
        public int PosY { get; set; }

        /// <summary>Thời điểm được gán vào vị trí này (locator_status_history).</summary>
        public DateTime? StoredAt { get; set; }

        /// <summary>model | category — xem <see cref="LastLotMatchedBy"/>.</summary>
        public string MatchedBy { get; set; } = LastLotMatchedBy.Model;
    }

    /// <summary>Một vị trí trống ứng viên, kèm các cờ xếp hạng do SQL tính.</summary>
    public sealed class LocatorCandidate
    {
        public long LocatorId { get; set; }
        public string LocatorCode { get; set; } = default!;

        public long? AreaId { get; set; }
        public string? AreaCode { get; set; }
        public string? AreaName { get; set; }

        public long? RackId { get; set; }
        public string? RackCode { get; set; }
        public string? RackName { get; set; }

        /// <summary>Tầng rack (master.locators.rack_row).</summary>
        public int? RackRow { get; set; }
        public int? RackCol { get; set; }
        /// <summary>'A' | 'B' với ô giá lửng; NULL với rack thường.</summary>
        public string? RackLevel { get; set; }
        public string? SlotKind { get; set; }

        public int PosX { get; set; }
        public int PosY { get; set; }

        /// <summary>1 = tầng nằm trong tập tầng gợi ý.</summary>
        public bool RowMatch { get; set; }

        /// <summary>
        /// 1 = đúng loại ô cần tìm. Nhắm giá lửng thì ô lửng khớp; nhắm tầng rack
        /// thường thì ô lửng KHÔNG khớp (bị đẩy xuống cuối).
        /// </summary>
        public bool SlotMatch { get; set; }

        /// <summary>Ô này là giá lửng (slot_kind = shelf).</summary>
        public bool IsShelf { get; set; }

        /// <summary>1 = cùng rack với last lot.</summary>
        public bool SameRack { get; set; }

        /// <summary>Lệch theo trục dọc (trên/dưới) so với last lot.</summary>
        public int Dy { get; set; }

        /// <summary>Lệch theo trục ngang (trái/phải) so với last lot.</summary>
        public int Dx { get; set; }
    }

    /// <summary>Tham số tìm vị trí trống — gom lại cho gọn chữ ký repository.</summary>
    public sealed class LocatorSearchCriteria
    {
        /// <summary>Loại pallet đang xin gợi ý ra khỏi kết quả.</summary>
        public long ExcludePalletId { get; init; }

        /// <summary>Lọc cứng theo khu vực (id) — từ master.models.suggest_area.</summary>
        public long? AreaId { get; init; }

        /// <summary>Lọc cứng theo mã khu vực — dùng khi không có AreaId (mặc định STORAGE).</summary>
        public string? AreaCode { get; init; }

        /// <summary>Tầng ưu tiên. Rỗng = không ưu tiên tầng nào.</summary>
        public IReadOnlyList<int> RackRows { get; init; } = [];

        /// <summary>slot_kind ưu tiên (vd shelf). Null = không ưu tiên.</summary>
        public string? SlotKind { get; init; }

        /// <summary>Mốc để tính gần/xa. Null = không có last lot -> lấy ngẫu nhiên.</summary>
        public LastLotLocation? Reference { get; init; }

        public int Take { get; init; } = 5;
    }
}
