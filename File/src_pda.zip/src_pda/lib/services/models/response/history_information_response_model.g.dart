// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'history_information_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HistoryInformationResponseModel _$HistoryInformationResponseModelFromJson(
        Map<String, dynamic> json) =>
    HistoryInformationResponseModel(
      createdBy: json['createdBy'] as String?,
      remark: json['remark'] as String?,
      createdDate: json['createdDate'] as String?,
      store: (json['store'] as num?)?.toDouble(),
      stock: (json['stock'] as num?)?.toDouble(),
      kitting: (json['kitting'] as num?)?.toDouble(),
      qtyBalance: (json['qtyBalance'] as num?)?.toDouble(),
    );

Map<String, dynamic> _$HistoryInformationResponseModelToJson(
        HistoryInformationResponseModel instance) =>
    <String, dynamic>{
      'createdBy': instance.createdBy,
      'remark': instance.remark,
      'createdDate': instance.createdDate,
      'stock': instance.stock,
      'store': instance.store,
      'kitting': instance.kitting,
      'qtyBalance': instance.qtyBalance,
    };
