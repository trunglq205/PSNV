// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stocky_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(stockyRemoteDataSource)
final stockyRemoteDataSourceProvider = StockyRemoteDataSourceProvider._();

final class StockyRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          StockyRemoteDataSource,
          StockyRemoteDataSource,
          StockyRemoteDataSource
        >
    with $Provider<StockyRemoteDataSource> {
  StockyRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'stockyRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$stockyRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<StockyRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  StockyRemoteDataSource create(Ref ref) {
    return stockyRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StockyRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StockyRemoteDataSource>(value),
    );
  }
}

String _$stockyRemoteDataSourceHash() =>
    r'44e393e7943b2d5dade83dd35dc95a443ba6270d';

@ProviderFor(stockyRepository)
final stockyRepositoryProvider = StockyRepositoryProvider._();

final class StockyRepositoryProvider
    extends
        $FunctionalProvider<
          StockyRepository,
          StockyRepository,
          StockyRepository
        >
    with $Provider<StockyRepository> {
  StockyRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'stockyRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$stockyRepositoryHash();

  @$internal
  @override
  $ProviderElement<StockyRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  StockyRepository create(Ref ref) {
    return stockyRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StockyRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StockyRepository>(value),
    );
  }
}

String _$stockyRepositoryHash() => r'760ff709ccf5df6f4f22b4023686c3b58061bee8';

/// Danh sách xe đang ở trong kho.
///
/// [filterName] là `StockyFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build —
/// `ng_providers.dart` ghi rõ cái bẫy này.

@ProviderFor(stockyCartList)
final stockyCartListProvider = StockyCartListFamily._();

/// Danh sách xe đang ở trong kho.
///
/// [filterName] là `StockyFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build —
/// `ng_providers.dart` ghi rõ cái bẫy này.

final class StockyCartListProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<StockyCart>>,
          List<StockyCart>,
          FutureOr<List<StockyCart>>
        >
    with $FutureModifier<List<StockyCart>>, $FutureProvider<List<StockyCart>> {
  /// Danh sách xe đang ở trong kho.
  ///
  /// [filterName] là `StockyFilter.name` chứ không phải chính enum: tham số
  /// family phải so sánh được bằng `==` và ổn định giữa các lần build —
  /// `ng_providers.dart` ghi rõ cái bẫy này.
  StockyCartListProvider._({
    required StockyCartListFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'stockyCartListProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$stockyCartListHash();

  @override
  String toString() {
    return r'stockyCartListProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<List<StockyCart>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<StockyCart>> create(Ref ref) {
    final argument = this.argument as String;
    return stockyCartList(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is StockyCartListProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$stockyCartListHash() => r'9b047884722c40f21f147781ca51ffd93a25c0d5';

/// Danh sách xe đang ở trong kho.
///
/// [filterName] là `StockyFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build —
/// `ng_providers.dart` ghi rõ cái bẫy này.

final class StockyCartListFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<List<StockyCart>>, String> {
  StockyCartListFamily._()
    : super(
        retry: null,
        name: r'stockyCartListProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Danh sách xe đang ở trong kho.
  ///
  /// [filterName] là `StockyFilter.name` chứ không phải chính enum: tham số
  /// family phải so sánh được bằng `==` và ổn định giữa các lần build —
  /// `ng_providers.dart` ghi rõ cái bẫy này.

  StockyCartListProvider call(String filterName) =>
      StockyCartListProvider._(argument: filterName, from: this);

  @override
  String toString() => r'stockyCartListProvider';
}
