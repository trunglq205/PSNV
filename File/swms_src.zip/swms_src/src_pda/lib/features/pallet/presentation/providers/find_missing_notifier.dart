import 'package:flutter/foundation.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_providers.dart';

part 'find_missing_notifier.g.dart';

/// Kết quả xử lý 1 lần quét box.
enum ScanBoxOutcome {
  matched, // quét đúng 1 box thuộc lot (lần đầu)
  already, // box này đã quét rồi
  foreign, // box lạ, không thuộc lot
}

@immutable
class FindMissingState {
  final List<PalletBox> boxes;
  final Set<String> scanned;
  final String? lastForeign;

  const FindMissingState({
    required this.boxes,
    this.scanned = const {},
    this.lastForeign,
  });

  int get total => boxes.length;
  int get scannedCount => scanned.length;
  int get remaining => total - scannedCount;
  double get progress => total == 0 ? 0 : scannedCount / total;
  bool get isComplete => remaining == 0 && total > 0;

  List<PalletBox> get missingBoxes =>
      boxes.where((b) => !scanned.contains(b.boxNo)).toList();

  bool isScanned(String boxNo) => scanned.contains(boxNo);
}

/// Phiên "tìm thùng bị mất" — client thuần, không gọi API.
/// Family theo lot_no; danh sách thùng lấy từ [palletProvider] (đã cache
/// bởi màn Detail) nên route không cần truyền `boxes` nữa.
@riverpod
class FindMissingNotifier extends _$FindMissingNotifier {
  @override
  FindMissingState build(String lotNo) {
    final boxes = ref.watch(palletProvider(lotNo)).value?.boxes ?? const [];
    return FindMissingState(boxes: boxes);
  }

  /// Xử lý 1 mã quét. Trả về kết quả để UI báo.
  ScanBoxOutcome onScan(String rawCode) {
    final code = rawCode.trim();
    if (code.isEmpty) return ScanBoxOutcome.foreign;

    final belongs = state.boxes.any((b) => b.boxNo == code);
    if (!belongs) {
      state = FindMissingState(
        boxes: state.boxes,
        scanned: state.scanned,
        lastForeign: code,
      );
      return ScanBoxOutcome.foreign;
    }

    if (state.scanned.contains(code)) return ScanBoxOutcome.already;

    state = FindMissingState(
      boxes: state.boxes,
      scanned: {...state.scanned, code},
    );
    return ScanBoxOutcome.matched;
  }

  /// Quét lại từ đầu.
  void reset() => state = FindMissingState(boxes: state.boxes);
}
