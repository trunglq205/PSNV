import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';

/// Loại hàng trả về.
///
/// [code] khớp cột `wms.return_instruction_lines.goods_type`, và CỐ Ý trùng
/// với `wms.pallets.disposition` — mục 2 sẽ đối chiếu dòng chỉ thị với pallet
/// WH tạo, nên hai bên phải dùng chung một bộ chuỗi.
enum ReturnGoodsType {
  rework('rework', LocaleKeys.return_instruction_type_rework),
  refurbish('refurbish', LocaleKeys.return_instruction_type_refurbish);

  const ReturnGoodsType(this.code, this.labelKey);

  final String code;

  /// LocaleKeys — UI gọi `.tr()` khi render.
  final String labelKey;

  /// Mã lạ từ server thì về [rework] thay vì ném: màn này CHỈ ĐỌC, một dòng
  /// hiện sai nhãn còn hơn cả danh sách trắng xoá.
  static ReturnGoodsType fromCode(String? code) => values.firstWhere(
        (e) => e.code == code,
        orElse: () => ReturnGoodsType.rework,
      );
}

/// Trạng thái phiếu, khớp `wms.return_instructions.doc_status`.
enum ReturnDocStatus {
  open('open', LocaleKeys.return_instruction_status_open),
  completed('completed', LocaleKeys.return_instruction_status_completed),
  cancelled('cancelled', LocaleKeys.return_instruction_status_cancelled);

  const ReturnDocStatus(this.code, this.labelKey);

  final String code;
  final String labelKey;

  static ReturnDocStatus fromCode(String? code) => values.firstWhere(
        (e) => e.code == code,
        orElse: () => ReturnDocStatus.open,
      );
}

/// Bộ lọc trên màn PDA. `null` = không lọc.
enum ReturnFilter {
  open(ReturnDocStatus.open, LocaleKeys.return_instruction_filter_open),
  all(null, LocaleKeys.return_instruction_filter_all);

  const ReturnFilter(this.status, this.labelKey);

  final ReturnDocStatus? status;
  final String labelKey;
}

/// Một model + số lượng trong chỉ thị. Loại hàng nằm ở PHIẾU, không ở đây.
class ReturnInstructionLine {
  final int lineNo;
  final String model;
  final int qty;

  /// SL thực nhận = số serial WH đã quét vào phiếu cho model này (mục 2a).
  final int receivedQty;

  /// Còn phải nhận. ÂM = đã nhận vượt chỉ thị — không phải lỗi.
  final int remainingQty;

  /// Lệch = thực nhận − chỉ thị. Dương vượt, âm thiếu, 0 đủ.
  ///
  /// Cùng con số với [remainingQty] nhưng ĐỔI DẤU, để riêng có chủ ý: màn quét
  /// đọc "còn phải nhận 6", bảng đối chiếu đọc "lệch −6".
  final int diffQty;

  final String? note;

  const ReturnInstructionLine({
    required this.lineNo,
    required this.model,
    required this.qty,
    this.receivedQty = 0,
    this.remainingQty = 0,
    this.diffQty = 0,
    this.note,
  });

  /// Đã nhận đủ hoặc vượt — dùng để tô màu chip model trên màn quét.
  bool get isDone => remainingQty <= 0;
}

/// Một chỉ thị back hàng do SCS Office tạo. Màn PDA CHỈ ĐỌC.
class ReturnInstruction {
  final int id;

  /// `RW-yyyyMMdd-###` (rework) | `RB-yyyyMMdd-###` (refurbish).
  final String docNo;

  /// MỘT PHIẾU MỘT LOẠI. Khách báo cả hai loại thì Office tạo hai phiếu.
  final ReturnGoodsType goodsType;

  final String? customer;

  /// Ngày hàng dự kiến về PSNV.
  final DateTime? expectedDate;

  final ReturnDocStatus status;
  final String? note;
  /// Số model trong phiếu. Mỗi dòng đúng một model, nên đếm dòng là đếm
  /// model — đặt tên theo thứ người dùng đọc, không theo cách lưu.
  final int modelCount;

  final int totalQty;

  /// Tổng SL thực nhận = số serial đã quét vào phiếu.
  final int receivedQty;

  /// Có model nhận vượt chỉ thị. Cảnh báo, không phải lỗi.
  final bool overReceived;

  /// Có model nhận thiếu. Cũng chỉ là cảnh báo.
  final bool shortReceived;

  /// Lệch cả phiếu = thực nhận − chỉ thị.
  final int diffQty;

  /// Đã chốt SL thực nhận lúc nào (mục 2b). NULL = chưa chốt.
  final DateTime? closedAt;
  final String? closedBy;

  /// Đã báo FA SỐ THỰC NHẬN lúc nào. NULL = chưa gửi được.
  final DateTime? actualMailSentAt;

  final DateTime? createdAt;
  final String? createdBy;
  final List<ReturnInstructionLine> lines;

  const ReturnInstruction({
    required this.id,
    required this.docNo,
    this.goodsType = ReturnGoodsType.rework,
    this.customer,
    this.expectedDate,
    this.status = ReturnDocStatus.open,
    this.note,
    this.modelCount = 0,
    this.totalQty = 0,
    this.receivedQty = 0,
    this.overReceived = false,
    this.shortReceived = false,
    this.diffQty = 0,
    this.closedAt,
    this.closedBy,
    this.actualMailSentAt,
    this.createdAt,
    this.createdBy,
    this.lines = const [],
  });

  bool get isOpen => status == ReturnDocStatus.open;

  /// Đã nhận được hàng — điều kiện để chốt thực nhận.
  bool get hasReceipt => receivedQty > 0;

  /// Đã chốt. Office mở lại phiếu thì trạng thái về open nhưng mốc chốt lần
  /// trước vẫn còn, để biết FA đã nhận số nào.
  bool get isClosed => closedAt != null;

  /// Đã nhận đủ mọi model. Phiếu KHÔNG tự đóng ở mục 2a — mục 2b mới chốt —
  /// nên đây chỉ là thông tin hiển thị.
  bool get isFullyReceived =>
      lines.isNotEmpty && lines.every((l) => l.isDone);
}
