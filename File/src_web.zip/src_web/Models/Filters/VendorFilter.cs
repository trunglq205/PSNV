﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class VendorFilter : BaseFilter
    {
        [Display(Name = "Vendor Code")]
        public string? VendorCode { get; set; }
        [Display(Name = "Vendor Name")]
        public string? VendorName { get; set; }
        [Display(Name = "Global Code")]
        public string? GlobalCode { get; set; }
    }
}
