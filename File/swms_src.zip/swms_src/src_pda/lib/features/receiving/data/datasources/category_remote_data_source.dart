import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category_option_model.dart';

part 'category_remote_data_source.g.dart';

@RestApi()
abstract class CategoryRemoteDataSource {
  factory CategoryRemoteDataSource(Dio dio, {String baseUrl}) =
  _CategoryRemoteDataSource;

  /// Danh mục Cate gọn (code + name) cho dropdown / chọn.
  @GET('/api/categories/options')
  Future<List<CategoryOptionModel>> getOptions();
}