import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/deadline_chip.dart';

/// Thẻ một công việc đang chờ: nhãn + hạn + mã + tiến độ.
class AssignmentCard extends StatelessWidget {
  final AssignmentData data;
  final VoidCallback? onTap;

  const AssignmentCard({super.key, required this.data, this.onTap});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.sm),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  // Row 1: icon + label + deadline
                  Row(
                    children: [
                      Container(
                        width: 22,
                        height: 22,
                        decoration: BoxDecoration(
                          color: data.toneBg,
                          borderRadius: BorderRadius.circular(6),
                        ),
                        child: Icon(data.icon, size: 14, color: data.tone),
                      ),
                      const SizedBox(width: 6),
                      Expanded(
                        child: Text(
                          data.labelKey.tr().toUpperCase(),
                          style: AppTextStyles.label.copyWith(
                            color: data.tone,
                            fontWeight: FontWeight.w800,
                            letterSpacing: .4,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 6),
                      DeadlineChip(text: data.deadlineText, urgent: data.urgent),
                    ],
                  ),
                  const SizedBox(height: 6),
                  // Row 2: code + sub
                  Row(
                    crossAxisAlignment: CrossAxisAlignment.baseline,
                    textBaseline: TextBaseline.alphabetic,
                    children: [
                      Flexible(
                        flex: 0,
                        child: Text(
                          data.code,
                          style: AppTextStyles.code.copyWith(
                            fontSize: 13,
                            letterSpacing: .2,
                            fontWeight: FontWeight.w700,
                            color: swms.text1,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Flexible(
                        child: Text(
                          data.subKey.tr(args: data.subArgs),
                          style: AppTextStyles.caption.copyWith(
                            color: swms.text3,
                            fontSize: 11,
                          ),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 6),
                  // Row 3: progress
                  Row(
                    children: [
                      Expanded(
                        child: ClipRRect(
                          borderRadius: BorderRadius.circular(999),
                          child: LinearProgressIndicator(
                            value: data.progress,
                            minHeight: 5,
                            backgroundColor: Theme.of(
                              context,
                            ).scaffoldBackgroundColor,
                            valueColor: AlwaysStoppedAnimation(data.tone),
                          ),
                        ),
                      ),
                      const SizedBox(width: 8),
                      RichText(
                        text: TextSpan(
                          style: AppTextStyles.caption.copyWith(
                            color: swms.text3,
                            fontSize: 11,
                          ),
                          children: [
                            TextSpan(
                              text: '${data.done}',
                              style: TextStyle(
                                color: swms.text1,
                                fontWeight: FontWeight.w800,
                              ),
                            ),
                            TextSpan(
                              text:
                                  '/${data.total} ${data.unitKey.tr()}',
                            ),
                          ],
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
            const SizedBox(width: 6),
            Icon(Icons.chevron_right, size: 16, color: swms.text4),
          ],
        ),
      ),
    );
  }
}
