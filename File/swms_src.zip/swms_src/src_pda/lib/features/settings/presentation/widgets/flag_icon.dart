import 'dart:math' as math;

import 'package:flutter/material.dart';

/// Cờ vẽ tay (16×12) — dịch trực tiếp từ SVG mẫu, không dùng emoji
/// để hiển thị nhất quán trên mọi PDA/font.
class FlagIcon extends StatelessWidget {
  final String code; // 'vi' | 'en' | 'zh' | 'ja'
  final double width;
  const FlagIcon(this.code, {super.key, this.width = 16});

  @override
  Widget build(BuildContext context) {
    final size = Size(width, width * 12 / 16); // tỉ lệ 30:20
    return ClipRRect(
      borderRadius: BorderRadius.circular(2),
      child: CustomPaint(size: size, painter: _flagPainter(code)),
    );
  }

  static CustomPainter _flagPainter(String code) => switch (code) {
    'vi' => _VnFlag(),
    'en' => _UkFlag(),
    'zh' => _CnFlag(),
    'ja' => _JpFlag(),
    _ => _VnFlag(),
  };
}

// viewBox gốc 30×20; scale theo size thực.
double _sx(Size s) => s.width / 30;
double _sy(Size s) => s.height / 20;

/// Việt Nam — nền đỏ, sao vàng 5 cánh.
class _VnFlag extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final kx = _sx(size), ky = _sy(size);
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFFDA251D));

    // points="15,4.5 16.6,9.4 21.7,9.4 17.6,12.4 19.1,17.3 15,14.3
    //         10.9,17.3 12.4,12.4 8.3,9.4 13.4,9.4"
    const pts = [
      [15.0, 4.5], [16.6, 9.4], [21.7, 9.4], [17.6, 12.4], [19.1, 17.3],
      [15.0, 14.3], [10.9, 17.3], [12.4, 12.4], [8.3, 9.4], [13.4, 9.4],
    ];
    final path = Path();
    for (var i = 0; i < pts.length; i++) {
      final x = pts[i][0] * kx, y = pts[i][1] * ky;
      i == 0 ? path.moveTo(x, y) : path.lineTo(x, y);
    }
    path.close();
    canvas.drawPath(path, Paint()..color = const Color(0xFFFFFF00));
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// Anh — Union Jack (đơn giản hóa theo SVG mẫu).
class _UkFlag extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final kx = _sx(size), ky = _sy(size);
    Offset p(double x, double y) => Offset(x * kx, y * ky);

    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFF012169));
    canvas.clipRect(Offset.zero & size);

    // Đường chéo trắng (rộng) rồi đỏ (mảnh)
    final diagW = Paint()
      ..color = Colors.white
      ..strokeWidth = 4 * kx
      ..style = PaintingStyle.stroke;
    final diagR = Paint()
      ..color = const Color(0xFFC8102E)
      ..strokeWidth = 1.5 * kx
      ..style = PaintingStyle.stroke;
    for (final paint in [diagW, diagR]) {
      canvas.drawLine(p(0, 0), p(30, 20), paint);
      canvas.drawLine(p(30, 0), p(0, 20), paint);
    }

    // Thập trắng (rộng) rồi đỏ (mảnh)
    final crossW = Paint()
      ..color = Colors.white
      ..strokeWidth = 5 * kx
      ..style = PaintingStyle.stroke;
    final crossR = Paint()
      ..color = const Color(0xFFC8102E)
      ..strokeWidth = 3 * kx
      ..style = PaintingStyle.stroke;
    for (final paint in [crossW, crossR]) {
      canvas.drawLine(p(15, 0), p(15, 20), paint);
      canvas.drawLine(p(0, 10), p(30, 10), paint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// Trung Quốc — nền đỏ, sao lớn + 4 sao nhỏ.
class _CnFlag extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final kx = _sx(size), ky = _sy(size);
    canvas.drawRect(Offset.zero & size, Paint()..color = const Color(0xFFDE2910));

    final star = Paint()..color = const Color(0xFFFFDE00);
    void drawStar(double cx, double cy, double r, double rot) {
      final path = Path();
      for (var i = 0; i < 5; i++) {
        final outer = rot + i * 2 * 3.1415926 / 5;
        final inner = outer + 3.1415926 / 5;
        final ox = cx + r * math.cos(outer), oy = cy + r * math.sin(outer);
        final ix = cx + r * 0.4 * math.cos(inner), iy = cy + r * 0.4 * math.sin(inner);
        i == 0 ? path.moveTo(ox, oy) : path.lineTo(ox, oy);
        path.lineTo(ix, iy);
      }
      path.close();
      canvas.drawPath(path, star);
    }

    const base = -1.5708; // -90°: một đỉnh hướng lên
    drawStar(5 * kx, 5 * ky, 3.2 * kx, base);
    drawStar(10 * kx, 2 * ky, 1.1 * kx, base);
    drawStar(12 * kx, 4 * ky, 1.1 * kx, base);
    drawStar(12 * kx, 7 * ky, 1.1 * kx, base);
    drawStar(10 * kx, 9 * ky, 1.1 * kx, base);
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}

/// Nhật Bản — nền trắng, vòng tròn đỏ.
class _JpFlag extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final kx = _sx(size), ky = _sy(size);
    canvas.drawRect(Offset.zero & size, Paint()..color = Colors.white);
    canvas.drawCircle(
      Offset(15 * kx, 10 * ky),
      5 * kx,
      Paint()..color = const Color(0xFFBC002D),
    );
  }

  @override
  bool shouldRepaint(covariant CustomPainter old) => false;
}