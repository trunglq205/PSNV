using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Swms.FinishGoods.Web.Features.Inventory.App.Csv;
using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Shared.App.CsvIo;

namespace Swms.FinishGoods.Web.Features.Inventory.App.Pages;

// Cụm thao tác: chi tiết lot, lịch sử, Aging/FIFO, Export.
// Đã gỡ mọi tham chiếu sang feature Lots — dùng IInventoryBusiness cho tất cả.
public partial class Inventories
{
    [Inject] private IJSRuntime JS { get; set; } = default!;

    // ── Detail dialog ──
    private AppInventoryItem? _detailLot;
    private readonly Dictionary<long, AppInventoryItem> _detailCache = new();
    private readonly HashSet<long> _detailLoading = new();

    private bool IsDetailLoading(long id) => _detailLoading.Contains(id);
    private AppInventoryItem? DetailOf(long id) => _detailCache.TryGetValue(id, out var d) ? d : null;

    private async Task OpenDetail(AppInventoryItem p)
    {
        _detailLot = p;

        // Hai lời gọi độc lập, chạy song song: timeline không phải chờ danh sách box
        // (lot nhiều thùng thì GET /{id} nặng hơn hẳn /history).
        var tasks = new List<Task>();
        if (DetailOf(p.Id) is null) tasks.Add(LoadDetailAsync(p.Id));
        if (HistoryOf(p.Id) is null) tasks.Add(LoadHistoryAsync(p.Id));

        StateHasChanged();
        if (tasks.Count > 0) await Task.WhenAll(tasks);
    }

    private async Task LoadDetailAsync(long id)
    {
        _detailLoading.Add(id);
        StateHasChanged();
        try
        {
            var r = await Business.GetByIdAsync(id);
            if (r.IsSuccess && r.Value != null) _detailCache[id] = InventoryItemDto.ToViewModel(r.Value);
            else Toast.Error(r.ErrorMessage ?? L["Lots.Load.DetailFailed"]);
        }
        finally { _detailLoading.Remove(id); StateHasChanged(); }
    }

    // ── Lịch sử (GET /api/pallets/{id}/history) ──
    private readonly Dictionary<long, List<AppStockEvent>> _historyCache = new();
    private readonly HashSet<long> _historyLoading = new();

    private bool IsHistoryLoading(long id) => _historyLoading.Contains(id);
    private List<AppStockEvent>? HistoryOf(long id) => _historyCache.TryGetValue(id, out var h) ? h : null;

    private async Task LoadHistoryAsync(long id)
    {
        _historyLoading.Add(id);
        StateHasChanged();
        try
        {
            var r = await Business.GetHistoryAsync(id);
            if (r.IsSuccess && r.Value != null)
            {
                _historyCache[id] = r.Value;
            }
            else
            {
                // Cache danh sách rỗng để dialog hiện "chưa có lịch sử" thay vì
                // spinner treo, và để không gọi lại mỗi lần mở.
                _historyCache[id] = new List<AppStockEvent>();
                Toast.Error(r.ErrorMessage ?? L["Inventory.Load.HistoryFailed"]);
            }
        }
        finally { _historyLoading.Remove(id); StateHasChanged(); }
    }
    private void CloseDetail()
    {
        // Bỏ cache lịch sử của lot vừa xem: timeline có thể vài trăm dòng và
        // người dùng hiếm khi mở lại cùng một lot trong một phiên.
        if (_detailLot is { } l) _historyCache.Remove(l.Id);
        _detailLot = null;
    }

    // ── Aging / FIFO ──
    private bool _agingOpen;
    private bool _agingLoading;
    private List<AppAgingBucket> _agingBuckets = new();

    private async Task OpenAging()
    {
        _agingOpen = true;
        _agingLoading = true;
        try
        {
            var q = BuildQuery(); q.Page = 1; q.Size = 1;
            var r = await Business.GetAgingAsync(q);
            if (r.IsSuccess && r.Value != null) _agingBuckets = InventoryAgingBucketDto.ToViewModel(r.Value);
            else Toast.Error(r.ErrorMessage ?? L["Inventory.Load.AgingFailed"]);
        }
        finally { _agingLoading = false; }
    }

    // Chọn 1 bucket trong dialog → lọc bảng theo ngày SX tương ứng (FIFO: xem hàng cũ trước).
    //   Tuổi X ngày ⇔ ngày SX = Hôm nay − X
    //   bucket [From, To] ngày  ⇔  ngày SX trong [Hôm nay − To, Hôm nay − From]
    //   bucket mở (gt90, To = null) ⇔ không chặn đầu dưới: mọi ngày SX ≤ Hôm nay − 90.
    // Ghi thẳng vào bộ lọc ngày SX ở toolbar (_prodFrom/_prodTo) nên chip + URL + DateRangePicker
    // đều hiện đúng khoảng vừa chọn, người dùng xoá chip là bỏ lọc.
    private void ApplyAgingBucket(AppAgingBucket b)
    {
        var today = DateTime.Today;
        _prodFrom = b.ToDays is { } t ? today.AddDays(-t) : null;
        _prodTo = today.AddDays(-b.FromDays);
        _agingOpen = false;
        CommitState();
    }

    // ── Export: CSV chi tiết lot → box → line/serial theo filter hiện tại ──
    // API list không trả box/line nên phải gọi GET /api/pallets/{id} cho từng lot.

    /// <summary>Trần số lot cho 1 lần xuất (mỗi lot = 1 request chi tiết).</summary>
    private const int ExportMaxLots = 5_000;

    /// <summary>Số lot tải chi tiết song song mỗi lượt.</summary>
    private const int ExportParallel = 6;

    private bool _exporting;
    private int _exportDone;
    private int _exportTotal;
    private CancellationTokenSource? _exportCts;

    private async Task ExportAsync()
    {
        if (_exporting) return;

        _exporting = true;
        _exportDone = _exportTotal = 0;
        _exportCts = new CancellationTokenSource();
        var ct = _exportCts.Token;
        StateHasChanged();

        try
        {
            // B1: toàn bộ lot theo filter. Lấy dư 1 để biết có vượt trần không.
            var run = await ListExporter.FetchAllAsync<AppInventoryItem>(
                fetchPageAsync: async (page, size, _) =>
                {
                    var q = BuildQuery(); q.Page = page; q.Size = size;
                    var r = await Business.GetPagedAsync(q);
                    if (!r.IsSuccess || r.Value is null) return null;
                    return new ExportPage<AppInventoryItem>(
                        r.Value.Items.Select(InventoryItemDto.ToViewModel).ToList(), r.Value.TotalCount);
                },
                options: new ExportOptions { PageSize = 200, MaxRows = ExportMaxLots + 1 },
                ct: ct);

            var lots = run.Items;
            if (lots.Count == 0)
            {
                Toast.Error(L["Inventory.Toast.ExportEmpty"]);
                return;
            }
            if (lots.Count > ExportMaxLots)
            {
                Toast.Error(L["Inventory.ExportDetail.TooMany", ExportMaxLots.ToString("N0")]);
                return;
            }

            _exportTotal = lots.Count;
            StateHasChanged();

            // B2: chi tiết box/line — song song theo lượt nhỏ.
            var data = new (AppInventoryItem Lot, IReadOnlyList<AppInventoryBox> Boxes)[lots.Count];
            var failed = new List<string>();

            for (var start = 0; start < lots.Count; start += ExportParallel)
            {
                ct.ThrowIfCancellationRequested();

                var idx = Enumerable.Range(start, Math.Min(ExportParallel, lots.Count - start)).ToArray();
                var boxes = await Task.WhenAll(idx.Select(i => LoadBoxesForExportAsync(lots[i])));

                for (var k = 0; k < idx.Length; k++)
                {
                    var lot = lots[idx[k]];
                    if (boxes[k] is null) failed.Add(lot.LotNo);
                    // Lỗi tải chi tiết vẫn giữ dòng lot (cột box/serial để trống).
                    data[idx[k]] = (lot, boxes[k] ?? new List<AppInventoryBox>());
                }

                _exportDone += idx.Length;
                StateHasChanged();
            }

            // B3: phẳng hoá + ghi CSV.
            var rows = InventoryCsvSchema.Flatten(data).ToList();
            var schema = InventoryCsvSchema.BuildSchema(L);
            var bytes = schema.Export(rows);
            await JS.InvokeVoidAsync("swmsSaveFile", ct,
                schema.ExportFileName(), "text/csv", Convert.ToBase64String(bytes));

            var boxCount = data.Sum(x => x.Boxes.Count);
            Toast.Success(L["Inventory.ExportDetail.Done",
                data.Length.ToString("N0"), boxCount.ToString("N0"), rows.Count.ToString("N0")]);

            if (failed.Count > 0)
                Toast.Error(L["Inventory.ExportDetail.PartialFailed", failed.Count, string.Join(", ", failed.Take(5))]);
        }
        catch (OperationCanceledException)
        {
            // Rời trang giữa chừng — bỏ qua.
        }
        finally
        {
            _exporting = false;
            _exportCts?.Dispose();
            _exportCts = null;
            StateHasChanged();
        }
    }

    /// <summary>Box + line của 1 lot. Null = tải lỗi.</summary>
    private async Task<List<AppInventoryBox>?> LoadBoxesForExportAsync(AppInventoryItem lot)
    {
        // Lot đã mở dialog chi tiết trong phiên -> dùng lại, không gọi API.
        if (DetailOf(lot.Id) is { } cached) return cached.Boxes;

        var r = await Business.GetByIdAsync(lot.Id);
        return r.IsSuccess && r.Value is not null
            ? r.Value.Boxes.Select(InventoryBoxDto.ToViewModel).ToList()
            : null;
    }
}