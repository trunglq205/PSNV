using Swms.FinishGoods.Web.Shared.App.Toast;

namespace Swms.FinishGoods.Web.Extensions;

/// <summary>
/// LAYER 1 — đăng ký dependency cấp UI (dialog service, toast, state container...).
/// Hiện tại trống; giữ lại để mở rộng và để Program.cs đồng nhất 3 layer.
/// </summary>
public static class AppServiceExtensions
{
    public static IServiceCollection AddUIServices(this IServiceCollection services)
    {
        services.AddScoped<ToastService>();

        return services;
    }
}
