/// Loại mục có thể gộp vào Pallet List.
enum MergeItemType { pallet, box }

/// Pallet gốc — đích của thao tác gộp (Tally 2).
class BasePallet {
  final String code;

  /// true khi pallet gốc đang rỗng (Pallet List mới, chưa có hàng gộp).
  final bool isNewList;
  final String? siCode;
  final String? route;
  final int boxCount;
  final int pcs;

  const BasePallet({
    required this.code,
    this.isNewList = false,
    this.siCode,
    this.route,
    this.boxCount = 0,
    this.pcs = 0,
  });
}

/// Pallet / thùng gộp được (cùng chuyến xe = cùng SI · cùng tuyến).
class MergeCandidate {
  final String code;
  final MergeItemType type;
  final String locatorCode;
  final int boxCount;
  final int pcs;

  const MergeCandidate({
    required this.code,
    required this.type,
    required this.locatorCode,
    required this.boxCount,
    required this.pcs,
  });
}

/// 1 cọc đã ghép thật của chuyến (theo cọc C0x của Stowage Plan).
/// [cocNo] = số cọc dùng khi chụp ảnh "Cọc pallet". [topCode] null = cọc 1 tầng.
class TripStack {
  final int cocNo;
  final String? code;
  final String bottomCode;
  final String? topCode;
  final bool placed;

  const TripStack({
    required this.cocNo,
    this.code,
    required this.bottomCode,
    this.topCode,
    this.placed = false,
  });
}

/// Trạng thái 1 thùng của pallet soạn so với pallet gốc.
enum PlanBoxStatus {
  /// Đã nằm trên pallet gốc.
  onBase,

  /// Đang ở pallet khác ([MergePlanBox.palletCode]) — cần ghép vào.
  source,

  /// Chưa có box thật (SI chưa lấy hàng / thùng dự kiến).
  missing;

  static PlanBoxStatus parse(String v) => switch (v.toLowerCase()) {
    'base' => onBase,
    'source' => source,
    _ => missing,
  };
}

/// 1 thùng của pallet soạn, theo thứ tự xếp của Web ([seq] 1 = xếp trước).
class MergePlanBox {
  final int seq;
  final String boxNo;
  final String? model;
  final PlanBoxStatus status;
  final String? palletCode;
  final String? locatorCode;
  final int pcs;

  const MergePlanBox({
    required this.seq,
    required this.boxNo,
    this.model,
    required this.status,
    this.palletCode,
    this.locatorCode,
    this.pcs = 0,
  });
}

/// Pallet thật đang giữ thùng cần ghép. [whole] = mọi thùng trên đó đều thuộc kế hoạch → quét mã pallet;
/// không thì quét từng thùng.
class MergeSource {
  final String palletCode;
  final String? locatorCode;
  final int needed;
  final int boxCount;
  final bool whole;

  const MergeSource({
    required this.palletCode,
    this.locatorCode,
    required this.needed,
    required this.boxCount,
    required this.whole,
  });
}

/// 1 tầng của cọc theo plan. [palletCode] = Pallet List thật đang giữ nhiều thùng nhất của pallet soạn
/// tầng này (tầng đang làm = pallet gốc); null = chưa có. [complete] = đủ thùng trên đúng pallet đó.
class MergeTier {
  final int tier;
  final String planPalletCode;
  final String? palletCode;
  final bool complete;
  final bool isThis;
  final int done;
  final int total;

  const MergeTier({
    required this.tier,
    required this.planPalletCode,
    this.palletCode,
    this.complete = false,
    this.isThis = false,
    this.done = 0,
    this.total = 0,
  });
}

/// Cọc của pallet soạn — ghép cọc ngay trên màn Pallet List.
class MergeColumn {
  final String code;
  final int cocNo;
  final List<MergeTier> tiers;
  final String? stackedBottom;
  final String? stackedTop;
  final bool placed;

  const MergeColumn({
    required this.code,
    required this.cocNo,
    this.tiers = const [],
    this.stackedBottom,
    this.stackedTop,
    this.placed = false,
  });

  bool get stacked => stackedBottom != null;

  MergeTier? tierOf(int tier) {
    for (final t in tiers) {
      if (t.tier == tier) return t;
    }
    return null;
  }
}

/// Kế hoạch vanning của pallet gốc: pallet soạn trên Stowage Plan của chuyến (lập trên Web).
class MergePlan {
  final String planNo;
  final String palletCode;
  final String? columnCode;

  /// 1 = tầng dưới, 2 = tầng trên.
  final int tier;
  final String? siNo;
  final String? palletSize;
  final List<MergePlanBox> boxes;
  final List<MergeSource> sources;

  /// Thùng đang trên pallet gốc nhưng không thuộc pallet soạn này — cần tách ra.
  final List<String> extra;

  /// Cọc chứa pallet soạn này (null = plan chưa đặt pallet vào cọc).
  final MergeColumn? column;

  const MergePlan({
    required this.planNo,
    required this.palletCode,
    this.columnCode,
    this.tier = 1,
    this.siNo,
    this.palletSize,
    this.boxes = const [],
    this.sources = const [],
    this.extra = const [],
    this.column,
  });

  int get total => boxes.length;
  int get missingCount => boxes.where((b) => b.status == PlanBoxStatus.missing).length;

  MergeSource? sourceOf(String code) {
    for (final s in sources) {
      if (s.palletCode.toUpperCase() == code) return s;
    }
    return null;
  }

  MergePlanBox? boxOf(String code) {
    for (final b in boxes) {
      if (b.boxNo.toUpperCase() == code) return b;
    }
    return null;
  }
}

/// Phiên gộp: mở khi quét pallet gốc, giữ kế hoạch + danh sách gợi ý của pallet đó.
class MergeSession {
  final BasePallet base;
  final List<MergeCandidate> candidates;
  final List<TripStack> stacks;

  /// Kế hoạch vanning (server bắt buộc có — không có thì đã báo lỗi khi mở phiên).
  final MergePlan? plan;

  const MergeSession({
    required this.base,
    required this.candidates,
    this.stacks = const [],
    this.plan,
  });

  /// Tra nhanh khi quét — mã quét về luôn viết hoa.
  MergeCandidate? findCandidate(String code) {
    for (final c in candidates) {
      if (c.code.toUpperCase() == code) return c;
    }
    return null;
  }
}

/// Kết quả gộp trả từ server. [cocNo] chỉ có khi gộp pallet đôi.
class MergeResult {
  final String palletListCode;
  final int boxCount;
  final int pcs;
  final int? cocNo;

  const MergeResult({
    required this.palletListCode,
    required this.boxCount,
    required this.pcs,
    this.cocNo,
  });
}