using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business.Models;
using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Client;
using Swms.FinishGoods.Web.Features.ShipmentInstruction.Business.Models;
using Swms.FinishGoods.Web.Features.ShipmentInstructions.Client;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business;

public class SiHdSoftCompareBusiness : BaseBusiness, ISiHdSoftCompareBusiness
{
    private readonly ISiHdSoftCompareApi _api;
    private readonly IShipmentInstructionApi _siApi;

    public SiHdSoftCompareBusiness(ISiHdSoftCompareApi api, IShipmentInstructionApi siApi,
        ILogger<SiHdSoftCompareBusiness> logger, ErrorHandler errorHandler)
        : base(logger, errorHandler)
    {
        _api = api;
        _siApi = siApi;
    }

    /*  Luôn lấy đủ (onlyIssues = false): màn hình lọc theo tab ngay trên client,
        đổi tab không phải gọi lại HD soft. Kho gửi chuỗi rỗng = mọi kho
        (gửi null thì API tự dùng PSNV).                                       */
    public Task<Result<AppSiCompareList>> GetListAsync(DateTime from, DateTime to, string warehouse)
        => ExecuteAsync(async () => SiCompareListDto.ToViewModel(
            await _api.GetListAsync(from.Date, to.Date, warehouse.Trim(), onlyIssues: false)));

    public Task<Result<AppSiCompare>> GetDetailAsync(string siNo)
        => ExecuteAsync(async () => SiCompareDetailDto.ToViewModel(await _api.GetDetailAsync(siNo.Trim())));

    /*  Tạo SI theo HD soft = tạo tay (POST /api/shipment-instructions): API kiểm doc_no trùng,
        tự đánh số dòng (LineNo = 0), created_by = người bấm.
        SI loại này do HD soft tự tạo — SAP không gửi lại, nên không lo bị SAP ghi đè.
        Màn hình phải gọi SiHdSoftCreate.Check trước; ở đây coi detail đã hợp lệ.          */
    public Task<Result<AppShipmentInstruction>> CreateFromHdSoftAsync(AppSiCompare detail)
        => ExecuteAsync(async () => SiDetailDto.ToViewModel(await _siApi.CreateAsync(BuildCreate(detail))));

    /// <summary>Chỉ đổi trạng thái -> completed, không kiểm tra hàng đã lấy / vanning (giống màn danh sách SI).</summary>
    public Task<Result> CompleteSwmsAsync(long swmsId)
        => ExecuteAsync(() => _siApi.CompleteAsync(swmsId));

    private static CreateSiRequestDto BuildCreate(AppSiCompare d)
    {
        string? H(string field) => SiHdSoftCreate.Hd(d, field);

        // PO / invoice phía HD soft là của cả phiếu (mapper SAP áp cho mọi dòng) — làm giống vậy
        var po = H("po_no");
        var invoice = H("invoice_no");

        // Thông tin chứng từ -> header_note, cùng khoá SapSiMapper ghi
        var note = new Dictionary<string, string>();
        void Put(string key, string? v) { if (v is not null) note[key] = v; }
        Put("bpartner_code", H("bpartner"));
        Put("warehouse_code", H("warehouse"));
        Put("order_date", H("order_date"));
        Put("promised_date", H("promised_date"));
        Put("container_size", H("container_size"));
        Put("po_no", po);
        Put("invoice_no", invoice);

        return new CreateSiRequestDto
        {
            SiNo = d.Summary.SiNo.Trim(),
            Revision = H("revision"),
            EtdDate = SiHdSoftCreate.Etd(d)!.Value,
            EtaDate = SiHdSoftCreate.Date(H("eta_date")),
            VanningDate = SiHdSoftCreate.Date(H("vanning_date")),
            CutOffAt = SiHdSoftCreate.DateTimeHm(H("cut_off_at")),
            ShipMode = H("ship_mode"),
            PortOfLoading = H("port_of_loading"),
            PortOfDischarge = H("port_of_discharge"),
            CountryCode = H("country_code"),
            ConsigneeCode = H("consignee_code"),
            ForwarderCode = H("forwarder_code"),
            CarrierCode = H("carrier_code"),
            PackingType = H("packing_type"),
            IsSerialRequired = SiHdSoftCreate.YesNo(H("is_serial_required")),
            IsWhiteFilm = SiHdSoftCreate.YesNo(H("is_white_film")),
            IsCaseMark = SiHdSoftCreate.YesNo(H("is_case_mark")),
            PicName = H("pic_name"),
            Description = $"Tạo từ HD soft {d.Summary.HdSoftDocNo}",
            HeaderNote = note.Count > 0 ? note : null,
            // Giữ thứ tự dòng HD soft; số dòng để API tự đánh
            Lines = SiHdSoftCreate.Lines(d)
                .OrderBy(l => l.HdSoftLineNos.DefaultIfEmpty(int.MaxValue).Min())
                .Select(l => new SiLineRequestDto
                {
                    LineNo = 0,
                    Model = l.Model.Trim(),
                    PoNo = po,
                    InvoiceNo = invoice,
                    PackingListNo = l.PackingListNo,
                    PackingItemNo = l.PackingItemNo,
                    QtyRequired = (int)l.HdSoftQty!.Value,
                })
                .ToList(),
        };
    }
}