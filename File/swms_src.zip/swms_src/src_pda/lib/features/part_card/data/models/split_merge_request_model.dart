import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/part_card/data/models/print_history_request_model.dart';

part 'split_merge_request_model.g.dart';

/// Khớp `SplitPartCardRequest` phía API (POST /api/part-cards/split).
///
/// Server tìm tem nguồn theo [sourcePayload], tạo [items] và huỷ (soft delete)
/// tem nguồn trong CÙNG 1 transaction.
@JsonSerializable(explicitToJson: true, includeIfNull: false)
class SplitPrintRequestModel {
  /// Payload QR tem nguồn — khớp tuyệt đối `part_cards.payload`.
  final String sourcePayload;

  /// Các tem con, mỗi tem 1 Card_ID mới. Ít nhất 2.
  final List<PrintHistoryRequestModel> items;

  const SplitPrintRequestModel({
    required this.sourcePayload,
    required this.items,
  });

  factory SplitPrintRequestModel.fromJson(Map<String, dynamic> json) =>
      _$SplitPrintRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$SplitPrintRequestModelToJson(this);
}

/// Khớp `MergePartCardsRequest` phía API (POST /api/part-cards/merge).
///
/// Server tìm các tem nguồn theo [sourcePayloads], tạo [item] và huỷ (soft
/// delete) toàn bộ tem nguồn trong CÙNG 1 transaction.
@JsonSerializable(explicitToJson: true, includeIfNull: false)
class MergePrintRequestModel {
  /// Payload QR các tem nguồn. Ít nhất 2, không trùng.
  final List<String> sourcePayloads;

  /// Tem gộp — 1 Card_ID mới, `isOverseaService = true`.
  final PrintHistoryRequestModel item;

  const MergePrintRequestModel({
    required this.sourcePayloads,
    required this.item,
  });

  factory MergePrintRequestModel.fromJson(Map<String, dynamic> json) =>
      _$MergePrintRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$MergePrintRequestModelToJson(this);
}