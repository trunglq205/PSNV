import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/storage_suggestion.dart';

part 'storage_suggestion_models.g.dart';

/// Map `GET /api/pallets/by-lot-no/{lotNo}/storage-suggestion`.
/// Chỉ đọc nên `createToJson: false`.
@JsonSerializable(createToJson: false)
class StorageSuggestionModel {
  final String lotNo;
  final String? model;
  final String? strategy;

  /// Cấu hình master hiện có. Null = model chưa có trong master.models.
  final ModelMasterConfigModel? master;

  final String? suggestedAreaCode;
  final String? suggestedAreaName;

  final List<int> suggestedRackRows;

  final String? suggestedSlotKind;

  final SuggestedLocatorModel? suggestedLocator;

  final List<SuggestedLocatorModel> alternatives;

  final LastLotLocationModel? lastLot;

  final List<String> warnings;

  const StorageSuggestionModel({
    required this.lotNo,
    this.model,
    this.strategy,
    this.master,
    this.suggestedAreaCode,
    this.suggestedAreaName,
    this.suggestedRackRows = const [],
    this.suggestedSlotKind,
    this.suggestedLocator,
    this.alternatives = const [],
    this.lastLot,
    this.warnings = const [],
  });

  factory StorageSuggestionModel.fromJson(Map<String, dynamic> json) =>
      _$StorageSuggestionModelFromJson(json);

  StorageSuggestion toEntity() => StorageSuggestion(
    lotNo: lotNo,
    model: model,
    strategy: SuggestionStrategy.fromApi(strategy),
    master: master?.toEntity(),
    suggestedAreaCode: suggestedAreaCode,
    suggestedAreaName: suggestedAreaName,
    suggestedRackRows: suggestedRackRows,
    suggestedSlotKind: suggestedSlotKind,
    suggestedLocator: suggestedLocator?.toEntity(),
    alternatives: alternatives.map((e) => e.toEntity()).toList(),
    lastLot: lastLot?.toEntity(),
    warnings: warnings,
  );
}

/// Khối `master` — cấu hình đang nằm trong `master.models`, không phải kết quả
/// gợi ý. Xem [ModelMasterConfig].
@JsonSerializable(createToJson: false)
class ModelMasterConfigModel {
  final int? areaId;
  final String? areaCode;

  final List<int> rackRows;

  const ModelMasterConfigModel({
    this.areaId,
    this.areaCode,
    this.rackRows = const [],
  });

  factory ModelMasterConfigModel.fromJson(Map<String, dynamic> json) =>
      _$ModelMasterConfigModelFromJson(json);

  ModelMasterConfig toEntity() => ModelMasterConfig(
    areaId: areaId,
    areaCode: areaCode,
    rackRows: rackRows,
  );
}

@JsonSerializable(createToJson: false)
class SuggestedLocatorModel {
  final int locatorId;
  final String locatorCode;
  final String? rackCode;
  final int? rackRow;
  final String? rackLevel;
  final String? slotKind;

  const SuggestedLocatorModel({
    required this.locatorId,
    required this.locatorCode,
    this.rackCode,
    this.rackRow,
    this.rackLevel,
    this.slotKind,
  });

  factory SuggestedLocatorModel.fromJson(Map<String, dynamic> json) =>
      _$SuggestedLocatorModelFromJson(json);

  SuggestedLocator toEntity() => SuggestedLocator(
    locatorId: locatorId,
    locatorCode: locatorCode,
    rackCode: rackCode,
    rackRow: rackRow,
    rackLevel: rackLevel,
    slotKind: slotKind,
  );
}

@JsonSerializable(createToJson: false)
class LastLotLocationModel {
  final String lotNo;
  final String locatorCode;
  final String? rackCode;
  final int? rackRow;
  final String? matchedBy;

  const LastLotLocationModel({
    required this.lotNo,
    required this.locatorCode,
    this.rackCode,
    this.rackRow,
    this.matchedBy,
  });

  factory LastLotLocationModel.fromJson(Map<String, dynamic> json) =>
      _$LastLotLocationModelFromJson(json);

  LastLotLocation toEntity() => LastLotLocation(
    lotNo: lotNo,
    locatorCode: locatorCode,
    rackCode: rackCode,
    rackRow: rackRow,
    matchedBy: LastLotMatchedBy.fromApi(matchedBy),
  );
}