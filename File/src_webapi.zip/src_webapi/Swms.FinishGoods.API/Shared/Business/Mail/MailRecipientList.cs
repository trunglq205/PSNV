﻿namespace Swms.FinishGoods.API.Shared.Business.Mail;

/// <summary>
/// Quy tắc dọn danh sách người nhận, dùng CHUNG cho mọi tính năng gửi mail
/// (phiếu bất thường, hàng thiếu…).
/// </summary>
public static class MailRecipientList
{
    /// <summary>
    /// - Một ô email chứa nhiều địa chỉ (ngăn bởi ',' hoặc ';') → tách từng địa chỉ.
    /// - Đã ở TO thì bỏ khỏi CC/BCC.
    /// - Trùng (loại, địa chỉ) chỉ giữ một; sắp TO → CC → BCC.
    /// </summary>
    public static List<MailRecipient> Normalize(IEnumerable<MailRecipient> rows)
    {
        var split = rows
            .Where(r => !string.IsNullOrWhiteSpace(r.Email))
            .SelectMany(r => r.Email
                .Split(new[] { ',', ';' },
                       StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries)
                .Select(addr => new MailRecipient
                {
                    Type = string.IsNullOrWhiteSpace(r.Type) ? "TO" : r.Type.Trim().ToUpperInvariant(),
                    Email = addr,
                    DisplayName = r.DisplayName
                }))
            .ToList();

        var toSet = split.Where(r => r.Type == "TO")
                         .Select(r => r.Email)
                         .ToHashSet(StringComparer.OrdinalIgnoreCase);

        return split
            .Where(r => r.Type == "TO" || !toSet.Contains(r.Email))
            .GroupBy(r => (r.Type, Email: r.Email.ToLowerInvariant()))
            .Select(g => g.First())
            .OrderBy(r => r.Type switch { "TO" => 0, "CC" => 1, _ => 2 })
            .ThenBy(r => r.Email, StringComparer.OrdinalIgnoreCase)
            .ToList();
    }

    /// <summary>
    /// Thêm người đang thao tác vào CC. Bỏ qua nếu họ đã có trong danh sách,
    /// để không ra hai dòng và không đẩy người đang ở TO xuống CC.
    /// </summary>
    public static List<MailRecipient> WithActorCc(List<MailRecipient> list, string? actorEmail, string? actorName)
    {
        var email = actorEmail?.Trim();
        if (string.IsNullOrWhiteSpace(email)) return list;
        if (list.Any(r => string.Equals(r.Email, email, StringComparison.OrdinalIgnoreCase))) return list;

        list.Add(new MailRecipient { Type = "CC", Email = email, DisplayName = actorName });
        return list;
    }
}