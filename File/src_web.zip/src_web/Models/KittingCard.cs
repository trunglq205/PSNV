﻿namespace SWMS_WebTool.Models
{
    public class KittingCard : AuditableEntity
    {
        public Int64 KittingCardID { get; set; }
        public string RCDetailID { get; set; }
        public string RCID { get; set; }
        public Int64 KittingListDetailId { get; set; }
        public string KittingTimeType { get; set; }
        public string Plant { get; set; }
        public string PartNo { get; set; }
        public string Model { get; set; }
        public double Quantity { get; set; }
        public DateTime DateTimeKitting { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Sloc { get; set; }
        public string Barcode { get; set; }
        public string PosFA { get; set; }
        public string PosMCS { get; set; }
        public string PicUser { get; set; }
        public string PL { get; set; }
    }

    public class KittingCardOutsideResponse : KittingCard
    {
        public string Category { get; set; }
        public string ReceiptSloc { get; set; }
        public string KittingFrom { get; set; }
        public string Reason { get; set; }
        public string Descriptions { get; set; }
        public string Remark { get; set; }
        public string PullID { get; set; }
        public DateTime? RequirementDate { get; set; }
    }
}
