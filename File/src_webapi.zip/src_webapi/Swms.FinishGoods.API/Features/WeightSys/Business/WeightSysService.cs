using Swms.FinishGoods.API.Features.Foss.DataAccess;
using Swms.FinishGoods.API.Features.WeightSys.DataAccess;

namespace Swms.FinishGoods.API.Features.WeightSys.Business;

public class WeightSysService : IWeightSysService
{
    private readonly IWeightSysRepository _repo;

    public WeightSysService(IWeightSysRepository repo)
    {
        _repo = repo;
    }

    public Task<IReadOnlyCollection<WeightDto>> GetSerialWeightAsync(
        FossCategory category,
        string modelNo,
        List<string> serialNos)
    {
        if (string.IsNullOrWhiteSpace(modelNo))
            throw new ArgumentException(nameof(modelNo));

        var serials = serialNos
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Select(x => x.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (serials.Count == 0)
            throw new ArgumentException(nameof(serialNos));

        return _repo.GetSerialWeightAsync(
            category,
            modelNo.Trim(),
            serials);
    }
}