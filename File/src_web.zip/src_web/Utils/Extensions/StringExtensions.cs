﻿using QRCoder;

namespace SWMS_WebTool.Utils.Extensions
{
    public static class StringExtensions
    {
        public static string GenerateQR(this string value)
        {
            QRCodeGenerator qrGenerator = new QRCodeGenerator();
            QRCodeData qrCodeData = qrGenerator.CreateQrCode(value, QRCodeGenerator.ECCLevel.Q);
            Base64QRCode qrCode = new Base64QRCode(qrCodeData);
            return qrCode.GetGraphic(20);
        }

        public static string GetLocalUser()
        {
            string userName = System.Security.Principal.WindowsIdentity.GetCurrent().Name;
            if (userName.Contains("\\"))
            {
                string[] strs = userName.Split('\\');
                userName = strs[1];
            }
            return userName;
        }

        public static int? ToInt(this string value)
        {
            int i;
            if (int.TryParse(value, out i)) return i;
            return null;
        }

        public static bool ToBool(this string value)
        {
            return value.ToLower() == "true";
        }
    }
}
