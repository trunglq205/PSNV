using Refit;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Client;

public interface IReturnInstructionApi
{
    /// <summary>
    /// Danh sách chỉ thị. Mọi tham số lọc đều cho phép null = không lọc.
    /// Tên query là camelCase: ASP.NET model binding KHÔNG phân biệt hoa
    /// thường nhưng CÓ phân biệt dấu gạch dưới, nên goods_type sẽ không khớp
    /// vào ReturnInstructionQuery.GoodsType.
    /// </summary>
    [Get("/api/return-instructions")]
    Task<List<ReturnInstructionDto>> GetListAsync(
        [Query] string? status = null,
        [AliasAs("goodsType")] string? goodsType = null,
        [Query] string? keyword = null,
        [AliasAs("fromDate")] DateTime? fromDate = null,
        [AliasAs("toDate")] DateTime? toDate = null);

    [Get("/api/return-instructions/{id}")]
    Task<ReturnInstructionDto> GetByIdAsync(long id);

    [Post("/api/return-instructions")]
    Task<ReturnInstructionDto> CreateAsync([Body] ReturnInstructionRequestDto request);

    [Put("/api/return-instructions/{id}")]
    Task<ReturnInstructionDto> UpdateAsync(long id, [Body] ReturnInstructionRequestDto request);

    [Delete("/api/return-instructions/{id}")]
    Task DeleteAsync(long id);

    /// <summary>
    /// Pallet hàng return WH đã nhận vào phiếu (mục 2a). Màn Web chỉ ĐỌC —
    /// pallet do WH tạo trên PDA khi quét thùng + serial.
    /// </summary>
    [Get("/api/return-instructions/{id}/pallets")]
    Task<List<ReturnPalletDto>> GetPalletsAsync(long id);

    /// <summary>
    /// Huỷ một lần nhận: xoá pallet và GIẢI PHÓNG serial khỏi sổ của phiếu.
    ///
    /// Cần có đường này vì serial bị giữ trên phạm vi toàn hệ thống: pallet
    /// quét sai mà không tháo được thì những con hàng đó không quét lại được
    /// vào đâu nữa.
    /// </summary>
    [Delete("/api/return-instructions/{id}/pallets/{palletId}")]
    Task<ReturnInstructionDto> ReleasePalletAsync(long id, long palletId);

    /// <summary>
    /// Chốt SL thực nhận: đóng phiếu và TỰ GỬI MAIL báo FA số thực tế kèm bảng
    /// lệch. Lệch thiếu / vượt đều không chặn.
    /// </summary>
    [Post("/api/return-instructions/{id}/close")]
    Task<ReturnInstructionDto> CloseAsync(long id);

    /// <summary>
    /// Mở lại phiếu đã chốt để WH quét tiếp. Chốt lại sẽ gửi FA mail mới.
    /// </summary>
    [Post("/api/return-instructions/{id}/reopen")]
    Task<ReturnInstructionDto> ReopenAsync(long id);

    /// <summary>
    /// Nhật ký serial lệch của phiếu (mục 2d ghi khi FA đóng pallet).
    ///
    /// <paramref name="openOnly"/> mặc định true bên API — màn hình cần việc
    /// CÒN PHẢI LÀM. Gửi false để xem cả nhật ký đã xử lý.
    /// </summary>
    [Get("/api/return-instructions/{id}/mismatches")]
    Task<List<ReturnMismatchDto>> GetMismatchesAsync(
        long id, [AliasAs("openOnly")] bool openOnly = true);

    /// <summary>
    /// SCS đánh dấu đã xử lý một dòng nhật ký (đã đặt riêng con hàng đó, hoặc
    /// đã trả về đúng phiếu).
    ///
    /// Route mang CẢ <paramref name="id"/> (phiếu) và <paramref name="mismatchId"/>
    /// (dòng nhật ký): controller gom chung route <c>{docId}</c>. Server xử lý
    /// theo mismatchId, docId chỉ để route khớp — nhưng vẫn phải truyền đúng,
    /// nếu không sẽ 404.
    /// </summary>
    [Post("/api/return-instructions/{id}/mismatches/{mismatchId}/resolve")]
    Task<ReturnMismatchDto> ResolveMismatchAsync(
        long id, long mismatchId, [Body] ResolveMismatchRequestDto request);
}
