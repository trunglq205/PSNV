#!/usr/bin/env python3
"""Thêm MỘT namespace khoá dịch vào PDA: 4 JSON + codegen_loader.g.dart +
locale_keys.g.dart.

Chèn SURGICAL, không sinh lại file: codegen_loader hiện đã lệch so với JSON
(lỗi có sẵn), sinh lại sẽ âm thầm đổi hàng loạt câu dịch khác.

Dùng:  python3 -I pda_i18n_ns.py spec.json [duong-dan-src_pda]

Chạy LẠI được nhiều lần: namespace đã có thì bỏ qua, không nhân đôi.
spec = {"namespace": "...", "after_namespace": "...", "keys": {k: {lang: text}}}
"""
import json
import os
import re
import sys

# Thư mục src_pda. Lấy từ tham số thứ 2, hoặc biến môi trường PDA_ROOT, hoặc
# thư mục đang đứng — để chạy được trên máy khác mà không phải sửa script.
ROOT = (sys.argv[2] if len(sys.argv) > 2
        else os.environ.get("PDA_ROOT", os.getcwd()))
LANGS = ["en", "ja", "vi", "zh"]


def esc(s):
    return s.replace("\\", "\\\\").replace('"', '\\"')


def patch_json(lang, ns, keys):
    """Chèn namespace mới bằng TEXT, không json round-trip.

    File JSON hiện KHÔNG sắp theo alphabet — nó theo thứ tự tác giả gõ. Dump
    lại với sort_keys sẽ xáo trộn cả file: diff vài nghìn dòng vô nghĩa, không
    ai review được và dễ vỡ khi merge. Nên chỉ chèn thêm, giữ nguyên phần cũ.
    """
    p = f"{ROOT}/assets/translations/{lang}.json"
    raw = open(p, "rb").read()
    crlf = b"\r\n" in raw
    text = raw.decode("utf-8-sig").replace("\r\n", "\n")

    # Kiểm ở CẤP CAO NHẤT, không phải substring: "return_fa" còn xuất hiện
    # như khoá con trong home.feature, nên `in text` cho dương tính giả.
    if ns in json.loads(text):
        print(f"  = {lang}.json: {ns} da co, bo qua")
        return

    # Chèn trước dấu } cuối cùng của object gốc.
    at = text.rstrip().rfind("}")
    head = text[:at].rstrip()
    if not head.endswith(","):
        head += ","
    body = ",\n".join(
        f'    "{k}": "{esc(keys[k][lang])}"' for k in sorted(keys))
    out = head + f'\n  "{ns}": {{\n{body}\n  }}\n' + text[at:]

    json.loads(out)                       # chốt cuối: phải parse được
    if crlf:
        out = out.replace("\n", "\r\n")
    open(p, "wb").write(out.encode("utf-8"))
    print(f"  + {lang}.json: {ns} ({len(keys)} khoa)")


def patch_loader(lang, ns, keys):
    p = f"{ROOT}/lib/core/localization/generated/codegen_loader.g.dart"
    src = open(p, encoding="utf-8").read()
    var = {"en": "_en", "ja": "_ja", "vi": "_vi", "zh": "_zh"}[lang]

    m = re.search(
        r"static const Map<String,\s*dynamic>\s*" + var + r"\s*=\s*\{", src)
    if not m:
        raise SystemExit(f"khong tim thay map {var}")
    at = m.end()

    # Thụt đúng 2 dấu cách = namespace cấp cao nhất. Không dùng substring
    # trần: cùng cái bẫy dương tính giả như bên JSON.
    if f'\n  "{ns}": {{' in src[at:]:
        # namespace đã có -> chèn từng khoá thiếu vào trong nó
        blk = re.search(r'\n  "' + ns + r'":\s*\{', src[at:])
        start = at + blk.end()
        lines = ""
        for k in sorted(keys):
            if f'"{k}":' not in src[start:start + 20000]:
                lines += f'\n    "{k}": "{esc(keys[k][lang])}",'
        src = src[:start] + lines + src[start:]
    else:
        body = "".join(
            f'\n    "{k}": "{esc(keys[k][lang])}",' for k in sorted(keys))
        src = src[:at] + f'\n  "{ns}": {{{body}\n  }},' + src[at:]

    open(p, "w", encoding="utf-8").write(src)
    print(f"  + codegen_loader {var}")


def patch_locale_keys(ns, after_ns, keys):
    p = f"{ROOT}/lib/core/localization/generated/locale_keys.g.dart"
    src = open(p, encoding="utf-8").read()
    marker = f"  static const {after_ns} = '{after_ns}';\n"
    if marker not in src:
        raise SystemExit(f"khong tim thay hang namespace {after_ns}")
    at = src.index(marker) + len(marker)

    block = ""
    for k in sorted(keys):
        name = f"{ns}_{k}"
        if f"static const {name} " in src:
            continue
        block += f"  static const {name} = '{ns}.{k}';\n"
    if f"static const {ns} = " not in src:
        block += f"  static const {ns} = '{ns}';\n"
    src = src[:at] + block + src[at:]
    open(p, "w", encoding="utf-8").write(src)
    print("  + locale_keys.g.dart")


if __name__ == "__main__":
    spec = json.load(open(sys.argv[1], encoding="utf-8"))
    ns, after_ns, keys = spec["namespace"], spec["after_namespace"], spec["keys"]
    for l in LANGS:
        patch_json(l, ns, keys)
    for l in LANGS:
        patch_loader(l, ns, keys)
    patch_locale_keys(ns, after_ns, keys)
    print("xong")
