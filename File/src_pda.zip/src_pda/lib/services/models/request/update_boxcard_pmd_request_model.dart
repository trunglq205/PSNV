import 'package:freezed_annotation/freezed_annotation.dart';

import 'base_request_model.dart';

part 'update_boxcard_pmd_request_model.g.dart';

@JsonSerializable()
class UpdateBoxcardPMDRequestModel extends BaseRequestModel {
  UpdateBoxcardPMDRequestModel({
    required this.id,
    required this.quantity,

    required this.userIDUpdate,


  });
  factory UpdateBoxcardPMDRequestModel.fromJson(Map<String, dynamic> json) =>
      _$UpdateBoxcardPMDRequestModelFromJson(json);

  final int id;
  final double quantity;
  final String userIDUpdate;

  @override
  Map<String, dynamic> toJson() => _$UpdateBoxcardPMDRequestModelToJson(this);
}
