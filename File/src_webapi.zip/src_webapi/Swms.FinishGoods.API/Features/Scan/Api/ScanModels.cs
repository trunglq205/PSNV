using Swms.FinishGoods.API.Features.Scan.DataAccess;

namespace Swms.FinishGoods.API.Features.Scan.Api
{
    /// <summary>Loại đối tượng mà mã quét trỏ tới.</summary>
    public enum ScanType
    {
        NotFound,
        Pallet,          // = lot
        Box,
        Serial,
        RecvLocation,    // vị trí phẳng: RECV / Vanning (phân biệt bằng areaCode)
        StorageLocation, // vị trí rack nhiều tầng
        Model,           // master.models (tra theo code hoặc gtin)
        PartCard,        // wms.part_cards (tra theo payload QR tem đã in)
    }

    /// <summary>
    /// Trạng thái tem Part Card. App chỉ đọc các cờ Can* để bật / tắt Sửa / Tách / Gộp,
    /// không tự suy luận lại. Cùng luật với PartCardService (sửa / tách / gộp).
    /// </summary>
    public sealed record ScanPartCardInfo(
        string CardId,        // Card_ID trong payload (số in trên tem)
        int ModelCount,
        int BoxCount,         // số thùng khi tem 1 mã; tem nhiều mã → 0
        bool IsLocked,        // khoá tay
        int StatusOqc,        // 0 = chưa vào OQC
        bool CanEdit,         // chưa vào OQC
        bool CanSplit,        // 1 mã (1 hay nhiều thùng), chưa khoá — OQC vẫn tách được
        bool CanMerge);       // chưa khoá, chưa vào OQC

    /// <summary>
    /// Kết quả phân loại mã quét. App dựa vào Type để mở đúng màn chi tiết.
    /// </summary>
    public sealed record ScanResolveResponse(
        string Code,
        string Type,        // chuỗi thường: "pallet" | "box" | "serial" | "recv_location" | "storage_location" | "not_found"
        long? Id,
        string? AreaCode,   // chỉ có với vị trí: "RECEIVING" | "VANNING" | "STORAGE"...
        ScanPartCardInfo? PartCard = null)   // chỉ có với type = "part_card"
    {
        private static string ToCode(ScanType t) => t switch
        {
            ScanType.Pallet => "pallet",
            ScanType.Box => "box",
            ScanType.Serial => "serial",
            ScanType.RecvLocation => "recv_location",
            ScanType.StorageLocation => "storage_location",
            ScanType.Model => "model",
            ScanType.PartCard => "part_card",
            _ => "not_found",
        };

        public static ScanResolveResponse Pallet(ScanHit h) =>
            new(h.Code, ToCode(ScanType.Pallet), h.Id, null);

        public static ScanResolveResponse Box(ScanHit h) =>
            new(h.Code, ToCode(ScanType.Box), h.Id, null);

        public static ScanResolveResponse Serial(ScanHit h) =>
            new(h.Code, ToCode(ScanType.Serial), h.Id, null);

        public static ScanResolveResponse Location(ScanHit h, ScanType t) =>
            new(h.Code, ToCode(t), h.Id, h.AreaCode);

        public static ScanResolveResponse Model(ScanHit h) =>
            new(h.Code, ToCode(ScanType.Model), h.Id, null);

        /// <summary>Code = payload gốc — app dùng lại làm khoá cho sửa / tách / gộp.</summary>
        public static ScanResolveResponse PartCardOf(PartCardScanHit h, ScanPartCardInfo info) =>
            new(h.Payload, ToCode(ScanType.PartCard), h.Id, null, info);

        public static ScanResolveResponse NotFound(string code) =>
            new(code, ToCode(ScanType.NotFound), null, null);
    }
}