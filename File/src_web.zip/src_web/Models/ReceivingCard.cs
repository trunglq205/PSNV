﻿using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Models
{
    public class ReceivingCard
    {
        public Int64 ReceivingCardID { get; set; }
        public byte ReceivingType { get; set; }
        public Int64? DAInvDetailID { get; set; }
        public string? ReceivingCardTime { get; set; }
        public string? Reason { get; set; }
        public string? Barcode { get; set; }
        public string? Plant { get; set; }
        public string? Category { get; set; }
        public DateTime ReceivingCardDate { get; set; }
        public string? Urgent { get; set; }
        public string? ULCOC { get; set; }
        public string? Material { get; set; }
        public string? MaterialType { get; set; }
        public string? MaterialFrequency { get; set; }
        public string? Sloc { get; set; }
        public string? CodeDate { get; set; }
        public double? TotalQuantity { get; set; }
        public double? CurrentQuantity { get; set; }
        public byte? SamplingCheck { get; set; }
        public byte? RohsCheck { get; set; }
        public string? DAInvNo { get; set; }
        public string? VendorCode { get; set; }
        public string? VendorName { get; set; }
        public string? PL { get; set; }
        public string? Rohs { get; set; }
        public int? BoxQuantity { get; set; }
        public double? qtyDAInv { get; set; }
        public string? TemporaryAreaCode { get; set; }
        public bool HaveBarcode { get; set; }
        public int Status { get; set; }

        public Int64? DAInvId { get; set; }
        public DateTime? PrintPanacimDate { get; set; }
        public bool? CheckPanacim { get; set; }
        public DateTime? PrintCheckPanacim { get; set; }
        public bool? IsChecking { get; set; }
        public bool? IsNoPrintPanacim { get; set; }
        public bool? IsPrintPanacim { get; set; }
        public int TotalReel { get; set; }

        public string? QR
        {
            get { return Barcode?.GenerateQR(); }
        }

        public List<ReceivingCardDetail>? ReceivingCardDetails { get; set; }

        public string? BoxInfo { get; set; }
    }
}
