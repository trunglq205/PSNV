using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.PartCards.Api;
using Swms.FinishGoods.API.Features.PartCards.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.Models;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.PartCards.Business;

public class PartCardService : IPartCardService
{
    private readonly IPartCardRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    // Cùng nguồn quyền với [RequirePermission<T>] (PermissionAuthorizationHandler) —
    // nên cờ CanDelete/CanLock/CanUnlock trả ra luôn khớp với việc endpoint có cho gọi hay không.
    private readonly IUserPermissionProvider _permissions;
    private readonly IHttpContextAccessor _http;

    // Code quyền lấy từ cây Perms, không gõ chuỗi tay: "part_card.delete" / ".lock" / ".unlock".
    private static readonly string DeleteCode = PermissionCatalog.CodeOf<Perms.Receiving.PartCard.Delete>();
    private static readonly string LockCode = PermissionCatalog.CodeOf<Perms.Receiving.PartCard.Lock>();
    private static readonly string UnlockCode = PermissionCatalog.CodeOf<Perms.Receiving.PartCard.Unlock>();

    // Template tem nhiều mã có đúng 3 dòng cố định.
    private const int MaxMergeRows = 3;

    // Giới hạn kích thước file import (5 MB) để tránh nuốt file rác.
    private const long MaxImportBytes = 5 * 1024 * 1024;

    public PartCardService(
        IPartCardRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        IUserPermissionProvider permissions,
        IHttpContextAccessor http)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
        _permissions = permissions;
        _http = http;
    }

    public async Task<PartCardResponse> GetPrintHistoryByIdAsync(long id)
    {
        var entity = await _repo.GetByIdAsync(id);
        if (entity is null)
            throw new NotFoundException(_localizer["PartCard.NotFound", id]);
        return PartCardResponse.From(entity, await ResolveAccessAsync());
    }

    public async Task<PagedResult<PartCardResponse>> GetPrintHistoryAsync(PartCardQuery query)
    {
        if (query.Page < 1) query.Page = 1;
        if (query.Size < 1 || query.Size > 100) query.Size = 20;

        // Chuẩn hoá: rỗng/khoảng trắng → null để repo bỏ qua điều kiện.
        query.PoNo = Norm(query.PoNo);
        query.CustomerPoNo = Norm(query.CustomerPoNo);
        query.Model = Norm(query.Model);
        query.G21Part = Norm(query.G21Part);
        query.Packer = Norm(query.Packer);
        query.Checker = Norm(query.Checker);
        query.Keyword = Norm(query.Keyword);
        query.Product = Norm(query.Product);
        if (query.Keyword is { Length: > 100 })
            query.Keyword = query.Keyword[..100];

        // Khoảng ngày nhập ngược thì đảo lại thay vì trả rỗng.
        if (query.PrintedFrom > query.PrintedTo)
            (query.PrintedFrom, query.PrintedTo) = (query.PrintedTo, query.PrintedFrom);
        if (query.ProductionFrom > query.ProductionTo)
            (query.ProductionFrom, query.ProductionTo) = (query.ProductionTo, query.ProductionFrom);

        var (rows, total) = await _repo.GetPagedAsync(query);
        // Quyền theo role tính 1 lần cho cả trang; từng dòng chỉ kết hợp thêm trạng thái khoá.
        var access = await ResolveAccessAsync();
        var items = rows.Select(r => PartCardResponse.From(r, access)).ToList();
        return new PagedResult<PartCardResponse>(items, total, query.Page, query.Size);
    }

    public async Task<PartCardResponse> SavePrintHistoryAsync(SavePrintRequest request)
    {
        ValidateRequest(request);

        var now = DateTime.UtcNow;
        var actor = _currentUser.FullName;

        var entity = BuildEntity(request, now, actor);
        entity.Id = await _repo.AddAsync(entity);

        return PartCardResponse.From(entity, await ResolveAccessAsync());
    }

    public async Task<List<PartCardResponse>> SavePrintHistoryAsync(IReadOnlyList<SavePrintRequest> requests)
    {
        if (requests.Count == 0)
            throw new BusinessRuleException(_localizer["PartCard.EmptyPayload"]);

        // Validate nghiệp vụ từng phiếu trước khi ghi.
        foreach (var req in requests)
            ValidateRequest(req);

        var now = DateTime.UtcNow;
        var actor = _currentUser.FullName;

        var entities = requests.Select(req => BuildEntity(req, now, actor)).ToList();

        var ids = await _repo.AddManyAsync(entities);
        for (int i = 0; i < entities.Count; i++)
            entities[i].Id = ids[i];

        var access = await ResolveAccessAsync();
        return entities.Select(e => PartCardResponse.From(e, access)).ToList();
    }

    public async Task<PartCardResponse> UpdatePrintHistoryAsync(long id, SavePrintRequest request)
    {
        // Cùng luật validate với lúc tạo.
        ValidateRequest(request);

        var actor = _currentUser.FullName;

        // Dùng lại BuildEntity để chuẩn hoá y hệt lúc tạo (trim, bỏ field oversea khi tắt...).
        // PrintedAt/PrintedBy/CreatedAt/CreatedBy trong entity KHÔNG được ghi xuống khi update.
        var entity = BuildEntity(request, DateTime.UtcNow, actor);
        entity.Id = id;

        var result = await _repo.UpdateAsync(entity, actor);

        if (result == PartCardUpdateResult.NotFound)
            throw new NotFoundException(_localizer["PartCard.NotFound", id]);
        if (result == PartCardUpdateResult.Locked)
            throw new BusinessRuleException(_localizer["PartCard.LockedByOqc", id]);

        // Đọc lại từ DB để FE refresh đúng dữ liệu đã lưu.
        var updated = await _repo.GetByIdAsync(id);
        return PartCardResponse.From(updated!, await ResolveAccessAsync());
    }

    public async Task<PartCardLineageResponse> GetLineageAsync(long id)
    {
        var lineage = await _repo.GetLineageAsync(id);
        if (!lineage.Exists)
            throw new NotFoundException(_localizer["PartCard.NotFound", id]);

        static PartCardLineageItem Map(PartCardLineageRow r)
            => new(r.Action, r.RelatedId, TryCardIdOf(r.Payload) ?? "", r.Payload ?? "",
                   r.IsDeleted, r.CreatedAt, r.CreatedBy);

        return new PartCardLineageResponse(
            id,
            lineage.Sources.Select(Map).ToList(),
            lineage.Derived.Select(Map).ToList());
    }

    public async Task<List<PartCardResponse>> SplitAsync(SplitPartCardRequest request)
    {
        var items = request.Items ?? new();
        if (items.Count < 2)
            throw new BusinessRuleException(_localizer["PartCard.SplitMinItems"]);
        foreach (var item in items)
            ValidateRequest(item);

        var source = (await LoadSourcesAsync(new[] { request.SourcePayload }))[0];
        var cardId = CardIdOf(source.Payload);

        // Chỉ tách phiếu 1 mã (1 hay nhiều thùng đều được).
        var src = Lines(source);
        if (src.Count != 1)
            throw new BusinessRuleException(_localizer["PartCard.SplitSingleOnly", cardId]);

        var now = DateTime.UtcNow;
        var actor = _currentUser.FullName;
        var entities = items.Select(req => BuildEntity(req, now, actor)).ToList();

        // Mỗi phiếu con: đúng 1 mã = mã phiếu nguồn, Qty > 0.
        //   Tổng Qty  = Qty phiếu nguồn.
        //   Thùng     : nguồn 1 thùng → mỗi phiếu con 1 thùng (tách pcs);
        //               nguồn N thùng → tổng thùng phiếu con = N (chia thùng).
        var total = 0;

        foreach (var e in entities)
        {
            var l = Lines(e);

            if (l.Count != 1 || l[0].Model != src[0].Model)
                throw new BusinessRuleException(
                    _localizer["PartCard.SplitModelMismatch", src[0].Model]);

            if (l[0].Qty <= 0)
                throw new BusinessRuleException(
                    _localizer["PartCard.SplitQtyMismatch", src[0].Qty]);

            total += l[0].Qty;
        }

        if (total != src[0].Qty)
            throw new BusinessRuleException(
                _localizer["PartCard.SplitQtyMismatch", src[0].Qty]);

        var ids = await ReplaceAsync(
            new List<PartCard> { source }, entities, PartCardLineageAction.Split, actor);
        for (int i = 0; i < entities.Count; i++)
            entities[i].Id = ids[i];

        var access = await ResolveAccessAsync();
        return entities.Select(e => PartCardResponse.From(e, access)).ToList();
    }

    public async Task<PartCardResponse> MergeAsync(MergePartCardsRequest request)
    {
        var payloads = (request.SourcePayloads ?? new())
            .Select(p => p?.Trim() ?? "")
            .Where(p => p.Length > 0)
            .ToList();
        if (payloads.Count < 2)
            throw new BusinessRuleException(_localizer["PartCard.MergeMinSources"]);
        if (payloads.Distinct(StringComparer.OrdinalIgnoreCase).Count() != payloads.Count)
            throw new BusinessRuleException(_localizer["PartCard.MergeDuplicateSource"]);

        ValidateRequest(request.Item);

        var sources = await LoadSourcesAsync(payloads);
        // Payload khác chuỗi nhưng trỏ cùng 1 phiếu (khác hoa thường / khoảng trắng cuối).
        if (sources.Select(x => x.Id).Distinct().Count() != sources.Count)
            throw new BusinessRuleException(_localizer["PartCard.MergeDuplicateSource"]);

        var now = DateTime.UtcNow;
        var actor = _currentUser.FullName;
        var entity = BuildEntity(request.Item, now, actor);

        var merged = Lines(entity);
        if (merged.Count > MaxMergeRows)
            throw new BusinessRuleException(_localizer["PartCard.MergeTooManyRows", MaxMergeRows]);

        // Theo từng mã: tổng Qty (pcs) phải giữ nguyên — gộp không được sinh thêm hay
        // làm mất hàng. Số thùng KHÔNG so: khi gộp có thể đóng lại thùng (user sửa Box).
        var before = QtyByModel(sources.SelectMany(Lines));
        var after = QtyByModel(merged);
        foreach (var model in before.Keys.Union(after.Keys))
        {
            if (before.GetValueOrDefault(model) != after.GetValueOrDefault(model))
                throw new BusinessRuleException(_localizer["PartCard.MergeQtyMismatch", model]);
        }

        var ids = await ReplaceAsync(
            sources, new List<PartCard> { entity }, PartCardLineageAction.Merge, actor);
        entity.Id = ids[0];

        return PartCardResponse.From(entity, await ResolveAccessAsync());
    }

    public async Task<PartCardResponse> UpdateDimensionsAsync(long id, UpdateDimensionsRequest request)
    {
        var ok = await _repo.UpdateDimensionsAsync(
            id, request.Length, request.Width, request.Height, request.Weight,
            _currentUser.FullName);

        if (!ok)
            throw new NotFoundException(_localizer["PartCard.NotFound", id]);

        // Trả về phiếu sau cập nhật để FE refresh ngay.
        var entity = await _repo.GetByIdAsync(id);
        return PartCardResponse.From(entity!, await ResolveAccessAsync());
    }

    public async Task DeletePrintHistoryAsync(long id)
    {
        var result = await _repo.SoftDeleteAsync(new[] { id }, _currentUser.FullName);
        if (result.Locked.Count > 0)
            throw new BusinessRuleException(_localizer["PartCard.LockedCannotDelete", id]);
        if (result.Deleted.Count == 0)
            throw new NotFoundException(_localizer["PartCard.NotFound", id]);
    }

    public async Task<DeletePartCardsResponse> DeletePrintHistoryAsync(IReadOnlyList<long> ids)
    {
        var distinct = NormalizeIds(ids);

        var result = await _repo.SoftDeleteAsync(distinct, _currentUser.FullName);

        // Phiếu đang khoá / id không tồn tại / đã xoá trước đó: không coi là lỗi,
        // các phiếu còn lại vẫn xoá, chỉ báo lại cho FE.
        var notFound = distinct.Except(result.Deleted).Except(result.Locked).ToList();
        return new DeletePartCardsResponse(result.Deleted.Count, notFound, result.Locked);
    }

    public Task<PartCardResponse> LockPrintHistoryAsync(long id) => SetLockedOneAsync(id, true);

    public Task<PartCardResponse> UnlockPrintHistoryAsync(long id) => SetLockedOneAsync(id, false);

    public Task<LockPartCardsResponse> LockPrintHistoryAsync(IReadOnlyList<long> ids)
        => SetLockedManyAsync(ids, true);

    public Task<LockPartCardsResponse> UnlockPrintHistoryAsync(IReadOnlyList<long> ids)
        => SetLockedManyAsync(ids, false);

    // ---- helpers ----

    private async Task<PartCardResponse> SetLockedOneAsync(long id, bool locked)
    {
        await _repo.SetLockedAsync(new[] { id }, locked, _currentUser.FullName);

        // Idempotent: phiếu đã ở sẵn trạng thái đích vẫn trả 200 kèm dữ liệu hiện tại.
        // Chỉ báo lỗi khi phiếu không tồn tại / đã xoá.
        var entity = await _repo.GetByIdAsync(id);
        if (entity is null)
            throw new NotFoundException(_localizer["PartCard.NotFound", id]);
        return PartCardResponse.From(entity, await ResolveAccessAsync());
    }

    private async Task<LockPartCardsResponse> SetLockedManyAsync(IReadOnlyList<long> ids, bool locked)
    {
        var distinct = NormalizeIds(ids);

        var result = await _repo.SetLockedAsync(distinct, locked, _currentUser.FullName);

        var notFound = distinct.Except(result.Changed).Except(result.Unchanged).ToList();
        return new LockPartCardsResponse(result.Changed.Count, result.Unchanged, notFound);
    }

    // ---- tách / gộp ----

    // Đọc phiếu nguồn theo đúng thứ tự [payloads]. Thiếu 1 phiếu là NotFound.
    private async Task<List<PartCard>> LoadSourcesAsync(IReadOnlyList<string> payloads)
    {
        var keys = payloads.Select(p => (p ?? "").Trim()).ToList();
        if (keys.Any(k => k.Length == 0))
            throw new BusinessRuleException(_localizer["PartCard.EmptyPayload"]);

        var found = await _repo.GetByPayloadsAsync(keys);

        var result = new List<PartCard>(keys.Count);
        foreach (var key in keys)
        {
            // SQL so payload không phân biệt hoa thường / bỏ khoảng trắng cuối — so lại
            // y như vậy. Trùng payload (hiếm) → lấy phiếu mới nhất, giống FE tra theo payload.
            var card = found
                .Where(c => string.Equals(c.Payload?.TrimEnd(), key, StringComparison.OrdinalIgnoreCase))
                .MaxBy(c => c.Id);
            if (card is null)
                throw new NotFoundException(_localizer["PartCard.SourceNotFound", CardIdOf(key)]);
            result.Add(card);
        }
        return result;
    }

    // Gọi repo + đổi kết quả thành exception có Card_ID của phiếu gây lỗi.
    private async Task<List<long>> ReplaceAsync(
        List<PartCard> sources, List<PartCard> replacements, string action, string? actor)
    {
        var r = await _repo.ReplaceAsync(sources, replacements, action, actor);
        if (r.Status == PartCardReplaceStatus.Replaced)
            return r.NewIds;

        var cardId = CardIdOf(sources.FirstOrDefault(x => x.Id == r.BlockedId)?.Payload);
        throw r.Status switch
        {
            PartCardReplaceStatus.Locked =>
                new BusinessRuleException(_localizer["PartCard.SourceLocked", cardId]),
            PartCardReplaceStatus.OqcLocked =>
                new BusinessRuleException(_localizer["PartCard.SourceLockedByOqc", cardId]),
            _ =>
                new BusinessRuleException(_localizer["PartCard.SourceChanged", cardId]),
        };
    }

    // Dòng mã hiệu lực của 1 phiếu (đã chuẩn hoá model):
    //   - oversea: đọc ở rows, số thùng = inner_box (rỗng / lạ → 1);
    //   - thường : đọc ở header, luôn 1 thùng.
    private static List<(string Model, int Box, int Qty)> Lines(PartCard c)
    {
        if (c.IsOverseaService)
            return c.Rows
                .Where(r => !string.IsNullOrWhiteSpace(r.Model))
                .Select(r => (NormModel(r.Model), BoxOf(r.InnerBox), r.Qty))
                .ToList();

        return string.IsNullOrWhiteSpace(c.Model)
            ? new()
            : new() { (NormModel(c.Model), 1, c.Qty ?? 0) };
    }

    // Tổng Qty (pcs) theo mã.
    private static Dictionary<string, int> QtyByModel(
        IEnumerable<(string Model, int Box, int Qty)> lines)
        => lines.GroupBy(l => l.Model)
                .ToDictionary(g => g.Key, g => g.Sum(l => l.Qty));

    private static int BoxOf(string? innerBox)
        => int.TryParse(innerBox?.Trim(), out var n) && n > 0 ? n : 1;

    private static string NormModel(string model) => model.Trim().ToUpperInvariant();

    // Card_ID trong payload (`ID=...|...`). Payload kiểu cũ không có field ID → null.
    private static string? TryCardIdOf(string? payload)
    {
        foreach (var field in (payload ?? "").Split('|'))
        {
            var i = field.IndexOf('=');
            if (i > 0 && field[..i].Trim() == "ID")
                return field[(i + 1)..].Trim();
        }
        return null;
    }

    // Dùng cho message lỗi (user nhìn thấy trên tem): không có Card_ID thì hiện nguyên payload.
    private static string CardIdOf(string? payload) => TryCardIdOf(payload) ?? payload ?? "";

    // Bỏ id trùng / không hợp lệ trước khi xuống DB; rỗng thì báo lỗi.
    private List<long> NormalizeIds(IReadOnlyList<long>? ids)
    {
        var distinct = (ids ?? Array.Empty<long>()).Where(i => i > 0).Distinct().ToList();
        if (distinct.Count == 0)
            throw new BusinessRuleException(_localizer["PartCard.EmptyPayload"]);
        return distinct;
    }

    // Quyền theo role của người đang gọi trên màn Part Card — tính 1 lần / request.
    // User thường: provider đọc DB có cache 5 phút, và [RequirePermission] của chính request này
    // đã nạp cache rồi nên ở đây không tốn thêm query. API key: đọc từ claim "perm".
    private async Task<PartCardAccess> ResolveAccessAsync()
    {
        var principal = _http.HttpContext?.User;
        if (principal?.Identity?.IsAuthenticated != true)
            return default;   // không xác thực ⟹ không có quyền nào

        var perms = await _permissions.GetPermissionsAsync(principal);
        return new PartCardAccess(
            Delete: perms.Contains(DeleteCode),
            Lock: perms.Contains(LockCode),
            Unlock: perms.Contains(UnlockCode));
    }

    private PartCard BuildEntity(SavePrintRequest req, DateTime now, string? actor)
    {
        var oversea = req.IsOverseaService;

        var rows = req.Rows
            .Where(r => !string.IsNullOrWhiteSpace(r.Model))
            .Select((r, i) => new PartCardRow
            {
                LineNo = i + 1,
                Model = r.Model.Trim(),
                Qty = r.Qty,
                Origin = Norm(r.Origin),
                // Field oversea: chỉ lưu khi phiếu bật service part oversea,
                // tránh ghi dữ liệu rác từ các ô ẩn phía FE.
                G21Part = oversea ? Norm(r.G21Part) : null,
                InnerBox = oversea ? Norm(r.InnerBox) : null,
                OqcChecked = oversea && r.OqcChecked,
                InnerLength = oversea ? r.InnerLength : null,
                InnerWidth = oversea ? r.InnerWidth : null,
                InnerHeight = oversea ? r.InnerHeight : null,
                InnerWeight = oversea ? r.InnerWeight : null,
            })
            .ToList();

        return new PartCard
        {
            PoNo = Norm(req.PoNo),
            CustomerPoNo = Norm(req.CustomerPoNo),
            ProductionDate = req.ProductionDate.Date,
            Packer = Norm(req.Packer),
            Checker = Norm(req.Checker),
            Category = req.Category,
            Length = req.Length,
            Width = req.Width,
            Height = req.Height,
            Weight = req.Weight,
            Model = oversea ? null : Norm(req.Model),
            Qty = oversea ? null : req.Qty,
            Origin = oversea ? null : Norm(req.Origin),
            IsOverseaService = req.IsOverseaService,
            PrintedAt = now,
            PrintedBy = actor,
            CreatedAt = now,
            CreatedBy = actor,
            Payload = req.Payload,
            Rows = rows,
        };
    }

    private void ValidateRequest(SavePrintRequest req)
    {
        if (req.ProductionDate == default)
            throw new BusinessRuleException(_localizer["PartCard.ProductionDateRequired"]);

        if (req.IsOverseaService)
        {
            var validRows = req.Rows.Count(r => !string.IsNullOrWhiteSpace(r.Model));
            if (validRows == 0)
                throw new BusinessRuleException(_localizer["PartCard.NoValidRows"]);
        }
        else if (string.IsNullOrEmpty(req.Model))
        {
            throw new BusinessRuleException(_localizer["PartCard.ModelRequired"]);
        }

    }

    private static string? Norm(string? s)
        => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}