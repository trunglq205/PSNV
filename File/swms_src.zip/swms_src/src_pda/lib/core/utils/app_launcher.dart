import 'package:android_intent_plus/android_intent.dart';
import 'package:app_settings/app_settings.dart';
import 'package:url_launcher/url_launcher.dart';

/// ============================================================
/// TÌM PACKAGE NAME & COMPONENT NAME CỦA APP (dùng cho AndroidIntent)
/// ============================================================
///
/// Đường dẫn adb (Windows):
///   C:\Users\<user>\AppData\Local\Android\Sdk\platform-tools\adb.exe
///
/// 1. Tìm PACKAGE NAME (lọc theo tên app):
///    adb shell pm list packages | Select-String datawedge
///    => package:com.symbol.datawedge  (lấy phần sau "package:")
///
/// 2. Tìm COMPONENT NAME (launcher activity):
///    adb shell cmd package resolve-activity --brief com.symbol.datawedge
///    => com.symbol.datawedge/com.symbol.datawedge.DWDemoActivity
///       (dạng: package/componentName)
///
/// 3. Nếu bước 2 trả về "ResolverActivity" (app không có launcher),
///    liệt kê tất cả activity:
///    adb shell dumpsys package com.symbol.datawedge | Select-String "Activity"
///    => chọn activity phù hợp, vd .DWDemoActivity
class AppLauncher {
  // ---- MỞ CÀI ĐẶT ----
  static void openSettings() => AppSettings.openAppSettings(type: AppSettingsType.generalSettings);
  static void openWifi() => AppSettings.openAppSettings(type: AppSettingsType.wifi);
  static void openLocation() => AppSettings.openAppSettings(type: AppSettingsType.location);
  static void openBluetooth() => AppSettings.openAppSettings(type: AppSettingsType.bluetooth);
  static void openNotification() => AppSettings.openAppSettings(type: AppSettingsType.notification);

  // ---- MỞ APP KHÁC ----
  static Future<void> open(Uri uri) async {
    if (await canLaunchUrl(uri)) {
      await launchUrl(uri, mode: LaunchMode.externalApplication);
    }
  }

  static Future<void> openDataWedge() async {
    try {
      const intent = AndroidIntent(
        action: 'android.intent.action.MAIN',
        package: 'com.symbol.datawedge',
        componentName: 'com.symbol.datawedge.DWDemoActivity',
      );
      await intent.launch();
    } on Exception{
      // Skip
    }
  }

  static Future<void> openSmartWarehouse() async {
    try {
      const intent = AndroidIntent(
        action: 'android.intent.action.MAIN',
        package: 'com.psnv.smart_warehouse.dev',
        componentName: 'com.example.smart_warehouse.MainActivity',
      );
      await intent.launch();
    } on Exception{
      // Skip
    }
  }
}