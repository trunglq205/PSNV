import 'dart:async';
import 'dart:typed_data';

import 'package:flutter_bluetooth_serial_plus/flutter_bluetooth_serial_plus.dart';

import 'package:swms_finish_goods/core/utils/printing/printer.dart';

/// Máy in SATO qua Bluetooth SPP.
///
/// Chiến lược: **connect-per-job**. Máy in cầm tay tự sleep sau vài phút,
/// giữ socket lâu dài rất hay dẫn tới `isConnected == true` nhưng gửi đi
/// không tới đâu. Mở kết nối ngay trước khi in thì trạng thái luôn tươi.
///
/// Nhiều nhãn ⇒ dùng [printBatch]: một phiên SPP, ACK riêng từng nhãn.
class SatoPrinter implements Printer {
  SatoPrinter({
    this.connectTimeout = const Duration(seconds: 15),
    this.ackTimeout = const Duration(seconds: 10),
  });

  /// Giới hạn thời gian mở SPP. Không có timeout thì máy in tắt nguồn
  /// sẽ làm Future treo vô hạn và UI đứng im.
  final Duration connectTimeout;

  /// Giới hạn chờ ACK sau khi đã gửi xong một nhãn.
  final Duration ackTimeout;

  static final _enq = Uint8List.fromList([0x05]);
  static const _ackByte = 0x06;
  static const _nakByte = 0x15;

  BluetoothConnection? _conn;
  StreamSubscription<Uint8List>? _inputSub;
  Completer<void>? _ack;
  Future<void>? _inFlight;
  bool _disposed = false;

  @override
  bool get isBusy => _inFlight != null;

  @override
  Future<void> printBytes(PrinterDevice device, List<int> bytes) =>
      printBatch(device, [bytes]);

  @override
  Future<void> printBatch(
    PrinterDevice device,
    List<List<int>> payloads, {
    void Function(int index)? onPrinted,
  }) {
    if (_disposed) {
      throw const PrinterException(
        PrinterErrorType.print,
        message: 'Printer đã dispose',
      );
    }
    if (payloads.isEmpty || payloads.any((p) => p.isEmpty)) {
      throw const PrinterException(
        PrinterErrorType.invalidData,
        message: 'Payload rỗng',
      );
    }

    // Xếp hàng: nút In bị double-tap là chuyện thường, và 2 socket SPP mở
    // song song tới cùng một máy in thì cả hai đều fail.
    late final Future<void> job;
    job = (_inFlight ?? Future<void>.value())
        // Lỗi của job trước không được làm job sau bị huỷ.
        .then<void>((_) {}, onError: (_) {})
        .then((_) => _runBatch(device, payloads, onPrinted))
        .whenComplete(() {
          if (identical(_inFlight, job)) _inFlight = null;
        });
    _inFlight = job;
    return job;
  }

  Future<void> _runBatch(
    PrinterDevice device,
    List<List<int>> payloads,
    void Function(int index)? onPrinted,
  ) async {
    var printed = 0;
    try {
      final conn = await BluetoothConnection.toAddress(
        device.macAddress,
      ).timeout(connectTimeout);
      _conn = conn;
      if (!conn.isConnected) {
        throw const PrinterException(
          PrinterErrorType.connect,
          message: 'Mở được socket nhưng không ở trạng thái connected',
        );
      }

      // MỘT listener cho cả lô — mỗi nhãn tạo một Completer mới.
      _listenInput(conn);

      for (var i = 0; i < payloads.length; i++) {
        await _sendOne(conn, payloads[i]);
        printed++;
        onPrinted?.call(i);
      }

      // Cả lô xong — ENQ kết thúc phiên.
      conn.output.add(_enq);
      await conn.output.allSent;
      await Future<void>.delayed(const Duration(milliseconds: 500));
    } on PrinterException catch (e) {
      throw _wrapBatch(e, printed, payloads.length);
    } on TimeoutException catch (e) {
      throw PrinterBatchException(
        printed: printed,
        total: payloads.length,
        type: PrinterErrorType.connect,
        message: 'Hết thời gian kết nối tới ${device.macAddress}',
        cause: e,
      );
    } on Object catch (e) {
      throw PrinterBatchException(
        printed: printed,
        total: payloads.length,
        type: PrinterErrorType.print,
        cause: e,
      );
    } finally {
      // Luôn đóng — kể cả khi lỗi. Đây là toàn bộ điểm mấu chốt của
      // chiến lược connect-per-job.
      await _close();
    }
  }

  PrinterBatchException _wrapBatch(
    PrinterException e,
    int printed,
    int total,
  ) => e is PrinterBatchException
      ? e
      : PrinterBatchException(
          printed: printed,
          total: total,
          type: e.type,
          message: e.message,
          cause: e.cause,
        );

  void _listenInput(BluetoothConnection conn) {
    final input = conn.input;
    _inputSub = input.listen(
      (event) {
        final ack = _ack;
        if (ack == null || ack.isCompleted) return;
        for (final b in event) {
          if (b == _nakByte) {
            ack.completeError(
              const PrinterException(
                PrinterErrorType.print,
                message: 'Máy in trả NAK — kiểm tra giấy/đầu in',
              ),
            );
            return;
          }
          if (b == _ackByte) {
            ack.complete();
            return;
          }
        }
      },
      onError: (Object e) {
        final ack = _ack;
        if (ack != null && !ack.isCompleted) {
          ack.completeError(PrinterException(PrinterErrorType.print, cause: e));
        }
      },
      cancelOnError: true,
    );
  }

  Future<void> _sendOne(BluetoothConnection conn, List<int> bytes) async {
    if (!conn.isConnected) {
      throw const PrinterException(
        PrinterErrorType.print,
        message: 'Mất kết nối giữa lô in',
      );
    }
    final ack = Completer<void>();
    _ack = ack;

    conn.output.add(Uint8List.fromList(bytes));
    // Phải chờ buffer đẩy hết — gửi tiếp khi chưa flush sẽ ra tem thiếu.
    await conn.output.allSent;

    await ack.future.timeout(
      ackTimeout,
      onTimeout: () => throw const PrinterException(
        PrinterErrorType.print,
        message: 'Hết thời gian chờ ACK từ máy in',
      ),
    );
  }

  Future<void> _close() async {
    _ack = null;
    await _inputSub?.cancel();
    _inputSub = null;
    final conn = _conn;
    _conn = null;
    try {
      await conn?.close();
    } catch (_) {
      // Đóng socket đã chết thì bỏ qua — không có gì để cứu.
    }
  }

  @override
  Future<void> dispose() async {
    _disposed = true;
    try {
      await _inFlight;
    } catch (_) {
      // Job đang chạy tự lo lỗi của nó.
    }
    await _close();
  }
}
