import 'package:flutter/material.dart';
import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';

part 'assignment_model.g.dart';

/// Model nhận từ API cho một "việc của tôi".
/// API chỉ trả dữ liệu thuần (type, số liệu, hạn); phần trình bày
/// (icon/tone/labelKey/unitKey) suy ra từ `type` khi map sang entity.
@JsonSerializable()
class AssignmentModel {
  final String id;
  final String type; // 'picking' | 'stocktake_morning' | ...
  final String code;

  /// Tham số mô tả đã chuẩn hoá từ API (vd ['Jakarta','A','10']).
  final List<String> subArgs;

  /// Hạn chót hiển thị, server dựng sẵn theo locale/độ trễ.
  final String deadlineText;
  final bool urgent;
  final int done;
  final int total;

  const AssignmentModel({
    required this.id,
    required this.type,
    required this.code,
    required this.done,
    required this.total,
    this.subArgs = const [],
    this.deadlineText = '',
    this.urgent = false,
  });

  factory AssignmentModel.fromJson(Map<String, dynamic> json) =>
      _$AssignmentModelFromJson(json);

  Map<String, dynamic> toJson() => _$AssignmentModelToJson(this);

  AssignmentData toEntity() {
    final p = _present(type);
    return AssignmentData(
      id: id,
      labelKey: p.labelKey,
      icon: p.icon,
      code: code,
      subKey: p.subKey,
      subArgs: subArgs,
      deadlineText: deadlineText,
      urgent: urgent,
      done: done,
      total: total,
      unitKey: p.unitKey,
      tone: p.tone,
      toneBg: p.toneBg,
    );
  }
}

/// Bảng trình bày theo `type`.
class _Present {
  final String labelKey;
  final String subKey;
  final String unitKey;
  final IconData icon;
  final Color tone;
  final Color toneBg;
  const _Present({
    required this.labelKey,
    required this.subKey,
    required this.unitKey,
    required this.icon,
    required this.tone,
    required this.toneBg,
  });
}

_Present _present(String type) {
  switch (type) {
    case 'picking':
      return const _Present(
        labelKey: LocaleKeys.home_task_picking,
        subKey: LocaleKeys.home_task_picking_sub,
        unitKey: LocaleKeys.home_unit_box,
        icon: Icons.outbox_outlined,
        tone: Color(0xFFF57C00),
        toneBg: Color(0xFFFFF3E0),
      );
    case 'stocktake_morning':
    default:
      return const _Present(
        labelKey: LocaleKeys.home_task_stocktake_morning,
        subKey: LocaleKeys.home_task_stocktake_sub,
        unitKey: LocaleKeys.home_unit_location,
        icon: Icons.schedule,
        tone: Color(0xFF2E7D32),
        toneBg: Color(0xFFE8F5E9),
      );
  }
}
