﻿namespace SWMS_WebTool.Models.Barcode
{
    public class BarcodeLineDIP
    {
        public string Model { get; set; }
        public string Time { get; set; }
        public double Quantity { get; set; }
        public string Line { get; set; }
        public string DeliveryDate { get; set; }
        //public string ModelFA { get; set; }
    }
}
