using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;

namespace SWMS_WebTool.Models.ImportModel
{
    public class KittingPlanImport
    {
        public string STT { get; set; }
        public string Plant { get; set; }
        public string ReservationNo { get; set; }
        public string Recipient { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Model { get; set; }
        public double ModelQuantity { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Material { get; set; }
        public string Descriptions { get; set; }
        public string Unit { get; set; }
        public double Quantity { get; set; }
        public string Receipt_Location { get; set; }
        public string ReceiptSloc { get; set; }
        public string Issue_Sloc { get; set; }
        public string RoHS { get; set; }
        public string INS { get; set; }
        public string MaterialDescription { get; set; }
        public DateTime? RequirementsDate { get; set; }
        public string PSNVStock { get; set; }
        public string KHFAN7 { get; set; }
        public string KittingFrom { get; set; }
        public string VenderName { get; set; }
        public string Tcode { get; set; }
        public string GroupName { get; set; }
        public string Account { get; set; }
        public string CostCenter { get; set; }
        public string Remark { get; set; }
        public string Reason { get; set; }
        public string? Category { get; set; }
        public double? QuantityActual { get; set; }
        public string? Pallet { get; set; }
        public int ReservationItem { get; set; }
    }

    public class ImportKittingListViewModel
    {
        [Display(Name = "Plant")]
        [Required(ErrorMessage = "Plant field is required.")]
        public string? Plant { get; set; }

        [Display(Name = "Category")]
        [Required(ErrorMessage = "Category field is required.")]
        public string? Category { get; set; }

        public IEnumerable<KittingPlanImport> KittingPlanImports { get; set; }
    }

    public class ImportKittingListSubconViewModel
    {
        [Display(Name = "Plant")]
        public string? Plant { get; set; }

        [Display(Name = "Category")]
        public string? Category { get; set; }
        public KittingFrom? KTFrom { get; set; }

        public IEnumerable<KittingPlanImport> KittingPlanImports { get; set; }
    }
}
