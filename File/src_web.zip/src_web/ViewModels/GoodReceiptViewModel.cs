using SWMS_WebTool.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.CSharp;

namespace SWMS_WebTool.ViewModels
{
    public class GoodReceiptViewModel : TableViewModel<GoodReceipt, GoodReceiptFilter>
    {
        public ReceivingSchedule? ReceivingSchedule { get; set; }
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, GoodReceiptFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Vendor = filter?.VendorCode ?? Filter.VendorCode,
                Plant = filter?.Plant ?? Filter.Plant,
                No = filter?.DeliveryPlanNo ?? Filter.DeliveryPlanNo,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Material = filter?.Material ?? Filter.Material,
                TrackingNumber = filter?.TrackingNumber ?? Filter.TrackingNumber,
                Urgent = filter?.isUrgent ?? Filter.isUrgent,
                Status = filter?.Status ?? Filter.Status,
                Date = (filter?.Date ?? Filter.Date)?.ToString("yyyy-MM-dd"),
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class InputTrackingNumberViewModel
    {
        [Display(Name = "DA/INV No")]
        [Required(ErrorMessage = "DA/INV No is required.")]
        public string? DACode { get; set; }

        [Display(Name = "Vendor Code")]
        [Required(ErrorMessage = "Vendor Code is required.")]
        public string? VendorCode { get; set; }

        [Display(Name = "Tracking Number")]
        [Required(ErrorMessage = "Tracking Number is required.")]
        public string? TrackingNumber { get; set; }

        public DeliveryPlanType Type { get; set; }
    }
}

