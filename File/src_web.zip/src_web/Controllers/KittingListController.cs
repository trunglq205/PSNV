using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using SWMS_WebTool.Services;
using SWMS_WebTool.ViewModels;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Models.Barcode;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Utils.Extensions;
using System.Data;
using SWMS_WebTool.Models.DataKitting;
using Wkhtmltopdf.NetCore;
using Wkhtmltopdf.NetCore.Options;
using QRCoder;

namespace SWMS_WebTool.Controllers
{
    public class KittingListController : BaseController
    {
        private readonly ApiService _apiService;
        private readonly IGeneratePdf _generatePdf;
        public KittingListController(ApiService apiService, IGeneratePdf generatePdf)
        {
            _apiService = apiService;
            _generatePdf = generatePdf;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] KittingListFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
            var dropdownData = await _apiService.GetCategoryPlanMaster();
            ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
            ViewBag.Categorys = new SelectList(dropdownData.Where(s => !string.IsNullOrEmpty(filter.Plant) ? s.Plant == filter.Plant : s.Plant == "").Select(x => x.Category).Distinct().ToList());
            ViewBag.SpecialParts = new SelectList(dropdownData.Select(x => x.SpecialPart).Distinct().ToList());
            int total = 10;

            if (User.Identity.Name != null)
            {
                if (User.Identity.Name.Contains("-PMD"))
                {
                    filter.Tab = KittingTab.KittingOutside;
                    filter.Cate = "PMD";
                }
            }

            IEnumerable<KittingList> items = new List<KittingList>();
            switch (filter.Tab)
            {
                case KittingTab.KittingFA:
                    var responseData = await _apiService.SearchKittingList(filter, pageNumber, _pageSize);
                    total = responseData.TotalRecord;
                    items = responseData.Records ?? new List<KittingList>();
                    break;
                case KittingTab.KittingDIP:
                    var responseDataDIP = await _apiService.SearchKittingList(filter, pageNumber, _pageSize);
                    total = responseDataDIP.TotalRecord;
                    items = responseDataDIP.Records ?? new List<KittingList>();
                    break;
                case KittingTab.KittingSubcon:
                    var responseDataSubcon = await _apiService.SearchKittingList(filter, pageNumber, _pageSize);
                    total = responseDataSubcon.TotalRecord;
                    items = responseDataSubcon.Records ?? new List<KittingList>();
                    break;
                case KittingTab.KittingOutside:
                    var responseDataOutside = await _apiService.SearchKittingList(filter, pageNumber, _pageSize);
                    total = responseDataOutside.TotalRecord;
                    items = responseDataOutside.Records ?? new List<KittingList>();
                    break;
            }
            var model = new KittingListViewModel()
            {
                Items = items,
                Filter = filter,
                PageNumber = pageNumber,
                PageSize = _pageSize,
                TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                Total = total,
            };
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> CreateKittingList(string plan, string cate, string proDate, string modelname, string line, string time, string fromtime,
            string finishtime, string specialpart, bool checkboxJIT, bool checkboxProcess, bool checkboxUrgent,
            string typekt, string uploadno, string ktfrom, KittingTab tab, int pageNumber = 1, string? pageSize = null)
        {
            KittingType type;
            KittingFrom ktfr;
            var dropdownData = await _apiService.GetCategoryPlanMaster();
            ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
            ViewBag.Categorys = new SelectList(dropdownData.Where(s => !string.IsNullOrEmpty(plan) ? s.Plant == plan : s.Plant == "").Select(x => x.Category).Distinct().ToList());
            ViewBag.SpecialParts = new SelectList(dropdownData.Select(x => x.SpecialPart).Distinct().ToList());
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
            var _filter = new KittingPlanFilter()
            {
                Plant = plan,
                Cate = cate,
                ProDate = proDate ?? DateTime.Now.ToString("yyyy-MM-dd"),
                Model = modelname,
                Line = line,
                Time = time,
                FromTime = fromtime,
                FinishTime = finishtime,
                Type = Enum.TryParse(typekt, true, out type) ? type : KittingType.OneTime,
                SpecialPart = specialpart,
                Tab = tab,
                JIT = checkboxJIT,
                UploadNo = uploadno ?? "",
                Process = checkboxProcess,
                IsUrgentDIP = checkboxUrgent,
                KTFrom = Enum.TryParse(ktfrom, true, out ktfr) ? ktfr : KittingFrom.PSNV,
            };
            int total = 20;
            int totalRecordItem = 0;
            IEnumerable<KittingPlan> items = new List<KittingPlan>();
            switch (tab)
            {
                case KittingTab.KittingFA:
                    var responseData = await _apiService.GetDataKittingFA(_filter, 1, Constants.PageMaximum);
                    var ruleKitting = await _apiService.GetAllRuleKitting(new SearchRuleKittingRequest { Category = _filter.Cate, Kittingtype = string.Empty });
                    var isHaveRuleProcess = ruleKitting.Any(s => s.KittingType.Contains(Constants.PROCESS));
                    switch (_filter.Type)
                    {
                        case KittingType.OneTime:
                        case KittingType.Prepare:
                            items = GetGroupedKittingOneTimePrepare(responseData.Records, isHaveRuleProcess);
                            totalRecordItem += items != null ? items.Sum(s => s.KittingPlans.Count()) : 0;
                            break;
                        case KittingType.NTime:
                            items = GetGroupedKittingNTime(responseData.Records, isHaveRuleProcess);
                            totalRecordItem += items != null ? items.Sum(s => s.KittingPlans.Count()) : 0;
                            break;
                    }
                    break;
                case KittingTab.KittingDIP:
                    var dropdownUploadno = await _apiService.GetUploadNoKittingPlan(1, _filter.ProDate);
                    ViewBag.UploadNos = new SelectList(dropdownUploadno.Distinct().ToList());
                    var responseDataDIP = await _apiService.GetDataKittingDIP(_filter, pageNumber, 0);
                    var datanewDIP = responseDataDIP.Records!.GroupBy(s => new { s.Plant, s.Category, s.FinishGoods, s.DeliveryDate, s.Line, s.Time, s.Type, s.SlocDIP, s.IsUrgent, s.UploadNo }).Select((x, i) => new KittingPlan
                    {
                        Plant = x.Key.Plant,
                        Category = x.Key.Category,
                        Line = x.Key.Line,
                        Time = x.Key.Time,
                        FinishGoods = x.Key.FinishGoods,
                        Barcode = Function.CreateBarCode(new BarcodeDIP()
                        {
                            Model = x.Key.FinishGoods,
                            Material = x.First().Material,
                            Line = x.Key.Line,
                            Quantity = x.First().Quantity,
                            Position = x.First().PositionFA ?? string.Empty,
                            Sloc = x.First().Sloc,
                            ProductDate = x.Key.DeliveryDate?.ToString("dd/MM/yyyy"),
                            Plant = x.Key.Plant,
                            Time = x.Key.Time,
                            SlocDIP = x.Key.SlocDIP,
                            UploadNo = x.First().UploadNo,
                            Category = x.Key.Category,
                            CategoryJT = x.Key.Category
                        }),
                        Type = x.Key.Type,
                        SlocDIP = x.Key.SlocDIP,
                        ModelQuantity = Convert.ToInt32(x.First().Quantity),
                        GroupID = i,
                        DeliveryDate = x.Key.DeliveryDate,
                        IsUrgent = x.Key.IsUrgent,
                        UploadNo = x.Key.UploadNo,
                        KittingPlans = x.ToList()
                    });
                    items = datanewDIP ?? new List<KittingPlan>();
                    totalRecordItem += items != null ? items.Sum(s => s.KittingPlans.Count()) : 0;
                    break;
                case KittingTab.KittingSubcon:
                    var responseDataSubcon = await _apiService.GetDataKittingSubcon(_filter, pageNumber, 0);
                    var dataneSubcon = responseDataSubcon.Records!.GroupBy(s => new { s.Plant, s.MaterialDescription, s.RequirementsDate, s.PullID }).Select((x, i) => new KittingPlan
                    {
                        Plant = x.Key.Plant,
                        Barcode = Function.CreateBarCode(new BarcodeSubcon()
                        {
                            Model = x.Key.MaterialDescription,
                            DeleveryDate = x.Key.RequirementsDate?.ToString("dd/MM/yyyy"),
                            Plant = x.Key.Plant
                        }),
                        MaterialDescription = x.Key.MaterialDescription,
                        Category = x.First().Category,
                        RequirementsDate = x.Key.RequirementsDate,
                        SpecialPart = x.First().SpecialPart,
                        PullID = x.Key.PullID,
                        GroupID = i,
                        KittingPlans = x.ToList(),
                    });
                    items = dataneSubcon ?? new List<KittingPlan>();
                    totalRecordItem += items != null ? items.Sum(s => s.KittingPlans.Count()) : 0;
                    break;
                case KittingTab.KittingOutside:
                    var responseDataOutside = await _apiService.GetDataKittingOutside(_filter, pageNumber, 0);
                    var dataneaOutside = responseDataOutside.Records!.GroupBy(s => new { s.Plant, s.RequirementsDate, s.UploadNo, s.GroupName }).Select((x, i) => new KittingPlan
                    {
                        Plant = x.Key.Plant,
                        Reason = x.First().Reason,
                        Category = x.First().Category,
                        Line = x.First().Line,
                        SpecialPart = x.First().SpecialPart,
                        Barcode = Function.CreateBarCode(new BarcodeSubcon()
                        {
                            Model = x.First().Reason,
                            DeleveryDate = x.Key.RequirementsDate?.ToString("dd/MM/yyyy"),
                            Plant = x.Key.Plant
                        }),
                        RequirementsDate = x.Key.RequirementsDate,
                        GroupName = x.Key.GroupName,
                        UploadNo = x.Key.UploadNo,
                        GroupID = i,
                        KittingPlans = x.ToList(),
                    });
                    items = dataneaOutside ?? new List<KittingPlan>();
                    totalRecordItem += items != null ? items.Sum(s => s.KittingPlans.Count()) : 0;
                    break;
            }
            var model = new KittingPlanViewModel()
            {
                Items = items,
                Filter = _filter,
                PageNumber = pageNumber,
                PageSize = _pageSize,
                TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                Total = total,

            };
            var tuppleRes = new Tuple<KittingPlanViewModel, int>(model, totalRecordItem);
            if (tab == KittingTab.KittingSubcon)
            {
                return PartialView("~/Views/KittingList/_CreateKittingListViewSubconModal.cshtml", tuppleRes);
            }
            else if (tab == KittingTab.KittingOutside)
            {
                return PartialView("~/Views/KittingList/_CreateKittingListViewOutsideModal.cshtml", tuppleRes);
            }
            else
            {
                return PartialView("~/Views/KittingList/_CreateKittingListViewModal.cshtml", tuppleRes);
            }
        }

        //Tuấn Anh
        [HttpPost]
        public async Task<IActionResult> ConfirmCreateKittingList([FromBody] List<KittingPlan> request, string selectedItems, KittingTab tab, string cate, bool? isJIT, bool? isProcess, bool? isUrgent, bool isList)
        {
            try
            {
                if (string.IsNullOrEmpty(cate))
                {
                    return BadRequest(Constants.ERROREMPTY_PLANT_CATE);
                }
                var listSelected = selectedItems.Split(";").ToList();
                var listData = new List<KittingPlan>();
                listData = listSelected.Count > 0 ? request.Where(s => listSelected.Contains(s.GroupID.ToString())).ToList() : request.ToList();
                var newlist = listData.Select(x => new KittingListRequest()
                {
                    Plant = x.Plant,
                    Category = x.Category,
                    Deliverydate = (tab == KittingTab.KittingDIP || tab == KittingTab.KittingFA) ? x.DeliveryDate : x.RequirementsDate,
                    Descriptions = x.Descriptions,
                    Line = x.Line,
                    Barcode = x.Barcode,
                    BarcodeLine = (tab == KittingTab.KittingFA) ? Function.CreateBarCode(new BarcodeLineFA()
                    {
                        Model = x.Model,
                        Line = x.Line,
                        DeliveryDate = x.DeliveryDate?.ToString("dd/MM/yyyy"),
                    }) : (tab == KittingTab.KittingDIP) ? Function.CreateBarCode(new BarcodeLineDIP()
                    {
                        Model = x.FinishGoods,
                        Time = x.Time,
                        Quantity = Convert.ToInt32(x.Quantity),
                        Line = x.Line,
                        DeliveryDate = x.DeliveryDate?.ToString("dd/MM/yyyy"),
                    }) : string.Empty,
                    Material = x.Material,
                    Model = (tab == KittingTab.KittingDIP) ? x.FinishGoods : (tab == KittingTab.KittingFA) ? x.Model : (tab == KittingTab.KittingSubcon) ? x.MaterialDescription : x.UploadNo,
                    ModelQuantity = Convert.ToInt32(x.ModelQuantity),
                    Quantity = x.Quantity,
                    ReservationNo = x.ReservationNo,
                    MaterialReplace = "",
                    QuantityReplace = 0,
                    Time = x.Time,
                    Unit = x.Unit,
                    SpecialPart = x.SpecialPart,
                    PositionFA = x.PositionFA,
                    KittingType = Convert.ToByte(tab.ToEnumMemberAttrValue()),
                    KittingTimeType = x.Type,
                    Sloc = (tab == KittingTab.KittingDIP) ? x.Sloc : x.Issue_Sloc,
                    UploadNo = x.UploadNo,
                    IsUrgent = isUrgent ?? false,
                    IsProcess = isProcess ?? false,
                    IsJIT = isJIT ?? false,
                    kittingPlans = x.KittingPlans.Select(kp =>
                    {
                        kp.Descriptions = (tab == KittingTab.KittingOutside) ? kp.Reason : (tab == KittingTab.KittingSubcon) ? kp.MaterialDescription : kp.Descriptions;
                        kp.KittingFrom = (tab == KittingTab.KittingOutside) ? kp.GroupName : kp.KittingFrom;
                        kp.ReceiptSloc = kp.ReceiptSloc ?? (tab == KittingTab.KittingDIP ? kp.SlocDIP : kp.Issue_Sloc);
                        kp.Sloc = (tab == KittingTab.KittingFA ? kp.Receipt_Location : tab == KittingTab.KittingDIP ? kp.Sloc : kp.Issue_Sloc); // SLoc MCS
                        kp.Remark = (tab == KittingTab.KittingSubcon) ? kp.STT : kp.Remark;
                        kp.PullID = (tab == KittingTab.KittingDIP) ? kp.UploadNo : kp.PullID;
                        kp.Quantity = (tab == KittingTab.KittingDIP) ? (kp.Quantity * kp.MaterialQuantity) : kp.Quantity;
                        kp.KittingTypeDetail = kp.Type;
                        kp.LocationName = (tab == KittingTab.KittingOutside) && kp.Line.ToUpper().Contains("SUB") ? "SUB" : kp.LocationName;
                        return kp;
                    }).ToList()
                }).ToList();
                var result = await _apiService.CreateKittingList(newlist);

                if (!isList)
                {
                    var pdfOptions = new ConvertOptions
                    {
                        PageMargins = new Margins
                        {
                            Top = 2,    // Lề trên 0mm
                            Right = 1,  // Lề phải 0mm
                            Bottom = 1, // Lề dưới 0mm
                            Left = 4    // Lề trái 0mm
                        },
                        PageOrientation = Orientation.Landscape,
                        PageSize = Size.A4
                    };
                    _generatePdf.SetConvertOptions(pdfOptions);
                }

                // print for tab view
                if (tab == KittingTab.KittingDIP)
                {
                    if (isList == true)
                    {
                        byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_PreviewKittingListDIP.cshtml", result);
                        return File(bytesRC, "application/pdf", string.Format("KittingLineListDIP_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                    }
                    else
                    {
                        byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_KittingListLine.cshtml", result);
                        return File(bytesRC, "application/pdf", string.Format("KittingListDIP_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                    }
                }
                else if (tab == KittingTab.KittingSubcon)
                {
                    return PartialView("~/Views/KittingList/_PreviewKittingListSubcon.cshtml", result);
                }
                else if (tab == KittingTab.KittingOutside)
                {
                    return PartialView("~/Views/KittingList/_PreviewKittingListOutside.cshtml", result);
                }
                else
                {
                    if (isList == true)
                    {
                        byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_PreviewKittingListNew.cshtml", result);
                        return File(bytesRC, "application/pdf", string.Format("KittingListFA_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                    }
                    else
                    {
                        byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_KittingListLine.cshtml", result);
                        return File(bytesRC, "application/pdf", string.Format("KittingLineListFA_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                    }
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        //Tuấn Anh

        [HttpGet]
        public async Task<IActionResult> ConfirmCreateKittingListAuto(string plant, string category, string prodate, bool isList, KittingTab tab)
        {
            try
            {
                var listData = new List<KittingPlan>();
                IEnumerable<KittingPlan> items = new List<KittingPlan>();
                if (string.IsNullOrEmpty(plant) || string.IsNullOrEmpty(category) || string.IsNullOrEmpty(prodate))
                {
                    return BadRequest(Constants.ERROREMPTY_PLANT_CATE);
                }
                var filter = new KittingPlanFilter
                {
                    Plant = plant,
                    Cate = category,
                    ProDate = prodate
                };
                var responseData = await _apiService.GetDataKittingFAAuto(filter, Constants.PagingDefault, Constants.PageMaximum);

               


                var ruleKitting = await _apiService.GetAllRuleKitting(new SearchRuleKittingRequest { Category = category, Kittingtype = string.Empty });

                var isHaveRuleProcess = ruleKitting.Any(s => s.KittingType.Contains(Constants.PROCESS));
                var isHaveRuleJIT = ruleKitting.Any(s => s.KittingType.Contains(Constants.JIT));

                var dataJIT = isHaveRuleJIT ? responseData.Records.Where(s => s.Frequency == Constants.JIT).ToList() : new List<KittingPlan>();
                var dataProcess = isHaveRuleProcess ? responseData.Records.Where(s => !s.Frequency.Contains(Constants.JIT) && !string.IsNullOrEmpty(s.PositionFA)).ToList() : new List<KittingPlan>();
                var dataNormal = responseData.Records.Except(dataJIT).Except(dataProcess).ToList();
                foreach (var item in ruleKitting.ToList())
                {
                    switch (item.KittingType)
                    {
                        //Tuấn Anh sửa không tạo Kitting List cho JIT ở đây mà tạo ở Print Line
                        //case Constants.JIT:
                        //    if (dataJIT.Any())
                        //        listData.AddRange(AddKittingData(dataJIT, isHaveRuleProcess));
                        //    break;
                        case Constants.PROCESS:
                            if (dataProcess.Any())
                                listData.AddRange(AddKittingData(dataProcess, isHaveRuleProcess));
                            break;
                        case Constants.TYPE:
                            if (dataNormal.Any())
                                listData.AddRange(AddKittingData(dataNormal, isHaveRuleProcess));
                            break;
                    }
                }

                var newlist = listData.Select(x => new KittingListRequest()
                {
                    Plant = x.Plant,
                    Category = x.Category,
                    Deliverydate = (tab == KittingTab.KittingDIP || tab == KittingTab.KittingFA) ? x.DeliveryDate : x.RequirementsDate,
                    Descriptions = x.Descriptions,
                    Line = x.Line,
                    Barcode = x.Barcode,
                    BarcodeLine = (tab == KittingTab.KittingFA) ? Function.CreateBarCode(new BarcodeLineFA()
                    {
                        Model = x.Model,
                        Line = x.Line,
                        DeliveryDate = x.DeliveryDate?.ToString("dd/MM/yyyy"),
                    }) : (tab == KittingTab.KittingDIP) ? Function.CreateBarCode(new BarcodeLineDIP()
                    {
                        Model = x.FinishGoods,
                        Time = x.Time,
                        Quantity = Convert.ToInt32(x.Quantity),
                        Line = x.Line,
                        DeliveryDate = x.DeliveryDate?.ToString("dd/MM/yyyy"),
                    }) : string.Empty,
                    Material = x.Material,
                    Model = (tab == KittingTab.KittingDIP) ? x.FinishGoods : (tab == KittingTab.KittingFA) ? x.Model : (tab == KittingTab.KittingSubcon) ? x.MaterialDescription : x.UploadNo,
                    ModelQuantity = Convert.ToInt32(x.ModelQuantity),
                    Quantity = x.Quantity,
                    ReservationNo = x.ReservationNo,
                    MaterialReplace = "",
                    QuantityReplace = 0,
                    Time = x.Time,
                    Unit = x.Unit,
                    SpecialPart = x.SpecialPart,
                    PositionFA = x.PositionFA,
                    KittingType = Convert.ToByte(tab.ToEnumMemberAttrValue()),
                    KittingTimeType = x.Type,
                    Sloc = (tab == KittingTab.KittingDIP) ? x.Sloc : x.Issue_Sloc,
                    IsProcess = !string.IsNullOrEmpty(x.PositionFA),
                    IsJIT = !string.IsNullOrEmpty(x.Frequency) && x.Frequency == Constants.JIT,
                    kittingPlans = x.KittingPlans.Select(kp =>
                    {
                        kp.Descriptions = (tab == KittingTab.KittingOutside) ? kp.Reason : (tab == KittingTab.KittingSubcon) ? kp.MaterialDescription : kp.Descriptions;
                        kp.KittingFrom = (tab == KittingTab.KittingOutside) ? kp.GroupName : kp.KittingFrom;
                        kp.ReceiptSloc = kp.ReceiptSloc ?? (tab == KittingTab.KittingDIP ? kp.SlocDIP : kp.Issue_Sloc);
                        kp.Sloc = (tab == KittingTab.KittingFA ? kp.Receipt_Location : tab == KittingTab.KittingDIP ? kp.Sloc : kp.Issue_Sloc); // SLoc MCS
                        kp.Remark = (tab == KittingTab.KittingSubcon) ? kp.STT : kp.Remark;
                        kp.PullID = (tab == KittingTab.KittingDIP) ? kp.UploadNo : kp.PullID;
                        kp.Quantity = (tab == KittingTab.KittingDIP) ? (kp.Quantity * kp.MaterialQuantity) : kp.Quantity;
                        kp.KittingTypeDetail = kp.Type;
                        return kp;
                    }).ToList()
                }).ToList();


                //var test = newlist.Where(it => it.Model == "KX-TG1611PDH-V4");


                //var test2 = test.Select(x => x.kittingPlans);

                var result = await _apiService.CreateKittingList(newlist);

                if (isList == true)
                {
                    byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_PreviewKittingListNew.cshtml", result);
                    return File(bytesRC, "application/pdf", string.Format("KittingListFA_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                }
                else
                {
                    var pdfOptions = new ConvertOptions
                    {
                        PageMargins = new Margins
                        {
                            Top = 2,    // Lề trên 0mm
                            Right = 1,  // Lề phải 0mm
                            Bottom = 1, // Lề dưới 0mm
                            Left = 4    // Lề trái 0mm
                        },
                        PageOrientation = Orientation.Landscape,
                        PageSize = Size.A4
                    };
                    _generatePdf.SetConvertOptions(pdfOptions);
                    byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_KittingListLine.cshtml",
                        result.OrderBy(s => s.KittingTimeType).ThenBy(s => s.Model).ThenBy(s =>
                        {
                            var timeSpan = TimeSpan.Parse(s.Time);
                            return timeSpan < TimeSpan.Parse("06:00") ? 1 : 0;
                        }).ThenBy(s => TimeSpan.Parse(s.Time) >= TimeSpan.Parse("06:00") ? TimeSpan.Parse(s.Time) : TimeSpan.MaxValue).ThenBy(s => string.IsNullOrEmpty(s.PositionFA) ? "ORDER" : s.PositionFA).ToList());
                    return File(bytesRC, "application/pdf", string.Format("KittingLineListFA_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        private List<KittingPlan> AddKittingData(List<KittingPlan> data, bool isHaveRuleProcess)
        {
            var dataNTime = data.Where(s => s.Type.Contains("N")).ToList();
            var dataOther = data.Where(s => !s.Type.Contains("N")).ToList();

            var oneTimePrepare = GetGroupedKittingOneTimePrepare(dataOther, isHaveRuleProcess);
            var nTime = GetGroupedKittingNTime(dataNTime, isHaveRuleProcess);

            return oneTimePrepare.Concat(nTime).ToList();
        }

        [HttpGet]
        public async Task<IActionResult> DownloadTestKittingList()
        {
            byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_PreviewKittingList_test.cshtml");
            return File(bytesRC, "application/pdf", string.Format("test{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
        }

        [HttpGet]
        public async Task<IActionResult> HistoryDeleteKittingList(KittingTab tab)
        {
            IEnumerable<KittingList> items = new List<KittingList>();
            var tabrequest = Convert.ToByte(tab.ToEnumMemberAttrValue());
            switch (tab)
            {
                case KittingTab.KittingFA:
                    var responseData = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                    items = responseData.ToList();
                    break;
                case KittingTab.KittingDIP:
                    var responseDataDIP = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                    items = responseDataDIP.ToList();
                    break;
                case KittingTab.KittingSubcon:
                    var responseDataSubcon = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                    items = responseDataSubcon.ToList();
                    break;
                case KittingTab.KittingOutside:
                    var responseDataOutside = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                    items = responseDataOutside.ToList();
                    break;
            }
            var tupleData = new Tuple<IEnumerable<KittingList>, KittingTab>(items, tab);
            return PartialView("~/Views/KittingList/_HistoryDeleteKittingListModal.cshtml", tupleData);
        }

        [HttpPost]
        public IActionResult DeleteKittingList(List<string> selectedItems, string tab)
        {
            var model = new DeletePlanObject()
            {
                Id = string.Join(",", selectedItems),
                Tab = tab,
                Action = "ConfirmDeleteKittingList",
                Controller = "KittingList",
            };
            return PartialView("~/Views/KittingPlan/_DeletePlanModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteKittingList(string id)
        {
            try
            {
                var lstID = id.Split(",").Select(int.Parse).ToList();
                await _apiService.DeleteKittingList(lstID);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmRevertKittingList(string id, KittingTab tab)
        {
            try
            {
                IEnumerable<KittingList> items = new List<KittingList>();
                var tabrequest = Convert.ToByte(tab.ToEnumMemberAttrValue());
                await _apiService.RevertKittingList(id);
                switch (tab)
                {
                    case KittingTab.KittingFA:
                        var responseData = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                        items = responseData.ToList();
                        break;
                    case KittingTab.KittingDIP:
                        var responseDataDIP = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                        items = responseDataDIP.ToList();
                        break;
                    case KittingTab.KittingSubcon:
                        var responseDataSubcon = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                        items = responseDataSubcon.ToList();
                        break;
                    case KittingTab.KittingOutside:
                        var responseDataOutside = await _apiService.GetHistoryKittingDelete(tabrequest, Constants.PagingDefault, Constants.PagingAll);
                        items = responseDataOutside.ToList();
                        break;
                }
                var tupleData = new Tuple<IEnumerable<KittingList>, KittingTab>(items, tab);
                return PartialView("~/Views/KittingList/_HistoryDeleteKittingListModal.cshtml", tupleData);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        /// <summary>
        /// Create KittingLine
        /// </summary>
        /// <param name="request"></param>
        /// <param name="selectedItems"></param>
        /// <param name="tab"></param>
        /// <param name="isJIT"></param>
        /// <param name="isProcess"></param>
        /// <param name="isUrgent"></param>
        /// <returns></returns>
        //[HttpGet]
        //public async Task<IActionResult> CreateKittingLine(string plant, string cate, string proDate, string modelname, string line, string time, string fromtime, string finishtime, bool checkboxPrepare, bool checkboxProcess, bool checkboxUrgent, string typekt, KittingTab tab, int pageNumber = 1, string? pageSize = null)
        //{
        //    KittingType type;
        //    var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
        //    var dropdownData = await _apiService.GetCategoryPlanMaster();
        //    ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
        //    ViewBag.Categorys = new SelectList(dropdownData.Where(s => !string.IsNullOrEmpty(plant) ? s.Plant == plant : s.Plant == "").Select(x => x.Category).Distinct().ToList());
        //    ViewBag.SpecialParts = new SelectList(dropdownData.Select(x => x.SpecialPart).Distinct().ToList());
        //    var _filter = new KittingPlanFilter()
        //    {
        //        Plant = plant,
        //        Cate = cate,
        //        ProDate = proDate ?? DateTime.Now.ToString("yyyy-MM-dd"),
        //        Model = modelname,
        //        Line = line,
        //        Time = time,
        //        FromTime = fromtime,
        //        FinishTime = finishtime,
        //        Tab = tab,
        //        Type = Enum.TryParse(typekt, true, out type) ? type : KittingType.OneTime,
        //        Prepare = checkboxPrepare,
        //        Process = checkboxProcess,
        //        IsUrgentDIP = checkboxUrgent
        //    };
        //    int total = 10;
        //    IEnumerable<KittingPlan> items = new List<KittingPlan>();
        //    switch (tab)
        //    {
        //        case KittingTab.KittingFA:
        //            var responseData = await _apiService.GetDataKittingFA(_filter, 1, 9999);
        //            switch (_filter.Type)
        //            {
        //                case KittingType.OneTime:
        //                case KittingType.Prepare:
        //                    var datanew = responseData.Records.GroupBy(s => new
        //                    {
        //                        s.Plant,
        //                        s.Category,
        //                        s.Model,
        //                        s.DeliveryDate,
        //                        s.Line,
        //                        s.Type,
        //                        s.SpecialPart,
        //                    }).Select((x, i) =>
        //                    {
        //                        return new KittingPlan
        //                        {
        //                            Plant = x.Key.Plant,
        //                            Category = x.Key.Category,
        //                            Line = x.Key.Line,
        //                            Time = x.First().Time,
        //                            Model = x.Key.Model,
        //                            ModelQuantity = x.GroupBy(x => x.Material).Select(g => new KittingPlan
        //                            {
        //                                ModelQuantity = g.Sum(e => e.ModelQuantity),
        //                            }).Select(a => a.ModelQuantity).First(),
        //                            Barcode = Function.CreateBarCode(new BarcodeLineFA()
        //                            {
        //                                Model = x.Key.Model,
        //                                Line = x.Key.Line,
        //                                DeliveryDate = x.Key.DeliveryDate?.ToString("dd/MM/yyyy")
        //                            }),
        //                            Type = x.Key.Type,
        //                            DeliveryDate = x.Key.DeliveryDate,
        //                            SpecialPart = x.Key.SpecialPart,
        //                            GroupID = i,
        //                        };
        //                    }).ToList();
        //                    items = datanew.Any() ? datanew : new List<KittingPlan>();
        //                    break;
        //                case KittingType.NTime:
        //                    var dataGrTime = responseData.Records.GroupBy(s => new
        //                    {
        //                        s.Plant,
        //                        s.Category,
        //                        s.Model,
        //                        s.DeliveryDate,
        //                        s.Line,
        //                        s.Time,
        //                        s.Type,
        //                        SpecialPart = (s.SpecialPart == "Carton" || s.SpecialPart == "Trolley") ? s.SpecialPart : "Normal",
        //                    }).Select((x, i) =>
        //                    {
        //                        return new KittingPlan
        //                        {
        //                            Plant = x.Key.Plant,
        //                            Category = x.Key.Category,
        //                            Line = x.Key.Line,
        //                            Time = x.Key.Time,
        //                            Model = x.Key.Model,
        //                            ModelQuantity = x.First().ModelQuantity,
        //                            Quantity = x.First().Quantity,
        //                            Barcode = Function.CreateBarCode(new BarcodeLineFA()
        //                            {
        //                                Model = x.Key.Model,
        //                                Line = x.Key.Line,
        //                                DeliveryDate = x.Key.DeliveryDate?.ToString("dd/MM/yyyy")
        //                            }),
        //                            Type = x.Key.Type,
        //                            DeliveryDate = x.Key.DeliveryDate,
        //                            SpecialPart = x.Key.SpecialPart,
        //                            GroupID = i,
        //                            KittingPlans = x.ToList()

        //                        };
        //                    }).ToList();
        //                    items = dataGrTime.Any() ? Function.GroupRecordsByTypeNTime(responseData.Records, dataGrTime) : new List<KittingPlan>();
        //                    break;
        //            }
        //            break;
        //        case KittingTab.KittingDIP:
        //            var responseDataDIP = await _apiService.GetDataKittingDIP(_filter, pageNumber, 0);
        //            var datanewDIP = responseDataDIP.Records!.GroupBy(s => new { s.Plant, s.Category, s.FinishGoods, s.DeliveryDate, s.Line, s.Time, s.Type, s.SlocDIP, s.IsUrgent }).Select((x, i) => new KittingPlan
        //            {
        //                Plant = x.Key.Plant,
        //                Category = x.Key.Category,
        //                Line = x.Key.Line,
        //                Time = x.Key.Time,
        //                Barcode = Function.CreateBarCode(new BarcodeLineDIP()
        //                {
        //                    Model = x.Key.FinishGoods,
        //                    Time = x.Key.Time,
        //                    Quantity = Convert.ToInt32(x.First().Quantity),
        //                    Line = x.Key.Line,
        //                    DeliveryDate = x.Key.DeliveryDate?.ToString("dd/MM/yyyy"),
        //                }),
        //                GroupID = i,
        //                Model = x.Key.FinishGoods,
        //                Type = x.Key.Type,
        //                IsUrgent = x.Key.IsUrgent,
        //                ModelQuantity = Convert.ToInt32(x.First().Quantity),
        //                DeliveryDate = x.Key.DeliveryDate,
        //            });
        //            items = datanewDIP ?? new List<KittingPlan>();
        //            break;
        //    }
        //    var model = new KittingPlanViewModel()
        //    {
        //        Items = items,
        //        Filter = _filter,
        //        PageNumber = pageNumber,
        //        PageSize = _pageSize,
        //        TotalPage = (int)Math.Ceiling((double)total / _pageSize),
        //        Total = total,

        //    };
        //    return PartialView("~/Views/KittingList/_CreateKittingLineModal.cshtml", model);
        //}

        //[HttpPost]
        //public async Task<IActionResult> ConfirmCreateKittingLine([FromBody] List<KittingPlan> request, string selectedItems, KittingTab tab, bool? isJIT, bool? isProcess, bool? isUrgent)
        //{
        //    try
        //    {
        //        var listSelected = selectedItems.Split(";").ToList();
        //        var listData = listSelected.Count > 0 ? request.Where(s => listSelected.Contains(s.GroupID.ToString())).ToList() : request.ToList();
        //        var newlist = listData.Select(x => new KittingListFARequest()
        //        {
        //            Plant = x.Plant,
        //            Category = x.Category,
        //            Deliverydate = x.DeliveryDate,
        //            Descriptions = x.Descriptions,
        //            Line = x.Line,
        //            Material = x.Material,
        //            Barcode = x.Barcode,
        //            Model = x.Model,
        //            ModelQuantity = Convert.ToInt32(x.ModelQuantity),
        //            Quantity = x.Quantity,
        //            ReservationNo = x.ReservationNo,
        //            Time = x.Time,
        //            Unit = x.Unit,
        //            IsUrgent = isUrgent ?? false,
        //            IsProcess = isProcess ?? false,
        //            IsJIT = isJIT ?? false,
        //            KittingType = Convert.ToByte(tab.ToEnumMemberAttrValue()),
        //            KittingTimeType = x.Type,

        //        }).ToList();
        //        await _apiService.CreateKittingLine(newlist);
        //        return PartialView("~/Views/KittingList/_PreviewKittingLine.cshtml", listData);
        //    }
        //    catch (Exception e)
        //    {
        //        return BadRequest(e.Message);
        //    }
        //}

        [HttpPost]
        public async Task<SelectList> OnChangePlant(string plant)
        {
            var dropdownData = await _apiService.GetCategoryPlanMaster();
            var lstData = new SelectList(dropdownData.Where(s => s.Plant == plant).Select(x => x.Category).Distinct().ToList());
            ViewBag.Categorys = lstData;
            return lstData;
        }

        [HttpGet]
        public async Task<IActionResult> ViewKittingListDetail(long kittingId, KittingTab tab)
        {
            var result = await _apiService.GetKittingListDetailByKTLId(kittingId);

            var tupple = new Tuple<List<KittingListDetail>, KittingTab, long>(result, tab, kittingId);

            return PartialView("~/Views/KittingList/_KittingListDetails.cshtml", tupple);
        }

        [HttpGet]
        public async Task<IActionResult> ReprintKittingList(long kittingId, bool isList, KittingTab tab)
        {
            var result = await _apiService.ReprintKittingList(kittingId);
            if (!isList)
            {
                var pdfOptions = new ConvertOptions
                {
                    PageMargins = new Margins
                    {
                        Top = 2,    // Lề trên 0mm
                        Right = 1,  // Lề phải 0mm
                        Bottom = 1, // Lề dưới 0mm
                        Left = 4    // Lề trái 0mm
                    },
                    PageOrientation = Orientation.Landscape,
                    PageSize = Size.A4
                };
                _generatePdf.SetConvertOptions(pdfOptions);
            }

            // print for tab view
            if (tab == KittingTab.KittingDIP)
            {
                if (isList == true)
                {
                    byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_PreviewKittingListDIP.cshtml", result);
                    return File(bytesRC, "application/pdf", string.Format("KittingLineListDIP_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                }
                else
                {
                    byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_KittingListLine.cshtml", result);
                    return File(bytesRC, "application/pdf", string.Format("KittingListDIP_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                }
            }
            else if (tab == KittingTab.KittingSubcon)
            {
                return PartialView("~/Views/KittingList/_PreviewKittingListSubcon.cshtml", result);
            }
            else if (tab == KittingTab.KittingOutside)
            {
                return PartialView("~/Views/KittingList/_PreviewKittingListOutside.cshtml", result);
            }
            else
            {
                if (isList == true)
                {
                    byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_PreviewKittingListNew.cshtml", result);
                    return File(bytesRC, "application/pdf", string.Format("KittingListFA_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                }
                else
                {
                    byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/KittingList/_KittingListLine.cshtml", result);
                    return File(bytesRC, "application/pdf", string.Format("KittingLineListFA_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
                }
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewKittingListTransfer(KittingTab Tab, string userselect, string dateselect, string model, string locationname, string category, bool? checkboxAutoTransfer)
        {
            var users = await _apiService.SearchUsers(new Models.Filters.UserFilter(), 1, 0);
            var UserLists = users.Records?.Select(x => new SelectListItem() { Value = x.ID, Text = x.FullName }).ToList();
            var _filterdefault = new SearchKittingListDetails
            {
                KittingType = Convert.ToByte(Tab.ToEnumMemberAttrValue()),
                DeliveryDate = dateselect ?? DateTime.Now.ToString("yyyy-MM-dd"),
            };

            var _filter = new SearchKittingListDetails
            {
                KittingType = Convert.ToByte(Tab.ToEnumMemberAttrValue()),
                DeliveryDate = dateselect ?? DateTime.Now.ToString("yyyy-MM-dd"),
                UserId = userselect,
                Model = model,
                Category = category,
                LocationName = locationname,
                AutoTransfer = checkboxAutoTransfer ?? false
            };

            var result = await _apiService.SearchKittingListDetailByUserKitting(_filter, Constants.PagingDefault, Constants.PageMaximum);
            var dataGroup = result.Records.AsEnumerable().Where(x => x.KittingStatus != KittingDetailStatus.Supplied).GroupBy(s => new { s.Material, s.PicUser, s.Unit, s.KittingStatus, s.Model, s.Category }).Select((x, i) => new KittingListTransfer
            {
                Material = x.Key.Material,
                Quantity = x.Sum(r => r.Quantity ?? 0),
                ID = x.Select(r => r.ID ?? 0).ToList(),
                LstID = string.Join(",", x.Select(r => r.ID).ToList()),
                PicUser = x.Key.PicUser,
                LocationName = x.First().LocationName,
                Category = x.Key.Category,
                Unit = x.Key.Unit,
                Model = x.Key.Model,
                GroupID = i,
                KittingStatus = ((byte)x.Key.KittingStatus)
            });
            var request = new TransferKittingVM
            {
                filter = _filter,
                NewPicUser = UserLists,
                kittingListDetails = dataGroup
            };
            var newRequest = new Tuple<TransferKittingVM, KittingTab>(request, Tab);
            return PartialView("~/Views/KittingList/_TransferKittingViewModal.cshtml", newRequest);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmTransferKittingList(string newPicUser, string selectedItems)
        {
            try
            {
                if (string.IsNullOrEmpty(newPicUser))
                {
                    return BadRequest(_loc.Get("Msg_PleaseSelectANewKittingOperator"));
                }
                await _apiService.TransferKittingListMaterial(newPicUser, selectedItems);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewPrintPartCard(long kittingId, KittingTab tab)
        {
            var result = await _apiService.GetKittingListDetailByKTLId(kittingId);

            var tupple = new Tuple<List<KittingListDetail>, KittingTab, long>(result, tab, kittingId);

            return PartialView("~/Views/KittingList/_KittingListPartCard.cshtml", tupple);
        }


        [HttpPost]
        public async Task<IActionResult> ConfirmPrintPartCard(long kittingId, KittingTab tab)
        {
            var result = await _apiService.ReprintKittingList(kittingId);
            var request = result.FirstOrDefault().kittingPlans;

            var ktting = request.Select(r => new CreateKittingCardOtherRequest
            {
                KittingListDetailId = r.ID ?? 0,
                Material = r.Material ?? "",
                Quantity = r.Quantity ?? 0
            }).ToList();


            if (tab == KittingTab.KittingSubcon)
            {
                //var print = await _apiService.CreateKittingCardSubcon(ktting);
                return PartialView("~/Views/KittingList/_PreviewKittingCardSubcon.cshtml", result);
            }
            else
            {
                var print = await _apiService.CreateKittingCardOutside(ktting);
                return PartialView("~/Views/KittingList/_PreviewKittingCardOutside.cshtml", print);
            }
        }

        [HttpGet]
        public async Task<IActionResult> EditKittingListDetails(string id)
        {
            var detail = await _apiService.GetKittingListDetailByID(long.Parse(id));
            var model = new ReplaceKittingListDetail()
            {
                MaterialId = detail.ID ?? 0,
                Material = detail.Material,
                Quantity = detail.Quantity ?? 0,
                MaterialReplace = detail.MaterialReplace,
                QuantityReplace = detail.QuantityReplace ?? 0
            };
            return PartialView("~/Views/KittingList/_UpdateMaterialReplaceModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmEditKittingListDetails(ReplaceKittingListDetail request)
        {
            try
            {
                var newrequest = new ReplaceKittingListDetailRequest()
                {
                    Id = request.MaterialId,
                    Material = request.Material,
                    MaterialReplace = request.MaterialReplace,
                    Quantity = request.Quantity,
                    QuantityReplace = request.QuantityReplace,
                };
                await _apiService.ReplaceKittingListDetail(newrequest);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> CreateKittingCard(KittingTab tab)
        {

            if (tab == KittingTab.KittingSubcon)
            {
                return PartialView("~/Views/KittingList/_PreviewKittingCardSubcon.cshtml");
            }
            else
            {
                return PartialView("~/Views/KittingList/_PreviewKittingCardOutside.cshtml");
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmCreateKittingCard([FromBody] List<KittingPlan> request, string selectedItems, KittingTab tab)
        {
            try
            {
                var listSelected = selectedItems.Split(";").ToList();
                var listData = listSelected.Count > 0 ? request.Where(s => listSelected.Contains(s.GroupID.ToString())).ToList() : request.ToList();
                var newlist = listData.Select(x => new KittingListFARequest()
                {
                    Plant = x.Plant,
                    Category = x.Category,
                    Deliverydate = x.DeliveryDate,
                    Descriptions = x.Descriptions,
                    Line = x.Line,
                    Material = x.Material,
                    Barcode = x.Barcode,
                    Model = x.Model,
                    ModelQuantity = Convert.ToInt32(x.ModelQuantity),
                    Quantity = x.Quantity,
                    ReservationNo = x.ReservationNo,
                    Time = x.Time,
                    Unit = x.Unit,
                    KittingType = Convert.ToByte(tab.ToEnumMemberAttrValue()),
                    KittingTimeType = x.Type,

                }).ToList();
                await _apiService.CreateKittingLine(newlist);
                return PartialView("~/Views/KittingList/_PreviewKittingLine.cshtml", listData);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmQtyKittingCardSubcon(long id, double QuantityNew)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }
            try
            {
                await _apiService.UpdateQtyRC(id, QuantityNew);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        public List<KittingPlan> GetGroupedKittingOneTimePrepare(List<KittingPlan> records, bool isHaveRuleProcess)
        {
            if (!records.Any())
            {
                return new List<KittingPlan>();
            }
            var result = records.GroupBy(s => new
            {
                s.Plant,
                s.Category,
                s.Model,
                s.DeliveryDate,
                s.Line,
                s.Type,
                SpecialPart = (s.SpecialPart == "Carton" || s.SpecialPart == "Trolley") ? s.SpecialPart : "Normal",
                PositionFA = isHaveRuleProcess ? !string.IsNullOrEmpty(s.PositionFA) ? s.PositionFA : null : null
            }).Select((x, i) =>
            {
                return new KittingPlan
                {
                    Plant = x.Key.Plant,
                    Category = x.Key.Category,
                    Line = x.Key.Line,
                    Time = x.First().Time,
                    Model = x.Key.Model,
                    ModelQuantity = x.GroupBy(x => x.Material).Select(g => new KittingPlan
                    {
                        ModelQuantity = g.Sum(e => e.ModelQuantity),
                    }).Select(a => a.ModelQuantity).First(),
                    Barcode = Function.CreateBarCode(new BarcodeFA()
                    {
                        Model = x.Key.Model,
                        Line = x.Key.Line,
                        RequirementDate = x.Key.DeliveryDate?.ToString("dd/MM/yyyy"),
                        Time = x.First().Time,
                        TypeReport = x.First().Type,
                        Plant = x.Key.Plant,
                        Category = x.Key.Category,
                        CategoryJT = x.Key.Category
                    }),
                    Type = x.Key.Type,
                    DeliveryDate = x.Key.DeliveryDate,
                    SpecialPart = x.Key.SpecialPart,
                    GroupID = i,
                    PositionFA = x.Key.PositionFA,
                    KittingPlans = x.ToList().GroupBy(x => x.Material).Select(g => new KittingPlan
                    {
                        Plant = g.First().Plant,
                        Category = g.First().Category,
                        Line = g.First().Line,
                        Time = g.First().Time,
                        Model = g.First().Model,
                        KittingTimeType = g.First().KittingTimeType,
                        ReservationNo = g.First().ReservationNo,
                        ReservationItem = g.First().ReservationItem,
                        Recipient = g.First().Recipient,
                        Quantity = g.Sum(r => r.Quantity),
                        Barcode = Function.CreateBarCode(new BarcodeFA()
                        {
                            Model = g.First().Model,
                            Line = g.First().Line,
                            RequirementDate = g.First().DeliveryDate?.ToString("dd/MM/yyyy"),
                            Time = g.First().Time,
                            Plant = g.First().Plant,
                            Category = g.First().Category,
                            CategoryJT = g.First().Category
                        }),
                        Type = g.First().Type,
                        DeliveryDate = g.First().DeliveryDate,
                        Descriptions = g.First().Descriptions,
                        CreatedBy = g.First().CreatedBy,
                        Unit = g.First().Unit,
                        Issue_Sloc = g.First().Issue_Sloc,
                        Sloc = g.First().Issue_Sloc,
                        Receipt_Location = g.First().Receipt_Location,
                        INS = g.First().INS,
                        RoHS = g.First().RoHS,
                        Material = g.Key,
                        SpecialPart = g.First().SpecialPart,
                        PositionFA = g.First().PositionFA,
                        Frequency = g.First().Frequency,
                        KittingFrom = g.First().KittingFrom,
                        Remark = g.First().Remark,
                        GroupName = g.First().GroupName,
                        CostCenter = g.First().CostCenter,
                        VenderName = g.First().VenderName,
                    }).ToList()
                };
            }).ToList();
            return result;
        }

        public List<KittingPlan> GetGroupedKittingNTime(List<KittingPlan> records, bool isHaveRuleProcess)
        {
            if (!records.Any())
            {
                return new List<KittingPlan>();
            }

            //Tuấn Anh


            //var ta = records.Where(x => x.Model == "KX-TG1611PDH-V4");

            //

            var dataGrTime = records.GroupBy(s => new
            {
                s.Plant,
                s.Category,
                s.Model,
                s.DeliveryDate,
                s.Line,
                s.Time,
                s.Type,
                SpecialPart = (s.SpecialPart == "Carton" || s.SpecialPart == "Trolley") ? s.SpecialPart : "Normal",
                PositionFA = isHaveRuleProcess ? !string.IsNullOrEmpty(s.PositionFA) ? s.PositionFA : null : null
            }).Select((x, i) =>
            {
                return new KittingPlan
                {
                    Plant = x.Key.Plant,
                    Category = x.Key.Category,
                    Line = x.Key.Line,
                    Time = x.Key.Time,
                    Model = x.Key.Model,
                    ModelQuantity = x.First().ModelQuantity,
                    Quantity = x.First().Quantity,
                    Barcode = Function.CreateBarCode(new BarcodeFA()
                    {
                        Model = x.Key.Model,
                        Line = x.Key.Line,
                        RequirementDate = x.Key.DeliveryDate?.ToString("dd/MM/yyyy"),
                        Time = x.Key.Time,
                        TypeReport = x.First().Type,
                        Plant = x.Key.Plant,
                        Category = x.Key.Category,
                        CategoryJT = x.Key.Category
                    }),
                    Type = x.Key.Type,
                    PositionFA = x.Key.PositionFA,
                    DeliveryDate = x.Key.DeliveryDate,
                    SpecialPart = x.Key.SpecialPart,
                    GroupID = i,
                    KittingPlans = x.ToList()
                    

                };
            }).ToList();
            //Tuấn Anh sửa
            var result = Function.GroupRecordsByTypeNTime(records, dataGrTime, isHaveRuleProcess);
            //var result = Function.GroupRecordsByTypeNTime(records, dataGrTime);

            return result;
        }
    }
}
