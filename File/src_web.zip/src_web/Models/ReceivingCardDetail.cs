﻿namespace SWMS_WebTool.Models
{
    public class ReceivingCardDetail
    {
        public Int64 ReceivingCardDetailID { get; set; }
        public Int64 ReceivingCardID { get; set; }
        public string? Material { get; set; }
        public string? Barcode { get; set; }
        public string? DateCode { get; set; }
        public string? UnitNo { get; set; }
        public double TotalQuantity { get; set; }
        public double CurrentQuantity { get; set; }
        public string? LotNo { get; set; }
        public bool IsPOPending { get; set; }
        public Int64? DAInvoiceItemDetailID { get; set; }
        public byte Status { get; set; }
        public DateTime CreatedDate { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedDate { get; set; }
        public string? UpdatedBy { get; set; }
        public DateTime? DateStored { get; set; }
        public string? UserStored { get; set; }
    }
}
