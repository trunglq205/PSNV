// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'receiving_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(receivingRemoteDataSource)
final receivingRemoteDataSourceProvider = ReceivingRemoteDataSourceProvider._();

final class ReceivingRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ReceivingRemoteDataSource,
          ReceivingRemoteDataSource,
          ReceivingRemoteDataSource
        >
    with $Provider<ReceivingRemoteDataSource> {
  ReceivingRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'receivingRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$receivingRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ReceivingRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ReceivingRemoteDataSource create(Ref ref) {
    return receivingRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReceivingRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReceivingRemoteDataSource>(value),
    );
  }
}

String _$receivingRemoteDataSourceHash() =>
    r'1a35c496f47bd9bbad7fbf3d77c2af6d29c00768';

@ProviderFor(receivingRepository)
final receivingRepositoryProvider = ReceivingRepositoryProvider._();

final class ReceivingRepositoryProvider
    extends
        $FunctionalProvider<
          ReceivingRepository,
          ReceivingRepository,
          ReceivingRepository
        >
    with $Provider<ReceivingRepository> {
  ReceivingRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'receivingRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$receivingRepositoryHash();

  @$internal
  @override
  $ProviderElement<ReceivingRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ReceivingRepository create(Ref ref) {
    return receivingRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReceivingRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReceivingRepository>(value),
    );
  }
}

String _$receivingRepositoryHash() =>
    r'aeb8aee5a008daf018c24c4f08f93384d80fde90';

@ProviderFor(receivingHistoryLocalDataSource)
final receivingHistoryLocalDataSourceProvider =
    ReceivingHistoryLocalDataSourceProvider._();

final class ReceivingHistoryLocalDataSourceProvider
    extends
        $FunctionalProvider<
          ReceivingHistoryLocalDataSource,
          ReceivingHistoryLocalDataSource,
          ReceivingHistoryLocalDataSource
        >
    with $Provider<ReceivingHistoryLocalDataSource> {
  ReceivingHistoryLocalDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'receivingHistoryLocalDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$receivingHistoryLocalDataSourceHash();

  @$internal
  @override
  $ProviderElement<ReceivingHistoryLocalDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ReceivingHistoryLocalDataSource create(Ref ref) {
    return receivingHistoryLocalDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReceivingHistoryLocalDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReceivingHistoryLocalDataSource>(
        value,
      ),
    );
  }
}

String _$receivingHistoryLocalDataSourceHash() =>
    r'b12169e05e287191db2748cf4be6221aaeb05318';

@ProviderFor(receivingHistoryRepository)
final receivingHistoryRepositoryProvider =
    ReceivingHistoryRepositoryProvider._();

final class ReceivingHistoryRepositoryProvider
    extends
        $FunctionalProvider<
          ReceivingHistoryRepository,
          ReceivingHistoryRepository,
          ReceivingHistoryRepository
        >
    with $Provider<ReceivingHistoryRepository> {
  ReceivingHistoryRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'receivingHistoryRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$receivingHistoryRepositoryHash();

  @$internal
  @override
  $ProviderElement<ReceivingHistoryRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ReceivingHistoryRepository create(Ref ref) {
    return receivingHistoryRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReceivingHistoryRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReceivingHistoryRepository>(value),
    );
  }
}

String _$receivingHistoryRepositoryHash() =>
    r'9b24e5a4f2196c44968d240bed3626abff85e37f';
