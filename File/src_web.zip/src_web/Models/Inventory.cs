﻿namespace SWMS_WebTool.Models
{
    public class Inventory
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Material { get; set; }
        public int GoodReceiptQuantity { get; set; }
        public int StoredQuantity { get; set; }
        public int MovedOutQuantity { get; set; }
    }

    public class InventoryGoodReceipt
    {
        public long ReceivingCardID { get; set; }
        public double? TotalQuantity { get; set; }
        public double? CurrentQuantity { get; set; }
        public string Plant { get; set; }
        public string Material { get; set; }
        public string MaterialType { get; set; }
        public string MaterialFrequency { get; set; }
        public string Sloc { get; set; }
        public string Category { get; set; }
        public string DANo { get; set; }
        public string VendorCode { get; set; }
        public string QC_Check { get; set; }
        public string PositionTem { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string StatusStorage { get; set; }
        public int Total { get; set; }
    }

    public class InventoryStoredQuantity
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Material { get; set; }
        public string Sloc { get; set; }
        public string MaterialFrequency { get; set; }
        public double TotalQuantity { get; set; }
        public string MaterialType { get; set; }
        public string PositionStored { get; set; }
        public DateTime? CreatedDate { get; set; }
    }

    public class InventotyMovedOut
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Material { get; set; }
        public string Sloc { get; set; }
        public string MaterialFrequency { get; set; }
        public double Quantity { get; set; }
        public string MaterialType { get; set; }
        public DateTime? KittingDate { get; set; }
    }
}
