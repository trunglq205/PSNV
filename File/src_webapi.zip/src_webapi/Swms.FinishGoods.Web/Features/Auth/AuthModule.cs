﻿using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.Auth.Business;
using Swms.FinishGoods.Web.Features.Auth.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.Auth;

public static class AuthModule
{
    public static IServiceCollection AddAuthFeature(this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<IAuthApi>(api, withAuth: false);   // login chưa có token
        services.AddScoped<IAuthBusiness, AuthBusiness>();
        return services;
    }
}