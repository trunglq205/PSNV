namespace Swms.FinishGoods.API.Features.MapView.DataAccess;

public interface IMapViewRepository
{
    Task<MapViewLayout?> GetLayoutAsync(string areaCode);
}
