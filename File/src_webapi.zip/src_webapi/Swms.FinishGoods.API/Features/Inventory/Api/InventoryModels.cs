using Microsoft.AspNetCore.Mvc.ModelBinding;
using Swms.FinishGoods.API.Features.Inventory.Business.Entities;
using Swms.FinishGoods.API.Features.Pallets.Api;

namespace Swms.FinishGoods.API.Features.Inventory.Api
{
    // ── Query ─────────────────────────────────────────────────

    /// <summary>
    /// Tham số tồn kho = PalletQuery (lot/category/model/inspection/lot type/detail level/
    /// urgent/SAP/ngày SX) + phần đặc thù. Khớp InventoryQuery phía Web.
    /// </summary>
    public class InventoryQuery : PalletQuery
    {
        /// <summary>staging | storing | vanning | jupiter | borrowed. Null = tất cả.</summary>
        public string? Area { get; set; }

        /// <summary>Tìm theo Box No hoặc Serial No (LIKE).</summary>
        public string? BoxOrSerial { get; set; }

        public int? QtyMin { get; set; }
        public int? QtyMax { get; set; }

        /// <summary>created_desc (mặc định) | pd_asc | pd_desc | qty_desc.</summary>
        public string? Sort { get; set; }

        // ── Chọn nhiều — phân tách bằng dấu phẩy ──
        // Gộp với bản 1 giá trị kế thừa từ PalletQuery (CategoryCode / InspectionStatus / SapStatus)
        // để link / client cũ vẫn chạy.

        /// <summary>Nhiều category: "310,410".</summary>
        public string? Categories { get; set; }

        /// <summary>Nhiều trạng thái OQC: "pass,ng".</summary>
        public string? Inspections { get; set; }

        /// <summary>Nhiều trạng thái SAP: "0,3". Có 0 (chưa đẩy) thì tính cả pallet sap_status NULL.</summary>
        public string? SapStatuses { get; set; }

        // Đã parse + gộp trong InventoryService.Normalize — repository chỉ đọc 3 list này.
        [BindNever] public List<int> CategoryList { get; set; } = [];
        [BindNever] public List<string> InspectionList { get; set; } = [];
        [BindNever] public List<int> SapStatusList { get; set; } = [];
    }

    // ── Response ──────────────────────────────────────────────

    /// <summary>
    /// 1 dòng tồn kho. Giữ nguyên toàn bộ trường của PalletResponse (client kế thừa PalletDto)
    /// + thông tin vị trí hiện tại. Danh sách không nạp Boxes (tránh N+1).
    /// </summary>
    public record InventoryItemResponse(
    long Id,
    string LotNo,
    int CategoryCode,
    string CategoryName,
    string LotType,
    string? StockyCode,
    long? LocatorId,
    string? LocatorCode,
    string? AreaCode,
    string DetailLevel,
    int? BoxCount,
    int? TotalQty,
    string? Model,
    string InspectionStatus,
    bool IsUrgent,
    int? SapStatus,
    DateTime? SapPushedAt,
    DateTime? ProductionDate,
    DateTime CreatedAt,
    string? CreatedBy,
    List<BoxResponse> Boxes,
    // ── đặc thù tồn kho ──
    string AreaKey,
    string? LocatorName,
    string? LocatorType,
    string? BorrowedFrom,
    bool IsHeavy,
    bool HasSerial,
    string? SiNo)
    {
        public static InventoryItemResponse From(InventoryItem x) => new(
            x.Id, x.LotNo, x.CategoryCode, x.CategoryName, x.LotType, x.StockyCode,
            x.LocatorId, x.LocatorCode, x.AreaCode, x.DetailLevel, x.BoxCount, x.TotalQty,
            x.Model, x.InspectionStatus, x.IsUrgent, x.SapStatus, x.SapPushedAt,
            x.ProductionDate, x.CreatedAt, x.CreatedBy,
            x.Boxes.Select(BoxResponse.From).ToList(),
            x.AreaKey, x.LocatorName, x.LocatorType, x.BorrowedFrom, x.IsHeavy, x.HasSerial,
            x.SiNo);
    }

    public record InventoryAreaStatResponse(
        string AreaKey, int PalletCount, int BoxCount, int TotalQty, int ModelCount)
    {
        public static InventoryAreaStatResponse From(InventoryAreaStat s)
            => new(s.AreaKey, s.PalletCount, s.BoxCount, s.TotalQty, s.ModelCount);
    }

    public record InventoryAgingBucketResponse(
        string Key, int FromDays, int? ToDays, int PalletCount, int TotalQty)
    {
        public static InventoryAgingBucketResponse From(InventoryAgingBucket b)
            => new(b.Key, b.FromDays, b.ToDays, b.PalletCount, b.TotalQty);
    }

    /// <summary>Kết quả đẩy SAP. Failed &gt; 0 → Message liệt kê lot lỗi (tối đa 10).</summary>
    public record InventorySyncResponse(int Pushed, int Failed, string? Message);

    // ── Error codes ───────────────────────────────────────────
    public static class InventoryErrors
    {
        public const string AreaInvalid = "Inventory.AreaInvalid";           // 422
        public const string SortInvalid = "Inventory.SortInvalid";           // 422
        public const string QtyRangeInvalid = "Inventory.QtyRangeInvalid";   // 422
        public const string NothingToSync = "Inventory.NothingToSync";       // 422
        public const string SapNotConfigured = "Inventory.SapNotConfigured"; // 422
    }
}
