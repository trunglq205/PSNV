# ShippingSCS – Auto Shipment

Hệ thống riêng, tách khỏi SWMS FG. ASP.NET Core MVC + Dapper + SQL Server.

## Cấu trúc

```
database/                 Script SQL, chạy theo thứ tự số
src/ShippingScs.Web/      1 project MVC duy nhất
  Controllers/            Mỏng: nhận request, gọi Service, trả View
  Services/               Toàn bộ logic nghiệp vụ + truy vấn Dapper
  Models/                 Class dữ liệu và form
  Data/Db.cs              Tạo kết nối SQL
  Views/
tests/ShippingScs.Tests/  Unit test cho logic (rule, lịch), không cần DB
```

Chủ ý giữ đơn giản: không Repository/UnitOfWork, không chia nhiều project.
Logic tính toán (rule ETD, Long FC, optimize) viết thành class thuần nhận dữ liệu
đã nạp, như `WorkingCalendarSnapshot`, để test được mà không cần DB.

## Chạy lần đầu

1. Tạo DB `ShippingScs`, chạy `database/001_M1_system.sql`.
2. Sửa `ConnectionStrings:Default` trong `appsettings.json`.
3. Đặt mật khẩu admin đầu tiên (không ghi vào file trong repo):
   ```
   cd src/ShippingScs.Web
   dotnet user-secrets init
   dotnet user-secrets set "SeedAdmin:Password" "<mật khẩu>"
   ```
   Hoặc biến môi trường `SeedAdmin__Password`. App chỉ tạo admin khi bảng `Users` trống.
4. `dotnet run`, đăng nhập `admin`.
5. Vào **Lịch làm việc**, bấm **Sinh năm** cho từng lịch và từng năm, rồi đánh dấu ngày lễ.

Test: `dotnet test` ở thư mục gốc.

## Phiên bản .NET

Đặt `net8.0` để mở được bằng Visual Studio 2022 (17.8 trở lên). Code viết theo cú pháp
C# 10 nên khi lên Visual Studio 2026 (v18) chỉ cần đổi `TargetFramework` sang `net10.0`
ở 2 file `.csproj`. Lưu ý .NET 8 đã hết hỗ trợ từ 10/11/2026; .NET 10 LTS hỗ trợ đến 11/2028.

## M1 – đã có

| Phần | Ghi chú |
|---|---|
| Đăng nhập | Cookie, mật khẩu băm bằng `PasswordHasher` có sẵn trong ASP.NET Core |
| Phân quyền | 3 role cố định trên `Users.Role`: Admin, PIC, Viewer. Dùng `[Authorize(Roles = ...)]` |
| Người dùng | Danh sách, thêm, sửa, khoá, đổi mật khẩu. Chặn mất admin cuối cùng |
| Mã PIC | `Users.PicCode` nối với cột PIC trong Master vessel. "X DUNG" = "X.DUNG" |
| Lịch làm việc | Nhiều lịch (PSNV, JUPITER), sinh năm, đánh dấu lễ/làm bù trên lưới tháng |
| Nhật ký | `ChangeLogService.WriteAsync(...)` ghi mọi thay đổi, có màn xem và lọc |

Giới hạn đã biết: khoá user thì cookie đang mở vẫn dùng được đến khi hết hạn (10 giờ).
