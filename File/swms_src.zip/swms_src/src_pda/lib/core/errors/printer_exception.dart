part of 'exceptions.dart';

/// Phân loại lỗi in ấn. Mỗi loại mang sẵn khóa i18n [code] và chuỗi tiếng
/// Việt mặc định [defaultMessage] (dùng khi log / chưa có bản dịch).
enum PrinterErrorType {
  /// Chưa được cấp quyền Bluetooth/Location.
  permission(
    'error.printer_permission',
    'Chưa cấp quyền Bluetooth cho ứng dụng',
  ),

  /// Bluetooth đang tắt.
  bluetoothOff('error.printer_bluetooth_off', 'Vui lòng bật Bluetooth'),

  /// Chưa chọn máy in.
  noPrinter('error.printer_no_printer', 'Chưa chọn máy in'),

  /// Không mở được kết nối tới máy in.
  connect(
    'error.printer_connect',
    'Không kết nối được máy in. Kiểm tra máy đã bật và trong tầm chưa.',
  ),

  /// Lỗi trong lúc gửi dữ liệu / không nhận được ACK.
  print(
    'error.printer_print',
    'Máy in không phản hồi. Kiểm tra giấy và nắp đầu in.',
  ),

  /// Dữ liệu gửi đi không hợp lệ (rỗng, chứa ký tự ngoài 1 byte...).
  invalidData('error.printer_invalid_data', 'Dữ liệu phiếu không hợp lệ');

  const PrinterErrorType(this.code, this.defaultMessage);

  /// Khóa i18n, khớp key trong file dịch.
  final String code;

  final String defaultMessage;
}

/// Lỗi in ấn (Bluetooth, driver SATO/TSPL, dữ liệu tem).
///
/// Không `sealed` như các nhóm khác: phân loại nằm ở [type] chứ không ở
/// subclass, để driver throw gọn `PrinterException(PrinterErrorType.connect)`.
class PrinterException extends AppException {
  /// `type.code` / `type.defaultMessage` không phải biểu thức const nên
  /// không truyền thẳng lên super được — override getter bên dưới.
  const PrinterException(this.type, {String? message, this.cause})
      : _detail = message,
        super(message ?? '', code: 'error.printer');

  final PrinterErrorType type;

  /// Exception gốc (plugin Bluetooth, TimeoutException của dart:async...).
  final Object? cause;

  /// Chi tiết kỹ thuật do driver truyền vào — chỉ để log.
  final String? _detail;

  /// Khóa i18n — UI hiển thị theo cái này.
  @override
  String get code => type.code;

  /// Chuỗi tiếng Việt để log; ưu tiên chi tiết driver truyền vào.
  @override
  String get message => _detail ?? type.defaultMessage;

  @override
  String toString() => 'PrinterException(${type.name}: $message)';
}

/// Lỗi giữa một lô nhãn — mang theo SỐ NHÃN ĐÃ RA GIẤY.
///
/// Caller BẮT BUỘC dùng [printed] để ghi lịch sử, nếu không thì sổ sách
/// lệch với số phiếu thật trong tay công nhân.
class PrinterBatchException extends PrinterException {
  const PrinterBatchException({
    required this.printed,
    required this.total,
    required PrinterErrorType type,
    super.message,
    super.cause,
  }) : super(type);

  /// Số nhãn đã được máy in ACK (SATO) hoặc đã đẩy xong xuống socket và
  /// chờ đủ thời gian tiêu buffer (TSPL — máy không có ACK).
  final int printed;

  /// Tổng số nhãn trong lô.
  final int total;

  /// Đã ra ít nhất 1 tờ thì phải báo rõ số tờ, nếu không công nhân sẽ in
  /// lại toàn bộ và ra thừa phiếu. Chưa ra tờ nào thì báo theo [type].
  @override
  String get code => printed > 0 ? 'error.printer_batch_partial' : type.code;

  @override
  Map<String, String> get namedArgs => {
    'printed': '$printed',
    'total': '$total',
  };

  @override
  String toString() =>
      'PrinterBatchException($printed/$total đã in, ${type.name}: $message)';
}