import 'package:smart_warehouse/shared/common/error_entity.dart';

enum KittingType {
  fa(0),
  dip(1),
  subcon(2),
  outside(3),
  // Thêm kho NG
  ng(4),
  pmd(5);


  const KittingType(this.code);

  final int code;

  static KittingType fromCode(int code) {
    return switch (code) {
      0 => fa,
      1 => dip,
      2 => subcon,
      3 => outside,
    4 => ng,
    5=>KittingType.pmd,
      _ => throw ErrorEntity(message: 'Kitting Type in valid')
    };
  }

  String get text => switch (this) {
        fa => 'FA',
        dip => 'DIP',
        subcon => 'SUBCON',
        outside => 'OUTSIDE',
        ng => 'NG',
  pmd=>'PMD'
      };
}
