using System.ComponentModel.DataAnnotations;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Shared.Models;

namespace Swms.FinishGoods.API.Features.PartCards.Api;

// Request / response DTOs cho feature Part Card.
// Khớp shape với IPartCardApi (Refit) bên Web để (de)serialize đúng.

// ── QUERY ────────────────────────────────────────────────────
// Lịch sử in: filter theo PO + khoảng ngày in, kèm phân trang.
// ── QUERY ────────────────────────────────────────────────────
// Lịch sử in: tìm kiếm tự do + filter theo phân loại / oversea / khoảng ngày, kèm phân trang.
public class PartCardQuery : PagedQuery
{
    // Giữ nguyên filter cũ (so khớp tuyệt đối).
    public string? Payload { get; set; }

    // ── Field riêng: khớp tiền tố (LIKE 'abc%') → seek được index ──
    public string? PoNo { get; set; }
    public string? CustomerPoNo { get; set; }
    // Model: tìm ở header (phiếu thường) hoặc dòng hàng (phiếu oversea).
    public string? Model { get; set; }
    public string? G21Part { get; set; }
    public string? Packer { get; set; }
    public string? Checker { get; set; }

    public int? Category { get; set; }
    // Loại hàng theo master.categories.product: "SP" | "F/G". Null = tất cả.
    public string? Product { get; set; }
    public bool? IsOverseaService { get; set; }
    // Trạng thái khoá: true = chỉ phiếu đang khoá, false = chỉ phiếu chưa khoá. Null = tất cả.
    public bool? IsLocked { get; set; }

    // Khoảng ngày in / ngày sản xuất — inclusive cả 2 đầu.
    public DateTime? PrintedFrom { get; set; }
    public DateTime? PrintedTo { get; set; }
    public DateTime? ProductionFrom { get; set; }
    public DateTime? ProductionTo { get; set; }
}

// ── REQUEST (input) ──────────────────────────────────────────
// 1 dòng hàng (inner box) trong payload lưu lịch sử in.
// G21Part / InnerBox / OqcChecked / dims chỉ có ý nghĩa khi IsOverseaService = true.
public record SavePartCardRowRequest(
    string? G21Part,
    [Required] string Model,
    string? InnerBox,
    int Qty,
    string? Origin,
    bool OqcChecked,
    decimal? InnerLength,
    decimal? InnerWidth,
    decimal? InnerHeight,
    decimal? InnerWeight);

// Payload lưu lịch sử in cho 1 phiếu (gửi khi bấm "Hoàn thành").
public record SavePrintRequest(
    string? PoNo,
    string? CustomerPoNo,
    [Required] DateTime ProductionDate,
    string? Packer,
    string? Checker,
    decimal? Length,
    decimal? Width,
    decimal? Height,
    decimal? Weight,
    string? Payload,
    string? Model,
    int? Qty,
    string? Origin,
    int? Category,
    bool IsOverseaService,
    List<SavePartCardRowRequest> Rows);

// Payload cập nhật kích thước / trọng lượng cấp phiếu cho 1 phiếu đã in.
public record UpdateDimensionsRequest(
    decimal? Length,
    decimal? Width,
    decimal? Height,
    decimal? Weight);

// Tách 1 phiếu 1 mã, 1 thùng thành nhiều phiếu.
//   SourcePayload — payload QR phiếu nguồn (khớp tuyệt đối wms.part_cards.payload).
//   Items         — các phiếu mới, mỗi phiếu 1 Card_ID mới trong payload. Ít nhất 2.
public record SplitPartCardRequest(
    [Required] string SourcePayload,
    [Required] List<SavePrintRequest> Items);

// Gộp nhiều phiếu thành 1 phiếu nhiều mã.
//   SourcePayloads — payload QR các phiếu nguồn. Ít nhất 2, không trùng.
//   Item           — phiếu gộp, 1 Card_ID mới.
public record MergePartCardsRequest(
    [Required] List<string> SourcePayloads,
    [Required] SavePrintRequest Item);

// Payload xoá nhiều phiếu đã in.
public record DeletePartCardsRequest([Required] List<long> Ids);

// Payload khoá / mở khoá nhiều phiếu.
public record LockPartCardsRequest([Required] List<long> Ids);

// ── RESPONSE (output) ────────────────────────────────────────
// Kết quả xoá nhiều: số phiếu đã xoá + các id không tìm thấy (hoặc đã xoá trước đó)
// + các id KHÔNG xoá được vì đang khoá.
public record DeletePartCardsResponse(int Deleted, List<long> NotFoundIds, List<long> LockedIds);

// Kết quả khoá / mở khoá nhiều (dùng chung cho cả 2 chiều):
//   Affected     — số phiếu thực sự đổi trạng thái.
//   UnchangedIds — đã ở sẵn trạng thái đích (khoá phiếu đã khoá / mở phiếu chưa khoá).
//   NotFoundIds  — không tồn tại hoặc đã xoá.
public record LockPartCardsResponse(int Affected, List<long> UnchangedIds, List<long> NotFoundIds);

// Quyền theo ROLE của người đang gọi trên màn Part Card (chưa xét trạng thái từng phiếu).
// Chỉ dùng nội bộ service, không serialize ra ngoài.
public readonly record struct PartCardAccess(bool Delete, bool Lock, bool Unlock);

// Quyền của người đang gọi trên ĐÚNG bản ghi này = quyền theo role AND trạng thái bản ghi.
// FE chỉ cần đọc 3 cờ này để bật/tắt nút, không phải tự suy luận lại.
public record PartCardPermissions(bool CanDelete, bool CanLock, bool CanUnlock)
{
    public static PartCardPermissions For(PartCard c, PartCardAccess access)
        => new(CanDelete: access.Delete && !c.IsLocked,
               CanLock: access.Lock && !c.IsLocked,
               CanUnlock: access.Unlock && c.IsLocked);
}

// ── TRUY VẾT (lineage) ───────────────────────────────────────
// 1 mối liên hệ với phiếu khác.
//   Action     — "edit" | "split" | "merge".
//   PartCardId — id phiếu BÊN KIA (Sources: phiếu nguồn; Derived: phiếu sinh ra).
//                Với "edit" = chính phiếu đang xem (sửa tại chỗ).
//   CardId     — Card_ID đọc từ Payload (số in trên tem).
//   Payload    — Sources: payload CŨ lúc thao tác (snapshot);
//                Derived: payload HIỆN TẠI của phiếu sinh ra.
//   IsDeleted  — phiếu bên kia hiện đã xoá mềm chưa (phiếu nguồn tách / gộp luôn = true).
public record PartCardLineageItem(
    string Action, long PartCardId, string CardId, string Payload,
    bool IsDeleted, DateTime CreatedAt, string? CreatedBy);

// Truy vết 1 phiếu, cả 2 chiều. Sắp theo thời gian thao tác tăng dần.
//   Sources — phiếu này sinh ra / được sửa từ đâu (gồm lịch sử sửa của chính nó).
//   Derived — phiếu này đã bị tách / gộp thành những phiếu nào.
public record PartCardLineageResponse(
    long PartCardId, List<PartCardLineageItem> Sources, List<PartCardLineageItem> Derived);

public record PartCardRowResponse(
    string G21Part, string Model, string InnerBox, int Qty, string Origin, bool OqcChecked,
    decimal? InnerLength, decimal? InnerWidth, decimal? InnerHeight, decimal? InnerWeight)
{
    public static PartCardRowResponse From(PartCardRow r)
        => new(r.G21Part ?? string.Empty, r.Model, r.InnerBox ?? string.Empty,
               r.Qty, r.Origin ?? string.Empty, r.OqcChecked,
               r.InnerLength, r.InnerWidth, r.InnerHeight, r.InnerWeight);
}

public record PartCardResponse(
    long Id, string PoNo, string CustomerPoNo, DateTime ProductionDate,
    string Packer, string Checker, int? Category,
    string? Model, int? Qty, string? Origin,
    decimal? Length, decimal? Width, decimal? Height, decimal? Weight,
    bool IsOverseaService, List<PartCardRowResponse> Rows,
    DateTime PrintedAt, string? PrintedBy, string Payload,
    bool IsLocked, DateTime? LockedAt, string? LockedBy,
    PartCardPermissions Permissions,
    // null = phiếu chưa qua sửa / tách / gộp. Chi tiết: GET {id}/lineage.
    PartCardChangeSummary? Changes = null)
{
    public static PartCardResponse From(PartCard c, PartCardAccess access)
        => new(c.Id, c.PoNo ?? string.Empty, c.CustomerPoNo ?? string.Empty,
               c.ProductionDate, c.Packer ?? string.Empty, c.Checker ?? string.Empty, c.Category,
               c.Model, c.Qty, c.Origin,
               c.Length, c.Width, c.Height, c.Weight,
               c.IsOverseaService,
               c.Rows.Select(PartCardRowResponse.From).ToList(),
               c.PrintedAt, c.PrintedBy, c.Payload ?? "",
               c.IsLocked, c.LockedAt, c.LockedBy,
               PartCardPermissions.For(c, access),
               c.Changes);
}