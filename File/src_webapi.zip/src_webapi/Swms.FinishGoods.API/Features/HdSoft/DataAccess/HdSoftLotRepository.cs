using Dapper;
using Swms.FinishGoods.API.Features.HdSoft.Business;

namespace Swms.FinishGoods.API.Features.HdSoft.DataAccess
{
    public class HdSoftLotRepository : IHdSoftLotRepository
    {
        // Lot luôn đi qua tham số @Lot -> không injection.
        private const string LotHistorySql = """
            SELECT  t.MovementDate,
                    t.Created      AS MovementTime,
                    t.MovementType,
                    t.MovementQty,
                    p.Value        AS Model,
                    l.Value        AS Locator,
                    io.DocumentNo  AS InOutDocumentNo,
                    mv.DocumentNo  AS MovementDocumentNo
            FROM adempiere.M_Transaction t
            JOIN adempiere.M_AttributeSetInstance asi ON asi.M_AttributeSetInstance_ID = t.M_AttributeSetInstance_ID
            JOIN adempiere.M_Product  p  ON p.M_Product_ID  = t.M_Product_ID
            JOIN adempiere.M_Locator  l  ON l.M_Locator_ID  = t.M_Locator_ID
            LEFT JOIN adempiere.M_InOutLine    iol ON iol.M_InOutLine_ID    = t.M_InOutLine_ID
            LEFT JOIN adempiere.M_InOut        io  ON io.M_InOut_ID         = iol.M_InOut_ID
            LEFT JOIN adempiere.M_MovementLine ml  ON ml.M_MovementLine_ID  = t.M_MovementLine_ID
            LEFT JOIN adempiere.M_Movement     mv  ON mv.M_Movement_ID      = ml.M_Movement_ID
            WHERE asi.Lot = @Lot
            ORDER BY t.Created DESC, t.M_Transaction_ID DESC
            """;

        // Tham số @Warehouse null thì lấy tất cả kho.
        private const string PalletStockSql = """
            SELECT  asi.Lot              AS PalletNo,
                    p.Value              AS Model,
                    l.Value              AS Locator,
                    w.Value              AS Warehouse,
                    so.QtyOnHand         AS QtyOnHand,
                    so.DateMaterialPolicy AS DateIn
            FROM adempiere.M_StorageOnhand so
            JOIN adempiere.M_AttributeSetInstance asi ON asi.M_AttributeSetInstance_ID = so.M_AttributeSetInstance_ID
            JOIN adempiere.M_Product   p ON p.M_Product_ID   = so.M_Product_ID
            JOIN adempiere.M_Locator   l ON l.M_Locator_ID   = so.M_Locator_ID
            JOIN adempiere.M_Warehouse w ON w.M_Warehouse_ID = l.M_Warehouse_ID
            WHERE so.QtyOnHand > 0
              AND asi.Lot IS NOT NULL
              AND LENGTH(asi.Lot) = 12
              AND (@Warehouse IS NULL OR w.Value = @Warehouse)
            ORDER BY w.Value, l.Value, asi.Lot
            """;

        // Giao dịch MỚI NHẤT của nhiều lot trong 1 câu: m_transaction chưa có index
        // trên m_attributesetinstance_id (DB HD soft read-only, không thêm được) nên
        // mỗi lần tra là 1 lần seq scan ~240ms — gom lại để chỉ quét 1 lần cho cả nhóm.
        private const string LastMovementsSql = """
            SELECT DISTINCT ON (asi.Lot)
                   asi.Lot         AS PalletNo,
                   t.MovementType  AS MovementType,
                   l.Value         AS Locator,
                   t.Created       AS MovementTime,
                   t.CreatedBy     AS UpdateBy
            FROM adempiere.M_Transaction t
            JOIN adempiere.M_AttributeSetInstance asi ON asi.M_AttributeSetInstance_ID = t.M_AttributeSetInstance_ID
            JOIN adempiere.M_Locator l ON l.M_Locator_ID = t.M_Locator_ID
            WHERE asi.Lot = ANY(@Lots)
            ORDER BY asi.Lot, t.Created DESC, t.M_Transaction_ID DESC
            """;

        // Giao dịch mới nhất của MỌI lot có giao dịch sau @Since.
        // DISTINCT ON trên tập "sau @Since" vẫn cho đúng giao dịch mới nhất tổng thể,
        // vì giao dịch mới nhất của 1 lot luôn nằm trong tập đó.
        // Vẫn là 1 lần quét M_Transaction, nhưng chỉ 1 lần cho cả lượt và kết quả
        // chỉ gồm vài chục lot vừa thay đổi -> phía SWMS gần như không phải làm gì.
        private const string LastMovementsSinceSql = """
            SELECT DISTINCT ON (asi.Lot)
                   asi.Lot         AS PalletNo,
                   t.MovementType  AS MovementType,
                   l.Value         AS Locator,
                   t.Created       AS MovementTime,
                   t.CreatedBy     AS UpdateBy
            FROM adempiere.M_Transaction t
            JOIN adempiere.M_AttributeSetInstance asi ON asi.M_AttributeSetInstance_ID = t.M_AttributeSetInstance_ID
            JOIN adempiere.M_Locator l ON l.M_Locator_ID = t.M_Locator_ID
            WHERE t.Created > @Since
              AND asi.Lot IS NOT NULL
              AND LENGTH(asi.Lot) = 12
            ORDER BY asi.Lot, t.Created DESC, t.M_Transaction_ID DESC
            """;

        // Vị trí ĐANG TỒN của nhiều lot trong 1 câu — đọc M_StorageOnhand thay cho lịch sử
        // M_Transaction: nhanh hơn (không seq scan bảng giao dịch) và đúng với "hàng đang ở đâu"
        // kể cả khi giao dịch cuối là kiểm kê (I+/I-) hay loại khác không mang vị trí đích.
        private const string CurrentLocationsSql = """
            SELECT  asi.Lot       AS PalletNo,
                    p.Value       AS Model,
                    l.Value       AS Locator,
                    w.Value       AS Warehouse,
                    so.QtyOnHand  AS QtyOnHand
            FROM adempiere.M_StorageOnhand so
            JOIN adempiere.M_AttributeSetInstance asi ON asi.M_AttributeSetInstance_ID = so.M_AttributeSetInstance_ID
            JOIN adempiere.M_Product   p ON p.M_Product_ID   = so.M_Product_ID
            JOIN adempiere.M_Locator   l ON l.M_Locator_ID   = so.M_Locator_ID
            JOIN adempiere.M_Warehouse w ON w.M_Warehouse_ID = l.M_Warehouse_ID
            WHERE so.QtyOnHand > 0
              AND asi.Lot = ANY(@Lots)
            ORDER BY asi.Lot, so.QtyOnHand DESC
            """;

        private readonly IHdSoftDbConnectionFactory _factory;

        public HdSoftLotRepository(IHdSoftDbConnectionFactory factory)
            => _factory = factory;

        public async Task<IReadOnlyList<HdSoftLotMovementRow>> GetLotHistoryAsync(string lot)
        {
            using var conn = _factory.Create();

            var rows = await conn.QueryAsync<HdSoftLotMovementRow>(
                LotHistorySql,
                new { Lot = lot },
                commandTimeout: 60);

            return rows.ToList();
        }

        public async Task<IReadOnlyList<HdSoftPalletStockRow>> GetPalletsInStockAsync(string? warehouse)
        {
            using var conn = _factory.Create();
            var rows = await conn.QueryAsync<HdSoftPalletStockRow>(
                PalletStockSql,
                new { Warehouse = warehouse },
                commandTimeout: 60);
            return rows.ToList();
        }

        public async Task<IReadOnlyDictionary<string, HdSoftLastMovementRow>> GetLastMovementsAsync(
            IReadOnlyList<string> lots)
        {
            if (lots.Count == 0)
                return new Dictionary<string, HdSoftLastMovementRow>(StringComparer.OrdinalIgnoreCase);

            using var conn = _factory.Create();
            var rows = await conn.QueryAsync<HdSoftLastMovementRow>(
                LastMovementsSql, new { Lots = lots.ToArray() }, commandTimeout: 120);

            var map = new Dictionary<string, HdSoftLastMovementRow>(StringComparer.OrdinalIgnoreCase);
            foreach (var r in rows) map.TryAdd(r.PalletNo, r);
            return map;
        }


        /// <summary>Vị trí đang tồn của từng lot (SL lớn trước). Lot không còn tồn thì không có key.</summary>
        public async Task<IReadOnlyDictionary<string, IReadOnlyList<HdSoftLotLocationRow>>> GetCurrentLocationsAsync(
            IReadOnlyList<string> lots)
        {
            if (lots.Count == 0)
                return new Dictionary<string, IReadOnlyList<HdSoftLotLocationRow>>(StringComparer.OrdinalIgnoreCase);

            using var conn = _factory.Create();
            var rows = await conn.QueryAsync<HdSoftLotLocationRow>(
                CurrentLocationsSql, new { Lots = lots.ToArray() }, commandTimeout: 60);

            return rows
                .GroupBy(r => r.PalletNo, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => (IReadOnlyList<HdSoftLotLocationRow>)g.ToList(),
                              StringComparer.OrdinalIgnoreCase);
        }

        public async Task<IReadOnlyDictionary<string, HdSoftLastMovementRow>> GetLastMovementsSinceAsync(
            DateTime since)
        {
            using var conn = _factory.Create();

            // Unspecified: M_Transaction.Created là timestamp không múi giờ. Truyền
            // DateTime Kind=Utc/Local thì Npgsql có thể quy đổi và lệch vài giờ.
            var rows = await conn.QueryAsync<HdSoftLastMovementRow>(
                LastMovementsSinceSql,
                new { Since = DateTime.SpecifyKind(since, DateTimeKind.Unspecified) },
                commandTimeout: 120);

            var map = new Dictionary<string, HdSoftLastMovementRow>(StringComparer.OrdinalIgnoreCase);
            foreach (var r in rows) map.TryAdd(r.PalletNo, r);
            return map;
        }
    }
}
