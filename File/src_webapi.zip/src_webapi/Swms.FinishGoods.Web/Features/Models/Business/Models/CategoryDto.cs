using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.Web.Features.Models.Business.Models;

/// <summary>
/// Dữ liệu category đầy đủ trả về từ GET /api/categories.
/// Khớp shape với CategoryResponse phía API core (master.categories).
/// Code là business key (int, vd 110 = "DECT", 210 = "DP").
/// </summary>
public class CategoryDto
{
    public int Code { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public string? Bd { get; set; }
    public string? PlantCode { get; set; }
    public string? Product { get; set; }
    public string? SlockPmd { get; set; }
    public string? SlockFa { get; set; }
    public string? SlockScs { get; set; }
    public string? SlockJpt { get; set; }
    public string? SlockPort { get; set; }
    public string? ProductionVersion { get; set; }
    public DateTime CreatedAt { get; set; }

    /// <summary>
    /// Bản sao dùng cho form sửa — không chỉnh trực tiếp bản gốc trong _categoryOptions
    /// (người dùng bấm Huỷ thì danh sách phải giữ nguyên).
    /// Tất cả property đều là kiểu giá trị / string nên shallow copy là đủ.
    /// </summary>
    public CategoryDto Clone() => (CategoryDto)MemberwiseClone();

    /// <summary>"110 - DECT" cho dropdown / toast.</summary>
    public string DisplayText => string.IsNullOrWhiteSpace(Name) ? Code.ToString() : $"{Code} - {Name}";
}

/// <summary>
/// Tham số lọc cho GET /api/categories (không phân trang).
/// Khớp CategoryQuery phía API core.
/// </summary>
public class CategoryQuery
{
    public string? Code { get; set; }
    public string? Name { get; set; }
    public string? PlantCode { get; set; }
    public string? Product { get; set; }
}

/// <summary>
/// Payload tạo mới category — khớp CreateCategoryRequest phía API core.
/// Code là business key do người dùng nhập.
/// </summary>
public class CreateCategoryRequest
{
    [Range(1, int.MaxValue, ErrorMessage = "Mã danh mục bắt buộc")]
    public int Code { get; set; }

    [MaxLength(200)] public string? Name { get; set; }
    [MaxLength(500)] public string? Description { get; set; }
    [MaxLength(50)] public string? Bd { get; set; }
    [MaxLength(10)] public string? PlantCode { get; set; }
    [MaxLength(50)] public string? Product { get; set; }
    [MaxLength(50)] public string? SlockPmd { get; set; }
    [MaxLength(50)] public string? SlockFa { get; set; }
    [MaxLength(50)] public string? SlockScs { get; set; }
    [MaxLength(50)] public string? SlockJpt { get; set; }
    [MaxLength(50)] public string? SlockPort { get; set; }
    [MaxLength(50)] public string? ProductionVersion { get; set; }

    public static CreateCategoryRequest From(CategoryDto c) => new()
    {
        Code = c.Code,
        Name = Trim(c.Name),
        Description = Trim(c.Description),
        Bd = Trim(c.Bd),
        PlantCode = Trim(c.PlantCode),
        Product = Trim(c.Product),
        SlockPmd = Trim(c.SlockPmd),
        SlockFa = Trim(c.SlockFa),
        SlockScs = Trim(c.SlockScs),
        SlockJpt = Trim(c.SlockJpt),
        SlockPort = Trim(c.SlockPort),
        ProductionVersion = Trim(c.ProductionVersion),
    };

    // Ô rỗng gửi null thay vì "" để DB không lưu chuỗi rỗng lẫn lộn với NULL.
    internal static string? Trim(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}

/// <summary>
/// Payload cập nhật category — khớp UpdateCategoryRequest phía API core.
/// KHÔNG có Code: code là khoá, lấy từ route (giống Model không cho đổi Code).
/// </summary>
public class UpdateCategoryRequest
{
    [MaxLength(200)] public string? Name { get; set; }
    [MaxLength(500)] public string? Description { get; set; }
    [MaxLength(50)] public string? Bd { get; set; }
    [MaxLength(10)] public string? PlantCode { get; set; }
    [MaxLength(50)] public string? Product { get; set; }
    [MaxLength(50)] public string? SlockPmd { get; set; }
    [MaxLength(50)] public string? SlockFa { get; set; }
    [MaxLength(50)] public string? SlockScs { get; set; }
    [MaxLength(50)] public string? SlockJpt { get; set; }
    [MaxLength(50)] public string? SlockPort { get; set; }
    [MaxLength(50)] public string? ProductionVersion { get; set; }

    public static UpdateCategoryRequest From(CategoryDto c) => new()
    {
        Name = CreateCategoryRequest.Trim(c.Name),
        Description = CreateCategoryRequest.Trim(c.Description),
        Bd = CreateCategoryRequest.Trim(c.Bd),
        PlantCode = CreateCategoryRequest.Trim(c.PlantCode),
        Product = CreateCategoryRequest.Trim(c.Product),
        SlockPmd = CreateCategoryRequest.Trim(c.SlockPmd),
        SlockFa = CreateCategoryRequest.Trim(c.SlockFa),
        SlockScs = CreateCategoryRequest.Trim(c.SlockScs),
        SlockJpt = CreateCategoryRequest.Trim(c.SlockJpt),
        SlockPort = CreateCategoryRequest.Trim(c.SlockPort),
        ProductionVersion = CreateCategoryRequest.Trim(c.ProductionVersion),
    };
}
