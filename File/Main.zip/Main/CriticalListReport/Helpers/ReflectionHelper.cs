﻿using ClosedXML.Excel;
using System.Reflection;

namespace CriticalListReport.Helpers
{
    public static class ReflectionHelper
    {
        public static T GetPropValue<T>(object obj, string propName)
        {
            var prop = obj.GetType().GetProperty(propName,
                BindingFlags.Instance | BindingFlags.Public | BindingFlags.IgnoreCase);

            if (prop == null) return default!;
            var val = prop.GetValue(obj);
            if (val == null) return default!;

            return (T)Convert.ChangeType(val, typeof(T));
        }

        public static string GetRankContent(string rank)
        {
            return rank switch
            {
                "A1" => "100 % Give up",
                "A2" => "80% Give up",
                "A3" => "Shortage > 6 weeks, gap > 4 weeks",
                "A4" => "Shortage > 6 weeks, gap < 4 weeks",
                "Production short LT" => "Production short leadtime",
                "B" => "OK",
                _ => "" // hoặc "Unknown"
            };
        }

        public static void SetDateCell(IXLWorksheet ws, int row, int col, object value)
        {
            var cell = ws.Cell(row, col);

            if (value != null && DateTime.TryParse(value.ToString(), out var dt))
            {
                cell.Value = dt;
                cell.Style.DateFormat.Format = "dd-MMM-yy";
            }
            else
            {
                cell.Value = value?.ToString();
            }
        }

        public static void SetNumberCell(IXLWorksheet ws, int r, int c, string? value)
        {
            if (decimal.TryParse(value, out var num))
            {
                ws.Cell(r, c).Value = num;

                // Case 1: số nguyên
                if (num == Math.Truncate(num))
                {
                    ws.Cell(r, c).Style.NumberFormat.Format = "#,##0";
                }
                else
                {
                    // Case 2: số thập phân
                    ws.Cell(r, c).Style.NumberFormat.Format = "#,##0.##########";
                }
            }
            else
            {
                ws.Cell(r, c).Value = value;
            }
        }

        public static void SetNumberCellNoComma(IXLWorksheet ws, int r, int c, string? value)
        {
            if (decimal.TryParse(value, out var num))
            {
                ws.Cell(r, c).Value = num;
                ws.Cell(r, c).Style.NumberFormat.Format = "0";  // Số nguyên, không dấu phẩy
            }
            else
            {
                ws.Cell(r, c).Value = value;
            }
        }
    }
}
