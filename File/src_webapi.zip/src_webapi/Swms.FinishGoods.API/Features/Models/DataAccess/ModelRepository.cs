using Dapper;
using Swms.FinishGoods.Api.Features.Models.Api;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.Api.Features.Models.DataAccess;

public class ModelRepository : IModelRepository
{
    private readonly IDbConnectionFactory _factory;
    public ModelRepository(IDbConnectionFactory factory) => _factory = factory;

    // Cột dùng chung — alias snake_case → PascalCase, JOIN category + warehouse area.
    private const string SelectColumns = """
        m.id                AS Id,
        m.gtin              AS GTIN,
        m.code              AS Code,
        m.origin            AS Origin,
        m.category_id       AS CategoryId,
        c.code              AS CategoryCode,
        c.name              AS CategoryName,
        m.length            AS Length,
        m.width             AS Width,
        m.height            AS Height,
        m.standard_packing  AS StandardPacking,
        m.layer_limit       AS LayerLimit,
        m.layer_count       AS LayerCount,
        m.stacking_length   AS StackingLength,
        m.stacking_width    AS StackingWidth,
        m.suggest_area      AS SuggestAreaId,
        wa.area_code        AS SuggestAreaCode,
        wa.area_name        AS SuggestAreaName,
        m.suggest_rack_row  AS SuggestRackRow,
        m.is_active         AS IsActive,
        m.created_at        AS CreatedAt,
        m.created_by        AS CreatedBy,
        m.updated_at        AS UpdatedAt,
        m.updated_by        AS UpdatedBy
        """;

    // LEFT JOIN vì suggest_area nullable — INNER sẽ làm mất các model chưa cấu hình gợi ý.
    private const string FromJoin = """
        FROM master.models m
        JOIN master.categories c ON c.code = m.category_id
        LEFT JOIN master.warehouse_areas wa ON wa.id = m.suggest_area AND wa.is_deleted = 0
        """;

    public async Task<ModelEntity?> GetByIdAsync(int id)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {SelectColumns}
            {FromJoin}
            WHERE m.id = @id AND m.is_deleted = 0;
            """;
        return await conn.QueryFirstOrDefaultAsync<ModelEntity>(sql, new { id });
    }

    // ModelRepository.cs
    public async Task<ModelEntity?> GetByCodeAsync(string code)
    {
        const string sql = $"""
        SELECT {SelectColumns}
        {FromJoin}
        WHERE m.code = @Code AND m.is_deleted = 0;
        """;

        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<ModelEntity>(sql, new { Code = code });
    }

    public async Task<ModelEntity?> GetByGTINAsync(string gtin)
    {
        const string sql = $"""
        SELECT {SelectColumns}
        {FromJoin}
        WHERE m.gtin = @gtin AND m.is_deleted = 0;
        """;

        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<ModelEntity>(sql, new { GTIN = gtin });
    }

    // Doc day du theo danh sach ma — import upsert can gia tri hien co de validate sau khi gop.
    // Chia lo vi Dapper bung "IN @codes" thanh tung tham so, ma SQL Server chi nhan toi da
    // 2100 tham so / lenh (file import co the toi ~10.000 dong).
    public async Task<IReadOnlyList<ModelEntity>> GetByCodesAsync(IReadOnlyList<string> codes)
    {
        const int batchSize = 2000;
        var result = new List<ModelEntity>(codes.Count);
        if (codes.Count == 0) return result;

        var sql = $"""
            SELECT {SelectColumns}
            {FromJoin}
            WHERE m.is_deleted = 0 AND m.code IN @codes;
            """;

        using var conn = _factory.Create();
        for (var i = 0; i < codes.Count; i += batchSize)
        {
            var batch = codes.Skip(i).Take(batchSize).ToList();
            result.AddRange(await conn.QueryAsync<ModelEntity>(sql, new { codes = batch }));
        }
        return result;
    }

    public async Task<PagedResult<ModelEntity>> GetPagedAsync(ModelQuery query)
    {
        using var conn = _factory.Create();

        // filter tái dùng cho cả SELECT lẫn COUNT để không lệch.
        const string filter = """
            WHERE m.is_deleted = 0
              AND (@GTIN          IS NULL OR m.gtin LIKE '%' + @GTIN + '%')
              AND (@Code          IS NULL OR m.code LIKE '%' + @Code + '%')
              AND (@CategoryCode  IS NULL OR m.category_id  = @CategoryCode)
              AND (@SuggestAreaId IS NULL OR m.suggest_area = @SuggestAreaId)
              AND (@Origin        IS NULL OR m.origin       = @Origin)
              AND (@IsActive      IS NULL OR m.is_active    = @IsActive)
              AND (@CreatedFrom   IS NULL OR m.created_at  >= @CreatedFrom)
              AND (@CreatedTo     IS NULL OR m.created_at  <= @CreatedTo)
            """;
        var sql = $"""
            SELECT {SelectColumns}
            {FromJoin}
            {filter}
            ORDER BY m.code
            OFFSET (@Page - 1) * @Size ROWS FETCH NEXT @Size ROWS ONLY;

            SELECT COUNT(*)
            {FromJoin}
            {filter};
         """;

        var p = new
        {
            query.GTIN,
            query.Code,
            query.CategoryCode,
            query.SuggestAreaId,
            query.Origin,
            query.IsActive,
            query.CreatedFrom,
            query.CreatedTo,
            query.Page,
            query.Size,
        };

        using var multi = await conn.QueryMultipleAsync(sql, p);
        var items = (await multi.ReadAsync<ModelEntity>()).ToList();
        var total = await multi.ReadFirstAsync<int>();

        return new PagedResult<ModelEntity>(items, total, query.Page, query.Size);
    }

    public async Task<int> AddAsync(ModelEntity e)
    {
        using var conn = _factory.Create();
        var sql = """
            INSERT INTO master.models
                (code, gtin, origin, category_id, length, width, height, standard_packing,
                 layer_limit, layer_count, stacking_length, stacking_width,
                 suggest_area, suggest_rack_row,
                 is_active, is_deleted, created_at, created_by)
            VALUES
                (@Code, @GTIN, @Origin, @CategoryId, @Length, @Width, @Height, @StandardPacking,
                 @LayerLimit, @LayerCount, @StackingLength, @StackingWidth,
                 @SuggestAreaId, @SuggestRackRow,
                 @IsActive, 0, SYSUTCDATETIME(), @CreatedBy);
            SELECT CAST(SCOPE_IDENTITY() AS int);
            """;
        return await conn.ExecuteScalarAsync<int>(sql, e);
    }

    public async Task AddManyAsync(IReadOnlyList<ModelEntity> entities)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            const string sql = """
                INSERT INTO master.models
                    (code, gtin, origin, category_id, length, width, height, standard_packing,
                 layer_limit, layer_count, stacking_length, stacking_width,
                     suggest_area, suggest_rack_row,
                     is_active, is_deleted, created_at, created_by)
                VALUES
                    (@Code, @GTIN, @Origin, @CategoryId, @Length, @Width, @Height, @StandardPacking,
                 @LayerLimit, @LayerCount, @StackingLength, @StackingWidth,
                     @SuggestAreaId, @SuggestRackRow,
                     @IsActive, 0, SYSUTCDATETIME(), @CreatedBy);
                """;
            foreach (var e in entities)
                await conn.ExecuteAsync(sql, e, tx);

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    // Import upsert: insert mã mới + vá mã đã có, trong CÙNG 1 transaction (all-or-nothing).
    // Vá = CHỈ ghi các cột mà patch có giá trị: COALESCE(@Param, cot) -> tham số NULL thì cột giữ nguyên.
    // Nhờ vậy cột không có trong file không bị ghi đè, kể cả khi người khác vừa sửa cột đó.
    // KHÔNG đụng cột code (khoá đối chiếu). Match theo id đã resolve ở Service.
    public async Task UpsertManyAsync(IReadOnlyList<ModelEntity> toInsert, IReadOnlyList<ModelImportPatch> toUpdate)
    {
        if (toInsert.Count == 0 && toUpdate.Count == 0) return;

        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            const string insertSql = """
                INSERT INTO master.models
                    (code, gtin, origin, category_id, length, width, height, standard_packing,
                     layer_limit, layer_count, stacking_length, stacking_width,
                     suggest_area, suggest_rack_row,
                     is_active, is_deleted, created_at, created_by)
                VALUES
                    (@Code, @GTIN, @Origin, @CategoryId, @Length, @Width, @Height, @StandardPacking,
                     @LayerLimit, @LayerCount, @StackingLength, @StackingWidth,
                     @SuggestAreaId, @SuggestRackRow,
                     @IsActive, 0, SYSUTCDATETIME(), @CreatedBy);
                """;

            const string updateSql = """
                UPDATE master.models SET
                    gtin             = COALESCE(@GTIN, gtin),
                    origin           = COALESCE(@Origin, origin),
                    category_id      = COALESCE(@CategoryId, category_id),
                    length           = COALESCE(@Length, length),
                    width            = COALESCE(@Width, width),
                    height           = COALESCE(@Height, height),
                    standard_packing = COALESCE(@StandardPacking, standard_packing),
                    layer_limit      = COALESCE(@LayerLimit, layer_limit),
                    layer_count      = COALESCE(@LayerCount, layer_count),
                    stacking_length  = COALESCE(@StackingLength, stacking_length),
                    stacking_width   = COALESCE(@StackingWidth, stacking_width),
                    suggest_area     = COALESCE(@SuggestAreaId, suggest_area),
                    suggest_rack_row = COALESCE(@SuggestRackRow, suggest_rack_row),
                    is_active        = COALESCE(@IsActive, is_active),
                    updated_at       = SYSUTCDATETIME(),
                    updated_by       = @UpdatedBy
                WHERE id = @Id AND is_deleted = 0;
                """;

            foreach (var e in toInsert)
                await conn.ExecuteAsync(insertSql, e, tx);

            foreach (var e in toUpdate)
                await conn.ExecuteAsync(updateSql, e, tx);

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public async Task UpdateAsync(ModelEntity e)
    {
        using var conn = _factory.Create();
        var sql = """
            UPDATE master.models SET
                code             = @Code,
                gtin             = @GTIN, 
                origin           = @Origin,
                category_id      = @CategoryCode,
                length           = @Length,
                width            = @Width,
                height           = @Height,
                standard_packing = @StandardPacking,
                layer_limit      = @LayerLimit,
                layer_count      = @LayerCount,
                stacking_length  = @StackingLength,
                stacking_width   = @StackingWidth,
                suggest_area     = @SuggestAreaId,
                suggest_rack_row = @SuggestRackRow,
                is_active        = @IsActive,
                updated_at       = SYSUTCDATETIME(),
                updated_by       = @UpdatedBy
            WHERE id = @Id AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(sql, e);
    }

    // Partial update cho màn hình gợi ý lưu kho (PDA / dialog master).
    // Cố tình KHÔNG dùng lại UpdateAsync để tránh ghi đè các cột khác bằng
    // giá trị cũ đọc từ DB (race với người khác đang sửa cùng model).
    public async Task<int> UpdateSuggestionAsync(int id, int? suggestAreaId, string? suggestRackRow, string? updatedBy)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.models SET
                suggest_area     = @SuggestAreaId,
                suggest_rack_row = @SuggestRackRow,
                updated_at       = SYSUTCDATETIME(),
                updated_by       = @UpdatedBy
            WHERE id = @Id AND is_deleted = 0;
            """;
        return await conn.ExecuteAsync(sql, new
        {
            Id = id,
            SuggestAreaId = suggestAreaId,
            SuggestRackRow = suggestRackRow,
            UpdatedBy = updatedBy,
        });
    }

    public async Task SoftDeleteAsync(int id, string? deletedBy)
    {
        using var conn = _factory.Create();
        var sql = """
            UPDATE master.models
            SET is_deleted = 1, updated_at = SYSUTCDATETIME(), updated_by = @deletedBy
            WHERE id = @id AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(sql, new { id, deletedBy });
    }

    public async Task<bool> CodeExistsAsync(string code, int? excludeId)
    {
        using var conn = _factory.Create();
        var sql = """
            SELECT COUNT(1) FROM master.models
            WHERE code = @code AND is_deleted = 0
              AND (@excludeId IS NULL OR id <> @excludeId);
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { code, excludeId }) > 0;
    }

    public async Task<bool> GtinExistsAsync(string gtin, int? excludeId)
    {
        using var conn = _factory.Create();
        const string sql = """
        SELECT COUNT(1) FROM master.models
        WHERE gtin = @gtin AND is_deleted = 0
          AND (@excludeId IS NULL OR id <> @excludeId);
        """;
        return await conn.ExecuteScalarAsync<int>(sql, new { gtin, excludeId }) > 0;
    }

    public async Task<IReadOnlyList<(int Id, string Code)>> GetExistingCodesAsync(IReadOnlyList<string> codes)
    {
        using var conn = _factory.Create();
        var sql = """
            SELECT id AS Id, code AS Code
            FROM master.models
            WHERE is_deleted = 0 AND code IN @codes;
            """;
        var rows = await conn.QueryAsync<(int Id, string Code)>(sql, new { codes });
        return rows.ToList();
    }
}