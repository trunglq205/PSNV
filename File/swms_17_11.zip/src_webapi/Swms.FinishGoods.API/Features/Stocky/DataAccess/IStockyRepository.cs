namespace Swms.FinishGoods.API.Features.Stocky.DataAccess;

public interface IStockyRepository
{
    /// <summary>
    /// Danh sách xe kèm hàng đang nằm trên xe. Bộ lọc nào NULL thì bỏ qua.
    /// </summary>
    /// <param name="status">in_warehouse | returned. NULL = cả hai.</param>
    /// <param name="hasGoods">true = chỉ xe có hàng, false = chỉ xe rỗng, NULL = cả hai.</param>
    /// <param name="keyword">Khớp mã xe, tên xe, mã pallet hoặc model.</param>
    Task<IReadOnlyList<StockyCart>> GetListAsync(string? status, bool? hasGoods, string? keyword);

    /// <summary>Một xe theo mã. NULL = chưa có xe nào mang mã đó.</summary>
    Task<StockyCart?> GetByCodeAsync(string code);

    /// <summary>
    /// Nhận một lô xe vào kho. Mã chưa có thì THÊM, mã đã có (kể cả đã xoá mềm
    /// hay đã trả về vendor) thì hồi sinh về trạng thái đang trong kho.
    /// </summary>
    /// <param name="parkLocatorId">
    /// Ô đậu xe gán cho xe rỗng. NULL = chưa khai ô, xe vẫn nhận được.
    /// </param>
    /// <param name="faLocatorId">
    /// Ô FA. Dùng để NHẬN BIẾT xe đang ở FA mà kéo về bãi đậu — nhận một xe
    /// đang ở FA chính là thao tác "đưa xe từ FA về kho". NULL = chưa khai ô FA.
    /// </param>
    /// <returns>Số xe thực sự đổi trạng thái.</returns>
    Task<int> ReceiveAsync(
        IReadOnlyList<string> codes, long? parkLocatorId, long? faLocatorId, string? user);

    /// <summary>
    /// Đẩy một lô xe sang FA. Chỉ đổi ô, KHÔNG đổi <c>status</c> — xe vẫn được
    /// quản lý. Đừng nhầm với <see cref="ReturnAsync"/>.
    /// </summary>
    /// <returns>Số xe đổi ô — luôn bằng <c>codes.Count</c>.</returns>
    /// <exception cref="StockyConcurrencyException">Có mã không còn hợp lệ.</exception>
    Task<int> ExportToFaAsync(IReadOnlyList<string> codes, long faLocatorId, string? user);

    /// <summary>
    /// Trả một lô xe VỀ VENDOR — xe rời hệ thống, không còn trong danh sách
    /// theo dõi nữa. Đây là trạng thái cuối duy nhất.
    /// </summary>
    /// <param name="faLocatorId">
    /// Ô FA, để CHẶN trả vendor khi xe đang ở FA (vendor nhận xe tại kho).
    /// NULL = chưa khai ô FA, khi đó không có xe nào ở FA nên không chặn gì.
    /// </param>
    /// <returns>Số xe đổi trạng thái — luôn bằng <c>codes.Count</c>.</returns>
    /// <exception cref="StockyConcurrencyException">Có mã không còn hợp lệ.</exception>
    Task<int> ReturnAsync(IReadOnlyList<string> codes, long? faLocatorId, string? user);

    /// <summary>
    /// Id của một ô theo <c>master.locators.locator_code</c> (bãi đậu xe
    /// Stocky, ô FA…). NULL = chưa khai ô đó.
    /// </summary>
    Task<long?> FindLocatorIdAsync(string locatorCode);

    /// <summary>
    /// Id các pallet HỆ THỐNG ĐANG GHI là nằm trên xe này (chưa xoá mềm).
    ///
    /// Dùng cho thao tác đặt xe vào ô: đẩy xe là hàng trên xe đi theo, nên
    /// phải biết đích danh từng pallet để chuyển ô qua đúng cổng của slice
    /// Pallets (lịch sử vị trí + sự kiện kho + cổng duyệt hàng RW/RB).
    /// </summary>
    Task<IReadOnlyList<long>> GetLotIdsOnCartAsync(string code);

    /// <summary>
    /// Ghi Ô RIÊNG của xe (<c>wms.stocky_carts.locator_id</c>).
    ///
    /// Chỉ ghi cho xe đang được quản lý (<c>in_warehouse</c>) và chưa xoá mềm.
    /// </summary>
    /// <returns>Số dòng đổi — 0 nghĩa là xe không còn hợp lệ để đặt ô.</returns>
    Task<int> PlaceAsync(string code, long locatorId);
}
