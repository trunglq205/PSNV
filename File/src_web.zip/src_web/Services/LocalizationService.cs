﻿using System.Text.Json;

namespace SWMS_WebTool.Services
{
    public class LocalizationService : ILocalizationService
    {
        private readonly Dictionary<string, string> _translations;
        private readonly ILogger<LocalizationService> _logger;

        public string CurrentLanguage { get; }

        public LocalizationService(
            IConfiguration configuration,
            IWebHostEnvironment environment,
            ILogger<LocalizationService> logger)
        {
            _logger = logger;
            CurrentLanguage = configuration["Language"] ?? "en";
            _translations = LoadTranslations(environment.ContentRootPath, CurrentLanguage);

            _logger.LogInformation(
                "LocalizationService initialized. Language: {Language}, Translations: {Count}",
                CurrentLanguage, _translations.Count);
        }

        private Dictionary<string, string> LoadTranslations(string contentRoot, string language)
        {
            var filePath = Path.Combine(contentRoot, "Resources", $"{language}.json");

            if (!File.Exists(filePath))
            {
                _logger.LogError("Translation file not found: {FilePath}", filePath);
                var fallback = Path.Combine(contentRoot, "Resources", "en.json");
                if (File.Exists(fallback)) filePath = fallback;
                else return new Dictionary<string, string>();
            }

            try
            {
                var json = File.ReadAllText(filePath);
                // Loại bỏ BOM nếu có (System.Text.Json không chấp nhận BOM)
                if (json.StartsWith('\uFEFF'))
                    json = json.Substring(1);
                var dict = JsonSerializer.Deserialize<Dictionary<string, string>>(json);

                // Cảnh báo nếu rỗng (JSON lỗi syntax)
                if (dict == null || dict.Count == 0)
                    _logger.LogWarning("Translation file EMPTY: {FilePath}. Check JSON syntax!", filePath);

                return dict ?? new Dictionary<string, string>();
            }
            catch (JsonException ex)
            {
                _logger.LogError(ex, "JSON SYNTAX ERROR in {FilePath} at line {Line}!",
                    filePath, ex.LineNumber);
                return new Dictionary<string, string>();
            }
        }

        public string Get(string key)
        {
            if (string.IsNullOrEmpty(key)) return string.Empty;
            if (_translations.TryGetValue(key, out var value)) return value;
            _logger.LogWarning("Translation key not found: {Key}", key);
            return key;
        }

        public string Get(string key, params object[] args)
        {
            var template = Get(key);
            if (args == null || args.Length == 0) return template;
            try { return string.Format(template, args); }
            catch (FormatException) { return template; }
        }
    }
}