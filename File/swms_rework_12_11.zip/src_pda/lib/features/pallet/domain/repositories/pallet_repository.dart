﻿import 'package:swms_finish_goods/features/pallet/domain/entities/locator_occupancy.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/storage_suggestion.dart';

/// Toàn bộ nghiệp vụ trên 1 pallet:
/// chi tiết · tách · vị trí tạm (gán/chuyển) · lưu kho · chuyển.
abstract class PalletRepository {
  /// `GET /api/pallets/by-lot-no/{lotNo}?include=...`
  /// [include] rỗng ⇒ chỉ thông tin lot + vị trí + allowedActions (nhẹ nhất).
  ///
  /// [createIfMissing] (mặc định true): mã chưa có trong SWMS thì dựng lot từ
  /// dữ liệu Foss — hành vi của màn QUÉT NHẬP.
  ///
  /// Truyền false ở những chỗ chỉ TRA CỨU một mã do người dùng nhập/quét, ví
  /// dụ ô pallet đích khi tách: gõ sai một số mà vẫn tạo thì sinh pallet rác.
  Future<Pallet> getByLotNo(
    String lotNo, {
    Set<PalletInclude> include = const {},
    bool createIfMissing = true,
  });

  /// `GET /api/pallets/by-lot-no/{lotNo}/storage-suggestion?palletHeightCm=...`
  ///
  /// Gợi ý vị trí lưu kho. [palletHeightCm] tuỳ chọn — chỉ dùng khi model chưa
  /// khai `suggest_rack_row` trong master; không gửi thì server vẫn trả gợi ý
  /// kèm cảnh báo.
  ///
  /// Đây là thông tin THAM KHẢO: hỏng thì màn Lưu kho vẫn phải quét được vị trí
  /// và xác nhận bình thường, nên tầng gọi đừng chặn luồng vì lỗi ở đây.
  Future<StorageSuggestion> getStorageSuggestion(
    String lotNo, {
    int? palletHeightCm,
  });

  /// Tách pallet khỏi [sourceLotNo].
  ///
  /// Pallet quản lý theo serial / box_line thì truyền [boxIds] (các thùng đã
  /// quét). Pallet quản lý theo box_count thì truyền [boxQty] — loại này chỉ
  /// biết số thùng, không có thùng nào để quét.
  ///
  /// [toNewLot] = true -> server tự sinh lot mới, bỏ qua [targetLotNo].
  ///
  /// [confirmModelMismatch] = true khi người dùng đã thấy cảnh báo pallet đích
  /// khác model và đồng ý tách. Để false thì server chặn như trước.
  Future<SplitResult> split({
    required String sourceLotNo,
    required List<int> boxIds,
    required bool toNewLot,
    String? targetLotNo,
    int? boxQty,
    bool confirmModelMismatch = false,
  });

  /// Gán (chưa có vị trí) hoặc chuyển (đã có) sang [locatorCode].
  /// `PUT /api/pallets/{id}/locator`
  Future<LocatorChangeResult> assignLocator({
    required int lotId,
    required String locatorCode,
    String? allowedMapType,
  });

  /// Lưu kho vào [locatorCode] (Movement 131). `PUT /api/pallets/{id}/storing`
  Future<LocatorChangeResult> store({
    required int lotId,
    required String locatorCode,
  });

  /// Out kho: gỡ pallet khỏi vị trí hiện tại, không có vị trí đích.
  /// `DELETE /api/pallets/{id}/locator` — quyền `temploc.release`.
  Future<LocatorChangeResult> releaseLocator({required int lotId});

  Future<LocatorOccupancy> getLocatorPallets(String locatorCode);

  Future<void> syncOqc(String lotNo);
}
