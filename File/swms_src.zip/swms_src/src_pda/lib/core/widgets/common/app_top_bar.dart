import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';

/// AppBar dùng chung — nền sáng, tiêu đề + phụ đề, viền mảnh bên dưới.
/// Khớp mockup PDA: nền card, đường kẻ ngăn cách với nội dung.
class AppTopBar extends StatelessWidget implements PreferredSizeWidget {
  final String title;
  final String? subtitle;

  /// Hiện nút back. Mặc định tự suy ra theo Navigator.canPop.
  final bool? showBack;
  final VoidCallback? onBack;

  final Widget? leading;

  /// Nút bên phải.
  final List<Widget> actions;

  const AppTopBar({
    super.key,
    required this.title,
    this.subtitle,
    this.showBack,
    this.onBack,
    this.leading,
    this.actions = const [],
  });

  static const double _barHeight = 56;
  static const double _dividerHeight = 1;

  @override
  Size get preferredSize => const Size.fromHeight(_barHeight + _dividerHeight);

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final canPop = showBack ?? Navigator.of(context).canPop();

    return AppBar(
      backgroundColor: Theme.of(context).colorScheme.surface,
      surfaceTintColor: Colors.transparent,
      foregroundColor: swms.text2,
      elevation: 0,
      scrolledUnderElevation: 0,
      centerTitle: false,
      titleSpacing: canPop ? 0 : AppDimens.md,
      leadingWidth: 44,
      leading: leading ?? (canPop ? _buildIconButton(context, swms) : null),
      title: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: [
          Text(title, style: AppTextStyles.title.copyWith(color: swms.text2)),
          if (subtitle != null)
            Text(
              subtitle!,
              style: AppTextStyles.caption.copyWith(
                fontSize: 11,
                fontWeight: FontWeight.w400,
                color: swms.text3,
              ),
            ),
        ],
      ),
      actions: actions.isEmpty
          ? null
          : [...actions, const SizedBox(width: AppDimens.sm)],
      bottom: PreferredSize(
        preferredSize: const Size.fromHeight(_dividerHeight),
        child: Container(height: _dividerHeight, color: swms.border),
      ),
    );
  }

  IconButton _buildIconButton(BuildContext context, SwmsColors swms) {
    return IconButton(
      onPressed: onBack ?? () => Navigator.of(context).maybePop(),
      icon: Icon(Icons.arrow_back_ios_new, size: 18, color: swms.text4),
      splashRadius: 22,
    );
  }
}
