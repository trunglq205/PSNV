import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2a — SCS WH nhận hàng back vào phiếu.
//
//  WH chọn phiếu → chọn model → quét mã thùng → quét serial từng sản phẩm
//  trong thùng đó → thùng tiếp theo → Lưu. Server cấp Pallet ID rồi PDA in
//  nhãn (hàng khách trả về không có nhãn Pallet ID in sẵn).
// ─────────────────────────────────────────────────────────────

/// Một thùng đang quét dở trên máy, CHƯA gửi server.
@immutable
class ReturnBoxDraft {
  /// Mã thùng quét được. `null` = hàng về rời, không có thùng để quét;
  /// server tự đặt mã theo Pallet ID.
  final String? boxNo;

  /// Model của CẢ thùng. Serial in trên sản phẩm không cho biết model nên WH
  /// phải chọn trước khi quét — xem [ReturnNoModelSelectedException].
  final String model;

  final List<String> serials;

  const ReturnBoxDraft({
    required this.model,
    this.boxNo,
    this.serials = const [],
  });

  ReturnBoxDraft copyWith({
    String? model,
    String? boxNo,
    List<String>? serials,
  }) =>
      ReturnBoxDraft(
        model: model ?? this.model,
        boxNo: boxNo ?? this.boxNo,
        serials: serials ?? this.serials,
      );
}

/// Kết quả một lần nhận: pallet vừa tạo + phiếu đã cập nhật SL thực nhận.
@immutable
class ReturnReceiveResult {
  /// Id `wms.pallets` — dùng khi cần mở màn chi tiết pallet.
  final int palletId;

  /// Pallet ID dạng 12 số, để in nhãn.
  final String lotNo;

  final int categoryCode;
  final int boxCount;
  final int serialCount;

  /// Đã nhận vượt chỉ thị ở ít nhất một model. Cảnh báo, không phải lỗi.
  final bool overReceived;

  /// Phiếu sau khi nhận — màn hình vẽ lại tiến độ từ đây, không gọi lại API.
  final ReturnInstruction doc;

  const ReturnReceiveResult({
    required this.palletId,
    required this.lotNo,
    required this.categoryCode,
    required this.boxCount,
    required this.serialCount,
    required this.overReceived,
    required this.doc,
  });
}
