﻿using System.Runtime.CompilerServices;
using System.Xml.Linq;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json;
using SWMS_WebTool.Utils;

namespace SWMS_WebTool.Models.Layout
{
    public class Node : IComparable<Node>
    {
        public Node(int x, int y, string name = "") { X = x; Y = y; Name = name; }

        public int X;
        public int Y;
        public string Name;
        public BoundingBox? BoundingBox;
        public bool IsObstacle = false;
        public bool IsRoad = false;
        private object value;

        public int GCost { get; set; }
        public int HCost { get; set; }
        public Node? Parent { get; set; }
        public int FCost => GCost + HCost;
        public int CompareTo(Node? other)
        {
            return (X == other.X && Y == other.Y) ? 0 : 1;
        }
        public override bool Equals(object? obj)
        {
            if (obj is Node other)
            {
                return this.CompareTo(other) == 0;
            }

            return false;
        }

    }

    public class EmapGrid : List<List<Node>>
    {
        public EmapGrid(Floor floor)
        {
            var cellSize = Constants.CELL_SIZE;
            var grid = new List<List<Node>>();

            int width = (int)Math.Round(floor.Width ?? 0) / cellSize;
            int height = (int)Math.Round(floor.Height ?? 0) / cellSize;
            grid.AddRange(Enumerable.Range(0, width)
                .Select(x => Enumerable.Range(0, height)
                .Select(y => new Node(x, y)).ToList()));

            MapObstacle(grid, floor);
            MapRoad(grid, floor);
            AddRange(grid);
        }

        public string ToJson()
        {
            return JsonConvert.SerializeObject(this, new JsonSerializerSettings
            {
                NullValueHandling = NullValueHandling.Ignore,
                ContractResolver = new Newtonsoft.Json.Serialization.CamelCasePropertyNamesContractResolver()
            });
        }

        private void MapObstacle(List<List<Node>> grid, Layout floor)
        {
            var cellSize = Constants.CELL_SIZE;
            var gridWidth = grid.Count;
            var gridHeight = grid.First().Count;

            if (floor.Widgets != null)
            {
                foreach (var element in floor.Widgets)
                {
                    var boundingBox = element.BoundingBox;

                    if (boundingBox == null)
                    {
                        continue;
                    }

                    switch (element.Type)
                    {
                        case WidgetType.Zone:
                            if (element is Layout )
                            {
                                var zone = element as Layout;

                                foreach (var zoneWidget in zone.Widgets)
                                {
                                    var boundingBoxWidget = zoneWidget.BoundingBox;

                                    var minXWidget = Math.Max(0, (int)Math.Round(boundingBoxWidget.X / cellSize));
                                    var maxXWidget = (int)Math.Round((double)((boundingBoxWidget.X + boundingBoxWidget.Width) / cellSize));
                                    var minYWidget = Math.Max(0, (int)Math.Round(boundingBoxWidget.Y / cellSize));
                                    var maxYWidget = (int)Math.Round((double)((boundingBoxWidget.Y + boundingBoxWidget.Height) / cellSize));
                                    switch (zoneWidget.Type)
                                    {
                                        case WidgetType.Rack:
                                        case WidgetType.Rectangle:
                                            for (int i = minXWidget; i < maxXWidget; i++)
                                            {
                                                for (int j = minYWidget; j < maxYWidget; j++)
                                                {
                                                    grid[i][j].IsObstacle = true;
                                                }
                                            }
                                            break;
                                    }
                                }
                            }
                            break;
                        case WidgetType.Rectangle:
                        case WidgetType.Door:
                        case WidgetType.SingleDoor:
                        case WidgetType.DoubleDoor:
                            var minX = Math.Max(0, (int)Math.Round(boundingBox.X / cellSize));
                            var maxX = (int)Math.Round((double)((boundingBox.X + boundingBox.Width) / cellSize));
                            var minY = Math.Max(0, (int)Math.Round(boundingBox.Y / cellSize));
                            var maxY = (int)Math.Round((double)((boundingBox.Y + boundingBox.Height) / cellSize));
                            for (int i = minX; i < Math.Min(gridWidth, maxX) && i >= 0; i++)
                            {
                                for (int j = minY; j < Math.Min(gridHeight, maxY) && j >= 0; j++)
                                {
                                    grid[i][j].IsObstacle = element.Type == WidgetType.Rectangle;
                                }
                            }
                            break;
                    }
                }
            }

        }

        private void MapRoad(List<List<Node>> grid, Floor floor)
        {
            foreach (var row in grid)
            {
                foreach (var element in row)
                {
                    if (element.IsRoad || !element.IsObstacle)
                    {
                        continue;
                    }

                    MapHorizontalRoad(grid, element);
                    MapVerticalRoad(grid, element);
                }
            }

            // Tầng 1
            if (floor.FloorCode == "1")
            {
                MapTrolleyRoad(grid, Constants.TROLLEY_TV_LOCATION);
                MapTrolleyRoad(grid, Constants.TROLLEY_MW_LOCATION);
            }
            // Tầng 2
            else if (floor.FloorCode == "2")
            {
                MapTrolleyRoad(grid, Constants.TROLLEY_PJ_LOCATION);
                MapTrolleyRoad(grid, Constants.TROLLEY_DP_DECT_SB_LOCATION);
            }
        }

        private void MapHorizontalRoad(List<List<Node>> grid, Node element)
        {
            int i = element.Y;

            while (i > 0 && !grid[element.X][i - 1].IsObstacle)
            {
                i--;
            }

            if (i > 0 && grid[element.X][i - 1].IsObstacle)
            {
                int k = (element.Y + i) / 2;

                if (Math.Abs(element.Y - i) > 2 &&
                    !grid[element.X][k].IsObstacle &&
                    !grid[element.X][k].IsRoad)
                {
                    grid[element.X][k].IsRoad = true;
                    ExtendRoadHorizontally(grid, element.X, k);
                }
            }
        }

        private void MapVerticalRoad(List<List<Node>> grid, Node element)
        {
            int i = element.X;

            while (i > 0 && !grid[i - 1][element.Y].IsObstacle)
            {
                i--;
            }

            if (i > 0 && grid[i - 1][element.Y].IsObstacle)
            {
                int k = (element.X + i) / 2;

                if (Math.Abs(element.X - i) > 2 &&
                    !grid[k][element.Y].IsObstacle &&
                    !grid[k][element.Y].IsRoad)
                {
                    grid[k][element.Y].IsRoad = true;
                    ExtendRoadVertically(grid, k, element.Y);
                }
            }
        }

        private void ExtendRoadHorizontally(List<List<Node>> grid, int x, int y)
        {
            if (x < 0 || y < 0 || x >= grid.Count || y >= grid.First().Count)
            {
                return;
            }

            int j = x;

            // Extend to the left
            while (j > 1 && !grid[j - 1][y].IsObstacle)
            {
                j--;
                grid[j][y].IsRoad = true;
            }

            // Reset j and extend to the right
            j = x;
            while (j < grid.Count - 1 && !grid[j + 1][y].IsObstacle)
            {
                j++;
                grid[j][y].IsRoad = true;
            }
        }

        private void ExtendRoadVertically(List<List<Node>> grid, int x, int y)
        {
            if (x < 0 || y < 0 || x > grid.Count || y > grid.First().Count)
            {
                return;
            }

            int j = y;

            // Extend upwards
            while (j > 1 && !grid[x][j - 1].IsObstacle)
            {
                j--;
                grid[x][j].IsRoad = true;
            }

            // Reset j and extend downwards
            j = y;
            while (j < grid.First().Count - 1 && !grid[x][j + 1].IsObstacle)
            {
                j++;
                grid[x][j].IsRoad = true;
            }
        }

        private void MapTrolleyRoad(List<List<Node>> grid, (int, int) trolleyLocation)
        {
            grid[trolleyLocation.Item1][trolleyLocation.Item2].IsObstacle = false;
            grid[trolleyLocation.Item1][trolleyLocation.Item2].IsRoad = true;

            var x = trolleyLocation.Item1;
            var y = trolleyLocation.Item2;

            int j = x;

            // Extend to the left
            while (j > 1 && !grid[j - 1][y].IsRoad)
            {
                j--;
                grid[j][y].IsObstacle = false;
                grid[j][y].IsRoad = true;
            }

            // Reset j and extend to the right
            j = x;
            while (j < grid.Count - 1 && !grid[j + 1][y].IsRoad)
            {
                j++;
                grid[j][y].IsObstacle = false;
                grid[j][y].IsRoad = true;
            }

            j = y;
            // Extend upwards
            while (j > 1 && !grid[x][j - 1].IsRoad)
            {
                j--;
                grid[x][j].IsObstacle = false;
                grid[x][j].IsRoad = true;
            }

            // Reset j and extend downwards
            j = y;
            while (j < grid.First().Count - 1 && !grid[x][j + 1].IsRoad)
            {
                j++;
                grid[x][j].IsObstacle = false;
                grid[x][j].IsRoad = true;
            }
        }

        public void MapKittingLocation(Floor floor, List<Node> kittingLocation)
        {
            foreach (var node in kittingLocation)
            {
                var blockRect = node.BoundingBox;

                if (blockRect == null)
                {
                    continue;
                }

                var minX = (int)Math.Round(blockRect.X / Constants.CELL_SIZE);
                var maxX = (int)Math.Round((blockRect.X + blockRect.Width) / Constants.CELL_SIZE);
                var minY = (int)Math.Round(blockRect.Y / Constants.CELL_SIZE);
                var maxY = (int)Math.Round((blockRect.Y + blockRect.Height) / Constants.CELL_SIZE);

                for (int x = minX; x < maxX; x++)
                {
                    for (int y = minY; y < maxY; y++)
                    {
                        this[x][y].IsObstacle = false;
                    }
                }

                foreach(var otherNode in kittingLocation)
                {
                    var distance = GetDistance(node, otherNode);

                    if (distance == 0) { continue; }

                    var totalWidth = (node.BoundingBox.Width / 2 + otherNode.BoundingBox.Width / 2) / Constants.CELL_SIZE;
                    var totalHeight = (node.BoundingBox.Height / 2 + otherNode.BoundingBox.Height / 2) / Constants.CELL_SIZE;

                    if (distance < totalWidth + 1 || distance < totalHeight + 1)
                    {
                        this[(node.X + otherNode.X) / 2][(node.Y + otherNode.Y) / 2].IsObstacle = true;
                    }
                }

                // Match to road
                var centerPoint = blockRect.GetCenterPoint();
                var centerPointX = (int)(Math.Round(centerPoint.Item1 / Constants.CELL_SIZE));
                var centerPointY = (int)(Math.Round(centerPoint.Item2 / Constants.CELL_SIZE));

                this[centerPointX][centerPointY].IsRoad = true;

                // Right
                int i = centerPointX + 1;
                while (i < this.Count && !this[i][centerPointY].IsObstacle)
                {
                    this[i][centerPointY].IsRoad = true;
                    i++;
                }

                // Left
                i = centerPointX - 1;
                while (i >= 0 && !this[i][centerPointY].IsObstacle)
                {
                    this[i][centerPointY].IsRoad = true;
                    i--;
                }

                // Top
                i = centerPointY + 1;
                while (i < this.First().Count && !this[centerPointX][i].IsObstacle)
                {
                    this[centerPointX][i].IsRoad = true;
                    i++;
                }

                // Bottom
                i = centerPointY - 1;
                while (i >= 0 && !this[centerPointX][i].IsObstacle)
                {
                    this[centerPointX][i].IsRoad = true;
                    i--;
                }
            }
        }

        private int GetDistance(Node a, Node b)
        {
            int distX = Math.Abs(a.X - b.X);
            int distY = Math.Abs(a.Y - b.Y);

            return distX + distY;
        }
    }
}
