import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';

/// Header thẻ kiểm: tiêu đề + bộ đếm `done/total`, đủ thì tô xanh.
class InspectSectionHeader extends StatelessWidget {
  final String title;
  final int done;
  final int total;

  const InspectSectionHeader({
    super.key,
    required this.title,
    required this.done,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final full = done >= total;
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.xs),
      child: Row(
        children: [
          Expanded(
            child: Text(title, style: AppTextStyles.title.copyWith(color: c.text1)),
          ),
          Text(
            '$done/$total',
            style: AppTextStyles.label.copyWith(
              color: full ? c.success : c.text3,
              fontFeatures: const [FontFeature.tabularFigures()],
            ),
          ),
        ],
      ),
    );
  }
}
