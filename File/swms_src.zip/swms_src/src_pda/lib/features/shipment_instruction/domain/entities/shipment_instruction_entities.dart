import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';

/// Tỉ lệ hoàn thành 0..1. required <= 0 thì coi như 0.
double _ratio(int done, int required) {
  if (required <= 0) return 0;
  return (done / required).clamp(0.0, 1.0);
}

/// Đã đáp ứng = yêu cầu − thiếu − đã cắt.
/// Khớp dữ liệu list (451 − 125 − 0 = 326 = qtyFulfilled). Detail không trả
/// qtyFulfilled nên tự tính theo cùng công thức để hai màn không lệch nhau.
int _fulfilled(int required, int short, int cut) {
  if (required <= 0) return 0;
  return (required - short - cut).clamp(0, required).toInt();
}

// ─────────────────────────────────────────────────────────────
//  LIST
// ─────────────────────────────────────────────────────────────

/// Một dòng trong danh sách chỉ thị (GET /api/shipment-instructions).
class ShipmentInstructionSummary {
  final int id;
  final String docNo;
  final String siNo;
  final String? revision;
  final String? category;
  final String? shipMode;

  /// null = key lạ; khi đó dùng [statusKey] để hiển thị.
  final SiStatus? status;
  final String? statusKey;

  final DateTime? etdDate;
  final DateTime? etaDate;
  final DateTime? vanningDate;
  final DateTime? cutOffAt;

  final String? consigneeCode;
  final String? countryCode;
  final String? forwarderCode;
  final String? picName;
  final bool isSerialRequired;

  final int lineCount;
  final int modelCount;
  final String? modelsPreview;
  final String? poNos;

  final int qtyRequired;
  final int qtyFulfilled;
  final int qtyCut;
  final int qtyShort;
  final int totalPlt;
  final int totalCtn;
  final int unmatchedBoxCount;

  const ShipmentInstructionSummary({
    required this.id,
    required this.docNo,
    required this.siNo,
    this.revision,
    this.category,
    this.shipMode,
    this.status,
    this.statusKey,
    this.etdDate,
    this.etaDate,
    this.vanningDate,
    this.cutOffAt,
    this.consigneeCode,
    this.countryCode,
    this.forwarderCode,
    this.picName,
    this.isSerialRequired = false,
    this.lineCount = 0,
    this.modelCount = 0,
    this.modelsPreview,
    this.poNos,
    this.qtyRequired = 0,
    this.qtyFulfilled = 0,
    this.qtyCut = 0,
    this.qtyShort = 0,
    this.totalPlt = 0,
    this.totalCtn = 0,
    this.unmatchedBoxCount = 0,
  });

  double get progress => _ratio(qtyFulfilled, qtyRequired);
}

/// Một trang kết quả + số đếm theo trạng thái (nếu server trả).
class ShipmentInstructionPage {
  final List<ShipmentInstructionSummary> items;
  final int totalCount;
  final int page;
  final int size;
  final int totalPages;

  /// Số chỉ thị theo từng trạng thái cho badge trên thanh lọc.
  /// null = server chưa trả → ẩn badge.
  final Map<SiStatus, int>? statusCounts;

  const ShipmentInstructionPage({
    required this.items,
    required this.totalCount,
    required this.page,
    required this.size,
    required this.totalPages,
    this.statusCounts,
  });

  bool get hasMore => page < totalPages;

  /// Nối trang kế. Lọc trùng theo id: có chỉ thị mới chen vào giữa hai lần gọi
  /// thì offset bị lệch, trang sau lặp lại bản ghi cuối của trang trước.
  ShipmentInstructionPage append(ShipmentInstructionPage next) {
    final seen = items.map((e) => e.id).toSet();
    return ShipmentInstructionPage(
      items: [...items, ...next.items.where((e) => seen.add(e.id))],
      totalCount: next.totalCount,
      page: next.page,
      size: next.size,
      totalPages: next.totalPages,
      statusCounts: next.statusCounts ?? statusCounts,
    );
  }
}

// ─────────────────────────────────────────────────────────────
//  DETAIL
// ─────────────────────────────────────────────────────────────

/// Chi tiết chỉ thị (GET /api/shipment-instructions/{id}).
class ShipmentInstructionDetail {
  final int id;
  final String docNo;
  final String siNo;
  final String? revision;
  final String? category;
  final String? shipMode;
  final SiStatus? status;
  final String? statusKey;

  final DateTime? etdDate;
  final DateTime? etaDate;
  final DateTime? vanningDate;
  final DateTime? cutOffAt;

  final String? portOfLoading;
  final String? portOfDischarge;
  final String? countryCode;
  final String? forwarderCode;
  final String? carrierCode;
  final String? consigneeCode;
  final String? packingType;

  final bool isWhiteFilm;
  final bool isCaseMark;
  final bool isSerialRequired;

  final String? picName;

  /// Khu tập kết. API hiện chỉ trả id, chưa có mã khu.
  final int? toAreaId;
  final String? description;

  /// Dữ liệu thô từ SAP — key snake_case, giữ nguyên dạng map.
  final Map<String, dynamic> headerNote;

  final DateTime? createdAt;
  final String? createdBy;

  final List<ShipmentInstructionLine> lines;

  const ShipmentInstructionDetail({
    required this.id,
    required this.docNo,
    required this.siNo,
    this.revision,
    this.category,
    this.shipMode,
    this.status,
    this.statusKey,
    this.etdDate,
    this.etaDate,
    this.vanningDate,
    this.cutOffAt,
    this.portOfLoading,
    this.portOfDischarge,
    this.countryCode,
    this.forwarderCode,
    this.carrierCode,
    this.consigneeCode,
    this.packingType,
    this.isWhiteFilm = false,
    this.isCaseMark = false,
    this.isSerialRequired = false,
    this.picName,
    this.toAreaId,
    this.description,
    this.headerNote = const {},
    this.createdAt,
    this.createdBy,
    this.lines = const [],
  });

  int get qtyRequired => lines.fold(0, (a, l) => a + l.qtyRequired);
  int get qtyShort => lines.fold(0, (a, l) => a + l.qtyShort);
  int get qtyCut => lines.fold(0, (a, l) => a + (l.qtyCut ?? 0));
  int get qtyFulfilled => lines.fold(0, (a, l) => a + l.qtyFulfilled);
  double get progress => _ratio(qtyFulfilled, qtyRequired);

  /// Số packing list lấy từ header SAP.
  String? get packingListNo => headerNote['packing_list_no']?.toString();
}

class ShipmentInstructionLine {
  final int id;
  final int lineNo;
  final String model;
  final String? customerMaterial;
  final String? poNo;
  final String? packingListNo;
  final String? packingItemNo;
  final String? invoiceNo;
  final String? soNo;
  final String? soItemNo;
  final int qtyRequired;
  final String? uom;
  final int plt;
  final int ctn;
  final int? qtyCut;
  final String? cutBy;
  final DateTime? cutAt;
  final int qtyPending;
  final int qtyPicked;
  final int qtyShort;

  /// Nhiệm vụ lấy hàng của dòng (mỗi vị trí 1 nhiệm vụ).
  final List<PickTask> tasks;

  const ShipmentInstructionLine({
    required this.id,
    required this.lineNo,
    required this.model,
    this.customerMaterial,
    this.poNo,
    this.packingListNo,
    this.packingItemNo,
    this.invoiceNo,
    this.soNo,
    this.soItemNo,
    this.qtyRequired = 0,
    this.uom,
    this.plt = 0,
    this.ctn = 0,
    this.qtyCut,
    this.cutBy,
    this.cutAt,
    this.qtyPending = 0,
    this.qtyPicked = 0,
    this.qtyShort = 0,
    this.tasks = const [],
  });

  int get qtyFulfilled => _fulfilled(qtyRequired, qtyShort, qtyCut ?? 0);
  double get progress => _ratio(qtyFulfilled, qtyRequired);
}
