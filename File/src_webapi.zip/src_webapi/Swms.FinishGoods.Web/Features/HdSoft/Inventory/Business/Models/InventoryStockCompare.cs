using Swms.FinishGoods.Web.Features.Inventory.Business.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;

/// <summary>Kết quả so 1 cặp (vị trí, model) giữa SWMS và HD soft.</summary>
public static class StockCmp
{
    public const string Match = "match";
    public const string QtyDiff = "qty_diff";
    public const string OnlySwms = "only_swms";
    public const string OnlyHdSoft = "only_hdsoft";

    public static string Pill(string result) => result switch
    {
        Match => "success",
        QtyDiff => "warning",
        _ => "danger",
    };
}

/// <summary>1 phần tồn SWMS: pallet + 1 model + số lượng của model đó trên pallet.</summary>
public record SwmsStockUnit(AppInventoryItem Pallet, string Model, int Qty);

/// <summary>Tiến độ so: Stage = "list" (lật trang tồn SWMS) | "detail" (tải chi tiết pallet nhiều model).</summary>
public record StockCompareProgress(string Stage, int Done, int Total);

/// <summary>1 dòng so = 1 cặp (vị trí, model).</summary>
public class AppStockCompareRow
{
    public string LocKey { get; set; } = "";          // vị trí đã chuẩn hoá — "" = chưa có vị trí
    public string Locator { get; set; } = "";         // vị trí để hiển thị
    public string Model { get; set; } = "";
    public string Result { get; set; } = StockCmp.Match;

    public int SwmsQty { get; set; }
    public int SwmsUnits { get; set; }
    public List<AppInventoryItem> SwmsPallets { get; } = new();
    /// <summary>Phần tồn SWMS gốc (pallet + SL của model này) — để so SL theo từng pallet.</summary>
    public List<SwmsStockUnit> SwmsItems { get; } = new();

    public decimal HdQty { get; set; }
    public int HdLines { get; set; }
    public List<string> HdPallets { get; } = new();
    /// <summary>Dòng HD soft gốc (pallet + SL) — để tạo đúng từng pallet HD soft.</summary>
    public List<HdSoftPalletStockDto> HdItems { get; } = new();

    public bool IsMatch => Result == StockCmp.Match;
    public bool HasSwms => SwmsUnits > 0;
    public bool HasHd => HdLines > 0;
    public decimal Diff => SwmsQty - HdQty;
}

public class AppStockCompareResult
{
    public string? Warehouse { get; set; }
    public List<AppStockCompareRow> Rows { get; set; } = new();
    public int SwmsPallets { get; set; }
    public int SwmsQty { get; set; }
    public int HdPallets { get; set; }
    public decimal HdQty { get; set; }
    public int Locations { get; set; }
    /// <summary>Tồn SWMS vượt trần tải — chỉ so phần đầu.</summary>
    public bool Truncated { get; set; }
    /// <summary>Pallet nhiều model tải chi tiết lỗi — đã tính theo model của pallet.</summary>
    public List<string> DetailFailed { get; set; } = new();
    public DateTime ComparedAt { get; set; }
}

/*  So tồn kho SWMS ↔ HD soft theo (VỊ TRÍ, MODEL).

    Không so theo mã pallet: khi đưa sang HD soft, 1 pallet SWMS nhiều model bị tách thành
    nhiều pallet mới (mỗi pallet 1 model, mã khác) -> mã pallet 2 bên không còn tương ứng.
    Cái phải khớp là: tại mỗi vị trí, tổng số lượng từng model bằng nhau.

      Vị trí : trim, chữ hoa, bỏ tiền tố "<kho>-" (vd "PSNV-A1-10-1A" -> "A1-10-1A").
      Model  : bỏ hậu tố "-V4" của HD soft (M_Product.Value).
      SL     : SWMS = tổng qty các SwmsStockUnit; HD soft = tổng qty_on_hand.
    Không gọi mạng — Business tính SwmsStockUnit (tải chi tiết pallet nhiều model) rồi gọi vào. */
public static class InventoryStockComparer
{
    public static AppStockCompareResult Compare(
        IReadOnlyList<AppInventoryItem> pallets,
        IReadOnlyList<SwmsStockUnit> swms,
        IReadOnlyList<HdSoftPalletStockDto> hd,
        string? warehouse, bool truncated, IReadOnlyList<string> detailFailed)
    {
        var map = new Dictionary<string, AppStockCompareRow>(StringComparer.OrdinalIgnoreCase);

        AppStockCompareRow At(string? rawLoc, string? model)
        {
            var loc = Loc(rawLoc, warehouse);
            var m = Normalize(model);
            var key = loc + "|" + m.ToUpperInvariant();
            if (!map.TryGetValue(key, out var row))
            {
                row = new AppStockCompareRow { LocKey = loc, Locator = Clean(rawLoc) ?? "", Model = m };
                map[key] = row;
            }
            return row;
        }

        foreach (var u in swms)
        {
            var row = At(u.Pallet.LocatorCode, u.Model);
            row.SwmsQty += u.Qty;
            row.SwmsUnits++;
            row.SwmsItems.Add(u);
            if (!row.SwmsPallets.Contains(u.Pallet)) row.SwmsPallets.Add(u.Pallet);
        }

        foreach (var h in hd)
        {
            var row = At(h.Locator, h.Model);
            row.HdQty += h.QtyOnHand;
            row.HdLines++;
            row.HdItems.Add(h);
            if (row.Locator.Length == 0) row.Locator = Clean(h.Locator) ?? "";
            var pn = Clean(h.PalletNo);
            if (pn is not null && !row.HdPallets.Contains(pn, StringComparer.OrdinalIgnoreCase))
                row.HdPallets.Add(pn);
        }

        foreach (var r in map.Values)
            r.Result = !r.HasHd ? StockCmp.OnlySwms
                     : !r.HasSwms ? StockCmp.OnlyHdSoft
                     : r.SwmsQty == r.HdQty ? StockCmp.Match
                     : StockCmp.QtyDiff;

        return new AppStockCompareResult
        {
            Warehouse = warehouse,
            // Theo vị trí rồi model -> các model cùng 1 vị trí đứng liền nhau; chưa có vị trí xuống cuối
            Rows = map.Values
                .OrderBy(r => r.LocKey.Length == 0 ? 1 : 0)
                .ThenBy(r => r.LocKey, StringComparer.OrdinalIgnoreCase)
                .ThenBy(r => r.Model, StringComparer.OrdinalIgnoreCase)
                .ToList(),
            SwmsPallets = pallets.Count,
            SwmsQty = pallets.Sum(p => p.TotalQty),
            HdPallets = hd.Select(x => Clean(x.PalletNo)).Where(x => x is not null)
                          .Distinct(StringComparer.OrdinalIgnoreCase).Count(),
            HdQty = hd.Sum(x => x.QtyOnHand),
            Locations = map.Values.Select(r => r.LocKey).Where(l => l.Length > 0)
                                  .Distinct(StringComparer.OrdinalIgnoreCase).Count(),
            Truncated = truncated,
            DetailFailed = detailFailed.ToList(),
            ComparedAt = DateTime.Now,
        };
    }

    private static string? Clean(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    /// <summary>Vị trí để so: trim, chữ hoa, bỏ tiền tố "&lt;kho&gt;-".</summary>
    private static string Loc(string? v, string? warehouse)
    {
        var s = (v ?? "").Trim().ToUpperInvariant();
        if (!string.IsNullOrWhiteSpace(warehouse))
        {
            var prefix = warehouse.Trim().ToUpperInvariant() + "-";
            if (s.StartsWith(prefix, StringComparison.Ordinal) && s.Length > prefix.Length) s = s[prefix.Length..];
        }
        return s;
    }

    /// <summary>HD soft mang hậu tố "-V4"; SWMS dùng mã không hậu tố.</summary>
    private static string Normalize(string? m)
    {
        var v = (m ?? "").Trim();
        return v.EndsWith("-V4", StringComparison.OrdinalIgnoreCase) ? v[..^3].Trim() : v;
    }
}
