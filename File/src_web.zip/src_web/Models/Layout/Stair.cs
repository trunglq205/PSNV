﻿namespace SWMS_WebTool.Models.Layout
{
    public class Stair : Widget
    {
        public Stair() { }
        public Stair(KonvaObject konvaObject) : base(konvaObject)
        {
            Data = konvaObject.Attrs.Data ?? "";
        }
        public override WidgetType Type => WidgetType.Stair;
        protected override KonvaClassType ClassName => KonvaClassType.Path;

        public string Data { get; set; }

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.Data = Data;
            return attrs;
        }
    }
}
