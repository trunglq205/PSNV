import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/scan/data/models/scan_result_model.dart';

part 'scan_remote_data_source.g.dart';

@RestApi()
abstract class ScanRemoteDataSource {
  factory ScanRemoteDataSource(Dio dio, {String baseUrl}) = _ScanRemoteDataSource;

  /// Phân loại 1 mã quét. Luôn trả 200 kèm type (kể cả not_found).
  @GET('/api/scan/resolve')
  Future<ScanResultModel> resolve(@Query('code') String code);
}
