import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/part_card/data/datasources/part_card_remote_data_source.dart';
import 'package:swms_finish_goods/features/part_card/data/part_card_repository_impl.dart';
import 'package:swms_finish_goods/features/part_card/domain/repositories/part_card_repository.dart';

part 'part_card_providers.g.dart';

@riverpod
PartCardRemoteDataSource partCardRemoteDataSource(Ref ref) {
  final dio = ref.watch(dioProvider);
  return PartCardRemoteDataSource(dio);
}

@riverpod
PartCardRepository partCardRepository(Ref ref) {
  return PartCardRepositoryImpl(ref.watch(partCardRemoteDataSourceProvider));
}
