import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/auth/domain/auth_entity.dart';
import 'package:swms_finish_goods/features/auth/presentation/providers/auth_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'auth_notifier.g.dart';

@riverpod
class AuthNotifier extends _$AuthNotifier
    with BaseAsyncNotifierMixin<AuthEntity?> {
  @override
  AsyncValue<AuthEntity?> build() => const AsyncValue.data(null);

  Future<bool?> login(String username, String password) async {
    return await ref.read(appActionProvider.notifier).run(() async {
      await ref.read(authRepositoryProvider).login(username, password);
      return true;
    });
  }
}