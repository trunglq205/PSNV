import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_instruction_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 3 — SCS WH nhận lại pallet FA đã giao.
//
//  MỘT lần quét mã pallet là xong: FA đã quét từng serial khi đóng pallet ở
//  mục 2d, nên quét lại 400 con ở đây là làm hai lần một việc. Server chuyển
//  mọi serial `at_fa` của phiếu trên pallet đó sang `returned`.
//
//  Làm dialog chứ không làm một màn riêng: việc này đúng một thao tác, mở cả
//  một trang cho một lần quét là bắt người dùng đi hai bước thừa.
// ─────────────────────────────────────────────────────────────

/// Mở dialog nhận lại. Trả `true` nếu đã nhận được ít nhất một con.
Future<bool?> showReturnReceiveBackDialog(
  BuildContext context, {
  required ReturnInstruction doc,
}) =>
    showAppDialog<bool>(
      context,
      builder: (_) => _ReturnReceiveBackDialog(doc: doc),
    );

class _ReturnReceiveBackDialog extends ConsumerStatefulWidget {
  const _ReturnReceiveBackDialog({required this.doc});

  final ReturnInstruction doc;

  @override
  ConsumerState<_ReturnReceiveBackDialog> createState() =>
      _ReturnReceiveBackDialogState();
}

class _ReturnReceiveBackDialogState
    extends ConsumerState<_ReturnReceiveBackDialog> {
  StreamSubscription<String>? _sub;
  bool _busy = false;

  /// Kết quả lần nhận vừa rồi — giữ dialog mở để WH đọc hai con số.
  ReceiveBackResult? _done;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted || _busy) return;
      _receive(data);
    });
  }

  Future<void> _receive(String raw) async {
    final lotNo = raw.trim();
    if (lotNo.isEmpty || _busy) return;

    setState(() {
      _busy = true;
      _done = null;
    });
    try {
      // Lỗi API (pallet không có, pallet của phiếu khác, không còn con nào ở
      // FA) đã được appActionProvider bắt + toast → null. Giữ dialog mở để WH
      // quét lại pallet khác, thay vì đóng rồi phải mở lại.
      final res = await ref.read(appActionProvider.notifier).run(
            () => ref
                .read(returnInstructionRepositoryProvider)
                .receiveBack(docId: widget.doc.id, lotNo: lotNo),
          );
      if (!mounted) return;

      if (res != null) {
        ref.invalidate(returnInstructionDetailProvider(widget.doc.id));
        ref.invalidate(returnInstructionListProvider);
        setState(() => _done = res);
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final done = _done;

    return PopScope(
      canPop: !_busy,
      child: AppDialog(
        icon: Icons.move_to_inbox_outlined,
        title: LocaleKeys.return_recv_title.tr(),
        subtitle: widget.doc.docNo,
        headerTone: AppDialogHeaderTone.accent,
        actions: [
          AppDialogAction(
            label: done == null
                ? LocaleKeys.common_cancel.tr()
                : LocaleKeys.return_recv_close.tr(),
            variant: AppButtonVariant.neutral,
            onPressed:
                _busy ? null : () => Navigator.pop(context, done != null),
          ),
        ],
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            BarcodeScannerButton(
              state: _busy ? ScannerState.loading : ScannerState.scanning,
              scanningLabel: LocaleKeys.return_recv_scan_label.tr(),
              loadingLabel: LocaleKeys.return_recv_saving.tr(),
            ),
            const SizedBox(height: AppDimens.sm),
            Text(
              LocaleKeys.return_recv_hint.tr(),
              textAlign: TextAlign.center,
              style: AppTextStyles.caption.copyWith(color: c.text2),
            ),

            if (done != null) ...[
              const SizedBox(height: AppDimens.md),
              Container(
                padding: const EdgeInsets.all(AppDimens.sm + 4),
                decoration: BoxDecoration(
                  color: c.successBg,
                  borderRadius: BorderRadius.circular(AppDimens.rCard),
                  border: Border.all(color: c.success),
                ),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Icon(Icons.check_circle_outline,
                            size: 16, color: c.success),
                        const SizedBox(width: 6),
                        Expanded(
                          child: Text(done.lotNo, style: AppTextStyles.code),
                        ),
                      ],
                    ),
                    const SizedBox(height: 4),
                    Text(
                      LocaleKeys.return_recv_done.tr(
                          namedArgs: {'count': '${done.received}'}),
                      style: AppTextStyles.label,
                    ),
                    // Bỏ qua = con đã về trước đó hoặc thuộc phiếu khác. Nói
                    // ra để WH đối chiếu, không phải để báo lỗi.
                    if (done.skipped > 0)
                      Text(
                        LocaleKeys.return_recv_skipped.tr(
                            namedArgs: {'count': '${done.skipped}'}),
                        style:
                            AppTextStyles.caption.copyWith(color: c.warning),
                      ),
                  ],
                ),
              ),
              const SizedBox(height: AppDimens.sm),
              Text(
                LocaleKeys.return_recv_scan_more.tr(),
                textAlign: TextAlign.center,
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            ],
          ],
        ),
      ),
    );
  }
}
