﻿namespace SWMS_WebTool.Models.Responses
{
    public class PlanOrderNumberRespone
    {
        public string? PlanOrderNumber { get; set; }
    }
}
