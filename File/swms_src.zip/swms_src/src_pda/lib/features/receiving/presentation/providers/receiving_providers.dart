import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/receiving/data/datasources/receiving_history_local_data_source.dart';
import 'package:swms_finish_goods/features/receiving/data/datasources/receiving_remote_data_source.dart';
import 'package:swms_finish_goods/features/receiving/data/receiving_history_repository_impl.dart';
import 'package:swms_finish_goods/features/receiving/data/receiving_repository_impl.dart';
import 'package:swms_finish_goods/features/receiving/domain/repositories/receiving_history_repository.dart';
import 'package:swms_finish_goods/features/receiving/domain/repositories/receiving_repository.dart';
import 'package:swms_finish_goods/shared/presentation/providers/model_provider.dart';

part 'receiving_providers.g.dart';

@riverpod
ReceivingRemoteDataSource receivingRemoteDataSource(Ref ref) {
  final dio = ref.watch(dioProvider);
  return ReceivingRemoteDataSource(dio);
}

@riverpod
ReceivingRepository receivingRepository(Ref ref) {
  return ReceivingRepositoryImpl(
    ref.watch(receivingRemoteDataSourceProvider),
    ref.watch(modelRemoteDataSourceProvider),
  );
}

@riverpod
ReceivingHistoryLocalDataSource receivingHistoryLocalDataSource(Ref ref) {
  return ReceivingHistoryLocalDataSourceImpl(
    ref.watch(appLocalManagerProvider).requireValue,
  );
}

@riverpod
ReceivingHistoryRepository receivingHistoryRepository(Ref ref) {
  return ReceivingHistoryRepositoryImpl(
    ref.watch(receivingHistoryLocalDataSourceProvider),
  );
}
