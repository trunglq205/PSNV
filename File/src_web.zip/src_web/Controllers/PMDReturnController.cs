﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models.PMD;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class PMDReturnController : BaseController
    {
        private readonly ApiService _apiService;
        public PMDReturnController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] PMDReturnRecycleFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new PMDReturnRecycleFilter();
                var response = await _apiService.PMDReturnSearch(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<PMDReturnRecycleModel>();

                var model = new PMDReturnRecycleViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/PMDReturn/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }
    }
}
