/* =========================================================
   FLAPPY SANTA — BỘ MÔ PHỎNG (dùng chung logic với server)
   Drop-in: wwwroot/js/xmas-flappy-sim.js

   QUAN TRỌNG: file này phải GIỐNG HỆT logic của Helpers/XmasFlappySim.cs.
   Server chơi lại toàn bộ lượt chơi từ (seed + các tick bấm bay) để tự tính điểm,
   nên trình duyệt có sửa điểm cũng không có tác dụng.
   - Chỉ dùng số nguyên (không chia, không sin/cos) → JS và C# ra kết quả y hệt nhau.
   - Đơn vị: 1 đơn vị thế giới = 100 "điểm". Thế giới cao 600 đơn vị (60000).
   - 60 tick / giây.
   ========================================================= */
(function (root) {
    "use strict";

    // Độ khó TĂNG DẦN:
    //  - EASY cột đầu dễ: khe rộng, bay chậm; cột đầu tiên nằm đúng ngang tầm xuất phát.
    //  - Từ cột thứ EASY+1: mỗi cột khe hẹp lại GAP_DEC → chạm GAP_MIN ở khoảng cột thứ 10.
    //  - Từ điểm thứ EASY: mỗi điểm bay nhanh thêm SPEED_INC → chạm SPEED_MAX ở khoảng 10 điểm.
    var C = {
        TPS: 60,              // tick mỗi giây
        H: 60000,             // chiều cao thế giới
        GROUND: 56000,        // mặt đất (chạm là thua)
        BIRD_X: 22000,        // vị trí ngang cố định của ông già Noel
        HB_W: 2350,           // nửa bề rộng vùng va chạm
        HB_H: 1660,           // nửa bề cao vùng va chạm
        START_Y: 28000,
        G: 35,                // trọng lực / tick
        FLAP: -624,           // vận tốc khi bấm bay
        MAX_FALL: 693,
        PW: 7200,             // bề rộng cột người tuyết
        SPACING: 23000,       // khoảng cách giữa 2 cột
        FIRST_X: 80000,       // cột đầu tiên
        SPAWN_X: 200000,      // sinh cột trước cho tới mốc này
        TOP_MIN: 11200,       // mép trên của khe không cao hơn mức này
        GAP_BOTTOM_MAX: 44800,// mép dưới của khe không thấp hơn mức này
        EASY: 5,              // số cột / điểm đầu được "dễ"
        GAP0: 23000,          // độ cao khe ở các cột dễ
        GAP_DEC: 300,         // sau đó mỗi cột hẹp lại
        GAP_MIN: 18000,       // khe hẹp nhất
        SPEED0: 200,          // tốc độ lúc đầu
        SPEED_INC: 3,         // sau đó mỗi điểm nhanh thêm
        SPEED_MAX: 240,       // tốc độ tối đa
        MIN_FLAP_GAP: 3,      // 2 lần bấm phải cách nhau ít nhất 3 tick (chống macro)
        MAX_TICKS: 72000      // tối đa 20 phút
    };

    function Sim(seed) {
        this.s = seed | 0;
        this.y = C.START_Y;
        this.vy = 0;
        this.pipes = [];
        this.n = 0;           // số cột đã sinh (độ khó khe theo thứ tự cột)
        this.score = 0;
        this.t = 0;
        this.dead = false;
        this.lastFlap = -1000;
        this.flaps = [];
    }

    // mulberry32 — số nguyên 32 bit, giống hệt bản C#
    Sim.prototype.rng = function () {
        this.s = (this.s + 0x6D2B79F5) | 0;
        var t = Math.imul(this.s ^ (this.s >>> 15), 1 | this.s);
        t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
        return (t ^ (t >>> 14)) >>> 0;
    };

    // có được bấm bay ở tick hiện tại không
    Sim.prototype.canFlap = function () {
        return this.t - this.lastFlap >= C.MIN_FLAP_GAP;
    };

    // chạy 1 tick. flap = true nếu người chơi bấm bay ở tick này. Trả về true nếu vừa thua.
    Sim.prototype.step = function (flap) {
        if (this.dead) return true;
        var i, p;

        if (flap && this.canFlap()) {
            this.vy = C.FLAP;
            this.lastFlap = this.t;
            this.flaps.push(this.t);
        }
        this.vy += C.G;
        if (this.vy > C.MAX_FALL) this.vy = C.MAX_FALL;
        this.y += this.vy;
        if (this.y < C.HB_H) { this.y = C.HB_H; this.vy = 0; }

        var speed = this.score < C.EASY ? C.SPEED0 : C.SPEED0 + (this.score - C.EASY + 1) * C.SPEED_INC;
        if (speed > C.SPEED_MAX) speed = C.SPEED_MAX;
        for (i = 0; i < this.pipes.length; i++) {
            p = this.pipes[i];
            p.px = p.x;
            p.x -= speed;
        }
        while (this.pipes.length && this.pipes[0].x + C.PW < -30000) this.pipes.shift();

        var lastX = this.pipes.length ? this.pipes[this.pipes.length - 1].x : C.FIRST_X - C.SPACING;
        while (lastX < C.SPAWN_X) {
            lastX += C.SPACING;
            var gap = this.n < C.EASY ? C.GAP0 : C.GAP0 - (this.n - C.EASY + 1) * C.GAP_DEC;
            if (gap < C.GAP_MIN) gap = C.GAP_MIN;
            var top;
            if (this.n === 0) top = C.START_Y - (gap >> 1);   // cột đầu: khe ngang tầm xuất phát
            else top = C.TOP_MIN + (this.rng() % (C.GAP_BOTTOM_MAX - C.TOP_MIN - gap + 1));
            this.n++;
            this.pipes.push({ x: lastX, px: lastX, top: top, gap: gap, passed: false });
        }

        for (i = 0; i < this.pipes.length; i++) {
            p = this.pipes[i];
            if (!p.passed && p.x * 2 + C.PW <= C.BIRD_X * 2) { p.passed = true; this.score++; }   // tính điểm khi giữa cột qua giữa người chơi
        }

        var hit = this.y + C.HB_H >= C.GROUND;
        for (i = 0; i < this.pipes.length && !hit; i++) {
            p = this.pipes[i];
            if (C.BIRD_X + C.HB_W > p.x && C.BIRD_X - C.HB_W < p.x + C.PW &&
                (this.y - C.HB_H < p.top || this.y + C.HB_H > p.top + p.gap)) hit = true;
        }
        if (hit) { this.dead = true; return true; }
        this.t++;
        return false;
    };

    // mô phỏng lại cả lượt từ danh sách tick bấm bay (giống hệt server) — dùng để tự kiểm tra
    function replay(seed, flaps) {
        var sim = new Sim(seed), k = 0;
        while (!sim.dead && sim.t < C.MAX_TICKS) {
            var f = k < flaps.length && flaps[k] === sim.t;
            if (f) k++;
            sim.step(f);
        }
        return { score: sim.score, endTick: sim.t, dead: sim.dead };
    }

    var api = { C: C, Sim: Sim, replay: replay };
    if (typeof module !== "undefined" && module.exports) module.exports = api;
    else root.XmasFlappySim = api;
})(typeof window !== "undefined" ? window : this);
