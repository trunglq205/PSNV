﻿using Swms.FinishGoods.API.Features.OqcSamples.Api;

namespace Swms.FinishGoods.API.Features.OqcSamples.Business
{
    /// <summary>
    /// OQC lấy mẫu / trả mẫu theo payload (part_cards), phục vụ lấy mẫu trước/sau
    /// khi tạo pallet. Cập nhật boxes.oqc_status khi payload đã có trong boxes.
    /// </summary>
    public interface IOqcSampleService
    {
        /// <summary>Tra pallet + vị trí để trả mẫu về (theo payload, hoặc theo model+ngày).</summary>
        Task<OqcLocationResponse> GetLocationsAsync(OqcGetLocationsRequest request);

        /// <summary>Lấy mẫu: đặt các payload sang trạng thái đang kiểm.</summary>
        Task<OqcOkResponse> SampleAsync(OqcSampleActionRequest request);

        /// <summary>Trả mẫu: đặt các payload về trạng thái chưa kiểm.</summary>
        Task<OqcOkResponse> ReturnAsync(OqcReturnRequest request);

        /// <summary>Cập nhật trạng thái OQC (ok|ng...) cho các payload.</summary>
        Task<OqcOkResponse> UpdateStatusAsync(OqcUpdateStatusRequest request);
    }
}