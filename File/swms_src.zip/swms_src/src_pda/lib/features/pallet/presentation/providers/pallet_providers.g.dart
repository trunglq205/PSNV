// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pallet_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(palletRemoteDataSource)
final palletRemoteDataSourceProvider = PalletRemoteDataSourceProvider._();

final class PalletRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          PalletRemoteDataSource,
          PalletRemoteDataSource,
          PalletRemoteDataSource
        >
    with $Provider<PalletRemoteDataSource> {
  PalletRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'palletRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$palletRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<PalletRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  PalletRemoteDataSource create(Ref ref) {
    return palletRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PalletRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PalletRemoteDataSource>(value),
    );
  }
}

String _$palletRemoteDataSourceHash() =>
    r'3270775767e8e7c78b5a70447d2a6243ac8a7b85';

@ProviderFor(palletRepository)
final palletRepositoryProvider = PalletRepositoryProvider._();

final class PalletRepositoryProvider
    extends
        $FunctionalProvider<
          PalletRepository,
          PalletRepository,
          PalletRepository
        >
    with $Provider<PalletRepository> {
  PalletRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'palletRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$palletRepositoryHash();

  @$internal
  @override
  $ProviderElement<PalletRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  PalletRepository create(Ref ref) {
    return palletRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PalletRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PalletRepository>(value),
    );
  }
}

String _$palletRepositoryHash() => r'65cd353ba659ee245e5fdfec27371c9d18174ef1';

/// Chi tiết pallet đầy đủ (thùng + lịch sử) — dùng cho màn Pallet Detail,
/// Tìm thùng bị mất, Tách pallet. Family theo lot_no để mỗi mã 1 lần gọi;
/// sau mutation (lưu kho, tách...) các notifier `ref.invalidate` provider này.

@ProviderFor(pallet)
final palletProvider = PalletFamily._();

/// Chi tiết pallet đầy đủ (thùng + lịch sử) — dùng cho màn Pallet Detail,
/// Tìm thùng bị mất, Tách pallet. Family theo lot_no để mỗi mã 1 lần gọi;
/// sau mutation (lưu kho, tách...) các notifier `ref.invalidate` provider này.

final class PalletProvider
    extends $FunctionalProvider<AsyncValue<Pallet>, Pallet, FutureOr<Pallet>>
    with $FutureModifier<Pallet>, $FutureProvider<Pallet> {
  /// Chi tiết pallet đầy đủ (thùng + lịch sử) — dùng cho màn Pallet Detail,
  /// Tìm thùng bị mất, Tách pallet. Family theo lot_no để mỗi mã 1 lần gọi;
  /// sau mutation (lưu kho, tách...) các notifier `ref.invalidate` provider này.
  PalletProvider._({
    required PalletFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'palletProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$palletHash();

  @override
  String toString() {
    return r'palletProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<Pallet> $createElement($ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<Pallet> create(Ref ref) {
    final argument = this.argument as String;
    return pallet(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is PalletProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$palletHash() => r'8adff5969ce0f8f683628c01844bee91b5a9038d';

/// Chi tiết pallet đầy đủ (thùng + lịch sử) — dùng cho màn Pallet Detail,
/// Tìm thùng bị mất, Tách pallet. Family theo lot_no để mỗi mã 1 lần gọi;
/// sau mutation (lưu kho, tách...) các notifier `ref.invalidate` provider này.

final class PalletFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<Pallet>, String> {
  PalletFamily._()
    : super(
        retry: null,
        name: r'palletProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Chi tiết pallet đầy đủ (thùng + lịch sử) — dùng cho màn Pallet Detail,
  /// Tìm thùng bị mất, Tách pallet. Family theo lot_no để mỗi mã 1 lần gọi;
  /// sau mutation (lưu kho, tách...) các notifier `ref.invalidate` provider này.

  PalletProvider call(String lotNo) =>
      PalletProvider._(argument: lotNo, from: this);

  @override
  String toString() => r'palletProvider';
}
