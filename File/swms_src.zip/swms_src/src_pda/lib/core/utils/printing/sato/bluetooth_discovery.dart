import 'package:flutter_bluetooth_serial_plus/flutter_bluetooth_serial_plus.dart';

import 'package:swms_finish_goods/core/utils/printing/printer.dart';

/// Tìm máy in — tách khỏi [Printer] vì đây là việc của TRANSPORT
/// (Bluetooth), không phải của protocol (SBPL). Khi nào chuyển sang máy in
/// Wi-Fi thì thay file này, driver SATO không đổi.
class BluetoothDiscovery {
  const BluetoothDiscovery();

  /// Bluetooth đang bật hay không.
  Future<bool> get isEnabled async =>
      await FlutterBluetoothSerial.instance.isEnabled ?? false;

  /// Hiện dialog hệ thống xin bật Bluetooth.
  Future<bool> requestEnable() async =>
      await FlutterBluetoothSerial.instance.requestEnable() ?? false;

  /// Danh sách thiết bị đã ghép đôi trong Settings của Android.
  ///
  /// Không tự scan: máy in công nghiệp luôn được pair sẵn 1 lần khi cấp
  /// thiết bị cho công nhân, scan chỉ làm chậm và tốn quyền Location.
  Future<List<PrinterDevice>> pairedDevices() async {
    if (!await isEnabled) {
      throw const PrinterException(
        PrinterErrorType.bluetoothOff,
        message: 'Bluetooth đang tắt',
      );
    }
    try {
      final devices = await FlutterBluetoothSerial.instance.getBondedDevices();
      return devices
          .map((d) => PrinterDevice(
        name: d.name ?? d.address,
        macAddress: d.address,
      ))
          .toList(growable: false);
    } on Exception catch (e) {
      throw PrinterException(PrinterErrorType.permission, cause: e);
    }
  }
}