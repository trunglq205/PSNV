﻿namespace SWMS_WebTool.Models
{
    public class AbnormalReportEmailConfig
    {
        // Member
        public List<string> MCSEmails { get; set; }
        public List<string> IQCEmails { get; set; }
        public List<string> PUSLocalEmails { get; set; }
        public List<string> PUSOverseaEmails { get; set; }

        // Leader
        public List<string> MCSLeaderEmails { get; set; }
        public List<string> IQCLeaderEmails { get; set; }
        public List<string> PUSLeaderLocalEmails { get; set; }
        public List<string> PUSLeaderOverseaEmails { get; set; }
    }

    public class AbnormalReportEmailConfigRequest
    {
        public List<string> MCS { get; set; } = new();
        public List<string> IQC { get; set; } = new();
        public List<string> PUSLocal { get; set; } = new();
        public List<string> PUSOversea { get; set; } = new();
        public List<string> MCSLeader { get; set; } = new();
        public List<string> IQCLeader { get; set; } = new();
        public List<string> PUSLeaderLocal { get; set; } = new();
        public List<string> PUSLeaderOversea { get; set; } = new();
    }
}
