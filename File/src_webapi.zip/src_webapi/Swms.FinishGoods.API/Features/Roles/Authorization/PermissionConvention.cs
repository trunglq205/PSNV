using Microsoft.AspNetCore.Mvc.ApplicationModels;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Quét mọi RequirePermission (generic & by-code) trên controller/action lúc khởi động,
/// đối chiếu với PermissionCatalog. Code lạ ⟹ ném lỗi ngay (fail-fast).
///
/// Với bản generic [RequirePermission&lt;T&gt;], policy đã được CodeOf&lt;T&gt;() resolve
/// từ catalog nên gần như không thể sai; convention này là lớp chặn bổ sung cho
/// bản by-code (string động) và để bắt sớm mọi bất nhất.
///
/// Đăng ký: services.AddControllers(o => o.Conventions.Add(new PermissionConvention()));
/// </summary>
public sealed class PermissionConvention : IControllerModelConvention
{
    public void Apply(ControllerModel controller)
    {
        CheckPolicies(controller.Selectors, $"controller {controller.ControllerName}");
        foreach (var action in controller.Actions)
            CheckPolicies(action.Selectors,
                $"{controller.ControllerName}.{action.ActionName}");
    }

    private static void CheckPolicies(
        IList<SelectorModel> selectors, string where)
    {
        foreach (var sel in selectors)
        {
            // EndpointMetadata chứa các AuthorizeAttribute đã set Policy
            foreach (var meta in sel.EndpointMetadata.OfType<Microsoft.AspNetCore.Authorization.IAuthorizeData>())
            {
                var code = PermissionPolicy.ExtractPermission(meta.Policy ?? "");
                if (code is null) continue;
                foreach (var c in code.Split('|'))
                    if (!PermissionCatalog.IsValid(c))
                        throw new InvalidOperationException(
                        $"RequirePermission dùng quyền KHÔNG có trong Perms: " +
                        $"'{code}' tại {where}. Kiểm tra lại cây Perms hoặc chính tả.");
            }
        }
    }
}