/// Loại đối tượng mà mã quét trỏ tới (khớp field `type` của API).
enum ScanType {
  pallet,
  box,
  serial,
  recvLocation,
  storageLocation,
  model,
  notFound;

  static ScanType fromApi(String? type) => switch (type) {
        'pallet' => ScanType.pallet,
        'box' => ScanType.box,
        'serial' => ScanType.serial,
        'recv_location' => ScanType.recvLocation,
        'storage_location' => ScanType.storageLocation,
        'model' => ScanType.model,
        _ => ScanType.notFound,
      };
}

/// Kết quả phân loại mã quét (GET /api/scan/resolve).
class ScanResult {
  final String code;
  final ScanType type;
  final int? id;

  /// Chỉ có với vị trí: "RECV" | "VANNING" | "STORAGE"...
  final String? areaCode;

  const ScanResult({
    required this.code,
    required this.type,
    this.id,
    this.areaCode,
  });

  bool get isFound => type != ScanType.notFound;
}
