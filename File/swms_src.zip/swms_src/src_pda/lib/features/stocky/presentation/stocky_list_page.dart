﻿import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_tab_bar.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';
import 'package:swms_finish_goods/features/stocky/presentation/providers/stocky_providers.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Xe Stocky trong kho — CHỈ ĐỌC.
//  Xem xe nào đang ở đâu, xe nào rỗng, xe nào có hàng.
//  Lọc Tất cả / Có hàng / Rỗng. Kéo xuống để tải lại.
//  Không quét gì ở đây: quét nhập/xuất nằm ở màn Xe Stocky.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class StockyListPage extends ConsumerStatefulWidget {
  const StockyListPage({super.key});

  @override
  ConsumerState<StockyListPage> createState() => _StockyListPageState();
}

class _StockyListPageState extends ConsumerState<StockyListPage> {
  StockyFilter _filter = StockyFilter.all;

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(stockyCartListProvider(_filter.name));

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.stocky_inwh_title.tr(),
        actions: [
          IconButton(
            tooltip: LocaleKeys.stocky_refresh.tr(),
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(stockyCartListProvider),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
                AppDimens.md, AppDimens.md, AppDimens.md, AppDimens.sm),
            child: AppTabBar<StockyFilter>(
              expanded: true,
              items: [
                for (final f in StockyFilter.values)
                  AppTabItem(value: f, label: f.labelKey.tr()),
              ],
              selected: _filter,
              // Mỗi bộ lọc một provider family riêng nên dữ liệu đã tải của bộ
              // lọc cũ vẫn còn — đổi qua đổi lại không gọi lại API.
              onChanged: (f) => setState(() => _filter = f),
            ),
          ),
          Expanded(
            child: switch (async) {
              AsyncLoading() => const AppLoading(),
              AsyncError(:final error) => AppErrorView.page(
                  message: ref.read(errorHandlerProvider).getMessage(error),
                  onRetry: () => ref.invalidate(stockyCartListProvider),
                ),
              AsyncValue(:final value) => _CartList(
                  carts: value ?? const [],
                  onRefresh: () async => ref.invalidate(stockyCartListProvider),
                ),
            },
          ),
        ],
      ),
    );
  }
}

class _CartList extends StatelessWidget {
  final List<StockyCart> carts;
  final Future<void> Function() onRefresh;

  const _CartList({required this.carts, required this.onRefresh});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    if (carts.isEmpty) {
      // Vẫn bọc RefreshIndicator: danh sách rỗng là lúc người dùng hay muốn
      // tải lại nhất, mà không bọc thì kéo xuống không có tác dụng gì.
      return RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 80),
              child: Text(
                LocaleKeys.stocky_inwh_empty.tr(),
                textAlign: TextAlign.center,
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(
            AppDimens.md, 0, AppDimens.md, AppDimens.md),
        itemCount: carts.length + 1,
        separatorBuilder: (_, _) => const SizedBox(height: 6),
        itemBuilder: (context, i) {
          if (i == 0) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                LocaleKeys.stocky_list_count
                    .tr(namedArgs: {'count': '${carts.length}'}),
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            );
          }
          return _CartTile(cart: carts[i - 1]);
        },
      ),
    );
  }
}

class _CartTile extends StatelessWidget {
  final StockyCart cart;
  const _CartTile({required this.cart});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final empty = cart.isEmpty;

    return AppCard(
      padding: const EdgeInsets.all(AppDimens.sm + 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(
            empty ? Icons.shopping_cart_outlined : Icons.shopping_cart,
            size: 20,
            color: empty ? c.text3 : AppColors.primary,
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        cart.code,
                        style: AppTextStyles.code.copyWith(
                          fontSize: 13,
                          fontWeight: FontWeight.w700,
                          color: c.text1,
                        ),
                      ),
                    ),
                    empty
                        ? StatusPill.neutral(context,
                            label: LocaleKeys.stocky_cart_empty.tr())
                        : StatusPill.success(context,
                            label: LocaleKeys.stocky_cart_loaded.tr()),
                  ],
                ),
                if (cart.name != null && cart.name!.isNotEmpty) ...[
                  const SizedBox(height: 2),
                  Text(cart.name!,
                      style: AppTextStyles.caption.copyWith(color: c.text2)),
                ],
                const SizedBox(height: 6),

                // VỊ TRÍ — thứ người dùng mở màn này để xem, nên đặt ngay dưới mã.
                //
                // Xe ở FA vẫn nằm trong danh sách này (status vẫn
                // in_warehouse), nên phải có dấu hiệu nhìn ra ngay: chip FA
                // đứng trước mã ô. Thiếu nó thì xe ở FA trông y hệt xe đang
                // đậu trong kho.
                Row(
                  children: [
                    Icon(
                      cart.atFa ? Icons.factory_outlined : Icons.place_outlined,
                      size: 14,
                      color: cart.atFa ? AppColors.warning : c.text3,
                    ),
                    const SizedBox(width: 4),
                    if (cart.atFa) ...[
                      StatusPill.warning(
                        context,
                        label: LocaleKeys.stocky_at_fa.tr(),
                      ),
                      const SizedBox(width: 6),
                    ],
                    Expanded(
                      child: Text(
                        cart.locatorCode == null || cart.locatorCode!.isEmpty
                            ? LocaleKeys.stocky_no_locator.tr()
                            : (cart.areaCode == null || cart.areaCode!.isEmpty
                                ? cart.locatorCode!
                                : '${cart.locatorCode!} · ${cart.areaCode!}'),
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.label.copyWith(
                          color: cart.locatorCode == null ? c.text3 : c.text1,
                        ),
                      ),
                    ),
                  ],
                ),

                if (!empty) ...[
                  const SizedBox(height: 4),
                  Text(
                    LocaleKeys.stocky_cart_meta.tr(namedArgs: {
                      'model': cart.model ?? '-',
                      'lots': '${cart.lotCount}',
                      'qty': '${cart.qty}',
                    }),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.caption.copyWith(color: c.text3),
                  ),
                  if (cart.palletCode != null && cart.palletCode!.isNotEmpty)
                    Text(
                      cart.palletCode!,
                      style: AppTextStyles.caption.copyWith(color: c.text3),
                    ),
                ],

                // Hàng đã có phiếu xuất mà xe không còn ô: hệ thống vẫn ghi
                // hàng trên xe nhưng hàng đã rời kho — cảnh báo để đi đối chiếu.
                if (cart.siNo != null &&
                    cart.siNo!.isNotEmpty &&
                    (cart.locatorCode == null || cart.locatorCode!.isEmpty)) ...[
                  const SizedBox(height: 6),
                  StatusPill.warning(
                    context,
                    label: LocaleKeys.stocky_shipped_warn
                        .tr(namedArgs: {'si': cart.siNo!}),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}
