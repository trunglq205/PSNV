// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pick_task_detail_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PickTaskDetailModel _$PickTaskDetailModelFromJson(Map<String, dynamic> json) =>
    PickTaskDetailModel(
      task: PickTaskModel.fromJson(json['task'] as Map<String, dynamic>),
      pcsPerBox: (json['pcsPerBox'] as num?)?.toInt() ?? 0,
      boxes:
          (json['boxes'] as List<dynamic>?)
              ?.map((e) => PickBoxModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
    );

PickBoxModel _$PickBoxModelFromJson(Map<String, dynamic> json) => PickBoxModel(
  boxId: (json['boxId'] as num).toInt(),
  boxNo: json['boxNo'] as String,
  productionDate: json['productionDate'] == null
      ? null
      : DateTime.parse(json['productionDate'] as String),
  qty: (json['qty'] as num?)?.toInt() ?? 0,
  state: json['state'] as String?,
);

Map<String, dynamic> _$ConfirmPalletRequestToJson(
  ConfirmPalletRequest instance,
) => <String, dynamic>{'palletCode': instance.palletCode};

Map<String, dynamic> _$PickBoxRequestToJson(PickBoxRequest instance) =>
    <String, dynamic>{'boxNo': instance.boxNo};

Map<String, dynamic> _$StageVanningRequestToJson(
  StageVanningRequest instance,
) => <String, dynamic>{
  'palletCode': instance.palletCode,
  'locatorCode': instance.locatorCode,
};
