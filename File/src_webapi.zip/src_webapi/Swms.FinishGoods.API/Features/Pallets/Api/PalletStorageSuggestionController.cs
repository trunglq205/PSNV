using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.Pallets.Business;

namespace Swms.FinishGoods.API.Features.Pallets.Api
{
    /// <summary>
    /// Gợi ý vị trí lưu kho — tách khỏi <c>GET by-lot-no?include=suggestion</c>.
    ///
    /// Lý do tách: luồng này cần thêm tham số chiều cao pallet (không thuộc dữ liệu lot),
    /// trả về nhiều thông tin hơn (khu + tầng + last lot + phương án thay thế), và có
    /// chi phí truy vấn cao hơn hẳn phần còn lại của by-lot-no — nhét chung sẽ làm màn
    /// Vị trí tạm và Quick Scan phải trả giá cho thứ chúng không dùng.
    ///
    /// Controller riêng nhưng vẫn dùng prefix api/pallets để PDA không phải đổi base URL.
    /// </summary>
    [ApiController]
    [Route("api/pallets")]
    public class PalletStorageSuggestionController : ControllerBase
    {
        private readonly IStorageSuggestionService _service;
        public PalletStorageSuggestionController(IStorageSuggestionService service)
            => _service = service;

        /// <summary>
        /// Gợi ý vị trí lưu kho theo mã quét (cột wms.pallets.pallet_id).
        /// Đây là endpoint PDA dùng — quét xong là có mã, không cần biết id số.
        /// </summary>
        /// <param name="lotNo">Mã pallet 12 số quét từ tem.</param>
        /// <param name="palletHeightCm">
        /// Chiều cao pallet (cm), dùng khi model chưa khai suggest_area/suggest_rack_row.
        /// Không gửi thì bỏ qua bước lọc tầng theo chiều cao và trả cảnh báo.
        /// </param>
        [HttpGet("by-lot-no/{lotNo}/storage-suggestion")]
        [RequirePermission<Perms.Pda.PdaStorage.Putaway>]
        public async Task<ActionResult<StorageSuggestionResponse>> SuggestByLotNo(
            string lotNo, [FromQuery] int? palletHeightCm)
            => Ok(await _service.SuggestByLotNoAsync(lotNo, palletHeightCm));

        /// <summary>Cùng chức năng, tra theo khoá số — dùng cho web/admin đã có id.</summary>
        [HttpGet("{id:long}/storage-suggestion")]
        [RequirePermission<Perms.Pda.PdaStorage.Putaway>]
        public async Task<ActionResult<StorageSuggestionResponse>> SuggestById(
            long id, [FromQuery] int? palletHeightCm)
            => Ok(await _service.SuggestByIdAsync(id, palletHeightCm));
    }
}
