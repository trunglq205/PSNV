﻿using Newtonsoft.Json;

namespace SWMS_WebTool.Models.Responses
{
    public class LoginRespone
    {
        public string? UserID { get; set; }
        public string? UserFullName { get; set; }
        [JsonProperty("SectionID")]
        public Section Section { get; set; }
        [JsonProperty("PositionUserID")]
        public Role Role { get; set; }
        [JsonProperty("lstWebRole")]
        public List<WebRole> WebRole { get; set; }
        public string? AssessToken { get; set; }
    }
}
