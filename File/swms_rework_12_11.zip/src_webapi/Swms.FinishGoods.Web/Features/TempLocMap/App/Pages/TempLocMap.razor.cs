﻿using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.Extensions.Localization;
using Microsoft.JSInterop;
using Swms.FinishGoods.Web.Features.TempLocMap.Business;
using Swms.FinishGoods.Web.Features.TempLocMap.Business.Models;
using Swms.FinishGoods.Web.Features.TempLocMap.Client;
using Swms.FinishGoods.Web.Features.MapView.Business;
using Swms.FinishGoods.Web.Features.MapView.Business.Models;
using Swms.FinishGoods.Web.Features.WarehouseAreas.Business;
using Swms.FinishGoods.Web.Features.WarehouseAreas.Business.Models;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.App.Toast;
using System.Text.Json;

namespace Swms.FinishGoods.Web.Features.TempLocMap.App.Pages;

// Trang Vị trí tạm. C# lo DATA + i18n + gọi API (Refit); JS lo vẽ/tương tác canvas.
// Luồng: OnAfterRender lần đầu -> GetLayout -> init JS (truyền layout + bảng dịch).
// JS callback ngược: OnSaveLayout / OnChangeStatus / OnToast.
public partial class TempLocMap : IAsyncDisposable
{
    [Inject] private ITempLocMapBusiness Business { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;
    [Inject] private ToastService Toast { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private AuthenticationStateProvider AuthState { get; set; } = default!;

    [Inject] private IWarehouseAreasBusiness MapsBusiness { get; set; } = default!;
    [Inject] private IMapViewBusiness ViewApi { get; set; } = default!;

    // Danh sách map loại "receiving" cho dropdown.
    private List<WarehouseAreaSummaryDto> _maps = new();
    private MapViewSummaryDto? _summary;

    private ElementReference _mapEl;
    private DotNetObjectReference<TempLocMap>? _ref;
    private string _areaCode = "RECEIVING";
    private string? _error;
    private bool _inited;

    private const string StorageKey = "swms.mapview.receiving";

    protected override async Task OnInitializedAsync()
    {
        try
        {
            _maps = await MapsBusiness.ListAsync("receiving");
            if (_maps.Count > 0 && !_maps.Any(m => m.AreaCode == _areaCode))
                _areaCode = _maps[0].AreaCode;
        }
        catch { /* dropdown lỗi -> vẫn xem map mặc định */ }
    }

    /// <summary>Engine gọi khi đổi bản đồ trong panel trái.</summary>
    [JSInvokable]
    public async Task OnMapSelectedJs(string areaCode)
    {
        if (string.IsNullOrWhiteSpace(areaCode) || areaCode == _areaCode) return;
        _areaCode = areaCode;
        await OnMapChanged();
    }

    private async Task RestoreLastMapAsync()
    {
        try
        {
            var saved = await JS.InvokeAsync<string?>("localStorage.getItem", StorageKey);
            if (!string.IsNullOrWhiteSpace(saved) && _maps.Any(m => m.AreaCode == saved))
                _areaCode = saved!;
        }
        catch { }
    }

    private async Task RememberMapAsync()
    {
        try { await JS.InvokeVoidAsync("localStorage.setItem", StorageKey, _areaCode); }
        catch { }
    }

    /// <summary>Đổi map trong dropdown -> huỷ canvas cũ, dựng lại với map mới.</summary>
    /// <summary>Người dùng đổi bản đồ trong dropdown.</summary>
    private async Task OnMapSelected(ChangeEventArgs e)
    {
        var code = e.Value?.ToString();
        if (string.IsNullOrWhiteSpace(code) || code == _areaCode) return;
        _areaCode = code;
        await OnMapChanged();
    }

    private async Task OnMapChanged()
    {
        _error = null;
        await RememberMapAsync();
        try { await JS.InvokeVoidAsync("swmsTempLocMap.destroy", _mapEl); } catch { }
        _inited = false;
        StateHasChanged();
        await InitMapAsync();
    }

    protected override async Task OnAfterRenderAsync(bool firstRender)
    {
        if (!firstRender || _inited || _error is not null) return;
        await RestoreLastMapAsync();
        StateHasChanged();
        await InitMapAsync();
    }

    private async Task InitMapAsync()
    {
        _inited = true;

        var r = await ViewApi.GetAsync(_areaCode);
        _summary = r.Value?.Summary;
        if (!r.IsSuccess || r.Value is null)
        {
            _error = r.ErrorMessage ?? L["TempLoc.Load.Failed"];
            StateHasChanged();
            return;
        }

        _ref = DotNetObjectReference.Create(this);

        // Đã đăng nhập chưa? Chưa thì khoá tab Chỉnh sửa (chỉ cho Vận hành).
        // Trang xem trạng thái: KHÔNG cho sửa layout. Muốn vẽ/sửa -> vào Map Design.
        const bool canEdit = false;

        var opts = new
        {
            layout = ToEngineLayout(r.Value),
            i18n = BuildI18n(),
            canEdit,
            areaCode = _areaCode,
            mapType = "receiving",                 // receiving: chú thích hiện đủ mọi trạng thái
            // Panel trái của engine dựng dropdown chọn bản đồ + thống kê chiếm chỗ.
            maps = _maps.Select(m => new { areaCode = m.AreaCode, areaName = m.AreaName }).ToList(),
            summary = _summary,
            refreshUrl = $"/receiving-map/refresh?area={_areaCode}",
            refreshIntervalMs = 120000   // 2 phút
        };

        try
        {
            await JS.InvokeVoidAsync("swmsTempLocMap.init", _mapEl, _ref, opts);
        }
        catch (JSException ex)
        {
            // Lỗi phía JS không đi qua Business — vẫn giữ try/catch riêng.
            _error = $"[TempLocMap] {ex.Message}";
            StateHasChanged();
        }
    }

    // Chuẩn hoá layout -> DTO ẩn danh mà JS hiểu (dùng chung init + refresh).
    /// <summary>Chuyển layout chung (rack + pallet + zone) sang format cell của engine.</summary>
    private static object ToEngineLayout(MapViewLayoutDto l) => new
    {
        areaCode = l.AreaCode,
        cols = l.Cols,
        rows = l.Rows,
        cellMeters = l.CellMeters,
        summary = l.Summary,
        cells = l.Blocks.Select(b => new
        {
            id = b.Id,
            code = b.Kind == "rack" ? b.RackCode : b.LocatorCode,
            cellType = b.Kind,
            gridX = b.GridX, gridY = b.GridY, gridW = b.GridW, gridH = b.GridH,
            arrow = b.Arrow, color = b.Color, label = b.Label,
            status = b.Status, model = b.Model, lotNo = (string?)null,
            sortOrder = 0, isUrgent = b.IsUrgent,
            rackCode = b.RackCode, totalSlots = b.TotalSlots, occupiedSlots = b.OccupiedSlots,
            positions = b.Positions.Select(p => new { position = p.Position, total = p.Total, occupied = p.Occupied }),
            lots = b.Lots.Select(x => new
            {
                lotId = x.LotId, lotNo = x.PalletId,
                inspectionStatus = x.Status, mappedStatus = x.Status,
                isUrgent = x.IsUrgent, boxCount = x.BoxCount,
                models = x.Model, productionDate = x.ProductionDate,
                // Dấu RW/RB — JS vẽ chip cạnh Pallet ID. ĐÂY mới là đường dữ
                // liệu của tab Vận hành (qua IMapViewApi); BuildLayoutDto bên
                // dưới là đường của chế độ thiết kế. Thiếu một trong hai là dấu
                // mất ở đúng màn đang xem mà không báo gì.
                disposition = x.Disposition
            })
        })
    };

    private static object BuildLayoutDto(Business.Models.MapLayoutDto layout) => new
    {
        areaCode = layout.AreaCode,
        cols = layout.Cols,
        rows = layout.Rows,
        cellMeters = layout.CellMeters,
        cells = layout.Cells.Select(c => new
        {
            id = c.Id,
            code = c.Code,
            cellType = c.CellType,
            gridX = c.GridX,
            gridY = c.GridY,
            gridW = c.GridW,
            gridH = c.GridH,
            arrow = c.Arrow,
            color = c.Color,
            label = c.Label,
            status = c.Status,
            model = c.Model,
            lotNo = c.LotNo,
            sortOrder = c.SortOrder,
            isUrgent = c.IsUrgent,
            lots = c.Lots == null ? null : c.Lots.Select(x => new
            {
                lotId = x.LotId,
                lotNo = x.LotNo,
                inspectionStatus = x.InspectionStatus,
                mappedStatus = x.MappedStatus,
                isUrgent = x.IsUrgent,
                boxCount = x.BoxCount,
                models = x.Models,
                productionDate = x.ProductionDate,
                // Dấu RW/RB — JS vẽ chip cạnh Pallet ID trong dialog danh sách.
                disposition = x.Disposition
            })
        })
    };

    // Bảng dịch: mọi key TempLoc.* mà JS cần -> chuỗi đã localize.
    private Dictionary<string, string> BuildI18n()
    {
        var keys = new[]
        {
            // nhãn khối thống kê chiếm chỗ ở panel trái
            "MapView.Sum.Title","MapView.Sum.Occupied","MapView.Sum.Free","MapView.Sum.Total",
            "TempLoc.Title","TempLoc.Subtitle","TempLoc.ModeView","TempLoc.ModeEdit",
            "TempLoc.Lots.Title","TempLoc.Lots.Empty","TempLoc.Lots.Boxes","TempLoc.Lots.DblClickHint","TempLoc.Lots.BoxCol","TempLoc.Lots.DateCol","TempLoc.Op.ModelSearch","TempLoc.Op.ModelPlaceholder","TempLoc.Op.StatusTitle","TempLoc.Op.NewLotsTitle","TempLoc.Op.NoNewLots","TempLoc.Op.FoundAt","TempLoc.Op.NotFound","TempLoc.Rt.Fresh","TempLoc.Rt.Stale",
            "TempLoc.PrintQR","TempLoc.New","TempLoc.Save","TempLoc.Saved",
            "TempLoc.Tool.Section","TempLoc.Tool.Select","TempLoc.Tool.Erase","TempLoc.Tool.DrawSection",
            "TempLoc.Tool.Pallet","TempLoc.Tool.Zone","TempLoc.Tool.PalletRow","TempLoc.Tool.UtilSection",
            "TempLoc.Tool.Renumber","TempLoc.Tool.Hint",
            "TempLoc.Insp.Title","TempLoc.Insp.CellInfo","TempLoc.Insp.Hint","TempLoc.Insp.Empty","TempLoc.Insp.ClickHint",
            "TempLoc.Field.CellType","TempLoc.Field.Status","TempLoc.Field.StatusQuick","TempLoc.Field.PlName",
            "TempLoc.Field.Model","TempLoc.Field.Arrow","TempLoc.Field.ZoneColor","TempLoc.Field.ZoneLabel",
            "TempLoc.Field.Pos","TempLoc.Field.Size","TempLoc.Field.Position","TempLoc.Field.DirLabel",
            "TempLoc.ZonePlaceholder","TempLoc.ZoneCell","TempLoc.ZoneNoPallet",
            "TempLoc.Btn.Dup","TempLoc.Btn.Del","TempLoc.Btn.PrintOne","TempLoc.Btn.PrintThis",
            "TempLoc.Status.Empty","TempLoc.Status.Urgent","TempLoc.Status.NotInspected","TempLoc.Status.UnderInspection",
            "TempLoc.Status.Ng","TempLoc.Status.PendingResult","TempLoc.Status.InspectionExempt","TempLoc.Status.Pass",
            "TempLoc.Dir.Up","TempLoc.Dir.Down","TempLoc.Dir.Left","TempLoc.Dir.Right",
            "TempLoc.TotalCells","TempLoc.Legend",
            "TempLoc.Toast.Undo","TempLoc.Toast.SampleLoaded","TempLoc.Toast.BlankCreated","TempLoc.Toast.NoPrint",
            "TempLoc.Toast.Created","TempLoc.Toast.Renumbered",
            "TempLoc.Modal.New","TempLoc.Modal.AreaName","TempLoc.Modal.Size","TempLoc.Modal.NewHint",
            "TempLoc.Modal.LoadSample","TempLoc.Modal.CreateBlank","TempLoc.Modal.Cancel",
            "TempLoc.Row.Title","TempLoc.Row.Count","TempLoc.Row.Direction","TempLoc.Row.Vertical",
            "TempLoc.Row.Horizontal","TempLoc.Row.StartName","TempLoc.Row.ArrowDir","TempLoc.Row.Create","TempLoc.Arrow.None",
            "TempLoc.Print.Title","TempLoc.Print.Hint","TempLoc.Print.Scope","TempLoc.Print.ScopeAll",
            "TempLoc.Print.ScopeSel","TempLoc.Print.ScopeRange","TempLoc.Print.RangeLabel","TempLoc.Print.Go",
        };
        var d = new Dictionary<string, string>(keys.Length);
        foreach (var k in keys) d[k] = L[k];
        return d;
    }

    // ---- callback từ JS ----

    [JSInvokable]
    public async Task OnSaveLayout(string payloadJson)
    {
        var dto = JsonSerializer.Deserialize<SaveLayoutDto>(payloadJson,
            new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

        if (dto is null)
        {
            Toast.Error(L["TempLoc.Toast.EmptyLayout"]);
            return;
        }

        var r = await Business.SaveLayoutAsync(_areaCode, dto);
        Toast.Show(r.IsSuccess ? L["TempLoc.Saved"] : r.ErrorMessage ?? L["TempLoc.Toast.SaveFailed"]);
        await InvokeAsync(StateHasChanged);
    }

    [JSInvokable]
    public async Task OnChangeStatus(string code, string status, string? model, string? lotNo)
    {
        var r = await Business.ChangeStatusAsync(code, status, model, lotNo);
        if (!r.IsSuccess)
            Toast.Error(r.ErrorMessage ?? L["TempLoc.Toast.StatusFailed"]);
    }

    [JSInvokable]
    public void OnToast(string message) => Toast.Success(message);

    public async ValueTask DisposeAsync()
    {
        try { await JS.InvokeVoidAsync("swmsTempLocMap.destroy", _mapEl); } catch { }
        _ref?.Dispose();
    }
}