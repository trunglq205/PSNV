using Refit;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Client;

/// <summary>
/// HTTP của màn so tồn SWMS ↔ HD soft: đọc tồn HD soft + các thao tác pallet
/// mà nút xử lý chênh lệch gọi. Tồn SWMS đọc qua IInventoryApi của màn Tồn kho.
/// </summary>
public interface IHdSoftCompareApi
{
    // ── HD soft ──

    /// <summary>Pallet đang tồn trong HD soft (mỗi dòng = 1 pallet tại 1 vị trí).</summary>
    [Get("/api/hdsoft/pallets/in-stock")]
    Task<List<HdSoftPalletStockDto>> GetHdSoftPalletsInStockAsync([Query] string? warehouse = null);

    /// <summary>Đồng bộ vị trí 1 pallet theo vị trí đang tồn bên HD soft.</summary>
    [Post("/api/pallets/by-lot-no/{lotNo}/hdsoft-sync")]
    Task<HdSoftSyncResultDto> SyncHdSoftLocatorAsync(string lotNo);

    // ── Foss ──

    /// <summary>Bổ sung thùng / serial Foss còn thiếu. 404 = không có trên Foss; 422 = box_count / thẻ in / đã xuất.</summary>
    [Post("/api/pallets/by-lot-no/{lotNo}/foss-top-up")]
    Task<FossTopUpResultDto> TopUpFromFossAsync(string lotNo);

    // ── Thao tác pallet SWMS (API Pallets sẵn có) ──

    [Post("/api/pallets")]
    Task<CreatePalletResultDto> CreatePalletAsync([Body] CreatePalletRequestDto request);

    [Delete("/api/pallets/{id}")]
    Task DeletePalletAsync(long id);

    /// <summary>Xoá thùng khỏi pallet serial / box_line. 409 = dữ liệu vừa đổi; 422 = box_count / chọn hết thùng.</summary>
    [Post("/api/pallets/{id}/boxes/delete")]
    Task<DeleteBoxesResultDto> DeleteBoxesAsync(long id, [Body] DeleteBoxesRequestDto request);

    [Put("/api/pallets/{id}/locator")]
    Task<LocatorChangeResultDto> AssignLocatorAsync(long id, [Body] AssignLocatorRequestDto request);

    /// <summary>Sửa SL pallet box_count. 409 = SL hiện tại khác expectedQty.</summary>
    [Put("/api/pallets/{id}/box-count")]
    Task<UpdateBoxCountResultDto> UpdateBoxCountAsync(long id, [Body] UpdateBoxCountRequestDto request);
}
