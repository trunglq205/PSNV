namespace Swms.FinishGoods.API.Features.WeightSys.DataAccess;

public sealed class WeightDto
{
    public DateTime TmrDate { get; set; }

    public string Process { get; set; } = string.Empty;

    public string ProcessFactory { get; set; } = string.Empty;

    public string Serial { get; set; } = string.Empty;

    public decimal Weight { get; set; }

    public string? GroupId { get; set; }
}

public enum WeightCategory
{
    DP,
    CAM,
    HP,
    MW,
    PEWVN
}