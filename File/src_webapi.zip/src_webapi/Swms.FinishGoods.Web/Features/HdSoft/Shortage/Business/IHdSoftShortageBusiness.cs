using Swms.FinishGoods.Web.Features.HdSoft.Shortage.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.HdSoft.Shortage.Business;

public interface IHdSoftShortageBusiness
{
    /// <summary>Hàng thiếu HD soft của SI có ngày vanning trong [from, to] (tối đa 62 ngày). Lấy đủ, màn hình tự lọc.</summary>
    Task<Result<AppHdSoftShortage>> GetAsync(DateTime from, DateTime to, string warehouse);
}
