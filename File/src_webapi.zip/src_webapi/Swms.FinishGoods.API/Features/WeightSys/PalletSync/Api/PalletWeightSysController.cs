using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.WeightSys.PalletSync.Business;

namespace Swms.FinishGoods.API.Features.WeightSys.PalletSync.Api
{
    /// <summary>
    /// Đồng bộ Foss -> pallet SWMS. Tách khỏi PalletController nhưng giữ prefix
    /// api/pallets nên PDA / Web không phải đổi URL.
    /// </summary>
    [ApiController]
    [Route("api/pallets")]
    public class PalletWeightSysController : ControllerBase
    {
        private readonly IPalletWeightSyncService _service;
        public PalletWeightSysController(IPalletWeightSyncService service) => _service = service;


        [HttpPost("by-lot-no/{lotNo}/sync-weight")]
        public async Task<IActionResult> SyncWeight(string lotNo)
        {
            var updated = await _service.SyncBoxWeightAsync(lotNo);

            return Ok(new { updated });
        }
    }
}
