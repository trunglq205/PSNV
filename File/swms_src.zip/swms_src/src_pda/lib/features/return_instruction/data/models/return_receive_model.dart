import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_instruction_model.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_receive_entities.dart';

part 'return_receive_model.g.dart';

/// KHÔNG dùng `fieldRename: FieldRename.snake` — xem ghi chú ở
/// `return_instruction_model.dart`: API dùng camelCase.

/// Một thùng gửi lên server: mã thùng, model của thùng, serial trong thùng.
@JsonSerializable(createFactory: false)
class ReceiveReturnBoxRequestModel {
  /// `null` = hàng về rời, server tự đặt mã theo Pallet ID.
  final String? boxNo;

  final String model;
  final List<String> serials;

  const ReceiveReturnBoxRequestModel({
    required this.model,
    required this.serials,
    this.boxNo,
  });

  factory ReceiveReturnBoxRequestModel.fromDraft(ReturnBoxDraft d) =>
      ReceiveReturnBoxRequestModel(
        boxNo: d.boxNo,
        model: d.model,
        serials: d.serials,
      );

  Map<String, dynamic> toJson() => _$ReceiveReturnBoxRequestModelToJson(this);
}

/// Thân POST /api/return-instructions/{id}/pallets.
@JsonSerializable(createFactory: false)
class ReceiveReturnRequestModel {
  final List<ReceiveReturnBoxRequestModel> boxes;

  const ReceiveReturnRequestModel({required this.boxes});

  factory ReceiveReturnRequestModel.fromDrafts(List<ReturnBoxDraft> drafts) =>
      ReceiveReturnRequestModel(
        boxes: drafts.map(ReceiveReturnBoxRequestModel.fromDraft).toList(),
      );

  Map<String, dynamic> toJson() => _$ReceiveReturnRequestModelToJson(this);
}

/// Response: pallet vừa tạo + phiếu đã cập nhật SL thực nhận.
@JsonSerializable(createToJson: false)
class ReceiveReturnResponseModel {
  final int palletId;
  final String lotNo;
  final int categoryCode;
  final int boxCount;
  final int serialCount;
  final bool overReceived;
  final ReturnInstructionModel doc;

  const ReceiveReturnResponseModel({
    required this.palletId,
    required this.lotNo,
    required this.doc,
    this.categoryCode = 0,
    this.boxCount = 0,
    this.serialCount = 0,
    this.overReceived = false,
  });

  factory ReceiveReturnResponseModel.fromJson(Map<String, dynamic> json) =>
      _$ReceiveReturnResponseModelFromJson(json);

  ReturnReceiveResult toEntity() => ReturnReceiveResult(
        palletId: palletId,
        lotNo: lotNo,
        categoryCode: categoryCode,
        boxCount: boxCount,
        serialCount: serialCount,
        overReceived: overReceived,
        doc: doc.toEntity(),
      );
}
