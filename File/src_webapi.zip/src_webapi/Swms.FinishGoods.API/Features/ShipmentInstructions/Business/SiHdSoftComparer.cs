using System.Globalization;
using Swms.FinishGoods.API.Features.HdSoft.Business;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Business;

/*  So 1 SI giữa SWMS và HD soft. Không đụng DB — service nạp dữ liệu rồi gọi vào đây.

    Header: C_Order được dựng lại thành SapSiRequest rồi cho chạy qua CHÍNH SapSiMapper,
    tức là ra đúng giá trị SWMS sẽ lưu nếu nhận dữ liệu đó. Hai bên vì vậy cùng chuẩn:
    "Ver: First" -> First, "FCL 40H" -> FCL + 40H, invoice bỏ số 0 đầu, ngày vanning /
    cut-off / forwarder lấy từ headernote3… Trường nào HD soft thiếu cột nguồn thì bỏ qua
    (ghi vào Notes) thay vì báo lệch giả.

    Dòng: KHÔNG khử trùng như mapper. SAP lặp dòng thì HD soft có thể lưu cả 2 dòng (số lượng
    gấp đôi) trong khi SWMS đã bỏ dòng trùng — đó chính là chỗ 2 hệ thống lệch, phải thấy.
    Khoá dòng: packing list + packing item + model nếu HD soft có cột packing, không thì
    chỉ model (so tổng số lượng). Số đã lấy / đã cắt / đã giao chỉ để xem, không tính lệch. */
internal static class SiHdSoftComparer
{
    public const string Match = "match";
    public const string Mismatch = "mismatch";
    public const string OnlySwms = "only_swms";
    public const string OnlyHdSoft = "only_hdsoft";

    private const string Diff = "diff";
    private const string QtyDiff = "qty_diff";
    private const string FieldDiff = "field_diff";

    private enum Kind { Text, Date }

    private static readonly Dictionary<string, string> SwmsStatusNames = new()
    {
        ["released"] = "Nháp",
        ["picking"] = "Đang lấy hàng",
        ["completed"] = "Hoàn thành",
        ["cancelled"] = "Đã huỷ",
    };

    private static readonly string[] DateFormats =
    {
        "yyyy-MM-dd", "yyyyMMdd", "yyyy-MM-ddTHH:mm:ss", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd HH:mm",
        "dd.MM.yyyy", "d.M.yyyy", "dd/MM/yyyy",
    };

    public static SiCompareDetailResponse Compare(
        string siNo, SiHeader? swms, IReadOnlyList<SiLine> swmsLines, HdSoftSiOrder? hd, HdSoftSiSchema schema)
    {
        // SI chỉ có ở 1 bên: mọi trường mang trạng thái của bên đó, không tính từng lệch
        var side = swms is null ? OnlyHdSoft : hd is null ? OnlySwms : null;
        var notes = new List<string>();

        var header = CompareHeader(swms, hd, schema, side, notes);

        var packingMode = schema.HasLine("packingno") && schema.HasLine("packingitems");
        var hdLines = (IReadOnlyList<HdSoftSiLine>?)hd?.Lines ?? Array.Empty<HdSoftSiLine>();
        var lines = CompareLines(swmsLines, hdLines, schema, packingMode, side);

        if (!packingMode)
            notes.Add("HD soft không có cột packingno / packingitems: dòng được so theo tổng số lượng từng model.");
        if (hd is { OrderCount: > 1 })
            notes.Add($"HD soft có {hd.OrderCount} phiếu cùng SI {hd.SiNo}; đang so với phiếu {hd.DocumentNo} (chưa huỷ, tạo mới nhất).");

        var issues = new List<string>();
        if (side == OnlyHdSoft) issues.Add("SWMS chưa có SI này");
        else if (side == OnlySwms) issues.Add("HD soft không có SI này");
        else
        {
            issues.AddRange(header.Where(f => f.Status == Diff)
                                  .Select(f => $"{f.Label}: {V(f.Swms)} ≠ {V(f.HdSoft)}"));
            issues.AddRange(lines.Where(l => l.Status != Match).Select(LineIssue));
        }

        var summary = new SiCompareSummaryResponse(
            SiNo: swms?.SiNo ?? hd?.SiNo ?? siNo,
            Result: side ?? (issues.Count == 0 ? Match : Mismatch),
            IssueCount: issues.Count,
            FirstIssue: issues.FirstOrDefault(),
            IsCancelled: swms?.DocStatus == "cancelled" || HdSoftDocStatus.IsCancelled(hd?.DocStatus),
            EtdDate: swms?.EtdDate ?? HdEtd(hd),
            VanningDate: SwmsVanning(swms) ?? HdVanning(hd),
            SwmsId: swms?.Id,
            SwmsDocNo: swms?.DocNo,
            SwmsStatus: swms?.DocStatus,
            SwmsCreatedAt: swms?.CreatedAt,
            SwmsLineCount: swmsLines.Count,
            SwmsTotalQty: swmsLines.Sum(l => l.QtyRequired),
            HdSoftOrderId: hd?.OrderId,
            HdSoftDocNo: hd?.DocumentNo,
            HdSoftStatus: hd?.DocStatus,
            HdSoftStatusName: HdSoftDocStatus.Name(hd?.DocStatus),
            HdSoftCreatedAt: hd?.Created,
            HdSoftLineCount: hdLines.Count,
            HdSoftTotalQty: hdLines.Sum(l => l.QtyEntered));

        return new SiCompareDetailResponse(
            summary, packingMode ? "packing" : "model", header, lines, notes, DateTime.Now);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Header
    // ═══════════════════════════════════════════════════════════════

    private static List<SiCompareField> CompareHeader(
        SiHeader? sw, HdSoftSiOrder? hd, HdSoftSiSchema schema, string? side, List<string> notes)
    {
        var fields = new List<SiCompareField>();
        var skipped = new List<string>();

        // Dữ liệu HD soft "như SWMS sẽ lưu"
        var m = hd is null ? null : SapSiMapper.Map(ToSapRequest(hd));
        var h = m?.ToUpdate(new List<SiLineRequest>());
        var hNote = h?.HeaderNote ?? new Dictionary<string, string>();
        var sNote = HeaderNoteJson.Read(sw?.HeaderNote);

        // needs: trường SAP mà giá trị phía HD soft phụ thuộc; không có cột nào thì không so
        void Add(string field, string label, string? s, string? hdv, Kind kind, params string[] needs)
        {
            if (needs.Length > 0 && !needs.Any(schema.HasHeader))
            {
                skipped.Add(label);
                return;
            }
            s = SapSiMapper.Clean(s);
            hdv = SapSiMapper.Clean(hdv);
            fields.Add(new SiCompareField(field, label, s, hdv, side ?? (Same(s, hdv, kind) ? Match : Diff)));
        }

        Add("doc_no", "Số chứng từ", sw?.DocNo, hd?.DocumentNo, Kind.Text);
        Add("revision", "Version", sw?.Revision, m?.Revision, Kind.Text);
        fields.Add(StatusField(sw, hd, side));
        Add("bpartner", "Đối tác", Get(sNote, "bpartner_code"), hd?.BPartnerCode, Kind.Text);
        fields.Add(new SiCompareField("warehouse", "Kho",
          SapSiMapper.Clean(Get(sNote, "warehouse_code")), SapSiMapper.Clean(hd?.WarehouseCode),
          side ?? Match));
        Add("order_date", "Ngày đặt hàng", Get(sNote, "order_date"), Ymd(hd?.DateOrdered), Kind.Date);
        Add("promised_date", "Ngày dự kiến giao", Get(sNote, "promised_date"), Ymd(hd?.DatePromised), Kind.Date);

        Add("etd_date", "ETD", Ymd(sw?.EtdDate), Ymd(h?.EtdDate is { } e && e != default ? e : null), Kind.Date, "etd");
        Add("eta_date", "ETA", Ymd(sw?.EtaDate), Ymd(h?.EtaDate), Kind.Date, "eta");
        Add("vanning_date", "Ngày vanning", Ymd(sw?.VanningDate), Ymd(h?.VanningDate), Kind.Date, "headernote3");
        Add("cut_off_at", "Cut-off (T/S deadline)", Ymdhm(sw?.CutOffAt), Ymdhm(h?.CutOffAt), Kind.Text, "headernote3");

        Add("ship_mode", "Ship mode", sw?.ShipMode, h?.ShipMode, Kind.Text, "contactno", "headernote3");
        Add("container_size", "Container", Get(sNote, "container_size"), Get(hNote, "container_size"),
            Kind.Text, "contactno", "headernote3");
        Add("port_of_loading", "Cảng xuất", sw?.PortOfLoading, h?.PortOfLoading, Kind.Text, "destport");
        Add("port_of_discharge", "Cảng đến", sw?.PortOfDischarge, h?.PortOfDischarge,
            Kind.Text, "tripcount", "headernote3");
        Add("country_code", "Nước đến", sw?.CountryCode, h?.CountryCode, Kind.Text, "promotioncode", "headernote3");
        Add("consignee_code", "Consignee", sw?.ConsigneeCode, h?.ConsigneeCode, Kind.Text, "contactname", "headernote3");
        Add("forwarder_code", "Forwarder", sw?.ForwarderCode, h?.ForwarderCode, Kind.Text, "headernote3");
        Add("carrier_code", "Carrier", sw?.CarrierCode, h?.CarrierCode, Kind.Text, "headernote3");
        Add("packing_type", "Kiểu đóng gói", sw?.PackingType, h?.PackingType, Kind.Text, "packingtype", "headernote3");
        Add("is_serial_required", "Yêu cầu serial", YesNo(sw?.IsSerialRequired), YesNo(h?.IsSerialRequired),
            Kind.Text, "headernote3");
        Add("is_white_film", "White film", YesNo(sw?.IsWhiteFilm), YesNo(h?.IsWhiteFilm), Kind.Text, "headernote3");
        Add("is_case_mark", "Case mark", YesNo(sw?.IsCaseMark), YesNo(h?.IsCaseMark), Kind.Text, "headernote3");
        Add("pic_name", "PIC", sw?.PicName, h?.PicName, Kind.Text, "pic");
        Add("po_no", "PO", Get(sNote, "po_no"), Get(hNote, "po_no"), Kind.Text, "po");
        Add("invoice_no", "Invoice", Get(sNote, "invoice_no"), Get(hNote, "invoice_no"), Kind.Text, "invoiceno");

        if (skipped.Count > 0)
            notes.Add($"HD soft không có cột nguồn cho: {string.Join(", ", skipped)} — không so các trường này.");
        return fields;
    }

    /// <summary>Trạng thái 2 hệ thống khác bộ mã -> chỉ so "đã huỷ" hay chưa.</summary>
    private static SiCompareField StatusField(SiHeader? sw, HdSoftSiOrder? hd, string? side)
    {
        var s = sw is null ? null : $"{sw.DocStatus} – {SwmsStatusNames.GetValueOrDefault(sw.DocStatus, sw.DocStatus)}";
        var h = hd?.DocStatus is null ? null : $"{hd.DocStatus} – {HdSoftDocStatus.Name(hd.DocStatus)}";
        var same = (sw?.DocStatus == "cancelled") == HdSoftDocStatus.IsCancelled(hd?.DocStatus);
        return new SiCompareField("doc_status", "Trạng thái (so đã huỷ / chưa)", s, h, side ?? (same ? Match : Diff));
    }

    /// <summary>ETD bên HD soft: trường etd (yyyy-MM-dd) nếu đọc được, không thì DatePromised.</summary>
    private static DateTime? HdEtd(HdSoftSiOrder? hd)
    {
        if (hd is null) return null;
        return TryDate(hd.Field("etd"), out var d) ? d : hd.DatePromised?.Date;
    }

    /// <summary>C_Order -> payload SAP. Tên trường payload = khoá Fields (xem HdSoftSiRepository).</summary>
    private static SapSiRequest ToSapRequest(HdSoftSiOrder o) => new()
    {
        Org = o.OrgCode,
        Warehouse = o.WarehouseCode,
        DocumentNo = o.DocumentNo,
        DateOrdered = Ymd(o.DateOrdered),
        DatePromised = Ymd(o.DatePromised),
        SiNo = o.SiNo,
        BPartner = o.BPartnerCode,
        DestPort = o.Field("destport"),
        DriverPhoneNo = o.Field("driverphoneno"),
        ContactName = o.Field("contactname"),
        ContactNo = o.Field("contactno"),
        TripCount = o.Field("tripcount"),
        PromotionCode = o.Field("promotioncode"),
        CutTime = o.Field("cuttime"),
        PackingType = o.Field("packingtype"),
        PalletList = o.Field("palletlist"),
        M3 = o.Field("m3"),
        HeaderNote3 = o.Field("headernote3"),
        CaseMark = o.Field("casemark"),
        QrInfor = o.Field("qrinfor"),
        Pic = o.Field("pic"),
        Etd = o.Field("etd"),
        Eta = o.Field("eta"),
        Po = o.Field("po"),
        InvoiceNo = o.Field("invoiceno"),
    };

    // ═══════════════════════════════════════════════════════════════
    //  Dòng
    // ═══════════════════════════════════════════════════════════════

    private sealed class Group
    {
        public string Key { get; init; } = "";
        public List<SiLine> Swms { get; } = new();
        public List<HdSoftSiLine> Hd { get; } = new();
    }

    private static List<SiCompareLine> CompareLines(
        IReadOnlyList<SiLine> swLines, IReadOnlyList<HdSoftSiLine> hdLines,
        HdSoftSiSchema schema, bool packingMode, string? side)
    {
        var groups = new Dictionary<string, Group>(StringComparer.OrdinalIgnoreCase);
        var ordered = new List<Group>();   // thứ tự: theo dòng SWMS, rồi dòng chỉ có ở HD soft

        Group At(string key)
        {
            if (!groups.TryGetValue(key, out var g))
            {
                g = new Group { Key = key };
                groups[key] = g;
                ordered.Add(g);
            }
            return g;
        }

        foreach (var l in swLines.OrderBy(x => x.LineNo))
            At(Key(packingMode, l.PackingListNo, l.PackingItemNo, l.Model)).Swms.Add(l);
        foreach (var l in hdLines.OrderBy(x => x.LineNo))
            At(Key(packingMode, l.Field("packingno"), l.Field("packingitems"), l.Model)).Hd.Add(l);

        var compareSo = packingMode && schema.HasLine("so");
        var compareSoItem = packingMode && schema.HasLine("soitem");
        return ordered.Select(g => ToLine(g, packingMode, compareSo, compareSoItem, side)).ToList();
    }

    private static SiCompareLine ToLine(Group g, bool packingMode, bool compareSo, bool compareSoItem, string? side)
    {
        var sw = g.Swms.FirstOrDefault();
        var hd = g.Hd.FirstOrDefault();
        var model = sw?.Model.Trim() ?? hd?.Model ?? "";
        var pl = packingMode ? N(sw?.PackingListNo) ?? N(hd?.Field("packingno")) : null;
        var item = packingMode ? N(sw?.PackingItemNo) ?? N(hd?.Field("packingitems")) : null;

        int? swQty = g.Swms.Count > 0 ? g.Swms.Sum(x => x.QtyRequired) : null;
        decimal? hdQty = g.Hd.Count > 0 ? g.Hd.Sum(x => x.QtyEntered) : null;

        var fields = new List<SiCompareField>();
        if (g.Swms.Count > 0 && g.Hd.Count > 0)
        {
            void AddField(string field, string label, string? s, string? h)
                => fields.Add(new SiCompareField(field, label, s, h,
                       string.Equals(s, h, StringComparison.OrdinalIgnoreCase) ? Match : Diff));

            if (compareSo)
                AddField("so_no", "SO", Join(g.Swms.Select(x => N(x.SoNo))), Join(g.Hd.Select(x => N(x.Field("so")))));
            if (compareSoItem)
                AddField("so_item_no", "SO item", Join(g.Swms.Select(x => N(x.SoItemNo))),
                         Join(g.Hd.Select(x => N(x.Field("soitem")))));
        }

        // Dòng chỉ có ở 1 bên mà số lượng bên đó = 0 (HD soft giữ dòng 0 pcs, SWMS không có) -> coi như khớp
        var status = side
            ?? (g.Swms.Count == 0 ? (hdQty == 0 ? Match : OnlyHdSoft)
              : g.Hd.Count == 0 ? (swQty == 0 ? Match : OnlySwms)
              : swQty != hdQty ? QtyDiff
              : fields.Any(f => f.Status == Diff) ? FieldDiff
              : Match);

        string? note = null;
        if (packingMode && g.Hd.Count > 1 && g.Swms.Count <= 1)
        {
            note = status == QtyDiff && g.Swms.Count == 1 && g.Hd.All(x => x.QtyEntered == swQty)
                ? $"HD soft lặp dòng này {g.Hd.Count} lần (SAP gửi trùng) — SWMS chỉ giữ 1 dòng"
                : $"HD soft có {g.Hd.Count} dòng cùng packing item";
        }

        return new SiCompareLine(
            Key: g.Key,
            Model: model,
            PackingListNo: pl,
            PackingItemNo: item,
            Status: status,
            SwmsQty: swQty,
            HdSoftQty: hdQty,
            SwmsLineNos: g.Swms.Select(x => x.LineNo).ToList(),
            HdSoftLineNos: g.Hd.Select(x => x.LineNo).ToList(),
            SwmsQtyPicked: g.Swms.Sum(x => x.QtyPicked),
            SwmsQtyCut: g.Swms.Sum(x => x.QtyCut ?? 0),
            HdSoftQtyDelivered: g.Hd.Sum(x => x.QtyDelivered),
            Fields: fields,
            Note: note);
    }

    private static string Key(bool packingMode, string? packingList, string? packingItem, string model)
    {
        var m = HdSoftModel.Normalize(model).ToUpperInvariant();
        return packingMode ? $"{N(packingList)}|{N(packingItem)}|{m}".ToUpperInvariant() : m;
    }

    private static string LineIssue(SiCompareLine l)
    {
        var what = l.PackingListNo is null && l.PackingItemNo is null
            ? l.Model
            : $"{l.Model} ({l.PackingListNo}/{l.PackingItemNo})";
        return l.Status switch
        {
            OnlySwms => $"{what}: chỉ có ở SWMS (SL {l.SwmsQty})",
            OnlyHdSoft => $"{what}: chỉ có ở HD soft (SL {Qty(l.HdSoftQty)})",
            QtyDiff => $"{what}: SL {l.SwmsQty} ≠ {Qty(l.HdSoftQty)}",
            _ => $"{what}: " + string.Join(", ", l.Fields.Where(f => f.Status == Diff)
                                                        .Select(f => $"{f.Label} {V(f.Swms)} ≠ {V(f.HdSoft)}")),
        };
    }

    // ═══════════════════════════════════════════════════════════════
    //  helpers
    // ═══════════════════════════════════════════════════════════════

    /// <summary>Chuẩn hoá mã giống SapSiMapper: trim, "...." = trống, bỏ số 0 đầu.</summary>
    private static string? N(string? v) => SapSiMapper.TrimZeros(SapSiMapper.Clean(v));

    private static string? Join(IEnumerable<string?> values)
    {
        var list = values.Where(v => v is not null).Select(v => v!)
                         .Distinct(StringComparer.OrdinalIgnoreCase)
                         .OrderBy(v => v, StringComparer.OrdinalIgnoreCase)
                         .ToList();
        return list.Count == 0 ? null : string.Join(", ", list);
    }

    private static bool Same(string? a, string? b, Kind kind)
    {
        if (kind == Kind.Date && TryDate(a, out var da) && TryDate(b, out var db)) return da == db;
        return string.Equals(a, b, StringComparison.OrdinalIgnoreCase);
    }

    private static bool TryDate(string? v, out DateTime date)
    {
        var ok = DateTime.TryParseExact(v, DateFormats, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d);
        date = d.Date;
        return ok;
    }

    /// <summary>Vanning SWMS: vanning_date, trống thì ETD (EtdDate NOT NULL) — cùng định nghĩa màn Hàng thiếu.</summary>
    internal static DateTime? SwmsVanning(SiHeader? sw)
        => sw is null ? null : (sw.VanningDate ?? sw.EtdDate).Date;

    /// <summary>Vanning HD soft: "Loading date" trong headernote3, không có thì ETD bên HD soft.</summary>
    internal static DateTime? HdVanning(HdSoftSiOrder? hd)
        => hd is null ? null : HdSoftSiVanning.Of(hd) ?? HdEtd(hd);

    private static string? Get(Dictionary<string, string> d, string key) => d.TryGetValue(key, out var v) ? v : null;
    private static string? Ymd(DateTime? d) => d?.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    private static string? Ymdhm(DateTime? d) => d?.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture);
    private static string? YesNo(bool? b) => b is null ? null : b.Value ? "Có" : "Không";
    private static string? Qty(decimal? q) => q?.ToString("0.###", CultureInfo.InvariantCulture);
    private static string V(string? v) => v ?? "∅";
}
