/* =========================================================
   FLAPPY SANTA — MÀN CHƠI SAU ĐĂNG NHẬP (mùa Giáng sinh)
   Drop-in: wwwroot/js/christmas-gate.js  (nạp bởi Views/Shared/_XmasGate.cshtml, SAU xmas-flappy-sim.js)

   Cách chơi: click / chạm / Space để ông già Noel bay lên, bay qua khe giữa các cột người tuyết.
   Mỗi cột vượt qua = 1 điểm. Đâm vào người tuyết hoặc rơi xuống đất là thua.
   Chống gian lận: trình duyệt chỉ gửi các tick bấm bay; server tự chơi lại để tính điểm
   (xem Helpers/XmasFlappySim.cs + Controllers/GameScoreController.cs).
   ========================================================= */
(function () {
    "use strict";

    /* ---------- CẤU HÌNH ---------- */
    var SKIP_AFTER_MS = 0;       // nút "Bỏ qua": 0 = hiện ngay; >0 = hiện sau n ms; -1 = không cho bỏ qua
    var SLOGAN = '"Đứa nào mải chơi làm critical chậm chếc với bà =))"';
    var SPRITE_SIZE = 0.62;      // cỡ hình ông già Noel — khớp vùng va chạm
    // ĐỘ RÕ: nền tối + mờ đi khi chơi (chỉnh trong christmas.css: .xg-gate.dim), cột người tuyết có nền cột riêng
    var PILLAR_COLOR = "rgba(16, 34, 82, .62)";   // nền cột phía sau người tuyết (xanh đêm, mờ 62%)
    var CAP_STRIPES = ["#c0282f", "#ffffff"];     // dải kẹo gậy ở mép khe = đúng mép va chạm

    var gate = document.getElementById("xmasGate");
    var S = window.XmasFlappySim;
    if (!gate || !S) return;
    var C = S.C;

    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    var root = document.documentElement;
    root.classList.add("xg-lock");

    var hud = gate.querySelector(".xg-hud");
    var skip = gate.querySelector(".xg-skip");
    var tokenEl = gate.querySelector('input[name="__RequestVerificationToken"]');
    var urls = {
        start: gate.getAttribute("data-start-url"),
        begin: gate.getAttribute("data-begin-url"),
        submit: gate.getAttribute("data-submit-url"),
        board: gate.getAttribute("data-board-url")
    };
    var hudReadyHtml = hud.innerHTML;

    function esc(t) {
        return String(t == null ? "" : t).replace(/[&<>"']/g, function (ch) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
        });
    }
    function prizesOf(d) {
        if (d && d.prizes && d.prizes.length === 3) return d.prizes;
        var m = document.querySelector('meta[name="game-prizes"]');
        var v = m ? (m.getAttribute("content") || "").split("|") : [];
        return v.length === 3 ? v : ["50.000đ – 500.000đ", "50.000đ – 200.000đ", "50.000đ – 100.000đ"];
    }

    /* ---------- GỌI SERVER ---------- */
    function post(url, body) {
        if (!url || !window.fetch) return Promise.resolve(null);
        return fetch(url, {
            method: "POST",
            credentials: "same-origin",
            headers: {
                "Content-Type": "application/json",
                "Accept": "application/json",
                "RequestVerificationToken": tokenEl ? tokenEl.value : ""
            },
            body: JSON.stringify(body || {})
        }).then(function (r) {
            return r.json().catch(function () { return null; }).then(function (j) {
                if (r.ok) return j;
                return { error: (j && j.message) || ("Lỗi " + r.status) };
            });
        }).catch(function () { return null; });
    }

    /* ---------- DẢI SLOGAN TO Ở ĐÁY ---------- */
    var sloganBar = (function () {
        var bar = document.createElement("div");
        bar.className = "xg-slogan";
        bar.setAttribute("role", "marquee");
        bar.setAttribute("aria-label", SLOGAN);
        var trk = document.createElement("div");
        trk.className = "trk";
        for (var half = 0; half < 2; half++) {
            for (var k = 0; k < 3; k++) {
                var sp = document.createElement("span");
                sp.textContent = SLOGAN;
                trk.appendChild(sp);
                var ic = document.createElement("i");
                ic.textContent = ["🎅", "⛄", "🎄"][k];
                ic.setAttribute("aria-hidden", "true");
                trk.appendChild(ic);
            }
        }
        bar.appendChild(trk);
        gate.appendChild(bar);
        return bar;
    })();

    /* ---------- BXH GÓC PHẢI (ẩn trong lúc bay) ---------- */
    var lb = (function () {
        if (!urls.board || !window.fetch) return null;
        var box = document.createElement("div");
        box.className = "xg-lb";
        box.setAttribute("aria-live", "polite");
        box.innerHTML = '<h4>🏆 BXH Flappy Santa</h4><div class="sub">Đang tải…</div>';
        gate.appendChild(box);

        box.addEventListener("click", function (e) {
            var b = e.target.closest ? e.target.closest(".rules") : null;
            if (!b) return;
            e.stopPropagation();
            if (window.Christmas && window.Christmas.openRules) window.Christmas.openRules();
        });

        function render(d, flash) {
            var rows = (d.rows || []).slice(0, 5);
            var myName = d.me ? d.me.username : null;
            var medal = ["🥇", "🥈", "🥉"];
            var html = '<h4>🏆 BXH Flappy Santa</h4><div class="sub">Mùa Giáng sinh ' + d.from + " – " + d.to + " · " +
                (d.closed ? "<b>đã chốt</b>" : "còn <b>" + d.daysLeft + " ngày</b>") + " · " + d.total + " người</div>" +
                (function (p) {
                    return '<div class="prize"><div class="ttl">🎁 Quà ngẫu nhiên cho Top 3</div>' +
                        "<span>🥇 " + esc(p[0]) + "</span><span>🥈 " + esc(p[1]) + "</span><span>🥉 " + esc(p[2]) + "</span></div>";
                })(prizesOf(d));
            function li(r) {
                var me = r.username === myName;
                return '<li class="' + (me ? "me" + (flash ? " flash" : "") : "") + '"><span class="rk">' + (medal[r.rank - 1] || r.rank) +
                    '</span><span class="nm">' + esc(r.fullName) + '</span><span class="tm">' + r.score + " điểm</span></li>";
            }
            if (!rows.length) {
                html += '<div class="empty">Chưa ai lên bảng — bay qua 1 người tuyết là có tên! 🎅</div>';
            } else {
                html += "<ol>";
                rows.forEach(function (r) { html += li(r); });
                if (d.me && d.me.rank > rows.length) html += '<li class="gap">⋯</li>' + li(d.me);
                html += "</ol>";
            }
            if (d.me) {
                var above = d.me.rank > 1 ? d.rows[d.me.rank - 2] : null;
                html += '<div class="mine">Kỷ lục của bạn: <b>' + d.me.score + " điểm</b> (hạng #" + d.me.rank + ")" +
                    (d.me.rank === 1 ? " · đang dẫn đầu! 👑" : above ? " · đạt <b>" + (above.score + 1) + "</b> để vượt #" + (d.me.rank - 1) : "") + "</div>";
            } else if (rows.length) {
                html += '<div class="mine">Bạn chưa có điểm — đạt <b>' + (rows[rows.length - 1].score + 1) + " điểm</b> để vào top " + rows.length + "!</div>";
            }
            html += '<button type="button" class="rules">📜 Xem thể lệ &amp; giải thưởng</button>';
            box.innerHTML = html;
        }

        function load(flash) {
            return fetch(urls.board + (urls.board.indexOf("?") < 0 ? "?" : "&") + "top=20",
                { credentials: "same-origin", headers: { "Accept": "application/json" } })
                .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
                .then(function (d) { render(d, flash); })
                .catch(function () { box.innerHTML = '<h4>🏆 BXH Flappy Santa</h4><div class="sub">Không tải được bảng xếp hạng.</div>'; });
        }
        load(false);
        return { reload: function () { return load(true); } };
    })();

    /* ---------- CANVAS ---------- */
    var cv = document.createElement("canvas");
    cv.className = "xg-canvas";
    cv.setAttribute("aria-hidden", "true");
    gate.insertBefore(cv, hud);
    var ctx = cv.getContext("2d");
    var W = 0, H = 0, PH = 0, SC = 1, BX = 200, DPR = Math.min(window.devicePixelRatio || 1, 2);
    var flakes = [];

    function resize() {
        W = gate.clientWidth; H = gate.clientHeight;
        cv.width = W * DPR; cv.height = H * DPR;
        ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
        PH = H - (sloganBar ? sloganBar.offsetHeight : 0);   // vùng chơi nằm trên dải slogan
        SC = PH / C.H;                                       // px trên 1 "điểm" mô phỏng
        BX = Math.max(130, Math.min(420, W * 0.26));         // vị trí ngang của ông già Noel trên màn
        var target = Math.round(Math.min(90, (W * H) / 20000));
        while (flakes.length < target) flakes.push(makeFlake(true));
        flakes.length = target;
    }
    function sx(x) { return BX + (x - C.BIRD_X) * SC; }
    function sy(y) { return y * SC; }
    function makeFlake(anyY) {
        var d = Math.random();
        return { x: Math.random() * W, y: anyY ? Math.random() * H : -8, r: 0.8 + d * 2, vy: 0.4 + d * 1.1, dr: Math.random() * 6.3, a: 0.35 + d * 0.5 };
    }

    /* ---------- TRẠNG THÁI ---------- */
    // ready → playing → dead → result → (Chơi lại → ready) | opening
    var state = "ready";
    var session = null, sessionPromise = null, offline = false;
    var sim = null, acc = 0, pendingFlap = false, lastFrame = performance.now();
    var deadAt = 0, deadY = 0, deadVy = 0, deadRot = 0, resultAt = 0;
    var parts = [], dust = [], groundOff = 0, opened = false;

    function requestSession() {
        session = null; offline = false;
        sessionPromise = post(urls.start, {}).then(function (r) {
            if (r && r.sessionId) session = r;
            else offline = true;
            return session;
        });
        return sessionPromise;
    }

    function startGame() {
        if (state !== "ready") return;
        if (!session && !offline) {             // chưa nhận được mã lượt chơi: đợi rồi tự bắt đầu
            hud.querySelector(".xg-start").textContent = "Đang chuẩn bị…";
            sessionPromise.then(function () { if (state === "ready") startGame(); });
            return;
        }
        var seed = session ? session.seed : (Math.random() * 4294967296) >>> 0;
        sim = new S.Sim(seed);
        acc = 0;
        pendingFlap = true;                      // bấm đầu tiên = cú bay ở tick 0
        state = "playing";
        gate.classList.add("playing", "dim");
        hud.classList.add("hidden");
        if (session) post(urls.begin, { sessionId: session.sessionId });
    }

    function flap() {
        if (state === "ready") startGame();
        else if (state === "playing") pendingFlap = true;
    }

    function die() {
        state = "dead";
        deadAt = performance.now();
        deadY = sy(sim.y); deadVy = -4; deadRot = 0;
        puff(BX + 20, deadY, 26);
        if (navigator.vibrate) { try { navigator.vibrate(60); } catch (e) { } }
        var flaps = sim.flaps.slice(), endTick = sim.t, score = sim.score;
        var req = session
            ? post(urls.submit, { sessionId: session.sessionId, flaps: flaps, endTick: endTick })
            : Promise.resolve(null);
        setTimeout(function () { showResult(score, req); }, REDUCED ? 200 : 750);
    }

    function abortForHidden() {
        if (state !== "playing") return;
        state = "result";
        resultAt = performance.now();
        hud.classList.remove("hidden");
        gate.classList.remove("playing");
        hud.innerHTML = '<h2>Ôi, bạn rời tab rồi!</h2><p>Lượt này dừng lại và <b>không được tính</b> — chơi lại nhé.</p>' + actionsHtml();
        wireActions();
    }

    function actionsHtml() {
        return '<div class="xg-actions"><button type="button" class="xg-replay">🔁 Chơi lại</button>' +
            '<button type="button" class="xg-go">Vào hệ thống ▶</button>' +
            '<button type="button" class="xg-board">🏆 Xem BXH</button></div>' +
            '<div class="xg-keys"><kbd>Space</kbd> / <kbd>R</kbd> chơi lại · <kbd>Enter</kbd> vào hệ thống</div>';
    }

    function wireActions() {
        hud.querySelector(".xg-replay").addEventListener("click", replay);
        hud.querySelector(".xg-go").addEventListener("click", function () { openNow(false); });
        hud.querySelector(".xg-board").addEventListener("click", function () { openNow(true); });
    }

    function showResult(score, req) {
        state = "result";
        resultAt = performance.now();
        gate.classList.remove("playing");
        hud.classList.remove("hidden");
        hud.classList.add("done");
        hud.innerHTML = '<h2>' + (score >= 10 ? "Quá đỉnh!" : score > 0 ? "Ho ho ho!" : "Úi, đâm người tuyết rồi!") + '</h2>' +
            '<div class="xg-score"><b>' + score + '</b><span>điểm</span></div>' +
            '<div class="xg-rank">' + (session ? "Đang lưu kết quả…" : "Không kết nối được máy chủ — lượt này không lưu.") + "</div>" +
            actionsHtml();
        wireActions();
        var rankEl = hud.querySelector(".xg-rank");
        req.then(function (r) {
            if (!rankEl.isConnected || !session) return;
            if (!r) { rankEl.textContent = "Không lưu được kết quả lần này (mất kết nối?)."; return; }
            if (r.error) { rankEl.textContent = r.error; return; }
            if (!r.valid) { rankEl.innerHTML = "⚠️ Lượt này <b>không được tính</b>: " + esc(r.reason || "dữ liệu không hợp lệ") + "."; }
            else if (!r.inSeason) { rankEl.innerHTML = "BXH mùa Giáng sinh đã chốt lúc <b>" + r.seasonTo + "</b> — lượt này không tính hạng nữa 🎄"; }
            else if (!r.ranked) { rankEl.innerHTML = "Bay qua ít nhất <b>1 người tuyết</b> để lên bảng nhé! ⛄"; }
            else {
                rankEl.innerHTML =
                    (r.personalBest ? '<span class="xg-pb">✨ Kỷ lục cá nhân mới!</span><br />'
                                    : "Kỷ lục của bạn vẫn là <b>" + r.best + " điểm</b><br />") +
                    "🏆 Hạng <b>#" + r.rank + "</b>/" + r.total + " mùa Giáng sinh (chốt " + r.seasonTo + ")" +
                    (r.rank >= 1 && r.rank <= 3
                        ? '<br /><span class="xg-pb">🎁 Bạn đang giữ Top ' + r.rank + " — quà ngẫu nhiên " + esc(prizesOf(r)[r.rank - 1]) + ". Giữ vững tới " + r.seasonTo + " nhé!</span>"
                        : "");
            }
            if (lb) lb.reload();
        });
    }

    function replay() {
        if (state !== "result" || opened) return;
        state = "ready";
        sim = null; parts.length = 0; dust.length = 0;
        gate.classList.remove("dim");
        hud.classList.remove("done");
        hud.innerHTML = hudReadyHtml;
        requestSession();
        gate.focus({ preventScroll: true });
    }

    /* ---------- MỞ MÀN VÀO HỆ THỐNG ---------- */
    function openNow(showBoard) {
        if (opened) return;
        opened = true;
        state = "opening";
        gate.classList.add("opening");
        if (window.Christmas && window.Christmas.burst) window.Christmas.burst(window.innerWidth / 2, window.innerHeight / 2, 28);
        setTimeout(function () {
            gate.remove();
            root.classList.remove("xg-lock");
            var main = document.querySelector("main");
            if (main) { main.setAttribute("tabindex", "-1"); main.focus({ preventScroll: true }); }
            window.dispatchEvent(new Event("resize"));
            document.dispatchEvent(new CustomEvent("xmas-gate-opened"));
            // bỏ ?themegate=1 khỏi thanh địa chỉ để F5 không hiện lại màn chơi
            try {
                var u = new URL(location.href);
                if (u.searchParams.has("themegate")) {
                    u.searchParams.delete("themegate");
                    history.replaceState(history.state, "", u.pathname + u.search + u.hash);
                }
            } catch (err) { }
            if (showBoard && window.Christmas && window.Christmas.openBoard) window.Christmas.openBoard();
        }, REDUCED ? 700 : 1600);
    }

    /* ---------- HIỆU ỨNG ---------- */
    function puff(x, y, n) {
        for (var i = 0; i < n; i++) {
            var a = Math.random() * 6.2832, v = 1 + Math.random() * 4;
            parts.push({ x: x, y: y, vx: Math.cos(a) * v, vy: Math.sin(a) * v - 1.5, r: 2 + Math.random() * 4, life: 1 });
        }
    }

    function ball(x, y, r) {
        var gr = ctx.createRadialGradient(x - r * 0.35, y - r * 0.4, r * 0.1, x, y, r);
        gr.addColorStop(0, "#ffffff");
        gr.addColorStop(0.7, "#eef3fa");
        gr.addColorStop(1, "#c3d1e7");
        ctx.fillStyle = gr;
        ctx.beginPath();
        ctx.arc(x, y, r, 0, 6.2832);
        ctx.fill();
        ctx.lineWidth = Math.max(1.5, r * 0.07);
        ctx.strokeStyle = "rgba(12,22,52,.9)";      // viền đậm để tách khỏi nền
        ctx.stroke();
    }

    // đầu người tuyết: mặt + khăn + mũ, (0,0) = tâm đầu
    function snowHead(r, hatType) {
        ball(0, 0, r);
        ctx.fillStyle = "#1e2233";
        ctx.beginPath(); ctx.arc(-r * 0.32, -r * 0.15, r * 0.11, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(r * 0.3, -r * 0.15, r * 0.11, 0, 6.2832); ctx.fill();
        for (var m = -2; m <= 2; m++) {
            ctx.beginPath(); ctx.arc(m * r * 0.15, r * 0.42 - Math.abs(m) * r * 0.06, r * 0.05, 0, 6.2832); ctx.fill();
        }
        ctx.fillStyle = "rgba(240,110,120,.45)";
        ctx.beginPath(); ctx.arc(-r * 0.55, r * 0.15, r * 0.13, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.arc(r * 0.53, r * 0.15, r * 0.13, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#f07b1d";                       // mũi cà rốt chĩa về phía ông già Noel (bên trái)
        ctx.beginPath();
        ctx.moveTo(0, -r * 0.02); ctx.lineTo(-r * 0.95, r * 0.12); ctx.lineTo(0, r * 0.2);
        ctx.closePath(); ctx.fill();
        if (hatType === 0) {                              // mũ Noel
            ctx.fillStyle = "#c0282f";
            ctx.beginPath();
            ctx.moveTo(-r * 0.9, -r * 0.55);
            ctx.quadraticCurveTo(r * 0.2, -r * 1.9, r * 1.1, -r * 1.2);
            ctx.lineTo(r * 0.9, -r * 0.55);
            ctx.closePath(); ctx.fill();
            ctx.fillStyle = "#fff";
            ctx.fillRect(-r * 1.0, -r * 0.72, r * 2.0, r * 0.3);
            ctx.beginPath(); ctx.arc(r * 1.12, -r * 1.18, r * 0.2, 0, 6.2832); ctx.fill();
        } else {                                          // mũ chóp đen
            ctx.fillStyle = "#23283d";
            ctx.fillRect(-r * 0.9, -r * 0.8, r * 1.8, r * 0.17);
            ctx.fillRect(-r * 0.58, -r * 1.55, r * 1.16, r * 0.8);
            ctx.fillStyle = "#1f6b45";
            ctx.fillRect(-r * 0.58, -r * 0.98, r * 1.16, r * 0.16);
        }
    }

    // 1 cột người tuyết. edgeY = mép khe (px), endY = đầu kia của cột; dir = 1 cột dưới (đứng), -1 cột trên (treo ngược)
    function drawColumn(cx, w, edgeY, endY, dir, hatType) {
        var len = Math.abs(endY - edgeY);
        if (len < 2) return;
        ctx.save();
        ctx.translate(cx, edgeY);
        if (dir < 0) ctx.scale(1, -1);
        ctx.beginPath(); ctx.rect(-w, 0, w * 2, len + 2); ctx.clip();
        var rh = w * 0.32, rm = w * 0.42, rb = w * 0.5;
        var capH = Math.max(7, w * 0.11);
        // nền cột: khối xanh đêm phía sau, viền sáng → cột nổi hẳn lên khỏi ảnh nền
        var pw = w * 0.62;
        ctx.fillStyle = PILLAR_COLOR;
        ctx.fillRect(-pw, 0, pw * 2, len + 2);
        ctx.strokeStyle = "rgba(190, 220, 255, .75)";
        ctx.lineWidth = 2;
        ctx.strokeRect(-pw, 0, pw * 2, len + 4);
        // dải kẹo gậy đỏ-trắng đúng mép khe
        ctx.save();
        ctx.beginPath(); ctx.rect(-pw - 3, 0, pw * 2 + 6, capH); ctx.clip();
        ctx.fillStyle = CAP_STRIPES[1]; ctx.fillRect(-pw - 3, 0, pw * 2 + 6, capH);
        ctx.fillStyle = CAP_STRIPES[0];
        for (var sx0 = -pw - 3 - capH * 2; sx0 < pw + 3; sx0 += capH * 1.6) {
            ctx.beginPath();
            ctx.moveTo(sx0, capH); ctx.lineTo(sx0 + capH * 0.8, capH); ctx.lineTo(sx0 + capH * 1.8, 0); ctx.lineTo(sx0 + capH, 0);
            ctx.closePath(); ctx.fill();
        }
        ctx.restore();
        ctx.strokeStyle = "rgba(12,22,52,.9)"; ctx.lineWidth = 1.5;
        ctx.strokeRect(-pw - 3, 0, pw * 2 + 6, capH);
        ctx.translate(0, capH);
        len -= capH;
        var hatH = rh * 0.95;
        var yh = hatH + rh * 0.62, ym = yh + rh * 0.8 + rm * 0.8, yb = ym + rm * 0.8 + rb * 0.82;
        for (var y = yb + rb * 1.55; y < len + rb; y += rb * 1.55) ball(0, y, rb);   // thân tuyết chồng lên nhau
        ball(0, yb, rb);
        ball(0, ym, rm);
        ctx.fillStyle = "#2a2f45";
        for (var i = 0; i < 3; i++) { ctx.beginPath(); ctx.arc(0, ym - rm * 0.45 + i * rm * 0.42, w * 0.03, 0, 6.2832); ctx.fill(); }
        // tay que gỗ
        ctx.strokeStyle = "#6b4226"; ctx.lineWidth = Math.max(2, w * 0.045); ctx.lineCap = "round";
        [-1, 1].forEach(function (s) {
            ctx.beginPath(); ctx.moveTo(s * rm * 0.85, ym - rm * 0.2); ctx.lineTo(s * w * 0.62, ym - rm * 0.75); ctx.stroke();
        });
        ctx.save();
        ctx.translate(0, yh);
        snowHead(rh, hatType);
        ctx.restore();
        // khăn quàng
        ctx.fillStyle = "#c0282f";
        ctx.beginPath(); ctx.ellipse(0, yh + rh * 0.88, rh * 1.05, rh * 0.26, 0, 0, 6.2832); ctx.fill();
        ctx.fillRect(rh * 0.35, yh + rh * 0.9, rh * 0.34, rh * 0.95);
        ctx.restore();
    }

    function drawGround(gy) {
        var g = ctx.createLinearGradient(0, gy, 0, PH);
        g.addColorStop(0, "#ffffff");
        g.addColorStop(1, "#cfdcf0");
        ctx.fillStyle = g;
        ctx.fillRect(0, gy, W, PH - gy);
        ctx.strokeStyle = "rgba(27,36,71,.35)";
        ctx.lineWidth = 2;
        ctx.beginPath(); ctx.moveTo(0, gy); ctx.lineTo(W, gy); ctx.stroke();
        // vệt tuyết trôi theo tốc độ bay
        ctx.fillStyle = "rgba(160,180,215,.55)";
        var step = 46;
        for (var x = -(groundOff % step); x < W; x += step) {
            ctx.beginPath(); ctx.ellipse(x, gy + (PH - gy) * 0.45, 9, 2.5, 0, 0, 6.2832); ctx.fill();
        }
    }

    function drawReindeer(d, shade) {
        ctx.save();
        ctx.translate(d.x, d.y + d.dy);
        var ph = d.ph;
        var body = shade < 1 ? "#6e4523" : "#8b5a2b";
        var dark = shade < 1 ? "#4d2f17" : "#5e3a1b";

        // chân phi nước đại (2 đoạn)
        ctx.strokeStyle = dark;
        ctx.lineCap = "round";
        ctx.lineWidth = 2.4;
        [[9, 1], [6, 1.3], [-9, -1], [-12, -1.3]].forEach(function (L) {
            var sw = Math.sin(ph + L[1]) * 0.9;
            var front = L[0] > 0 ? 1 : -1;
            var kx = L[0] + Math.sin(sw) * 8 * front, ky = 4 + 7 * Math.cos(sw * 0.6);
            ctx.beginPath();
            ctx.moveTo(L[0], 3);
            ctx.lineTo(kx, ky);
            ctx.lineTo(kx + front * 5 * Math.max(0.2, Math.abs(sw)), ky + 5);
            ctx.stroke();
        });

        // thân
        var g = ctx.createLinearGradient(0, -8, 0, 8);
        g.addColorStop(0, shade < 1 ? "#8a5a30" : "#a8703a");
        g.addColorStop(1, body);
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.ellipse(0, 0, 16, 7.5, 0, 0, 6.2832);
        ctx.fill();
        // bụng sáng + đuôi trắng
        ctx.fillStyle = "rgba(245,225,200,.8)";
        ctx.beginPath(); ctx.ellipse(1, 4, 10, 2.6, 0, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.ellipse(-16, -3, 3, 2.2, -0.5, 0, 6.2832); ctx.fill();

        // yên cương đỏ + chuông vàng
        ctx.fillStyle = "#c0282f";
        ctx.fillRect(-4, -7.5, 7, 15);
        ctx.fillStyle = "#e8b64c";
        ctx.beginPath(); ctx.arc(-0.5, 8, 1.9, 0, 6.2832); ctx.fill();

        // cổ + đầu
        ctx.fillStyle = body;
        ctx.beginPath();
        ctx.moveTo(10, -5); ctx.lineTo(17, -15); ctx.lineTo(22, -12); ctx.lineTo(15, 0);
        ctx.closePath(); ctx.fill();
        ctx.beginPath(); ctx.ellipse(22, -16, 6.5, 4.2, 0.25, 0, 6.2832); ctx.fill();
        ctx.beginPath(); ctx.ellipse(27, -14.5, 3.4, 2.6, 0.2, 0, 6.2832); ctx.fill(); // mõm
        // tai
        ctx.beginPath(); ctx.ellipse(17.5, -20, 3.2, 1.4, -0.7, 0, 6.2832); ctx.fill();
        // mắt
        ctx.fillStyle = "#1e2233";
        ctx.beginPath(); ctx.arc(23, -17.5, 1, 0, 6.2832); ctx.fill();

        // gạc
        ctx.strokeStyle = "#d9b88a";
        ctx.lineWidth = 1.6;
        ctx.beginPath();
        ctx.moveTo(19, -20); ctx.lineTo(15, -29); ctx.lineTo(11, -32);
        ctx.moveTo(16.5, -26); ctx.lineTo(20, -31);
        ctx.moveTo(21, -20); ctx.lineTo(20, -28); ctx.lineTo(24, -32);
        ctx.moveTo(15.3, -28.5); ctx.lineTo(13, -26);
        ctx.stroke();

        // mũi: Rudolph đỏ phát sáng, còn lại đen
        if (d.rudolph) {
            var glow = ctx.createRadialGradient(30, -14.5, 0, 30, -14.5, 9);
            glow.addColorStop(0, "rgba(255,90,90,.9)");
            glow.addColorStop(1, "rgba(255,60,60,0)");
            ctx.fillStyle = glow;
            ctx.beginPath(); ctx.arc(30, -14.5, 9, 0, 6.2832); ctx.fill();
            ctx.fillStyle = "#ff3030";
            ctx.beginPath(); ctx.arc(30, -14.5, 2.4, 0, 6.2832); ctx.fill();
        } else {
            ctx.fillStyle = "#2a1a10";
            ctx.beginPath(); ctx.arc(30, -14.5, 1.6, 0, 6.2832); ctx.fill();
        }
        ctx.restore();
    }

    function drawSleighBody(t) {
        // túi quà sau lưng
        ctx.fillStyle = "#7a4a26";
        ctx.beginPath(); ctx.ellipse(-20, -18, 11, 12, -0.2, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#1f6b45"; ctx.fillRect(-30, -32, 9, 9);
        ctx.fillStyle = "#e8b64c"; ctx.fillRect(-21, -34, 8, 8);
        ctx.fillStyle = "#3b6fd1"; ctx.fillRect(-27, -38, 7, 7);
        ctx.fillStyle = "#c0282f"; ctx.fillRect(-26.2, -32, 1.6, 9); ctx.fillRect(-30, -28.3, 9, 1.6);

        // ông già Noel
        ctx.fillStyle = "#c0282f";
        ctx.beginPath(); ctx.ellipse(2, -15, 10, 11, 0, 0, 6.2832); ctx.fill();   // thân áo
        ctx.fillStyle = "#fff";
        ctx.fillRect(-2, -8, 10, 2.5);                                             // viền áo
        ctx.fillStyle = "#23283d"; ctx.fillRect(-7, -12, 18, 3);                   // thắt lưng
        ctx.fillStyle = "#e8b64c"; ctx.fillRect(1, -12.5, 3.5, 4);
        // tay cầm dây cương
        ctx.strokeStyle = "#c0282f"; ctx.lineWidth = 4; ctx.lineCap = "round";
        ctx.beginPath(); ctx.moveTo(6, -19); ctx.lineTo(12, -18 + Math.sin(t * 6) * 1.5); ctx.stroke();
        ctx.fillStyle = "#23283d";
        ctx.beginPath(); ctx.arc(13, -18 + Math.sin(t * 6) * 1.5, 2.3, 0, 6.2832); ctx.fill();
        // mặt + râu
        ctx.fillStyle = "#f5c9a8";
        ctx.beginPath(); ctx.arc(5, -30, 6, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.beginPath(); ctx.ellipse(6, -25, 6.5, 5.5, 0, 0, 6.2832); ctx.fill();
        ctx.fillStyle = "#e05a5a";
        ctx.beginPath(); ctx.arc(9.5, -29.5, 1.5, 0, 6.2832); ctx.fill();        // mũi
        ctx.fillStyle = "#1e2233";
        ctx.beginPath(); ctx.arc(7.5, -32, 0.9, 0, 6.2832); ctx.fill();          // mắt
        // mũ bay phấp phới về sau
        var flap = Math.sin(t * 5) * 2;
        ctx.fillStyle = "#c0282f";
        ctx.beginPath();
        ctx.moveTo(-1, -33); ctx.quadraticCurveTo(0, -44, -12, -40 + flap); ctx.lineTo(11, -34);
        ctx.closePath(); ctx.fill();
        ctx.fillStyle = "#fff";
        ctx.fillRect(-2, -36, 14, 3.4);
        ctx.beginPath(); ctx.arc(-12.5, -40 + flap, 2.6, 0, 6.2832); ctx.fill();

        // thân xe trượt tuyết
        var g = ctx.createLinearGradient(0, -12, 0, 10);
        g.addColorStop(0, "#d93a41");
        g.addColorStop(1, "#8f1b21");
        ctx.fillStyle = g;
        ctx.beginPath();
        ctx.moveTo(-34, -14);
        ctx.quadraticCurveTo(-38, 8, -22, 9);
        ctx.lineTo(18, 9);
        ctx.quadraticCurveTo(30, 8, 31, -6);
        ctx.quadraticCurveTo(33, -16, 26, -18);
        ctx.quadraticCurveTo(22, -12, 18, -6);
        ctx.lineTo(-24, -6);
        ctx.quadraticCurveTo(-28, -12, -34, -14);
        ctx.closePath();
        ctx.fill();
        // viền vàng
        ctx.strokeStyle = "#e8b64c";
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(-30, 2); ctx.lineTo(22, 2);
        ctx.stroke();
        ctx.beginPath(); ctx.arc(26, -15, 3, 0, 6.2832); ctx.stroke();
        // càng + ván trượt vàng
        ctx.lineWidth = 2.4;
        ctx.beginPath();
        ctx.moveTo(-18, 9); ctx.lineTo(-18, 15);
        ctx.moveTo(12, 9); ctx.lineTo(12, 15);
        ctx.moveTo(-34, 15);
        ctx.lineTo(28, 15);
        ctx.quadraticCurveTo(40, 15, 38, 5);
        ctx.quadraticCurveTo(36, 1, 33, 4);
        ctx.stroke();
    }


    // ông già Noel ngồi xe trượt (không kéo tuần lộc để hình khớp đúng vùng va chạm). (cx, cy) = tâm vùng va chạm
    function drawSanta(cx, cy, rot, now) {
        var k = SC * 100 * SPRITE_SIZE;           // 1 đơn vị hình vẽ ≈ SPRITE_SIZE đơn vị thế giới
        ctx.save();
        ctx.translate(cx, cy);
        ctx.rotate(rot);
        ctx.scale(k, k);
        ctx.translate(-1, 16);
        drawSleighBody(now / 1000);
        ctx.restore();
    }

    /* ---------- VÒNG LẶP ---------- */
    var TICK = 1000 / C.TPS;
    function frame(now) {
        if (!gate.isConnected) return;
        var dtMs = now - lastFrame;
        lastFrame = now;
        var dt = Math.min(dtMs / 16.67, 3);

        if (state === "playing") {
            acc += Math.min(dtMs, 250);
            var steps = 0;
            while (acc >= TICK && steps < 12 && state === "playing") {
                var f = pendingFlap;
                pendingFlap = false;
                acc -= TICK; steps++;
                if (sim.step(f)) die();
            }
        }

        ctx.clearRect(0, 0, W, H);

        // tuyết rơi
        if (!REDUCED) {
            ctx.fillStyle = "#fff";
            for (var i = 0; i < flakes.length; i++) {
                var fl = flakes[i];
                fl.y += fl.vy * dt; fl.dr += 0.012 * dt; fl.x += Math.sin(fl.dr) * 0.3 * dt - (state === "playing" ? 0.8 * dt : 0);
                if (fl.y > H + 6 || fl.x < -10) { flakes[i] = makeFlake(false); continue; }
                ctx.globalAlpha = fl.a;
                ctx.beginPath(); ctx.arc(fl.x, fl.y, fl.r, 0, 6.2832); ctx.fill();
            }
            ctx.globalAlpha = 1;
        }

        var alpha = state === "playing" ? Math.min(1, acc / TICK) : 1;
        var gy = sy(C.GROUND);

        // cột người tuyết
        if (sim) {
            var w = C.PW * SC;
            for (var p = 0; p < sim.pipes.length; p++) {
                var pp = sim.pipes[p];
                var x = pp.px + (pp.x - pp.px) * alpha;
                var left = sx(x);
                if (left > W + 10 || left + w < -10) continue;
                var hat = (pp.top >> 3) & 1;
                drawColumn(left + w / 2, w, sy(pp.top), 0, -1, hat);
                drawColumn(left + w / 2, w, sy(pp.top + pp.gap), PH, 1, 1 - hat);
            }
            if (state === "playing") groundOff += (C.SPEED0 + sim.score * C.SPEED_INC > C.SPEED_MAX ? C.SPEED_MAX : C.SPEED0 + sim.score * C.SPEED_INC) * SC * dt;
        }
        drawGround(gy);

        // ông già Noel
        var cy, rot;
        if (state === "ready") {
            cy = sy(C.START_Y) + Math.sin(now / 320) * 6;
            rot = Math.sin(now / 640) * 0.05;
        } else if (state === "playing") {
            var y = sim.y - sim.vy * (1 - alpha);
            cy = sy(y);
            rot = Math.max(-0.45, Math.min(0.9, sim.vy / 1100 * 0.7));
        } else if (state === "dead" || state === "result") {
            if (deadY < gy - 10) { deadVy += 0.5 * dt; deadY += deadVy * dt; deadRot += 0.08 * dt; }
            cy = Math.min(deadY, gy - 10); rot = 0.9 + deadRot;
        } else {
            cy = sy(C.START_Y); rot = 0;
        }
        if (state !== "opening") {
            // bụi sao sau xe
            if (state === "playing" || state === "ready") {
                dust.push({ x: BX - 38 * SC * 100 * SPRITE_SIZE, y: cy + 4, vx: -(1.5 + Math.random() * 2), vy: (Math.random() - 0.5) * 0.8, r: 1.2 + Math.random() * 2, life: 1, c: Math.random() < 0.6 ? "#ffe39a" : "#fff" });
            }
            for (var dI = dust.length - 1; dI >= 0; dI--) {
                var ds = dust[dI];
                ds.x += ds.vx * dt; ds.y += ds.vy * dt; ds.life -= 0.025 * dt;
                if (ds.life <= 0) { dust.splice(dI, 1); continue; }
                ctx.globalAlpha = ds.life;
                ctx.fillStyle = ds.c;
                ctx.beginPath(); ctx.arc(ds.x, ds.y, ds.r, 0, 6.2832); ctx.fill();
            }
            ctx.globalAlpha = 1;
            drawSanta(BX, cy, rot, now);
        }

        // mảnh tuyết vỡ khi đâm
        for (var q = parts.length - 1; q >= 0; q--) {
            var pt = parts[q];
            pt.vy += 0.18 * dt; pt.x += pt.vx * dt; pt.y += pt.vy * dt; pt.life -= 0.02 * dt;
            if (pt.life <= 0) { parts.splice(q, 1); continue; }
            ctx.globalAlpha = pt.life;
            ctx.fillStyle = "#fff";
            ctx.beginPath(); ctx.arc(pt.x, pt.y, pt.r, 0, 6.2832); ctx.fill();
        }
        ctx.globalAlpha = 1;

        // điểm lớn khi đang bay
        if (state === "playing" || state === "dead") {
            ctx.font = "800 " + Math.round(Math.max(44, PH * 0.09)) + "px 'Be Vietnam Pro', 'Segoe UI', sans-serif";
            ctx.textAlign = "center";
            ctx.textBaseline = "top";
            ctx.lineWidth = 7;
            ctx.strokeStyle = "rgba(27,36,71,.85)";
            ctx.strokeText(String(sim.score), W / 2, 22);
            ctx.fillStyle = "#fff";
            ctx.fillText(String(sim.score), W / 2, 22);
        }

        requestAnimationFrame(frame);
    }

    /* ---------- ĐIỀU KHIỂN ---------- */
    function modalOpen() { return !!document.querySelector(".xm-rules-overlay.open, .xm-board-overlay.open"); }

    cv.addEventListener("pointerdown", function (e) {
        e.preventDefault();
        if (modalOpen()) return;
        if (state === "result") { if (performance.now() - resultAt > 900) replay(); return; }
        flap();
    });

    document.addEventListener("keydown", function (e) {
        if (!gate.isConnected || opened || modalOpen()) return;
        var k = e.key;
        if (k === "Escape") {
            e.preventDefault();
            if (state === "result" || (skip && skip.classList.contains("show") && state !== "dead")) openNow(false);
            return;
        }
        if (state === "result") {
            if (k === "Enter") { e.preventDefault(); openNow(false); }
            else if ((k === " " || k === "Spacebar" || k === "r" || k === "R") && !e.repeat && performance.now() - resultAt > 900) { e.preventDefault(); replay(); }
            else if (k === " ") e.preventDefault();
            return;
        }
        if (k === " " || k === "Spacebar" || k === "ArrowUp" || k === "w" || k === "W") {
            e.preventDefault();
            if (!e.repeat) flap();                 // giữ phím không tự bay — phải bấm từng cái
        }
    });

    document.addEventListener("visibilitychange", function () { if (document.hidden) abortForHidden(); });

    if (skip) {
        skip.addEventListener("click", function (e) { e.stopPropagation(); openNow(false); });
        if (SKIP_AFTER_MS === 0) skip.classList.add("show");
        else if (SKIP_AFTER_MS > 0) setTimeout(function () { skip.classList.add("show"); }, SKIP_AFTER_MS);
    }

    window.addEventListener("resize", resize);
    resize();
    requestSession();
    gate.focus({ preventScroll: true });
    requestAnimationFrame(frame);
})();
