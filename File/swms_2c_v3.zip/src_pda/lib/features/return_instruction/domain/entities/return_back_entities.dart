// ─────────────────────────────────────────────────────────────
//  Mục 2c — đề nghị nhận lại hàng về FA, phần PDA nhìn thấy.
//
//  PDA chỉ lo BƯỚC CUỐI: SCS WH quét Pallet ID giao hàng cho FA. Hai bước
//  trước (FA tạo đề nghị, quản lý FA xác nhận) làm trên Web — không ai soạn
//  một đề nghị trên máy quét.
//
//  Vì vậy ở đây chỉ có vừa đủ để DỰNG LẠI màn giao hàng: số đề nghị, phiếu,
//  bảng model, và các con số tiến độ. Không chép toàn bộ DTO của Web.
// ─────────────────────────────────────────────────────────────

/// Bước đang chờ. Khớp `ReturnBackStep` bên API — lệch một ký tự là màn lọc
/// ra danh sách rỗng mà không báo lỗi gì.
enum BackStep {
  faApprove('fa_approve'),
  scsDeliver('scs_deliver'),
  done('done');

  const BackStep(this.code);
  final String code;

  static BackStep from(String? v) => BackStep.values.firstWhere(
        (e) => e.code == v,
        // Mã lạ (API thêm bước mới mà PDA chưa cập nhật) coi như ĐÃ XONG: thà
        // không hiện ra còn hơn hiện một đề nghị mà bấm vào thì server chặn.
        orElse: () => BackStep.done,
      );
}

/// Trạng thái đề nghị. Khớp `ReturnBackStatus` bên API.
enum BackStatus {
  faRequested('fa_requested'),
  faApproved('fa_approved'),
  delivered('delivered'),
  cancelled('cancelled');

  const BackStatus(this.code);
  final String code;

  static BackStatus from(String? v) => BackStatus.values.firstWhere(
        (e) => e.code == v,
        orElse: () => BackStatus.faRequested,
      );
}

class BackRequestLine {
  final int lineNo;
  final String model;

  /// SL của model này trong đề nghị — suy từ phiếu, không ai nhập.
  final int qty;

  /// Số serial đã thực giao cho model này.
  final int deliveredQty;

  const BackRequestLine({
    required this.lineNo,
    required this.model,
    required this.qty,
    required this.deliveredQty,
  });

  int get remainQty => qty - deliveredQty < 0 ? 0 : qty - deliveredQty;
  bool get isDone => deliveredQty >= qty;
}

class BackRequest {
  final int id;
  final int docId;
  final String reqNo;
  final String? docNo;
  final String? goodsType;
  final BackStatus status;
  final BackStep step;
  final String? note;

  final int modelCount;
  final int totalQty;

  /// Đã giao được bao nhiêu con.
  final int deliveredQty;

  /// Còn bao nhiêu con chưa giao. API tính, PDA KHÔNG trừ lại: con đã đánh
  /// `ng` không còn chờ giao, trừ bằng tay sẽ ra số khác.
  final int remainQty;

  final String? requestedBy;
  final DateTime? requestedAt;
  final String? faApprovedBy;
  final DateTime? faApprovedAt;

  final List<BackRequestLine> lines;

  const BackRequest({
    required this.id,
    required this.docId,
    required this.reqNo,
    required this.docNo,
    required this.goodsType,
    required this.status,
    required this.step,
    required this.note,
    required this.modelCount,
    required this.totalQty,
    required this.deliveredQty,
    required this.remainQty,
    required this.requestedBy,
    required this.requestedAt,
    required this.faApprovedBy,
    required this.faApprovedAt,
    required this.lines,
  });

  /// Đang chờ SCS WH giao hàng — đúng cái PDA được phép làm.
  bool get isDeliverable => step == BackStep.scsDeliver;

  bool get isDelivered => status == BackStatus.delivered;

  /// Đã giao được pallet nào nhưng chưa hết.
  bool get isPartlyDelivered => !isDelivered && deliveredQty > 0;

  bool get isRework => goodsType == 'rework';
}

/// Một pallet đã giao (`wms.return_back_deliveries`).
class BackDelivery {
  final String lotNo;
  final int serialCount;
  final DateTime deliveredAt;
  final String? deliveredBy;

  const BackDelivery({
    required this.lotNo,
    required this.serialCount,
    required this.deliveredAt,
    required this.deliveredBy,
  });
}

/// Kết quả MỘT lượt quét.
///
/// `notFoundLots` là mã không có trong hệ thống, `emptyLots` là pallet có thật
/// nhưng không còn con nào của phiếu. Tách hai danh sách vì WH xử lý khác nhau:
/// cái đầu là quét sai mã, cái sau là pallet đã rỗng.
class BackDeliverResult {
  final int deliveredQty;
  final int remainQty;
  final bool completed;
  final List<BackDelivery> pallets;
  final List<String> notFoundLots;
  final List<String> emptyLots;
  final BackRequest? request;

  const BackDeliverResult({
    required this.deliveredQty,
    required this.remainQty,
    required this.completed,
    required this.pallets,
    required this.notFoundLots,
    required this.emptyLots,
    required this.request,
  });

  bool get anyMoved => deliveredQty > 0;
  bool get anyRejected => notFoundLots.isNotEmpty || emptyLots.isNotEmpty;
}
