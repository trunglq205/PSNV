﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using Microsoft.CSharp;

namespace SWMS_WebTool.ViewModels
{
    public class BarcodeNGViewModel : TableViewModel<BarcodeNG, BarcodeNGFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, BarcodeNGFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Vendor = filter?.Vendor ?? Filter.Vendor,
                DeliveryPlanNo = filter?.DeliveryPlanNo ?? Filter.DeliveryPlanNo,
                Plant = filter?.Plant ?? Filter.Plant,
                Category = filter?.Category ?? Filter.Category,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Material = filter?.Material ?? Filter.Material,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
