import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_text_field.dart';
import 'package:swms_finish_goods/features/stocktake/domain/entities/stocktake_entities.dart';
import 'package:swms_finish_goods/features/stocktake/presentation/providers/stocktake_providers.dart';

/// Sheet đếm các pallet tại 1 vị trí. Auto ĐÓNG NGAY khi lưu 1 pallet
/// (mỗi pallet 1 lần đếm). Trả `true` cho parent nếu có thay đổi để reload.
///
/// Kiểm cuối tháng theo ô:
///  - Ô trống theo hệ thống: "Xác nhận trống" (đếm 0) hoặc "Có pallet" -> quét pallet phát sinh.
///  - Ô bất kỳ: "Pallet phát sinh" -> quét mã pallet thấy ở ô này mà hệ thống không ghi ở đây.
///    Mã quét đến qua scanStream (DataWedge); trang bên dưới tạm ngừng nghe khi sheet mở.
class StocktakeCountSheet extends ConsumerStatefulWidget {
  final int countId;
  final List<CountLine> lines;

  const StocktakeCountSheet({
    super.key,
    required this.countId,
    required this.lines,
  });

  @override
  ConsumerState<StocktakeCountSheet> createState() =>
      _StocktakeCountSheetState();
}

class _StocktakeCountSheetState extends ConsumerState<StocktakeCountSheet> {
  final Set<int> _busy = {};

  /// Dòng của ô này — cập nhật lại sau khi ghi pallet phát sinh.
  late List<CountLine> _lines = widget.lines;
  bool _changed = false;

  /// Đang chờ quét mã pallet phát sinh.
  bool _awaitPallet = false;
  bool _adding = false;
  int? _newLineId;
  StreamSubscription<String>? _scanSub;
  final _manualCtrl = TextEditingController();

  int get _locatorId => widget.lines.first.locatorId;

  @override
  void initState() {
    super.initState();
    _listenScanner();
  }

  Future<void> _listenScanner() async {
    final pda = await ref.read(pdaProvider.future);
    if (!mounted) return;
    _scanSub = pda.scanStream.listen((data) {
      if (!mounted || !_awaitPallet || _adding) return;
      final code = data.trim();
      if (code.isNotEmpty) _addFound(code);
    });
  }

  @override
  void dispose() {
    _scanSub?.cancel();
    _manualCtrl.dispose();
    super.dispose();
  }

  /// Ghi pallet phát sinh rồi nạp lại dòng của ô — dòng mới hiện ngay để nhập số đếm.
  Future<void> _addFound(String palletCode) async {
    setState(() => _adding = true);
    try {
      final lineId = await ref
          .read(stocktakeRepositoryProvider)
          .addFound(widget.countId, _locatorId, palletCode);
      _changed = true;
      final d = await ref.refresh(stocktakeDetailProvider(widget.countId).future);
      if (!mounted) return;
      _manualCtrl.clear();
      setState(() {
        _lines = d.lines.where((l) => l.locatorId == _locatorId).toList();
        _awaitPallet = false;
        _adding = false;
        _newLineId = lineId;
      });
    } catch (e) {
      if (mounted) {
        AppToastHelper.toastError(context, e.toString());
        setState(() => _adding = false);
      }
    }
  }

  Future<void> _save(CountLine line, int qty, {int? boxCount}) async {
    setState(() => _busy.add(line.id));
    try {
      await ref
          .read(stocktakeRepositoryProvider)
          .setCount(line.id, qty, boxCount: boxCount);
      // AUTO ĐÓNG NGAY sau khi lưu thành công.
      if (mounted) Navigator.pop(context, true);
    } catch (e) {
      if (mounted) {
        AppToastHelper.toastError(context, e.toString());
        setState(() => _busy.remove(line.id));
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final locator = widget.lines.first.locatorCode;
    final palletCount = _lines.where((l) => !l.isEmptySlot).length;
    return DraggableScrollableSheet(
      initialChildSize: 0.6,
      maxChildSize: 0.95,
      minChildSize: 0.35,
      expand: false,
      builder: (ctx, controller) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 8),
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.black26,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 8, 4),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        locator,
                        style: const TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        palletCount == 0
                            ? LocaleKeys.stocktake_empty_slot.tr()
                            : '$palletCount ${LocaleKeys.stocktake_pallets_word.tr()}',
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.pop(context, _changed),
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: ListView.separated(
                controller: controller,
                padding: EdgeInsets.fromLTRB(
                  12,
                  8,
                  12,
                  MediaQuery.of(context).viewInsets.bottom + 20,
                ),
                // Dòng của ô + ô cuối: khung ghi pallet phát sinh
                itemCount: _lines.length + 1,
                separatorBuilder: (_, _) => const SizedBox(height: 8),
                itemBuilder: (_, i) {
                  if (i == _lines.length) {
                    return _FoundPanel(
                      waiting: _awaitPallet,
                      adding: _adding,
                      controller: _manualCtrl,
                      onStart: () => setState(() => _awaitPallet = true),
                      onCancel: () => setState(() => _awaitPallet = false),
                      onSubmit: (code) {
                        if (code.trim().isNotEmpty) _addFound(code.trim());
                      },
                    );
                  }
                  final line = _lines[i];
                  if (line.isEmptySlot) {
                    return _EmptySlotRow(
                      line: line,
                      busy: _busy.contains(line.id),
                      onConfirm: () => _save(line, 0),
                      onHasPallet: () => setState(() => _awaitPallet = true),
                    );
                  }
                  return _PalletRow(
                    key: ValueKey(line.id),
                    line: line,
                    busy: _busy.contains(line.id),
                    highlight: line.id == _newLineId,
                    onSave: (l, qty, box) => _save(l, qty, boxCount: box),
                  );
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _PalletRow extends StatefulWidget {
  final CountLine line;
  final bool busy;

  /// Dòng phát sinh vừa ghi — viền cam để mắt tìm ngay.
  final bool highlight;

  /// (dòng, số lượng, số box đếm được) — số box null khi nhập thẳng số lượng
  /// mà không đếm box.
  final Future<void> Function(CountLine, int, int?) onSave;

  const _PalletRow({
    super.key,
    required this.line,
    required this.busy,
    this.highlight = false,
    required this.onSave,
  });

  @override
  State<_PalletRow> createState() => _PalletRowState();
}

class _PalletRowState extends State<_PalletRow> {
  /// Số box đếm được — ô người kiểm nhập ở trường hợp thường.
  late final TextEditingController _boxCtrl;

  /// Số lượng. Model có quy cách thì ô này do hệ thống tính, chỉ sửa được
  /// khi bật [_manual].
  late final TextEditingController _qtyCtrl;

  /// Nhập thẳng số lượng: model chưa khai quy cách (bắt buộc), hoặc thực tế
  /// lệch quy cách nên người kiểm tự bật.
  late bool _manual;

  @override
  void initState() {
    super.initState();
    final l = widget.line;

    // Pallet phát sinh không có số hệ thống ở ô này -> để trống, bắt buộc tự đếm.
    _boxCtrl = TextEditingController(
      text: l.boxCountCounted?.toString() ??
          (l.isFound ? '' : (l.boxCountSystem?.toString() ?? '')),
    );
    _qtyCtrl = TextEditingController(
      text: l.qtyCount?.toString() ?? (l.isFound ? '' : l.qtySystem.toString()),
    );

    // Chưa khai quy cách thì không có đường nào khác ngoài nhập thẳng.
    // Dòng đã đếm mà không lưu số box -> lần trước đã nhập thẳng, giữ nguyên.
    _manual = !l.hasPacking ||
        (l.qtyCount != null && l.boxCountCounted == null);
  }

  @override
  void dispose() {
    _boxCtrl.dispose();
    _qtyCtrl.dispose();
    super.dispose();
  }

  int? get _box {
    final v = int.tryParse(_boxCtrl.text.trim());
    return v == null || v < 0 ? null : v;
  }

  /// Số lượng sẽ lưu. Đếm theo box thì nhân quy cách, nhập thẳng thì lấy ô số lượng.
  int? get _qty {
    if (_manual) {
      final v = int.tryParse(_qtyCtrl.text.trim());
      return v == null || v < 0 ? null : v;
    }
    final b = _box;
    final p = widget.line.standardPacking ?? 0;
    return b == null || p <= 0 ? null : b * p;
  }

  /// Ô số lượng chỉ phản chiếu box × quy cách khi đếm theo box.
  void _syncQty() {
    if (_manual) return;
    final q = _qty;
    _qtyCtrl.text = q?.toString() ?? '';
  }

  @override
  Widget build(BuildContext context) {
    final line = widget.line;
    final packing = line.standardPacking ?? 0;
    final qty = _qty;

    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: widget.highlight ? _cFound : const Color(0xFFE3E8EE),
          width: widget.highlight ? 2 : 1,
        ),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            if (line.isFound) _FoundBadge(systemLocator: line.systemLocatorCode),
            Text(
              line.model ?? line.productName ?? '#${line.productId}',
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
            if (line.palletId != null)
              Padding(
                padding: const EdgeInsets.only(top: 2),
                child: Text(
                  line.palletId!,
                  style: const TextStyle(fontSize: 12, color: Colors.black54),
                ),
              ),

            // Số hệ thống nằm thành 1 dải mảnh, nhường hết chiều ngang cho 2 ô
            // nhập bên dưới — nhãn "Số box"/"Đếm thực" mới hiện đủ chữ.
            const SizedBox(height: 8),
            Container(
              width: double.infinity,
              padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 10),
              decoration: BoxDecoration(
                color: const Color(0xFFEFF4F8),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                children: [
                  Text(
                    '${LocaleKeys.stocktake_qty_system.tr()}: ',
                    style: const TextStyle(fontSize: 11, color: Colors.black54),
                  ),
                  Expanded(
                    child: Text(
                      // Có quy cách thì ghi rõ phép tính để người kiểm đối chiếu
                      // được ngay; không có thì chỉ ghi số lượng.
                      packing > 0 && line.boxCountSystem != null
                          ? LocaleKeys.stocktake_qty_calc.tr(args: [
                              '${line.boxCountSystem}',
                              '$packing',
                              '${line.qtySystem}',
                            ])
                          : LocaleKeys.stocktake_qty_pcs
                              .tr(args: ['${line.qtySystem}']),
                      style: const TextStyle(
                        fontWeight: FontWeight.w700,
                        fontSize: 13,
                        color: Color(0xFF2F6FB0),
                      ),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 10),
            Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Expanded(
                  child: AppTextField(
                    kind: AppInputKind.number,
                    controller: _boxCtrl,
                    label: LocaleKeys.stocktake_box_count.tr(),
                    suffixText: LocaleKeys.stocktake_box_word.tr(),
                    onChanged: (_) => setState(_syncQty),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: AppTextField(
                    kind: AppInputKind.number,
                    controller: _qtyCtrl,
                    label: LocaleKeys.stocktake_qty_count.tr(),
                    // Đếm theo box: số lượng do quy cách quyết định, chặn sửa tay
                    // để số box và số lượng không bao giờ lệch nhau.
                    readOnly: !_manual,
                    onChanged: _manual ? (_) => setState(() {}) : null,
                  ),
                ),
              ],
            ),

            // Lý do ô số lượng đang khoá / đang mở.
            Padding(
              padding: const EdgeInsets.only(top: 6),
              child: line.hasPacking
                  ? Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Row(
                          children: [
                            Checkbox(
                              value: _manual,
                              visualDensity: VisualDensity.compact,
                              materialTapTargetSize:
                                  MaterialTapTargetSize.shrinkWrap,
                              onChanged: widget.busy
                                  ? null
                                  : (v) => setState(() {
                                        _manual = v ?? false;
                                        _syncQty();
                                      }),
                            ),
                            Expanded(
                              child: GestureDetector(
                                onTap: widget.busy
                                    ? null
                                    : () => setState(() {
                                          _manual = !_manual;
                                          _syncQty();
                                        }),
                                child: Text(
                                  LocaleKeys.stocktake_manual_qty.tr(),
                                  style: const TextStyle(
                                    fontSize: 12,
                                    color: Colors.black54,
                                  ),
                                ),
                              ),
                            ),
                          ],
                        ),
                        // Nhập tay mà vẫn đếm được box: nói rõ quy cách ra bao
                        // nhiêu, để người kiểm thấy ngay mình đang lệch quy cách.
                        if (_manual && _box != null)
                          Padding(
                            padding: const EdgeInsets.only(left: 4, top: 2),
                            child: Text(
                              LocaleKeys.stocktake_qty_manual
                                  .tr(args: ['${_box! * packing}']),
                              style: const TextStyle(
                                fontSize: 11,
                                color: Color(0xFFB26A00),
                              ),
                            ),
                          ),
                      ],
                    )
                  : Text(
                      LocaleKeys.stocktake_no_packing.tr(),
                      style: const TextStyle(
                        fontSize: 11,
                        color: Color(0xFFB26A00),
                      ),
                    ),
            ),

            const SizedBox(height: 4),
            Row(
              children: [
                if (!line.isFound) ...[
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: widget.busy
                          ? null
                          : () => widget.onSave(
                                line,
                                line.qtySystem,
                                line.boxCountSystem,
                              ),
                      icon: widget.busy
                          ? const SizedBox(
                              width: 14,
                              height: 14,
                              child: CircularProgressIndicator(strokeWidth: 2),
                            )
                          : const Icon(Icons.check, size: 18),
                      label: Text(
                        '${LocaleKeys.stocktake_ok_match.tr()} (${line.qtySystem})',
                        overflow: TextOverflow.ellipsis,
                      ),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: const Color(0xFF2E8650),
                        side: const BorderSide(color: Color(0xFF2E8650)),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
                Expanded(
                  child: FilledButton.icon(
                    // Chưa đủ dữ liệu để tính ra số lượng thì không cho lưu,
                    // tránh ghi 0 vì ô còn trống.
                    onPressed: widget.busy || qty == null
                        ? null
                        : () => widget.onSave(line, qty, _box),
                    icon: const Icon(Icons.save, size: 18),
                    label: Text(LocaleKeys.stocktake_save.tr()),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Màu cho pallet phát sinh — cam, khác xanh (khớp) và đỏ (lệch) đang dùng.
const Color _cFound = Color(0xFFD9822B);

class _FoundBadge extends StatelessWidget {
  final String? systemLocator;
  const _FoundBadge({this.systemLocator});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 4),
      child: Row(
        children: [
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 2),
            decoration: BoxDecoration(
              color: _cFound,
              borderRadius: BorderRadius.circular(4),
            ),
            child: Text(
              LocaleKeys.stocktake_found_badge.tr(),
              style: const TextStyle(
                color: Colors.white,
                fontSize: 10,
                fontWeight: FontWeight.w800,
              ),
            ),
          ),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              systemLocator == null
                  ? LocaleKeys.stocktake_found_no_location.tr()
                  : LocaleKeys.stocktake_found_at.tr(args: [systemLocator!]),
              style: const TextStyle(fontSize: 11, color: Color(0xFF8A5A1E)),
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}

/// Dòng ô trống theo hệ thống: xác nhận trống, hoặc báo có pallet để quét.
class _EmptySlotRow extends StatelessWidget {
  final CountLine line;
  final bool busy;
  final VoidCallback onConfirm;
  final VoidCallback onHasPallet;

  const _EmptySlotRow({
    required this.line,
    required this.busy,
    required this.onConfirm,
    required this.onHasPallet,
  });

  @override
  Widget build(BuildContext context) {
    final confirmed = line.qtyCount != null;
    return Card(
      elevation: 0,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: const BorderSide(color: Color(0xFFE3E8EE)),
      ),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.crop_square, size: 18, color: Colors.black45),
                const SizedBox(width: 6),
                Text(
                  LocaleKeys.stocktake_empty_slot.tr(),
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Text(
                confirmed
                    ? LocaleKeys.stocktake_empty_confirmed.tr()
                    : LocaleKeys.stocktake_empty_slot_hint.tr(),
                style: const TextStyle(fontSize: 12, color: Colors.black54),
              ),
            ),
            const SizedBox(height: 10),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton.icon(
                    onPressed: busy ? null : onHasPallet,
                    icon: const Icon(Icons.qr_code_scanner, size: 18),
                    label: Text(LocaleKeys.stocktake_has_pallet.tr()),
                    style: OutlinedButton.styleFrom(
                      foregroundColor: _cFound,
                      side: const BorderSide(color: _cFound),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: FilledButton.icon(
                    onPressed: busy || confirmed ? null : onConfirm,
                    icon: busy
                        ? const SizedBox(
                            width: 14,
                            height: 14,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          )
                        : const Icon(Icons.check, size: 18),
                    label: Text(LocaleKeys.stocktake_confirm_empty.tr()),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

/// Khung ghi pallet phát sinh: nút mở, rồi chờ quét (hoặc gõ tay mã pallet).
class _FoundPanel extends StatelessWidget {
  final bool waiting;
  final bool adding;
  final TextEditingController controller;
  final VoidCallback onStart;
  final VoidCallback onCancel;
  final ValueChanged<String> onSubmit;

  const _FoundPanel({
    required this.waiting,
    required this.adding,
    required this.controller,
    required this.onStart,
    required this.onCancel,
    required this.onSubmit,
  });

  @override
  Widget build(BuildContext context) {
    if (!waiting) {
      return Align(
        alignment: Alignment.centerLeft,
        child: TextButton.icon(
          onPressed: onStart,
          icon: const Icon(Icons.add_box_outlined, color: _cFound),
          label: Text(
            LocaleKeys.stocktake_add_found.tr(),
            style: const TextStyle(color: _cFound, fontWeight: FontWeight.w700),
          ),
        ),
      );
    }
    return Container(
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFFFF4E8),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(color: const Color(0xFFF2C28F)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              adding
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.qr_code_scanner, color: _cFound),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  LocaleKeys.stocktake_scan_pallet_prompt.tr(),
                  style: const TextStyle(fontWeight: FontWeight.w700),
                ),
              ),
              IconButton(
                visualDensity: VisualDensity.compact,
                icon: const Icon(Icons.close, size: 18),
                onPressed: adding ? null : onCancel,
              ),
            ],
          ),
          const SizedBox(height: 8),
          // Dự phòng khi tem mờ/máy không quét được: gõ tay mã pallet.
          Row(
            children: [
              Expanded(
                child: AppTextField(
                  controller: controller,
                  label: LocaleKeys.stocktake_pallet_code.tr(),
                ),
              ),
              const SizedBox(width: 8),
              FilledButton(
                onPressed: adding ? null : () => onSubmit(controller.text),
                style: FilledButton.styleFrom(backgroundColor: _cFound),
                child: Text(LocaleKeys.stocktake_add_found_submit.tr()),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
