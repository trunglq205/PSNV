﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class SupplyController : BaseController
    {
        private readonly ApiService _apiService;

        public SupplyController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] SupplyFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());

                var _filter = new KittingListFilter()
                {
                    Model = filter.Modal,
                    Line = filter.Line,
                    Cate = filter.Category,
                    ProDate = filter.DeliveryDate.ToString("yyyy-MM-dd"),
                    Tab = filter.Tab,
                    Type = filter.Type,
                    IsLoadByTime = false,
                };

                var responseData = await _apiService.SearchKittingList(_filter, pageNumber, _pageSize);
                var total = responseData.TotalRecord;
                var items = responseData.Records ?? new List<KittingList>();

                var data = await _apiService.GetCategoryPlanMaster();
                var categoryMaster = data.Select(x => x.Category).Distinct().ToList();
                ViewBag.Categories = new SelectList(categoryMaster);

                var model = new SupplyViewModel()
                {
                    Items = items,
                    Filter = filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };

                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> SupplyStatus([FromQuery] SupplyFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());

                var _filter = new KittingListFilter()
                {
                    Model = filter.Modal,
                    Line = filter.Line,
                    Cate = filter.Category,
                    ProDate = filter.DeliveryDate.ToString("yyyy-MM-dd"),
                    Tab = filter.Tab,
                    Type = filter.Type,
                    IsLoadByTime = filter.IsLoadByTime,
                };

                var responseData = await _apiService.SearchKittingList(_filter, pageNumber, _pageSize);
                var total = responseData.TotalRecord;
                var items = filter.IsLoadByTime ? responseData.Records.OrderByDescending(s => s.Time).ToList() : responseData.Records ?? new List<KittingList>();
                var lstOverTime = items.Where(s =>
                {
                    TimeSpan itemTime = TimeSpan.Parse(s.Time);
                    TimeSpan currentTime = TimeSpan.Parse(filter.CurrentTime);
                    return itemTime < currentTime && s.Status == 0;
                }).ToList();
                if (lstOverTime.Any() && User.Identity.IsAuthenticated && filter.IsLoadByTime)
                {
                    foreach (var item in lstOverTime)
                    {
                        var request = new UpdateSupplyRequest
                        {
                            ID = item.ID,
                            Reason = Constants.OVERTIME_SUPPLY,
                            Status = 3
                        };
                        await _apiService.UpdateSupplyReason(request);
                    }
                }

                var data = await _apiService.GetCategoryPlanMaster();
                var categoryMaster = data.Select(x => x.Category).Distinct().ToList();
                ViewBag.Categories = new SelectList(categoryMaster);

                var model = new SupplyViewModel()
                {
                    Items = items,
                    Filter = filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };

                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewKittingListDetail(long kittingId)
        {
            var result = await _apiService.GetKittingListDetailByKTLId(kittingId);

            var tupple = new Tuple<List<KittingListDetail>, long>(result, kittingId);

            return PartialView("~/Views/Supply/_KittingListDetails.cshtml", tupple);
        }

        [HttpGet]
        public async Task<IActionResult> UpdateReasonView(string id)
        {
            var kittinglist = await _apiService.GetKittingListByID(long.Parse(id), null); ;
            var model = new UpdateSupplyRequest()
            {
                ID = kittinglist.ID,
                Reason = kittinglist.Reason,
                Status = kittinglist.Status
            };
            return PartialView("~/Views/Supply/_UpdateReasonModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmUpdateReason(UpdateSupplyRequest request)
        {
            try
            {
                await _apiService.UpdateSupplyReason(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}