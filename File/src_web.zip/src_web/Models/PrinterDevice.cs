﻿namespace SWMS_WebTool.Models
{
    public class PrinterDevice
    {
        public string Id { get; set; }
        public string MacAddress { get; set; }
        public Status Status { get; set; }
    }
}
