using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

/// <summary>
/// Mục 2d — FA quét serial đóng lại Pallet ID sau khi rework xong.
///
/// KHÁC mục 2a ở ba điểm, và cả ba đều là lý do không dùng chung service:
///   1. Serial đã CÓ trong sổ — chỉ cập nhật pallet_id, không chèn dòng mới.
///   2. FA không chọn model: sổ đã biết mỗi con thuộc model nào.
///   3. Serial lạ VẪN cho quét tiếp (yêu cầu nghiệp vụ), chỉ bị loại khỏi
///      pallet và ghi nhật ký — ngược hẳn mục 2a, nơi serial lạ bị CHẶN.
/// </summary>
public class ReturnFaPalletService : IReturnFaPalletService
{
    /// <summary>Trần serial / thùng một pallet — cùng mức với mục 2a.</summary>
    private const int MaxSerialsPerPallet = 500;

    private const int MaxBoxesPerPallet = 100;
    private const int MaxSerialLength = 50;
    private const int MaxBoxNoLength = 50;

    /// <summary>
    /// Số lần thử xin Pallet ID. <c>GenerateNextLotNoAsync</c> KHÔNG giữ chỗ nên
    /// hai người bấm Lưu cùng lúc nhận cùng một số. Cùng lý do ở mục 2a.
    /// </summary>
    private const int LotNoAttempts = 3;

    private readonly IReturnInstructionRepository _repo;
    private readonly IPalletService _pallets;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly ILogger<ReturnFaPalletService> _logger;

    public ReturnFaPalletService(
        IReturnInstructionRepository repo,
        IPalletService pallets,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        ILogger<ReturnFaPalletService> logger)
    {
        _repo = repo;
        _pallets = pallets;
        _currentUser = currentUser;
        _localizer = localizer;
        _logger = logger;
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    public async Task<IReadOnlyList<ReturnSerialIndexResponse>> GetSerialIndexAsync(long docId)
    {
        _ = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        return (await _repo.GetSerialIndexAsync(docId))
            .Select(ReturnSerialIndexResponse.From).ToList();
    }

    public async Task<CreateFaPalletResponse> CreateAsync(
        long docId, CreateFaPalletRequest request)
    {
        var doc = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        var boxes = CleanBoxes(request);
        var allSerials = boxes.SelectMany(b => b.Serials).ToList();

        // ── Phân loại từng serial ─────────────────────────────────────
        var owners = (await _repo.ResolveSerialsAsync(allSerials))
            .GroupBy(o => o.SerialNo, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

        var matched = new List<(string BoxNo, string Model, string Serial)>();
        var mismatches = new List<ReturnSerialMismatch>();

        foreach (var b in boxes)
            foreach (var s in b.Serials)
            {
                if (!owners.TryGetValue(s, out var o))
                {
                    // Không thuộc sổ nào: hàng lạ hoàn toàn.
                    mismatches.Add(new ReturnSerialMismatch
                    {
                        SerialNo = s,
                        Reason = ReturnMismatchReason.NotInDoc,
                    });
                    continue;
                }

                if (o.DocId != docId)
                {
                    // Thuộc phiếu khác — nói rõ phiếu nào để FA trả về đúng chỗ.
                    mismatches.Add(new ReturnSerialMismatch
                    {
                        SerialNo = s,
                        Model = o.Model,
                        Reason = ReturnMismatchReason.OtherDoc,
                        FoundStatus = o.Status,
                        OtherDocNo = o.DocNo,
                    });
                    continue;
                }

                if (o.Status != ReturnSerialStatus.AtFa)
                {
                    // Đúng phiếu nhưng chưa từng giao FA / đã về / đã xuất / ng.
                    mismatches.Add(new ReturnSerialMismatch
                    {
                        SerialNo = s,
                        Model = o.Model,
                        Reason = ReturnMismatchReason.WrongStatus,
                        FoundStatus = o.Status,
                    });
                    continue;
                }

                // Model lấy từ SỔ, không từ request: FA không nhập model, và sổ
                // là nơi duy nhất biết đúng.
                matched.Add((b.BoxNo, o.Model!, s));
            }

        // ── Không con nào khớp ────────────────────────────────────────
        if (matched.Count == 0)
        {
            // Nhật ký lưu TRƯỚC rồi mới ném lỗi: đây chính là danh sách SCS cần
            // để đặt hàng lạ riêng ra. Ném lỗi mà không lưu là mất sạch thông
            // tin của cả lần quét.
            await _repo.AddMismatchesAsync(docId, mismatches, Actor);

            _logger.LogWarning(
                "FA quet {Count} serial vao phieu {DocNo} nhung KHONG con nao dang o at_fa — "
                + "da ghi {Mismatch} dong vao nhat ky lech.",
                allSerials.Count, doc.DocNo, mismatches.Count);

            throw new BusinessRuleException(
                _localizer[FaMsg.NothingMatched, doc.DocNo, mismatches.Count]);
        }

        // ── Category: Pallet ID nhúng mã category nên một pallet một category ──
        var models = matched.Select(m => m.Model)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var catOf = await _repo.GetCategoryByModelAsync(models);

        var noCategory = models.Where(m => !catOf.ContainsKey(m)).ToList();
        if (noCategory.Count > 0)
            throw new BusinessRuleException(
                _localizer[FaMsg.CategoryUnknown, string.Join(", ", noCategory)]);

        var categories = models.Select(m => catOf[m]).Distinct().ToList();
        if (categories.Count > 1)
            throw new BusinessRuleException(_localizer[FaMsg.CategoryMixed,
                string.Join(", ", models.Select(m => $"{m} ({catOf[m]:D3})"))]);

        var categoryCode = categories[0];

        // ── Tạo pallet ────────────────────────────────────────────────
        CreatePalletResponse created;
        for (var attempt = 1; ; attempt++)
        {
            var lotNo = (await _pallets.GenerateNextLotNoAsync(categoryCode)).LotNo;

            // Thùng không quét được mã thì đặt tên theo Pallet ID, tính ở đây để
            // pallet và sổ serial dùng CÙNG một mã thùng.
            var boxNoOf = new Dictionary<string, string>(StringComparer.OrdinalIgnoreCase);
            var i = 0;
            foreach (var b in boxes)
            {
                i++;
                boxNoOf[b.Key] = b.Generated ? $"{lotNo}-{i:D2}" : b.BoxNo;
            }

            // Một thùng có thể chứa nhiều model (phiếu nhiều model cùng
            // category), nên nhóm theo (thùng, model) — mỗi nhóm một dòng box.
            var grouped = matched
                .GroupBy(m => (Box: boxNoOf[m.BoxNo], m.Model))
                .Select(g => (BoxNo: g.Key.Box, g.Key.Model,
                              Serials: g.Select(x => x.Serial).ToList()))
                .ToList();

            var palletRequest = ReturnPalletRequestFactory.Build(lotNo, categoryCode, grouped);

            var serialRows = matched
                .Select(m => new ReturnFaSerialRow
                {
                    SerialNo = m.Serial,
                    BoxNo = boxNoOf[m.BoxNo],
                })
                .ToList();

            try
            {
                // Hook chạy TRONG transaction tạo pallet: pallet, sổ serial và
                // nhật ký lệch cùng sống cùng chết.
                created = await _pallets.CreateAsync(palletRequest,
                    onInserted: async (conn, tx, palletDbId) =>
                    {
                        await _repo.AttachFaPalletAsync(
                            conn, tx, docId, palletDbId, doc.GoodsType, serialRows, Actor);
                        await _repo.AddMismatchesAsync(
                            conn, tx, docId, palletDbId, mismatches, Actor);
                    });
                break;
            }
            // Pallet ID bị người khác lấy — nhận ra bằng chính số vừa xin trong
            // câu lỗi, không bắt mọi ConflictException. Xem ghi chú ở mục 2a.
            catch (ConflictException ex)
                when (attempt < LotNoAttempts
                      && ex.Message.Contains(lotNo, StringComparison.Ordinal))
            {
                _logger.LogInformation(
                    "Pallet ID {LotNo} vua bi nguoi khac lay khi FA dong pallet phieu {DocNo} — xin so moi (lan {Attempt}).",
                    lotNo, doc.DocNo, attempt);
            }
            catch (Microsoft.Data.SqlClient.SqlException ex)
                when (attempt < LotNoAttempts && IsPalletIdCollision(ex))
            {
                _logger.LogInformation(
                    "Pallet ID {LotNo} trung tai unique index khi FA dong pallet phieu {DocNo} — xin so moi (lan {Attempt}).",
                    lotNo, doc.DocNo, attempt);
            }
        }

        var saved = await _repo.GetByIdAsync(docId) ?? doc;
        var logged = await _repo.GetMismatchesAsync(docId, openOnly: true);

        return new CreateFaPalletResponse(
            created.Id,
            created.LotNo,
            categoryCode,
            created.BoxCount,
            matched.Count,
            mismatches.Count,
            // Trả nhật ký CÒN MỞ của cả phiếu, không chỉ lần quét này: FA rời
            // bàn là SCS đọc màn hình này, họ cần cả những con lần trước chưa
            // ai đặt riêng ra.
            logged.Select(ReturnMismatchResponse.From).ToList(),
            ReturnInstructionResponse.From(saved));
    }

    public async Task<IReadOnlyList<ReturnMismatchResponse>> GetMismatchesAsync(
        long docId, bool openOnly)
    {
        _ = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        return (await _repo.GetMismatchesAsync(docId, openOnly))
            .Select(ReturnMismatchResponse.From).ToList();
    }

    public async Task<ReturnMismatchResponse> ResolveMismatchAsync(
        long id, ResolveMismatchRequest request)
    {
        if (!await _repo.ResolveMismatchAsync(id, Trim(request.Note), Actor))
            // Không phân biệt "không có" với "đã xử lý rồi" bằng hai câu query
            // nữa: cả hai đều dẫn tới cùng một việc của người dùng là tải lại.
            throw new ConflictException(_localizer[FaMsg.AlreadyResolved, id]);

        // Đọc lại để trả về đúng người / lúc server đã ghi, chứ không dựng
        // response từ giá trị client gửi lên.
        var row = await _repo.GetMismatchByIdAsync(id)
            ?? throw new NotFoundException(_localizer[FaMsg.MismatchNotFound, id]);

        return ReturnMismatchResponse.From(row);
    }

    // ───────────────────────────── Hỗ trợ ─────────────────────────────

    /// <summary>Một thùng đã chuẩn hoá. <c>Key</c> dùng để gom nhóm.</summary>
    private sealed record CleanBox(string Key, string BoxNo, bool Generated, List<string> Serials);

    private List<CleanBox> CleanBoxes(CreateFaPalletRequest request)
    {
        if (request.Boxes.Count == 0)
            throw new BusinessRuleException(_localizer[FaMsg.BoxesRequired]);

        if (request.Boxes.Count > MaxBoxesPerPallet)
            throw new BusinessRuleException(
                _localizer[FaMsg.TooManyBoxes, MaxBoxesPerPallet]);

        var boxes = new List<CleanBox>(request.Boxes.Count);
        var seenBoxNo = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var seenSerial = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var total = 0;

        var n = 0;
        foreach (var b in request.Boxes)
        {
            n++;
            var boxNo = b.BoxNo?.Trim();
            var generated = string.IsNullOrEmpty(boxNo);

            // Kiểm độ dài TRƯỚC transaction: để DB chặn sẽ ném lỗi truncation
            // thô giữa transaction, không dịch được thành câu người đọc hiểu.
            if (!generated && boxNo!.Length > MaxBoxNoLength)
                throw new BusinessRuleException(
                    _localizer[FaMsg.ValueTooLong, boxNo, MaxBoxNoLength]);

            if (!generated && !seenBoxNo.Add(boxNo!))
                throw new BusinessRuleException(_localizer[FaMsg.BoxNoDuplicated, boxNo!]);

            if (b.Serials is null || b.Serials.Count == 0)
                throw new BusinessRuleException(_localizer[FaMsg.SerialRequired]);

            var serials = new List<string>(b.Serials.Count);
            foreach (var raw in b.Serials)
            {
                var s = raw?.Trim();
                if (string.IsNullOrEmpty(s))
                    throw new BusinessRuleException(_localizer[FaMsg.SerialRequired]);

                if (s.Length > MaxSerialLength)
                    throw new BusinessRuleException(
                        _localizer[FaMsg.ValueTooLong, s, MaxSerialLength]);

                if (!seenSerial.Add(s))
                    throw new BusinessRuleException(
                        _localizer[FaMsg.SerialDuplicatedInRequest, s]);

                serials.Add(s);
            }

            total += serials.Count;
            if (total > MaxSerialsPerPallet)
                throw new BusinessRuleException(
                    _localizer[FaMsg.TooManySerials, MaxSerialsPerPallet]);

            // Key phải ổn định và KHÁC NHAU giữa các thùng không mã, nên lấy số
            // thứ tự — dùng chính boxNo rỗng sẽ gom hết thùng không mã vào một.
            boxes.Add(new CleanBox(
                Key: generated ? $"#{n}" : boxNo!,
                BoxNo: generated ? $"#{n}" : boxNo!,
                Generated: generated,
                Serials: serials));
        }

        return boxes;
    }

    /// <summary>
    /// Trùng Pallet ID ở unique index của <c>wms.pallets</c>. Giống hàm cùng tên
    /// ở mục 2a — giữ riêng để hai luồng không phụ thuộc nhau.
    /// </summary>
    private static bool IsPalletIdCollision(Microsoft.Data.SqlClient.SqlException ex)
        => IsUniqueViolation(ex)
           && ex.Errors.Cast<Microsoft.Data.SqlClient.SqlError>()
               .Any(e => e.Message.Contains("pallet", StringComparison.OrdinalIgnoreCase)
                         && !e.Message.Contains("ris_", StringComparison.OrdinalIgnoreCase));

    private static bool IsUniqueViolation(Microsoft.Data.SqlClient.SqlException ex)
        => ex.Errors.Cast<Microsoft.Data.SqlClient.SqlError>()
            .Any(e => e.Number is 2601 or 2627);

    private static string? Trim(string? s)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        var t = s.Trim();
        return t.Length <= 500 ? t : t[..500];
    }
}
