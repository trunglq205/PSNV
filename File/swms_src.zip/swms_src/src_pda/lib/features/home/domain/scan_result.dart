/// Loại đối tượng mà mã quét trỏ tới (khớp field `type` của API).
enum ScanType {
  pallet,
  box,
  serial,
  recvLocation,
  storageLocation,
  model,

  /// Tem Part Card đã in — tra `wms.part_cards` theo payload.
  partCard,
  notFound;

  static ScanType fromApi(String? type) => switch (type) {
    'pallet' => ScanType.pallet,
    'box' => ScanType.box,
    'serial' => ScanType.serial,
    'recv_location' => ScanType.recvLocation,
    'storage_location' => ScanType.storageLocation,
    'model' => ScanType.model,
    'part_card' => ScanType.partCard,
    _ => ScanType.notFound,
  };
}

/// Trạng thái tem Part Card do server tính (`ScanPartCardInfo`).
///
/// App chỉ đọc các cờ `can*` để bật / tắt Sửa / Tách / Gộp — luật nằm ở server
/// (cùng luật với API sửa / tách / gộp), không suy luận lại ở đây.
class PartCardScanInfo {
  const PartCardScanInfo({
    required this.cardId,
    required this.modelCount,
    required this.boxCount,
    required this.isLocked,
    required this.statusOqc,
    required this.canEdit,
    required this.canSplit,
    required this.canMerge,
  });

  /// Card_ID in trên tem.
  final String cardId;
  final int modelCount;

  /// Số thùng khi tem 1 mã; tem nhiều mã = 0.
  final int boxCount;

  /// Khoá tay.
  final bool isLocked;

  /// 0 = chưa vào OQC.
  final int statusOqc;

  bool get inOqc => statusOqc != 0;

  final bool canEdit;
  final bool canSplit;
  final bool canMerge;
}

/// Kết quả phân loại mã quét ở Home (GET /api/scan/resolve).
class ScanResult {
  /// Mã đã chuẩn hoá. Với tem Part Card = payload gốc.
  final String code;
  final ScanType type;
  final int? id;

  /// Chỉ có với vị trí: "RECV" | "VANNING" | "STORAGE"...
  final String? areaCode;

  /// Chỉ có với [ScanType.partCard].
  final PartCardScanInfo? partCard;

  const ScanResult({
    required this.code,
    required this.type,
    this.id,
    this.areaCode,
    this.partCard,
  });

  bool get isFound => type != ScanType.notFound;
}