import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/presentation/providers/container_check_state.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/container_card.dart';

/// Chế độ danh sách: khung quét QR + danh sách container trong ca.
class ContainerListView extends ConsumerWidget {
  final ContainerCheckState state;
  final Future<void> Function() onRefresh;
  final ValueChanged<ContainerItem> onOpen;

  const ContainerListView({
    super.key,
    required this.state,
    required this.onRefresh,
    required this.onOpen,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.swms;
    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView(
        // Luôn kéo được để RefreshIndicator chạy cả khi danh sách ngắn.
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.all(AppDimens.md),
        children: [
          AppCard(
            padding: const EdgeInsets.all(AppDimens.sm + 4),
            child: Column(
              children: [
                BarcodeScannerButton(
                  height: 64,
                  state: state.resolving
                      ? ScannerState.loading
                      : ScannerState.scanning,
                  scanningLabel: LocaleKeys.container_check_scan_hint.tr(),
                ),
                const SizedBox(height: AppDimens.sm),
                Text(
                  LocaleKeys.container_check_scan_sub.tr(),
                  textAlign: TextAlign.center,
                  style: AppTextStyles.caption.copyWith(color: c.text3),
                ),
              ],
            ),
          ),
          const SizedBox(height: AppDimens.sm),
          state.containers.when(
            loading: () => const ContainerListSkeleton(),
            error: (e, _) => AppErrorView.widget(
              message: ref.read(errorHandlerProvider).getMessage(e),
              onRetry: onRefresh,
            ),
            data: (items) => items.isEmpty
                ? Padding(
                    padding: const EdgeInsets.symmetric(vertical: AppDimens.xl),
                    child: Text(
                      LocaleKeys.container_check_empty.tr(),
                      textAlign: TextAlign.center,
                      style: AppTextStyles.body.copyWith(color: c.text3),
                    ),
                  )
                : Column(
                    children: [
                      for (final item in items) ...[
                        ContainerCard(
                          item: item,
                          onTap: state.resolving ? null : () => onOpen(item),
                        ),
                        const SizedBox(height: 6),
                      ],
                    ],
                  ),
          ),
        ],
      ),
    );
  }
}
