import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// Bản nháp quét đang dở — lưu khi user back khỏi bước confirm, phục hồi
/// ở bước scan, xóa khi submit thành công hoặc khi quá hạn 1 ngày.
///
/// Chỉ tồn tại DUY NHẤT 1 bản: lần lưu sau ghi đè lần trước.
@immutable
class ReceivingHistoryEntry {
  final DateTime savedAt;
  final ReceivingMode mode;

  /// Tên model để hiển thị trên card lịch sử. Tính sẵn lúc lưu để không phải
  /// parse lại payload khi build UI (parse có thể throw).
  final String? modelName;

  /// Mode box: payload gốc của từng carton — dựng lại qua
  /// [PartCard.fromPayload], không lưu field rời để tránh lệch dữ liệu.
  final List<String> cardPayloads;

  /// Mode model / gtin.
  final ModelInfo? modelInfo;

  /// Mode gtin.
  final int boxCount;
  final int? stdPackOverride;

  /// Mode model.
  final List<String> serials;

  const ReceivingHistoryEntry({
    required this.savedAt,
    required this.mode,
    this.modelName,
    this.cardPayloads = const [],
    this.modelInfo,
    this.boxCount = 0,
    this.stdPackOverride,
    this.serials = const [],
  });

  /// Tự hết hạn sau 1 ngày kể từ lúc lưu.
  bool get isExpired =>
      DateTime.now().difference(savedAt) > const Duration(days: 1);

  /// Số lượng hiển thị — suy ra từ mode, không cần parse payload.
  int get itemCount => switch (mode) {
    ReceivingMode.box => cardPayloads.length,
    ReceivingMode.model => serials.length,
    ReceivingMode.gtin => boxCount,
  };

  /// Key locale của đơn vị tương ứng [itemCount].
  String get unitKey => switch (mode) {
    ReceivingMode.box => 'receiving.cartons_unit',
    ReceivingMode.model => 'receiving.serials_unit',
    ReceivingMode.gtin => 'receiving.box_unit',
  };
}