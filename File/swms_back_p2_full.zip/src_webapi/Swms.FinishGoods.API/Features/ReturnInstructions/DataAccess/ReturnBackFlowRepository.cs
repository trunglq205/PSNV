using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

public class ReturnBackFlowRepository : IReturnBackFlowRepository
{
    private readonly IDbConnectionFactory _factory;
    public ReturnBackFlowRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<bool> RequestAsync(
        long docId, string? note, IReadOnlyList<BackReqLine> lines, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        // Header và dòng đề nghị phải đi CÙNG một transaction: ghi được header
        // rồi hỏng lúc ghi dòng là phiếu mang trạng thái "FA đã đề nghị" mà
        // không có dòng nào — quản lý FA mở ra duyệt một đề nghị trống.
        var ok = await RequestHeaderAsync(conn, tx, docId, note, user);
        if (!ok) { tx.Rollback(); return false; }

        // XOÁ CỨNG dòng của lượt trước rồi chèn lại, không xoá mềm: dòng đề
        // nghị không phải dữ liệu lịch sử cần tra lại (lịch sử nằm ở sổ serial
        // và nhật ký giao hàng), mà ux_rbl_doc_model lại chặn trùng (doc, model)
        // nên để lại dòng cũ là lượt đề nghị mới chèn không vào được.
        await conn.ExecuteAsync(
            "DELETE FROM wms.return_back_lines WHERE doc_id = @docId;",
            new { docId }, tx);

        if (lines.Count > 0)
            await conn.ExecuteAsync("""
                INSERT INTO wms.return_back_lines
                    (doc_id, model, req_qty, created_at, created_by)
                VALUES
                    (@docId, @model, @reqQty, SYSDATETIME(), @user);
                """,
                lines.Select(l => new
                {
                    docId,
                    model = l.Model,
                    reqQty = l.ReqQty,
                    user,
                }), tx);

        tx.Commit();
        return true;
    }

    private static async Task<bool> RequestHeaderAsync(
        IDbConnection conn, IDbTransaction tx, long docId, string? note, string? user)
    {
        // Điều kiện đề nghị được, HẾT trong một câu:
        //   phiếu còn sống · chưa huỷ · chưa có luồng back (hoặc đã huỷ) ·
        //   CÒN con nào ở kho.
        //
        // Lượt đề nghị lại sau khi huỷ phải xoá sạch dấu cũ — cả ba mốc duyệt,
        // ba ô ý kiến và bộ huỷ. Để sót một ô là màn hình hiện đề nghị mới kèm
        // "lý do huỷ" của lượt trước.
        var n = await conn.ExecuteAsync("""
            UPDATE d
            SET    d.back_status         = N'fa_requested',
                   d.back_note           = @note,
                   d.back_requested_by   = @user,
                   d.back_requested_at   = SYSDATETIME(),
                   d.back_approved_by    = NULL,
                   d.back_approved_at    = NULL,
                   d.back_fa_comment     = NULL,
                   d.back_scs_approved_by = NULL,
                   d.back_scs_approved_at = NULL,
                   d.back_delivered_by   = NULL,
                   d.back_delivered_at   = NULL,
                   d.back_scs_comment    = NULL,
                   d.back_cancelled_by   = NULL,
                   d.back_cancelled_at   = NULL,
                   d.back_cancel_reason  = NULL,
                   d.updated_at          = SYSDATETIME(),
                   d.updated_by          = @user
            FROM   wms.return_instructions d
            WHERE  d.id = @docId
              AND  d.is_deleted = 0
              AND  d.doc_status <> N'cancelled'
              AND  (d.back_status IS NULL OR d.back_status = N'cancelled')
              AND  EXISTS (SELECT 1 FROM wms.return_instruction_serials s
                           WHERE s.doc_id = d.id AND s.status = N'received'
                             AND s.is_deleted = 0);
            """, new { docId, note, user }, tx);

        return n > 0;
    }

    /// <summary>
    /// B3 — quản lý SCS xác nhận (thêm 10/11). Sau bước này SCS WH mới được
    /// tách pallet và quét giao.
    ///
    /// Điều kiện <c>back_status = 'fa_approved'</c> nằm TRONG câu UPDATE: hai
    /// người duyệt cùng lúc thì người sau cập nhật 0 dòng và nhận 409, chứ
    /// không ghi đè mốc của người đầu.
    ///
    /// KHÔNG bắn mail — xem ghi chú ở <c>ReturnBackFlowService</c>.
    /// </summary>
    public async Task<bool> ScsApproveAsync(long docId, string? comment, string? user)
    {
        using var conn = _factory.Create();
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    back_status           = N'scs_approved',
                   back_scs_approved_by  = @user,
                   back_scs_approved_at  = SYSDATETIME(),
                   back_scs_comment      = @comment,
                   updated_at            = SYSDATETIME(),
                   updated_by            = @user
            WHERE  id = @docId AND is_deleted = 0
              AND  back_status = N'fa_approved';
            """, new { docId, comment, user });
        return n > 0;
    }

    public async Task<bool> UpdateNoteAsync(long docId, string? note, string? user)
    {
        using var conn = _factory.Create();
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    back_note  = @note,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  id = @docId AND is_deleted = 0
              AND  back_status = N'fa_requested';
            """, new { docId, note, user });
        return n > 0;
    }

    public async Task<bool> ApproveAsync(long docId, string? comment, string? user)
    {
        using var conn = _factory.Create();
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    back_status       = N'fa_approved',
                   back_approved_by  = @user,
                   back_approved_at  = SYSDATETIME(),
                   back_fa_comment   = @comment,
                   updated_at        = SYSDATETIME(),
                   updated_by        = @user
            WHERE  id = @docId AND is_deleted = 0
              AND  back_status = N'fa_requested';
            """, new { docId, comment, user });
        return n > 0;
    }

    public async Task<bool> CancelAsync(long docId, string? reason, string? user)
    {
        using var conn = _factory.Create();

        // NOT EXISTS nằm TRONG câu UPDATE, không kiểm trước rồi ghi sau: giữa
        // hai lệnh đó WH có thể vừa quét xong một pallet, và lúc ấy huỷ là để
        // lại một lô hàng ở FA mà không đề nghị nào đứng tên.
        var n = await conn.ExecuteAsync("""
            UPDATE d
            SET    d.back_status        = N'cancelled',
                   d.back_cancelled_by  = @user,
                   d.back_cancelled_at  = SYSDATETIME(),
                   d.back_cancel_reason = @reason,
                   d.updated_at         = SYSDATETIME(),
                   d.updated_by         = @user
            FROM   wms.return_instructions d
            WHERE  d.id = @docId
              AND  d.is_deleted = 0
              AND  d.back_status IN (N'fa_requested', N'fa_approved', N'scs_approved')
              AND  NOT EXISTS (SELECT 1 FROM wms.return_instruction_serials s
                               WHERE s.doc_id = d.id AND s.sent_fa_at IS NOT NULL
                                 AND s.is_deleted = 0);
            """, new { docId, reason, user });

        return n > 0;
    }

    public async Task<ReturnBackDeliverResult> DeliverAsync(
        long docId, IReadOnlyList<string> lotNos, string? comment, string? user)
    {
        var result = new ReturnBackDeliverResult();

        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        // Khoá phiếu ngay từ đầu (UPDLOCK, HOLDLOCK) rồi mới đọc trạng thái:
        // hai WH quét cùng lúc thì người sau xếp hàng chờ, chứ không cùng đọc
        // "đang ở bước giao" rồi cùng đóng phiếu.
        var head = await conn.QuerySingleOrDefaultAsync<HeadRow>("""
            SELECT TOP 1 d.id AS [Id], d.back_status AS [BackStatus]
            FROM   wms.return_instructions d WITH (UPDLOCK, HOLDLOCK)
            WHERE  d.id = @docId AND d.is_deleted = 0;
            """, new { docId }, tx);

        if (head is null)
        {
            result.NotFound = true;
            tx.Rollback();
            return result;
        }

        // ScsApproved, KHÔNG còn FaApproved (đổi 10/11): quản lý FA duyệt xong
        // mới chỉ là phía FA đồng ý; phải có quản lý SCS duyệt nữa thì hàng mới
        // được rời kho. Giao dần nhiều lượt thì phiếu vẫn ở scs_approved cho
        // đến lượt làm hết hàng, nên điều kiện này đúng cho mọi lượt.
        if (head.BackStatus != ReturnBackStatus.ScsApproved)
        {
            result.WrongStep = true;
            tx.Rollback();
            return result;
        }

        foreach (var lotNo in lotNos)
        {
            // RTRIM vì pallet_id là cột char cố định độ dài — so thẳng với mã
            // quét (12 ký tự, không khoảng trắng) sẽ không khớp dòng nào.
            var palletId = await conn.ExecuteScalarAsync<long?>("""
                SELECT TOP 1 p.id
                FROM   wms.pallets p
                WHERE  RTRIM(p.pallet_id) = @lotNo AND p.is_deleted = 0;
                """, new { lotNo }, tx);

            if (palletId is null)
            {
                result.NotFoundLots.Add(lotNo);
                continue;
            }

            var moved = await conn.ExecuteAsync("""
                UPDATE s
                SET    s.status     = N'at_fa',
                       s.sent_fa_at = SYSDATETIME(),
                       s.updated_at = SYSDATETIME(),
                       s.updated_by = @user
                FROM   wms.return_instruction_serials s
                WHERE  s.doc_id    = @docId
                  AND  s.pallet_id = @palletId
                  AND  s.status    = N'received'
                  AND  s.is_deleted = 0;
                """, new { docId, palletId, user }, tx);

            // Ghi nhật ký CẢ KHI moved = 0: sau này tra ra được là đã quét
            // pallet đó rồi mà nó không còn con nào của phiếu — khác hẳn với
            // "chưa ai quét".
            var id = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.return_back_deliveries
                    (doc_id, pallet_id, lot_no, serial_count, delivered_at, delivered_by)
                OUTPUT INSERTED.id
                VALUES (@docId, @palletId, @lotNo, @moved, SYSDATETIME(), @user);
                """, new { docId, palletId, lotNo, moved, user }, tx);

            result.Pallets.Add(new ReturnBackDelivery
            {
                Id = id,
                DocId = docId,
                PalletId = palletId,
                LotNo = lotNo,
                SerialCount = moved,
                DeliveredAt = DateTime.Now,
                DeliveredBy = user,
            });
            result.DeliveredQty += moved;
        }

        // Còn con nào ở 'received' không — đếm theo PHIẾU. Đây là định nghĩa
        // duy nhất của "còn hàng chưa giao"; không có tổng nào lưu sẵn để lệch.
        result.RemainQty = await conn.ExecuteScalarAsync<int>("""
            SELECT COUNT(*)
            FROM   wms.return_instruction_serials s
            WHERE  s.doc_id = @docId AND s.status = N'received' AND s.is_deleted = 0;
            """, new { docId }, tx);

        if (result.RemainQty == 0)
        {
            await conn.ExecuteAsync("""
                UPDATE wms.return_instructions
                SET    back_status       = N'delivered',
                       back_delivered_by = @user,
                       back_delivered_at = SYSDATETIME(),
                       back_scs_comment  = @comment,
                       updated_at        = SYSDATETIME(),
                       updated_by        = @user
                WHERE  id = @docId;
                """, new { docId, comment, user }, tx);
            result.Completed = true;
        }
        else if (!string.IsNullOrWhiteSpace(comment))
        {
            // Chưa xong nhưng WH có ghi chú: giữ lại, vì lượt sau có thể người
            // khác quét và ghi chú này là thứ duy nhất nói vì sao giao dở.
            await conn.ExecuteAsync("""
                UPDATE wms.return_instructions
                SET    back_scs_comment = @comment,
                       updated_at       = SYSDATETIME(),
                       updated_by       = @user
                WHERE  id = @docId;
                """, new { docId, comment, user }, tx);
        }

        tx.Commit();
        return result;
    }

    public async Task<IReadOnlyList<ReturnBackDelivery>> GetDeliveriesAsync(long docId)
    {
        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<ReturnBackDelivery>("""
            SELECT  d.id           AS [Id],
                    d.doc_id       AS [DocId],
                    d.pallet_id    AS [PalletId],
                    d.lot_no       AS [LotNo],
                    d.serial_count AS [SerialCount],
                    d.delivered_at AS [DeliveredAt],
                    d.delivered_by AS [DeliveredBy]
            FROM    wms.return_back_deliveries d
            WHERE   d.doc_id = @docId
            ORDER BY d.delivered_at DESC, d.id DESC;
            """, new { docId });
        return rows.ToList();
    }

    public async Task<IReadOnlyList<BackModelQty>> GetRemainByModelAsync(long docId)
    {
        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<BackModelQty>("""
            SELECT  s.model  AS [Model],
                    COUNT(*) AS [Qty]
            FROM    wms.return_instruction_serials s
            WHERE   s.doc_id = @docId AND s.status = N'received' AND s.is_deleted = 0
            GROUP BY s.model
            ORDER BY s.model;
            """, new { docId });
        return rows.ToList();
    }

    private sealed class HeadRow
    {
        public long Id { get; set; }
        public string? BackStatus { get; set; }
    }
}
