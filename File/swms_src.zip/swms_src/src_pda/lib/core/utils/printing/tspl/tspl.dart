import 'dart:typed_data';

import 'package:swms_finish_goods/core/utils/printing/printer.dart';

/// Lệnh TSPL — mỗi lệnh một dòng, phân cách CRLF, tham số cách nhau dấu phẩy.
///
/// Toạ độ tính bằng DOT, gốc góc trên-trái, 203 dpi ⇒ 8 dot/mm.
/// Chỉ bọc những lệnh đang dùng; cần lệnh khác thì thêm ở đây, KHÔNG
/// viết chuỗi tay trong renderer để khỏi lệch dấu nháy/dấu phẩy.
class Tspl {
  Tspl._();

  static const eol = '\r\n';

  /// Ghép các lệnh thành một chuỗi hoàn chỉnh, có CRLF sau lệnh cuối
  /// (thiếu là máy không chạy lệnh cuối — thường là chính lệnh PRINT).
  static String join(Iterable<String> commands) => '${commands.join(eol)}$eol';

  /// Xoá bộ đệm ảnh trước khi vẽ tem mới.
  static const cls = 'CLS';

  /// BOX x1,y1,x2,y2,thickness — hình chữ nhật rỗng.
  static String box(int x1, int y1, int x2, int y2, int thickness) =>
      'BOX $x1,$y1,$x2,$y2,$thickness';

  /// BAR x,y,width,height — khối đặc (dùng vẽ đường kẻ).
  static String bar(int x, int y, int width, int height) =>
      'BAR $x,$y,$width,$height';

  /// TEXT x,y,"font",rotation,xMul,yMul,"content"
  ///
  /// [font] là font bitmap có sẵn: "1".."8" (kích cỡ dot: 1=8×12, 2=12×20,
  /// 3=16×24, 4=24×32, 5=32×48, 6=14×19, 7=21×27, 8=14×25).
  static String text(
      int x,
      int y,
      String font,
      int rotation,
      int xMul,
      int yMul,
      String content,
      ) =>
      'TEXT $x,$y,"$font",$rotation,$xMul,$yMul,"${sanitizeTsplValue(content)}"';

  /// QRCODE x,y,ecc,cell,mode,rotation,"data"
  ///
  /// [ecc] L/M/Q/H; [cell] 1..10; [mode] A (auto) hoặc M (manual).
  static String qrcode(
      int x,
      int y,
      String ecc,
      int cell,
      String mode,
      int rotation,
      String data,
      ) =>
      'QRCODE $x,$y,$ecc,$cell,$mode,$rotation,"${sanitizeTsplValue(data)}"';

  /// PRINT 1,n — in n bản của tem hiện tại trong bộ đệm.
  static String print(int copies) => 'PRINT 1,$copies';
}

/// TSPL bọc nội dung trong dấu nháy kép và KHÔNG có cách escape đáng tin
/// giữa các firmware (TSC dùng `\["]`, hàng clone thì không). Bỏ luôn `"`,
/// cùng ký tự điều khiển — CR/LF sẽ cắt lệnh làm đôi.
String sanitizeTsplValue(String value) =>
    value.replaceAll(RegExp(r'[\u0000-\u001F\u007F"]'), '');

/// TSPL cũng là byte stream 1 byte/ký tự — chặn sớm ký tự ngoài Latin-1
/// (tiếng Việt có dấu, emoji...) vì máy in sẽ in ra rác.
Uint8List encodeTspl(String data) {
  final units = data.codeUnits;
  final bad = units.where((u) => u > 0xFF);
  if (bad.isNotEmpty) {
    throw const PrinterException(
      PrinterErrorType.invalidData,
      message: 'Dữ liệu chứa ký tự ngoài phạm vi 1 byte (cần bỏ dấu)',
    );
  }
  return Uint8List.fromList(units);
}