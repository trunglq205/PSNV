﻿using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Auth.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business;
using Swms.FinishGoods.API.Shared.Business.Exceptions;

namespace Swms.FinishGoods.API.Features.Auth.Business;

public sealed class ApiKeyService : IApiKeyService
{
    private readonly IApiKeyRepository _repo;
    private readonly IPasswordHasher _hasher;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public ApiKeyService(
        IApiKeyRepository repo,
        IPasswordHasher hasher,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _hasher = hasher;
        _localizer = localizer;
    }

    public async Task<ApiKeyIssuedResponse> CreateAsync(CreateApiKeyRequest request, string? createdBy)
    {
        var clientName = request.ClientName.Trim();
        if (string.IsNullOrWhiteSpace(clientName))
            throw new BadRequestException(_localizer["ApiKey.ClientNameRequired"]);

        // Chặn tạo key đã hết hạn ngay lúc tạo.
        if (request.ExpiresAt is { } exp && exp <= DateTime.UtcNow)
            throw new BadRequestException(_localizer["ApiKey.ExpiryInPast"]);

        var perms = NormalizePermissions(request.Permissions);
        var (fullKey, prefix) = ApiKeyGenerator.Create(clientName);

        var entity = new ApiKey
        {
            ClientName = clientName,
            KeyPrefix = prefix,
            KeyHash = _hasher.Hash(fullKey),
            PermissionsCsv = string.Join(',', perms),
            IsActive = true,
            ExpiresAt = request.ExpiresAt,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = createdBy
        };

        var id = await _repo.CreateAsync(entity);
        return new ApiKeyIssuedResponse(id, clientName, fullKey, prefix, perms, request.ExpiresAt);
    }

    // Xoay key: tạo key mới CÙNG client & quyền, vô hiệu MỌI key active cùng client.
    public async Task<ApiKeyIssuedResponse> RotateAsync(long id, string? createdBy)
    {
        var old = await _repo.GetByIdAsync(id)
                  ?? throw new NotFoundException(_localizer["ApiKey.NotFound"]);

        var (fullKey, prefix) = ApiKeyGenerator.Create(old.ClientName);

        var entity = new ApiKey
        {
            ClientName = old.ClientName,
            KeyPrefix = prefix,
            KeyHash = _hasher.Hash(fullKey),
            PermissionsCsv = old.PermissionsCsv,   // giữ nguyên quyền
            IsActive = true,
            ExpiresAt = old.ExpiresAt,
            CreatedAt = DateTime.UtcNow,
            CreatedBy = createdBy
        };

        // Revoke mọi key active cùng client + insert key mới, nguyên tử trong 1 transaction.
        var newId = await _repo.RotateForClientAsync(
            entity, old.ClientName, DateTime.UtcNow, createdBy);

        return new ApiKeyIssuedResponse(
            newId, old.ClientName, fullKey, prefix, old.Permissions, old.ExpiresAt);
    }

    public async Task RevokeAsync(long id, string? by)
    {
        _ = await _repo.GetByIdAsync(id)
            ?? throw new NotFoundException(_localizer["ApiKey.NotFound"]);
        await _repo.RevokeAsync(id, DateTime.UtcNow, by);
    }

    public async Task<IReadOnlyList<ApiKeyInfo>> ListAsync()
    {
        var keys = await _repo.ListAsync();
        return keys.Select(k => new ApiKeyInfo(
            k.Id, k.ClientName, k.KeyPrefix, k.Permissions,
            k.IsActive, k.ExpiresAt, k.CreatedAt, k.LastUsedAt, k.RevokedAt)).ToList();
    }

    // Chặn cấp quyền không có trong catalog (fail sớm, khớp PermissionConvention).
    private IReadOnlyList<string> NormalizePermissions(IEnumerable<string>? input)
    {
        var perms = (input ?? Enumerable.Empty<string>())
            .Select(p => p.Trim())
            .Where(p => p.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        var invalid = perms.Where(p => !PermissionCatalog.IsValid(p)).ToList();
        if (invalid.Count > 0)
            throw new BadRequestException(
                _localizer["ApiKey.InvalidPermissions"] + " " + string.Join(", ", invalid));

        return perms;
    }
}