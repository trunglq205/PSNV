﻿namespace CriticalListReport.Helpers
{
    /// <summary>
    /// Chọn giao diện theo mùa lễ cho Login + Layout.
    /// appsettings.json → "Theme": "auto" | "halloween" | "christmas" | "none"
    ///   auto      : tháng 10 = Halloween, tháng 12 = Giáng sinh, còn lại = giao diện hồng gốc
    ///   halloween : luôn Halloween      christmas : luôn Giáng sinh      none : luôn giao diện hồng
    /// Xem thử nhanh không cần sửa cấu hình: thêm ?theme=halloween / ?theme=christmas / ?theme=none vào URL.
    /// </summary>
    public static class SeasonTheme
    {
        public const string None = "none";
        public const string Halloween = "halloween";
        public const string Christmas = "christmas";

        public static string Get(IConfiguration config, HttpContext? context)
        {
            // 1. Ghi đè tạm qua URL để xem thử
            var preview = context?.Request.Query["theme"].ToString();
            if (IsKnown(preview)) return preview!.Trim().ToLowerInvariant();

            // 2. Cấu hình cứng trong appsettings.json
            var setting = (config["Theme"] ?? "auto").Trim().ToLowerInvariant();
            if (IsKnown(setting)) return setting;

            // 3. auto: theo tháng
            return DateTime.Today.Month switch
            {
                10 => Halloween,
                12 => Christmas,
                _ => None
            };
        }

        /// <summary>Có hiện màn mini game sau đăng nhập không (cờ TempData do AccountController đặt, hoặc ?themegate=1 để xem thử).</summary>
        public static bool ShowGate(string theme, HttpContext context, object? tempDataFlag)
        {
            if (theme == None) return false;
            return tempDataFlag != null || context.Request.Query["themegate"] == "1";
        }

        private static bool IsKnown(string? value)
        {
            var v = value?.Trim().ToLowerInvariant();
            return v == None || v == Halloween || v == Christmas;
        }
    }
}
