import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';

// ─────────────────────────────────────────────────────────────
//  Skeleton dùng chung cho mọi màn.
//
//  - Bone        : khối xám tĩnh, KHÔNG tự chạy animation.
//  - AppShimmer  : 1 AnimationController cho cả vùng con; vệt sáng chỉ phủ
//                  lên pixel có màu (các Bone) nhờ ShaderMask srcATop,
//                  khoảng trống giữa các Bone không bị tô.
//  - SkeletonCard: AppCard + AppShimmer — dùng cho gần như mọi trường hợp.
//
//  Quy tắc: không đặt AppCard/Container có nền BÊN TRONG AppShimmer, vì nền
//  đó cũng sẽ bị tô sáng. Card con → vẽ bằng 1 Bone lớn.
// ─────────────────────────────────────────────────────────────

/// Khối giữ chỗ. Màu lấy từ theme nên tự đúng ở cả light/dark.
class Bone extends StatelessWidget {
  final double? width;
  final double height;
  final double radius;

  const Bone({super.key, this.width, this.height = 12, this.radius = 6});

  /// Hình tròn (avatar, status dot, nút icon).
  const Bone.circle({super.key, required double size})
      : width = size,
        height = size,
        radius = 999;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: width,
      height: height,
      decoration: BoxDecoration(
        // Phải khác màu nền card, nếu không Bone sẽ chìm mất.
        color: context.swms.border,
        borderRadius: BorderRadius.circular(radius),
      ),
    );
  }
}

/// Chạy vệt sáng liền mạch qua toàn bộ [child].
class AppShimmer extends StatefulWidget {
  final Widget child;
  final Duration period;

  const AppShimmer({
    super.key,
    required this.child,
    this.period = const Duration(milliseconds: 1400),
  });

  @override
  State<AppShimmer> createState() => _AppShimmerState();
}

class _AppShimmerState extends State<AppShimmer>
    with SingleTickerProviderStateMixin {
  late final AnimationController _c = AnimationController.unbounded(
    vsync: this,
  )..repeat(min: -1, max: 1, period: widget.period);

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Máy bật "giảm chuyển động" → chỉ hiện Bone tĩnh.
    if (MediaQuery.disableAnimationsOf(context)) return widget.child;

    final hi = context.swms.card;
    return AnimatedBuilder(
      animation: _c,
      child: widget.child,
      builder: (context, child) => ShaderMask(
        blendMode: BlendMode.srcATop,
        shaderCallback: (bounds) => LinearGradient(
          begin: const Alignment(-1, -0.3),
          end: const Alignment(1, 0.3),
          colors: [
            hi.withValues(alpha: 0),
            hi.withValues(alpha: .7),
            hi.withValues(alpha: 0),
          ],
          stops: const [0.35, 0.5, 0.65],
          transform: _Slide(_c.value),
        ).createShader(bounds),
        child: child,
      ),
    );
  }
}

class _Slide extends GradientTransform {
  final double percent;
  const _Slide(this.percent);

  @override
  Matrix4 transform(Rect bounds, {TextDirection? textDirection}) =>
      Matrix4.translationValues(bounds.width * percent, 0, 0);
}

/// Card skeleton: nền card bình thường, chỉ các Bone bên trong chạy shimmer.
class SkeletonCard extends StatelessWidget {
  final Widget child;
  final EdgeInsets? padding;

  const SkeletonCard({super.key, required this.child, this.padding});

  @override
  Widget build(BuildContext context) {
    final body = AppShimmer(child: child);
    return padding == null
        ? AppCard(child: body)
        : AppCard(padding: padding!, child: body);
  }
}