﻿abstract final class AppRoutePaths {
  const AppRoutePaths._();

  static const String login = '/login';
  static const String home = '/home';
  static const String partCard = '/part-card';
  static const String partCardAction = '/part-card/action';
  static const String receiving = '/receiving';
  static const String tempLocation = '/temp-location';
  static const String palletDetail = '/pallet/:lotNo';
  static const String findMissingBox = '/pallet/find-missing';
  static const String boxDetail = '/box/:boxNo';
  static const String splitPallet = '/pallet/split';
  static const String gallery = '/gallery';
  static const String settings = '/settings';
  static const String storing = '/storing';
  static const String storageMap = '/storage-map';
  static const String abnormalReport = '/abnormal-report';
  static const String abnormalReportCreate = '/abnormal-report/new';
  static const String abnormalReportDetail = '/abnormal-report/:id';
  static const String stocktakeMorning = '/stocktake/morning';
  static const String stocktakeMonthly = '/stocktake/monthly';
  static const String stocktakeShipment = '/stocktake/shipment';
  static const String stocktakeDetail = '/stocktake/detail';
  static const String warehouseMove = '/warehouse-move';
  static const String vanningArea = '/vanning-area';
  static const String shipmentInstruction = '/shipment-instructions';
  static const String shipmentInstructionDetail = '/shipment-instructions/:siId';
  static const String kitting = '/kitting';
  static const String kittingDetail = '/kitting';
  static const String stocky = '/stocky';
  static const String modelDetail = '/model/:modelId';
  static const String stockyInWarehouse = '/stocky/in-warehouse';
  static const String palletVanning = '/pallet-vanning';
  static const String palletPhotos = '/pallet-vanning/photos';
  static const String stowagePlan = '/stowage-plan';
  static const String containerCheck = '/container-check';
  static const String containerFinish = '/container-finish';
  static const String returnInstruction = '/return-instruction';

  /// Mục 2a — WH quét thùng + serial để nhận hàng back vào một phiếu.
  static const String returnReceive = '/return-instruction/receive';

}