import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';

/// Ba chiều thao tác với xe Stocky. [code] gửi lên server để kiểm xe theo
/// đúng chiều.
///
/// Phân biệt theo việc xe CÓ CÒN ĐƯỢC QUẢN LÝ KHÔNG:
///   [receive]      — vào kho. Xe mới từ vendor, HOẶC xe đang ở FA đưa về.
///   [exportFa]     — sang FA. Xe VẪN được quản lý, chỉ đổi vị trí.
///   [returnVendor] — về vendor. Xe RỜI hệ thống, biến mất khỏi danh sách.
///
/// ⚠ Trước đây chỉ có 2 chiều và nút "Xuất sang FA" gửi `out`, mà `out` bên
/// server là TRẢ VENDOR — nên xuất sang FA là xe bị xoá khỏi danh sách theo
/// dõi. Giờ FA có mã riêng `fa`; `out` chỉ còn nghĩa trả vendor.
enum StockyMode {
  receive(
    'in',
    LocaleKeys.stocky_tab_receive,
    LocaleKeys.stocky_btn_receive,
    LocaleKeys.stocky_confirm_receive,
    LocaleKeys.stocky_done_receive,
  ),
  exportFa(
    'fa',
    LocaleKeys.stocky_tab_export_fa,
    LocaleKeys.stocky_btn_export_fa,
    LocaleKeys.stocky_confirm_export_fa,
    LocaleKeys.stocky_done_export_fa,
  ),
  returnVendor(
    'out',
    LocaleKeys.stocky_tab_return_vendor,
    LocaleKeys.stocky_btn_return_vendor,
    LocaleKeys.stocky_confirm_return_vendor,
    LocaleKeys.stocky_done_return_vendor,
  );

  const StockyMode(
    this.code,
    this.tabKey,
    this.buttonKey,
    this.confirmKey,
    this.doneKey,
  );

  final String code;

  /// LocaleKeys — UI gọi `.tr()` khi render.
  ///
  /// Gom cả 4 khoá vào enum thay vì rải `if/switch` ở page: thêm chiều thứ tư
  /// sau này chỉ phải sửa một chỗ, và không còn cảnh quên một câu nào đó.
  final String tabKey;
  final String buttonKey;
  final String confirmKey;
  final String doneKey;
}

/// Trạng thái xe, khớp chuỗi trong DB (`wms.stocky_carts.status`).
///
/// ⚠ Hai giá trị này nói về việc xe CÓ CÒN ĐƯỢC QUẢN LÝ KHÔNG, KHÔNG nói xe
/// đang đứng ở đâu. Xe đã đẩy sang FA vẫn mang [inWarehouse] — vị trí đọc ở
/// [StockyCart.locatorCode] / [StockyCart.atFa].
abstract final class StockyStatus {
  /// Đang trong hệ thống: bãi đậu kho SCS, ô Receiving (PLxx…), hoặc ở FA.
  static const String inWarehouse = 'in_warehouse';

  /// Đã trả về vendor — trạng thái cuối duy nhất khiến xe rời danh sách.
  static const String returned = 'returned';
}

/// Một xe Stocky.
///
/// Dùng cho CẢ HAI nơi: xe vừa quét ở màn nhập/xuất, và một dòng trong màn
/// danh sách xe đang ở trong kho. Nên mọi trường ngoài [code] đều có thể
/// trống — endpoint tra một xe trả ít trường hơn endpoint danh sách.
class StockyCart {
  /// Barcode trên xe, vd "STK-0218".
  final String code;

  /// Tên xe. Trống với xe mới quét lần đầu (chưa khai trong danh mục).
  final String? name;

  final String? model;
  final int qty;

  /// Số lot / pallet trên xe. 0 = xe rỗng.
  final int lotCount;

  /// Server tính: đang có pallet nào ghi nằm trên xe này không.
  final bool hasGoods;

  /// `in_warehouse` | `returned`. Trống = xe chưa có trong danh mục.
  final String? status;

  /// VỊ TRÍ HIỆU LỰC: ô của pallet đang trên xe; xe rỗng thì ô đậu xe.
  /// Trống = chưa gán ô nào.
  final String? locatorCode;
  final String? areaCode;

  /// Mã pallet đang nằm trên xe. Trống khi xe rỗng.
  final String? palletCode;

  /// Số phiếu xuất của hàng trên xe. Có giá trị mà [locatorCode] trống nghĩa
  /// là hàng đã rời kho nhưng hệ thống vẫn ghi nằm trên xe — cần đối chiếu.
  final String? siNo;

  /// Xe đang đứng ở FA. SERVER tính (so ô riêng của xe với ô FA khai trong
  /// cấu hình), client không tự suy ra được vì không biết mã ô đó.
  final bool atFa;

  final DateTime? receivedAt;

  const StockyCart({
    required this.code,
    this.name,
    this.model,
    this.qty = 0,
    this.lotCount = 0,
    this.hasGoods = false,
    this.status,
    this.locatorCode,
    this.areaCode,
    this.palletCode,
    this.siNo,
    this.atFa = false,
    this.receivedAt,
  });

  /// Xét CẢ HAI dấu hiệu: server tính `hasGoods` từ việc có dòng pallet nào
  /// trỏ vào xe, `lotCount` là đếm số dòng đó — nhất quán thì hai cái bằng
  /// nhau. Xét cả hai để một response thiếu trường không làm xe có hàng hiện
  /// thành rỗng.
  bool get isEmpty => !hasGoods && lotCount == 0;

  /// Xe đang ở trong kho. Xe mới quét lần đầu (status trống) chưa ở trong kho.
  bool get isInWarehouse => status == StockyStatus.inWarehouse;
}

/// Kết quả chốt danh sách.
class StockySubmitResult {
  final int cartCount;
  final int qty;

  const StockySubmitResult({required this.cartCount, required this.qty});
}

/// Bộ lọc màn danh sách xe trong kho.
enum StockyFilter {
  all(null, LocaleKeys.stocky_filter_all),
  loaded(true, LocaleKeys.stocky_filter_loaded),
  empty(false, LocaleKeys.stocky_filter_empty);

  const StockyFilter(this.hasGoods, this.labelKey);

  /// null = không lọc.
  final bool? hasGoods;
  final String labelKey;
}
