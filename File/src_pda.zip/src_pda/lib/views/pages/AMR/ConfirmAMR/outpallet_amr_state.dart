import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:smart_warehouse/shared/base/base_state.dart';
import 'package:smart_warehouse/shared/common/error_entity.dart';
import '../../../../entities/Robot/RobotLocationTarget.dart';
part 'outpallet_amr_state.freezed.dart';

@freezed
class OutpalletAmrState extends BaseState with _$OutpalletAmrState {
  factory OutpalletAmrState({
    @Default(PageStatus.initial) PageStatus pageStatus,
    @Default(false) bool processing,
    @Default(null) ErrorEntity? errorEntity,
    @Default(null) Robotlocationtarget? robotLocationStart,
  }) = _OutpalletAmrState;
}