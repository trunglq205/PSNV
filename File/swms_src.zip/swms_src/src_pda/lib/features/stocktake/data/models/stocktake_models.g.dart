// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stocktake_models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CountSummaryModel _$CountSummaryModelFromJson(Map<String, dynamic> json) =>
    CountSummaryModel(
      id: (json['id'] as num).toInt(),
      docNo: json['docNo'] as String,
      countType: json['countType'] as String?,
      countDate: DateTime.parse(json['countDate'] as String),
      docStatus: json['docStatus'] as String,
      description: json['description'] as String?,
      totalLines: (json['totalLines'] as num).toInt(),
      countedLines: (json['countedLines'] as num).toInt(),
      discrepancyLines: (json['discrepancyLines'] as num).toInt(),
    );

Map<String, dynamic> _$CountSummaryModelToJson(CountSummaryModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'docNo': instance.docNo,
      'countType': ?instance.countType,
      'countDate': instance.countDate.toIso8601String(),
      'docStatus': instance.docStatus,
      'description': ?instance.description,
      'totalLines': instance.totalLines,
      'countedLines': instance.countedLines,
      'discrepancyLines': instance.discrepancyLines,
    };

CountLineModel _$CountLineModelFromJson(Map<String, dynamic> json) =>
    CountLineModel(
      id: (json['id'] as num).toInt(),
      lineNo: (json['lineNo'] as num).toInt(),
      productId: (json['productId'] as num).toInt(),
      productName: json['productName'] as String?,
      locatorId: (json['locatorId'] as num).toInt(),
      locatorCode: json['locatorCode'] as String,
      lotId: (json['lotId'] as num?)?.toInt(),
      palletId: json['palletId'] as String?,
      model: json['model'] as String?,
      qtySystem: (json['qtySystem'] as num).toInt(),
      qtyCount: (json['qtyCount'] as num?)?.toInt(),
      boxCountSystem: (json['boxCountSystem'] as num?)?.toInt(),
      boxCountCounted: (json['boxCountCounted'] as num?)?.toInt(),
      standardPacking: (json['standardPacking'] as num?)?.toInt(),
      walkSeq: (json['walkSeq'] as num?)?.toInt() ?? 0,
      areaCode: json['areaCode'] as String?,
      areaName: json['areaName'] as String?,
      isFound: json['isFound'] as bool? ?? false,
      systemLocatorCode: json['systemLocatorCode'] as String?,
    );

Map<String, dynamic> _$CountLineModelToJson(CountLineModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'lineNo': instance.lineNo,
      'productId': instance.productId,
      'productName': ?instance.productName,
      'locatorId': instance.locatorId,
      'locatorCode': instance.locatorCode,
      'lotId': ?instance.lotId,
      'palletId': ?instance.palletId,
      'model': ?instance.model,
      'qtySystem': instance.qtySystem,
      'qtyCount': ?instance.qtyCount,
      'boxCountSystem': ?instance.boxCountSystem,
      'boxCountCounted': ?instance.boxCountCounted,
      'standardPacking': ?instance.standardPacking,
      'walkSeq': instance.walkSeq,
      'areaCode': ?instance.areaCode,
      'areaName': ?instance.areaName,
      'isFound': instance.isFound,
      'systemLocatorCode': ?instance.systemLocatorCode,
    };

CountDetailModel _$CountDetailModelFromJson(Map<String, dynamic> json) =>
    CountDetailModel(
      header: CountSummaryModel.fromJson(
        json['header'] as Map<String, dynamic>,
      ),
      lines: (json['lines'] as List<dynamic>)
          .map((e) => CountLineModel.fromJson(e as Map<String, dynamic>))
          .toList(),
    );

Map<String, dynamic> _$CountDetailModelToJson(CountDetailModel instance) =>
    <String, dynamic>{'header': instance.header, 'lines': instance.lines};

Map<String, dynamic> _$SetCountRequestModelToJson(
  SetCountRequestModel instance,
) => <String, dynamic>{
  'qtyCount': instance.qtyCount,
  'note': ?instance.note,
  'boxCountCounted': ?instance.boxCountCounted,
};

AddFoundResultModel _$AddFoundResultModelFromJson(Map<String, dynamic> json) =>
    AddFoundResultModel(
      lineId: (json['lineId'] as num).toInt(),
      created: json['created'] as bool? ?? true,
    );

Map<String, dynamic> _$AddFoundResultModelToJson(
  AddFoundResultModel instance,
) => <String, dynamic>{'lineId': instance.lineId, 'created': instance.created};

Map<String, dynamic> _$AddFoundRequestModelToJson(
  AddFoundRequestModel instance,
) => <String, dynamic>{
  'locatorId': instance.locatorId,
  'palletId': instance.palletId,
};
