﻿namespace SWMS_WebTool.Models
{
    public abstract class AuditableEntity
    {
        /// <summary>
        /// Status
        /// </summary>
        public byte? Status { get; set; }
        /// <summary>
        /// Create Date when add record
        /// </summary>
        public DateTime? CreatedDate { get; set; }

        /// <summary>
        /// User Create when add record
        /// </summary>
        public string? CreatedBy { get; set; }

        /// <summary>
        /// Update Date when edit record
        /// </summary>
        public DateTime? UpdatedDate { get; set; }

        /// <summary>
        /// Update User when edit record
        /// </summary>
        public string? UpdatedBy { get; set; }
    }
}
