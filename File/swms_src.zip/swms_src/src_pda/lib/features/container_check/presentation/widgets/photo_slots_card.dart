import 'dart:io';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/inspect_section_header.dart';

/// 4 ô ảnh cố định theo góc chụp, lưới 2×2 tỉ lệ 4:3.
class PhotoSlotsCard extends StatelessWidget {
  final Map<ContainerPhotoSlot, String> photos;

  /// null = chỉ xem. Chạm ô trống = chụp; chạm ô có ảnh = chụp lại.
  final ValueChanged<ContainerPhotoSlot>? onCapture;
  final ValueChanged<ContainerPhotoSlot>? onRemove;

  const PhotoSlotsCard({
    super.key,
    required this.photos,
    required this.onCapture,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    const all = ContainerPhotoSlot.values;
    return AppCard(
      padding: const EdgeInsets.all(AppDimens.sm + 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InspectSectionHeader(
            title: LocaleKeys.container_check_photos.tr(),
            done: photos.length,
            total: all.length,
          ),
          const SizedBox(height: AppDimens.xs),
          GridView.count(
            crossAxisCount: 2,
            childAspectRatio: 4 / 3,
            mainAxisSpacing: AppDimens.sm,
            crossAxisSpacing: AppDimens.sm,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              for (final slot in all)
                _SlotTile(
                  label: slot.labelKey.tr(),
                  path: photos[slot],
                  onTap: onCapture == null ? null : () => onCapture!(slot),
                  onRemove: onRemove == null ? null : () => onRemove!(slot),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SlotTile extends StatelessWidget {
  final String label;
  final String? path;
  final VoidCallback? onTap;
  final VoidCallback? onRemove;

  const _SlotTile({
    required this.label,
    required this.path,
    required this.onTap,
    required this.onRemove,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final radius = BorderRadius.circular(AppDimens.rInput);

    if (path == null) {
      return InkWell(
        onTap: onTap,
        borderRadius: radius,
        child: Opacity(
          opacity: onTap == null ? 0.4 : 1,
          child: DashedBorder(
            borderRadius: AppDimens.rInput,
            child: Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(Icons.photo_camera_outlined, size: 22, color: c.text3),
                  const SizedBox(height: 6),
                  Text(
                    label,
                    textAlign: TextAlign.center,
                    style: AppTextStyles.caption.copyWith(
                      color: c.text3,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      );
    }

    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: radius,
        child: Stack(
          fit: StackFit.expand,
          children: [
            // cacheWidth: ảnh camera 12MP, giải mã full size trên TC25 rất tốn RAM.
            Image.file(File(path!), fit: BoxFit.cover, cacheWidth: 400),
            Positioned(
              left: 0,
              right: 0,
              bottom: 0,
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 3),
                color: Colors.black54,
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.caption.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            if (onRemove != null)
              Positioned(
                top: 2,
                right: 2,
                child: GestureDetector(
                  onTap: onRemove,
                  child: Container(
                    padding: const EdgeInsets.all(5),
                    decoration: const BoxDecoration(
                      color: Colors.black54,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.close_rounded, size: 14, color: Colors.white),
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
