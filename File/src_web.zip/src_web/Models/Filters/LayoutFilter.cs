﻿namespace SWMS_WebTool.Models.Filters
{
    public class LayoutFilter : BaseFilter
    {
        public LayoutFilter() { }

        public bool ShowGrid { get; set; }
        public bool ShowDetail { get; set; }

        public string kittingPos { get; set; }

    }
}
