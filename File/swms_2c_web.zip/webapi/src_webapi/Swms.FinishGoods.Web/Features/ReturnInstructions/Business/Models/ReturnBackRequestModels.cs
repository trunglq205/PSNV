namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

/// <summary>
/// Yêu cầu back hàng sang FA (mục 2c). Bốn bước, hai cấp duyệt.
///
/// Mọi con số tiến độ (<see cref="AssignedQty"/>, <see cref="ReturnedQty"/>,
/// <see cref="AtFaQty"/>) do API đếm từ SỔ SERIAL — web không tự cộng lại từ
/// dòng, vì dòng chỉ ghi "FA đã xin bao nhiêu".
/// </summary>
public class ReturnBackRequestDto
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public string? DocNo { get; set; }
    public string? GoodsType { get; set; }
    public string ReqNo { get; set; } = "";
    public string ReqStatus { get; set; } = "";
    public string CurrentStep { get; set; } = "";
    public string? Note { get; set; }

    public int ModelCount { get; set; }
    public int TotalQty { get; set; }
    public int AssignedQty { get; set; }
    public int ReturnedQty { get; set; }
    public int AtFaQty { get; set; }

    public bool IsOpen { get; set; }
    public bool IsApproved { get; set; }
    public bool IsCancelled { get; set; }

    public string? RequestedBy { get; set; }
    public DateTime RequestedAt { get; set; }

    public string? FaApprovedBy { get; set; }
    public DateTime? FaApprovedAt { get; set; }
    public string? FaComment { get; set; }

    public string? ScsInstructedBy { get; set; }
    public DateTime? ScsInstructedAt { get; set; }

    public string? ScsApprovedBy { get; set; }
    public DateTime? ScsApprovedAt { get; set; }
    public string? ScsComment { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    public List<ReturnBackRequestLineDto> Lines { get; set; } = new();

    /// <summary>Gắp thiếu so với SL đã xin ở ít nhất một model.</summary>
    public bool AnyShort => Lines.Any(l => l.Short);
}

public class ReturnBackRequestLineDto
{
    public long Id { get; set; }
    public int LineNo { get; set; }
    public string Model { get; set; } = "";
    public int Qty { get; set; }
    public int AssignedQty { get; set; }
    public int ReturnedQty { get; set; }
    public int AvailableQty { get; set; }
    public bool Short { get; set; }
    public string? Note { get; set; }

    /// <summary>Bản sao để sửa trong dialog mà không đụng dữ liệu đang hiện.</summary>
    public ReturnBackRequestLineDto Clone() => new()
    {
        Id = Id, LineNo = LineNo, Model = Model, Qty = Qty,
        AssignedQty = AssignedQty, ReturnedQty = ReturnedQty,
        AvailableQty = AvailableQty, Short = Short, Note = Note,
    };
}

public class BackRequestLineRequestDto
{
    public string Model { get; set; } = "";
    public int Qty { get; set; }
    public string? Note { get; set; }
}

public class CreateBackRequestRequestDto
{
    public long DocId { get; set; }
    public string? Note { get; set; }
    public List<BackRequestLineRequestDto> Lines { get; set; } = new();
}

public class UpdateBackRequestRequestDto
{
    public string? Note { get; set; }
    public List<BackRequestLineRequestDto> Lines { get; set; } = new();
}

public class BackRequestDecisionRequestDto
{
    public string? Comment { get; set; }
}

public class BackAvailableModelDto
{
    public string Model { get; set; } = "";
    public int AvailableQty { get; set; }
}

/// <summary>
/// Giá trị <c>current_step</c>. GIỮ KHỚP với <c>ReturnBackStep</c> bên API —
/// lệch một ký tự là tab hàng đợi rỗng mà không báo lỗi gì.
/// </summary>
public static class BackStep
{
    public const string FaApprove = "fa_approve";
    public const string ScsInstruct = "scs_instruct";
    public const string ScsApprove = "scs_approve";
    public const string Done = "done";
}

/// <summary>Giá trị <c>req_status</c>. GIỮ KHỚP với <c>ReturnBackStatus</c>.</summary>
public static class BackStatus
{
    public const string FaRequested = "fa_requested";
    public const string FaApproved = "fa_approved";
    public const string ScsInstructed = "scs_instructed";
    public const string ScsApproved = "scs_approved";
    public const string Cancelled = "cancelled";
}
