﻿namespace SWMS_WebTool.Models.Filters
{
    public class TrolleyFilter : BaseFilter
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public string Category { get; set; }
    }
}
