using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.ShipmentTrips.Api;
using Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

public interface ITripInspectionService
{
    /// <summary>Chốt kết quả kiểm container (PDA). Mỗi lần kiểm 1 dòng — kiểm lại sau khi rửa cont là thêm dòng mới.</summary>
    Task<TripInspectionResponse> SubmitAsync(long tripId, TripInspectionRequest request);
}

/*  Kiểm container & seal trước khi đóng hàng (trước đây là màn Container Check riêng trên PDA).
    - Chỉ chuyến container, khi chưa đóng chì (planned / arrived).
    - Đạt: đủ 4 hạng mục + đủ ảnh bước 1 "Tình trạng container" (10 ảnh, kiểm trên server —
      ảnh đã upload trước qua POST {id}/photos, không gửi kèm ở đây).
    - Không đạt: bắt buộc lý do; cont trả về đi rửa. Chuyến KHÔNG tự đổi trạng thái —
      văn phòng đổi số cont nếu hãng tàu cấp cont khác, rồi PDA kiểm lại.            */
public class TripInspectionService : ITripInspectionService
{
    private static readonly HashSet<string> InspectableStatuses = new() { "planned", "arrived" };

    private readonly IShipmentTripRepository _trips;
    private readonly ITripPhotoRepository _photos;
    private readonly ITripVanningRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public TripInspectionService(
        IShipmentTripRepository trips,
        ITripPhotoRepository photos,
        ITripVanningRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _trips = trips;
        _photos = photos;
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    public async Task<TripInspectionResponse> SubmitAsync(long tripId, TripInspectionRequest r)
    {
        var trip = await _trips.GetAsync(tripId)
            ?? throw new NotFoundException(_localizer["Trip.NotFound", tripId]);

        if (trip.VehicleType != ShipmentTripService.Container)
            throw new BusinessRuleException(_localizer["Trip.Inspect.NotContainer"]);
        if (!InspectableStatuses.Contains(trip.Status))
            throw new BusinessRuleException(_localizer["Trip.Inspect.Locked", trip.Status]);

        var result = (r.Result ?? "").Trim().ToLowerInvariant();
        if (result is not (InspectionResults.Pass or InspectionResults.Fail))
            throw new BusinessRuleException(_localizer["Trip.Inspect.ResultInvalid", result]);

        var conditions = (r.PassedConditions ?? new())
            .Select(c => (c ?? "").Trim().ToLowerInvariant())
            .Where(c => c.Length > 0)
            .Distinct()
            .ToList();
        var unknown = conditions.FirstOrDefault(c => !ContainerConditions.All.Contains(c));
        if (unknown is not null)
            throw new BusinessRuleException(_localizer["Trip.Inspect.ConditionInvalid", unknown]);

        var note = string.IsNullOrWhiteSpace(r.Note) ? null : r.Note.Trim();

        if (result == InspectionResults.Pass)
        {
            if (conditions.Count < ContainerConditions.All.Count)
                throw new BusinessRuleException(_localizer["Trip.Inspect.Incomplete"]);

            // Ảnh bước 1 phải có đủ TRÊN SERVER — PDA upload từng ảnh trước khi bấm Đạt.
            var have = (await _photos.GetByTripAsync(tripId))
                .GroupBy(p => p.ItemKey).ToDictionary(g => g.Key, g => g.Count());
            var missing = TripPhotoCatalog.Fcl
                .Where(d => d.Step == 1 && have.GetValueOrDefault(d.Key) < d.PerUnit)
                .Select(d => d.Label)
                .ToList();
            if (missing.Count > 0)
                throw new BusinessRuleException(_localizer["Trip.Inspect.PhotosMissing", string.Join(", ", missing)]);
        }
        else if (note is null)
        {
            throw new BusinessRuleException(_localizer["Trip.Inspect.NoteRequired"]);
        }

        var row = new TripInspectionRow
        {
            TripId = tripId,
            Result = result,
            // Giữ thứ tự chuẩn để báo cáo so chuỗi được
            PassedConditions = string.Join(",", ContainerConditions.All.Where(conditions.Contains)),
            Note = note,
            ContainerNo = trip.ContainerNo,
            InspectedBy = _currentUser.FullName ?? _currentUser.EmployeeCode,
        };
        row.Id = await _repo.AddInspectionAsync(row);

        return TripInspectionResponse.From(await _repo.GetLatestInspectionAsync(tripId) ?? row);
    }
}
