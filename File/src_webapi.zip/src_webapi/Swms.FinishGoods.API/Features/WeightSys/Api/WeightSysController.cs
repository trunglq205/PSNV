using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.Foss.DataAccess;
using Swms.FinishGoods.API.Features.WeightSys.Business;

namespace Swms.FinishGoods.API.Features.WeightSys.Api;

[ApiController]
[Route("api/weight_sys")]
public class WeightSysController : ControllerBase
{
    private readonly IWeightSysService _service;

    public WeightSysController(IWeightSysService service)
    {
        _service = service;
    }

    /// <summary>
    /// Lấy cân nặng theo danh sách serial.
    /// </summary>
    [HttpPost("serials")]
    public async Task<ActionResult<List<WeightResponse>>> GetSerialWeights(
        [FromQuery] FossCategory category,
        [FromQuery] string modelNo,
        [FromBody] List<string> serialNos)
    {
        var result = await _service.GetSerialWeightAsync(
            category,
            modelNo,
            serialNos);

        return Ok(
            result.Select(WeightResponse.From).ToList());
    }
}