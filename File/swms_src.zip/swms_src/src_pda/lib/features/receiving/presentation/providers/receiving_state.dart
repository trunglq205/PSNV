import 'package:flutter/foundation.dart' hide Category;
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/lot_entities.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_history_entry.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// Nguồn Pallet ID ở bước 3.
enum PalletIdSource {
  /// Pallet đã dán nhãn Pallet ID → quét nhãn để lấy lotNo.
  scanExisting,

  /// Pallet chưa có nhãn → hệ thống cấp lotNo khi tạo, rồi in nhãn mới.
  printNew,
}

/// State màn Receiving — ĐỒNG BỘ.
/// step + mode có ngay (UI tức thì); phần đối chiếu có loading/error riêng
/// qua appActionProvider khi quét.
@immutable
class ReceivingState {
  /// Bước hiện tại của quy trình.
  final ReceivingStep step;

  /// Phương thức nhận hàng đang chọn ở bước 1 (box / model).
  final ReceivingMode mode;

  // ── Mode BOX ───────────────────────────────────────────────
  /// Thông tin part card đã quét.
  final List<PartCard> partCards;

  // ── Mode MODEL ─────────────────────────────────────────────
  /// Thông tin model đã quét ở bước 1 (null khi chưa quét).
  final ModelInfo? modelInfo;

  /// Số hộp nhập tay (chỉ dùng khi inputMode == manual).
  final int boxCount;

  /// Danh sách serial đã quét (chỉ dùng khi inputMode == serial).
  final List<String> serials;

  /// Giá trị quét ở bước 3.
  /// - Thường: Pallet ID in sẵn (= lotNo).
  /// - PAP: mã stocky trên xe (lotNo do server cấp).
  final String? lotNo;

  /// Mã stocky trên xe
  final String? stockyCode;

  /// Standard packing do user chỉnh tay trong màn GTIN (null = dùng của modelInfo).
  final int? stdPackOverride;

  /// Bước 3: quét nhãn có sẵn hay tự in nhãn mới. Không áp dụng cho PAP.
  final PalletIdSource palletIdSource;

  /// Bản nháp quét dở còn lưu trong máy (null = không có). Hiển thị ở bước
  /// scan để user phục hồi; KHÔNG bị xóa bởi [ReceivingNotifier.reset].
  final ReceivingHistoryEntry? historyEntry;

  int? get categoryCode => mode == .box
      ? (partCards.isEmpty ? null : partCards.first.category.value)
      : modelInfo?.category?.value;

  /// PAP: lotNo luôn do server cấp, giá trị quét ở bước 3 là mã stocky.
  bool get isPap => categoryCode == CategoryCodes.pap;

  /// lotNo do server cấp khi tạo (PAP, hoặc chọn tự in nhãn).
  bool get usesAutoLotNo =>
      isPap || palletIdSource == PalletIdSource.printNew;

  /// Tạo xong cần in nhãn Pallet ID mới.
  bool get printsNewLabel =>
      !isPap && palletIdSource == PalletIdSource.printNew;

  /// Bước 3 đã đủ dữ liệu để bấm tạo pallet.
  bool get canSubmitPallet =>
      isPap ? lotNo != null : (printsNewLabel || lotNo != null);

  const ReceivingState({
    this.step = ReceivingStep.scan,
    this.mode = ReceivingMode.box,
    this.partCards = const [],
    this.modelInfo,
    this.boxCount = 0,
    this.serials = const [],
    this.lotNo,
    this.stockyCode,
    this.stdPackOverride,
    this.palletIdSource = PalletIdSource.scanExisting,
    this.historyEntry,
  });

  /// Số lượng đơn vị (hộp hoặc serial) tùy inputMode.
  int get modelQty => mode == .gtin ? serials.length : boxCount;

  /// Tổng pcs = qty × standard packing.
  int get modelTotalPcs => modelQty * effectiveStdPack;

  /// Standard packing hiệu lực: ưu tiên override, fallback về modelInfo.
  int get effectiveStdPack =>
      stdPackOverride ?? (modelInfo?.standardPacking ?? 0);

  ReceivingState copyWith({
    ReceivingStep? step,
    ReceivingMode? mode,
    List<PartCard>? partCards,
    ModelInfo? modelInfo,
    int? boxCount,
    List<String>? serials,
    Category? category,
    String? lotNo,
    String? stockyCode,
    CreatedLot? createdLot,
    int? stdPackOverride,
    PalletIdSource? palletIdSource,
    ReceivingHistoryEntry? historyEntry,
    bool clearStdPack = false,
    bool clearLot = false,
    bool clearStocky = false,
    bool clearModel = false,
    bool clearHistory = false,
  }) {
    return ReceivingState(
      step: step ?? this.step,
      mode: mode ?? this.mode,
      partCards: partCards ?? this.partCards,
      modelInfo: clearModel ? null : modelInfo ?? this.modelInfo,
      boxCount: clearModel ? 0 : boxCount ?? this.boxCount,
      serials: clearModel ? const [] : serials ?? this.serials,
      lotNo: clearLot ? null : lotNo ?? this.lotNo,
      stockyCode: clearStocky ? null : stockyCode ?? this.stockyCode,
      stdPackOverride: (clearModel || clearStdPack)
          ? null
          : stdPackOverride ?? this.stdPackOverride,
      palletIdSource: palletIdSource ?? this.palletIdSource,
      historyEntry: clearHistory ? null : historyEntry ?? this.historyEntry,
    );
  }
}