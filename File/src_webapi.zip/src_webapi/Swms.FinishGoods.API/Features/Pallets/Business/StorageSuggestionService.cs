using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.Pallets.Business
{
    /// <summary>
    /// Gợi ý vị trí lưu kho (FR-STR-02).
    ///
    /// Các bước:
    ///   1. Lấy pallet + model đại diện.
    ///   2. Tra master.models: suggest_area quyết định KHU.
    ///      Tầng thì chiều cao pallet ưu tiên trước, master chỉ là dự phòng.
    ///      Khu vực gợi ý không phải STORAGE -> bỏ qua tầng, chỉ gợi ý vị trí.
    ///   3. Tìm last lot cùng model; không có thì cùng category; không nữa thì bỏ mốc.
    ///   4. Xếp hạng vị trí trống: đúng tầng -> đúng loại ô -> cùng rack ->
    ///      trái/phải -> trên/dưới -> gần nhất. Không có mốc thì lấy ngẫu nhiên.
    /// </summary>
    public class StorageSuggestionService : IStorageSuggestionService
    {
        /// <summary>Số phương án thay thế trả kèm. Giữ nhỏ để response gọn.</summary>
        private const int AlternativeCount = 3;

        private readonly IStorageSuggestionRepository _repo;
        private readonly IStringLocalizer<SharedResource> _localizer;

        public StorageSuggestionService(
            IStorageSuggestionRepository repo,
            IStringLocalizer<SharedResource> localizer)
        {
            _repo = repo;
            _localizer = localizer;
        }

        public async Task<StorageSuggestionResponse> SuggestByIdAsync(long palletId, int? palletHeightCm)
        {
            var ctx = await _repo.GetPalletContextAsync(palletId)
                      ?? throw new NotFoundException(_localizer["Lot.Suggestion.PalletNotFound", palletId]);

            return await BuildAsync(ctx, palletHeightCm);
        }

        public async Task<StorageSuggestionResponse> SuggestByLotNoAsync(string lotNo, int? palletHeightCm)
        {
            lotNo = (lotNo ?? "").Trim();
            if (lotNo.Length == 0)
                throw new BusinessRuleException(_localizer["Lot.LotNoRequired"]);

            var ctx = await _repo.GetPalletContextByLotNoAsync(lotNo)
                      ?? throw new NotFoundException(_localizer["Lot.Suggestion.PalletNotFound", lotNo]);

            return await BuildAsync(ctx, palletHeightCm);
        }

        // ── Thân xử lý ────────────────────────────────────────────────────

        private async Task<StorageSuggestionResponse> BuildAsync(
            PalletSuggestionContext ctx, int? heightCm)
        {
            if (heightCm is not null && heightCm <= 0)
                throw new BusinessRuleException(_localizer["Lot.Suggestion.HeightInvalid", heightCm]);

            var warnings = new List<string>();
            var model = ctx.EffectiveModel;

            // ── B1. Cấu hình gợi ý từ master.models ──
            var master = string.IsNullOrWhiteSpace(model)
                ? null
                : await _repo.GetModelSuggestionAsync(model!);

            var hasMasterArea = master?.HasArea == true;

            // Parse ngoài nhánh isStorageArea: khối Master trong response phải
            // phản ánh đúng những gì đang nằm trong DB, kể cả khi lần gợi ý này
            // không dùng tới (khu khác STORAGE, hoặc chiều cao đè lên).
            var masterRows = ParseRackRows(master?.SuggestRackRowRaw);

            long? areaId = hasMasterArea ? master!.SuggestAreaId : null;
            string? areaCode = hasMasterArea ? master!.SuggestAreaCode : AreaCodes.Storage;

            // Lọc theo id khu khi có; ngược lại lọc theo mã khu mặc định.
            string? areaCodeFilter = hasMasterArea ? null : AreaCodes.Storage;

            // ── B2. Tầng / loại ô ──
            // Khu vực gợi ý không phải STORAGE -> chỉ cần vị trí, không cần tầng.
            var isStorageArea = string.Equals(areaCode, AreaCodes.Storage, StringComparison.OrdinalIgnoreCase);

            IReadOnlyList<int> rackRows = [];
            string? slotKind = null;

            if (isStorageArea)
            {
                // CHIỀU CAO ƯU TIÊN TRƯỚC MASTER.
                //
                // suggest_rack_row là cấu hình chung cho cả model, đặt từ trước và
                // theo quy cách đóng hàng dự kiến. Chiều cao là số đo của CHÍNH
                // pallet đang nằm trên xe nâng. Khi hai thứ lệch nhau thì cái đo
                // được mới là sự thật: pallet 180cm nhét vào tầng 2 theo master là
                // đụng nóc, còn pallet 60cm để tầng 2 là bỏ phí ô giá lửng.
                //
                // Master vì vậy lùi xuống vai trò dự phòng: chỉ dùng khi thao tác
                // viên chưa nhập chiều cao.
                var (heightSlotKind, heightRows) = PalletHeightRule.Resolve(heightCm);

                if (heightSlotKind is not null || heightRows.Count > 0)
                {
                    slotKind = heightSlotKind;
                    rackRows = heightRows;
                }
                else if (masterRows.Count > 0)
                {
                    rackRows = masterRows;
                }
                else
                {
                    // Không đo được, master cũng không khai -> không ràng buộc tầng.
                    warnings.Add(_localizer["Lot.Suggestion.Warn.HeightMissing"]);
                }
            }

            // ── B3. Last lot: theo model -> theo category ──
            var lastLot = string.IsNullOrWhiteSpace(model)
                ? null
                : await _repo.FindLastLotAsync(ctx.Id, model, null, areaId, areaCodeFilter);

            if (lastLot is null)
                lastLot = await _repo.FindLastLotAsync(ctx.Id, null, ctx.CategoryCode, areaId, areaCodeFilter);

            if (lastLot is null)
                warnings.Add(_localizer["Lot.Suggestion.Warn.NoLastLot"]);

            // ── B4. Xếp hạng vị trí trống ──
            var criteria = new LocatorSearchCriteria
            {
                ExcludePalletId = ctx.Id,
                AreaId = areaId,
                AreaCode = areaCodeFilter,
                RackRows = rackRows,
                SlotKind = slotKind,
                Reference = lastLot,
                Take = AlternativeCount + 1,
            };

            var candidates = await _repo.FindFreeLocatorsAsync(criteria);

            // Khu vực gợi ý hết chỗ -> nới ra toàn kho STORAGE thay vì trả rỗng.
            if (candidates.Count == 0 && areaId is not null)
            {
                warnings.Add(_localizer["Lot.Suggestion.Warn.AreaFallback",
                                        master?.SuggestAreaCode ?? areaId.ToString() ?? ""]);

                candidates = await _repo.FindFreeLocatorsAsync(new LocatorSearchCriteria
                {
                    ExcludePalletId = ctx.Id,
                    AreaId = null,
                    AreaCode = AreaCodes.Storage,
                    RackRows = rackRows,
                    SlotKind = slotKind,
                    Reference = lastLot,
                    Take = AlternativeCount + 1,
                });
            }

            var best = candidates.FirstOrDefault();

            // Tầng / loại ô là ưu tiên mềm -> gợi ý lệch vẫn trả, kèm cảnh báo
            // để PDA hiển thị cho người vận hành tự quyết.
            if (best is not null)
            {
                if (rackRows.Count > 0 && !best.RowMatch)
                    warnings.Add(_localizer["Lot.Suggestion.Warn.RowMismatch",
                                            string.Join(", ", rackRows),
                                            best.RackRow?.ToString() ?? "-"]);

                // Lệch loại ô theo cả hai chiều: nhắm giá lửng mà phải xuống rack thường,
                // hoặc nhắm tầng rack mà chỉ còn ô giá lửng.
                if (!best.SlotMatch)
                {
                    if (slotKind is not null)
                        warnings.Add(_localizer["Lot.Suggestion.Warn.SlotMismatch", slotKind]);
                    else if (rackRows.Count > 0 && best.IsShelf)
                        warnings.Add(_localizer["Lot.Suggestion.Warn.ShelfNotSuitable"]);
                }
            }

            return new StorageSuggestionResponse(
                ctx.LotNo,
                model,
                ResolveStrategy(hasMasterArea, lastLot),
                ModelMasterConfigResponse.From(master, masterRows),
                // Ưu tiên khu của vị trí thực sự chọn được: khi phải nới khu (AreaFallback)
                // thì đây mới là khu đúng, còn khu trong master chỉ là ý định ban đầu.
                best?.AreaCode ?? areaCode,
                best?.AreaName ?? master?.SuggestAreaName,
                rackRows,
                slotKind,
                best is null ? null : SuggestedLocatorResponse.From(best),
                candidates.Skip(1).Select(SuggestedLocatorResponse.From).ToList(),
                lastLot is null ? null : LastLotLocationResponse.From(lastLot),
                warnings);
        }

        // ── helpers ───────────────────────────────────────────────────────

        /// <summary>
        /// Parse cột master.models.suggest_rack_row ("2,3") sang danh sách tầng.
        /// Giá trị rác bị bỏ qua thay vì ném lỗi — dữ liệu master không nên chặn
        /// người vận hành đang đứng ở kho.
        /// </summary>
        private static IReadOnlyList<int> ParseRackRows(string? raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return [];

            var rows = new SortedSet<int>();
            foreach (var part in raw.Split(',', StringSplitOptions.RemoveEmptyEntries
                                              | StringSplitOptions.TrimEntries))
                if (int.TryParse(part, out var v) && v > 0)
                    rows.Add(v);

            return rows.ToList();
        }

        private static string ResolveStrategy(bool hasMasterArea, LastLotLocation? lastLot)
        {
            if (lastLot is null)
                return hasMasterArea ? SuggestionStrategies.MasterOnly : SuggestionStrategies.Random;

            if (lastLot.MatchedBy == LastLotMatchedBy.Category)
                return SuggestionStrategies.CategoryLastLot;

            return hasMasterArea
                ? SuggestionStrategies.MasterAndLastLot
                : SuggestionStrategies.HeightAndLastLot;
        }
    }
}
