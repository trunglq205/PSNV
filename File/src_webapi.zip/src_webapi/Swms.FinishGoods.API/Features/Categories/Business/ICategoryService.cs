﻿using Swms.FinishGoods.Api.Features.Categories.Api;

namespace Swms.FinishGoods.Api.Features.Categories.Business;

public interface ICategoryService
{
    Task<List<CategoryResponse>> GetAllAsync(CategoryQuery query);
    Task<List<CategoryOptionResponse>> GetOptionsAsync();
    Task<CategoryResponse> GetByCodeAsync(int code);
    Task<CategoryResponse> CreateAsync(CreateCategoryRequest request);
    Task UpdateAsync(int code, UpdateCategoryRequest request);
    Task DeleteAsync(int code);
}