// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'trip_stowage_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

StowageTierModel _$StowageTierModelFromJson(Map<String, dynamic> json) =>
    StowageTierModel(
      tier: (json['tier'] as num).toInt(),
      planPalletCode: json['planPalletCode'] as String?,
      siNo: json['siNo'] as String?,
      palletSize: json['palletSize'] as String?,
    );

StowageColumnModel _$StowageColumnModelFromJson(Map<String, dynamic> json) =>
    StowageColumnModel(
      code: json['code'] as String,
      cocNo: (json['cocNo'] as num).toInt(),
      rowNo: (json['rowNo'] as num?)?.toInt(),
      laneNo: (json['laneNo'] as num?)?.toInt(),
      tiers:
          (json['tiers'] as List<dynamic>?)
              ?.map((e) => StowageTierModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
      bottomCode: json['bottomCode'] as String?,
      topCode: json['topCode'] as String?,
      stackedAt: json['stackedAt'] == null
          ? null
          : DateTime.parse(json['stackedAt'] as String),
      placedAt: json['placedAt'] == null
          ? null
          : DateTime.parse(json['placedAt'] as String),
      placedBy: json['placedBy'] as String?,
    );

TripStowageModel _$TripStowageModelFromJson(Map<String, dynamic> json) =>
    TripStowageModel(
      tripId: (json['tripId'] as num).toInt(),
      planNo: json['planNo'] as String,
      planStatus: json['planStatus'] as String,
      shipMode: json['shipMode'] as String,
      containerType: json['containerType'] as String,
      rows: (json['rows'] as num?)?.toInt() ?? 0,
      lanes: (json['lanes'] as num?)?.toInt() ?? 0,
      stacked: (json['stacked'] as num?)?.toInt() ?? 0,
      placed: (json['placed'] as num?)?.toInt() ?? 0,
      canEdit: json['canEdit'] as bool? ?? false,
      columns:
          (json['columns'] as List<dynamic>?)
              ?.map(
                (e) => StowageColumnModel.fromJson(e as Map<String, dynamic>),
              )
              .toList() ??
          const [],
    );

Map<String, dynamic> _$StowageCodesRequestModelToJson(
  StowageCodesRequestModel instance,
) => <String, dynamic>{
  'bottomCode': ?instance.bottomCode,
  'topCode': ?instance.topCode,
};
