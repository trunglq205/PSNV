using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.HdSoft.Business;

namespace Swms.FinishGoods.API.Features.HdSoft.Api
{
    [ApiController]
    [Route("api/hdsoft")]
    public class HdSoftController : ControllerBase
    {
        private readonly IHdSoftService _service;
        public HdSoftController(IHdSoftService service) => _service = service;

        /// <summary>
        /// Lịch sử di chuyển của lot (mới nhất trước).
        /// VD: GET /api/hdsoft/lot/PL1/history
        /// </summary>
        [HttpGet("lot/{lot}/history")]
        public async Task<ActionResult<List<HdSoftLotHistoryItemResponse>>> GetLotHistory(string lot)
            => Ok(await _service.GetLotHistoryAsync(lot));

        /// <summary>
        /// Tất cả pallet đang tồn kho (QtyOnHand > 0).
        /// VD: GET /api/hdsoft/pallets/in-stock?warehouse=PSNV
        /// </summary>
        [HttpGet("pallets/in-stock")]
        public async Task<ActionResult<List<HdSoftPalletStockResponse>>> GetPalletsInStock(
            [FromQuery] string warehouse = "PSNV")
            => Ok(await _service.GetPalletsInStockAsync(warehouse));

        /// <summary>
        /// Trường SAP nào đọc được từ cột nào của C_Order / C_OrderLine — kiểm tra cấu hình.
        /// VD: GET /api/hdsoft/si/columns
        /// </summary>
        [HttpGet("si/columns")]
        public async Task<ActionResult<HdSoftSiColumnsResponse>> GetSiColumns()
            => Ok(await _service.GetSiColumnsAsync());

        /// <summary>
        /// Hàng thiếu theo ngày vanning: nhu cầu còn mở của SI so với tồn kho HD soft (chia tồn theo vanning sớm trước).
        /// VD: GET /api/hdsoft/si/shortages?from=2026-10-23&amp;to=2026-10-31&amp;warehouse=PSNV&amp;onlyShort=true
        /// </summary>
        [HttpGet("si/shortages")]
        public async Task<ActionResult<HdSoftShortageResponse>> GetShortages([FromQuery] HdSoftShortageQuery query)
            => Ok(await _service.GetShortagesAsync(query));

        /// <summary>
        /// SI bên HD soft theo SINo: phiếu C_Order mới nhất chưa huỷ + dòng.
        /// VD: GET /api/hdsoft/si/PB202506J3
        /// </summary>
        [HttpGet("si/{siNo}")]
        public async Task<ActionResult<HdSoftSiResponse>> GetSi(string siNo)
            => Ok(await _service.GetSiAsync(siNo));
    }
}
