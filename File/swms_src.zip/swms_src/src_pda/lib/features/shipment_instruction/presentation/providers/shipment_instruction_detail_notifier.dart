import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/repositories/shipment_instruction_repository.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_detail_state.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_providers.dart';

part 'shipment_instruction_detail_notifier.g.dart';

/// Notifier family theo siId.
@riverpod
class ShipmentInstructionDetailNotifier
    extends _$ShipmentInstructionDetailNotifier
    with BaseNotifierMixin<ShipmentInstructionDetailState> {
  ShipmentInstructionRepository get _repo =>
      ref.read(shipmentInstructionRepositoryProvider);

  @override
  ShipmentInstructionDetailState build(int siId) {
    Future.microtask(load);
    return const ShipmentInstructionDetailState();
  }

  /// Đọc → executePartial (lỗi hiển thị trong vùng detail).
  Future<void> load() => executePartial<ShipmentInstructionDetail>(
    action: () => _repo.getDetail(siId),
    getField: (s) => s.detail,
    setField: (s, f) => s.copyWith(detail: f),
  );
}
