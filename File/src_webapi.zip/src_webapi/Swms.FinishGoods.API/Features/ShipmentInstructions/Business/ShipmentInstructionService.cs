using System.Text.RegularExpressions;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Business;

public class ShipmentInstructionService : IShipmentInstructionService
{
    private readonly IShipmentInstructionRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly SapInboundAudit _audit;
    private readonly ISapInboundLogRepository _sapLogs;

    // Phiếu ở 2 trạng thái này chỉ còn xem được
    private static readonly HashSet<string> ClosedStatuses = new() { "completed", "cancelled" };

    public ShipmentInstructionService(
        IShipmentInstructionRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        SapInboundAudit audit,
        ISapInboundLogRepository sapLogs)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
        _audit = audit;
        _sapLogs = sapLogs;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Danh sách / chi tiết
    // ═══════════════════════════════════════════════════════════════

    public async Task<PagedResult<SiListItemResponse>> GetPagedAsync(SiQuery query)
    {
        if (query.Page < 1) query.Page = 1;
        if (query.Size < 1 || query.Size > 100) query.Size = 20;
        // Ngày "đến" tính hết ngày đó
        if (query.VanningFrom is { } vf) query.VanningFrom = vf.Date;
        if (query.VanningTo is { } vt) query.VanningTo = vt.Date;
        if (query.CreatedTo is { } ct) query.CreatedTo = ct.Date.AddDays(1).AddTicks(-1);

        var (rows, total) = await _repo.GetPagedAsync(query);
        var items = rows.Select(SiListItemResponse.From).ToList();
        return new PagedResult<SiListItemResponse>(items, total, query.Page, query.Size);
    }

    public async Task<SiStatusCountResponse> GetStatusCountsAsync()
        => new(await _repo.GetStatusCountsAsync());

    public async Task<SiDetailResponse> GetByIdAsync(long id)
    {
        var detail = await _repo.GetDetailAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);
        return SiDetailResponse.From(detail);
    }

    /// <summary>Lịch sử lấy từ wms.sap_inbound_logs — chỉ gồm các lần SAP gửi, không gồm sửa tay trên web.</summary>
    public async Task<List<SiHistoryItemResponse>> GetHistoryAsync(long id, bool onlyChanges)
    {
        var header = await _repo.GetHeaderAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);
        var logs = await _sapLogs.GetBySiAsync(id, header.SiNo, onlyChanges);
        return logs.Select(SiHistoryItemResponse.From).ToList();
    }

    // ═══════════════════════════════════════════════════════════════
    //  Header
    // ═══════════════════════════════════════════════════════════════

    public Task<SiDetailResponse> CreateAsync(CreateSiRequest request)
        => CreateCoreAsync(request, _currentUser.FullName);

    /// <summary>actor: người tạo ghi vào created_by (SAP: pic của payload).</summary>
    private async Task<SiDetailResponse> CreateCoreAsync(CreateSiRequest request, string? actor)
    {
        var siNo = request.SiNo.Trim();
        var revision = Clean(request.Revision);
        var docNo = revision is null ? siNo : $"{siNo}-{revision}";

        if (await _repo.DocNoExistsAsync(docNo, excludeId: null))
            throw new ConflictException(_localizer["Si.DocNoExists", docNo]);

        var lines = BuildLines(request.Lines);
        if (lines.Count == 0)
            throw new BusinessRuleException(_localizer["Si.LinesRequired"]);

        var header = new SiHeader
        {
            DocNo = docNo,
            SiNo = siNo,
            Revision = revision,
            DocStatus = "released",
            CreatedAt = DateTime.Now,
            CreatedBy = actor,
        };
        ApplyHeader(header, request);

        var id = await _repo.AddAsync(header, lines);
        return await GetByIdAsync(id);
    }

    /*  Nhận payload SAP nguyên dạng (SapSiRequest), dịch qua SapSiMapper.

        SAP gửi cùng 1 si_no nhiều lần: sửa lại cùng revision, hoặc lên revision mới
        (First -> REV1 -> REV2). Phiếu được nhận diện theo SI_NO, không theo doc_no:
          si_no chưa có (hoặc chỉ còn phiếu đã huỷ) -> tạo mới          (Created = true)
          si_no đã có                               -> cập nhật phiếu đó (Created = false):
                header + doc_no / revision lấy theo payload, dòng được đồng bộ
          payload không khác gì phiếu đang có       -> không ghi gì, vẫn trả 200
        isupdatesi không còn cần — có hay không đều cập nhật.

        Dòng cũ nhận diện theo (packing_list_no, packing_item_no, model).
        Dòng ĐÃ có kế hoạch / thùng chỉ định:
          - đổi ngày, SO, invoice, tăng số lượng           -> nhận
          - giảm số lượng xuống dưới số đã phân bổ + đã lấy -> từ chối
          - đổi PO, hoặc SAP bỏ hẳn dòng                    -> từ chối (rút kế hoạch trước)
        Trường kho tự quản (category, khu đến, ghi chú, customer material, plt / ctn) giữ nguyên.

        Mỗi lần nhận, service ghi vào _audit ai sửa (pic) và đổi gì; SapInboundLogFilter
        lưu vào wms.sap_inbound_logs cùng dòng với payload gốc và thời điểm nhận.          */
    public async Task<(SiDetailResponse Si, bool Created)> CreateFromSapAsync(SapSiRequest request)
    {
        var m = SapSiMapper.Map(request);
        var actor = SapActor(request.Pic);

        // Ghi sớm: request bị từ chối vẫn biết ai gửi
        _audit.ChangedBy = actor;

        if (m.Errors.Count > 0)
            throw new BusinessRuleException(_localizer["Si.SapInvalid", string.Join("; ", m.Errors)]);

        var changes = new SiChangeSet();
        changes.Notes.AddRange(m.Warnings);

        var existingId = await _repo.GetActiveIdBySiNoAsync(m.SiNo);
        if (existingId is null)
        {
            var created = await CreateCoreAsync(m.ToCreate(), actor);
            SetAudit(SapInboundAudit.Created, created.Id, changes);
            return (created, true);
        }

        var detail = await _repo.GetDetailAsync(existingId.Value)
            ?? throw new NotFoundException(_localizer["Si.NotFound", existingId.Value]);
        var header = detail.Header;
        _audit.SiId = header.Id;
        EnsureEditable(header);     // completed: không nhận sửa nữa (cancelled đã bị loại ở bước tìm)

        // SAP gửi lệch thứ tự / gửi lại bản cũ: không để REV1 đè lên REV2
        if (RevisionRank(m.Revision) is { } incoming && RevisionRank(header.Revision) is { } current
            && incoming < current)
            throw new ConflictException(_localizer["Si.SapStaleRevision", m.DocNo, header.DocNo]);

        if (!string.Equals(header.DocNo, m.DocNo, StringComparison.OrdinalIgnoreCase)
            && await _repo.DocNoExistsAsync(m.DocNo, header.Id))
            throw new ConflictException(_localizer["Si.DocNoExists", m.DocNo]);

        // ── Header ──────────────────────────────────────────
        var before = SiChangeSet.Snapshot(header);
        var req = m.ToUpdate(m.Lines);
        req.Category = header.Category;          // kho tự quản — SAP không gửi, giữ nguyên
        req.ToAreaId = header.ToAreaId;
        req.Description = header.Description;
        req.HeaderNote = MergeSapNote(header.HeaderNote, req.HeaderNote);
        ApplyHeader(header, req);
        header.DocNo = m.DocNo;
        header.Revision = m.Revision;
        changes.AddHeaderDiff(before, SiChangeSet.Snapshot(header));

        // ── Dòng ────────────────────────────────────────────
        static string Key(string? pl, string? item, string model) => $"{pl}|{item}|{model}".ToUpperInvariant();
        // Mỗi dòng cũ chỉ khớp 1 lần — trùng khoá thì lấy lần lượt theo số dòng
        var pool = detail.Lines
            .GroupBy(l => Key(l.PackingListNo, l.PackingItemNo, l.Model))
            .ToDictionary(g => g.Key, g => new Queue<SiLine>(g.OrderBy(l => l.LineNo)));
        var lockedIds = detail.Tasks.Select(t => t.LineId)
            .Concat(detail.Boxes.Select(b => b.LineId))
            .ToHashSet();

        var lines = new List<SiLine>();
        var added = new List<(int Index, SiLine Line)>();   // số dòng chỉ có sau khi ghi
        foreach (var r in m.Lines)
        {
            var line = ToLine(r);
            if (pool.TryGetValue(Key(line.PackingListNo, line.PackingItemNo, line.Model), out var queue)
                && queue.TryDequeue(out var old))
            {
                line.Id = old.Id;
                line.SiId = old.SiId;
                line.LineNo = old.LineNo;                       // giữ số dòng cũ
                line.CustomerMaterial = old.CustomerMaterial;   // kho tự nhập — SAP không gửi
                line.PackagePlt = old.PackagePlt;
                line.PackageCtn = old.PackageCtn;

                var diff = SiChangeSet.DiffLine(old, line);
                if (diff.Count > 0)
                {
                    if (lockedIds.Contains(old.Id)) EnsureLockedLineChange(old, line);
                    changes.AddLine("changed", line, diff);
                }
            }
            else
            {
                line.SiId = header.Id;
                line.LineNo = 0;                                // repository đánh số sau số lớn nhất
                added.Add((changes.Lines.Count, line));
                changes.AddLine("added", line);
            }
            lines.Add(line);
        }

        foreach (var gone in pool.Values.SelectMany(q => q).OrderBy(l => l.LineNo))
        {
            if (lockedIds.Contains(gone.Id))
                throw new BusinessRuleException(_localizer["Si.LineLocked", gone.LineNo, gone.Model]);
            changes.AddLine("removed", gone);
        }

        changes.DropRawNoteNoise();
        if (!changes.HasChanges)
        {
            // SAP gửi lại y nguyên (kể cả bản lặp dòng đã khử trùng): không đụng updated_at
            SetAudit(SapInboundAudit.Unchanged, header.Id, changes);
            return (SiDetailResponse.From(detail), false);
        }

        header.UpdatedAt = DateTime.Now;
        header.UpdatedBy = actor;
        var (found, lockedLineId) = await _repo.ApplySapRevisionAsync(header, lines);
        if (!found)
            throw new NotFoundException(_localizer["Si.NotFound", header.Id]);
        if (lockedLineId is { } lid)
        {
            // Dòng vừa được phân bổ giữa lúc kiểm tra và lúc ghi — transaction đã rollback
            var l = detail.Lines.First(x => x.Id == lid);
            throw new BusinessRuleException(_localizer["Si.LineLocked", l.LineNo, l.Model]);
        }

        foreach (var (index, line) in added)
            changes.Lines[index] = changes.Lines[index] with { LineNo = line.LineNo };

        SetAudit(SapInboundAudit.Updated, header.Id, changes);
        return (await GetByIdAsync(header.Id), false);
    }

    /// <summary>Dòng đã có kế hoạch / thùng chỉ định: chỉ nhận thay đổi không làm lệch phần đã phân bổ.</summary>
    private void EnsureLockedLineChange(SiLine old, SiLine cur)
    {
        // Phân bổ FIFO lọc theo PO của thùng -> đổi PO là kế hoạch cũ sai
        if (cur.PoNo != old.PoNo)
            throw new BusinessRuleException(_localizer["Si.LineLocked", old.LineNo, old.Model]);

        var held = old.QtyPending + old.QtyPicked;
        if (cur.QtyRequired < held)
            throw new BusinessRuleException(
                _localizer["Si.SapQtyBelowAllocated", old.LineNo, old.Model, cur.QtyRequired, held]);
    }

    private void SetAudit(string action, long siId, SiChangeSet changes)
    {
        _audit.Action = action;
        _audit.SiId = siId;
        _audit.ChangeSummary = changes.Summary();
        _audit.ChangesJson = changes.HasChanges || changes.Notes.Count > 0 ? changes.ToJson() : null;
    }

    /// <summary>Người sửa = pic của payload; không có thì lấy user gọi API, cuối cùng là "SAP".</summary>
    private string SapActor(string? pic)
    {
        var name = Clean(pic) ?? Clean(_currentUser.FullName) ?? "SAP";
        return name.Length <= 50 ? name : name[..50];
    }

    /// <summary>First / không ghi = 0; "REV2", "Rev 2" = 2. Dạng lạ -> null: không so được, cho qua.</summary>
    private static int? RevisionRank(string? revision)
    {
        var r = Clean(revision);
        if (r is null || r.Contains("first", StringComparison.OrdinalIgnoreCase)) return 0;
        var match = Regex.Match(r, @"(\d+)\s*$");
        return match.Success && int.TryParse(match.Groups[1].Value, out var n) ? n : null;
    }

    /// <summary>Thay các khoá do SAP ghi (SapSiMapper.NoteKeys), giữ khoá kho tự nhập trên web.</summary>
    private static Dictionary<string, string> MergeSapNote(string? currentJson, Dictionary<string, string>? sapNote)
    {
        var merged = HeaderNoteJson.Read(currentJson)
            .Where(kv => !SapSiMapper.NoteKeys.Contains(kv.Key))
            .ToDictionary(kv => kv.Key, kv => kv.Value);
        foreach (var (key, value) in sapNote ?? new())
            merged[key] = value;
        return merged;
    }

    public async Task UpdateAsync(long id, UpdateSiRequest request)
    {
        var detail = await _repo.GetDetailAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);
        EnsureEditable(detail.Header);

        List<SiLine>? lines = null;
        if (request.Lines is not null)
        {
            lines = BuildLines(request.Lines, detail.Lines.ToDictionary(l => l.Id, l => l.LineNo));
            if (lines.Count == 0)
                throw new BusinessRuleException(_localizer["Si.LinesRequired"]);

            // Dòng đã có kế hoạch / thùng chỉ định: không được xoá, không đổi model / PO / số lượng.
            // Báo lỗi rõ thay vì để repository lặng lẽ bỏ qua.
            var locked = detail.Lines
                .Where(l => detail.Tasks.Any(t => t.LineId == l.Id) || detail.Boxes.Any(b => b.LineId == l.Id))
                .ToList();
            foreach (var l in locked)
            {
                var req = lines.FirstOrDefault(x => x.Id == l.Id);
                if (req is null
                    || req.Model != l.Model
                    || req.PoNo != l.PoNo
                    || req.QtyRequired != l.QtyRequired)
                    throw new BusinessRuleException(_localizer["Si.LineLocked", l.LineNo, l.Model]);
            }
        }

        var header = detail.Header;
        ApplyHeader(header, request);
        header.UpdatedAt = DateTime.Now;
        header.UpdatedBy = _currentUser.FullName;

        if (!await _repo.UpdateAsync(header, lines))
            throw new NotFoundException(_localizer["Si.NotFound", id]);
    }

    public async Task DeleteAsync(long id)
    {
        _ = await _repo.GetHeaderAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);

        // Đã lấy hàng thật thì chỉ được huỷ (còn dấu vết), không được xoá.
        if (await _repo.HasPickedAsync(id))
            throw new BusinessRuleException(_localizer["Si.DeleteHasPicked"]);

        if (!await _repo.SoftDeleteAsync(id, _currentUser.FullName))
            throw new NotFoundException(_localizer["Si.NotFound", id]);
    }

    public async Task CancelAsync(long id, CancelSiRequest request)
    {
        var header = await _repo.GetHeaderAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);
        EnsureEditable(header);

        if (!await _repo.CancelAsync(id, request.Reason.Trim(), _currentUser.FullName))
            throw new NotFoundException(_localizer["Si.NotFound", id]);
    }

    public async Task CompleteAsync(long id)
    {
        var header = await _repo.GetHeaderAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);
        EnsureEditable(header);     // đã completed / cancelled -> Si.Closed

        if (!await _repo.CompleteAsync(id, _currentUser.FullName))
            throw new BusinessRuleException(_localizer["Si.Closed", header.DocNo, header.DocStatus]);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Line
    // ═══════════════════════════════════════════════════════════════

    public async Task<SiLineResponse> AddLineAsync(long siId, SiLineRequest request)
    {
        var header = await _repo.GetHeaderAsync(siId)
            ?? throw new NotFoundException(_localizer["Si.NotFound", siId]);
        EnsureEditable(header);

        var line = ToLine(request);
        line.SiId = siId;
        line.Id = await _repo.AddLineAsync(line);

        var saved = await _repo.GetLineAsync(line.Id)
            ?? throw new NotFoundException(_localizer["Si.LineNotFound", line.Id]);
        return SiLineResponse.From(saved, Array.Empty<SiTask>(), Array.Empty<SiBox>());
    }

    public async Task UpdateLineAsync(long lineId, SiLineRequest request)
    {
        var (line, _) = await GetEditableLineAsync(lineId);
        if (await _repo.LineLockedAsync(lineId))
            throw new BusinessRuleException(_localizer["Si.LineLocked", line.LineNo, line.Model]);

        var updated = ToLine(request);
        updated.Id = lineId;
        updated.SiId = line.SiId;
        if (updated.LineNo <= 0) updated.LineNo = line.LineNo;

        if (!await _repo.UpdateLineAsync(updated))
            throw new NotFoundException(_localizer["Si.LineNotFound", lineId]);
    }

    public async Task DeleteLineAsync(long lineId)
    {
        var (line, _) = await GetEditableLineAsync(lineId);
        if (await _repo.LineLockedAsync(lineId))
            throw new BusinessRuleException(_localizer["Si.LineLocked", line.LineNo, line.Model]);

        if (!await _repo.DeleteLineAsync(lineId))
            throw new NotFoundException(_localizer["Si.LineNotFound", lineId]);
    }

    /*  QtyCut là TỔNG số cắt của dòng (không cộng dồn). Tối đa = phần chưa được đáp ứng:
        qty_required - pending - picked. null = bỏ cắt.                                  */
    public async Task CutLineAsync(long lineId, CutLineRequest request)
    {
        var (line, _) = await GetEditableLineAsync(lineId);

        if (request.QtyCut is { } cut)
        {
            var max = line.QtyRequired - line.QtyPending - line.QtyPicked;
            if (cut > max)
                throw new BusinessRuleException(_localizer["Si.CutTooMuch", max]);
        }

        await _repo.SetCutAsync(lineId, request.QtyCut, _currentUser.FullName);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Phân bổ
    // ═══════════════════════════════════════════════════════════════

    public async Task<AllocateResponse> AllocateAsync(long id, AllocateRequest request)
    {
        var header = await _repo.GetHeaderAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);
        EnsureEditable(header);

        if (request.LineId is { } lid)
        {
            var line = await _repo.GetLineAsync(lid);
            if (line is null || line.SiId != id)
                throw new NotFoundException(_localizer["Si.LineNotFound", lid]);
        }

        var created = await _repo.AllocateAsync(
            id, request.LineId, request.ToLocatorId, Clean(request.AssignedTo), _currentUser.FullName);

        // Trả luôn phần còn thiếu để FE báo "đã phân bổ N pallet, còn thiếu X pcs"
        var detail = await _repo.GetDetailAsync(id);
        var shortAfter = detail?.Lines
            .Where(l => request.LineId is null || l.Id == request.LineId)
            .Sum(l => l.QtyShort) ?? 0;

        return new AllocateResponse(created, shortAfter);
    }

    public async Task<List<SiTaskResponse>> GetTasksAsync(long id)
    {
        var detail = await _repo.GetDetailAsync(id)
            ?? throw new NotFoundException(_localizer["Si.NotFound", id]);
        return detail.Tasks.Select(SiTaskResponse.From).ToList();
    }

    public async Task UpdateTaskAsync(long taskId, UpdateTaskRequest request)
    {
        var task = await _repo.GetTaskAsync(taskId)
            ?? throw new NotFoundException(_localizer["Si.TaskNotFound", taskId]);
        if (task.ShipmentStatus != "pending")
            throw new BusinessRuleException(_localizer["Si.TaskNotPending"]);

        if (!await _repo.UpdateTaskAsync(taskId, request.ToLocatorId, Clean(request.AssignedTo)))
            throw new NotFoundException(_localizer["Si.TaskNotFound", taskId]);
    }

    public async Task ReleaseTaskAsync(long taskId)
    {
        var task = await _repo.GetTaskAsync(taskId)
            ?? throw new NotFoundException(_localizer["Si.TaskNotFound", taskId]);
        if (task.ShipmentStatus != "pending")
            throw new BusinessRuleException(_localizer["Si.TaskNotPending"]);
        if (task.BoxPicked > 0)
            throw new BusinessRuleException(_localizer["Si.TaskHasScanned", task.BoxPicked]);

        if (!await _repo.ReleaseTaskAsync(taskId))
            throw new BusinessRuleException(_localizer["Si.TaskHasScanned", task.BoxPicked]);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Mã thùng chỉ định
    // ═══════════════════════════════════════════════════════════════

    public async Task<List<SiBoxResponse>> DesignateBoxesAsync(long lineId, DesignateBoxesRequest request)
    {
        await GetEditableLineAsync(lineId);

        var boxNos = request.BoxNos
            .Select(x => x?.Trim())
            .Where(x => !string.IsNullOrEmpty(x))
            .Select(x => x!)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (boxNos.Count == 0)
            throw new BusinessRuleException(_localizer["Si.BoxNosRequired"]);
        if (boxNos.Any(x => x.Length > 50))
            throw new BusinessRuleException(_localizer["Si.BoxNoTooLong"]);

        await _repo.AddDesignatedBoxesAsync(lineId, boxNos, request.Replace);
        return (await _repo.GetBoxesByLineAsync(lineId)).Select(SiBoxResponse.From).ToList();
    }

    public async Task<List<SiBoxResponse>> RematchBoxesAsync(long lineId)
    {
        await GetEditableLineAsync(lineId);
        await _repo.MatchDesignatedBoxesAsync(lineId);
        return (await _repo.GetBoxesByLineAsync(lineId)).Select(SiBoxResponse.From).ToList();
    }

    /// <summary>Chọn tay 1 thùng cho mã bị 'ambiguous' (nhiều pallet cùng box_no + model).</summary>
    public async Task ResolveBoxAsync(long id, ResolveBoxRequest request)
    {
        var box = await _repo.GetBoxAsync(id)
            ?? throw new NotFoundException(_localizer["Si.BoxNotFound", id]);
        await GetEditableLineAsync(box.LineId);

        if (box.SiPalletId is not null || box.PickedAt is not null)
            throw new BusinessRuleException(_localizer["Si.BoxAlreadyPlanned", box.BoxNo]);
        if (!await _repo.BoxMatchesAsync(id, request.BoxId))
            throw new BusinessRuleException(_localizer["Si.BoxNotMatch", box.BoxNo]);
        if (await _repo.BoxHeldAsync(request.BoxId, id))
            throw new ConflictException(_localizer["Si.BoxTaken", box.BoxNo]);

        await _repo.ResolveBoxAsync(id, request.BoxId);
    }

    public async Task DeleteBoxAsync(long id)
    {
        var box = await _repo.GetBoxAsync(id)
            ?? throw new NotFoundException(_localizer["Si.BoxNotFound", id]);
        await GetEditableLineAsync(box.LineId);

        // Đã vào kế hoạch -> phải rút dòng kế hoạch trước, không thì box_planned lệch
        if (box.SiPalletId is not null || box.PickedAt is not null)
            throw new BusinessRuleException(_localizer["Si.BoxAlreadyPlanned", box.BoxNo]);

        await _repo.DeleteBoxAsync(id);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Lấy hàng (PDA)
    // ═══════════════════════════════════════════════════════════════

    private const string ModePallet = "pallet";
    private const string ModeDesignated = "designated";

    public async Task<PickTaskDetailResponse> GetPickTaskAsync(long taskId)
        => await BuildPickDetailAsync(await GetTaskOrThrowAsync(taskId));

    /// <summary>Lấy nguyên pallet: Pallet ID quét phải đúng pallet của dòng kế hoạch.</summary>
    public async Task<PickTaskDetailResponse> ConfirmPalletAsync(long taskId, ConfirmPalletRequest request)
    {
        var task = await GetPickableTaskAsync(taskId);
        if (task.PickMode != ModePallet)
            throw new BusinessRuleException(_localizer["Si.PickWrongMode"]);

        var expected = task.PalletCode.Trim();
        if (!string.Equals(request.PalletCode.Trim(), expected, StringComparison.OrdinalIgnoreCase))
            throw new BusinessRuleException(_localizer["Si.PickPalletMismatch", expected]);

        if (!await _repo.ConfirmPalletAsync(taskId, _currentUser.FullName))
            throw new BusinessRuleException(_localizer["Si.TaskNotPending"]);

        return await BuildPickDetailAsync(await GetTaskOrThrowAsync(taskId));
    }

    /*  Quét 1 thùng (fifo / chỉ định). Chặn theo thứ tự:
          không thuộc pallet / khác model -> đã quét -> SI khác giữ -> đủ thùng
          -> không nằm trong danh sách chỉ định -> chưa tới lượt NSX (FIFO)          */
    public async Task<PickTaskDetailResponse> PickBoxAsync(long taskId, PickBoxRequest request)
    {
        var task = await GetPickableTaskAsync(taskId);
        if (task.PickMode == ModePallet)
            throw new BusinessRuleException(_localizer["Si.PickWrongMode"]);

        var boxNo = request.BoxNo.Trim();
        var rows = await _repo.GetPickBoxesAsync(taskId);
        var row = FindBox(rows, boxNo)
            ?? throw new BusinessRuleException(_localizer["Si.PickBoxNotInPallet", boxNo]);

        if (row.IsPicked)
            throw new BusinessRuleException(_localizer["Si.PickBoxAlreadyPicked", boxNo]);
        if (row.HeldByOther)
            throw new ConflictException(_localizer["Si.BoxTaken", boxNo]);

        var boxes = BuildPickBoxes(task, rows);
        if (boxes.Count(b => b.State == "picked") >= task.BoxPlanned)
            throw new BusinessRuleException(_localizer["Si.PickTaskFull"]);

        var state = boxes.FirstOrDefault(b => b.BoxId == row.BoxId)?.State;
        if (state is null)   // chỉ định: thùng của pallet nhưng không nằm trong danh sách
            throw new BusinessRuleException(_localizer["Si.PickBoxNotDesignated", boxNo]);
        if (state != "eligible")
            throw new BusinessRuleException(_localizer["Si.PickBoxNotYet", boxNo]);

        var result = await _repo.PickBoxAsync(
            taskId, task.LineId, row.BoxId, row.BoxNo.Trim(),
            designated: task.PickMode == ModeDesignated, _currentUser.FullName);

        return result switch
        {
            PickScanResult.AlreadyPicked =>
                throw new BusinessRuleException(_localizer["Si.PickBoxAlreadyPicked", boxNo]),
            PickScanResult.Taken => throw new ConflictException(_localizer["Si.BoxTaken", boxNo]),
            _ => await BuildPickDetailAsync(await GetTaskOrThrowAsync(taskId)),
        };
    }

    /// <summary>Gỡ thùng quét nhầm. Được cả khi dòng kế hoạch đã tự đóng (mở lại pending).</summary>
    public async Task<PickTaskDetailResponse> UnpickBoxAsync(long taskId, string boxNo)
    {
        var task = await GetTaskOrThrowAsync(taskId);
        await GetEditableLineAsync(task.LineId);
        if (task.PickMode == ModePallet)
            throw new BusinessRuleException(_localizer["Si.PickWrongMode"]);

        var code = boxNo.Trim();
        var row = FindBox(await _repo.GetPickBoxesAsync(taskId), code);
        if (row is null || !row.IsPicked
            || !await _repo.UnpickBoxAsync(taskId, row.BoxId, task.PickMode == ModeDesignated))
            throw new BusinessRuleException(_localizer["Si.PickBoxNotPicked", code]);

        return await BuildPickDetailAsync(await GetTaskOrThrowAsync(taskId));
    }

    // ═══════════════════════════════════════════════════════════════
    //  Vanning (PDA)
    // ═══════════════════════════════════════════════════════════════

    private const string VanningMapType = "vanning";

    /*  Lưu pallet tại vị trí vanning — bước cuối của mọi dòng kế hoạch.
        Chặn theo thứ tự: chưa picked -> đã ở khu vanning -> vị trí không tồn tại
        -> không thuộc khu vanning -> lệch vị trí chỉ định -> pallet không tồn tại
        -> (nguyên pallet) sai pallet | (theo thùng) thiếu thùng đã quét trên pallet
        -> (theo thùng) pallet gốc còn thùng giữ lại, chưa tách
        Không lưu cột riêng: dời wms.pallets.locator_id; trạng thái đọc lại qua TaskSql. */
    public async Task<PickTaskDetailResponse> StageVanningAsync(long taskId, StageVanningRequest request)
    {
        var task = await GetTaskOrThrowAsync(taskId);
        await GetEditableLineAsync(task.LineId);

        if (task.ShipmentStatus != "picked")
            throw new BusinessRuleException(_localizer["Si.StageNotPicked"]);
        if (task.StagedLocatorCode is not null)
            throw new BusinessRuleException(_localizer["Si.StageAlready", task.StagedLocatorCode]);

        var locatorCode = request.LocatorCode.Trim();
        var locator = await _repo.GetLocatorByCodeAsync(locatorCode)
            ?? throw new BusinessRuleException(_localizer["Si.StageLocatorNotFound", locatorCode]);
        if (!string.Equals(locator.MapType, VanningMapType, StringComparison.OrdinalIgnoreCase))
            throw new BusinessRuleException(_localizer["Si.StageNotVanning", locatorCode]);
        if (task.ToLocatorId is { } target && locator.Id != target)
            throw new BusinessRuleException(_localizer["Si.StageLocatorMismatch", task.ToLocatorCode ?? ""]);

        var palletCode = request.PalletCode.Trim();
        var palletId = await _repo.GetPalletIdByCodeAsync(palletCode)
            ?? throw new BusinessRuleException(_localizer["Si.StagePalletNotFound", palletCode]);

        if (task.PickMode == ModePallet)
        {
            if (palletId != task.PalletId)
                throw new BusinessRuleException(_localizer["Si.PickPalletMismatch", task.PalletCode.Trim()]);
        }
        else
        {
            var off = await _repo.CountPickedBoxesOffPalletAsync(taskId, palletId);
            if (off > 0)
                throw new BusinessRuleException(_localizer["Si.StagePalletMissingBoxes", palletCode, off]);

            // Pallet gốc còn thùng không thuộc phần đã lấy -> chưa tách, không được đem cả pallet đi
            if (palletId == task.PalletId
                && await _repo.CountForeignBoxesOnPalletAsync(taskId, palletId) > 0)
                throw new BusinessRuleException(_localizer["Si.StageNeedSplit", palletCode]);
        }

        if (!await _repo.MovePalletToLocatorAsync(palletId, locator.Id, taskId, _currentUser.FullName))
            throw new BusinessRuleException(_localizer["Si.StagePalletNotFound", palletCode]);

        return await BuildPickDetailAsync(await GetTaskOrThrowAsync(taskId));
    }

    private async Task<SiTask> GetTaskOrThrowAsync(long taskId)
        => await _repo.GetTaskAsync(taskId)
           ?? throw new NotFoundException(_localizer["Si.TaskNotFound", taskId]);

    /// <summary>Dòng kế hoạch còn lấy được: tồn tại, SI chưa đóng, còn pending.</summary>
    private async Task<SiTask> GetPickableTaskAsync(long taskId)
    {
        var task = await GetTaskOrThrowAsync(taskId);
        await GetEditableLineAsync(task.LineId);
        if (task.ShipmentStatus != "pending")
            throw new BusinessRuleException(_localizer["Si.TaskNotPending"]);
        return task;
    }

    private async Task<PickTaskDetailResponse> BuildPickDetailAsync(SiTask task)
    {
        var rows = task.PickMode == ModePallet
            ? new List<PickBoxRow>()
            : await _repo.GetPickBoxesAsync(task.Id);
        var perBox = task.BoxPlanned > 0 ? task.QtyPlanned / task.BoxPlanned : 0;
        return new PickTaskDetailResponse(SiTaskResponse.From(task), perBox, BuildPickBoxes(task, rows));
    }

    private static PickBoxRow? FindBox(IEnumerable<PickBoxRow> rows, string boxNo)
        => rows.FirstOrDefault(r => string.Equals(r.BoxNo.Trim(), boxNo, StringComparison.OrdinalIgnoreCase));

    /*  Trạng thái thùng cho màn PDA (rows đã sắp NSX cũ → mới):
          - nguyên pallet : không có danh sách thùng
          - chỉ định      : chỉ thùng của dòng kế hoạch — picked / eligible
          - fifo          : bỏ thùng người khác giữ. Còn cần K thùng -> K thùng rảnh cũ nhất
                            được lấy, và mọi thùng CÙNG NGÀY SX với thùng thứ K cũng được
                            lấy ("quét bất kỳ thùng NSX này"). Còn lại locked.            */
    private static List<PickBoxResponse> BuildPickBoxes(SiTask task, IReadOnlyList<PickBoxRow> rows)
    {
        static PickBoxResponse To(PickBoxRow r, string state)
            => new(r.BoxId, r.BoxNo.Trim(), r.ProductionDate, r.Qty, state);

        if (task.PickMode == ModePallet) return new();

        if (task.PickMode == ModeDesignated)
            return rows.Where(r => r.IsMine)
                       .Select(r => To(r, r.IsPicked ? "picked" : "eligible"))
                       .ToList();

        var visible = rows.Where(r => !r.HeldByOther).ToList();
        var free = visible.Where(r => !r.IsPicked).ToList();
        var need = Math.Min(task.BoxPlanned - visible.Count(r => r.IsPicked), free.Count);
        var cutoff = need > 0 ? free[need - 1].ProductionDate?.Date : null;

        var result = new List<PickBoxResponse>(visible.Count);
        var freeIndex = 0;
        foreach (var r in visible)
        {
            if (r.IsPicked) { result.Add(To(r, "picked")); continue; }

            var eligible = need > 0
                && (freeIndex < need
                    || (cutoff is not null && r.ProductionDate?.Date <= cutoff));
            result.Add(To(r, eligible ? "eligible" : "locked"));
            freeIndex++;
        }
        return result;
    }

    // ═══════════════════════════════════════════════════════════════
    //  helpers
    // ═══════════════════════════════════════════════════════════════

    private void EnsureEditable(SiHeader h)
    {
        if (ClosedStatuses.Contains(h.DocStatus))
            throw new BusinessRuleException(_localizer["Si.Closed", h.DocNo, h.DocStatus]);
    }

    private async Task<(SiLine Line, SiHeader Header)> GetEditableLineAsync(long lineId)
    {
        var line = await _repo.GetLineAsync(lineId)
            ?? throw new NotFoundException(_localizer["Si.LineNotFound", lineId]);
        var header = await _repo.GetHeaderAsync(line.SiId)
            ?? throw new NotFoundException(_localizer["Si.NotFound", line.SiId]);
        EnsureEditable(header);
        return (line, header);
    }

    private static void ApplyHeader(SiHeader h, SiHeaderRequest r)
    {
        h.Category = Clean(r.Category);
        h.ShipMode = Clean(r.ShipMode)?.ToUpperInvariant();
        h.EtdDate = r.EtdDate.Date;
        h.EtaDate = r.EtaDate?.Date;
        h.VanningDate = r.VanningDate?.Date;
        h.CutOffAt = r.CutOffAt;
        h.PortOfLoading = Clean(r.PortOfLoading);
        h.PortOfDischarge = Clean(r.PortOfDischarge);
        h.CountryCode = Clean(r.CountryCode);
        h.ForwarderCode = Clean(r.ForwarderCode);
        h.CarrierCode = Clean(r.CarrierCode);
        h.ConsigneeCode = Clean(r.ConsigneeCode);
        h.PackingType = Clean(r.PackingType);
        h.IsWhiteFilm = r.IsWhiteFilm;
        h.IsCaseMark = r.IsCaseMark;
        h.IsSerialRequired = r.IsSerialRequired;
        h.PicName = Clean(r.PicName);
        h.ToAreaId = r.ToAreaId;
        h.Description = Clean(r.Description);
        h.HeaderNote = HeaderNoteJson.Write(r.HeaderNote);
    }

    /// <summary>Bỏ dòng rỗng, tự đánh số dòng chưa có số, chặn trùng số dòng.
    /// existingNos (khi sửa phiếu): Id -> line_no hiện tại, để dòng cũ không gửi số giữ nguyên số.</summary>
    private List<SiLine> BuildLines(IEnumerable<SiLineRequest> requests,
                                    IReadOnlyDictionary<long, int>? existingNos = null)
    {
        var lines = requests
            .Where(r => !string.IsNullOrWhiteSpace(r.Model))
            .Select(r =>
            {
                var l = ToLine(r);
                if (existingNos is not null && r.Id is > 0 && existingNos.TryGetValue(r.Id.Value, out var no))
                {
                    l.Id = r.Id.Value;
                    if (l.LineNo <= 0) l.LineNo = no;
                }
                return l;
            })
            .ToList();

        var next = lines.Select(l => l.LineNo)
                        .Concat(existingNos?.Values ?? Enumerable.Empty<int>())
                        .DefaultIfEmpty(0).Max();
        foreach (var l in lines.Where(l => l.LineNo <= 0))
            l.LineNo = ++next;

        var dup = lines.Where(l => l.LineNo > 0).GroupBy(l => l.LineNo).FirstOrDefault(g => g.Count() > 1);
        if (dup is not null)
            throw new BusinessRuleException(_localizer["Si.LineNoDuplicate", dup.Key]);

        return lines;
    }

    private static SiLine ToLine(SiLineRequest r) => new()
    {
        LineNo = r.LineNo,
        Model = r.Model.Trim(),
        CustomerMaterial = Clean(r.CustomerMaterial),
        PoNo = Clean(r.PoNo),
        PackingListNo = Clean(r.PackingListNo),
        PackingItemNo = Clean(r.PackingItemNo),
        InvoiceNo = Clean(r.InvoiceNo),
        SoNo = Clean(r.SoNo),
        SoItemNo = Clean(r.SoItemNo),
        QtyRequired = r.QtyRequired,
        Uom = Clean(r.Uom),
        PackagePlt = r.PackagePlt,
        PackageCtn = r.PackageCtn,
    };

    private static string? Clean(string? v) => string.IsNullOrWhiteSpace(v) ? null : v.Trim();
}