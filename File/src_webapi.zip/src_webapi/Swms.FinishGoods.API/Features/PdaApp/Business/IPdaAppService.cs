using Swms.FinishGoods.Api.Features.PdaApp.Api;

namespace Swms.FinishGoods.Api.Features.PdaApp.Business;

public interface IPdaAppService
{
    /// <summary>Lịch sử phiên bản (mới nhất trước) để hiển thị bảng + bản hiện hành.</summary>
    Task<List<PdaAppVersionResponse>> GetVersionsAsync();

    /// <summary>Công bố APK mới: đọc metadata từ file, lưu file, ghi DB, trả bản vừa công bố.</summary>
    Task<PdaAppVersionResponse> PublishAsync(PublishPdaAppRequest request);

    /// <summary>File APK của bản đang phát hành: (stream, tên file, version).</summary>
    Task<(Stream Content, string FileName, string Version)> DownloadCurrentAsync();
}
