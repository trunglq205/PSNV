import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Pill trạng thái — nền tint nhạt, chữ đậm cùng tông.
class StatusPill extends StatelessWidget {
  final String label;
  final Color background;
  final Color foreground;
  final IconData? icon;

  const StatusPill({
    super.key,
    required this.label,
    required this.background,
    required this.foreground,
    this.icon,
  });

  factory StatusPill.success(
    BuildContext context, {
    Key? key,
    required String label,
    IconData? icon,
  }) {
    final swms = context.swms;
    return StatusPill(
      key: key,
      label: label,
      background: swms.successBg,
      foreground: swms.success,
      icon: icon,
    );
  }

  factory StatusPill.warning(
    BuildContext context, {
    Key? key,
    required String label,
    IconData? icon,
  }) {
    final swms = context.swms;
    return StatusPill(
      key: key,
      label: label,
      background: swms.warningBg,
      foreground: swms.warning,
      icon: icon,
    );
  }

  factory StatusPill.danger(
    BuildContext context, {
    Key? key,
    required String label,
    IconData? icon,
  }) {
    final swms = context.swms;
    return StatusPill(
      key: key,
      label: label,
      background: swms.dangerBg,
      foreground: swms.danger,
      icon: icon,
    );
  }

  factory StatusPill.info(
    BuildContext context, {
    Key? key,
    required String label,
    IconData? icon,
  }) {
    return StatusPill(
      key: key,
      label: label,
      background: context.swms.primaryTint,
      foreground: AppColors.primaryDark,
      icon: icon,
    );
  }

  factory StatusPill.neutral(
    BuildContext context, {
    Key? key,
    required String label,
    IconData? icon,
  }) {
    final swms = context.swms;
    return StatusPill(
      key: key,
      label: label,
      background: swms.border,
      foreground: swms.text2,
      icon: icon,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
      decoration: BoxDecoration(
        color: background,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 13, color: foreground),
            const SizedBox(width: 4),
          ],
          Text(
            label,
            style: AppTextStyles.caption.copyWith(
              color: foreground,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
