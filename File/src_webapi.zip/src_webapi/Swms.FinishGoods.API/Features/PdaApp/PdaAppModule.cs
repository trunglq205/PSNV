using Swms.FinishGoods.Api.Features.PdaApp.Business;
using Swms.FinishGoods.Api.Features.PdaApp.DataAccess;

namespace Swms.FinishGoods.Api.Features.PdaApp;

public static class PdaAppModule
{
    public static IServiceCollection AddPdaAppFeature(this IServiceCollection services)
    {
        services.AddScoped<IPdaAppService, PdaAppService>();
        services.AddScoped<IPdaAppRepository, PdaAppRepository>();

        // Seam đọc metadata APK + lưu file. Thay implementation nếu dùng aapt/blob/share khác.
        services.AddScoped<IApkInspector, ApkInspector>();
        services.AddScoped<IApkStorage, LocalApkStorage>();
        return services;
    }
}

// Program.cs:
//   builder.Services.AddPdaAppFeature();
