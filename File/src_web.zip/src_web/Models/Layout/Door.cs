﻿using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Models.Layout
{
    public abstract class Door : Widget
    {
        public Door() { }

        protected Door(KonvaObject konvaObject) : base(konvaObject)
        {
            Data = konvaObject.Attrs.Data ?? "";
        }

        public string Data { get; set; }

        protected override KonvaClassType ClassName => KonvaClassType.Group;

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.Data = Data;
            return attrs;
        }
    }

    public class SingleDoor : Door
    {
        public SingleDoor() { }

        public SingleDoor(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type => WidgetType.SingleDoor;

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.Data = "M 20 0 Q 20 20 0 20 L 0 0";
            attrs.Stroke = "#000000";
            attrs.StrokeWidth = 3;
            return attrs;
        }

        public override KonvaObject ToKonvaObject()
        {
            try
            {
                var attrs = ToKonvaAttr();
                return new KonvaObject()
                {
                    ClassName = ClassName.GetString(),
                    Attrs = ToKonvaAttr(),
                    Children = new List<KonvaObject>()
                {
                    new KonvaObject()
                    {
                        ClassName = KonvaClassType.Rect.GetString(),
                        Attrs = new KonvaAttr()
                        {
                            X = -2.5,
                            Width = 25,
                            Height = 22.5,
                            Fill = "#FFFFFF",
                            Name = WidgetType.Wall.GetString(),
                        },
                    },
                    new KonvaObject()
                    {
                        ClassName = KonvaClassType.Path.GetString(),
                        Attrs = new KonvaAttr()
                        {
                            Data = attrs.Data,
                            Stroke = attrs.Stroke,
                            StrokeWidth = attrs.StrokeWidth,
                            Name = WidgetType.Wall.GetString(),
                        },
                    },
                }
                };

            }
            catch (Exception ex)
            {

                throw ex;
            }
           
        }
    }

    public class DoubleDoor : Door
    {
        public DoubleDoor() { }

        public DoubleDoor(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type => WidgetType.DoubleDoor;

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.Data = "M 20 0 Q 20 20 0 20 L 0 0 M 20 0 Q 20 20 40 20 L 40 0";
            attrs.Stroke = "#000000";
            attrs.StrokeWidth = 3;
            return attrs;
        }

        public override KonvaObject ToKonvaObject()
        {
            var attrs = ToKonvaAttr();
            return new KonvaObject()
            {
                ClassName = ClassName.GetString(),
                Attrs = attrs,
                Children = new List<KonvaObject>()
                {
                    new KonvaObject()
                    {
                        ClassName = KonvaClassType.Rect.GetString(),
                        Attrs = new KonvaAttr()
                        {
                            X = -2.5,
                            Width = 45,
                            Height = 25,
                            Fill = "#FFFFFF",
                            Name = WidgetType.Wall.GetString(),
                        },
                    },
                    new KonvaObject()
                    {
                        ClassName = KonvaClassType.Path.GetString(),
                        Attrs = new KonvaAttr()
                        {
                            Data = attrs.Data,
                            Stroke = attrs.Stroke,
                            StrokeWidth = attrs.StrokeWidth,
                            Name = WidgetType.Wall.GetString(),

                        },
                    },
                }
            };
        }
    }

    public class NoDoor : Door
    {
        public NoDoor() { }

        public NoDoor(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type => WidgetType.NoDoor;


        public override KonvaObject ToKonvaObject()
        {
            return new KonvaObject()
            {
                ClassName = ClassName.GetString(),
                Attrs = ToKonvaAttr(),
                Children = new List<KonvaObject>()
                {
                    new KonvaObject()
                    {
                        ClassName = KonvaClassType.Rect.GetString(),
                        Attrs = new KonvaAttr()
                        {
                            Width = 20,
                            Height = 20,
                            Fill = "white",
                            Name = WidgetType.Wall.GetString(),
                        },
                    },
                }
            };
        }
    }
}
