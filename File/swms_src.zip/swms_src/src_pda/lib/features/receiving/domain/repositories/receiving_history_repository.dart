import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_history_entry.dart';

/// Hợp đồng lưu bản nháp quét — domain layer, không biết nguồn dữ liệu.
abstract interface class ReceivingHistoryRepository {
  /// Đọc bản nháp. Trả null nếu chưa có, JSON hỏng, hoặc đã quá hạn 1 ngày
  /// (trường hợp quá hạn sẽ tự xóa luôn dưới storage).
  Future<ReceivingHistoryEntry?> read();

  /// Ghi đè bản nháp hiện tại.
  Future<void> save(ReceivingHistoryEntry entry);

  /// Xóa bản nháp (gọi sau khi tạo lot thành công hoặc user chủ động xóa).
  Future<void> clear();
}