﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace SWMS_WebTool.Models.PMD
{
    public class PurgingRunnerNGPMD
    {
        public Int64? ID { get; set; }
        public string? Plant {get; set;}
        public string? Material { get; set; }
        public string? IssueSloc { get; set; }
        public string? ReceiveSloc { get; set; }
        public double Quantity { get; set; }
        public string? Unit { get; set; }
        public string? Model { get; set; }
        public string? Type { get; set; }
        public string? Recycle { get; set; }
        public string? Machine { get; set; }
        public string? UserCreate { get; set; }
        public DateTime? TimeCreate { get; set; }
        public string? UserUpdate { get; set; }
        public DateTime? TimeUpdate { get; set; }
        public string? Status { get; set; }
        public DateTime? TimeTranfer { get; set; }
    }
}
