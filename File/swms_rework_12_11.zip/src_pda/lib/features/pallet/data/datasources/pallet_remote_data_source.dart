import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/pallet/data/models/locator_models.dart';
import 'package:swms_finish_goods/features/pallet/data/models/locator_pallets_model.dart';
import 'package:swms_finish_goods/features/pallet/data/models/pallet_model.dart';
import 'package:swms_finish_goods/features/pallet/data/models/split_models.dart';
import 'package:swms_finish_goods/features/pallet/data/models/storage_suggestion_models.dart';

part 'pallet_remote_data_source.g.dart';

/// Toàn bộ API của 1 pallet. Mọi màn quét theo lot_no đều dùng chung
/// `by-lot-no/{lotNo}` với `include` khác nhau — không còn endpoint
/// `/location`, `/storing` (GET) riêng.
@RestApi()
abstract class PalletRemoteDataSource {
  factory PalletRemoteDataSource(Dio dio, {String baseUrl}) =
      _PalletRemoteDataSource;

  /// Chi tiết pallet: thông tin + model/qty + vị trí + allowedActions,
  /// và tuỳ `include`: thùng · lịch sử.
  ///
  /// `include` nhận: `boxes` | `history` | `all`, phân cách bằng `,`.
  /// Không truyền thì server trả `boxes` = `history` = null (nhẹ nhất).
  ///
  /// Gợi ý vị trí đã TÁCH sang [fetchStorageSuggestion] vì cần thêm tham số
  /// chiều cao pallet — không truyền `include=suggestion` nữa.
  @GET('/api/pallets/by-lot-no/{lotNo}')
  Future<PalletModel> fetchPallet(
    @Path('lotNo') String lotNo, {
    @Query('include') String? include,
  });

  /// Gợi ý vị trí lưu kho (FR-STR-02) — chỉ màn Lưu kho gọi.
  ///
  /// [palletHeightCm] tuỳ chọn: model đã khai `suggest_rack_row` trong master
  /// thì server không dùng tới; chưa khai thì đây là căn cứ chọn tầng
  /// (≤70 giá lửng · ≤135 tầng 2-3 · ≤155 tầng 1 · còn lại tầng 4).
  /// Không gửi thì vẫn có gợi ý nhưng kèm cảnh báo trong `warnings`.
  @GET('/api/pallets/by-lot-no/{lotNo}/storage-suggestion')
  Future<StorageSuggestionModel> fetchStorageSuggestion(
    @Path('lotNo') String lotNo, {
    @Query('palletHeightCm') int? palletHeightCm,
  });

  /// Tạo lot từ dữ liệu Foss theo mã quét, trả về đúng shape của GET by-lot-no.
  /// Idempotent: lot đã tồn tại thì trả về luôn, không gọi Foss.
  /// PDA: gọi GET trước, gặp 404 thì gọi endpoint này.
  @POST('/api/pallets/by-lot-no/{lotNo}/from-foss')
  Future<PalletModel> createFromFoss(
    @Path('lotNo') String lotNo, {
    @Query('include') String? include,
  });

  /// Tách pallet: chuyển một số thùng sang lot đích (có sẵn hoặc tạo mới).
  @POST('/api/pallets/split')
  Future<SplitPalletResponseModel> split(@Body() SplitPalletRequestModel body);

  /// Gán (chưa có vị trí) hoặc chuyển (đã có) sang vị trí mới.
  @PUT('/api/pallets/{id}/locator')
  Future<LocatorChangeResponseModel> assignLocator(
    @Path('id') int id,
    @Body() LocatorRequestModel body,
  );

  /// Lưu kho: đặt pallet vào vị trí đích (Movement 131 → to_location).
  @PUT('/api/pallets/{id}/storing')
  Future<LocatorChangeResponseModel> store(
    @Path('id') int id,
    @Body() LocatorRequestModel body,
  );

  /// Out kho: gỡ pallet khỏi vị trí hiện tại (không có vị trí đích).
  /// Quyền `temploc.release`; server chặn khi pallet đang trong vòng kiểm OQC,
  /// và khi là hàng RW/RB chưa được quản lý SCS duyệt cho giao FA.
  @DELETE('/api/pallets/{id}/locator')
  Future<LocatorChangeResponseModel> releaseLocator(@Path('id') int id);

  /// Danh sách pallet_id đang nằm tại vị trí. 404 nếu mã vị trí không tồn tại.
  @GET('/api/temploc/locators/{locatorCode}/pallets')
  Future<LocatorPalletsModel> fetchLocatorPallets(
    @Path('locatorCode') String locatorCode,
  );

  /// Đồng bộ trạng thái OQC
  @POST('/api/pallets/by-lot-no/{lotNo}/oqc-sync')
  Future<PalletModel> syncOqc(@Path('lotNo') String lotNo);
}
