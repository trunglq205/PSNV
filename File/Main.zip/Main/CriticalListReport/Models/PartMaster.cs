﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("PartMaster")]
    public class PartMaster
    {
        public int ID { get; set; }
        public string? PartNo { get; set; }
        public string? Vendor { get; set; }
        public string? MakerName { get; set; }
    }
}
