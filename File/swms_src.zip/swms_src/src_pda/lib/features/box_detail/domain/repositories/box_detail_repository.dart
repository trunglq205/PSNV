import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_event.dart';

abstract class BoxDetailRepository {
  /// Chi tiết box theo id (định danh duy nhất).
  Future<BoxDetail> getDetail(int id);

  /// Chi tiết box khi quét mã — cần palletId vì box_no không duy nhất.
  Future<BoxDetail> getDetailByBoxNo(String boxNo, {String? palletId});

  /// Cập nhật PO. null = xoá giá trị.
  Future<BoxDetail> updatePo({
    required int id,
    required String? customerPo,
    required String? psnvPo,
  });

  /// Lịch sử thùng. [ownOnly] = true thì bỏ event kế thừa từ pallet chứa nó.
  Future<BoxHistory> getHistory(int id, {bool ownOnly = false});
}