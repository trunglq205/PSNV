using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.App.Toast;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.App;

public partial class InventoryHdSoftCompareDialog : IDisposable
{
    [Parameter] public bool Open { get; set; }
    [Parameter] public EventCallback OnClose { get; set; }
    /// <summary>Bấm 1 pallet SWMS -> trang mở dialog chi tiết lot.</summary>
    [Parameter] public EventCallback<AppInventoryItem> OnOpenLot { get; set; }

    [Inject] private IHdSoftCompareBusiness Business { get; set; } = default!;
    [Inject] private ToastService Toast { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;

    private const string Warehouse = "PSNV";  // kho phía HD soft — cố định như màn đối chiếu SI
    private const int PageChunk = 200;        // số dòng vẽ mỗi lần
    private const int MaxPalletChips = 3;     // số mã pallet hiện trong 1 ô, còn lại "+n"

    // Hàng "chỉ có ở SWMS" chưa có vị trí / ở khu FA, Customer là đương nhiên (chưa vào kho / đã giao)
    private static readonly HashSet<string> OutsideAreas = new(StringComparer.OrdinalIgnoreCase) { "fa", "customer" };

    // "issues" = mọi dòng chưa khớp — tab mặc định
    private static readonly string[] Tabs =
    {
        "issues", StockCmp.QtyDiff, StockCmp.OnlyHdSoft, StockCmp.OnlySwms, StockCmp.Match, "all",
    };

    private bool _wasOpen;
    private bool _loading;
    private bool _excludeOutside = true;
    private StockCompareProgress? _progress;
    private AppStockCompareResult? _data;
    private string _tab = "issues";
    private string _q = "";
    private int _limit = PageChunk;
    private CancellationTokenSource? _cts;

    // Mỗi lần mở là so lại; đóng thì huỷ lượt đang tải
    protected override void OnParametersSet()
    {
        if (Open && !_wasOpen)
        {
            _wasOpen = true;
            _ = RunAsync();
        }
        else if (!Open && _wasOpen)
        {
            _wasOpen = false;
            _cts?.Cancel();
        }
    }

    private async Task RunAsync()
    {
        _cts?.Cancel();
        _cts = new CancellationTokenSource();
        var ct = _cts.Token;

        _loading = true;
        _progress = null;
        StateHasChanged();

        var progress = new Progress<StockCompareProgress>(p =>
        {
            _progress = p;
            _ = InvokeAsync(StateHasChanged);
        });

        var r = await Business.CompareWithHdSoftAsync(Warehouse, progress, ct);
        if (ct.IsCancellationRequested) return;      // đã đóng / bấm so lại

        _loading = false;
        if (r.IsSuccess && r.Value is not null)
        {
            _data = r.Value;
            _actions = HdSoftRowActions.Build(_data);
            _done.Clear();
            _expanded.Clear();
            _bulkOpen = false;
            _boxesFor = null;
            _limit = PageChunk;
            if (_tab == "issues" && IssueCount == 0 && Visible.Any()) _tab = "all";
        }
        else
        {
            Toast.Error(r.ErrorMessage ?? L["Inventory.Cmp.LoadFailed"]);
        }
        await InvokeAsync(StateHasChanged);
    }

    private Task Close() => _confirm is not null || _bulkOpen || _boxesFor is not null
        ? Task.CompletedTask
        : OnClose.InvokeAsync();

    // ── Xử lý từng dòng ─────────────────────────────────────
    // Mỗi nút = 1 hành động trên 1 pallet, có bước xác nhận. Xong thì đánh dấu tại chỗ,
    // KHÔNG so lại tự động (so lại tải lại toàn bộ tồn) — người dùng bấm "So lại" khi muốn.

    private record ActState(bool Ok, string Pill, string LabelKey, string? Message);

    private Dictionary<AppStockCompareRow, List<HdRowAction>> _actions = new();
    private readonly Dictionary<string, ActState> _done = new();
    private HdRowAction? _confirm;
    private string? _busyKey;

    // Quy cách đóng thùng (pcs/thùng) cho create / qty
    private int? _packing;
    private string _packSource = "manual";   // default (tạo) | gcd (sửa SL) | manual

    private static bool NeedsPacking(HdRowAction a) => a.Kind is HdActKind.Create or HdActKind.Qty;

    private string? PackingError => _confirm is not { } c || !NeedsPacking(c) ? null
        : _packing is not > 0 ? L["Inventory.Act.PackingRequired"].Value
        : c.Qty % _packing.Value != 0 ? L["Inventory.Act.PackingNotDivisible", c.Qty.ToString("N0"), _packing.Value.ToString("N0")].Value
        : null;

    private bool CanConfirm => _confirm is { } c && _busyKey is null
        && (!NeedsPacking(c) || PackingError is null);

    private void OnPackingInput(ChangeEventArgs e)
    {
        _packing = int.TryParse(e.Value?.ToString(), out var v) && v > 0 ? v : null;
        _packSource = "manual";
    }

    // Dòng đang mở hết nút (mặc định chỉ hiện MaxPalletChips nút / dòng)
    private readonly HashSet<AppStockCompareRow> _expanded = new();

    private void ToggleExpand(AppStockCompareRow row)
    {
        if (!_expanded.Remove(row)) _expanded.Add(row);
    }

    /// <summary>Mã 12 số dài -> hiện 6 số cuối trên nút, mã đầy đủ ở tooltip.</summary>
    private static string ShortCode(string code) => code.Length > 8 ? "…" + code[^6..] : code;

    // ── Xoá thùng: chọn tay trong dialog riêng, không qua hộp xác nhận / chạy hàng loạt ──
    private HdRowAction? _boxesFor;

    private void OnAct(HdRowAction a)
    {
        if (_busyKey is not null) return;
        if (a.Kind == HdActKind.Boxes) _boxesFor = a;
        else AskConfirm(a);
    }

    private void OnBoxesDone(string message)
    {
        if (_boxesFor is { } a)
            _done[a.Key] = new(true, "success", "Inventory.Act.State." + HdActKind.Boxes, message);
        Toast.Success(message);
        _boxesFor = null;
    }

    private void AskConfirm(HdRowAction a)
    {
        if (_busyKey is not null) return;
        _confirm = a;
        _packing = null;
        _packSource = "manual";
        if (!NeedsPacking(a)) return;

        _packing = DefaultPacking(a);
        _packSource = a.Kind == HdActKind.Create ? "default" : "gcd";
    }

    private void CancelConfirm()
    {
        if (_busyKey is not null) return;
        _confirm = null;
    }

    private async Task ConfirmAsync()
    {
        if (!CanConfirm || _confirm is not { } a) return;
        _busyKey = a.Key;
        StateHasChanged();

        var r = await Business.ApplyHdRowActionAsync(a, NeedsPacking(a) ? _packing : null);
        Record(a, r, toast: true);

        _busyKey = null;
        _confirm = null;
        await InvokeAsync(StateHasChanged);
    }

    /// <summary>Ghi kết quả 1 hành động vào ô của dòng. Sync đánh dấu luôn dòng kia của cùng pallet.</summary>
    private void Record(HdRowAction a, Result<string?> r, bool toast)
    {
        ActState st;
        if (!r.IsSuccess)
        {
            st = new(false, "danger", "Inventory.Act.State.Failed", r.ErrorMessage);
            if (toast) Toast.Error(r.ErrorMessage ?? L["Inventory.Act.Failed", a.Pallet]);
        }
        else if (!string.IsNullOrWhiteSpace(r.Value))
        {
            st = new(true, "warning", "Inventory.Act.State." + a.Kind, r.Value);
            if (toast) Toast.Warning(L["Inventory.Act.DoneWithWarning", a.Pallet, r.Value]);
        }
        else
        {
            st = new(true, "success", "Inventory.Act.State." + a.Kind, null);
            if (toast) Toast.Success(L["Inventory.Act.Done." + a.Kind, a.Pallet]);
        }

        _done[a.Key] = st;
        if (HdActKind.IsPerPallet(a.Kind))
            foreach (var twin in SamePallet(a)) _done[twin.Key] = st;
    }

    /// <summary>Pallet lệch vị trí hiện ở 2 dòng (bên SWMS + bên HD soft) với cùng mã — chỉ cần đồng bộ 1 lần.</summary>
    private IEnumerable<HdRowAction> SamePallet(HdRowAction a)
        => _actions.Values.SelectMany(x => x)
            .Where(x => x.Kind == a.Kind && x.Key != a.Key
                        && string.Equals(x.Pallet, a.Pallet, StringComparison.OrdinalIgnoreCase));

    // ── Chạy tất cả ─────────────────────────────────────────
    // Chạy LẦN LƯỢT mọi hành động còn chờ của danh sách ĐANG LỌC (tab + tìm kiếm), không chỉ phần đang vẽ.
    // Không có bước nhập quy cách: dùng DefaultPacking (tạo = SL, sửa SL = UCLN trước / sau).

    private static readonly string[] BulkKinds = { HdActKind.Sync, HdActKind.TopUp, HdActKind.Qty, HdActKind.Create, HdActKind.Delete };

    private bool _bulkOpen;
    private bool _bulkRunning;
    private readonly HashSet<string> _bulkKinds = new() { HdActKind.Sync, HdActKind.TopUp, HdActKind.Qty, HdActKind.Create };  // xoá mặc định TẮT
    private int _bulkDone, _bulkTotal, _bulkFailed;
    private CancellationTokenSource? _bulkCts;

    /// <summary>Hành động còn chờ của các dòng đang lọc. Sync / bổ sung Foss trùng mã chỉ lấy 1.</summary>
    private List<HdRowAction> PendingActions()
    {
        var seenPallet = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        return Filtered()
            .Where(r => _actions.ContainsKey(r))
            .SelectMany(r => _actions[r])
            .Where(a => a.Enabled && !_done.ContainsKey(a.Key) && BulkKinds.Contains(a.Kind!))   // "boxes" phải chọn tay
            .Where(a => !HdActKind.IsPerPallet(a.Kind) || seenPallet.Add(a.Kind + "|" + a.Pallet))
            .ToList();
    }

    private int PendingCount(string kind) => PendingActions().Count(a => a.Kind == kind);

    private int BulkSelectedCount => PendingActions().Count(a => _bulkKinds.Contains(a.Kind!));

    private string BulkWidth => _bulkTotal == 0 ? "0%" : $"{Math.Round(100.0 * _bulkDone / _bulkTotal):0}%";

    private void OpenBulk() { if (_busyKey is null) _bulkOpen = true; }
    private void CloseBulk() { if (!_bulkRunning) _bulkOpen = false; }

    private void ToggleBulkKind(string kind, ChangeEventArgs e)
    {
        if (e.Value is true) _bulkKinds.Add(kind); else _bulkKinds.Remove(kind);
    }

    private void StopBulk() => _bulkCts?.Cancel();

    private async Task RunBulkAsync()
    {
        if (_bulkRunning || _busyKey is not null) return;

        // Thứ tự: đồng bộ vị trí trước (giải quyết pallet chỉ lệch vị trí), rồi bổ sung từ Foss, sửa SL, tạo, xoá
        var queue = PendingActions()
            .Where(a => _bulkKinds.Contains(a.Kind!))
            .OrderBy(a => Array.IndexOf(BulkKinds, a.Kind))
            .ToList();
        if (queue.Count == 0) return;

        _bulkCts?.Dispose();
        _bulkCts = new CancellationTokenSource();
        var ct = _bulkCts.Token;

        _bulkRunning = true;
        _bulkDone = _bulkFailed = 0;
        _bulkTotal = queue.Count;
        StateHasChanged();

        foreach (var a in queue)
        {
            if (ct.IsCancellationRequested) break;
            if (_done.ContainsKey(a.Key)) { _bulkDone++; continue; }   // đã xong nhờ sync dòng kia

            _busyKey = a.Key;
            await InvokeAsync(StateHasChanged);

            int? packing = NeedsPacking(a) ? DefaultPacking(a) : null;

            var r = await Business.ApplyHdRowActionAsync(a, packing);
            Record(a, r, toast: false);
            if (!r.IsSuccess) _bulkFailed++;
            _bulkDone++;
        }

        _busyKey = null;
        _bulkRunning = false;
        _bulkOpen = false;

        var ok = _bulkDone - _bulkFailed;
        if (_bulkFailed == 0) Toast.Success(L["Inventory.Act.Bulk.Done", ok.ToString("N0")]);
        else Toast.Warning(L["Inventory.Act.Bulk.DoneWithFail", ok.ToString("N0"), _bulkFailed.ToString("N0")]);
        await InvokeAsync(StateHasChanged);
    }

    /// <summary>
    /// Quy cách mặc định, dùng chung cho hộp xác nhận và chạy hàng loạt:
    ///   tạo mới  -> = SL (1 thùng chứa đủ SL)
    ///   sửa SL   -> UCLN(SL trước, SL sau). Luôn chia hết SL mới nên không bao giờ kẹt,
    ///               và chia hết cả SL cũ nên số thùng trước / sau đều là số nguyên.
    ///               vd 36 -> 18: quy cách 18, 2 thùng -> 1 thùng.
    /// Người dùng vẫn sửa được trong hộp xác nhận.
    /// </summary>
    private static int DefaultPacking(HdRowAction a)
        => a.Kind == HdActKind.Create ? a.Qty : Gcd(a.OldQty, a.Qty);

    /// <summary>UCLN; Gcd(0, n) = n nên pallet SL cũ = 0 vẫn ra quy cách = SL mới.</summary>
    private static int Gcd(int a, int b)
    {
        a = Math.Abs(a); b = Math.Abs(b);
        while (b != 0) (a, b) = (b, a % b);
        return a;
    }

    private string ConfirmText(HdRowAction a) => a.Kind switch
    {
        HdActKind.Create => L["Inventory.Act.Confirm.Text.create", a.Pallet, a.Model, a.Qty.ToString("N0"), a.Locator ?? "—"],
        HdActKind.Delete => L["Inventory.Act.Confirm.Text.delete", a.Pallet, a.Model, a.OldQty.ToString("N0"), a.Lot?.LocatorCode ?? "—"],
        HdActKind.Qty => L["Inventory.Act.Confirm.Text.qty", a.Pallet, a.OldQty.ToString("N0"), a.Qty.ToString("N0")],
        HdActKind.TopUp => L["Inventory.Act.Confirm.Text.topup", a.Pallet, a.Model, a.OldQty.ToString("N0")],
        _ => L["Inventory.Act.Confirm.Text.sync", a.Pallet],
    };

    private string ProgressText => _progress switch
    {
        { Stage: "detail" } p => L["Inventory.Cmp.LoadingDetail", p.Done.ToString("N0"), p.Total.ToString("N0")],
        { } p => L["Inventory.Cmp.Loading", p.Done.ToString("N0"), p.Total.ToString("N0")],
        _ => L["Inventory.Cmp.Running"],
    };

    // ── Lọc trên client ─────────────────────────────────────
    private bool IsOutside(AppStockCompareRow r)
        => r.Result == StockCmp.OnlySwms
           && (r.LocKey.Length == 0 || r.SwmsPallets.All(p => OutsideAreas.Contains(p.AreaKey)));

    private IEnumerable<AppStockCompareRow> Visible => _data is null
        ? Enumerable.Empty<AppStockCompareRow>()
        : _data.Rows.Where(r => !(_excludeOutside && IsOutside(r)));

    private int IssueCount => Visible.Count(r => !r.IsMatch);

    private int TabCount(string key) => key switch
    {
        "all" => Visible.Count(),
        "issues" => IssueCount,
        _ => Visible.Count(r => r.Result == key),
    };

    private string TabLabel(string key) => key switch
    {
        "all" => L["Inventory.Cmp.Tab.All"],
        "issues" => L["Inventory.Cmp.Tab.Issues"],
        _ => L["Inventory.Cmp.Result." + key],
    };

    private IEnumerable<AppStockCompareRow> Filtered()
    {
        var q = _tab switch
        {
            "all" => Visible,
            "issues" => Visible.Where(r => !r.IsMatch),
            _ => Visible.Where(r => r.Result == _tab),
        };

        if (!string.IsNullOrWhiteSpace(_q))
        {
            var k = _q.Trim();
            q = q.Where(r => r.Locator.Contains(k, StringComparison.OrdinalIgnoreCase)
                          || r.Model.Contains(k, StringComparison.OrdinalIgnoreCase)
                          || r.SwmsPallets.Any(p => (p.StockyCode ?? p.LotNo).Contains(k, StringComparison.OrdinalIgnoreCase))
                          || r.HdPallets.Any(p => p.Contains(k, StringComparison.OrdinalIgnoreCase)));
        }
        return q;
    }

    private int FilteredCount => Filtered().Count();
    private IEnumerable<AppStockCompareRow> Shown => Filtered().Take(_limit);

    private void SetTab(string key) { _tab = key; _limit = PageChunk; }
    private void OnSearch(ChangeEventArgs e) { _q = e.Value?.ToString() ?? ""; _limit = PageChunk; }
    private void OnExcludeChanged(ChangeEventArgs e) { _excludeOutside = e.Value is true; _limit = PageChunk; }
    private void ShowMore() => _limit += PageChunk;

    private static string PalletCode(AppInventoryItem p) => (p.StockyCode ?? p.LotNo).Trim();

    private static string DiffText(AppStockCompareRow r) => !r.HasSwms || !r.HasHd ? "—"
        : r.Diff == 0 ? "0"
        : r.Diff > 0 ? "+" + r.Diff.ToString("N0")
        : r.Diff.ToString("N0");

    public void Dispose()
    {
        _cts?.Cancel();
        _cts?.Dispose();
        _bulkCts?.Cancel();
        _bulkCts?.Dispose();
    }
}