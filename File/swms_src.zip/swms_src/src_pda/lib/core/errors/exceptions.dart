/// Library gốc chứa cây exception nghiệp vụ. Các nhóm exception được tách ra
/// file `part` để dễ đọc nhưng vẫn thuộc cùng một library — điều kiện bắt buộc
/// để `sealed` hoạt động xuyên file.
///
/// Import file này là có toàn bộ cây exception; giữ nguyên đường dẫn cũ
/// (`core/errors/exceptions.dart`) nên không phải sửa import ở nơi khác.
library;

part 'infra_exception.dart';
part 'scan_exception.dart';
part 'lot_exception.dart';
part 'payload_exception.dart';
part 'locator_exceptions.dart';
part 'printer_exception.dart';
part 'vanning_exception.dart';
part 'container_exception.dart';
part 'stowage_exception.dart';
part 'stocky_exception.dart';
part 'part_card_exception.dart';
part 'return_exception.dart';

/// Gốc của cây exception nghiệp vụ. Mọi lỗi (Dio, Hive, ...) được map về đây
/// để tầng pages phân loại và hiển thị message i18n phù hợp.
///
/// [code] là khóa i18n (khớp key trong file dịch, ví dụ `error.network`),
/// [message] là chuỗi tiếng Việt mặc định dùng khi chưa kịp map i18n / khi log.
///
/// Cây kế thừa chia theo nhóm:
/// - [InfraException]  : lỗi hạ tầng (mạng, server, cache, auth...).
/// - [ScanException]   : lỗi nghiệp vụ quét thùng / model.
/// - [LotException]    : lỗi nghiệp vụ tạo lot.
/// - [VanningException]: lỗi nghiệp vụ quét gộp Pallet List / Pallet đôi.
sealed class AppException implements Exception {
  final String message;
  final String code;
  final int? statusCode;

  const AppException(this.message, {required this.code, this.statusCode});

  /// Tham số động chèn vào chuỗi i18n (mặc định rỗng).
  Map<String, String> get namedArgs => const {};

  @override
  String toString() => '$runtimeType($code: $message)';
}