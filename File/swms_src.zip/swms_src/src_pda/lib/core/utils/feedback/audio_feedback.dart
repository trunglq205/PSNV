// core/utils/feedback/audio_feedback.dart
import 'package:audioplayers/audioplayers.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/core/logger/app_logger.dart';
import 'package:swms_finish_goods/core/utils/app_local_storage.dart';
import 'package:swms_finish_goods/core/utils/constants.dart';
import 'package:swms_finish_goods/core/utils/feedback/app_feedback.dart';

class AudioFeedback implements AppFeedback {
  final _errorPlayer = AudioPlayer(playerId: 'fb_error');
  final _successPlayer = AudioPlayer(playerId: 'fb_success');

  late final Future<void> _ready = _init();

  AudioFeedback(this._ref);

  final Ref _ref;

  AppLocalStorage? get _storage => _ref.read(appLocalManagerProvider).value;

  bool get _soundOn =>
      _storage?.readBool(SettingsKeys.soundAlert) ?? true;

  static const _minGap = Duration(milliseconds: 400);
  DateTime? _lastAt;

  Future<void> _init() async {
    // USAGE_ALARM: tiếng không bị chìm khi media volume để thấp.
    // audioFocus.none: không cướp focus, không làm gián đoạn app khác.
    final context = AudioContext(
      android: const AudioContextAndroid(
        contentType: AndroidContentType.sonification,
        usageType: AndroidUsageType.alarm,
        audioFocus: AndroidAudioFocus.none,
      ),
    );

    for (final (player, path) in [
      (_errorPlayer, 'sounds/error.wav'),
      (_successPlayer, 'sounds/success.wav'),
    ]) {
      await player.setAudioContext(context);
      await player.setReleaseMode(ReleaseMode.stop);
      // Preload để lần phát đầu không bị trễ.
      await player.setSource(AssetSource(path));
    }
  }

  @override
  Future<void> error() async {
    if (!_shouldPlay()) return;
    await _run(() async {
      await _ready;
      await _errorPlayer.seek(Duration.zero);
      await _errorPlayer.resume();
      await HapticFeedback.heavyImpact();
    });
  }

  @override
  Future<void> success() async {
    if (!_shouldPlay()) return;
    await _run(() async {
      await _ready;
      await _successPlayer.seek(Duration.zero);
      await _successPlayer.resume();
      await HapticFeedback.lightImpact();
    });
  }

  bool _shouldPlay() {
    if (!_soundOn) return false;
    final now = DateTime.now();
    if (_lastAt != null && now.difference(_lastAt!) < _minGap) return false;
    _lastAt = now;
    return true;
  }

  Future<void> _run(Future<void> Function() action) async {
    try {
      await action();
    } catch (e, s) {
      logger.e('AudioFeedback failed', error: e, stackTrace: s);
    }
  }

  Future<void> dispose() async {
    await _errorPlayer.dispose();
    await _successPlayer.dispose();
  }
}