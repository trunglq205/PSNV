namespace Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;

// Cấu hình email của Hàng bất thường.
//
// Vì sao có bản DTO riêng ở đây thay vì dùng lại của màn Thiếu hàng: bộ
// IEmailConfigApi/IEmailConfigBusiness hiện nằm trong Features/Shortages — mã
// của người khác. Phụ thuộc vào đó nghĩa là họ đổi tên hay dời file là màn này
// gãy, mà hai bên lại do hai người làm. Hợp đồng thật sự là các endpoint
// /api/email-configs/*, nên ở đây gọi thẳng endpoint.
//
// Khi nào team quyết gộp thành một màn cấu hình email dùng chung thì bộ này
// biến mất cùng bộ kia — xem ghi chú trong NgSettingsDialog.

/// <summary>Một loại mail (master.email_events) kèm mẫu tiêu đề và nội dung.</summary>
public class NgEmailEventDto
{
    public string Code { get; set; } = "";
    public string Module { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public string SubjectTemplate { get; set; } = "";
    public string BodyTemplate { get; set; } = "";
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>Một dòng người nhận (master.email_config).</summary>
public class NgEmailConfigDto
{
    public long Id { get; set; }
    public string EventCode { get; set; } = "";
    public string? Department { get; set; }
    public string? SubCode { get; set; }
    public string? Category { get; set; }
    public string? Model { get; set; }
    public string? AreaCode { get; set; }
    public string RecipientType { get; set; } = "TO";
    public long? UserId { get; set; }

    /// <summary>Có thể chứa NHIỀU địa chỉ ngăn bởi dấu phẩy — đó là cách khai nhóm.</summary>
    public string Email { get; set; } = "";
    public string? DisplayName { get; set; }
    public bool IsActive { get; set; } = true;

    /// <summary>Bản sao để sửa trong form mà không đụng vào dòng đang hiện trên bảng.</summary>
    public NgEmailConfigDto Clone() => (NgEmailConfigDto)MemberwiseClone();
}

/// <summary>Thân request lưu người nhận. Khớp SaveEmailConfigRequest bên API.</summary>
public class SaveNgEmailConfigRequestDto
{
    public string EventCode { get; set; } = "";
    public string? Department { get; set; }
    public string? SubCode { get; set; }
    public string? Category { get; set; }
    public string? Model { get; set; }
    public string? AreaCode { get; set; }
    public string RecipientType { get; set; } = "TO";
    public long? UserId { get; set; }
    public string? Email { get; set; }
    public string? DisplayName { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>
/// Gợi ý cho ô Bộ phận / Danh mục. Khớp EmailScopeOptionsResponse bên API.
/// Là gợi ý chứ không phải danh sách đóng — gõ giá trị mới vẫn lưu được.
/// </summary>
public class NgEmailScopeOptionsDto
{
    public List<string> Departments { get; set; } = new();
    public List<NgCategoryOptionDto> Categories { get; set; } = new();
}

/// <summary>Một danh mục hàng. Mã là chuỗi — xem ghi chú bên API.</summary>
public class NgCategoryOptionDto
{
    public string Code { get; set; } = "";
    public string? Name { get; set; }
}

/// <summary>Thân request lưu mẫu thư.</summary>
public class SaveNgTemplateRequestDto
{
    public string Subject { get; set; } = "";
    public string? Body { get; set; }
}
