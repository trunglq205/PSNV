using SkiaSharp;

namespace Swms.FinishGoods.API.Shared.Business.Media;

/// <summary>
/// Lưu ảnh dùng chung cho mọi tính năng (hàng bất thường, kiểm kê, hư hỏng kệ…).
/// Mỗi ảnh sinh 3 bản:
///   gốc            — bằng chứng, giữ nguyên byte ảnh máy chụp gửi lên
///   view (2048px)  — mở nhanh khi duyệt
///   thumb (320px)  — lưới ảnh, danh sách
/// Tính năng gọi chỉ cần truyền <c>module</c> để ảnh nằm đúng thư mục riêng.
///
/// Dùng SkiaSharp (MIT, Microsoft). Trước đây dùng SixLabors.ImageSharp nhưng
/// từ 4.0.0 nó chặn build Release nếu không có license key trả phí, còn nhánh
/// 3.x thì đọng 5 lỗ hổng không được vá. Giao diện IImageStorage giữ nguyên nên
/// mọi nơi gọi không phải sửa gì.
/// </summary>
public interface IImageStorage
{
    /// <summary>
    /// Thư mục gốc đang dùng thật (sau khi đọc Media:Root / NgPhotos:Root, hoặc
    /// đường dẫn mặc định). Cần cho thông báo lỗi: biết đã tìm ở đâu thì mới
    /// phát hiện được trường hợp ghi một nơi, đọc một nơi khác.
    /// </summary>
    string Root { get; }

    /// <param name="module">Tên tính năng, dùng làm thư mục: ng, stocktake, rack…</param>
    /// <param name="namePrefix">Tiền tố tên file, thường là số phiếu.</param>
    Task<StoredImage> SaveAsync(Stream source, string module, string namePrefix,
        string originalFileName, CancellationToken ct = default);

    /// <param name="size">original | view | thumb</param>
    (string FullPath, string ContentType)? Resolve(string relativePath, string size);

    /// <summary>Xoá cả 3 bản của 1 ảnh. Dùng khi dọn dữ liệu, không dùng lúc xoá mềm.</summary>
    void Delete(string relativePath);
}

public record StoredImage(string RelativePath, string FileName, string ContentType, long SizeBytes);

/// <summary>
/// Ảnh tải lên không phải ảnh hợp lệ, không giải mã được, hoặc ở định dạng
/// không nhận. Tầng trên bắt ĐÚNG MỘT loại này cho mọi trường hợp ảnh xấu —
/// không cần biết thư viện ảnh bên dưới ném ra cái gì.
/// </summary>
public class NotAnImageException : Exception
{
    public NotAnImageException() : base("The uploaded file is not a supported image.") { }
}

public class ImageStorage : IImageStorage
{
    private const int ViewMaxEdge = 2048;
    private const int ThumbMaxEdge = 320;
    private const int ViewQuality = 82;
    private const int ThumbQuality = 70;

    /// <summary>
    /// Danh sách ĐÓNG các định dạng được nhận, kèm phần mở rộng DO SERVER đặt.
    /// Đây là chốt an toàn: Skia không giải mã SVG nên file .svg chứa script
    /// không qua được bước này, và vì phần mở rộng do server đặt theo nội dung
    /// thật nên không ai đổi tên file để lừa trình duyệt chạy script.
    /// </summary>
    private static readonly Dictionary<SKEncodedImageFormat, string> Allowed = new()
    {
        [SKEncodedImageFormat.Jpeg] = ".jpg",
        [SKEncodedImageFormat.Png] = ".png",
        [SKEncodedImageFormat.Webp] = ".webp",
        [SKEncodedImageFormat.Gif] = ".gif",
        [SKEncodedImageFormat.Bmp] = ".bmp",
    };

    /// <summary>
    /// Thu nhỏ bằng nội suy bicubic Mitchell-Netravali — mượt, ít răng cưa khi
    /// giảm nhiều lần, tương đương mặc định của thư viện cũ.
    /// </summary>
    private static readonly SKSamplingOptions Sampling = new(SKCubicResampler.Mitchell);

    private readonly string _root;

    public string Root => _root;

    public ImageStorage(IConfiguration config, IWebHostEnvironment env)
    {
        // Cấu hình "Media:Root"; không khai thì dùng thư mục con của ứng dụng.
        var configured = config["Media:Root"] ?? config["NgPhotos:Root"];
        _root = string.IsNullOrWhiteSpace(configured)
            ? Path.Combine(env.ContentRootPath, "App_Data", "media")
            : configured;
        Directory.CreateDirectory(_root);
    }

    public async Task<StoredImage> SaveAsync(Stream source, string module, string namePrefix,
        string originalFileName, CancellationToken ct = default)
    {
        var now = DateTime.Now;
        var safeModule = Sanitize(module, "misc");
        // Thư mục theo tính năng / năm / tháng để 1 folder không phình ra hàng chục nghìn file
        var relDir = Path.Combine(safeModule, now.ToString("yyyy"), now.ToString("MM"));
        Directory.CreateDirectory(Path.Combine(_root, relDir));

        using var buffer = new MemoryStream();
        await source.CopyToAsync(buffer, ct);
        var raw = buffer.ToArray();

        // KHÔNG tin phần mở rộng máy khách gửi: đọc nội dung để biết định dạng thật.
        var ext = DetectExtension(raw);

        var stem = $"{Sanitize(namePrefix, "img")}_{Guid.NewGuid():N}";
        var relOriginal = Path.Combine(relDir, stem + ext);

        // Ảnh gốc ghi nguyên byte đã nhận, không giải mã rồi mã hoá lại —
        // giữ đúng bằng chứng, kể cả EXIF.
        await File.WriteAllBytesAsync(Path.Combine(_root, relOriginal), raw, ct);

        using var bitmap = Decode(raw);
        SaveResized(bitmap, Path.Combine(_root, relDir, stem + "_view.jpg"), ViewMaxEdge, ViewQuality);
        SaveResized(bitmap, Path.Combine(_root, relDir, stem + "_thumb.jpg"), ThumbMaxEdge, ThumbQuality);

        return new StoredImage(
            relOriginal.Replace(Path.DirectorySeparatorChar, '/'),
            Path.GetFileName(originalFileName),
            ContentTypeOf(ext),
            raw.LongLength);
    }

    /// <summary>
    /// Nhận dạng định dạng thật từ nội dung file và trả về phần mở rộng tương ứng.
    /// Định dạng ngoài danh sách cho phép (TIFF, HEIF, ICO, DNG…) cũng bị loại ở đây.
    /// </summary>
    private static string DetectExtension(byte[] raw)
    {
        if (raw.Length == 0) throw new NotAnImageException();

        try
        {
            // SKCodec bọc stream nên MemoryStream phải còn sống đến khi đọc xong
            // EncodedFormat — khai trong cùng using là đủ.
            using var ms = new MemoryStream(raw, writable: false);
            using var codec = SKCodec.Create(ms);
            if (codec is null) throw new NotAnImageException();

            return Allowed.TryGetValue(codec.EncodedFormat, out var ext)
                ? ext
                : throw new NotAnImageException();
        }
        catch (NotAnImageException) { throw; }
        catch (Exception)
        {
            // File dựng sẵn để phá bộ giải mã: gom về đúng một loại lỗi nghiệp vụ.
            throw new NotAnImageException();
        }
    }

    private static SKBitmap Decode(byte[] raw)
    {
        try
        {
            return SKBitmap.Decode(raw) ?? throw new NotAnImageException();
        }
        catch (NotAnImageException) { throw; }
        catch (Exception)
        {
            throw new NotAnImageException();
        }
    }

    public (string FullPath, string ContentType)? Resolve(string relativePath, string size)
    {
        var full = SafeFullPath(relativePath);
        if (full is null) return null;

        if (size is "view" or "thumb")
        {
            var derived = Path.Combine(
                Path.GetDirectoryName(full)!,
                $"{Path.GetFileNameWithoutExtension(full)}_{size}.jpg");
            if (File.Exists(derived)) return (derived, "image/jpeg");
            // chưa sinh được bản thu nhỏ thì trả ảnh gốc, hơn là trả lỗi
        }

        return File.Exists(full) ? (full, ContentTypeOf(Path.GetExtension(full))) : null;
    }

    public void Delete(string relativePath)
    {
        var full = SafeFullPath(relativePath);
        if (full is null) return;

        var dir = Path.GetDirectoryName(full)!;
        var stem = Path.GetFileNameWithoutExtension(full);
        foreach (var p in new[] { full, Path.Combine(dir, stem + "_view.jpg"), Path.Combine(dir, stem + "_thumb.jpg") })
        {
            try { if (File.Exists(p)) File.Delete(p); } catch { /* file đang bị khoá — bỏ qua */ }
        }
    }

    /// <summary>Chặn đi ngược thư mục (../): chỉ cho phép file nằm trong thư mục gốc.</summary>
    private string? SafeFullPath(string relativePath)
    {
        var rel = relativePath.Replace('/', Path.DirectorySeparatorChar);
        var full = Path.GetFullPath(Path.Combine(_root, rel));
        return full.StartsWith(Path.GetFullPath(_root), StringComparison.OrdinalIgnoreCase) ? full : null;
    }

    /// <summary>
    /// Ghi 1 bản thu nhỏ dạng JPEG, cạnh dài không quá <paramref name="maxEdge"/>.
    /// Ảnh vốn đã nhỏ hơn khung thì KHÔNG phóng to, chỉ mã hoá lại — phóng to
    /// không thêm chi tiết nào mà làm file phình ra vô ích.
    /// </summary>
    private static void SaveResized(SKBitmap source, string path, int maxEdge, int quality)
    {
        var (w, h) = FitWithin(source.Width, source.Height, maxEdge);

        SKBitmap? resized = null;
        try
        {
            var target = source;
            if (w != source.Width || h != source.Height)
            {
                resized = source.Resize(new SKSizeI(w, h), Sampling)
                          ?? throw new NotAnImageException();
                target = resized;
            }

            using var image = SKImage.FromBitmap(target);
            using var data = image.Encode(SKEncodedImageFormat.Jpeg, quality)
                             ?? throw new NotAnImageException();
            using var file = File.Create(path);
            data.SaveTo(file);
        }
        finally
        {
            resized?.Dispose();
        }
    }

    /// <summary>Co cho vừa khung vuông maxEdge, giữ tỉ lệ, không bao giờ phóng to.</summary>
    private static (int W, int H) FitWithin(int w, int h, int maxEdge)
    {
        var longest = Math.Max(w, h);
        if (longest <= 0) throw new NotAnImageException();
        if (longest <= maxEdge) return (w, h);

        var scale = (double)maxEdge / longest;
        return (Math.Max(1, (int)Math.Round(w * scale)),
                Math.Max(1, (int)Math.Round(h * scale)));
    }

    /// <summary>Bỏ mọi ký tự có thể tạo đường dẫn; chỉ giữ chữ, số, gạch.</summary>
    private static string Sanitize(string? value, string fallback)
    {
        if (string.IsNullOrWhiteSpace(value)) return fallback;
        var clean = new string(value.Where(c => char.IsLetterOrDigit(c) || c is '-' or '_').ToArray());
        return clean.Length == 0 ? fallback : clean;
    }

    /// <summary>
    /// Kiểu nội dung lấy từ phần mở rộng DO SERVER đặt sau khi nhận dạng.
    /// Danh sách đóng: không bao giờ trả về svg hay html vì chúng chạy được script.
    /// </summary>
    private static string ContentTypeOf(string ext) => ext.ToLowerInvariant() switch
    {
        ".png" => "image/png",
        ".webp" => "image/webp",
        ".gif" => "image/gif",
        ".bmp" => "image/bmp",
        _ => "image/jpeg"
    };
}
