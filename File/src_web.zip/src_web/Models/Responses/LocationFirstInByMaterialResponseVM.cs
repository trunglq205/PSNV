﻿namespace SWMS_WebTool.Models.Responses
{
    public class LocationFirstInByMaterialResponseVM
    {
        public string PositionName { get; set; }
        public string PIC { get; set; }
    }
}
