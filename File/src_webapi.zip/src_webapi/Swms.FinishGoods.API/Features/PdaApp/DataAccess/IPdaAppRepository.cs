namespace Swms.FinishGoods.Api.Features.PdaApp.DataAccess;

public interface IPdaAppRepository
{
    /// <summary>Toàn bộ lịch sử phiên bản (mới nhất trước). Bản đang phát hành có IsCurrent = 1.</summary>
    Task<IReadOnlyList<PdaAppVersionEntity>> GetAllAsync();

    /// <summary>Bản đang phát hành (is_current = 1), null nếu chưa công bố bản nào.</summary>
    Task<PdaAppVersionEntity?> GetCurrentAsync();

    Task<PdaAppVersionEntity?> GetByIdAsync(long id);

    /// <summary>Kiểm tra versionName đã tồn tại (không tính bản đã xoá mềm).</summary>
    Task<bool> VersionExistsAsync(string version);

    /// <summary>versionCode lớn nhất hiện có (0 nếu chưa có bản nào) — để tự tăng.</summary>
    Task<int> GetMaxVersionCodeAsync();

    /// <summary>
    /// Công bố bản mới trong 1 transaction: bỏ cờ current của mọi bản, insert bản mới với is_current = 1.
    /// Trả về id vừa insert.
    /// </summary>
    Task<long> PublishAsync(PdaAppVersionEntity entity);
}
