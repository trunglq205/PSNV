import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_warehouse/entities/Robot/RobotLocationTarget.dart';
import 'package:smart_warehouse/shared/extensions/duration_extensions.dart';
import 'package:smart_warehouse/shared/extensions/widget_extensions.dart';
import '../../../../di/di.dart';
import '../../../../shared/base/base_page.dart';
import '../../../../shared/utils/alert.dart';
import '../../../../shared/utils/logger.dart';
import '../../../../subsystem/pda/pda.dart';
import '../../../widgets/app_form_field.dart';
import 'outpallet_amr_controller.dart';
import 'outpallet_amr_state.dart';

@RoutePage()
class OutpalletAmrPage extends BasePage<OutpalletAmrController, OutpalletAmrState> {
  const OutpalletAmrPage({super.key});
  @override
  BasePageState createState() => _OutpalletAmrPageState();
}
class _OutpalletAmrPageState
    extends BasePageState<OutpalletAmrController, OutpalletAmrState>
{
  late TextEditingController _controller;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = TextEditingController();
    getIt<PdaDevice>().listen(context, (data) async {logger.d('Barcode: $data');
    _controller.text = data;
    });
  }

  @override
  Widget builder(context, cubit, state) {
    return Scaffold(
      appBar: AppBar(title: const Text('Out Pallet')),
      body:  Column(
        children: [
          Row(
            children: [
              const Text('Location: '),
              const SizedBox(width: 8),
              Expanded(
                child: AppFormField(
                  readOnly: true,
                  autoFocus: true,
                  controller: _controller,
                ),
              ),

            ],
          ).paddingSymmetric(horizontal: 16, vertical: 8),
          const Divider(),


        ],
      ),
      bottomNavigationBar: ElevatedButton(
        onPressed: () async {
          final cubit = context.read<OutpalletAmrController>();
          await cubit.Robot_OutPallet(_controller.text);
          await Duration.zero.delay(() async {
            getIt<AppAlertDialog>().show(
              context,
              type: AppAlertType.success,
            );
          });
        },
        child:
        const Text('Confirm Out Pallet'),
      ).paddingSymmetric(horizontal: 16, vertical: 8),

    );
  }

}