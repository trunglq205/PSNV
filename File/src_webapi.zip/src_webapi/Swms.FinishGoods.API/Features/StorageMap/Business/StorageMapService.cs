using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.StorageMap.Api;
using Swms.FinishGoods.API.Features.StorageMap.DataAccess;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.StorageMap.Business;

public class StorageMapService : IStorageMapService
{
    // Map mặc định khi client không truyền areaCode (tương thích ngược).
    private const string DefaultStorageAreaCode = "STORAGE";

    private static string Area(string? areaCode)
        => string.IsNullOrWhiteSpace(areaCode) ? DefaultStorageAreaCode : areaCode.Trim().ToUpperInvariant();

    private readonly IStorageMapRepository _repo;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public StorageMapService(
        IStorageMapRepository repo,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _localizer = localizer;
    }

    public async Task<IReadOnlyList<RackSummaryResponse>> GetRacksAsync(string? areaCode = null)
    {
        var racks = await _repo.GetRacksAsync(Area(areaCode));
        return racks.Select(RackSummaryResponse.From).ToList();
    }

    public async Task<RackElevationResponse> GetElevationAsync(string rackCode, string? areaCode = null)
    {
        var area = Area(areaCode);
        rackCode = (rackCode ?? "").Trim();
        if (rackCode.Length == 0)
            throw new BusinessRuleException(_localizer["Storage.Err.RackCodeRequired"]);

        var rack = await _repo.GetRackByCodeAsync(area, rackCode)
                   ?? throw new NotFoundException(_localizer["Storage.Err.RackNotFound"]);

        var cells = await _repo.GetElevationAsync(area, rackCode);
        return RackElevationResponse.From(rack, cells);
    }

    public async Task<TopMapResponse> GetTopMapAsync(string? areaCode = null)
    {
        var map = await _repo.GetTopMapAsync(Area(areaCode))
                  ?? throw new NotFoundException(_localizer["Storage.Err.AreaNotFound"]);
        return TopMapResponse.From(map);
    }

    public async Task SaveTopMapAsync(SaveTopMapRequest request, string? user)
    {
        var blocks = (request.Blocks ?? Array.Empty<SaveTopMapBlockRequest>())
            .Select(b => new SaveTopMapBlock
            {
                Id = b.Id,
                Kind = b.Kind,
                RackId = b.RackId,
                Label = b.Label,
                Color = b.Color,
                GridX = b.GridX,
                GridY = b.GridY,
                GridW = b.GridW,
                GridH = b.GridH
            })
            .ToList();
        await _repo.SaveTopMapAsync(DefaultStorageAreaCode, blocks, user);
    }

    public async Task CreateRackAsync(CreateRackRequest request, string? user)
    {
        var code = (request.Code ?? string.Empty).Trim().ToUpperInvariant();
        if (string.IsNullOrWhiteSpace(code)) throw new BusinessRuleException(_localizer["Storage.Err.RackCodeRequired"]);
        if (request.Positions <= 0) throw new BusinessRuleException(_localizer["Storage.Err.PositionsPositive"]);
        var floors = request.Floors is >= 1 and <= 10 ? request.Floors : 4;
        var shelf = (request.ShelfPositions ?? Array.Empty<int>())
            .Where(p => p >= 1 && p <= request.Positions).Distinct().ToList();
        await _repo.CreateRackAsync(DefaultStorageAreaCode, code, request.Positions, floors, shelf,
            request.GridX, request.GridY, request.GridW, request.GridH, user);
    }

    public async Task DeleteRackAsync(string rackCode, string? user)
    {
        if (string.IsNullOrWhiteSpace(rackCode)) throw new BusinessRuleException(_localizer["Storage.Err.RackCodeRequired"]);
        await _repo.DeleteRackAsync(DefaultStorageAreaCode, rackCode.Trim(), user);
    }

    public async Task SetCellKindAsync(SetCellKindRequest request, string? user)
    {
        if (string.IsNullOrWhiteSpace(request.RackCode)) throw new BusinessRuleException(_localizer["Storage.Err.RackCodeRequired"]);
        await _repo.SetCellKindAsync(Area(request.AreaCode), request.RackCode.Trim(), request.Position, request.Floor, request.Kind, user);
    }

    public async Task<LocatorLocationResponse> LocateAsync(string locatorCode)
    {
        var code = (locatorCode ?? string.Empty).Trim();
        if (code.Length == 0) throw new BusinessRuleException(_localizer["Storage.Err.LocatorRequired"]);

        var loc = await _repo.LocateAsync(code)
                  ?? throw new NotFoundException(_localizer["Storage.Err.LocatorNotFound"]);
        return LocatorLocationResponse.From(loc);
    }

    public async Task<IReadOnlyList<PalletSerialResponse>> GetSerialsAsync(string palletCode)
    {
        var code = (palletCode ?? string.Empty).Trim();
        if (code.Length == 0) throw new BusinessRuleException(_localizer["Storage.Err.PalletRequired"]);

        var rows = await _repo.GetSerialsAsync(code);
        return rows.Select(PalletSerialResponse.From).ToList();
    }
}
