import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_skeleton.dart';

/// Skeleton màn Soạn hàng: bám đúng bố cục KittingHeaderCard + KittingRouteList
/// để khi data về, nội dung "rơi" đúng chỗ, không giật layout.
class KittingSkeleton extends StatelessWidget {
  /// Số dòng vị trí giả.
  final int rows;

  const KittingSkeleton({super.key, this.rows = 8});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return ListView(
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.all(AppDimens.md),
      children: [
        const _HeaderSkeleton(),
        const SizedBox(height: AppDimens.md),
        SkeletonCard(
          padding: EdgeInsets.zero,
          child: Column(
            children: [
              for (var i = 0; i < rows; i++) ...[
                if (i > 0) Divider(height: 1, color: swms.border),
                _RouteRowSkeleton(seed: i),
              ],
            ],
          ),
        ),
      ],
    );
  }
}

/// = KittingHeaderCard: nút đổi SI · mã SI + tiến độ · nút bản đồ.
class _HeaderSkeleton extends StatelessWidget {
  const _HeaderSkeleton();

  @override
  Widget build(BuildContext context) {
    return const SkeletonCard(
      padding: EdgeInsets.all(8),
      child: Row(
        children: [
          SizedBox.square(
            dimension: AppDimens.hitMd,
            child: Center(
              child: Bone(width: 32, height: 32, radius: AppDimens.rInput - 2),
            ),
          ),
          SizedBox(width: 4),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Bone(width: 140, height: 15),
                SizedBox(height: 6),
                Bone(width: 180, height: 11),
              ],
            ),
          ),
          SizedBox(width: AppDimens.sm),
          Bone(width: 96, height: 32, radius: AppDimens.rBtn),
        ],
      ),
    );
  }
}

/// = _TaskRow: status dot · vị trí + mode / model + PO · qty.
class _RouteRowSkeleton extends StatelessWidget {
  /// Đổi độ dài thanh theo dòng cho tự nhiên, tránh 6 dòng giống hệt.
  final int seed;

  const _RouteRowSkeleton({required this.seed});

  static const _codeW = [88.0, 72.0, 96.0];
  static const _subW = [150.0, 120.0, 170.0];

  @override
  Widget build(BuildContext context) {
    final k = seed % 3;
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      child: Row(
        children: [
          const Bone.circle(size: 30),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Bone(width: _codeW[k], height: 13),
                    const SizedBox(width: 6),
                    const Bone(width: 64, height: 11),
                  ],
                ),
                const SizedBox(height: 6),
                Bone(width: _subW[k], height: 11),
              ],
            ),
          ),
          const SizedBox(width: AppDimens.sm),
          const Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Bone(width: 44, height: 14),
              SizedBox(height: 4),
              Bone(width: 22, height: 10),
            ],
          ),
          // Chỗ của chevron (4 + 18) để cột qty thẳng hàng với data thật.
          const SizedBox(width: AppDimens.xs + 18),
        ],
      ),
    );
  }
}
