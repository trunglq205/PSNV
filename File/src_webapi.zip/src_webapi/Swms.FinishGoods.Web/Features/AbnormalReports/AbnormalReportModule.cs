using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.AbnormalReports.Business;
using Swms.FinishGoods.Web.Features.AbnormalReports.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.AbnormalReports;

public static class AbnormalReportModule
{
    public static IServiceCollection AddAbnormalReportFeature(this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<INgReportApi>(api);
        services.AddScoped<INgReportBusiness, NgReportBusiness>();

        // Cấu hình email của riêng Hàng bất thường. Gọi endpoint dùng chung
        // /api/email-configs/* nhưng qua client riêng, để không phụ thuộc vào
        // bộ IEmailConfigApi đang nằm trong Features/Shortages.
        services.AddApiClient<INgMailConfigApi>(api);
        services.AddScoped<INgMailConfigBusiness, NgMailConfigBusiness>();

        return services;
    }
}
