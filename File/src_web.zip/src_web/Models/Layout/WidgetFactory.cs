using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Models.Layout
{
    public static class WidgetFactory
    {
        public static Widget BuildWidget(KonvaObject konvaObject)
        {
            var type = konvaObject?.Attrs.Name?.ToEnum<WidgetType>();

            switch (type)
            {
                case WidgetType.Floor:
                    return new Floor(konvaObject);
                case WidgetType.Zone:
                    return new Zone(konvaObject);
                case WidgetType.Rectangle:
                    return new Rectangle(konvaObject);
                case WidgetType.Circle:
                    return new Circle(konvaObject);
                case WidgetType.Line:
                    return new Line(konvaObject);
                case WidgetType.Text:
                    return new Text(konvaObject);
                case WidgetType.Door:
                    return new SingleDoor(konvaObject);
                case WidgetType.SingleDoor:
                    return new SingleDoor(konvaObject);
                case WidgetType.DoubleDoor:
                    return new DoubleDoor(konvaObject);
                case WidgetType.Rack:
                    return new Rack(konvaObject);
                case WidgetType.RobotLine:
                    return new RobotLine(konvaObject);  
                case WidgetType.Stair:
                    return new Stair(konvaObject);
                case WidgetType.Arrow:
                    return new Arrow(konvaObject);
                case WidgetType.ArrowFill:
                    return new ArrowFill(konvaObject);
                case WidgetType.Folklift:
                    return new Folklift(konvaObject);
                case WidgetType.FolkliftWorking:
                    return new FolkliftWorking(konvaObject);
                case WidgetType.Container:
                    return new Container(konvaObject);
                case WidgetType.Folklift2:
                    return new Folklift2(konvaObject);
                case WidgetType.Container2:
                    return new Container2(konvaObject);
                case WidgetType.Trolley:
                    return new Trolley(konvaObject);
                default:
                    throw new Exception("This type is not supported.");
            }

        }
    }
}
