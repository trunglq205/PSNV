import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'theme_provider.g.dart';

/// Giữ ThemeMode runtime. Có thể mở rộng để lưu vào Hive.
@Riverpod(keepAlive: true)
class ThemeModeNotifier extends _$ThemeModeNotifier {
  @override
  ThemeMode build() => ThemeMode.system;

  void toggle() =>
      state = state == ThemeMode.light ? ThemeMode.dark : ThemeMode.light;

  void set(ThemeMode mode) => state = mode;
}
