﻿namespace SWMS_WebTool.Models.DataKitting
{
    public class DataKittingFA : DataKittingPL
    {
        public Int64 DataKittingFAID { get; set; }
        public string ReservationNo { get; set; }
        public string Recipient { get; set; }
        public string Frequency { get; set; }
        public string Receipt_Location { get; set; }
        public string RoHS { get; set; }
        public string INS { get; set; }
    }
}
