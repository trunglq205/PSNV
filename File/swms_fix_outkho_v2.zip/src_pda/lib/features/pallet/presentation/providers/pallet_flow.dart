import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';

/// 3 màn "quét pallet → chọn hành động → quét vị trí → xác nhận" chỉ khác nhau
/// ở: dữ liệu nạp thêm, hành động được phép hiện, và chữ trên màn.
/// Gom thành 1 enum để dùng chung 1 notifier + 1 body.
enum PalletFlow {
  /// Vị trí tạm: gán / rời / chuyển.
  tempLocation,

  /// Lưu kho: chỉ "store", có gợi ý vị trí.
  storing,

  /// Chuyển / Out (pallet đã lưu kho): move, bỏ assign.
  warehouseMove,

  /// Khu tập kết (vanning): đưa pallet đã soạn ra khu chờ đóng cont.
  /// Chỉ gán / chuyển vào vị trí — không lưu kho, không rời vị trí.
  vanningArea;

  /// Dữ liệu cần nạp thêm khi lookup ở bước 1.
  ///
  /// Storing KHÔNG còn `PalletInclude.suggestion`: gợi ý vị trí đã tách sang
  /// `GET by-lot-no/{lotNo}/storage-suggestion` vì cần thêm chiều cao pallet.
  Set<PalletInclude> get include => const {};

  /// Màn này có gọi API gợi ý vị trí lưu kho hay không.
  bool get needsStorageSuggestion => this == PalletFlow.storing;

  /// Loại khu (`warehouse_areas.map_type`) MẶC ĐỊNH của màn.
  ///
  /// Chỉ còn dùng làm phương án dự phòng khi chưa chọn hành động. Khu đích
  /// THẬT bám theo HÀNH ĐỘNG (xem [PalletActionArea.mapType]), không theo màn:
  /// một màn có thể có hai hành động đi về hai khu khác nhau — màn Chuyển / Out
  /// vừa chuyển nội bộ trong kho (storing), vừa out hàng RW/RB ra khu nhận
  /// hàng để giao FA (receiving).
  String get mapType => switch (this) {
    PalletFlow.tempLocation => 'receiving',
    PalletFlow.storing => 'storing',
    PalletFlow.warehouseMove => 'storing',
    PalletFlow.vanningArea => 'vanning',
  };

  /// Lọc `allowedActions` của server theo màn.
  List<PalletAction> actionsFor(Pallet p) {
    final wanted = switch (this) {
      PalletFlow.tempLocation => {
        PalletAction.assign,
        PalletAction.moveReceiving,
      },
      PalletFlow.storing => {PalletAction.store},
      // moveReceiving: hàng RW/RB out kho ra khu nhận hàng = GIAO CHO FA.
      // Server chỉ trả action này cho pallet có disposition, nên hàng thường
      // không thấy nó. Đặt ở màn Chuyển / Out chứ không phải màn Vị trí tạm:
      // người đứng kho nghĩ tới "out" là mở màn này, và pallet đang nằm trong
      // kho chứ không phải ở khu nhận hàng.
      PalletFlow.warehouseMove => {
        PalletAction.moveStoring,
        PalletAction.moveReceiving,
      },
      PalletFlow.vanningArea => {
        PalletAction.vanning,
        PalletAction.moveVanning,
      },
    };
    return p.allowedActions.where(wanted.contains).toList();
  }
}

/// Khu đích của từng hành động.
///
/// Đây mới là nguồn sự thật cho "vị trí quét vào phải thuộc khu nào", chứ
/// không phải [PalletFlow.mapType]: cùng một màn có thể có hai hành động đi về
/// hai khu khác nhau.
extension PalletActionArea on PalletAction {
  String get mapType => switch (this) {
    PalletAction.assign => 'receiving',
    PalletAction.moveReceiving => 'receiving',
    PalletAction.store => 'storing',
    PalletAction.moveStoring => 'storing',
    PalletAction.vanning => 'vanning',
    PalletAction.moveVanning => 'vanning',
  };
}
