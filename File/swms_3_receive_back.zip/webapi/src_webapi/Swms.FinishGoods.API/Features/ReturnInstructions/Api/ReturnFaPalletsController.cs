using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.ReturnInstructions.Business;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// Mục 2d — FA quét serial đóng lại Pallet ID sau rework.
///
/// Khác mục 2a (SCS WH nhận hàng khách trả) ở chỗ quan trọng nhất: serial lạ
/// VẪN cho quét tiếp, chỉ bị loại khỏi pallet và ghi vào nhật ký lệch để SCS WH
/// đặt riêng ra. Mục 2a thì CHẶN.
///
/// Đặt chung route <c>/api/return-instructions/{docId}</c> chứ không mở route
/// mới: đây vẫn là việc trên một phiếu back hàng, và PDA đã có sẵn base đó.
/// </summary>
[ApiController]
[Route("api/return-instructions/{docId:long}")]
public class ReturnFaPalletsController : ControllerBase
{
    private readonly IReturnFaPalletService _service;
    public ReturnFaPalletsController(IReturnFaPalletService service) => _service = service;

    /// <summary>
    /// Sổ serial dạng GỌN (serial · model · status) để PDA tải một lần rồi kiểm
    /// NGAY LÚC QUÉT, không chờ mạng từng con.
    ///
    /// Chỉ cần quyền xem: nó là dữ liệu của phiếu, và cả FA lẫn SCS đều đọc.
    /// </summary>
    [HttpGet("serial-index")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<ReturnSerialIndexResponse>>> GetSerialIndex(long docId)
        => Ok(await _service.GetSerialIndexAsync(docId));

    /// <summary>FA đóng pallet mới sau rework.</summary>
    [HttpPost("fa-pallets")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ProcessFa>]
    public async Task<ActionResult<CreateFaPalletResponse>> CreateFaPallet(
        long docId, [FromBody] CreateFaPalletRequest request)
        => Ok(await _service.CreateAsync(docId, request));

    /// <summary>
    /// Mục 3 — SCS nhận lại một pallet FA đã giao.
    ///
    /// Chỉ cần mã pallet: FA đã quét từng serial khi đóng pallet ở mục 2d, nên
    /// quét lại 400 con ở đây là làm hai lần một việc. Quyền <c>Process</c> —
    /// đây là việc của SCS WH.
    /// </summary>
    [HttpPost("receive-back")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<ReceiveBackResponse>> ReceiveBack(
        long docId, [FromBody] ReceiveBackRequest request)
        => Ok(await _service.ReceiveBackAsync(docId, request));

    /// <summary>
    /// Nhật ký serial lệch. <paramref name="openOnly"/> mặc định true — màn hình
    /// cần việc CÒN PHẢI LÀM, nhật ký cũ thì càng ngày càng dài.
    /// </summary>
    [HttpGet("mismatches")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<ReturnMismatchResponse>>> GetMismatches(
        long docId, [FromQuery] bool openOnly = true)
        => Ok(await _service.GetMismatchesAsync(docId, openOnly));

    /// <summary>
    /// SCS đánh dấu đã đặt riêng / đã trả về đúng phiếu.
    ///
    /// Nhận cả <c>Process</c> và <c>Create</c>: người đặt hàng riêng ra là SCS
    /// WH, nhưng Office cũng phải đóng được một dòng nhật ký đã xử lý xong —
    /// cùng lý do hai bên đều chốt được thực nhận ở mục 2b.
    /// </summary>
    [HttpPost("mismatches/{id:long}/resolve")]
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.Process,
                          Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<ActionResult<ReturnMismatchResponse>> ResolveMismatch(
        long docId, long id, [FromBody] ResolveMismatchRequest request)
        => Ok(await _service.ResolveMismatchAsync(id, request));
}
