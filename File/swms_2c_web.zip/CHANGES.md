# Mục 2c — Màn Web "Yêu cầu back hàng sang FA"

14 file. Chạy SAU `swms_2c_backend.zip` (cần endpoint + quyền của gói đó).

⚠ **`Shared/Auth/Perms.cs` và 4 resx trong gói này thay bản ở các zip trước** —
chúng cộng dồn, không phải ghi đè mất.

## 1. Một màn, bốn bên — không màn riêng cho FA

Màn mới `/rework-back`, nav item **"Yêu cầu back hàng"** trong nhóm Nhận hàng,
gác bằng `rework_refurbish.view` — **bốn bên đều phải THẤY** màn này; ai được
bấm gì thì nút tự lọc.

Theo đúng khuôn màn Hàng bất thường: tách việc bằng **tab hàng đợi** + quyền
trên từng nút. Không dựng màn riêng cho FA vì bốn bên đọc cùng một danh sách —
tách màn là sớm muộn hai bên nhìn hai con số khác nhau.

| Tab | Lọc theo | Ai hay dùng |
|---|---|---|
| Tất cả | — | mọi người |
| Chờ quản lý FA | `step = fa_approve` | quản lý FA |
| Chờ SCS WH | `step = scs_instruct` | SCS WH |
| Chờ quản lý SCS | `step = scs_approve` | quản lý SCS |
| Đã cho back | `status = scs_approved` | theo dõi hàng ở FA |
| Đã huỷ | `status = cancelled` | tra lại |

Mỗi tab có **số việc đang chờ** trong chip tròn. Hai tab cuối phải lọc theo
*status* chứ không theo *step*, vì bước `done` gồm cả đã-cho-back và đã-huỷ.

Lọc tab làm ở **client**: cả màn chỉ vài trăm dòng, mà muốn đếm số trên tab thì
buộc phải có toàn bộ dữ liệu — gọi API cho từng tab sẽ thành sáu lượt gọi chỉ
để vẽ sáu con số.

## 2. Nút = QUYỀN **AND** ĐÚNG BƯỚC

```csharp
private bool CanApproveScs(ReturnBackRequestDto r)
    => r.IsOpen && r.CurrentStep == BackStep.ScsApprove && MayApproveScs;
```

Lớp "đúng bước" là thứ làm cho duyệt có nghĩa: role khai sai cũng không nhảy
được hàng, và server còn chặn lần nữa bằng điều kiện bước nằm **trong câu
UPDATE**.

Các `@if` **độc lập, KHÔNG else-if** — chuỗi else-if làm người chỉ có một quyền
bị bỏ qua cả nhánh và mất luôn nút của mình. Các điều kiện loại trừ nhau theo
bước nên `@if` riêng vẫn ra đúng.

| Nút | Quyền | Bước |
|---|---|---|
| Sửa | `request_back` ‖ `process` | `fa_approve` hoặc `scs_instruct` |
| Quản lý FA duyệt | `approve_fa` | `fa_approve` |
| Xác nhận và tạo chỉ thị | `process` | `scs_instruct` |
| Duyệt cho back | `approve_scs` | `scs_approve` |
| Huỷ yêu cầu | một trong ba | còn mở |

## 3. Timeline bốn bước khi bung dòng

Bốn ô: FA tạo → quản lý FA → SCS WH → quản lý SCS, mỗi ô có **người và lúc**.
Ô đang chờ tô cam viền dày; ô xong xanh nhạt; ô chưa tới lượt làm nhạt hẳn.

Lý do hiện cả mốc thời gian: "đang chờ quản lý SCS" mà không biết chờ từ bao giờ
thì không ai biết có phải đi nhắc hay không.

## 4. Dialog soạn yêu cầu — chặn trước khi bấm Lưu

- Chọn chỉ thị → tự nạp **SL kho còn gắp được theo model**, và mồi sẵn một dòng.
- Ô model là **dropdown chỉ những model còn hàng** (không cho gõ tay model lạ).
- Ô SL có `max` = SL còn kho; đổi model thì SL cũ **tự kẹp xuống** mức của model
  mới, thay vì để nút Lưu tắt mà người dùng không hiểu vì sao.
- Nút Lưu tắt khi: chưa chọn phiếu · có dòng thiếu model/SL · có dòng xin quá
  SL kho · model trùng nhau.
- Lúc **SỬA**, SL đã gắp cho chính dòng đó được **cộng lại** vào "còn kho" (nó
  đã bị đóng dấu `back_request_id` nên không còn nằm trong available) — không
  cộng thì người sửa bị bắt giảm số xuống dưới cái họ đang có.
- Phiếu đã huỷ không vào danh sách chọn: server cũng chặn, đưa vào chỉ để người
  dùng chọn rồi ăn lỗi.

## 5. Dialog duyệt

Dùng CHUNG một dialog cho cả bốn hành động, đổi tiêu đề + nút theo hành động.
Riêng **Duyệt cho back** có cảnh báo cam: *"Duyệt là hệ thống gắp serial và
chuyển sang trạng thái đang ở FA. Sau bước này KHÔNG huỷ được yêu cầu nữa."* —
đó là mốc hàng rời kho, nói thẳng ra trước khi bấm.

Lỗi 409 ("có người vừa xử lý trước") **giữ dialog mở** để người dùng đọc được
câu đó, rồi tự tải lại danh sách để họ thấy trạng thái mới.

## 6. Cột trên bảng

| Cột | Nguồn |
|---|---|
| SL xin | tổng dòng |
| Đã gắp | **đếm từ sổ serial** |
| Đang ở FA | đếm `status = at_fa` |
| Đã về | đếm `status = returned` |

"Đang ở FA" đếm thẳng status chứ không lấy `đã gắp − đã về`: con đánh `ng` không
còn chờ về, trừ kiểu kia sẽ cộng nó vào đây và SCS đi đòi một lô hàng không bao
giờ tới.

Gắp thiếu tô đỏ nhạt + chip "Thiếu" trên dòng — **cảnh báo, không phải lỗi**:
kho có thể vừa bị một yêu cầu khác gắp trước.

## 7. i18n

55 khoá (`Return.Back.*` + `Nav.ReworkBack`) thêm vào **cả 4** resx. Đã kiểm:
- 55/55 có mặt ở cả 4 culture
- số placeholder `{n}` khớp nhau giữa 4 culture
- **mọi khoá màn này dùng đều tồn tại** (0 thiếu)
- cả 4 file **parse được XML**

⚠ Một bài học: nhãn tiếng Việt/Anh ban đầu là *"Xác nhận & tạo chỉ thị"* —
dấu `&` trần làm **cả file resx không parse được**, mà Blazor chỉ báo lỗi lúc
chạy. Đã đổi thành "và" / "and" và sửa luôn script chèn resx để tự thoát XML.

Key-set giữa 4 culture vẫn lệch đúng những khoá **có sẵn từ trước**: `en` thiếu
13 khoá `Inventory.*`, `vi` thiếu `Nav.EmapKitting`. Không phải do gói này.

## 8. CSS

`ReturnBackRequests.razor.css` dựng từ `ReworkRefurbish.razor.css` đổi tiền tố
`ri-` → `rb-`, cộng phần riêng ở cuối (timeline 4 bước, chip bước, chip số trên
tab). CSS Blazor là **scoped theo component** nên không dùng chung file được, mà
hai màn này phải trông giống nhau — người dùng đi qua đi lại giữa chúng.

## 9. Áp dụng

1. Chạy `return_back_request_schema.sql` (gói backend) nếu chưa.
2. Ghi đè 14 file.
3. Build Web.
4. Tick quyền ở màn Roles (xem gói backend, mục 9).
5. Thử: FA tạo yêu cầu → quản lý FA duyệt → SCS WH xác nhận → quản lý SCS duyệt,
   rồi soi cột **Đang ở FA** và `wms.return_instruction_serials`.

## 10. Chưa có

- **Mail báo khi duyệt** — chưa khai sự kiện mail nào cho 2c. Cần thì tôi thêm
  tab thứ 3 vào bánh răng cấu hình mail của màn Tái gia công.
- **Mục 2d** (FA quét tạo lại pallet) và **mục 3** (SCS nhận lại) — làm tiếp.
- Màn `ReworkRefurbish` cũ vẫn gọi API trực tiếp còn màn mới đi qua lớp
  business. Hai khuôn trong một feature; nên dồn về một khuôn khi có dịp.
