import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/extensions/navigation_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/back_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_bottom_hint.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_stepper_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/kitting_notifier.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/kitting_task_notifier.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/kitting_task_state.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_box_list.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_box_progress_card.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_location_hero.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_next_hint.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_pallet_content_card.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_vanning_card.dart';

// ─────────────────────────────────────────────────────────────
//  Lấy hàng tại 1 vị trí trên tuyến soạn hàng.
//    - Pallet chẵn: B1 quét Pallet ID → Xác nhận (server đóng task)
//                   B2 quét vị trí vanning → Lưu
//    - Pallet lẻ  : B1 quét từng thùng (server tự đóng task khi đủ)
//                   B2 tách thùng đã lấy sang pallet mới (lấy hết → bỏ qua)
//                   B3 quét tem pallet mới + vị trí vanning → Lưu
//  Bước suy từ server (isDone, stagedLocatorCode) → thoát giữa chừng rồi
//  vào lại vẫn đúng bước. Mã quét nhận từ PDA (scanStream), không nhập tay.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class KittingTaskScreen extends ConsumerStatefulWidget {
  /// Truyền object (push trong app) — màn không mở được bằng deep link.
  final PickTask task;

  /// Vị trí kế tiếp chưa lấy trên tuyến; null = đây là vị trí cuối.
  final PickTask? next;

  /// Khoá kittingProvider của màn tuyến — để nạp lại tuyến và đi tiếp.
  final int? siId;

  /// Thứ tự 1-based của vị trí này trên tuyến, và tổng số vị trí.
  final int index;
  final int total;

  const KittingTaskScreen({
    super.key,
    required this.task,
    required this.index,
    required this.total,
    this.next,
    this.siId,
  });

  @override
  ConsumerState<KittingTaskScreen> createState() => _KittingTaskScreenState();
}

class _KittingTaskScreenState extends ConsumerState<KittingTaskScreen> {
  StreamSubscription<String>? _sub;

  KittingTaskNotifierProvider get _provider => kittingTaskProvider(widget.task);

  KittingTaskNotifier get _notifier => ref.read(_provider.notifier);

  bool get _isPallet => widget.task.mode == PickMode.wholePallet;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    _sub = pda.scanStream.listen((data) async {
      if (!mounted) return;
      final result = await _notifier.onScan(data);
      if (!mounted || result == null) return;

      final task = ref.read(_provider).taskOr(widget.task);
      switch (result) {
        case KittingScanResult.palletMismatch:
          _toastError(
            LocaleKeys.kitting_task_err_pallet_mismatch.tr(
              args: [task.palletCode ?? ''],
            ),
          );
        case KittingScanResult.stagePalletIsOrigin:
          _toastError(
            LocaleKeys.kitting_task_err_stage_pallet_origin.tr(
              args: [task.palletCode ?? ''],
            ),
          );
        case KittingScanResult.vanningMismatch:
          _toastError(
            LocaleKeys.kitting_task_err_vanning_mismatch.tr(
              args: [task.toLocatorCode ?? ''],
            ),
          );
        case KittingScanResult.boxesDone:
          // Còn thùng trên pallet → mở tách ngay; lấy hết → đã sang vanning.
          if (ref.read(_provider).splitPending) await _openSplit();
        default:
          break;
      }
    });
  }

  void _toastError(String message) =>
      AppToastHelper.toastError(context, message);

  /// Tách thùng đã lấy sang pallet mới. Tách xong → bước lưu vanning;
  /// back giữa chừng → ở lại màn này, nút đáy cho mở lại.
  Future<void> _openSplit() async {
    final detail = ref.read(_provider).detail.value;
    final lotNo = detail?.task.palletCode ?? widget.task.palletCode;
    if (detail == null || lotNo == null) return;

    final picked = {
      for (final b in detail.boxes)
        if (b.state == PickBoxState.picked) b.boxId,
    };

    // Màn tách tự nghe PDA — tạm dừng ở đây để mã lot đích không bị gửi
    // nhầm thành "quét thùng".
    _sub?.pause();
    try {
      final ok = await context.router.push<bool>(
        SplitPalletRoute(lotNo: lotNo, pickedBoxIds: picked),
      );
      if (ok == true && mounted) _notifier.markSplitDone();
    } finally {
      _sub?.resume();
    }
  }

  /// Xong vị trí này → nạp lại tuyến, mở thẳng vị trí chưa xong kế tiếp
  /// (thay màn hiện tại). Hết vị trí → về màn tuyến.
  Future<void> _goNext() async {
    final key = kittingProvider(widget.siId);
    await ref.read(key.notifier).load();
    if (!mounted) return;

    final route = ref.read(key).route;
    final next = route.nextPendingAfter(widget.task);
    if (next == null) {
      await context.router.maybePop(true);
    } else {
      await context.replaceKittingTask(route, next, siId: widget.siId);
    }
  }

  /// Xác nhận pallet chẵn — thành công thì màn tự sang bước vanning.
  Future<void> _confirmPallet() async {
    await _notifier.confirmPallet();
  }

  /// Lưu vanning xong → vị trí kế tiếp.
  Future<void> _saveVanning() async {
    if (await _notifier.saveVanning() && mounted) await _goNext();
  }

  void _backToRoute() => context.router.maybePop(true);

  /// Pallet đã lấy xong trên server, hoặc vừa quét khớp trong lần mở này.
  bool _palletOk(PickTask task, KittingTaskState state) =>
      task.isDone || state.scannedPalletCode != null;

  List<StepItem> get _stepItems => _isPallet
      ? [
          StepItem(LocaleKeys.kitting_task_step_pick_pallet.tr()),
          StepItem(LocaleKeys.kitting_task_step_vanning.tr()),
        ]
      : [
          StepItem(LocaleKeys.kitting_task_step_pick_boxes.tr()),
          StepItem(LocaleKeys.kitting_task_step_split.tr()),
          StepItem(LocaleKeys.kitting_task_step_vanning.tr()),
        ];

  /// Số bước 1-based cho AppStepperBar; done = vượt quá số bước.
  int _stepNo(KittingStep step) => _isPallet
      ? switch (step) {
          KittingStep.vanning => 2,
          KittingStep.done => 3,
          _ => 1,
        }
      : switch (step) {
          KittingStep.split => 2,
          KittingStep.vanning => 3,
          KittingStep.done => 4,
          _ => 1,
        };

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(_provider);
    final task = state.taskOr(widget.task);
    final step = state.stepFor(widget.task);

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.kitting_task_title.tr(),
        subtitle: task.locatorCode,
        actions: [_Counter(index: widget.index, total: widget.total)],
      ),
      body: ListView(
        padding: const EdgeInsets.all(AppDimens.md),
        children: [
          KittingLocationHero(
            task: task,
            onOpenMap: () => context.pushRoute(StorageMapRoute()),
          ),
          const SizedBox(height: AppDimens.md),
          AppCard(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
            child: AppStepperBar(current: _stepNo(step), steps: _stepItems),
          ),
          const SizedBox(height: AppDimens.md),
          _buildScanFrame(task, state, step),
          const SizedBox(height: AppDimens.md),
          ..._buildContent(task, state, step),
          if (widget.next != null) ...[
            const SizedBox(height: AppDimens.md),
            KittingNextHint(next: widget.next!),
          ],
        ],
      ),
      bottomNavigationBar: _buildBottom(task, state, step),
    );
  }

  Widget _buildScanFrame(
    PickTask task,
    KittingTaskState state,
    KittingStep step,
  ) {
    final (bool success, String scanning, String successLabel) = switch (step) {
      KittingStep.pickPallet => (
        state.scannedPalletCode != null,
        LocaleKeys.kitting_task_scan_pallet.tr(),
        LocaleKeys.kitting_task_pallet_matched.tr(
          args: [task.palletCode ?? ''],
        ),
      ),
      KittingStep.pickBoxes => (
        false,
        LocaleKeys.kitting_task_scan_box.tr(),
        '',
      ),
      KittingStep.split => (true, '', LocaleKeys.kitting_task_split_hint.tr()),
      KittingStep.vanning => (
        state.scannedVanningCode != null,
        state.vanningPalletFor(widget.task) == null
            ? LocaleKeys.kitting_task_scan_stage_pallet.tr()
            : LocaleKeys.kitting_task_scan_vanning.tr(),
        LocaleKeys.kitting_task_vanning_scanned.tr(
          args: [state.scannedVanningCode ?? ''],
        ),
      ),
      KittingStep.done => (
        true,
        '',
        LocaleKeys.kitting_task_vanning_saved.tr(
          args: [task.stagedLocatorCode ?? ''],
        ),
      ),
    };

    return BarcodeScannerButton(
      height: 64,
      state: state.busy
          ? ScannerState.loading
          : (success ? ScannerState.success : ScannerState.scanning),
      scanningLabel: scanning,
      successLabel: successLabel,
    );
  }

  List<Widget> _buildContent(
    PickTask task,
    KittingTaskState state,
    KittingStep step,
  ) {
    final main = _isPallet
        ? [
            KittingPalletContentCard(
              task: task,
              matched: _palletOk(task, state),
            ),
          ]
        : _buildBoxContent(task, state);

    if (step != KittingStep.vanning && step != KittingStep.done) return main;

    // Bước vanning: thẻ vanning lên đầu — đang cần nhìn nó nhất.
    final isDone = step == KittingStep.done;
    return [
      KittingVanningCard(
        palletCode: state.vanningPalletFor(widget.task),
        targetLocator: task.toLocatorCode,
        locatorCode: isDone ? task.stagedLocatorCode : state.scannedVanningCode,
        saved: isDone,
        onRescanPallet: !isDone && state.stagePalletCode != null
            ? _notifier.resetStagePallet
            : null,
      ),
      const SizedBox(height: AppDimens.md),
      ...main,
    ];
  }

  List<Widget> _buildBoxContent(PickTask task, KittingTaskState state) =>
      switch (state.detail) {
        AsyncData(:final value) => [
          KittingBoxProgressCard(
            task: task,
            boxes: value.boxes,
            picked: value.pickedBoxCount,
          ),
          const SizedBox(height: AppDimens.md),
          KittingBoxList(
            boxes: value.boxes,
            onUnpick: task.isDone ? null : (b) => _notifier.unpickBox(b.boxNo),
          ),
        ],
        AsyncError() => [
          AppErrorView.widget(
            message: LocaleKeys.kitting_task_load_error.tr(),
            onRetry: _notifier.load,
          ),
        ],
        _ => [
          const Padding(
            padding: EdgeInsets.symmetric(vertical: AppDimens.lg),
            child: AppLoading(),
          ),
        ],
      };

  Widget _buildBottom(PickTask task, KittingTaskState state, KittingStep step) {
    final remaining = (task.boxPlanned - state.pickedBoxCount).clamp(
      0,
      task.boxPlanned,
    );
    final vanningReady =
        state.vanningPalletFor(widget.task) != null &&
        state.scannedVanningCode != null;

    final Widget action = switch (step) {
      KittingStep.pickPallet => AppButton(
        label: LocaleKeys.kitting_task_confirm_pallet.tr(),
        icon: Icons.check_rounded,
        variant: AppButtonVariant.success,
        isFullWidth: false,
        isLoading: state.busy,
        onPressed: state.scannedPalletCode != null ? _confirmPallet : null,
      ),
      // Quét bằng phím cứng PDA — nút chỉ nhắc số còn lại, không bấm được.
      KittingStep.pickBoxes => AppButton(
        label: LocaleKeys.kitting_task_scan_box_left.tr(args: ['$remaining']),
        icon: Icons.qr_code_scanner,
        isFullWidth: false,
      ),
      KittingStep.split => AppButton(
        label: LocaleKeys.kitting_task_split_continue.tr(),
        icon: Icons.call_split,
        variant: AppButtonVariant.success,
        isFullWidth: false,
        onPressed: _openSplit,
      ),
      KittingStep.vanning => AppButton(
        label: LocaleKeys.kitting_task_save_vanning.tr(),
        icon: Icons.local_shipping_outlined,
        variant: AppButtonVariant.success,
        isFullWidth: false,
        isLoading: state.busy,
        onPressed: vanningReady ? _saveVanning : null,
      ),
      // Đã lưu vanning từ trước (vào lại xem) → chỉ đi tiếp.
      KittingStep.done => AppButton(
        label: LocaleKeys.kitting_task_done_continue.tr(),
        icon: Icons.check_rounded,
        variant: AppButtonVariant.success,
        isFullWidth: false,
        onPressed: _isPallet ? _backToRoute : _goNext,
      ),
    };

    return AppBottomHint(
      child: Row(
        children: [
          const BackIconButton(),
          const SizedBox(width: AppDimens.sm),
          Expanded(child: action),
        ],
      ),
    );
  }
}

/// "2/6" góc phải app bar — vị trí thứ mấy trên tuyến.
class _Counter extends StatelessWidget {
  final int index;
  final int total;

  const _Counter({required this.index, required this.total});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Padding(
      padding: const EdgeInsets.only(right: AppDimens.md),
      child: Center(
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 6),
          decoration: BoxDecoration(
            color: swms.card2,
            borderRadius: BorderRadius.circular(AppDimens.sm),
          ),
          child: Text.rich(
            TextSpan(
              children: [
                TextSpan(text: '$index'),
                TextSpan(
                  text: '/$total',
                  style: TextStyle(
                    color: swms.text4,
                    fontWeight: FontWeight.w500,
                  ),
                ),
              ],
            ),
            style: AppTextStyles.code.copyWith(
              fontSize: 13,
              letterSpacing: 0,
              fontWeight: FontWeight.w700,
              color: swms.text2,
            ),
          ),
        ),
      ),
    );
  }
}
