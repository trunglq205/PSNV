﻿using SWMS_WebTool.Models.Responses;

namespace SWMS_WebTool.ViewModels
{
    public class TrolleyKittingListViewModel
    {
    }
}
