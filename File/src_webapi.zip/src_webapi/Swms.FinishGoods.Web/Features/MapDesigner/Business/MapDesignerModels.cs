namespace Swms.FinishGoods.Web.Features.MapDesigner.Business.Models;

/// <summary>Khối trên bản đồ — dùng chung rack/pallet/zone.</summary>
public class MapBlockDto
{
    public long? Id { get; set; }
    public string Kind { get; set; } = "zone";     // rack | pallet | zone

    public long? RackId { get; set; }
    public string? RackCode { get; set; }
    public int? RackRows { get; set; }
    public int? RackCols { get; set; }

    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string? CurrentStatus { get; set; }

    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; } = 1;
    public int GridH { get; set; } = 1;

    public string? Label { get; set; }
    public string? Color { get; set; }
    public string? Arrow { get; set; }
    public int SortOrder { get; set; }
}

public class MapLayoutDto
{
    public long AreaId { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public string MapType { get; set; } = "storing";
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public List<MapBlockDto> Blocks { get; set; } = new();
}

public class CreateRackInputDto
{
    public string RackCode { get; set; } = string.Empty;
    public string? RackName { get; set; }
    public int Positions { get; set; } = 4;
    public int Floors { get; set; } = 4;
    public int[] ShelfPositions { get; set; } = Array.Empty<int>();
    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; } = 4;
    public int GridH { get; set; } = 2;
}
