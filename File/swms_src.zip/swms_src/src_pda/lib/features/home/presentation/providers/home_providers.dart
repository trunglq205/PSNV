import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/home/data/datasources/home_local_data_source.dart';
import 'package:swms_finish_goods/features/home/data/datasources/home_remote_data_source.dart';
import 'package:swms_finish_goods/features/home/data/home_repository_impl.dart';
import 'package:swms_finish_goods/features/home/domain/home_repository.dart';

part 'home_providers.g.dart';

@riverpod
HomeRemoteDataSource homeRemoteDataSource(Ref ref) {
  final dio = ref.watch(dioProvider);
  return HomeRemoteDataSource(dio);
}

@riverpod
HomeLocalDataSource homeLocalDataSource(Ref ref) {
  return HomeLocalDataSourceImpl(
    ref.watch(appLocalManagerProvider).requireValue,
  );
}

@riverpod
HomeRepository homeRepository(Ref ref) {
  return HomeRepositoryImpl(
    ref.watch(homeRemoteDataSourceProvider),
    ref.watch(homeLocalDataSourceProvider),
  );
}
