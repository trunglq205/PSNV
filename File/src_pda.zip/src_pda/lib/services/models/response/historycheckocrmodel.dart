import 'package:json_annotation/json_annotation.dart';
import 'package:smart_warehouse/services/models/request/receiving_card_model.dart';

import 'base_response_model.dart';

part 'historycheckocrmodel.g.dart';

@JsonSerializable()
class HistoryCheckOcrModel extends BaseResponseModel  {
  HistoryCheckOcrModel({

    required this.all,
    required this.checked,

  });

  factory HistoryCheckOcrModel.fromJson(Map<String, dynamic> json) =>
      _$HistoryCheckOcrModelFromJson(json);


  final String? all;
  final String? checked;


  @override
  Map<String, dynamic> toJson() => _$HistoryCheckOcrModelToJson(this);
}