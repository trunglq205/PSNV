import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_text_field.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_line.dart';
import 'package:swms_finish_goods/features/part_card/presentation/dialogs/adjust_value_dialog.dart';
import 'package:swms_finish_goods/features/part_card/presentation/dialogs/pick_origin_dialog.dart';
import 'package:swms_finish_goods/features/receiving/presentation/dialogs/category_picker.dart';

/// Bước 2: xác nhận thông tin lấy từ API, cho phép sửa nếu lệch thực tế.
///
/// **Controlled component** — toàn bộ dữ liệu do parent giữ; widget chỉ bắn
/// [onChanged] với bản [PartCardForm] mới. `ConsumerWidget` chỉ để mở dialog
/// chọn Cate (đọc danh mục từ API), không đọc state nào khác.
///
/// Chế độ [PartCardMode.multi] thêm PSNV PO / CUS PO và danh sách mã
/// (mỗi mã có Box · Qty · Origin riêng); [onAddModel] do notifier xử lý.
class PartCardConfirmBody extends ConsumerWidget {
  const PartCardConfirmBody({
    super.key,
    required this.form,
    required this.mode,
    required this.onChanged,
    this.onAddModel,
    this.lockLineQty = false,
  });

  final PartCardForm form;
  final PartCardMode mode;
  final ValueChanged<PartCardForm> onChanged;

  /// Mã vừa quét / nhập ở khung thêm mã — notifier thêm dòng.
  /// `null` = không cho thêm mã tay (vd màn gộp: dòng chỉ đến từ tem nguồn).
  final ValueChanged<String>? onAddModel;

  /// Khoá Qty + nút xoá dòng — tổng pcs phải khớp tem nguồn (màn gộp).
  /// Box / Origin / OQC vẫn sửa được (đóng lại thùng khi gộp).
  final bool lockLineQty;

  Future<void> _adjust(
      BuildContext context, {
        required String label,
        required String unit,
        required double value,
        required PartCardForm Function(double) apply,
        int decimalDigits = 1,
        double maxValue = 999,
      }) async {
    final result = await showAdjustValueDialog(
      context,
      label: label,
      unit: unit,
      value: value,
      decimalDigits: decimalDigits,
      maxValue: maxValue,
    );
    if (result != null) onChanged(apply(result));
  }

  Future<void> _editText(
      BuildContext context, {
        required String label,
        required String value,
        required PartCardForm Function(String) apply,
        bool allowEmpty = false,
      }) async {
    final result = await showEditTextDialog(
      context,
      label: label,
      value: value,
    );
    if (result == null) return;
    if (result.isEmpty && !allowEmpty) return;
    onChanged(apply(result));
  }

  Future<void> _pickDate(BuildContext context) async {
    final now = DateTime.now();
    final picked = await showDatePicker(
      context: context,
      initialDate: form.productionDate,
      firstDate: DateTime(now.year - 3),
      lastDate: DateTime(now.year + 1, 12, 31),
    );
    if (picked != null) onChanged(form.copyWith(productionDate: picked));
  }

  Future<void> _pickOrigin(BuildContext context) async {
    final result = await showPickOriginDialog(context, selected: form.origin);
    if (result != null) onChanged(form.copyWith(origin: result));
  }

  Future<void> _pickCategory(BuildContext context, WidgetRef ref) async {
    final result = await showPickCategoryDialog(
      context,
      ref,
      selected: form.category,
    );
    if (result != null) onChanged(form.copyWith(category: result));
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final missing = form.missingFields;

    return ListView(
      children: [
        if (missing.isNotEmpty) ...[
          _MissingBanner(fields: missing),
          const SizedBox(height: AppDimens.sm),
        ],

        if (mode.isMulti)
          ..._multiHeader(context, ref)
        else
          ..._singleHeader(context, ref, missing),

        const SizedBox(height: 12),

        // Length / Width / Height / Weight — 4 cột đều nhau (card-level)
        Row(
          children: [
            Expanded(
              child: _InfoCell(
                label: 'Length',
                value: formatDecimal(form.length),
                unit: 'cm',
                missing: missing.contains(PartCardField.length),
                onTap: () => _adjust(
                  context,
                  label: 'Length',
                  unit: 'cm',
                  value: form.length,
                  apply: (v) => form.copyWith(length: v),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _InfoCell(
                label: 'Width',
                value: formatDecimal(form.width),
                unit: 'cm',
                missing: missing.contains(PartCardField.width),
                onTap: () => _adjust(
                  context,
                  label: 'Width',
                  unit: 'cm',
                  value: form.width,
                  apply: (v) => form.copyWith(width: v),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _InfoCell(
                label: 'Height',
                value: formatDecimal(form.height),
                unit: 'cm',
                missing: missing.contains(PartCardField.height),
                onTap: () => _adjust(
                  context,
                  label: 'Height',
                  unit: 'cm',
                  value: form.height,
                  apply: (v) => form.copyWith(height: v),
                ),
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _InfoCell(
                label: 'Weight',
                value: form.weightText,
                unit: 'kg',
                missing: missing.contains(PartCardField.weight),
                onTap: () => _adjust(
                  context,
                  label: 'Weight',
                  unit: 'kg',
                  value: form.weight,
                  maxValue: 99,
                  decimalDigits: 3,
                  apply: (v) => form.copyWith(weight: v),
                ),
              ),
            ),
          ],
        ),

        const SizedBox(height: 12),

        if (mode.isMulti)
          _LinesSection(
            form: form,
            onChanged: onChanged,
            onAdd: onAddModel,
            lockQty: lockLineQty,
          )
        else
        // Production Date
          Row(
            children: [
              Expanded(
                child: _InfoCell(
                  label: 'Origin',
                  value: form.origin?.label ?? '',
                  missing: missing.contains(PartCardField.origin),
                  onTap: () => _pickOrigin(context),
                ),
              ),
              const SizedBox(width: 12),
              Expanded(
                child: _InfoCell(
                  label: 'Production Date',
                  value: form.productionDateText,
                  onTap: () => _pickDate(context),
                ),
              ),
            ],
          ),
        const SizedBox(height: AppDimens.sm),
        _EditHint(multi: mode.isMulti),
      ],
    );
  }

  // ── Header chế độ 1 mã ─────────────────────────────────────
  List<Widget> _singleHeader(
      BuildContext context,
      WidgetRef ref,
      List<String> missing,
      ) => [
    // Model : Cate = 2 : 1 — Model KHÓA (sửa nghĩa là quét sai model)
    Row(
      children: [
        Expanded(
          flex: 2,
          child: _InfoCell(label: 'Model', value: form.model, locked: true),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _InfoCell(
            label: 'Cate',
            value: form.categoryText ?? '',
            missing: missing.contains(PartCardField.cate),
            onTap: () => _pickCategory(context, ref),
          ),
        ),
      ],
    ),
    const SizedBox(height: 12),
    _InfoCell(
      label: 'Quantity',
      value: '${form.quantity}',
      unit: 'pcs',
      missing: missing.contains(PartCardField.qty),
      onTap: () => _adjust(
        context,
        label: 'Quantity',
        unit: 'pcs',
        value: form.quantity.toDouble(),
        maxValue: 9999,
        decimalDigits: 0,
        apply: (v) => form.copyWith(quantity: v.round()),
      ),
    ),
  ];

  // ── Header chế độ nhiều mã ─────────────────────────────────
  List<Widget> _multiHeader(BuildContext context, WidgetRef ref) => [
    Row(
      children: [
        Expanded(
          child: _InfoCell(
            label: LocaleKeys.part_card_field_psnv_po.tr(),
            value: form.psnvPo,
            onTap: () => _editText(
              context,
              label: LocaleKeys.part_card_field_psnv_po.tr(),
              value: form.psnvPo,
              allowEmpty: true,
              apply: (v) => form.copyWith(psnvPo: v),
            ),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _InfoCell(
            label: LocaleKeys.part_card_field_cus_po.tr(),
            value: form.cusPo,
            onTap: () => _editText(
              context,
              label: LocaleKeys.part_card_field_cus_po.tr(),
              value: form.cusPo,
              allowEmpty: true,
              apply: (v) => form.copyWith(cusPo: v),
            ),
          ),
        ),
      ],
    ),
    const SizedBox(height: 12),
    Row(
      children: [
        Expanded(
          child: _InfoCell(
            label: 'Cate',
            value: form.categoryText ?? '',
            missing: form.category == null,
            onTap: () => _pickCategory(context, ref),
          ),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: _InfoCell(
            label: LocaleKeys.part_card_field_mfd.tr(),
            value: form.productionDateText,
            onTap: () => _pickDate(context),
          ),
        ),
      ],
    ),
  ];
}

// ─────────────────────────────────────────────────────────────
//  Danh sách mã (chỉ chế độ nhiều mã)
// ─────────────────────────────────────────────────────────────
class _LinesSection extends StatelessWidget {
  const _LinesSection({
    required this.form,
    required this.onChanged,
    required this.onAdd,
    required this.lockQty,
  });

  final PartCardForm form;
  final ValueChanged<PartCardForm> onChanged;

  /// `null` = ẩn khung thêm mã.
  final ValueChanged<String>? onAdd;
  final bool lockQty;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Text(
          LocaleKeys.part_card_confirm_models_title.tr(
            namedArgs: {
              'count': '${form.lines.length}',
              'max': '${PartCardForm.maxLines}',
            },
          ),
          style: AppTextStyles.caption.copyWith(
            fontWeight: FontWeight.w800,
            letterSpacing: .3,
            color: swms.text3,
          ),
        ),
        const SizedBox(height: AppDimens.sm),

        for (var i = 0; i < form.lines.length; i++) ...[
          _LineCard(
            index: i,
            line: form.lines[i],
            canRemove: !lockQty && form.lines.length > 1,
            lockQty: lockQty,
            onChanged: (line) => onChanged(form.updateLineAt(i, line)),
            onRemove: () => onChanged(form.removeLineAt(i)),
          ),
          const SizedBox(height: 8),
        ],

        _TotalBar(box: form.totalBox, pcs: form.totalPcs),
        const SizedBox(height: AppDimens.md),

        if (onAdd case final onAdd?)
          if (form.canAddLine)
            _AddModelBox(onSubmit: onAdd)
          else
            const _FullNote(max: PartCardForm.maxLines),
      ],
    );
  }
}

/// Khung thêm mã — DÙNG LẠI cách nhập của bước 1: quét là chính, gõ tay là
/// đường lui. Máy PDA đang lắng nghe sẵn nên bóp cò là vào thẳng danh sách,
/// không phải mở dialog nào.
class _AddModelBox extends StatefulWidget {
  const _AddModelBox({required this.onSubmit});

  final ValueChanged<String> onSubmit;

  @override
  State<_AddModelBox> createState() => _AddModelBoxState();
}

class _AddModelBoxState extends State<_AddModelBox> {
  final TextEditingController _controller = TextEditingController();

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() {
    final value = _controller.text.trim();
    if (value.isEmpty) return;
    widget.onSubmit(value);
    _controller.clear();
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(
          color: swms.primary.withValues(alpha: .35),
          width: 1.2,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(Icons.add_rounded, size: 14, color: swms.primary),
              const SizedBox(width: 5),
              Text(
                LocaleKeys.part_card_confirm_add_model.tr().toUpperCase(),
                style: AppTextStyles.caption.copyWith(
                  fontSize: 10,
                  fontWeight: FontWeight.w800,
                  letterSpacing: .3,
                  color: swms.primary,
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimens.sm),

          BarcodeScannerButton(
            scanningLabel: LocaleKeys.part_card_input_scan_label.tr(),
          ),

          const SizedBox(height: AppDimens.sm),

          Row(
            children: [
              Expanded(child: Divider(color: swms.border)),
              Padding(
                padding: const EdgeInsets.symmetric(horizontal: AppDimens.sm),
                child: Text(
                  LocaleKeys.part_card_input_or.tr(),
                  style: AppTextStyles.caption.copyWith(
                    fontSize: 10,
                    fontWeight: FontWeight.w700,
                    letterSpacing: .5,
                    color: swms.text4,
                  ),
                ),
              ),
              Expanded(child: Divider(color: swms.border)),
            ],
          ),

          const SizedBox(height: AppDimens.sm),

          Row(
            children: [
              Expanded(
                child: AppTextField(
                  kind: AppInputKind.code,
                  controller: _controller,
                  hint: LocaleKeys.part_card_input_hint.tr(),
                  onSubmitted: (_) => _submit(),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Material(
                color: swms.primary,
                borderRadius: BorderRadius.circular(AppDimens.rInput),
                child: InkWell(
                  onTap: _submit,
                  borderRadius: BorderRadius.circular(AppDimens.rInput),
                  child: const SizedBox(
                    width: AppDimens.hitSm,
                    height: AppDimens.hitSm,
                    child: Icon(
                      Icons.arrow_forward_rounded,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Đã đủ số mã tối đa của template nhãn.
class _FullNote extends StatelessWidget {
  const _FullNote({required this.max});

  final int max;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 9),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Icon(Icons.info_outline_rounded, size: 13, color: swms.text3),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              LocaleKeys.part_card_confirm_models_full.tr(
                namedArgs: {'max': '$max'},
              ),
              style: AppTextStyles.caption.copyWith(
                fontSize: 10.5,
                height: 1.4,
                color: swms.text3,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 1 dòng mã: hàng trên = số thứ tự + model + nút xoá,
/// hàng dưới = Box · Qty · Origin (chạm để sửa).
class _LineCard extends StatelessWidget {
  const _LineCard({
    required this.index,
    required this.line,
    required this.canRemove,
    required this.lockQty,
    required this.onChanged,
    required this.onRemove,
  });

  final int index;
  final PartCardLine line;
  final bool canRemove;

  /// Qty chỉ xem, không sửa. Box vẫn sửa được.
  final bool lockQty;
  final ValueChanged<PartCardLine> onChanged;
  final VoidCallback onRemove;

  Future<void> _editNumber(
      BuildContext context, {
        required String label,
        required String unit,
        required int value,
        required double maxValue,
        required PartCardLine Function(int) apply,
      }) async {
    final result = await showAdjustValueDialog(
      context,
      label: label,
      unit: unit,
      value: value.toDouble(),
      decimalDigits: 0,
      maxValue: maxValue,
    );
    if (result != null) onChanged(apply(result.round()));
  }

  Future<void> _pickOrigin(BuildContext context) async {
    final result = await showPickOriginDialog(context, selected: line.origin);
    if (result != null) {
      onChanged(line.copyWith(origin: result));
    }
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(10, 8, 6, 10),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              SizedBox(
                width: 16,
                child: Text(
                  '${index + 1}',
                  style: AppTextStyles.caption.copyWith(
                    fontSize: 10,
                    fontWeight: FontWeight.w800,
                    color: swms.text4,
                  ),
                ),
              ),
              Expanded(
                child: Text(
                  line.model,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 12.5,
                    fontWeight: FontWeight.w800,
                    color: swms.text1,
                  ),
                ),
              ),
              if (line.isNewModel)
                Container(
                  margin: const EdgeInsets.only(left: 6),
                  padding: const EdgeInsets.symmetric(
                    horizontal: 5,
                    vertical: 2,
                  ),
                  decoration: BoxDecoration(
                    color: swms.card2,
                    borderRadius: BorderRadius.circular(4),
                    border: Border.all(color: swms.border),
                  ),
                  child: Text(
                    LocaleKeys.part_card_confirm_new_model.tr(),
                    style: AppTextStyles.caption.copyWith(
                      fontSize: 9,
                      fontWeight: FontWeight.w800,
                      color: swms.text3,
                    ),
                  ),
                ),
              InkWell(
                onTap: canRemove ? onRemove : null,
                borderRadius: BorderRadius.circular(AppDimens.sm),
                child: Padding(
                  padding: const EdgeInsets.all(6),
                  child: Icon(
                    Icons.close_rounded,
                    size: 15,
                    color: canRemove ? swms.danger : swms.text4,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              Expanded(
                child: _MiniCell(
                  label: LocaleKeys.part_card_field_box.tr(),
                  value: '${line.box}',
                  missing: line.box <= 0,
                  onTap: () => _editNumber(
                    context,
                    label: LocaleKeys.part_card_field_box.tr(),
                    unit: '',
                    value: line.box,
                    maxValue: 99,
                    apply: (v) => line.copyWith(box: v),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _MiniCell(
                  label: 'Qty',
                  value: '${line.quantity}',
                  missing: line.quantity <= 0,
                  onTap: lockQty ? null : () => _editNumber(
                    context,
                    label: 'Qty',
                    unit: 'pcs',
                    value: line.quantity,
                    maxValue: 9999,
                    apply: (v) => line.copyWith(quantity: v),
                  ),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: _MiniCell(
                  label: 'Origin',
                  value: line.origin?.label ?? '',
                  missing: line.origin == null,
                  onTap: () => _pickOrigin(context),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: _OqcCell(
                  checked: line.oqcChecked,
                  onTap: () =>
                      onChanged(line.copyWith(oqcChecked: !line.oqcChecked)),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniCell extends StatelessWidget {
  const _MiniCell({
    required this.label,
    required this.value,
    this.missing = false,
    this.onTap,
  }) : unit = '';

  final String label;
  final String value;
  final String unit;
  final bool missing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: swms.card2,
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          border: Border.all(
            color: missing ? swms.danger.withValues(alpha: .45) : swms.border,
            width: missing ? 1.2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.caption.copyWith(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: missing ? swms.danger : swms.text4,
              ),
            ),
            const SizedBox(height: 2),
            Text(
              unit.isEmpty ? value : '$value $unit',
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.code.copyWith(
                fontSize: 11.5,
                fontWeight: FontWeight.w700,
                color: missing ? swms.danger : swms.text1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

/// Dòng Total — đúng 2 số sẽ in ở đáy tem.
class _TotalBar extends StatelessWidget {
  const _TotalBar({required this.box, required this.pcs});

  final int box;
  final int pcs;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 9),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              LocaleKeys.part_card_confirm_total.tr().toUpperCase(),
              style: AppTextStyles.caption.copyWith(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: .3,
                color: swms.text3,
              ),
            ),
          ),
          Text(
            '$box ${LocaleKeys.part_card_field_box.tr()}  ·  $pcs pcs',
            style: AppTextStyles.code.copyWith(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: swms.text1,
            ),
          ),
        ],
      ),
    );
  }
}

/// Cảnh báo field API không trả / còn bằng 0.
class _MissingBanner extends StatelessWidget {
  const _MissingBanner({required this.fields});

  final List<String> fields;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 8),
      decoration: BoxDecoration(
        color: swms.dangerBg,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.danger.withValues(alpha: .25)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.error_outline_rounded, size: 14, color: swms.danger),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              LocaleKeys.part_card_confirm_missing.tr(
                namedArgs: {'fields': fields.join(', ')},
              ),
              style: AppTextStyles.caption.copyWith(
                fontSize: 11,
                fontWeight: FontWeight.w700,
                color: swms.danger,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _EditHint extends StatelessWidget {
  const _EditHint({required this.multi});

  final bool multi;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(top: 1),
          child: Icon(Icons.touch_app_outlined, size: 12, color: swms.primary),
        ),
        const SizedBox(width: 6),
        Expanded(
          child: Text(
            multi
                ? LocaleKeys.part_card_confirm_edit_hint_multi.tr()
                : LocaleKeys.part_card_confirm_edit_hint.tr(),
            style: AppTextStyles.caption.copyWith(
              fontSize: 10.5,
              height: 1.4,
              color: swms.text3,
            ),
          ),
        ),
      ],
    );
  }
}

/// Ô hiển thị 1 trường. Chạm để sửa (trừ khi [locked]).
class _InfoCell extends StatelessWidget {
  const _InfoCell({
    required this.label,
    required this.value,
    this.unit = '',
    this.locked = false,
    this.missing = false,
    this.onTap,
  });

  final String label;
  final String value;
  final String unit;
  final bool locked;
  final bool missing;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return GestureDetector(
      onTap: locked ? null : onTap,
      child: Container(
        foregroundDecoration: missing
            ? BoxDecoration(
          color: swms.danger.withValues(alpha: .06),
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          border: Border.all(
            color: swms.danger.withValues(alpha: .45),
            width: 1.2,
          ),
        )
            : null,
        child: AppCard(
          padding: const EdgeInsets.all(10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Row(
                children: [
                  Flexible(
                    child: Text(
                      label,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.caption.copyWith(
                        fontSize: 10,
                        fontWeight: FontWeight.w700,
                        color: missing ? swms.danger : swms.text3,
                      ),
                    ),
                  ),
                  const SizedBox(width: 4),
                  if (locked)
                    Icon(Icons.lock_outline, size: 11, color: swms.text4),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                value.isEmpty ? '—' : (unit.isEmpty ? value : '$value $unit'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.code.copyWith(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: missing
                      ? swms.danger
                      : (value.isEmpty ? swms.text4 : null),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Ô OQC của 1 dòng mã — chạm để bật/tắt.
/// Chưa check = tem in "X"; đã check = tem để trống.
class _OqcCell extends StatelessWidget {
  const _OqcCell({required this.checked, required this.onTap});

  final bool checked;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final color = checked ? swms.primary : swms.text4;

    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 6),
        decoration: BoxDecoration(
          color: checked ? swms.primary.withValues(alpha: .08) : swms.card2,
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          border: Border.all(
            color: checked ? swms.primary.withValues(alpha: .45) : swms.border,
            width: checked ? 1.2 : 1,
          ),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              'OQC',
              style: AppTextStyles.caption.copyWith(
                fontSize: 9,
                fontWeight: FontWeight.w700,
                color: color,
              ),
            ),
            const SizedBox(height: 2),
            SizedBox(
              height: 15,
              child: Icon(
                checked
                    ? Icons.check_box_rounded
                    : Icons.check_box_outline_blank_rounded,
                size: 15,
                color: color,
              ),
            ),
          ],
        ),
      ),
    );
  }
}