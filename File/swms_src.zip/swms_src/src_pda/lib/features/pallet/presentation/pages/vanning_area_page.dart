import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/features/pallet/presentation/pages/pallet_flow_page.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow.dart';

/// Khu tập kết (vanning) — quét pallet → gán / chuyển vào vị trí khu vanning.
@RoutePage()
class VanningAreaScreen extends StatelessWidget {
  /// Nếu truyền sẵn (từ Pallet Detail) thì tự lookup, bỏ bước quét.
  final String? lotNo;

  const VanningAreaScreen({super.key, this.lotNo});

  @override
  Widget build(BuildContext context) =>
      PalletFlowPage(flow: PalletFlow.vanningArea, lotNo: lotNo);
}