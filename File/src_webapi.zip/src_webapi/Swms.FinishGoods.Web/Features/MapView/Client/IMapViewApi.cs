using Refit;
using Swms.FinishGoods.Web.Features.MapView.Business.Models;

namespace Swms.FinishGoods.Web.Features.MapView.Client;

public interface IMapViewApi
{
    [Get("/api/map-view/{areaCode}")]
    Task<MapViewLayoutDto> GetAsync(string areaCode);
}
