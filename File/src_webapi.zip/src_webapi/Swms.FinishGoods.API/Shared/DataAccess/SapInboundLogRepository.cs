﻿using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

/// <summary>1 dòng wms.sap_inbound_logs.</summary>
public class SapInboundLog
{
    public string Endpoint { get; set; } = "";
    public string? DocNo { get; set; }
    public string? SiNo { get; set; }
    public string? RequestBody { get; set; }
    public int HttpStatus { get; set; }
    public string Result { get; set; } = "";     // created | updated | unchanged | rejected | error
    public long? SiId { get; set; }
    public string? ErrorMessage { get; set; }
    public string? RemoteIp { get; set; }
    public int DurationMs { get; set; }
    public DateTime ReceivedAt { get; set; }

    // Lịch sử thay đổi SI — service điền qua SapInboundAudit. Thời điểm = ReceivedAt.
    public string? ChangedBy { get; set; }       // người sửa (pic của payload)
    public string? ChangeSummary { get; set; }   // 1 dòng đọc được ngay
    public string? Changes { get; set; }         // JSON đầy đủ: header / lines / notes, kèm giá trị cũ -> mới
}

public interface ISapInboundLogRepository
{
    Task AddAsync(SapInboundLog log);

    /// <summary>Các lần SAP gửi của 1 SI, mới nhất trước (tối đa 200). Không kèm request_body.
    /// Gồm cả request bị từ chối chưa gắn được si_id nhưng trùng si_no.
    /// onlyChanges = true: chỉ lần tạo + các lần sửa thật.</summary>
    Task<List<SapInboundLog>> GetBySiAsync(long siId, string siNo, bool onlyChanges);
}

public class SapInboundLogRepository : ISapInboundLogRepository
{
    private readonly IDbConnectionFactory _factory;
    public SapInboundLogRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task AddAsync(SapInboundLog log)
    {
        using var conn = _factory.Create();
        const string sql = """
            INSERT INTO wms.sap_inbound_logs
                (endpoint, doc_no, si_no, request_body, http_status, result,
                 si_id, error_message, remote_ip, duration_ms, received_at,
                 changed_by, change_summary, changes)
            VALUES
                (@Endpoint, @DocNo, @SiNo, @RequestBody, @HttpStatus, @Result,
                 @SiId, @ErrorMessage, @RemoteIp, @DurationMs, @ReceivedAt,
                 @ChangedBy, @ChangeSummary, @Changes);
            """;
        await conn.ExecuteAsync(sql, log);
    }

    public async Task<List<SapInboundLog>> GetBySiAsync(long siId, string siNo, bool onlyChanges)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT TOP (200)
                   l.endpoint AS Endpoint, l.doc_no AS DocNo, l.si_no AS SiNo,
                   l.http_status AS HttpStatus, l.result AS Result, l.si_id AS SiId,
                   l.error_message AS ErrorMessage, l.duration_ms AS DurationMs, l.received_at AS ReceivedAt,
                   l.changed_by AS ChangedBy, l.change_summary AS ChangeSummary, l.changes AS Changes
            FROM wms.sap_inbound_logs l
            WHERE (l.si_id = @siId OR (l.si_id IS NULL AND l.si_no = @siNo))
              AND (@onlyChanges = 0 OR l.result IN ('created', 'updated'))
            ORDER BY l.received_at DESC;
            """;
        return (await conn.QueryAsync<SapInboundLog>(sql, new { siId, siNo, onlyChanges })).ToList();
    }
}