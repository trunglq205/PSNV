using Dapper;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.Api.Features.Roles.DataAccess;

/// <summary>
/// Đồng bộ <see cref="PermissionCatalog"/> (nguồn sự thật, file C#) xuống DB.
/// Idempotent: chạy mỗi lần khởi động đều an toàn.
///   • Upsert module/screen/permission theo code (giữ id ổn định cho FK).
///   • Soft-delete (is_deleted=1) những bản ghi không còn trong catalog.
/// DB chỉ lưu code + quan hệ + sort_order — KHÔNG lưu tên hiển thị.
/// </summary>
public class PermissionCatalogSeeder
{
    private readonly IDbConnectionFactory _factory;
    public PermissionCatalogSeeder(IDbConnectionFactory factory) => _factory = factory;

    public async Task SyncAsync()
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var moduleCodes = new List<string>();
            var screenCodes = new List<string>();
            var permCodes = new List<string>();

            int mOrder = 0;
            foreach (var m in PermissionCatalog.Modules)
            {
                mOrder++;
                moduleCodes.Add(m.Code);
                var moduleId = await UpsertModuleAsync(conn, tx, m.Code, mOrder);

                int sOrder = 0;
                foreach (var s in m.Screens)
                {
                    sOrder++;
                    screenCodes.Add(s.Code);
                    var screenId = await UpsertScreenAsync(conn, tx, s.Code, moduleId, sOrder);

                    int pOrder = 0;
                    foreach (var p in s.Permissions)
                    {
                        pOrder++;
                        permCodes.Add(p.Code);
                        await UpsertPermissionAsync(conn, tx, p.Code, p.Action, screenId, pOrder);
                    }
                }
            }

            // Vô hiệu hóa những gì không còn trong catalog (soft delete)
            await DeactivateMissingAsync(conn, tx,
                "master.permissions", "code", permCodes);
            await DeactivateMissingAsync(conn, tx,
                "master.permission_screens", "code", screenCodes);
            await DeactivateMissingAsync(conn, tx,
                "master.permission_modules", "code", moduleCodes);

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    private static async Task<long> UpsertModuleAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx, string code, int sortOrder)
    {
        const string sql = """
            MERGE master.permission_modules AS t
            USING (SELECT @code AS code) AS src ON t.code = src.code
            WHEN MATCHED THEN
                UPDATE SET sort_order = @sortOrder, is_deleted = 0
            WHEN NOT MATCHED THEN
                INSERT (code, sort_order) VALUES (@code, @sortOrder);
            SELECT id FROM master.permission_modules WHERE code = @code;
            """;
        return await conn.ExecuteScalarAsync<long>(sql, new { code, sortOrder }, tx);
    }

    private static async Task<long> UpsertScreenAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx,
        string code, long moduleId, int sortOrder)
    {
        const string sql = """
            MERGE master.permission_screens AS t
            USING (SELECT @code AS code) AS src ON t.code = src.code
            WHEN MATCHED THEN
                UPDATE SET module_id = @moduleId, sort_order = @sortOrder, is_deleted = 0
            WHEN NOT MATCHED THEN
                INSERT (module_id, code, sort_order) VALUES (@moduleId, @code, @sortOrder);
            SELECT id FROM master.permission_screens WHERE code = @code;
            """;
        return await conn.ExecuteScalarAsync<long>(sql, new { code, moduleId, sortOrder }, tx);
    }

    private static async Task UpsertPermissionAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx,
        string code, string action, long screenId, int sortOrder)
    {
        const string sql = """
            MERGE master.permissions AS t
            USING (SELECT @code AS code) AS src ON t.code = src.code
            WHEN MATCHED THEN
                UPDATE SET screen_id = @screenId, action = @action,
                           sort_order = @sortOrder, is_deleted = 0
            WHEN NOT MATCHED THEN
                INSERT (screen_id, action, code, sort_order)
                VALUES (@screenId, @action, @code, @sortOrder);
            """;
        await conn.ExecuteAsync(sql, new { code, action, screenId, sortOrder }, tx);
    }

    private static async Task DeactivateMissingAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx,
        string table, string keyCol, List<string> keepCodes)
    {
        // keepCodes luôn có phần tử (catalog không rỗng) nên IN (@keep) an toàn
        var sql = $"""
            UPDATE {table} SET is_deleted = 1
            WHERE is_deleted = 0 AND {keyCol} NOT IN @keep;
            """;
        await conn.ExecuteAsync(sql, new { keep = keepCodes }, tx);
    }
}

public static class PermissionCatalogSeederExtensions
{
    /// <summary>Gọi trong Program.cs sau khi build app: await app.SyncPermissionCatalogAsync();</summary>
    public static async Task SyncPermissionCatalogAsync(this IServiceProvider services)
    {
        using var scope = services.CreateScope();
        var seeder = scope.ServiceProvider.GetRequiredService<PermissionCatalogSeeder>();
        await seeder.SyncAsync();
    }
}
