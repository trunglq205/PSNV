import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/stocktake/data/models/stocktake_models.dart';

part 'stocktake_remote_data_source.g.dart';

@RestApi()
abstract class StocktakeRemoteDataSource {
  factory StocktakeRemoteDataSource(Dio dio, {String baseUrl}) =
      _StocktakeRemoteDataSource;

  /// Danh sách phiếu kiểm kê (lọc theo loại: morning | monthly | shipment).
  @GET('/api/stocktake/counts')
  Future<List<CountSummaryModel>> fetchCounts({@Query('type') String? type});

  /// Chi tiết 1 phiếu: header + các dòng.
  @GET('/api/stocktake/counts/{id}')
  Future<CountDetailModel> fetchCount(@Path('id') int id);

  /// Nhập/sửa số đếm cho 1 dòng.
  @POST('/api/stocktake/counts/lines/{lineId}/count')
  Future<void> setCount(
      @Path('lineId') int lineId, @Body() SetCountRequestModel body);

  /// Đóng phiếu.
  @POST('/api/stocktake/counts/{id}/close')
  Future<void> closeCount(@Path('id') int id);

  /// Ghi pallet phát sinh tại một ô (pallet có thật nhưng hệ thống không ghi ở ô này).
  @POST('/api/stocktake/counts/{id}/found')
  Future<AddFoundResultModel> addFound(
      @Path('id') int id, @Body() AddFoundRequestModel body);
}
