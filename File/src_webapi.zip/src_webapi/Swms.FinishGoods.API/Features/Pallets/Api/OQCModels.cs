using Swms.FinishGoods.API.Features.Pallets.Business;
using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.Pallets.Api
{
    // ── Request ───────────────────────────────────────────────

    /// <summary>
    /// OQC lấy mẫu: rút một số box khỏi pallet đưa đi kiểm.
    /// - serial | box_line: gửi BoxIds (bắt buộc), SampleBoxCount bỏ qua.
    /// - box_count: gửi SampleBoxCount (bắt buộc), BoxIds cấm (không có box vật lý).
    /// </summary>
    public record OqcSampleRequest(
        IReadOnlyList<long>? BoxIds,
        int? SampleBoxCount,
        [MaxLength(200)] string? Remark);

    /// <summary>
    /// OQC trả hàng: trả các mẫu đang giữ về pallet + ghi kết quả kiểm.
    /// Result bắt buộc: pass | ng.
    /// </summary>
    public record OqcReturnRequest(
        [Required, MaxLength(20)] string Result,
        [MaxLength(200)] string? Remark);

    // ── Response ──────────────────────────────────────────────

    /// <summary>Kết quả lấy mẫu: trạng thái kiểm mới của lot + danh sách box đã rút.</summary>
    public record OqcSampleResponse(
        long LotId,
        string LotNo,
        string InspectionStatus,
        IReadOnlyList<long> SampledBoxIds,
        int SampleCount);

    /// <summary>Kết quả trả hàng: trạng thái kiểm cuối (pass|ng) + danh sách box đã trả.</summary>
    public record OqcReturnResponse(
        long LotId,
        string LotNo,
        string Result,
        string InspectionStatus,
        IReadOnlyList<long> ReturnedBoxIds,
        int ReturnedCount);

    // ── Error codes ───────────────────────────────────────────

    /// <summary>Mã lỗi nghiệp vụ của luồng OQC (lấy mẫu / trả hàng).</summary>
    public static class OqcErrors
    {
        // Lấy mẫu
        public const string AlreadyInspected = "Lot.Oqc.AlreadyInspected";      // 422
        public const string SampleAlreadyTaken = "Lot.Oqc.SampleAlreadyTaken";  // 409
        public const string BoxNotInLot = "Lot.Oqc.BoxNotInLot";                // 422
        public const string BoxIdsRequired = "Lot.Oqc.BoxIdsRequired";          // 422
        public const string BoxIdsNotAllowed = "Lot.Oqc.BoxIdsNotAllowed";      // 422
        public const string SampleBoxCountRequired = "Lot.Oqc.SampleBoxCountRequired"; // 422

        // Trả hàng
        public const string NotUnderInspection = "Lot.Oqc.NotUnderInspection";  // 422
        public const string ResultInvalid = "Lot.Oqc.ResultInvalid";            // 422
        public const string NoSampleToReturn = "Lot.Oqc.NoSampleToReturn";      // 422
    }
}
