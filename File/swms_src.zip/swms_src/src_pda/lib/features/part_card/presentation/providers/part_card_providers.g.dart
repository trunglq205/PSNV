// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'part_card_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(partCardRemoteDataSource)
final partCardRemoteDataSourceProvider = PartCardRemoteDataSourceProvider._();

final class PartCardRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          PartCardRemoteDataSource,
          PartCardRemoteDataSource,
          PartCardRemoteDataSource
        >
    with $Provider<PartCardRemoteDataSource> {
  PartCardRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'partCardRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$partCardRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<PartCardRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  PartCardRemoteDataSource create(Ref ref) {
    return partCardRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PartCardRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PartCardRemoteDataSource>(value),
    );
  }
}

String _$partCardRemoteDataSourceHash() =>
    r'e75832072e6914f7f1452de2284f096988739d43';

@ProviderFor(partCardRepository)
final partCardRepositoryProvider = PartCardRepositoryProvider._();

final class PartCardRepositoryProvider
    extends
        $FunctionalProvider<
          PartCardRepository,
          PartCardRepository,
          PartCardRepository
        >
    with $Provider<PartCardRepository> {
  PartCardRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'partCardRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$partCardRepositoryHash();

  @$internal
  @override
  $ProviderElement<PartCardRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  PartCardRepository create(Ref ref) {
    return partCardRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PartCardRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PartCardRepository>(value),
    );
  }
}

String _$partCardRepositoryHash() =>
    r'640d955c11b59e04d31cad20d71bd24031ec390c';
