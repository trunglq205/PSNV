using Swms.FinishGoods.API.Features.ReturnInstructions.Business;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions;

public static class ReturnInstructionModule
{
    public static IServiceCollection AddReturnInstructionFeature(this IServiceCollection services)
    {
        services.AddScoped<IReturnInstructionService, ReturnInstructionService>();
        services.AddScoped<IReturnInstructionRepository, ReturnInstructionRepository>();

        // Mục 2c — chỉ thị back hàng (4 bước duyệt).
        services.AddScoped<IReturnBackRequestService, ReturnBackRequestService>();
        services.AddScoped<IReturnBackRequestRepository, ReturnBackRequestRepository>();

        // Mục 2d — FA đóng lại Pallet ID. File của mục này đã có trong source
        // nên phải đăng ký, không thì ReturnFaPalletsController chết lúc
        // resolve dependency.
        services.AddScoped<IReturnFaPalletService, ReturnFaPalletService>();

        return services;
    }
}

// ServiceCollectionExtensions.AddFeatures():
//   .AddReturnInstructionFeature()
