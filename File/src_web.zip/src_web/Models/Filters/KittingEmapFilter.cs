﻿namespace SWMS_WebTool.Models.Filters
{
    public class KittingEmapFilter : BaseFilter
    {
        public KittingTab SelectedTab { get; set; } = KittingTab.KittingFA;
        public string? PIC { get; set; }
        public KittingType? KittingType { get; set; }
        public DateTime? Date { get; set; } = DateTime.Now;
    }
}
