// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'printer_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// MỘT driver cho MỖI ngôn ngữ (family theo [PrinterLanguage]).
///
/// keepAlive: driver giữ hàng đợi job nội bộ để chống double-tap.
/// Nếu để autoDispose, hàng đợi bị reset mỗi lần rời màn hình.

@ProviderFor(printer)
final printerProvider = PrinterFamily._();

/// MỘT driver cho MỖI ngôn ngữ (family theo [PrinterLanguage]).
///
/// keepAlive: driver giữ hàng đợi job nội bộ để chống double-tap.
/// Nếu để autoDispose, hàng đợi bị reset mỗi lần rời màn hình.

final class PrinterProvider
    extends $FunctionalProvider<Printer, Printer, Printer>
    with $Provider<Printer> {
  /// MỘT driver cho MỖI ngôn ngữ (family theo [PrinterLanguage]).
  ///
  /// keepAlive: driver giữ hàng đợi job nội bộ để chống double-tap.
  /// Nếu để autoDispose, hàng đợi bị reset mỗi lần rời màn hình.
  PrinterProvider._({
    required PrinterFamily super.from,
    required PrinterLanguage super.argument,
  }) : super(
         retry: null,
         name: r'printerProvider',
         isAutoDispose: false,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$printerHash();

  @override
  String toString() {
    return r'printerProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $ProviderElement<Printer> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  Printer create(Ref ref) {
    final argument = this.argument as PrinterLanguage;
    return printer(ref, argument);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(Printer value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<Printer>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is PrinterProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$printerHash() => r'1d024ecd92cd12eba2fa5b29ee569f17b3c9b128';

/// MỘT driver cho MỖI ngôn ngữ (family theo [PrinterLanguage]).
///
/// keepAlive: driver giữ hàng đợi job nội bộ để chống double-tap.
/// Nếu để autoDispose, hàng đợi bị reset mỗi lần rời màn hình.

final class PrinterFamily extends $Family
    with $FunctionalFamilyOverride<Printer, PrinterLanguage> {
  PrinterFamily._()
    : super(
        retry: null,
        name: r'printerProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: false,
      );

  /// MỘT driver cho MỖI ngôn ngữ (family theo [PrinterLanguage]).
  ///
  /// keepAlive: driver giữ hàng đợi job nội bộ để chống double-tap.
  /// Nếu để autoDispose, hàng đợi bị reset mỗi lần rời màn hình.

  PrinterProvider call(PrinterLanguage language) =>
      PrinterProvider._(argument: language, from: this);

  @override
  String toString() => r'printerProvider';
}

@ProviderFor(bluetoothDiscovery)
final bluetoothDiscoveryProvider = BluetoothDiscoveryProvider._();

final class BluetoothDiscoveryProvider
    extends
        $FunctionalProvider<
          BluetoothDiscovery,
          BluetoothDiscovery,
          BluetoothDiscovery
        >
    with $Provider<BluetoothDiscovery> {
  BluetoothDiscoveryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'bluetoothDiscoveryProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$bluetoothDiscoveryHash();

  @$internal
  @override
  $ProviderElement<BluetoothDiscovery> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  BluetoothDiscovery create(Ref ref) {
    return bluetoothDiscovery(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(BluetoothDiscovery value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<BluetoothDiscovery>(value),
    );
  }
}

String _$bluetoothDiscoveryHash() =>
    r'eb3791f317cca162a8a5c0a2cd6bf5a95ff4870f';

/// Danh sách máy in đã ghép đôi. autoDispose để mỗi lần mở màn hình chọn
/// máy in là đọc lại — công nhân có thể vừa pair thêm máy trong Settings.
///
/// Mỗi thiết bị được điền [PrinterLanguage] ĐOÁN theo tên; UI chọn máy
/// phải cho người dùng sửa lại trước khi [SelectedPrinter.select].

@ProviderFor(pairedPrinters)
final pairedPrintersProvider = PairedPrintersProvider._();

/// Danh sách máy in đã ghép đôi. autoDispose để mỗi lần mở màn hình chọn
/// máy in là đọc lại — công nhân có thể vừa pair thêm máy trong Settings.
///
/// Mỗi thiết bị được điền [PrinterLanguage] ĐOÁN theo tên; UI chọn máy
/// phải cho người dùng sửa lại trước khi [SelectedPrinter.select].

final class PairedPrintersProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<PrinterDevice>>,
          List<PrinterDevice>,
          FutureOr<List<PrinterDevice>>
        >
    with
        $FutureModifier<List<PrinterDevice>>,
        $FutureProvider<List<PrinterDevice>> {
  /// Danh sách máy in đã ghép đôi. autoDispose để mỗi lần mở màn hình chọn
  /// máy in là đọc lại — công nhân có thể vừa pair thêm máy trong Settings.
  ///
  /// Mỗi thiết bị được điền [PrinterLanguage] ĐOÁN theo tên; UI chọn máy
  /// phải cho người dùng sửa lại trước khi [SelectedPrinter.select].
  PairedPrintersProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'pairedPrintersProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$pairedPrintersHash();

  @$internal
  @override
  $FutureProviderElement<List<PrinterDevice>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<PrinterDevice>> create(Ref ref) {
    return pairedPrinters(ref);
  }
}

String _$pairedPrintersHash() => r'aaf204c8c6375d9c8939e77b1dffce705a59da75';

/// Lưu MAC + ngôn ngữ sau lần chọn đầu để công nhân không phải chọn lại
/// mỗi phiên.

@ProviderFor(SelectedPrinter)
final selectedPrinterProvider = SelectedPrinterProvider._();

/// Lưu MAC + ngôn ngữ sau lần chọn đầu để công nhân không phải chọn lại
/// mỗi phiên.
final class SelectedPrinterProvider
    extends $NotifierProvider<SelectedPrinter, PrinterDevice?> {
  /// Lưu MAC + ngôn ngữ sau lần chọn đầu để công nhân không phải chọn lại
  /// mỗi phiên.
  SelectedPrinterProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'selectedPrinterProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$selectedPrinterHash();

  @$internal
  @override
  SelectedPrinter create() => SelectedPrinter();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PrinterDevice? value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PrinterDevice?>(value),
    );
  }
}

String _$selectedPrinterHash() => r'cd9bcd62f67fa00a1325621d65b49bf7e24ea9fb';

/// Lưu MAC + ngôn ngữ sau lần chọn đầu để công nhân không phải chọn lại
/// mỗi phiên.

abstract class _$SelectedPrinter extends $Notifier<PrinterDevice?> {
  PrinterDevice? build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<PrinterDevice?, PrinterDevice?>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<PrinterDevice?, PrinterDevice?>,
              PrinterDevice?,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}

/// UI không biết SATO, không biết TSPL, không biết Bluetooth.
///
/// Driver chọn theo `language` của máy in đang chọn; tem tự sinh lệnh
/// đúng ngôn ngữ qua [Label.toBytes].
///
/// Trạng thái in nằm luôn trong [state]:
/// - `isLoading` → đang in, disable nút
/// - `hasError`  → lỗi, đọc `error` để hiện message

@ProviderFor(PrintController)
final printControllerProvider = PrintControllerProvider._();

/// UI không biết SATO, không biết TSPL, không biết Bluetooth.
///
/// Driver chọn theo `language` của máy in đang chọn; tem tự sinh lệnh
/// đúng ngôn ngữ qua [Label.toBytes].
///
/// Trạng thái in nằm luôn trong [state]:
/// - `isLoading` → đang in, disable nút
/// - `hasError`  → lỗi, đọc `error` để hiện message
final class PrintControllerProvider
    extends $AsyncNotifierProvider<PrintController, void> {
  /// UI không biết SATO, không biết TSPL, không biết Bluetooth.
  ///
  /// Driver chọn theo `language` của máy in đang chọn; tem tự sinh lệnh
  /// đúng ngôn ngữ qua [Label.toBytes].
  ///
  /// Trạng thái in nằm luôn trong [state]:
  /// - `isLoading` → đang in, disable nút
  /// - `hasError`  → lỗi, đọc `error` để hiện message
  PrintControllerProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'printControllerProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$printControllerHash();

  @$internal
  @override
  PrintController create() => PrintController();
}

String _$printControllerHash() => r'55f346aff4413b21d7f30a8d4e31be03ef2918ca';

/// UI không biết SATO, không biết TSPL, không biết Bluetooth.
///
/// Driver chọn theo `language` của máy in đang chọn; tem tự sinh lệnh
/// đúng ngôn ngữ qua [Label.toBytes].
///
/// Trạng thái in nằm luôn trong [state]:
/// - `isLoading` → đang in, disable nút
/// - `hasError`  → lỗi, đọc `error` để hiện message

abstract class _$PrintController extends $AsyncNotifier<void> {
  FutureOr<void> build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<AsyncValue<void>, void>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<AsyncValue<void>, void>,
              AsyncValue<void>,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
