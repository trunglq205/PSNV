﻿using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Scan.DataAccess
{
    /// <summary>
    /// Tra mã quét để phân loại (pallet/box/serial/vị trí).
    /// Pattern thu hẹp bảng cần tra — KHÔNG quét toàn DB.
    /// </summary>
    public interface IScanRepository
    {
        Task<ScanHit?> FindLotAsync(string code);
        Task<ScanHit?> FindBoxAsync(string code);
        Task<ScanHit?> FindSerialAsync(string code);
        Task<ScanHit?> FindRecvLocatorAsync(string code);
        Task<ScanHit?> FindStorageLocatorAsync(string code);
        Task<ScanHit?> FindModelAsync(string code);
        Task<PartCardScanHit?> FindPartCardAsync(string payload);
    }

    /// <summary>Một dòng tìm thấy: id + mã gốc (+ khu nếu là vị trí).</summary>
    public sealed record ScanHit(long Id, string Code, string? AreaCode);

    /// <summary>
    /// Phiếu Part Card tìm theo payload — đủ dữ liệu để app biết được Sửa / Tách / Gộp.
    /// Class (không phải record positional) để Dapper map theo tên cột.
    /// </summary>
    public sealed class PartCardScanHit
    {
        public long Id { get; set; }
        public string Payload { get; set; } = "";
        public bool IsOverseaService { get; set; }
        public bool IsLocked { get; set; }
        public int StatusOqc { get; set; }
        /// <summary>Số dòng hàng (phiếu oversea); phiếu thường coi là 1 mã.</summary>
        public int RowCount { get; set; }
        /// <summary>inner_box của dòng đầu — số thùng khi phiếu chỉ có 1 dòng.</summary>
        public string? FirstInnerBox { get; set; }
    }

    public class ScanRepository : IScanRepository
    {
        private readonly IDbConnectionFactory _factory;
        public ScanRepository(IDbConnectionFactory factory) => _factory = factory;

        public async Task<ScanHit?> FindLotAsync(string code)
        {
            using var conn = _factory.Create();
            const string sql = """
                SELECT TOP 1 id AS Id, pallet_id AS Code, CAST(NULL AS NVARCHAR(20)) AS AreaCode
                FROM wms.pallets
                WHERE pallet_id = @code AND is_deleted = 0;
                """;
            return await conn.QueryFirstOrDefaultAsync<ScanHit>(sql, new { code });
        }

        public async Task<ScanHit?> FindBoxAsync(string code)
        {
            using var conn = _factory.Create();
            const string sql = """
                SELECT TOP 1 b.id AS Id, b.box_no AS Code, CAST(NULL AS NVARCHAR(20)) AS AreaCode
                FROM wms.boxes b
                WHERE b.raw_payload = @code AND b.is_deleted = 0;
                """;
            return await conn.QueryFirstOrDefaultAsync<ScanHit>(sql, new { code });
        }

        public async Task<ScanHit?> FindSerialAsync(string code)
        {
            using var conn = _factory.Create();
            const string sql = """
                SELECT TOP 1 bl.id AS Id, bl.serial_no AS Code, CAST(NULL AS NVARCHAR(20)) AS AreaCode
                FROM wms.box_lines bl
                WHERE bl.serial_no = @code AND bl.is_deleted = 0;
                """;
            return await conn.QueryFirstOrDefaultAsync<ScanHit>(sql, new { code });
        }

        public async Task<ScanHit?> FindModelAsync(string code)
        {
            using var conn = _factory.Create();
            // Model: khớp theo code hoặc gtin (mã vạch thương mại).
            const string sql = """
                SELECT TOP 1 m.id AS Id, m.code AS Code, CAST(NULL AS NVARCHAR(20)) AS AreaCode
                FROM master.models m
                WHERE (m.code = @code OR m.gtin = @code) AND m.is_deleted = 0
                ORDER BY CASE WHEN m.code = @code THEN 0 ELSE 1 END;
                """;
            return await conn.QueryFirstOrDefaultAsync<ScanHit>(sql, new { code });
        }

        public async Task<PartCardScanHit?> FindPartCardAsync(string payload)
        {
            using var conn = _factory.Create();
            // payload là varchar(500): truyền DbString IsAnsi để SQL so varchar = varchar,
            // không convert ngầm cả cột sang nvarchar (mất seek index).
            // Trùng payload (hiếm) → lấy phiếu mới nhất, khớp cách tách / gộp chọn phiếu nguồn.
            const string sql = """
                SELECT TOP 1
                    c.id AS Id, c.payload AS Payload,
                    c.is_oversea_service AS IsOverseaService,
                    c.is_locked AS IsLocked,
                    CAST(ISNULL(c.Status_OQC, 0) AS int) AS StatusOqc,
                    (SELECT COUNT(*) FROM wms.part_card_rows r
                      WHERE r.part_card_id = c.id) AS [RowCount],
                    (SELECT TOP 1 r.inner_box FROM wms.part_card_rows r
                      WHERE r.part_card_id = c.id ORDER BY r.line_no) AS FirstInnerBox
                FROM wms.part_cards c
                WHERE c.payload = @payload AND c.is_deleted = 0
                ORDER BY c.id DESC;
                """;
            return await conn.QueryFirstOrDefaultAsync<PartCardScanHit>(sql, new
            {
                payload = new DbString { Value = payload, IsAnsi = true, Length = 500 },
            });
        }

        public async Task<ScanHit?> FindRecvLocatorAsync(string code)
        {
            using var conn = _factory.Create();
            // Vị trí phẳng (RECV / Vanning) — bảng master.locators, khu lấy từ warehouse_areas.
            const string sql = """
                SELECT TOP 1 loc.id AS Id, loc.locator_code AS Code, a.area_code AS AreaCode
                FROM master.locators loc
                LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id AND a.is_deleted = 0
                WHERE loc.locator_code = @code AND loc.is_deleted = 0;
                """;
            return await conn.QueryFirstOrDefaultAsync<ScanHit>(sql, new { code });
        }

        public async Task<ScanHit?> FindStorageLocatorAsync(string code)
        {
            using var conn = _factory.Create();
            // Vị trí rack nhiều tầng — nay dùng chung bảng master.locators (đã gộp sau tái kiến trúc);
            // phân biệt recv/rack ở tầng ScanService qua regex pattern của mã quét.
            const string sql = """
                SELECT TOP 1 loc.id AS Id, loc.locator_code AS Code, a.area_code AS AreaCode
                FROM master.locators loc
                LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id AND a.is_deleted = 0
                WHERE loc.locator_code = @code AND loc.is_deleted = 0;
                """;
            return await conn.QueryFirstOrDefaultAsync<ScanHit>(sql, new { code });
        }
    }
}