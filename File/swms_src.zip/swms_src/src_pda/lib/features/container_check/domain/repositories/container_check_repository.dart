import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';

abstract interface class ContainerCheckRepository {
  /// Container đang trong ca: chờ kiểm, đang đóng, vừa hoàn thành.
  Future<List<ContainerItem>> getContainers();

  /// Tra theo số container khi QR quét được không có trong danh sách đang
  /// hiển thị (danh sách cũ, hoặc container của ca khác).
  Future<ContainerItem> getByContainerNo(String containerNo);

  Future<ContainerItem> getDetail(int containerId);

  /// Chốt kết quả kiểm kèm ảnh.
  Future<void> submitInspection(ContainerInspection inspection);
}
