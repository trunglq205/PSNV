﻿using System.Security.Claims;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Router chọn nguồn quyền theo cách principal được xác thực:
///  - API key (claim "auth_method" = "apikey")  → đọc quyền từ claim "perm"
///    (ClaimsUserPermissionProvider), KHÔNG chạm DB.
///  - User thường (đăng nhập JWT)               → đọc quyền như cấu hình hiện tại
///    (DbCachedUserPermissionProvider hoặc Claims tùy dự án).
///
/// Nhờ vậy API key mang quyền qua claim vẫn qua được PermissionAuthorizationHandler
/// mà không cần user thật trong bảng master.users.
/// </summary>
public sealed class CompositeUserPermissionProvider : IUserPermissionProvider
{
    public const string ApiKeyAuthMethodClaim = "auth_method";
    public const string ApiKeyAuthMethodValue = "apikey";

    private readonly ClaimsUserPermissionProvider _claims;
    private readonly DbCachedUserPermissionProvider _db;

    public CompositeUserPermissionProvider(
        ClaimsUserPermissionProvider claims,
        DbCachedUserPermissionProvider db)
    {
        _claims = claims;
        _db = db;
    }

    public Task<IReadOnlySet<string>> GetPermissionsAsync(ClaimsPrincipal user)
        => IsApiKey(user)
            ? _claims.GetPermissionsAsync(user)   // API key: quyền nằm trong claim
            : _db.GetPermissionsAsync(user);      // user thường: quyền từ DB (giữ nguyên hành vi cũ)

    private static bool IsApiKey(ClaimsPrincipal user)
        => user.HasClaim(ApiKeyAuthMethodClaim, ApiKeyAuthMethodValue);
}