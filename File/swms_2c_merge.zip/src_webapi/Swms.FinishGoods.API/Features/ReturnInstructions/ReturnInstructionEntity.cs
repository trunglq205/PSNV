namespace Swms.FinishGoods.API.Features.ReturnInstructions;

/// <summary>
/// Chỉ thị back hàng (<c>wms.return_instructions</c>) — SCS Office ghi nhận
/// thông tin khách hàng báo trả hàng về PSNV: model nào, bao nhiêu, về ngày nào.
///
/// Phiếu này là GỐC của cả luồng return / refurbish: mục 2 đối chiếu số lượng
/// thực nhận với <see cref="Lines"/>, mục 7 phát sinh SI đuôi -RE / -R theo
/// <see cref="GoodsType"/> của chính phiếu.
/// </summary>
public class ReturnInstruction
{
    public long Id { get; set; }

    /// <summary>
    /// Sinh ở server. Tiền tố nói luôn loại hàng:
    /// <c>RW-yyyyMMdd-###</c> (rework) | <c>RB-yyyyMMdd-###</c> (refurbish).
    /// </summary>
    public string DocNo { get; set; } = string.Empty;

    /// <summary>
    /// MỘT PHIẾU MỘT LOẠI: <c>rework</c> | <c>refurbish</c>.
    ///
    /// Nằm ở phiếu chứ không ở dòng. Khách báo cả hai loại trong một lần thì
    /// SCS Office tạo hai phiếu — nhờ vậy số phiếu nói luôn loại, và bước 7
    /// (SI đuôi -RE / -R định tuyến theo loại) bám thẳng vào phiếu được.
    /// </summary>
    public string GoodsType { get; set; } = string.Empty;

    public string? Customer { get; set; }

    /// <summary>Ngày hàng dự kiến về PSNV, theo thông tin khách hàng.</summary>
    public DateTime? ExpectedDate { get; set; }

    /// <summary><c>open</c> | <c>completed</c> | <c>cancelled</c>.</summary>
    public string DocStatus { get; set; } = ReturnDocStatus.Open;

    public string? Note { get; set; }

    /// <summary>
    /// Đã báo FA lúc nào. NULL = chưa gửi được — mail bị tắt
    /// (<c>Mail:Enabled</c>), hoặc chưa khai người nhận trong
    /// <c>master.email_config</c>. Tạo phiếu KHÔNG hỏng vì mail hỏng.
    /// </summary>
    public DateTime? MailSentAt { get; set; }
    public string? MailSentTo { get; set; }

    /// <summary>
    /// WH đã chốt SL thực nhận lúc nào (mục 2b). NULL = chưa chốt.
    ///
    /// Tách khỏi <see cref="DocStatus"/> dù chốt là đóng phiếu: Office mở lại
    /// phiếu thì trạng thái về <c>open</c>, còn mốc chốt lần trước vẫn đọc được
    /// để biết FA đã nhận số nào.
    /// </summary>
    public DateTime? ClosedAt { get; set; }
    public string? ClosedBy { get; set; }

    /// <summary>
    /// Đã báo FA SỐ THỰC NHẬN lúc nào. Khác <see cref="MailSentAt"/> (mail lúc
    /// TẠO phiếu) — "FA đã biết phiếu" và "FA đã biết số thực nhận" là hai việc.
    /// </summary>
    public DateTime? ActualMailSentAt { get; set; }
    public string? ActualMailSentTo { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    // ─────────────────────────────────────────────────────────────
    //  LUỒNG NHẬN LẠI HÀNG VỀ FA (mục 2c) — gộp vào chính phiếu này.
    //
    //  Vì sao gộp chứ không để bảng đề nghị riêng: hàng về nhiều đợt thì mỗi
    //  đợt một chỉ thị, nên MỘT PHIẾU CHỈ CÓ MỘT LUỒNG BACK. Bảng riêng chỉ
    //  thêm một số phiếu (BK-…) để người ta phải đối chiếu, và một bảng dòng
    //  model + SL mà từ lúc chốt "lấy là lấy hết" thì chỉ còn là ẢNH CHỤP của
    //  sổ serial — ảnh chụp không ai sửa được thì chỉ còn mỗi việc lệch dần.
    //
    //  KHÔNG có cột "bước đang chờ": với ba bước thì bước suy được từ
    //  <see cref="BackStatus"/> một-đối-một (xem <see cref="BackStep"/>). Hai
    //  cột nói cùng một việc là hai cột sớm muộn lệch nhau.
    // ─────────────────────────────────────────────────────────────

    /// <summary>
    /// NULL = FA chưa đề nghị nhận lại hàng. Ngoài ra:
    /// <c>fa_requested</c> | <c>fa_approved</c> | <c>delivered</c> | <c>cancelled</c>.
    /// </summary>
    public string? BackStatus { get; set; }

    /// <summary>Ghi chú của FA lúc đề nghị.</summary>
    public string? BackNote { get; set; }

    public string? BackRequestedBy { get; set; }
    public DateTime? BackRequestedAt { get; set; }

    /// <summary>Quản lý FA xác nhận — mốc lá mail sang SCS Office đi.</summary>
    public string? BackApprovedBy { get; set; }
    public DateTime? BackApprovedAt { get; set; }
    public string? BackFaComment { get; set; }

    /// <summary>SCS WH bấm xác nhận ở lượt giao làm XONG cả phiếu.</summary>
    public string? BackDeliveredBy { get; set; }
    public DateTime? BackDeliveredAt { get; set; }
    public string? BackScsComment { get; set; }

    public string? BackCancelledBy { get; set; }
    public DateTime? BackCancelledAt { get; set; }
    public string? BackCancelReason { get; set; }

    // ── Bốn con số của luồng back ──
    //
    // Repository ĐẾM TỪ SỔ SERIAL rồi gán vào, không lưu cột tổng nào trên
    // header. Lưu sẵn là phải nhớ cập nhật ở mọi đường ghi, và chỉ cần quên
    // một đường là tổng sai vĩnh viễn — đúng lỗi đã xảy ra với bảng đề nghị cũ.

    /// <summary>Còn ở kho SCS, chưa giao lần nào: <c>status = 'received'</c>.</summary>
    public int BackRemainQty { get; set; }

    /// <summary>
    /// Đã TỪNG giao sang FA: <c>sent_fa_at IS NOT NULL</c>.
    ///
    /// Bám mốc thời gian chứ không bám <c>status = 'at_fa'</c>: hàng giao rồi
    /// FA trả lại hết (mục 3) thì status về <c>returned</c>, mà lượt giao đó
    /// vẫn đã xảy ra.
    /// </summary>
    public int BackSentQty { get; set; }

    /// <summary>Đang ở FA lúc này: <c>status = 'at_fa'</c>.</summary>
    public int AtFaQty { get; set; }

    /// <summary>FA đã trả về SCS: <c>status = 'returned'</c>.</summary>
    public int BackReturnedQty { get; set; }

    public List<ReturnInstructionLine> Lines { get; set; } = [];

    /// <summary>Tổng SL kỳ vọng của cả phiếu — dùng ở danh sách và trong mail.</summary>
    public int TotalQty => Lines.Sum(l => l.Qty);

    /// <summary>
    /// Tổng SL THỰC NHẬN = số serial đã đăng ký vào phiếu (mục 2a). Suy ra từ
    /// dòng chứ không lưu trên header, cùng lý do với <see cref="TotalQty"/>.
    /// </summary>
    public int ReceivedQty => Lines.Sum(l => l.ReceivedQty);

    /// <summary>
    /// Đã nhận nhiều hơn chỉ thị ở ít nhất một model. KHÔNG phải lỗi: hàng về
    /// nhiều hơn khách báo là chuyện thường, và mục 2b có nhiệm vụ mail cho FA
    /// đúng số thực tế. Màn hình chỉ cần hiện cảnh báo.
    /// </summary>
    public bool OverReceived => Lines.Any(l => l.ReceivedQty > l.Qty);

    /// <summary>
    /// Đã nhận ÍT hơn chỉ thị ở ít nhất một model. Cũng không phải lỗi — khách
    /// báo 100 mà về 94 là chuyện thường; việc của hệ thống là báo FA số thực.
    /// </summary>
    public bool ShortReceived => Lines.Any(l => l.ReceivedQty < l.Qty);

    /// <summary>
    /// Lệch của cả phiếu = thực nhận − chỉ thị. Dương là nhận vượt, âm là thiếu.
    ///
    /// Tính từ hai con số chứ KHÔNG ghi SL thực nhận đè lên
    /// <c>return_instruction_lines.qty</c>: qty là mốc để so, ghi đè nó là mất
    /// luôn cái để so và từ đó bảng lệch luôn báo 0.
    /// </summary>
    public int DiffQty => ReceivedQty - TotalQty;

    /// <summary>Đã chốt thực nhận. Mở lại phiếu KHÔNG xoá mốc này.</summary>
    public bool IsClosed => ClosedAt is not null;

    /// <summary>
    /// Số model trong phiếu. Mỗi dòng đúng một model (unique theo
    /// <c>(doc_id, model)</c>) nên đếm dòng chính là đếm model — đặt tên theo
    /// thứ người dùng đọc, không theo cách lưu.
    /// </summary>
    public int ModelCount => Lines.Count;

    // ── Luồng back: trạng thái suy ra ──

    /// <summary>FA đã đề nghị nhận lại hàng (kể cả đã xong hoặc đã huỷ).</summary>
    public bool BackRequested => BackStatus is not null;

    public bool BackIsCancelled => BackStatus == ReturnBackStatus.Cancelled;

    /// <summary>Đã giao xong — không còn con nào ở kho để giao.</summary>
    public bool BackIsDelivered => BackStatus == ReturnBackStatus.Delivered;

    /// <summary>Luồng back đang chạy, chưa xong chưa huỷ.</summary>
    public bool BackIsOpen => BackRequested && !BackIsDelivered && !BackIsCancelled;

    /// <summary>
    /// Đã giao được con nào nhưng chưa xong. Đây là mốc KHÔNG CÒN HUỶ ĐƯỢC:
    /// hàng đã ở FA thì huỷ là để lại một lô hàng ở FA không ai đứng tên.
    /// </summary>
    public bool BackIsPartlyDelivered => !BackIsDelivered && BackSentQty > 0;

    /// <summary>
    /// Bước đang chờ ai — SUY RA từ <see cref="BackStatus"/>, không phải cột.
    ///
    /// Trả <c>null</c> khi FA chưa đề nghị gì: màn hình cần phân biệt "chưa ai
    /// đề nghị" với "đang chờ quản lý FA", mà một chuỗi rỗng thì không nói
    /// được chuyện đó.
    /// </summary>
    public string? BackStep => BackStatus switch
    {
        ReturnBackStatus.FaRequested => ReturnBackStep.FaApprove,
        ReturnBackStatus.FaApproved => ReturnBackStep.ScsDeliver,
        ReturnBackStatus.Delivered or ReturnBackStatus.Cancelled => ReturnBackStep.Done,
        _ => null,
    };

    /// <summary>
    /// FA có thể đề nghị nhận lại hàng được chưa: phiếu chưa huỷ, CÒN hàng ở
    /// kho, và chưa có luồng back nào đang chạy hoặc đã xong.
    ///
    /// Huỷ rồi thì đề nghị LẠI được — huỷ là đổi ý, không phải cấm vĩnh viễn.
    /// </summary>
    public bool CanRequestBack
        => DocStatus != ReturnDocStatus.Cancelled
           && BackRemainQty > 0
           && (BackStatus is null || BackIsCancelled);
}

/// <summary>Một dòng model + số lượng trong chỉ thị (<c>wms.return_instruction_lines</c>).</summary>
public class ReturnInstructionLine
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public int LineNo { get; set; }

    /// <summary>Khớp <c>master.models.code</c> — service kiểm trước khi ghi.</summary>
    public string Model { get; set; } = string.Empty;

    public int Qty { get; set; }
    public string? Note { get; set; }

    /// <summary>
    /// SL thực nhận = số serial của model này đã đăng ký trong
    /// <c>wms.return_instruction_serials</c>. KHÔNG phải cột trong bảng dòng:
    /// repository đếm sang bảng sổ serial rồi gán vào đây.
    ///
    /// Lưu sẵn một con số đếm được là phải nhớ cập nhật ở mọi đường ghi serial
    /// (nhận hàng, giao FA, nhận lại, xuất) — quên một đường là lệch vĩnh viễn.
    /// </summary>
    public int ReceivedQty { get; set; }

    /// <summary>Còn phải nhận bao nhiêu. Âm thì đã nhận vượt — xem OverReceived.</summary>
    public int RemainingQty => Qty - ReceivedQty;

    /// <summary>
    /// Lệch của dòng = thực nhận − chỉ thị. Dương là vượt, âm là thiếu, 0 là đủ.
    ///
    /// Cùng con số với <see cref="RemainingQty"/> nhưng ĐỔI DẤU, và để riêng có
    /// chủ ý: màn hình đọc "còn phải nhận 6" khi đang nhận, còn bảng đối chiếu
    /// và mail báo FA đọc "lệch −6". Bắt một chỗ tự đổi dấu của chỗ kia là nơi
    /// sớm muộn sẽ có người quên.
    /// </summary>
    public int DiffQty => ReceivedQty - Qty;
}

/// <summary>
/// Một serial hàng return đã đăng ký vào phiếu
/// (<c>wms.return_instruction_serials</c>).
///
/// Đây là SỔ của phiếu, không phải ảnh chụp pallet: một serial sẽ đi qua nhiều
/// Pallet ID trong suốt chu trình (WH nhận → giao FA → FA trả → xuất), còn
/// dòng sổ này thì sống từ lúc quét tới lúc xuất xong.
/// </summary>
public class ReturnSerial
{
    public long Id { get; set; }
    public long DocId { get; set; }

    /// <summary>Khớp model của một dòng trong phiếu.</summary>
    public string Model { get; set; } = string.Empty;

    public string SerialNo { get; set; } = string.Empty;

    /// <summary>Mã thùng lúc nhận. NULL khi hàng về rời, không có thùng để quét.</summary>
    public string? BoxNo { get; set; }

    /// <summary>Id <c>wms.pallets</c> ĐANG giữ serial (không phải pallet_id dạng chuỗi).</summary>
    public long? PalletDbId { get; set; }

    /// <summary>Mã pallet dạng người đọc — JOIN sang <c>wms.pallets.pallet_id</c>.</summary>
    public string? PalletNo { get; set; }

    public string Status { get; set; } = ReturnSerialStatus.Received;

    public DateTime ReceivedAt { get; set; }
    public string? CreatedBy { get; set; }
}

/// <summary>
/// Một pallet hàng return của phiếu — gom từ sổ serial, không phải một bảng.
/// </summary>
public class ReturnPallet
{
    public long Id { get; set; }
    public string LotNo { get; set; } = string.Empty;
    public string? LocatorCode { get; set; }
    public int SerialCount { get; set; }
    public int BoxCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }

    /// <summary>Model → số serial trên pallet này.</summary>
    public Dictionary<string, int> ModelCounts { get; set; } = [];
}

/// <summary>
/// Trạng thái của MỘT serial trong chu trình return. Khai đủ ngay từ mục 2a để
/// các mục sau không phải ALTER bảng; CHECK của
/// <c>wms.return_instruction_serials</c> giữ đúng bộ giá trị này.
/// </summary>
public static class ReturnSerialStatus
{
    /// <summary>WH đã nhận vào kho SCS. Mục 2a chỉ sinh ra giá trị này.</summary>
    public const string Received = "received";

    /// <summary>Đã giao sang FA (mục 2c / 3).</summary>
    public const string AtFa = "at_fa";

    /// <summary>FA đã trả về SCS (mục 5).</summary>
    public const string Returned = "returned";

    /// <summary>Đã xuất cho khách (mục 10).</summary>
    public const string Shipped = "shipped";

    /// <summary>Kiểm lại không đạt (nhánh NG của mục 5).</summary>
    public const string Ng = "ng";

    public static bool IsValid(string? s) =>
        s is Received or AtFa or Returned or Shipped or Ng;
}

/// <summary>
/// Giá trị cột <c>wms.return_instructions.back_status</c>.
///
/// NULL (không có hằng nào ở đây) = FA chưa đề nghị gì. Dùng <c>null</c> chứ
/// không thêm một hằng <c>"none"</c>: một dòng chưa bước vào luồng thì không
/// có trạng thái, mà đặt tên cho cái không có là mời người ta đi lọc nó.
/// </summary>
public static class ReturnBackStatus
{
    /// <summary>B1 xong — đang chờ quản lý FA xác nhận.</summary>
    public const string FaRequested = "fa_requested";

    /// <summary>B2 xong — đang chờ SCS WH giao hàng.</summary>
    public const string FaApproved = "fa_approved";

    /// <summary>B3 xong — không còn con nào ở kho để giao.</summary>
    public const string Delivered = "delivered";

    public const string Cancelled = "cancelled";

    public static bool IsValid(string? s) =>
        s is FaRequested or FaApproved or Delivered or Cancelled;
}

/// <summary>
/// Bước đang chờ ai. KHÔNG phải cột trong DB — suy ra từ
/// <see cref="ReturnBackStatus"/> (xem <c>ReturnInstruction.BackStep</c>).
///
/// Vẫn để thành hằng vì web lọc hàng đợi theo đúng ba chuỗi này, và một chuỗi
/// gõ tay ở hai phía là một tab rỗng không báo lỗi gì.
/// </summary>
public static class ReturnBackStep
{
    public const string FaApprove = "fa_approve";
    public const string ScsDeliver = "scs_deliver";
    public const string Done = "done";

    public static bool IsValid(string? s) =>
        s is FaApprove or ScsDeliver or Done;
}

/// <summary>
/// Một lượt SCS WH quét pallet giao hàng cho FA
/// (<c>wms.return_back_deliveries</c>).
///
/// Bảng DUY NHẤT còn lại của luồng back sau khi gộp, và nó phải ở lại: giao
/// dần nhiều lượt thì không có nó thì không ai trả lời được "đã đẩy những
/// pallet nào rồi".
/// </summary>
public class ReturnBackDelivery
{
    public long Id { get; set; }
    public long DocId { get; set; }

    /// <summary>
    /// Khoá của pallet lúc giao. NULL khi pallet đã bị tách / gộp / xoá sau đó
    /// — dòng nhật ký vẫn phải còn, nên bảng KHÔNG đặt FK sang wms.pallets.
    /// </summary>
    public long? PalletId { get; set; }

    /// <summary>Pallet ID dạng chữ, giữ lại kể cả khi pallet không còn.</summary>
    public string LotNo { get; set; } = string.Empty;

    /// <summary>Số serial chuyển được ở riêng pallet này, trong riêng lượt này.</summary>
    public int SerialCount { get; set; }

    public DateTime DeliveredAt { get; set; }
    public string? DeliveredBy { get; set; }
}

/// <summary>
/// SL còn ở kho của một model trong phiếu.
///
/// Đặt ở namespace CHA (<c>…ReturnInstructions</c>), không ở
/// <c>…DataAccess</c>: Api và DataAccess là hai namespace CON ngang hàng nên
/// không thấy nhau, và lần trước để ở DataAccess đã cho CS0246 ngay tại
/// <c>BackRemainModelResponse.From</c>. Một type "một model một số lượng" cũng
/// không thuộc riêng tầng nào.
///
/// Khai CLASS có property set được, không dùng positional record: mọi type
/// Dapper map trong solution này đều là class như vậy, và record positional
/// cần Dapper khớp đúng tên tham số constructor — một thứ dễ vỡ im lặng khi ai
/// đó đổi alias trong câu SQL.
/// </summary>
public class BackModelQty
{
    public string Model { get; set; } = string.Empty;
    public int Qty { get; set; }
}

/// <summary>
/// Kết quả MỘT lượt quét giao hàng.
///
/// <see cref="NotFoundLots"/> là mã quét ra mà hệ thống không có,
/// <see cref="Pallets"/> có <c>SerialCount = 0</c> là pallet có thật nhưng
/// không còn con nào của phiếu. Tách hai thứ vì cách xử lý khác nhau: cái đầu
/// là quét sai, cái sau là pallet đã rỗng.
/// </summary>
public class ReturnBackDeliverResult
{
    /// <summary>Phiếu không tồn tại / đã bị xoá mềm.</summary>
    public bool NotFound { get; set; }

    /// <summary>Phiếu không ở bước SCS giao hàng — ai đó vừa xử lý trước.</summary>
    public bool WrongStep { get; set; }

    public List<string> NotFoundLots { get; set; } = [];
    public List<ReturnBackDelivery> Pallets { get; set; } = [];

    /// <summary>Tổng số serial chuyển được trong LƯỢT NÀY.</summary>
    public int DeliveredQty { get; set; }

    /// <summary>Còn bao nhiêu con ở kho sau lượt này.</summary>
    public int RemainQty { get; set; }

    /// <summary>Lượt này làm xong cả phiếu — đây là lúc gửi mail cho FA.</summary>
    public bool Completed { get; set; }

    public bool AnyMoved => DeliveredQty > 0;
}

/// <summary>
/// Loại hàng trả về. Để hằng chuỗi vì giá trị này đi thẳng vào cột
/// <c>nvarchar</c>, và cũng là hậu tố khoá dịch (<c>Return.GoodsType.*</c>).
///
/// ⚠ TRÙNG CÓ CHỦ Ý với <c>wms.pallets.disposition</c>. Mục 2 phải đối chiếu
/// dòng chỉ thị với pallet WH đã tạo, và bản đồ kho đã vẽ badge RW/RE theo
/// đúng hai chuỗi này — đặt bộ từ vựng thứ hai là chuốc thêm một lớp quy đổi
/// và sớm muộn sẽ lệch.
/// </summary>
public static class ReturnGoodsType
{
    /// <summary>Hàng rework. SI xuất mang đuôi <c>-RE</c>.</summary>
    public const string Rework = "rework";

    /// <summary>Hàng refurbish. SI xuất mang đuôi <c>-R</c>.</summary>
    public const string Refurbish = "refurbish";

    public static bool IsValid(string? s) => s is Rework or Refurbish;

    /// <summary>
    /// Tiền tố số phiếu theo loại. Giữ ở ĐÂY cạnh chính hai hằng loại hàng:
    /// thêm loại thứ ba mà quên tiền tố thì lỗi lộ ra ngay tại đây, thay vì
    /// âm thầm sinh ra một phiếu mang tiền tố của loại khác.
    /// </summary>
    public static string DocPrefix(string goodsType) => goodsType switch
    {
        Rework => "RW",
        Refurbish => "RB",
        _ => throw new ArgumentOutOfRangeException(nameof(goodsType), goodsType,
            "Loại hàng không hợp lệ — không suy ra được tiền tố số phiếu."),
    };
}

/// <summary>
/// Trạng thái phiếu. Mục 1 chỉ sinh ra <see cref="Open"/>; hai giá trị còn lại
/// đã khai sẵn trong CHECK của bảng để mục 2 trở đi không phải ALTER.
/// </summary>
public static class ReturnDocStatus
{
    /// <summary>Đang theo dõi — hàng chưa về đủ.</summary>
    public const string Open = "open";

    /// <summary>Đã nhận đủ hàng.</summary>
    public const string Completed = "completed";

    public const string Cancelled = "cancelled";

    public static bool IsValid(string? s) => s is Open or Completed or Cancelled;
}
