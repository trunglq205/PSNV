using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Json.Serialization;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Business;

/*  Lịch sử thay đổi SI do SAP gửi.

    SAP có thể gửi cùng 1 si_no nhiều lần (sửa lại cùng revision, hoặc lên revision mới).
    Mỗi lần nhận, service so phiếu đang có với payload mới -> SiChangeSet.

    Ai ghi log?  SapInboundLogFilter — nó bọc ngoài request nên thấy body thô, mã HTTP, lỗi,
    nhưng KHÔNG thấy bên trong service đã đổi gì.
    SapInboundAudit là tờ ghi chú service để lại cho filter (scoped: 1 request = 1 instance):
    service điền "ai sửa, đổi gì", filter đọc và ghi vào changed_by / change_summary / changes
    của wms.sap_inbound_logs — cùng dòng với payload gốc. Xem lịch sử 1 SI = lọc log theo si_no. */

/// <summary>Ghi chú service để lại cho SapInboundLogFilter. Không tự ghi DB.</summary>
public class SapInboundAudit
{
    public const string Created = "created";
    public const string Updated = "updated";
    public const string Unchanged = "unchanged";

    /// <summary>created | updated | unchanged; null = request bị từ chối trước khi ghi được gì.</summary>
    public string? Action { get; set; }

    /// <summary>Phiếu bị tác động. Có cả khi request bị từ chối sau khi đã tìm ra phiếu.</summary>
    public long? SiId { get; set; }

    /// <summary>Người sửa = pic trong payload SAP.</summary>
    public string? ChangedBy { get; set; }

    /// <summary>1 dòng đọc được ngay trong lưới log, tối đa 500 ký tự.</summary>
    public string? ChangeSummary { get; set; }
    /// <summary>Chi tiết đầy đủ (JSON của SiChangeSet).</summary>
    public string? ChangesJson { get; set; }
}

public record SiFieldChange(string Field, string? Old, string? New);

/// <summary>Action: added | removed | changed.</summary>
public record SiLineChange(
    string Action, int LineNo, string Model, string? PackingListNo, string? PackingItemNo,
    int QtyRequired, List<SiFieldChange> Fields);

public class SiChangeSet
{
    public List<SiFieldChange> Header { get; } = new();
    public List<SiLineChange> Lines { get; } = new();
    /// <summary>Điều mapper đã tự xử lý (vd. bỏ dòng trùng).</summary>
    public List<string> Notes { get; } = new();

    [JsonIgnore] public bool HasChanges => Header.Count > 0 || Lines.Count > 0;

    // header_note thô: luôn đổi theo revision ("Ver: REV2…") nên chỉ báo khi không còn gì khác đổi.
    private static readonly string[] RawNoteFields = { "note.note_raw", "note.qr_raw" };

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase,
        Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping,   // giữ tiếng Việt, không \uXXXX
    };

    public string ToJson() => JsonSerializer.Serialize(this, JsonOptions);

    /// <summary>"revision: REV1 → REV2; vanning_date: 2026-10-13 → 2026-10-14; dòng 1 (NE-…) qty_required: 340 → 400"</summary>
    public string? Summary(int maxLength = 500)
    {
        static string V(string? v) => string.IsNullOrEmpty(v) ? "∅" : v;

        var parts = new List<string>();
        parts.AddRange(Header.Select(c => $"{c.Field}: {V(c.Old)} → {V(c.New)}"));
        foreach (var l in Lines)
        {
            parts.Add(l.Action switch
            {
                "added" => $"+ dòng {l.LineNo} ({l.Model}) qty {l.QtyRequired}",
                "removed" => $"− dòng {l.LineNo} ({l.Model}) qty {l.QtyRequired}",
                _ => $"dòng {l.LineNo} ({l.Model}) "
                     + string.Join(", ", l.Fields.Select(c => $"{c.Field}: {V(c.Old)} → {V(c.New)}")),
            });
        }
        parts.AddRange(Notes);
        if (parts.Count == 0) return null;

        var text = string.Join("; ", parts);
        return text.Length <= maxLength ? text : text[..(maxLength - 1)] + "…";
    }

    // ── So sánh header ──────────────────────────────────────
    /// <summary>Ảnh chụp các trường header theo thứ tự hiển thị. Gọi trước và sau khi áp payload.</summary>
    public static List<(string Field, string? Value)> Snapshot(SiHeader h)
    {
        static string? D(DateTime? d) => d?.ToString("yyyy-MM-dd");
        static string? B(bool? b) => b is null ? null : b.Value ? "true" : "false";

        var list = new List<(string, string?)>
        {
            ("doc_no", h.DocNo),
            ("revision", h.Revision),
            ("ship_mode", h.ShipMode),
            ("etd_date", D(h.EtdDate)),
            ("eta_date", D(h.EtaDate)),
            ("vanning_date", D(h.VanningDate)),
            ("cut_off_at", h.CutOffAt?.ToString("yyyy-MM-dd HH:mm")),
            ("port_of_loading", h.PortOfLoading),
            ("port_of_discharge", h.PortOfDischarge),
            ("country_code", h.CountryCode),
            ("forwarder_code", h.ForwarderCode),
            ("carrier_code", h.CarrierCode),
            ("consignee_code", h.ConsigneeCode),
            ("packing_type", h.PackingType),
            ("is_white_film", B(h.IsWhiteFilm)),
            ("is_case_mark", B(h.IsCaseMark)),
            ("is_serial_required", B(h.IsSerialRequired)),
            ("pic_name", h.PicName),
        };
        list.AddRange(HeaderNoteJson.Read(h.HeaderNote)
            .OrderBy(kv => kv.Key, StringComparer.Ordinal)
            .Select(kv => ($"note.{kv.Key}", (string?)kv.Value)));
        return list;
    }

    public void AddHeaderDiff(List<(string Field, string? Value)> before, List<(string Field, string? Value)> after)
    {
        var old = before.ToDictionary(x => x.Field, x => x.Value);
        var cur = after.ToDictionary(x => x.Field, x => x.Value);

        // Giữ thứ tự của "after", rồi tới các khoá note đã bị bỏ
        foreach (var field in after.Select(x => x.Field).Concat(before.Select(x => x.Field)).Distinct())
        {
            old.TryGetValue(field, out var o);
            cur.TryGetValue(field, out var n);
            if (!Same(o, n)) Header.Add(new SiFieldChange(field, Blank(o), Blank(n)));
        }
    }

    /// <summary>Gọi sau khi đã thêm đủ header + line: bỏ thay đổi note thô nếu còn thay đổi thật khác.</summary>
    public void DropRawNoteNoise()
    {
        var hasReal = Lines.Count > 0 || Header.Any(c => !RawNoteFields.Contains(c.Field));
        if (hasReal) Header.RemoveAll(c => RawNoteFields.Contains(c.Field));
    }

    // ── So sánh dòng ────────────────────────────────────────
    /// <summary>Các trường SAP gửi cho 1 dòng. Rỗng = dòng không đổi.</summary>
    public static List<SiFieldChange> DiffLine(SiLine old, SiLine cur)
    {
        var fields = new List<SiFieldChange>();
        void Add(string field, string? o, string? n)
        {
            if (!Same(o, n)) fields.Add(new SiFieldChange(field, Blank(o), Blank(n)));
        }
        Add("qty_required", old.QtyRequired.ToString(), cur.QtyRequired.ToString());
        Add("po_no", old.PoNo, cur.PoNo);
        Add("invoice_no", old.InvoiceNo, cur.InvoiceNo);
        Add("so_no", old.SoNo, cur.SoNo);
        Add("so_item_no", old.SoItemNo, cur.SoItemNo);
        Add("uom", old.Uom, cur.Uom);
        return fields;
    }

    public void AddLine(string action, SiLine l, List<SiFieldChange>? fields = null)
        => Lines.Add(new SiLineChange(action, l.LineNo, l.Model, l.PackingListNo, l.PackingItemNo,
                                      l.QtyRequired, fields ?? new()));

    private static string? Blank(string? v) => string.IsNullOrWhiteSpace(v) ? null : v.Trim();
    private static bool Same(string? a, string? b) => string.Equals(Blank(a), Blank(b), StringComparison.Ordinal);
}