﻿using SWMS_WebTool.Models.Layout;

namespace SWMS_API.SWMS.Core.BusinessDomain
{
    public class MinHeap<T> where T : Node
    {
        private List<T> elements = new List<T>();

        public void Add(T element)
        {
            elements.Add(element);
            HeapifyUp();
        }

        public T Remove()
        {
            if (IsEmpty) return null;
            if (elements.Count == 1)
            {
                var lastElement = elements[0];
                elements.Clear();
                return lastElement;
            };
            T root = elements[0];
            elements[0] = elements[^1];
            elements.RemoveAt(elements.Count - 1);
            HeapifyDown();
            return root;
        }

        public bool IsEmpty => elements.Count == 0;

        public bool Contains(T element) => elements.Contains(element);

        private void HeapifyUp()
        {
            int index = elements.Count - 1;
            while (index > 0)
            {
                int parentIndex = (index - 1) / 2;
                if (elements[index].FCost >= elements[parentIndex].FCost) break;
                Swap(index, parentIndex);
                index = parentIndex;
            }
        }

        private void HeapifyDown()
        {
            int index = 0;
            while (index < elements.Count)
            {
                int leftChildIndex = 2 * index + 1;
                int rightChildIndex = 2 * index + 2;
                int smallestIndex = index;

                if (leftChildIndex < elements.Count &&
                    elements[leftChildIndex].FCost < elements[smallestIndex].FCost)
                {
                    smallestIndex = leftChildIndex;
                }

                if (rightChildIndex < elements.Count &&
                    elements[rightChildIndex].FCost < elements[smallestIndex].FCost)
                {
                    smallestIndex = rightChildIndex;
                }

                if (smallestIndex == index) break;
                Swap(index, smallestIndex);
                index = smallestIndex;
            }
        }

        private void Swap(int indexA, int indexB)
        {
            T temp = elements[indexA];
            elements[indexA] = elements[indexB];
            elements[indexB] = temp;
        }
    }
    public class Pathfinding
    {
        private List<List<Node>> grid;
        private MinHeap<Node> openList;
        private HashSet<Node> closedList;

        public Pathfinding(List<List<Node>> grid)
        {
            this.grid = grid;
        }

        public (List<Node> OptimalPath, List<Node> VisitedWaypoints) FindOptimalPath(Node start, Node end, List<Node> waypoints)
        {
            // Nếu không có dữ liệu trong cache, thực hiện tính toán
            List<Node> optimalPath = new List<Node>();
            List<Node> visitedWaypoints = new List<Node>();
            HashSet<Node> visited = new HashSet<Node>();
            Node currentNode = start;
            optimalPath.Add(currentNode);

            while (visited.Count < waypoints.Count + 1)
            {
                Node nearestNode = null;
                int shortestDistance = int.MaxValue;

                foreach (Node waypoint in waypoints)
                {
                    if (!visited.Contains(waypoint))
                    {
                        int distance = GetDistance(currentNode, waypoint);
                        if (distance < shortestDistance)
                        {
                            shortestDistance = distance;
                            nearestNode = waypoint;
                        }
                    }
                }

                if (nearestNode == null)
                {
                    nearestNode = end;
                }

                var subPath = AStarSearch(currentNode, nearestNode);
                if (subPath == null)
                {
                    return (null, null);
                }

                optimalPath.AddRange(subPath);
                visited.Add(nearestNode);
                visitedWaypoints.Add(nearestNode);
                currentNode = nearestNode;
            }

            return (optimalPath, visitedWaypoints);
        }


        public (List<Node> OptimalPath, List<Node> VisitedWaypoints) FindOptimalTSPPath(Node start, List<Node> waypoints)
        {
            List<Node> optimalPath = null;
            List<Node> visitedWaypoints = null;
            int shortestDistance = int.MaxValue;

            // Lấy tất cả các permutation của các điểm waypoints
            var permutations = GetPermutations(waypoints, waypoints.Count);

            foreach (var permutation in permutations)
            {
                List<Node> currentPath = new List<Node>();
                Node currentNode = start;
                int currentDistance = 0;

                foreach (var waypoint in permutation)
                {
                    var subPath = AStarSearch(currentNode, waypoint);
                    if (subPath == null)
                    {
                        currentDistance = int.MaxValue; // Nếu không tìm thấy đường đi thì coi như vô hạn
                        break;
                    }

                    currentDistance += GetPathDistance(subPath);
                    currentPath.AddRange(subPath);
                    currentNode = waypoint;
                }

                // Sau khi đã đi qua các waypoints, quay lại điểm xuất phát
                var returnPath = AStarSearch(currentNode, start);
                if (returnPath != null)
                {
                    currentDistance += GetPathDistance(returnPath);
                    currentPath.AddRange(returnPath);
                }
                else
                {
                    currentDistance = int.MaxValue;
                }

                // Cập nhật đường đi ngắn nhất nếu tìm được
                if (currentDistance < shortestDistance)
                {
                    shortestDistance = currentDistance;
                    optimalPath = new List<Node>(currentPath);
                    visitedWaypoints = new List<Node>(permutation);
                }
            }

            return (optimalPath, visitedWaypoints);
        }

        public static IEnumerable<IEnumerable<T>> GetPermutations<T>(List<T> list, int length)
        {
            if (length == 1) return list.Select(t => new T[] { t });
            return GetPermutations(list, length - 1)
                .SelectMany(t => list.Where(e => !t.Contains(e)),
                            (t1, t2) => t1.Concat(new T[] { t2 }));
        }

        private int GetPathDistance(List<Node> path)
        {
            int totalDistance = 0;
            for (int i = 0; i < path.Count - 1; i++)
            {
                totalDistance += GetDistance(path[i], path[i + 1]);
            }
            return totalDistance;
        }

        // Tạo một key duy nhất dựa trên tham số đầu vào
        private string GenerateCacheKey(Node start, Node end, List<Node> waypoints)
        {
            string key = $"{start.X},{start.Y}-{end.X},{end.Y}";
            foreach (var waypoint in waypoints)
            {
                key += $"-{waypoint.X},{waypoint.Y}";
            }
            return key;
        }

        private List<Node> AStarSearch(Node start, Node end)
        {
            openList = new MinHeap<Node>();
            closedList = new HashSet<Node>();
            openList.Add(start);

            while (!openList.IsEmpty)
            {
                Node current = openList.Remove();

                Console.WriteLine($"({start.Name}| {start.X}, {start.Y}) => ({end.Name}| {end.X}, {end.Y}): ({current.X}, {current.Y})");


                if (current.Equals(end))
                {
                    return RetracePath(start, current);
                }

                closedList.Add(current);

                foreach (Node neighbor in GetNeighbors(current))
                {
                    if (neighbor.IsObstacle || !neighbor.IsRoad || closedList.Contains(neighbor))
                    {
                        continue;
                    }

                    int newCostToNeighbor = current.GCost + GetDistance(current, neighbor);
                    if (newCostToNeighbor < neighbor.GCost || !openList.Contains(neighbor))
                    {
                        neighbor.GCost = newCostToNeighbor;
                        neighbor.HCost = GetDistance(neighbor, end);
                        neighbor.Parent = current;

                        if (!openList.Contains(neighbor))
                        {
                            openList.Add(neighbor);
                        }
                    }
                }
            }

            return null; // No path found
        }

        private List<Node> ThetaStarSearch(Node start, Node end)
        {
            openList = new MinHeap<Node>();
            closedList = new HashSet<Node>();
            start.Parent = start; // Gán chính nó làm cha ban đầu
            openList.Add(start);

            while (!openList.IsEmpty)
            {
                Node current = openList.Remove();

                Console.WriteLine($"({start.Name}| {start.X}, {start.Y}) => ({end.Name}| {end.X}, {end.Y}): ({current.X}, {current.Y})");

                if (current.Equals(end))
                {
                    return RetracePath(start, current);
                }

                closedList.Add(current);

                foreach (Node neighbor in GetNeighbors(current))
                {
                    if (neighbor.IsObstacle || !neighbor.IsRoad || closedList.Contains(neighbor))
                    {
                        continue;
                    }

                    // Kiểm tra đường nhìn trực tiếp giữa cha của current và neighbor
                    Node parent = current.Parent;
                    if (LineOfSight(parent, neighbor))
                    {
                        int newCostToNeighbor = parent.GCost + GetDistance(parent, neighbor);
                        if (newCostToNeighbor < neighbor.GCost || !openList.Contains(neighbor))
                        {
                            neighbor.GCost = newCostToNeighbor;
                            neighbor.HCost = GetDistance(neighbor, end);
                            neighbor.Parent = parent;  // Cập nhật cha là parent của current
                            if (!openList.Contains(neighbor))
                            {
                                openList.Add(neighbor);
                            }
                        }
                    }
                    else
                    {
                        // Nếu không có đường nhìn trực tiếp, xử lý giống như A*
                        int newCostToNeighbor = current.GCost + GetDistance(current, neighbor);
                        if (newCostToNeighbor < neighbor.GCost || !openList.Contains(neighbor))
                        {
                            neighbor.GCost = newCostToNeighbor;
                            neighbor.HCost = GetDistance(neighbor, end);
                            neighbor.Parent = current;
                            if (!openList.Contains(neighbor))
                            {
                                openList.Add(neighbor);
                            }
                        }
                    }
                }
            }

            return null; // No path found
        }

        private bool LineOfSight(Node nodeA, Node nodeB)
        {
            int x0 = nodeA.X;
            int y0 = nodeA.Y;
            int x1 = nodeB.X;
            int y1 = nodeB.Y;

            // Kiểm tra theo trục X trước
            while (x0 != x1)
            {
                if (!grid[x0][y0].IsRoad || grid[x0][y0].IsObstacle) return false; // Kiểm tra xem có phải đường đi và không phải chướng ngại vật
                x0 += (x0 < x1) ? 1 : -1; // Di chuyển theo trục X (trái hoặc phải)
            }

            // Sau khi đã đến đúng vị trí theo trục X, kiểm tra trục Y
            while (y0 != y1)
            {
                if (!grid[x0][y0].IsRoad || grid[x0][y0].IsObstacle) return false; // Kiểm tra xem có phải đường đi và không phải chướng ngại vật
                y0 += (y0 < y1) ? 1 : -1; // Di chuyển theo trục Y (trên hoặc dưới)
            }

            return true; // Không có chướng ngại vật và chỉ đi qua đường hợp lệ
        }



        private List<Node> RetracePath(Node startNode, Node endNode)
        {
            List<Node> path = new List<Node>();
            Node currentNode = endNode;

            while (currentNode != startNode)
            {
                path.Add(currentNode);
                currentNode = currentNode.Parent;
            }
            path.Reverse();

            return path;
        }

        private List<Node> GetNeighbors(Node node)
        {
            List<Node> neighbors = new List<Node>();

            int x = node.X;
            int y = node.Y;

            if (x - 1 >= 0) neighbors.Add(grid[x - 1][y]);
            if (x + 1 < grid.Count) neighbors.Add(grid[x + 1][y]);
            if (y - 1 >= 0) neighbors.Add(grid[x][y - 1]);
            if (y + 1 < grid.First().Count) neighbors.Add(grid[x][y + 1]);

            //// Kiểm tra nếu node có parent
            //if (node.Parent != null)
            //{
            //    // Xác định hướng di chuyển từ parent đến node
            //    int dx = node.X - node.Parent.X;
            //    int dy = node.Y - node.Parent.Y;

            //    // Ưu tiên các neighbor nằm trên cùng đường thẳng với hướng di chuyển hiện tại
            //    if (dx == 0 && dy == 1 && y + 1 < grid.First().Count) // Di chuyển lên
            //        neighbors.Add(grid[x][y + 1]);
            //    if (dx == 0 && dy == -1 && y - 1 >= 0) // Di chuyển xuống
            //        neighbors.Add(grid[x][y - 1]);
            //    if (dx == 1 && dy == 0 && x + 1 < grid.Count) // Di chuyển phải
            //        neighbors.Add(grid[x + 1][y]);
            //    if (dx == -1 && dy == 0 && x - 1 >= 0) // Di chuyển trái
            //        neighbors.Add(grid[x - 1][y]);
            //}

            //// Thêm các neighbors khác nếu chưa có trong danh sách (ưu tiên các neighbor thẳng hàng trước)
            //if (x - 1 >= 0 && !neighbors.Contains(grid[x - 1][y])) neighbors.Add(grid[x - 1][y]); // Trái
            //if (x + 1 < grid.Count && !neighbors.Contains(grid[x + 1][y])) neighbors.Add(grid[x + 1][y]); // Phải
            //if (y - 1 >= 0 && !neighbors.Contains(grid[x][y - 1])) neighbors.Add(grid[x][y - 1]); // Dưới
            //if (y + 1 < grid.First().Count && !neighbors.Contains(grid[x][y + 1])) neighbors.Add(grid[x][y + 1]); // Trên

            return neighbors;
        }

        private int GetDistance(Node a, Node b)
        {
            int distX = Math.Abs(a.X - b.X);
            int distY = Math.Abs(a.Y - b.Y);

            return distX + distY;
        }
    }

}
