import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/qr_label.dart';

/// Dấu **RW / RB** đứng cạnh mã pallet — "pallet này là hàng tái gia công".
///
/// Vì sao phải có mặt ở MỌI màn có mã pallet: hàng RW/RB nằm lẫn trong kho với
/// hàng thường, và nó mang `inspection_status = 'ng'` suốt vòng đời. Không có
/// dấu này thì người đứng kho thấy một pallet NG không rõ vì sao — NG do OQC
/// đánh fail (phải xử lý) và NG vì bản chất hàng tái gia công (bình thường)
/// trông y như nhau.
///
/// Hai ký hiệu cố ý ngắn và CỐ ĐỊNH, trùng với tem QR
/// ([QrLabelData.badgeForDisposition]) và bản đồ kho:
///   rework → RW · refurbish → RB.
/// KHÔNG dùng "RE": HD soft đã dùng ký hiệu đó cho "Đã đảo".
class DispositionBadge extends StatelessWidget {
  const DispositionBadge({
    super.key,
    required this.disposition,
    this.compact = false,
  });

  /// `rework` | `refurbish` | null (hàng thường → không vẽ gì).
  final String? disposition;

  /// Thu nhỏ để chen vào hàng đã chật (thẻ pallet ở bước quét).
  final bool compact;

  /// Cùng màu với bản đồ kho (rack_elevation_sheet.dart) và badge trên Web
  /// (swms-storage-map.css .rk-idmark): một pallet không được đổi màu khi
  /// người dùng đi từ màn này sang màn khác.
  static const Color reworkColor = Color(0xFF8A5CD0);
  static const Color refurbishColor = Color(0xFFE0A24A);

  static Color? colorFor(String? disposition) => switch (disposition) {
    'rework' => reworkColor,
    'refurbish' => refurbishColor,
    _ => null,
  };

  @override
  Widget build(BuildContext context) {
    final text = QrLabelData.badgeForDisposition(disposition);
    final color = colorFor(disposition);

    // Hàng thường: không chiếm chỗ, để layout của màn không đổi.
    if (text == null || color == null) return const SizedBox.shrink();

    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: compact ? 6 : 8,
        vertical: compact ? 1 : 2,
      ),
      decoration: BoxDecoration(
        color: color.withValues(alpha: .15),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withValues(alpha: .55)),
      ),
      child: Text(
        text,
        style: TextStyle(
          color: color,
          fontWeight: FontWeight.w900,
          fontSize: compact ? 11 : 12,
          letterSpacing: .5,
        ),
      ),
    );
  }
}
