using Swms.FinishGoods.Web.Features.Shortages.App.Addons;

namespace Swms.FinishGoods.Web.Features.HdSoft.Shortage.App;

/// <summary>Gắn nút "Hàng thiếu HD soft" vào màn Hàng thiếu qua <see cref="IShortageScreenAddon"/>,
/// mở <see cref="HdSoftShortageDialog"/>. Đăng ký ở HdSoftModule; xoá feature HD soft là màn tự mất nút.</summary>
public sealed class ShortageHdSoftAddon : IShortageScreenAddon
{
    private const string IcChart =
        "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M3 3v18h18'/><path d='M7 15l4-4 3 3 5-6'/></svg>";

    public int Order => 100;

    public ShortageAddonAction? PageAction { get; } =
        new("Hàng thiếu HD soft", "Danh sách hàng thiếu tính trên hệ thống HD soft", IcChart, typeof(HdSoftShortageDialog));
}
