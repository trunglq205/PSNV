import 'package:swms_finish_goods/core/utils/app_local_storage.dart';

/// Lưu dữ liệu nhạy cảm (token, ...) bằng flutter_secure_storage.
class SecureStorageService {
  final AppLocalStorage _storage;

  SecureStorageService(this._storage);

  static const _kToken = 'access_token';
  static const _kRefresh = 'refresh_token';

  Future<void> saveToken(String token) => _storage.writeSecure(_kToken, token);

  Future<String?> readToken() => _storage.readSecure(_kToken);

  Future<void> saveRefreshToken(String token) =>
      _storage.writeSecure(_kRefresh, token);

  Future<String?> readRefreshToken() => _storage.readSecure(_kRefresh);

  Future<void> clear() async {
    await _storage.deleteSecure(_kToken);
    await _storage.deleteSecure(_kToken);
  }
}
