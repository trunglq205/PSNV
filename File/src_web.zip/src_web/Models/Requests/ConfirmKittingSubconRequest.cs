﻿namespace SWMS_WebTool.Models.Requests
{
    public class ConfirmKittingSubconRequest
    {
        public Int64 ID { get; set; }
        public int Quantity { get; set; }
    }

    public class CreateKittingCardOtherRequest : KittingCard
    {
        public Int64 KittingListDetailId { get; set; }
        public double Quantity { get; set; }
        public string Material { get; set; }
        public bool IsPreview { get; set; }
    }
}
