using Swms.FinishGoods.API.Features.ReturnInstructions.Business;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions;

public static class ReturnInstructionModule
{
    public static IServiceCollection AddReturnInstructionFeature(this IServiceCollection services)
    {
        services.AddScoped<IReturnInstructionService, ReturnInstructionService>();
        services.AddScoped<IReturnInstructionRepository, ReturnInstructionRepository>();

        // Mục 2c — luồng nhận lại hàng về FA, GỘP vào chính phiếu chỉ thị.
        // Slice riêng vì ba bước này có bộ quyền, bộ mail và vòng đời riêng với
        // việc nhận hàng; dữ liệu thì nằm chung bảng wms.return_instructions.
        services.AddScoped<IReturnBackFlowService, ReturnBackFlowService>();
        services.AddScoped<IReturnBackFlowRepository, ReturnBackFlowRepository>();

        // Mục 2d — FA đóng lại Pallet ID sau rework.
        //
        // KHÔNG có repository riêng: bốn hàm dữ liệu của mục này nằm trên
        // IReturnInstructionRepository ở trên, vì AttachFaPalletAsync phải chạy
        // trong CÙNG transaction tạo pallet với RegisterSerialsAsync của mục 2a
        // (cùng hook onInserted của IPalletService) — hai repository là hai
        // IDbConnection, tức hai transaction.
        services.AddScoped<IReturnFaPalletService, ReturnFaPalletService>();

        return services;
    }
}

// ServiceCollectionExtensions.AddFeatures():
//   .AddReturnInstructionFeature()
