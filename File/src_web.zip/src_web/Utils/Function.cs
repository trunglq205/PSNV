﻿using Microsoft.VisualBasic;
using OfficeOpenXml;
using QRCoder;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models;
using System.Data;
using System.Drawing;
using System.Reflection;
using SWMS_WebTool.ViewModels;
using System.Text;
using SWMS_WebTool.Models.Barcode;
using SWMS_WebTool.Models.DataKitting;
using SWMS_WebTool.Models.Requests;
using System.Globalization;
using Microsoft.AspNetCore.Components.Forms;
using System.Linq;

namespace SWMS_WebTool.Utils
{
    public static class Function
    {

        public static async Task<string> GetFilePath(IFormFile excelFile)
        {
            var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads");
            if (!Directory.Exists(uploadDirectory))
            {
                Directory.CreateDirectory(uploadDirectory);
            }
            var fileextension = Path.GetExtension(excelFile.FileName);
            var filename = Guid.NewGuid().ToString() + fileextension;

            var filepath = Path.Combine(uploadDirectory, filename);
            using FileStream fs = System.IO.File.Create(filepath);
            {
                await excelFile.CopyToAsync(fs);
            }
            return filepath;
        }

        public static void DeleteFile(string filePath)
        {
            if (!string.IsNullOrWhiteSpace(filePath))
            {
                File.Delete(filePath);
            }
        }

        public static string CreateBarCode(this object obj)
        {
            Type type = obj.GetType();
            PropertyInfo[] properties = type.GetProperties();

            string barCode = string.Join(";", properties.Select(p => p.GetValue(obj)?.ToString() ?? ""));
            return barCode;
        }

        public static DataTable? GetDataTableFromExcelFile(string filePath, string sheet = "Sheet1")

        {
            try
            {
                DataTable dt = new();

                using (var package = new ExcelPackage())
                {
                    using (var stream = File.OpenRead(filePath))
                    {
                        package.Load(stream);
                    }
                    var worksheet = package.Workbook.Worksheets[sheet];

                    //check if the worksheet is completely empty
                    if (worksheet.Dimension == null)
                    {
                        return dt;
                    }

                    //create a list to hold the column names
                    List<string> columnNames = new();

                    //needed to keep track of empty column headers
                    int currentColumn = 1;

                    //loop all columns in the sheet and add them to the datatable
                    foreach (var cell in worksheet.Cells[1, 1, 1, worksheet.Dimension.End.Column])
                    {
                        string columnName = cell.Text.Trim();

                        //check if the previous header was empty and add it if it was
                        if (cell.Start.Column != currentColumn)
                        {
                            columnNames.Add("Header_" + currentColumn);
                            dt.Columns.Add("Header_" + currentColumn);
                            currentColumn++;
                        }

                        //add the column name to the list to count the duplicates
                        columnNames.Add(columnName);

                        //count the duplicate column names and make them unique to avoid the exception
                        //A column named 'Name' already belongs to this DataTable
                        int occurrences = columnNames.Count(x => x.Equals(columnName));
                        if (occurrences > 1)
                        {
                            columnName = columnName + "_" + occurrences;
                        }

                        //add the column to the datatable
                        dt.Columns.Add(columnName);

                        currentColumn++;
                    }

                    //start adding the contents of the excel file to the datatable
                    for (int i = 2; i <= worksheet.Dimension.End.Row; i++)
                    {
                        var row = worksheet.Cells[i, 1, i, worksheet.Dimension.End.Column];
                        DataRow newRow = dt.NewRow();

                        //loop all cells in the row
                        foreach (var cell in row)
                        {
                            newRow[cell.Start.Column - 1] = cell.Text;
                        }

                        dt.Rows.Add(newRow);
                    }

                    return dt;
                }

            }
            catch
            {
                return null;
            }
        }
        public static DataTable? GetDataTableFromExcel(string path, string sheet, List<string>? headers = null, List<int>? indexheader = null, bool allowBlank = false)
        {
            try
            {
                using (var pck = new ExcelPackage())
                {
                    using (var stream = File.OpenRead(path))
                    {
                        pck.Load(stream);
                    }
                    var ws = pck.Workbook.Worksheets[sheet];
                    DataTable tbl = new DataTable();
                    List<int> indexes = new List<int>();
                    if (headers != null && headers.Count > 0)
                    {
                        foreach (string header in headers)
                        {
                            tbl.Columns.Add(header);
                            indexes.Add(headers.IndexOf(header) + 1);
                        }
                    }
                    var startRow = 2;
                    for (int rowNum = startRow; rowNum <= ws.Dimension.End.Row; rowNum++)
                    {
                        int endOfColums = ws.Dimension.End.Column;
                        ExcelRange wsRow = ws.Cells[rowNum, 1, rowNum, endOfColums];
                        DataRow row = tbl.Rows.Add();
                        foreach (ExcelRangeBase cell in wsRow)
                        {
                            if (cell.Start.Column == 1 && string.IsNullOrEmpty(cell.Text) && !allowBlank)
                            {
                                tbl.Rows.Remove(row);
                                break;
                            }
                            if (indexheader == null)
                            {
                                indexheader = indexes;
                            }
                            if (indexheader.Contains(cell.Start.Column))
                            {
                                row[indexheader.IndexOf(cell.Start.Column)] = cell.Text;
                            }
                        }
                    }
                    return tbl;
                }
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        public static DataTable? GetDataTableFromCSV(string path, List<string>? headers = null)
        {
            DataTable tbl = new();
            try
            {
                using (var reader = new StreamReader(path))
                {
                    if (headers != null && headers.Count > 0)
                    {
                        foreach (string header in headers)
                        {
                            tbl.Columns.Add(header);
                        }
                        while (!reader.EndOfStream)
                        {
                            string record = reader.ReadLine();
                            string[] data = record.Split(",");
                            tbl.Rows.Add(data);
                        }
                    }
                    else
                    {
                        return tbl;
                    }
                }
            }
            catch
            {
                return null;
            }
            return tbl;
        }

        public static List<T> ConvertDataTable<T>(DataTable dt)
        {
            List<T> data = new List<T>();
            foreach (DataRow row in dt.Rows)
            {
                T item = GetItem<T>(row);
                data.Add(item);
            }
            return data;
        }
        public static T GetItem<T>(DataRow dr)
        {
            Type temp = typeof(T);
            T obj = Activator.CreateInstance<T>();

            foreach (DataColumn column in dr.Table.Columns)
            {
                foreach (PropertyInfo pro in temp.GetProperties())
                {
                    if (pro.Name == column.ColumnName)
                        pro.SetValue(obj, dr[column.ColumnName], null);
                    else
                        continue;
                }
            }
            return obj;
        }


        public static List<InvoiceImport>? DataTatbleToInvoice(DataTable dt)
        {
            List<InvoiceImport> invoices = new List<InvoiceImport>();
            try
            {
                var listInvoiceDist = dt.AsEnumerable()
                                .Select(row => new
                                {
                                    InvoiceNo = row.Field<string>("InvoiceNo"),
                                    VendorCode = row.Field<string>("VendorCode"),
                                    DeliveryDate = DateTime.Parse(row.Field<string>("DeliveryDate")),
                                }).Distinct().ToList();
                foreach (var item in listInvoiceDist)
                {
                    if (item != null)
                    {
                        InvoiceImport invoice = new InvoiceImport
                        {
                            InvoiceNo = item.InvoiceNo,
                            LotNo = string.Empty,
                            InvoiceDate = item.DeliveryDate.ToString("yyyy-MM-dd"),
                            VendorCode = item.VendorCode,
                        };

                        List<InvoiceDetailImport> lstDetail = dt.AsEnumerable().Where(row => row.Field<string>("VendorCode") == invoice.VendorCode && row.Field<string>("InvoiceNo") == invoice.InvoiceNo && DateTime.Parse(row.Field<string>("DeliveryDate")) == item.DeliveryDate)
                                                                      .Select(row => new InvoiceDetailImport
                                                                      {
                                                                          Plant = row.Field<string>("Plant"),
                                                                          Material = row.Field<string>("Material"),
                                                                          Sloc = row.Field<string>("Sloc"),
                                                                          Unit = row.Field<string>("Unit"),
                                                                          DeliveryDate = invoice.InvoiceDate,
                                                                      }).ToList();
                        lstDetail = lstDetail.GroupBy(x => new
                        {
                            x.Plant,
                            x.Material,
                            x.Sloc,
                            x.Unit,
                            x.DeliveryDate
                        }).Select(y => new InvoiceDetailImport
                        {
                            Plant = y.Key.Plant,
                            Material = y.Key.Material,
                            Sloc = y.Key.Sloc,
                            Unit = y.Key.Unit,
                            DeliveryDate = y.Key.DeliveryDate
                        }).ToList();

                        List<InvoiceDetailImport> details = new List<InvoiceDetailImport>();
                        foreach (InvoiceDetailImport ivd in lstDetail)
                        {
                            var lstDetailItem = dt.AsEnumerable().Where(row => row.Field<string>("VendorCode") == invoice.VendorCode
                                                                 && row.Field<string>("InvoiceNo") == invoice.InvoiceNo
                                                                 && row.Field<string>("Plant") == ivd.Plant
                                                                 && row.Field<string>("Material") == ivd.Material
                                                                 && row.Field<string>("Sloc") == ivd.Sloc)
                                                             .Select(row => new
                                                             {
                                                                 InvoiceItem = row.Field<string>("InvoiceItem"),
                                                                 PONo = row.Field<string>("PONo"),
                                                                 POItem = row.Field<string>("POItem"),
                                                                 PlanQuantity = double.Parse(row.Field<string>("PlanQuantity")!),
                                                             }).Distinct().ToList();
                            List<InvoiceItemDetailImport> itemDetails = new List<InvoiceItemDetailImport>();
                            foreach (var ivdi in lstDetailItem)
                            {
                                InvoiceItemDetailImport ivDetailItem = dt.AsEnumerable().Where(row => row.Field<string>("VendorCode") == invoice.VendorCode
                                                                                                                        && row.Field<string>("InvoiceNo") == invoice.InvoiceNo
                                                                                                                        && row.Field<string>("InvoiceItem") == ivdi.InvoiceItem
                                                                                                                        && row.Field<string>("PONo") == ivdi.PONo
                                                                                                                        && row.Field<string>("POItem") == ivdi.POItem
                                                                                                                        && row.Field<string>("Plant") == ivd.Plant
                                                                                                                        && row.Field<string>("Material") == ivd.Material
                                                                                                                        && row.Field<string>("Sloc") == ivd.Sloc)
                                                                                                              .Select(row => new InvoiceItemDetailImport
                                                                                                              {
                                                                                                                  InvoiceItem = row.Field<string>("InvoiceItem"),
                                                                                                                  PONo = row.Field<string>("PONo"),
                                                                                                                  POItem = row.Field<string>("POItem"),
                                                                                                                  PlanQuantity = double.Parse(row.Field<string>("PlanQuantity")!),
                                                                                                              }).LastOrDefault()!;

                                if (itemDetails.Count == 0)
                                {
                                    itemDetails.Add(ivDetailItem);
                                }
                                else
                                {
                                    InvoiceItemDetailImport? temp = itemDetails.Where(x => x.InvoiceItem == ivDetailItem.InvoiceItem &&
                                                                                       x.PONo == ivDetailItem.PONo &&
                                                                                       x.POItem == ivDetailItem.POItem &&
                                                                                       x.Status == ivDetailItem.Status
                                                                                 ).FirstOrDefault();
                                    if (temp == null)
                                    {
                                        itemDetails.Add(ivDetailItem);
                                    }
                                }
                            }
                            ivd.DetailItems = itemDetails;
                            ivd.TotalQuantity = itemDetails.Select(x => x.PlanQuantity).Sum();
                            details.Add(ivd);
                        }

                        invoice.Details = details;
                        invoices.Add(invoice);
                    }
                }
            }
            catch
            {
                return null;
                throw;
            }
            return invoices;
        }

        public static List<TypeFrequency>? DataTatbleToTypeMaster(DataTable dt)
        {
            List<TypeFrequency>? types = new List<TypeFrequency>();
            try
            {
                var listTypeDist = dt.AsEnumerable()
                                .Select(row => new TypeFrequency
                                {
                                    Plant = row.Field<string>("Plant"),
                                    Category = row.Field<string>("Category"),
                                    Material = row.Field<string>("Material"),
                                    Description = row.Field<string>("Discription"),
                                    Sloc = row.Field<string>("Sloc"),
                                    PositionJPT = row.Field<string>("Position"),
                                    PositionFA = row.Field<string>("PositionFA"),
                                    KittingType = row.Field<string>("KittingType"),
                                    SpecialPart = row.Field<string>("SpecialPart"),
                                    Type = row.Field<string>("Type"),
                                    Frequency = row.Field<string>("Frequency"),
                                }).Distinct().ToList();
                if (listTypeDist != null)
                {
                    types = listTypeDist;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return types;
        }

        public static List<UrgentULCOCRH>? DataTatbleToUrgentMaster(DataTable dt)
        {
            List<UrgentULCOCRH>? frequencies = new List<UrgentULCOCRH>();
            try
            {
                var listTypeDist = dt.AsEnumerable()
                                .Select(row => new UrgentULCOCRH
                                {
                                    Material = row.Field<string>("Material"),
                                    Urgent = row.Field<string>("Urgent"),
                                }).Distinct().ToList();
                if (listTypeDist != null)
                {
                    frequencies = listTypeDist;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return frequencies;
        }

        public static List<StandardPacking>? DataTatbleToStandardPackingMaster(DataTable dt)
        {
            List<StandardPacking>? frequencies = new List<StandardPacking>();
            try
            {
                var listTypeDist = dt.AsEnumerable()
                                .Select(row => new StandardPacking
                                {
                                    Material = row.Field<string>("Material"),
                                    Quantity = int.Parse(row.Field<string>("Quantity")),
                                }).Distinct().ToList();
                if (listTypeDist != null)
                {
                    frequencies = listTypeDist;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return frequencies;
        }

        public static List<UrgentULCOCRH>? DataTatbleToULCOCRKMaster(DataTable dt)
        {
            List<UrgentULCOCRH>? frequencies = new List<UrgentULCOCRH>();
            try
            {
                var listTypeDist = dt.AsEnumerable()
                                .Select(row => new
                                {
                                    Material = row.Field<string>("Material"),
                                    UL = row.Field<string>("UL"),
                                    COC = row.Field<string>("COC"),
                                    RH = row.Field<string>("RH"),
                                    Remark = row.Field<string>("Remark"),
                                }).Distinct().ToList();
                foreach (var item in listTypeDist)
                {
                    UrgentULCOCRH frequency = new UrgentULCOCRH();
                    frequency.Material = item.Material;
                    if (!string.IsNullOrEmpty(item.UL))
                    {
                        frequency.Ulcoc += item.UL;
                    }
                    if (!string.IsNullOrEmpty(item.COC))
                    {
                        if (!string.IsNullOrEmpty(frequency.Ulcoc))
                        {
                            frequency.Ulcoc += " | ";
                        }
                        frequency.Ulcoc += item.COC;
                    }
                    if (!string.IsNullOrEmpty(item.RH))
                    {
                        if (!string.IsNullOrEmpty(frequency.Ulcoc))
                        {
                            frequency.Ulcoc += " | ";
                        }
                        frequency.Ulcoc += item.RH;
                    }
                    if (!string.IsNullOrEmpty(item.Remark))
                    {
                        if (!string.IsNullOrEmpty(frequency.Ulcoc))
                        {
                            frequency.Ulcoc += " | ";
                        }
                        frequency.Ulcoc += item.Remark;
                    }

                    frequencies.Add(frequency);
                }
            }
            catch
            {
                return null;
                throw;
            }
            return frequencies;
        }

        public static bool CheckHeaderExcel(string path, string sheet, List<string> headers)
        {
            try
            {
                using (var pck = new ExcelPackage())
                {
                    using (var stream = File.OpenRead(path))
                    {
                        pck.Load(stream);
                    }
                    var ws = pck.Workbook.Worksheets[sheet];

                    ExcelRange wsRow = ws.Cells[1, 1, 1, ws.Dimension.End.Column];
                    /* if (headers.Count != ws.Dimension.End.Column)
                     {
                         return false;
                     }*/
                    for (int column = 0; column < headers.Count; column++)
                    {
                        if (!headers[column].Equals(ws.Cells[1, column + 1].Text))
                        {
                            return false;
                        }
                    }
                }
                return true;
            }
            catch
            {
                return false;
            }
        }

        public static List<PlanOrderImport>? DataTatbleToPlanOrder(DataTable dt, string planOrderNumber)
        {
            List<PlanOrderImport>? planOrders = new List<PlanOrderImport>();
            try
            {

                var listPODist = dt.AsEnumerable()
                                .Select(row => new PlanOrderImport
                                {
                                    PlanOrderNumber = planOrderNumber,
                                    Plant = row.Field<string>("Plant").ToUpper(),
                                    Material = row.Field<string>("Material").ToUpper(),
                                    Sloc = row.Field<string>("Sloc").ToUpper(),
                                    ProductionVersion = row.Field<string>("ProductionVersion").ToUpper(),
                                    PlanOrderQuantity = double.Parse(row.Field<string>("PlanOrderQuantity")),
                                    IsWD = !string.IsNullOrEmpty(row.Field<string>("WD")) && row.Field<string>("WD").ToUpper().Equals("X"),
                                }).Distinct().ToList();
                if (listPODist != null)
                {
                    planOrders = listPODist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return planOrders;
        }

        public static List<ImportNoPrintPanacim>? DataTatbleToNoPrintPanacim(DataTable dt)
        {
            try
            {
                var data = dt.AsEnumerable()
                                .Select(row => new ImportNoPrintPanacim
                                {
                                    Plant = row.Field<string>("Plant"),
                                    Material = row.Field<string>("Material"),
                                    Sloc = row.Field<string>("Sloc"),

                                }).Distinct().ToList();
                if (data != null)
                {
                    return data;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return null;
        }

        public static List<TrackingNumberImport>? DataTatbleToTrackingNumder(DataTable dt)
        {
            List<TrackingNumberImport>? trackingNumbers = new List<TrackingNumberImport>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row => new TrackingNumberImport
                                {
                                    Plant = row.Field<string>("Plant"),
                                    VendorCode = row.Field<string>("VendorCode"),
                                    InvoiceNo = row.Field<string>("InvoiceNo"),
                                    TrackingNumber = row.Field<string>("TrackingNumber"),
                                    Sloc = row.Field<string>("Sloc"),
                                    Material = row.Field<string>("Material"),
                                    PONo = row.Field<string>("PONo"),
                                    POItem = row.Field<string>("POItem"),
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    trackingNumbers = listTNDist.Where(x => !string.IsNullOrEmpty(x.TrackingNumber)).ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return trackingNumbers;
        }
        public static List<KittingPlanImport>? DataTatbleToKittingPlan(DataTable dt)
        {
            List<KittingPlanImport>? kittingPlans = new List<KittingPlanImport>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row =>
                                {
                                    var sTime = row.Field<string>("Recipient").Substring(7, 4);
                                    sTime = sTime.Substring(0, 2) + ":" + sTime.Substring(2);
                                    var sLine = row.Field<string>("Recipient").Substring(4, 3);
                                    return new KittingPlanImport
                                    {
                                        Plant = row.Field<string>("Plnt"),
                                        ReservationNo = row.Field<string>("Reserv.No"),
                                        Material = row.Field<string>("Material No"),
                                        Deliverydate = ParseDate(row.Field<string>("ReqmtsDate"), true),
                                        Descriptions = row.Field<string>("Description"),
                                        INS = row.Field<string>("INS"),
                                        Issue_Sloc = row.Field<string>("Issu"),
                                        Model = row.Field<string>("F/G Material No"),
                                        ModelQuantity = Convert.ToDouble(row.Field<string>("Quantity ling grp")),
                                        Quantity = Convert.ToDouble(row.Field<string>("Quantity")),
                                        Receipt_Location = row.Field<string>("Rep"),
                                        Recipient = row.Field<string>("Recipient"),
                                        RoHS = row.Field<string>("RoHS"),
                                        Unit = row.Field<string>("Quantity1"),
                                        Time = sTime,
                                        Line = sLine,
                                        ReservationItem = int.Parse(row.Field<string>("Itm")),
                                    };
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    kittingPlans = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return kittingPlans;
        }

        public static List<ModelMapping>? DataTatbleToModelMapping(DataTable dt)
        {
            List<ModelMapping>? modelMappings = new List<ModelMapping>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row => new ModelMapping
                                {
                                    Plant = row.Field<string>("Plant"),
                                    Category = row.Field<string>("Cate"),
                                    ModelJTF = row.Field<string>("Model JTF"),
                                    ModelSWMS = row.Field<string>("Model SWMS"),
                                    Note = row.Field<string>("Note"),
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    modelMappings = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return modelMappings;
        }

        public static List<KittingPlanImport>? DataTatbleToKittingPlanOther(DataTable dt)
        {
            List<KittingPlanImport>? kittingPlans = new List<KittingPlanImport>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row => new KittingPlanImport
                                {
                                    Material = row.Field<string>("Material"),
                                    Plant = row.Field<string>("Plant"),
                                    RequirementsDate = ParseDate(row.Field<string>("ReqmtsDate"), true),
                                    Issue_Sloc = row.Field<string>("ISL"),
                                    ReceiptSloc = row.Field<string>("RepLoc"),
                                    Line = row.Field<string>("line"),
                                    Quantity = Convert.ToDouble(row.Field<string>("Quantity staged")),
                                    Remark = row.Field<string>("Remark"),
                                    Tcode = row.Field<string>("Tcode"),
                                    GroupName = row.Field<string>("GroupName"),
                                    Account = row.Field<string>("Account"),
                                    Reason = row.Field<string>("Reason"),
                                    CostCenter = row.Field<string>("CostCenter")
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    kittingPlans = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return kittingPlans;
        }

        public static List<KittingPlanDIPImport>? DataTatbleToKittingPlanDIP(DataTable dt)
        {
            List<KittingPlanDIPImport>? kittingPlans = new List<KittingPlanDIPImport>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row => new KittingPlanDIPImport
                                {
                                    Plant = row.Field<string>("Plant"),
                                    FinishGoods = row.Field<string>("Material"),
                                    Assembly = row.Field<string>("Component"),
                                    Material = row.Field<string>("Component1"),
                                    Lvl = row.Field<string>("Lvl"),
                                    MovingType = row.Field<string>("Material type"),
                                    Descriptions = row.Field<string>("Discription"),
                                    AssemblyQuantity = Convert.ToDouble(row.Field<string>("quantity")),
                                    MaterialQuantity = Convert.ToDouble(row.Field<string>("quantity1")),
                                    Vendor = row.Field<string>("Vendor"),
                                    Sloc = row.Field<string>("Storage"),
                                    //Deliverydate = DateTime.Now,
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    kittingPlans = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return kittingPlans;
        }

        public static List<KittingPlanImport>? DataTatbleToKittingPlanSubcon(DataTable dt)
        {
            List<KittingPlanImport>? kittingPlans = new List<KittingPlanImport>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row => new KittingPlanImport
                                {
                                    Plant = row.Field<string>("Plant"),
                                    Issue_Sloc = row.Field<string>("ISL"),
                                    ReceiptSloc = row.Field<string>("RepLoc"),
                                    Material = row.Field<string>("Material"),
                                    Quantity = Convert.ToDouble(row.Field<string>("Quantity staged")),
                                    MaterialDescription = row.Field<string>("Material Description"),
                                    RequirementsDate = ParseDate(row.Field<string>("ReqmtsDate")),
                                    Line = row.Field<string>("Line"),
                                    STT = row.Field<string>("STT"),
                                    PSNVStock = row.Field<string>("PSNV_Stock"),
                                    KHFAN7 = row.Field<string>("KHFA_N7"),
                                    VenderName = row.Field<string>("VenderName"),
                                    QuantityActual = Convert.ToDouble(row.Field<string>("Quantity Actual")),
                                    Pallet = row.Field<string>("Pallet")
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    kittingPlans = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return kittingPlans;
        }

        public static List<ActualPlanImport>? DataTatbleToActualPlanDIP(DataTable dt)
        {
            List<ActualPlanImport>? kittingPlans = new List<ActualPlanImport>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row =>
                                {
                                    var sTime = row.Field<string>("Time") ?? string.Empty;
                                    return new ActualPlanImport
                                    {
                                        Plant = row.Field<string>("Plant"),
                                        Blog = row.Field<string>("blog"),
                                        Model = row.Field<string>("Model"),
                                        Note = row.Field<string>("Note"),
                                        ProductDate = ParseDate(row.Field<string>("ProductDate")),
                                        SlocDIP = row.Field<string>("SlocDIP"),
                                        Line = row.Field<string>("Line"),
                                        Time = sTime.Replace('h', ':').Replace('H', ':'),
                                        Quantity = Convert.ToDouble(row.Field<string>("Qty")),
                                        ModelFA = row.Field<string>("ModelFA"),
                                    };
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    kittingPlans = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return kittingPlans;
        }

        public static List<SapStockImport>? DataTatbleToSapStock(DataTable dt)
        {
            List<SapStockImport>? sapStock = new List<SapStockImport>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row =>
                                {
                                    return new SapStockImport
                                    {
                                        Plant = row.Field<string>("Plnt"),
                                        Sloc = row.Field<string>("SLoc"),
                                        Material = row.Field<string>("Material"),
                                        StandardPrice = Convert.ToDouble(row.Field<string>("Standard price")),
                                        PerQuantity = Convert.ToDouble(row.Field<string>("per")),
                                        SAPQuantity = Convert.ToDouble(row.Field<string>("Total stock qty"))
                                    };
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    sapStock = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return sapStock;
        }

        public static List<BlockSapSchedulePlanRequest>? DataTatbleToBlockSchedule(DataTable dt)
        {
            List<BlockSapSchedulePlanRequest>? schedule = new List<BlockSapSchedulePlanRequest>();
            try
            {
                var listTNDist = dt.AsEnumerable()
                                .Select(row =>
                                {
                                    return new BlockSapSchedulePlanRequest
                                    {
                                        Plant = row.Field<string>("Plant"),
                                        KittingType = Convert.ToByte(row.Field<string>("Type")),
                                        Category = row.Field<string>("Category"),
                                    };
                                }).Distinct().ToList();
                if (listTNDist != null)
                {
                    schedule = listTNDist.ToList();
                }
            }
            catch
            {
                return null;
                throw;
            }
            return schedule;
        }

        /// <summary>
        /// Using Microsoft.Office.Interop to convert XLS to XLSX format, to work with EPPlus library
        /// </summary>
        /// <param name="filesFolder"></param>
        /* public static string ConvertXLS_XLSX(string filePath)
         {
             FileInfo file = new FileInfo(filePath);
             var app = new Microsoft.Office.Interop.Excel.Application();
             var xlsFile = file.FullName;
             var wb = app.Workbooks.Open(xlsFile);
             var xlsxFile = xlsFile + "x";
             wb.SaveAs(Filename: xlsxFile, FileFormat: Microsoft.Office.Interop.Excel.XlFileFormat.xlOpenXMLWorkbook);
             wb.Close();
             app.Quit();
             return xlsxFile;
         }*/
        public static string BarcodeBase64(string str)
        {
            string imgBase64 = string.Empty;
            try
            {
                QRCodeGenerator qrGenerator = new QRCodeGenerator();
                QRCodeData qrCodeData = qrGenerator.CreateQrCode(str, QRCodeGenerator.ECCLevel.Q);
                QRCode qrCode = new QRCode(qrCodeData);
                Bitmap qrCodeImage = qrCode.GetGraphic(20);
                byte[] bitmapBytes = BitmapToBytes(qrCodeImage);
                imgBase64 = Convert.ToBase64String(bitmapBytes);
            }
            catch (Exception ex)
            {

            }
            return imgBase64;
        }

        private static byte[] BitmapToBytes(Bitmap img)
        {
            using (MemoryStream stream = new MemoryStream())
            {
                img.Save(stream, System.Drawing.Imaging.ImageFormat.Png);
                return stream.ToArray();
            }
        }

        public static string ConvertUtf16ToUtf8(string utf16String)
        {
            byte[] utf8Bytes = Encoding.UTF8.GetBytes(utf16String);

            string utf8String = Encoding.UTF8.GetString(utf8Bytes);

            return utf8String;
        }

        public static List<ImportMaterialDetailViewModel>? DataTatbleToMaterialDetail(DataTable dt)
        {
            List<ImportMaterialDetailViewModel>? types = new List<ImportMaterialDetailViewModel>();
            try
            {
                var listMaterialDetail = dt.AsEnumerable()
                                .Select(row => new ImportMaterialDetailViewModel
                                {
                                    Name = row.Field<string>("Name"),
                                    Material = row.Field<string>("Material"),
                                    Description = row.Field<string>("Description"),
                                }).Distinct().ToList();
                if (listMaterialDetail != null)
                {
                    types = listMaterialDetail;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return types;
        }

        public static List<ImportPlanPanacim>? DataTatbleToPkanPrintPanacim(DataTable dt, DateTime deliverydate)
        {
            try
            {
                var data = dt.AsEnumerable()
                                .Select(row => new ImportPlanPanacim
                                {
                                    Plant = row.Field<string>("Plant"),
                                    Material = row.Field<string>("Material"),
                                    Category = row.Field<string>("Category"),
                                    GRQuantity = int.Parse(row.Field<string>("GRQuantity")),
                                    SPQ = int.Parse(row.Field<string>("SPQ")),
                                    SoundbizQuantity = int.Parse(row.Field<string>("SoundbizQuantity")),
                                    ProjectorQuantity = int.Parse(row.Field<string>("ProjectorQuantity")),
                                    Invoice = row.Field<string>("Invoice"),
                                    DeliveryDate = deliverydate.ToString("yyyy-MM-dd")

                                }).Distinct().ToList();
                if (data != null)
                {
                    return data;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return null;
        }

        public static List<ImportMasterSlocViewModel>? DataTatbleToMasterSloc(DataTable dt)
        {
            List<ImportMasterSlocViewModel>? types = new List<ImportMasterSlocViewModel>();
            try
            {
                var listMasterSloc = dt.AsEnumerable()
                                .Select(row => new ImportMasterSlocViewModel
                                {
                                    Plant = row.Field<string>("Plant"),
                                    Category = row.Field<string>("Category"),
                                    Sloc = row.Field<string>("Sloc"),
                                    Type = row.Field<string>("Type"),
                                    Address = row.Field<string>("Address"),
                                    Description = row.Field<string>("Detail"),
                                }).Distinct().ToList();
                if (listMasterSloc != null)
                {
                    types = listMasterSloc;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return types;
        }

        public static string MapNameKittingType(string kittingtype)
        {
            if (kittingtype == "1")
            {
                return Constants.ONETIME;
            }
            else if (kittingtype == "2")
            {
                return Constants.PREPARATION;
            }
            else
            {
                return Constants.NTIME + Constants.TIME; ;
            }
        }

        public static string MapNameKittingTypeString(string kittingtype)
        {
            if (kittingtype == "1")
            {
                return Constants.ONETIMETEXT;
            }
            else if (kittingtype == "2")
            {
                return Constants.PREPARETEXT;
            }
            else
            {
                return Constants.NTIMETEXT; ;
            }
        }

        public static string MapNameKittingTabString(Byte? kittingtype)
        {
            if (kittingtype == 0)
            {
                return "KittingFA";
            }
            else if (kittingtype == 1)
            {
                return "KittingDIP";
            }
            else if (kittingtype == 2)
            {
                return "KittingSubcon";
            }
            else if (kittingtype == 3)
            {
                return "KittingOutside";
            }
            else
            {
                return string.Empty;
            }
        }

        public static List<CheckTypeFrequencyImport>? DataTatbleToTypeCheck(DataTable dt)
        {
            List<CheckTypeFrequencyImport>? types = new List<CheckTypeFrequencyImport>();
            try
            {
                var listTypeDist = dt.AsEnumerable()
                                .Select(row => new CheckTypeFrequencyImport
                                {
                                    Material = row.Field<string>("Material No"),
                                    Sloc = row.Field<string>("Sloc"),
                                    Category = row.Field<string>("Category"),
                                }).Distinct().ToList();
                if (listTypeDist != null)
                {
                    types = listTypeDist;
                }
            }
            catch
            {
                return null;
                throw;
            }
            return types;
        }

        public static List<KittingPlan> GroupRecordsByTypeNTime(List<KittingPlan> dataRaw, List<KittingPlan> dataGroup,bool isHaveRuleProcess)
        {

            //DataRaw là dữ liệu N1,N2,... chưa group
            //datagroup là dữ liệu N1,N2,... đã group
            var res = new List<KittingPlan>();
            //Tuấn Anh check
            // Lấy ra dữ liệu N1
            var dataN1Result = dataGroup.Where(s => s.Type == "N1").ToList();
            //Tuấn Anh thêm
            var dataNResult = dataGroup.Where(s => s.Type != "N1").ToList();
            //Tuấn Anh thêm trường hợp có Process
            if (isHaveRuleProcess)
            {
                // Lấy ra dữ liệu N2,N3,...
                var grByTimeAnType = dataRaw
                    .Where(e => e.Type != "N1")
                    .Select(g => new TimeAndTypeProces
                    {
                        Time = g.Time,
                        Type = g.Type,
                        Model = g.Model,
                        Line = g.Line,
                        Plant = g.Plant,
                        SpecialPart = (g.SpecialPart == "Carton" || g.SpecialPart == "Trolley") ? g.SpecialPart : "Normal",
                        PositionFA = g.PositionFA // Grouping logic
                    })
                    .Distinct(new TimeAndTypeComparerProcess())
                    .ToList(); // nhóm by Time And Type

                var dicTimeByType = new List<(CustomKeyProcess, List<KittingPlan>)>(); // lưu trữ các cặp Time by Type
                                                                                // Lưu lại dữ liệu đã lặp qua



                //var dicTimeByTypeTemp = new List<(CustomKeyProcess, List<KittingPlan>)>();


                var skipTimes = new List<TimeAndTypeProces>();

                // Xử lý gộp danh sách N2 N3 N4...
                foreach (var modelStr in grByTimeAnType.Select(e => e.Model).Distinct())
                {

                    var lstByModel = grByTimeAnType.Where(e => e.Model == modelStr).ToList();



                    foreach (var item in lstByModel)
                    {
                        if (skipTimes.Any(e => e.Time == item.Time && e.Type == item.Type && e.Model == item.Model && item.Line == e.Line && item.PositionFA == e.PositionFA && item.SpecialPart == e.SpecialPart)) continue; // Tuấn Anh thêm chỗ line
                        string numberTake = new string(item.Type.SkipWhile(c => !char.IsDigit(c)).ToArray());

                        //Tuấn Anh
                        //Có thể chỗ này thiếu line
                        var dAdd = grByTimeAnType
                            .Where(e => !skipTimes.Any(x => x.Time == e.Time && x.Type == e.Type && x.Model == e.Model && e.SpecialPart == x.SpecialPart && e.Plant == x.Plant
                                && x.Line == e.Line && x.PositionFA == e.PositionFA) // Tuấn Anh Thêm dòng này
                                && e.Type == item.Type
                                && e.Model == item.Model
                                && e.SpecialPart == item.SpecialPart
                                && e.Plant == item.Plant
                                && e.Line == item.Line && e.PositionFA == item.PositionFA) // Tuấn Anh Thêm dòng ngày
                            .Take(int.Parse(numberTake))
                            .ToList();


                        //Tuấn Anh test sau khi sửa thì comment lại

                        //if (item.Model == "NE-1054FAUH-V4" && item.Type == "N4")
                        //{
                        //    string a = "";
                        //}


                        var lstCon = dataRaw.Where(s => s.Model == item.Model
                                                         && s.Type == item.Type
                                                         && s.Line == item.Line
                                                         && s.Plant == item.Plant
                                                         && s.SpecialPart == item.SpecialPart
                                                         && s.PositionFA == item.PositionFA //Tuấn Anh thêm
                                                        // && dAdd.Where(e => e.Time == s.Time).Any()); // Tuấn Anh sửa
                                                         && dAdd.Select(e => e.Time ).Contains(s.Time));

                        var lstConGrByMaterial = lstCon.GroupBy(g => g.Material).Select(r => new KittingPlan
                        {
                            Plant = r.First().Plant,
                            Category = r.First().Category,
                            Line = r.First().Line,
                            Time = r.First().Time,
                            Model = r.First().Model,
                            Quantity = r.Sum(r => r.Quantity),
                            Barcode = Function.CreateBarCode(new BarcodeFA()
                            {
                                Model = r.First().Model,
                                Line = r.First().Line,
                                RequirementDate = r.First().DeliveryDate?.ToString("dd/MM/yyyy"),
                                Time = r.First().Time,
                                Plant = r.First().Plant,
                                Category = r.First().Category,
                                CategoryJT = r.First().Category
                            }),
                            Type = r.First().Type,
                            DeliveryDate = r.First().DeliveryDate,
                            Descriptions = r.First().Descriptions,
                            CreatedBy = r.First().CreatedBy,
                            Unit = r.First().Unit,
                            Issue_Sloc = r.First().Issue_Sloc,
                            Receipt_Location = r.First().Receipt_Location,
                            ReservationNo = r.First().ReservationNo,
                            INS = r.First().INS,
                            Material = r.Key,
                            SpecialPart = r.First().SpecialPart,
                        }).ToList();

                        dicTimeByType.Add((new CustomKeyProcess
                        {
                            Model = item.Model,
                            Type = item.Type,
                            Line = item.Line,
                            Plant = item.Plant,
                            SpecialPart = item.SpecialPart,
                            Time = item.Time,
                            PositionFA = item.PositionFA,
                            
                        }, lstConGrByMaterial));



                        //Tuấn Anh test sau khi sửa thì comment đoạn này

                        //if (item.Model == "NE-1054FAUH-V4" && (item.Type == "N4" || item.Type == "N2") && item.PositionFA == "BD,DG,NQ,LK")
                        //{
                        //    dicTimeByTypeTemp.Add((new CustomKey
                        //    {
                        //        Model = item.Model,
                        //        Type = item.Type,
                        //        Line = item.Line,
                        //        Plant = item.Plant,
                        //        SpecialPart = item.SpecialPart,
                        //        Time = item.Time,
                        //        PositionFA = item.PositionFA,

                        //    }, lstConGrByMaterial));




                        //}




                        skipTimes.AddRange(dAdd);
                    }
                }


                //var abc = dicTimeByTypeTemp.SelectMany(r => r.Item2).ToList();


                //List<KittingPlan> abc1 = new List<KittingPlan>();

                // Add lại data cho list con
                foreach (var item in dataN1Result)
                {
                    var lstChildOtherNTime = dicTimeByType
                        .Where(e => e.Item1.Model == item.Model
                                    && e.Item1.Line == item.Line
                                    && e.Item1.SpecialPart == item.SpecialPart
                                    && e.Item1.Plant == item.Plant
                                    && e.Item1.Time == item.Time
                                    && e.Item1.PositionFA == item.PositionFA) //Tuấn Anh thêm MW
                        .SelectMany(r => r.Item2)
                        .ToList();

                    //Tuấn Anh thêm
                    dicTimeByType.RemoveAll(e => e.Item1.Model == item.Model
                                    && e.Item1.Line == item.Line
                                    && e.Item1.SpecialPart == item.SpecialPart
                                    && e.Item1.Plant == item.Plant
                                    && e.Item1.Time == item.Time
                                    && e.Item1.PositionFA == item.PositionFA);


                    dataNResult.RemoveAll(e => e.Model == item.Model
                                    && e.Line == item.Line
                                    && e.SpecialPart == item.SpecialPart
                                    && e.Plant == item.Plant
                                    && e.Time == item.Time
                                    && e.PositionFA == item.PositionFA);
                    //Kết thúc thêm

                    //item.Quantity = dataN1Result
                    //    .Where(s => s.Model == item.Model && s.Line == item.Line)
                    //    .GroupBy(x => new { x.Model, x.Line })
                    //    .Select(g => new KittingPlan
                    //    {
                    //        ModelQuantity = g.Sum(e => e.ModelQuantity)
                    //    })
                    //    .Select(a => a.ModelQuantity)
                    //    .First();

                    //abc1.AddRange(lstChildOtherNTime);

                    item.KittingPlans.AddRange(lstChildOtherNTime);
                    res.Add(item);
                }

                //Tuấn Anh thêm


                dataNResult = dataNResult.OrderBy(e => e.Type.Trim('N')).ToList();


                if (dataN1Result.Count > 0 && dicTimeByType.Count > 0)
                {
                    var isadded = new List<KittingPlan>();
                    foreach (var item in dataNResult)
                    {
                        var isexist = isadded.Where(e => e.Model == item.Model
                                       && e.Line == item.Line
                                       && e.SpecialPart == item.SpecialPart
                                       && e.Plant == item.Plant
                                       && e.Time == item.Time
                                       && e.PositionFA == item.PositionFA).Select(x => x);

                        item.KittingPlans.Clear();

                        if (isexist.Count() > 0)
                        {
                            continue;
                        }


                        var lstChildOtherNTime = dicTimeByType
                            .Where(e => e.Item1.Model == item.Model
                                        && e.Item1.Line == item.Line
                                        && e.Item1.SpecialPart == item.SpecialPart
                                        && e.Item1.Plant == item.Plant
                                        && e.Item1.Time == item.Time
                                        && e.Item1.PositionFA == item.PositionFA
                                        ) //Tuấn Anh
                                        .SelectMany(r => r.Item2)
                            .ToList();
                        
                        //if(item != null)
                        //{
                            isadded.Add(item);
                        //}

                        if (lstChildOtherNTime.Count > 0)
                        {

                            //if (item.Type == "N2" || item.Type == "N4")
                            //{
                                //abc1.AddRange(lstChildOtherNTime);
                            //}

                            item.KittingPlans.AddRange(lstChildOtherNTime);
                            res.Add(item);
                        }
                    }
                }

                //Kêt thúc Tuấn Anh thêm

                //Tuấn Anh thêm trường hợp không có N1

                if (dataN1Result.Count == 0)
                {
                    var isadd = new List<KittingPlan>();
                    foreach (var item in dataNResult)
                    {
                        var isexist = isadd.Where(e => e.Model == item.Model
                                       && e.Line == item.Line
                                       && e.SpecialPart == item.SpecialPart
                                       && e.Plant == item.Plant
                                       && e.Time == item.Time
                                       && e.PositionFA ==item.PositionFA).Select(x => x);

                        item.KittingPlans.Clear();

                        if (isexist.Count() > 0)
                        {
                            continue;
                        }

                       

                        var lstChildOtherNTime = dicTimeByType
                            .Where(e => e.Item1.Model == item.Model
                                        && e.Item1.Line == item.Line
                                        && e.Item1.SpecialPart == item.SpecialPart
                                        && e.Item1.Plant == item.Plant
                                        && e.Item1.Time == item.Time
                                        && e.Item1.PositionFA == item.PositionFA) //Tuấn Anh
                            .SelectMany(r => r.Item2)
                            .ToList();

                        isadd.Add(item);


                        //item.Quantity = dataNResult
                        //    .Where(s => s.Model == item.Model && s.Line == item.Line)
                        //    .GroupBy(x => new { x.Model, x.Line })
                        //    .Select(g => new KittingPlan
                        //    {
                        //        ModelQuantity = g.Sum(e => e.ModelQuantity)
                        //    })
                        //    .Select(a => a.ModelQuantity)
                        //    .First();
                        if (lstChildOtherNTime.Count > 0)
                        {

                            item.KittingPlans.AddRange(lstChildOtherNTime);
                            res.Add(item);
                        }
                    }
                }
                // Kết thúc
                return res;
            }

            else
            {
                // Lấy ra dữ liệu N2,N3,...
                var grByTimeAnType = dataRaw
                    .Where(e => e.Type != "N1")
                    .Select(g => new TimeAndType
                    {

                        Time = g.Time,
                        Type = g.Type,
                        Model = g.Model,
                        Line = g.Line,
                        Plant = g.Plant,
                        SpecialPart = (g.SpecialPart == "Carton" || g.SpecialPart == "Trolley") ? g.SpecialPart : "Normal",  // Grouping logic
                    })
                    .Distinct(new TimeAndTypeComparer())
                    .ToList(); // nhóm by Time And Type

                var dicTimeByType = new List<(CustomKey, List<KittingPlan>)>(); // lưu trữ các cặp Time by Type
                                                                                // Lưu lại dữ liệu đã lặp qua
                var skipTimes = new List<TimeAndType>();

                // Xử lý gộp danh sách N2 N3 N4...
                foreach (var modelStr in grByTimeAnType.Select(e => e.Model).Distinct())
                {

                    var lstByModel = grByTimeAnType.Where(e => e.Model == modelStr).ToList();
                    foreach (var item in lstByModel)
                    {
                        if (skipTimes.Any(e => e.Time == item.Time && e.Type == item.Type && e.Model == item.Model && item.Line == e.Line)) continue; // Tuấn Anh thêm chỗ line
                        string numberTake = new string(item.Type.SkipWhile(c => !char.IsDigit(c)).ToArray());

                        //Tuấn Anh
                        //Có thể chỗ này thiếu line
                        var dAdd = grByTimeAnType
                            .Where(e => !skipTimes.Any(x => x.Time == e.Time && x.Type == e.Type && x.Model == e.Model && e.SpecialPart == x.SpecialPart && e.Plant == x.Plant
                                && x.Line == e.Line) // Tuấn Anh Thêm dòng này
                                && e.Type == item.Type
                                && e.Model == item.Model
                                && e.SpecialPart == item.SpecialPart
                                && e.Plant == item.Plant
                                && e.Line == item.Line) // Tuấn Anh Thêm dòng ngày
                            .Take(int.Parse(numberTake))
                            .ToList();

                        var lstCon = dataRaw.Where(s => s.Model == item.Model
                                                         && s.Type == item.Type
                                                         && s.Line == item.Line
                                                         && s.Plant == item.Plant
                                                         && s.SpecialPart == item.SpecialPart
                                                         && dAdd.Select(e => e.Time).Contains(s.Time));

                        var lstConGrByMaterial = lstCon.GroupBy(g => g.Material).Select(r => new KittingPlan
                        {
                            Plant = r.First().Plant,
                            Category = r.First().Category,
                            Line = r.First().Line,
                            Time = r.First().Time,
                            Model = r.First().Model,
                            Quantity = r.Sum(r => r.Quantity),
                            Barcode = Function.CreateBarCode(new BarcodeFA()
                            {
                                Model = r.First().Model,
                                Line = r.First().Line,
                                RequirementDate = r.First().DeliveryDate?.ToString("dd/MM/yyyy"),
                                Time = r.First().Time,
                                Plant = r.First().Plant,
                                Category = r.First().Category,
                                CategoryJT = r.First().Category
                            }),
                            Type = r.First().Type,
                            DeliveryDate = r.First().DeliveryDate,
                            Descriptions = r.First().Descriptions,
                            CreatedBy = r.First().CreatedBy,
                            Unit = r.First().Unit,
                            Issue_Sloc = r.First().Issue_Sloc,
                            Receipt_Location = r.First().Receipt_Location,
                            ReservationNo = r.First().ReservationNo,
                            INS = r.First().INS,
                            Material = r.Key,
                            SpecialPart = r.First().SpecialPart,
                        }).ToList();

                        dicTimeByType.Add((new CustomKey
                        {
                            Model = item.Model,
                            Type = item.Type,
                            Line = item.Line,
                            Plant = item.Plant,
                            SpecialPart = item.SpecialPart,
                            Time = item.Time
                        }, lstConGrByMaterial));

                        skipTimes.AddRange(dAdd);
                    }
                }
                // Add lại data cho list con
                foreach (var item in dataN1Result)
                {
                    var lstChildOtherNTime = dicTimeByType
                        .Where(e => e.Item1.Model == item.Model
                                    && e.Item1.Line == item.Line
                                    && e.Item1.SpecialPart == item.SpecialPart
                                    && e.Item1.Plant == item.Plant
                                    && e.Item1.Time == item.Time)
                        .SelectMany(r => r.Item2)
                        .ToList();

                    //Tuấn Anh thêm
                    dicTimeByType.RemoveAll(e => e.Item1.Model == item.Model
                                    && e.Item1.Line == item.Line
                                    && e.Item1.SpecialPart == item.SpecialPart
                                    && e.Item1.Plant == item.Plant
                                    && e.Item1.Time == item.Time);


                    dataNResult.RemoveAll(e => e.Model == item.Model
                                    && e.Line == item.Line
                                    && e.SpecialPart == item.SpecialPart
                                    && e.Plant == item.Plant
                                    && e.Time == item.Time);



                    item.Quantity = dataN1Result
                        .Where(s => s.Model == item.Model && s.Line == item.Line)
                        .GroupBy(x => new { x.Model, x.Line })
                        .Select(g => new KittingPlan
                        {
                            ModelQuantity = g.Sum(e => e.ModelQuantity)
                        })
                        .Select(a => a.ModelQuantity)
                        .First();
                    item.KittingPlans.AddRange(lstChildOtherNTime);
                    res.Add(item);
                }


                // Tuấn Anh thêm
                dataNResult = dataNResult.OrderBy(e => e.Type.Trim('N')).ToList();


                if (dataN1Result.Count > 0 && dicTimeByType.Count > 0)
                {
                    var isadded = new List<KittingPlan>();
                    foreach (var item in dataNResult)
                    {
                        var isexist = isadded.Where(e => e.Model == item.Model
                                       && e.Line == item.Line
                                       && e.SpecialPart == item.SpecialPart
                                       && e.Plant == item.Plant
                                       && e.Time == item.Time
                                       ).Select(x => x);

                        item.KittingPlans.Clear();

                        if (isexist.Count() > 0)
                        {
                            continue;
                        }


                        var lstChildOtherNTime = dicTimeByType
                            .Where(e => e.Item1.Model == item.Model
                                        && e.Item1.Line == item.Line
                                        && e.Item1.SpecialPart == item.SpecialPart
                                        && e.Item1.Plant == item.Plant
                                        && e.Item1.Time == item.Time
                                        ) //Tuấn Anh
                                        .SelectMany(r => r.Item2)
                            .ToList();

                        //if(item != null)
                        //{
                        isadded.Add(item);
                        //}

                        if (lstChildOtherNTime.Count > 0)
                        {

                            //if (item.Type == "N2" || item.Type == "N4")
                            //{
                            //abc1.AddRange(lstChildOtherNTime);
                            //}

                            item.KittingPlans.AddRange(lstChildOtherNTime);
                            res.Add(item);
                        }
                    }
                }








                //Tuấn Anh thêm trường hợp không có N1


                if (dataN1Result.Count == 0)
                {

                    dataNResult = dataNResult.OrderBy(e => e.Type.Trim('N')).ToList();

                    var isadd = new List<KittingPlan>();
                    foreach (var item in dataNResult)
                    {
                        var isexist = isadd.Where(e => e.Model == item.Model
                                       && e.Line == item.Line
                                       && e.SpecialPart == item.SpecialPart
                                       && e.Plant == item.Plant
                                       && e.Time == item.Time).Select(x => x);

                        item.KittingPlans.Clear();

                        if (isexist.Count() > 0)
                        {
                            continue;
                        }
                        var lstChildOtherNTime = dicTimeByType
                            .Where(e => e.Item1.Model == item.Model
                                        && e.Item1.Line == item.Line
                                        && e.Item1.SpecialPart == item.SpecialPart
                                        && e.Item1.Plant == item.Plant
                                        && e.Item1.Time == item.Time
                                        )
                            .SelectMany(r => r.Item2)
                            .ToList();

                        isadd.AddRange(lstChildOtherNTime);

                        //item.Quantity = dataNResult
                        //    .Where(s => s.Model == item.Model && s.Line == item.Line)
                        //    .GroupBy(x => new { x.Model, x.Line })
                        //    .Select(g => new KittingPlan
                        //    {
                        //        ModelQuantity = g.Sum(e => e.ModelQuantity)
                        //    })
                        //    .Select(a => a.ModelQuantity)
                        //    .First();
                        if (lstChildOtherNTime.Count > 0)
                        {

                            item.KittingPlans.AddRange(lstChildOtherNTime);
                            res.Add(item);
                        }
                    }
                }
                // Kết thúc
                return res;
            }
          
        }

        public static DateTime? ParseDate(string dateString, bool isFormatFA = false)
        {
            var cultule = new System.Globalization.CultureInfo("en-GB");
            DateTime parsedDate;
            string[] formats;
            if (isFormatFA)
            {
                formats = new[] { "dd/MM/yyyy" };
            }
            else
            {
                formats = new[] { "dd-MMM-yy", "d-MMM-yy", "dd MMM yy", "d MMM yy", "dd/MM/yyyy", "yyyy/MM/dd", "MM/dd/yyyy", "MM/d/yyyy" };
            }
            bool success = DateTime.TryParseExact(
                dateString,
                formats,
                cultule,
                DateTimeStyles.None,
                out parsedDate
            );

            if (success)
            {
                return parsedDate;
            }
            return null;
        }
    }
}