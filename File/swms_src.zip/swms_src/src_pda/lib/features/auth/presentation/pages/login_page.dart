import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_shadows.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/utils/app_version.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/glass_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/common/liquid_glass_feature_card.dart';
import 'package:swms_finish_goods/features/auth/presentation/dialog/employee_code_sheet.dart';
import 'package:swms_finish_goods/features/auth/presentation/providers/auth_notifier.dart';
import 'package:swms_finish_goods/features/auth/presentation/widgets/login_status_row.dart';
import 'package:swms_finish_goods/gen/assets.gen.dart';
import 'package:swms_finish_goods/shared/presentation/providers/update_providers.dart';

@RoutePage()
class LoginPage extends ConsumerStatefulWidget {
  const LoginPage({super.key});

  @override
  ConsumerState<LoginPage> createState() => _LoginPageState();
}

// Đổi State sang ConsumerState để có ref
class _LoginPageState extends ConsumerState<LoginPage> {
  StreamSubscription<String>? _sub;
  bool _checkingUpdate = false;

  List<Feature> get kFeatures => [
    Feature(
      icon: Icons.description_outlined,
      title: LocaleKeys.login_feature_paperless_title.tr(),
      sub: LocaleKeys.login_feature_paperless_sub.tr(),
    ),
    Feature(
      icon: Icons.view_in_ar_outlined,
      title: LocaleKeys.login_feature_3d_mapping_title.tr(),
      sub: LocaleKeys.login_feature_3d_mapping_sub.tr(),
    ),
    Feature(
      icon: Icons.sync_outlined,
      title: LocaleKeys.login_feature_auto_sync_title.tr(),
      sub: LocaleKeys.login_feature_auto_sync_sub.tr(),
    ),
    Feature(
      icon: Icons.smart_toy_outlined,
      title: LocaleKeys.login_feature_automation_title.tr(),
      sub: LocaleKeys.login_feature_automation_sub.tr(),
    ),
  ];

  // Lắng nghe state change để navigate / show error
  @override
  void initState() {
    super.initState();
    _listen();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    _sub = pda.scanStream.listen((data) async {
      final isLoading = ref.read(authProvider).isLoading;

      if (isLoading ||
          _checkingUpdate || // đang check thì bỏ qua lần quét mới
          !mounted ||
          !(ModalRoute.of(context)?.isCurrent ?? false)) {
        return;
      }

      final hasUpdate = await _checkUpdate();
      if (hasUpdate || !mounted) return; // có bản mới -> không gọi login

      await _onBarcodeScanned(data);
    });
  }

  Future<bool> _checkUpdate() async {
    if (!mounted || _checkingUpdate) return true;
    setState(() => _checkingUpdate = true);
    try {
      return await ref.read(updateFlowProvider).start(context, manual: false);
    } catch (e) {
      debugPrint('Check update failed: $e');
      return false;
    } finally {
      if (mounted) setState(() => _checkingUpdate = false);
    }
  }

  // Scan barcode → gọi notifier (username = barcode, password = '')
  Future<void> _onBarcodeScanned(String barcode) async {
    final ok = await ref.read(authProvider.notifier).login(barcode, barcode);
    if (ok != true || !mounted) return;
    await context.router.replace(const HomeRoute());
  }

  // Mở PIN dialog, truyền callback để dialog gọi login
  void _openPinDialog() async {
    final code = await showEmployeeCodeSheet(context);
    if (code != null) {
      final ok = await ref.read(authProvider.notifier).login(code, code);
      if (ok != true || !mounted) return;
      await context.router.replace(const HomeRoute());
    }
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Watch state để lấy isLoading
    final authState = ref.watch(authProvider);
    final isLoading = authState.isLoading;

    final cardColor = Theme.of(context).colorScheme.surface;

    return AnnotatedRegion<SystemUiOverlayStyle>(
      value: const SystemUiOverlayStyle(
        statusBarColor: Colors.transparent,
        statusBarIconBrightness: Brightness.light,
      ),
      child: Scaffold(
        resizeToAvoidBottomInset: false,
        body: Stack(
          children: [
            // Background image
            Assets.images.background.image(
              fit: BoxFit.fitHeight,
              height: double.infinity,
            ),
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [
                    Color(0x55000000), // top tối hơn
                    Color(0x33000000), // bottom nhẹ hơn
                  ],
                ),
              ),
            ),
            SafeArea(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Align(
                    alignment: Alignment.centerRight,
                    child: Padding(
                      padding: const EdgeInsets.only(
                        right: AppDimens.md,
                        top: AppDimens.sm,
                      ),
                      child: AppGlassIconButton(
                        icon: Icons.settings_outlined,
                        onTap: () => context.pushRoute(const SettingsRoute()),
                      ),
                    ),
                  ),
                  const SizedBox(height: AppDimens.sm),
                  Center(
                    child: Column(
                      children: [
                        Container(
                          width: 68,
                          height: 68,
                          decoration: BoxDecoration(
                            borderRadius: BorderRadius.circular(AppDimens.rBtn),
                            color: Colors.white,
                            boxShadow: AppShadows.s4,
                          ),
                          padding: const EdgeInsets.all(AppDimens.xs),
                          child: Assets.images.logo.image(),
                        ),
                        const SizedBox(height: AppDimens.xs),
                        Text(
                          LocaleKeys.login_app_name.tr(),
                          style: AppTextStyles.h1.copyWith(
                            color: Colors.white,
                            fontSize: 26,
                            letterSpacing: -0.3,
                          ),
                        ),
                        Text(
                          LocaleKeys.login_app_subtitle.tr(),
                          style: AppTextStyles.caption.copyWith(
                            color: Colors.white.withValues(alpha: 0.7),
                            letterSpacing: 2.5,
                          ),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: AppDimens.md),
                  GridView.count(
                    crossAxisCount: 2,
                    shrinkWrap: true,
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppDimens.md,
                    ),
                    physics: const NeverScrollableScrollPhysics(),
                    mainAxisSpacing: AppDimens.sm,
                    crossAxisSpacing: AppDimens.sm,
                    childAspectRatio: 3,
                    children: kFeatures
                        .map((f) => LiquidGlassFeatureCard(feature: f))
                        .toList(),
                  ),
                  const Spacer(),
                  Container(
                    padding: const EdgeInsets.all(AppDimens.md),
                    decoration: BoxDecoration(
                      color: cardColor,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(AppDimens.rCard),
                      ),
                      boxShadow: AppShadows.s4,
                    ),
                    child: Column(
                      children: [
                        // Disable khi đang loading
                        BarcodeScannerButton(
                          state: (isLoading)
                              ? ScannerState.loading
                              : ScannerState.scanning,
                          scanningLabel: LocaleKeys.login_scan_label.tr(),
                        ),
                        const SizedBox(height: AppDimens.sm),
                        LoginStatusRow(scanning: isLoading),
                        const SizedBox(height: AppDimens.sm),
                        AppButton(
                          label: LocaleKeys.login_pin_button.tr(),
                          variant: AppButtonVariant.neutral,
                          // Disable khi đang loading
                          onPressed: isLoading ? null : _openPinDialog,
                        ),
                        const SizedBox(height: AppDimens.sm),
                        Center(
                          child: Text(
                            LocaleKeys.login_version.tr(
                              namedArgs: {'version': AppVersion.fullVersion},
                            ),
                            style: AppTextStyles.caption.copyWith(
                              color: context.swms.text4,
                              letterSpacing: 0.4,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
