﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("FactoryMaster")]
    public class FactoryMaster
    {
        public int ID { get; set; }
        public string? FactoryCode { get; set; }
        public string? FactoryName { get; set; }
    }
}
