namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

// Entity cho Vanning trên PDA: kiểm container, pallet thuộc chuyến, pallet đôi (cọc).
// Tên property khớp alias trong SQL của TripVanningRepository.

/// <summary>Hạng mục kiểm container. Mã gửi lên từ PDA (ContainerCondition.code) —
/// báo cáo group theo mã: đổi nhãn được, KHÔNG đổi mã.</summary>
public static class ContainerConditions
{
    public const string Floor = "floor";
    public const string Dry = "dry";
    public const string Intact = "intact";
    public const string Door = "door";

    public static readonly IReadOnlyList<string> All = new[] { Floor, Dry, Intact, Door };
}

public static class InspectionResults
{
    public const string Pass = "pass";
    public const string Fail = "fail";
}

/// <summary>1 dòng wms.shipment_trip_inspections.</summary>
public class TripInspectionRow
{
    public long Id { get; set; }
    public long TripId { get; set; }
    public string Result { get; set; } = "";
    /// <summary>Mã hạng mục đạt, ngăn bởi dấu phẩy.</summary>
    public string? PassedConditions { get; set; }
    public string? Note { get; set; }
    public string? ContainerNo { get; set; }
    public DateTime InspectedAt { get; set; }
    public string? InspectedBy { get; set; }
}

/// <summary>
/// 1 pallet tra theo mã quét. InScope = pallet thuộc SI của chuyến
/// (shipment_instruction_pallets chưa skipped, SI đang gắn chuyến).
/// </summary>
public class TripPalletInfo
{
    public long Id { get; set; }
    public string Code { get; set; } = "";
    public string? SiNo { get; set; }
    public int CategoryCode { get; set; }
    public string DetailLevel { get; set; } = "";
    public int BoxCount { get; set; }
    public int Pcs { get; set; }
    public string? LocatorCode { get; set; }
    public bool InScope { get; set; }
}

/// <summary>1 thùng tra theo số thùng quét. InScope = pallet chứa nó thuộc chuyến,
/// hoặc số thùng nằm trong packing list (shipment_instruction_boxes) của SI trên chuyến.</summary>
public class TripBoxInfo
{
    public long Id { get; set; }
    public string BoxNo { get; set; } = "";
    public long LotId { get; set; }
    public string LotCode { get; set; } = "";
    public int Pcs { get; set; }
    public string? LocatorCode { get; set; }
    public bool InScope { get; set; }
}

/// <summary>1 cọc đã ghép thật của chuyến (wms.shipment_trip_columns) — theo cọc C0x của Stowage Plan.
/// CocNo = số trong mã cọc (C07 -> 7), dùng làm unit_no của ảnh "Cọc pallet".</summary>
public class TripStackRow
{
    public long Id { get; set; }
    public long TripId { get; set; }
    public string ColumnCode { get; set; } = "";
    public int CocNo => TripStowageRules.CocNoOf(ColumnCode);
    public long BottomPalletId { get; set; }
    public string BottomCode { get; set; } = "";
    /// <summary>NULL = cọc 1 tầng.</summary>
    public long? TopPalletId { get; set; }
    public string? TopCode { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    /// <summary>NULL = chưa xếp vào cont.</summary>
    public DateTime? PlacedAt { get; set; }
    public string? PlacedBy { get; set; }
}
