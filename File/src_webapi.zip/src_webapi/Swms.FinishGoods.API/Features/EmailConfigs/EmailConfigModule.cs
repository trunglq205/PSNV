using Swms.FinishGoods.API.Features.EmailConfigs.Business;
using Swms.FinishGoods.API.Features.EmailConfigs.DataAccess;

namespace Swms.FinishGoods.API.Features.EmailConfigs;

public static class EmailConfigModule
{
    public static IServiceCollection AddEmailConfigFeature(this IServiceCollection services)
    {
        services.AddScoped<IEmailConfigService, EmailConfigService>();
        services.AddScoped<IEmailConfigRepository, EmailConfigRepository>();
        return services;
    }
}
