/// ─────────────────────────────────────────────────────────────
///  Part Card — enum bước + chế độ phiếu + helper dùng chung.
/// ─────────────────────────────────────────────────────────────
library;

/// Bước của quy trình in Part Card MỚI.
/// `number` = index (khớp với [AppStepperBar.current], giống ReceivingStep).
enum PartCardStep { input, confirm, printCard }

extension PartCardStepX on PartCardStep {
  int get number => index + 1;

  static PartCardStep fromNumber(int number) =>
      PartCardStep.values[(number - 1).clamp(
        0,
        PartCardStep.values.length - 1,
      )];
}

/// Chế độ phiếu — KHÔNG gắn với loại hàng, chỉ khác nhau ở SỐ MÃ trên 1 tem.
///
/// Nghiệp vụ nào cũng dùng được: chỉ cần 1 tem gom nhiều mã thì bật [multi].
enum PartCardMode {
  /// 1 mã / 1 tem — layout cũ (Model · Qty · Origin).
  single,

  /// Nhiều mã / 1 tem — có PSNV PO, CUS PO, cột Box và dòng Total.
  multi,
}

extension PartCardModeX on PartCardMode {
  bool get isSingle => this == PartCardMode.single;

  bool get isMulti => this == PartCardMode.multi;

  PartCardMode get toggled =>
      isMulti ? PartCardMode.single : PartCardMode.multi;
}

/// Cate in tem gom nhiều mã — chọn Cate này thì tự bật [PartCardMode.multi].
const partCardMultiCategories = [312, 314];

/// Thao tác trên tem ĐÃ IN — quét tem ở Home rồi chọn.
/// Màn in Part Card chỉ phục vụ in mới, không làm mấy việc này.
enum PartCardAction {
  /// In lại đúng Card_ID cũ + ghi đè bản ghi cũ.
  edit,

  /// Tem 1 mã → N tem 1 mã, chia số pcs. Tem cũ bị huỷ trên server.
  split,

  /// N tem → 1 tem nhiều mã. Các tem cũ bị huỷ trên server.
  merge,
}

/// Đuôi mã FG hợp lệ (sau dấu `-` cuối cùng).
const _fgSuffixes = {'SP', 'MW', 'MW1', 'DP', 'DP1'};

final _fieldSeparator = RegExp(r'[;|,\t\r\n]');

/// Lấy mã model (FG) từ chuỗi quét được.
///
/// - Quét **kitting card**: `MODEL;LOT;QTY...` → lấy field ĐẦU TIÊN.
/// - Quét **trực tiếp model**: dùng nguyên chuỗi (đã trim).
/// - Mã semi (`…-V4`) được đổi về mã FG, xem [semiToModel].
///
/// [semiToFg]: bảng tra semi → FG (key viết HOA), dùng cho mã semi bị nén
/// vì giới hạn 18 ký tự. Không có trong bảng thì trả nguyên mã quét.
///
/// Trả `null` nếu chuỗi rỗng / không tách được field nào.
String? modelFromScan(String raw, {Map<String, String> semiToFg = const {}}) {
  for (final part in raw.split(_fieldSeparator)) {
    final token = part.trim().toUpperCase();
    if (token.isEmpty) continue;
    return semiToModel(token, semiToFg: semiToFg);
  }
  return null;
}

/// Đổi mã semi về mã FG. [code] phải đã trim + viết HOA.
///
/// 1. Có trong [semiToFg] → lấy theo bảng (luôn ưu tiên).
/// 2. `X-V4`  → `X`        (FG ≤ 15 ký tự: `H0102-3J20-SP-V4` → `H0102-3J20-SP`)
/// 3. `X-SPV4` → `X-SP`    (FG 16 ký tự, gạch trước V4 bị bỏ;
///    chỉ khi phần sau dấu `-` cuối là đuôi FG hợp lệ: SP/MW/MW1/DP/DP1)
/// 4. Còn lại (mã nén kiểu `H20013700BP/ASSPV4`, hoặc mã không có V4)
///    → trả nguyên, KHÔNG đoán.
String semiToModel(String code, {Map<String, String> semiToFg = const {}}) {
  final mapped = semiToFg[code];
  if (mapped != null) return mapped;

  if (code.endsWith('-V4')) {
    return code.substring(0, code.length - 3);
  }

  if (code.endsWith('V4')) {
    final body = code.substring(0, code.length - 2);
    final dash = body.lastIndexOf('-');
    if (dash >= 0 && _fgSuffixes.contains(body.substring(dash + 1))) {
      return body;
    }
  }

  return code;
}

/// Chuỗi quét có phải payload QR của 1 Part Card ĐÃ IN không
/// (`ID=...|CATE=...|MFD=...|MODELS=...`). Kitting card / mã model không
/// bao giờ có field `ID=`.
bool isPartCardPayload(String raw) =>
    RegExp(r'(^|\|)ID=[^|]+').hasMatch(raw.trim());

/// Số thập phân trong payload tem. Nhận cả dấu chấm lẫn dấu PHẨY thập phân:
/// tem in từ PDA ghi `1.5`, tem in từ web ghi theo culture vi-VN `1,5000`.
/// Bỏ qua phần chữ theo sau (đơn vị). Không đọc được → null.
double? parsePayloadDecimal(String? raw) {
  if (raw == null) return null;
  final m = RegExp(r'^\s*(\d+(?:[.,]\d+)?)').firstMatch(raw);
  return m == null ? null : double.tryParse(m.group(1)!.replaceAll(',', '.'));
}

/// Tách `DIM=` trên tem thành `[L, W, H]`. Không đủ 3 số → null.
///
/// Tách theo dấu NHÂN trước (`x`, `X`, `*`, `×`) rồi mới đọc từng số — không
/// được quét số trực tiếp, vì dấu phẩy trong `25,0000x35,0000x20,0000` là dấu
/// thập phân chứ không phải ngăn cách 6 số.
List<double>? parseDimension(String raw) {
  final parts = raw.split(RegExp(r'[xX*×]'));
  if (parts.length < 3) return null;

  final nums = <double>[];
  for (final part in parts.take(3)) {
    final n = parsePayloadDecimal(part);
    if (n == null) return null;
    nums.add(n);
  }
  return nums;
}

/// Bỏ số 0 thừa: 24.00 → 24, 24.10 → 24.1
String formatDecimal(num value) {
  var s = value.toStringAsFixed(2);
  if (s.contains('.')) {
    s = s.replaceFirst(RegExp(r'0+$'), '').replaceFirst(RegExp(r'\.$'), '');
  }
  return s;
}

/// dd/MM/yyyy — hiển thị UI + text in trên nhãn.
String formatDisplayDate(DateTime d) =>
    '${d.day.toString().padLeft(2, '0')}/'
    '${d.month.toString().padLeft(2, '0')}/${d.year}';

/// yyyy-MM-dd — dùng trong payload QR (MFD=).
String formatIsoDate(DateTime d) =>
    '${d.year}-${d.month.toString().padLeft(2, '0')}-'
    '${d.day.toString().padLeft(2, '0')}';
