import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';

/// Căn tiêu đề. [start] dùng cho dialog kiểu danh sách (menu ngôn ngữ…),
/// [center] cho dialog thao tác một việc.
enum AppDialogAlign { center, start }

/// Nền header. Mặc định [plain] = cùng màu thân.
enum AppDialogHeaderTone {
  /// Không tô nền — dialog ngắn, một việc.
  plain,

  /// Xám rất nhạt (`card2`) — tách header khỏi danh sách cuộn bên dưới.
  muted,

  /// Xanh nhạt (`primaryTint`) — dialog cần nổi, có icon.
  accent,
}

/// Một nút ở thanh đáy dialog.
///
/// `onPressed = null` -> nút mờ và không bấm được (AppButton tự lo), KHÔNG ẩn
/// nút: ẩn đi thì thanh đáy đổi bố cục giữa chừng, người dùng mất điểm tựa.
@immutable
class AppDialogAction {
  const AppDialogAction({
    required this.label,
    this.onPressed,
    this.variant = AppButtonVariant.primary,
    this.icon,
    this.isLoading = false,
  });

  /// Nút huỷ: đóng dialog và trả [result] (mặc định null = "người dùng huỷ").
  factory AppDialogAction.cancel(
      BuildContext context, {
        String? label,
        Object? result,
      }) {
    return AppDialogAction(
      label: label ?? LocaleKeys.common_cancel.tr(),
      variant: AppButtonVariant.neutral,
      onPressed: () => Navigator.pop(context, result),
    );
  }

  /// Nút đóng cho dialog chỉ đọc (không có gì để xác nhận).
  factory AppDialogAction.close(BuildContext context, {String? label}) {
    return AppDialogAction(
      label: label ?? LocaleKeys.common_close.tr(),
      variant: AppButtonVariant.neutral,
      onPressed: () => Navigator.pop(context),
    );
  }

  /// Nút xác nhận. Truyền `onPressed: null` khi form chưa hợp lệ.
  factory AppDialogAction.confirm({
    required VoidCallback? onPressed,
    String? label,
    AppButtonVariant variant = AppButtonVariant.primary,
    IconData? icon,
    bool isLoading = false,
  }) {
    return AppDialogAction(
      label: label ?? LocaleKeys.common_confirm.tr(),
      onPressed: onPressed,
      variant: variant,
      icon: icon,
      isLoading: isLoading,
    );
  }

  final String label;
  final VoidCallback? onPressed;
  final AppButtonVariant variant;
  final IconData? icon;
  final bool isLoading;
}

/// Icon tròn nền tint đặt trên tiêu đề — dùng cho dialog báo kết quả
/// (thành công / lỗi / hỏi). Kích thước cố định để 4 loại dialog cao bằng nhau.
class AppDialogHeroIcon extends StatelessWidget {
  const AppDialogHeroIcon({
    super.key,
    required this.icon,
    required this.color,
    this.size = 64,
  });

  final IconData icon;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        color: color.withValues(alpha: 0.12),
        shape: BoxShape.circle,
      ),
      child: Icon(icon, color: color, size: size * 0.5625),
    );
  }
}

/// Khung dialog dùng chung: header (hero · icon · tiêu đề · phụ đề · nút phụ)
/// + thân + thanh nút đáy. Mọi dialog trong app dựng từ đây để cùng một bo góc,
/// cùng khoảng cách, cùng kiểu chữ — trước đây mỗi file tự dựng `Dialog` nên
/// sửa design token phải đi sửa từng chỗ và luôn sót.
///
/// Chỉ lo phần VỎ, không giữ state: phần thân và trạng thái nút do widget gọi
/// tự quản (StatefulWidget bọc ngoài, ValueListenableBuilder, Riverpod…).
///
/// ```dart
/// AppDialog(
///   title: 'Chọn khu',
///   child: ...,
///   actions: [
///     AppDialogAction.cancel(context),
///     AppDialogAction.confirm(onPressed: _canSave ? _save : null),
///   ],
/// );
/// ```
class AppDialog extends StatelessWidget {
  const AppDialog({
    super.key,
    this.hero,
    this.title,
    this.subtitle,
    this.message,
    this.icon,
    this.headerTrailing,
    this.headerTone,
    this.align = AppDialogAlign.center,
    this.titleStyle,
    this.child,
    this.actions = const [],
    this.scrollable = false,
    this.maxBodyHeight,
    this.bodyPadding,
    this.dividers = false,
    this.backgroundColor,
    this.insetPadding,
    this.maxTextScaleFactor,
  });

  /// Khối nổi bật trên tiêu đề, canh giữa — thường là [AppDialogHeroIcon].
  final Widget? hero;

  /// Tiêu đề. Bỏ trống thì không dựng header.
  final String? title;

  /// Dòng phụ dưới tiêu đề (mã hàng đang xử lý, số máy in tìm thấy…).
  final String? subtitle;

  /// Nội dung chữ đơn giản — dùng cho dialog xác nhận, khỏi phải dựng [child].
  /// Có cả [message] và [child] thì message nằm trên.
  final String? message;

  /// Icon nhỏ bên trái tiêu đề.
  final IconData? icon;

  /// Nút phụ góc phải header (làm mới, trợ giúp…).
  final Widget? headerTrailing;

  /// Nền header. Bỏ trống: [AppDialogHeaderTone.muted] khi [dividers] = true,
  /// ngược lại [AppDialogHeaderTone.plain].
  final AppDialogHeaderTone? headerTone;

  final AppDialogAlign align;

  /// Ghi đè kiểu chữ tiêu đề. Mặc định: [AppTextStyles.h2], hoặc
  /// [AppTextStyles.title] khi [dividers] = true (header dạng thanh).
  final TextStyle? titleStyle;

  final Widget? child;

  /// Thanh nút đáy. Rỗng = không có thanh nút (dialog chọn xong là đóng).
  final List<AppDialogAction> actions;

  /// Bọc thân trong [SingleChildScrollView]. Nội dung dài thì bật, kèm
  /// [maxBodyHeight] để dialog không cao bằng màn hình.
  final bool scrollable;
  final double? maxBodyHeight;

  /// Ghi đè padding thân. `EdgeInsets.zero` cho danh sách tràn viền.
  final EdgeInsetsGeometry? bodyPadding;

  /// Vẽ đường kẻ ngăn header / thân / thanh nút. Dùng cho dialog danh sách,
  /// nơi nội dung cuộn qua lại dưới header.
  final bool dividers;

  /// Nền dialog. Mặc định `swms.card` (trắng) — KHÔNG để null: null rơi về
  /// `colorScheme.surface`, mà surface trong theme này là `bg` (#F5F7FA) nên
  /// dialog xám hơn thẻ nội dung phía sau nó.
  final Color? backgroundColor;

  final EdgeInsets? insetPadding;

  /// Khoá cỡ chữ hệ thống. Đặt 1.3 cho dialog có vòng quay / lưới ô cố định
  /// chiều cao, nếu không chữ phóng to sẽ cắt mất nội dung.
  final double? maxTextScaleFactor;

  bool get _hasHeader =>
      hero != null || title != null || subtitle != null || icon != null;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    Widget content = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        if (_hasHeader) _Header(dialog: this),
        if (child != null || message != null) _buildBody(context),
        if (actions.isNotEmpty) _buildFooter(context),
      ],
    );

    final scale = maxTextScaleFactor;
    if (scale != null) {
      content = MediaQuery.withClampedTextScaling(
        maxScaleFactor: scale,
        child: content,
      );
    }

    return Dialog(
      backgroundColor: backgroundColor ?? swms.card,
      // Material 3 trộn `colorScheme.surfaceTint` vào nền theo elevation ->
      // trắng bị ngả tím/xám. Tắt hẳn thì nền đúng bằng token.
      surfaceTintColor: Colors.transparent,
      elevation: 10,
      shadowColor: Colors.black.withValues(alpha: .18),
      insetPadding:
      insetPadding ??
          const EdgeInsets.symmetric(horizontal: 32, vertical: 24),
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        // Viền mảnh: nền trắng trên barrier nhạt dễ "chảy" vào nền sau.
        side: BorderSide(color: swms.border),
      ),
      clipBehavior: Clip.antiAlias,
      child: content,
    );
  }

  Widget _buildBody(BuildContext context) {
    final swms = context.swms;

    final padding =
        bodyPadding ??
            (dividers
                ? const EdgeInsets.all(AppDimens.sm)
                : const EdgeInsets.fromLTRB(
              AppDimens.md,
              AppDimens.sm,
              AppDimens.md,
              0,
            ));

    final text = message;
    Widget body;
    if (text == null) {
      body = child!;
    } else {
      final messageText = Text(
        text,
        textAlign: align == AppDialogAlign.start
            ? TextAlign.start
            : TextAlign.center,
        style: AppTextStyles.body.copyWith(height: 1.4, color: swms.text3),
      );
      body = child == null
          ? messageText
          : Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          messageText,
          const SizedBox(height: AppDimens.md),
          child!,
        ],
      );
    }

    Widget content = scrollable
        ? SingleChildScrollView(padding: padding, child: body)
        : Padding(padding: padding, child: body);

    final maxHeight = maxBodyHeight;
    if (maxHeight != null) {
      content = ConstrainedBox(
        constraints: BoxConstraints(maxHeight: maxHeight),
        child: content,
      );
    }

    // Flexible (không Expanded): dialog vẫn ôm sát nội dung ngắn, chỉ co lại
    // khi thân dài hơn chỗ còn trống.
    return Flexible(child: content);
  }

  Widget _buildFooter(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: dividers
          ? const EdgeInsets.all(AppDimens.sm)
          : const EdgeInsets.all(AppDimens.md),
      decoration: dividers
          ? BoxDecoration(border: Border(top: BorderSide(color: swms.border)))
          : null,
      child: Row(
        children: [
          for (var i = 0; i < actions.length; i++) ...[
            if (i > 0) const SizedBox(width: AppDimens.sm + AppDimens.xs),
            Expanded(child: _actionButton(actions[i])),
          ],
        ],
      ),
    );
  }

  Widget _actionButton(AppDialogAction a) => AppButton(
    label: a.label,
    variant: a.variant,
    icon: a.icon,
    isLoading: a.isLoading,
    onPressed: a.onPressed,
  );
}

class _Header extends StatelessWidget {
  const _Header({required this.dialog});

  final AppDialog dialog;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    // Có icon hoặc nút phụ -> header thành hàng ngang, chữ buộc phải canh trái
    // (canh giữa trong khoảng còn lại trông như bị lệch).
    final isRow = dialog.icon != null || dialog.headerTrailing != null;
    final isStart = isRow || dialog.align == AppDialogAlign.start;
    final textAlign = isStart ? TextAlign.start : TextAlign.center;

    final tone =
        dialog.headerTone ??
            (dialog.dividers
                ? AppDialogHeaderTone.muted
                : AppDialogHeaderTone.plain);

    final background = switch (tone) {
      AppDialogHeaderTone.plain => null,
      AppDialogHeaderTone.muted => swms.card2,
      AppDialogHeaderTone.accent => swms.primaryTint,
    };

    // Header xanh -> tiêu đề theo tông xanh đậm cho ăn nền.
    final titleColor = tone == AppDialogHeaderTone.accent
        ? swms.primaryDark
        : swms.text1;

    final title = dialog.title;
    final subtitle = dialog.subtitle;
    final hero = dialog.hero;

    final texts = Column(
      mainAxisSize: MainAxisSize.min,
      crossAxisAlignment: isStart
          ? CrossAxisAlignment.start
          : CrossAxisAlignment.center,
      children: [
        if (title != null)
          Text(
            title,
            textAlign: textAlign,
            style:
            dialog.titleStyle ??
                (dialog.dividers ? AppTextStyles.title : AppTextStyles.h2)
                    .copyWith(color: titleColor),
          ),
        if (subtitle != null) ...[
          const SizedBox(height: AppDimens.xs),
          Text(
            subtitle,
            textAlign: textAlign,
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
        ],
      ],
    );

    final Widget headerContent = isRow
        ? Row(
      children: [
        if (dialog.icon != null) ...[
          Icon(dialog.icon, size: 18, color: swms.primary),
          const SizedBox(width: AppDimens.sm),
        ],
        Expanded(child: texts),
        if (dialog.headerTrailing != null) dialog.headerTrailing!,
      ],
    )
        : texts;

    return Container(
      padding: dialog.dividers
          ? const EdgeInsets.fromLTRB(AppDimens.md, 12, AppDimens.sm, 12)
          : EdgeInsets.fromLTRB(
        AppDimens.md,
        // Có hero thì nới trên cho vòng tròn thở.
        hero == null ? AppDimens.md : AppDimens.lg,
        AppDimens.md,
        AppDimens.sm,
      ),
      decoration: BoxDecoration(
        color: background,
        border: dialog.dividers
            ? Border(bottom: BorderSide(color: swms.border))
            : null,
      ),
      child: hero == null
          ? headerContent
          : Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          hero,
          const SizedBox(height: AppDimens.md),
          headerContent,
        ],
      ),
    );
  }
}

/// Mở dialog với lớp phủ nhạt hơn mặc định của Flutter (black54 làm cả màn
/// tối sầm, dialog trắng trông như bị ám xám).
///
/// Dùng thay cho `showDialog` ở mọi chỗ mở [AppDialog].
Future<T?> showAppDialog<T>(
    BuildContext context, {
      required WidgetBuilder builder,
      bool barrierDismissible = true,
    }) {
  return showDialog<T>(
    context: context,
    builder: builder,
    barrierDismissible: barrierDismissible,
    barrierColor: Colors.black.withValues(alpha: .32),
  );
}

/// Dialog xác nhận nhanh: tiêu đề + mô tả + Huỷ / Xác nhận.
/// Trả `false` khi người dùng huỷ hoặc bấm ra ngoài.
///
/// Đặt [confirmVariant] = [AppButtonVariant.danger] cho hành động phá dữ liệu.
Future<bool> showConfirmDialog(
    BuildContext context, {
      required String title,
      String? message,
      String? confirmLabel,
      String? cancelLabel,
      AppButtonVariant confirmVariant = AppButtonVariant.primary,
    }) async {
  final ok = await showAppDialog<bool>(
    context,
    builder: (ctx) => AppDialog(
      title: title,
      message: message,
      actions: [
        AppDialogAction.cancel(ctx, label: cancelLabel, result: false),
        AppDialogAction.confirm(
          label: confirmLabel,
          variant: confirmVariant,
          onPressed: () => Navigator.pop(ctx, true),
        ),
      ],
    ),
  );
  return ok ?? false;
}