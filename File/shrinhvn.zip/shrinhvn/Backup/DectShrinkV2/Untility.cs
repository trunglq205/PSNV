﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DectShrinkV2
{
    class Untility
    {
        public static C_Parameter _para = new C_Parameter();
    }
}
