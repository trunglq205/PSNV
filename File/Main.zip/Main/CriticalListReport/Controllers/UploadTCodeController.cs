﻿using ClosedXML.Excel;
using CriticalListReport.Helpers;
using CriticalListReport.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Text;

namespace CriticalListReport.Controllers
{
    [Authorize]
    [Authorize(Roles = "Admin,User")]
    public class UploadTCodeController : Controller
    {
        private readonly ILogger<UploadTCodeController> _logger;
        private readonly AppDbContext _context;
        private readonly string _connectionString;
        private readonly string _uploadPath;
        private readonly string _formatPath;

        private const string _errorExcep = "Có lỗi xảy ra. Kiểm tra lại format hoặc liên hệ quản trị viên!";

        // Mapping: InputName -> (TableName, FormatFileName, FirstRow)
        private readonly Dictionary<string, (string Table, string Format, int FirstRow)> _fileConfig = new()
        {
            { "fileZCV006", ("zcv006_STG", "zcv006.fmt", 2) },
            { "fileZCV008", ("ZCV008_STG", "ZCV008.fmt", 2) },
            { "fileZMV022", ("ZMV022_STG", "ZMV022.fmt", 2) },
            { "fileZMV032", ("ZMV032_STG", "ZMV032.fmt", 2) },
            { "fileZMV106", ("ZMV106_STG", "ZMV106.fmt", 2) },
            { "fileZMV132", ("ZMV132_STG", "ZMV132.fmt", 3) }
        };

        public UploadTCodeController(
            ILogger<UploadTCodeController> logger,
            AppDbContext context,
            IConfiguration configuration,
            IWebHostEnvironment env)
        {
            _logger = logger;
            _context = context;
            _connectionString = configuration.GetConnectionString("DefaultConnection")!;

            // Paths trong wwwroot
            _uploadPath = Path.Combine(env.WebRootPath, "Tcode");
            _formatPath = Path.Combine(env.WebRootPath, "fmt");

            // Tạo folder upload nếu chưa có
            Directory.CreateDirectory(_uploadPath);
        }

        [HttpGet]
        public async Task<IActionResult> Index()
        {
            // Lấy ValidDate hiện tại từ NumberColumnShow (DataSource = 1 cho TCode)
            var columnInfo = await _context.NumberColumnShows
                .FirstOrDefaultAsync(x => x.DataSource == 1);

            if (columnInfo != null && !string.IsNullOrEmpty(columnInfo.EndValidDate))
            {
                if (DateTime.TryParse(columnInfo.EndValidDate, out var parsedDate))
                {
                    ViewData["ValidDate"] = parsedDate.ToString("yyyy-MM-dd");
                }
            }

            return View();
        }

        [HttpPost]
        [RequestSizeLimit(209715200)] // 200MB
        public async Task<IActionResult> UploadAllAndGenerate(
        IFormFile? fileZCV006,
        IFormFile? fileZCV008,
        IFormFile? fileZMV022,
        IFormFile? fileZMV032,
        IFormFile? fileZMV106,
        IFormFile? fileZMV132,
        DateTime? validDate)
        {
            var tempFiles = new List<string>();
            try
            {
                // === VALIDATE VALID DATE (REQUIRED) ===
                if (!validDate.HasValue)
                {
                    return Json(new { success = false, message = "Valid Date is required! Please select a date." });
                }

                var files = new Dictionary<string, IFormFile?>
                {
                    { "fileZCV006", fileZCV006 },
                    { "fileZCV008", fileZCV008 },
                    { "fileZMV022", fileZMV022 },
                    { "fileZMV032", fileZMV032 },
                    { "fileZMV106", fileZMV106 },
                    { "fileZMV132", fileZMV132 }
                };

                if (files.Values.All(f => f == null || f.Length == 0))
                {
                    return Json(new { success = false, message = "Vui lòng chọn ít nhất một file để upload!" });
                }

                // === CẬP NHẬT VALID DATE ===
                var columnInfo = await _context.NumberColumnShows
                    .FirstOrDefaultAsync(x => x.DataSource == 1);

                if (columnInfo != null)
                {
                    columnInfo.EndValidDate = validDate.Value.ToString("dd-MMM-yy");
                    columnInfo.IsOverride = false;
                }
                else
                {
                    // Tạo mới nếu chưa có record cho TCode
                    _context.NumberColumnShows.Add(new NumberColumnShow
                    {
                        DataSource = 1,
                        EndValidDate = validDate.Value.ToString("dd-MMM-yy"),
                        IsOverride = false
                    });
                }
                await _context.SaveChangesAsync();

                int totalRows = 0;
                var results = new List<string>();
                var uploadedFiles = new List<string>();

                await using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync();

                foreach (var (inputName, file) in files)
                {
                    if (file == null || file.Length == 0)
                        continue;

                    var config = _fileConfig[inputName];
                    uploadedFiles.Add(file.FileName);

                    var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(file.FileName)}";
                    var filePath = Path.Combine(_uploadPath, fileName);
                    tempFiles.Add(filePath);

                    await using (var stream = new FileStream(filePath, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }

                    var count = await BulkInsertAsync(connection, filePath, config.Table, config.Format, config.FirstRow);
                    totalRows += count;
                    results.Add($"{config.Table}: {count:N0} dòng");

                    _logger.LogInformation("BULK INSERT {Table}: {Count} rows", config.Table, count);
                }

                _logger.LogInformation("Executing sp_CriticalListReport_TCode...");
                await using var cmd = new SqlCommand("sp_CriticalListReport_TCode", connection)
                {
                    CommandType = CommandType.StoredProcedure,
                    CommandTimeout = 600
                };
                await cmd.ExecuteNonQueryAsync();

                await using var countCmd = new SqlCommand("SELECT COUNT(*) FROM tblShortageSimulation WHERE DataSource = 1", connection);
                var reportRows = (int)(await countCmd.ExecuteScalarAsync() ?? 0);

                // Log với thêm thông tin validDate
                _context.ActionHistories.Add(new ActionHistory
                {
                    Username = User.Identity?.Name ?? "Anonymous",
                    ActionName = "ImportTCode",
                    FileName = string.Join(", ", uploadedFiles) + $" | ValidDate: {validDate:dd-MMM-yyyy}"
                });
                await _context.SaveChangesAsync();

                return Json(new
                {
                    success = true,
                    message = $"Import thành công {totalRows:N0} dòng. Report đã tạo với {reportRows:N0} records. Valid Date: {validDate:dd-MMM-yyyy}",
                    totalRows,
                    reportRows,
                    details = results
                });
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in UploadAllAndGenerate");
                LogHelper.WriteError(ex, "UploadAllAndGenerate");
                return Json(new { success = false, message = _errorExcep + " - " + ex.Message });
            }
            finally
            {
                foreach (var tempFile in tempFiles)
                {
                    try
                    {
                        if (System.IO.File.Exists(tempFile))
                            System.IO.File.Delete(tempFile);
                    }
                    catch (Exception ex)
                    {
                        _logger.LogWarning(ex, "Failed to delete temp file: {File}", tempFile);
                        LogHelper.WriteError(ex, $"DeleteTempFile: {tempFile}");
                    }
                }
            }
        }

        /// <summary>
        /// BULK INSERT sử dụng file .fmt
        /// </summary>
        private async Task<int> BulkInsertAsync(SqlConnection connection, string filePath, string tableName, string formatFileName, int firstRow = 2)
        {
            try
            {
                var formatFilePath = Path.Combine(_formatPath, formatFileName);

                if (!System.IO.File.Exists(formatFilePath))
                    throw new FileNotFoundException($"Format file không tồn tại: {formatFileName}");

                await using (var truncateCmd = new SqlCommand($"TRUNCATE TABLE {tableName}", connection))
                {
                    await truncateCmd.ExecuteNonQueryAsync();
                }

                var sql = $@"
            BULK INSERT {tableName}
            FROM '{filePath}'
            WITH (
                FORMATFILE = '{formatFilePath}',
                FIRSTROW = {firstRow},
                TABLOCK,
                MAXERRORS = 0
            )";

                await using var cmd = new SqlCommand(sql, connection)
                {
                    CommandTimeout = 300
                };
                await cmd.ExecuteNonQueryAsync();

                await using var countCmd = new SqlCommand($"SELECT COUNT(*) FROM {tableName}", connection);
                return (int)(await countCmd.ExecuteScalarAsync() ?? 0);
            }
            catch (Exception ex)
            {
                LogHelper.WriteError(ex, $"BulkInsert-{tableName}");  // <-- Thêm dòng này
                throw;  // Re-throw để UploadAllAndGenerate xử lý tiếp
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateVendorConfirm(IFormFile vendorConfirmFile, string dataType = "sap")
        {
            string? tempFilePath = null;

            try
            {
                // Chỉ áp dụng cho SAP
                if (dataType == "tcode")
                {
                    return Json(new { success = false, message = "Chức năng này chỉ áp dụng cho dữ liệu SAP." });
                }

                if (vendorConfirmFile == null || vendorConfirmFile.Length == 0)
                {
                    return Json(new { success = false, message = "Vui lòng chọn file ZMV132 để upload." });
                }

                // Kiểm tra định dạng file
                var extension = Path.GetExtension(vendorConfirmFile.FileName).ToLower();
                if (extension != ".csv")
                {
                    return Json(new { success = false, message = "Vui lòng chọn file định dạng .csv" });
                }

                // Lưu file tạm
                var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(vendorConfirmFile.FileName)}";
                tempFilePath = Path.Combine(_uploadPath, fileName);

                await using (var stream = new FileStream(tempFilePath, FileMode.Create))
                {
                    await vendorConfirmFile.CopyToAsync(stream);
                }

                await using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync();

                using var transaction = connection.BeginTransaction();
                try
                {
                    // Truncate table trước khi import
                    await using (var truncateCmd = new SqlCommand("TRUNCATE TABLE ZMV132_STG", connection, transaction))
                    {
                        await truncateCmd.ExecuteNonQueryAsync();
                    }

                    // BULK INSERT file ZMV132
                    var fmtPath = Path.Combine(_formatPath, "zmv132.fmt");
                    var bulkSql = $@"
                        BULK INSERT ZMV132_STG
                        FROM '{tempFilePath}'
                        WITH (
                            FORMATFILE = '{fmtPath}',
                            FIRSTROW = 3,
                            CODEPAGE = '65001'
                        )";

                    await using (var bulkCmd = new SqlCommand(bulkSql, connection, transaction))
                    {
                        bulkCmd.CommandTimeout = 300;
                        await bulkCmd.ExecuteNonQueryAsync();
                    }

                    // Đếm số dòng đã import
                    int rowCount = 0;
                    await using (var countCmd = new SqlCommand("SELECT COUNT(*) FROM ZMV132_STG", connection, transaction))
                    {
                        rowCount = (int)(await countCmd.ExecuteScalarAsync() ?? 0);
                    }

                    // Execute stored procedure để recalculate
                    await using (var spCmd = new SqlCommand("sp_RecalculateAfterZMV132Upload", connection, transaction))
                    {
                        spCmd.CommandType = CommandType.StoredProcedure;
                        spCmd.CommandTimeout = 600;
                        await spCmd.ExecuteNonQueryAsync();
                    }

                    // Log action
                    _context.ActionHistories.Add(new ActionHistory
                    {
                        Username = User.Identity?.Name ?? "Anonymous",
                        ActionName = "UpdateVendorConfirm",
                        FileName = vendorConfirmFile?.FileName
                    });
                    await _context.SaveChangesAsync();

                    await transaction.CommitAsync();

                    return Json(new
                    {
                        success = true,
                        message = $"Upload thành công {rowCount:N0} dòng từ ZMV132 và đã cập nhật dữ liệu SAP."
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Có lỗi xảy ra: {ex.Message}" });
            }
            finally
            {
                // Xóa file tạm
                if (!string.IsNullOrEmpty(tempFilePath) && System.IO.File.Exists(tempFilePath))
                {
                    try { System.IO.File.Delete(tempFilePath); } catch { }
                }
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateInbound(IFormFile inboundFile, IFormFile vendorConfirmFile)
        {
            string? tempFilePath = null;

            try
            {
                // ========== VALIDATE ==========
                if (inboundFile == null || inboundFile.Length == 0)
                    return Json(new { success = false, message = "Vui lòng chọn file ZMV029." });

                if (vendorConfirmFile == null || vendorConfirmFile.Length == 0)
                    return Json(new { success = false, message = "Vui lòng chọn file ZMV132." });

                var extension = Path.GetExtension(vendorConfirmFile.FileName).ToLower();
                if (extension != ".csv")
                    return Json(new { success = false, message = "File ZMV132 phải là định dạng .csv" });

                // ========== XỬ LÝ ZMV029 (Excel) ==========
                using var stream = new MemoryStream();
                await inboundFile.CopyToAsync(stream);
                using var workbook = new XLWorkbook(stream);
                var ws = workbook.Worksheet(1);
                var rows = ws.RangeUsed().RowsUsed().Skip(1);

                var data = new List<(string Plant, string Vendor, string DelivDate, string Material, string InboundQty)>();
                foreach (var row in rows)
                {
                    var plant = row.Cell(1).GetString().Trim();
                    var vendor = row.Cell(2).GetString().Trim();
                    var delivDate = row.Cell(6).GetString().Trim();
                    var material = row.Cell(8).GetString().Trim();
                    var inboundQty = row.Cell(9).GetString().Trim();

                    if (string.IsNullOrEmpty(plant) || string.IsNullOrEmpty(material))
                        continue;

                    data.Add((plant, vendor, delivDate, material, inboundQty));
                }

                if (!data.Any())
                    return Json(new { success = false, message = "Không có dữ liệu hợp lệ trong file ZMV029." });

                // ========== XỬ LÝ ZMV132 (CSV - BULK INSERT) ==========
                var fileName = $"{Guid.NewGuid()}_{Path.GetFileName(vendorConfirmFile.FileName)}";
                tempFilePath = Path.Combine(_uploadPath, fileName);

                await using (var fileStream = new FileStream(tempFilePath, FileMode.Create))
                {
                    await vendorConfirmFile.CopyToAsync(fileStream);
                }

                // ========== EXECUTE ==========
                await using var connection = new SqlConnection(_connectionString);
                await connection.OpenAsync();
                using var transaction = connection.BeginTransaction();

                try
                {
                    // Xóa ZMV029_STG và insert mới
                    await using (var cmd = new SqlCommand("DELETE FROM ZMV029_STG", connection, transaction))
                        await cmd.ExecuteNonQueryAsync();

                    var insertSql = new StringBuilder();
                    insertSql.AppendLine("INSERT INTO ZMV029_STG (Plant, DelivDate, Material, InboundQty, Vendor) VALUES");
                    var values = data.Select(d =>
                        $"(N'{d.Plant}', " +
                        $"{(string.IsNullOrEmpty(d.DelivDate) ? "NULL" : $"'{d.DelivDate}'")}, " +
                        $"N'{d.Material}', " +
                        $"{(string.IsNullOrEmpty(d.InboundQty) ? "NULL" : d.InboundQty.Replace(",", ""))}" +
                        $"N'{d.Vendor})"
                    );
                    insertSql.AppendLine(string.Join(",\n", values));

                    await using (var cmd = new SqlCommand(insertSql.ToString(), connection, transaction))
                        await cmd.ExecuteNonQueryAsync();

                    // Truncate ZMV132_STG và BULK INSERT
                    await using (var cmd = new SqlCommand("TRUNCATE TABLE ZMV132_STG", connection, transaction))
                        await cmd.ExecuteNonQueryAsync();

                    var fmtPath = Path.Combine(_formatPath, "zmv132.fmt");
                    var bulkSql = $@"
                BULK INSERT ZMV132_STG
                FROM '{tempFilePath}'
                WITH (
                    FORMATFILE = '{fmtPath}',
                    FIRSTROW = 3,
                    CODEPAGE = '65001'
                )";

                    await using (var cmd = new SqlCommand(bulkSql, connection, transaction))
                    {
                        cmd.CommandTimeout = 300;
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Đếm số dòng ZMV132
                    int zmv132Count = 0;
                    await using (var cmd = new SqlCommand("SELECT COUNT(*) FROM ZMV132_STG", connection, transaction))
                        zmv132Count = (int)(await cmd.ExecuteScalarAsync() ?? 0);

                    // Recalculate
                    await using (var cmd = new SqlCommand("sp_RecalculateAfterZMV029_ZMV132Upload", connection, transaction))
                    {
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.CommandTimeout = 600;
                        await cmd.ExecuteNonQueryAsync();
                    }

                    // Log action
                    _context.ActionHistories.Add(new ActionHistory
                    {
                        Username = User.Identity?.Name ?? "Anonymous",
                        ActionName = "UpdateInbound",
                        FileName = $"{inboundFile.FileName} | {vendorConfirmFile.FileName}"
                    });
                    await _context.SaveChangesAsync();

                    await transaction.CommitAsync();

                    return Json(new
                    {
                        success = true,
                        message = $"Upload thành công: ZMV029 ({data.Count} dòng), ZMV132 ({zmv132Count:N0} dòng)."
                    });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Có lỗi xảy ra: {ex.Message}" });
            }
            finally
            {
                if (!string.IsNullOrEmpty(tempFilePath) && System.IO.File.Exists(tempFilePath))
                {
                    try { System.IO.File.Delete(tempFilePath); } catch { }
                }
            }
        }
    }
}
