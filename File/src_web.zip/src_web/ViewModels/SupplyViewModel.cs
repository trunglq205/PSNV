﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class SupplyViewModel : TableViewModel<KittingList, SupplyFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, SupplyFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                Tab = filter?.Tab ?? Filter.Tab,
                CurrentTime = filter?.CurrentTime ?? Filter.CurrentTime,
                DeliveryDate = filter?.DeliveryDate ?? Filter.DeliveryDate,
                Category = filter?.Category ?? Filter.Category,
                Line = filter?.Line ?? Filter.Line,
                Modal = filter?.Modal ?? Filter.Modal,
                Status = filter?.Status ?? Filter.Status,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
