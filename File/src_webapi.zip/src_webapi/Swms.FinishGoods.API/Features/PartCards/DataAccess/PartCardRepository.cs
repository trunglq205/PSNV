using Dapper;
using Swms.FinishGoods.API.Features.PartCards.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using Swms.FinishGoods.API.Shared.Models;
using System.Data;

namespace Swms.FinishGoods.API.Features.PartCards.DataAccess;

public class PartCardRepository : IPartCardRepository
{
    private readonly IDbConnectionFactory _factory;

    public PartCardRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    // Cột header dùng chung — tránh lệch giữa các câu SELECT.
    // Bọc [] vì length/width/height/weight là từ khoá/hàm dựng sẵn của SQL Server.
    private const string CardColumns = """
        id, po_no AS PoNo, customer_po_no AS CustomerPoNo,
        production_date AS ProductionDate, packer, checker,
        category, model, qty, origin, payload AS Payload,
        [length], [width], [height], [weight],
        is_oversea_service AS IsOverseaService,
        printed_at AS PrintedAt, printed_by AS PrintedBy,
        created_at AS CreatedAt, created_by AS CreatedBy,
        is_locked AS IsLocked, locked_at AS LockedAt, locked_by AS LockedBy
        """;

    // Lọc theo danh sách id dạng CSV.
    // STRING_SPLIT thay cho "IN @Ids": không đụng giới hạn 2100 tham số khi thao tác nhiều phiếu.
    private const string IdInCsv =
        "id IN (SELECT CAST(value AS bigint) FROM STRING_SPLIT(@ids, ','))";

    private const string RowColumns = """
        id, part_card_id AS PartCardId, line_no AS 'LineNo',
        g21_part AS G21Part, model, inner_box AS InnerBox,
        qty, origin, oqc_checked AS OqcChecked,
        inner_length AS InnerLength, inner_width AS InnerWidth,
        inner_height AS InnerHeight, inner_weight AS InnerWeight
        """;

    private const string InsertCardSql = """
    INSERT INTO wms.part_cards
        (po_no, customer_po_no, production_date, packer, checker,
         category, model, qty, origin,
         [length], [width], [height], [weight], payload, is_oversea_service,
         printed_at, printed_by, created_at, created_by, is_deleted)
    VALUES
        (@PoNo, @CustomerPoNo, @ProductionDate, @Packer, @Checker,
         @Category, @Model, @Qty, @Origin,
         @Length, @Width, @Height, @Weight, @Payload, @IsOverseaService,
         @PrintedAt, @PrintedBy, @CreatedAt, @CreatedBy, 0);
    SELECT CAST(SCOPE_IDENTITY() AS bigint);
    """;

    // Chỉ sửa được phiếu chưa xoá và chưa vào quy trình OQC (Status_OQC = 0 / NULL).
    // Không đụng printed_at/by, created_at/by, Status_OQC, LotName, Flag_print.
    private const string UpdateCardSql = """
    UPDATE wms.part_cards
    SET po_no = @PoNo, customer_po_no = @CustomerPoNo, production_date = @ProductionDate,
        packer = @Packer, checker = @Checker,
        category = @Category, model = @Model, qty = @Qty, origin = @Origin,
        [length] = @Length, [width] = @Width, [height] = @Height, [weight] = @Weight,
        payload = @Payload, is_oversea_service = @IsOverseaService,
        updated_at = SYSDATETIME(), updated_by = @UserId
    WHERE id = @Id AND is_deleted = 0 AND ISNULL(Status_OQC, 0) = 0;
    """;

    // 1 dòng nguồn gốc: phiếu @PartCardId sinh ra / sửa từ phiếu @SourceId (payload cũ @SourcePayload).
    private const string InsertLineageSql = """
    INSERT INTO wms.part_card_lineage
        (part_card_id, source_part_card_id, source_payload, action, created_at, created_by)
    VALUES
        (@PartCardId, @SourceId, @SourcePayload, @Action, SYSUTCDATETIME(), @UserId);
    """;

    private const string InsertRowSql = """
    INSERT INTO wms.part_card_rows
        (part_card_id, line_no, g21_part, model, inner_box,
         qty, origin, oqc_checked, inner_length, inner_width, inner_height, inner_weight)
    VALUES
        (@PartCardId, @LineNo, @G21Part, @Model, @InnerBox,
         @Qty, @Origin, @OqcChecked, @InnerLength, @InnerWidth, @InnerHeight, @InnerWeight);
    """;

    public async Task<PartCard?> GetByIdAsync(long id)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {CardColumns}
            FROM wms.part_cards
            WHERE id = @id AND is_deleted = 0;

            SELECT {RowColumns}
            FROM wms.part_card_rows
            WHERE part_card_id = @id
            ORDER BY line_no;
            """;

        using var multi = await conn.QueryMultipleAsync(sql, new { id });
        var card = await multi.ReadFirstOrDefaultAsync<PartCard>();
        if (card is null) return null;
        card.Rows = (await multi.ReadAsync<PartCardRow>()).ToList();
        await LoadChangesAsync(conn, new List<PartCard> { card });
        return card;
    }

    public async Task<(IReadOnlyList<PartCard> Items, int Total)> GetPagedAsync(PartCardQuery query)
    {
        using var conn = _factory.Create();

        // Mọi điều kiện đều optional: param NULL thì bỏ qua.
        // Nhóm 1 — field riêng, khớp tiền tố: seek được index.
        // Nhóm 2 — keyword '%kw%': chỉ lọc phần dư sau khi nhóm 1 + ngày đã thu hẹp.
        const string filter = """
        c.is_deleted = 0
        AND (@Payload          IS NULL OR c.payload = @Payload)
        AND (@PoNo             IS NULL OR c.po_no          LIKE @PoNo         ESCAPE '\')
        AND (@CustomerPoNo     IS NULL OR c.customer_po_no LIKE @CustomerPoNo ESCAPE '\')
        AND (@Packer           IS NULL OR c.packer         LIKE @Packer       ESCAPE '\')
        AND (@Checker          IS NULL OR c.checker        LIKE @Checker      ESCAPE '\')
        AND (@Category         IS NULL OR c.category = @Category)
        AND (@Product IS NULL OR c.category IN (
        SELECT cat.code FROM master.categories cat
        WHERE cat.product = @Product))
        AND (@IsOverseaService IS NULL OR c.is_oversea_service = @IsOverseaService)
        AND (@IsLocked         IS NULL OR c.is_locked = @IsLocked)
        AND (@PrintedFrom      IS NULL OR c.printed_at >= @PrintedFrom)
        AND (@PrintedToExcl    IS NULL OR c.printed_at <  @PrintedToExcl)
        AND (@ProductionFrom   IS NULL OR c.production_date >= @ProductionFrom)
        AND (@ProductionTo     IS NULL OR c.production_date <= @ProductionTo)
        -- Model: header (phiếu thường) UNION dòng hàng (oversea) — mỗi nhánh seek index riêng.
        AND (@Model IS NULL
            OR c.model LIKE @Model ESCAPE '\'
            OR EXISTS (SELECT 1 FROM wms.part_card_rows r
                   WHERE r.part_card_id = c.id
                     AND r.model LIKE @Model ESCAPE '\'))
        AND (@G21Part IS NULL OR EXISTS (
                SELECT 1 FROM wms.part_card_rows r
                WHERE r.part_card_id = c.id
                  AND r.g21_part LIKE @G21Part ESCAPE '\'))
        AND (@Kw IS NULL
             OR c.po_no          LIKE @Kw ESCAPE '\'
             OR c.customer_po_no LIKE @Kw ESCAPE '\'
             OR c.model          LIKE @Kw ESCAPE '\'
             OR c.packer         LIKE @Kw ESCAPE '\'
             OR c.checker        LIKE @Kw ESCAPE '\'
             OR EXISTS (
                 SELECT 1 FROM wms.part_card_rows r
                 WHERE r.part_card_id = c.id
                   AND (r.model     LIKE @Kw ESCAPE '\'
                     OR r.g21_part  LIKE @Kw ESCAPE '\'
                     OR r.inner_box LIKE @Kw ESCAPE '\')))
        """;

        // OPTION (RECOMPILE) là BẮT BUỘC ở đây, không phải tuỳ chọn:
        // với pattern "(@x IS NULL OR col LIKE @x)", chỉ khi recompile SQL Server mới
        // nhúng giá trị param, loại bỏ các nhánh NULL và chọn được index seek.
        var sql = $"""
        SELECT {CardColumns}
        FROM wms.part_cards c
        WHERE {filter}
        ORDER BY c.printed_at DESC, c.id DESC
        OFFSET (@Page - 1) * @Size ROWS FETCH NEXT @Size ROWS ONLY
        OPTION (RECOMPILE);

        SELECT COUNT(*) FROM wms.part_cards c WHERE {filter}
        OPTION (RECOMPILE);
        """;

        var param = new
        {
            query.Page,
            query.Size,
            query.Payload,
            PoNo = ToPrefixPattern(query.PoNo),
            CustomerPoNo = ToPrefixPattern(query.CustomerPoNo),
            Model = ToPrefixPattern(query.Model),
            G21Part = ToPrefixPattern(query.G21Part),
            Packer = ToPrefixPattern(query.Packer),
            Checker = ToPrefixPattern(query.Checker),
            query.Category,
            query.Product,
            query.IsOverseaService,
            query.IsLocked,
            PrintedFrom = query.PrintedFrom?.Date,
            PrintedToExcl = query.PrintedTo?.Date.AddDays(1),   // inclusive cả ngày cuối
            ProductionFrom = query.ProductionFrom?.Date,
            ProductionTo = query.ProductionTo?.Date,
            Kw = ToContainsPattern(query.Keyword),
        };

        using var multi = await conn.QueryMultipleAsync(sql, param);
        var items = (await multi.ReadAsync<PartCard>()).ToList();
        var total = await multi.ReadFirstAsync<int>();

        await LoadRowsAsync(conn, items);
        await LoadChangesAsync(conn, items);
        return (items, total);
    }

    // Tóm tắt sửa / tách / gộp cho cả danh sách trong 1 query — tránh N+1.
    // Chỉ xét dòng part_card_id = phiếu (phiếu này sinh ra / được sửa từ đâu).
    private static async Task LoadChangesAsync(IDbConnection conn, List<PartCard> cards)
    {
        if (cards.Count == 0) return;

        const string sql = """
            SELECT part_card_id AS PartCardId, action AS Action,
                   COUNT(*) AS Cnt, MAX(created_at) AS LastAt
            FROM wms.part_card_lineage
            WHERE part_card_id IN @Ids
            GROUP BY part_card_id, action;
            """;
        var rows = await conn.QueryAsync<(long PartCardId, string Action, int Cnt, DateTime LastAt)>(
            sql, new { Ids = cards.Select(c => c.Id).ToArray() });

        foreach (var g in rows.GroupBy(r => r.PartCardId))
        {
            var card = cards.FirstOrDefault(c => c.Id == g.Key);
            if (card is null) continue;

            // Phiếu sinh ra từ tách / gộp: có dòng split | merge trỏ VỀ nó (mới nhất thắng).
            var createdFrom = g
                .Where(r => r.Action is PartCardLineageAction.Split or PartCardLineageAction.Merge)
                .OrderByDescending(r => r.LastAt)
                .Select(r => r.Action)
                .FirstOrDefault();
            var edits = g.Where(r => r.Action == PartCardLineageAction.Edit).Sum(r => r.Cnt);

            card.Changes = new PartCardChangeSummary(createdFrom, edits, g.Max(r => r.LastAt));
        }
    }

    // Nạp rows cho cả danh sách trong 1 query — tránh N+1.
    private static async Task LoadRowsAsync(IDbConnection conn, List<PartCard> cards)
    {
        if (cards.Count == 0) return;

        var rowsSql = $"""
            SELECT {RowColumns}
            FROM wms.part_card_rows
            WHERE part_card_id IN @Ids
            ORDER BY part_card_id, line_no;
            """;
        var rows = await conn.QueryAsync<PartCardRow>(
            rowsSql, new { Ids = cards.Select(i => i.Id).ToArray() });

        var map = rows.GroupBy(r => r.PartCardId)
                      .ToDictionary(g => g.Key, g => g.ToList());
        foreach (var c in cards)
            c.Rows = map.TryGetValue(c.Id, out var rs) ? rs : new();
    }

    public async Task<IReadOnlyList<PartCard>> GetByPayloadsAsync(IReadOnlyCollection<string> payloads)
    {
        if (payloads.Count == 0) return Array.Empty<PartCard>();

        using var conn = _factory.Create();
        var sql = $"""
            SELECT {CardColumns}
            FROM wms.part_cards
            WHERE is_deleted = 0 AND payload IN @payloads
            ORDER BY id DESC;
            """;
        var cards = (await conn.QueryAsync<PartCard>(sql, new { payloads })).ToList();
        await LoadRowsAsync(conn, cards);
        return cards;
    }

    public async Task<PartCardLineage> GetLineageAsync(long id)
    {
        using var conn = _factory.Create();

        // Không lọc is_deleted: phiếu nguồn sau tách / gộp đã xoá mềm nhưng vẫn phải truy được.
        // Derived bỏ dòng "edit" (part_card_id = source = chính nó) — đó là lịch sử sửa,
        // đã nằm ở Sources.
        const string sql = """
            SELECT CAST(CASE WHEN EXISTS (SELECT 1 FROM wms.part_cards WHERE id = @id)
                        THEN 1 ELSE 0 END AS bit);

            SELECT l.action AS Action, l.source_part_card_id AS RelatedId,
                   l.source_payload AS Payload, s.is_deleted AS IsDeleted,
                   l.created_at AS CreatedAt, l.created_by AS CreatedBy
            FROM wms.part_card_lineage l
            JOIN wms.part_cards s ON s.id = l.source_part_card_id
            WHERE l.part_card_id = @id
            ORDER BY l.created_at, l.id;

            SELECT l.action AS Action, l.part_card_id AS RelatedId,
                   c.payload AS Payload, c.is_deleted AS IsDeleted,
                   l.created_at AS CreatedAt, l.created_by AS CreatedBy
            FROM wms.part_card_lineage l
            JOIN wms.part_cards c ON c.id = l.part_card_id
            WHERE l.source_part_card_id = @id AND l.part_card_id <> @id
            ORDER BY l.created_at, l.id;
            """;

        using var multi = await conn.QueryMultipleAsync(sql, new { id });
        var exists = await multi.ReadFirstAsync<bool>();
        var sources = (await multi.ReadAsync<PartCardLineageRow>()).ToList();
        var derived = (await multi.ReadAsync<PartCardLineageRow>()).ToList();
        return new PartCardLineage(exists, sources, derived);
    }

    public async Task<PartCardReplaceResult> ReplaceAsync(
        IReadOnlyList<PartCard> sources, IReadOnlyList<PartCard> replacements,
        string action, string? userId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var ids = string.Join(',', sources.Select(x => x.Id));

        // UPDLOCK + HOLDLOCK: giữ khoá tới lúc commit. 2 PDA cùng tách / gộp 1 phiếu thì
        // máy sau phải chờ, rồi đọc thấy phiếu đã bị xoá → Changed, không tạo trùng.
        // Service đã đọc + kiểm tra số lượng TRƯỚC transaction; ở đây kiểm tra lại payload
        // để chắc phiếu không bị sửa xen giữa (sửa phiếu luôn đổi payload).
        var current = (await conn.QueryAsync<SourceState>($"""
            SELECT id AS Id, payload AS Payload, is_locked AS IsLocked,
                   CAST(ISNULL(Status_OQC, 0) AS int) AS StatusOqc
            FROM wms.part_cards WITH (UPDLOCK, HOLDLOCK)
            WHERE is_deleted = 0 AND {IdInCsv};
            """, new { ids }, tx)).ToDictionary(r => r.Id);

        // Tách được cả phiếu đã vào OQC (tem con kế thừa trạng thái, xem dưới);
        // gộp thì không — N phiếu nguồn có thể khác trạng thái OQC.
        var isSplit = action == PartCardLineageAction.Split;

        foreach (var src in sources)
        {
            var status =
                !current.TryGetValue(src.Id, out var cur) || cur.Payload != src.Payload
                    ? PartCardReplaceStatus.Changed
                : cur.IsLocked ? PartCardReplaceStatus.Locked
                : cur.StatusOqc != 0 && !isSplit ? PartCardReplaceStatus.OqcLocked
                : PartCardReplaceStatus.Replaced;

            if (status != PartCardReplaceStatus.Replaced)
            {
                tx.Rollback();
                return new PartCardReplaceResult(status, src.Id, new());
            }
        }

        var newIds = new List<long>(replacements.Count);
        foreach (var card in replacements)
            newIds.Add(await InsertCardAsync(conn, tx, card));

        // Nguồn gốc: mọi phiếu mới × mọi phiếu nguồn (tách: N×1, gộp: 1×N).
        // Payload nguồn lấy từ dòng vừa khoá — đúng bản sắp bị xoá mềm.
        var lineage = newIds
            .SelectMany(newId => sources.Select(src => new
            {
                PartCardId = newId,
                SourceId = src.Id,
                SourcePayload = current[src.Id].Payload,
                Action = action,
                UserId = userId,
            }))
            .ToList();
        await conn.ExecuteAsync(InsertLineageSql, lineage, tx);

        // Tách: tem con kế thừa trạng thái OQC + lot của tem nguồn, nếu không phiếu đã
        // vào OQC tách ra sẽ thành phiếu "chưa OQC".
        if (isSplit)
        {
            await conn.ExecuteAsync($"""
                UPDATE c
                SET c.Status_OQC = s.Status_OQC, c.LotName = s.LotName
                FROM wms.part_cards c
                CROSS JOIN (SELECT Status_OQC, LotName FROM wms.part_cards WHERE id = @srcId) s
                WHERE c.id IN (SELECT CAST(value AS bigint) FROM STRING_SPLIT(@newIds, ','));
                """,
                new { srcId = sources[0].Id, newIds = string.Join(',', newIds) }, tx);
        }

        await conn.ExecuteAsync($"""
            UPDATE wms.part_cards
            SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @userId
            WHERE is_deleted = 0 AND {IdInCsv};
            """, new { ids, userId }, tx);

        tx.Commit();
        return new PartCardReplaceResult(PartCardReplaceStatus.Replaced, null, newIds);
    }

    // Trạng thái phiếu nguồn đọc trong transaction tách / gộp.
    private sealed class SourceState
    {
        public long Id { get; set; }
        public string? Payload { get; set; }
        public bool IsLocked { get; set; }
        public int StatusOqc { get; set; }
    }

    // Escape ký tự đặc biệt của LIKE để "%", "_", "[" được hiểu là ký tự thường.
    private static string EscapeLike(string s)
        => s.Replace(@"\", @"\\").Replace("%", @"\%").Replace("_", @"\_").Replace("[", @"\[");

    // 'abc%' — khớp tiền tố, sargable (seek được index).
    private static string? ToPrefixPattern(string? s)
        => string.IsNullOrWhiteSpace(s) ? null : EscapeLike(s.Trim()) + "%";

    // '%abc%' — khớp chứa, không seek được.
    private static string? ToContainsPattern(string? s)
        => string.IsNullOrWhiteSpace(s) ? null : "%" + EscapeLike(s.Trim()) + "%";

    // Insert 1 card + toàn bộ rows của nó trong transaction đang mở.
    private static async Task<long> InsertCardAsync(IDbConnection conn, IDbTransaction tx, PartCard card)
    {
        var id = await conn.ExecuteScalarAsync<long>(InsertCardSql, card, tx);
        await InsertRowsAsync(conn, tx, id, card.Rows);
        return id;
    }

    // Insert toàn bộ rows của 1 card (dùng chung cho tạo mới và sửa).
    private static async Task InsertRowsAsync(
        IDbConnection conn, IDbTransaction tx, long partCardId, IReadOnlyList<PartCardRow> source)
    {
        // Dapper multi-exec: 1 lời gọi cho cả list rows thay vì loop từng dòng.
        var rows = source
            .Select((r, i) => new
            {
                PartCardId = partCardId,
                LineNo = i + 1,
                r.G21Part,
                r.Model,
                r.InnerBox,
                r.Qty,
                r.Origin,
                r.OqcChecked,
                r.InnerLength,
                r.InnerWidth,
                r.InnerHeight,
                r.InnerWeight,
            })
            .ToList();

        if (rows.Count > 0)
            await conn.ExecuteAsync(InsertRowSql, rows, tx);
    }

    public async Task<long> AddAsync(PartCard entity)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var id = await InsertCardAsync(conn, tx, entity);

        tx.Commit();
        return id;
    }

    public async Task<List<long>> AddManyAsync(IReadOnlyList<PartCard> entities)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var ids = new List<long>(entities.Count);
        foreach (var card in entities)
            ids.Add(await InsertCardAsync(conn, tx, card));

        tx.Commit();
        return ids;
    }

    public async Task<PartCardUpdateResult> UpdateAsync(PartCard entity, string? userId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        // Payload TRƯỚC khi sửa — lưu làm nguồn gốc. UPDLOCK giữ dòng tới lúc commit
        // để payload đọc được đúng là payload bị ghi đè.
        var oldPayload = await conn.ExecuteScalarAsync<string?>(
            """
            SELECT payload FROM wms.part_cards WITH (UPDLOCK, HOLDLOCK)
            WHERE id = @Id AND is_deleted = 0;
            """,
            new { entity.Id }, tx);

        var affected = await conn.ExecuteAsync(UpdateCardSql, new
        {
            entity.Id,
            entity.PoNo,
            entity.CustomerPoNo,
            entity.ProductionDate,
            entity.Packer,
            entity.Checker,
            entity.Category,
            entity.Model,
            entity.Qty,
            entity.Origin,
            entity.Length,
            entity.Width,
            entity.Height,
            entity.Weight,
            entity.Payload,
            entity.IsOverseaService,
            UserId = userId,
        }, tx);

        if (affected == 0)
        {
            // Không update được: phân biệt "không tồn tại / đã xoá" với "bị OQC khoá".
            var exists = await conn.ExecuteScalarAsync<int?>(
                "SELECT 1 FROM wms.part_cards WHERE id = @Id AND is_deleted = 0;",
                new { entity.Id }, tx);
            tx.Rollback();
            return exists is null ? PartCardUpdateResult.NotFound : PartCardUpdateResult.Locked;
        }

        // Thay toàn bộ rows: xoá cũ rồi chèn lại theo thứ tự mới (line_no đánh lại từ 1).
        await conn.ExecuteAsync(
            "DELETE FROM wms.part_card_rows WHERE part_card_id = @Id;",
            new { entity.Id }, tx);
        await InsertRowsAsync(conn, tx, entity.Id, entity.Rows);

        // Sửa tại chỗ: phiếu nguồn = chính nó.
        await conn.ExecuteAsync(InsertLineageSql, new
        {
            PartCardId = entity.Id,
            SourceId = entity.Id,
            SourcePayload = oldPayload,
            Action = PartCardLineageAction.Edit,
            UserId = userId,
        }, tx);

        tx.Commit();
        return PartCardUpdateResult.Updated;
    }

    public async Task<bool> UpdateDimensionsAsync(long id, decimal? length, decimal? width,
    decimal? height, decimal? weight, string? userId)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.part_cards
            SET [length] = @length, [width] = @width, [height] = @height, [weight] = @weight,
                updated_at = SYSDATETIME(), updated_by = @userId
            WHERE id = @id AND is_deleted = 0;
            """;
        var affected = await conn.ExecuteAsync(sql,
            new { id, length, width, height, weight, userId });
        return affected > 0;
    }

    public async Task<PartCardDeleteResult> SoftDeleteAsync(IReadOnlyCollection<long> ids, string? userId)
    {
        if (ids.Count == 0) return new(new(), new());

        using var conn = _factory.Create();

        // Điều kiện "is_locked = 0" nằm NGAY TRONG câu UPDATE: 1 câu = atomic, nên dù có
        // người khoá phiếu đúng lúc đang xoá thì phiếu đã khoá cũng không thể lọt.
        // Câu SELECT thứ 2 chỉ để báo lại những phiếu bị chặn vì đang khoá.
        // part_card_rows không có is_deleted — rows ẩn theo header (mọi câu đọc đều lọc header).
        var sql = $"""
            UPDATE wms.part_cards
            SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @userId
            OUTPUT INSERTED.id
            WHERE is_deleted = 0 AND is_locked = 0
              AND {IdInCsv};

            SELECT id
            FROM wms.part_cards
            WHERE is_deleted = 0 AND is_locked = 1
              AND {IdInCsv};
            """;

        using var multi = await conn.QueryMultipleAsync(sql,
            new { ids = string.Join(',', ids), userId });
        var deleted = (await multi.ReadAsync<long>()).ToList();
        var locked = (await multi.ReadAsync<long>()).ToList();
        return new PartCardDeleteResult(deleted, locked);
    }

    public async Task<PartCardLockResult> SetLockedAsync(
        IReadOnlyCollection<long> ids, bool locked, string? userId)
    {
        if (ids.Count == 0) return new(new(), new());

        using var conn = _factory.Create();

        // Chỉ đụng phiếu đang ở trạng thái NGƯỢC lại (is_locked <> @locked): khoá lại phiếu
        // đã khoá sẽ không ghi đè locked_at / locked_by của người khoá ban đầu.
        // locked_at dùng UTC cho khớp printed_at / created_at (cùng trả ra FE).
        // Mở khoá thì xoá locked_at / locked_by; ai mở vẫn truy được qua updated_at / updated_by.
        var sql = $"""
            UPDATE wms.part_cards
            SET is_locked = @locked,
                locked_at = CASE WHEN @locked = 1 THEN SYSUTCDATETIME() END,
                locked_by = CASE WHEN @locked = 1 THEN @userId END,
                updated_at = SYSDATETIME(), updated_by = @userId
            OUTPUT INSERTED.id
            WHERE is_deleted = 0 AND is_locked <> @locked
              AND {IdInCsv};

            SELECT id
            FROM wms.part_cards
            WHERE is_deleted = 0 AND is_locked = @locked
              AND {IdInCsv};
            """;

        using var multi = await conn.QueryMultipleAsync(sql,
            new { ids = string.Join(',', ids), locked, userId });
        var changed = (await multi.ReadAsync<long>()).ToList();
        // Mọi phiếu hiện đang ở trạng thái đích = vừa đổi + đã ở sẵn từ trước.
        var inTargetState = (await multi.ReadAsync<long>()).ToList();
        return new PartCardLockResult(changed, inTargetState.Except(changed).ToList());
    }
}