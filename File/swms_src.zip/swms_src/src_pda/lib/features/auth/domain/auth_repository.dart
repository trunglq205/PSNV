import 'package:swms_finish_goods/features/auth/domain/auth_entity.dart';
import 'package:swms_finish_goods/features/auth/domain/user_info.dart';

abstract class AuthRepository {
  Future<AuthEntity> login(String username, String password);
  Future<UserInfo> getUserInfo();
}
