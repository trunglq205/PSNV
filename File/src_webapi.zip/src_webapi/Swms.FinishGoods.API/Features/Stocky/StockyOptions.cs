namespace Swms.FinishGoods.API.Features.Stocky;

/// <summary>
/// Mã hai ô đặc biệt của xe Stocky. Khai trong <c>appsettings.json</c>, cùng
/// khuôn với <c>MailOptions</c>:
///
/// <code>
/// "Stocky": {
///   "ParkLocatorCode": "STOCKY_SCS",
///   "FaLocatorCode":   "STOCKY_FA"
/// }
/// </code>
///
/// KHÔNG có giá trị mặc định trong source. Trước đây hai mã này là hằng
/// <c>const</c> trong <c>StockyService</c>, nên đổi tên ô là phải sửa code rồi
/// build lại. Giờ đổi tên ô chỉ cần sửa file <c>appsettings.json</c> cạnh bản
/// publish — xem <see cref="Validated"/>.
///
/// Giá trị phải khớp <c>master.locators.locator_code</c>. Đổi tên ô trong DB mà
/// quên sửa ở đây (hoặc ngược lại) thì:
///   • ô đậu xe lệch → xe nhận về thành "chưa gán ô", nhìn ra ngay;
///   • ô FA lệch     → xe đang ở FA bị coi là xe trong kho và TRẢ VENDOR LỌT.
/// Nên đổi tên ô FA là phải sửa hai nơi trong cùng một lần.
/// </summary>
public class StockyOptions
{
    public const string Section = "Stocky";

    /// <summary>
    /// Ô đậu xe Stocky trong kho. Xe rỗng nhận vào kho, và xe nhận về từ FA,
    /// được kéo về ô này.
    /// </summary>
    /// Khai non-nullable (khác <c>MailOptions</c> để <c>string?</c>): hai mã
    /// này BẮT BUỘC, và <see cref="Validated"/> đã đảm bảo khác rỗng, nên để
    /// nullable chỉ tổ sinh cảnh báo CS8604 ở mọi chỗ dùng.
    public string ParkLocatorCode { get; set; } = string.Empty;

    /// <summary>
    /// Ô đại diện cho FA. Xe đẩy sang FA được gán vào ô này và GIỮ NGUYÊN
    /// trạng thái <c>in_warehouse</c> — vẫn là xe đang được quản lý, chỉ đứng
    /// ở chỗ khác.
    /// </summary>
    public string FaLocatorCode { get; set; } = string.Empty;

    /// <summary>
    /// Đọc từ cấu hình và kiểm bắt buộc. Khác <c>MailOptions</c> ở chỗ Mail
    /// thiếu cấu hình thì chỉ ghi log, còn ở đây thiếu là KHÔNG CHẠY ĐƯỢC:
    /// không biết mã ô thì không nhận xe, không xuất FA, cũng không nói được
    /// xe đang ở đâu. Thà ném sớm còn hơn chạy sai âm thầm.
    ///
    /// Gọi ở HAI chỗ, có chủ ý:
    ///   1. <c>StockyModule.AddStockyFeature</c> lúc khởi động — thiếu cấu
    ///      hình thì API không lên, thay vì lên rồi đổ 500 vào mặt người đầu
    ///      tiên bấm nút Stocky giữa ca.
    ///   2. Constructor của <c>StockyService</c> (Scoped) mỗi request — nhờ
    ///      <c>reloadOnChange</c> mặc định của host, sửa appsettings trên
    ///      server có hiệu lực ngay ở request kế tiếp, KHÔNG phải restart.
    ///      Đây là lý do không giữ kết quả lại thành singleton.
    /// </summary>
    public static StockyOptions Validated(IConfiguration config)
    {
        var opt = config.GetSection(Section).Get<StockyOptions>() ?? new StockyOptions();
        opt.ParkLocatorCode = Require(opt.ParkLocatorCode, $"{Section}:ParkLocatorCode");
        opt.FaLocatorCode = Require(opt.FaLocatorCode, $"{Section}:FaLocatorCode");
        return opt;
    }

    private static string Require(string value, string key) =>
        value?.Trim() is { Length: > 0 } v
            ? v
            : throw new InvalidOperationException(
                $"Thiếu cấu hình bắt buộc \"{key}\" trong appsettings.json. Khai: " +
                $"\"{Section}\": {{ \"ParkLocatorCode\": \"...\", \"FaLocatorCode\": \"...\" }}. " +
                "Hai giá trị phải khớp master.locators.locator_code của ô đậu xe Stocky và ô FA.");
}
