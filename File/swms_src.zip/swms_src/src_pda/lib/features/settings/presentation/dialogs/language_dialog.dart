import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/features/settings/domain/app_language.dart';
import 'package:swms_finish_goods/features/settings/presentation/widgets/flag_icon.dart';

/// Mở menu chọn ngôn ngữ. Chọn là áp dụng ngay — trả về [AppLanguage]
/// đã chọn, hoặc null nếu đóng mà không đổi.
Future<AppLanguage?> showLanguageMenu(
    BuildContext context, {
      required AppLanguage current,
    }) {
  return showDialog<AppLanguage>(
    context: context,
    builder: (_) => LanguageMenu(current: current),
  );
}

/// Menu chọn ngôn ngữ — mỗi mục có cờ, tên, mã 2 chữ; mục đang chọn
/// hiện dấu tick. Bấm là đóng và trả kết quả ngay.
class LanguageMenu extends StatelessWidget {
  final AppLanguage current;

  const LanguageMenu({super.key, required this.current});

  @override
  Widget build(BuildContext context) {
    return AppDialog(
      title: LocaleKeys.settings_language.tr(),
      align: AppDialogAlign.start,
      titleStyle: AppTextStyles.h2,
      // Header kẻ ngăn, các mục tràn hết bề ngang (mỗi mục tự có viền dưới).
      dividers: true,
      bodyPadding: EdgeInsets.zero,
      insetPadding: const EdgeInsets.symmetric(
        horizontal: AppDimens.lg,
        vertical: AppDimens.lg,
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          for (final lang in AppLanguage.values)
            _LangOption(
              language: lang,
              selected: lang == current,
              showDivider: lang != AppLanguage.values.last,
              onTap: () => Navigator.pop(context, lang),
            ),
        ],
      ),
    );
  }
}

class _LangOption extends StatelessWidget {
  final AppLanguage language;
  final bool selected;
  final bool showDivider;
  final VoidCallback onTap;

  const _LangOption({
    required this.language,
    required this.selected,
    required this.showDivider,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return InkWell(
      onTap: onTap,
      child: Container(
        constraints: const BoxConstraints(minHeight: AppDimens.hitMd),
        padding: const EdgeInsets.symmetric(horizontal: AppDimens.md),
        decoration: BoxDecoration(
          color: selected ? swms.primaryTint : null,
          border: showDivider
              ? Border(bottom: BorderSide(color: swms.border))
              : null,
        ),
        child: Row(
          children: [
            FlagIcon(language.code, width: 20),
            const SizedBox(width: AppDimens.sm + 2),
            Expanded(
              child: Text(
                language.name,
                style: AppTextStyles.bodyStrong.copyWith(
                  color: selected ? AppColors.primary : swms.text2,
                ),
              ),
            ),
            // Mã 2 chữ (mono) — như data-code trong mẫu
            Text(
              language.label,
              style: AppTextStyles.code.copyWith(
                fontSize: 11,
                letterSpacing: 1,
                color: selected ? AppColors.primary : swms.text4,
              ),
            ),
            const SizedBox(width: AppDimens.sm),
            // Dấu tick chỉ hiện ở mục đang chọn
            SizedBox(
              width: 16,
              child: selected
                  ? const Icon(Icons.check, size: 16, color: AppColors.primary)
                  : null,
            ),
          ],
        ),
      ),
    );
  }
}