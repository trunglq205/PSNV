using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.ReturnInstructions.Business;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// Luồng nhận lại hàng về FA (mục 2c) — treo trên chính phiếu chỉ thị.
///
/// CÙNG tiền tố route với <see cref="ReturnInstructionsController"/> nhưng là
/// controller RIÊNG: ba bước này có bộ quyền riêng, bộ mail riêng và vòng đời
/// riêng với việc nhận hàng. Nhồi vào controller kia là làm file đó dài gấp đôi
/// và trộn hai nghiệp vụ không liên quan. Route cuối không trùng nhau nên
/// ASP.NET định tuyến bình thường.
///
/// BA bước, mỗi bước MỘT QUYỀN, để một người không gánh được hai bước liền
/// nhau (cùng khuôn màn Hàng bất thường):
///   B1 FA đề nghị nhận lại hàng        → <c>RequestBack</c>  (không mail)
///   B2 quản lý FA xác nhận             → <c>ApproveFa</c>     (mail SCS Office, CC FA)
///   B3 SCS WH quét Pallet ID giao hàng → <c>Process</c>       (mail FA, CC SCS)
///
/// KHÔNG có bước duyệt của quản lý SCS: SCS WH chỉ chuyển hàng sau khi đã có
/// thông báo của SCS Office, và lúc chuyển cũng bắn mail — thêm một lớp duyệt
/// nữa chỉ làm chậm mà không ai đọc thêm được gì.
///
/// Serial chỉ chuyển <c>at_fa</c> ở B3, THEO PALLET SCS WH quét. Trước đó phiếu
/// chỉ mang trạng thái đề nghị — gắp sớm là giữ hàng trong khi đề nghị còn có
/// thể bị huỷ.
/// </summary>
[ApiController]
[Route("api/return-instructions")]
public class ReturnBackFlowController : ControllerBase
{
    private readonly IReturnBackFlowService _service;
    public ReturnBackFlowController(IReturnBackFlowService service) => _service = service;

    /// <summary>
    /// SL còn ở kho theo model — màn đề nghị gọi để CHO XEM phần sẽ lấy về.
    /// Chỉ cần quyền xem.
    /// </summary>
    [HttpGet("{id:long}/back-remain")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<BackRemainModelResponse>>> GetRemain(long id)
        => Ok(await _service.GetRemainAsync(id));

    /// <summary>
    /// Nhật ký pallet đã giao, mới nhất trước. Giao dần nhiều lượt thì WH phải
    /// tra được đã quét những pallet nào, không thể nhớ bằng đầu.
    /// </summary>
    [HttpGet("{id:long}/back-deliveries")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<BackDeliveryResponse>>> GetDeliveries(long id)
        => Ok(await _service.GetDeliveriesAsync(id));

    /// <summary>
    /// B1 — FA đề nghị nhận lại hàng. Body chỉ có ghi chú: đã đề nghị là lấy
    /// TOÀN BỘ phần phiếu còn ở kho.
    /// </summary>
    //  Tên RequestBack, KHÔNG phải Request: ControllerBase đã có thuộc tính
    //  Request (HttpRequest hiện tại), đặt trùng là CS0108 "hides inherited
    //  member" — và nếu thêm `new` cho hết warning thì mọi chỗ trong controller
    //  gọi Request.Headers sẽ im lặng trỏ sang action này.
    [HttpPost("{id:long}/request-back")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.RequestBack>]
    public async Task<ActionResult<BackFlowResponse>> RequestBack(
        long id, [FromBody] RequestBackRequest request)
        => Ok(await _service.RequestAsync(id, request));

    /// <summary>
    /// Sửa ghi chú của đề nghị, chỉ khi còn chờ quản lý FA.
    ///
    /// Chỉ quyền <c>RequestBack</c>: không còn model hay SL nào để chỉnh, mà mở
    /// quyền cho bên khác ở đây là mở cả ô ghi chú của FA.
    /// </summary>
    [HttpPut("{id:long}/request-back")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.RequestBack>]
    public async Task<ActionResult<BackFlowResponse>> UpdateNote(
        long id, [FromBody] RequestBackRequest request)
        => Ok(await _service.UpdateNoteAsync(id, request));

    /// <summary>B2 — quản lý FA xác nhận. Lá mail sang SCS Office đi từ đây.</summary>
    [HttpPost("{id:long}/approve-back")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ApproveFa>]
    public async Task<ActionResult<BackFlowResponse>> Approve(
        long id, [FromBody] BackDecisionRequest request)
        => Ok(await _service.ApproveAsync(id, request));

    /// <summary>
    /// B3 — quản lý SCS xác nhận (thêm 10/11). Sau bước này SCS WH mới được
    /// tách Pallet ID và quét giao.
    ///
    /// Quyền RIÊNG <c>ApproveScs</c>, không dùng chung với <c>Process</c> của
    /// SCS WH: cả ý nghĩa của bước này là có người khác duyệt trước khi hàng
    /// rời kho, mà gán chung một quyền thì chính WH tự duyệt cho mình.
    /// </summary>
    [HttpPost("{id:long}/approve-back-scs")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ApproveScs>]
    public async Task<ActionResult<BackFlowResponse>> ApproveScs(
        long id, [FromBody] BackDecisionRequest request)
        => Ok(await _service.ScsApproveAsync(id, request));

    /// <summary>
    /// B4 — SCS WH quét Pallet ID giao hàng cho FA. Gọi được NHIỀU LẦN cho một
    /// phiếu (giao dần từng xe).
    ///
    /// KHÔNG mail (bỏ 10/11) — xem ghi chú ở service.
    /// </summary>
    [HttpPost("{id:long}/deliver-back")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<BackDeliverResponse>> Deliver(
        long id, [FromBody] DeliverBackRequest request)
        => Ok(await _service.DeliverAsync(id, request));

    /// <summary>
    /// Huỷ đề nghị. Nhận cả ba quyền của ba bên: ai đang giữ bước cũng phải dừng
    /// được, chứ không phải chờ bên kia. Service chặn khi đã giao được con nào —
    /// lúc đó hàng ở FA rồi, huỷ là mất dấu lô hàng.
    /// </summary>
    [HttpPost("{id:long}/cancel-back")]
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.RequestBack,
                          Perms.Receiving.ReworkRefurbish.ApproveFa,
                          Perms.Receiving.ReworkRefurbish.ApproveScs,
                          Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<BackFlowResponse>> Cancel(
        long id, [FromBody] BackDecisionRequest request)
        => Ok(await _service.CancelAsync(id, request));
}
