import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/pallet_label.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/printer_status_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/shared/presentation/printer_picker_dialog.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

/// In [copies] tem pallet cho [lotNo] ra máy in đang chọn.
///
/// Lỗi (chưa chọn máy, mất kết nối...) do appActionProvider bắt + toast →
/// trả false. Dùng chung cho Tách pallet (in sau khi tạo lot mới) và dialog
/// in lại tem ở Pallet Detail.
Future<bool> printPalletLabel(
  WidgetRef ref,
  String lotNo, {
  int copies = 1,
}) async {
  final ok = await ref.read(appActionProvider.notifier).run(() async {
    final device = ref.read(selectedPrinterProvider);
    if (device == null) {
      throw const PrinterException(PrinterErrorType.noPrinter);
    }

    final printer = ref.read(printerProvider(device.language));
    await printer.printBytes(
      device,
      PalletLabelData(
        lotNo: lotNo,
      ).toBytes(language: device.language, copies: copies),
    );
    return true;
  });
  return ok ?? false;
}

/// Mở dialog in tem pallet. Trả `true` nếu đã in xong.
Future<bool?> showPalletLabelPrintDialog(
  BuildContext context, {
  required String lotNo,
}) {
  return showAppDialog<bool>(
    context,
    builder: (_) => PalletLabelPrintDialog(lotNo: lotNo),
  );
}

/// Dialog in tem pallet: máy in (đổi được) + số bản → In.
class PalletLabelPrintDialog extends ConsumerStatefulWidget {
  const PalletLabelPrintDialog({super.key, required this.lotNo});

  final String lotNo;

  @override
  ConsumerState<PalletLabelPrintDialog> createState() =>
      _PalletLabelPrintDialogState();
}

class _PalletLabelPrintDialogState
    extends ConsumerState<PalletLabelPrintDialog> {
  static const _maxCopies = 10;

  int _copies = 1;
  bool _printing = false;

  Future<void> _print() async {
    if (_printing) return;
    setState(() => _printing = true);

    final ok = await printPalletLabel(ref, widget.lotNo, copies: _copies);
    if (!mounted) return;

    if (!ok) {
      // Lỗi đã được toast — giữ dialog để đổi máy / in lại.
      setState(() => _printing = false);
      return;
    }

    AppToastHelper.toast(
      context,
      message: LocaleKeys.pallet_label_printed.tr(args: [widget.lotNo]),
      type: .success,
    );
    Navigator.pop(context, true);
  }

  @override
  Widget build(BuildContext context) {
    final printer = ref.watch(selectedPrinterProvider);

    // Đang in: chặn back / bấm ra ngoài, tránh đóng dialog giữa lệnh in.
    return PopScope(
      canPop: !_printing,
      child: AppDialog(
        icon: Icons.print_outlined,
        title: LocaleKeys.pallet_label_print_title.tr(),
        subtitle: widget.lotNo,
        headerTone: AppDialogHeaderTone.accent,
        actions: [
          AppDialogAction(
            label: LocaleKeys.common_cancel.tr(),
            variant: AppButtonVariant.neutral,
            onPressed: _printing ? null : () => Navigator.pop(context),
          ),
          AppDialogAction.confirm(
            label: LocaleKeys.pallet_label_print.tr(args: ['$_copies']),
            variant: AppButtonVariant.success,
            icon: Icons.print,
            isLoading: _printing,
            onPressed: printer != null && !_printing ? _print : null,
          ),
        ],
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            PrinterStatusBar(
              device: printer,
              onChange: _printing ? null : () => pickPrinter(context, ref),
            ),
            const SizedBox(height: AppDimens.sm),
            _CopiesRow(
              value: _copies,
              max: _maxCopies,
              onChanged: _printing ? null : (v) => setState(() => _copies = v),
            ),
          ],
        ),
      ),
    );
  }
}

/// Số bản in — cùng kiểu với ô số phiếu của Part Card.
class _CopiesRow extends StatelessWidget {
  const _CopiesRow({
    required this.value,
    required this.max,
    required this.onChanged,
  });

  final int value;
  final int max;

  /// Null = khoá (đang in).
  final ValueChanged<int>? onChanged;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final change = onChanged;

    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              LocaleKeys.pallet_label_copies.tr(),
              style: AppTextStyles.caption.copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: .3,
                color: swms.text3,
              ),
            ),
          ),
          _StepButton(
            icon: Icons.remove_rounded,
            onTap: change != null && value > 1 ? () => change(value - 1) : null,
          ),
          SizedBox(
            width: 44,
            child: Text(
              '$value',
              textAlign: TextAlign.center,
              style: AppTextStyles.code.copyWith(
                fontSize: 18,
                fontWeight: FontWeight.w900,
                color: swms.text1,
              ),
            ),
          ),
          _StepButton(
            icon: Icons.add_rounded,
            primary: true,
            onTap: change != null && value < max
                ? () => change(value + 1)
                : null,
          ),
        ],
      ),
    );
  }
}

class _StepButton extends StatelessWidget {
  const _StepButton({
    required this.icon,
    required this.onTap,
    this.primary = false,
  });

  final IconData icon;
  final VoidCallback? onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final enabled = onTap != null;

    return Material(
      color: primary && enabled ? swms.success : swms.card,
      borderRadius: BorderRadius.circular(AppDimens.sm),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.sm),
        child: SizedBox(
          width: AppDimens.hitSm,
          height: AppDimens.hitSm,
          child: Icon(
            icon,
            size: 18,
            color: !enabled
                ? swms.text4
                : (primary ? Colors.white : swms.text2),
          ),
        ),
      ),
    );
  }
}
