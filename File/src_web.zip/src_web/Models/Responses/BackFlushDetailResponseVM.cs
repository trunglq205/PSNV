﻿namespace SWMS_WebTool.Models.Responses
{
    public class BackFlushDetailResponseVM
    {
        public string Material { get; set; }
        public string PlanOrderNumber { get; set; }
        public string LotNo { get; set; }
        public double? TotalQuantity { get; set; }
        public double? CurrentQuantity { get; set; }
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string StoreUser { get; set; } = string.Empty;
        public DateTime? StoreDate { get; set; }
    }
}
