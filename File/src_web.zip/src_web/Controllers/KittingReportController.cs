using ClosedXML.Excel;
using DocumentFormat.OpenXml.InkML;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.DataKitting;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Models.Responses;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using System.Data;
using System.Drawing.Printing;

namespace SWMS_WebTool.Controllers
{
    public class KittingReportController : BaseController
    {
        private readonly ApiService _apiService;
        public KittingReportController(ApiService apiService)
        {
            _apiService = apiService;
        }
        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] KittingFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new KittingFilter();

                if (User.Identity.Name != null)
                {
                    if (User.Identity.Name.Contains("-PMD"))
                    {
                        _filter.Tab = KittingTab.KittingOutside;
                        filter.Cate = "PMD";
                    }
                }

                int total = 10;
                var dropdownData = await _apiService.GetCategoryPlanMaster();
                ViewBag.Plants = new SelectList(dropdownData.Select(x => x.Plant).Distinct().ToList());
                ViewBag.Categorys = new SelectList(dropdownData.Where(s => !string.IsNullOrEmpty(filter.Plant) ? s.Plant == filter.Plant : s.Plant == "").Select(x => x.Category).Distinct().ToList());
                var response = await _apiService.SearchKittingReport(_filter, pageNumber, _pageSize);
                IEnumerable<KittingReport> items = new List<KittingReport>();
                switch (filter?.Tab)
                {
                    case KittingTab.KittingFA:
                        total = response.TotalRecord;
                        items = response.Records ?? new List<KittingReport>();
                        break;
                    case KittingTab.KittingDIP:
                        var dropdownUploadno = await _apiService.GetUploadNoKittingPlan(1, _filter.ProDate);
                        ViewBag.UploadNos = new SelectList(dropdownUploadno.Distinct().ToList());
                        total = response.TotalRecord;
                        items = response.Records ?? new List<KittingReport>();
                        break;
                    case KittingTab.KittingSubcon:
                        total = response.TotalRecord;
                        items = response.Records ?? new List<KittingReport>();
                        break;
                    case KittingTab.KittingOutside:
                        total = response.TotalRecord;
                        items = response.Records ?? new List<KittingReport>();
                        break;
                }
                var model = new KittingViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/KittingReport/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewConfirmKittingSubconJPT(string prodate, string plant, string cate, string fromsloc, string partno)
        {
            var _filter = new KittingFilter()
            {
                Tab = KittingTab.KittingSubcon,
                KTFrom = KittingFrom.JPT,
                ProDate = prodate,
                Plant = plant,
                Cate = cate,
                FromSloc = fromsloc,
                PartNo = partno
            };
            var response = await _apiService.SearchKittingReport(_filter, Constants.PagingDefault, Constants.PageMaximum);
            var lstData = response.Records != null ? response.Records : new List<KittingReport>();
            var model = new KittingViewModel()
            {
                Items = lstData,
                Filter = _filter,
                PageNumber = Constants.PagingDefault,
                PageSize = Constants.PageMaximum,
                TotalPage = (int)Math.Ceiling((double)Constants.PagingDefault / Constants.PageMaximum),
                Total = 9999,
            };
            return PartialView("~/Views/KittingReport/_ViewConfirmKittingSubconJPT.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmKittingSubconJPT([FromBody] List<ConfirmKittingSubconRequest> requests)
        {
            try
            {
                await _apiService.ConfirmKittingSubconJPT(requests);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult DeleteKittingDetails(string selectedItems)
        {
            var model = new DeletePlanObject()
            {
                Id = selectedItems,
                Tab = "1",
                Action = "ConfirmDeleteKittingDetails",
                Controller = "KittingReport",
            };
            return PartialView("~/Views/KittingPlan/_DeletePlanModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteKittingDetails(string Id)
        {
            try
            {
                if (string.IsNullOrEmpty(Id))
                {
                    return BadRequest(_loc.Get("Msg_PleaseSelectAPlanToDelete"));
                }
                var lstID = Id.Split(";").Select(int.Parse).ToList();

                await _apiService.DeleteKittingListDetails(lstID);


                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ConfirmBlockSapDateView(byte tab)
        {
            try
            {
                var scheduleResponse = await _apiService.GetALlBlockSapSchedule();
                var schedule = scheduleResponse.Where(s => s.KittingType == Convert.ToByte(tab)).Select(x => new BlockSapScheduleRequest
                {
                    KittingType = Convert.ToByte(tab),
                    BlockDate = x.BlockDate,
                    BlockTime = x.BlockTime,
                    OpenDate = x.OpenDate,
                    OpenTime = x.OpenTime,
                }).FirstOrDefault();

                if (User.Identity.Name != null)
                {
                    if (User.Identity.Name.Contains("-PMD"))
                    {
                        schedule = scheduleResponse.Where(s => s.KittingType == 4).Select(x => new BlockSapScheduleRequest
                        {
                            KittingType = 4,
                            BlockDate = x.BlockDate,
                            BlockTime = x.BlockTime,
                            OpenDate = x.OpenDate,
                            OpenTime = x.OpenTime,
                        }).FirstOrDefault();

                        tab = 4;
                    }
                }

                var tuple = new Tuple<BlockSapScheduleRequest, byte>(schedule, tab);
                return PartialView("~/Views/KittingReport/_BlockSapScheduleModal.cshtml", tuple);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmBlockSapDate(BlockSapScheduleRequest request)
        {
            try
            {
                var scheduleResponse = await _apiService.GetALlBlockSapSchedule();
                var newRequest = new List<BlockSapScheduleRequest>();
                {
                };
                //var newrequest = new ReceivingSchedule
                //{
                //    BlockDate = request.BlockDate == null ? scheduleResponse.BlockDate : request.BlockDate,
                //    DatePrint = request.DatePrint == null ? scheduleResponse.DatePrint : request.DatePrint,
                //    IsBlock = request.IsBlock
                //};
                await _apiService.CreateBlockSapSchedule(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        public IActionResult ExportToExcelALL(string proDate, string plant, string cate)
        {

            DataTable dt = Db_Connect_TA.StoreFillDS("GetAllKittingReport_TA", CommandType.StoredProcedure, plant, cate, "", "", "", "", "", "", "0", proDate, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value, DBNull.Value, "", "", "", "", 1, 99999);





            if (dt.Rows.Count > 0)
            {
                foreach (DataRow item in dt.Rows)
                {

                    if ( !item["LocationName"].ToString().IsNullOrEmpty() && !item["PicUser"].ToString().IsNullOrEmpty())
                    {
                        
                        continue;
                    }



                    DataSet ds = Db_Connect_TA.StoreFillDataSet("GetLastLotByMaterialandLocationFIFOByMaterialSloc", CommandType.StoredProcedure, item["Material"].ToString(), item["Plant"].ToString(), item["Sloc"].ToString());

                    DataTable resLocationLastLot = ds.Tables[0];

                    //DataTable resLocationFiFo = Db_Connect_TA.StoreFillDS("GetLocationFIFOByMaterialSloc", CommandType.StoredProcedure, item["Material"].ToString(), item["Plant"].ToString(), item["Sloc"].ToString());

                    DataTable resLocationFiFo = ds.Tables[1];



                    var picuserupdate = resLocationFiFo.Rows.Count > 0 ? resLocationFiFo.Rows[0]["PIC"].ToString() : resLocationLastLot.Rows.Count > 0 ? resLocationLastLot.Rows[0]["PIC"].ToString() : string.Empty;
                    var locationname = resLocationFiFo.Rows.Count > 0 ? String.Join(";", resLocationFiFo.AsEnumerable().Select(s => s["PositionName"].ToString()).Distinct().ToList()) : resLocationLastLot.Rows.Count > 0 ? resLocationLastLot.Rows[0]["PositionName"].ToString() : string.Empty;

                    item["LocationName"] = locationname;
                    item["PicUser"] = picuserupdate;

                }
            }

            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add("data");
                worksheet.Cell(1, 1).InsertTable(dt);
                
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    stream.Position = 0;
                    return File(stream.ToArray(), "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", "FilteredData.xlsx");
                }
            }
        }



    }
}
