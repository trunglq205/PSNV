using Refit;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Client;

public interface IReturnInstructionApi
{
    /// <summary>
    /// Danh sách chỉ thị. Mọi tham số lọc đều cho phép null = không lọc.
    /// Tên query là camelCase: ASP.NET model binding KHÔNG phân biệt hoa
    /// thường nhưng CÓ phân biệt dấu gạch dưới, nên goods_type sẽ không khớp
    /// vào ReturnInstructionQuery.GoodsType.
    /// </summary>
    [Get("/api/return-instructions")]
    Task<List<ReturnInstructionDto>> GetListAsync(
        [Query] string? status = null,
        [AliasAs("goodsType")] string? goodsType = null,
        [Query] string? keyword = null,
        [AliasAs("fromDate")] DateTime? fromDate = null,
        [AliasAs("toDate")] DateTime? toDate = null);

    [Get("/api/return-instructions/{id}")]
    Task<ReturnInstructionDto> GetByIdAsync(long id);

    [Post("/api/return-instructions")]
    Task<ReturnInstructionDto> CreateAsync([Body] ReturnInstructionRequestDto request);

    [Put("/api/return-instructions/{id}")]
    Task<ReturnInstructionDto> UpdateAsync(long id, [Body] ReturnInstructionRequestDto request);

    [Delete("/api/return-instructions/{id}")]
    Task DeleteAsync(long id);

    /// <summary>
    /// Pallet hàng return WH đã nhận vào phiếu (mục 2a). Màn Web chỉ ĐỌC —
    /// pallet do WH tạo trên PDA khi quét thùng + serial.
    /// </summary>
    [Get("/api/return-instructions/{id}/pallets")]
    Task<List<ReturnPalletDto>> GetPalletsAsync(long id);

    /// <summary>
    /// Huỷ một lần nhận: xoá pallet và GIẢI PHÓNG serial khỏi sổ của phiếu.
    ///
    /// Cần có đường này vì serial bị giữ trên phạm vi toàn hệ thống: pallet
    /// quét sai mà không tháo được thì những con hàng đó không quét lại được
    /// vào đâu nữa.
    /// </summary>
    [Delete("/api/return-instructions/{id}/pallets/{palletId}")]
    Task<ReturnInstructionDto> ReleasePalletAsync(long id, long palletId);

    /// <summary>
    /// Chốt SL thực nhận: đóng phiếu và TỰ GỬI MAIL báo FA số thực tế kèm bảng
    /// lệch. Lệch thiếu / vượt đều không chặn.
    /// </summary>
    [Post("/api/return-instructions/{id}/close")]
    Task<ReturnInstructionDto> CloseAsync(long id);

    /// <summary>
    /// Mở lại phiếu đã chốt để WH quét tiếp. Chốt lại sẽ gửi FA mail mới.
    /// </summary>
    [Post("/api/return-instructions/{id}/reopen")]
    Task<ReturnInstructionDto> ReopenAsync(long id);

    // ───────── Mục 2c · luồng nhận lại hàng về FA ─────────
    //
    // Cùng tiền tố route với phần trên vì sau khi gộp thì đây là một mặt của
    // phiếu. Bên API là controller riêng (ReturnBackFlowController) nhưng route
    // thì liền một bộ, nên client cũng để chung một interface — tách ra là
    // người đọc phải mở hai file mới thấy hết đường gọi của một màn.

    /// <summary>
    /// SL còn ở kho theo model — màn đề nghị gọi để CHO XEM phần sẽ lấy về.
    /// </summary>
    [Get("/api/return-instructions/{id}/back-remain")]
    Task<List<BackRemainModelDto>> GetBackRemainAsync(long id);

    /// <summary>Nhật ký pallet đã giao, mới nhất trước.</summary>
    [Get("/api/return-instructions/{id}/back-deliveries")]
    Task<List<BackDeliveryDto>> GetBackDeliveriesAsync(long id);

    /// <summary>B1 — FA đề nghị nhận lại hàng. Body chỉ có ghi chú.</summary>
    [Post("/api/return-instructions/{id}/request-back")]
    Task<BackFlowDto> RequestBackAsync(long id, [Body] RequestBackRequestDto request);

    /// <summary>Sửa ghi chú, chỉ khi còn chờ quản lý FA.</summary>
    [Put("/api/return-instructions/{id}/request-back")]
    Task<BackFlowDto> UpdateBackNoteAsync(long id, [Body] RequestBackRequestDto request);

    /// <summary>B2 — quản lý FA xác nhận. Mail sang SCS Office đi từ đây.</summary>
    [Post("/api/return-instructions/{id}/approve-back")]
    Task<BackFlowDto> ApproveBackAsync(long id, [Body] BackDecisionRequestDto request);

    // DeliverBackAsync đã XOÁ (11/11) cùng endpoint deliver-back bên API.
    // Giao hàng cho FA giờ là việc SCS WH out hàng khỏi kho rồi đặt pallet vào
    // một vị trí thuộc bản đồ Nhận hàng (PDA, màn vị trí tạm) — không có nút
    // giao hàng nào trên web nữa.

    /// <summary>
    /// B3 — quản lý SCS xác nhận (thêm 10/11). Sau bước này SCS WH mới được
    /// tách Pallet ID và quét giao. Không gửi mail.
    /// </summary>
    [Post("/api/return-instructions/{id}/approve-back-scs")]
    Task<BackFlowDto> ApproveBackScsAsync(long id, [Body] BackDecisionRequestDto request);

    /// <summary>Huỷ đề nghị — chỉ khi chưa giao con nào.</summary>
    [Post("/api/return-instructions/{id}/cancel-back")]
    Task<BackFlowDto> CancelBackAsync(long id, [Body] BackDecisionRequestDto request);

    // ──────────── Mục 2d — nhật ký serial lệch ────────────
    //
    // Hai endpoint này treo trên controller RIÊNG bên API
    // (ReturnFaPalletsController, route `api/return-instructions/{docId}`) nhưng
    // với Refit thì chỉ là hai đường dẫn nữa — tiền tố trùng nhau không sao vì
    // đoạn cuối khác hẳn (`mismatches` ≠ `pallets` / `serials`).
    //
    // KHÔNG có hàm FA đóng pallet: việc đó chỉ làm trên PDA, bên Web chỉ đọc
    // nhật ký và đóng dòng đã xử lý.

    /// <summary>
    /// Nhật ký serial FA quét ra mà không khớp sổ của phiếu.
    ///
    /// Màn hình luôn xin <c>openOnly = false</c> rồi lọc ở client: con số
    /// "còn n chưa xử lý" phải còn đúng khi người dùng bật xem cả dòng đã xử lý.
    /// </summary>
    [Get("/api/return-instructions/{id}/mismatches")]
    Task<List<ReturnMismatchDto>> GetMismatchesAsync(long id, [Query] bool openOnly);

    /// <summary>
    /// Đánh dấu một dòng nhật ký đã xử lý (đã đặt riêng / đã trả về đúng phiếu).
    ///
    /// CHỈ đóng dòng nhật ký, KHÔNG đổi trạng thái serial — serial thuộc phiếu
    /// khác thì việc của nó nằm ở phiếu đó.
    /// </summary>
    [Post("/api/return-instructions/{id}/mismatches/{mismatchId}/resolve")]
    Task<ReturnMismatchDto> ResolveMismatchAsync(
        long id, long mismatchId, [Body] ResolveMismatchRequestDto request);
}
