import 'dart:typed_data';

import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/utils/printing/sato/sbpl.dart';
import 'package:swms_finish_goods/core/utils/printing/tspl/tspl.dart';

/// Một tem in được — tự sinh lệnh cho MỌI [PrinterLanguage].
///
/// Mỗi loại tem là một subclass giữ DỮ LIỆU + TEMPLATE của từng ngôn ngữ.
/// Lớp này chỉ chọn ngôn ngữ và gói setup + body thành bytes. Thêm ngôn
/// ngữ = thêm 1 case ở [toBytes]/[batchToBytes] và 2 member abstract —
/// compiler sẽ chỉ ra tem nào chưa implement.
abstract class Label {
  const Label();

  // ─── SBPL ────────────────────────────────────────────────────────────────

  /// Block cấu hình khổ tem (ESC A ... ESC Z), gửi MỘT lần đầu payload.
  String get sbplSetup;

  /// Block nhãn, đã gồm ESC Q\<copies>, ESC Z, ETX.
  String toSbpl({int copies = 1});

  // ─── TSPL ────────────────────────────────────────────────────────────────

  /// SIZE/GAP/DENSITY/SPEED..., gửi MỘT lần đầu payload.
  List<String> get tsplSetup;

  /// CLS ... PRINT 1,\<copies>.
  List<String> toTspl({int copies = 1});

  // ─── Dùng chung ──────────────────────────────────────────────────────────

  /// Bytes cho MỘT tem, gồm cả block setup.
  Uint8List toBytes({required PrinterLanguage language, int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    return switch (language) {
      PrinterLanguage.sbpl => encodeSbpl(sbplSetup + toSbpl(copies: copies)),
      PrinterLanguage.tspl => encodeTspl(
        Tspl.join([...tsplSetup, ...toTspl(copies: copies)]),
      ),
    };
  }

  /// Bytes cho NHIỀU tem khác nhau trong MỘT lần gửi.
  ///
  /// Block setup chỉ gửi một lần ở đầu — lấy từ tem đầu tiên, nên cả lô
  /// phải CÙNG loại tem (khổ khác nhau thì setup khác nhau). Vì dùng
  /// connect-per-print, gộp như thế này tiết kiệm ~1–3s mở SPP cho mỗi tem.
  static Uint8List batchToBytes({
    required PrinterLanguage language,
    required Iterable<Label> labels,
  }) {
    final list = labels.toList(growable: false);
    if (list.isEmpty) {
      throw ArgumentError.value(labels, 'labels', 'danh sách rỗng');
    }
    final first = list.first;
    if (list.any((l) => l.runtimeType != first.runtimeType)) {
      throw ArgumentError.value(labels, 'labels', 'lô phải cùng một loại tem');
    }
    return switch (language) {
      PrinterLanguage.sbpl => encodeSbpl(
        [first.sbplSetup, for (final l in list) l.toSbpl()].join(),
      ),
      PrinterLanguage.tspl => encodeTspl(
        Tspl.join([...first.tsplSetup, for (final l in list) ...l.toTspl()]),
      ),
    };
  }
}