import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/back_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_stepper_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_alert_dialog_helper.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/pallet/presentation/dialogs/pallet_label_print_dialog.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/receiving_notifier.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/receiving_state.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_bottom_hint.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_confirm_box_body.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_confirm_gtin_body.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_confirm_model_body.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_history_card.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_scan_body.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_scan_pallet_body.dart';
import 'package:swms_finish_goods/shared/presentation/printer_picker_dialog.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Receiving — Nhận hàng · Quét & đối chiếu.
//  Quy trình 3 bước: Quét → Xác nhận → Pallet ID.
//  Bước 3: quét nhãn Pallet ID có sẵn, hoặc tự in nhãn mới.
//
//  Tự in: bắt buộc chọn máy in ở B3; tạo lot xong (server cấp lotNo) in
//  ngay tem pallet. In lỗi KHÔNG huỷ lot (đã commit ở server) — hỏi in lại
//  bằng dialog in tem (đổi máy / số bản được).
//
//  Back khỏi bước 2 → hỏi lưu lịch sử; bước 1 hiển thị lịch sử để phục hồi.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class ReceivingScreen extends ConsumerStatefulWidget {
  const ReceivingScreen({super.key});

  @override
  ConsumerState<ReceivingScreen> createState() => _ReceivingScreenState();
}

class _ReceivingScreenState extends ConsumerState<ReceivingScreen> {
  StreamSubscription<String>? _sub;

  /// Chặn bấm 2 lần khi đang tạo lot / in tem
  /// (overlay do appActionProvider lo).
  bool _submitting = false;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Page đã dispose trong lúc chờ → không gán, tránh rò listener.
    // _sub != null: đã nghe rồi (gọi _listen 2 lần liên tiếp).
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      ref.read(receivingProvider.notifier).onScan(data);
    });
  }

  /// Ngưng listener của page trong lúc mở dialog tự nghe scan
  /// (chọn máy in = quét MAC) — nếu không, mã MAC rơi vào notifier như
  /// mã thùng / Pallet ID. Xong thì nghe lại.
  Future<T> _withScanPaused<T>(Future<T> Function() action) async {
    await _sub?.cancel();
    _sub = null;
    try {
      return await action();
    } finally {
      if (mounted) await _listen();
    }
  }

  Future<void> _pickPrinter() => _withScanPaused(() async {
    if (!mounted) return;
    await pickPrinter(context, ref);
  });

  Future<void> _submit() async {
    if (_submitting) return;
    final notifier = ref.read(receivingProvider.notifier);
    // Chốt trước khi submit — tạo xong sẽ reset state.
    final printNew = ref.read(receivingProvider).printsNewLabel;

    setState(() => _submitting = true);
    try {
      // Lỗi API đã được appActionProvider bắt + toast → null.
      final lotNo = await notifier.submit();
      if (!mounted || lotNo == null) return;

      // Lot đã tạo ở server — in lỗi chỉ toast, không rollback.
      final printed = printNew && await printPalletLabel(ref, lotNo);
      if (!mounted) return;

      // submit() đã xóa dưới storage; clearHistory dọn nốt trên state rồi reset.
      await notifier.clearHistory();
      notifier.reset();
      if (!mounted) return;

      if (!printNew) {
        AppToastHelper.toastSuccess(
          context,
          LocaleKeys.receiving_toast_saved.tr(),
        );
      } else if (printed) {
        AppToastHelper.toastSuccess(
          context,
          'receiving.toast_created_printed'.tr(args: [lotNo]),
        );
      } else {
        await _offerReprint(lotNo);
      }
    } finally {
      if (mounted) setState(() => _submitting = false);
    }
  }

  /// Tạo lot xong nhưng in lỗi: báo rõ pallet ĐÃ tạo, hỏi in lại.
  Future<void> _offerReprint(String lotNo) async {
    final retry = await AppDialogHelper.confirm(
      context,
      title: 'receiving.print_failed_title'.tr(),
      message: 'receiving.print_failed_message'.tr(args: [lotNo]),
      confirmText: 'receiving.print_failed_retry'.tr(),
      cancelText: 'receiving.print_failed_later'.tr(),
    );
    if (!retry || !mounted) return;

    // Dialog in có nút đổi máy (quét MAC) → ngưng listener của page.
    await _withScanPaused(() async {
      if (!mounted) return;
      await showPalletLabelPrintDialog(context, lotNo: lotNo);
    });
  }

  /// Back khỏi bước confirm: hỏi có lưu lịch sử không.
  /// Cả 2 lựa chọn đều quay về bước 1 — chỉ khác việc có ghi bản nháp hay không.
  Future<void> _backFromConfirm() async {
    final shouldSave = await AppDialogHelper.confirm(
      context,
      title: LocaleKeys.receiving_history_save_title.tr(),
      message: LocaleKeys.receiving_history_save_message.tr(),
      confirmText: LocaleKeys.receiving_history_save_confirm.tr(),
      cancelText: LocaleKeys.receiving_history_save_discard.tr(),
    );

    final notifier = ref.read(receivingProvider.notifier);
    if (shouldSave) {
      await notifier.saveDraftAndBackToScan();
    } else {
      notifier.backToScanWithoutSaving();
    }
  }

  Future<void> _deleteHistory() async {
    final confirmed = await AppDialogHelper.confirm(
      context,
      title: LocaleKeys.receiving_history_delete_title.tr(),
      message: LocaleKeys.receiving_history_delete_message.tr(),
      confirmText: LocaleKeys.receiving_history_delete.tr(),
      cancelText: LocaleKeys.common_cancel.tr(),
    );
    if (!confirmed) return;

    await ref.read(receivingProvider.notifier).clearHistory();
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(receivingProvider);
    final notifier = ref.read(receivingProvider.notifier);
    final printer = ref.watch(selectedPrinterProvider);

    return Scaffold(
      appBar: AppTopBar(
        onBack: state.step == .confirm ? () => _backFromConfirm() : null,
        title: LocaleKeys.receiving_title.tr(),
        subtitle: LocaleKeys.receiving_subtitle.tr(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppDimens.md),
        child: Column(
          children: [
            // Step bar
            AppStepperBar(
              current: state.step.number,
              steps: [
                StepItem(LocaleKeys.receiving_step_scan.tr()),
                StepItem(LocaleKeys.receiving_step_confirm.tr()),
                StepItem(LocaleKeys.receiving_step_scan_pallet.tr()),
              ],
            ),

            const SizedBox(height: AppDimens.sm),

            // Body theo bước
            Expanded(
              child: _buildStepBody(context, state, notifier, printer),
            ),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottom(context, state, printer),
    );
  }

  Widget _buildStepBody(
      BuildContext context,
      ReceivingState state,
      ReceivingNotifier notifier,
      PrinterDevice? printer,
      ) {
    switch (state.step) {
      case ReceivingStep.scan:
        final history = state.historyEntry;
        return Column(
          children: [
            if (history != null) ...[
              ReceivingHistoryCard(
                entry: history,
                onResume: notifier.restoreFromHistory,
                onDelete: _deleteHistory,
              ),
              const SizedBox(height: AppDimens.sm),
            ],
            Expanded(
              child: ReceivingScanBody(
                mode: state.mode,
                onModeChanged: notifier.setMode,
              ),
            ),
          ],
        );

      case ReceivingStep.confirm:
        return switch (state.mode) {
              .box => ReceivingConfirmBoxBody(
            partCards: state.partCards,
            onRemoveCarton: notifier.onRemoveCarton,
          ),
              .model =>
          state.modelInfo == null
              ? const SizedBox.shrink() // chưa quét model thì chưa vào được bước này
              : ReceivingConfirmModelBody(
            modelInfo: state.modelInfo!,
            serials: state.serials,
            onSerialRemove: notifier.onSerialRemoved,
          ),
              .gtin =>
          state.modelInfo == null
              ? const SizedBox.shrink()
              : ReceivingConfirmGTINBody(
            modelInfo: state.modelInfo!,
            boxCount: state.boxCount,
            stdPack: state.effectiveStdPack,
            onBoxChange: notifier.onBoxCountChanged,
            onStdPackChange: notifier.onStdPackChanged,
            onSerialRemove: notifier.onSerialRemoved,
          ),
        };
      case ReceivingStep.scanPallet:
        return ReceivingScanPalletBody(
          lotId: state.lotNo,
          isPap: state.isPap,
          source: state.palletIdSource,
          onSourceChanged: notifier.setPalletIdSource,
          printer: printer,
          onChangePrinter: _submitting ? null : _pickPrinter,
        );
    }
  }

  Widget _buildBottom(
      BuildContext context,
      ReceivingState state,
      PrinterDevice? printer,
      ) {
    switch (state.step) {
      case ReceivingStep.scan:
        return ReceivingBottomHint(text: LocaleKeys.receiving_hint_scan.tr());

      case ReceivingStep.confirm:
        return ReceivingBottomHint(
          child: Row(
            children: [
              BackIconButton(onPressed: _backFromConfirm),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: AppButton(
                  label: LocaleKeys.receiving_btn_confirm_scan_loc.tr(),
                  variant: AppButtonVariant.success,
                  isFullWidth: false,
                  onPressed: ref.read(receivingProvider.notifier).confirmPallet,
                ),
              ),
            ],
          ),
        );

      case ReceivingStep.scanPallet:
        final printNew = state.printsNewLabel;
        // Tự in bắt buộc có máy in — tạo xong in tem ngay.
        final canSubmit = state.canSubmitPallet &&
            !_submitting &&
            (!printNew || printer != null);

        return ReceivingBottomHint(
          child: Row(
            children: [
              BackIconButton(
                onPressed: _submitting
                    ? null
                    : () {
                  ref
                      .read(receivingProvider.notifier)
                      .goStep(ReceivingStep.confirm.number);
                },
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: AppButton(
                  label: printNew
                      ? 'receiving.btn_create_print_pallet'.tr()
                      : LocaleKeys.receiving_btn_create_pallet.tr(),
                  variant: AppButtonVariant.success,
                  icon: printNew ? Icons.print_rounded : Icons.check_rounded,
                  isFullWidth: false,
                  isLoading: _submitting,
                  onPressed: canSubmit ? _submit : null,
                ),
              ),
            ],
          ),
        );
    }
  }
}