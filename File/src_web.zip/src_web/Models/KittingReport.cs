﻿using SWMS_WebTool.Models;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using Newtonsoft.Json;

namespace SWMS_WebTool.Models
{
    public class KittingReport : AuditableEntity
    {
        public KittingTab Tab { get; set; }
        public KittingStatus? Status { get; set; }
        public Int64? ID { get; set; }
        public Int64? KittingCardID { get; set; }
        public string RCDetailID { get; set; }
        public string RCID { get; set; }
        public Int64? KittingListDetailId { get; set; }
        public string KittingTimeType { get; set; }
        public string Plant { get; set; }
        public string PartNo { get; set; }
        public string Model { get; set; }
        public double? Quantity { get; set; }
        public DateTime? DateTimeKitting { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Sloc { get; set; }
        public string Barcode { get; set; }
        public string PosFA { get; set; }
        public string PosMCS { get; set; }
        public string PicUser { get; set; }
        public string Material { get; set; }
        public double? QuantityKT { get; set; }
        public double? PickedQuantity { get; set; }
        public string Unit { get; set; }
        public string Descriptions { get; set; }
        public string LocationName { get; set; }

        public byte? KittingStatus { get; set; }

        public byte? SupplyStatus { get; set; }
        public string KittingTimeTypeKT { get; set; }
        public byte? KittingType { get; set; }
        public string KittingFrom { get; set; }
        public string PositionFA { get; set; }
        public double? AssemblyQuantity { get; set; }
        public string ReceiptSloc { get; set; }
        public string Urgent { get; set; }
        public string PSNVStock { get; set; }
        public string KHFAN7 { get; set; }
        public string VenderName { get; set; }
        public string Tcode { get; set; }
        public string PL { get; set; }
        public string ReservationNo { get; set; }
        public int? ModelQuantity { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Category { get; set; }
        public double? TotalModelQuantity { get; set; }
        public double? PlanQuantity { get; set; }
        public double? ActualQuantity { get; set; }
        public DateTime? ConfirmDate { get; set; }
        public string ConfirmID { get; set; }
        public string PullID { get; set; }
        public string UploadNo { get; set; }
        public string Reason { get; set; }
        public string AutoSapDate { get; set; }
        public DateTime? dCreatedDate { get; set; }
        public string dCreatedBy { get; set; }
        public DateTime? dUpdatedDate { get; set; }
        public string dUpdatedBy { get; set; }
        public double KittingProcess
        {
            get { return (Quantity == null || QuantityKT == null) ? 0 : (double)(Quantity / QuantityKT * 100); }
        }

        public double QuantityValue
        {
            get { return (Quantity == null) ? 0 : (double)(Quantity); }
        }

    }
}

public enum KittingStatus
{
    [EnumMember(Value = "0")]
    [Description("Status_KittingOk")]
    KittingOk = 0,

    [EnumMember(Value = "1")]
    [Description("Status_KittingNotEnough")]
    KittingNotEnough = 1,

    [EnumMember(Value = "2")]
    [Description("Status_KittingLack")]
    KittingLack = 2,

    [EnumMember(Value = "3")]
    [Description("Status_SupplyOk")]
    SupplyOK = 3,

    [EnumMember(Value = "4")]
    [Description("Status_NotKitting")]
    NotKitting = 4,

    [EnumMember(Value = "5")]
    [Description("Status_ABC")]
    ABC = 5

}

public enum KittingType
{
    [EnumMember(Value = "1")]
    [Description("Status_OneTime")]
    OneTime,
    [EnumMember(Value = "2")]
    [Description("Status_Prepare")]
    Prepare,
    [EnumMember(Value = "N")]
    [Description("Status_NTime")]
    NTime
}

public enum KittingTab
{
    [EnumMember(Value = "0")]
    [Description("Status_KittingFa")]
    KittingFA,
    [EnumMember(Value = "1")]
    [Description("Status_KittingDip")]
    KittingDIP,
    [EnumMember(Value = "2")]
    [Description("Status_KittingSubcon")]
    KittingSubcon,
    [EnumMember(Value = "3")]
    [Description("Status_KittingOutside")]
    KittingOutside
}

public enum KittingLocation
{
    [EnumMember(Value = "0")]
    [Description("Status_Psnv")]
    PSNV,
    [EnumMember(Value = "1")]
    [Description("Status_Outside")]
    Outside
}

public enum KittingFrom
{
    [EnumMember(Value = "0")]
    [Description("Status_Psnv")]
    PSNV,
    [EnumMember(Value = "1")]
    [Description("Status_Jpt")]
    JPT
}

public enum EnumRuleKitting
{
    [Description("Common")]
    Common,
    [Description("JIT")]
    JIT,
    [Description("Process")]
    Process,
    [Description("Special")]
    Special,
    [Description("Type")]
    Type
}