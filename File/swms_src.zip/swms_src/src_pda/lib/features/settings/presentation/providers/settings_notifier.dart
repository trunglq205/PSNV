import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/core/storage/secure_storage_service.dart';
import 'package:swms_finish_goods/features/settings/domain/app_language.dart';
import 'package:swms_finish_goods/features/settings/domain/settings_entity.dart';
import 'package:swms_finish_goods/features/settings/domain/settings_repository.dart';
import 'package:swms_finish_goods/features/settings/presentation/providers/settings_providers.dart';

part 'settings_notifier.g.dart';

// Dùng AsyncNotifier vì build() cần load từ repo (async).
// Sau khi load xong, các setter dùng applyOptimistic (không loading).
@riverpod
class SettingsNotifier extends _$SettingsNotifier
    with BaseAsyncNotifierMixin<SettingsEntity> {
  SettingsRepository get _repo => ref.read(settingsRepositoryProvider);

  SecureStorageService get _secureStorage => ref.read(secureStorageProvider);

  @override
  Future<SettingsEntity> build() => _repo.getSettings();

  // state.value có thể null khi đang build() → fallback về default.
  SettingsEntity get _current => state.value ?? const SettingsEntity();

  Future<void> setLanguage(AppLanguage value) =>
      _save(_current.copyWith(language: value));

  Future<void> setSoundAlert(bool value) =>
      _save(_current.copyWith(soundAlert: value));

  Future<void> _save(SettingsEntity next) =>
      applyOptimistic(next, (v) => _repo.saveSettings(v));

  Future<void> logout() => _secureStorage.clear();
}
