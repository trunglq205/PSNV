// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stocktake_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(stocktakeRepository)
final stocktakeRepositoryProvider = StocktakeRepositoryProvider._();

final class StocktakeRepositoryProvider
    extends
        $FunctionalProvider<
          StocktakeRepository,
          StocktakeRepository,
          StocktakeRepository
        >
    with $Provider<StocktakeRepository> {
  StocktakeRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'stocktakeRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$stocktakeRepositoryHash();

  @$internal
  @override
  $ProviderElement<StocktakeRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  StocktakeRepository create(Ref ref) {
    return stocktakeRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StocktakeRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StocktakeRepository>(value),
    );
  }
}

String _$stocktakeRepositoryHash() =>
    r'fd0a52157ae37d1d2ad6c6308b7ec4194cc4a8a4';

/// Danh sách phiếu theo loại (morning | monthly | shipment).

@ProviderFor(stocktakeCounts)
final stocktakeCountsProvider = StocktakeCountsFamily._();

/// Danh sách phiếu theo loại (morning | monthly | shipment).

final class StocktakeCountsProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<CountSummary>>,
          List<CountSummary>,
          FutureOr<List<CountSummary>>
        >
    with
        $FutureModifier<List<CountSummary>>,
        $FutureProvider<List<CountSummary>> {
  /// Danh sách phiếu theo loại (morning | monthly | shipment).
  StocktakeCountsProvider._({
    required StocktakeCountsFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'stocktakeCountsProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$stocktakeCountsHash();

  @override
  String toString() {
    return r'stocktakeCountsProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<List<CountSummary>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<CountSummary>> create(Ref ref) {
    final argument = this.argument as String;
    return stocktakeCounts(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is StocktakeCountsProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$stocktakeCountsHash() => r'e72cd9e85efb4c70008a0e0c21a56a887b7ff1db';

/// Danh sách phiếu theo loại (morning | monthly | shipment).

final class StocktakeCountsFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<List<CountSummary>>, String> {
  StocktakeCountsFamily._()
    : super(
        retry: null,
        name: r'stocktakeCountsProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Danh sách phiếu theo loại (morning | monthly | shipment).

  StocktakeCountsProvider call(String type) =>
      StocktakeCountsProvider._(argument: type, from: this);

  @override
  String toString() => r'stocktakeCountsProvider';
}

/// Chi tiết 1 phiếu.

@ProviderFor(stocktakeDetail)
final stocktakeDetailProvider = StocktakeDetailFamily._();

/// Chi tiết 1 phiếu.

final class StocktakeDetailProvider
    extends
        $FunctionalProvider<
          AsyncValue<CountDetail>,
          CountDetail,
          FutureOr<CountDetail>
        >
    with $FutureModifier<CountDetail>, $FutureProvider<CountDetail> {
  /// Chi tiết 1 phiếu.
  StocktakeDetailProvider._({
    required StocktakeDetailFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'stocktakeDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$stocktakeDetailHash();

  @override
  String toString() {
    return r'stocktakeDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<CountDetail> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<CountDetail> create(Ref ref) {
    final argument = this.argument as int;
    return stocktakeDetail(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is StocktakeDetailProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$stocktakeDetailHash() => r'bac836c6f82aa6a9f982826cfd68b94ae8d0a7c7';

/// Chi tiết 1 phiếu.

final class StocktakeDetailFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<CountDetail>, int> {
  StocktakeDetailFamily._()
    : super(
        retry: null,
        name: r'stocktakeDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Chi tiết 1 phiếu.

  StocktakeDetailProvider call(int id) =>
      StocktakeDetailProvider._(argument: id, from: this);

  @override
  String toString() => r'stocktakeDetailProvider';
}
