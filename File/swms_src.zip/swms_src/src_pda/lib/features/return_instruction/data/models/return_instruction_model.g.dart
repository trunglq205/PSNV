// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_instruction_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReturnInstructionModel _$ReturnInstructionModelFromJson(
  Map<String, dynamic> json,
) => ReturnInstructionModel(
  id: (json['id'] as num).toInt(),
  docNo: json['docNo'] as String,
  goodsType: json['goodsType'] as String?,
  customer: json['customer'] as String?,
  expectedDate: json['expectedDate'] == null
      ? null
      : DateTime.parse(json['expectedDate'] as String),
  docStatus: json['docStatus'] as String?,
  note: json['note'] as String?,
  modelCount: (json['modelCount'] as num?)?.toInt() ?? 0,
  totalQty: (json['totalQty'] as num?)?.toInt() ?? 0,
  receivedQty: (json['receivedQty'] as num?)?.toInt() ?? 0,
  overReceived: json['overReceived'] as bool? ?? false,
  shortReceived: json['shortReceived'] as bool? ?? false,
  diffQty: (json['diffQty'] as num?)?.toInt() ?? 0,
  closedAt: json['closedAt'] == null
      ? null
      : DateTime.parse(json['closedAt'] as String),
  closedBy: json['closedBy'] as String?,
  actualMailSentAt: json['actualMailSentAt'] == null
      ? null
      : DateTime.parse(json['actualMailSentAt'] as String),
  createdAt: json['createdAt'] == null
      ? null
      : DateTime.parse(json['createdAt'] as String),
  createdBy: json['createdBy'] as String?,
  lines:
      (json['lines'] as List<dynamic>?)
          ?.map(
            (e) =>
                ReturnInstructionLineModel.fromJson(e as Map<String, dynamic>),
          )
          .toList() ??
      const [],
);

Map<String, dynamic> _$ReturnInstructionModelToJson(
  ReturnInstructionModel instance,
) => <String, dynamic>{
  'id': instance.id,
  'docNo': instance.docNo,
  'goodsType': ?instance.goodsType,
  'customer': ?instance.customer,
  'expectedDate': ?instance.expectedDate?.toIso8601String(),
  'docStatus': ?instance.docStatus,
  'note': ?instance.note,
  'modelCount': instance.modelCount,
  'totalQty': instance.totalQty,
  'receivedQty': instance.receivedQty,
  'overReceived': instance.overReceived,
  'shortReceived': instance.shortReceived,
  'diffQty': instance.diffQty,
  'closedAt': ?instance.closedAt?.toIso8601String(),
  'closedBy': ?instance.closedBy,
  'actualMailSentAt': ?instance.actualMailSentAt?.toIso8601String(),
  'createdAt': ?instance.createdAt?.toIso8601String(),
  'createdBy': ?instance.createdBy,
  'lines': instance.lines,
};

ReturnInstructionLineModel _$ReturnInstructionLineModelFromJson(
  Map<String, dynamic> json,
) => ReturnInstructionLineModel(
  lineNo: (json['lineNo'] as num).toInt(),
  model: json['model'] as String,
  qty: (json['qty'] as num?)?.toInt() ?? 0,
  receivedQty: (json['receivedQty'] as num?)?.toInt() ?? 0,
  remainingQty: (json['remainingQty'] as num?)?.toInt() ?? 0,
  diffQty: (json['diffQty'] as num?)?.toInt() ?? 0,
  note: json['note'] as String?,
);

Map<String, dynamic> _$ReturnInstructionLineModelToJson(
  ReturnInstructionLineModel instance,
) => <String, dynamic>{
  'lineNo': instance.lineNo,
  'model': instance.model,
  'qty': instance.qty,
  'receivedQty': instance.receivedQty,
  'remainingQty': instance.remainingQty,
  'diffQty': instance.diffQty,
  'note': ?instance.note,
};
