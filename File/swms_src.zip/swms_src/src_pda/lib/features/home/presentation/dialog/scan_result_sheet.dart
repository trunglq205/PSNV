import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_shadows.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';

// ─────────────────────────────────────────────────────────────────────────────
// Public API
// ─────────────────────────────────────────────────────────────────────────────

/// Hiển thị kết quả quét không nhận dạng được.
///
/// Sheet chỉ có nút Đóng → không trả giá trị.
Future<void> showUnknownScanResultSheet(
  BuildContext context, {
  required String rawValue,
}) {
  return showModalBottomSheet<void>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black54,
    builder: (_) => _UnknownScanResultSheet(rawValue: rawValue),
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// Sheet
// ─────────────────────────────────────────────────────────────────────────────

class _UnknownScanResultSheet extends StatelessWidget {
  const _UnknownScanResultSheet({required this.rawValue});

  final String rawValue;

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;

    return Container(
      decoration: BoxDecoration(
        color: cs.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Hero ──────────────────────────────────────────────────────────
          _HeroBanner(onClose: () => Navigator.of(context).pop()),

          // ── Body ──────────────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(
              AppDimens.md,
              AppDimens.md,
              AppDimens.md,
              0,
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                _RawValueCard(value: rawValue),

                const SizedBox(height: AppDimens.sm),

                _HintRow(text: LocaleKeys.scan_result_unknown_hint.tr()),

                const SizedBox(height: AppDimens.md),

                AppButton(
                  label: LocaleKeys.common_close.tr(),
                  variant: AppButtonVariant.neutral,
                  onPressed: () => Navigator.of(context).pop(),
                ),

                SizedBox(
                  height: MediaQuery.of(context).padding.bottom + AppDimens.md,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Hero banner — cố định xám (unknown)
// ─────────────────────────────────────────────────────────────────────────────

class _HeroBanner extends StatelessWidget {
  const _HeroBanner({required this.onClose});

  final VoidCallback onClose;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF475569), Color(0xFF334155)],
        ),
        borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Icon badge
          Container(
            width: 36,
            height: 36,
            decoration: BoxDecoration(
              color: Colors.white.withValues(alpha: 0.15),
              borderRadius: BorderRadius.circular(12),
            ),
            child: const Icon(
              Icons.barcode_reader,
              color: Colors.white,
              size: 20,
            ),
          ),

          const SizedBox(width: AppDimens.sm),

          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  LocaleKeys.scan_result_unknown_type.tr(),
                  style: AppTextStyles.title.copyWith(color: Colors.white),
                ),
                const SizedBox(height: 2),
                Text(
                  LocaleKeys.scan_result_unknown_sub.tr(),
                  style: AppTextStyles.caption.copyWith(color: Colors.white70),
                ),
              ],
            ),
          ),

          // Close
          GestureDetector(
            onTap: onClose,
            child: Container(
              width: 32,
              height: 32,
              decoration: BoxDecoration(
                color: Colors.white.withValues(alpha: 0.15),
                borderRadius: BorderRadius.circular(8),
              ),
              child: const Icon(
                Icons.close_rounded,
                color: Colors.white,
                size: 16,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Raw value card
// ─────────────────────────────────────────────────────────────────────────────

class _RawValueCard extends StatefulWidget {
  const _RawValueCard({required this.value});

  final String value;

  @override
  State<_RawValueCard> createState() => _RawValueCardState();
}

class _RawValueCardState extends State<_RawValueCard> {
  bool _copied = false;

  Future<void> _copy() async {
    await Clipboard.setData(ClipboardData(text: widget.value));
    // Sheet có thể đã đóng (quét mã mới) trong lúc chờ clipboard.
    if (!mounted) return;
    setState(() => _copied = true);
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: swms.border),
        boxShadow: AppShadows.s1,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.scan_result_content_label.tr(),
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
          const SizedBox(height: AppDimens.xs),
          Row(
            children: [
              Expanded(
                child: Text(
                  widget.value,
                  style: AppTextStyles.code.copyWith(
                    color: swms.text1,
                    letterSpacing: 1.0,
                  ),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              _CopyButton(copied: _copied, onTap: _copy),
            ],
          ),
        ],
      ),
    );
  }
}

class _CopyButton extends StatelessWidget {
  const _CopyButton({required this.copied, required this.onTap});

  final bool copied;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
        decoration: BoxDecoration(
          color: copied ? AppColors.successBg : AppColors.primaryTint,
          borderRadius: BorderRadius.circular(AppDimens.rBtn),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(
              copied ? Icons.check_rounded : Icons.copy_rounded,
              size: 13,
              color: copied ? AppColors.success : AppColors.primary,
            ),
            const SizedBox(width: 4),
            Text(
              copied
                  ? LocaleKeys.scan_result_copied.tr()
                  : LocaleKeys.scan_result_copy.tr(),
              style: AppTextStyles.caption.copyWith(
                color: copied ? AppColors.success : AppColors.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Hint row
// ─────────────────────────────────────────────────────────────────────────────

class _HintRow extends StatelessWidget {
  const _HintRow({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Icon(Icons.warning_amber_rounded, size: 14, color: swms.text3),
        const SizedBox(width: AppDimens.xs),
        Expanded(
          child: Text(
            text,
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
        ),
      ],
    );
  }
}
