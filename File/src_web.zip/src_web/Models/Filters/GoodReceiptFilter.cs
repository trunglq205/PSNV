﻿using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Refit;

namespace SWMS_WebTool.Models
{
	public class GoodReceiptFilter : BaseFilter
	{
		public GoodReceiptFilter() {
        }

        public DeliveryPlanType? Type { get; set; }
        [Display(Name = "DA/INV No")]
        public string? DACode { get; set; }
        [Display(Name = "Vendor")]
        [FromQuery(Name = "Vendor")] 
        public string? VendorCode { get; set; }
        [FromQuery(Name = "No")]
        [Display(Name = "Delivery Plan")]
        public string? DeliveryPlanNo { get; set; }
		public string? Plant { get; set; }
		public string? Sloc { get; set; }
		public string? Material { get; set; }
        [Display(Name = "Tracking Number")]
        public string? TrackingNumber { get; set; }

        public bool? isUrgent { get; set; }
        public DeliveryPlanStatus? Status { get; set; }
        [Query(Format = "yyyy-MM-dd")]
        public DateTime? Date { get; set; } = DateTime.Now;
    }
}

