using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Layout;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;

namespace SWMS_WebTool.ViewModels
{
    public class LayoutViewModel
    {
        public List<Floor> Floors = new List<Floor>();

        public int SelectedFloor = 0;

        public Floor FloorLayout;

        public object getQueryConditions(LayoutFilter? filter = null, int? selectedFloor = null)
        {
            return new
            {
                selectedFloor = selectedFloor ?? SelectedFloor,
            };
        }
    }

    public class ActionViewModel
    {
        public ActionViewModel(WidgetType? type = null, string? icon = null)
        {
            Type = type;
            Icon = icon ?? type?.GetImagePath() ?? string.Empty;
        }

        public WidgetType? Type;

        public string Icon;

        public List<ActionViewModel>? Children = null;

        public ActionViewModel? SelectedItem = null;
    }

    public class FloorViewModel
    {
        [Required(ErrorMessage = "FloorName is required.")]
        public string Name { get; set; }

        [Required(ErrorMessage = "FloorCode is required.")]
        public string Code { get; set; }

        [Range(1, 10000, ErrorMessage = "Width must be greater than 1.")]
        public int Width { get; set; }

        [Range(1, 10000, ErrorMessage = "Height must be greater than 1.")]
        public int Height { get; set; }
    }

    public class ZoneViewModel
    {
        public int FloorId { get; set; }
        [Required(ErrorMessage = "ZoneName is required.")]
        public string Name { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        [Range(1, 10000, ErrorMessage = "Width must be greater than 1.")]
        public double Width { get; set; }
        [Range(1, 10000, ErrorMessage = "Height must be greater than 1.")]
        public double Height { get; set; }
    }    

    public class RackViewModel
    {
        public int? RackID { get; set; }
        [Required(ErrorMessage = "RackCode is required.")]
        public string RackCode { get; set; }
        public double X { get; set; } = 0;
        public double Y { get; set; } = 0;
        [Range(1, 10000, ErrorMessage = "Width must be greater than 1.")]
        public double Width { get; set; }
        [Range(1, 10000, ErrorMessage = "Height must be greater than 1.")]
        public double Height { get; set; }
        public double Rotation { get; set; }
        public string PIC { get; set; }
        public int ZoneID { get; set; }
        [Range(1, 10000, ErrorMessage = "Number of Layers must be greater than 1.")]
        public int NumberOfLayer { get; set; } = 1;
        [Range(1, 10000, ErrorMessage = "Number of Units must be greater than 1.")]
        public int NumberOfUnit { get; set; } = 1;
        public string Category { get; set; }

        [Required(ErrorMessage = "RackDetailType is required.")]
        public RackDetailType RackDetailType { get; set; }
        public bool IsPL { get; set; } = false;
        public TypeSloc TypeSloc { get; set; } = TypeSloc.FA;
        public List<bool> JITs { get; set; }
    }

    public class TrolleyLayoutViewModel
    {
        [Required(ErrorMessage = "Code is required.")]
        public int Code { get; set; }
        public TrolleyCategory Category { get; set; }

        public double X { get; set; }
        public double Y { get; set; }
        [Range(1, 10000, ErrorMessage = "Width must be greater than 1.")]
        public double Width { get; set; } = 240;
        [Range(1, 10000, ErrorMessage = "Height must be greater than 1.")]
        public double Height { get; set; } = 290;
        public int FloorID { get; set; }

    }

    public class GenQRCodeLocation
    {
        public string Name { get; set; }
        public string QRCode { get; set; }
    }
}
