namespace Swms.FinishGoods.API.Features.Pallets.Business.Entities
{
    /// <summary>
    /// Vị trí gợi ý để lưu pallet (FR-STR-02: dựa loại SP / khu cùng model / FIFO / chỗ trống).
    /// </summary>
    public sealed class LocatorSuggestion
    {
        public long LocatorId { get; set; }
        public string LocatorCode { get; set; } = default!;
        public string? AreaCode { get; set; }
        public string? AreaName { get; set; }

        /// <summary>Lý do gợi ý để hiển thị cho operator (vd: "cùng khu model", "còn trống").</summary>
        public string? Reason { get; set; }
    }

    /// <summary>Một model trong pallet + tổng số lượng và số thùng (gộp từ box_lines).</summary>
    public sealed class PalletModelQty
    {
        public string Model { get; set; } = default!;
        public int TotalQty { get; set; }

        /// <summary>Số thùng chứa model này trong lot.</summary>
        public int BoxCount { get; set; }
    }
}
