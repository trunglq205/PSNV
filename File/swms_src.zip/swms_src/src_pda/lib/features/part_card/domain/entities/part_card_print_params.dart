import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_line.dart';

/// 1 dòng hàng (inner box) của phiếu — khớp `SavePartCardRowRequest`.
///
/// [g21Part] / [oqcChecked] / các `inner*` chỉ có ý nghĩa với phiếu nhiều mã.
/// App PDA chưa thu thập mấy field này nên để trống.
@immutable
class PartCardPrintRow {
  const PartCardPrintRow({
    required this.model,
    required this.qty,
    this.g21Part,
    this.innerBox,
    this.origin,
    this.oqcChecked = false,
    this.innerLength,
    this.innerWidth,
    this.innerHeight,
    this.innerWeight,
  });

  final String model;

  /// pcs / 1 thùng — ĐÚNG con số in ở cột `Qty` trên tem.
  final int qty;

  final String? g21Part;

  /// Số thùng của mã. Server nhận string nên gửi dạng `'5'`.
  final String? innerBox;

  final String? origin;
  final bool oqcChecked;

  final double? innerLength;
  final double? innerWidth;
  final double? innerHeight;
  final double? innerWeight;

  factory PartCardPrintRow.fromLine(PartCardLine line) => PartCardPrintRow(
    model: line.model.trim(),
    qty: line.quantity,
    innerBox: '${line.box}',
    origin: line.origin?.code,
    oqcChecked: line.oqcChecked,
  );
}

/// Params domain cho 1 phiếu Part Card đã in
/// (map sang `PrintHistoryRequestModel` ở tầng data → `SavePrintRequest`).
@immutable
class PartCardPrintParams {
  const PartCardPrintParams({
    required this.cardId,
    required this.productionDate,
    required this.payload,
    required this.rows,
    required this.isMulti,
    required this.categoryCode,
    this.poNo,
    this.customerPoNo,
    this.packer,
    this.checker,
    this.length,
    this.width,
    this.height,
    this.weight,
    this.model,
    this.qty,
    this.origin,
  });

  /// Card_ID — KHÔNG có field riêng trong request (nằm trong [payload]: `ID=...`).
  /// Giữ ở client để hiển thị / đối chiếu.
  final String cardId;

  final DateTime productionDate;
  final String payload;

  /// LUÔN có ít nhất 1 dòng — server 400 "Yêu cầu thông tin mã model" nếu rỗng.
  final List<PartCardPrintRow> rows;

  /// Phiếu nhiều mã. Map sang `IsOverseaService` phía server.
  final bool isMulti;

  final String? poNo; // PSNV PO
  final String? customerPoNo; // CUS PO

  final String? packer;
  final String? checker;

  final double? length;
  final double? width;
  final double? height;
  final double? weight;

  /// `int Category` phía API — lấy từ `Category.value` (khớp `Category.fromValue`).
  final int categoryCode;

  /// Thông tin cấp PHIẾU. Chỉ có giá trị khi phiếu 1 mã; phiếu nhiều mã để
  /// `null` vì chi tiết nằm ở [rows].
  final String? model;
  final int? qty;
  final String? origin;

  factory PartCardPrintParams.fromForm({
    required PartCardForm form,
    required String cardId,
    required bool multi,
  }) {
    return PartCardPrintParams(
      cardId: cardId,
      productionDate: form.productionDate,
      payload: form.buildMainPayload(cardId),
      rows: form.lines.map(PartCardPrintRow.fromLine).toList(growable: false),
      isMulti: multi,
      poNo: multi ? _blankToNull(form.psnvPo) : null,
      customerPoNo: multi ? _blankToNull(form.cusPo) : null,
      length: form.length,
      width: form.width,
      height: form.height,
      weight: form.weight,
      categoryCode: form.category?.value ?? 0,
      model: multi ? null : form.model,
      qty: multi ? null : form.quantity,
      origin: multi ? null : form.origin?.code,
    );
  }

  static String? _blankToNull(String value) {
    final trimmed = value.trim();
    return trimmed.isEmpty ? null : trimmed;
  }
}

/// 1 dòng hàng trả về trong lịch sử in.
@immutable
class PartCardHistoryRow {
  const PartCardHistoryRow({
    required this.model,
    this.g21Part,
    this.innerBox,
    this.qty,
    this.origin,
    this.oqcChecked = false,
  });

  final String model;
  final String? g21Part;
  final String? innerBox;
  final int? qty;
  final String? origin;
  final bool oqcChecked;
}

/// Kết quả trả về sau khi lưu lịch sử in (`PartCardResponse`).
@immutable
class PartCardPrintHistory {
  const PartCardPrintHistory({
    this.id,
    this.poNo,
    this.customerPoNo,
    this.productionDate,
    this.packer,
    this.checker,
    this.model,
    this.qty,
    this.origin,
    this.isMulti = false,
    this.rows = const [],
    this.printedAt,
    this.printedBy,
  });

  final int? id;
  final String? poNo;
  final String? customerPoNo;
  final DateTime? productionDate;
  final String? packer;
  final String? checker;
  final String? model;
  final int? qty;
  final String? origin;
  final bool isMulti;
  final List<PartCardHistoryRow> rows;
  final DateTime? printedAt;
  final String? printedBy;
}
/// 1 nhãn cần in: dữ liệu phiếu + Card_ID in lên QR.
///
/// Mỗi nhãn 1 Card_ID riêng — N nhãn là N phiếu khác nhau, không phải N bản
/// copy của cùng 1 phiếu.
@immutable
class PartCardPrintJob {
  const PartCardPrintJob({required this.form, required this.cardId});

  /// Phiếu đã gắn đúng `mode` (quyết định layout tem + cờ multi khi lưu).
  final PartCardForm form;
  final String cardId;

  PartCardPrintParams toParams() => PartCardPrintParams.fromForm(
    form: form,
    cardId: cardId,
    multi: form.mode.isMulti,
  );
}
