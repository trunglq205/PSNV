using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Features.Users.Business;
using Swms.FinishGoods.API.Features.Users.DataAccess;

namespace Swms.FinishGoods.API.Features.Users;

public static class UserModule
{
    public static IServiceCollection AddUserFeature(this IServiceCollection services)
    {
        services.AddScoped<IUserService, UserService>();
        services.AddScoped<IUserRepository, UserRepository>();
        return services;
    }
}
