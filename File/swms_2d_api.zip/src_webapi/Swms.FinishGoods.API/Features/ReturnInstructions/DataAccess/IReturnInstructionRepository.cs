using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Shared.Business.Mail;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

public interface IReturnInstructionRepository
{
    /// <summary>
    /// Danh sách phiếu kèm số dòng và tổng SL, KHÔNG kèm chi tiết dòng — màn
    /// danh sách không hiện dòng, nạp hết dòng của mọi phiếu là phí.
    /// </summary>
    Task<IReadOnlyList<ReturnInstruction>> GetListAsync(ReturnInstructionQuery query);

    /// <summary>Một phiếu kèm đủ dòng. NULL = không có / đã xoá mềm.</summary>
    Task<ReturnInstruction?> GetByIdAsync(long id);

    /// <summary>
    /// Tạo phiếu + dòng trong một transaction, tự sinh <c>doc_no</c>.
    /// </summary>
    /// <returns>Id phiếu vừa tạo.</returns>
    Task<long> CreateAsync(ReturnInstruction doc, string? user);

    /// <summary>
    /// Sửa phần header và THAY TOÀN BỘ dòng bằng danh sách mới.
    ///
    /// Dòng cũ bị xoá mềm chứ không xoá cứng: mục 2 trở đi sẽ trỏ ngược về
    /// dòng chỉ thị, nên một dòng từng tồn tại phải còn đọc được.
    /// </summary>
    /// <returns>false = không có phiếu nào khớp (đã xoá, hoặc id sai).</returns>
    Task<bool> UpdateAsync(ReturnInstruction doc, string? user);

    /// <summary>Xoá mềm cả phiếu lẫn dòng.</summary>
    Task<bool> SoftDeleteAsync(long id, string? user);

    /// <summary>Ghi dấu vết đã báo FA. Mail hỏng thì không gọi hàm này.</summary>
    Task MarkMailSentAsync(long id, string recipients);

    // ── Mục 2b: chốt SL thực nhận ──

    /// <summary>
    /// Chốt thực nhận: đóng phiếu + đóng dấu <c>closed_at / closed_by</c>.
    ///
    /// Điều kiện "đang mở" nằm trong chính câu UPDATE, nên hai người cùng bấm
    /// Chốt thì người sau nhận false — không chốt hai lần, không mail hai lần.
    /// </summary>
    /// <returns>false = phiếu không còn ở trạng thái mở.</returns>
    Task<bool> CloseAsync(long id, string? user);

    /// <summary>
    /// Office mở lại phiếu đã chốt để WH quét tiếp phần hàng về sau.
    ///
    /// KHÔNG xoá <c>closed_at</c> / <c>actual_mail_sent_at</c> — đó là dấu vết
    /// FA đã nhận số nào; chốt lại sẽ ghi đè bằng mốc mới.
    /// </summary>
    /// <returns>false = phiếu không ở trạng thái đã đóng.</returns>
    Task<bool> ReopenAsync(long id, string? user);

    /// <summary>Ghi dấu vết đã báo FA SỐ THỰC NHẬN.</summary>
    Task MarkActualMailSentAsync(long id, string recipients);

    /// <summary>
    /// Những mã model KHÔNG có trong <c>master.models</c> (chưa xoá mềm).
    /// Trả về danh sách thiếu chứ không trả true/false: thông báo lỗi cần nói
    /// rõ mã nào sai, người nhập mới biết sửa ô nào.
    /// </summary>
    Task<IReadOnlyList<string>> FindUnknownModelsAsync(IReadOnlyList<string> models);

    /// <summary>
    /// Người nhận mail của một sự kiện, lấy từ <c>master.email_config</c> qua
    /// <c>master.fn_email_recipients</c>.
    /// </summary>
    Task<List<MailRecipient>> GetMailRecipientsAsync(string eventCode);

    /// <summary>
    /// Mẫu tiêu đề / thân mail từ <c>master.email_events</c>.
    /// NULL = chưa khai sự kiện, hoặc đã tắt (<c>is_active = 0</c>).
    /// </summary>
    Task<MailTemplateRow?> GetMailTemplateAsync(string eventCode);

    /// <summary>Mail của người đang thao tác, để đặt Reply-To.</summary>
    Task<string?> GetUserEmailAsync(string? employeeCode);

    // ── Mục 2a: sổ serial của phiếu ──

    /// <summary>
    /// Category của từng model, đọc <c>master.models.category_id</c>. Model
    /// không có trong danh mục hoặc chưa khai category thì KHÔNG có mặt trong
    /// kết quả — người gọi phân biệt được "thiếu" với "sai".
    /// </summary>
    Task<IReadOnlyDictionary<string, int>> GetCategoryByModelAsync(IReadOnlyList<string> models);

    /// <summary>
    /// Serial nào trong danh sách đã nằm trong sổ của một phiếu đang chạy.
    /// Dùng để pre-check trả lỗi nói rõ serial nào, phiếu nào; chốt chặn thật
    /// là unique index <c>ux_ris_serial_open</c>.
    /// </summary>
    Task<IReadOnlyList<ReturnSerialOwnerRow>> FindSerialOwnersAsync(IReadOnlyList<string> serials);

    /// <summary>
    /// Đăng ký serial vào sổ của phiếu + đóng dấu pallet (disposition theo loại
    /// hàng của phiếu, inspection_status = inspection_exempt).
    ///
    /// Nhận SẴN connection + transaction: chạy bên trong transaction tạo pallet
    /// (hook <c>onInserted</c>), nên pallet và sổ serial cùng sống cùng chết.
    /// </summary>
    Task RegisterSerialsAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletDbId,
        string disposition,
        IReadOnlyList<ReturnSerial> serials,
        string? user);

    /// <summary>Các pallet hàng return đã nhận vào phiếu, mới nhất trước.</summary>
    Task<IReadOnlyList<ReturnPallet>> GetPalletsByDocAsync(long docId);

    /// <summary>
    /// Huỷ một lần nhận: xoá mềm dòng sổ serial của pallet đó trong phiếu đó,
    /// và xoá mềm luôn pallet + thùng + dòng thùng. Tất cả trong một transaction.
    ///
    /// Giải phóng serial là phần KHÔNG ĐƯỢC THIẾU: unique index
    /// <c>ux_ris_serial_open</c> giữ serial trên phạm vi toàn hệ thống, nên một
    /// pallet quét sai mà không tháo sổ là những con hàng đó không bao giờ quét
    /// lại được vào pallet mới.
    /// </summary>
    /// <returns>Số serial đã giải phóng.</returns>
    Task<int> ReleasePalletAsync(long docId, long palletDbId, string? user);

    /// <summary>Toàn bộ serial trong sổ của phiếu.</summary>
    Task<IReadOnlyList<ReturnSerial>> GetSerialsByDocAsync(long docId);

    // ───────────────── Mục 2d — FA đóng lại Pallet ID ─────────────────
    //
    // Đặt ở ĐÂY chứ không tách interface riêng: cả bốn hàm dưới đọc/ghi đúng
    // hai bảng mà interface này đã sở hữu (sổ serial + pallet của phiếu), và
    // AttachFaPalletAsync phải chạy trong CÙNG transaction với
    // RegisterSerialsAsync ở trên — cùng hook `onInserted` của IPalletService.
    // Tách ra hai repository là hai IDbConnection, tức là hai transaction.

    /// <summary>
    /// Sổ serial của phiếu ở dạng GỌN (serial · model · status) để PDA tải một
    /// lần rồi kiểm NGAY TRÊN MÁY lúc FA quét.
    ///
    /// Không dùng <see cref="GetSerialsByDocAsync"/>: một phiếu vài nghìn
    /// serial, trả object đầy đủ là vài trăm KB qua mạng kho.
    /// </summary>
    Task<IReadOnlyList<ReturnSerialIndexRow>> GetSerialIndexAsync(long docId);

    /// <summary>
    /// Tra một loạt serial FA vừa quét: mỗi con đang thuộc phiếu nào, model gì,
    /// trạng thái gì. Con không có trong sổ nào thì KHÔNG có dòng trả về.
    ///
    /// Khác <see cref="FindSerialOwnersAsync"/> ở chỗ trả thêm model — mục 2d
    /// lấy model TỪ SỔ vì FA không nhập model.
    /// </summary>
    Task<IReadOnlyList<ReturnSerialResolution>> ResolveSerialsAsync(
        IReadOnlyList<string> serials);

    /// <summary>
    /// Gắn pallet FA vừa đóng vào những serial ĐÃ KHỚP: đổi <c>pallet_id</c> và
    /// <c>box_no</c>, đóng dấu <c>disposition</c> cho pallet mới.
    ///
    /// GIỮ NGUYÊN <c>status = 'at_fa'</c>: hàng vẫn đang ở FA, chỉ là đã được
    /// đóng lại thành pallet mới. Chỉ mục 3 (SCS quét nhận lại) mới đổi sang
    /// <c>returned</c>.
    ///
    /// Điều kiện <c>AND status = N'at_fa'</c> nằm TRONG câu UPDATE, nên hai lần
    /// quét song song thì lần sau cập nhật 0 dòng chứ không kéo serial của người
    /// khác sang pallet mình.
    /// </summary>
    /// <returns>Số serial đã gắn được.</returns>
    Task<int> AttachFaPalletAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletDbId,
        string disposition,
        IReadOnlyList<ReturnFaSerialRow> serials,
        string? user);

    /// <summary>
    /// Ghi nhật ký serial lệch — bản chạy TRONG transaction tạo pallet, nên
    /// nhật ký và pallet cùng sống cùng chết.
    /// </summary>
    Task AddMismatchesAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long? palletDbId,
        IReadOnlyList<ReturnSerialMismatch> rows,
        string? user);

    /// <summary>
    /// Ghi nhật ký serial lệch — bản ĐỨNG RIÊNG, dùng khi KHÔNG con nào khớp
    /// nên chẳng có pallet nào được tạo. <c>pallet_id</c> để NULL.
    ///
    /// Phải lưu được ở trường hợp đó mới có nghĩa: cả lần quét toàn hàng lạ
    /// chính là lúc SCS cần danh sách nhất.
    /// </summary>
    Task AddMismatchesAsync(
        long docId, IReadOnlyList<ReturnSerialMismatch> rows, string? user);

    /// <summary>
    /// Nhật ký lệch của một phiếu, mới nhất trước.
    /// </summary>
    /// <param name="openOnly">
    /// <c>true</c> = chỉ dòng chưa xử lý. Màn hình luôn xin CẢ dòng đã xử lý rồi
    /// lọc ở client, để con số "còn n chưa xử lý" vẫn đúng khi người dùng bật
    /// xem hết.
    /// </param>
    Task<IReadOnlyList<ReturnSerialMismatch>> GetMismatchesAsync(long docId, bool openOnly);

    /// <summary>Một dòng nhật ký theo id, để trả về sau khi đánh dấu đã xử lý.</summary>
    Task<ReturnSerialMismatch?> GetMismatchByIdAsync(long id);

    /// <summary>
    /// Đánh dấu một dòng nhật ký đã xử lý. Điều kiện
    /// <c>resolved_at IS NULL</c> nằm TRONG câu UPDATE: hai người bấm cùng lúc
    /// thì người sau nhận <c>false</c>, và mốc của người đầu KHÔNG bị ghi đè.
    ///
    /// CHỈ đóng dòng nhật ký, KHÔNG đổi trạng thái serial — con thuộc phiếu khác
    /// thì việc của nó nằm ở phiếu đó.
    /// </summary>
    /// <returns><c>false</c> khi không có dòng nào, hoặc đã xử lý trước đó.</returns>
    Task<bool> ResolveMismatchAsync(long id, string? note, string? user);
}

/// <summary>
/// Serial đã có chủ: dùng để báo lỗi nói rõ nó đang ở phiếu nào, trạng thái gì.
/// Class có property, không dùng ValueTuple — xem <see cref="MailTemplateRow"/>.
/// </summary>
public class ReturnSerialOwnerRow
{
    public string SerialNo { get; set; } = string.Empty;
    public long DocId { get; set; }
    public string DocNo { get; set; } = string.Empty;
    public string Status { get; set; } = string.Empty;
}

/// <summary>
/// Mẫu mail đọc từ <c>master.email_events</c>. Dùng class có property chứ
/// KHÔNG dùng ValueTuple: Dapper map theo tên cột vào property, còn với tuple
/// thì chỉ map được theo vị trí và tuple nullable lại càng không chắc chắn.
/// Cùng khuôn với <c>MailTemplateRow</c> của phiếu bất thường.
/// </summary>
public class MailTemplateRow
{
    public string? Subject { get; set; }
    public string? Body { get; set; }
}
