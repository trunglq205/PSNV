﻿using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;

namespace Swms.FinishGoods.API.Features.StockEvents.Api
{
    /// <summary>
    /// Vị trí + khu, gộp làm một.
    ///
    /// Trước đây là 4 trường phẳng fromLocatorCode/fromAreaCode/toLocatorCode/
    /// toAreaCode, buộc client kiểm null từng cái để biết "event này có đổi vị
    /// trí không". Với object thì <c>to != null</c> là đủ.
    ///
    /// Nhãn event đã nói LOẠI khu (STORAGE_IN), AreaCode nói KHO CỤ THỂ
    /// (STORAGE | FA | JUPITER | MCS). UI ghép: "Lưu kho · FA · A-03-02-01".
    /// </summary>
    public record LocatorRef(string LocatorCode, string? AreaCode)
    {
        /// <summary>Null khi không có locator — event không đổi vị trí.</summary>
        public static LocatorRef? From(string? locatorCode, string? areaCode)
            => string.IsNullOrWhiteSpace(locatorCode) ? null : new(locatorCode, areaCode);
    }

    /// <summary>
    /// Một dòng timeline pallet — 12 trường.
    ///
    /// Nhãn / màu / icon KHÔNG có ở đây: client tra <c>EventCode</c> trong catalog
    /// đã cache (GET /api/stock-event-types). 29 tổ hợp không đáng lặp ở mọi dòng.
    /// </summary>
    public record PalletEventResponse(
        /// <summary>Key cho list, không hiển thị.</summary>
        long Id,

        string EventCode,
        DateTime EventAt,
        string? Actor,

        /// <summary>Null với event không đổi vị trí.</summary>
        LocatorRef? From,
        LocatorRef? To,

        string? RefNo,

        /// <summary>Pallet đối ứng khi tách — gọi by-lot-no/{code}/history để sang.</summary>
        string? RelatedPalletCode,

        int? BoxCountBefore,
        int? BoxCountAfter,
        string? Note,

        /// <summary>JSON nguyên văn — client tự parse theo EventCode.</summary>
        string? Payload)
    {
        public static PalletEventResponse FromRow(PalletEventRow r) => new (
            r.Id, r.EventCode, r.EventAt, r.Actor,
            LocatorRef.From(r.FromLocatorCode, r.FromAreaCode),
            LocatorRef.From(r.ToLocatorCode, r.ToAreaCode),
            r.RefNo, r.RelatedPalletCode,
            r.BoxCountBefore, r.BoxCountAfter, r.Note, r.Payload);
    }

    /// <summary>
    /// Một dòng timeline box — 11 trường.
    ///
    /// <c>Inherited</c>: false = thao tác trên chính thùng này (tạo, đổi pallet,
    /// sửa PO, OQC); true = kế thừa từ pallet chứa nó (lưu kho, chuyển vị trí,
    /// vanning). UI phải phân biệt hai mức — trộn phẳng thì người dùng tưởng có
    /// ai quét riêng từng thùng.
    /// </summary>
    public record BoxEventResponse(
        long Id,
        string EventCode,
        DateTime EventAt,
        string? Actor,
        bool Inherited,

        /// <summary>Pallet chứa thùng TẠI THỜI ĐIỂM đó — đổi sau mỗi lần tách.</summary>
        string? PalletCode,

        LocatorRef? From,
        LocatorRef? To,
        string? RefNo,
        string? Note,
        string? Payload)
    {
        public static BoxEventResponse FromRow(BoxEventRow r) => new(
            r.Id, r.EventCode, r.EventAt, r.Actor, r.Inherited, r.PalletCode,
            LocatorRef.From(r.FromLocatorCode, r.FromAreaCode),
            LocatorRef.From(r.ToLocatorCode, r.ToAreaCode),
            r.RefNo, r.Note, r.Payload);
    }

    /// <summary>
    /// Timeline rút gọn kèm khi quét pallet (<c>?include=history</c>) — 4 trường,
    /// mặc định 10 dòng gần nhất. Đầy đủ thì gọi /history.
    /// </summary>
    public record PalletEventBriefResponse(
        string EventCode,
        DateTime EventAt,
        string? Actor,
        string? ToLocatorCode)
    {
        public static PalletEventBriefResponse From(PalletEventBrief b)
            => new(b.EventCode, b.EventAt, b.Actor, b.ToLocatorCode);
    }

    /// <summary>Header màn lịch sử pallet — 9 trường.</summary>
    public record PalletHistoryHeaderResponse(
        long PalletId,
        string PalletCode,
        string? StockyCode,
        string? Model,
        int? BoxCount,
        string InspectionStatus,
        DateTime? ProductionDate,
        LocatorRef? CurrentLocator,
        bool IsDeleted)
    {
        public static PalletHistoryHeaderResponse From(PalletHistoryHeader h) => new(
            h.PalletId, h.PalletCode, h.StockyCode, h.Model, h.BoxCount,
            h.InspectionStatus, h.ProductionDate,
            LocatorRef.From(h.CurrentLocatorCode, h.CurrentAreaCode),
            h.IsDeleted);
    }

    /// <summary>Header màn lịch sử box — 9 trường.</summary>
    public record BoxHistoryHeaderResponse(
        long BoxId,
        string BoxNo,
        string? PalletCode,
        string? Model,
        int LineCount,
        int? TotalQty,
        int? OqcStatus,
        LocatorRef? CurrentLocator,
        bool IsDeleted)
    {
        public static BoxHistoryHeaderResponse From(BoxHistoryHeader h) => new(
            h.BoxId, h.BoxNo, h.PalletCode, h.Model,
            h.LineCount, h.TotalQty, h.OqcStatus,
            LocatorRef.From(h.CurrentLocatorCode, h.CurrentAreaCode),
            h.IsDeleted);
    }

    public record PalletHistoryResponse(
        PalletHistoryHeaderResponse Header,
        IReadOnlyList<PalletEventResponse> Events)
    {
        public static PalletHistoryResponse From(PalletHistory h) => new(
            PalletHistoryHeaderResponse.From(h.Header),
            h.Events.Select(PalletEventResponse.FromRow).ToList());
    }

    public record BoxHistoryResponse(
        BoxHistoryHeaderResponse Header,
        IReadOnlyList<BoxEventResponse> Events)
    {
        public static BoxHistoryResponse From(BoxHistory h) => new(
            BoxHistoryHeaderResponse.From(h.Header),
            h.Events.Select(BoxEventResponse.FromRow).ToList());
    }

    // ── Catalog ───────────────────────────────────────────────────

    /// <summary>
    /// Một loại event. Client tải MỘT LẦN rồi cache, tra theo Code khi render
    /// timeline. Blazor: singleton; Flutter: Riverpod provider + SharedPreferences.
    /// </summary>
    public record StockEventTypeResponse(
        string Code,
        string NameKey,
        string SubjectType,
        string GroupCode,
        string ColorToken,
        string? Icon,
        int SortOrder)
    {
        public static StockEventTypeResponse From(StockEventType t) => new(
            t.Code, t.NameKey, t.SubjectType, t.GroupCode,
            t.ColorToken, t.Icon, t.SortOrder);
    }

    /// <summary>
    /// Catalog + mốc phiên bản. <c>Version</c> dùng làm ETag để client biết khi
    /// nào phải tải lại thay vì cache vô thời hạn.
    /// </summary>
    public record StockEventTypeListResponse(
        string Version,
        IReadOnlyList<StockEventTypeResponse> Types)
    {
        public static StockEventTypeListResponse From(IReadOnlyList<StockEventType> types)
        {
            // Phiên bản = hash nội dung. Đổi bất kỳ dòng nào -> đổi version.
            var raw = string.Join('|', types.Select(t =>
                $"{t.Code}:{t.NameKey}:{t.GroupCode}:{t.ColorToken}:{t.Icon}:{t.SortOrder}"));

            var hash = Convert.ToHexString(
                System.Security.Cryptography.MD5.HashData(
                    System.Text.Encoding.UTF8.GetBytes(raw)))[..12];

            return new(hash, types.Select(StockEventTypeResponse.From).ToList());
        }
    }

    // ── Query ─────────────────────────────────────────────────────

    /// <summary>Bộ lọc timeline, nhận qua query string.</summary>
    public class StockEventQuery
    {
        public DateTime? From { get; set; }
        public DateTime? To { get; set; }

        /// <summary>CSV event_code, vd "STORAGE_IN,STORAGE_MOVED".</summary>
        public string? Codes { get; set; }

        /// <summary>CSV group_code, vd "MOVE,OQC".</summary>
        public string? Groups { get; set; }

        public StockEventFilter ToFilter() => new()
        {
            From = From,
            To = To,
            Codes = Codes,
            Groups = Groups,
        };
    }

    /// <summary>Mã lỗi của luồng lịch sử.</summary>
    public static class StockEventErrors
    {
        public const string PalletNotFound = "History.PalletNotFound";  // 404
        public const string BoxNotFound = "History.BoxNotFound";        // 404
    }
}