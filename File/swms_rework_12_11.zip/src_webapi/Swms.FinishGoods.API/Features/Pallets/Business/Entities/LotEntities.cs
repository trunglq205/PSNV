namespace Swms.FinishGoods.API.Features.Pallets.Business.Entities
{
    public class Pallet
    {
        public long Id { get; set; }
        public string LotNo { get; set; } = default!;
        public int CategoryCode { get; set; }
        public string CategoryName { get; set; } = default!;
        public string LotType { get; set; } = default!;      // pallet | stocky

        /// <summary>Mã xe stocky. Bắt buộc khi LotType = stocky, NULL khi pallet.</summary>
        public string? StockyCode { get; set; }
        public bool? EvenLot { get; set; }

        public long? LocatorId { get; set; }
        public string? LocatorCode { get; set; }
        public string? AreaCode { get; set; }
        public string DetailLevel { get; set; } = default!;   // serial | box_line | box_count
        public int? BoxCount { get; set; }
        public int? SapStatus { get; set; }
        public DateTime? SapPushedAt { get; set; }

        /// <summary>Chỉ set khi DetailLevel = box_count (không có box_lines để suy ra model).</summary>
        public string? Model { get; set; }
        public string? SiNo { get; set; }

        /// <summary>Chỉ set khi DetailLevel = box_count — pcs/box, để tính TotalQty khỏi JOIN models.</summary>
        public int? StandardPacking { get; set; }

        // Giá trị tính sẵn từ SQL (chỉ dùng cho trang danh sách). Null nếu chưa tính.
        public int? TotalQtySql { get; set; }

        public int? TotalQty =>
            TotalQtySql
            ?? (DetailLevel == "box_count"
                ? (BoxCount ?? 0) * (StandardPacking ?? 0)
                : Boxes.Sum(b => b.Lines.Sum(l => l.Qty)));

        public string InspectionStatus { get; set; } = "not_required";
        public bool IsUrgent { get; set; }
        public DateTime? ProductionDate { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }

        public List<Box> Boxes { get; set; } = [];
    }

    public class Box
    {
        public long Id { get; set; }
        public long LotId { get; set; }
        public string BoxNo { get; set; } = default!;
        public string? PsnvPo { get; set; }
        public string? CustomerPo { get; set; }
        public string? Line { get; set; }
        public int? OQCStatus { get; set; }
        public string? LotName { get; set; }
        public DateTime? ProductionDate { get; set; }
        public decimal? Length { get; set; }
        public decimal? Width { get; set; }
        public decimal? Height { get; set; }
        public decimal? Weight { get; set; }
        public string? RawPayload { get; set; }
        public bool IsDeleted { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }

        public List<BoxLine> Lines { get; set; } = [];
    }

    public class BoxLine
    {
        public long Id { get; set; }
        public long BoxId { get; set; }
        public string Model { get; set; } = "";
        public int Qty { get; set; }
        public string? SerialNo { get; set; }
        public DateTime? ProductionDate { get; set; }

        /// <summary>Số lượng inner carton (cột box_lines.carton_qty).</summary>
        public int? CartonCount { get; set; }

        public bool IsDeleted { get; set; }
        public DateTime CreatedAt { get; set; }
        public string? CreatedBy { get; set; }
        public DateTime? UpdatedAt { get; set; }
        public string? UpdatedBy { get; set; }
    }

    public class PalletCategory
    {
        public int Code { get; set; }
        public string? Name { get; set; }
    }

    // ── Vị trí tạm (PDA): quét lot → gán / rời / chuyển vị trí ────────

    /// <summary>
    /// Lot + vị trí đang đặt (JOIN master.locators / warehouse_areas)
    /// + model gộp (từ wms.box_lines, fallback sang lots.model). Dùng cho màn Vị trí tạm.
    /// </summary>
    public class PalletLocationInfo
    {
        /// <summary>Loại bản đồ chứa vị trí hiện tại: storing | receiving | vanning (null = chưa có vị trí).</summary>
        public string? MapType { get; set; }

        public long Id { get; set; }
        public string LotNo { get; set; } = default!;
        public int CategoryCode { get; set; }
        public string? CategoryName { get; set; }
        public string LotType { get; set; } = default!;
        public string? StockyCode { get; set; }
        public string DetailLevel { get; set; } = default!;
        public int? BoxCount { get; set; }
        public string InspectionStatus { get; set; } = "not_required";
        public bool IsUrgent { get; set; }
        public DateTime? ProductionDate { get; set; }
        public int? SapStatus { get; set; }
        public DateTime? SapPushedAt { get; set; }
        public bool IsDeleted { get; set; }
        public string? SiNo { get; set; }

        /// <summary>Chỉ có khi DetailLevel = box_count (lots.model).</summary>
        public string? Model { get; set; }

        /// <summary>Chỉ có khi DetailLevel = box_count — pcs/box.</summary>
        public int? StandardPacking { get; set; }

        /// <summary>SUM(box_lines.qty) tính sẵn từ SQL. Null với lot box_count.</summary>
        public int? TotalQtySql { get; set; }

        /// <summary>Tổng số lượng: từ box_lines, fallback BoxCount * StandardPacking.</summary>
        public int? TotalQty =>
            TotalQtySql
            ?? (DetailLevel == "box_count" ? (BoxCount ?? 0) * (StandardPacking ?? 0) : null);

        // vị trí hiện tại (null nếu chưa gán)
        public long? LocatorId { get; set; }
        public string? LocatorCode { get; set; }
        public string? AreaCode { get; set; }
        public string? AreaName { get; set; }

        /// <summary>Các model trong lot, gộp bằng ", ".</summary>
        public string? Models { get; set; }

        /// <summary>
        /// Hướng xử lý hàng: rework | refurbish | null (hàng thường).
        ///
        /// Pallet tái gia công (RW/RB) có inspection_status = 'ng' nên các cổng
        /// chặn theo trạng thái kiểm sẽ loại nó ra khỏi lưu kho. Cột này là thứ
        /// duy nhất phân biệt "NG vì tái gia công, vẫn phải lưu kho được" với
        /// "NG vì OQC đánh fail". Xem BuildAllowedActions.
        /// </summary>
        public string? Disposition { get; set; }

        /// <summary>
        /// Pallet này đang giữ serial của một phiếu back hàng (sổ
        /// <c>wms.return_instruction_serials</c>) — tức là hàng RW/RB kể cả khi
        /// cột <see cref="Disposition"/> chưa được đóng dấu.
        ///
        /// Dùng để MỞ NÚT, không phải để duyệt: cổng duyệt thật là
        /// <c>IReturnBackMoveGate</c>. Xem LocationInfoSql.
        /// </summary>
        public bool IsReturnBack { get; set; }
    }

    // LocatorStatusHistory đã XOÁ cùng bảng wms.locator_status_history.
    // Lịch sử vị trí giờ là một phần của wms.stock_events:
    //   Features/StockEvents/Business/StockEventEntities.cs -> StockEventRow
    // Câu hỏi "ô kệ này từng chứa pallet nào" trả bằng
    //   WHERE to_locator_id = @id  (index IX_stock_events_to_loc).

    /// <summary>Mã khu vực (master.warehouse_areas.area_code).</summary>
    /// <summary>Loại bản đồ (master.warehouse_areas.map_type).</summary>
    public static class MapTypes
    {
        public const string Receiving = "receiving";
        public const string Storing = "storing";
        public const string Vanning = "vanning";
    }

    public static class AreaCodes
    {
        public const string Receiving = "RECEIVING";
        public const string Storage = "STORAGE";
        public const string Vanning = "VANNING";
    }

    /// <summary>Vị trí (master.locators) — kiểm tra khi gán / chuyển.</summary>
    public class LocatorBrief
    {
        public long Id { get; set; }
        public string LocatorCode { get; set; } = default!;
        public long? AreaId { get; set; }
        public string? AreaCode { get; set; }
        public string? AreaName { get; set; }
        /// <summary>Loại bản đồ chứa vị trí: storing | receiving | vanning.</summary>
        public string? MapType { get; set; }
        /// <summary>Số lot đang nằm ở vị trí này (để cảnh báo khi gán chồng).</summary>
        public int CurrentLotCount { get; set; }
    }

    /// <summary>Kết quả xoá thùng, đọc / ghi trong cùng transaction.</summary>
    public sealed record BoxDeleteResult(
        string LotNo,
        int BoxesDeleted,
        int LinesDeleted,
        int QtyDeleted,
        int BoxCountBefore,
        int BoxCountAfter);

    // ── Tách pallet ────────────────────────────────────────────────

    /// <summary>Thông tin lot phục vụ validate tách.</summary>
    public sealed class SplitLotInfo
    {
        public long Id { get; set; }
        public string LotNo { get; set; } = "";
        public int CategoryId { get; set; }
        public string? Model { get; set; }
        public string? DetailLevel { get; set; }
        public DateTime? ProductionDate { get; set; }
        public long? LocatorId { get; set; }
        public string InspectionStatus { get; set; } = "not_inspected";
        public int BoxCount { get; set; }
        public bool IsDeleted { get; set; }
    }


    /// <summary>Tham số thực thi tách trong transaction.</summary>
    public sealed class SplitExecuteParams
    {
        public long SourceLotId { get; init; }
        public IReadOnlyList<long> BoxIds { get; init; } = [];

        /// <summary>Số thùng cần chuyển. Chỉ dùng cho pallet box_count.</summary>
        public int BoxQty { get; init; }
        public long? TargetLotId { get; init; }
        public bool CreateNew { get; init; }
        public string? NewLotNo { get; init; }
        public string? NewModel { get; init; }
        public int NewCategoryId { get; init; }
        public DateTime? NewProductionDate { get; init; }
        // Kế thừa trạng thái kiểm từ lot gốc (thỏa CHECK CK_lots_inspection).
        public string InspectionStatus { get; init; } = "not_inspected";
        public string? User { get; init; }

        /// <summary>
        /// Ghi chú gắn vào 2 event PALLET_SPLIT_OUT / PALLET_SPLIT_IN của lần
        /// tách này. Null -> không ghi (mặc định). Hiện dùng để lưu việc người
        /// dùng đã xác nhận tách khác model.
        ///
        /// stock_events.note là nvarchar(500) — Service phải cắt trước khi truyền.
        /// </summary>
        public string? EventNote { get; init; }

        /// <summary>
        /// JSON gắn vào 2 event PALLET_SPLIT_OUT / PALLET_SPLIT_IN. Null -> không ghi.
        /// Phải là JSON hợp lệ: DB có CHECK CK_stock_events_payload (ISJSON).
        /// </summary>
        public string? EventPayload { get; init; }
    }
}

/// <summary>
/// Thẻ in (wms.part_cards) khớp với một thùng qua
/// boxes.raw_payload = part_cards.payload.
///
/// Ba trường này KHÔNG có trong CreateBoxRequest: client chỉ gửi chuỗi đã quét,
/// phần còn lại là dữ liệu của chính SWMS. Trước đây boxes.lot_name và
/// oqc_status luôn NULL với lot tạo qua POST /api/pallets.
/// </summary>
public sealed class PartCardInfo
{
    public string Payload { get; set; } = default!;
    public DateTime CreatedAt { get; set; }
    public string? LotName { get; set; }

    /// <summary>Cột Status_OQC — map thẳng vào boxes.oqc_status.</summary>
    public int? OqcStatus { get; set; }
}

public sealed record SplitModelCheck(
    IReadOnlyList<string> TargetModels,
    IReadOnlyList<string> BoxModels)
{
    /// <summary>
    /// Model của box KHÔNG khớp model duy nhất của pallet đích.
    /// Rỗng khi được phép gộp (đích rỗng / đích đa model / cùng model).
    /// </summary>
    public IReadOnlyList<string> ForeignModels =>
        TargetModels.Count == 1
            ? BoxModels
                .Where(m => !string.Equals(m, TargetModels[0], StringComparison.OrdinalIgnoreCase))
                .ToList()
            : [];
}
