import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Chuyển JSON → entity cho mục 2c.
//
//  VIẾT TAY `fromJson`, KHÔNG dùng json_serializable như các model khác của
//  feature này. Lý do là cân nhắc, không phải lười: thêm một model có
//  @JsonSerializable là phải chạy lại build_runner, mà build_runner trong
//  source hiện tại đang vỡ (hai file cùng khai `@RoutePage() class
//  VanningPage`). Bộ mục 2c vì vậy làm sao để KHÔNG cần sinh mã: không
//  annotation, không retrofit, không @riverpod.
//
//  Khi nào build_runner chạy lại được thì chuyển sang @JsonSerializable cũng
//  không đổi gì ở lớp trên — entity và repository giữ nguyên.
// ─────────────────────────────────────────────────────────────

/// Đọc số nguyên chịu được cả `int`, `double` và chuỗi.
///
/// System.Text.Json trả `int` đúng kiểu, nhưng một cột `decimal` phía SQL hay
/// một tầng proxy có thể biến nó thành `420.0` — ép thẳng `as int` sẽ ném
/// giữa lúc WH đang quét.
int _int(Object? v, [int fallback = 0]) => switch (v) {
      int i => i,
      double d => d.round(),
      num n => n.round(),
      String s => int.tryParse(s) ?? fallback,
      _ => fallback,
    };

bool _bool(Object? v, [bool fallback = false]) => switch (v) {
      bool b => b,
      String s => s.toLowerCase() == 'true',
      _ => fallback,
    };

String? _str(Object? v) {
  if (v == null) return null;
  final s = v.toString().trim();
  return s.isEmpty ? null : s;
}

/// Mốc thời gian. Trả null khi thiếu hoặc không parse được, chứ KHÔNG trả
/// `DateTime.now()`: một mốc bịa ra trông y như mốc thật trên màn hình.
DateTime? _date(Object? v) {
  final s = _str(v);
  return s == null ? null : DateTime.tryParse(s);
}

List<Map<String, Object?>> _rows(Object? v) => v is List
    ? v.whereType<Map>().map((e) => e.cast<String, Object?>()).toList()
    : const [];

List<String> _strings(Object? v) => v is List
    ? v.map(_str).whereType<String>().toList()
    : const [];

BackRequestLine backRequestLineFromJson(Map<String, Object?> j) =>
    BackRequestLine(
      lineNo: _int(j['lineNo']),
      model: _str(j['model']) ?? '',
      qty: _int(j['qty']),
      // API gọi cột này là assignedQty (số serial đã gắp cho đề nghị).
      deliveredQty: _int(j['assignedQty']),
    );

BackRequest backRequestFromJson(Map<String, Object?> j) => BackRequest(
      id: _int(j['id']),
      docId: _int(j['docId']),
      reqNo: _str(j['reqNo']) ?? '',
      docNo: _str(j['docNo']),
      goodsType: _str(j['goodsType']),
      status: BackStatus.from(_str(j['reqStatus'])),
      step: BackStep.from(_str(j['currentStep'])),
      note: _str(j['note']),
      modelCount: _int(j['modelCount']),
      totalQty: _int(j['totalQty']),
      deliveredQty: _int(j['assignedQty']),
      remainQty: _int(j['remainQty']),
      requestedBy: _str(j['requestedBy']),
      requestedAt: _date(j['requestedAt']),
      faApprovedBy: _str(j['faApprovedBy']),
      faApprovedAt: _date(j['faApprovedAt']),
      lines: _rows(j['lines']).map(backRequestLineFromJson).toList(),
    );

BackDelivery backDeliveryFromJson(Map<String, Object?> j) => BackDelivery(
      lotNo: _str(j['lotNo']) ?? '',
      serialCount: _int(j['serialCount']),
      deliveredAt: _date(j['deliveredAt']) ?? DateTime.now(),
      deliveredBy: _str(j['deliveredBy']),
    );

BackDeliverResult backDeliverResultFromJson(Map<String, Object?> j) =>
    BackDeliverResult(
      deliveredQty: _int(j['deliveredQty']),
      remainQty: _int(j['remainQty']),
      completed: _bool(j['completed']),
      pallets: _rows(j['pallets']).map(backDeliveryFromJson).toList(),
      notFoundLots: _strings(j['notFoundLots']),
      emptyLots: _strings(j['emptyLots']),
      request: j['request'] is Map
          ? backRequestFromJson((j['request'] as Map).cast<String, Object?>())
          : null,
    );
