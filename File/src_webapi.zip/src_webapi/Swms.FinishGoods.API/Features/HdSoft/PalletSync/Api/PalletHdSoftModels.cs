using System.ComponentModel.DataAnnotations;
using Swms.FinishGoods.API.Features.Pallets.Api;

namespace Swms.FinishGoods.API.Features.HdSoft.PalletSync.Api
{
    /// <summary>Các thao tác đã thực hiện khi đồng bộ 1 pallet với HD soft.</summary>
    public static class HdSoftSyncActions
    {
        public const string LocatorAssigned = "locator_assigned";
        public const string LocatorReleased = "locator_released";
        public const string SiNoAssigned = "si_no_assigned";
    }

    /// <summary>
    /// Kết quả đồng bộ 1 pallet. Actions = việc đã làm, Warnings = bước bị bỏ qua
    /// kèm lý do (không chặn cả luồng).
    /// </summary>
    public record HdSoftSyncResponse(
        PalletDetailResponse Pallet,
        string? LastMovementType,
        string? LastMovementLocator,
        IReadOnlyList<string> Actions,
        IReadOnlyList<string> Warnings);

    public record HdSoftSyncBatchRequest(
        [Required, MinLength(1), MaxLength(200)] List<string> LotNos);

    /// <summary>Kết quả đồng bộ vị trí 1 pallet trong batch.</summary>
    public record HdSoftSyncBatchItem(
        string LotNo,
        string? LastMovementType,
        string? LastMovementLocator,
        string? LocatorCode,
        IReadOnlyList<string> Actions,
        IReadOnlyList<string> Warnings);
}
