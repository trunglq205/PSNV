import 'package:smart_warehouse/shared/utils/copyable.dart';

class BoxQCReturn implements Copyable<BoxQCReturn> {
  BoxQCReturn({
    this.barcode,
    this.currentQuantity = 0,
  });

  final double currentQuantity;
  final String? barcode;

  @override
  BoxQCReturn copyWith({String? addedBarcode, double qtyBox = 0}) {
    return BoxQCReturn(
      barcode: addedBarcode,
      currentQuantity: qtyBox,
    );
  }
}
