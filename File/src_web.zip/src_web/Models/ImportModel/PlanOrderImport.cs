﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class PlanOrderImport
    {
        public string? PlanOrderNumber {  get; set; }
        public string? Plant {  get; set; }
        public string? Material {  get; set; }
        public string? Sloc {  get; set; }
        public string? ProductionVersion {  get; set; }
        public double PlanOrderQuantity {  get; set; }
        public double GRQuantity {  get; set; }
        public string? PostingDate {  get; set; }
        public string? Check {  get; set; }
        public bool IsWD {  get; set; }
    }
}
