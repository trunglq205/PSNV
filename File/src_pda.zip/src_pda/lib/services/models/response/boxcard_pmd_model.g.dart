// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'boxcard_pmd_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BoxcardPMDModel _$BoxcardPMDModelFromJson(Map<String, dynamic> json) =>
    BoxcardPMDModel(
      id: (json['id'] as num).toInt(),
      quantity: (json['quantity'] as num).toDouble(),
    );

Map<String, dynamic> _$BoxcardPMDModelToJson(BoxcardPMDModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'quantity': instance.quantity,
    };
