﻿namespace SWMS_WebTool.Models.Requests
{
    public class DeleteKittingRequest
    {
        public List<string> SelectedItems { get; set; }
        public string Tab { get; set; }
    }
}
