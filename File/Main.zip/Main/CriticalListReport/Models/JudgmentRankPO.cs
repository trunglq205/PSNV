﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("tblVendorConfirmRank")]
    public class JudgmentRankPO
    {
        [Key]
        public int Id { get; set; }
        public string? PlantName { get; set; }
        public string? Vendor { get; set; }
        public string? VendorName { get; set; }
        public string? Material { get; set; }
        public string? ShortText { get; set; }
        public string? PO { get; set; }
        public string? Item { get; set; }
        public string? PONoItem { get; set; }
        public string? DelivDate { get; set; }
        public string? MRP { get; set; }
        public DateTime? NECDate { get; set; }
        public string? QtyOrder { get; set; }
        public string? QtyInbound { get; set; }
        public decimal? QtyPending { get; set; }
        public string? LT { get; set; }
        public string? VendorLastCF { get; set; }
        public string? ETAPSNV_VendorLastCF { get; set; }
        public string? ShippingMode { get; set; }
        public string? ETAPSNV_AfterJudgement { get; set; }
        public string? ShippingMode_AfterJudgement { get; set; }
        public string? GWPer1Pcs { get; set; }
        public string? TotalGW { get; set; }
        public string? HeaderText { get; set; }
        public string? ShortLT { get; set; }
        public string? PurGrp { get; set; }
        public string? MRPCtr { get; set; }
        public string? PIC { get; set; }
        public string? Plant { get; set; }
        public string? MaterialType { get; set; }
        public string? JudgmentRank { get; set; }
        public string? FreightUnit { get; set; }
        public decimal? GWAir { get; set; }
        public byte? DataSource { get; set; }  // 0 = SAP, 1 = TCode
        public DateTime CreatedAt { get; set; }
        public string? RoundingVal { get; set; }
        public string? UnitPacking { get; set; }
        public string? CreatedOn { get; set; }
    }
}