namespace Swms.FinishGoods.API.Features.Balance.Api;

public record BalanceDocSummaryResponse(
    long Id, string DocNo, long CountId, string CountDocNo, string? CountType, DateTime CountDate,
    string DocStatus, string? FaRef,
    int TotalLines, int ResolvedLines, decimal NetDelta,
    DateTime CreatedAt, DateTime? IssuedAt)
{
    public static BalanceDocSummaryResponse From(BalanceDocSummary d) => new(
        d.Id, d.DocNo, d.CountId, d.CountDocNo, d.CountType, d.CountDate,
        d.DocStatus, d.FaRef, d.TotalLines, d.ResolvedLines, d.NetDelta, d.CreatedAt, d.IssuedAt);
}

public record BalanceLineResponse(
    long LineId, int LineNo, int ProductId, string? ProductName, long LocatorId, string LocatorCode,
    long? LotId, string? PalletId, string? Model,
    decimal QtySystem, decimal QtyCount, decimal Delta, string? Resolution, string? Note,
    bool IsFound, string? SystemLocatorCode)
{
    public static BalanceLineResponse From(BalanceLine l) => new(
        l.LineId, l.LineNo, l.ProductId, l.ProductName, l.LocatorId, l.LocatorCode,
        l.LotId, l.PalletId, l.Model, l.QtySystem, l.QtyCount, l.Delta, l.Resolution, l.Note,
        l.IsFound, l.SystemLocatorCode);
}

public record BalanceDocDetailResponse(BalanceDocSummaryResponse Header, IReadOnlyList<BalanceLineResponse> Lines);

/// <summary>Chọn hướng xử lý: 'count' (tin PDA) hoặc 'system' (giữ hệ thống).</summary>
public record SetResolutionRequest(string Resolution);

/// <summary>Chọn hướng cho nhiều dòng cùng lúc.</summary>
public record BulkResolutionRequest(IReadOnlyList<long> LineIds, string Resolution);

public record IssueFaResultResponse(string FaRef, int AdjustedPallets, string MoveDocNo)
{
    public static IssueFaResultResponse From(IssueFaResult r) => new(r.FaRef, r.AdjustedPallets, r.MoveDocNo);
}
