using Swms.FinishGoods.API.Features.EuLabel.Api;
using Swms.FinishGoods.API.Features.EuLabel.DataAccess;
using System.Security.Cryptography;
using System.Text;

namespace Swms.FinishGoods.API.Features.EuLabel.Business;

public interface IEuLabelService
{
    Task<EuLabelLoginResponse> LoginAsync(string userName, string password);
    Task<EuLabelLoginResponse> LoginByCardAsync(string cardCode);
    Task<HandoverConfirmResponse> ConfirmFromPdaAsync(string key, int confirmedBy);
    Task<HandoverJobSummaryResponse?> JobSummaryAsync(int printJobId);
    Task<JobByTagResponse> FindJobByTagAsync(string key);
}

public class EuLabelService : IEuLabelService
{
    private readonly IEuLabelRepository _repo;
    public EuLabelService(IEuLabelRepository repo) => _repo = repo;

    public async Task<EuLabelLoginResponse> LoginAsync(string userName, string password)
    {
        if (string.IsNullOrWhiteSpace(userName) || string.IsNullOrEmpty(password))
            return new EuLabelLoginResponse(false, 0, "", "", "");

        // Hash SHA-256 hex-lowercase, UTF-8 — KHỚP y hệt cách desktop hash.
        string hash = Sha256Hex(password);
        var result = await _repo.LoginAsync(userName.Trim(), hash);
        return result ?? new EuLabelLoginResponse(false, 0, "", "", "");
    }

    private static string Sha256Hex(string text)
    {
        using var sha = SHA256.Create();
        byte[] bytes = sha.ComputeHash(Encoding.UTF8.GetBytes(text));
        var sb = new StringBuilder();
        foreach (var b in bytes) sb.Append(b.ToString("x2"));
        return sb.ToString();
    }

    public Task<HandoverConfirmResponse> ConfirmFromPdaAsync(string key, int confirmedBy)
    {
        if (string.IsNullOrWhiteSpace(key))
            return Task.FromResult(new HandoverConfirmResponse(0, "Mã rỗng"));

        // Nguồn cố định 'PDA' cho các xác nhận đến từ máy quét cầm tay.
        return _repo.ConfirmAsync(key.Trim(), confirmedBy, "PDA");
    }

    public Task<HandoverJobSummaryResponse?> JobSummaryAsync(int printJobId)
        => _repo.JobSummaryAsync(printJobId);

    public async Task<EuLabelLoginResponse> LoginByCardAsync(string cardCode)
    {
        if (string.IsNullOrWhiteSpace(cardCode))
            return new EuLabelLoginResponse(false, 0, "", "", "");
        var r = await _repo.LoginByCardAsync(cardCode.Trim());
        return r ?? new EuLabelLoginResponse(false, 0, "", "", "");
    }

    public async Task<JobByTagResponse> FindJobByTagAsync(string key)
    {
        if (string.IsNullOrWhiteSpace(key))
            return new JobByTagResponse(false, 0, "", null, new List<HandoverSerialRow>());

        var job = await _repo.FindJobByTagAsync(key.Trim());
        if (job is null)
            return new JobByTagResponse(false, 0, "", null, new List<HandoverSerialRow>());

        var summary = await _repo.JobSummaryAsync(job.Value.printJobId);
        var serials = await _repo.JobDetailAsync(job.Value.printJobId);
        return new JobByTagResponse(
            true, job.Value.printJobId, job.Value.siList, summary, serials);
    }
}