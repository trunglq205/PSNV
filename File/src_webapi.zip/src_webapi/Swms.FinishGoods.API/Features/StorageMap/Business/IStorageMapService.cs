using Swms.FinishGoods.API.Features.StorageMap.Api;

namespace Swms.FinishGoods.API.Features.StorageMap.Business;

public interface IStorageMapService
{
    Task<IReadOnlyList<RackSummaryResponse>> GetRacksAsync(string? areaCode = null);
    Task<RackElevationResponse> GetElevationAsync(string rackCode, string? areaCode = null);
    Task<TopMapResponse> GetTopMapAsync(string? areaCode = null);
    Task<LocatorLocationResponse> LocateAsync(string locatorCode);
    Task<IReadOnlyList<PalletSerialResponse>> GetSerialsAsync(string palletCode);
    Task SaveTopMapAsync(SaveTopMapRequest request, string? user);
    Task CreateRackAsync(CreateRackRequest request, string? user);
    Task DeleteRackAsync(string rackCode, string? user);
    Task SetCellKindAsync(SetCellKindRequest request, string? user);
}
