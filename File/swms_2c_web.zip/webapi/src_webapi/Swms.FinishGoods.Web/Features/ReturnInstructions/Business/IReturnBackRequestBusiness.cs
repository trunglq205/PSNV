using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business;

public interface IReturnBackRequestBusiness
{
    /// <summary>Danh sách. Mọi tham số null = không lọc.</summary>
    Task<Result<List<ReturnBackRequestDto>>> GetListAsync(
        long? docId = null, string? status = null, string? step = null, string? keyword = null);

    Task<Result<ReturnBackRequestDto>> GetByIdAsync(long id);

    /// <summary>SL kho còn gắp được theo model của một chỉ thị.</summary>
    Task<Result<List<BackAvailableModelDto>>> GetAvailableAsync(long docId);

    Task<Result<ReturnBackRequestDto>> CreateAsync(CreateBackRequestRequestDto request);

    Task<Result<ReturnBackRequestDto>> UpdateAsync(long id, UpdateBackRequestRequestDto request);

    /// <summary>B2 — quản lý FA duyệt.</summary>
    Task<Result<ReturnBackRequestDto>> ApproveFaAsync(long id, string? comment);

    /// <summary>B3 — SCS WH xác nhận và tạo chỉ thị back.</summary>
    Task<Result<ReturnBackRequestDto>> InstructAsync(long id, string? comment);

    /// <summary>B4 — quản lý SCS duyệt cho back; bước này gắp serial.</summary>
    Task<Result<ReturnBackRequestDto>> ApproveScsAsync(long id, string? comment);

    Task<Result<ReturnBackRequestDto>> CancelAsync(long id, string? reason);
}
