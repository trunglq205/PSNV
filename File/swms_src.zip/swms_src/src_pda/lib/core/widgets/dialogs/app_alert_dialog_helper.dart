import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_alert_dialog.dart';

/// Hàm tiện gọi dialog. Trả Future để await kết quả.
/// confirm() trả bool (true nếu user đồng ý).
abstract final class AppDialogHelper {
  const AppDialogHelper._();

  /// Dialog xác nhận có 2 nút. Trả true nếu người dùng đồng ý.
  static Future<bool> confirm(
    BuildContext context, {
    required String title,
    String? message,
    String confirmText = 'Confirm',
    String cancelText = 'Cancel',
  }) async {
    final result = await showDialog<bool>(
      context: context,
      builder: (_) => AppAlertDialog(
        type: AppAlertDialogType.confirm,
        title: title,
        message: message,
        confirmText: confirmText,
        cancelText: cancelText,
      ),
    );
    return result ?? false;
  }

  static Future<void> success(
    BuildContext context, {
    required String title,
    String? message,
    String confirmText = 'OK',
  }) {
    return showDialog<void>(
      context: context,
      builder: (_) => AppAlertDialog(
        type: AppAlertDialogType.success,
        title: title,
        message: message,
        confirmText: confirmText,
      ),
    );
  }

  static Future<void> error(
    BuildContext context, {
    required String title,
    String? message,
    String confirmText = 'OK',
  }) {
    return showDialog<void>(
      context: context,
      builder: (_) => AppAlertDialog(
        type: AppAlertDialogType.error,
        title: title,
        message: message,
        confirmText: confirmText,
      ),
    );
  }

  static Future<void> info(
    BuildContext context, {
    required String title,
    String? message,
    String confirmText = 'OK',
  }) {
    return showDialog<void>(
      context: context,
      builder: (_) => AppAlertDialog(
        type: AppAlertDialogType.info,
        title: title,
        message: message,
        confirmText: confirmText,
      ),
    );
  }
}
