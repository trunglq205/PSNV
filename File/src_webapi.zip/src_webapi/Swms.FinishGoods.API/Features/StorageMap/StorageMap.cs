namespace Swms.FinishGoods.API.Features.StorageMap;

/// <summary>Tóm tắt 1 kệ trong khu Storing (đếm slot + chiếm chỗ).</summary>
public class RackSummary
{
    public long Id { get; set; }
    public string RackCode { get; set; } = string.Empty;
    public string RackName { get; set; } = string.Empty;
    public int TotalSlots { get; set; }
    public int OccupiedSlots { get; set; }
    public int PalletSlots { get; set; }
    public int ShelfSlots { get; set; }
    public int SortOrder { get; set; }
    public int Cols { get; set; }   // số vị trí (bao) — bề rộng lưới elevation
    public int Rows { get; set; }   // số tầng (bao)  — chiều cao lưới elevation
}

/// <summary>
/// Một ô trên mặt đứng (elevation) kệ = 1 dòng master.locators.
/// Vị trí lưới: Location = rack_col (ngang), Floor = rack_row (dọc).
/// </summary>
/// <summary>Một pallet đang nằm trong ô (một ô có thể chứa nhiều pallet).</summary>
public class ElevationPallet
{
    public long LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public int? BoxCount { get; set; }
    public DateTime? ProductionDate { get; set; }
    public string? Disposition { get; set; }
    public bool StopShipment { get; set; }
    /// <summary>Trạng thái kiểm của pallet (giống bản đồ Receiving): not_inspected | under_inspection |
    /// pending_result | inspection_exempt | pass | ng.</summary>
    public string? Status { get; set; }
    public bool IsUrgent { get; set; }
}

public class ElevationLocator
{
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = string.Empty;
    public int Location { get; set; }                 // rack_col
    public int Floor { get; set; }                    // rack_row
    public string SlotKind { get; set; } = "pallet";  // pallet | shelf (giá lửng)
    public string? Level { get; set; }                // NULL=pallet; 'A'(dưới)/'B'(trên)=giá lửng
    public bool Occupied { get; set; }
    public string? PalletId { get; set; }             // mã pallet đang chứa (nếu có)
    public string? Model { get; set; }                // tên model
    public int? BoxCount { get; set; }                // số lượng (thùng)
    public DateTime? ProductionDate { get; set; }     // ngày SX
    public string? Disposition { get; set; }          // refurbish | rework | NULL
    public bool StopShipment { get; set; }            // hàng khoá giao (độc lập)
    /// <summary>Trạng thái kiểm của pallet (giống bản đồ Receiving): not_inspected | under_inspection |
    /// pending_result | inspection_exempt | pass | ng.</summary>
    public string? Status { get; set; }
    public bool IsUrgent { get; set; }


    /// <summary>Toàn bộ pallet trong ô (mới nhất trước). Các trường phía trên là của pallet mới nhất.</summary>
    public List<ElevationPallet> Pallets { get; set; } = new();
}

/// <summary>Tồn theo từng vị trí (bao) của 1 kệ — để chia ô trên top-down.</summary>
public class PositionOcc
{
    public long RackId { get; set; }
    public int Position { get; set; }   // rack_col
    public int Total { get; set; }
    public int Occupied { get; set; }
}

/// <summary>Một khối trên sơ đồ top-down: kệ (rack) hoặc khu chức năng (decor).</summary>
public class TopMapBlock
{
    // --- khối pallet (ô vị trí đơn) ---
    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string? Status { get; set; }
    public bool IsUrgent { get; set; }
    public string? Model { get; set; }
    public string? PalletId { get; set; }
    public int? BoxCount { get; set; }
    public DateTime? ProductionDate { get; set; }

    public long Id { get; set; }
    public string Kind { get; set; } = "rack";   // rack | decor
    public long? RackId { get; set; }
    public string? RackCode { get; set; }
    public string? Label { get; set; }
    public string? Color { get; set; }
    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; }
    public int GridH { get; set; }
    public int TotalSlots { get; set; }
    public int OccupiedSlots { get; set; }
    public List<PositionOcc> Positions { get; set; } = new();
}

/// <summary>Sơ đồ top-down của khu Storing (kích thước lưới + các khối).</summary>
public class TopMap
{
    public string AreaCode { get; set; } = string.Empty;
    public int Cols { get; set; }
    public int Rows { get; set; }
    public double CellMeters { get; set; }
    public List<TopMapBlock> Blocks { get; set; } = new();
}

/// <summary>Khối gửi lên khi Lưu sơ đồ (editor). Id=null nghĩa là khối mới.</summary>
public class SaveTopMapBlock
{
    public long? Id { get; set; }
    public string Kind { get; set; } = "rack";   // rack | decor
    public long? RackId { get; set; }
    public string? Label { get; set; }
    public string? Color { get; set; }
    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; }
    public int GridH { get; set; }
}

/// <summary>Một vị trí nằm ở đâu trên bản đồ: khu nào, thuộc kệ nào (nếu có), vị trí/tầng mấy.</summary>
public class LocatorLocation
{
    public string LocatorCode { get; set; } = string.Empty;
    public string? AreaCode { get; set; }
    public string? AreaName { get; set; }
    public string? MapType { get; set; }
    public string? RackCode { get; set; }
    public int? RackCol { get; set; }
    public int? RackRow { get; set; }
    public string? RackLevel { get; set; }
}

/// <summary>Một dòng serial trong pallet (wms.boxes + wms.box_lines).</summary>
public class PalletSerial
{
    public string? BoxNo { get; set; }
    public string? Model { get; set; }
    public string? SerialNo { get; set; }
    public int? Qty { get; set; }
}
