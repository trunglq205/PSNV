namespace Swms.FinishGoods.API.Features.Balance;

/// <summary>Tóm tắt 1 phiếu cân bằng (cho danh sách trái).</summary>
public class BalanceDocSummary
{
    public long Id { get; set; }
    public string DocNo { get; set; } = string.Empty;
    public long CountId { get; set; }
    public string CountDocNo { get; set; } = string.Empty;
    public string? CountType { get; set; }
    public DateTime CountDate { get; set; }
    public string DocStatus { get; set; } = "pending"; // pending | processing | issued
    public string? FaRef { get; set; }
    public int TotalLines { get; set; }        // tổng dòng lệch của KK nguồn
    public int ResolvedLines { get; set; }     // đã chọn hướng
    public decimal NetDelta { get; set; }      // tổng Δ ròng
    public DateTime CreatedAt { get; set; }
    public DateTime? IssuedAt { get; set; }
}

/// <summary>1 dòng lệch trong phiếu cân bằng (join từ count_lines).</summary>
public class BalanceLine
{
    public long LineId { get; set; }
    public int LineNo { get; set; }
    public int ProductId { get; set; }
    public string? ProductName { get; set; }
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = string.Empty;
    public long? LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public decimal QtySystem { get; set; }
    public decimal QtyCount { get; set; }
    public decimal Delta => QtyCount - QtySystem;
    public string? Resolution { get; set; }    // count | system | null
    public string? Note { get; set; }

    /// <summary>Pallet phát sinh khi kiểm (tìm thấy ở ô này, hệ thống ghi ở <see cref="SystemLocatorCode"/>).</summary>
    public bool IsFound { get; set; }
    public string? SystemLocatorCode { get; set; }
}

public class BalanceDocDetail
{
    public BalanceDocSummary Header { get; set; } = new();
    public IReadOnlyList<BalanceLine> Lines { get; set; } = new List<BalanceLine>();
}

public class IssueFaResult
{
    public string FaRef { get; set; } = string.Empty;
    public int AdjustedPallets { get; set; }
    public string MoveDocNo { get; set; } = string.Empty;
}
