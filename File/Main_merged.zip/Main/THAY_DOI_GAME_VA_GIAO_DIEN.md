# Thay đổi: game Flappy Santa + giao diện mới (Bootstrap) + sửa lỗi Update Inbound

## 1. Game Giáng sinh "Flappy Santa" (lấy từ bản FlappySanta)
- `Helpers/XmasFlappySim.cs`, `wwwroot/js/xmas-flappy-sim.js`: bộ mô phỏng dùng chung — server tự chơi lại để tính điểm (chống gian lận).
- `Controllers/GameScoreController.cs`, `Models/GameScore.cs`, `Helpers/SeasonTheme.cs`: bản Flappy Santa (Start / Begin / Submit / Leaderboard).
- `Views/Shared/_XmasGate.cshtml`, `wwwroot/js/christmas-gate.js`, `christmas.js`, `css/christmas.css`, `wwwroot/images/*.jpg`.
- `Sql/ChristmasLeaderboard.sql`: truy vấn BXH để trao giải. Bảng `tblGameScore` không đổi cấu trúc.
- ĐÃ BỎ game ném ma Halloween cùng theme Halloween: `_HalloweenGate.cshtml`, `_LoginHalloween.cshtml`,
  `halloween-gate.js`, `halloween.js`, `halloween.css`.

Luồng giữ nguyên: Login → AccountController đặt `TempData["ThemeGate"]` → chuyển về Home → _Layout hiện màn Flappy Santa phủ lên Home
→ chơi xong / bỏ qua thì vào Home.

Cấu hình trong `appsettings.json`:
- `"Theme"`: `auto` (mặc định, Giáng sinh từ 27/11 tới hết 31/12) | `christmas` (luôn Giáng sinh) | `none` (luôn giao diện hồng thường)
- `"GameSeason:christmas"`: thời gian tính BXH, ngày giữ giao diện Giáng sinh, khoảng giải thưởng Top 1 / Top 2 (`Prize1`, `Prize2`).

Thể lệ (hiện ở băng chúc mừng, bảng xếp hạng, hộp thể lệ, màn chơi):
- Thời gian tính điểm: từ 27/11 đến hết 12h trưa 25/12 (server chỉ tính lượt chơi trong khoảng này).
- Giải thưởng dành cho Top 1 và Top 2: lần lượt đấu trực tiếp 1vs1 với Admin chiều 25/12;
  thắng Admin mới được quay ngẫu nhiên (bước 50k): Top 1 = 50k → 300k, Top 2 = 50k → 200k. Thua thì không có giải.
- Xem thử nhanh: thêm `?theme=christmas&themegate=1` vào URL.

## 2. Giao diện (Bootstrap 5, tông hồng chủ đạo)
- `wwwroot/css/site.css`: bộ giao diện chung (navbar, card, form, nút, bảng, phân trang, loading, dialog) — tông hồng #F48FB1 → #EC407A.
- `Views/Shared/_Layout.cshtml`: navbar Bootstrap mới, thu gọn được trên màn nhỏ, tự đánh dấu trang đang mở.
- Làm lại toàn bộ trang bằng Bootstrap, icon chuyển sang Bootstrap Icons (trước dùng class Font Awesome nhưng không nạp thư viện).
- Toàn bộ `id`, `name`, form action và script của từng trang giữ nguyên.
- Trong mùa Giáng sinh: Layout + màn Login dùng theme Giáng sinh (christmas.css đã chỉnh cho khớp layout mới).

## 3. Sửa lỗi
- `Controllers/UploadTCodeController.cs` (Update Inbound — insert `ZMV029_STG`): thiếu dấu phẩy sau `InboundQty` và thiếu dấu `'` đóng
  sau `Vendor` → câu SQL sinh ra sai cú pháp. Đã sửa thành `..., {InboundQty}, N'{Vendor}')`.
