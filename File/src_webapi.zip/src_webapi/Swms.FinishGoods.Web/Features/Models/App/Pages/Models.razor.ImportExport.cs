using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Swms.FinishGoods.Web.Features.Models.App.Csvlo;
using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Shared.App.CsvIo;
using Swms.FinishGoods.Web.Shared.Business.Models;

namespace Swms.FinishGoods.Web.Features.Models.App.Pages;

// Phan import/export cua man Models — chi "noi day": dung schema + ha tang chung.
// Yeu cau Models.razor.cs khai bao: public partial class Models : ListPageBase<AppModel, ModelQuery>
public partial class Models
{
    [Inject] private IJSRuntime JS { get; set; } = default!;

    private bool _importOpen;
    private bool _exporting;

    private void OpenImport() => _importOpen = true;
    private void CloseImport() => _importOpen = false;

    // -- Tai mau --
    private async Task DownloadTemplate()
        => await SaveBytes(ModelCsvSchema.BuildSchema(L).TemplateFileName(),
                           ModelCsvSchema.BuildSchema(L).Template());

    // -- Export TOAN BO theo bo loc hien tai (paginate qua API) --
    private async Task ExportAll()
    {
        if (_exporting) return;
        _exporting = true;
        Toast.Success(L["Models.Export.Preparing"]);
        try
        {
            var run = await ListExporter.FetchAllAsync<AppModel>(
                fetchPageAsync: async (page, size, ct) =>
                {
                    var q = BuildQuery();
                    q.Page = page;
                    q.Size = size;
                    var r = await ModelBusiness.GetPagedAsync(q);
                    if (!r.IsSuccess || r.Value is null) return null;
                    return new ExportPage<AppModel>(r.Value.Items.Select(ModelDto.ToViewModel).ToList(), r.Value.TotalCount);
                },
                options: new ExportOptions { PageSize = 100, MaxRows = 50_000 },
                ct: default);

            if (!run.IsSuccess)
            {
                Toast.Error(run.ErrorMessage ?? L["Models.Export.Failed"]);
                return;
            }

            var bytes = ModelCsvSchema.BuildSchema(L).Export(run.Items);
            await SaveBytes(ModelCsvSchema.BuildSchema(L).ExportFileName(), bytes);

            var msg = L["Models.Export.Done", run.Items.Count].Value;
            if (run.Truncated) msg += L["Models.Export.Truncated"].Value;
            Toast.Success(msg);
        }
        finally
        {
            _exporting = false;
        }
    }

    // -- Nhan ket qua parse tu dialog --
    // Cac dong sai dinh dang / trung ma trong file DA bi CsvImportDialog loai bo; o day
    // chi con dong hop le. Quy tac xu ly tiep:
    //   (1) category_code co dien nhung khong ton tai -> bo qua dong do, KHONG chan ca file.
    //   (2) ma da ton tai trong DB -> UPDATE (upsert), va CHI cap nhat cac o co dien trong file;
    //       o de trong giu nguyen gia tri hien co. Vi vay file chi can cot "code" + cac cot muon sua.
    //   (3) suggest_area khong ton tai -> GIU dong, coi nhu o goi y khu vuc khong dien.
    //   (4) ma CHUA co ma thieu cot bat buoc de tao (category_code, length, width, height,
    //       standard_packing), hoac ma da co ma khong dien o nao -> API bo qua va tra ve danh sach ma.
    private async Task OnImportConfirmed(IReadOnlyList<AppModel> models)
    {
        // (1) Loc bo dong co category_code khong nam trong option list -> skip, gom lai de bao cao.
        //     Dong khong dien category thi khong kiem tra (giu danh muc hien co).
        var toImport = new List<AppModel>();
        var skippedCategoryCodes = new List<string>();

        foreach (var m in models)
        {
            if (!m.IsCsvFilled("category_code") || _categoryOptions.Any(c => c.Code == m.CategoryCode))
                toImport.Add(m);
            else
                skippedCategoryCodes.Add(m.Code);
        }

        // (3) Resolve ma khu vuc goi y -> Id. Ma khong khop thi coi nhu khong dien + dem de bao cao.
        var unknownAreaCodes = new List<string>();
        foreach (var m in toImport)
        {
            if (string.IsNullOrWhiteSpace(m.SuggestAreaCode))
            {
                m.SuggestAreaId = null;
                continue;
            }

            var area = _areaOptions.FirstOrDefault(a =>
                string.Equals(a.AreaCode, m.SuggestAreaCode, StringComparison.OrdinalIgnoreCase));

            if (area is null)
            {
                unknownAreaCodes.Add(m.Code);
                m.SuggestAreaId = null;
                m.SuggestAreaCode = "";
            }
            else
            {
                m.SuggestAreaId = area.Id;
            }
        }

        if (toImport.Count == 0)
        {
            Toast.Error(L["Models.Import.AllSkipped"], 5000);
            return;
        }

        // (2) Upsert. Field null = "o khong dien": cac truong kieu int/bool cua AppModel khong the null
        //     nen phai dua vao CsvFilled de biet o do co gia tri that hay chi la mac dinh.
        var result = await ModelBusiness.BulkUpsertAsync(toImport.Select(m => new UpsertModelRequest
        {
            Code = m.Code.Trim(),
            GTIN = string.IsNullOrWhiteSpace(m.GTIN) ? null : m.GTIN.Trim(),
            Origin = OriginRule.Normalize(m.Origin),
            CategoryId = m.IsCsvFilled("category_code") ? m.CategoryCode : (int?)null,
            Length = m.IsCsvFilled("length") ? m.Length : (int?)null,
            Width = m.IsCsvFilled("width") ? m.Width : (int?)null,
            Height = m.IsCsvFilled("height") ? m.Height : (int?)null,
            StandardPacking = m.IsCsvFilled("standard_packing") ? m.StandardPacking : (int?)null,
            LayerLimit = m.LayerLimit,
            LayerCount = m.LayerCount,
            StackingLength = m.StackingLength,
            StackingWidth = m.StackingWidth,
            SuggestAreaId = m.SuggestAreaId,
            SuggestRackRow = m.SuggestRackRow.Count == 0 ? null : m.SuggestRackRow,
            IsActive = m.IsCsvFilled("active") ? m.IsActive : (bool?)null,
        }).ToList());

        if (!result.IsSuccess || result.Value is null)
        {
            Toast.Error(result.ErrorMessage ?? L["Models.Import.Failed"], 5000);
            return;
        }

        CloseImport();

        // Tong ket: da tao / da cap nhat / bo qua.
        var summary = result.Value;
        var msg = L["Models.Import.UpsertDone", summary.Created, summary.Updated].Value;
        if (skippedCategoryCodes.Count > 0)
            msg += L["Models.Import.SkippedCategory", skippedCategoryCodes.Count].Value;
        if (unknownAreaCodes.Count > 0)
            msg += L["Models.Import.SkippedArea", unknownAreaCodes.Count].Value;
        if (summary.Skipped > 0)
            msg += L["Models.Import.SkippedRows", summary.Skipped, SampleCodes(summary.SkippedCodes)].Value;

        Toast.Success(msg);
        await ReloadAsync();
    }

    // "A, B, C, D, E…" — vai ma dau tien cua cac dong bi bo qua, du de nguoi dung tra lai file.
    private static string SampleCodes(IReadOnlyList<string>? codes, int take = 5)
    {
        if (codes is null || codes.Count == 0) return "";
        var text = string.Join(", ", codes.Take(take));
        return codes.Count > take ? text + "…" : text;
    }

    // -- Download qua JS interop --
    private async Task SaveBytes(string fileName, byte[] bytes)
    {
        var b64 = Convert.ToBase64String(bytes);
        await JS.InvokeVoidAsync("swmsSaveFile", fileName, "text/csv", b64);
    }
}