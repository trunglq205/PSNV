using Swms.FinishGoods.API.Features.ShipmentTrips.Api;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

public interface ITripPhotoService
{
    /// <summary>Bộ ảnh bắt buộc của chuyến (theo loại xe) + ảnh đã có.</summary>
    Task<TripPhotoListResponse> GetAsync(long tripId);

    /// <summary>PDA gửi 1 ảnh vào 1 ô; ô đã có ảnh thì thay.</summary>
    Task<TripPhotoResponse> UploadAsync(long tripId, TripPhotoUploadRequest request);

    Task<(Stream Content, string ContentType, string FileName)> GetFileAsync(long photoId, string size);

    Task DeleteAsync(long photoId);
}
