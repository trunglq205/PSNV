﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;
using System.Text;


namespace SWMS_WebTool.Controllers
{
    public class BlockController : BaseController
    {
        private readonly ApiService _apiService;
        public BlockController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] BlockFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new BlockFilter();
                var response = await _apiService.SearchBlock(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<BlockEntity>();

                var model = new BlockViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]
        public IActionResult GenQRCode(string request)
        {
            var lstQRCodeViewModels = new ListQRCodeBlockViewModel();
            var qrCodeViewModel = new List<QRCodeBlockViewModel>();

            var nameLocations = request.Split(',');

            foreach (var item in nameLocations)
            {
                var qrCode = StringExtensions.GenerateQR(item);
                qrCodeViewModel.Add(new QRCodeBlockViewModel()
                {
                    Name = item,
                    QRCode = qrCode
                });
            }
            lstQRCodeViewModels.QRCodeBlockViewModels = qrCodeViewModel;

            return PartialView("~/Views/BlockEntity/_QRCodeBlock.cshtml", lstQRCodeViewModels);
        }
    }
}