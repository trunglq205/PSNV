using System.Text.RegularExpressions;
using Swms.FinishGoods.API.Features.Scan.Api;
using Swms.FinishGoods.API.Features.Scan.DataAccess;

namespace Swms.FinishGoods.API.Features.Scan.Business
{
    public interface IScanService
    {
        Task<ScanResolveResponse> ResolveAsync(string code);
    }

    /// <summary>
    /// Phân loại mã quét. Pattern quyết định tra bảng nào (thu hẹp),
    /// rồi tra DB để xác định chính xác + lấy id/khu.
    /// </summary>
    public partial class ScanService : IScanService
    {
        private readonly IScanRepository _repo;
        public ScanService(IScanRepository repo) => _repo = repo;

        // payload lưu varchar(500) — dài hơn thì chắc chắn không có trong DB.
        private const int MaxPayloadLength = 500;

        // pallet_id: đúng 12 chữ số
        [GeneratedRegex(@"^\d{12}$")]
        private static partial Regex LotPattern();

        // Vị trí rack: có dấu gạch, dạng chữ-số / số / số  (A1-1-1, B2-2-2)
        [GeneratedRegex(@"^[A-Za-z]+\d*-\d+-\d+$")]
        private static partial Regex StoragePattern();

        // Vị trí phẳng RECV/Vanning: chữ + số, không gạch (PL1, P001, VN5...)
        [GeneratedRegex(@"^[A-Za-z]+\d+$")]
        private static partial Regex FlatLocatorPattern();

        public async Task<ScanResolveResponse> ResolveAsync(string code)
        {
            code = (code ?? "").Trim();
            if (code.Length == 0)
                return ScanResolveResponse.NotFound(code);

            // 0) Tem Part Card -> chỉ tra part_cards. Payload dạng này không thể là
            //    pallet / box / model nên không thấy thì trả not_found luôn.
            // Nhận diện: payload có field ID=<khác rỗng> (ID=xxx|CATE=...|MODELS=...).
            // Kitting card / model / pallet không bao giờ có field này.
            if (CardIdOf(code).Length > 0)
            {
                if (code.Length > MaxPayloadLength)
                    return ScanResolveResponse.NotFound(code);

                var card = await _repo.FindPartCardAsync(code);
                return card is null
                    ? ScanResolveResponse.NotFound(code)
                    : ScanResolveResponse.PartCardOf(card, ToInfo(card));
            }

            // 1) Dạng rack -> tra locator. Không thấy thì đi tiếp (mã model có thể trùng dạng).
            if (StoragePattern().IsMatch(code))
            {
                var hit = await _repo.FindStorageLocatorAsync(code);
                if (hit != null)
                    return ScanResolveResponse.Location(hit, ScanType.StorageLocation);
            }
            // 2) Chữ + số không gạch -> vị trí phẳng (RECV / Vanning).
            else if (FlatLocatorPattern().IsMatch(code))
            {
                var hit = await _repo.FindRecvLocatorAsync(code);
                if (hit != null)
                    return ScanResolveResponse.Location(hit, ScanType.RecvLocation);
            }
            // 3) Đúng 12 số -> ưu tiên lot.
            else if (LotPattern().IsMatch(code))
            {
                var lot = await _repo.FindLotAsync(code);
                if (lot != null) return ScanResolveResponse.Pallet(lot);
            }

            // 4) Còn lại -> box -> serial -> model.
            var box = await _repo.FindBoxAsync(code);
            if (box != null) return ScanResolveResponse.Box(box);

            var serial = await _repo.FindSerialAsync(code);
            if (serial != null) return ScanResolveResponse.Serial(serial);

            var model = await _repo.FindModelAsync(code);
            if (model != null) return ScanResolveResponse.Model(model);

            return ScanResolveResponse.NotFound(code);
        }

        // Cờ thao tác — PHẢI khớp luật của PartCardService / PartCardRepository:
        //   sửa       : chặn khi Status_OQC <> 0 (khoá tay không chặn sửa);
        //   tách      : xoá phiếu nguồn → chặn khoá tay; chỉ 1 mã (nhiều thùng được);
        //               đã vào OQC vẫn tách (tem con kế thừa Status_OQC);
        //   gộp       : xoá phiếu nguồn → chặn khoá tay lẫn OQC.
        private static ScanPartCardInfo ToInfo(PartCardScanHit c)
        {
            var models = c.IsOverseaService ? c.RowCount : 1;
            var boxes = models == 1
                ? (c.IsOverseaService ? BoxOf(c.FirstInnerBox) : 1)
                : 0;
            var inOqc = c.StatusOqc != 0;

            return new ScanPartCardInfo(
                CardId: CardIdOf(c.Payload),
                ModelCount: models,
                BoxCount: boxes,
                IsLocked: c.IsLocked,
                StatusOqc: c.StatusOqc,
                CanEdit: !c.IsLocked,
                CanSplit: !c.IsLocked && models == 1,
                CanMerge: !c.IsLocked);
        }

        private static int BoxOf(string? innerBox)
            => int.TryParse(innerBox?.Trim(), out var n) && n > 0 ? n : 1;

        private static string CardIdOf(string payload)
        {
            foreach (var field in payload.Split('|'))
            {
                var i = field.IndexOf('=');
                if (i > 0 && field[..i].Trim() == "ID")
                    return field[(i + 1)..].Trim();
            }
            return "";
        }
    }
}