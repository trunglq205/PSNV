﻿using System.ComponentModel.DataAnnotations;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Utils;

namespace SWMS_WebTool.Models
{
    public class AbnormalReport
    {
        public Guid Id { get; set; }

        public string? ManagementNumber { get; set; }

        [Required(ErrorMessage = "Please select discovery date")]
        public DateTime DiscoveryDate { get; set; } = DateTime.Now;
        public DateTime? ReceivingDate { get; set; } = DateTime.Now;

        // ── Product info ────────────────────────────────────────────
        [Required(ErrorMessage = "Please enter Part Number")]
        [MaxLength(100)]
        public string? PartNumber { get; set; }
        public string? PartName { get; set; }
        public string? VendorCode { get; set; }
        public string? IssuingSLOC { get; set; }
        public string? ReceivingSLOC { get; set; }

        [Required(ErrorMessage = "Please enter Invoice Number")]
        [MaxLength(100)]
        public string? InvoiceNumber { get; set; }

        [Required(ErrorMessage = "Please enter quantity")]
        [Range(0, int.MaxValue, ErrorMessage = "Must be >= 0")]
        public int InvoiceQuantity { get; set; }

        [Required(ErrorMessage = "Please enter abnormal quantity")]
        public int AbnormalQuantity { get; set; }

        [Required(ErrorMessage = "Please enter Supplier")]
        [MaxLength(200)]
        public string? Supplier { get; set; }

        [MaxLength(200)]
        public string? ShippingCompany { get; set; }

        [Required(ErrorMessage = "Please enter discovery location")]
        [MaxLength(200)]
        public string? DiscoveryLocation { get; set; }

        [Required(ErrorMessage = "Please enter discovered by")]
        [MaxLength(100)]
        public string? DiscoveredBy { get; set; }

        // ── Problem type ──
        /// <summary>A) Packaging Issue / カートン問題</summary>
        public bool ProblemTypeA { get; set; }

        /// <summary>B) Wrong Part Number / 品番誤り</summary>
        public bool ProblemTypeB { get; set; }

        /// <summary>C) Wrong Quantity / 数量誤り</summary>
        public bool ProblemTypeC { get; set; }

        [MaxLength(2000)]
        public string? ProblemDescriptionA { get; set; }

        [MaxLength(2000)]
        public string? ProblemDescriptionB { get; set; }

        [MaxLength(2000)]
        public string? ProblemDescriptionC { get; set; }

        // ── IQC ─────────────────────────────────────────────────────
        /// <summary>Có cần IQC kiểm tra không (do người tạo report đánh dấu)</summary>
        public bool RequiresIQC { get; set; }
        public SupplierType SupplierType { get; set; }

        /// <summary>1 = OK, 2 = NG</summary>
        public byte? IQCResult { get; set; }

        [MaxLength(100)]
        public string? IQCConfirmedBy { get; set; }

        public DateTime? IQCConfirmedAt { get; set; }
        public string? IQCApprovedBy { get; set; }
        public DateTime? IQCApprovedAt { get; set; }
        public string? IQCLeaderNote { get; set; }

        [MaxLength(2000)]
        public string? IQCNote { get; set; }

        // ── PUS result ───────────────────────────────────────────────
        /// <summary>1 = Lỗi của PSNV, 2 = Lỗi của NCC</summary>
        public byte? PUSAction { get; set; }

        [MaxLength(100)]
        public string? PUSConfirmedBy { get; set; }

        public DateTime? PUSConfirmedAt { get; set; }
        public string? PUSApprovedBy { get; set; }
        public DateTime? PUSApprovedAt { get; set; }

        [MaxLength(2000)]
        public string? PUSNote { get; set; }
        [MaxLength(2000)]
        public string? PUSLeaderNote { get; set; }

        // ── MCS result ───────────────────────────────────────────────
        [MaxLength(2000)]
        public string? MCSNote { get; set; }
        public string? MCSLeaderNote { get; set; }
        public string? MCSConfirmedBy { get; set; }
        public DateTime? MCSConfirmedAt { get; set; }

        public string? MCSApprovedBy { get; set; }
        public DateTime? MCSApprovedAt { get; set; }

        // ── Status / Audit ───────────────────────────────────────────
        public byte ReportStatus { get; set; }

        [MaxLength(100)]
        public string? CreatedBy { get; set; }

        public DateTime CreatedAt { get; set; }
        public DateTime UpdatedAt { get; set; }

        // ── Ảnh đính kèm ────────────────────────────────────────────

        /// <summary>
        /// Danh sách ảnh đã lưu, dùng để hiển thị readonly trong
        /// ConfirmIQC / ConfirmPUS modal (populate từ API).
        /// </summary>
        public List<AbnormalReportImageVM> ImageViews { get; set; } = new();

        // ── Helper (không map DB) ────────────────────────────────────
        /// <summary>
        /// Trả về true nếu ít nhất một loại vấn đề được chọn.
        /// Dùng để validate trước khi lưu.
        /// </summary>
        public bool HasAnyProblemType => ProblemTypeA || ProblemTypeB || ProblemTypeC;
    }

    public enum SupplierType : byte
    {
        Local = 1,
        Oversea = 2
    }

    /// <summary>
    /// Nhận file upload từ form (Create / Edit).
    /// Bind qua: Images[0].File, Images[0].Comment
    /// </summary>
    public class AbnormalReportImageUpload
    {
        public string? Url { get; set; }

        [MaxLength(500)]
        public string? Comment { get; set; }
    }

    /// <summary>
    /// Hiển thị ảnh đã lưu (readonly).
    /// Populate từ API response, dùng trong Confirm modals.
    /// </summary>
    public class AbnormalReportImageVM
    {
        public Guid Id { get; set; }
        public Guid ReportId { get; set; }
        public string FilePath { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public string? Comment { get; set; }
        public byte SortOrder { get; set; }
        public string? UploadedBy { get; set; }
        public DateTime UploadedAt { get; set; }

        public string FileFullPath =>
                $"{Constants.ENV.GetImageURL()}{Uri.EscapeDataString(FilePath.Replace('\\', '/'))}";
    }

    public class AbnormalReportResponse
    {
        public List<AbnormalReport> Records { get; set; } = new List<AbnormalReport>();
        public int TotalRecord { get; set; }
    }
}