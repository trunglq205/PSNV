using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShippingScs.Web.Models;
using ShippingScs.Web.Services;

namespace ShippingScs.Web.Controllers;

public class CalendarViewModel
{
    public List<WorkingCalendar> Calendars { get; set; } = new();
    public string Code { get; set; } = "";
    public int Year { get; set; }
    public int Month { get; set; }
    /// <summary>"month" hoặc "year"</summary>
    public string View { get; set; } = "month";
    public bool IsYearView => View == "year";
    public DateOnly From { get; set; }
    public DateOnly To { get; set; }
    // Ngày -> dòng trong DB (thiếu = chưa sinh lịch). Phủ cả tháng hoặc cả năm tuỳ View.
    public Dictionary<DateOnly, WorkingDay> Days { get; set; } = new();
}

public class CalendarController : Controller
{
    private const string XlsxContentType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
    private const long MaxUploadBytes = 5 * 1024 * 1024;

    private readonly WorkingCalendarService _calendar;
    private readonly CalendarExcelService _excel;

    public CalendarController(WorkingCalendarService calendar, CalendarExcelService excel)
    {
        _calendar = calendar;
        _excel = excel;
    }

    public async Task<IActionResult> Index(string? code, int? year, int? month, string? view)
    {
        var calendars = await _calendar.ListCalendarsAsync();
        if (calendars.Count == 0) return Content("Chưa có lịch làm việc nào. Chạy script database/001_M1_system.sql.");

        var today = DateTime.Today;
        var model = new CalendarViewModel
        {
            Calendars = calendars,
            Code = calendars.Any(c => c.Code == code) ? code! : calendars[0].Code,
            Year = year is >= 2000 and <= 2100 ? year.Value : today.Year,
            Month = month is >= 1 and <= 12 ? month.Value : today.Month,
            View = view == "year" ? "year" : "month",
        };

        if (model.IsYearView)
        {
            model.From = new DateOnly(model.Year, 1, 1);
            model.To = new DateOnly(model.Year, 12, 31);
        }
        else
        {
            model.From = new DateOnly(model.Year, model.Month, 1);
            model.To = model.From.AddMonths(1).AddDays(-1);
        }

        var days = await _calendar.GetDaysAsync(model.Code, model.From, model.To);
        model.Days = days.ToDictionary(d => DateOnly.FromDateTime(d.Date));
        return View(model);
    }

    [HttpPost, Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Generate(string code, int year, bool saturdayIsWorking)
    {
        try
        {
            var n = await _calendar.GenerateYearAsync(code, year, saturdayIsWorking);
            TempData["Success"] = n == 0
                ? $"Lịch {code} năm {year} đã đủ ngày, không thêm gì."
                : $"Đã thêm {n} ngày cho lịch {code} năm {year}. Bấm vào từng ngày để đánh dấu ngày lễ.";
        }
        catch (BusinessException ex)
        {
            TempData["Error"] = ex.Message;
        }
        // Sinh xong mở xem cả năm để đánh dấu ngày lễ luôn
        return RedirectToAction(nameof(Index), new { code, year, view = "year" });
    }

    /// <summary>File Excel mẫu để điền ngày lễ.</summary>
    public IActionResult Template(int? year)
    {
        var y = year is >= 2000 and <= 2100 ? year.Value : DateTime.Today.Year + 1;
        return File(_excel.BuildTemplate(y), XlsxContentType, $"Mau_lich_lam_viec_{y}.xlsx");
    }

    /// <summary>Xuất lịch cả năm ra Excel (đúng format import, sửa xong upload lại được).</summary>
    public async Task<IActionResult> Export(string code, int year)
    {
        if (year < 2000 || year > 2100) return BadRequest();
        var from = new DateOnly(year, 1, 1);
        var days = await _calendar.GetDaysAsync(code, from, new DateOnly(year, 12, 31));
        if (days.Count == 0)
        {
            TempData["Error"] = $"Lịch {code} năm {year} chưa có ngày nào để xuất. Sinh lịch năm hoặc import trước.";
            return RedirectToAction(nameof(Index), new { code, year, view = "year" });
        }
        return File(_excel.BuildExport(days, code, year), XlsxContentType, $"Lich_{code}_{year}.xlsx");
    }

    [HttpPost, Authorize(Roles = Roles.Admin)]
    [RequestSizeLimit(MaxUploadBytes)]
    public async Task<IActionResult> Import(string code, IFormFile? file, bool generateMissing, bool saturdayIsWorking, int year)
    {
        if (file == null || file.Length == 0)
        {
            TempData["Error"] = "Chưa chọn file.";
            return RedirectToAction(nameof(Index), new { code, year, view = "year" });
        }
        if (!file.FileName.EndsWith(".xlsx", StringComparison.OrdinalIgnoreCase))
        {
            TempData["Error"] = "Chỉ nhận file .xlsx. File .xls hãy mở bằng Excel rồi Lưu thành .xlsx.";
            return RedirectToAction(nameof(Index), new { code, year, view = "year" });
        }

        CalendarImportResult parsed;
        using (var stream = file.OpenReadStream())
        {
            parsed = _excel.Parse(stream);
        }

        if (!parsed.IsValid)
        {
            // Có lỗi là không import gì cả: hiện danh sách lỗi theo dòng để sửa file
            TempData["ImportErrors"] = string.Join("\n", parsed.Errors.Take(100))
                + (parsed.Errors.Count > 100 ? $"\n... và {parsed.Errors.Count - 100} lỗi khác" : "");
            TempData["ImportFile"] = file.FileName;
            return RedirectToAction(nameof(Index), new { code, year, view = "year" });
        }

        try
        {
            var n = await _calendar.ImportDaysAsync(code, parsed.Rows, generateMissing, saturdayIsWorking);
            var years = parsed.Rows.Select(r => r.Date.Year).Distinct().OrderBy(y => y).ToList();
            TempData["Success"] = $"Đã import {n} ngày từ {file.FileName} vào lịch {code} (năm {string.Join(", ", years)}).";
            return RedirectToAction(nameof(Index), new { code, year = years[0], view = "year" });
        }
        catch (BusinessException ex)
        {
            TempData["Error"] = ex.Message;
            return RedirectToAction(nameof(Index), new { code, year, view = "year" });
        }
    }

    [HttpPost, Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> SetDay(string code, DateTime date, string dayType, string? note, string? view)
    {
        var d = DateOnly.FromDateTime(date);
        try
        {
            await _calendar.SetDayAsync(code, d, dayType, note);
            TempData["Success"] = $"Đã cập nhật ngày {d:dd/MM/yyyy}.";
        }
        catch (BusinessException ex)
        {
            TempData["Error"] = ex.Message;
        }
        return RedirectToAction(nameof(Index), new { code, year = d.Year, month = d.Month, view = view == "year" ? "year" : "month" });
    }
}
