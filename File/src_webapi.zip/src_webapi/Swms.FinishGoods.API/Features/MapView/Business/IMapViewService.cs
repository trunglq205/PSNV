namespace Swms.FinishGoods.API.Features.MapView.Business;

public interface IMapViewService
{
    Task<MapViewLayout> GetLayoutAsync(string areaCode);
}
