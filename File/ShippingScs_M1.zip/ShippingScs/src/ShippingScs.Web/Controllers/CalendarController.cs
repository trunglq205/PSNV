using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShippingScs.Web.Models;
using ShippingScs.Web.Services;

namespace ShippingScs.Web.Controllers;

public class CalendarMonthModel
{
    public List<WorkingCalendar> Calendars { get; set; } = new();
    public string Code { get; set; } = "";
    public int Year { get; set; }
    public int Month { get; set; }
    // Ngày -> dòng trong DB (thiếu = chưa sinh lịch)
    public Dictionary<DateOnly, WorkingDay> Days { get; set; } = new();
}

public class CalendarController : Controller
{
    private readonly WorkingCalendarService _calendar;

    public CalendarController(WorkingCalendarService calendar) => _calendar = calendar;

    public async Task<IActionResult> Index(string? code, int? year, int? month)
    {
        var calendars = await _calendar.ListCalendarsAsync();
        if (calendars.Count == 0) return Content("Chưa có lịch làm việc nào. Chạy script database/001_M1_system.sql.");

        var today = DateTime.Today;
        var model = new CalendarMonthModel
        {
            Calendars = calendars,
            Code = calendars.Any(c => c.Code == code) ? code! : calendars[0].Code,
            Year = year ?? today.Year,
            Month = month is >= 1 and <= 12 ? month.Value : today.Month,
        };

        var first = new DateOnly(model.Year, model.Month, 1);
        var days = await _calendar.GetDaysAsync(model.Code, first, first.AddMonths(1).AddDays(-1));
        model.Days = days.ToDictionary(d => DateOnly.FromDateTime(d.Date));
        return View(model);
    }

    [HttpPost, Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> Generate(string code, int year, bool saturdayIsWorking)
    {
        try
        {
            var n = await _calendar.GenerateYearAsync(code, year, saturdayIsWorking);
            TempData["Success"] = n == 0
                ? $"Lịch {code} năm {year} đã đủ ngày, không thêm gì."
                : $"Đã thêm {n} ngày cho lịch {code} năm {year}.";
        }
        catch (BusinessException ex)
        {
            TempData["Error"] = ex.Message;
        }
        return RedirectToAction(nameof(Index), new { code, year, month = 1 });
    }

    [HttpPost, Authorize(Roles = Roles.Admin)]
    public async Task<IActionResult> SetDay(string code, DateTime date, string dayType, string? note)
    {
        var d = DateOnly.FromDateTime(date);
        try
        {
            await _calendar.SetDayAsync(code, d, dayType, note);
            TempData["Success"] = $"Đã cập nhật ngày {d:dd/MM/yyyy}.";
        }
        catch (BusinessException ex)
        {
            TempData["Error"] = ex.Message;
        }
        return RedirectToAction(nameof(Index), new { code, year = d.Year, month = d.Month });
    }
}
