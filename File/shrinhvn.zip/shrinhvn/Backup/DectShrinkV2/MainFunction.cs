﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class MainFunction : Form
    {
        ConnectSQL objConnect = new ConnectSQL();
        string id;
        public static string content = "";
        public MainFunction(string id)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Normal;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            //KeyPreview = true;
            lblid.Text = id;
            lblName.Text = objConnect.GetExcuteScalar("select sFullName from TBLUSER where susername='" + id + "'").ToString();
            this.id = id;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frmStep3cs step3 = new frmStep3cs(id);
            step3.ShowDialog();
        }

        private void MainFunction_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void MainFunction_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.D1 || e.KeyCode == Keys.NumPad1)
            {
                button1_Click(sender, e);
            }
            if (e.KeyCode == Keys.D3)
            {
                button3_Click(sender, e);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            frmQTTycs step3 = new frmQTTycs(lblid.Text);
            step3.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {

        }

        private void btnUploadMasterPalllet_Click(object sender, EventArgs e)
        {
            frmUploadMasterPallet frm = new frmUploadMasterPallet(lblid.Text);
            frm.ShowDialog();
            this.Hide();
        }

        private void button4_Click_1(object sender, EventArgs e)
        {
            frmGhepHang frmGH = new frmGhepHang(lblid.Text);
            frmGH.ShowDialog();
        }
    }
}
