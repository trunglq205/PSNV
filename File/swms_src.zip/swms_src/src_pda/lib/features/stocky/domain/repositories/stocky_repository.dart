import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';

abstract interface class StockyRepository {
  /// Tra xe vừa quét và kiểm có được nhập / xuất theo [mode] không
  /// (vd xe đã nhập rồi thì không nhập lại, xe chưa nhập thì không xuất).
  ///
  /// Sai chiều: server trả 409, `ErrorInterceptor` biến thành
  /// `ServerException` mang NGUYÊN câu thông báo đã dịch của server — câu đó
  /// nói rõ xe nào và vì sao, nên không bọc lại thành lỗi chung ở client.
  Future<StockyCart> lookup({required String code, required StockyMode mode});

  /// Chốt nhập / xuất cả danh sách trong 1 lần.
  Future<StockySubmitResult> submit({
    required StockyMode mode,
    required List<String> codes,
  });

  /// Danh sách xe trong kho kèm vị trí. [hasGoods] null = cả xe rỗng lẫn xe
  /// có hàng.
  Future<List<StockyCart>> fetchList({bool? hasGoods, String? keyword});
}
