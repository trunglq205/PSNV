﻿using System;
using SWMS_WebTool.Models;
using Microsoft.CSharp;
using System.Diagnostics;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using System.Security.Claims;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.ViewModels;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.ViewModels
{
    public abstract class TableViewModel<T, F> where F : BaseFilter 
    {
        public IEnumerable<T> Items;

        public int PageNumber;
        public int PageSize;
        public int TotalPage;
        public int Total;
        public F Filter;

        public abstract object getQueryConditions(int? pageNumber = null, string? pageSize = null, F? filter = default(F));
    }
}

