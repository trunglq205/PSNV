part of 'exceptions.dart';

/// Lỗi nghiệp vụ khi tạo lot — [code] khớp mã lỗi server trả về (`Lot.*`)
/// nhưng đổi sang dạng khóa i18n `error.*` để hiển thị.
sealed class LotException extends AppException {
  const LotException(super.message, {required super.code});
}

class LotNoInvalidFormatException extends LotException {
  const LotNoInvalidFormatException()
      : super(
    'Mã lot phải gồm đúng 12 chữ số',
    code: 'error.lot_no_invalid_format',
  );
}

class LotNoCategoryMismatchException extends LotException {
  const LotNoCategoryMismatchException()
      : super(
    '3 ký tự đầu của mã lot phải khớp category',
    code: 'error.lot_no_category_mismatch',
  );
}

class StockyCodeRequiredException extends LotException {
  const StockyCodeRequiredException()
      : super(
    'Lot stocky thì bắt buộc có mã stocky',
    code: 'error.stocky_code_required',
  );
}

class StockyCodeNotAllowedException extends LotException {
  const StockyCodeNotAllowedException()
      : super(
    'Lot pallet thì không được có mã stocky',
    code: 'error.stocky_code_not_allowed',
  );
}

class BoxesNotAllowedForBoxCountException extends LotException {
  const BoxesNotAllowedForBoxCountException()
      : super(
    'Chế độ đếm hộp thì không được gửi danh sách hộp',
    code: 'error.boxes_not_allowed_for_box_count',
  );
}

class BoxCountRequiredException extends LotException {
  const BoxCountRequiredException()
      : super(
    'Chế độ đếm hộp thì bắt buộc có số hộp',
    code: 'error.box_count_required',
  );
}

class BoxesRequiredException extends LotException {
  const BoxesRequiredException()
      : super('Phải có ít nhất 1 hộp', code: 'error.boxes_required');
}

class BoxNoDuplicatedException extends LotException {
  const BoxNoDuplicatedException()
      : super(
    'Mã hộp bị trùng trong cùng lot',
    code: 'error.box_no_duplicated',
  );
}

class BoxLinesRequiredException extends LotException {
  const BoxLinesRequiredException()
      : super(
    'Mỗi hộp phải có ít nhất 1 dòng',
    code: 'error.box_lines_required',
  );
}

class SerialNoRequiredException extends LotException {
  const SerialNoRequiredException()
      : super(
    'Chế độ serial thì mỗi dòng bắt buộc có serial',
    code: 'error.serial_no_required',
  );
}

class SerialDuplicatedException extends LotException {
  const SerialDuplicatedException()
      : super(
    'Serial bị trùng trong cùng lot',
    code: 'error.serial_duplicated',
  );
}

class SerialNotAllowedException extends LotException {
  const SerialNotAllowedException()
      : super(
    'Chế độ box line thì dòng không được có serial',
    code: 'error.serial_not_allowed',
  );
}

class QtyRequiredException extends LotException {
  const QtyRequiredException()
      : super(
    'Chế độ box line thì số lượng bắt buộc và >= 1',
    code: 'error.qty_required',
  );
}

class QtyNotDivisibleByCartonCountException extends LotException {
  const QtyNotDivisibleByCartonCountException()
      : super(
    'Số lượng phải chia hết cho số carton',
    code: 'error.qty_not_divisible_by_carton_count',
  );
}