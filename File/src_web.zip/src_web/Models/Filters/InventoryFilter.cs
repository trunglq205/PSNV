﻿using System.ComponentModel;
using System.Runtime.Serialization;
using Refit;

namespace SWMS_WebTool.Models.Filters
{
    public class InventoryStoredQuantityFilter : BaseFilter
    {
        public string Material { get; set; }
        public string Category { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? DateStorage { get; set; }
        [Query(Format = "yyyy-MM-dd")]
        public DateTime? ToDate { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? FromDate { get; set; }
    }

    public class InventoryFilter : BaseFilter
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Material { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? ToDate { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? FromDate { get; set; }
    }

    public class InvenoryGoodReceiptFilter : BaseFilter
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? DateReceive { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? ToDate { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? FromDate { get; set; }
    }

    public class InventoryMovedOutFilter : BaseFilter
    {
        public string Material { get; set; }
        public string Category { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? KittingDate { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? FromDate { get; set; }

        [Query(Format = "yyyy-MM-dd")]
        public DateTime? ToDate { get; set; }
    }

    public class SapStockFilter : BaseFilter
    {
        public string Material { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
    }

    public class InventoryFormFilter : BaseFilter
    {
        public InventoryFormTab Tab { get; set; }
        public InventoryBalanceType? BalanceType { get; set; }
        public DateTime StartDate { get; set; } = DateTime.Now;
        public DateTime EndDate { get; set; } = DateTime.Now;
        public KittingTab Type { get; set; }
        public string? Material { get; set; }
        public string? Plant { get; set; }
        public string? Category { get; set; }
        public string? Sloc { get; set; }
        public bool IsAll { get; set; }
    }

    public class InventoryFormKittingFilter : BaseFilter
    {
        public InventoryFormTab Tab { get; set; }
        public InventoryBalanceType? BalanceType { get; set; }
        public DateTime InventoryCloseDate { get; set; } = DateTime.Now;
        public string? Material { get; set; }
        public string? Plant { get; set; }
        public string? Category { get; set; }
        public string? Sloc { get; set; }
        public bool IsAll { get; set; }
    }

    public enum InventoryFormTab
    {
        [EnumMember(Value = "0")]
        [Description("Status_InventoryFormOk")]
        FormOK,
        [EnumMember(Value = "1")]
        [Description("Status_InventoryFormNg")]
        FormNG
    }

    public enum InventoryBalanceType
    {
        [EnumMember(Value = "0")]
        [Description("Status_BalanceManual")]
        BalanceManual,
        [EnumMember(Value = "1")]
        [Description("Status_BalanceAuto")]
        BalanceAuto,
        [EnumMember(Value = "2")]
        [Description("Status_NeedConfirm")]
        NeedConfirm
    }
}
