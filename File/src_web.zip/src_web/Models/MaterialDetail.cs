﻿namespace SWMS_WebTool.Models
{
    public class MaterialDetail
    {
        public Int64 Id { get; set; }
        public string Name { get; set; }
        public string Material { get; set; }
        public string Description { get; set; }
        public string FilePath { get; set; }
        public string FileBase64 { get; set; }
    }

    public class MaterialDetailRequest
    {
        public Int64 Id { get; set; }
        public string Name { get; set; }
        public string Material { get; set; }
        public string Description { get; set; }
        public string FilePath { get; set; }
    }

    public class UploadImageRequest
    {
        public long Id { get; set; }
        public IFormFile FileUpload { get; set; }
      
        public string FileName { get; set; } = string.Empty;
        public List<byte> ByteImageUpload { get; set; } = new List<byte>();
    }

    public class UploadImageRequestVM
    {
        public long Id { get; set; } = 0;
        public string Material { get; set; } = string.Empty;
        public string FileName { get; set; } = string.Empty;
        public List<byte> ByteImageUpload { get; set; } = new List<byte>();
    }

    public class UploadMultipleRequestVM
    {
        public List<UploadImageRequestVM> UploadImageRequests { get; set; } = new List<UploadImageRequestVM>();
    }
}
