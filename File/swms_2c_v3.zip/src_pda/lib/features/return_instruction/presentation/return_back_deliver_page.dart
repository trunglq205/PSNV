import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/feedback/feedback_provider.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_back_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2c · bước cuối — SCS WH giao hàng RW/RB cho FA.
//
//  Vào từ màn Chỉ thị back hàng (chạm phiếu → "Giao hàng cho FA").
//
//  HAI MÀN, không một:
//    _PickPage   chọn đề nghị đang chờ giao của phiếu (bỏ qua nếu chỉ có một)
//    _ScanPage   quét Pallet ID → xác nhận một lượt
//
//  ĐIỀU HƯỚNG BẰNG MaterialPageRoute, không khai route auto_route. Thêm một
//  @RoutePage là phải sinh lại app_router.gr.dart — một file DÙNG CHUNG cả
//  app, mà build_runner trong source hiện tại đang vỡ (hai file cùng khai
//  `@RoutePage() class VanningPage`). Đây là việc làm MỘT LẦT từ một màn, nên
//  không cần deep-link; đổi sang auto_route sau này chỉ là thêm annotation.
//
//  QUYỀN: `rework_refurbish.process`, khớp
//  `[RequirePermission<…Process>]` trên `POST {id}/deliver`. Màn gọi không
//  kiểm lại quyền — chỗ gọi (màn danh sách) đã ẩn nút khi không có quyền.
// ─────────────────────────────────────────────────────────────

/// Mở luồng giao hàng cho một phiếu chỉ thị.
///
/// Trả `true` khi đã giao được con nào — chỗ gọi dùng nó để tải lại danh sách.
Future<bool> openBackDeliverFlow(
  BuildContext context, {
  required int docId,
  required String docNo,
}) async {
  final changed = await Navigator.of(context).push<bool>(
    MaterialPageRoute(
      builder: (_) => _PickPage(docId: docId, docNo: docNo),
    ),
  );
  return changed ?? false;
}

// ── Màn chọn đề nghị ────────────────────────────────────────

class _PickPage extends ConsumerStatefulWidget {
  const _PickPage({required this.docId, required this.docNo});

  final int docId;
  final String docNo;

  @override
  ConsumerState<_PickPage> createState() => _PickPageState();
}

class _PickPageState extends ConsumerState<_PickPage> {
  /// Đã giao được con nào trong cả luồng — trả về cho màn danh sách.
  bool _changed = false;

  /// Đã tự nhảy sang màn quét chưa. Cờ này cần thiết vì build chạy lại nhiều
  /// lần: thiếu nó thì mỗi lần build lại đẩy thêm một màn quét lên stack.
  bool _autoJumped = false;

  Future<void> _open(BackRequest req) async {
    final done = await Navigator.of(context).push<bool>(
      MaterialPageRoute(builder: (_) => _ScanPage(request: req)),
    );
    if (!mounted) return;
    if (done == true) {
      _changed = true;
      ref.invalidate(backDeliverableListProvider(widget.docId));
    }
    // Đã nhảy thẳng vào màn quét (phiếu chỉ có một đề nghị) thì đóng luôn màn
    // chọn: quay về một danh sách MỘT dòng — hoặc rỗng — chẳng để làm gì, mà
    // WH thì phải bấm back thêm một lần mới về được chỗ họ đi ra.
    if (_autoJumped) Navigator.of(context).pop(_changed);
  }

  /// Phiếu chỉ có MỘT đề nghị chờ giao: vào thẳng màn quét.
  ///
  /// Đó là trường hợp gần như luôn xảy ra, và bắt WH chạm thêm một lần vào
  /// danh sách một dòng là bước thừa khi đang đứng cạnh pallet.
  void _autoJump(List<BackRequest> rows) {
    if (_autoJumped || rows.length != 1) return;
    _autoJumped = true;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _open(rows.first);
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final async = ref.watch(backDeliverableListProvider(widget.docId));

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (!didPop) Navigator.of(context).pop(_changed);
      },
      child: Scaffold(
        appBar: AppTopBar(
          title: LocaleKeys.return_back_deliver_title.tr(),
          subtitle: widget.docNo,
          actions: [
            IconButton(
              tooltip: LocaleKeys.return_back_refresh.tr(),
              icon: const Icon(Icons.refresh_rounded),
              onPressed: () =>
                  ref.invalidate(backDeliverableListProvider(widget.docId)),
            ),
          ],
        ),
        body: switch (async) {
          AsyncLoading() => const AppLoading(),
          AsyncError(:final error) => AppErrorView.page(
              message: ref.read(errorHandlerProvider).getMessage(error),
              onRetry: () =>
                  ref.invalidate(backDeliverableListProvider(widget.docId)),
            ),
          AsyncValue(:final value) => _buildList(context, c, value ?? const []),
        },
      ),
    );
  }

  Widget _buildList(
      BuildContext context, SwmsColors c, List<BackRequest> rows) {
    _autoJump(rows);

    if (rows.isEmpty) {
      return RefreshIndicator(
        onRefresh: () async =>
            ref.invalidate(backDeliverableListProvider(widget.docId)),
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(
                  AppDimens.md, 80, AppDimens.md, 0),
              child: Text(
                LocaleKeys.return_back_deliver_empty.tr(),
                textAlign: TextAlign.center,
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: () async =>
          ref.invalidate(backDeliverableListProvider(widget.docId)),
      child: ListView.separated(
        padding: const EdgeInsets.all(AppDimens.md),
        itemCount: rows.length,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (_, i) => _RequestTile(
          req: rows[i],
          onTap: () => _open(rows[i]),
        ),
      ),
    );
  }
}

class _RequestTile extends StatelessWidget {
  const _RequestTile({required this.req, required this.onTap});

  final BackRequest req;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      padding: EdgeInsets.zero,
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(10),
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.sm + 4),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Expanded(
                    child: Text(
                      req.reqNo,
                      style: AppTextStyles.code.copyWith(
                        fontSize: 13,
                        fontWeight: FontWeight.w700,
                        color: c.text1,
                      ),
                    ),
                  ),
                  // Hai loại hàng hai màu, cùng tinh thần badge RW/RB trên bản
                  // đồ kho: người dùng quét bằng mắt chứ không đọc chữ.
                  //
                  // Nhãn dùng LẠI ReturnGoodsType của mục 2a, không khai khoá
                  // dịch mới: hai chỗ cùng gọi một loại hàng thì phải cùng một
                  // chữ, mà hai khoá riêng là sớm muộn dịch lệch nhau.
                  req.isRework
                      ? StatusPill.warning(context,
                          label: ReturnGoodsType.rework.labelKey.tr())
                      : StatusPill.info(context,
                          label: ReturnGoodsType.refurbish.labelKey.tr()),
                  const SizedBox(width: 4),
                  Icon(Icons.chevron_right_rounded, size: 18, color: c.text3),
                ],
              ),
              const SizedBox(height: 6),
              // CÒN LẠI là con số WH đọc để biết phải đẩy mấy pallet nữa, nên
              // nó to và đứng trước tổng.
              Row(
                children: [
                  Text(
                    LocaleKeys.return_back_remain_pcs
                        .tr(namedArgs: {'qty': '${req.remainQty}'}),
                    style: AppTextStyles.label.copyWith(
                      fontWeight: FontWeight.w700,
                      color: req.remainQty > 0 ? c.warning : c.success,
                    ),
                  ),
                  const Spacer(),
                  Text(
                    LocaleKeys.return_back_meta.tr(namedArgs: {
                      'models': '${req.modelCount}',
                      'qty': '${req.totalQty}',
                    }),
                    style: AppTextStyles.caption.copyWith(color: c.text3),
                  ),
                ],
              ),
              if (req.isPartlyDelivered) ...[
                const SizedBox(height: 4),
                Text(
                  LocaleKeys.return_back_partly.tr(namedArgs: {
                    'done': '${req.deliveredQty}',
                    'total': '${req.totalQty}',
                  }),
                  style: AppTextStyles.caption.copyWith(color: c.text2),
                ),
              ],
              if (req.note != null) ...[
                const SizedBox(height: 4),
                Text(req.note!,
                    style: AppTextStyles.caption.copyWith(color: c.text3)),
              ],
            ],
          ),
        ),
      ),
    );
  }
}

// ── Màn quét Pallet ID ──────────────────────────────────────

class _ScanPage extends ConsumerStatefulWidget {
  const _ScanPage({required this.request});

  final BackRequest request;

  @override
  ConsumerState<_ScanPage> createState() => _ScanPageState();
}

class _ScanPageState extends ConsumerState<_ScanPage> {
  StreamSubscription<String>? _sub;

  /// Mã đã quét, chưa gửi. Danh sách chứ không Set: THỨ TỰ quét là thứ tự WH
  /// xếp hàng lên xe, hiện đúng thứ tự thì họ soát lại bằng mắt được.
  final List<String> _lots = [];

  bool _saving = false;
  bool _changed = false;

  /// Kết quả lượt vừa xác nhận — giữ trên màn khi còn hàng chưa giao.
  BackDeliverResult? _last;

  /// Số liệu mới nhất của đề nghị. Mỗi lượt giao xong thì server trả lại bản
  /// đã cập nhật, dùng nó thay vì giữ con số lúc mở màn.
  late BackRequest _req = widget.request;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Page đã dispose trong lúc chờ → không gán, tránh rò listener.
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      _onScan(data);
    });
  }

  /// Nhận một mã quét.
  ///
  /// Trùng thì KHÔNG thêm lần hai mà kêu một tiếng cảnh báo: quét hai lần cùng
  /// một pallet là chuyện thường ở máy quét, và gửi trùng lên server thì nhật
  /// ký có hai dòng cho một pallet với dòng thứ hai bằng 0 con.
  void _onScan(String raw) {
    final code = raw.trim();
    if (code.isEmpty || _saving) return;

    final dup = _lots.any((x) => x.toLowerCase() == code.toLowerCase());
    if (dup) {
      // error() chứ không phải success(): mã này KHÔNG được nhận, và tiếng
      // bíp là thứ duy nhất WH nghe được khi mắt đang nhìn pallet.
      ref.read(appFeedbackProvider).error();
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_back_scan_dup.tr(namedArgs: {'lot': code}),
      );
      return;
    }

    ref.read(appFeedbackProvider).success();
    setState(() => _lots.add(code));
  }

  void _remove(int ix) {
    if (ix < 0 || ix >= _lots.length) return;
    setState(() => _lots.removeAt(ix));
  }

  Future<void> _submit() async {
    if (_saving || _lots.isEmpty) return;

    final ok = await showConfirmDialog(
      context,
      title: LocaleKeys.return_back_confirm_title.tr(),
      message: LocaleKeys.return_back_confirm_msg.tr(namedArgs: {
        'count': '${_lots.length}',
        'reqNo': _req.reqNo,
      }),
      confirmLabel: LocaleKeys.return_back_confirm_ok.tr(),
      confirmVariant: AppButtonVariant.success,
    );
    if (!ok || !mounted) return;

    setState(() => _saving = true);
    try {
      // Lỗi API đã được appActionProvider bắt + toast → null.
      final res = await ref.read(appActionProvider.notifier).run(
            () => ref.read(returnBackRepositoryProvider).deliver(
                  id: _req.id,
                  lotNos: List<String>.from(_lots),
                ),
          );
      if (!mounted || res == null) return;

      setState(() {
        _last = res;
        _req = res.request ?? _req;
        // Chỉ xoá danh sách khi server ĐÃ nhận: xoá trước rồi gọi hỏng là WH
        // phải quét lại cả xe.
        _lots.clear();
        if (res.anyMoved) _changed = true;
      });

      ref.invalidate(backDeliveriesProvider(_req.id));

      if (res.completed) {
        AppToastHelper.toastSuccess(
          context,
          LocaleKeys.return_back_done_all.tr(namedArgs: {'reqNo': _req.reqNo}),
        );
        // Giao xong cả đề nghị thì không còn gì để quét — đóng màn luôn.
        Navigator.of(context).pop(true);
        return;
      }

      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_back_done_round.tr(namedArgs: {
          'qty': '${res.deliveredQty}',
          'remain': '${res.remainQty}',
        }),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        // Còn mã đã quét mà chưa gửi: hỏi lại. Thoát im lặng ở đây là mất cả
        // một xe hàng vừa quét mà không ai biết.
        if (_lots.isNotEmpty && !_saving) {
          final leave = await showConfirmDialog(
            context,
            title: LocaleKeys.return_back_leave_title.tr(),
            message: LocaleKeys.return_back_leave_msg
                .tr(namedArgs: {'count': '${_lots.length}'}),
            confirmLabel: LocaleKeys.return_back_leave_ok.tr(),
            confirmVariant: AppButtonVariant.danger,
          );
          if (!leave || !mounted) return;
        }
        if (mounted) Navigator.of(context).pop(_changed);
      },
      child: Scaffold(
        appBar: AppTopBar(
          title: LocaleKeys.return_back_scan_title.tr(),
          subtitle: '${_req.reqNo} · ${_req.docNo ?? ''}',
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(AppDimens.md),
                children: [
                  _Summary(req: _req, scanned: _lots.length),
                  const SizedBox(height: AppDimens.sm),

                  BarcodeScannerButton(
                    state:
                        _saving ? ScannerState.loading : ScannerState.scanning,
                    scanningLabel: LocaleKeys.return_back_scan_label.tr(),
                    loadingLabel: LocaleKeys.return_back_scan_saving.tr(),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.arrow_upward_rounded, size: 14, color: c.text3),
                      const SizedBox(width: 4),
                      Flexible(
                        child: Text(
                          LocaleKeys.return_back_scan_hint.tr(),
                          textAlign: TextAlign.center,
                          style: AppTextStyles.caption.copyWith(color: c.text2),
                        ),
                      ),
                    ],
                  ),

                  if (_last case final r?) ...[
                    const SizedBox(height: AppDimens.sm),
                    _LastRound(result: r),
                  ],

                  if (_lots.isNotEmpty) ...[
                    const SizedBox(height: AppDimens.sm),
                    _ScannedList(lots: _lots, onRemove: _remove),
                  ],

                  const SizedBox(height: AppDimens.sm),
                  _DeliveredLog(requestId: _req.id),
                ],
              ),
            ),

            // CTA ghim đáy màn: WH đeo găng, nút phải ở chỗ ngón tay vẫn tới
            // được mà không cuộn.
            Padding(
              padding: const EdgeInsets.all(AppDimens.md),
              child: AppButton(
                label: _lots.isEmpty
                    ? LocaleKeys.return_back_btn_submit_empty.tr()
                    : LocaleKeys.return_back_btn_submit
                        .tr(namedArgs: {'count': '${_lots.length}'}),
                variant: AppButtonVariant.success,
                size: AppButtonSize.lg,
                icon: Icons.local_shipping_outlined,
                isLoading: _saving,
                onPressed: _lots.isEmpty ? null : _submit,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ── Các khối nhỏ ────────────────────────────────────────────

class _Summary extends StatelessWidget {
  const _Summary({required this.req, required this.scanned});

  final BackRequest req;
  final int scanned;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  LocaleKeys.return_back_remain_pcs
                      .tr(namedArgs: {'qty': '${req.remainQty}'}),
                  style: AppTextStyles.label.copyWith(
                    fontWeight: FontWeight.w700,
                    color: req.remainQty > 0 ? c.warning : c.success,
                  ),
                ),
              ),
              Text(
                LocaleKeys.return_back_scanned_count
                    .tr(namedArgs: {'count': '$scanned'}),
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            ],
          ),
          const SizedBox(height: 6),
          // Bảng model để WH soát "đúng hàng này không" trước khi đẩy pallet.
          for (final l in req.lines)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      l.model,
                      style: AppTextStyles.code
                          .copyWith(fontSize: 12, color: c.text1),
                    ),
                  ),
                  Text(
                    '${l.deliveredQty}/${l.qty}',
                    style: AppTextStyles.label.copyWith(
                      fontWeight: FontWeight.w700,
                      color: l.isDone ? c.success : c.text2,
                    ),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Kết quả lượt vừa xác nhận. Mã sai và pallet rỗng là thứ WH phải đọc rồi đi
/// kiểm lại, nên để ngay trên màn chứ không chỉ một toast rồi biến mất.
class _LastRound extends StatelessWidget {
  const _LastRound({required this.result});

  final BackDeliverResult result;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_back_round_result.tr(namedArgs: {
              'qty': '${result.deliveredQty}',
              'pallets': '${result.pallets.length}',
            }),
            style: AppTextStyles.label.copyWith(
              fontWeight: FontWeight.w700,
              color: result.anyMoved ? c.success : c.warning,
            ),
          ),
          if (result.notFoundLots.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              LocaleKeys.return_back_lots_not_found
                  .tr(namedArgs: {'lots': result.notFoundLots.join(', ')}),
              style: AppTextStyles.caption.copyWith(color: c.danger),
            ),
          ],
          if (result.emptyLots.isNotEmpty) ...[
            const SizedBox(height: 4),
            Text(
              LocaleKeys.return_back_lots_empty
                  .tr(namedArgs: {'lots': result.emptyLots.join(', ')}),
              style: AppTextStyles.caption.copyWith(color: c.warning),
            ),
          ],
        ],
      ),
    );
  }
}

class _ScannedList extends StatelessWidget {
  const _ScannedList({required this.lots, required this.onRemove});

  final List<String> lots;
  final ValueChanged<int> onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_back_scanned_title.tr(),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
          for (var i = 0; i < lots.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  SizedBox(
                    width: 22,
                    child: Text('${i + 1}',
                        style:
                            AppTextStyles.caption.copyWith(color: c.text3)),
                  ),
                  Expanded(
                    child: Text(
                      lots[i],
                      style: AppTextStyles.code
                          .copyWith(fontSize: 13, color: c.text1),
                    ),
                  ),
                  // Xoá được từng mã: quét nhầm pallet của phiếu khác là
                  // chuyện xảy ra, mà bắt quét lại cả xe thì không ai chịu.
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    constraints: const BoxConstraints(minWidth: 36, minHeight: 36),
                    icon: Icon(Icons.close_rounded, size: 18, color: c.text3),
                    onPressed: () => onRemove(i),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Nhật ký pallet đã giao — giao dần nhiều lượt thì đây là chỗ duy nhất trả
/// lời "đã đẩy những pallet nào rồi".
class _DeliveredLog extends ConsumerWidget {
  const _DeliveredLog({required this.requestId});

  final int requestId;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.swms;
    final async = ref.watch(backDeliveriesProvider(requestId));

    final rows = async.valueOrNull ?? const <BackDelivery>[];
    // Chưa giao gì thì không dựng thẻ rỗng. Lỗi tải nhật ký cũng im lặng: đây
    // là thông tin tham khảo, một khối đỏ ở đây làm WH tưởng lượt quét hỏng.
    if (rows.isEmpty) return const SizedBox.shrink();

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_back_log_title.tr(),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
          for (final d in rows)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Expanded(
                    child: Text(
                      d.lotNo,
                      style: AppTextStyles.code
                          .copyWith(fontSize: 12, color: c.text1),
                    ),
                  ),
                  Text(
                    LocaleKeys.return_back_qty_pcs
                        .tr(namedArgs: {'qty': '${d.serialCount}'}),
                    style: AppTextStyles.caption.copyWith(color: c.text2),
                  ),
                  const SizedBox(width: 8),
                  Text(
                    DateFormat('dd/MM HH:mm').format(d.deliveredAt),
                    style: AppTextStyles.caption.copyWith(color: c.text3),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
