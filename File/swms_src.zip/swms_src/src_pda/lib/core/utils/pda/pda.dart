abstract interface class PdaDevice {
  Future<void> initialize();

  /// Stream phát ra dữ liệu thô mỗi lần scan.
  Stream<String> get scanStream;

  void dispose();
}