﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    /// <summary>
    /// Trạng thái xử lý của mỗi bộ phận (IQC / PUS / MCS)
    /// </summary>
    public enum ConfirmStatus : byte
    {
        All = 0,  // Tất cả (mặc định)
        Processing = 1,  // Chưa xác nhận
        Confirmed = 2,  // Đã xác nhận, chờ phê duyệt
        Approved = 3,  // Đã phê duyệt
    }

    public class AbnormalReportFilter : BaseFilter
    {
        public string? ManagementNumber { get; set; }
        public string? PartNumber { get; set; }
        public string? Supplier { get; set; }
        public IEnumerable<string> VendorCodes { get; set; } = new List<string>();
        public DateTime? DiscoveryDate { get; set; }

        // 0=Draft, 1=Processing, 2=Completed
        public byte? ReportStatus { get; set; }

        // ── IQC ──────────────────────────────────────────────
        // 1=OK, 2=NG
        public byte? IQCResult { get; set; }
        public ConfirmStatus IQCStatus { get; set; } = ConfirmStatus.All;

        // ── PUS ──────────────────────────────────────────────
        // 1=PSNV, 2=NCC
        public byte? PUSAction { get; set; }
        public ConfirmStatus PUSStatus { get; set; } = ConfirmStatus.All;

        // ── MCS ──────────────────────────────────────────────
        public ConfirmStatus MCSStatus { get; set; } = ConfirmStatus.All;

        // ── Paging ───────────────────────────────────────────
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 20;

        public IEnumerable<string> NormalizedVendorCodes =>
    (VendorCodes ?? new List<string>())
        .Where(v => !string.IsNullOrWhiteSpace(v))
        .Select(v => v.Trim().ToUpperInvariant())
        .Distinct();

        public bool HasVendorFilter => NormalizedVendorCodes.Any();
    }
}