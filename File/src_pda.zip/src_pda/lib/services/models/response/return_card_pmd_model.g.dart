// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_card_pmd_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReturnCardPmdModel _$ReturnCardPmdModelFromJson(Map<String, dynamic> json) =>
    ReturnCardPmdModel(
      id: (json['id'] as num).toInt(),
      section: json['section'] as String?,
      material: json['material'] as String?,
      model: json['model'] as String?,
      machine: json['machine'] as String?,
      typeCard: json['typeCard'] as String?,
      statusRecycle: json['statusRecycle'] as String?,
      barcode: json['barcode'] as String?,
      quantity: (json['quantity'] as num).toDouble(),
      unit: json['unit'] as String?,
      sloc: json['sloc'] as String?,
      kittingCardID: (json['kittingCardID'] as num).toInt(),
      dateTimeInsert: DateTime.parse(json['dateTimeInsert'] as String),
      userIDInsert: json['userIDInsert'] as String?,
      dateTimeUpdate: json['dateTimeUpdate'] == null
          ? null
          : DateTime.parse(json['dateTimeUpdate'] as String),
      userIDUpdate: json['userIDUpdate'] as String?,
      statusTranferSAP: (json['statusTranferSAP'] as num?)?.toInt(),
      dateTimeTranferSAP: json['dateTimeTranferSAP'] == null
          ? null
          : DateTime.parse(json['dateTimeTranferSAP'] as String),
      flagDelete: (json['flagDelete'] as num).toInt(),
    );

Map<String, dynamic> _$ReturnCardPmdModelToJson(ReturnCardPmdModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'section': instance.section,
      'material': instance.material,
      'model': instance.model,
      'machine': instance.machine,
      'typeCard': instance.typeCard,
      'statusRecycle': instance.statusRecycle,
      'barcode': instance.barcode,
      'quantity': instance.quantity,
      'unit': instance.unit,
      'sloc': instance.sloc,
      'kittingCardID': instance.kittingCardID,
      'dateTimeInsert': instance.dateTimeInsert.toIso8601String(),
      'userIDInsert': instance.userIDInsert,
      'dateTimeUpdate': instance.dateTimeUpdate?.toIso8601String(),
      'userIDUpdate': instance.userIDUpdate,
      'statusTranferSAP': instance.statusTranferSAP,
      'dateTimeTranferSAP': instance.dateTimeTranferSAP?.toIso8601String(),
      'flagDelete': instance.flagDelete,
    };
