using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>Bộ lọc danh sách chỉ thị back hàng.</summary>
public record ReturnInstructionQuery
{
    /// <summary>open | completed | cancelled. Bỏ trống = tất cả.</summary>
    public string? Status { get; init; }

    /// <summary>rework | refurbish. Lọc thẳng trên loại của phiếu.</summary>
    public string? GoodsType { get; init; }

    /// <summary>Khớp số phiếu, khách hàng, hoặc model của dòng bất kỳ.</summary>
    public string? Keyword { get; init; }

    /// <summary>Lọc theo ngày hàng về dự kiến (bao gồm hai đầu).</summary>
    public DateTime? FromDate { get; init; }
    public DateTime? ToDate { get; init; }
}

/// <summary>Một dòng model + SL khi tạo / sửa phiếu.</summary>
public record ReturnInstructionLineRequest
{
    [Required, MaxLength(100)]
    public string Model { get; set; } = string.Empty;

    [Range(1, int.MaxValue)]
    public int Qty { get; set; }

    [MaxLength(500)]
    public string? Note { get; set; }
}

/// <summary>
/// Tạo / sửa chỉ thị. Gửi NGUYÊN danh sách dòng mong muốn, không gửi từng
/// thao tác thêm-sửa-xoá: màn hình là một bảng nhập, người dùng sửa vài ô rồi
/// bấm Lưu một lần, nên server thay cả cụm dòng cho khớp đúng thứ đang hiện
/// trên màn hình.
/// </summary>
public record ReturnInstructionRequest
{
    /// <summary>
    /// rework | refurbish. MỘT PHIẾU MỘT LOẠI — khách báo cả hai loại thì tạo
    /// hai phiếu, vì số phiếu mang tiền tố theo loại (RW- / RB-).
    /// </summary>
    [Required, MaxLength(20)]
    public string GoodsType { get; set; } = string.Empty;

    [MaxLength(200)]
    public string? Customer { get; set; }

    public DateTime? ExpectedDate { get; set; }

    [MaxLength(500)]
    public string? Note { get; set; }

    [Required]
    [MinLength(1, ErrorMessage = "Phiếu phải có ít nhất một dòng.")]
    public List<ReturnInstructionLineRequest> Lines { get; set; } = [];
}

// ── Mục 2a: WH nhận hàng, quét thùng + serial ─────────────────

/// <summary>
/// Một thùng WH vừa quét: mã thùng, model của thùng, và các serial trong nó.
///
/// Model nằm ở THÙNG chứ không ở từng serial: serial in trên sản phẩm không
/// cho biết model, WH chọn model rồi quét hết serial của thùng đó. Một pallet
/// được nhiều thùng nhiều model, miễn các model cùng category (Pallet ID nhúng
/// mã category trong 12 số nên không thể lẫn category).
/// </summary>
public record ReceiveReturnBoxRequest
{
    /// <summary>
    /// Mã thùng quét được. Bỏ trống khi hàng về rời không còn thùng — server tự
    /// đặt <c>{PalletId}-01</c>, <c>-02</c>… để mỗi thùng vẫn có mã riêng.
    /// </summary>
    [MaxLength(50)]
    public string? BoxNo { get; set; }

    [Required, MaxLength(100)]
    public string Model { get; set; } = string.Empty;

    /// <summary>Serial in trên từng sản phẩm trong thùng.</summary>
    [Required, MinLength(1)]
    public List<string> Serials { get; set; } = [];
}

/// <summary>
/// WH nhận một pallet hàng return vào phiếu. Server tự cấp Pallet ID (hàng trả
/// về không có nhãn in sẵn) và trả về để PDA in nhãn.
/// </summary>
public record ReceiveReturnRequest
{
    [Required, MinLength(1)]
    public List<ReceiveReturnBoxRequest> Boxes { get; set; } = [];
}

/// <summary>Kết quả nhận hàng: pallet vừa tạo + tiến độ phiếu sau khi nhận.</summary>
public record ReceiveReturnResponse(
    long PalletId,
    string LotNo,
    int CategoryCode,
    int BoxCount,
    int SerialCount,

    // true = ít nhất một model đã nhận vượt SL chỉ thị. Cảnh báo, không phải lỗi.
    bool OverReceived,

    // Phiếu đã cập nhật SL thực nhận — PDA vẽ lại tiến độ không cần gọi lại.
    ReturnInstructionResponse Doc);

/// <summary>Một pallet hàng return đã nhận vào phiếu.</summary>
public record ReturnPalletResponse(
    long Id,
    string LotNo,
    string? LocatorCode,
    int BoxCount,
    int SerialCount,
    DateTime CreatedAt,
    string? CreatedBy,
    List<ReturnPalletModelResponse> Models)
{
    public static ReturnPalletResponse From(ReturnPallet p) => new(
        p.Id, p.LotNo, p.LocatorCode, p.BoxCount, p.SerialCount, p.CreatedAt, p.CreatedBy,
        p.ModelCounts.Select(kv => new ReturnPalletModelResponse(kv.Key, kv.Value))
                     .OrderBy(m => m.Model, StringComparer.OrdinalIgnoreCase).ToList());
}

public record ReturnPalletModelResponse(string Model, int SerialCount);

/// <summary>Một serial trong sổ của phiếu.</summary>
public record ReturnSerialResponse(
    long Id,
    string Model,
    string SerialNo,
    string? BoxNo,
    string? PalletNo,
    string Status,
    DateTime ReceivedAt,
    string? CreatedBy)
{
    public static ReturnSerialResponse From(ReturnSerial s) =>
        new(s.Id, s.Model, s.SerialNo, s.BoxNo, s.PalletNo, s.Status, s.ReceivedAt, s.CreatedBy);
}

// ── Response phiếu ────────────────────────────────────────────

public record ReturnInstructionLineResponse(
    long Id,
    int LineNo,
    string Model,
    int Qty,

    // SL thực nhận — số serial đã quét vào phiếu cho model này.
    int ReceivedQty,

    // Còn phải nhận. Âm = đã nhận vượt.
    int RemainingQty,

    // Lệch = thực nhận − chỉ thị. Dương vượt, âm thiếu, 0 đủ. Bảng đối chiếu
    // và mail báo FA đọc con số này.
    int DiffQty,

    // Vòng đi–về với FA. AtFaQty = đã chỉ thị giao (2c), FA chưa giao lại;
    // ReturnedQty = FA đã giao lại và SCS đã nhận (mục 3).
    int AtFaQty,
    int ReturnedQty,

    string? Note)
{
    public static ReturnInstructionLineResponse From(ReturnInstructionLine l) =>
        new(l.Id, l.LineNo, l.Model, l.Qty, l.ReceivedQty, l.RemainingQty, l.DiffQty,
            l.AtFaQty, l.ReturnedQty, l.Note);
}

public record ReturnInstructionResponse(
    long Id,
    string DocNo,
    string GoodsType,
    string? Customer,
    DateTime? ExpectedDate,
    string DocStatus,
    string? Note,
    int ModelCount,
    int TotalQty,

    // SL thực nhận của cả phiếu = số serial đã quét vào (mục 2a).
    int ReceivedQty,

    // true = có model nhận vượt chỉ thị. Màn hình hiện cảnh báo, không chặn.
    bool OverReceived,

    // true = có model nhận thiếu. Cũng không chặn — việc của hệ thống là báo
    // FA số thực, không phải bắt hàng về cho đúng.
    bool ShortReceived,

    // Lệch cả phiếu = thực nhận − chỉ thị.
    int DiffQty,

    // Vòng đi–về với FA, tổng cả phiếu. Màn Web cần AtFaQty để biết còn hàng
    // ngoài kho hay không: phiếu đã chốt mà không hiện con số này thì nhìn vào
    // tưởng đã xong việc.
    int AtFaQty,
    int ReturnedQty,

    DateTime? MailSentAt,
    string? MailSentTo,

    // Mục 2b: mốc WH chốt thực nhận, và dấu vết mail BÁO SỐ THỰC NHẬN (khác
    // MailSentAt — mail lúc tạo phiếu).
    DateTime? ClosedAt,
    string? ClosedBy,
    DateTime? ActualMailSentAt,
    string? ActualMailSentTo,
    DateTime CreatedAt,
    string? CreatedBy,
    DateTime? UpdatedAt,
    string? UpdatedBy,
    List<ReturnInstructionLineResponse> Lines)
{
    public static ReturnInstructionResponse From(ReturnInstruction d) => new(
        d.Id, d.DocNo, d.GoodsType, d.Customer, d.ExpectedDate, d.DocStatus, d.Note,
        d.ModelCount, d.TotalQty, d.ReceivedQty, d.OverReceived, d.ShortReceived, d.DiffQty,
        d.AtFaQty, d.ReturnedQty,
        d.MailSentAt, d.MailSentTo,
        d.ClosedAt, d.ClosedBy, d.ActualMailSentAt, d.ActualMailSentTo,
        d.CreatedAt, d.CreatedBy, d.UpdatedAt, d.UpdatedBy,
        d.Lines.Select(ReturnInstructionLineResponse.From).ToList());
}

/// <summary>Khoá dịch thông báo lỗi của riêng feature này.</summary>
public static class ReturnMsg
{
    public const string NotFound = "Return.Err.NotFound";
    public const string StatusInvalid = "Return.Err.StatusInvalid";
    public const string GoodsTypeInvalid = "Return.Err.GoodsTypeInvalid";
    public const string LinesRequired = "Return.Err.LinesRequired";
    public const string TooManyLines = "Return.Err.TooManyLines";
    public const string ModelRequired = "Return.Err.ModelRequired";

    /// <summary>Model không có trong master.models.</summary>
    public const string ModelNotFound = "Return.Err.ModelNotFound";

    /// <summary>Hai dòng cùng một model trong một phiếu.</summary>
    public const string DuplicateLine = "Return.Err.DuplicateLine";

    public const string QtyInvalid = "Return.Err.QtyInvalid";

    /// <summary>Phiếu đã huỷ / đã đóng thì không sửa được nữa.</summary>
    public const string NotEditable = "Return.Err.NotEditable";

    /// <summary>Đổi loại hàng sau khi đã cấp số phiếu — tiền tố sẽ nói sai.</summary>
    public const string GoodsTypeLocked = "Return.Err.GoodsTypeLocked";

    // ── Mục 2a: WH nhận hàng ──

    /// <summary>Phiếu không còn mở nên không nhận thêm hàng vào được.</summary>
    public const string DocNotOpen = "Return.Err.DocNotOpen";

    /// <summary>Request không có thùng nào.</summary>
    public const string BoxesRequired = "Return.Err.BoxesRequired";

    /// <summary>Thùng không có serial nào.</summary>
    public const string SerialRequired = "Return.Err.SerialRequired";

    /// <summary>Quá nhiều serial trong một lần nhận.</summary>
    public const string TooManySerials = "Return.Err.TooManySerials";

    /// <summary>Cùng một serial xuất hiện hai lần trong chính request này.</summary>
    public const string SerialDuplicatedInRequest = "Return.Err.SerialDuplicatedInRequest";

    /// <summary>Serial đã quét vào phiếu này trước đó.</summary>
    public const string SerialAlreadyReceived = "Return.Err.SerialAlreadyReceived";

    /// <summary>Serial đang thuộc một phiếu khác — đây là cái chặn "serial lạ".</summary>
    public const string SerialOnOtherDoc = "Return.Err.SerialOnOtherDoc";

    /// <summary>Hai máy quét cùng một serial cùng lúc, máy sau thua.</summary>
    public const string SerialRaceLost = "Return.Err.SerialRaceLost";

    /// <summary>Model quét không có trong phiếu.</summary>
    public const string ModelNotInDoc = "Return.Err.ModelNotInDoc";

    /// <summary>Model trong phiếu nhưng chưa khai category trong danh mục.</summary>
    public const string CategoryUnknown = "Return.Err.CategoryUnknown";

    /// <summary>Một pallet lẫn model của hai category — Pallet ID không nhúng được cả hai.</summary>
    public const string CategoryMixed = "Return.Err.CategoryMixed";

    /// <summary>Hai thùng trong cùng một lần nhận mang cùng một mã.</summary>
    public const string BoxNoDuplicated = "Return.Err.BoxNoDuplicated";

    /// <summary>Quá nhiều thùng trong một lần nhận.</summary>
    public const string TooManyBoxes = "Return.Err.TooManyBoxes";

    /// <summary>Serial / model dài hơn chỗ chứa được.</summary>
    public const string ValueTooLong = "Return.Err.ValueTooLong";

    /// <summary>Xoá phiếu đã nhận hàng.</summary>
    public const string DocHasSerials = "Return.Err.DocHasSerials";

    /// <summary>Bỏ một model đã có serial trong sổ ra khỏi phiếu.</summary>
    public const string ModelHasSerials = "Return.Err.ModelHasSerials";

    /// <summary>Pallet không thuộc phiếu này.</summary>
    public const string PalletNotInDoc = "Return.Err.PalletNotInDoc";

    // ── Mục 2b: chốt thực nhận ──

    /// <summary>Chốt phiếu chưa nhận được con nào.</summary>
    public const string NothingReceived = "Return.Err.NothingReceived";

    /// <summary>Mở lại phiếu chưa chốt.</summary>
    public const string NotClosed = "Return.Err.NotClosed";
}
