import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/features/storage_map/domain/entities/storage_map_entities.dart';
import 'package:swms_finish_goods/features/storage_map/presentation/providers/storage_map_providers.dart';
import 'package:swms_finish_goods/features/storage_map/presentation/widgets/status_colors.dart';

/// Mặt cắt 1 kệ (bottom sheet): lưới vị trí × tầng + chạm ô xem chi tiết/tình trạng.
class RackElevationSheet extends ConsumerStatefulWidget {
  final String rackCode;

  /// Mã ô cần chỉ ra (mở từ gợi ý Lưu kho): chọn sẵn, cuộn tới và đánh dấu riêng.
  final String? focusLocatorCode;

  const RackElevationSheet({super.key, required this.rackCode, this.focusLocatorCode});

  @override
  ConsumerState<RackElevationSheet> createState() => _RackElevationSheetState();
}

const _cSelBorder = Color(0xFF2F6FB0);
const _cBorder = Color(0xFFD3DBE3);
const _cEmptyBg = Color(0xFFF6F9FB);
const _cXbg = Color(0xFFEFF2F5);
const _cStop = Color(0xFFD9534F);
const _cRefurb = Color(0xFFE0A24A);
const _cRework = Color(0xFF8A5CD0);
const _cOccPallet = Color(0xFFB07A3D);
const _cEmptyPallet = Color(0xFFD5DBE1);

class _RackElevationSheetState extends ConsumerState<RackElevationSheet> {
  ElevationCell? _sel;

  final _hScroll = ScrollController();
  bool _focusApplied = false;

  /// Trùng màu chỉ vị trí đích trên sơ đồ (hồng cánh sen) để người dùng nhận ra ngay.
  static const Color _cFocus = Color(0xFFE6007E);

  @override
  void dispose() {
    _hScroll.dispose();
    super.dispose();
  }

  /// Serial của pallet đang xem; null = chưa tải xong.
  List<PalletSerial>? _serials;
  String? _serialsOf;   // mã pallet ứng với _serials
  bool _serialsError = false;

  void _select(ElevationCell c) {
    setState(() {
      _sel = c;
      _serials = null;
      _serialsError = false;
      _serialsOf = c.palletId;
    });
    final code = c.palletId;
    if (code == null || code.isEmpty) return;
    _loadSerials(code);
  }

  Future<void> _loadSerials(String palletCode) async {
    try {
      final rows = await ref.read(storageMapRepositoryProvider).serials(palletCode);
      if (!mounted || _serialsOf != palletCode) return;
      setState(() => _serials = rows);
    } catch (_) {
      if (!mounted || _serialsOf != palletCode) return;
      setState(() => _serialsError = true);
    }
  }

  bool _isFocus(ElevationCell c) =>
      widget.focusLocatorCode != null && c.locatorCode == widget.focusLocatorCode;

  /// Lần đầu có dữ liệu: chọn sẵn ô đích và cuộn ngang tới cột của nó.
  void _applyFocus(RackElevation elev) {
    if (_focusApplied || widget.focusLocatorCode == null) return;
    _focusApplied = true;
    ElevationCell? target;
    for (final c in elev.cells) {
      if (_isFocus(c)) { target = c; break; }
    }
    if (target == null) return;
    _sel = target;
    _serialsOf = target.palletId;
    if (target.palletId != null && target.palletId!.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) => _loadSerials(target!.palletId!));
    }
    final loc = target.location;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!_hScroll.hasClients) return;
      final x = ((loc - 1) * _cw - _cw).clamp(0.0, _hScroll.position.maxScrollExtent);
      _hScroll.animateTo(x, duration: const Duration(milliseconds: 350), curve: Curves.easeOutCubic);
    });
  }

  static const double _cw = 68; // rộng ô
  static const double _ch = 86; // cao ô
  static const double _lead = 26; // cột nhãn tầng

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(rackElevationProvider(widget.rackCode));
    return DraggableScrollableSheet(
      initialChildSize: 0.8,
      minChildSize: 0.45,
      maxChildSize: 0.96,
      expand: false,
      builder: (context, controller) => Container(
        decoration: const BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.vertical(top: Radius.circular(18)),
        ),
        child: Column(
          children: [
            Container(
              margin: const EdgeInsets.only(top: 8),
              width: 42,
              height: 4,
              decoration: BoxDecoration(
                color: Colors.black26,
                borderRadius: BorderRadius.circular(2),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(18, 8, 8, 6),
              child: Row(
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        LocaleKeys.storage_map_rack_title.tr(
                          args: [widget.rackCode],
                        ),
                        style: const TextStyle(
                          fontSize: 19,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      Text(
                        LocaleKeys.storage_map_tap_cell.tr(),
                        style: const TextStyle(
                          fontSize: 12,
                          color: Colors.black45,
                        ),
                      ),
                    ],
                  ),
                  const Spacer(),
                  IconButton(
                    icon: const Icon(Icons.close),
                    onPressed: () => Navigator.of(context).pop(),
                  ),
                ],
              ),
            ),
            Expanded(
              child: async.when(
                loading: () => const Center(child: CircularProgressIndicator()),
                error: (e, _) => Center(
                  child: Padding(
                    padding: const EdgeInsets.all(24),
                    child: Text('$e'),
                  ),
                ),
                data: (elev) => ListView(
                  controller: controller,
                  padding: const EdgeInsets.fromLTRB(14, 4, 14, 28),
                  children: [
                    _legend(elev),
                    const SizedBox(height: 8),
                    _grid(elev),
                    const SizedBox(height: 14),
                    _detail(),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Thứ tự hiển thị trạng thái trong chú thích.
  static const _statusOrder = [
    'not_inspected',
    'under_inspection',
    'pending_result',
    'inspection_exempt',
    'pass',
    'ng',
  ];

  /// Chú thích chỉ liệt kê những gì ĐANG CÓ trong kệ này — kho lưu thực tế
  /// chỉ dùng vài trạng thái, không cần bày hết bảng màu.
  Widget _legend(RackElevation elev) {
    final present = elev.cells.where((c) => c.occupied).toList();
    final statuses = _statusOrder.where(
      (st) => present.any((c) => c.status == st),
    );
    return Wrap(
      spacing: 12,
      runSpacing: 4,
      children: [
        for (final st in statuses)
          _lg(statusColors(st).bg, 'inspection_status.$st'.tr(), border: statusColors(st).border),
        _lg(_cEmptyBg, LocaleKeys.storage_map_empty.tr()),
        if (present.any((c) => c.stopShipment))
          _lg(_cStop, '🔒 ${LocaleKeys.storage_map_stop.tr()}'),
        // RB chứ không phải RE: giữ khớp với badge in trên TEM PALLET
        // (QrLabelData.badgeForDisposition) và với bản đồ kho bên web
        // (RackElevation.DispCode). Người trong kho đọc tem rồi đối chiếu
        // bản đồ — hai chỗ ghi khác nhau là họ phải dịch trong đầu.
        if (present.any((c) => c.disposition == 'refurbish')) _lg(_cRefurb, 'RB'),
        if (present.any((c) => c.disposition == 'rework')) _lg(_cRework, 'RW'),
      ],
    );
  }

  Widget _lg(Color c, String t, {Color? border}) => Row(
    mainAxisSize: MainAxisSize.min,
    children: [
      Container(
        width: 12,
        height: 12,
        decoration: BoxDecoration(
          color: c,
          borderRadius: BorderRadius.circular(3),
          border: Border.all(color: border ?? _cBorder),
        ),
      ),
      const SizedBox(width: 4),
      Text(t, style: const TextStyle(fontSize: 11)),
    ],
  );

  Widget _grid(RackElevation elev) {
    _applyFocus(elev);
    final map = <String, List<ElevationCell>>{};
    var maxLoc = 0, maxFl = 0;
    for (final c in elev.cells) {
      map.putIfAbsent('${c.location}-${c.floor}', () => []).add(c);
      if (c.location > maxLoc) maxLoc = c.location;
      if (c.floor > maxFl) maxFl = c.floor;
    }
    return SingleChildScrollView(
      controller: _hScroll,
      scrollDirection: Axis.horizontal,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              const SizedBox(width: _lead),
              for (int loc = 1; loc <= maxLoc; loc++)
                SizedBox(
                  width: _cw,
                  child: Center(
                    child: Text(
                      '$loc',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 2),
          for (int fl = maxFl; fl >= 1; fl--)
            Row(
              children: [
                SizedBox(
                  width: _lead,
                  height: _ch,
                  child: Center(
                    child: Text(
                      '$fl',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                        color: Colors.black54,
                      ),
                    ),
                  ),
                ),
                for (int loc = 1; loc <= maxLoc; loc++)
                  _cell(map['$loc-$fl'] ?? const [], loc, fl),
              ],
            ),
        ],
      ),
    );
  }

  Widget _cell(List<ElevationCell> cells, int loc, int fl) {
    if (cells.isEmpty) {
      return Container(
        width: _cw,
        height: _ch,
        margin: const EdgeInsets.all(2),
        decoration: BoxDecoration(
          color: _cXbg,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(color: _cBorder),
        ),
        child: CustomPaint(painter: _CrossPainter()),
      );
    }
    if (cells.first.isShelf) {
      final b = cells.firstWhere(
        (c) => c.level == 'B',
        orElse: () => cells.first,
      );
      final a = cells.firstWhere(
        (c) => c.level == 'A',
        orElse: () => cells.last,
      );
      return SizedBox(
        width: _cw,
        height: _ch,
        child: Padding(
          padding: const EdgeInsets.all(2),
          child: Column(
            children: [
              Expanded(child: _slot(b, 'B')),
              const SizedBox(height: 3),
              Expanded(child: _slot(a, 'A')),
            ],
          ),
        ),
      );
    }
    return SizedBox(
      width: _cw,
      height: _ch,
      child: Padding(
        padding: const EdgeInsets.all(2),
        child: _slot(cells.first, null),
      ),
    );
  }

  Widget _slot(ElevationCell c, String? level) {
    final sel = _sel?.locatorId == c.locatorId;
    final focus = _isFocus(c);
    final disp = _dispColor(c);
    // Lấy mã thật từ dữ liệu — mỗi kho một quy ước (E1-5-1-A hay 1.B12A.3.02).
    final code = c.locatorCode;
    // Nền theo trạng thái kiểm — cùng bảng màu bản đồ Receiving và sơ đồ kho.
    final st = statusColors(c.occupied ? c.status : null);
    return GestureDetector(
      onTap: () => _select(c),
      child: Container(
        clipBehavior: Clip.antiAlias,
        decoration: BoxDecoration(
          color: c.occupied ? st.bg : _cEmptyBg,
          borderRadius: BorderRadius.circular(6),
          border: Border.all(
            color: focus
                ? _cFocus
                : sel
                    ? _cSelBorder
                    : (disp ?? (c.occupied ? st.border : _cBorder)),
            width: focus ? 3 : sel ? 2.5 : (disp != null ? 2 : 1),
          ),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            if (focus)
              const Positioned(
                top: 2,
                right: 2,
                child: Icon(Icons.place, size: 14, color: _cFocus),
              ),
            // minh hoạ pallet (fill — không tràn)
            Padding(
              padding: const EdgeInsets.fromLTRB(5, 5, 5, 4),
              child: CustomPaint(painter: _PalletPainter(c.occupied)),
            ),
            // tên đầy đủ
            Positioned(
              left: 3,
              top: 2,
              right: 3,
              child: FittedBox(
                fit: BoxFit.scaleDown,
                alignment: Alignment.centerLeft,
                child: Text(
                  code,
                  // Nền trạng thái có màu đậm (NG đỏ, miễn kiểm xanh dương) -> lấy
                  // màu chữ của chính bảng màu OQC để luôn đọc được.
                  style: TextStyle(
                    fontSize: 9,
                    color: c.occupied ? st.fg : Colors.black87,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ),
            ),
            // marker giữa
            if (c.occupied &&
                (c.stopShipment ||
                    c.disposition == 'refurbish' ||
                    c.disposition == 'rework'))
              Center(
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    if (c.stopShipment) _mk('🔒', _cStop),
                    if (c.disposition == 'refurbish') _mk('RB', _cRefurb),
                    if (c.disposition == 'rework') _mk('RW', _cRework),
                  ],
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _mk(String t, Color c) => Container(
    margin: const EdgeInsets.symmetric(horizontal: 1),
    padding: const EdgeInsets.symmetric(horizontal: 4, vertical: 2),
    decoration: BoxDecoration(color: c, borderRadius: BorderRadius.circular(4)),
    child: Text(
      t,
      style: const TextStyle(
        fontSize: 11,
        color: Colors.white,
        fontWeight: FontWeight.w800,
      ),
    ),
  );

  Widget _detail() {
    final c = _sel;
    if (c == null) {
      return Container(
        padding: const EdgeInsets.symmetric(vertical: 22),
        alignment: Alignment.center,
        child: Text(
          LocaleKeys.storage_map_tap_cell_hint.tr(),
          style: const TextStyle(color: Colors.black45),
        ),
      );
    }
    final month = c.productionDate == null
        ? '—'
        : '${c.productionDate!.month.toString().padLeft(2, '0')}/${c.productionDate!.year}';
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: const Color(0xFFF7F9FB),
        borderRadius: BorderRadius.circular(14),
        border: Border.all(color: const Color(0xFFE6EAEE)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            c.locatorCode,
            style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 8),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              _badge(
                c.occupied
                    ? LocaleKeys.storage_map_occupied.tr()
                    : LocaleKeys.storage_map_empty.tr(),
                c.occupied ? const Color(0xFF2E8650) : Colors.black45,
              ),
              if (c.stopShipment) _badge('Stop shipment', _cStop),
              if (c.disposition == 'refurbish') _badge('Refurbish', _cRefurb),
              if (c.disposition == 'rework') _badge('Rework', _cRework),
            ],
          ),
          const SizedBox(height: 6),
          _kv(LocaleKeys.storage_map_position.tr(), '${c.location}'),
          _kv(LocaleKeys.storage_map_floor.tr(), '${c.floor}'),
          if (c.occupied) ...[
            const Divider(height: 22),
            Text(
              LocaleKeys.storage_map_current_pallet.tr(),
              style: const TextStyle(
                fontSize: 11,
                letterSpacing: .5,
                fontWeight: FontWeight.w700,
                color: Colors.black45,
              ),
            ),
            const SizedBox(height: 6),
            _kv('Model', c.model ?? '—'),
            _kv(LocaleKeys.storage_map_qty.tr(), c.boxCount?.toString() ?? '—'),
            _kv(
              LocaleKeys.storage_map_pallet_id.tr(),
              c.palletId ?? '—',
              mono: true,
            ),
            _kv(LocaleKeys.storage_map_prod_month.tr(), month),
            const Divider(height: 22),
            _serialList(),
          ] else ...[
            const SizedBox(height: 8),
            Text(
              LocaleKeys.storage_map_no_pallet.tr(),
              style: const TextStyle(color: Colors.black45),
            ),
          ],
        ],
      ),
    );
  }

  /// Serial của từng thùng trong pallet đang xem.
  Widget _serialList() {
    final rows = _serials;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Text(
              LocaleKeys.storage_map_serials.tr(),
              style: const TextStyle(
                fontSize: 11,
                letterSpacing: .5,
                fontWeight: FontWeight.w700,
                color: Colors.black45,
              ),
            ),
            const SizedBox(width: 6),
            if (rows != null)
              Text(
                '(${rows.length})',
                style: const TextStyle(fontSize: 11, color: Colors.black45),
              ),
          ],
        ),
        const SizedBox(height: 6),
        if (_serialsError)
          Text(
            LocaleKeys.storage_map_serials_error.tr(),
            style: const TextStyle(color: Color(0xFFC62828), fontSize: 12),
          )
        else if (rows == null)
          const Padding(
            padding: EdgeInsets.symmetric(vertical: 6),
            child: SizedBox(
              width: 18,
              height: 18,
              child: CircularProgressIndicator(strokeWidth: 2),
            ),
          )
        else if (rows.isEmpty)
          Text(
            LocaleKeys.storage_map_serials_empty.tr(),
            style: const TextStyle(color: Colors.black45, fontSize: 12),
          )
        else
          // Gom theo thùng: mã thùng ghi 1 lần ở tiêu đề, dưới là các serial.
          // Danh sách có thể dài -> giới hạn chiều cao, cuộn trong khung chi tiết.
          ConstrainedBox(
            constraints: const BoxConstraints(maxHeight: 240),
            child: SingleChildScrollView(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final box in _byBox(rows).entries) ...[
                    Padding(
                      padding: const EdgeInsets.only(top: 6, bottom: 2),
                      child: Text(
                        [
                          box.key,
                          if (box.value.first.model != null) box.value.first.model!,
                          '${box.value.length} serial',
                        ].join(' · '),
                        style: const TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w700,
                          color: Color(0xFF5A6B7D),
                        ),
                      ),
                    ),
                    for (final r in box.value)
                      Padding(
                        padding: const EdgeInsets.symmetric(vertical: 2),
                        child: Row(
                          children: [
                            Expanded(
                              child: Text(
                                r.serialNo ?? '—',
                                style: const TextStyle(
                                  fontFamily: 'monospace',
                                  fontWeight: FontWeight.w700,
                                  fontSize: 13,
                                ),
                              ),
                            ),
                            // Serial thường là 1 sản phẩm -> chỉ hiện khi khác 1
                            if (r.qty != null && r.qty != 1)
                              Text(
                                '${r.qty}',
                                style: const TextStyle(fontWeight: FontWeight.w700),
                              ),
                          ],
                        ),
                      ),
                  ],
                ],
              ),
            ),
          ),
      ],
    );
  }

  /// Nhóm serial theo mã thùng, giữ nguyên thứ tự API trả về.
  Map<String, List<PalletSerial>> _byBox(List<PalletSerial> rows) {
    final out = <String, List<PalletSerial>>{};
    for (final r in rows) {
      out.putIfAbsent(r.boxNo ?? '—', () => []).add(r);
    }
    return out;
  }

  Widget _kv(String k, String v, {bool mono = false}) => Padding(
    padding: const EdgeInsets.symmetric(vertical: 3),
    child: Row(
      children: [
        SizedBox(
          width: 92,
          child: Text(k, style: const TextStyle(color: Colors.black54)),
        ),
        Expanded(
          child: Text(v, style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    ),
  );

  Widget _badge(String t, Color c) => Container(
    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
    decoration: BoxDecoration(
      color: c.withValues(alpha: .13),
      borderRadius: BorderRadius.circular(999),
    ),
    child: Text(
      t,
      style: TextStyle(color: c, fontWeight: FontWeight.w700, fontSize: 12),
    ),
  );

  Color? _dispColor(ElevationCell c) {
    if (!c.occupied) return null;
    if (c.stopShipment) return _cStop;
    if (c.disposition == 'refurbish') return _cRefurb;
    if (c.disposition == 'rework') return _cRework;
    return null;
  }
}

/// Vẽ pallet gỗ (deck trên + 3 chân + deck dưới) lấp đầy vùng cho — không tràn.
class _PalletPainter extends CustomPainter {
  final bool occupied;

  _PalletPainter(this.occupied);

  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()..color = occupied ? _cOccPallet : _cEmptyPallet;
    final w = size.width, h = size.height;
    final deck = (h * 0.14).clamp(2.5, 7.0);
    final block = (h * 0.20).clamp(3.0, 9.0);
    // đặt pallet ở đáy ô
    double y = h - deck - block - deck - 1;
    if (y < h * 0.45) y = h * 0.45;
    // deck trên
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, y, w, deck),
        const Radius.circular(1),
      ),
      p,
    );
    // 3 chân
    final bw = w * 0.2;
    final by = y + deck + 1;
    for (final x in [0.0, (w - bw) / 2, w - bw]) {
      canvas.drawRect(Rect.fromLTWH(x, by, bw, block), p);
    }
    // deck dưới
    canvas.drawRRect(
      RRect.fromRectAndRadius(
        Rect.fromLTWH(0, by + block + 1, w, deck),
        const Radius.circular(1),
      ),
      p,
    );
  }

  @override
  bool shouldRepaint(covariant _PalletPainter old) => old.occupied != occupied;
}

class _CrossPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final p = Paint()
      ..color = const Color(0xFFCED6DE)
      ..strokeWidth = 1;
    canvas.drawLine(Offset.zero, Offset(size.width, size.height), p);
    canvas.drawLine(Offset(size.width, 0), Offset(0, size.height), p);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
