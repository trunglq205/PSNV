using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.Pallets.Api
{
    // ── Request ───────────────────────────────────────────────

    /// <summary>
    /// Lưu kho: đặt pallet vào vị trí đích (locatorCode).
    /// Bản chất là gán/chuyển vị trí (Movement 131 → to_location) nên chỉ cần mã vị trí.
    /// </summary>
    public record StoreRequest(
        [Required, MaxLength(50)] string LocatorCode);

    // Response dùng chung LocatorChangeResponse với luồng gán / chuyển vị trí
    // (StoringResponse cũ chỉ là bản thiếu from*).

    // ── Error codes ───────────────────────────────────────────

    /// <summary>Mã lỗi nghiệp vụ của luồng Lưu kho.</summary>
    public static class StoringErrors
    {
        public const string LotNoRequired = "Lot.Storing.LotNoRequired";        // 422
        public const string LocatorCodeRequired = "Lot.Storing.LocatorCodeRequired"; // 422
        public const string AlreadyAtLocator = "Lot.Storing.AlreadyAtLocator";  // 422

        // Điều kiện khu vực — kiểm ở PUT /{id}/storing (trước đây chỉ kiểm ở GET .../storing
        // nên gọi thẳng PUT là lách được).
        public const string PalletNotInTemporaryArea = "Lot.Storing.PalletNotInTemporaryArea"; // 422
        public const string PalletAlreadyStored = "Lot.Storing.PalletAlreadyStored";           // 422
        public const string PalletAlreadyInVanning = "Lot.Storing.PalletAlreadyInVanning";     // 422
    }
}
