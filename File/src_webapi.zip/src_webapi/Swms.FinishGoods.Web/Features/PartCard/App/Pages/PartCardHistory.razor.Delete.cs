using Swms.FinishGoods.Web.Features.PartCard.Business.Models;

namespace Swms.FinishGoods.Web.Features.PartCard.App.Pages;

// Xoá phiếu đã in: 1 phiếu (nút ở dòng / dialog chi tiết) hoặc nhiều phiếu (thanh chọn).
// Cả hai đi chung 1 luồng: mở ConfirmDialog → POST .../bulk-delete → tải lại bảng.
public partial class PartCardHistory
{
    // Target của ConfirmDialog: khác null = dialog đang mở.
    private List<AppPartCardHistory>? _deleteTargets;

    private void AskDelete(AppPartCardHistory p) => _deleteTargets = new() { p };

    // Trong các phiếu đã chọn, chỉ những phiếu người dùng ĐƯỢC xoá (có quyền + chưa khoá)
    // mới đưa vào xoá; nút "Xoá (n)" trên thanh chọn hiện đúng con số này, n = 0 thì ẩn nút.
    private int SelectedDeletableCount => _selected.Count(x => x.CanDelete);

    private void AskDeleteSelected()
    {
        var targets = _selected.Where(x => x.CanDelete).ToList();
        if (targets.Count > 0) _deleteTargets = targets;
    }

    private void CancelDelete() => _deleteTargets = null;

    private string DeleteConfirmText(List<AppPartCardHistory> cards) => cards.Count == 1
        ? L["Common.Delete.ConfirmOne", cards[0].ModelText]
        : L["Common.Delete.ConfirmMany", cards.Count];

    // ConfirmDialog tự khoá nút (và chặn đóng) trong lúc hàm này chạy → không cần cờ busy riêng.
    private async Task ConfirmDeleteAsync(List<AppPartCardHistory> targets)
    {
        if (targets.Count == 0) return;

        var ids = targets.Select(t => t.Id).ToList();
        var r = await Business.DeletePrintHistoryAsync(ids);
        if (!r.IsSuccess)
        {
            // Không xoá _deleteTargets → dialog vẫn mở để thử lại hoặc huỷ.
            Toast.Error(r.ErrorMessage ?? L["Common.Toast.DeleteFailed"]);
            return;
        }

        // Id nằm trong NotFoundIds là phiếu đã bị người khác xoá trước → cũng coi như đã mất.
        var deleted = r.Value?.Deleted ?? ids.Count;
        var missing = r.Value?.NotFoundIds?.Count ?? 0;

        // LockedIds: phiếu bị ai đó khoá sau khi trang này tải (dữ liệu trên màn đã cũ) →
        // API không xoá, phiếu VẪN CÒN. Báo rõ, giữ chúng lại; lần tải lại bên dưới sẽ cập nhật nút.
        var stillLocked = r.Value?.LockedIds ?? new List<long>();
        if (stillLocked.Count > 0)
        {
            var msg = L["PartCardHistory.Toast.DeletedSkipLocked", deleted, stillLocked.Count];
            if (deleted > 0) Toast.Success(msg); else Toast.Error(msg);
        }
        else
        {
            Toast.Success(missing > 0
                ? L["Common.Toast.DeletedPartial", deleted, missing]
                : L["Common.Toast.Deleted", deleted]);
        }

        var gone = ids.Except(stillLocked).ToHashSet();
        _selected.RemoveAll(x => gone.Contains(x.Id));
        _selectedIds.ExceptWith(gone);
        if (_detail is not null && gone.Contains(_detail.Id)) _detail = null;
        _deleteTargets = null;

        // Xoá sạch trang CUỐI → lùi 1 trang, nếu không sẽ đứng ở trang rỗng.
        // InvokeAsync(() => ...) để dùng được dù GoPage của ListPageBase trả void hay Task.
        var removedOnPage = Items.Count(p => gone.Contains(p.Id));
        if (removedOnPage >= Items.Count && Page > 1 && Page >= TotalPages)
            await InvokeAsync(() => GoPage(Page - 1));
        else
            await ReloadAsync();
    }
}