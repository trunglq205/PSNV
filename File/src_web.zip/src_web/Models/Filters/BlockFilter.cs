﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class BlockFilter : BaseFilter
    {
        [Display(Name = "ZoneName")]
        public string? Name { get; set; }
        public long RackId {  get; set; }
        
    }
}
