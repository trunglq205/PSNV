using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Features.Inventory.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.Inventory.Business;

/// <summary>Nghiệp vụ màn Tồn kho — phần SWMS thuần (xem IInventoryBusiness).</summary>
public class InventoryBusiness : BaseBusiness, IInventoryBusiness
{
    private readonly IInventoryApi _api;
    private readonly StockEventCatalog _catalog;

    public InventoryBusiness(
        IInventoryApi api,
        StockEventCatalog catalog,
        ILogger<InventoryBusiness> logger,
        ErrorHandler errorHandler)
        : base(logger, errorHandler)
    {
        _api = api;
        _catalog = catalog;
    }

    public Task<Result<PagedResult<InventoryItemDto>>> GetPagedAsync(InventoryQuery query)
        => ExecuteAsync(() => _api.GetAllAsync(query));

    public Task<Result<List<InventoryAreaDto>>> GetAreasAsync(InventoryQuery query)
        => ExecuteAsync(() => _api.GetAreasAsync(query));

    public Task<Result<List<InventoryAgingBucketDto>>> GetAgingAsync(InventoryQuery query)
        => ExecuteAsync(() => _api.GetAgingAsync(query));

    public Task<Result<InventoryItemDto>> GetByIdAsync(long id)
        => ExecuteAsync(() => _api.GetByIdAsync(id));

    public Task<Result<List<CategoryOptionDto>>> GetCategoryOptionsAsync()
        => ExecuteAsync(() => _api.GetCategoryOptionsAsync());

    public Task<Result<List<AppStockEvent>>> GetHistoryAsync(long id)
        => ExecuteAsync(async () =>
        {
            // Catalog trước, timeline sau: map cần nhãn/màu. Catalog là singleton nên
            // chỉ có request đầu tiên của cả ứng dụng thực sự gọi mạng.
            await _catalog.EnsureLoadedAsync(() => _api.GetEventTypesAsync("pallet")!);

            var history = await _api.GetHistoryAsync(id);

            return history.Events
                .Select(e => StockEventDto.ToViewModel(e, _catalog))
                .ToList();
        });
}
