using System.Data;
using Dapper;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

public class ShipmentInstructionRepository : IShipmentInstructionRepository
{
    private readonly IDbConnectionFactory _factory;

    public ShipmentInstructionRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    // ═══════════════════════════════════════════════════════════════
    //  SQL dùng chung
    // ═══════════════════════════════════════════════════════════════

    private const string HeaderColumns = """
        s.id AS Id, s.doc_no AS DocNo, s.si_no AS SiNo, s.revision AS Revision,
        s.category AS Category, s.ship_mode AS ShipMode,
        s.etd_date AS EtdDate, s.eta_date AS EtaDate, s.vanning_date AS VanningDate, s.cut_off_at AS CutOffAt,
        s.port_of_loading AS PortOfLoading, s.port_of_discharge AS PortOfDischarge,
        s.country_code AS CountryCode, s.forwarder_code AS ForwarderCode,
        s.carrier_code AS CarrierCode, s.consignee_code AS ConsigneeCode,
        s.packing_type AS PackingType, s.is_white_film AS IsWhiteFilm, s.is_case_mark AS IsCaseMark,
        s.is_serial_required AS IsSerialRequired, s.pic_name AS PicName, s.to_area_id AS ToAreaId,
        s.doc_status AS DocStatus, s.description AS Description, s.header_note AS HeaderNote,
        s.created_at AS CreatedAt, s.created_by AS CreatedBy, s.updated_at AS UpdatedAt, s.updated_by AS UpdatedBy
        """;

    /*  Số đã đáp ứng của 1 dòng, tách 2 phần theo từng dòng kế hoạch (task):
       QtyPicked  = hàng đã thực sự lấy
                    - nguyên pallet đã đóng 'picked'        -> qty_planned
                    - fifo / chỉ định (pending hoặc picked) -> pcs THỰC TẾ các thùng đã quét
       QtyPending = phần kế hoạch CHƯA quét của task pending
                    = qty_planned - pcs đã quét (không âm)
     Với task pending đang quét dở, thùng đã quét chuyển từ pending sang picked,
     nên pending + picked vẫn bằng qty_planned và không bị đếm 2 lần.
     Task 'skipped' không tính vào đâu cả.                                          */
    private const string LineAggSql = """
        SELECT l.id AS Id, l.si_id AS SiId, l.line_no AS [LineNo], l.model AS Model,
               l.customer_material AS CustomerMaterial, l.po_no AS PoNo,
               l.packing_list_no AS PackingListNo, l.packing_item_no AS PackingItemNo,
               l.invoice_no AS InvoiceNo, l.so_no AS SoNo, l.so_item_no AS SoItemNo,
               l.qty_required AS QtyRequired, l.uom AS Uom,
               l.package_plt AS PackagePlt, l.package_ctn AS PackageCtn,
               l.qty_cut AS QtyCut, l.cut_by AS CutBy, l.cut_at AS CutAt,
               ISNULL(t.qty_pending, 0) AS QtyPending,
               ISNULL(t.qty_picked, 0)  AS QtyPicked
        FROM wms.shipment_instruction_lines l
        OUTER APPLY (
            SELECT
                SUM(CASE WHEN sp.shipment_status = N'pending'
                         THEN CASE WHEN sp.qty_planned > ISNULL(sc.qty, 0)
                                   THEN sp.qty_planned - ISNULL(sc.qty, 0)
                                   ELSE 0 END
                    END) AS qty_pending,
                SUM(CASE WHEN sp.pick_mode = N'pallet' AND sp.shipment_status = N'picked'
                              THEN sp.qty_planned
                         WHEN sp.pick_mode <> N'pallet' AND sp.shipment_status IN (N'pending', N'picked')
                              THEN ISNULL(sc.qty, 0)
                    END) AS qty_picked
            FROM wms.shipment_instruction_pallets sp
            OUTER APPLY (
                SELECT SUM(bl.qty) AS qty
                FROM wms.shipment_instruction_boxes sb
                JOIN wms.box_lines bl ON bl.box_id = sb.box_id AND bl.is_deleted = 0
                                     AND bl.model = l.model
                WHERE sb.si_pallet_id = sp.id AND sb.picked_at IS NOT NULL
            ) sc
            WHERE sp.line_id = l.id
        ) t
        """;

    /*  st = pallet đang chứa hàng đã lấy của dòng kế hoạch:
          nguyên pallet -> chính sp.pallet_id
          theo thùng    -> pallet của thùng đã quét (sau tách là pallet mới)
        Staged* chỉ có giá trị khi pallet đó đang nằm ở khu vanning (map_type 'vanning'). */
    private const string TaskSql = """
        SELECT sp.id AS Id, sp.line_id AS LineId, sp.pallet_id AS PalletId, p.pallet_id AS PalletCode,
               sp.pick_mode AS PickMode, sp.unit_type AS UnitType,
               sp.box_planned AS BoxPlanned, ISNULL(x.picked, 0) AS BoxPicked, sp.qty_planned AS QtyPlanned,
               loc.locator_code AS LocatorCode, a.area_code AS AreaCode,
               sp.to_locator_id AS ToLocatorId, tl.locator_code AS ToLocatorCode,
               sp.assigned_to AS AssignedTo, sp.is_fifo AS IsFifo, sp.shipment_status AS ShipmentStatus,
               sp.picked_at AS PickedAt, sp.picked_by AS PickedBy, sp.skip_reason AS SkipReason,
               p.production_date AS ProductionDate,
               st.pallet_id AS StagedPalletId, st.pallet_code AS StagedPalletCode,
               st.locator_code AS StagedLocatorCode
        FROM wms.shipment_instruction_pallets sp
        JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
        JOIN wms.pallets p ON p.id = sp.pallet_id
        LEFT JOIN master.locators loc ON loc.id = p.locator_id
        LEFT JOIN master.racks rk     ON rk.id  = loc.rack_id 
        LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id
        LEFT JOIN master.locators tl ON tl.id = sp.to_locator_id
        OUTER APPLY (SELECT COUNT(*) AS picked FROM wms.shipment_instruction_boxes sb
                     WHERE sb.si_pallet_id = sp.id AND sb.picked_at IS NOT NULL) x
        OUTER APPLY (
            SELECT TOP 1 sp2.id AS pallet_id, sp2.pallet_id AS pallet_code, sl.locator_code
            FROM wms.pallets sp2
            JOIN master.locators sl ON sl.id = sp2.locator_id
            JOIN master.warehouse_areas sa ON sa.id = sl.area_id AND sa.map_type = N'vanning'
            WHERE sp.shipment_status = N'picked'
              AND sp2.id = CASE WHEN sp.pick_mode = N'pallet' THEN sp.pallet_id
                                ELSE (SELECT TOP 1 b.lot_id
                                      FROM wms.shipment_instruction_boxes sb
                                      JOIN wms.boxes b ON b.id = sb.box_id
                                      WHERE sb.si_pallet_id = sp.id AND sb.picked_at IS NOT NULL) END
        ) st
        """;

    // Chỉ đọc thùng CHỈ ĐỊNH; thùng fifo sinh lúc quét là dấu vết PDA, không hiện ở đây.
    private const string BoxSql = """
        SELECT sb.id AS Id, sb.line_id AS LineId, sb.si_pallet_id AS SiPalletId, sb.box_no AS BoxNo,
               sb.box_id AS BoxId, p.pallet_id AS PalletCode, sb.assign_source AS AssignSource,
               sb.match_status AS MatchStatus, tk.si_no AS TakenBySi,
               sb.matched_at AS MatchedAt, sb.picked_at AS PickedAt, sb.picked_by AS PickedBy
        FROM wms.shipment_instruction_boxes sb
        JOIN wms.shipment_instruction_lines l ON l.id = sb.line_id
        LEFT JOIN wms.boxes b   ON b.id = sb.box_id
        LEFT JOIN wms.pallets p ON p.id = b.lot_id
        OUTER APPLY (
            SELECT TOP 1 s2.si_no
            FROM wms.shipment_instruction_boxes x
            JOIN wms.boxes b2 ON b2.id = x.box_id
            JOIN wms.shipment_instruction_lines l2 ON l2.id = x.line_id
            JOIN wms.shipment_instructions s2 ON s2.id = l2.si_id
            WHERE sb.match_status = N'taken' AND x.id <> sb.id
              AND b2.box_no = sb.box_no AND l2.model = l.model
        ) tk
        WHERE sb.assign_source = N'designated'
        """;

    /*  Nhóm 0: pallet đang ở vị trí trong kho (chưa ra vanning)
        Nhóm 1: không có vị trí
        Nhóm 2: đã đưa ra khu vanning -> dưới cùng
                (pallet nằm ở khu vanning, hoặc pallet chứa thùng đã lấy (st) đang ở vanning)
        Trong nhóm: mã kệ -> hàng -> cột -> tầng -> locator_code; cuối cùng NSX cũ -> mới, sp.id. */
    private const string TaskOrderBy = """
    ORDER BY CASE WHEN a.map_type = N'vanning' OR st.pallet_id IS NOT NULL THEN 2
                  WHEN loc.id IS NULL THEN 1
                  ELSE 0 END,
             ISNULL(rk.rack_code, loc.locator_code),
             loc.rack_row, loc.rack_col, loc.rack_level,
             loc.locator_code,
             p.production_date, sp.id
    """;

    /*  Line xong hẳn (có task và MỌI task đã vào vanning) -> xuống dưới cùng.
    Task "đã vanning" = cùng quy tắc với st trong TaskSql:
      đã picked + pallet chứa hàng đã lấy đang nằm ở khu vanning
        (nguyên pallet -> sp.pallet_id; theo thùng -> lot của thùng đã quét).
    Line chưa có task nào giữ nguyên ở trên. Trong mỗi nhóm theo line_no. */
    private const string LineOrderBy = """
    ORDER BY CASE WHEN EXISTS (SELECT 1 FROM wms.shipment_instruction_pallets sp
                               WHERE sp.line_id = l.id)
                   AND NOT EXISTS (
                       SELECT 1 FROM wms.shipment_instruction_pallets sp
                       WHERE sp.line_id = l.id
                         AND NOT EXISTS (
                             SELECT 1
                             FROM wms.pallets vp
                             JOIN master.locators vl ON vl.id = vp.locator_id
                             JOIN master.warehouse_areas va ON va.id = vl.area_id
                                                           AND va.map_type = N'vanning'
                             WHERE sp.shipment_status = N'picked'
                               AND vp.id = CASE WHEN sp.pick_mode = N'pallet' THEN sp.pallet_id
                                                ELSE (SELECT TOP 1 b.lot_id
                                                      FROM wms.shipment_instruction_boxes sb
                                                      JOIN wms.boxes b ON b.id = sb.box_id
                                                      WHERE sb.si_pallet_id = sp.id
                                                        AND sb.picked_at IS NOT NULL) END))
                  THEN 1 ELSE 0 END,
             l.line_no
    """;

    // ═══════════════════════════════════════════════════════════════
    //  Đọc
    // ═══════════════════════════════════════════════════════════════

    public async Task<(IReadOnlyList<SiListRow> Items, int Total)> GetPagedAsync(SiQuery query)
    {
        using var conn = _factory.Create();

        const string filter = """
            s.is_deleted = 0
            AND (@DocNo         IS NULL OR s.si_no LIKE '%' + @DocNo + '%' OR s.doc_no LIKE '%' + @DocNo + '%')
            AND (@DocStatus     IS NULL OR s.doc_status = @DocStatus)
            AND (@ShipMode      IS NULL OR s.ship_mode = @ShipMode)
            AND (@VanningFrom   IS NULL OR COALESCE(s.vanning_date, s.etd_date) >= @VanningFrom)
            AND (@VanningTo     IS NULL OR COALESCE(s.vanning_date, s.etd_date) <  DATEADD(DAY, 1, @VanningTo))
            AND (@ConsigneeCode IS NULL OR s.consignee_code LIKE '%' + @ConsigneeCode + '%')
            AND (@CountryCode   IS NULL OR s.country_code   LIKE '%' + @CountryCode + '%')
            AND (@ForwarderCode IS NULL OR s.forwarder_code LIKE '%' + @ForwarderCode + '%')
            AND (@CarrierCode   IS NULL OR s.carrier_code   LIKE '%' + @CarrierCode + '%')
            AND (@PicName       IS NULL OR s.pic_name       LIKE '%' + @PicName + '%')
            AND (@Category      IS NULL OR s.category = @Category)
            AND (@Revision      IS NULL
                 OR (@Revision = 'first' AND ISNULL(s.revision, N'First') LIKE N'%First%')
                 OR (@Revision = 'rev'   AND s.revision LIKE N'%Rev%'))
            AND (@IsSerialRequired IS NULL OR ISNULL(s.is_serial_required, 0) = @IsSerialRequired)
            AND (@CreatedFrom   IS NULL OR s.created_at >= @CreatedFrom)
            AND (@CreatedTo     IS NULL OR s.created_at <= @CreatedTo)
            AND (@Model IS NULL OR EXISTS (SELECT 1 FROM wms.shipment_instruction_lines x
                                           WHERE x.si_id = s.id AND x.model LIKE '%' + @Model + '%'))
            AND (@PoNo IS NULL OR EXISTS (SELECT 1 FROM wms.shipment_instruction_lines x
                                          WHERE x.si_id = s.id AND x.po_no LIKE '%' + @PoNo + '%'))
            AND (@PackingListNo IS NULL OR EXISTS (SELECT 1 FROM wms.shipment_instruction_lines x
                                          WHERE x.si_id = s.id AND x.packing_list_no LIKE '%' + @PackingListNo + '%'))
            AND (@InvoiceNo IS NULL OR EXISTS (SELECT 1 FROM wms.shipment_instruction_lines x
                                          WHERE x.si_id = s.id AND x.invoice_no LIKE '%' + @InvoiceNo + '%'))
            """;

        // Lọc header TRƯỚC (si_f) rồi mới tính tổng hợp line, để không quét số liệu của
        // mọi SI trong DB. HasShortage lọc sau cùng vì phụ thuộc số đã tính.
        var cte = $"""
            WITH si_f AS (
                SELECT s.id FROM wms.shipment_instructions s WHERE {filter}
            ),
            line_agg AS (
                SELECT la.*,
                       CASE WHEN la.QtyRequired - ISNULL(la.QtyCut, 0) - la.QtyPending - la.QtyPicked > 0
                            THEN la.QtyRequired - ISNULL(la.QtyCut, 0) - la.QtyPending - la.QtyPicked
                            ELSE 0 END AS QtyShort
                FROM ({LineAggSql} WHERE l.si_id IN (SELECT id FROM si_f)) la
            ),
            si_agg AS (
                SELECT SiId,
                       COUNT(*) AS LineCount,
                       COUNT(DISTINCT PackingListNo) AS PackingListCount,
                       COUNT(DISTINCT Model) AS ModelCount,
                       SUM(QtyRequired) AS QtyRequired,
                       SUM(QtyPending + QtyPicked) AS QtyFulfilled,
                       SUM(QtyPending)             AS QtyPending, 
                       SUM(QtyPicked)              AS QtyPicked, 
                       SUM(ISNULL(QtyCut, 0)) AS QtyCut,
                       SUM(QtyShort) AS QtyShort,
                       SUM(ISNULL(PackagePlt, 0)) AS TotalPlt,
                       SUM(ISNULL(PackageCtn, 0)) AS TotalCtn
                FROM line_agg GROUP BY SiId
            ),
            si_rows AS (
                SELECT {HeaderColumns},
                       ISNULL(a.LineCount, 0) AS LineCount, ISNULL(a.PackingListCount, 0) AS PackingListCount,
                       ISNULL(a.ModelCount, 0) AS ModelCount,
                       ISNULL(a.QtyRequired, 0) AS QtyRequired, ISNULL(a.QtyFulfilled, 0) AS QtyFulfilled,
                       ISNULL(a.QtyPending, 0)  AS QtyPending,  
                       ISNULL(a.QtyPicked, 0)   AS QtyPicked,   
                       ISNULL(a.QtyCut, 0) AS QtyCut, ISNULL(a.QtyShort, 0) AS QtyShort,
                       ISNULL(a.TotalPlt, 0) AS TotalPlt, ISNULL(a.TotalCtn, 0) AS TotalCtn
                FROM wms.shipment_instructions s
                JOIN si_f f ON f.id = s.id
                LEFT JOIN si_agg a ON a.SiId = s.id
                WHERE @HasShortage IS NULL
                   OR (@HasShortage = 1 AND ISNULL(a.QtyShort, 0) > 0)
                   OR (@HasShortage = 0 AND ISNULL(a.QtyShort, 0) = 0)
            )
            """;

        var sql = $"""
            {cte}
            SELECT r.*,
                   (SELECT STRING_AGG(m.model, N', ')
                    FROM (SELECT DISTINCT TOP 2 x.model FROM wms.shipment_instruction_lines x
                          WHERE x.si_id = r.Id ORDER BY x.model) m) AS ModelsPreview,
                   (SELECT STRING_AGG(po.po_no, N', ')
                    FROM (SELECT DISTINCT TOP 3 x.po_no FROM wms.shipment_instruction_lines x
                          WHERE x.si_id = r.Id AND x.po_no IS NOT NULL ORDER BY x.po_no) po) AS PoNos,
                   (SELECT COUNT(*) FROM wms.shipment_instruction_boxes sb
                    JOIN wms.shipment_instruction_lines x ON x.id = sb.line_id
                    WHERE x.si_id = r.Id AND sb.assign_source = N'designated'
                      AND sb.match_status <> N'matched') AS UnmatchedBoxCount
            FROM si_rows r
            ORDER BY COALESCE(r.VanningDate, r.EtdDate), r.Id DESC
            OFFSET (@Page - 1) * @Size ROWS FETCH NEXT @Size ROWS ONLY;

            {cte}
            SELECT COUNT(*) FROM si_rows;
            """;

        using var multi = await conn.QueryMultipleAsync(sql, query);
        var items = (await multi.ReadAsync<SiListRow>()).ToList();
        var total = await multi.ReadFirstAsync<int>();
        return (items, total);
    }

    public async Task<Dictionary<string, int>> GetStatusCountsAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT doc_status AS Status, COUNT(*) AS Cnt
            FROM wms.shipment_instructions
            WHERE is_deleted = 0
            GROUP BY doc_status;

            SELECT COUNT(*) FROM wms.shipment_instructions WHERE is_deleted = 0;
            """;
        using var multi = await conn.QueryMultipleAsync(sql);
        var rows = await multi.ReadAsync<(string Status, int Cnt)>();
        var total = await multi.ReadFirstAsync<int>();

        var result = rows.ToDictionary(r => r.Status, r => r.Cnt);
        result[""] = total;   // key rỗng = tổng tất cả
        return result;
    }

    public async Task<SiDetail?> GetDetailAsync(long id)
    {
        using var conn = _factory.Create();
        var sql = $"""
        SELECT {HeaderColumns} FROM wms.shipment_instructions s WHERE s.id = @id AND s.is_deleted = 0;
        {LineAggSql} WHERE l.si_id = @id {LineOrderBy};
        {TaskSql} WHERE l.si_id = @id {TaskOrderBy};
        {BoxSql} AND l.si_id = @id ORDER BY sb.line_id, sb.box_no;
        """;

        using var multi = await conn.QueryMultipleAsync(sql, new { id });
        var header = await multi.ReadFirstOrDefaultAsync<SiHeader>();
        if (header is null) return null;

        return new SiDetail
        {
            Header = header,
            Lines = (await multi.ReadAsync<SiLine>()).ToList(),
            Tasks = (await multi.ReadAsync<SiTask>()).ToList(),
            Boxes = (await multi.ReadAsync<SiBox>()).ToList(),
        };
    }

    public async Task<SiHeader?> GetHeaderAsync(long id)
    {
        using var conn = _factory.Create();
        var sql = $"SELECT {HeaderColumns} FROM wms.shipment_instructions s WHERE s.id = @id AND s.is_deleted = 0;";
        return await conn.QueryFirstOrDefaultAsync<SiHeader>(sql, new { id });
    }

    public async Task<SiLine?> GetLineAsync(long lineId)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<SiLine>($"{LineAggSql} WHERE l.id = @lineId;", new { lineId });
    }

    public async Task<SiTask?> GetTaskAsync(long taskId)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<SiTask>($"{TaskSql} WHERE sp.id = @taskId;", new { taskId });
    }

    public async Task<SiBox?> GetBoxAsync(long id)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<SiBox>($"{BoxSql} AND sb.id = @id;", new { id });
    }

    public async Task<List<SiBox>> GetBoxesByLineAsync(long lineId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<SiBox>($"{BoxSql} AND sb.line_id = @lineId ORDER BY sb.box_no;", new { lineId })).ToList();
    }

    public async Task<bool> DocNoExistsAsync(string docNo, long? excludeId)
    {
        using var conn = _factory.Create();
        // Tính cả phiếu đã xoá mềm: UQ_si_doc_no không phân biệt is_deleted.
        const string sql = """
            SELECT COUNT(1) FROM wms.shipment_instructions
            WHERE doc_no = @docNo AND (@excludeId IS NULL OR id <> @excludeId);
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { docNo, excludeId }) > 0;
    }

    public async Task<long?> GetIdByDocNoAsync(string docNo)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<long?>(
            "SELECT id FROM wms.shipment_instructions WHERE doc_no = @docNo AND is_deleted = 0;",
            new { docNo });
    }

    /*  SAP nhận diện phiếu theo si_no (doc_no đổi theo revision). Phiếu đã huỷ không tính:
        SAP gửi lại SI đã huỷ ở kho thì tạo phiếu mới. Dữ liệu cũ có thể còn nhiều phiếu
        cùng si_no (mỗi revision 1 phiếu) -> lấy phiếu mới nhất.                              */
    public async Task<long?> GetActiveIdBySiNoAsync(string siNo)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<long?>("""
            SELECT TOP 1 id FROM wms.shipment_instructions
            WHERE si_no = @siNo AND is_deleted = 0 AND doc_status <> N'cancelled'
            ORDER BY id DESC;
            """, new { siNo });
    }

    public async Task<bool> HasPickedAsync(long siId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT CASE WHEN EXISTS (
                SELECT 1 FROM wms.shipment_instruction_pallets sp
                JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
                WHERE l.si_id = @siId AND sp.shipment_status = N'picked')
              OR EXISTS (
                SELECT 1 FROM wms.shipment_instruction_boxes sb
                JOIN wms.shipment_instruction_lines l ON l.id = sb.line_id
                WHERE l.si_id = @siId AND sb.picked_at IS NOT NULL)
            THEN 1 ELSE 0 END;
            """;
        return await conn.ExecuteScalarAsync<bool>(sql, new { siId });
    }

    public async Task<bool> LineLockedAsync(long lineId)
    {
        using var conn = _factory.Create();
        return await IsLineLockedAsync(conn, null, lineId);
    }

    private static async Task<bool> IsLineLockedAsync(IDbConnection conn, IDbTransaction? tx, long lineId)
    {
        const string sql = """
            SELECT CASE WHEN EXISTS (SELECT 1 FROM wms.shipment_instruction_pallets WHERE line_id = @lineId)
                          OR EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes   WHERE line_id = @lineId)
                        THEN 1 ELSE 0 END;
            """;
        return await conn.ExecuteScalarAsync<bool>(sql, new { lineId }, tx);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Header
    // ═══════════════════════════════════════════════════════════════

    private const string InsertLineSql = """
        INSERT INTO wms.shipment_instruction_lines
            (si_id, line_no, model, customer_material, po_no, packing_list_no, packing_item_no,
             invoice_no, so_no, so_item_no, qty_required, uom, package_plt, package_ctn)
        VALUES
            (@SiId, @LineNo, @Model, @CustomerMaterial, @PoNo, @PackingListNo, @PackingItemNo,
             @InvoiceNo, @SoNo, @SoItemNo, @QtyRequired, @Uom, @PackagePlt, @PackageCtn);
        SELECT CAST(SCOPE_IDENTITY() AS bigint);
        """;

    private const string UpdateLineSql = """
        UPDATE wms.shipment_instruction_lines
        SET line_no = @LineNo, model = @Model, customer_material = @CustomerMaterial, po_no = @PoNo,
            packing_list_no = @PackingListNo, packing_item_no = @PackingItemNo, invoice_no = @InvoiceNo,
            so_no = @SoNo, so_item_no = @SoItemNo, qty_required = @QtyRequired, uom = @Uom,
            package_plt = @PackagePlt, package_ctn = @PackageCtn
        WHERE id = @Id;
        """;

    // Các cột header sửa được — dùng chung cho sửa trên web và SAP gửi lại.
    private const string HeaderSetSql = """
        category = @Category, ship_mode = @ShipMode,
        etd_date = @EtdDate, eta_date = @EtaDate, vanning_date = @VanningDate, cut_off_at = @CutOffAt,
        port_of_loading = @PortOfLoading, port_of_discharge = @PortOfDischarge,
        country_code = @CountryCode, forwarder_code = @ForwarderCode,
        carrier_code = @CarrierCode, consignee_code = @ConsigneeCode,
        packing_type = @PackingType, is_white_film = @IsWhiteFilm, is_case_mark = @IsCaseMark,
        is_serial_required = @IsSerialRequired, pic_name = @PicName, to_area_id = @ToAreaId,
        description = @Description, header_note = @HeaderNote,
        updated_at = @UpdatedAt, updated_by = @UpdatedBy
        """;

    public async Task<long> AddAsync(SiHeader h, IReadOnlyList<SiLine> lines)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string insertSql = """
            INSERT INTO wms.shipment_instructions
                (doc_no, si_no, revision, category, ship_mode, etd_date, eta_date, vanning_date, cut_off_at,
                 port_of_loading, port_of_discharge, country_code, forwarder_code, carrier_code, consignee_code,
                 packing_type, is_white_film, is_case_mark, is_serial_required, pic_name, to_area_id,
                 doc_status, description, header_note, is_deleted, created_at, created_by)
            VALUES
                (@DocNo, @SiNo, @Revision, @Category, @ShipMode, @EtdDate, @EtaDate, @VanningDate, @CutOffAt,
                 @PortOfLoading, @PortOfDischarge, @CountryCode, @ForwarderCode, @CarrierCode, @ConsigneeCode,
                 @PackingType, @IsWhiteFilm, @IsCaseMark, @IsSerialRequired, @PicName, @ToAreaId,
                 @DocStatus, @Description, @HeaderNote, 0, @CreatedAt, @CreatedBy);
            SELECT CAST(SCOPE_IDENTITY() AS bigint);
            """;
        var id = await conn.ExecuteScalarAsync<long>(insertSql, h, tx);

        foreach (var line in lines)
        {
            line.SiId = id;
            line.Id = await conn.ExecuteScalarAsync<long>(InsertLineSql, line, tx);
        }

        tx.Commit();
        return id;
    }

    public async Task<bool> UpdateAsync(SiHeader h, IReadOnlyList<SiLine>? lines)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string updateSql = $"""
            UPDATE wms.shipment_instructions
            SET {HeaderSetSql}
            WHERE id = @Id AND is_deleted = 0;
            """;
        if (await conn.ExecuteAsync(updateSql, h, tx) == 0)
        {
            tx.Rollback();
            return false;
        }

        if (lines is not null)
        {
            var existing = (await conn.QueryAsync<long>(
                "SELECT id FROM wms.shipment_instruction_lines WHERE si_id = @Id;", new { h.Id }, tx)).ToHashSet();
            var nextNo = await conn.ExecuteScalarAsync<int>(
                "SELECT ISNULL(MAX(line_no), 0) FROM wms.shipment_instruction_lines WHERE si_id = @Id;", new { h.Id }, tx);

            // Dòng đã có kế hoạch / thùng chỉ định: KHÔNG sửa, KHÔNG xoá — service đã báo trước.
            foreach (var line in lines)
            {
                line.SiId = h.Id;
                if (line.Id > 0 && existing.Contains(line.Id))
                {
                    if (!await IsLineLockedAsync(conn, tx, line.Id))
                        await conn.ExecuteAsync(UpdateLineSql, line, tx);
                }
                else
                {
                    if (line.LineNo <= 0) line.LineNo = ++nextNo;
                    line.Id = await conn.ExecuteScalarAsync<long>(InsertLineSql, line, tx);
                }
            }

            var keep = lines.Where(l => l.Id > 0).Select(l => l.Id).ToHashSet();
            foreach (var goneId in existing.Where(x => !keep.Contains(x)))
                if (!await IsLineLockedAsync(conn, tx, goneId))
                    await conn.ExecuteAsync("DELETE FROM wms.shipment_instruction_lines WHERE id = @goneId;", new { goneId }, tx);
        }

        tx.Commit();
        return true;
    }

    /*  SAP gửi lại SI đã có (sửa lại cùng revision hoặc lên revision mới).
        Khác UpdateAsync ở 2 điểm:
          - ghi cả doc_no + revision (phiếu giữ nguyên id, kế hoạch / thùng đã lấy không đổi)
          - dòng đã có kế hoạch vẫn được sửa (số lượng, SO, invoice…) — service đã kiểm tra
            thay đổi đó không làm lệch phần đã phân bổ.
        Dòng SAP bỏ đi chỉ xoá khi chưa có kế hoạch / thùng chỉ định; kiểm tra lại ngay trong
        câu DELETE vì có thể vừa có người phân bổ -> rollback toàn bộ, trả id dòng đó.        */
    public async Task<(bool Found, long? LockedLineId)> ApplySapRevisionAsync(SiHeader h, IReadOnlyList<SiLine> lines)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string updateSql = $"""
            UPDATE wms.shipment_instructions
            SET doc_no = @DocNo, revision = @Revision,
                {HeaderSetSql}
            WHERE id = @Id AND is_deleted = 0;
            """;
        if (await conn.ExecuteAsync(updateSql, h, tx) == 0)
        {
            tx.Rollback();
            return (false, null);
        }

        var existing = (await conn.QueryAsync<long>(
            "SELECT id FROM wms.shipment_instruction_lines WHERE si_id = @Id;", new { h.Id }, tx)).ToHashSet();
        var nextNo = await conn.ExecuteScalarAsync<int>(
            "SELECT ISNULL(MAX(line_no), 0) FROM wms.shipment_instruction_lines WHERE si_id = @Id;", new { h.Id }, tx);

        foreach (var line in lines)
        {
            line.SiId = h.Id;
            if (line.Id > 0 && existing.Contains(line.Id))
            {
                await conn.ExecuteAsync(UpdateLineSql, line, tx);
            }
            else
            {
                if (line.LineNo <= 0) line.LineNo = ++nextNo;
                line.Id = await conn.ExecuteScalarAsync<long>(InsertLineSql, line, tx);
            }
        }

        const string deleteSql = """
            DELETE FROM wms.shipment_instruction_lines
            WHERE id = @goneId
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_pallets WHERE line_id = @goneId)
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes   WHERE line_id = @goneId);
            """;
        var keep = lines.Select(l => l.Id).ToHashSet();
        foreach (var goneId in existing.Where(x => !keep.Contains(x)))
        {
            if (await conn.ExecuteAsync(deleteSql, new { goneId }, tx) == 0)
            {
                tx.Rollback();
                return (true, goneId);
            }
        }

        tx.Commit();
        return (true, null);
    }

    /*  Xoá mềm. Trả tài nguyên đang giữ (pallet pending, thùng chỉ định) để SI khác
        dùng được, và đổi doc_no vì UQ_si_doc_no không phân biệt is_deleted — nếu không,
        tạo lại đúng số SI đó sẽ bị báo trùng mãi. */
    public async Task<bool> SoftDeleteAsync(long id, string? actor)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string sql = """
            DELETE sb FROM wms.shipment_instruction_boxes sb
            JOIN wms.shipment_instruction_lines l ON l.id = sb.line_id
            WHERE l.si_id = @id AND sb.picked_at IS NULL;

            DELETE sp FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
            WHERE l.si_id = @id AND sp.shipment_status = N'pending';

            UPDATE wms.shipment_instructions
            SET is_deleted = 1,
                doc_no = LEFT(doc_no, 40) + N'#DEL' + CAST(id AS nvarchar(20)),
                updated_at = SYSDATETIME(), updated_by = @actor
            WHERE id = @id AND is_deleted = 0;
            SELECT @@ROWCOUNT;
            """;
        var n = await conn.ExecuteScalarAsync<int>(sql, new { id, actor }, tx);
        if (n == 0) { tx.Rollback(); return false; }
        tx.Commit();
        return true;
    }

    /*  Huỷ:
          - dòng kế hoạch pending đã quét dở -> đóng 'picked' (lấy thiếu), giữ số thùng đã quét
          - dòng pending chưa quét           -> xoá, trả pallet về kho
          - thùng chỉ định chưa lấy          -> xoá, trả thùng cho SI khác                      */
    public async Task<bool> CancelAsync(long id, string reason, string? actor)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string sql = """
            DECLARE @p TABLE (id bigint PRIMARY KEY);
            INSERT @p SELECT DISTINCT sp.pallet_id
            FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
            WHERE l.si_id = @id AND sp.shipment_status = N'pending';

            UPDATE sp SET shipment_status = N'picked', picked_at = SYSDATETIME(), picked_by = @actor
            FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
            WHERE l.si_id = @id AND sp.shipment_status = N'pending'
              AND EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes sb
                          WHERE sb.si_pallet_id = sp.id AND sb.picked_at IS NOT NULL);

            DELETE sb FROM wms.shipment_instruction_boxes sb
            JOIN wms.shipment_instruction_lines l ON l.id = sb.line_id
            WHERE l.si_id = @id AND sb.picked_at IS NULL;

            DELETE sp FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
            WHERE l.si_id = @id AND sp.shipment_status = N'pending';

            UPDATE p SET is_urgent = 0, updated_at = SYSDATETIME(), updated_by = @actor
            FROM wms.pallets p
            WHERE p.id IN (SELECT id FROM @p) AND p.is_urgent = 1
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_pallets sp
                              WHERE sp.pallet_id = p.id AND sp.shipment_status = N'pending');

            UPDATE wms.shipment_instructions
            SET doc_status = N'cancelled',
                description = LEFT(N'[Huỷ] ' + @reason, 500),
                updated_at = SYSDATETIME(), updated_by = @actor
            WHERE id = @id AND is_deleted = 0;
            SELECT @@ROWCOUNT;
            """;
        var n = await conn.ExecuteScalarAsync<int>(sql, new { id, reason, actor }, tx);
        if (n == 0) { tx.Rollback(); return false; }
        tx.Commit();
        return true;
    }

    /*  Hoàn thành: chỉ đổi trạng thái. Dòng kế hoạch / thùng chỉ định giữ nguyên.
      Điều kiện doc_status nằm ngay trong WHERE để 2 người bấm cùng lúc không ghi đè nhau. */
    public async Task<bool> CompleteAsync(long id, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.shipment_instructions
            SET doc_status = N'completed', updated_at = SYSDATETIME(), updated_by = @actor
            WHERE id = @id AND is_deleted = 0
              AND doc_status NOT IN (N'completed', N'cancelled');
            """;
        return await conn.ExecuteAsync(sql, new { id, actor }) > 0;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Line
    // ═══════════════════════════════════════════════════════════════

    public async Task<long> AddLineAsync(SiLine line)
    {
        using var conn = _factory.Create();
        if (line.LineNo <= 0)
            line.LineNo = await conn.ExecuteScalarAsync<int>(
                "SELECT ISNULL(MAX(line_no), 0) + 1 FROM wms.shipment_instruction_lines WHERE si_id = @SiId;", line);
        return await conn.ExecuteScalarAsync<long>(InsertLineSql, line);
    }

    public async Task<bool> UpdateLineAsync(SiLine line)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteAsync(UpdateLineSql, line) > 0;
    }

    public async Task<bool> DeleteLineAsync(long lineId)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteAsync(
            "DELETE FROM wms.shipment_instruction_lines WHERE id = @lineId;", new { lineId }) > 0;
    }

    public async Task<bool> SetCutAsync(long lineId, int? qtyCut, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.shipment_instruction_lines
            SET qty_cut = @qtyCut,
                cut_by  = CASE WHEN @qtyCut IS NULL THEN NULL ELSE @actor END,
                cut_at  = CASE WHEN @qtyCut IS NULL THEN NULL ELSE SYSDATETIME() END
            WHERE id = @lineId;
            """;
        return await conn.ExecuteAsync(sql, new { lineId, qtyCut, actor }) > 0;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Phân bổ
    // ═══════════════════════════════════════════════════════════════

    public async Task<int> AllocateAsync(long siId, long? lineId, long? toLocatorId, string? assignedTo, string? actor)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        // Hai người bấm phân bổ cùng lúc sẽ cùng thấy 1 thùng là "rảnh".
        // Khoá theo tên trong transaction — nhả tự động khi commit / rollback.
        await conn.ExecuteAsync("""
            DECLARE @r int;
            EXEC @r = sp_getapplock @Resource = N'wms.si_allocate', @LockMode = N'Exclusive',
                                    @LockOwner = N'Transaction', @LockTimeout = 15000;
            IF @r < 0 THROW 50001, N'Đang có phiên phân bổ khác, thử lại sau.', 1;
            """, transaction: tx);

        var lines = (await conn.QueryAsync<SiLine>(
            $"{LineAggSql} WHERE l.si_id = @siId AND (@lineId IS NULL OR l.id = @lineId) ORDER BY l.line_no;",
            new { siId, lineId }, tx)).ToList();

        var ctx = new AllocContext(conn, tx, toLocatorId, assignedTo, actor);
        var created = 0;

        foreach (var line in lines)
        {
            var designated = await conn.ExecuteScalarAsync<int>("""
                SELECT COUNT(1) FROM wms.shipment_instruction_boxes
                WHERE line_id = @Id AND assign_source = N'designated';
                """, new { line.Id }, tx) > 0;

            if (designated)
                created += await AllocateDesignatedAsync(ctx, line);
            else if (line.QtyShort > 0)
                created += await AllocateFifoAsync(ctx, line, line.QtyShort);
        }

        if (created > 0)
            await conn.ExecuteAsync("""
                UPDATE wms.shipment_instructions
                SET doc_status = N'picking', updated_at = SYSDATETIME(), updated_by = @actor
                WHERE id = @siId AND doc_status = N'released';
                """, new { siId, actor }, tx);

        // Pallet có dòng kế hoạch pending của SI (hoặc của dòng đang phân bổ) -> đánh dấu gấp
        await conn.ExecuteAsync("""
            UPDATE p
            SET is_urgent = 1, updated_at = SYSDATETIME(), updated_by = @actor
            FROM wms.pallets p
            WHERE p.is_deleted = 0 AND ISNULL(p.is_urgent, 0) = 0
              AND EXISTS (SELECT 1
                          FROM wms.shipment_instruction_pallets sp
                          JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
                          WHERE sp.pallet_id = p.id
                            AND sp.shipment_status = N'pending'
                            AND l.si_id = @siId
                            AND (@lineId IS NULL OR l.id = @lineId));
            """, new { siId, lineId, actor }, tx);

        tx.Commit();
        return created;
    }

    private sealed record AllocContext(
        IDbConnection Conn, IDbTransaction Tx, long? ToLocatorId, string? AssignedTo, string? Actor);

    private const string InsertTaskSql = """
        INSERT INTO wms.shipment_instruction_pallets
            (line_id, pallet_id, unit_type, box_planned, qty_planned, to_locator_id, assigned_to,
             pick_mode, is_fifo, approved_by, approved_at, shipment_status, created_at, created_by)
        VALUES
            (@LineId, @PalletId, @UnitType, @BoxPlanned, @QtyPlanned, @ToLocatorId, @AssignedTo,
             @PickMode, @IsFifo, @ApprovedBy, @ApprovedAt, N'pending', SYSDATETIME(), @Actor);
        SELECT CAST(SCOPE_IDENTITY() AS bigint);
        """;

    /*  FIFO ở mức THÙNG, xuyên pallet.
        1. Thùng ứng viên: đúng model [+ PO], pallet ở khu storing, OQC pass/miễn,
           không stop shipment, chưa bị SI nào giữ (_boxes), pallet chưa bị giữ nguyên.
        2. Trừ phần đã hứa: dòng fifo pending của SI khác trên cùng pallet giữ SỐ thùng
           (chưa biết thùng nào) -> bỏ đi N thùng CŨ NHẤT của pallet đó, vì PDA sẽ lấy
           theo FIFO.
        3. Lấy dần theo ngày SX tới đủ nhu cầu, gom theo pallet thành dòng kế hoạch.
           Lấy hết thùng của 1 pallet chỉ chứa model này và chưa ai giữ -> nguyên pallet. */
    private static async Task<int> AllocateFifoAsync(AllocContext c, SiLine line, int need)
    {
        const string candSql = """
            SELECT b.id AS BoxId, p.id AS PalletId,
                   COALESCE(b.production_date, p.production_date) AS ProdDate,
                   q.qty AS Qty
            FROM wms.boxes b
            JOIN wms.pallets p ON p.id = b.lot_id AND p.is_deleted = 0
            JOIN master.locators loc ON loc.id = p.locator_id
            JOIN master.warehouse_areas a ON a.id = loc.area_id AND a.map_type = N'storing'
            CROSS APPLY (SELECT SUM(bl.qty) AS qty FROM wms.box_lines bl
                         WHERE bl.box_id = b.id AND bl.is_deleted = 0 AND bl.model = @Model) q
            WHERE b.is_deleted = 0 AND q.qty > 0
              AND p.stop_shipment = 0
              AND p.inspection_status IN (N'pass', N'inspection_exempt')
              --AND (@PoNo IS NULL OR b.customer_po = @PoNo)
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes sb WHERE sb.box_id = b.id)
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_pallets sp
                              WHERE sp.pallet_id = p.id AND sp.unit_type = N'pallet'
                                AND sp.shipment_status IN (N'pending', N'picked'))
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_pallets sp
                              WHERE sp.pallet_id = p.id AND sp.line_id = @LineId
                                AND sp.shipment_status = N'pending')
            ORDER BY CASE WHEN COALESCE(b.production_date, p.production_date) IS NULL THEN 1 ELSE 0 END,
                     COALESCE(b.production_date, p.production_date), b.id;
            """;
        var cands = (await c.Conn.QueryAsync<AllocCandidate>(
            candSql, new { line.Model, line.PoNo, LineId = line.Id }, c.Tx)).ToList();
        if (cands.Count == 0) return 0;

        var palletIds = cands.Select(x => x.PalletId).Distinct().ToArray();

        const string reservedSql = """
            SELECT sp.pallet_id AS PalletId,
                   SUM(sp.box_planned - ISNULL(x.scanned, 0)) AS Reserved
            FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id AND l.model = @Model
            OUTER APPLY (SELECT COUNT(*) AS scanned FROM wms.shipment_instruction_boxes sb
                         WHERE sb.si_pallet_id = sp.id) x
            WHERE sp.shipment_status = N'pending' AND sp.pick_mode = N'fifo'
              AND sp.pallet_id IN @PalletIds
            GROUP BY sp.pallet_id;

            SELECT lot_id AS PalletId, COUNT(*) AS Cnt
            FROM wms.boxes WHERE is_deleted = 0 AND lot_id IN @PalletIds
            GROUP BY lot_id;
            """;
        Dictionary<long, int> reserved, boxTotal;
        // Đóng GridReader trước khi INSERT trên cùng connection (1 connection = 1 reader mở)
        using (var multi = await c.Conn.QueryMultipleAsync(
                   reservedSql, new { line.Model, PalletIds = palletIds }, c.Tx))
        {
            reserved = (await multi.ReadAsync<(long PalletId, int Reserved)>())
                       .ToDictionary(x => x.PalletId, x => Math.Max(0, x.Reserved));
            boxTotal = (await multi.ReadAsync<(long PalletId, int Cnt)>())
                       .ToDictionary(x => x.PalletId, x => x.Cnt);
        }

        // Bước 2: bỏ N thùng cũ nhất mỗi pallet đã hứa cho dòng khác
        var free = cands
            .GroupBy(x => x.PalletId)
            .SelectMany(g => g.Skip(reserved.GetValueOrDefault(g.Key)))
            .OrderBy(x => x.ProdDate is null ? 1 : 0).ThenBy(x => x.ProdDate).ThenBy(x => x.BoxId)
            .ToList();
        var freePerPallet = free.GroupBy(x => x.PalletId).ToDictionary(g => g.Key, g => g.Count());

        // Bước 3: lấy tới đủ
        var chosen = new List<AllocCandidate>();
        var got = 0;
        foreach (var box in free)
        {
            if (got >= need) break;
            chosen.Add(box);
            got += box.Qty;
        }

        var created = 0;
        foreach (var g in chosen.GroupBy(x => x.PalletId))
        {
            var whole = g.Count() == freePerPallet[g.Key]
                        && reserved.GetValueOrDefault(g.Key) == 0
                        && g.Count() == boxTotal.GetValueOrDefault(g.Key);

            await c.Conn.ExecuteScalarAsync<long>(InsertTaskSql, new
            {
                LineId = line.Id,
                PalletId = g.Key,
                UnitType = whole ? "pallet" : "box",
                BoxPlanned = g.Count(),
                QtyPlanned = g.Sum(x => x.Qty),
                c.ToLocatorId,
                c.AssignedTo,
                PickMode = whole ? "pallet" : "fifo",
                IsFifo = true,
                ApprovedBy = (string?)null,
                ApprovedAt = (DateTime?)null,
                c.Actor,
            }, c.Tx);
            created++;
        }
        return created;
    }

    /*  Chỉ định: lấy ĐÚNG các thùng SI đã chỉ định (matched), không chạy FIFO, không
        giới hạn theo nhu cầu. Vẫn chặn pallet NG / stop shipment — chứng từ không được
        vượt quyết định chặn của kho. Thùng bị chặn giữ nguyên chưa gán, phân bổ lại sau. */
    private static async Task<int> AllocateDesignatedAsync(AllocContext c, SiLine line)
    {
        const string candSql = """
            SELECT sb.id AS SbId, b.lot_id AS PalletId, ISNULL(q.qty, 0) AS Qty
            FROM wms.shipment_instruction_boxes sb
            JOIN wms.boxes b   ON b.id = sb.box_id AND b.is_deleted = 0
            JOIN wms.pallets p ON p.id = b.lot_id  AND p.is_deleted = 0
            CROSS APPLY (SELECT SUM(bl.qty) AS qty FROM wms.box_lines bl
                         WHERE bl.box_id = b.id AND bl.is_deleted = 0 AND bl.model = @Model) q
            WHERE sb.line_id = @LineId AND sb.assign_source = N'designated'
              AND sb.match_status = N'matched' AND sb.si_pallet_id IS NULL AND sb.picked_at IS NULL
              AND p.stop_shipment = 0 AND p.inspection_status <> N'ng';
            """;
        var cands = (await c.Conn.QueryAsync<DesignatedCandidate>(
            candSql, new { line.Model, LineId = line.Id }, c.Tx)).ToList();

        var created = 0;
        foreach (var g in cands.GroupBy(x => x.PalletId))
        {
            var qty = g.Sum(x => x.Qty);
            if (qty <= 0) continue;

            // UX_si_pallets_pending_line: 1 dòng pending / (pallet, line) -> cộng dồn nếu đã có
            var taskId = await c.Conn.ExecuteScalarAsync<long?>("""
                SELECT id FROM wms.shipment_instruction_pallets
                WHERE pallet_id = @PalletId AND line_id = @LineId AND shipment_status = N'pending';
                """, new { PalletId = g.Key, LineId = line.Id }, c.Tx);

            if (taskId is null)
            {
                taskId = await c.Conn.ExecuteScalarAsync<long>(InsertTaskSql, new
                {
                    LineId = line.Id,
                    PalletId = g.Key,
                    UnitType = "box",
                    BoxPlanned = g.Count(),
                    QtyPlanned = qty,
                    c.ToLocatorId,
                    c.AssignedTo,
                    PickMode = "designated",
                    IsFifo = false,                      // CK_si_pallets_mode_fifo
                    ApprovedBy = "SI designated",
                    ApprovedAt = (DateTime?)DateTime.Now,
                    c.Actor,
                }, c.Tx);
                created++;
            }
            else
            {
                await c.Conn.ExecuteAsync("""
                    UPDATE wms.shipment_instruction_pallets
                    SET box_planned = box_planned + @n, qty_planned = qty_planned + @qty
                    WHERE id = @taskId;
                    """, new { n = g.Count(), qty, taskId }, c.Tx);
            }

            await c.Conn.ExecuteAsync(
                "UPDATE wms.shipment_instruction_boxes SET si_pallet_id = @taskId WHERE id IN @ids;",
                new { taskId, ids = g.Select(x => x.SbId).ToArray() }, c.Tx);
        }
        return created;
    }

    public async Task<bool> UpdateTaskAsync(long taskId, long? toLocatorId, string? assignedTo)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.shipment_instruction_pallets
            SET to_locator_id = @toLocatorId, assigned_to = @assignedTo
            WHERE id = @taskId AND shipment_status = N'pending';
            """;
        return await conn.ExecuteAsync(sql, new { taskId, toLocatorId, assignedTo }) > 0;
    }

    /// <summary>Chỉ dòng pending chưa quét thùng nào. Thùng chỉ định được nhả về chưa gán.</summary>
    public async Task<bool> ReleaseTaskAsync(long taskId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        const string sql = """
            IF EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes
                       WHERE si_pallet_id = @taskId AND picked_at IS NOT NULL)
            BEGIN SELECT 0; RETURN; END

            DECLARE @palletId bigint = (SELECT pallet_id FROM wms.shipment_instruction_pallets WHERE id = @taskId);

            UPDATE wms.shipment_instruction_boxes SET si_pallet_id = NULL
            WHERE si_pallet_id = @taskId AND assign_source = N'designated';

            DELETE FROM wms.shipment_instruction_boxes
            WHERE si_pallet_id = @taskId AND assign_source = N'fifo';

            DELETE FROM wms.shipment_instruction_pallets
            WHERE id = @taskId AND shipment_status = N'pending';
            DECLARE @n int = @@ROWCOUNT;

            -- Pallet không còn SI nào giữ -> bỏ gấp
            UPDATE p SET is_urgent = 0, updated_at = SYSDATETIME()
            FROM wms.pallets p
            WHERE p.id = @palletId AND p.is_urgent = 1
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_pallets sp
                              WHERE sp.pallet_id = p.id AND sp.shipment_status = N'pending');

            SELECT @n;
            """;
        var n = await conn.ExecuteScalarAsync<int>(sql, new { taskId }, tx);
        if (n == 0) { tx.Rollback(); return false; }
        tx.Commit();
        return true;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Mã thùng chỉ định
    // ═══════════════════════════════════════════════════════════════

    public async Task<int> AddDesignatedBoxesAsync(long lineId, IReadOnlyList<string> boxNos, bool replace)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        if (replace)
            await conn.ExecuteAsync("""
                DELETE FROM wms.shipment_instruction_boxes
                WHERE line_id = @lineId AND assign_source = N'designated'
                  AND si_pallet_id IS NULL AND picked_at IS NULL;
                """, new { lineId }, tx);

        const string insertSql = """
            INSERT INTO wms.shipment_instruction_boxes (line_id, box_no, assign_source, match_status)
            SELECT @lineId, @boxNo, N'designated', N'pending'
            WHERE NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes
                              WHERE line_id = @lineId AND box_no = @boxNo);
            """;
        var added = 0;
        foreach (var boxNo in boxNos)
            added += await conn.ExecuteAsync(insertSql, new { lineId, boxNo }, tx);

        await MatchAsync(conn, tx, lineId);
        tx.Commit();
        return added;
    }

    public async Task MatchDesignatedBoxesAsync(long lineId)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        await MatchAsync(conn, tx, lineId);
        tx.Commit();
    }

    /*  Khớp (box_no + model của line) -> wms.boxes. Chỉ xét thùng CHƯA gán kế hoạch.
        boxes.model cho phép NULL (usp_oqc_sample backfill sau) nên fallback box_lines.model.
          Dòng đã matched không bị khớp lại — kể cả dòng chọn tay qua ResolveBox.
          1 thùng, chưa ai giữ   -> matched
          0 thùng                -> not_found
          nhiều pallet cùng mã   -> ambiguous (chọn tay qua ResolveBox)
          thùng đã thuộc SI khác -> taken                                                */
    private static async Task MatchAsync(IDbConnection conn, IDbTransaction tx, long lineId)
    {
        const string sql = """
            -- Chỉ khớp lại dòng CHƯA matched; dòng đã matched (kể cả chọn tay qua Resolve) giữ nguyên
            UPDATE wms.shipment_instruction_boxes
            SET box_id = NULL, match_status = N'pending'
            WHERE line_id = @lineId AND assign_source = N'designated'
              AND si_pallet_id IS NULL AND picked_at IS NULL AND match_status <> N'matched';

            ;WITH cand AS (
                SELECT sb.id AS sb_id, b.id AS box_id
                FROM wms.shipment_instruction_boxes sb
                JOIN wms.shipment_instruction_lines l ON l.id = sb.line_id
                JOIN wms.boxes b ON b.box_no = sb.box_no AND b.is_deleted = 0
                 AND (b.model = l.model
                      OR (b.model IS NULL AND EXISTS (SELECT 1 FROM wms.box_lines bl
                                                      WHERE bl.box_id = b.id AND bl.is_deleted = 0
                                                        AND bl.model = l.model)))
                WHERE sb.line_id = @lineId AND sb.assign_source = N'designated'
                  AND sb.match_status = N'pending'
            ),
            agg AS (
                SELECT sb_id, MIN(box_id) AS box_id, COUNT(*) AS hits FROM cand GROUP BY sb_id
            ),
            res AS (
                SELECT sb.id,
                       a.box_id, a.hits,
                       CASE WHEN a.box_id IS NOT NULL AND EXISTS (
                                SELECT 1 FROM wms.shipment_instruction_boxes x
                                WHERE x.box_id = a.box_id AND x.id <> sb.id) THEN 1 ELSE 0 END AS taken
                FROM wms.shipment_instruction_boxes sb
                LEFT JOIN agg a ON a.sb_id = sb.id
                WHERE sb.line_id = @lineId AND sb.assign_source = N'designated'
                  AND sb.match_status = N'pending'
            )
            UPDATE sb
            SET box_id       = CASE WHEN r.hits = 1 AND r.taken = 0 THEN r.box_id END,
                match_status = CASE WHEN r.box_id IS NULL THEN N'not_found'
                                    WHEN r.hits > 1       THEN N'ambiguous'
                                    WHEN r.taken = 1      THEN N'taken'
                                    ELSE N'matched' END,
                matched_at   = SYSDATETIME()
            FROM wms.shipment_instruction_boxes sb
            JOIN res r ON r.id = sb.id;
            """;
        await conn.ExecuteAsync(sql, new { lineId }, tx);
    }

    public async Task<bool> BoxMatchesAsync(long id, long boxId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT COUNT(1)
            FROM wms.shipment_instruction_boxes sb
            JOIN wms.shipment_instruction_lines l ON l.id = sb.line_id
            JOIN wms.boxes b ON b.id = @boxId AND b.is_deleted = 0 AND b.box_no = sb.box_no
             AND (b.model = l.model
                  OR (b.model IS NULL AND EXISTS (SELECT 1 FROM wms.box_lines bl
                                                  WHERE bl.box_id = b.id AND bl.is_deleted = 0
                                                    AND bl.model = l.model)))
            WHERE sb.id = @id;
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { id, boxId }) > 0;
    }

    public async Task<bool> BoxHeldAsync(long boxId, long excludeId)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM wms.shipment_instruction_boxes WHERE box_id = @boxId AND id <> @excludeId;",
            new { boxId, excludeId }) > 0;
    }

    public async Task<bool> ResolveBoxAsync(long id, long boxId)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.shipment_instruction_boxes
            SET box_id = @boxId, match_status = N'matched', matched_at = SYSDATETIME()
            WHERE id = @id AND si_pallet_id IS NULL AND picked_at IS NULL;
            """;
        return await conn.ExecuteAsync(sql, new { id, boxId }) > 0;
    }

    public async Task<bool> DeleteBoxAsync(long id)
    {
        using var conn = _factory.Create();
        const string sql = """
            DELETE FROM wms.shipment_instruction_boxes
            WHERE id = @id AND assign_source = N'designated'
              AND si_pallet_id IS NULL AND picked_at IS NULL;
            """;
        return await conn.ExecuteAsync(sql, new { id }) > 0;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Lấy hàng (PDA)
    // ═══════════════════════════════════════════════════════════════

    /*  Thùng của pallet trong dòng kế hoạch, cùng model với dòng SI, NSX cũ → mới
        (cùng thứ tự FIFO với AllocateFifoAsync). Kèm cờ IsMine / IsPicked / HeldByOther;
        eligible / locked do service tính. */
    public async Task<List<PickBoxRow>> GetPickBoxesAsync(long taskId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT b.id AS BoxId, b.box_no AS BoxNo,
                   COALESCE(b.production_date, p.production_date) AS ProductionDate,
                   q.qty AS Qty,
                   CAST(CASE WHEN mine.id IS NOT NULL THEN 1 ELSE 0 END AS bit) AS IsMine,
                   CAST(CASE WHEN mine.picked_at IS NOT NULL THEN 1 ELSE 0 END AS bit) AS IsPicked,
                   CAST(CASE WHEN mine.id IS NULL AND other.id IS NOT NULL THEN 1 ELSE 0 END AS bit) AS HeldByOther
            FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
            JOIN wms.pallets p ON p.id = sp.pallet_id
            JOIN wms.boxes b ON b.is_deleted = 0
            AND (b.lot_id = p.id
                 -- Thùng đã quét cho dòng kế hoạch này: vẫn hiện dù đã tách sang lot khác
                 OR EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes x
                            WHERE x.box_id = b.id AND x.si_pallet_id = sp.id))
            CROSS APPLY (SELECT SUM(bl.qty) AS qty FROM wms.box_lines bl
                         WHERE bl.box_id = b.id AND bl.is_deleted = 0 AND bl.model = l.model) q
            OUTER APPLY (SELECT TOP 1 x.id, x.picked_at FROM wms.shipment_instruction_boxes x
                         WHERE x.box_id = b.id AND x.si_pallet_id = sp.id) mine
            OUTER APPLY (SELECT TOP 1 x.id FROM wms.shipment_instruction_boxes x
                         WHERE x.box_id = b.id AND (x.si_pallet_id IS NULL OR x.si_pallet_id <> sp.id)) other
            WHERE sp.id = @taskId AND q.qty > 0
            ORDER BY CASE WHEN COALESCE(b.production_date, p.production_date) IS NULL THEN 1 ELSE 0 END,
                     COALESCE(b.production_date, p.production_date), b.id;
            """;
        return (await conn.QueryAsync<PickBoxRow>(sql, new { taskId })).ToList();
    }

    /// <summary>Lấy nguyên pallet: đóng dòng kế hoạch. Chỉ dòng pending + pick_mode 'pallet'.</summary>
    public async Task<bool> ConfirmPalletAsync(long taskId, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.shipment_instruction_pallets
            SET shipment_status = N'picked', picked_at = SYSDATETIME(), picked_by = @actor
            WHERE id = @taskId AND shipment_status = N'pending' AND pick_mode = N'pallet';
            """;
        return await conn.ExecuteAsync(sql, new { taskId, actor }) > 0;
    }

    // Đủ số thùng kế hoạch -> đóng dòng kế hoạch (thùng đã quét của dòng này).
    private const string CompleteIfFullSql = """
        UPDATE wms.shipment_instruction_pallets
        SET shipment_status = N'picked', picked_at = SYSDATETIME(), picked_by = @actor
        WHERE id = @taskId AND shipment_status = N'pending'
          AND (SELECT COUNT(*) FROM wms.shipment_instruction_boxes sb
               WHERE sb.si_pallet_id = @taskId AND sb.picked_at IS NOT NULL) >= box_planned;
        """;

    /*  Quét 1 thùng. Service đã kiểm FIFO / chỉ định; ở đây chỉ chặn tranh chấp:
          - khoá theo thùng: 2 PDA quét cùng 1 thùng cùng lúc
          - fifo: thùng đã bị bất kỳ dòng _boxes nào giữ -> Taken (cùng quy tắc
            "chưa bị SI nào giữ" của AllocateFifoAsync)                           */
    public async Task<PickScanResult> PickBoxAsync(
        long taskId, long lineId, long boxId, string boxNo, bool designated, string? actor)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        await conn.ExecuteAsync("""
            DECLARE @r int, @res nvarchar(255) = N'wms.si_pick_box_' + CAST(@boxId AS nvarchar(20));
            EXEC @r = sp_getapplock @Resource = @res, @LockMode = N'Exclusive',
                                    @LockOwner = N'Transaction', @LockTimeout = 10000;
            IF @r < 0 THROW 50002, N'Thùng đang được quét ở máy khác, thử lại sau.', 1;
            """, new { boxId }, tx);

        if (designated)
        {
            var n = await conn.ExecuteAsync("""
                UPDATE wms.shipment_instruction_boxes
                SET picked_at = SYSDATETIME(), picked_by = @actor
                WHERE si_pallet_id = @taskId AND box_id = @boxId AND picked_at IS NULL;
                """, new { taskId, boxId, actor }, tx);
            if (n == 0) { tx.Rollback(); return PickScanResult.AlreadyPicked; }
        }
        else
        {
            var sbId = await conn.ExecuteScalarAsync<long?>(@"
                INSERT INTO wms.shipment_instruction_boxes
                    (line_id, si_pallet_id, box_no, box_id, assign_source, match_status,
                     matched_at, picked_at, picked_by)
                OUTPUT INSERTED.id
                SELECT @lineId, @taskId, @boxNo, @boxId, N'fifo', N'matched',
                       SYSDATETIME(), SYSDATETIME(), @actor
                WHERE NOT EXISTS
                (
                    SELECT 1
                    FROM wms.shipment_instruction_boxes
                    WHERE box_id = @boxId
                );",
                new
                {
                    lineId,
                    taskId,
                    boxNo,
                    boxId,
                    actor
                },
                tx);

            if (sbId is null)
            {
                tx.Rollback();
                return PickScanResult.Taken;
            }

            await conn.ExecuteAsync("""
                UPDATE pb
                SET pb.si_box_id = @sbId
                FROM wms.stowage_pallet_boxes pb
                WHERE pb.si_box_id IS NULL
                  AND pb.si_line_id = @lineId;
                """,
                new
                {
                    sbId,
                    lineId
                },
                tx);
        }

        await conn.ExecuteAsync(CompleteIfFullSql, new { taskId, actor }, tx);
        tx.Commit();
        return PickScanResult.Ok;
    }

    /*  Gỡ thùng quét nhầm: fifo -> xoá dòng _boxes (trả thùng về kho),
        chỉ định -> bỏ picked_at (thùng vẫn thuộc dòng kế hoạch).
        Dòng kế hoạch đã tự đóng mà giờ hụt thùng -> mở lại pending. */
    public async Task<bool> UnpickBoxAsync(long taskId, long boxId, bool designated)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var sql = designated
            ? """
              UPDATE wms.shipment_instruction_boxes SET picked_at = NULL, picked_by = NULL
              WHERE si_pallet_id = @taskId AND box_id = @boxId AND picked_at IS NOT NULL;
              """
            : """
              DELETE FROM wms.shipment_instruction_boxes
              WHERE si_pallet_id = @taskId AND box_id = @boxId
                AND assign_source = N'fifo' AND picked_at IS NOT NULL;
              """;
        if (await conn.ExecuteAsync(sql, new { taskId, boxId }, tx) == 0)
        {
            tx.Rollback();
            return false;
        }

        await conn.ExecuteAsync("""
            UPDATE wms.shipment_instruction_pallets
            SET shipment_status = N'pending', picked_at = NULL, picked_by = NULL
            WHERE id = @taskId AND shipment_status = N'picked' AND pick_mode <> N'pallet'
              AND (SELECT COUNT(*) FROM wms.shipment_instruction_boxes sb
                   WHERE sb.si_pallet_id = @taskId AND sb.picked_at IS NOT NULL) < box_planned;
            """, new { taskId }, tx);

        tx.Commit();
        return true;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Vanning (PDA)
    // ═══════════════════════════════════════════════════════════════

    public async Task<LocatorRow?> GetLocatorByCodeAsync(string locatorCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT loc.id AS Id, loc.locator_code AS LocatorCode, a.map_type AS MapType
            FROM master.locators loc
            LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id
            WHERE loc.locator_code = @locatorCode;
            """;
        return await conn.QueryFirstOrDefaultAsync<LocatorRow>(sql, new { locatorCode });
    }

    public async Task<long?> GetPalletIdByCodeAsync(string palletCode)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<long?>(
            "SELECT id FROM wms.pallets WHERE pallet_id = @palletCode AND is_deleted = 0;",
            new { palletCode });
    }

    public async Task<int> CountPickedBoxesOffPalletAsync(long taskId, long palletId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT COUNT(*)
            FROM wms.shipment_instruction_boxes sb
            JOIN wms.boxes b ON b.id = sb.box_id
            WHERE sb.si_pallet_id = @taskId AND sb.picked_at IS NOT NULL
              AND b.lot_id <> @palletId;
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { taskId, palletId });
    }

    public async Task<int> CountForeignBoxesOnPalletAsync(long taskId, long palletId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT COUNT(*)
            FROM wms.boxes b
            WHERE b.lot_id = @palletId AND b.is_deleted = 0
              AND NOT EXISTS (SELECT 1 FROM wms.shipment_instruction_boxes sb
                              WHERE sb.si_pallet_id = @taskId AND sb.box_id = b.id AND sb.picked_at IS NOT NULL);
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { taskId, palletId });
    }

    /*  Đưa ra vanning = dời pallet sang vị trí vanning + ghi 1 dòng VANNING_IN vào
        wms.stock_events (append-only, cùng transaction). Không lưu cột riêng trên
        dòng kế hoạch — TaskSql suy trạng thái từ vị trí hiện tại của pallet.
        from_locator đọc TRƯỚC khi UPDATE để lịch sử có đủ đi từ đâu → đến đâu.     */
    public async Task<bool> MovePalletToLocatorAsync(long palletId, long locatorId, long taskId, string? actor)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string sql = """
            DECLARE @fromLocatorId bigint, @palletCode nvarchar(50), @stockyCode nvarchar(50),
                    @boxCount int, @siNo nvarchar(30);

            SELECT @fromLocatorId = p.locator_id, @palletCode = p.pallet_id, @stockyCode = p.stocky_code,
                   @boxCount = (SELECT COUNT(*) FROM wms.boxes b WHERE b.lot_id = p.id AND b.is_deleted = 0)
            FROM wms.pallets p WITH (UPDLOCK)
            WHERE p.id = @palletId AND p.is_deleted = 0;

            IF @palletCode IS NULL BEGIN SELECT 0; RETURN; END

            SELECT @siNo = s.si_no
            FROM wms.shipment_instruction_pallets sp
            JOIN wms.shipment_instruction_lines l ON l.id = sp.line_id
            JOIN wms.shipment_instructions s ON s.id = l.si_id
            WHERE sp.id = @taskId;

            UPDATE wms.pallets SET locator_id = @locatorId WHERE id = @palletId;

            INSERT INTO wms.stock_events
                (subject_type, pallet_id, pallet_code, stocky_code, event_code, event_at, actor, source,
                 from_locator_id, from_locator_code, to_locator_id, to_locator_code, box_count_after, note)
            SELECT N'pallet', @palletId, @palletCode, @stockyCode, N'VANNING_IN', SYSDATETIME(), @actor, N'PDA',
                   @fromLocatorId, fl.locator_code, @locatorId, tl.locator_code, @boxCount,
                   N'Kitting → vanning, SI ' + ISNULL(@siNo, N'?') + N' (task ' + CAST(@taskId AS nvarchar(20)) + N')'
            FROM master.locators tl
            LEFT JOIN master.locators fl ON fl.id = @fromLocatorId
            WHERE tl.id = @locatorId;

            SELECT 1;
            """;

        var ok = await conn.ExecuteScalarAsync<int>(sql, new { palletId, locatorId, taskId, actor }, tx) == 1;
        if (!ok) { tx.Rollback(); return false; }

        tx.Commit();
        return true;
    }

    // ═══════════════════════════════════════════════════════════════
    //  So sánh với HD soft
    // ═══════════════════════════════════════════════════════════════

    /*  1 si_no có thể còn nhiều phiếu (dữ liệu cũ mỗi revision 1 phiếu, hoặc phiếu huỷ rồi
        SAP gửi lại) -> lấy đúng 1: phiếu chưa huỷ trước, rồi id lớn nhất.
        Cùng quy tắc với GetActiveIdBySiNoAsync, chỉ khác là vẫn trả phiếu huỷ khi không còn
        phiếu nào khác — để so trạng thái huỷ với HD soft.                                    */
    public async Task<List<SiHeader>> GetHeadersBySiNosAsync(IReadOnlyCollection<string> siNos)
    {
        if (siNos.Count == 0) return new();
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {HeaderColumns}
            FROM (SELECT x.*,
                         ROW_NUMBER() OVER (PARTITION BY x.si_no
                                            ORDER BY CASE WHEN x.doc_status = N'cancelled' THEN 1 ELSE 0 END,
                                                     x.id DESC) AS rn
                  FROM wms.shipment_instructions x
                  WHERE x.is_deleted = 0 AND x.si_no IN @siNos) s
            WHERE s.rn = 1;
            """;
        return (await conn.QueryAsync<SiHeader>(sql, new { siNos })).ToList();
    }

    public async Task<List<SiLine>> GetLinesBySiIdsAsync(IReadOnlyCollection<long> siIds)
    {
        if (siIds.Count == 0) return new();
        using var conn = _factory.Create();
        return (await conn.QueryAsync<SiLine>(
            $"{LineAggSql} WHERE l.si_id IN @siIds ORDER BY l.si_id, l.line_no;", new { siIds })).ToList();
    }

    public async Task<List<string>> GetSiNosByEtdAsync(DateTime from, DateTime toExclusive)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT DISTINCT si_no FROM wms.shipment_instructions
            WHERE is_deleted = 0 AND doc_status <> N'cancelled'
              AND etd_date >= @from AND etd_date < @toExclusive;
            """;
        return (await conn.QueryAsync<string>(sql, new { from, toExclusive })).ToList();
    }

    public async Task<List<string>> GetSiNosByVanningAsync(DateTime from, DateTime toExclusive)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT DISTINCT LTRIM(RTRIM(s.si_no))
            FROM wms.shipment_instructions s
            WHERE s.is_deleted = 0
              AND s.doc_status <> N'cancelled'
              AND s.si_no IS NOT NULL AND LTRIM(RTRIM(s.si_no)) <> N''
              AND COALESCE(s.vanning_date, s.etd_date) >= @From
              AND COALESCE(s.vanning_date, s.etd_date) <  @To;
            """;
        return (await conn.QueryAsync<string>(sql, new { From = from, To = toExclusive })).ToList();
    }
}