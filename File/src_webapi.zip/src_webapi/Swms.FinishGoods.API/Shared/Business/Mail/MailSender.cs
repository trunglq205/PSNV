﻿using System.Net.Mail;
using System.Text;

namespace Swms.FinishGoods.API.Shared.Business.Mail;

/// <summary>
/// Một người nhận. Type: TO | CC | BCC (khớp master.email_config.recipient_type).
///
/// Dùng class có property chứ không dùng record positional: Dapper đọc trực
/// tiếp vào kiểu này, và cách map theo tên property là cách đã chạy được trong
/// dự án (xem RecipientRow của tính năng Thiếu hàng). Map qua constructor của
/// record cũng được nhưng chưa có tiền lệ ở đây.
/// </summary>
public class MailRecipient
{
    public string Type { get; set; } = "TO";
    public string Email { get; set; } = "";
    public string? DisplayName { get; set; }
}

/// <summary>
/// Cấu hình trong appsettings, nhóm "Mail":
///   "Mail": {
///     "Enabled": true,
///     "Host": "157.8.1.131",
///     "Port": 25,
///     "From": "psnv.isg@vn.panasonic.com",
///     "FromName": "SWMS Finish Goods",
///     "TimeoutSeconds": 15,
///     "RedirectTo": null
///   }
/// Relay nội bộ của nhà máy không cần đăng nhập nên không có User/Password.
/// </summary>
public class MailOptions
{
    public const string Section = "Mail";

    /// <summary>false = KHÔNG gửi, chỉ ghi log. Để false ở môi trường dev.</summary>
    public bool Enabled { get; set; }

    public string? Host { get; set; }
    public int Port { get; set; } = 25;
    public string? From { get; set; }
    public string? FromName { get; set; }
    public int TimeoutSeconds { get; set; } = 15;

    /// <summary>
    /// Có giá trị thì MỌI mail bị chuyển hết về địa chỉ này, bỏ qua danh sách
    /// người nhận thật. Dùng khi test trên môi trường dev để không làm phiền
    /// người thật; tiêu đề sẽ được thêm tiền tố [TEST].
    /// </summary>
    public string? RedirectTo { get; set; }
}

public interface IMailSender
{
    /// <summary>
    /// Cấu hình có đang cho gửi thật không. Dùng để màn hình nói đúng sự thật:
    /// hiện "mail sẽ gửi cho A, B" trong khi Mail:Enabled = false là nói dối
    /// người duyệt, và họ sẽ đi tìm lá mail không bao giờ tới.
    /// </summary>
    bool Enabled { get; }

    /// <summary>
    /// Gửi mail HTML. KHÔNG ném lỗi: hàm này được gọi sau khi nghiệp vụ đã ghi
    /// xong, nên mail lỗi không được phép làm đổ nghiệp vụ. Trả về true nếu đã
    /// gửi đi, false nếu bị tắt / thiếu cấu hình / gửi lỗi (đều có log).
    /// </summary>
    /// <param name="onBehalfOfName">
    /// Tên người vừa thao tác, dùng làm tên hiển thị của Reply-To. KHÔNG đưa
    /// vào tên người gửi: đây là thư tự động, để tên người vào đó làm hộp thư
    /// đến trông như thư cá nhân.
    /// </param>
    /// <param name="onBehalfOfEmail">
    /// Mail người vừa thao tác, đặt vào Reply-To: người nhận bấm Trả lời là
    /// thư về thẳng người đó, không về hộp thư hệ thống. Rỗng thì bỏ qua.
    /// </param>
    Task<bool> SendAsync(IReadOnlyList<MailRecipient> recipients, string subject, string htmlBody,
        string? onBehalfOfName = null, string? onBehalfOfEmail = null,
        CancellationToken ct = default);
}

/// <summary>
/// Gửi qua relay SMTP nội bộ bằng System.Net.Mail — đúng cách job gửi mail của
/// nhà máy đang làm.
///
/// Vì sao dùng System.Net.Mail chứ không phải MailKit: tài liệu Microsoft
/// khuyến nghị MailKit cho dự án mới, NHƯNG SmtpClient KHÔNG bị đánh dấu
/// [Obsolete] nên không sinh warning lúc build, và relay nội bộ không cần
/// TLS/đăng nhập — tức không dùng tới phần mà SmtpClient yếu. Thêm một package
/// nữa ở đây không đổi được gì. Nếu sau này relay bắt buộc STARTTLS hoặc phải
/// đăng nhập thì đổi sang MailKit (MIT): chỉ phải viết lại class này.
/// </summary>
public class SmtpMailSender : IMailSender
{
    private readonly MailOptions _opt;
    private readonly ILogger<SmtpMailSender> _logger;

    public SmtpMailSender(IConfiguration config, ILogger<SmtpMailSender> logger)
    {
        _opt = config.GetSection(MailOptions.Section).Get<MailOptions>() ?? new MailOptions();
        _logger = logger;
    }

    /// <summary>
    /// Đúng BA điều kiện mà SendAsync dùng để quyết định bỏ qua. Phải khớp y
    /// hệt, nếu không màn hình sẽ báo "sẽ gửi" cho một cấu hình mà SendAsync
    /// lặng lẽ bỏ qua — tức là lại tạo ra đúng loại lỗi âm thầm đang muốn diệt.
    /// </summary>
    public bool Enabled => _opt.Enabled
                           && !string.IsNullOrWhiteSpace(_opt.Host)
                           && !string.IsNullOrWhiteSpace(_opt.From);

    public async Task<bool> SendAsync(IReadOnlyList<MailRecipient> recipients, string subject,
        string htmlBody, string? onBehalfOfName = null, string? onBehalfOfEmail = null,
        CancellationToken ct = default)
    {
        var to = Pick(recipients, "TO");
        var cc = Pick(recipients, "CC");
        var bcc = Pick(recipients, "BCC");

        if (to.Count == 0 && cc.Count == 0 && bcc.Count == 0)
        {
            _logger.LogWarning("Mail [{Subject}]: khong co nguoi nhan nao — bo qua.", subject);
            return false;
        }

        if (!_opt.Enabled || string.IsNullOrWhiteSpace(_opt.Host) || string.IsNullOrWhiteSpace(_opt.From))
        {
            // Không cấu hình thì ghi log ĐỦ để biết đáng ra gửi cho ai — hữu ích ở dev.
            _logger.LogInformation(
                "Mail [{Subject}] KHONG GUI (Mail:Enabled={Enabled}, Host={Host}). TO: {To} | CC: {Cc}",
                subject, _opt.Enabled, _opt.Host ?? "(trong)",
                string.Join(", ", to), string.Join(", ", cc));
            return false;
        }

        // Chặn đổi dòng trong tiêu đề: ký tự CR/LF ở header là lỗ hổng chèn header.
        subject = (subject ?? string.Empty).Replace('\r', ' ').Replace('\n', ' ').Trim();

        var redirect = !string.IsNullOrWhiteSpace(_opt.RedirectTo);
        if (redirect) subject = "[TEST] " + subject;

        try
        {
            // Địa chỉ gửi LUÔN là địa chỉ hệ thống; chỉ tên hiển thị mang tên
            // người thao tác. Gửi bằng chính địa chỉ của họ sẽ bị SPF/DMARC
            // của tên miền coi là mạo danh vì server SWMS không nằm trong danh
            // sách được phép gửi thay họ.
            // Tên người gửi chỉ là tên hệ thống. Ai vừa thao tác thì xem trong
            // thân mail và ở Reply-To — nhét tên họ vào đây làm hộp thư đến
            // trông như thư cá nhân, trong khi đó là thư tự động.
            var fromName = _opt.FromName ?? _opt.From!;

            using var msg = new MailMessage
            {
                From = new MailAddress(_opt.From!, fromName, Encoding.UTF8),
                Subject = subject,
                Body = htmlBody,
                IsBodyHtml = true,

                // KHÔNG đặt ba dòng này thì tiếng Việt có dấu ra ký tự rác:
                // System.Net.Mail mặc định theo nội dung, gặp ký tự ngoài ASCII
                // mà không được chỉ định bảng mã thì Outlook đoán sai.
                // HeadersEncoding cho tên hiển thị có dấu ở From và Reply-To.
                SubjectEncoding = Encoding.UTF8,
                BodyEncoding = Encoding.UTF8,
                HeadersEncoding = Encoding.UTF8,
            };

            // Reply-To bọc riêng: địa chỉ hỏng chỉ làm mất nút Trả lời đúng
            // người, KHÔNG được làm đổ cả mail. MailAddress ném FormatException
            // với chuỗi không phải địa chỉ hợp lệ.
            if (!string.IsNullOrWhiteSpace(onBehalfOfEmail))
            {
                try
                {
                    msg.ReplyToList.Add(new MailAddress(
                        onBehalfOfEmail.Trim(),
                        string.IsNullOrWhiteSpace(onBehalfOfName) ? onBehalfOfEmail.Trim() : onBehalfOfName.Trim(),
                        Encoding.UTF8));
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Reply-To '{Addr}' khong hop le — bo qua, mail van gui.",
                        onBehalfOfEmail);
                }
            }

            if (redirect)
            {
                // Dev: dồn hết về 1 hộp thư, ghi danh sách thật vào đầu thân mail
                msg.To.Add(_opt.RedirectTo!);
                msg.Body = $"<p style='background:#fff3cd;padding:8px;border:1px solid #ffe082'>"
                         + $"<b>Mail test</b> — bản thật sẽ gửi TO: {string.Join(", ", to)}"
                         + (cc.Count > 0 ? $" | CC: {string.Join(", ", cc)}" : "")
                         + "</p>" + htmlBody;
            }
            else
            {
                AddAll(msg.To, to, "TO");
                AddAll(msg.CC, cc, "CC");
                AddAll(msg.Bcc, bcc, "BCC");

                // Mọi địa chỉ đều hỏng thì đừng gọi SMTP làm gì — SendMailAsync
                // sẽ ném, và dòng log ngoại lệ khó hiểu hơn câu này nhiều.
                if (msg.To.Count == 0 && msg.CC.Count == 0 && msg.Bcc.Count == 0)
                {
                    _logger.LogWarning(
                        "Mail [{Subject}]: khong con dia chi nao hop le sau khi loc — bo qua.", subject);
                    return false;
                }
            }

            using var client = new SmtpClient(_opt.Host, _opt.Port)
            {
                Timeout = Math.Max(1, _opt.TimeoutSeconds) * 1000
            };

            await client.SendMailAsync(msg, ct);

            _logger.LogInformation("Mail [{Subject}] da gui. TO: {To} | CC: {Cc}",
                subject, string.Join(", ", to), string.Join(", ", cc));
            return true;
        }
        catch (Exception ex)
        {
            // Nuốt lỗi CÓ CHỦ Ý: phiếu đã duyệt xong rồi, không thể vì relay mail
            // chết mà làm người duyệt thấy báo lỗi và bấm lại.
            _logger.LogError(ex, "Mail [{Subject}] GUI LOI. Host={Host}:{Port} TO: {To}",
                subject, _opt.Host, _opt.Port, string.Join(", ", to));
            return false;
        }
    }

    /// <summary>
    /// Thêm từng địa chỉ MỘT, mỗi cái một try/catch. Trước đây gọi
    /// <c>msg.To.Add(a)</c> trong khối try chung: một địa chỉ gõ sai là
    /// <see cref="FormatException"/> bay lên và MẤT CẢ LÁ MAIL. Từ khi một ô
    /// cấu hình chứa được cả nhóm mười người, xác suất có một người gõ sai cao
    /// hẳn lên, nên để chung là hỏng cả nhóm vì một dấu cách thừa.
    /// </summary>
    /// <summary>
    /// Thêm địa chỉ vào một ô người nhận.
    ///
    /// MỘT dòng cấu hình có thể chứa nhiều địa chỉ cách nhau bởi dấu phẩy hoặc
    /// chấm phẩy — đó là cách khai một nhóm (OQC, FA, SCS) mà không phải tạo
    /// mỗi người một dòng. Phép tách nằm ở đây, chỗ duy nhất mọi module đi qua
    /// khi gửi, nên module nào cũng dùng được nhóm. Trước đây chỉ
    /// NgReportRepository tách, nên nhóm chỉ chạy cho Hàng bất thường; module
    /// khác gõ nhóm vào là MailAddress ném lỗi và mất người nhận.
    ///
    /// Mỗi địa chỉ một try/catch: một chỗ gõ sai không được làm mất cả nhóm.
    /// </summary>
    private void AddAll(MailAddressCollection target, List<string> addrs, string label)
    {
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var raw in addrs)
        {
            var parts = (raw ?? string.Empty).Split(
                new[] { ',', ';' },
                StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

            foreach (var a in parts)
            {
                if (!seen.Add(a)) continue;   // cùng một địa chỉ khai hai lần thì bỏ

                try
                {
                    target.Add(new MailAddress(a));
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex,
                        "Dia chi {Label} '{Addr}' khong hop le — bo qua, mail van gui cho nhung nguoi con lai.",
                        label, a);
                }
            }
        }
    }

    /// <summary>Lọc theo loại người nhận, bỏ địa chỉ rỗng và trùng lặp.</summary>
    private static List<string> Pick(IReadOnlyList<MailRecipient> rs, string type)
        => rs.Where(r => string.Equals(r.Type, type, StringComparison.OrdinalIgnoreCase)
                         && !string.IsNullOrWhiteSpace(r.Email))
             .Select(r => r.Email.Trim())
             .GroupBy(e => e.ToLowerInvariant())
             .Select(g => g.First())
             .ToList();
}
