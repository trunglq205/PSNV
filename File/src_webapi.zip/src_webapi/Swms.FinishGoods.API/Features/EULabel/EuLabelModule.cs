using Swms.FinishGoods.API.Features.EuLabel.Business;
using Swms.FinishGoods.API.Features.EuLabel.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.EuLabel;

public static class EuLabelModule
{
    public static IServiceCollection AddEuLabelFeature(this IServiceCollection services)
    {
        // Connection factory riêng cho DB In tem EU (stateless -> singleton).
        services.AddSingleton<IEuLabelDbConnectionFactory, EuLabelDbConnectionFactory>();
        services.AddScoped<IEuLabelService, EuLabelService>();
        services.AddScoped<IEuLabelRepository, EuLabelRepository>();
        return services;
    }
}
