namespace Swms.FinishGoods.API.Features.WarehouseAreas.Api;

public record CreateWarehouseAreaRequest(
    string AreaCode,
    string AreaName,
    string MapType,        // storing | receiving | vanning
    int Cols,
    int Rows,
    decimal? CellMeters    // null -> mặc định 1.0
);

/// <summary>Update map (KHÔNG cho đổi map_type sau khi tạo).</summary>
public record UpdateWarehouseAreaRequest(
    string AreaName,
    int Cols,
    int Rows,
    decimal? CellMeters
);
