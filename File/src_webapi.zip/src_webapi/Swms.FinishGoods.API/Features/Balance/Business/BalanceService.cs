using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Balance.Api;
using Swms.FinishGoods.API.Features.Balance.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.Balance.Business;

public class BalanceService : IBalanceService
{
    private readonly IBalanceRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public BalanceService(IBalanceRepository repo, ICurrentUser currentUser, IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo; _currentUser = currentUser; _localizer = localizer;
    }

    public async Task<IReadOnlyList<BalanceDocSummaryResponse>> GetDocsAsync(string? status)
        => (await _repo.GetDocsAsync(status)).Select(BalanceDocSummaryResponse.From).ToList();

    public async Task<BalanceDocDetailResponse> GetDocAsync(long id)
    {
        var d = await _repo.GetDocAsync(id)
                ?? throw new NotFoundException(_localizer["Balance.Err.DocNotFound"]);
        return new BalanceDocDetailResponse(
            BalanceDocSummaryResponse.From(d.Header),
            d.Lines.Select(BalanceLineResponse.From).ToList());
    }

    public Task SetLineResolutionAsync(long docId, long lineId, SetResolutionRequest request)
    {
        var r = Normalize(request.Resolution);
        return _repo.SetLinesResolutionAsync(docId, new[] { lineId }, r, _currentUser.UserId);
    }

    public Task SetLinesResolutionAsync(long docId, BulkResolutionRequest request)
    {
        if (request.LineIds is null || request.LineIds.Count == 0)
            throw new BusinessRuleException(_localizer["Balance.Err.NoLinesSelected"]);
        var r = Normalize(request.Resolution);
        return _repo.SetLinesResolutionAsync(docId, request.LineIds, r, _currentUser.UserId);
    }

    public async Task<IssueFaResultResponse> IssueFaAsync(long docId)
    {
        try
        {
            var r = await _repo.IssueFaAsync(docId, _currentUser.UserId);
            return IssueFaResultResponse.From(r);
        }
        catch (InvalidOperationException)
        {
            throw new BusinessRuleException(_localizer["Balance.Err.UnresolvedRemaining"]);
        }
    }

    private string Normalize(string s)
    {
        var v = (s ?? string.Empty).Trim().ToLowerInvariant();
        if (v != "count" && v != "system")
            throw new BusinessRuleException(_localizer["Balance.Err.InvalidResolution"]);
        return v;
    }
}
