using Microsoft.AspNetCore.Components;
using Swms.FinishGoods.Web.Features.Models.Business.Models;

namespace Swms.FinishGoods.Web.Features.Models.App.Pages;

// Chon dong + hanh dong hang loat cho man Models.
// Ten file dang Models.razor.Selection.cs de Visual Studio tu nest duoi Models.razor.
public partial class Models
{
    // Luu Id cac dong duoc chon.
    private readonly HashSet<int> _selected = new();

    // Header: tat ca dong tren trang deu duoc chon
    private bool _headerChecked =>
        Items.Count > 0 && Items.All(m => _selected.Contains(m.Id));

    // Header: chon mot phan (hien dau gach ngang)
    private bool _headerIndeterminate =>
        _selected.Count > 0 && !_headerChecked;

    private void ToggleRow(int id, ChangeEventArgs e)
    {
        var on = e.Value is bool b && b;
        if (on) _selected.Add(id);
        else _selected.Remove(id);
    }

    private void ToggleSelectAll(ChangeEventArgs e)
    {
        var on = e.Value is bool b && b;
        if (on)
            foreach (var m in Items) _selected.Add(m.Id);
        else
            foreach (var m in Items) _selected.Remove(m.Id);
    }

    private void ClearSelection() => _selected.Clear();

    // Cac model dang duoc chon tren trang hien tai
    private List<AppModel> SelectedItems =>
        Items.Where(m => _selected.Contains(m.Id)).ToList();

    // ===== Hanh dong hang loat =====
    // Khi backend co endpoint bulk-update/bulk-delete, goi qua ModelBusiness
    // cho nhat quan voi cac thao tac trong Models.razor.Crud.cs.

    private async Task BulkActivate()
    {
        var ids = _selected.ToList();
        // await ModelBusiness.SetActiveAsync(ids, true);
        await Task.CompletedTask;
        ClearSelection();
        await ReloadAsync();
    }

    private async Task BulkDeactivate()
    {
        var ids = _selected.ToList();
        // await ModelBusiness.SetActiveAsync(ids, false);
        await Task.CompletedTask;
        ClearSelection();
        await ReloadAsync();
    }

    private async Task BulkExport()
    {
        var ids = _selected.ToList();
        // await ExportService.ExportModelsAsync(ids);
        await Task.CompletedTask;
    }

    private async Task BulkDelete()
    {
        var ids = _selected.ToList();
        // Nen bat dialog xac nhan truoc khi xoa (giong OpenDeleteConfirm).
        // await ModelBusiness.DeleteManyAsync(ids);
        await Task.CompletedTask;
        ClearSelection();
        await ReloadAsync();
    }
}
