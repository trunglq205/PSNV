﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class BackFlushViewModel : TableViewModel<BackFlush, BackFlushFilter>
    {
        public ReceivingSchedule? ReceivingSchedule { get; set; }
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, BackFlushFilter? filter = null)
        {
            return new
            {
                PlanOderNumber = filter?.PlanOderNumber ?? Filter.PlanOderNumber,
                Material = filter?.Material ?? Filter.Material,
                Plant = filter?.Plant ?? Filter.Plant,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                ProductionVersion = filter?.ProductionVersion ?? Filter.ProductionVersion,
                Status = filter?.Status ?? Filter.Status,
                Date = (filter?.Date ?? Filter.Date)?.ToString("yyyy-MM-dd"),
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
