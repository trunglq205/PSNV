using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using ShippingScs.Web.Models;
using ShippingScs.Web.Services;

namespace ShippingScs.Web.Controllers;

public class HomeController : Controller
{
    private readonly ChangeLogService _log;

    public HomeController(ChangeLogService log) => _log = log;

    public IActionResult Index() => View();

    /// <summary>Nhật ký thay đổi, lọc theo loại/khoá.</summary>
    [Authorize(Roles = Roles.AdminOrPic)]
    public async Task<IActionResult> ChangeLog(string? entityType, string? entityKey)
    {
        ViewBag.EntityType = entityType;
        ViewBag.EntityKey = entityKey;
        var rows = await _log.ListAsync(
            string.IsNullOrWhiteSpace(entityType) ? null : entityType.Trim(),
            string.IsNullOrWhiteSpace(entityKey) ? null : entityKey.Trim());
        return View(rows);
    }

    [AllowAnonymous]
    public IActionResult Error() => View();
}
