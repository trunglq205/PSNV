using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.ShipmentTrips.Api;
using Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

public interface ITripMergeService
{
    /// <summary>PDA quét pallet gốc -> phiên gộp theo kế hoạch vanning: pallet soạn của Stowage Plan chứa
    /// thùng của pallet này, thùng theo thứ tự xếp của Web, pallet / thùng cần ghép vào. Không có kế hoạch -> lỗi.</summary>
    Task<TripMergeSessionResponse> OpenAsync(long tripId, string baseCode);

    /// <summary>Màn Pallet List quét pallet trước, không chọn chuyến: pallet -> SI -> chuyến còn mở có kế hoạch
    /// vanning chứa thùng của pallet. Trả id chuyến (thường 1; SI chia nhiều chuyến thì nhiều). Không có -> lỗi.</summary>
    Task<List<long>> FindTripsOfPalletAsync(string code);

    /// <summary>Tra 1 mã quét ngoài gợi ý (pallet hoặc thùng). Không thuộc chuyến -> lỗi.</summary>
    Task<TripMergeCandidateResponse> LookupAsync(long tripId, string baseCode, string code);

    Task<TripMergeResultResponse> MergeAsync(long tripId, TripMergeRequest request);
}

/*  Gộp hàng trên PDA (trước đây là màn Vanning riêng), gắn theo CHUYẾN XE:
    "cùng SI · cùng tuyến" = cùng chuyến (chuyến đã gom SI cùng FWD, cùng ngày, cùng loại cont).

    Pallet List theo KẾ HOẠCH VANNING (Stowage Plan của chuyến, lập trên Web):
      quét pallet gốc -> tìm pallet soạn (stowage_pallets) đang chứa thùng của nó (nhiều thùng nhất).
      Không có -> lỗi "không có kế hoạch vanning". Có -> trả thùng của pallet soạn theo đúng thứ tự Web
      lưu (gợi ý thứ tự xếp), pallet thật nào đang giữ các thùng còn thiếu. Xác nhận gộp chỉ nhận thùng
      thuộc pallet soạn đó — pallet nguồn lẫn thùng của pallet soạn khác phải quét từng thùng.

    Pallet List — gộp pallet / thùng vào pallet gốc:
      KHÔNG có bảng riêng. Mỗi pallet nguồn = 1 lần "tách pallet sang pallet có sẵn"
      (IPalletService.SplitAsync, cùng nghiệp vụ POST /api/pallets/split) nên giữ nguyên
      mọi quy tắc + event PALLET_SPLIT_OUT / IN / BOX_MOVED_PALLET của màn Tách pallet:
      cùng category, cùng detail_level, khác model phải xác nhận.
      Pallet box_count (không có dòng thùng) không gộp được kiểu này.

    Ghép cọc (pallet đôi) KHÔNG còn ở đây — đi theo cọc của Stowage Plan (TripStowageService).

    Chỉ khi chuyến còn mở (planned / arrived / sealed — đã đóng chì vẫn gộp được trên bãi
    trước khi xe ra là bất thường, nhưng không chặn để không kẹt hàng).                  */
public class TripMergeService : ITripMergeService
{
    private const string BoxCountLevel = "box_count";
    private static readonly HashSet<string> OpenStatuses = new() { "planned", "arrived", "sealed" };

    private readonly IShipmentTripRepository _trips;
    private readonly ITripVanningRepository _repo;
    private readonly ITripStowageRepository _stowage;
    private readonly IPalletService _pallets;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public TripMergeService(
        IShipmentTripRepository trips,
        ITripVanningRepository repo,
        ITripStowageRepository stowage,
        IPalletService pallets,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _trips = trips;
        _repo = repo;
        _stowage = stowage;
        _pallets = pallets;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Phiên gộp
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripMergeSessionResponse> OpenAsync(long tripId, string baseCode)
    {
        var trip = await OpenTripAsync(tripId);
        var basePallet = await BaseAsync(tripId, baseCode);
        var plan = await PlanOfAsync(tripId, basePallet);

        // Gợi ý = đúng những gì kế hoạch cần: pallet lấy cả (mọi thùng đều thuộc kế hoạch) + từng thùng cần lấy.
        var candidates = plan.Sources.Where(x => x.Whole)
            .Select(x => new TripMergeCandidateResponse(
                x.PalletCode, "pallet", x.LocatorCode, x.Needed,
                plan.Boxes.Where(b => b.PalletId == x.PalletId).Sum(b => b.Pcs)))
            .Concat(plan.Boxes.Where(b => b.Status == SourceStatus)
                .Select(b => new TripMergeCandidateResponse(b.BoxNo!, "box", b.LocatorCode, 1, b.Pcs)))
            .ToList();

        var stacks = await _repo.GetStacksAsync(tripId);
        var column = await ColumnOfAsync(plan, basePallet, stacks);

        return new TripMergeSessionResponse(
            basePallet.Code, basePallet.BoxCount == 0, basePallet.SiNo, trip.ForwarderCode,
            basePallet.BoxCount, basePallet.Pcs,
            candidates,
            stacks.Select(TripStackResponse.From).ToList(),
            plan.ToResponse(column));
    }

    public async Task<List<long>> FindTripsOfPalletAsync(string code)
    {
        code = Clean(code);
        var pallet = await _repo.FindPalletAsync(0, code)
            ?? throw new NotFoundException(_localizer["Trip.Merge.BaseNotFound", code]);

        var tripIds = await _repo.GetOpenTripIdsBySisAsync(await _stowage.GetPalletSiIdsAsync(pallet.Id));
        if (tripIds.Count == 0)
            throw new BusinessRuleException(_localizer["Trip.Merge.PalletNoTrip", code]);

        // Chỉ giữ chuyến có kế hoạch vanning chứa thùng của pallet này.
        var found = new List<long>();
        string? planNo = null;
        foreach (var id in tripIds.OrderBy(x => x))
        {
            if (await _stowage.GetPlanAsync(id) is not { } plan) continue;
            planNo ??= plan.PlanNo;
            if ((await _stowage.FindPlanPalletsOfAsync(plan.PlanId, plan.ContainerIndex, pallet.Id)).Count > 0)
                found.Add(id);
        }
        if (found.Count > 0) return found;

        throw new BusinessRuleException(planNo is null
            ? _localizer["Trip.Merge.NoPlan"]
            : _localizer["Trip.Merge.NotInPlan", code, planNo]);
    }

    public async Task<TripMergeCandidateResponse> LookupAsync(long tripId, string baseCode, string code)
    {
        await OpenTripAsync(tripId);
        var basePallet = await BaseAsync(tripId, baseCode);
        code = Clean(code);

        if (string.Equals(code, basePallet.Code, StringComparison.OrdinalIgnoreCase))
            throw new BusinessRuleException(_localizer["Trip.Merge.ItemIsBase"]);

        // Mã pallet trước (12 số), không có thì coi là số thùng
        if (await _repo.FindPalletAsync(tripId, code) is { } p)
        {
            if (!p.InScope)
                throw new BusinessRuleException(_localizer["Trip.Merge.ItemNotInTrip", code]);
            return ToCandidate(p);
        }

        var box = await PickBoxAsync(tripId, code, basePallet.Id);
        return new TripMergeCandidateResponse(box.BoxNo, "box", box.LocatorCode, 1, box.Pcs);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Xác nhận gộp
    // ═══════════════════════════════════════════════════════════════

    public async Task<TripMergeResultResponse> MergeAsync(long tripId, TripMergeRequest r)
    {
        await OpenTripAsync(tripId);
        var basePallet = await BaseAsync(tripId, r.BaseCode);

        var palletCodes = Codes(r.PalletCodes);
        var boxCodes = Codes(r.BoxCodes);
        if (palletCodes.Count + boxCodes.Count == 0)
            throw new BusinessRuleException(_localizer["Trip.Merge.Empty"]);

        // Ghép cọc giờ theo Stowage Plan (TripStowageService) — không ghép ở đây nữa.
        if (r.DoublePallet)
            throw new BusinessRuleException(_localizer["Trip.Merge.UseStowage"]);
        var plan = await PlanOfAsync(tripId, basePallet);
        return await MergeListAsync(tripId, basePallet, plan, palletCodes, boxCodes, r.ConfirmModelMismatch);
    }

    /// <summary>Pallet List: chuyển thùng của từng pallet / thùng nguồn sang pallet gốc.</summary>
    private async Task<TripMergeResultResponse> MergeListAsync(
        long tripId, TripPalletInfo basePallet, MergePlan plan,
        List<string> palletCodes, List<string> boxCodes, bool confirmModelMismatch)
    {
        if (basePallet.DetailLevel == BoxCountLevel)
            throw new BusinessRuleException(_localizer["Trip.Merge.BoxCountPallet", basePallet.Code]);

        // Kiểm HẾT trước khi chuyển thùng nào: lỗi dữ liệu (mã sai, không thuộc chuyến,
        // pallet box_count…) phải chặn từ đầu, không để gộp dở dang.
        var sources = new Dictionary<string, List<long>>(StringComparer.OrdinalIgnoreCase);

        foreach (var code in palletCodes)
        {
            var p = await ScopePalletAsync(tripId, code, basePallet.Id, plan.SourcePalletIds);
            if (p.DetailLevel == BoxCountLevel)
                throw new BusinessRuleException(_localizer["Trip.Merge.BoxCountPallet", p.Code]);

            var ids = await _repo.GetBoxIdsAsync(p.Id);
            if (ids.Count == 0)
                throw new BusinessRuleException(_localizer["Trip.Merge.PalletEmpty", p.Code]);
            sources[p.Code] = ids;
        }

        foreach (var code in boxCodes)
        {
            var b = await PickBoxAsync(tripId, code, basePallet.Id);
            if (!sources.TryGetValue(b.LotCode, out var ids))
                sources[b.LotCode] = ids = new List<long>();
            if (!ids.Contains(b.Id)) ids.Add(b.Id);       // pallet nguồn đã gộp cả -> thùng đã có sẵn
        }

        // Chỉ nhận thùng thuộc pallet soạn của kế hoạch: lấy cả pallet nguồn mà pallet đó còn thùng
        // của pallet soạn khác -> chặn, bắt quét từng thùng cần lấy.
        foreach (var (sourceCode, ids) in sources)
        {
            var stray = ids.Count(id => !plan.SourceBoxIds.Contains(id));
            if (stray > 0)
                throw new BusinessRuleException(palletCodes.Contains(sourceCode, StringComparer.OrdinalIgnoreCase)
                    ? _localizer["Trip.Merge.PalletNotWhole", sourceCode, stray, plan.Pallet.Code]
                    : _localizer["Trip.Merge.NotInPlanPallet", sourceCode, plan.Pallet.Code]);
        }

        // Pallet gốc thành Pallet List của chuyến TRƯỚC khi chuyển thùng: pallet rỗng mới lấy ra
        // không thuộc SI nào, không ghi thì sau khi gộp nó "không thuộc chuyến" — không ghép cọc,
        // không chụp ảnh được. Gộp lỗi hết thì pallet vẫn rỗng, bị lọc khỏi danh sách ảnh.
        await _repo.AddTripPalletAsync(tripId, basePallet.Id, Actor);

        // Mỗi pallet nguồn 1 transaction (của SplitAsync). Lỗi giữa chừng (vd khác model,
        // khác category) -> báo rõ đã gộp xong những pallet nào để người dùng không gộp lại.
        var done = new List<string>();
        foreach (var (sourceCode, boxIds) in sources)
        {
            try
            {
                await _pallets.SplitAsync(new SplitPalletRequest(
                    sourceCode, boxIds, SplitTargetType.Existing, basePallet.Code,
                    ConfirmModelMismatch: confirmModelMismatch));
                done.Add(sourceCode);
            }
            catch (Exception ex) when (done.Count > 0
                                       && ex is BusinessRuleException or ConflictException or NotFoundException)
            {
                throw new BusinessRuleException(
                    _localizer["Trip.Merge.Partial", string.Join(", ", done), sourceCode, ex.Message]);
            }
        }

        var after = await _repo.FindPalletAsync(tripId, basePallet.Code) ?? basePallet;
        return new TripMergeResultResponse(after.Code, after.BoxCount, after.Pcs, null);
    }

    // ═══════════════════════════════════════════════════════════════
    //  Kiểm tra
    // ═══════════════════════════════════════════════════════════════

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    private async Task<TripRow> OpenTripAsync(long tripId)
    {
        var trip = await _trips.GetAsync(tripId)
            ?? throw new NotFoundException(_localizer["Trip.NotFound", tripId]);
        if (!OpenStatuses.Contains(trip.Status))
            throw new BusinessRuleException(_localizer["Trip.Merge.Locked", trip.Status]);
        return trip;
    }

    /// <summary>Pallet gốc: thuộc chuyến, HOẶC pallet rỗng vừa tạo làm Pallet List mới.</summary>
    private async Task<TripPalletInfo> BaseAsync(long tripId, string? code)
    {
        code = Clean(code);
        var p = await _repo.FindPalletAsync(tripId, code)
            ?? throw new NotFoundException(_localizer["Trip.Merge.BaseNotFound", code]);
        if (!p.InScope && p.BoxCount > 0)
            throw new BusinessRuleException(_localizer["Trip.Merge.BaseNotInTrip", code]);
        return p;
    }

    /// <summary>Pallet nguồn: thuộc chuyến, hoặc đang giữ thùng của kế hoạch ([planPalletIds]).</summary>
    private async Task<TripPalletInfo> ScopePalletAsync(
        long tripId, string code, long baseId, IReadOnlySet<long> planPalletIds)
    {
        var p = await _repo.FindPalletAsync(tripId, code)
            ?? throw new NotFoundException(_localizer["Trip.Merge.ItemNotFound", code]);
        if (p.Id == baseId)
            throw new BusinessRuleException(_localizer["Trip.Merge.ItemIsBase"]);
        if (!p.InScope && !planPalletIds.Contains(p.Id))
            throw new BusinessRuleException(_localizer["Trip.Merge.ItemNotInTrip", code]);
        return p;
    }

    /// <summary>Số thùng chỉ unique trong 1 pallet — lọc theo chuyến, còn trùng thì bắt quét lại bằng mã khác.</summary>
    private async Task<TripBoxInfo> PickBoxAsync(long tripId, string code, long baseId)
    {
        var all = await _repo.FindBoxesAsync(tripId, code);
        if (all.Count == 0)
            throw new NotFoundException(_localizer["Trip.Merge.ItemNotFound", code]);

        var inScope = all.Where(b => b.InScope).ToList();
        if (inScope.Count == 0)
            throw new BusinessRuleException(_localizer["Trip.Merge.ItemNotInTrip", code]);
        if (inScope.Count > 1)
            throw new BusinessRuleException(_localizer["Trip.Merge.BoxAmbiguous", code]);
        if (inScope[0].LotId == baseId)
            throw new BusinessRuleException(_localizer["Trip.Merge.BoxOnBase", code]);
        return inScope[0];
    }

    // ═══════════════════════════════════════════════════════════════
    //  Kế hoạch vanning (Stowage Plan)
    // ═══════════════════════════════════════════════════════════════

    private const string BaseStatus = "base";
    private const string SourceStatus = "source";
    private const string MissingStatus = "missing";

    /// <summary>Pallet soạn của plan chứa thùng của pallet gốc (nhiều thùng nhất).
    /// Chuyến chưa có plan / pallet không có thùng nào trong plan -> lỗi.</summary>
    private async Task<MergePlan> PlanOfAsync(long tripId, TripPalletInfo basePallet)
    {
        var plan = await _stowage.GetPlanAsync(tripId)
            ?? throw new BusinessRuleException(_localizer["Trip.Merge.NoPlan"]);
        var matches = await _stowage.FindPlanPalletsOfAsync(plan.PlanId, plan.ContainerIndex, basePallet.Id);
        if (matches.Count == 0)
            throw new BusinessRuleException(_localizer["Trip.Merge.NotInPlan", basePallet.Code, plan.PlanNo]);

        var target = matches[0];
        var rows = await _stowage.GetPlanPalletBoxesAsync(target.StowagePalletId);
        var boxes = rows.Select((r, i) => new MergePlanBox(
            i + 1,
            r.BoxId is null ? PlanKey(r) : r.BoxNo ?? PlanKey(r),
            r.Model,
            r.BoxId is null || r.PalletId is null ? MissingStatus
                : r.PalletId == basePallet.Id ? BaseStatus : SourceStatus,
            r.BoxId, r.PalletId, r.PalletCode, r.LocatorCode, r.PalletBoxCount, r.Pcs)).ToList();

        var inPlan = boxes.Where(b => b.BoxId is not null).Select(b => b.BoxId!.Value).ToHashSet();
        var extra = (await _stowage.GetPalletBoxesAsync(basePallet.Id))
            .Where(b => !inPlan.Contains(b.Id)).Select(b => b.BoxNo).ToList();

        return new MergePlan(plan.PlanId, plan.PlanNo, target, boxes, extra);
    }

    /// <summary>Cọc của pallet soạn: mỗi tầng đang ở Pallet List thật nào, đủ thùng chưa, đã ghép / xếp chưa.
    /// PDA dùng để ghép cọc luôn sau khi gộp (POST {id}/stowage/columns/{code}/stack).</summary>
    private async Task<TripMergeColumnResponse?> ColumnOfAsync(
        MergePlan plan, TripPalletInfo basePallet, List<TripStackRow> stacks)
    {
        var code = plan.Pallet.ColumnCode;
        if (string.IsNullOrWhiteSpace(code)) return null;

        var tiers = new List<TripMergeTierResponse>();
        foreach (var sp in await _stowage.GetColumnPalletsAsync(plan.PlanId, code))
        {
            if (sp.StowagePalletId == plan.Pallet.StowagePalletId)
            {
                var onBase = plan.Boxes.Count(b => b.Status == BaseStatus);
                tiers.Add(new(sp.Tier, sp.Code, basePallet.Code,
                    plan.Boxes.Count > 0 && onBase == plan.Boxes.Count, true, onBase, plan.Boxes.Count));
                continue;
            }
            // Tầng kia: Pallet List thật giữ nhiều thùng nhất của pallet soạn đó.
            var boxes = await _stowage.GetPlanPalletBoxesAsync(sp.StowagePalletId);
            var best = boxes.Where(b => b.PalletId is not null && b.BoxId is not null)
                .GroupBy(b => b.PalletCode ?? "")
                .OrderByDescending(g => g.Count()).ThenBy(g => g.Key)
                .FirstOrDefault();
            var done = best?.Count() ?? 0;
            tiers.Add(new(sp.Tier, sp.Code, best?.Key, boxes.Count > 0 && done == boxes.Count, false, done, boxes.Count));
        }

        var stack = stacks.FirstOrDefault(x => string.Equals(x.ColumnCode, code, StringComparison.OrdinalIgnoreCase));
        return new TripMergeColumnResponse(
            code, TripStowageRules.CocNoOf(code), tiers,
            stack?.BottomCode, stack?.TopCode, stack?.PlacedAt is not null);
    }

    /// <summary>Mã thùng như Web: box thật -> số box; thùng dự kiến -> "{si_no}/{line_no}/{seq:000}".</summary>
    private static string PlanKey(PlanPalletBoxRow r)
        => r.SiBoxId is not null && r.PlanBoxNo is not null
            ? r.PlanBoxNo
            : $"{r.SiNo}/{r.LineNo}/{r.CartonSeq:000}";

    private sealed record MergePlanBox(
        int Seq, string BoxNo, string? Model, string Status,
        long? BoxId, long? PalletId, string? PalletCode, string? LocatorCode, int PalletBoxCount, int Pcs);

    private sealed record MergeSource(long PalletId, string PalletCode, string? LocatorCode, int Needed, int BoxCount)
    {
        public bool Whole => Needed >= BoxCount;
    }

    private sealed class MergePlan
    {
        public long PlanId { get; }
        public string PlanNo { get; }
        public PlanPalletMatchRow Pallet { get; }
        public List<MergePlanBox> Boxes { get; }
        public List<string> Extra { get; }
        public List<MergeSource> Sources { get; }
        public HashSet<long> SourceBoxIds { get; }
        public HashSet<long> SourcePalletIds { get; }

        public MergePlan(long planId, string planNo, PlanPalletMatchRow pallet, List<MergePlanBox> boxes, List<string> extra)
        {
            PlanId = planId;
            PlanNo = planNo;
            Pallet = pallet;
            Boxes = boxes;
            Extra = extra;
            var src = boxes.Where(b => b.Status == SourceStatus).ToList();
            // Thứ tự pallet nguồn = thứ tự thùng đầu tiên của nó trong kế hoạch (lấy theo thứ tự xếp).
            Sources = src.GroupBy(b => b.PalletId!.Value)
                .Select(g => new MergeSource(g.Key, g.First().PalletCode ?? "", g.First().LocatorCode,
                    g.Count(), g.First().PalletBoxCount))
                .ToList();
            SourceBoxIds = src.Select(b => b.BoxId!.Value).ToHashSet();
            SourcePalletIds = Sources.Select(x => x.PalletId).ToHashSet();
        }

        public TripMergePlanResponse ToResponse(TripMergeColumnResponse? column) => new(
            PlanNo, Pallet.Code, Pallet.ColumnCode, Pallet.Tier, Pallet.SiNo, Pallet.PalletSize,
            Boxes.Count, Boxes.Count(b => b.Status == BaseStatus),
            Boxes.Select(b => new TripMergePlanBoxResponse(
                b.Seq, b.BoxNo, b.Model, b.Status, b.PalletCode, b.LocatorCode, b.Pcs)).ToList(),
            Sources.Select(x => new TripMergeSourceResponse(
                x.PalletCode, x.LocatorCode, x.Needed, x.BoxCount, x.Whole)).ToList(),
            Extra,
            column);
    }

    private static TripMergeCandidateResponse ToCandidate(TripPalletInfo p)
        => new(p.Code, "pallet", p.LocatorCode, p.BoxCount, p.Pcs);

    private static List<string> Codes(List<string>? v)
        => (v ?? new()).Select(Clean).Where(c => c.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();

    private static string Clean(string? v) => (v ?? "").Trim().ToUpperInvariant();
}