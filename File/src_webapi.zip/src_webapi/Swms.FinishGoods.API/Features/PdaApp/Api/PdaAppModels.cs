using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Http;

namespace Swms.FinishGoods.Api.Features.PdaApp.Api;

// ── REQUEST (input) ──────────────────────────────────────────────────────
// Công bố APK mới. Nhận qua multipart/form-data: file APK + release note + force update.
// versionName/versionCode KHÔNG do client gửi — server đọc từ chính file APK để tránh sai lệch.
public class PublishPdaAppRequest
{
    [Required]
    public IFormFile File { get; set; } = default!;

    [MaxLength(1000)]
    public string? ReleaseNote { get; set; }

    public bool ForceUpdate { get; set; }
}

// ── RESPONSE (output) ────────────────────────────────────────────────────
// Khớp field-for-field với PdaAppVersionDto ở tầng Web (PublishedAt là chuỗi dd/MM/yyyy).
public record PdaAppVersionResponse(
    long Id,
    string Version,
    int VersionCode,
    string ReleaseNote,
    string ApkUrl,
    long SizeBytes,
    bool ForceUpdate,
    bool IsCurrent,
    string PublishedAt)
{
    public static PdaAppVersionResponse From(PdaAppVersionEntity e)
        => new(e.Id, e.Version, e.VersionCode, e.ReleaseNote, e.ApkUrl,
               e.SizeBytes, e.ForceUpdate, e.IsCurrent,
               e.PublishedAt.ToString("dd/MM/yyyy"));
}
