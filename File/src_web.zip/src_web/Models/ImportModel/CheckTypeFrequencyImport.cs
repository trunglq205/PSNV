﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class CheckTypeFrequencyImport
    {
        public string? Material {  get; set; }
        public string? Sloc { get; set; }
        public string? Category { get; set; }
    }
}
