import 'package:swms_finish_goods/core/utils/printing/labels/label.dart';
import 'package:swms_finish_goods/core/utils/printing/sato/sbpl.dart';
import 'package:swms_finish_goods/core/utils/printing/tspl/tspl.dart';

/// Dữ liệu của một tem Part Card.
///
/// Field có TÊN thay vì `List<String?>`: thứ tự các `%s` trong template là
/// kiến thức ngầm, truyền lệch một vị trí thì không compiler nào bắt được
/// và tem in ra vẫn "hợp lệ" — chỉ sai chỗ.
class PartCardData extends Label {
  const PartCardData({
    required this.qrLarge,
    required this.qrSmall,
    required this.model,
    required this.qty,
    required this.origin,
    required this.category,
    required this.proDate,
    required this.dimensionCm3,
    required this.weightKg,
  });

  /// QR lớn (SBPL: H0042 V00186 size 04 — TSPL: 280,460 cell 5).
  final String qrLarge;

  /// QR nhỏ (SBPL: H0042 V00622 size 02 — TSPL: 300,24 cell 2).
  final String qrSmall;

  final String model;
  final String qty;
  final String origin;
  final String category;

  /// Đã format sẵn thành chuỗi hiển thị, ví dụ '28/07/2026'.
  final String proDate;

  /// Chỉ phần số — đơn vị 'cm3' đã nằm trong template.
  final String dimensionCm3;

  /// Chỉ phần số — đơn vị 'kg' đã nằm trong template.
  final String weightKg;

  PartCardData copyWith({
    String? qrLarge,
    String? qrSmall,
    String? model,
    String? qty,
    String? origin,
    String? category,
    String? proDate,
    String? dimensionCm3,
    String? weightKg,
  }) =>
      PartCardData(
        qrLarge: qrLarge ?? this.qrLarge,
        qrSmall: qrSmall ?? this.qrSmall,
        model: model ?? this.model,
        qty: qty ?? this.qty,
        origin: origin ?? this.origin,
        category: category ?? this.category,
        proDate: proDate ?? this.proDate,
        dimensionCm3: dimensionCm3 ?? this.dimensionCm3,
        weightKg: weightKg ?? this.weightKg,
      );

  // ═══ SBPL ════════════════════════════════════════════════════════════════

  /// Thứ tự PHẢI khớp với thứ tự `%s` xuất hiện trong [_sbplBody].
  /// Đổi template thì đổi cả list này.
  List<String> get _sbplValues => [
    ...qrPair(qrLarge), // 1-2: DN<len>,<data>
    ...qrPair(qrSmall), // 3-4: DN<len>,<data>
    qty, // 5: H0363 V00284
    origin, // 6: H0178 V00618
    model, // 7: H0363 V00613
    category, // 8: H0232 V00158
    proDate, // 9: H0232 V00495
    dimensionCm3, // 10: H0178 V00561 (+ ' cm3')
    weightKg, // 11: H0178 V00301 (+ ' kg')
  ];

  @override
  String get sbplSetup => _sbplSetup;

  /// Chuỗi SBPL của riêng block nhãn (chưa gồm block setup).
  @override
  String toSbpl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    return buildSbpl(_sbplBody, _sbplValues) +
        Sbpl.quantity(copies) +
        Sbpl.end +
        Sbpl.etx;
  }

  // Ký tự điều khiển viết dưới dạng escape (\x02 STX, \x03 ETX, \x1B ESC)
  // thay vì ký tự thật. Bản trong `Constants` cũ chứa 120 byte ESC VÔ HÌNH
  // trong source: copy/paste qua editor khác là mất sạch, và không ai nhìn
  // ra được cấu trúc lệnh.
  //
  // Block 1 — cấu hình khổ tem (ESC A ... ESC Z), gửi một lần mỗi phiên.
  static const _sbplSetup =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00639H0440\x1BZ';

  // Block 2 — nội dung nhãn, chứa 11 chỗ `%s`. KHÔNG chứa ESC Q<n> và ESC Z:
  // hai lệnh đó do [toSbpl] sinh ra để đổi được số bản in.
  static const _sbplBody =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00639H0440\x1BZ\x03\x02\x1BA\x1BPS\x1BW'
      'KLabel\x1B%0\x1BH0029\x1BV00013\x1BFW0404V0618H0380\x1B%0\x1BH0278\x1BV00013\x1BFW0404V0'
      '618H0074\x1B%0\x1BH0212\x1BV00013\x1BFW04V0618\x1B%0\x1BH0032\x1BV00196\x1BFW04H0185\x1B'
      '%0\x1BH0215\x1BV00301\x1BFW04H0191\x1B%0\x1BH0280\x1BV00148\x1BFW04H0124\x1B%1\x1BH0081'
      '\x1BV00510\x1BP02\x1BRH0,SATOSANS.ttf,1,046,051,Part Card\x1B%1\x1BH0042\x1BV00186\x1B2D'
      '30,L,04,1,0\x1BDN%s,%s\x1B%1\x1BH0042\x1BV00622\x1B2D30,L,02,1,0\x1BDN%s,%s\x1B%1\x1BH02'
      '32\x1BV00622\x1BP02\x1BRH0,SATOSANS.ttf,0,026,028,MFD:\x1B%1\x1BH0232\x1BV00289\x1BP02'
      '\x1BRH0,SATOSANS.ttf,0,026,028,Category:\x1B%1\x1BH0298\x1BV00510\x1BP02\x1BRH0,SATOSANS'
      '.ttf,0,026,028,Model\x1B%1\x1BH0300\x1BV00256\x1BP02\x1BRH0,SATOSANS.ttf,0,026,028,Qty'
      '\x1B%1\x1BH0304\x1BV00112\x1BP02\x1BRH0,SATOSANS.ttf,0,026,028,COO\x1B%1\x1BH0178\x1BV00'
      '618\x1BP02\x1BRH0,SATOSANS.ttf,0,021,023,Dim:\x1B%1\x1BH0178\x1BV00386\x1BP02\x1BRH0,SAT'
      'OSANS.ttf,0,021,023,Weight:\x1B%1\x1BH0363\x1BV00284\x1BP02\x1BRH0,SATOSANS.ttf,1,026,02'
      '8,%s\x1B%1\x1BH0364\x1BV00120\x1BP02\x1BRH0,SATOSANS.ttf,1,026,028,%s\x1B%1\x1BH0363\x1B'
      'V00613\x1BP02\x1BRH0,SATOSANS.ttf,1,026,028,%s\x1B%1\x1BH0232\x1BV00164\x1BP02\x1BRH0,SA'
      'TOSANS.ttf,1,026,028, %s\x1B%1\x1BH0232\x1BV00536\x1BP02\x1BRH0,SATOSANS.ttf,1,026,028, '
      '%s\x1B%1\x1BH0178\x1BV00561\x1BP02\x1BRH0,SATOSANS.ttf,1,021,023,%s cm3\x1B%1\x1BH0178'
      '\x1BV00301\x1BP02\x1BRH0,SATOSANS.ttf,1,021,023, %s kg\x1BQ1\x1BZ\x03';

  // ═══ TSPL ════════════════════════════════════════════════════════════════
  //
  // Toạ độ lấy NGUYÊN từ `tsplTest` đã in đúng trên MJ8001, chỉ thay literal
  // bằng field. Tem in xoay 90° (text rotation 90) nên "hàng" trong comment
  // là hàng THEO HƯỚNG ĐỌC TEM, không phải theo trục y của TSPL.
  // Khổ 51×80 mm = 408×640 dot (203 dpi).

  @override
  List<String> get tsplSetup => _tsplSetup;

  static const _tsplSetup = [
    'SIZE 51 mm,80 mm',
    'GAP 0,0',
    'DIRECTION 1,0',
    'REFERENCE 0,0',
    'DENSITY 8',
    'SPEED 4',
  ];

  @override
  List<String> toTspl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    return [
      Tspl.cls,

      // Khung ngoài
      Tspl.box(16, 16, 392, 624, 3),

      // 3 đường kẻ NGANG theo hướng đọc (chia 4 hàng)
      Tspl.bar(206, 16, 3, 608), // dưới khu QR + Part Card
      Tspl.bar(140, 16, 3, 608), // dưới MFD / Category
      Tspl.bar(74, 16, 3, 608), // dưới Model / Qty / Origin

      // 3 đường kẻ DỌC theo hướng đọc (chia cột)
      Tspl.bar(206, 444, 186, 3), // tách cột QR lớn (chỉ hàng trên)
      Tspl.bar(16, 337, 190, 3), // MFD|Category và Model|Qty
      Tspl.bar(16, 428, 124, 3), // Qty|Origin

      // Hàng 1: QR nhỏ, tiêu đề, Dim/Weight, QR lớn
      Tspl.qrcode(265, 24, 'L', 1, 'A', 0, qrSmall),
      Tspl.text(334, 200, '7', 90, 2, 1, 'Part Card'),
      Tspl.text(250, 30, '2', 90, 1, 1, 'Dim:'),
      Tspl.text(250, 90, '2', 90, 1, 1, '$dimensionCm3 cm3'),
      Tspl.text(250, 260, '2', 90, 1, 1, 'Weight:'),
      Tspl.text(250, 356, '2', 90, 1, 1, '$weightKg kg'),
      Tspl.qrcode(230, 455, 'L', 4, 'A', 0, qrLarge),

      // Hàng 2: MFD / Category
      Tspl.text(183, 30, '2', 90, 1, 1, 'MFD:'),
      Tspl.text(185, 150, '3', 90, 1, 1, proDate),
      Tspl.text(183, 350, '2', 90, 1, 1, 'Category:'),
      Tspl.text(185, 470, '3', 90, 1, 1, category),

      // Hàng 3: tiêu đề cột
      Tspl.text(119, 136, '3', 90, 1, 1, 'Model'),
      Tspl.text(119, 358, '3', 90, 1, 1, 'Qty'),
      Tspl.text(119, 478, '3', 90, 1, 1, 'Origin'),

      // Hàng 4: giá trị
      Tspl.text(57, 70, '3', 90, 1, 1, model),
      Tspl.text(57, 374, '3', 90, 1, 1, qty),
      Tspl.text(57, 460, '3', 90, 1, 1, origin),

      Tspl.print(copies),
    ];
  }
}