﻿namespace SWMS_WebTool.Models.Requests
{
    public class KittingListRequest
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Model { get; set; }
        public int ModelQuantity { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string SpecialPart { get; set; }
        public string PositionFA { get; set; }
        public string ReservationNo { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Material { get; set; }
        public string MaterialReplace { get; set; }
        public double QuantityReplace { get; set; }
        public string Descriptions { get; set; }
        public string Unit { get; set; }
        public double Quantity { get; set; }
        public byte KittingType { get; set; }
        public string? KittingTimeType { get; set; }
        public string Barcode { get; set; }
        public string BarcodeLine { get; set; }
        public string Sloc { get; set; }
        public Int64 LocationID { get; set; }
        public string PicUser { get; set; }
        public byte KittingStatus { get; set; }
        public byte SupplyStatus { get; set; }
        public string LocationName { get; set; }
        public string UploadNo { get; set; }
        public bool IsUrgent { get; set; }
        public bool IsJIT { get; set; }
        public bool IsProcess { get; set; }
        public bool IsCommon { get; set; }
        public List<KittingPlan> kittingPlans { get; set; }
    }
}
