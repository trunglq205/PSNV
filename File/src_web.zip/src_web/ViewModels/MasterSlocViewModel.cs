﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;

namespace SWMS_WebTool.ViewModels
{
    public class MasterSlocViewModel : TableViewModel<MasterSloc, MasterSlocFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, MasterSlocFilter? filter = null)
        {
            return new
            {
                Category = filter?.Category ?? Filter.Category,
                Plant = filter?.Plant ?? Filter.Plant,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Type = filter?.Type ?? Filter.Type,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class ImportMasterSlocViewModel
    {
        public string? Plant { get; set; }
        public string? Category { get; set; }
        public string? Sloc { get; set; }
        public string? Type { get; set; }
        public string? Address { get; set; }
        public string? Description { get; set; }
    }
}
