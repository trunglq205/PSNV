﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class CategoryViewModel : TableViewModel<Category, CategoryFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, CategoryFilter? filter = null)
        {
            return new
            {
                CategoryName = filter?.CategoryName ?? Filter.CategoryName,
                ShortName = filter?.ShortName ?? Filter.ShortName,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
        
    }
}
