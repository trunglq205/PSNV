import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_handler.dart';
import 'package:swms_finish_goods/core/utils/feedback/feedback_provider.dart';

final errorHandlerProvider = Provider<ErrorHandler>(
  (ref) =>
      ErrorHandler(ref.watch(appFeedbackProvider)),
);
