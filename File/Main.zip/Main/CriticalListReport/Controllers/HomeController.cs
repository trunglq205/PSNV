﻿using ClosedXML.Excel;
using CriticalListReport.Helpers;
using CriticalListReport.Models;
using LinqKit;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using System.Data;
using System.Diagnostics;
using System.Text;

namespace CriticalListReport.Controllers
{
    [Authorize]
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly AppDbContext _context;

        public HomeController(ILogger<HomeController> logger, AppDbContext context)
        {
            _logger = logger;
            _context = context;
        }

        public async Task<IActionResult> Index(
            int pageNumber = 1,
            int pageSize = 12,
            string? plant = null,
            string? partNo = null,
            string? vendorCode = null,
            string? pic = null,
            DateTime? fromDate = null,
            DateTime? toDate = null,
            string? dataType = null,
            bool cos = false)
        {
            try
            {
                if (User.IsInRole("Viewer"))
                {
                    dataType = "sap_updated";
                }

                // Parse dataType to dataSource
                byte dataSource = ParseDataSource(dataType);

                var query = _context.CriticalItems
                    .Where(x => x.DataSource == dataSource)
                    .AsNoTracking();

                // Lấy columnInfo theo dataSource (0 và 2 dùng chung config của 0)
                byte configSource = dataSource == 2 ? (byte)0 : dataSource;
                var columnInfo = await _context.NumberColumnShows
                    .FirstOrDefaultAsync(x => x.DataSource == configSource);

                // Áp filter
                query = ApplyFilter(query, plant, partNo, vendorCode, fromDate, toDate, pic, cos);

                // Tổng số bản ghi
                var totalCount = await query.CountAsync();
                if (totalCount == 0)
                {
                    var vmN = new CriticalListViewModel
                    {
                        Items = new List<CriticalItem>(),
                        TotalCount = totalCount,
                        PageNumber = pageNumber,
                        PageSize = pageSize,
                        Plant = plant,
                        PartNo = partNo,
                        VendorCode = vendorCode,
                        FromDate = fromDate,
                        ToDate = toDate,
                        PIC = pic,
                        DataType = dataType,
                        Cos = cos
                    };

                    return View(vmN);
                }

                // Phân trang
                var items = await query
                    .OrderBy(x => x.No)
                    .Skip((pageNumber - 1) * pageSize)
                    .Take(pageSize)
                    .ToListAsync();

                // Đếm số cột inbound có data cho từng record
                var maxInboundColumn = items
                    .Max(x =>
                        (string.IsNullOrEmpty(x.Inbound1Qty) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Inbound2Qty) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Inbound3Qty) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Inbound4Qty) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Inbound5Qty) ? 0 : 1)
                    );

                // Đếm số cột shipment có data cho từng record
                var maxShipmentColumn = items
                    .Max(x =>
                        (string.IsNullOrEmpty(x.Qty1) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty2) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty3) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty4) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty5) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty6) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty7) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty8) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty9) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty10) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty11) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty12) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty13) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty14) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Qty15) ? 0 : 1)
                    );

                // Đếm số cột OrPart có data cho từng record
                var maxOrPartColumn = items
                    .Max(x =>
                        (string.IsNullOrEmpty(x.Part1) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part2) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part3) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part4) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part5) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part6) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part7) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part8) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part9) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part10) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part11) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part12) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part13) ? 0 : 1) +
                        (string.IsNullOrEmpty(x.Part14) ? 0 : 1)
                    );

                ViewData["MaxInboundColumn"] = maxInboundColumn;
                ViewData["MaxShipmentColumn"] = maxShipmentColumn;
                ViewData["MaxOrPartColumn"] = maxOrPartColumn;
                ViewData["MaxAirSummaryColumn"] = columnInfo?.ColumnAirSummary ?? 0;
                ViewData["EndValidDate"] = columnInfo?.EndValidDate ?? "";
                ViewData["ValidGWAir"] = columnInfo?.ValidGWAir ?? 100;
                ViewData["ValidGWAirOtherPlant"] = columnInfo?.ValidGWAirOtherPlant ?? 50;
                ViewData["IsMR"] = columnInfo?.IsMR;

                DateTime? endValidDate = null;

                if (!string.IsNullOrWhiteSpace(columnInfo?.EndValidDate))
                {
                    if (DateTime.TryParse(columnInfo.EndValidDate, out var parsedDate))
                    {
                        endValidDate = parsedDate;
                    }
                }
                ViewData["ValidRange"] = columnInfo?.OverrideEndValidDate ?? endValidDate;

                var vm = new CriticalListViewModel
                {
                    Items = items,
                    TotalCount = totalCount,
                    PageNumber = pageNumber,
                    PageSize = pageSize,
                    Plant = plant,
                    PartNo = partNo,
                    VendorCode = vendorCode,
                    PIC = pic,
                    FromDate = fromDate,
                    ToDate = toDate,
                    DataType = dataType,
                    Cos = cos
                };

                return View(vm);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error in Index");
                throw;
            }
        }

        [HttpGet]
        public async Task<IActionResult> ExportExcel(
            string? plant = null,
            string? partNo = null,
            string? vendorCode = null,
            string? pic = null,
            DateTime? fromDate = null,
            DateTime? toDate = null,
            string? dataType = null,
            bool cos = false)
        {
            try
            {
                byte dataSource = ParseDataSource(dataType);    
                if (User.IsInRole("Viewer"))
                {
                    if (dataSource != 2)
                    {
                        return BadRequest(new { message = "You only have permission to export 'Data from SAP (Before update)'." });
                    }
                }

                var query = _context.CriticalItems
                    .Where(x => x.DataSource == dataSource)
                    .AsNoTracking();

                byte configSource = dataSource == 2 ? (byte)0 : dataSource;
                var columnInfo = await _context.NumberColumnShows
                   .FirstOrDefaultAsync(x => x.DataSource == configSource);

                // Áp filter
                query = ApplyFilter(query, plant, partNo, vendorCode, fromDate, toDate, pic, cos);

                var items = await query
                    .OrderBy(x => x.No)
                    .ToListAsync();

                // Khi export SAP (0) hoặc TCode (1): lấy "this week" từ nguồn 2 (no COS) hoặc 3 (COS)
                // theo PartNo + Plant, bản ghi mới nhất, đổ vào cột LastWeek trong file
                if (dataSource == 0 || dataSource == 1)
                {
                    byte lookupSource = cos ? (byte)3 : (byte)2;

                    // Loại null để tránh lỗi khi Contains / GroupBy
                    var plantsLst = items
                        .Select(x => x.Plant)
                        .Where(p => !string.IsNullOrEmpty(p))
                        .Distinct()
                        .ToList();
                    var partNos = items
                        .Select(x => x.PartNo)
                        .Where(p => !string.IsNullOrEmpty(p))
                        .Distinct()
                        .ToList();

                    // Chỉ tra chéo khi có key để tra
                    if (plantsLst.Count > 0 && partNos.Count > 0)
                    {
                        var lookupData = await _context.CriticalItems
                            .Where(x => x.DataSource == lookupSource
                                        && x.Plant != null && x.PartNo != null
                                        && plantsLst.Contains(x.Plant)
                                        && partNos.Contains(x.PartNo))
                            .Select(x => new
                            {
                                x.Plant,
                                x.PartNo,
                                x.CreatedDate,
                                x.RemarkByLeaderThisWeek,
                                x.RankThisWeek
                            })
                            .AsNoTracking()
                            .ToListAsync();

                        var lookupDict = lookupData
                            .GroupBy(x => $"{x.Plant}|{x.PartNo}")
                            .ToDictionary(
                                g => g.Key,
                                g => g.OrderByDescending(x => x.CreatedDate).First()
                            );

                        foreach (var item in items)
                        {
                            if (string.IsNullOrEmpty(item.Plant) || string.IsNullOrEmpty(item.PartNo))
                                continue;

                            var key = $"{item.Plant}|{item.PartNo}";
                            if (lookupDict.TryGetValue(key, out var src))
                            {
                                item.RemarkByLeaderLastWeek = src.RemarkByLeaderThisWeek;
                                item.RankLastWeek = src.RankThisWeek;
                            }
                        }
                    }
                }

                if (items.Count == 0)
                {
                    return BadRequest(new { message = "Không có dữ liệu phù hợp với điều kiện lọc (COS) để export." });
                }

                // Đếm số cột inbound có data cho từng record
                //var maxInboundColumn = items
                //    .Max(x =>
                //        (string.IsNullOrEmpty(x.Inbound1Qty) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Inbound2Qty) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Inbound3Qty) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Inbound4Qty) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Inbound5Qty) ? 0 : 1)
                //    );

                var maxInboundColumn = 5;

                // Đếm số cột shipment có data cho từng record
                //var maxShipmentColumn = items
                //    .Max(x =>
                //        (string.IsNullOrEmpty(x.Qty1) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty2) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty3) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty4) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty5) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty6) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty7) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty8) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty9) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty10) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty11) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty12) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty13) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty14) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Qty15) ? 0 : 1)
                //    );

                var maxShipmentColumn = 15;

                // Đếm số cột OrPart có data cho từng record
                //var maxOrPartColumn = items
                //    .Max(x =>
                //        (string.IsNullOrEmpty(x.Part1) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part2) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part3) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part4) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part5) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part6) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part7) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part8) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part9) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part10) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part11) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part12) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part13) ? 0 : 1) +
                //        (string.IsNullOrEmpty(x.Part14) ? 0 : 1)
                //    );

                var maxOrPartColumn = 14;

                int maxInbound = maxInboundColumn;
                int maxShipment = maxShipmentColumn;
                int maxOrPart = maxOrPartColumn;
                int maxAirSummary = columnInfo?.ColumnAirSummary ?? 0;
                string endValidDate = columnInfo?.EndValidDate ?? "";

                var now = DateTime.Now;
                var months = new List<string>();
                for (int i = 0; i < maxAirSummary; i++)
                {
                    months.Add(now.AddMonths(i).ToString("MMM").ToUpper());
                }

                
                using var workbook = new ClosedXML.Excel.XLWorkbook();
                var ws = workbook.Worksheets.Add("Critical List");

                int row1 = 1, row2 = 2;
                int col = 1;

                // Helper để set header
                void SetHeader(int r, int c, string text, bool bold = true)
                {
                    var cell = ws.Cell(r, c);
                    cell.Value = text;
                    cell.Style.Font.Bold = bold;
                    cell.Style.Alignment.Horizontal = ClosedXML.Excel.XLAlignmentHorizontalValues.Center;
                    cell.Style.Alignment.Vertical = ClosedXML.Excel.XLAlignmentVerticalValues.Center;
                    cell.Style.Fill.BackgroundColor = ClosedXML.Excel.XLColor.PastelPink;
                    cell.Style.Border.OutsideBorder = ClosedXML.Excel.XLBorderStyleValues.Thin;
                }

                void MergeHeader(int r1, int c1, int r2_, int c2_)
                {
                    var rng = ws.Range(r1, c1, r2_, c2_);
                    rng.Merge();
                    rng.Style.Font.Bold = true;
                    rng.Style.Alignment.Horizontal = ClosedXML.Excel.XLAlignmentHorizontalValues.Center;
                    rng.Style.Alignment.Vertical = ClosedXML.Excel.XLAlignmentVerticalValues.Center;
                    rng.Style.Fill.BackgroundColor = ClosedXML.Excel.XLColor.PastelPink;
                    rng.Style.Border.OutsideBorder = ClosedXML.Excel.XLBorderStyleValues.Thin;
                }

                // --- Header cố định (rowspan=2)
                string[] fixedRowspan2 = {
                "No","Category","Combine Part","Plant","Part no","Part name",
                "Vendor code","Vendor name","Maker name","Lead time","Pur Gr","PIC",
                "Rounding value (SPQ)","G/W per 1pcs","Unit of packing (kg, g)"
            };
                foreach (var h in fixedRowspan2)
                {
                    SetHeader(row1, col, h);
                    MergeHeader(row1, col, row2, col);
                    col++;
                }

                // --- Inbound group
                if (maxInbound > 0)
                {
                    int start = col;
                    MergeHeader(row1, start, row1, start + maxInbound * 2 - 1);
                    ws.Cell(row1, start).Value = "On the way shipment";
                    for (int i = 1; i <= maxInbound; i++)
                    {
                        SetHeader(row2, col++, $"Inbound{i} (Qty)");
                        SetHeader(row2, col++, $"Inbound{i} (ETA)");
                    }
                }

                // --- First shortage, Shortage qty
                SetHeader(row1, col, "First shortage (after on the way)");
                MergeHeader(row1, col, row2, col); col++;
                SetHeader(row1, col, $"Shortage qty (Until {endValidDate})");
                MergeHeader(row1, col, row2, col); col++;

                // --- Shipment group
                if (maxShipment > 0)
                {
                    int start = col;
                    MergeHeader(row1, start, row1, start + maxShipment * 10 - 1);
                    ws.Cell(row1, start).Value = "Vendor confirmation (SA)";
                    for (int i = 1; i <= maxShipment; i++)
                    {
                        var shipColor = i % 2 == 0 ? XLColor.FromArgb(173, 216, 230) : XLColor.PastelPink;
                        void SetShipmentHeader(int c, string text)
                        {
                            var cell = ws.Cell(row2, c);
                            cell.Value = text;
                            cell.Style.Font.Bold = true;
                            cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                            cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                            cell.Style.Fill.BackgroundColor = shipColor;
                            cell.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        }
                        SetShipmentHeader(col++, $"Qty {i}");
                        SetShipmentHeader(col++, $"ETD {i}");
                        SetShipmentHeader(col++, $"ETA {i}");
                        SetShipmentHeader(col++, $"Shortage {i}");
                        SetShipmentHeader(col++, $"Gap {i}");
                        SetShipmentHeader(col++, $"ETD (Air) {i}");
                        SetShipmentHeader(col++, $"ETA (Air) {i}");
                        SetShipmentHeader(col++, $"GW (Air) {i}");
                        SetShipmentHeader(col++, $"Final Shortage {i}");
                        SetShipmentHeader(col++, $"Gap (Air) {i}");
                    }
                }

                // --- Final Shortage group
                int startFinal = col;
                SetHeader(row1, col, "Final Shortage date (after vendor confirm)");
                MergeHeader(row1, col, row2, col); col++;

                SetHeader(row1, col, "Final shortage Qty");
                MergeHeader(row1, col, row2, col); col++;

                // --- Stock other plant
                int startStock = col;
                string[] stockCols = { "V501", "VE01", "VR01", "VG01", "VY01" };
                MergeHeader(row1, startStock, row1, startStock + stockCols.Length - 1);
                ws.Cell(row1, startStock).Value = "Stock other plant (PSNV internal)";
                foreach (var s in stockCols)
                    SetHeader(row2, col++, s);

                SetHeader(row1, col, "NG Qty");
                MergeHeader(row1, col, row2, col); col++;

                SetHeader(row1, col, "Final shortage (after vendor confirm + stock other plan)");
                MergeHeader(row1, col, row2, col); col++;

                SetHeader(row1, col, "Next Simulation");
                MergeHeader(row1, col, row2, col); col++;

                SetHeader(row1, col, "Final Simulation");
                MergeHeader(row1, col, row2, col); col++;

                SetHeader(row1, col, "Final Gap date");
                MergeHeader(row1, col, row2, col); col++;

                // --- Or Part
                if (maxOrPart > 0)
                {
                    int start = col;
                    MergeHeader(row1, start, row1, start + maxOrPart - 1);
                    ws.Cell(row1, start).Value = "List up or part";
                    for (int i = 1; i <= maxOrPart; i++)
                        SetHeader(row2, col++, $"Part {i}");
                }

                // --- Judgement
                int startJudgement = col;
                SetHeader(row1, startJudgement, "Judgement");
                SetHeader(row2, col++, "RANK");

                SetHeader(row1, col, "Vendor status");
                MergeHeader(row1, col, row2, col); col++;

                SetHeader(row1, col, "Short LT (first)");
                MergeHeader(row1, col, row2, col); col++;

                // --- Other information
                int startOther = col;
                MergeHeader(row1, startOther, row1, startOther + 7);
                ws.Cell(row1, startOther).Value = "Other information";
                string[] otherCols = {
                "REQUEST GPRC","Market stock","Other factory name", "Stock other factory",
                "Remark by leader (last week)","Rank (last week)",
                "Remark by leader (this week)","Rank (this week)"
            };
                foreach (var o in otherCols)
                    SetHeader(row2, col++, o);

                SetHeader(row1, col, "Freight unit");
                MergeHeader(row1, col, row2, col); col++;

                // --- Air GW summary
                if (maxAirSummary > 0)
                {
                    int start = col;
                    MergeHeader(row1, start, row1, start + maxAirSummary - 1);
                    ws.Cell(row1, start).Value = "Air GW summary by month";
                    foreach (var m in months)
                        SetHeader(row2, col++, m);
                }

                // --- Air cost summary
                if (maxAirSummary > 0)
                {
                    int start = col;
                    MergeHeader(row1, start, row1, start + maxAirSummary - 1);
                    ws.Cell(row1, start).Value = "Air cost summary by month";
                    foreach (var m in months)
                        SetHeader(row2, col++, m);
                }

                SetHeader(row1, col, "CreatedDate");
                MergeHeader(row1, col, row2, col); col++;

                SetHeader(row1, col, "Include MR");
                MergeHeader(row1, col, row2, col); col++;

                // Freeze header
                ws.SheetView.FreezeRows(2);
                //ws.SheetView.FreezeColumns(5);

                // --- Ghi dữ liệu (map theo thứ tự cột bạn đã định nghĩa)
                int dataStartRow = 3;
                int r = dataStartRow;

                foreach (var item in items)
                {
                    int c = 1;

                    // Các cột cố định
                    ws.Cell(r, c++).Value = item.No;
                    ws.Cell(r, c++).Value = item.Cat;
                    ws.Cell(r, c++).Value = item.CombinePart;
                    ws.Cell(r, c++).Value = item.Plant;
                    ws.Cell(r, c++).Value = item.PartNo;
                    ws.Cell(r, c++).Value = item.PartName;
                    ws.Cell(r, c++).Value = item.VendorCode;
                    ws.Cell(r, c++).Value = item.VendorName;
                    ws.Cell(r, c++).Value = item.MakerName;
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.LeadTime);
                    ws.Cell(r, c++).Value = item.PurGr;
                    ws.Cell(r, c++).Value = item.PIC;
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.RoundingVal);
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.GWper1pcs);
                    ws.Cell(r, c++).Value = item.UnitOfPacking;

                    // Inbound động
                    for (int i = 1; i <= maxInbound; i++)
                    {
                        ReflectionHelper.SetNumberCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"Inbound{i}Qty"));
                        ReflectionHelper.SetDateCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"Inbound{i}ETA"));
                    }

                    ReflectionHelper.SetDateCell(ws, r, c++, item.FirstShortage!);
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.ShortageQty);

                    // Shipment động
                    for (int i = 1; i <= maxShipment; i++)
                    {
                        var qtyCell = ws.Cell(r, c);
                        ReflectionHelper.SetNumberCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"Qty{i}"));
                        ws.Cell(r, c - 1).Style.Font.Bold = true;

                        ReflectionHelper.SetDateCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"ETD{i}"));
                        ReflectionHelper.SetDateCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"ETA{i}"));
                        ReflectionHelper.SetDateCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"Shortage{i}"));

                        ReflectionHelper.SetNumberCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"Gap{i}"));

                        ReflectionHelper.SetDateCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"ETDAir{i}"));
                        ReflectionHelper.SetDateCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"ETAAir{i}"));

                        ReflectionHelper.SetNumberCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"GWAir{i}"));

                        ReflectionHelper.SetDateCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"FinalShortage{i}"));

                        ReflectionHelper.SetNumberCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, $"GapAir{i}"));
                    }

                    ReflectionHelper.SetDateCell(ws, r, c++, item.FinalShortageDate!);
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.FinalShortageQty);

                    // Stock other plant
                    ws.Cell(r, c++).Value = item.Plant == "V501" ? "" : item.V501;
                    ws.Cell(r, c++).Value = item.Plant == "VE01" ? "" : item.VE01;
                    ws.Cell(r, c++).Value = item.Plant == "VR01" ? "" : item.VR01;
                    ws.Cell(r, c++).Value = item.Plant == "VG01" ? "" : item.VG01;
                    ws.Cell(r, c++).Value = item.Plant == "VY01" ? "" : item.VY01;

                    ws.Cell(r, c++).Value = item.NGQty;
                    ReflectionHelper.SetDateCell(ws, r, c++, item.FinalShortageAfterVendorConfirmStockOtherPlan!);
                    ReflectionHelper.SetDateCell(ws, r, c++, item.NextSimulation!);
                    ReflectionHelper.SetDateCell(ws, r, c++, item.FinalSimulation!);
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.FinalGapDate);

                    // Or Part
                    for (int i = 1; i <= maxOrPart; i++)
                    {
                        ws.Cell(r, c++).Value = ReflectionHelper.GetPropValue<string>(item, $"Part{i}");
                    }

                    ws.Cell(r, c++).Value = item.Rank;
                    ws.Cell(r, c++).Value = item.VendorStatus;
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.ShortLTFirst);
                    ws.Cell(r, c++).Value = item.RequestGPRC;
                    ws.Cell(r, c++).Value = item.MarketStock;
                    ws.Cell(r, c++).Value = item.StockOtherFactory;
                    ReflectionHelper.SetNumberCell(ws, r, c++, item.StockOtherFactoryQty);
                    ws.Cell(r, c++).Value = item.RemarkByLeaderLastWeek;
                    ws.Cell(r, c++).Value = item.RankLastWeek;
                    ws.Cell(r, c++).Value = item.RemarkByLeaderThisWeek;
                    ws.Cell(r, c++).Value = item.RankThisWeek;

                    ReflectionHelper.SetNumberCell(ws, r, c++, item.FreightUnit);

                    // Air GW summary
                    for (int i = 0; i < maxAirSummary; i++)
                    {
                        var propName = i == 0 ? "GWAirMonthN" : $"GWAirMonthN{i}";
                        ReflectionHelper.SetNumberCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, propName));
                    }

                    // Air cost summary
                    for (int i = 0; i < maxAirSummary; i++)
                    {
                        var propName = i == 0 ? "CostAirMonthN" : $"CostAirMonthN{i}";
                        ReflectionHelper.SetNumberCell(ws, r, c++, ReflectionHelper.GetPropValue<string>(item, propName));
                    }

                    // CreatedDate
                    ReflectionHelper.SetDateCell(ws, r, c++, item.CreatedDate.ToString("dd-MMM-yy"));

                    var mrCell = ws.Cell(r, c++);
                    bool isMR = columnInfo?.IsMR ?? false;
                    mrCell.Value = isMR ? "X" : "";
                    mrCell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    mrCell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;

                    r++;
                }

                // Style dữ liệu
                var dataRange = ws.Range(dataStartRow, 1, r - 1, col - 1);
                dataRange.Style.Border.OutsideBorder = ClosedXML.Excel.XLBorderStyleValues.Thin;
                dataRange.Style.Border.InsideBorder = ClosedXML.Excel.XLBorderStyleValues.Dotted;
                // Thay ws.Columns().AdjustToContents();
                foreach (var column in ws.ColumnsUsed())
                {
                    column.AdjustToContents(3);
                    double dataWidth = column.Width;

                    // Lấy text header từ cả dòng 1 và dòng 2, chọn cái dài hơn
                    var header1 = ws.Cell(1, column.ColumnNumber()).GetString();
                    var header2 = ws.Cell(2, column.ColumnNumber()).GetString();
                    var longestHeader = header1.Length > header2.Length ? header1 : header2;

                    // Tính width chính xác hơn
                    double headerWidth = longestHeader.Length;

                    column.Width = Math.Max(dataWidth, headerWidth);
                }


                // Tạo sheet Summarize
                var wsSummary = workbook.Worksheets.Add("Summarize");

                // Helper để set header
                void SetHeaderSum(IXLWorksheet sheet, int r, int c, string text, bool bold = true)
                {
                    var cell = sheet.Cell(r, c);
                    cell.Value = text;
                    cell.Style.Font.Bold = bold;
                    cell.Style.Font.FontColor = XLColor.White;
                    cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                    cell.Style.Fill.BackgroundColor = XLColor.MediumPurple;
                    cell.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                }

                // 1. Title dòng đầu
                var titleRange = wsSummary.Range(1, 1, 1, months.Count * 4 + 3);
                titleRange.Merge();
                titleRange.Value = "SUMMARY MATERIAL STATUS";
                titleRange.Style.Font.Bold = true;
                titleRange.Style.Font.FontSize = 16;
                titleRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                titleRange.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                titleRange.Style.Fill.BackgroundColor = XLColor.Lavender;

                // 2. Section header "By month and rank"
                var sectionRange = wsSummary.Range(3, 1, 3, months.Count * 4 + 3);
                sectionRange.Merge();
                sectionRange.Value = "1. By month, plant and rank";
                sectionRange.Style.Font.Bold = true;
                sectionRange.Style.Font.FontSize = 12;
                sectionRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                sectionRange.Style.Fill.BackgroundColor = XLColor.Thistle;

                // 3. Header động theo months (bắt đầu từ dòng 4)
                SetHeaderSum(wsSummary, 4, 1, "Rank");
                SetHeaderSum(wsSummary, 4, 2, "Content");
                wsSummary.Range(4, 1, 5, 1).Merge();
                wsSummary.Range(4, 2, 5, 2).Merge();

                var plants = new List<string> { "V501", "VE01", "VR01", "VG01", "VY01" };
                int colS = 3;
                foreach (var pl in plants)
                {
                    SetHeaderSum(wsSummary, 4, colS, pl);
                    wsSummary.Cell(4, colS).Style.Font.FontColor = XLColor.Black;
                    wsSummary.Range(4, colS, 4, colS + months.Count - 1).Merge();

                    // Dòng 5: Month
                    foreach (var m in months)
                    {
                        SetHeaderSum(wsSummary, 5, colS, m);
                        colS++;
                    }
                }

                // Thêm cột Total
                wsSummary.Range(4, colS, 5, colS).Merge();
                SetHeaderSum(wsSummary, 4, colS, "Total");

                int colSummary = colS;

                // 4. Ghi dữ liệu (bắt đầu từ dòng 5)
                int row = 6;
                var grouped = items.GroupBy(x => x.Rank);

                foreach (var g in grouped)
                {
                    wsSummary.Cell(row, 1).Value = g.Key;
                    wsSummary.Cell(row, 2).Value = ReflectionHelper.GetRankContent(g.Key);

                    int total = 0;
                    int colData = 3;

                    foreach (var pl in plants)
                    {
                        foreach (var m in months)
                        {
                            int count = 0;

                            foreach (var x in g)
                            {
                                if (x.Plant != pl)
                                    continue;

                                var val = (x.FinalShortageAfterVendorConfirmStockOtherPlan ?? "").Trim();

                                if (g.Key == "B")
                                {
                                    if (m == months.Last())
                                        count++;
                                }
                                else
                                {
                                    if (DateTime.TryParse(val, out var dt))
                                    {
                                        var monthStr = dt.ToString("MMM").ToUpper();
                                        if (monthStr == m)
                                            count++;
                                    }
                                }
                            }

                            wsSummary.Cell(row, colData).Value = count;
                            total += count;
                            colData++;
                        }
                    }

                    wsSummary.Cell(row, colData).Value = total;
                    row++;
                }

                // 4b. Thêm dòng Total
                int totalRow = row;
                wsSummary.Cell(totalRow, 1).Value = "";
                wsSummary.Cell(totalRow, 2).Value = "Total";
                wsSummary.Cell(totalRow, 2).Style.Font.Bold = true;

                for (int c = 3; c <= colSummary; c++)
                {
                    string colLetter = wsSummary.Cell(1, c).Address.ColumnLetter;
                    wsSummary.Cell(totalRow, c).FormulaA1 = $"SUM({colLetter}5:{colLetter}{row - 1})";
                    wsSummary.Cell(totalRow, c).Style.Font.Bold = true;
                }

                // Tô nền dòng tổng
                var totalRange = wsSummary.Range(totalRow, 1, totalRow, colSummary);
                totalRange.Style.Fill.BackgroundColor = XLColor.LightGray;
                totalRange.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                totalRange.Style.Border.InsideBorder = XLBorderStyleValues.Dotted;

                // 5. Border cho toàn bộ bảng Rank
                var dataRangeSummary = wsSummary.Range(4, 1, row - 1, colSummary);
                dataRangeSummary.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                dataRangeSummary.Style.Border.InsideBorder = XLBorderStyleValues.Dotted;



                // 6. Section "By vendor"
                int vendorHeaderRow = row + 2;
                var vendorSectionRange = wsSummary.Range(vendorHeaderRow, 1, vendorHeaderRow, 8);
                vendorSectionRange.Merge();
                vendorSectionRange.Value = "2. By vendor";
                vendorSectionRange.Style.Font.Bold = true;
                vendorSectionRange.Style.Font.FontSize = 12;
                vendorSectionRange.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Left;
                vendorSectionRange.Style.Fill.BackgroundColor = XLColor.Thistle;

                // Header bảng Vendor(dòng vendorHeaderRow+1)
                int vendorTableRow = vendorHeaderRow + 1;
                SetHeaderSum(wsSummary, vendorTableRow, 1, "Vendor");
                SetHeaderSum(wsSummary, vendorTableRow, 2, "Vendor name");
                SetHeaderSum(wsSummary, vendorTableRow, 3, "A1");
                SetHeaderSum(wsSummary, vendorTableRow, 4, "A2");
                SetHeaderSum(wsSummary, vendorTableRow, 5, "A3");
                SetHeaderSum(wsSummary, vendorTableRow, 6, "A4");
                SetHeaderSum(wsSummary, vendorTableRow, 7, "B");
                SetHeaderSum(wsSummary, vendorTableRow, 8, "Production short LT");

                int vRow = vendorTableRow + 1;
                var groupedVendor = items.GroupBy(x => new { x.VendorCode, x.VendorName });

                foreach (var gv in groupedVendor)
                {
                    wsSummary.Cell(vRow, 1).Value = gv.Key.VendorCode;
                    wsSummary.Cell(vRow, 2).Value = gv.Key.VendorName;

                    // Đếm theo Rank
                    wsSummary.Cell(vRow, 3).Value = gv.Count(x => x.Rank == "A1");
                    wsSummary.Cell(vRow, 4).Value = gv.Count(x => x.Rank == "A2");
                    wsSummary.Cell(vRow, 5).Value = gv.Count(x => x.Rank == "A3");
                    wsSummary.Cell(vRow, 6).Value = gv.Count(x => x.Rank == "A4");
                    wsSummary.Cell(vRow, 7).Value = gv.Count(x => x.Rank == "B");
                    wsSummary.Cell(vRow, 8).Value = gv.Count(x => x.Rank == "Production short LT");

                    vRow++;
                }

                var vendorRange = wsSummary.Range(vendorTableRow, 1, vRow - 1, 8);
                vendorRange.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                vendorRange.Style.Border.InsideBorder = XLBorderStyleValues.Dotted;

                //wsSummary.Columns().AdjustToContents();
                foreach (var column in wsSummary.ColumnsUsed())
                {
                    column.AdjustToContents(5);
                    double dataWidth = column.Width;
                    var header4 = wsSummary.Cell(4, column.ColumnNumber()).GetString();
                    var header5 = wsSummary.Cell(5, column.ColumnNumber()).GetString();
                    var longestHeader = header4.Length > header5.Length ? header4 : header5;
                    double headerWidth = longestHeader.Length;
                    column.Width = Math.Max(dataWidth, Math.Max(headerWidth, 6));
                }

                // ========== SHEET RANK JUDGEMENT ==========
                var wsRank = workbook.Worksheets.Add("Rank judgement");

                Action<IXLCell, string, XLColor> setCell = (cell, val, color) =>
                {
                    cell.Value = val;
                    cell.Style.Fill.BackgroundColor = color;
                    cell.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                };

                Action<IXLCell, string> setHeader = (cell, val) =>
                {
                    cell.Value = val;
                    cell.Style.Font.Bold = true;
                    cell.Style.Fill.BackgroundColor = XLColor.FromArgb(255, 204, 255);
                    cell.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    cell.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    cell.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                };

                Action<IXLRange, string, bool> setMergeCell = (range, val, bold) =>
                {
                    range.Merge();
                    range.Value = val;
                    range.Style.Font.Bold = bold;
                    range.Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    range.Style.Alignment.Vertical = XLAlignmentVerticalValues.Center;
                    range.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    range.Style.Border.InsideBorder = XLBorderStyleValues.Thin;
                };

                var white = XLColor.White;
                var yellow = XLColor.FromArgb(255, 255, 204);

                // ===== TITLE OVERSEAS =====
                wsRank.Cell(1, 1).Value = "Rank judgement (Overseas)";
                wsRank.Cell(1, 1).Style.Font.Bold = true;
                wsRank.Cell(1, 1).Style.Font.FontColor = XLColor.Red;
                wsRank.Range(1, 1, 1, 5).Merge();

                setHeader(wsRank.Cell(2, 1), "Rank Judgement");
                setHeader(wsRank.Cell(2, 2), "Condition 1");
                setHeader(wsRank.Cell(2, 3), "Condition 2");
                setHeader(wsRank.Cell(2, 4), "Content");
                setHeader(wsRank.Cell(2, 5), "New rule");

                // A1
                setMergeCell(wsRank.Range(3, 1, 4, 1), "A1", true);
                setMergeCell(wsRank.Range(3, 3, 4, 3), "And", false);
                setCell(wsRank.Cell(3, 4), "Shortage date", white); setCell(wsRank.Cell(3, 5), "≤ 4w", yellow);
                setCell(wsRank.Cell(4, 4), "Gap delivery", white); setCell(wsRank.Cell(4, 5), "≥ 2w", yellow);

                // A2 - 3 điều kiện, cần rows 5-10
                setMergeCell(wsRank.Range(5, 1, 10, 1), "A2", true);
                setMergeCell(wsRank.Range(5, 2, 10, 2), "Or", false);
                setMergeCell(wsRank.Range(5, 3, 6, 3), "And", false);
                setMergeCell(wsRank.Range(7, 3, 8, 3), "And", false);
                setMergeCell(wsRank.Range(9, 3, 10, 3), "And", false);  // [THÊM]
                setCell(wsRank.Cell(5, 4), "Shortage date", white); setCell(wsRank.Cell(5, 5), "≤ 4w", yellow);
                setCell(wsRank.Cell(6, 4), "Gap delivery", white); setCell(wsRank.Cell(6, 5), "< 2w", yellow);
                setCell(wsRank.Cell(7, 4), "Shortage date", white); setCell(wsRank.Cell(7, 5), "4w < Shortage date ≤ 6w", yellow);
                setCell(wsRank.Cell(8, 4), "Gap delivery", white); setCell(wsRank.Cell(8, 5), "≥ 1w", yellow);
                setCell(wsRank.Cell(9, 4), "Shortage date", white); setCell(wsRank.Cell(9, 5), "> 6w", yellow);   // [THÊM]
                setCell(wsRank.Cell(10, 4), "Gap delivery", white); setCell(wsRank.Cell(10, 5), "≥ 6w", yellow);  // [THÊM]

                // A3 - rows 11-14
                setMergeCell(wsRank.Range(11, 1, 14, 1), "A3", true);
                setMergeCell(wsRank.Range(11, 2, 14, 2), "Or", false);
                setMergeCell(wsRank.Range(11, 3, 12, 3), "And", false);
                setMergeCell(wsRank.Range(13, 3, 14, 3), "And", false);
                setCell(wsRank.Cell(11, 4), "Shortage date", white); setCell(wsRank.Cell(11, 5), "4w < Shortage date ≤ 6w", yellow);
                setCell(wsRank.Cell(12, 4), "Gap delivery", white); setCell(wsRank.Cell(12, 5), "< 1w", yellow);
                setCell(wsRank.Cell(13, 4), "Shortage date", white); setCell(wsRank.Cell(13, 5), "> 6w", yellow);
                setCell(wsRank.Cell(14, 4), "Gap delivery", white); setCell(wsRank.Cell(14, 5), "< 6w", yellow);

                // B - rows 15-16
                setMergeCell(wsRank.Range(15, 1, 16, 1), "B", true);
                setMergeCell(wsRank.Range(15, 2, 16, 2), "", false);
                setMergeCell(wsRank.Range(15, 3, 16, 3), "And", false);
                setCell(wsRank.Cell(15, 4), "Shortage date", white); setCell(wsRank.Cell(15, 5), "> valid date", yellow);
                setCell(wsRank.Cell(16, 4), "Gap delivery", white); setCell(wsRank.Cell(16, 5), "0", yellow);

                // Production short LT - rows 17-18
                setMergeCell(wsRank.Range(17, 1, 18, 1), "Production short LT", true);
                setMergeCell(wsRank.Range(17, 2, 18, 2), "", false);
                setMergeCell(wsRank.Range(17, 3, 18, 3), "And", false);
                setCell(wsRank.Cell(17, 4), "Shortage date", white); setCell(wsRank.Cell(17, 5), "Shortage date = ETA PSNV", yellow);
                setCell(wsRank.Cell(18, 4), "Gap delivery", white); setCell(wsRank.Cell(18, 5), "1", yellow);


                // ===== TITLE LOCAL =====
                wsRank.Cell(1, 7).Value = "Rank judgement (Local)";
                wsRank.Cell(1, 7).Style.Font.Bold = true;
                wsRank.Cell(1, 7).Style.Font.FontColor = XLColor.Red;
                wsRank.Range(1, 7, 1, 11).Merge();

                setHeader(wsRank.Cell(2, 7), "Rank Judgement");
                setHeader(wsRank.Cell(2, 8), "Condition 1");
                setHeader(wsRank.Cell(2, 9), "Condition 2");
                setHeader(wsRank.Cell(2, 10), "Content");
                setHeader(wsRank.Cell(2, 11), "Rule");

                // A1 Local
                setMergeCell(wsRank.Range(3, 7, 4, 7), "A1", true);
                setMergeCell(wsRank.Range(3, 9, 4, 9), "And", false);
                setCell(wsRank.Cell(3, 10), "Shortage date", white); setCell(wsRank.Cell(3, 11), "≤ 1 week", yellow);
                setCell(wsRank.Cell(4, 10), "Gap delivery", white); setCell(wsRank.Cell(4, 11), "> 2 day", yellow);

                // A2 Local
                setMergeCell(wsRank.Range(5, 7, 8, 7), "A2", true);
                setMergeCell(wsRank.Range(5, 8, 8, 8), "Or", false);
                setMergeCell(wsRank.Range(5, 9, 6, 9), "And", false);
                setMergeCell(wsRank.Range(7, 9, 8, 9), "And", false);
                setCell(wsRank.Cell(5, 10), "Shortage date", white); setCell(wsRank.Cell(5, 11), "≤ 1 week", yellow);
                setCell(wsRank.Cell(6, 10), "Gap delivery", white); setCell(wsRank.Cell(6, 11), "≤ 2 day", yellow);
                setCell(wsRank.Cell(7, 10), "Shortage date", white); setCell(wsRank.Cell(7, 11), "2 week > Shortage date > 1 week", yellow);
                setCell(wsRank.Cell(8, 10), "Gap delivery", white); setCell(wsRank.Cell(8, 11), "> 4 day", yellow);

                // A3 Local
                setMergeCell(wsRank.Range(9, 7, 10, 7), "A3", true);
                setMergeCell(wsRank.Range(9, 9, 10, 9), "And", false);
                setCell(wsRank.Cell(9, 10), "Shortage date", white); setCell(wsRank.Cell(9, 11), "2 week > Shortage date > 1 week", yellow);
                setCell(wsRank.Cell(10, 10), "Gap delivery", white); setCell(wsRank.Cell(10, 11), "≤ 4 day", yellow);

                // A4 Local
                setMergeCell(wsRank.Range(11, 7, 12, 7), "A4", true);
                setMergeCell(wsRank.Range(11, 9, 12, 9), "And", false);
                setCell(wsRank.Cell(11, 10), "Shortage date", white); setCell(wsRank.Cell(11, 11), "≥ 2 week", yellow);
                setCell(wsRank.Cell(12, 10), "Gap delivery", white); setCell(wsRank.Cell(12, 11), "> 0", yellow);

                // B Local
                setMergeCell(wsRank.Range(13, 7, 14, 7), "B", true);
                setMergeCell(wsRank.Range(13, 9, 14, 9), "And", false);
                setCell(wsRank.Cell(13, 10), "Shortage date", white); setCell(wsRank.Cell(13, 11), "> valid date", yellow);
                setCell(wsRank.Cell(14, 10), "Gap delivery", white); setCell(wsRank.Cell(14, 11), "0", yellow);

                // Production short LT Local
                setMergeCell(wsRank.Range(15, 7, 16, 7), "Production short LT", true);
                setMergeCell(wsRank.Range(15, 9, 16, 9), "And", false);
                setCell(wsRank.Cell(15, 10), "Shortage date", white); setCell(wsRank.Cell(15, 11), "Shortage date = ETA PSNV", yellow);
                setCell(wsRank.Cell(16, 10), "Gap delivery", white); setCell(wsRank.Cell(16, 11), "1 day", yellow);

                // Overseas - Condition 1 trống cho A1, B, Production short LT
                setMergeCell(wsRank.Range(3, 2, 4, 2), "", false);    // A1
                setMergeCell(wsRank.Range(15, 2, 16, 2), "", false);  // B
                setMergeCell(wsRank.Range(17, 2, 18, 2), "", false);  // Production short LT

                // Local - Condition 1 trống cho A1, A3, A4, B, Production short LT
                setMergeCell(wsRank.Range(3, 8, 4, 8), "", false);    // A1
                setMergeCell(wsRank.Range(9, 8, 10, 8), "", false);   // A3
                setMergeCell(wsRank.Range(11, 8, 12, 8), "", false);  // A4
                setMergeCell(wsRank.Range(13, 8, 14, 8), "", false);  // B
                setMergeCell(wsRank.Range(15, 8, 16, 8), "", false);  // Production short LT

                // AutoFit
                wsRank.ColumnsUsed().AdjustToContents();

                using var stream = new MemoryStream();
                workbook.SaveAs(stream);
                return File(stream.ToArray(),
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    "CriticalList.xlsx");
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Có lỗi xảy ra: {ex.Message}" });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ChangeValid(DateTime? validRange, int validGWAir, int validGWAirOtherPlant, bool isMR)
        {
            try
            {
                var item = _context.NumberColumnShows.FirstOrDefault(x => x.DataSource == 0);
                if (item == null)
                {
                    return Json(new { success = false, message = "Không tìm thấy bản ghi để cập nhật." });
                }

                if (User.IsInRole("Admin"))
                {
                    item.OverrideEndValidDate = validRange;
                    item.IsOverride = true;
                    item.ValidGWAir = validGWAir;
                    item.ValidGWAirOtherPlant = validGWAirOtherPlant;
                }
                item.IsMR = isMR;
                _context.SaveChanges();

                _context.Database.SetCommandTimeout(300); // 300 giây = 5 phút
                await _context.Database.ExecuteSqlRawAsync("EXEC sp_ResertMR");

                // Log action history
                _context.ActionHistories.Add(new ActionHistory
                {
                    Username = User.Identity?.Name ?? "Anonymous",
                    ActionName = "ChangeValid",
                    FileName = $"ValidRange: {validRange:dd-MMM-yyyy}, ValidGWAir: {validGWAir}kg, ValidGWAirOtherPlant: {validGWAirOtherPlant}kg, IsMR: {isMR}"
                });
                await _context.SaveChangesAsync();

                return Json(new { success = true, message = "Cập nhật thành công." });
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Có lỗi xảy ra: {ex.Message}" });
            }

        }

        [HttpPost]
        [Authorize(Roles = "Admin,User")]
        public async Task<IActionResult> UpdateAllReports(IFormFile reportFile, DateTime? fromDate, DateTime? toDate, string dataType = "sap")
        {
            try
            {
                if (reportFile == null || reportFile.Length == 0)
                    return Json(new { success = false, message = "Vui lòng chọn file để upload." });

                // Xác định DataSource để xóa và insert
                byte deleteDataSource;
                byte insertDataSource;

                if (dataType?.ToLower() == "tcode")
                {
                    // TCode: xóa và insert DataSource = 1
                    deleteDataSource = 1;
                    insertDataSource = 1;
                }
                else if (dataType == "cos")
                {
                    deleteDataSource = 3;
                    insertDataSource = 3;
                }
                else
                {
                    // SAP hoặc SAP_Updated: xóa DataSource = 2, insert DataSource = 2
                    deleteDataSource = 2;
                    insertDataSource = 2;
                }

                using var stream = new MemoryStream();
                await reportFile.CopyToAsync(stream);
                using var workbook = new XLWorkbook(stream);
                var worksheet = workbook.Worksheet(1);

                // Đọc header row 2 để map column index
                var headerRow2 = worksheet.Row(2);
                var columnMap = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

                foreach (var cell in headerRow2.CellsUsed())
                {
                    var headerName = cell.GetString().Trim();
                    int colNum = cell.Address.ColumnNumber;
                    if (!string.IsNullOrEmpty(headerName) && !columnMap.ContainsKey(headerName))
                    {
                        columnMap[headerName] = colNum;
                    }
                }

                // Đọc row 1 cho các cột rowspan=2
                var headerRow1 = worksheet.Row(1);
                foreach (var cell in headerRow1.CellsUsed())
                {
                    var headerName = cell.GetString().Trim();
                    int colNum = cell.Address.ColumnNumber;
                    var row2Cell = worksheet.Cell(2, colNum).GetString().Trim();

                    if (string.IsNullOrEmpty(row2Cell) && !string.IsNullOrEmpty(headerName) && !columnMap.ContainsKey(headerName))
                    {
                        columnMap[headerName] = colNum;
                    }
                }

                // Tìm vị trí cột Freight unit để xác định Air GW và Air Cost
                int freightUnitCol = columnMap.TryGetValue("Freight unit", out int fc) ? fc : 0;

                // Đếm số cột Air summary
                int maxAirSummary = 0;
                if (freightUnitCol > 0)
                {
                    int totalMonthCols = 0;
                    for (int c = freightUnitCol + 1; c <= worksheet.LastColumnUsed().ColumnNumber(); c++)
                    {
                        var colName = worksheet.Cell(2, c).GetString().Trim().ToUpper();
                        if (IsMonthName(colName)) totalMonthCols++;
                    }
                    maxAirSummary = totalMonthCols / 2;
                }

                // Helper functions
                string GetString(IXLRow row, string colName)
                {
                    if (!columnMap.TryGetValue(colName, out int col)) return "";
                    return GetStringByCol(row, col);
                }

                string GetStringByCol(IXLRow row, int col)
                {
                    var cell = row.Cell(col);
                    if (cell.IsEmpty()) return "";
                    if (cell.Value.IsDateTime) return cell.GetDateTime().ToString("dd-MMM-yy");
                    return cell.GetString().Trim();
                }

                decimal? GetDecimal(IXLRow row, string colName)
                {
                    if (!columnMap.TryGetValue(colName, out int col)) return null;
                    var cell = row.Cell(col);
                    if (cell.IsEmpty()) return null;
                    if (cell.Value.IsNumber) return (decimal)cell.Value.GetNumber();
                    if (decimal.TryParse(cell.GetString(), out decimal result)) return result;
                    return null;
                }

                int? GetInt(IXLRow row, string colName)
                {
                    var dec = GetDecimal(row, colName);
                    return dec.HasValue ? (int?)Convert.ToInt32(dec.Value) : null;
                }

                bool IsMonthName(string name)
                {
                    var months = new[] { "JAN", "FEB", "MAR", "APR", "MAY", "JUN", "JUL", "AUG", "SEP", "OCT", "NOV", "DEC" };
                    return months.Contains(name.ToUpper());
                }

                // Data rows (skip 2 header rows)
                var dataRows = worksheet.RowsUsed().Where(r => r.RowNumber() >= 3);

                var list = new List<CriticalItem>();

                foreach (var row in dataRows)
                {
                    if (string.IsNullOrWhiteSpace(row.Cell(1).GetString()) &&
                        string.IsNullOrWhiteSpace(row.Cell(5).GetString())) continue;

                    var item = new CriticalItem
                    {
                        No = GetInt(row, "No") ?? 0,
                        Cat = GetString(row, "Category"),
                        CombinePart = GetString(row, "Combine Part"),
                        Plant = GetString(row, "Plant"),
                        PartNo = GetString(row, "Part no"),
                        PartName = GetString(row, "Part name"),
                        VendorCode = GetString(row, "Vendor code"),
                        VendorName = GetString(row, "Vendor name"),
                        MakerName = GetString(row, "Maker name"),
                        LeadTime = GetString(row, "Lead time"),
                        PurGr = GetString(row, "Pur Gr"),
                        PIC = GetString(row, "PIC"),
                        RoundingVal = GetString(row, "Rounding value (SPQ)"),
                        GWper1pcs = GetString(row, "G/W per 1pcs"),
                        UnitOfPacking = GetString(row, "Unit of packing (kg, g)"),

                        FirstShortage = GetString(row, "First shortage (after on the way)"),
                        ShortageQty = GetString(row, "Shortage qty"),

                        FinalShortageDate = GetString(row, "Final Shortage date"),
                        FinalShortageQty = GetString(row, "Final shortage Qty"),

                        V501 = GetString(row, "V501"),
                        VE01 = GetString(row, "VE01"),
                        VR01 = GetString(row, "VR01"),
                        VG01 = GetString(row, "VG01"),
                        VY01 = GetString(row, "VY01"),

                        NGQty = GetString(row, "NG Qty"),
                        FinalShortageAfterVendorConfirmStockOtherPlan = GetString(row, "Final shortage (after vendor confirm + stock other plan)"),
                        NextSimulation = GetString(row, "Next Simulation"),
                        FinalSimulation = GetString(row, "Final Simulation"),
                        FinalGapDate = GetString(row, "Final Gap date"),

                        Rank = GetString(row, "RANK"),
                        VendorStatus = GetString(row, "Vendor status"),
                        ShortLTFirst = GetString(row, "Short LT (first)"),

                        RequestGPRC = GetString(row, "REQUEST GPRC"),
                        MarketStock = GetString(row, "Market stock"),
                        StockOtherFactory = GetString(row, "Other factory name"),
                        StockOtherFactoryQty = GetString(row, "Stock other factory"),
                        RemarkByLeaderLastWeek = GetString(row, "Remark by leader (last week)"),
                        RankLastWeek = GetString(row, "Rank (last week)"),
                        RemarkByLeaderThisWeek = GetString(row, "Remark by leader (this week)"),
                        RankThisWeek = GetString(row, "Rank (this week)"),

                        FreightUnit = GetString(row, "Freight unit"),
                        CreatedDate = DateTime.Now,

                        DataSource = insertDataSource  // Insert với DataSource đã xác định
                    };

                    // Dynamic Inbound columns (max 5)
                    for (int i = 1; i <= 5; i++)
                    {
                        typeof(CriticalItem).GetProperty($"Inbound{i}Qty")?.SetValue(item, GetString(row, $"Inbound{i} (Qty)"));
                        typeof(CriticalItem).GetProperty($"Inbound{i}ETA")?.SetValue(item, GetString(row, $"Inbound{i} (ETA)"));
                    }

                    // Dynamic Vendor Confirmation columns (max 15)
                    for (int i = 1; i <= 15; i++)
                    {
                        typeof(CriticalItem).GetProperty($"Qty{i}")?.SetValue(item, GetString(row, $"Qty {i}"));
                        typeof(CriticalItem).GetProperty($"ETD{i}")?.SetValue(item, GetString(row, $"ETD {i}"));
                        typeof(CriticalItem).GetProperty($"ETA{i}")?.SetValue(item, GetString(row, $"ETA {i}"));
                        typeof(CriticalItem).GetProperty($"Shortage{i}")?.SetValue(item, GetString(row, $"Shortage {i}"));
                        typeof(CriticalItem).GetProperty($"Gap{i}")?.SetValue(item, GetString(row, $"Gap {i}"));
                        typeof(CriticalItem).GetProperty($"ETDAir{i}")?.SetValue(item, GetString(row, $"ETD (Air) {i}"));
                        typeof(CriticalItem).GetProperty($"ETAAir{i}")?.SetValue(item, GetString(row, $"ETA (Air) {i}"));
                        typeof(CriticalItem).GetProperty($"GWAir{i}")?.SetValue(item, GetString(row, $"GW (Air) {i}"));
                        typeof(CriticalItem).GetProperty($"FinalShortage{i}")?.SetValue(item, GetString(row, $"Final Shortage {i}"));
                        typeof(CriticalItem).GetProperty($"GapAir{i}")?.SetValue(item, GetString(row, $"Gap (Air) {i}"));
                    }

                    // Dynamic Part columns (max 14)
                    for (int i = 1; i <= 14; i++)
                    {
                        typeof(CriticalItem).GetProperty($"Part{i}")?.SetValue(item, GetString(row, $"Part {i}"));
                    }

                    // Dynamic Air GW summary by month
                    for (int i = 0; i < maxAirSummary; i++)
                    {
                        var propName = i == 0 ? "GWAirMonthN" : $"GWAirMonthN{i}";
                        int col = freightUnitCol + 1 + i;
                        typeof(CriticalItem).GetProperty(propName)?.SetValue(item, GetStringByCol(row, col));
                    }

                    // Dynamic Air Cost summary by month
                    for (int i = 0; i < maxAirSummary; i++)
                    {
                        var propName = i == 0 ? "CostAirMonthN" : $"CostAirMonthN{i}";
                        int col = freightUnitCol + 1 + maxAirSummary + i;
                        typeof(CriticalItem).GetProperty(propName)?.SetValue(item, GetStringByCol(row, col));
                    }

                    list.Add(item);
                }

                if (list.Count == 0)
                    return Json(new { success = false, message = "File không có dữ liệu." });

                using var transaction = await _context.Database.BeginTransactionAsync();
                try
                {
                    // Xóa data theo deleteDataSource và date
                    var from = fromDate?.Date ?? DateTime.Now.Date;
                    var to = toDate?.Date ?? DateTime.Now.Date;
                    var oneYearAgo = DateTime.Now.Date.AddYears(-1);

                    await _context.Database.ExecuteSqlRawAsync(@"DELETE FROM tblShortageSimulation WHERE DataSource = {0} AND CAST(CreatedDate AS DATE) >= {1} AND CAST(CreatedDate AS DATE) <= {2} OR CAST(CreatedDate AS DATE) <= {3}", deleteDataSource, from, to, oneYearAgo);
                     _context.CriticalItems.AddRange(list);

                    // Log action
                    _context.ActionHistories.Add(new ActionHistory
                    {
                        Username = User.Identity?.Name ?? "Anonymous",
                        ActionName = "UpdateAllReports",
                        FileName = reportFile?.FileName
                    });
                    await _context.SaveChangesAsync();
                    await transaction.CommitAsync();

                    // Message theo loại
                    string sourceText = insertDataSource == 1 ? "TCode" : "SAP (Updated)";
                    return Json(new { success = true, message = $"Upload thành công {list.Count} bản ghi vào {sourceText}." });
                }
                catch
                {
                    await transaction.RollbackAsync();
                    throw;
                }
            }
            catch (Exception ex)
            {
                return Json(new { success = false, message = $"Có lỗi xảy ra: {ex.Message}" });
            }
        }


        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        private byte ParseDataSource(string? dataType)
        {
            return dataType?.ToLower() switch
            {
                "tcode" => 1,
                "sap_updated" => 2,
                "cos" => 3,
                _ => 0  // default: sap
            };
        }

        private IQueryable<CriticalItem> ApplyFilter(IQueryable<CriticalItem> query,
        string? plant, string? partNo, string? vendorCode, DateTime? fromDate, DateTime? toDate, string? pic, bool cos = false)
        {
            // Parse nhiều giá trị với dấu , và space
            List<string> ParseMultipleValues(string? input)
            {
                if (string.IsNullOrEmpty(input))
                    return new List<string>();
                return input
                    .Split(new[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries)
                    .Select(v => v.Trim())
                    .Where(v => !string.IsNullOrEmpty(v))
                    .ToList();
            }

            // Parse chỉ với dấu phẩy (cho PIC vì tên có thể có space)
            List<string> ParseByCommaOnly(string? input)
            {
                if (string.IsNullOrEmpty(input))
                    return new List<string>();
                return input
                    .Split(',', StringSplitOptions.RemoveEmptyEntries)
                    .Select(v => v.Trim())
                    .Where(v => !string.IsNullOrEmpty(v))
                    .ToList();
            }

            // Filter CreatedDate
            var from = fromDate?.Date ?? DateTime.Now.Date;
            var to = toDate?.Date ?? DateTime.Now.Date;

            query = query.Where(x => x.CreatedDate.Date >= from
                                  && x.CreatedDate.Date <= to);

            // Filter Plant (exact match)
            var plants = ParseMultipleValues(plant);
            if (plants.Count > 0)
            {
                query = query.Where(x => plants.Contains(x.Plant!));
            }

            // Filter PartNo (partial match)
            var partNos = ParseMultipleValues(partNo);
            if (partNos.Count > 0)
            {
                var predicate = PredicateBuilder.New<CriticalItem>(false);
                foreach (var p in partNos)
                {
                    predicate = predicate.Or(x => x.PartNo!.Contains(p));
                }
                query = query.AsExpandable().Where(predicate);
            }

            // Filter VendorCode (partial match - hỗ trợ format VE001/VE002/VE003)
            var vendorCodes = ParseMultipleValues(vendorCode);
            if (vendorCodes.Count > 0)
            {
                var predicate = PredicateBuilder.New<CriticalItem>(false);
                foreach (var v in vendorCodes)
                {
                    // Match nếu VendorCode chứa giá trị search
                    // Ví dụ: search "VE001" sẽ match "VE001/VE002/VE003"
                    predicate = predicate.Or(x => x.VendorCode!.Contains(v));
                }
                query = query.AsExpandable().Where(predicate);
            }

            // Filter PIC (partial match) - CHỈ CẮT THEO DẤU PHẨY
            var pics = ParseByCommaOnly(pic);
            if (pics.Count > 0)
            {
                var predicate = PredicateBuilder.New<CriticalItem>(false);
                foreach (var p in pics)
                {
                    predicate = predicate.Or(x => x.PIC!.Contains(p));
                }
                query = query.AsExpandable().Where(predicate);
            }

            if (cos)
            {
                query = query.Where(x =>
                    (x.PurGr != null && (
                        x.PurGr.EndsWith("01") ||
                        x.PurGr.EndsWith("95") ||
                        x.PurGr.EndsWith("DE") ||
                        x.PurGr.EndsWith("DY") ||
                        x.PurGr.EndsWith("99") ||
                        x.PurGr.EndsWith("D5")))
                    || x.VendorCode == null);
            }

            return query;
        }
    }
}
