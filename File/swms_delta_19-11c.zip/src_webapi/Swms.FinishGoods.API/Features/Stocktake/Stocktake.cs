namespace Swms.FinishGoods.API.Features.Stocktake;

/// <summary>Tóm tắt 1 phiếu kiểm kê (cho danh sách).</summary>
public class CountSummary
{
    public long Id { get; set; }
    public string DocNo { get; set; } = string.Empty;
    public string? CountType { get; set; }        // morning | shipment | monthly
    public DateTime CountDate { get; set; }
    public string DocStatus { get; set; } = "draft"; // draft | counting | counted | confirmed
    public string? SourceRef { get; set; }
    public string? Description { get; set; }
    public int TotalLines { get; set; }
    public int CountedLines { get; set; }
    public int DiscrepancyLines { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>1 dòng kiểm kê = 1 pallet (lot) tại 1 vị trí.</summary>
public class CountLine
{
    public long Id { get; set; }
    public int LineNo { get; set; }
    public int ProductId { get; set; }
    public string? ProductName { get; set; }
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = string.Empty;
    public long? LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public int QtySystem { get; set; }
    public int? QtyCount { get; set; }

    /// <summary>Số box theo hệ thống; số lượng = box x StandardPacking.</summary>
    public int? BoxCountSystem { get; set; }
    /// <summary>Số box người kiểm đếm được (dấu vết nhập tay).</summary>
    public int? BoxCountCounted { get; set; }
    /// <summary>Số cái/box của model, chụp lúc tạo phiếu (master.models).</summary>
    public int? StandardPacking { get; set; }

    public bool IsAdjusted { get; set; }
    public string? Note { get; set; }

    /// <summary>Pallet phát sinh: tìm thấy ở ô này khi kiểm, hệ thống không ghi ở đây.</summary>
    public bool IsFound { get; set; }
    /// <summary>Vị trí hệ thống đang ghi cho pallet phát sinh (lúc quét).</summary>
    public string? SystemLocatorCode { get; set; }

    /// <summary>
    /// Pallet này có biến động vị trí trong cửa sổ của phiếu SÁNG hay không.
    ///
    /// Luôn false ở phiếu cuối tháng — phiếu đó kiểm theo Ô, mọi pallet đều
    /// phải đếm nên cờ này vô nghĩa. Chỉ dùng để màn hình lọc bớt những pallet
    /// nằm yên tại chỗ ở phiếu sáng.
    /// </summary>
    public bool IsMoved { get; set; }

    /// <summary>Thứ tự đi kiểm kê theo bản đồ (1 = kiểm đầu tiên).</summary>
    public int WalkSeq { get; set; }
    public string? AreaCode { get; set; }
    public string? AreaName { get; set; }
}

public class CountDetail
{
    public CountSummary Header { get; set; } = new();
    public IReadOnlyList<CountLine> Lines { get; set; } = new List<CountLine>();
}

public class CreateCountResult
{
    public long Id { get; set; }
    public string DocNo { get; set; } = string.Empty;
    public int LineCount { get; set; }
}

/// <summary>Kết quả ghi pallet phát sinh.</summary>
public class AddFoundResult
{
    public long LineId { get; set; }
    /// <summary>false = pallet vốn thuộc ô này (đã có dòng) — không tạo dòng mới.</summary>
    public bool Created { get; set; }
}
