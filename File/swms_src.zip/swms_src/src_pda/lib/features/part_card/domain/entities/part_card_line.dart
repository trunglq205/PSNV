import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_origin.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// MỘT dòng mã trên phiếu Part Card.
///
/// Chế độ [PartCardMode.single] luôn có đúng 1 dòng với [box] = 1 —
/// nhờ vậy layout/nhãn cũ không đổi một byte nào.
@immutable
class PartCardLine {
  const PartCardLine({
    required this.model,
    this.box = 1,
    this.quantity = 0,
    this.origin = .defaultValue,
    this.oqcChecked = false,
    this.info,
  });

  final String model;

  /// Số THÙNG của mã này trên phiếu.
  final int box;

  /// Số pcs TRONG 1 THÙNG (= standard packing của model).
  final int quantity;

  final PartCardOrigin? origin;

  /// Đã OQC check (ASSY) hay chưa. Chỉ in ở tem nhiều mã:
  /// chưa check → in "X", đã check → để trống. KHÔNG bắt buộc để in.
  final bool oqcChecked;

  /// Thông tin model lấy từ API.
  /// `null` = model chưa có trên hệ thống → phải `createModel` trước khi in.
  final ModelInfo? info;

  bool get isNewModel => info == null;

  bool get isComplete =>
      model.trim().isNotEmpty &&
          box > 0 &&
          quantity > 0 &&
          origin != null;

  factory PartCardLine.fromModelInfo(ModelInfo info) => PartCardLine(
    model: info.model,
    quantity: info.standardPacking,
    info: info,
  );

  factory PartCardLine.empty(String model) =>
      PartCardLine(model: model.trim().toUpperCase());

  PartCardLine copyWith({
    String? model,
    int? box,
    int? quantity,
    PartCardOrigin? origin,
    bool? oqcChecked,
    ModelInfo? info,
    bool clearInfo = false,
  }) {
    return PartCardLine(
      model: model ?? this.model,
      box: box ?? this.box,
      quantity: quantity ?? this.quantity,
      origin: origin ?? this.origin,
      oqcChecked: oqcChecked ?? this.oqcChecked,
      info: clearInfo ? null : info ?? this.info,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
          other is PartCardLine &&
              other.model == model &&
              other.box == box &&
              other.quantity == quantity &&
              other.origin == origin &&
              other.oqcChecked == oqcChecked &&
              other.info == info;

  @override
  int get hashCode =>
      Object.hash(model, box, quantity, origin, oqcChecked, info);
}