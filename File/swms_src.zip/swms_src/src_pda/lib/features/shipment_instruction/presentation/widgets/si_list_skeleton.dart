import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_skeleton.dart';

/// Skeleton danh sách Chỉ thị lấy hàng: bám đúng padding/khoảng cách của
/// _SiListView và bố cục SiListCard để data về không giật layout.
class SiListSkeleton extends StatelessWidget {
  /// Số thẻ giả.
  final int count;

  const SiListSkeleton({super.key, this.count = 5});

  @override
  Widget build(BuildContext context) {
    return ListView.separated(
      physics: const NeverScrollableScrollPhysics(),
      padding: const EdgeInsets.fromLTRB(
        AppDimens.md,
        0,
        AppDimens.md,
        AppDimens.md,
      ),
      itemCount: count,
      separatorBuilder: (_, _) => const SizedBox(height: AppDimens.sm),
      itemBuilder: (_, i) => _SiCardSkeleton(seed: i),
    );
  }
}

/// = SiListCard: mã SI + revision + nút/pill · dòng nước đến/ETD ·
/// thanh tiến độ + % · dòng model.
class _SiCardSkeleton extends StatelessWidget {
  /// Đổi độ dài thanh theo thẻ cho tự nhiên.
  final int seed;

  const _SiCardSkeleton({required this.seed});

  static const _siW = [128.0, 110.0, 142.0];
  static const _infoW = [210.0, 180.0, 230.0];
  static const _modelW = [160.0, 130.0, 190.0];

  @override
  Widget build(BuildContext context) {
    final k = seed % 3;
    return SkeletonCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Mã SI + revision + nút "Soạn hàng"/pill trạng thái
          Row(
            children: [
              Bone(width: _siW[k], height: 15),
              const SizedBox(width: 7),
              const Bone(width: 22, height: 11),
              const Spacer(),
              const Bone(width: 84, height: 28, radius: AppDimens.rInput - 2),
            ],
          ),
          const SizedBox(height: AppDimens.xs),
          // Nước đến · consignee · mode · ETD
          Bone(width: _infoW[k]),
          const SizedBox(height: 9),
          // Tiến độ + %
          const Row(
            children: [
              Expanded(child: Bone(height: 6, radius: 999)),
              SizedBox(width: AppDimens.sm),
              Bone(width: 28, height: 11),
            ],
          ),
          const SizedBox(height: 6),
          // Model preview / cảnh báo
          Bone(width: _modelW[k], height: 11),
        ],
      ),
    );
  }
}
