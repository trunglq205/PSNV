using Swms.FinishGoods.API.Features.HdSoft.Business;

namespace Swms.FinishGoods.API.Features.HdSoft.DataAccess;

public interface IHdSoftSiRepository
{
    /// <summary>Mỗi SINo 1 phiếu C_Order (chưa huỷ, tạo mới nhất) kèm dòng. SINo không có thì không có trong kết quả.</summary>
    Task<IReadOnlyList<HdSoftSiOrder>> GetOrdersAsync(IReadOnlyCollection<string> siNos);

    /// <summary>SINo có ETD trong [from, toExclusive): cột etd nếu là kiểu ngày, không thì datepromised.
    /// Bỏ phiếu đã huỷ / đảo. warehouse null = mọi kho.</summary>
    Task<IReadOnlyList<string>> GetSiNosByEtdAsync(DateTime from, DateTime toExclusive, string? warehouse);

    /// <summary>Cột tuỳ biến tìm được (cache 30 phút).</summary>
    Task<HdSoftSiSchema> GetSchemaAsync();

    /// <summary>Tồn kho (QtyOnHand) theo M_Product.Value, chỉ các sản phẩm được hỏi. warehouse null = mọi kho.</summary>
    Task<IReadOnlyDictionary<string, decimal>> GetOnHandByProductAsync(
        IReadOnlyCollection<string> productValues, string? warehouse);
}
