using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Shortages.Api;

namespace Swms.FinishGoods.API.Features.Shortages.Business;

public interface IShortageService
{
    Task<PagedResult<ShortageItemResponse>> GetPagedAsync(ShortageQuery query);
    Task<ShortageSummaryResponse> GetSummaryAsync(ShortageQuery query);
    Task<List<StockPalletResponse>> GetStockAsync(string model);
    Task<List<RecipientResponse>> GetRecipientsAsync(
        string eventCode, string? department, string? subCode, string? category, string? model);
    Task<ShortageMailPreviewResponse> GetMailPreviewAsync(ShortageMailPreviewQuery query);
    Task<SendRequestResponse> SendAsync(ShortageSendRequest request);

    /// <summary>Báo cáo hàng thiếu hằng ngày (SHORTAGE_DAILY) — worker gọi mỗi sáng.</summary>
    Task<DailyReportResponse> SendDailyReportAsync(bool dryRun, bool skipIfEmpty);
}
