using Swms.FinishGoods.Web.Features.HdSoft.Shortage.Business.Models;
using Swms.FinishGoods.Web.Features.HdSoft.Shortage.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.HdSoft.Shortage.Business;

public class HdSoftShortageBusiness : BaseBusiness, IHdSoftShortageBusiness
{
    private readonly IHdSoftShortageApi _api;

    public HdSoftShortageBusiness(IHdSoftShortageApi api, ILogger<HdSoftShortageBusiness> logger, ErrorHandler errorHandler)
        : base(logger, errorHandler)
    {
        _api = api;
    }

    public Task<Result<AppHdSoftShortage>> GetAsync(DateTime from, DateTime to, string warehouse)
        => ExecuteAsync(async () =>
            (await _api.GetAsync(from.Date, to.Date, warehouse.Trim(), onlyShort: false)).ToViewModel());
}
