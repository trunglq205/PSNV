﻿// Features/Models/ModelModule.cs
using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.Models.Business;
using Swms.FinishGoods.Web.Features.Models.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.Models;

public static class ModelModule
{
    public static IServiceCollection AddModelFeature(this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<IModelApi>(api);
        services.AddScoped<IModelBusiness, ModelBusiness>();
        return services;
    }
}