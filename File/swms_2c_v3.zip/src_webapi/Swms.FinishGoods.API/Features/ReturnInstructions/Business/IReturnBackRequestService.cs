using Swms.FinishGoods.API.Features.ReturnInstructions.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

public interface IReturnBackRequestService
{
    Task<IReadOnlyList<BackRequestResponse>> GetListAsync(BackRequestQuery query);

    Task<BackRequestResponse> GetByIdAsync(long id);

    /// <summary>
    /// SL còn gắp được theo model. Màn soạn đề nghị gọi để CHO XEM phần hàng sẽ
    /// lấy về — không nhập, không sửa.
    /// </summary>
    Task<IReadOnlyList<BackAvailableModelResponse>> GetAvailableAsync(long docId);

    /// <summary>
    /// B1 — FA tạo đề nghị. Chỉ chọn phiếu; dòng model + SL suy từ phiếu.
    /// KHÔNG gửi mail ở bước này.
    /// </summary>
    Task<BackRequestResponse> CreateAsync(CreateBackRequestRequest request);

    /// <summary>Sửa ghi chú, chỉ khi còn chờ quản lý FA xác nhận.</summary>
    Task<BackRequestResponse> UpdateAsync(long id, UpdateBackRequestRequest request);

    /// <summary>
    /// B2 — quản lý FA xác nhận. Gửi mail TO SCS Office, CC FA. Sau bước này
    /// SCS Office tự thông báo cho SCS WH ngoài hệ thống.
    /// </summary>
    Task<BackRequestResponse> ApproveFaAsync(long id, BackRequestDecisionRequest request);

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA. ĐÂY là bước chuyển serial
    /// sang <c>at_fa</c>, tức mốc hàng rời kho SCS. Giao xong cả đề nghị thì gửi
    /// mail TO FA, CC SCS.
    /// </summary>
    Task<BackDeliverResponse> DeliverAsync(long id, DeliverBackRequest request);

    /// <summary>
    /// Nhật ký pallet đã giao của một đề nghị, mới nhất trước. Màn hình và PDA
    /// cần nó để WH biết đã quét những pallet nào rồi — giao dần nhiều lượt thì
    /// không ai nhớ được bằng đầu.
    /// </summary>
    Task<IReadOnlyList<BackDeliveryResponse>> GetDeliveriesAsync(long id);

    /// <summary>Huỷ — chỉ khi chưa giao con nào.</summary>
    Task<BackRequestResponse> CancelAsync(long id, BackRequestDecisionRequest request);
}
