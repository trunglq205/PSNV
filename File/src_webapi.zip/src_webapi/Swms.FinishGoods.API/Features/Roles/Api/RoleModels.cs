using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.Api.Features.Roles.Api;

// ─────────────────────────── REQUESTS (input) ───────────────────────────

public record CreateRoleRequest(
    [Required, MaxLength(50)]  string Code,
    [Required, MaxLength(200)] string Name,
    [MaxLength(500)]           string? Description,
    [MaxLength(20)]            string? Dot,
    string? CloneFromCode);                 // sao chép quyền từ role có sẵn (nullable)

public record UpdateRoleRequest(
    [Required, MaxLength(50)]  string Code,      // code hiện tại (để tìm role)
    [Required, MaxLength(50)]  string NewCode,   // code mới (có thể bằng Code)
    [Required, MaxLength(200)] string Name,
    [MaxLength(500)]           string? Description,
    [MaxLength(20)]            string? Dot);

public record UpdateRolePermsRequest(
    [Required] string Code,
    List<string> Permissions);

// ─────────────────────────── RESPONSES (output) ─────────────────────────

public record RoleResponse(
    string Code,
    string Name,
    string Description,
    string Dot,
    bool IsSystem,
    int UserCount,
    List<string> Permissions)
{
    public static RoleResponse From(Business.Models.Role r)
        => new(r.Code, r.Name, r.Description, r.Dot, r.IsSystem, r.UserCount,
               r.Permissions ?? new());
}

// ─── Permission catalog: cây Module → Screen → Permission ───
//     Name đa ngôn ngữ được service tra từ resx theo code rồi đổ vào đây.

public record PermissionItemResponse(
    string Action,
    string Code,
    string Name);

public record PermissionScreenResponse(
    string Code,
    string Name,
    List<PermissionItemResponse> Perms);

public record PermissionModuleResponse(
    string Code,
    string Name,
    List<PermissionScreenResponse> Screens);
