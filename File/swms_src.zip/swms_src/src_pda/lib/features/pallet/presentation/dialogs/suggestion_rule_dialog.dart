import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';

/// Một dòng cấu hình master: đầu mã được quy định ở khu nào, tầng nào.
class RuleMasterZone {
  const RuleMasterZone({required this.zone, required this.floors});

  /// Khu / slock, ví dụ: SCM, PMD, FA...
  final String zone;

  /// Tầng được phép, ví dụ: "Tầng 2,3".
  final String floors;
}

/// Mở dialog giải thích quy tắc gợi ý vị trí (theo "Rule lưu kho" của PLD).
///
/// [itemCode] đầu mã pallet đang xử lý (ví dụ: ABC).
/// [masterZones] cấu hình khu · tầng lấy từ master.
/// [lastLotLocation] vị trí lot gần nhất của model, null nếu chưa có.
Future<void> showSuggestionRuleDialog(
    BuildContext context, {
      String? itemCode,
      List<RuleMasterZone> masterZones = const [],
      String? lastLotLocation,
    }) {
  return showDialog<void>(
    context: context,
    builder: (_) => _SuggestionRuleDialog(
      itemCode: itemCode,
      masterZones: masterZones,
      lastLotLocation: lastLotLocation,
    ),
  );
}

/// Dialog chỉ đọc: thứ tự ưu tiên khi hệ thống gợi ý vị trí đặt pallet.
class _SuggestionRuleDialog extends StatelessWidget {
  const _SuggestionRuleDialog({
    this.itemCode,
    this.masterZones = const [],
    this.lastLotLocation,
  });

  final String? itemCode;
  final List<RuleMasterZone> masterZones;
  final String? lastLotLocation;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppDialog(
      title: LocaleKeys.pallet_flow_rule_title.tr(),
      subtitle: LocaleKeys.pallet_flow_rule_subtitle.tr(),
      // Nội dung dài -> cuộn, chặn trần để dialog không cao bằng màn hình.
      scrollable: true,
      maxBodyHeight: 460,
      // Chỉ đọc: không có gì để xác nhận, một nút đóng là đủ.
      actions: [AppDialogAction.close(context)],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // ── Ưu tiên 1: theo master ──
          _RuleSection(
            index: 1,
            title: LocaleKeys.pallet_flow_rule_p1_title.tr(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _MasterCaption(itemCode: itemCode),
                const SizedBox(height: AppDimens.sm),
                if (masterZones.isEmpty)
                  _EmptyHint(text: LocaleKeys.pallet_flow_rule_p1_empty.tr())
                else
                  for (final zone in masterZones)
                    Padding(
                      padding: const EdgeInsets.only(bottom: AppDimens.xs),
                      child: _ZoneRow(zone: zone),
                    ),
              ],
            ),
          ),
          const SizedBox(height: AppDimens.md),

          // ── Ưu tiên 2: theo last lot ──
          _RuleSection(
            index: 2,
            title: LocaleKeys.pallet_flow_rule_p2_title.tr(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Text(
                  LocaleKeys.pallet_flow_rule_p2_desc.tr(),
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
                const SizedBox(height: AppDimens.sm),
                if (lastLotLocation == null || lastLotLocation!.isEmpty)
                  _EmptyHint(text: LocaleKeys.pallet_flow_rule_p2_empty.tr())
                else
                  _LastLotRow(location: lastLotLocation!),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Khối "Ưu tiên N" với badge số + tiêu đề + nội dung.
class _RuleSection extends StatelessWidget {
  const _RuleSection({
    required this.index,
    required this.title,
    required this.child,
  });

  final int index;
  final String title;
  final Widget child;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: swms.primary),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Container(
                width: 22,
                height: 22,
                alignment: Alignment.center,
                decoration: BoxDecoration(
                  color: swms.primary,
                  shape: BoxShape.circle,
                ),
                child: Text(
                  '$index',
                  style: AppTextStyles.caption.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w800,
                  ),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Text(
                  title,
                  style: AppTextStyles.label.copyWith(
                    fontWeight: FontWeight.w700,
                    color: swms.text2,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(height: AppDimens.sm),
          child,
        ],
      ),
    );
  }
}

/// Dòng mô tả "Mã {code} được quy định ở các khu · tầng:" với mã in đậm.
class _MasterCaption extends StatelessWidget {
  const _MasterCaption({this.itemCode});

  final String? itemCode;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final captionStyle = AppTextStyles.caption.copyWith(color: swms.text3);
    final code = (itemCode == null || itemCode!.isEmpty) ? '—' : itemCode!;
    final parts = LocaleKeys.pallet_flow_rule_p1_desc.tr().split('{code}');

    return Text.rich(
      TextSpan(
        style: captionStyle,
        children: [
          TextSpan(text: parts.first),
          TextSpan(
            text: code,
            style: AppTextStyles.code.copyWith(
              fontWeight: FontWeight.w700,
              color: swms.text2,
            ),
          ),
          if (parts.length > 1) TextSpan(text: parts[1]),
        ],
      ),
    );
  }
}

/// Chip "khu → tầng" của rule master.
class _ZoneRow extends StatelessWidget {
  const _ZoneRow({required this.zone});

  final RuleMasterZone zone;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
      decoration: BoxDecoration(
        color: swms.primary.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: swms.primary.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Text(
            zone.zone,
            style: AppTextStyles.code.copyWith(
              fontWeight: FontWeight.w700,
              color: swms.primary,
            ),
          ),
          const SizedBox(width: AppDimens.sm),
          Icon(Icons.arrow_forward, size: 14, color: swms.primary),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text(
              zone.floors,
              style: AppTextStyles.label.copyWith(
                fontWeight: FontWeight.w700,
                color: swms.text2,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Chip vị trí lot gần nhất.
class _LastLotRow extends StatelessWidget {
  const _LastLotRow({required this.location});

  final String location;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
      decoration: BoxDecoration(
        color: swms.primary.withValues(alpha: 0.08),
        borderRadius: BorderRadius.circular(9),
        border: Border.all(color: swms.primary.withValues(alpha: 0.3)),
      ),
      child: Row(
        children: [
          Icon(Icons.history, size: 17, color: swms.primary),
          const SizedBox(width: AppDimens.sm),
          Text(
            location,
            style: AppTextStyles.code.copyWith(
              fontWeight: FontWeight.w700,
              color: swms.primary,
            ),
          ),
          const Spacer(),
          Text(
            LocaleKeys.pallet_flow_rule_p2_hint.tr(),
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
        ],
      ),
    );
  }
}

/// Dòng thay thế khi chưa có dữ liệu cho một ưu tiên.
class _EmptyHint extends StatelessWidget {
  const _EmptyHint({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Text(
      text,
      style: AppTextStyles.caption.copyWith(color: swms.text3),
    );
  }
}