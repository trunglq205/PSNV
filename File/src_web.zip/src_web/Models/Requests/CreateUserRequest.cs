﻿using Newtonsoft.Json;

namespace SWMS_WebTool.Models.Requests
{
    public class CreateUserRequest
    {
        public string UserID { get; set; }
        public string UserFullName { get; set; }
        public int SectionID { get; set; }
        public int PositionUserID { get; set; }
        public string Password { get; set; }
        public string WebRole { get; set; }
        public string PdaRole { get; set; }
    }
}
