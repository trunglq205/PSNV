import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/back_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_stepper_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_alert_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/pallet/presentation/dialogs/storage_info_dialog.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow_notifier.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow_state.dart';
import 'package:swms_finish_goods/features/pallet/presentation/utils/pallet_i18n.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/flow/pallet_flow_action_body.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/flow/pallet_flow_scan_body.dart';
import 'package:swms_finish_goods/features/receiving/presentation/widgets/receiving_bottom_hint.dart';

// ─────────────────────────────────────────────────────────────
//  Trang dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
//  Route thật (TempLocationScreen, StoringScreen, WarehouseMoveScreen)
//  chỉ là wrapper truyền [flow] vào đây.
//
//  Bước 1: quét mã pallet -> lookup by-lot-no (include theo flow).
//  Bước 2: chọn hành động -> quét vị trí (nếu cần) -> xác nhận.
//          Riêng Lưu kho: gọi thêm .../storage-suggestion ở nền.
//  Xong  : tự quay lại bước 1 để quét pallet tiếp.
// ─────────────────────────────────────────────────────────────

class PalletFlowPage extends ConsumerStatefulWidget {
  const PalletFlowPage({super.key, required this.flow, this.lotNo});

  final PalletFlow flow;

  /// Nếu truyền sẵn (từ Pallet Detail) thì tự lookup, bỏ bước quét.
  final String? lotNo;

  @override
  ConsumerState<PalletFlowPage> createState() => _PalletFlowPageState();
}

class _PalletFlowPageState extends ConsumerState<PalletFlowPage> {
  StreamSubscription<String>? _sub;

  /// Đang xử lý 1 mã (gọi API / đang mở popup) → bỏ qua mã quét chen vào,
  /// tránh PDA bắn liên tiếp mở nhiều popup chồng nhau.
  bool _busy = false;

  PalletFlowNotifierProvider get _provider => palletFlowProvider(widget.flow);
  PalletFlowNotifier get _notifier => ref.read(_provider.notifier);

  @override
  void initState() {
    super.initState();
    _listen();
    final lot = widget.lotNo;
    if (lot != null && lot.trim().isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (!mounted) return;
        _handleScan(lot.trim());
      });
    }
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      _handleScan(data);
    });
  }

  Future<void> _handleScan(String data) async {
    if (_busy) return;
    _busy = true;
    try {
      final code = data.trim();
      final others = await _notifier.onScan(code);
      if (!mounted || others == null || others.isEmpty) return;

      final ok = await _confirmShared(code, others);
      if (ok == true && mounted) _notifier.confirmLocator(code);
    } finally {
      _busy = false;
    }
  }

  Future<bool?> _confirmShared(String locatorCode, List<String> others) {
    return showDialog<bool>(
      context: context,
      barrierDismissible: false,
      builder: (_) => AppAlertDialog(
        type: AppAlertDialogType.confirm,
        title: LocaleKeys.pallet_flow_locator_occupied_title.tr(),
        message: LocaleKeys.pallet_flow_locator_occupied_message.tr(
          args: [locatorCode, others.join(', ')],
        ),
        confirmText: LocaleKeys.pallet_flow_locator_occupied_confirm.tr(),
        cancelText: LocaleKeys.common_cancel.tr(),
      ),
    );
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _submit() async {
    final result = await _notifier.submit();
    if (!mounted || result == null) return;

    final text = LocaleKeys.pallet_flow_done_to.tr(
      args: [result.lotNo, result.toLocatorCode ?? ''],
    );

    AppToastHelper.toast(
      context,
      message: result.hasWarning ? '$text\n${result.warning}' : text,
      type: result.hasWarning ? .warning : .info,
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(_provider);

    return Scaffold(
      appBar: AppTopBar(
        title: widget.flow.titleKey.tr(),
        subtitle: widget.flow.subtitleKey.tr(),
      ),
      body: Padding(
        padding: const EdgeInsets.all(AppDimens.md),
        child: Column(
          children: [
            AppStepperBar(
              current: state.step.number,
              steps: [
                StepItem(LocaleKeys.pallet_flow_step_scan.tr()),
                StepItem(LocaleKeys.pallet_flow_step_action.tr()),
              ],
              // Chỉ cho lùi về bước 1; muốn sang bước 2 phải quét pallet.
              onStepTap: (i) {
                if (i == 1) _notifier.goStep(1);
              },
            ),
            const SizedBox(height: AppDimens.sm),
            Expanded(child: _buildBody(state)),
          ],
        ),
      ),
      bottomNavigationBar: _buildBottom(state),
    );
  }

  Widget _buildBody(PalletFlowState state) {
    switch (state.step) {
      case PalletFlowStep.scanPallet:
      // Loading / lỗi lookup hiện inline ở bước 1 (từ executePartial).
        return switch (state.pallet) {
          AsyncLoading() => const AppLoading(),
          AsyncError(:final error) => AppErrorView.page(
            message: _errorMessage(error),
            onRetry: _notifier.retry,
          ),
          _ => const PalletFlowScanBody(),
        };

      case PalletFlowStep.action:
        final pallet = state.currentPallet;
        if (pallet == null) return const SizedBox.shrink();
        return PalletFlowActionBody(
          pallet: pallet,
          actions: state.actions,
          action: state.action,
          scannedLocatorCode: state.scannedLocatorCode,
          onActionChanged: _notifier.selectAction,
          onClearLocator: _notifier.clearLocator,
          // Gợi ý vị trí lưu kho — các màn khác giữ AsyncData(null) nên khối
          // gợi ý tự ẩn, không cần rẽ nhánh theo flow ở đây.
          suggestion: state.suggestion,
          palletHeightCm: state.palletHeightCm,
          masterDraft: state.masterDraft,
          onRetrySuggestion: _notifier.reloadSuggestion,
          onStorageInfoSaved: _onStorageInfoSaved,
        );
    }
  }

  Widget _buildBottom(PalletFlowState state) {
    switch (state.step) {
      case PalletFlowStep.scanPallet:
        return ReceivingBottomHint(
          text: LocaleKeys.pallet_flow_scan_pallet_to_start.tr(),
        );

      case PalletFlowStep.action:
        final action = state.action;
        final label =
        (action?.submitKey ?? LocaleKeys.pallet_flow_choose_action).tr();

        return ReceivingBottomHint(
          child: Row(
            children: [
              BackIconButton(onPressed: () => _notifier.goStep(1)),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: AppButton(
                  label: label,
                  variant: AppButtonVariant.success,
                  icon: Icons.check_rounded,
                  isFullWidth: false,
                  onPressed: state.canSubmit ? _submit : null,
                ),
              ),
            ],
          ),
        );
    }
  }

  /// Người dùng vừa bấm Xác nhận ở dialog bổ sung thông tin lưu kho.
  ///
  /// Hai tab ghi vào hai chỗ khác hẳn nhau:
  ///   - "Nhập kích thước": chiều cao của RIÊNG pallet đang cầm, chỉ nằm trong
  ///     state rồi gửi kèm query khi xin gợi ý.
  ///   - "Khai báo master": PATCH thẳng master.models — có tác dụng cho mọi
  ///     pallet cùng model về sau, nên đi qua overlay + báo lỗi rõ ràng.
  ///
  /// Không dùng `switch` biểu thức ở đây vì cả hai nhánh đều là lời gọi trả
  /// Futurevoid>; `switch` câu lệnh (không cần `break` ở Dart 3) là đúng hình.
  void _onStorageInfoSaved(StorageInfoResult r) {
    switch (r.mode) {
      case StorageInfoMode.dimension:
        _notifier.setPalletHeight(r.heightCm);
      case StorageInfoMode.master:
        _notifier.saveMasterSuggestion(
          suggestAreaId: r.suggestAreaId,
          suggestRackRow: r.suggestRackRow,
        );
    }
  }

  String _errorMessage(Object error) =>
      error is AppException ? error.message : LocaleKeys.pallet_flow_load_error.tr();
}