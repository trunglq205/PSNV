import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/dashed_border.dart';

/// Gợi ý: bấm ghim cạnh tên cụm để đưa cụm lên đầu.
class PinHint extends StatelessWidget {
  const PinHint({super.key});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      margin: const EdgeInsets.symmetric(vertical: AppDimens.sm),
      child: DashedBorder(
        child: Row(
          children: [
            const Icon(Icons.push_pin, size: 11, color: AppColors.primary),
            const SizedBox(width: AppDimens.xs),
            Expanded(
              child: Text(
                LocaleKeys.home_pin_hint.tr(),
                style: AppTextStyles.caption.copyWith(color: swms.text3),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
