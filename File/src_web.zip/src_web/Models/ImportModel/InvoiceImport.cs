﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class InvoiceImport
    {
        /// <summary>
        /// InvoiceNo
        /// </summary>
        public string? InvoiceNo { get; set; }
        /// <summary>
        /// LotNo
        /// </summary>
        public string? LotNo { get; set; }
        /// <summary>
        /// InvoiceDate
        /// </summary>
        public string? InvoiceDate { get; set; }
        /// <summary>
        /// VendorCode
        /// </summary>
        public string? VendorCode { get; set; }

        public List<InvoiceDetailImport>? Details { get; set; }

    }
}
