# Mục 2c — Yêu cầu back hàng sang FA, hai cấp duyệt (BACKEND)

16 file + 1 script SQL. **Đây là nửa backend**; màn Web cho 2c tôi gửi ở gói kế
tiếp. Chạy script + build API là test được bằng Swagger ngay.

⚠ **`Perms.cs` (API) trong gói này thay thế bản ở `swms_return_roles.zip`** —
nó gồm cả lá `pda_receiving.return_receive` của gói đó cộng 4 lá mới.

## 1. Mô hình — chốt lại cho đúng

Hôm qua tôi nói "chỉ thị back phải là phiếu riêng có dòng kế hoạch". Sau câu trả
lời của anh về việc FA load serial để kiểm, mô hình đã chốt khác:

- Yêu cầu back **có dòng model + SL** (FA xin "100 con model X"), vì không ai
  tick 100 serial trên web.
- Nhưng **serial chỉ được GẮP ở bước duyệt cuối (B4)**. Gắp sớm là giữ hàng
  trong khi yêu cầu còn có thể bị huỷ.
- Từ sau B4, **sổ serial là nguồn sự thật duy nhất** cho tiến độ. Dòng chỉ còn
  là bản ghi "FA đã xin bao nhiêu". **Không có cột số lượng nào được lưu** —
  cùng nguyên tắc với SL thực nhận ở mục 2b.
- Một chỉ thị nhận hàng sinh được **nhiều lượt back** (FA xin dần theo năng lực
  xưởng), nên không nhét thành trạng thái của phiếu nhận.

## 2. Bốn bước, mỗi bước một quyền

| Bước | Ai | Quyền | Kết quả |
|---|---|---|---|
| B1 | FA | `rework_refurbish.request_back` | `fa_requested`, chờ `fa_approve` |
| B2 | quản lý FA | `rework_refurbish.approve_fa` | `fa_approved`, chờ `scs_instruct` |
| B3 | SCS WH | `rework_refurbish.process` | `scs_instructed`, chờ `scs_approve` |
| B4 | quản lý SCS | `rework_refurbish.approve_scs` | `scs_approved` + **gắp serial → `at_fa`** |

Hai cột trạng thái, cùng cách `ng_reports` làm: `req_status` để đọc lịch sử,
`current_step` để **lọc hàng đợi "đang chờ tôi"** và để nút chỉ hiện khi
(quyền AND đúng bước).

Hai cấp duyệt là **hai lá quyền khác nhau** (`approve_fa` / `approve_scs`), không
gộp vào `rework_refurbish.approve` đang có — hai bên khác nhau duyệt hai việc
khác nhau. `Approve` cũ vẫn để nguyên, **không xoá** (seeder MERGE theo code,
xoá rồi khai lại tên cũ sẽ làm sống lại quyền của mọi role từng được gán).

## 3. Script `return_back_request_schema.sql`

Chạy SAU `return_receiving_schema.sql` và `return_actual_schema.sql`.

| Tạo gì | Ghi chú |
|---|---|
| `wms.return_back_requests` | header + 4 cặp người/lúc cho 4 bước + huỷ |
| `wms.return_back_request_lines` | model + qty, unique `(request_id, model)` |
| 3 cột trên sổ serial | `back_request_id`, `sent_fa_at`, `returned_at` |
| 5 index | gồm `ix_ris_pickable` cho bước gắp serial |

`returned_at` thêm luôn ở đây dù **mục 3 mới dùng** — một lần dừng DB là một lần
xin phép, không chia hai lần.

⚠ Ba cột mới nằm trên bảng **đã tồn tại**, nên mọi câu nhắc tới chúng đều bọc
`EXEC(N'…')`. Không bọc thì cả batch lỗi 207 và **không câu nào chạy**, kể cả
`CREATE TABLE` ở trên. Đúng cái bẫy đã trả giá ở `return_receiving_schema.sql`.
(Bảng mới thì không cần bọc — SQL Server hoãn phân giải TÊN BẢNG tới lúc chạy,
chỉ TÊN CỘT là bind lúc compile.)

## 4. Bước gắp serial (B4) — chỗ dễ sai nhất

```sql
WITH pick AS (
    SELECT TOP (@qty) s.id
    FROM   wms.return_instruction_serials s WITH (UPDLOCK, READPAST)
    WHERE  s.doc_id = @docId AND s.model = @model
      AND  s.status = N'received' AND s.back_request_id IS NULL
      AND  s.is_deleted = 0
    ORDER BY s.received_at, s.id
)
UPDATE s SET s.back_request_id = @requestId, s.status = N'at_fa',
             s.sent_fa_at = SYSDATETIME(), s.pallet_id = NULL, ...
FROM wms.return_instruction_serials s JOIN pick p ON p.id = s.id;
```

- `ORDER BY received_at` → **FIFO**: con về kho trước đi rework trước.
- `UPDLOCK, READPAST` → hai yêu cầu duyệt cùng lúc **không gắp trùng** một con;
  READPAST bỏ qua dòng đang bị khoá thay vì xếp hàng chờ.
- `pallet_id = NULL` → hàng rời kho SCS, pallet cũ không còn giữ nó. Để nguyên
  con trỏ cũ là **bản đồ kho vẽ hàng ở chỗ không có hàng**.
- Đổi bước và gắp serial nằm trong **CÙNG transaction**, và đổi bước chạy
  TRƯỚC với điều kiện bước cũ nằm trong câu UPDATE. Thua race ⇒ rollback, không
  con serial nào bị gắp. Duyệt xong mà gắp hỏng thì yêu cầu ở trạng thái "đã cho
  back" nhưng không con nào đi — sai nguy hiểm hơn là không duyệt được.

**Gắp thiếu KHÔNG phải lỗi.** Kho có thể vừa bị một yêu cầu khác gắp trước. B4
lấy được bao nhiêu lấy bấy nhiêu, ghi log, và `Short` trên từng dòng nói ra phần
thiếu. Ném lỗi ở đây sẽ làm người dùng bấm lại rồi nhận `WrongStep` — không hiểu
gì.

## 5. Kiểm ở tầng service

| Kiểm | Vì sao ở service chứ không để DB chặn |
|---|---|
| model có thật trong chỉ thị | xin model lạ thì B4 gắp 0 con và không ai hiểu vì sao |
| SL xin ≤ SL kho còn gắp được | để FA biết NGAY lúc soạn, không đi qua 2 cấp duyệt rồi mới biết kho thiếu |
| độ dài model / ghi chú | để nguyên cho DB thì ném lỗi truncation thô giữa transaction, không dịch được |
| model trùng trong một yêu cầu | unique index là lưới cuối; chặn ở đây mới nói được "gộp vào một dòng" |
| trần 200 dòng | một request hỏng không kéo theo vài nghìn INSERT trong một transaction |

## 6. Endpoint

| Method | Đường dẫn | Quyền |
|---|---|---|
| GET | `/api/return-back-requests?docId=&status=&step=&keyword=` | `view` |
| GET | `/api/return-back-requests/{id}` | `view` |
| GET | `/api/return-back-requests/available/{docId}` | `view` |
| POST | `/api/return-back-requests` | `request_back` |
| PUT | `/api/return-back-requests/{id}` | `request_back` ‖ `process` |
| POST | `/api/return-back-requests/{id}/approve-fa` | `approve_fa` |
| POST | `/api/return-back-requests/{id}/instruct` | `process` |
| POST | `/api/return-back-requests/{id}/approve-scs` | `approve_scs` |
| POST | `/api/return-back-requests/{id}/cancel` | `request_back` ‖ `approve_fa` ‖ `approve_scs` |

`PUT` nhận cả hai quyền vì SCS WH ở B3 phải **sửa được số** — xác nhận mà không
sửa được thì gặp số sai họ chỉ còn cách bắt FA làm lại từ đầu. Service vẫn chặn
theo BƯỚC nên quyền rộng không cho ai vượt bước.

`Cancel` nhận cả ba quyền: ai đang giữ bước cũng phải dừng được, không phải chờ
bên kia. Nhưng **đã duyệt xong B4 thì không huỷ được** — lúc đó hàng ở FA rồi,
huỷ là mất dấu lô hàng.

## 7. Thêm `RequireAnyPermission<T1,T2,T3>`

Trước chỉ có bản 2 quyền. **Không stack hai `RequirePermission` để thay thế**:
ASP.NET **AND** các `AuthorizeAttribute` lại với nhau, ra ngược ý. Bản 3 quyền
sinh policy nối `'|'` giống bản 2 quyền, và `PermissionConvention` đã split `'|'`
khi validate lúc khởi động nên không phải sửa gì ở tầng xử lý.

## 8. i18n

13 khoá `Return.Back.Err.*` thêm vào **cả 4** resx của API. Đã kiểm:
- 4 culture có **tập khoá giống nhau** (733 khoá mỗi file)
- **số placeholder `{n}` khớp nhau** giữa 4 culture
- **mọi hằng trong `BackMsg` đều có khoá resx** (13/13)
- mỗi call site `_localizer[BackMsg.X, …]` truyền **đúng số tham số** mà câu dịch cần

## 9. Áp dụng

1. Ghi đè 16 file (Perms.cs của API **thay** bản trong `swms_return_roles.zip`).
2. Chạy `return_back_request_schema.sql`.
3. Build API. Seeder tự thêm 4 quyền mới vào `master.permissions`.
4. Vào màn Roles tick quyền: FA → `request_back`; trưởng nhóm FA →
   `approve_fa`; SCS WH → `process` (đã có); trưởng nhóm SCS → `approve_scs`.
   Theo quyết định của anh, hai cấp duyệt là **role gắn thêm cho người đang
   làm**, không cần account mới.
5. Test bằng Swagger theo đúng thứ tự B1 → B2 → B3 → B4, rồi soi
   `wms.return_instruction_serials` xem `status`, `back_request_id`,
   `sent_fa_at`, `pallet_id`.

## 10. Chưa có trong gói này

- **Màn Web cho 2c** — gói kế tiếp.
- **Mail báo khi duyệt** — chưa khai sự kiện mail nào cho 2c. Nếu cần báo FA khi
  quản lý SCS cho back thì nói, tôi thêm tab thứ 3 vào bánh răng cấu hình mail.
- **Mục 2d / 3** — làm sau khi 2c chạy được.
