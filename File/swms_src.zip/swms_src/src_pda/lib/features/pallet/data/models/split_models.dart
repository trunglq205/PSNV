﻿import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';

part 'split_models.g.dart';

/// Loại lot đích khi tách — khớp enum `SplitTargetType` phía API.
class SplitTargetType {
  static const existing = 'Existing';
  static const newLot = 'New';
}

/// Body gửi lên `POST /api/pallets/split`.
@JsonSerializable()
class SplitPalletRequestModel {
  final String sourceLotNo;

  /// Danh sách thùng — dùng cho pallet detail_level serial / box_line.
  final List<int> boxIds;

  final String targetType;

  /// Chỉ dùng khi targetType = Existing.
  final String? targetLotNo;

  /// Số thùng cần tách — dùng cho pallet detail_level = box_count, loại chỉ
  /// biết có bao nhiêu thùng chứ không có thùng nào để quét.
  ///
  /// Server quyết định đọc [boxIds] hay [boxQty] theo detail_level của pallet
  /// gốc, không theo client gửi gì — nên gửi thừa cũng không sai lệch.
  final int? boxQty;

  /// Người dùng đã thấy cảnh báo "pallet đích khác model" và đồng ý tách.
  ///
  /// false (mặc định) -> server chặn bằng Split.ModelMismatch như trước.
  /// Chỉ đặt true sau khi người dùng bấm đồng ý trên dialog cảnh báo.
  final bool confirmModelMismatch;

  const SplitPalletRequestModel({
    required this.sourceLotNo,
    required this.boxIds,
    required this.targetType,
    this.targetLotNo,
    this.boxQty,
    this.confirmModelMismatch = false,
  });

  factory SplitPalletRequestModel.fromJson(Map<String, dynamic> json) =>
      _$SplitPalletRequestModelFromJson(json);

  Map<String, dynamic> toJson() => _$SplitPalletRequestModelToJson(this);
}

/// Khớp `SplitPalletResponse` của API.
@JsonSerializable()
class SplitPalletResponseModel {
  final String sourceLotNo;
  final int sourceRemainingBoxes;
  final String targetLotNo;
  final bool targetIsNew;
  final int movedBoxes;

  const SplitPalletResponseModel({
    required this.sourceLotNo,
    required this.sourceRemainingBoxes,
    required this.targetLotNo,
    required this.targetIsNew,
    required this.movedBoxes,
  });

  factory SplitPalletResponseModel.fromJson(Map<String, dynamic> json) =>
      _$SplitPalletResponseModelFromJson(json);

  Map<String, dynamic> toJson() => _$SplitPalletResponseModelToJson(this);

  SplitResult toEntity() => SplitResult(
        sourceLotNo: sourceLotNo,
        sourceRemainingBoxes: sourceRemainingBoxes,
        targetLotNo: targetLotNo,
        targetIsNew: targetIsNew,
        movedBoxes: movedBoxes,
      );
}
