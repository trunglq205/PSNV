using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Primitives;
using Swms.FinishGoods.Web.Features.Inventory.App.Components;
using Swms.FinishGoods.Web.Features.Inventory.Business;
using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Shared.App.Components;
using Swms.FinishGoods.Web.Shared.App.Layout;
using Swms.FinishGoods.Web.Shared.App.Model;
using Swms.FinishGoods.Web.Shared.App.Toast;
using System.Globalization;

namespace Swms.FinishGoods.Web.Features.Inventory.App.Pages;

// Lõi màn Tồn kho: DI, search/filter, query, load, state đặc thù ↔ URL.
//
// ĐÃ GỠ dependency IPalletBusiness: chi tiết lot và category options giờ đi qua
// IInventoryBusiness. Màn này không còn tham chiếu feature Lots nào.
public partial class Inventories
{
    [Inject] private IInventoryBusiness Business { get; set; } = default!;
    [Inject] private ToastService Toast { get; set; } = default!;

    private bool _printPalletOpen;

    private bool _hdCompareOpen;

    /// <summary>Dialog quản lý xe Stocky — mở từ nút Stocky trên đầu màn.</summary>
    private bool _stockyOpen;

    // ── State đặc thù (ngoài AdvancedFilter) — đồng bộ URL ──
    private string _activeArea = "";     // card khu vực

    // 3 ô lọc chọn nhiều trên toolbar (MultiCheckFilter). URL: cat=310,410 · insp=pass,ng · sap=0,3
    private readonly List<string> _categories = new();
    private readonly List<string> _inspections = new();
    private readonly List<string> _saps = new();
    private DateTime? _prodFrom, _prodTo;
    private DateTime? _createdFrom, _createdTo;

    private List<CategoryOptionDto> _categoryOptions = new();

    private const string IsoDate = "yyyy-MM-dd";
    private static string? Iso(DateTime? d) => d?.ToString(IsoDate, CultureInfo.InvariantCulture);
    private static DateTime? FromIso(string s)
        => DateTime.TryParseExact(s, IsoDate, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;

    private static string DateChip(DateTime? f, DateTime? t)
        => f?.Date == t?.Date ? $"{f:dd/MM/yyyy}"
         : $"{f?.ToString("dd/MM/yyyy") ?? "…"} – {t?.ToString("dd/MM/yyyy") ?? "…"}";

    // ── Thống kê khu vực ──
    private Dictionary<string, AppInventoryArea> _areaStats = new();
    private bool _areasLoading;
    private AppInventoryArea AreaStat(string key)
        => _areaStats.TryGetValue(key, out var s) ? s : new AppInventoryArea { Key = key };

    private const string IcScopeLot = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='3' y='7' width='18' height='13' rx='1'/><path d='M3 11h18M9 11V7M15 11V7'/></svg>";
    private const string IcScopeModel = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M20 7L12 3 4 7l8 4 8-4z'/><path d='M4 7v10l8 4 8-4V7'/><path d='M12 11v10'/></svg>";
    private const string IcScopeBox = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='3' y='3' width='18' height='18' rx='2'/><path d='M3 9h18M9 21V9'/></svg>";

    // ── (1) Search scopes: Lot No · Model · Box/Serial ──
    protected override IReadOnlyList<SearchScope> SearchScopes => new List<SearchScope>
    {
        new("lotNo", L["Lots.Search.LotNo.Title"],    L["Lots.Search.LotNo.Hint"],    IcScopeLot,   L["Lots.Search.LotNo.Short"]),
        new("model", L["Lots.Search.Model.Title"],    L["Lots.Search.Model.Hint"],    IcScopeModel, L["Lots.Search.Model.Short"]),
        new("box",   L["Inventory.Search.Box.Title"], L["Inventory.Search.Box.Hint"], IcScopeBox,   L["Inventory.Search.Box.Short"]),
    };

    private void OnDateFilterChanged() { CommitState(); }
    private void ClearProduction() { _prodFrom = _prodTo = null; CommitState(); }
    private void ClearCreated() { _createdFrom = _createdTo = null; CommitState(); }

    // ── (2) Filter nâng cao: Lot type · Detail level · Ưu tiên · Total qty · Sắp xếp ──
    // SAP đã chuyển ra toolbar (chọn nhiều) cùng Category / Inspection.
    protected override IReadOnlyList<ListFilterField> FilterFields => new List<ListFilterField>
    {
        new()
        {
            Key = "lotType", Label = L["Lots.Filter.LotType"], Kind = ListFilterKind.Select,
            Options = new[]
            {
                new ListFilterOption("",            L["Lots.Filter.LotType.All"]),
                new ListFilterOption("pallet",      L["Lots.LotType.Pallet"]),
                // Giá trị DB là "stocky" (PalletType.ToDbValue()), KHÔNG phải
                // "stocky_cart". Cột lot_type được so bằng dấu = nên gửi sai
                // là bộ lọc này luôn trả 0 dòng.
                new ListFilterOption("stocky", L["Lots.LotType.StockyCart"]),
            },
        },
        new()
        {
            Key = "level", Label = L["Inventory.Filter.Level"], Kind = ListFilterKind.Select,
            Options = new[]
            {
                new ListFilterOption("",          L["Lots.Level.All"]),
                new ListFilterOption("serial",    L["Lots.Level.Serial"]),
                new ListFilterOption("box_line",  L["Lots.Level.BoxLine"]),
                new ListFilterOption("box_count", L["Lots.Level.BoxCount"]),
            },
        },
        new()
        {
            Key = "urgent", Label = L["Inventory.Filter.Urgent"], Kind = ListFilterKind.Select,
            Options = new[]
            {
                new ListFilterOption("",  L["Inventory.Filter.Urgent.All"]),
                new ListFilterOption("1", L["Inventory.Filter.Urgent.Only"]),
                new ListFilterOption("0", L["Inventory.Filter.Urgent.None"]),
            },
        },
        new()
        {
            Key = "qty", Label = L["Inventory.Filter.Qty"], Kind = ListFilterKind.Select,
            Options = new[]
            {
                new ListFilterOption("",        L["Inventory.Filter.Qty.All"]),
                new ListFilterOption("lt50",    L["Inventory.Filter.Qty.Lt50"]),
                new ListFilterOption("50_200",  L["Inventory.Filter.Qty.50_200"]),
                new ListFilterOption("200_500", L["Inventory.Filter.Qty.200_500"]),
                new ListFilterOption("gt500",   L["Inventory.Filter.Qty.Gt500"]),
            },
        },
        new()
        {
            Key = "sort", Label = L["Inventory.Filter.Sort"], Kind = ListFilterKind.Select,
            Options = new[]
            {
                new ListFilterOption("",         L["Inventory.Sort.Default"]),
                new ListFilterOption("pd_asc",   L["Inventory.Sort.PdAsc"]),
                new ListFilterOption("pd_desc",  L["Inventory.Sort.PdDesc"]),
                new ListFilterOption("qty_desc", L["Inventory.Sort.QtyDesc"]),
            },
        },
    };

    // ── (3) Map state → query ──
    protected override InventoryQuery BuildQuery()
    {
        var lotType = Applied("lotType").Value;
        var level = Applied("level").Value;
        var urgent = Applied("urgent").Value;
        var sort = Applied("sort").Value;
        var (qMin, qMax) = InventoryDisplay.QtyRange(Applied("qty").Value);

        return new InventoryQuery
        {
            Area = string.IsNullOrEmpty(_activeArea) ? null : _activeArea,
            Categories = JoinCsv(_categories),
            Inspections = JoinCsv(_inspections),
            SapStatuses = JoinCsv(_saps),

            LotNo = TryGetTerm("lotNo", out var lot) ? lot : null,
            Model = TryGetTerm("model", out var mdl) ? mdl : null,
            BoxOrSerial = TryGetTerm("box", out var box) ? box : null,

            LotType = string.IsNullOrEmpty(lotType) ? null : lotType,
            DetailLevel = string.IsNullOrEmpty(level) ? null : level,
            IsUrgent = urgent switch { "1" => true, "0" => false, _ => (bool?)null },
            QtyMin = qMin,
            QtyMax = qMax,
            Sort = string.IsNullOrEmpty(sort) ? null : sort,
            ProductionFrom = ParseDate(Iso(_prodFrom) ?? ""),
            ProductionTo = ParseDateEndOfDay(Iso(_prodTo) ?? ""),
            CreatedFrom = ParseDate(Iso(_createdFrom) ?? ""),
            CreatedTo = ParseDateEndOfDay(Iso(_createdTo) ?? ""),
            Page = Page,
            Size = PageSize,
        };
    }

    // ── (4) Tải trang + đồng thời làm mới card khu vực ──
    protected override async Task<LoadOutcome<AppInventoryItem>> LoadPageAsync(InventoryQuery query, CancellationToken ct)
    {
        _ = LoadAreasAsync(query);   // fire-and-forget, không chặn bảng

        var result = await Business.GetPagedAsync(query);
        if (!result.IsSuccess || result.Value == null)
            return LoadOutcome<AppInventoryItem>.Fail(result.ErrorCode, result.ErrorMessage ?? L["Inventory.Load.ListFailed"]);

        IReadOnlyList<AppInventoryItem> items = result.Value.Items.Select(InventoryItemDto.ToViewModel).ToList();
        return LoadOutcome<AppInventoryItem>.Ok(items, result.Value.TotalCount);
    }

    // Card khu vực đếm theo cùng bộ lọc nhưng bỏ Area (để 5 card luôn so sánh được với nhau).
    private async Task LoadAreasAsync(InventoryQuery query)
    {
        _areasLoading = true;
        StateHasChanged();
        try
        {
            var q = BuildQuery();
            q.Area = null; q.Page = 1; q.Size = 1;
            var r = await Business.GetAreasAsync(q);
            if (r.IsSuccess && r.Value != null)
                _areaStats = r.Value.Select(InventoryAreaDto.ToViewModel).ToDictionary(a => a.Key, a => a);
        }
        finally { _areasLoading = false; StateHasChanged(); }
    }

    protected override void ShowError(string message) => Toast.Error(message);

    protected override async Task OnFirstLoadAsync()
    {
        var cats = await Business.GetCategoryOptionsAsync();
        if (cats.IsSuccess && cats.Value != null) _categoryOptions = cats.Value;
        await ReloadAsync();
    }

    // ── State đặc thù <-> URL (area / cat / insp) ──
    protected override void ReadExtraFromUrl(Dictionary<string, StringValues> qs)
    {
        _activeArea = GetQ(qs, "area", "");
        if (InventoryDisplay.Area(_activeArea) is null) _activeArea = "";
        // Link cũ 1 giá trị (cat=310, sap=2) vẫn đọc được — 1 giá trị là CSV 1 phần tử.
        Replace(_categories, SplitCsv(GetQ(qs, "cat", "")));
        Replace(_inspections, SplitCsv(GetQ(qs, "insp", "")));
        Replace(_saps, SplitCsv(GetQ(qs, "sap", "")));
        _prodFrom = FromIso(GetQ(qs, "pdFrom", ""));
        _prodTo = FromIso(GetQ(qs, "pdTo", ""));
        _createdFrom = FromIso(GetQ(qs, "crFrom", ""));
        _createdTo = FromIso(GetQ(qs, "crTo", ""));
    }

    protected override void WriteExtraToUrl(Dictionary<string, object?> query)
    {
        query["area"] = _activeArea != "" ? _activeArea : null;
        query["cat"] = JoinCsv(_categories);
        query["insp"] = JoinCsv(_inspections);
        query["sap"] = JoinCsv(_saps);
        query["pdFrom"] = Iso(_prodFrom);
        query["pdTo"] = Iso(_prodTo);
        query["crFrom"] = Iso(_createdFrom);
        query["crTo"] = Iso(_createdTo);
    }

    private IReadOnlyList<StatCardItem> AreaCards => InventoryDisplay.Areas
    .Select(a =>
    {
        var stat = AreaStat(a.Key);
        return new StatCardItem
        {
            Key = a.Key,
            Label = L[a.LabelKey],
            Color = a.Color,
            Title = L[a.HintKey],
            Value = stat.PalletCount.ToString("N0"),
            Unit = L["Inventory.Unit.Pallet"],
            Sub = L["Inventory.Area.Stats", stat.BoxCount.ToString("N0"),
                    stat.TotalQty.ToString("N0"), stat.ModelCount],
        };
    })
    .ToList();

    protected override bool HasActiveFilters
       => base.HasActiveFilters || _activeArea != ""
          || _categories.Count > 0 || _inspections.Count > 0 || _saps.Count > 0
          || _prodFrom is not null || _prodTo is not null
          || _createdFrom is not null || _createdTo is not null;

    protected override void ClearExtraFilters()
    {
        _activeArea = "";
        _categories.Clear(); _inspections.Clear(); _saps.Clear();
        _prodFrom = _prodTo = _createdFrom = _createdTo = null;
    }

    // Click card: click lại card đang chọn = bỏ lọc.
    private void SetArea(string key)
    {
        _activeArea = _activeArea == key ? "" : key;
        CommitState();
    }

    // ── 3 ô lọc chọn nhiều ──

    private static readonly string[] InspectionValues =
        ["pass", "ng", "pending_result", "under_inspection", "not_inspected", "inspection_exempt"];

    private static readonly int[] SapValues = [0, 1, 2, 3, 4];

    private IReadOnlyList<MultiCheckFilter.Option> CategoryOptions => _categoryOptions
        .Select(c => new MultiCheckFilter.Option(c.Code.ToString(CultureInfo.InvariantCulture), $"{c.Code} · {c.Name}"))
        .ToList();

    // Ô màu = đúng màu pill trong bảng, nhìn danh sách là nhận ra trạng thái.
    private IReadOnlyList<MultiCheckFilter.Option> InspectionOptions => InspectionValues
        .Select(v => new MultiCheckFilter.Option(v, L[InventoryDisplay.InspectionLabelKey(v)], InventoryDisplay.InspectionStyle(v)))
        .ToList();

    private IReadOnlyList<MultiCheckFilter.Option> SapOptions => SapValues
        .Select(v => new MultiCheckFilter.Option(v.ToString(CultureInfo.InvariantCulture), L[InventoryDisplay.SapLabelKey(v)], InventoryDisplay.SapStyle(v)))
        .ToList();

    private void SetCategories(IReadOnlyCollection<string> v) { Replace(_categories, v); CommitState(); }
    private void SetInspections(IReadOnlyCollection<string> v) { Replace(_inspections, v); CommitState(); }
    private void SetSaps(IReadOnlyCollection<string> v) { Replace(_saps, v); CommitState(); }

    /// <summary>Chữ trên chip: tên các mục đã chọn.</summary>
    private static string ChipOf(IReadOnlyList<MultiCheckFilter.Option> options, IEnumerable<string> selected)
        => string.Join(", ", selected.Select(v =>
            options.FirstOrDefault(o => string.Equals(o.Value, v, StringComparison.OrdinalIgnoreCase))?.Text ?? v));

    private static void Replace(List<string> target, IEnumerable<string> values)
    {
        target.Clear();
        target.AddRange(values.Where(v => !string.IsNullOrWhiteSpace(v)).Distinct(StringComparer.OrdinalIgnoreCase));
    }

    private static IEnumerable<string> SplitCsv(string raw)
        => raw.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

    private static string? JoinCsv(IReadOnlyCollection<string> values) => values.Count == 0 ? null : string.Join(",", values);

    // Cùng ngưỡng bucket với InventoryAgingDialog (lt30 · d30_60 · d60_90 · gt90) để màu
    // tuổi tồn trong bảng luôn khớp màu trong dialog Aging / FIFO.
    private static string AgeColor(int ageDays) => ageDays switch
    {
        < 30 => InventoryDisplay.AgingBucketColor("lt30"),
        < 60 => InventoryDisplay.AgingBucketColor("d30_60"),
        < 90 => InventoryDisplay.AgingBucketColor("d60_90"),
        _ => InventoryDisplay.AgingBucketColor("gt90"),
    };

    // Màu locator pill lấy đúng màu của card khu vực tương ứng — đồng bộ với 5 card đầu trang.
    private static string AreaColor(string? areaKey)
        => InventoryDisplay.Area(areaKey)?.Color ?? "var(--text-3)";

    private string ModelText(AppInventoryItem p)
        => !string.IsNullOrWhiteSpace(p.Model) ? p.Model!
         : p.Models.Count > 0 ? string.Join(", ", p.Models) : "—";
}
