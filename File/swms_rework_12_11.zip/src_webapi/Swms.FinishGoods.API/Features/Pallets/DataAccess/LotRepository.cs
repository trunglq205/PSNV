using Dapper;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Boxes;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Data;
using System.Linq;
using System.Text.Json;

namespace Swms.FinishGoods.API.Features.Pallets.DataAccess
{
    /// <summary>
    /// Truy cập wms.pallets / boxes / box_lines cho nghiệp vụ SWMS.
    /// Phần chỉ luồng Foss dùng (bổ sung thùng, OQC, chọn ứng viên job) nằm ở
    /// Features/Foss/PalletSync/DataAccess/PalletFossRepository.
    /// </summary>
    public class LotRepository : ILotRepository
    {
        private readonly IDbConnectionFactory _factory;
        private readonly IStockEventWriter _events;

        public LotRepository(IDbConnectionFactory factory, IStockEventWriter events)
        {
            _factory = factory;
            _events = events;
        }

        // ── SQL tái dùng ──────────────────────────────────────────────
        private const string LotColumns = """
            l.id                AS Id,
            l.pallet_id         AS LotNo,
            c.code              AS CategoryCode,
            c.name              AS CategoryName,
            l.lot_type          AS LotType,
            l.stocky_code       AS StockyCode,
            l.si_no             AS SiNo,
            l.locator_id        AS LocatorId,
            loc.locator_code    AS LocatorCode,
            wa.area_code        AS AreaCode,
            l.detail_level      AS DetailLevel,
            l.box_count         AS BoxCount,
            l.standard_packing  AS StandardPacking,
            -- Pallet serial / box_line KHÔNG ghi cột pallets.model (model nằm ở
            -- box_lines) nên đọc thẳng l.model làm danh sách pallet trống cột
            -- Model với hai loại đó. Bộ LỌC theo model ở dưới đã tra cả hai
            -- nguồn từ trước, chỉ cột hiển thị là còn một chiều.
            COALESCE(
                (SELECT STRING_AGG(z.model, ', ')
                 FROM (SELECT DISTINCT bl.model
                       FROM wms.boxes bx
                       JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                       WHERE bx.lot_id = l.id AND bx.is_deleted = 0) z),
                l.model)        AS Model,
            l.inspection_status AS InspectionStatus,
            l.is_urgent         AS IsUrgent,
            l.production_date   AS ProductionDate,
            l.sap_status        AS SapStatus,
            l.sap_pushed_at     AS SapPushedAt,
            l.is_deleted        AS IsDeleted,
            l.created_at        AS CreatedAt,
            l.created_by        AS CreatedBy,
            l.updated_at        AS UpdatedAt,
            l.updated_by        AS UpdatedBy
            """;

        private const string LotFrom = """
            FROM wms.pallets l
            JOIN master.categories c ON c.code = l.category_id
            LEFT JOIN master.locators loc ON loc.id = l.locator_id
            LEFT JOIN master.warehouse_areas wa ON wa.id = loc.area_id
            """;

        private const string BoxColumns = """
            b.id              AS Id,
            b.lot_id          AS LotId,
            b.box_no          AS BoxNo,
            b.psnv_po         AS PsnvPo,
            b.customer_po     AS CustomerPo,
            b.line            AS Line,
            b.model           AS Model,
            b.oqc_status      AS OQCStatus,
            b.lot_name        AS LotName,
            COALESCE(p.length, m.length) AS Length,
            COALESCE(p.width,  m.width)  AS Width,
            COALESCE(p.height, m.height) AS Height,
            COALESCE(b.weight, p.weight) AS Weight,
            b.production_date AS ProductionDate,
            b.raw_payload     AS RawPayload,
            b.created_at      AS CreatedAt,
            b.created_by      AS CreatedBy
            """;

        // carton_qty giữ nguyên tên cột trong DB, alias sang CartonCount cho khớp entity.
        private const string LineColumns = """
            bl.id              AS Id,
            bl.box_id          AS BoxId,
            bl.model           AS Model,
            bl.qty             AS Qty,
            bl.serial_no       AS SerialNo,
            bl.production_date AS ProductionDate,
            bl.carton_qty      AS CartonCount,
            bl.created_at      AS CreatedAt,
            bl.created_by      AS CreatedBy
            """;

        private const string LotFilter = """
            WHERE l.is_deleted = 0
              AND (@LotNo            IS NULL OR l.pallet_id LIKE '%' + @LotNo + '%')
              AND (@CategoryCode     IS NULL OR c.code = @CategoryCode)
              AND (@LotType          IS NULL OR l.lot_type = @LotType)
              AND (@StockyCode       IS NULL OR l.stocky_code = @StockyCode)
              AND (@DetailLevel      IS NULL OR l.detail_level = @DetailLevel)
              AND (@InspectionStatus IS NULL OR l.inspection_status = @InspectionStatus)
              AND (@IsUrgent         IS NULL OR l.is_urgent = @IsUrgent)
              AND (@LocatorId        IS NULL OR l.locator_id = @LocatorId)
              AND (@ProductionFrom   IS NULL OR l.production_date >= @ProductionFrom)
              AND (@ProductionTo     IS NULL OR l.production_date <= @ProductionTo)
              AND (@CreatedFrom      IS NULL OR l.created_at >= @CreatedFrom)
              AND (@CreatedTo        IS NULL OR l.created_at < DATEADD(day, 1, @CreatedTo))
              AND (@SapStatus        IS NULL OR l.sap_status = @SapStatus)
              AND (@SapPushed        IS NULL
                   OR (@SapPushed = 1 AND l.sap_pushed_at IS NOT NULL)
                   OR (@SapPushed = 0 AND l.sap_pushed_at IS NULL))
              AND (@SapPushedFrom    IS NULL OR l.sap_pushed_at >= @SapPushedFrom)
              AND (@SapPushedTo      IS NULL OR l.sap_pushed_at < DATEADD(day, 1, @SapPushedTo))
              AND (@Model IS NULL
                   OR l.model LIKE '%' + @Model + '%'
                   OR EXISTS (SELECT 1 FROM wms.boxes b
                              JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                              WHERE b.lot_id = l.id AND b.is_deleted = 0
                                AND bl.model LIKE '%' + @Model + '%'))
            """;

        // ── Read ──────────────────────────────────────────────────────
        public Task<Pallet?> GetByIdAsync(long id)
            => GetOneAsync("l.id = @key", id);

        public Task<Pallet?> GetByLotNoAsync(string lotNo)
            => GetOneAsync("l.pallet_id = @key OR l.stocky_code = @key", lotNo);

        /// <summary>Client tự sinh pallet_id nên server chỉ cần kiểm tra trùng.</summary>
        public async Task<bool> ExistsLotNoAsync(string lotNo)
        {
            using var conn = _factory.Create();
            const string sql = """
                SELECT TOP 1 1 FROM wms.pallets
                WHERE (pallet_id = @lotNo OR stocky_code = @lotNo) AND is_deleted = 0;
                """;
            return await conn.ExecuteScalarAsync<int?>(sql, new { lotNo }) is not null;
        }

        public async Task<int> GetMaxSequenceAsync(string prefix)
        {
            using var conn = _factory.Create();
            // Đếm cả bản ghi is_deleted = 1: số đã cấp không tái sử dụng, tránh
            // đụng unique index ux_lots_pallet_id_active nếu lot cũ được khôi phục.
            // Chỉ xét pallet_id đúng 12 số và khớp prefix để loại dữ liệu rác.
            const string sql = """
        SELECT ISNULL(MAX(CAST(RIGHT(pallet_id, 3) AS int)), 0)
        FROM wms.pallets
        WHERE pallet_id LIKE @prefix + '%'
          AND LEN(pallet_id) = 12
          AND pallet_id NOT LIKE '%[^0-9]%';
        """;
            return await conn.ExecuteScalarAsync<int>(sql, new { prefix });
        }

        private async Task<Pallet?> GetOneAsync(string predicate, object key)
        {
            using var conn = _factory.Create();
            var sql = $"""
                SELECT {LotColumns}
                {LotFrom}
                WHERE {predicate} AND l.is_deleted = 0;

                SELECT {BoxColumns}
                FROM wms.boxes b
                JOIN wms.pallets l ON l.id = b.lot_id
                LEFT JOIN master.models m ON m.code = b.model
                LEFT JOIN wms.part_cards p On p.payload = b.raw_payload
                WHERE {predicate} AND l.is_deleted = 0 AND b.is_deleted = 0
                ORDER BY b.box_no;

                SELECT {LineColumns}
                FROM wms.box_lines bl
                JOIN wms.boxes b ON b.id = bl.box_id AND b.is_deleted = 0
                JOIN wms.pallets l ON l.id = b.lot_id
                WHERE {predicate} AND l.is_deleted = 0 AND bl.is_deleted = 0
                ORDER BY bl.id;
                """;

            using var multi = await conn.QueryMultipleAsync(sql, new { key });

            var lot = await multi.ReadFirstOrDefaultAsync<Pallet>();
            if (lot is null) return null;

            var boxes = (await multi.ReadAsync<Box>()).ToList();
            var lines = (await multi.ReadAsync<BoxLine>()).ToList();

            var lineMap = lines.GroupBy(x => x.BoxId).ToDictionary(g => g.Key, g => g.ToList());
            foreach (var b in boxes)
                b.Lines = lineMap.TryGetValue(b.Id, out var ls) ? ls : [];

            lot.Boxes = boxes;
            return lot;
        }

        public async Task<PagedResult<Pallet>> GetPagedAsync(PalletQuery query)
        {
            using var conn = _factory.Create();
            var sql = $"""
                SELECT {LotColumns}, CASE
                    WHEN l.detail_level = 'box_count'
                        THEN COALESCE(l.box_count, 0) * COALESCE(l.standard_packing, 0)
                    ELSE COALESCE((
                        SELECT SUM(bl.qty)
                        FROM wms.boxes lb
                        JOIN wms.box_lines bl ON bl.box_id = lb.id AND bl.is_deleted = 0
                        WHERE lb.lot_id = l.id
                    ), 0)
                END AS TotalQtySql
                {LotFrom}
                {LotFilter}
                ORDER BY l.created_at DESC, l.id DESC
                OFFSET (@Page - 1) * @Size ROWS FETCH NEXT @Size ROWS ONLY;

                SELECT COUNT(*)
                {LotFrom}
                {LotFilter};
                """;

            // Phải truyền đủ mọi @param xuất hiện trong LotFilter, thiếu 1 cái
            // là SQL Server báo "Must declare the scalar variable".
            using var multi = await conn.QueryMultipleAsync(sql, new
            {
                query.Page,
                query.Size,
                query.LotNo,
                query.CategoryCode,
                query.Model,
                query.LotType,
                query.StockyCode,
                query.DetailLevel,
                query.InspectionStatus,
                query.IsUrgent,
                query.LocatorId,
                query.ProductionFrom,
                query.ProductionTo,
                query.CreatedFrom,
                query.CreatedTo,
                query.SapStatus,
                query.SapPushed,
                query.SapPushedFrom,
                query.SapPushedTo
            });

            var items = (await multi.ReadAsync<Pallet>()).ToList();
            var total = await multi.ReadFirstAsync<int>();

            // Danh sách trang: không nạp box/line (tránh N+1). Chi tiết lấy qua GetByIdAsync.
            return new PagedResult<Pallet>(items, total, query.Page, query.Size);
        }

        // ── Write ─────────────────────────────────────────────────────

        public async Task<long> AddAsync(
            Pallet lot,
            string origin = PalletOrigins.Manual,
            string source = StockEventSources.Web,
            bool rejectDuplicatePayload = false,
            IntegrationSyncContext? sync = null,
            Func<IDbConnection, IDbTransaction, long, Task>? onInserted = null)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                // Chốt chặn cuối cho trùng raw_payload: check lại TRONG transaction với
                // UPDLOCK + HOLDLOCK. Khoá range giữ tới Commit nên request thứ 2 quét
                // cùng thẻ phải chờ, rồi thấy box vừa insert -> ném lỗi, không lọt qua.
                if (rejectDuplicatePayload)
                {
                    var payloads = lot.Boxes
                        .Select(b => b.RawPayload)
                        .Where(p => !string.IsNullOrWhiteSpace(p))
                        .Select(p => p!)
                        .Distinct(StringComparer.Ordinal)
                        .ToList();

                    if (payloads.Count > 0)
                    {
                        var existing = await QueryActivePalletsByPayloadAsync(
                            conn, tx, payloads, lockRange: true);
                        if (existing.Count > 0)
                            throw new DuplicateBoxPayloadException(existing);
                    }
                }

                const string insertLot = """
                    INSERT INTO wms.pallets
                        (pallet_id, category_id, lot_type, stocky_code, locator_id, detail_level, box_count, even_lot,
                         model, standard_packing, inspection_status, is_urgent, production_date,
                         is_deleted, created_at, created_by)
                    VALUES
                        (@LotNo, @CategoryCode, @LotType, @StockyCode, @LocatorId, @DetailLevel, @BoxCount, @EvenLot,
                         @Model, @StandardPacking, @InspectionStatus, @IsUrgent, @ProductionDate,
                         0, SYSDATETIME(), @CreatedBy);
                    SELECT CAST(SCOPE_IDENTITY() AS bigint);
                    """;

                // Truyền param tường minh — entity có property denormalize (CategoryCode)
                // không tồn tại dưới dạng cột.
                var lotId = await conn.ExecuteScalarAsync<long>(insertLot, new
                {
                    lot.LotNo,
                    lot.CategoryCode,
                    lot.LotType,
                    lot.StockyCode,
                    lot.LocatorId,
                    lot.DetailLevel,
                    lot.BoxCount,
                    lot.EvenLot,
                    lot.Model,
                    lot.StandardPacking,
                    lot.InspectionStatus,
                    lot.IsUrgent,
                    lot.ProductionDate,
                    lot.CreatedBy
                }, tx);

                foreach (var box in lot.Boxes)
                    await PalletSqlShared.InsertBoxWithLinesAsync(conn, tx, lotId, box);

                // ── Khoá thẻ in đã lên pallet ──
                // Chỉ luồng tạo tay: Foss có raw_payload = SERIAL_OUTER, tra part_cards
                // sẽ khớp nhầm (cùng lý do với ApplyPartCardsAsync).
                // Payload KHÔNG unique (in lại sinh bản ghi mới) -> khoá MỌI bản ghi
                // cùng payload, vì tất cả đều là một thùng vật lý.
                // Nằm trong transaction: tạo pallet lỗi thì thẻ không bị khoá oan.
                if (origin == PalletOrigins.Manual)
                {
                    var cardPayloads = lot.Boxes
                        .Select(b => b.RawPayload)
                        .Where(p => !string.IsNullOrWhiteSpace(p))
                        .Select(p => p!)
                        .Distinct(StringComparer.Ordinal)
                        .ToList();

                    if (cardPayloads.Count > 0)
                    {
                        const string lockCardsSql = """
                            UPDATE wms.part_cards
                            SET is_locked = 1,
                                locked_at = SYSDATETIME(),
                                locked_by = @user
                            WHERE payload IN @payloads
                              AND is_deleted = 0
                              AND ISNULL(is_locked, 0) = 0;
                            """;
                        await conn.ExecuteAsync(
                            lockCardsSql,
                            new { payloads = cardPayloads, user = lot.CreatedBy },
                            tx);
                    }
                }

                // ── Dữ liệu kèm theo của feature gọi vào ──
                // Đặt ở đây, sau khi box đã có id và trước khi ghi event: hook ném
                // lỗi thì rollback mất cả pallet, và lịch sử cũng không kịp ghi một
                // pallet không tồn tại. Xem chú thích onInserted ở ILotRepository.
                if (onInserted is not null)
                    await onInserted(conn, tx, lotId);

                // ── Event: PALLET_CREATED + BOX_CREATED ──
                // Ghi TRƯỚC tx.Commit() để rollback là mất luôn, không để lịch sử nói dối.
                await _events.WriteAsync(conn, tx, new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = lotId,
                    EventCode = StockEventCodes.PalletCreated,
                    Actor = lot.CreatedBy,
                    Source = sync?.Source ?? source,
                    ToLocatorId = lot.LocatorId,
                    BoxCountAfter = lot.BoxCount ?? lot.Boxes.Count,
                    Payload = sync?.ToPayload(new { origin }) ?? $"{{\"origin\":\"{origin}\"}}",
                });

                await _events.WriteManyAsync(conn, tx, lot.Boxes.Select(box => new StockEvent
                {
                    SubjectType = StockEventSubjects.Box,
                    PalletId = lotId,
                    BoxId = box.Id,
                    EventCode = StockEventCodes.BoxCreated,
                    EventAt = box.CreatedAt == default ? null : box.CreatedAt,
                    Actor = box.CreatedBy ?? sync?.Actor ?? lot.CreatedBy,
                    Source = sync?.Source ?? source,
                }));

                tx.Commit();
                lot.Id = lotId;
                return lotId;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>
        /// raw_payload nào trong danh sách đã nằm trên box active của pallet active.
        /// Trả về payload -> pallet_id đang giữ nó. Rỗng = chưa dùng.
        /// </summary>
        public async Task<IReadOnlyDictionary<string, string>> GetActivePalletsByBoxPayloadAsync(
            IReadOnlyList<string> payloads)
        {
            if (payloads.Count == 0) return new Dictionary<string, string>();

            using var conn = _factory.Create();
            return await QueryActivePalletsByPayloadAsync(conn, null, payloads, lockRange: false);
        }

        private static async Task<Dictionary<string, string>> QueryActivePalletsByPayloadAsync(
            IDbConnection conn,
            IDbTransaction? tx,
            IReadOnlyList<string> payloads,
            bool lockRange)
        {
            // Split chỉ UPDATE lot_id nên box chuyển pallet không bị tính trùng.
            // SoftDelete pallet cũng set boxes.is_deleted = 1 -> thẻ được dùng lại.
            // Join thêm pallets.is_deleted = 0 cho chắc và để lấy pallet_id báo lỗi.
            var hint = lockRange ? "WITH (UPDLOCK, HOLDLOCK)" : "";
            var sql = $"""
                SELECT b.raw_payload    AS Payload,
                       MIN(l.pallet_id) AS PalletId
                FROM wms.boxes b {hint}
                JOIN wms.pallets l ON l.id = b.lot_id AND l.is_deleted = 0
                WHERE b.is_deleted = 0 AND b.raw_payload IN @payloads
                GROUP BY b.raw_payload;
                """;

            var rows = await conn.QueryAsync<(string Payload, string PalletId)>(
                sql, new { payloads = payloads.ToList() }, tx);

            // Collation DB có thể không phân biệt hoa/thường -> gộp an toàn, không ném khi trùng key.
            var result = new Dictionary<string, string>(StringComparer.Ordinal);
            foreach (var r in rows) result.TryAdd(r.Payload, r.PalletId);
            return result;
        }

        public async Task<IReadOnlyDictionary<string, PartCardInfo>> GetPartCardsByPayloadAsync(
            IReadOnlyList<string> payloads)
        {
            if (payloads.Count == 0) return new Dictionary<string, PartCardInfo>();

            using var conn = _factory.Create();

            // ROW_NUMBER chứ không GROUP BY + MIN: payload KHÔNG unique (in lại thẻ
            // sinh bản ghi mới). Cần lấy TRỌN VẸN một dòng — dùng MIN(created_at) kèm
            // LotName, Status_OQC thì ba giá trị có thể đến từ ba bản ghi khác nhau.
            //
            // Lấy thẻ ĐẦU TIÊN: đó là lúc thùng được đóng, lần in sau chỉ là in lại.
            const string sql = """
                SELECT x.payload    AS Payload,
                       x.created_at AS CreatedAt,
                       x.LotName    AS LotName,
                       x.Status_OQC AS OqcStatus
                FROM (
                    SELECT pc.payload, pc.created_at, pc.LotName, pc.Status_OQC,
                           ROW_NUMBER() OVER (
                               PARTITION BY pc.payload
                               ORDER BY pc.created_at, pc.id) AS rn
                    FROM wms.part_cards pc
                    WHERE pc.is_deleted = 0 AND pc.payload IN @payloads
                ) x
                WHERE x.rn = 1;
                """;

            var rows = await conn.QueryAsync<PartCardInfo>(
                sql, new { payloads = payloads.ToList() });

            return rows.ToDictionary(r => r.Payload, r => r, StringComparer.Ordinal);
        }

        public async Task SoftDeleteAsync(
            long id, string updatedBy, string source = StockEventSources.Web)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                // Số box trước khi xoá — để timeline biết pallet mất bao nhiêu thùng.
                const string countSql = """
                    SELECT COUNT(*) FROM wms.boxes WHERE lot_id = @id AND is_deleted = 0;
                    """;
                var boxCountBefore = await conn.ExecuteScalarAsync<int>(countSql, new { id }, tx);

                // Cascade soft delete: lines → boxes → lot
                const string sql = """
                    UPDATE bl
                    SET bl.is_deleted = 1, bl.updated_at = SYSDATETIME(), bl.updated_by = @updatedBy
                    FROM wms.box_lines bl
                    JOIN wms.boxes b ON b.id = bl.box_id
                    WHERE b.lot_id = @id AND bl.is_deleted = 0;

                    UPDATE wms.boxes
                    SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @updatedBy
                    WHERE lot_id = @id AND is_deleted = 0;

                    UPDATE wms.pallets
                    SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @updatedBy
                    WHERE id = @id AND is_deleted = 0;
                    """;
                await conn.ExecuteAsync(sql, new { id, updatedBy }, tx);

                // ── Mở khoá thẻ in ──
                // Xoá pallet thì thẻ được dùng lại (xem QueryActivePalletsByPayloadAsync)
                // -> phải mở khoá, không thì thẻ kẹt vĩnh viễn.
                // NOT EXISTS: không mở nếu payload đó vẫn còn nằm trên box active của
                // pallet active khác (dữ liệu cũ trước khi có chốt chống trùng).
                const string unlockCardsSql = """
                    UPDATE pc
                    SET pc.is_locked = 0, pc.locked_at = NULL, pc.locked_by = NULL
                    FROM wms.part_cards pc
                    WHERE pc.is_locked = 1
                      AND pc.payload IN (
                          SELECT b.raw_payload FROM wms.boxes b
                          WHERE b.lot_id = @id AND b.raw_payload IS NOT NULL)
                      AND NOT EXISTS (
                          SELECT 1
                          FROM wms.boxes b2
                          JOIN wms.pallets l2 ON l2.id = b2.lot_id AND l2.is_deleted = 0
                          WHERE b2.raw_payload = pc.payload AND b2.is_deleted = 0);
                    """;
                await conn.ExecuteAsync(unlockCardsSql, new { id }, tx);


                await _events.WriteAsync(conn, tx, new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = id,
                    EventCode = StockEventCodes.PalletDeleted,
                    Actor = updatedBy,
                    Source = source,
                    BoxCountBefore = boxCountBefore,
                    BoxCountAfter = 0,
                });

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        // ── Xoá thùng ────────────────────────────────────────────────

        public async Task<BoxDeleteResult?> SoftDeleteBoxesAsync(
            long lotId, IReadOnlyList<long> boxIds, string user, StockEventContext ctx)
        {
            var ids = boxIds.Distinct().ToList();
            if (ids.Count == 0) return null;

            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                // 1) Khoá pallet: xoá thùng / bổ sung Foss / tách cùng lúc thì xếp hàng.
                const string lockSql = """
                    SELECT pallet_id FROM wms.pallets WITH (UPDLOCK, ROWLOCK)
                    WHERE id = @lotId AND is_deleted = 0 AND detail_level <> 'box_count';
                    """;
                var lotNo = await conn.ExecuteScalarAsync<string?>(lockSql, new { lotId }, tx);
                if (lotNo is null) { tx.Rollback(); return null; }

                // 2) Kiểm lại trong khoá: thùng phải còn thuộc pallet, và không được xoá hết.
                const string pickSql = """
                    SELECT b.id                   AS Id,
                           b.box_no               AS BoxNo,
                           COUNT(bl.id)           AS Lines,
                           ISNULL(SUM(bl.qty), 0) AS Qty
                    FROM wms.boxes b WITH (UPDLOCK)
                    LEFT JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                    WHERE b.lot_id = @lotId AND b.is_deleted = 0 AND b.id IN @ids
                    GROUP BY b.id, b.box_no;

                    SELECT COUNT(*) FROM wms.boxes WHERE lot_id = @lotId AND is_deleted = 0;
                    """;
                List<(long Id, string BoxNo, int Lines, int Qty)> picked;
                int before;
                using (var multi = await conn.QueryMultipleAsync(pickSql, new { lotId, ids }, tx))
                {
                    picked = (await multi.ReadAsync<(long Id, string BoxNo, int Lines, int Qty)>()).ToList();
                    before = await multi.ReadFirstAsync<int>();
                }

                if (picked.Count != ids.Count || picked.Count >= before) { tx.Rollback(); return null; }

                // 3) Mở khoá thẻ in TRƯỚC khi xoá thùng (cùng quy tắc SoftDeleteAsync):
                //    chỉ mở khi payload không còn nằm trên box active nào khác.
                const string unlockCardsSql = """
                    UPDATE pc
                    SET pc.is_locked = 0, pc.locked_at = NULL, pc.locked_by = NULL
                    FROM wms.part_cards pc
                    WHERE pc.is_locked = 1
                      AND pc.payload IN (
                          SELECT b.raw_payload FROM wms.boxes b
                          WHERE b.id IN @ids AND b.raw_payload IS NOT NULL)
                      AND NOT EXISTS (
                          SELECT 1
                          FROM wms.boxes b2
                          JOIN wms.pallets l2 ON l2.id = b2.lot_id AND l2.is_deleted = 0
                          WHERE b2.raw_payload = pc.payload AND b2.is_deleted = 0
                            AND b2.id NOT IN @ids);
                    """;
                await conn.ExecuteAsync(unlockCardsSql, new { ids }, tx);

                // 4) Xoá mềm line -> thùng, tính lại pallet.
                //    production_date = MIN của thùng còn lại (FIFO): xoá đúng thùng cũ nhất thì ngày SX lùi theo.
                const string deleteSql = """
                    UPDATE bl
                    SET bl.is_deleted = 1, bl.updated_at = SYSDATETIME(), bl.updated_by = @user
                    FROM wms.box_lines bl
                    WHERE bl.box_id IN @ids AND bl.is_deleted = 0;

                    UPDATE wms.boxes
                    SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                    WHERE lot_id = @lotId AND id IN @ids AND is_deleted = 0;

                    UPDATE l
                    SET box_count       = x.cnt,
                        production_date = COALESCE(x.min_date, l.production_date),
                        updated_at      = SYSDATETIME(),
                        updated_by      = @user
                    FROM wms.pallets l
                    CROSS APPLY (SELECT COUNT(*) AS cnt, MIN(b.production_date) AS min_date
                                 FROM wms.boxes b
                                 WHERE b.lot_id = l.id AND b.is_deleted = 0) x
                    WHERE l.id = @lotId;
                    """;
                await conn.ExecuteAsync(deleteSql, new { lotId, ids, user }, tx);

                var after = before - picked.Count;
                var lines = picked.Sum(x => x.Lines);
                var qty = picked.Sum(x => x.Qty);

                // 5) 1 event cấp pallet. Mã thùng ghi vào Note để đọc được ngay trên timeline.
                await _events.WriteAsync(conn, tx, new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = lotId,
                    EventCode = ctx.EventCode,
                    Actor = ctx.Actor ?? user,
                    Source = ctx.Source,
                    BoxCountBefore = before,
                    BoxCountAfter = after,
                    Note = string.Join(", ", picked.Select(x => x.BoxNo)),
                    Payload = ctx.Payload,
                });

                tx.Commit();
                return new BoxDeleteResult(lotNo, picked.Count, lines, qty, before, after);
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        // ── Vị trí tạm (PDA) ─────────────────────────────────────────

        // Model: gộp từ box_lines; lot mức box_count không có line nên fallback l.model.
        private const string LocationInfoSql = """
            SELECT  l.id                       AS Id,
                    l.pallet_id                AS LotNo,
                    c.code                     AS CategoryCode,
                    c.name                     AS CategoryName,
                    l.lot_type                 AS LotType,
                    l.stocky_code              AS StockyCode,
                    l.si_no                    AS SiNo,
                    l.detail_level             AS DetailLevel,
                    l.box_count                AS BoxCount,
                    l.standard_packing         AS StandardPacking,
                    l.model                    AS Model,
                    l.inspection_status        AS InspectionStatus,
                    l.is_urgent                AS IsUrgent,
                    l.production_date          AS ProductionDate,
                    l.sap_status               AS SapStatus,
                    l.sap_pushed_at            AS SapPushedAt,
                    l.is_deleted               AS IsDeleted,
                    l.disposition              AS Disposition,
                    -- IsReturnBack: pallet NÀY ĐANG GIỮ serial của một phiếu back hàng.
                    --
                    -- Vì sao không chỉ đọc `disposition`: cột đó là DẤU, do luồng
                    -- nhận hàng back đóng vào lúc đăng ký serial. Dữ liệu tạo
                    -- trước khi có dấu, hoặc pallet được sửa tay dưới DB, thì cột
                    -- rỗng — và khi đó BuildAllowedActions không mở nút "Out kho",
                    -- WH đọc ra thành "chức năng chưa có". Sự thật về việc pallet
                    -- có phải hàng back hay không nằm ở SỔ SERIAL, nên lấy ở đây.
                    --
                    -- Đây KHÔNG phải cổng duyệt: cổng thật là IReturnBackMoveGate
                    -- (phải scs_approved mới out kho được). Cột này chỉ quyết định
                    -- có HIỆN nút hay không.
                    CAST(CASE WHEN EXISTS (
                             SELECT 1
                             FROM   wms.return_instruction_serials ris
                             WHERE  ris.pallet_id = l.id
                               AND  ris.is_deleted = 0
                         ) THEN 1 ELSE 0 END AS bit) AS IsReturnBack,
                    l.locator_id               AS LocatorId,
                    loc.locator_code           AS LocatorCode,
                    a.area_code                AS AreaCode,
                    a.area_name                AS AreaName,
                    a.map_type                 AS MapType,
                    COALESCE(m.models, l.model) AS Models,
                    q.total_qty                AS TotalQtySql
            FROM wms.pallets l
            LEFT JOIN master.categories c
                   ON c.code = l.category_id
            LEFT JOIN master.locators loc
                   ON loc.id = l.locator_id AND loc.is_deleted = 0
            LEFT JOIN master.warehouse_areas a
                   ON a.id = loc.area_id AND a.is_deleted = 0
            OUTER APPLY (
                SELECT STRING_AGG(x.model, ', ') AS models
                FROM (
                    SELECT DISTINCT bl.model
                    FROM wms.boxes lb
                    INNER JOIN wms.box_lines bl ON bl.box_id = lb.id AND bl.is_deleted = 0
                    -- lb.is_deleted: thiếu thì thùng đã xoá mềm vẫn góp model,
                    -- lệch với GetModelQtysByLotIdAsync (câu đó đã lọc).
                    WHERE lb.lot_id = l.id AND lb.is_deleted = 0
                ) x
            ) m
            -- Tổng qty gộp từ box_lines; lot box_count không có line -> NULL,
            -- service fallback sang BoxCount * StandardPacking.
            OUTER APPLY (
                SELECT SUM(bl2.qty) AS total_qty
                FROM wms.boxes b2
                INNER JOIN wms.box_lines bl2 ON bl2.box_id = b2.id AND bl2.is_deleted = 0
                WHERE b2.lot_id = l.id AND b2.is_deleted = 0
            ) q
            """;

        public async Task<PalletLocationInfo?> GetLocationInfoByLotNoAsync(string lotNo)
        {
            using var conn = _factory.Create();
            var sql = LocationInfoSql + " WHERE (l.pallet_id = @lotNo OR l.stocky_code = @lotNo) AND l.is_deleted = 0;";
            return await conn.QueryFirstOrDefaultAsync<PalletLocationInfo>(sql, new { lotNo });
        }

        public async Task<PalletLocationInfo?> GetLocationInfoByIdAsync(long id)
        {
            using var conn = _factory.Create();
            var sql = LocationInfoSql + " WHERE l.id = @id AND l.is_deleted = 0;";
            return await conn.QueryFirstOrDefaultAsync<PalletLocationInfo>(sql, new { id });
        }

        // GetHistoryByLotNoAsync đã XOÁ — xem ILotRepository.

        public async Task<LocatorBrief?> GetLocatorByCodeAsync(string locatorCode)
        {
            using var conn = _factory.Create();
            const string sql = """
                SELECT  loc.id           AS Id,
                        loc.locator_code AS LocatorCode,
                        loc.area_id      AS AreaId,
                        a.area_code      AS AreaCode,
                        a.area_name      AS AreaName,
                        a.map_type       AS MapType,
                        (SELECT COUNT(1) FROM wms.pallets x
                          WHERE x.locator_id = loc.id AND x.is_deleted = 0) AS CurrentLotCount
                FROM master.locators loc
                LEFT JOIN master.warehouse_areas a ON a.id = loc.area_id AND a.is_deleted = 0
                WHERE loc.locator_code = @locatorCode AND loc.is_deleted = 0;
                """;
            return await conn.QueryFirstOrDefaultAsync<LocatorBrief>(sql, new { locatorCode });
        }

        public async Task ChangeLocatorAsync(
            long lotId, long? toLocatorId, string? user, StockEventContext ctx,
            string? inspectionStatus = null,
            Func<System.Data.IDbConnection, System.Data.IDbTransaction, long, Task>? onMoved = null)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                // 1) Trạng thái trước khi đổi (để ghi event).
                const string beforeSql = """
                    SELECT l.pallet_id AS LotNo, l.locator_id AS LocatorId
                    FROM wms.pallets l
                    WHERE l.id = @lotId;
                    """;
                var before = await conn.QueryFirstOrDefaultAsync(beforeSql, new { lotId }, tx);
                if (before is null) { tx.Rollback(); return; }

                long? fromLocatorId = (long?)before.LocatorId;

                // 2) Cập nhật vị trí (kèm trạng thái kiểm nếu Service yêu cầu).
                //
                // Nối chuỗi chứ không dùng `inspection_status = COALESCE(@x,
                // inspection_status)`: cách COALESCE vẫn ghi lại chính giá trị
                // cũ nên updated_at/trigger coi như có sửa trạng thái, và đọc
                // câu SQL không còn thấy được là lần gọi này có đổi hay không.
                var updSql = $"""
                    UPDATE wms.pallets
                    SET locator_id = @toLocatorId,
                        {(inspectionStatus is null ? "" : "inspection_status = @inspectionStatus,")}
                        updated_at = SYSDATETIME(),
                        updated_by = @user
                    WHERE id = @lotId;
                    """;
                await conn.ExecuteAsync(
                    updSql, new { lotId, toLocatorId, user, inspectionStatus }, tx);

                // 2b) Hook của feature khác — xem ILotRepository.ChangeLocatorAsync.
                //     Ném ở đây thì catch bên dưới rollback cả việc đổi vị trí.
                if (onMoved is not null)
                    await onMoved(conn, tx, lotId);

                // 3) Ghi event.
                //
                // Trước đây chỗ này ghi 2 dòng vào locator_status_history
                // (released ở vị trí cũ + assigned ở vị trí mới) và KHÔNG phân biệt
                // được gán tạm / lưu kho / vanning. Giờ chỉ 1 dòng, mang cả from lẫn
                // to, và event code do Service quyết định qua ResolveMoveEvent.
                await _events.WriteAsync(conn, tx, new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = lotId,
                    EventCode = ctx.EventCode,
                    Actor = ctx.Actor ?? user,
                    Source = ctx.Source,
                    FromLocatorId = fromLocatorId,
                    ToLocatorId = toLocatorId,
                    Note = ctx.Note,
                    Payload = ctx.Payload,
                });

                tx.Commit();
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        // ── Tách pallet ──────────────────────────────────────────────

        public async Task<SplitLotInfo?> GetSplitLotInfoAsync(string lotNo)
        {
            using var conn = _factory.Create();
            const string sql = """
            SELECT TOP 1 id AS Id, pallet_id AS LotNo, category_id AS CategoryId,
                   production_date AS ProductionDate, locator_id AS LocatorId,
                   inspection_status AS InspectionStatus, model AS Model,
                   detail_level AS DetailLevel,
                   ISNULL(box_count, 0) AS BoxCount, is_deleted AS IsDeleted
            FROM wms.pallets
            WHERE pallet_id = @lotNo OR stocky_code = @lotNo;
            """;
            return await conn.QueryFirstOrDefaultAsync<SplitLotInfo>(sql, new { lotNo });
        }

        public async Task<int> CountBoxesInLotAsync(long lotId, IReadOnlyList<long> boxIds)
        {
            if (boxIds.Count == 0) return 0;
            using var conn = _factory.Create();
            const string sql = """
                SELECT COUNT(*)
                FROM wms.boxes
                WHERE lot_id = @lotId AND is_deleted = 0 AND id IN @boxIds;
                """;
            return await conn.ExecuteScalarAsync<int>(sql, new { lotId, boxIds = boxIds.ToList() });
        }

        /// <summary>
        /// Tách pallet THEO SỐ LƯỢNG — dành cho pallet detail_level = 'box_count',
        /// loại chỉ biết có bao nhiêu thùng chứ không có dòng nào trong wms.boxes.
        ///
        /// Vì sao không dùng chung <see cref="ExecuteSplitAsync"/>: hàm kia kết thúc
        /// bằng bước ĐẾM LẠI box_count từ wms.boxes. Pallet box_count không có dòng
        /// box nào, nên chạy bước đó là set cả hai pallet về 0 — mất sạch số liệu.
        /// Ở đây box_count là nguồn sự thật, phải cộng trừ chứ không đếm lại.
        ///
        /// Cũng không ghi event cấp Box: không có box nào để mà ghi.
        /// </summary>
        public async Task<(int moved, int sourceRemaining)> ExecuteSplitByQtyAsync(SplitExecuteParams p)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                var qty = p.BoxQty;

                // 0) box_count gốc TRƯỚC khi tách — đọc thẳng cột, không đếm wms.boxes.
                const string srcBeforeSql = """
                    SELECT ISNULL(box_count, 0) FROM wms.pallets WHERE id = @sourceLotId;
                    """;
                var sourceBefore = await conn.ExecuteScalarAsync<int>(
                    srcBeforeSql, new { sourceLotId = p.SourceLotId }, tx);

                // 1) Lot đích: tạo mới (clone từ lot gốc, box_count = 0) hoặc lot có sẵn.
                long targetLotId;
                if (p.CreateNew)
                {
                    const string insSql = """
                    INSERT INTO wms.pallets
                        (pallet_id, category_id, lot_type, stocky_code, locator_id, detail_level,
                         box_count, even_lot, model, standard_packing, inspection_status,
                         is_urgent, production_date, sap_status, sap_pushed_at, disposition,
                         is_deleted, created_at, created_by)
                    OUTPUT INSERTED.id
                    SELECT
                         @NewLotNo, s.category_id, s.lot_type, NULL, s.locator_id, s.detail_level,
                         0, s.even_lot, s.model, s.standard_packing, s.inspection_status,
                         s.is_urgent, s.production_date, s.sap_status, s.sap_pushed_at,
                         -- disposition: pallet con TÁCH RA VẪN LÀ HÀNG RW/RB.
                         -- Thiếu cột này thì tem pallet con in ra KHÔNG có badge
                         -- RW/RB, và bản đồ kho cũng không nhận ra nó là hàng
                         -- tái gia công. Đúng lúc cần nhất: SCS WH tách pallet
                         -- để giao một phần cho FA (mục 2c), nên pallet con là
                         -- thứ đi ra khỏi kho.
                         s.disposition,
                         0, SYSDATETIME(), @User
                    FROM wms.pallets s
                    WHERE s.id = @SourceLotId AND s.is_deleted = 0;
                    """;
                    targetLotId = await conn.ExecuteScalarAsync<long?>(insSql, new
                    {
                        p.NewLotNo,
                        p.SourceLotId,
                        p.User,
                    }, tx) ?? throw new InvalidOperationException(
                        $"Không tìm thấy pallet gốc id={p.SourceLotId} để clone.");
                }
                else
                {
                    targetLotId = p.TargetLotId!.Value;
                }

                const string tgtBeforeSql = """
                    SELECT ISNULL(box_count, 0) FROM wms.pallets WHERE id = @targetLotId;
                    """;
                var targetBefore = await conn.ExecuteScalarAsync<int>(
                    tgtBeforeSql, new { targetLotId }, tx);

                // 2) Trừ ở lot gốc. Điều kiện box_count >= @qty nằm NGAY TRONG câu
                //    UPDATE: hai người cùng tách một pallet thì người sau không trừ
                //    được quá số còn lại, và ta biết điều đó qua số dòng bị ảnh hưởng.
                //    Kiểm trước rồi mới trừ thì giữa hai bước vẫn lọt được.
                const string subSql = """
                    UPDATE wms.pallets
                    SET    box_count = ISNULL(box_count, 0) - @qty,
                           updated_at = SYSDATETIME(), updated_by = @user
                    WHERE  id = @sourceLotId AND ISNULL(box_count, 0) >= @qty;
                    """;
                var hit = await conn.ExecuteAsync(subSql, new
                {
                    qty,
                    sourceLotId = p.SourceLotId,
                    user = p.User,
                }, tx);

                if (hit == 0)
                    throw new InvalidOperationException(
                        $"Pallet id={p.SourceLotId} không còn đủ {qty} thùng để tách " +
                        $"(có thể người khác vừa tách cùng lúc).");

                // 3) Cộng vào lot đích.
                const string addSql = """
                    UPDATE wms.pallets
                    SET    box_count = ISNULL(box_count, 0) + @qty,
                           updated_at = SYSDATETIME(), updated_by = @user
                    WHERE  id = @targetLotId;
                    """;
                await conn.ExecuteAsync(addSql, new { qty, targetLotId, user = p.User }, tx);

                var remaining = sourceBefore - qty;

                // 4) Event — giống ExecuteSplitAsync, trừ phần event cấp Box.
                var events = new List<StockEvent>();

                if (p.CreateNew)
                {
                    events.Add(new StockEvent
                    {
                        SubjectType = StockEventSubjects.Pallet,
                        PalletId = targetLotId,
                        EventCode = StockEventCodes.PalletCreated,
                        Actor = p.User,
                        RelatedPalletId = p.SourceLotId,
                        BoxCountAfter = targetBefore + qty,
                        Payload = $"{{\"origin\":\"{PalletOrigins.Split}\"}}",
                    });
                }

                // Note/Payload: chỉ khác null khi Service cho qua một cảnh báo đã
                // được người dùng xác nhận (vd. tách khác model). Gắn lên CẢ HAI
                // chiều để đọc lịch sử pallet nào cũng thấy.
                events.Add(new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = p.SourceLotId,
                    EventCode = StockEventCodes.PalletSplitOut,
                    Actor = p.User,
                    RelatedPalletId = targetLotId,
                    BoxCountBefore = sourceBefore,
                    BoxCountAfter = remaining,
                    Note = p.EventNote,
                    Payload = p.EventPayload,
                });

                events.Add(new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = targetLotId,
                    EventCode = StockEventCodes.PalletSplitIn,
                    Actor = p.User,
                    RelatedPalletId = p.SourceLotId,
                    BoxCountBefore = targetBefore,
                    BoxCountAfter = targetBefore + qty,
                    Note = p.EventNote,
                    Payload = p.EventPayload,
                });

                await _events.WriteManyAsync(conn, tx, events);

                tx.Commit();
                return (qty, remaining);
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>
        /// Chuyển sổ serial hàng return theo những THÙNG vừa tách sang pallet con.
        ///
        /// BẮT BUỘC, không phải cho đẹp: <c>wms.return_instruction_serials</c>
        /// giữ <c>pallet_id</c> riêng của nó, và tách pallet mà không đụng tới
        /// nó thì sổ vẫn trỏ pallet GỐC. Lúc SCS WH quét pallet con để giao cho
        /// FA (mục 2c) sẽ ra 0 serial và không giao được gì — mà tách pallet
        /// đúng là việc phải làm khi FA chỉ xin một phần.
        ///
        /// Nối bằng <c>box_no</c> và CHẶN TRONG pallet nguồn: box_no chỉ chắc
        /// chắn duy nhất trong phạm vi một pallet, nối trần sẽ kéo nhầm serial
        /// của pallet khác trùng mã thùng.
        ///
        /// Serial có <c>box_no IS NULL</c> (hàng về rời, không còn thùng để
        /// quét) Ở LẠI pallet gốc: không có gì chỉ ra nó thuộc thùng nào trong
        /// số vừa chuyển, và đoán ở đây là đẩy nhầm hàng ra khỏi kho.
        ///
        /// Nuốt 207/208 như mọi chỗ khác chạm bảng của mục return: DB chưa chạy
        /// return_receiving_schema.sql thì bảng chưa có, và việc tách pallet
        /// thường KHÔNG được phép hỏng vì một bảng của feature khác.
        /// </summary>
        /// <remarks>
        /// Chỉ <see cref="ExecuteSplitAsync"/> gọi. <c>ExecuteSplitByQtyAsync</c>
        /// không gọi vì nó chỉ cộng trừ <c>box_count</c> chứ không chuyển dòng
        /// thùng nào — không có thùng nào để lần ra serial.
        /// </remarks>
        private static async Task MoveReturnSerialsAsync(
            IDbConnection conn, IDbTransaction tx,
            long sourceLotId, long targetLotId,
            IReadOnlyList<long> boxIds, string? user)
        {
            if (boxIds.Count == 0) return;

            try
            {
                await conn.ExecuteAsync("""
                    UPDATE s
                    SET    s.pallet_id  = @targetLotId,
                           s.updated_at = SYSDATETIME(),
                           s.updated_by = @user
                    FROM   wms.return_instruction_serials s
                    JOIN   wms.boxes b
                           ON b.box_no = s.box_no
                          AND b.id IN @boxIds
                    WHERE  s.pallet_id = @sourceLotId
                      AND  s.is_deleted = 0;
                    """,
                    new
                    {
                        targetLotId,
                        sourceLotId,
                        boxIds = boxIds.ToList(),
                        user,
                    }, tx);
            }
            catch (Microsoft.Data.SqlClient.SqlException ex)
                when (ex.Number is 207 or 208)
            {
                // Bảng/cột của mục return chưa có — pallet này chắc chắn không
                // phải hàng return, nên không có gì để chuyển.
            }
        }

        public async Task<(int moved, int sourceRemaining)> ExecuteSplitAsync(SplitExecuteParams p)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                long targetLotId;

                // 0) Số box của lot gốc TRƯỚC khi chuyển — cho box_count_before.
                const string sourceCountSql = """
                    SELECT COUNT(*) FROM wms.boxes
                    WHERE lot_id = @sourceLotId AND is_deleted = 0;
                    """;
                var sourceBefore = await conn.ExecuteScalarAsync<int>(
                    sourceCountSql, new { sourceLotId = p.SourceLotId }, tx);

                // 1) Lot đích: tạo mới hoặc dùng lot có sẵn.
                if (p.CreateNew)
                {
                    const string insSql = """
                    INSERT INTO wms.pallets
                        (pallet_id, category_id, lot_type, stocky_code, locator_id, detail_level,
                         box_count, even_lot, model, standard_packing, inspection_status,
                         is_urgent, production_date, sap_status, sap_pushed_at, disposition,
                         is_deleted, created_at, created_by)
                    OUTPUT INSERTED.id
                    SELECT
                         @NewLotNo, s.category_id, s.lot_type, NULL, s.locator_id, s.detail_level,
                         0, s.even_lot, s.model, s.standard_packing, s.inspection_status,
                         s.is_urgent, s.production_date, s.sap_status, s.sap_pushed_at,
                         -- disposition: pallet con TÁCH RA VẪN LÀ HÀNG RW/RB.
                         -- Thiếu cột này thì tem pallet con in ra KHÔNG có badge
                         -- RW/RB, và bản đồ kho cũng không nhận ra nó là hàng
                         -- tái gia công. Đúng lúc cần nhất: SCS WH tách pallet
                         -- để giao một phần cho FA (mục 2c), nên pallet con là
                         -- thứ đi ra khỏi kho.
                         s.disposition,
                         0, SYSDATETIME(), @User
                    FROM wms.pallets s
                    WHERE s.id = @SourceLotId AND s.is_deleted = 0;
                    """;
                    targetLotId = await conn.ExecuteScalarAsync<long?>(insSql, new
                    {
                        p.NewLotNo,
                        p.SourceLotId,
                        p.User,
                    }, tx) ?? throw new InvalidOperationException(
                    $"Không tìm thấy pallet gốc id={p.SourceLotId} để clone.");
                }
                else
                {
                    targetLotId = p.TargetLotId!.Value;
                }

                // Số box lot đích trước khi nhận.
                const string targetCountSql = """
                    SELECT COUNT(*) FROM wms.boxes
                    WHERE lot_id = @targetLotId AND is_deleted = 0;
                    """;
                var targetBefore = await conn.ExecuteScalarAsync<int>(
                    targetCountSql, new { targetLotId }, tx);

                // 2) Chuyển box sang lot đích.
                const string moveSql = """
                    UPDATE wms.boxes
                    SET lot_id = @targetLotId,
                        updated_at = SYSDATETIME(),
                        updated_by = @user
                    WHERE lot_id = @sourceLotId AND is_deleted = 0 AND id IN @boxIds;
                    """;
                var moved = await conn.ExecuteAsync(moveSql, new
                {
                    targetLotId,
                    sourceLotId = p.SourceLotId,
                    boxIds = p.BoxIds.ToList(),
                    user = p.User,
                }, tx);

                await MoveReturnSerialsAsync(
                    conn, tx, p.SourceLotId, targetLotId, p.BoxIds.ToList(), p.User);

                // 3) Đếm lại box_count 2 lot.
                const string recountSql = """
                    UPDATE l
                    SET box_count = (
                        SELECT COUNT(*) FROM wms.boxes b
                        WHERE b.lot_id = l.id AND b.is_deleted = 0),
                        updated_at = SYSDATETIME(), updated_by = @user
                    FROM wms.pallets l
                    WHERE l.id IN (@sourceLotId, @targetLotId);
                    """;
                await conn.ExecuteAsync(recountSql, new
                {
                    sourceLotId = p.SourceLotId,
                    targetLotId,
                    user = p.User,
                }, tx);

                // 4) Số box còn lại của lot gốc.
                const string remainSql = """
                    SELECT COUNT(*) FROM wms.boxes
                    WHERE lot_id = @sourceLotId AND is_deleted = 0;
                    """;
                var remaining = await conn.ExecuteScalarAsync<int>(remainSql,
                    new { sourceLotId = p.SourceLotId }, tx);

                // 5) Event.
                //
                // Hai dòng trỏ chéo nhau qua RelatedPalletId để CẢ HAI pallet đều tự
                // kể được câu chuyện của nó mà không phải query ngược.
                var events = new List<StockEvent>();

                if (p.CreateNew)
                {
                    events.Add(new StockEvent
                    {
                        SubjectType = StockEventSubjects.Pallet,
                        PalletId = targetLotId,
                        EventCode = StockEventCodes.PalletCreated,
                        Actor = p.User,
                        RelatedPalletId = p.SourceLotId,
                        BoxCountAfter = targetBefore + moved,
                        Payload = $"{{\"origin\":\"{PalletOrigins.Split}\"}}",
                    });
                }

                // Note/Payload: xem chú thích ở ExecuteSplitByQtyAsync.
                events.Add(new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = p.SourceLotId,
                    EventCode = StockEventCodes.PalletSplitOut,
                    Actor = p.User,
                    RelatedPalletId = targetLotId,
                    BoxCountBefore = sourceBefore,
                    BoxCountAfter = remaining,
                    Note = p.EventNote,
                    Payload = p.EventPayload,
                });

                events.Add(new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = targetLotId,
                    EventCode = StockEventCodes.PalletSplitIn,
                    Actor = p.User,
                    RelatedPalletId = p.SourceLotId,
                    BoxCountBefore = targetBefore,
                    BoxCountAfter = targetBefore + moved,
                    Note = p.EventNote,
                    Payload = p.EventPayload,
                });

                // Box: mỗi thùng đổi pallet là một event của CHÍNH nó — đây là dòng
                // duy nhất cho phép dựng lại membership khi đọc lịch sử box.
                events.AddRange(p.BoxIds.Select(boxId => new StockEvent
                {
                    SubjectType = StockEventSubjects.Box,
                    PalletId = targetLotId,          // pallet ĐÍCH
                    BoxId = boxId,
                    EventCode = StockEventCodes.BoxMovedPallet,
                    Actor = p.User,
                    RelatedPalletId = p.SourceLotId, // pallet NGUỒN
                }));

                await _events.WriteManyAsync(conn, tx, events);

                tx.Commit();
                return (moved, remaining);
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>
        /// Tổng số lượng + số thùng theo model của lot (gộp box_lines).
        /// Rỗng với lot box_count (không có line để gộp).
        /// </summary>
        public async Task<IReadOnlyList<PalletModelQty>> GetModelQtysByLotIdAsync(long lotId)
        {
            using var conn = _factory.Create();
            const string sql = """
                SELECT  bl.model             AS Model,
                        SUM(bl.qty)          AS TotalQty,
                        COUNT(DISTINCT b.id) AS BoxCount
                FROM wms.boxes b
                INNER JOIN wms.box_lines bl
                        ON bl.box_id = b.id AND bl.is_deleted = 0
                WHERE b.lot_id = @lotId AND b.is_deleted = 0
                GROUP BY bl.model
                ORDER BY bl.model;
                """;
            return (await conn.QueryAsync<PalletModelQty>(sql, new { lotId })).ToList();
        }

        /// <summary>
        /// Gợi ý 1 vị trí storage để lưu pallet (FR-STR-02).
        /// Ưu tiên vị trí storage TRỐNG cùng khu đang chứa model của lot (gom cụm cùng model),
        /// nếu không có thì lấy vị trí storage trống bất kỳ (theo locator_code).
        /// "Trống" = chưa pallet nào (is_deleted = 0) trỏ tới. Null nếu hết chỗ.
        /// </summary>
        public async Task<LocatorSuggestion?> SuggestLocatorAsync(long lotId)
        {
            using var conn = _factory.Create();
            const string sql = """
                WITH free_locators AS (
                    SELECT  loc.id, loc.locator_code, loc.area_id,
                            a.area_code, a.area_name
                    FROM master.locators loc
                    JOIN master.warehouse_areas a
                           ON a.id = loc.area_id  AND a.is_deleted = 0 AND a.area_code = 'STORAGE'
                    WHERE loc.is_deleted = 0
                      AND NOT EXISTS (
                          SELECT 1 FROM wms.pallets p
                          WHERE p.locator_id = loc.id AND p.is_deleted = 0)
                ),
                lot_models AS (
                    SELECT DISTINCT bl.model
                    FROM wms.boxes b
                    INNER JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                    WHERE b.lot_id = @lotId AND b.is_deleted = 0
                ),
                same_model_areas AS (
                    SELECT DISTINCT loc.area_id
                    FROM wms.pallets p
                    INNER JOIN master.locators loc ON loc.id = p.locator_id AND loc.is_deleted = 0
                    INNER JOIN wms.boxes b2 ON b2.lot_id = p.id AND b2.is_deleted = 0
                    INNER JOIN wms.box_lines bl2 ON bl2.box_id = b2.id AND bl2.is_deleted = 0
                    WHERE p.is_deleted = 0
                      AND bl2.model IN (SELECT model FROM lot_models)
                )
                SELECT TOP 1
                        f.id           AS LocatorId,
                        f.locator_code AS LocatorCode,
                        f.area_code    AS AreaCode,
                        f.area_name    AS AreaName,
                        CASE WHEN sma.area_id IS NOT NULL THEN 'same_model_area'
                             ELSE 'free_storage' END AS Reason
                FROM free_locators f
                LEFT JOIN same_model_areas sma ON sma.area_id = f.area_id
                ORDER BY
                        CASE WHEN sma.area_id IS NOT NULL THEN 0 ELSE 1 END,
                        f.locator_code;
                """;
            return await conn.QueryFirstOrDefaultAsync<LocatorSuggestion>(sql, new { lotId });
        }

        public async Task<SplitModelCheck> GetSplitModelCheckAsync(
            long targetLotId, IReadOnlyList<long> boxIds)
        {
            using var conn = _factory.Create();

            // Model lấy từ box_lines; lot/box không có line (mức box_count) fallback
            // sang cột model của chính nó. TRIM + bỏ rỗng để '' không thành 1 model.
            const string sql = """
            -- 1) Model pallet đích
            SELECT DISTINCT LTRIM(RTRIM(x.model)) AS Model
            FROM (
                SELECT bl.model
                FROM wms.boxes b
                JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                WHERE b.lot_id = @targetLotId AND b.is_deleted = 0
                UNION ALL
                SELECT l.model
                FROM wms.pallets l
                WHERE l.id = @targetLotId AND l.is_deleted = 0
                  AND NOT EXISTS (
                      SELECT 1 FROM wms.boxes b
                      JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                      WHERE b.lot_id = l.id AND b.is_deleted = 0)
            ) x
            WHERE NULLIF(LTRIM(RTRIM(x.model)), '') IS NOT NULL;

            -- 2) Model các box sắp chuyển
            SELECT DISTINCT LTRIM(RTRIM(x.model)) AS Model
            FROM (
                SELECT COALESCE(bl.model, b.model) AS model
                FROM wms.boxes b
                LEFT JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                WHERE b.id IN @boxIds AND b.is_deleted = 0
            ) x
            WHERE NULLIF(LTRIM(RTRIM(x.model)), '') IS NOT NULL;
            """;

            using var multi = await conn.QueryMultipleAsync(
                sql, new { targetLotId, boxIds = boxIds.ToList() });

            var targetModels = (await multi.ReadAsync<string>()).ToList();
            var boxModels = (await multi.ReadAsync<string>()).ToList();
            return new SplitModelCheck(targetModels, boxModels);
        }

        /// <summary>Lot nào trong danh sách đã có trong SWMS (theo pallet_id hoặc stocky_code).</summary>
        public async Task<HashSet<string>> GetExistingLotNosAsync(IReadOnlyCollection<string> lotNos)
        {
            var set = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
            if (lotNos.Count == 0) return set;

            using var conn = _factory.Create();
            const string sql = """
                SELECT j.lot
                FROM OPENJSON(@lots) WITH (lot varchar(50) '$') j
                WHERE EXISTS (SELECT 1 FROM wms.pallets l
                              WHERE l.is_deleted = 0 AND l.pallet_id = j.lot)
                   OR EXISTS (SELECT 1 FROM wms.pallets l
                              WHERE l.is_deleted = 0 AND l.stocky_code = j.lot);
                """;
            var rows = await conn.QueryAsync<string>(
                sql, new { lots = JsonSerializer.Serialize(lotNos) }, commandTimeout: 60);

            foreach (var r in rows) set.Add(r);
            return set;
        }

        /// <summary>Mọi pallet đang tồn trong SWMS (chưa xuất cho khách).</summary>
        public async Task<List<string>> GetLotNosInStockAsync()
        {
            using var conn = _factory.Create();
            var sql = $"""
                SELECT l.pallet_id
                FROM wms.pallets l
                WHERE l.is_deleted = 0
                  AND {PalletSqlShared.NotShippedSql};
                """;
            return (await conn.QueryAsync<string>(sql, commandTimeout: 60)).ToList();
        }

        /// <summary>
        /// Thông tin vị trí của cả nhóm trong 1 câu (thay cho 1 câu / pallet).
        /// Dùng lại LocationInfoSql để map đúng PalletLocationInfo.
        /// </summary>
        public async Task<Dictionary<string, PalletLocationInfo>> GetLocationInfosByLotNosAsync(
            IReadOnlyCollection<string> lotNos)
        {
            var map = new Dictionary<string, PalletLocationInfo>(StringComparer.OrdinalIgnoreCase);
            if (lotNos.Count == 0) return map;

            using var conn = _factory.Create();
            var sql = LocationInfoSql
                + "\nJOIN OPENJSON(@lots) WITH (lot varchar(50) '$') j ON j.lot = l.pallet_id"
                + "\nWHERE l.is_deleted = 0;";

            var rows = await conn.QueryAsync<PalletLocationInfo>(
                sql, new { lots = JsonSerializer.Serialize(lotNos) }, commandTimeout: 120);

            foreach (var r in rows) map.TryAdd(r.LotNo, r);
            return map;
        }

        /// <summary>
        /// Đặt box_count + standard_packing cho pallet box_count, ghi event cùng transaction.
        /// <paramref name="expectedQty"/> != null: chỉ ghi khi SL hiện tại (box_count × standard_packing)
        /// vẫn bằng giá trị đó. Null = không ghi được (đã đổi / bị xoá / không phải box_count).
        /// </summary>
        public async Task<BoxCountUpdateResult?> UpdateBoxCountAsync(
            long lotId, int boxCount, int standardPacking, int? expectedQty,
            string? user, StockEventContext ctx)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                // UPDLOCK: giữ dòng tới Commit để giá trị "trước" khớp với lúc UPDATE.
                const string beforeSql = """
                    SELECT ISNULL(box_count, 0)        AS BoxCountBefore,
                           ISNULL(standard_packing, 0) AS StandardPackingBefore
                    FROM wms.pallets WITH (UPDLOCK, ROWLOCK)
                    WHERE id = @lotId AND is_deleted = 0 AND detail_level = 'box_count';
                    """;
                var before = await conn.QueryFirstOrDefaultAsync<BoxCountUpdateResult>(
                    beforeSql, new { lotId }, tx);
                if (before is null) { tx.Rollback(); return null; }

                const string sql = """
                    UPDATE wms.pallets
                    SET    box_count        = @boxCount,
                           standard_packing = @standardPacking,
                           updated_at       = SYSDATETIME(),
                           updated_by       = @user
                    WHERE  id = @lotId
                      AND  is_deleted = 0
                      AND  detail_level = 'box_count'
                      AND  (@expectedQty IS NULL
                            OR ISNULL(box_count, 0) * ISNULL(standard_packing, 0) = @expectedQty);
                    """;
                var hit = await conn.ExecuteAsync(sql,
                    new { lotId, boxCount, standardPacking, expectedQty, user }, tx);
                if (hit == 0) { tx.Rollback(); return null; }

                await _events.WriteAsync(conn, tx, new StockEvent
                {
                    SubjectType = StockEventSubjects.Pallet,
                    PalletId = lotId,
                    EventCode = ctx.EventCode,
                    Actor = ctx.Actor ?? user,
                    Source = ctx.Source,
                    BoxCountBefore = before.BoxCountBefore,
                    BoxCountAfter = boxCount,
                    Note = ctx.Note,
                    Payload = ctx.Payload,
                });

                tx.Commit();
                return before;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }

        /// <summary>
        /// Gán si_no cho pallet. Chỉ ghi khi giá trị thật sự đổi.
        /// Trả về true nếu có cập nhật.
        /// </summary>
        public async Task<bool> UpdateSiNoAsync(
            long lotId, string? siNo, string? user, StockEventContext? ctx = null)
        {
            using var conn = _factory.Create();
            conn.Open();
            using var tx = conn.BeginTransaction();
            try
            {
                const string sql = """
                    UPDATE wms.pallets
                    SET si_no      = @siNo,
                        updated_at = SYSDATETIME(),
                        updated_by = @user
                    WHERE id = @lotId
                      AND is_deleted = 0
                      AND (si_no IS NULL OR si_no <> @siNo);
                    """;
                var changed = await conn.ExecuteAsync(sql, new { lotId, siNo, user }, tx) > 0;

                if (changed && ctx is not null)
                {
                    await _events.WriteAsync(conn, tx, new StockEvent
                    {
                        SubjectType = StockEventSubjects.Pallet,
                        PalletId = lotId,
                        EventCode = ctx.EventCode,
                        Actor = ctx.Actor ?? user,
                        Source = ctx.Source,
                        Note = ctx.Note,
                        Payload = ctx.Payload,
                    });
                }

                tx.Commit();
                return changed;
            }
            catch
            {
                tx.Rollback();
                throw;
            }
        }
    }

    /// <summary>
    /// Ném từ AddAsync khi raw_payload đã nằm trên pallet active khác.
    /// Tầng repo không có localizer — service bắt và đổi sang ConflictException.
    /// </summary>
    public sealed class DuplicateBoxPayloadException : Exception
    {
        public IReadOnlyDictionary<string, string> Existing { get; }

        public DuplicateBoxPayloadException(IReadOnlyDictionary<string, string> existing)
            : base($"Box payload already used: {string.Join(", ", existing.Keys)}")
            => Existing = existing;
    }
}
