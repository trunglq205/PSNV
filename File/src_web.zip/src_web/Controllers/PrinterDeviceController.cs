﻿using CurrieTechnologies.Razor.SweetAlert2;
using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class PrinterDeviceController : BaseController
    {
        private readonly ApiService _apiService;

        public PrinterDeviceController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] PrinterDeviceFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new PrinterDeviceFilter();
                var response = await _apiService.SearchPrinterDevice(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<PrinterDevice>();

                var model = new PrinterDeviceViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/PrinterDevice/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }
        
        [HttpGet]
        public IActionResult CreatePrinterDevice()
        {
            return PartialView("~/Views/PrinterDevice/_CreatePrinterDeviceModal.cshtml", new CreateUpdatePrinterDeviceViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreatePrinterDevice(CreateUpdatePrinterDeviceViewModel model)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var request = new PrinterDevice() { Id = model.ID, MacAddress = model.MacAddress };
                await _apiService.CreatePrinterDevice(new List<PrinterDevice>() { request });
                return Json(new { success = true });
            } catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public IActionResult UpdatePrinterDevice(string id, string macAddress)
        {
            var model = new CreateUpdatePrinterDeviceViewModel()
            {
                ID = id,
                MacAddress = macAddress,
            };
            return PartialView("~/Views/PrinterDevice/_CreatePrinterDeviceModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> UpdatePrinterDevice(CreateUpdatePrinterDeviceViewModel model)
        {
            try
            {
                return Json(new { success = true });
            } catch (Exception e)
            {
                return BadRequest(e.Message);
            }
  
        }

        [HttpGet]
        public IActionResult DeletePrinterDevice(string id)
        {
            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDeletePrinterDevice",
                Controller = "PrinterDevice",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeletePrinterDevice(string id)
        {
            try
            {
                await _apiService.DeletePrinterDevice(new List<string>() { id });
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }
    }
}

