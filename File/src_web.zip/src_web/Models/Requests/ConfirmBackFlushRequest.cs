﻿namespace SWMS_WebTool.Models
{
    public class ConfirmBackflushRequest
    {
        //public List<String> PlanOrderNumber { get; set; }
        public string? PlanOrderNumber { get; set; }
        public string? Material { get; set; }
        public string? Sloc { get; set; }
        public string? Plant { get; set; }
    }
}
