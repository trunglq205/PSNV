import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// 1 ô nhãn + giá trị của màn Model Detail.
class ModelField {
  final String label;

  /// null / rỗng → hiện "—".
  final String? value;
  final String unit;

  const ModelField(this.label, this.value, {this.unit = ''});

  /// Tiện cho số nullable: null → "—".
  ModelField.number(this.label, int? number, {this.unit = ''})
    : value = number?.toString();
}

/// Lưới các ô nhãn/giá trị, chia đều theo [columns]. Dùng chung cho các thẻ
/// thông tin của màn Model Detail.
class ModelFieldGrid extends StatelessWidget {
  const ModelFieldGrid({super.key, required this.fields, this.columns = 3});

  final List<ModelField> fields;
  final int columns;

  @override
  Widget build(BuildContext context) {
    final rows = <Widget>[];
    for (var i = 0; i < fields.length; i += columns) {
      if (i > 0) rows.add(const SizedBox(height: AppDimens.sm));
      rows.add(
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (var c = 0; c < columns; c++) ...[
              if (c > 0) const SizedBox(width: AppDimens.sm),
              Expanded(
                child: i + c < fields.length
                    ? _FieldCell(field: fields[i + c])
                    : const SizedBox.shrink(),
              ),
            ],
          ],
        ),
      );
    }
    return Column(mainAxisSize: MainAxisSize.min, children: rows);
  }
}

class _FieldCell extends StatelessWidget {
  const _FieldCell({required this.field});

  final ModelField field;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final raw = (field.value ?? '').trim();
    final empty = raw.isEmpty;
    final text = empty ? '—' : (field.unit.isEmpty ? raw : '$raw ${field.unit}');

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          field.label,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTextStyles.caption.copyWith(color: swms.text3),
        ),
        const SizedBox(height: 2),
        Text(
          text,
          maxLines: 1,
          overflow: TextOverflow.ellipsis,
          style: AppTextStyles.code.copyWith(
            fontWeight: FontWeight.w700,
            color: empty ? swms.text4 : swms.text1,
          ),
        ),
      ],
    );
  }
}

/// Tiêu đề nhỏ phía trên mỗi thẻ (cùng kiểu với BoxActionList).
class ModelSectionLabel extends StatelessWidget {
  const ModelSectionLabel(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(left: AppDimens.xs, bottom: AppDimens.xs),
      child: Text(
        text,
        style: AppTextStyles.label.copyWith(color: context.swms.text3),
      ),
    );
  }
}
