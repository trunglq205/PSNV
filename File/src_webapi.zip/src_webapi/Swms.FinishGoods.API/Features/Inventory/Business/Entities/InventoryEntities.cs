using Swms.FinishGoods.API.Features.Pallets.Business.Entities;

namespace Swms.FinishGoods.API.Features.Inventory.Business.Entities
{
    /// <summary>Khóa khu vực tồn kho — khớp 5 card trên màn Web.</summary>
    public static class InventoryArea
    {
        public const string FA  = "fa";   // FA chưa giao
        public const string Receiving  = "receiving";   // đã nhận, chưa lên kệ (kể cả chưa gán vị trí)
        public const string Storing  = "storing";   // đã lên kệ (STORAGE)
        public const string Vanning  = "vanning";   // chờ / đang lên container
        public const string Customer = "customer";   // Khách hàng

        public static readonly IReadOnlyList<string> All =
            [FA, Receiving, Storing, Vanning, Customer];

        public static bool IsValid(string? key) => key is not null && All.Contains(key);
    }

    /// <summary>Khóa sort cho danh sách tồn kho.</summary>
    public static class InventorySort
    {
        public const string CreatedDesc = "created_desc";   // mặc định
        public const string PdAsc = "pd_asc";
        public const string PdDesc = "pd_desc";
        public const string QtyDesc = "qty_desc";

        public static readonly IReadOnlyList<string> All = [CreatedDesc, PdAsc, PdDesc, QtyDesc];
    }

    /// <summary>
    /// 1 dòng tồn kho = Pallet + thông tin vị trí hiện tại (khu vực, kho, loại locator).
    /// Kế thừa Pallet để map response bằng PalletResponse.From.
    /// </summary>
    public class InventoryItem : Pallet
    {
        public string AreaKey { get; set; } = InventoryArea.Receiving;
        public string? LocatorName { get; set; }
        public string? LocatorType { get; set; }      // storage | staging | reserve | vanning | production
        public string? WarehouseCode { get; set; }
        public string? BorrowedFrom { get; set; }     // mã kho cho mượn — chỉ khi AreaKey = borrowed
        public bool IsHeavy { get; set; }             // nằm ở Jupiter
        public bool HasSerial { get; set; }
    }

    /// <summary>Thống kê 1 khu vực.</summary>
    public sealed class InventoryAreaStat
    {
        public string AreaKey { get; set; } = "";
        public int PalletCount { get; set; }
        public int BoxCount { get; set; }
        public int TotalQty { get; set; }
        public int ModelCount { get; set; }
    }

    /// <summary>1 bucket tuổi tồn (tính từ production_date).</summary>
    public sealed class InventoryAgingBucket
    {
        public string Key { get; set; } = "";     // lt30 | d30_60 | d60_90 | gt90
        public int FromDays { get; set; }
        public int? ToDays { get; set; }
        public int PalletCount { get; set; }
        public int TotalQty { get; set; }
    }

    /// <summary>Lot ứng viên đẩy SAP (sap_status 0/3/NULL).</summary>
    public sealed class SapCandidate
    {
        public long Id { get; set; }
        public string LotNo { get; set; } = "";
        public int? SapStatus { get; set; }
    }
}
