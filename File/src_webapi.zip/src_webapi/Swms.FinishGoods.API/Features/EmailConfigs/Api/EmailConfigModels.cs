using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.EmailConfigs.Api;

// Cấu hình email DÙNG CHUNG (hàng thiếu, nhận hàng bất thường, OQC NG, kiểm kê…).
// Bảng: master.email_events / email_event_subtypes / email_config — xem email_schema.sql.

public record EmailEventResponse(
    string Code, string Module, string Name, string? Description,
    string SubjectTemplate, string BodyTemplate, DateTime? UpdatedAt, string? UpdatedBy);

public record EmailSubtypeResponse(string EventCode, string SubCode, string Name, string Severity);

public record EmailConfigResponse(
    long Id, string EventCode,
    string? Department, string? SubCode, string? Category, string? Model, string? AreaCode,
    string RecipientType, long? UserId, string Email, string? DisplayName, bool IsActive);

public record EmailRecipientResponse(string Type, string Email, string? DisplayName);

public record SaveTemplateRequest(
    [Required, MaxLength(300)] string Subject,
    string? Body);

/// <summary>
/// Một ô email được phép chứa NHIỀU địa chỉ, ngăn bởi dấu phẩy hoặc chấm phẩy —
/// đó là cách khai một nhóm (OQC, FA, SCS) mà không phải tạo mỗi người một dòng.
///
/// [EmailAddress] của .NET chỉ nhận MỘT địa chỉ, nên nó chặn nhóm ngay ở khâu
/// lưu: dữ liệu nhóm hiện có trong DB là do chèn bằng SQL, hễ mở ra sửa qua API
/// là bị từ chối. Thuộc tính này tách rồi kiểm từng địa chỉ.
///
/// Đây là NỚI LỎNG chứ không siết: chuỗi nào trước đây hợp lệ thì nay vẫn hợp
/// lệ, nên không màn nào đang dùng API này bị ảnh hưởng.
/// </summary>
public sealed class EmailListAttribute : ValidationAttribute
{
    private static readonly EmailAddressAttribute One = new();

    public override bool IsValid(object? value)
    {
        // Rỗng thì để [Required] lo — ở đây Email là tuỳ chọn (có thể dùng UserId).
        if (value is not string s || string.IsNullOrWhiteSpace(s)) return true;

        var parts = s.Split(
            new[] { ',', ';' },
            StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);

        return parts.Length > 0 && parts.All(p => One.IsValid(p));
    }

    public override string FormatErrorMessage(string name)
        => $"{name}: địa chỉ không hợp lệ. Nhiều địa chỉ thì ngăn bằng dấu phẩy.";
}

public class SaveEmailConfigRequest
{
    [Required, MaxLength(40)] public string EventCode { get; set; } = "";
    [MaxLength(10)] public string? Department { get; set; }
    [MaxLength(30)] public string? SubCode { get; set; }
    [MaxLength(20)] public string? Category { get; set; }
    [MaxLength(50)] public string? Model { get; set; }
    [MaxLength(50)] public string? AreaCode { get; set; }
    [Required, MaxLength(3)] public string RecipientType { get; set; } = "TO";

    /// <summary>User nội bộ: điền UserId, Email bỏ qua. Người ngoài: điền Email.</summary>
    public long? UserId { get; set; }
    [MaxLength(200), EmailList] public string? Email { get; set; }
    [MaxLength(200)] public string? DisplayName { get; set; }
    public bool IsActive { get; set; } = true;
}
