using System.Data;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;
using Wkhtmltopdf.NetCore;
using Function = SWMS_WebTool.Utils.Function;

namespace SWMS_WebTool.Controllers
{
    public class DeliveryPlanController : BaseController
    {
        private readonly ApiService _apiService;
        readonly IGeneratePdf _generatePdf;

        public DeliveryPlanController(ApiService apiService, IGeneratePdf generatePdf)
        {
            _apiService = apiService;
            _generatePdf = generatePdf;
        }

        // GET: /<controller>/
        public async Task<IActionResult> Index([FromQuery] DeliveryPlanFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                int total = 1;
                IEnumerable<DeliveryPlan> items = new List<DeliveryPlan>();
                //var lstCheck = await _apiService.GetDAInvIsJPT();

                string name = User.Identity?.Name ?? "";

                if (name.Contains("-PMD"))
                {
                    if(filter.Type == DeliveryPlanType.DispatchAdvice || filter.Type == DeliveryPlanType.Invoice || filter.Type == DeliveryPlanType.NG)
                    {
                        filter.Type = DeliveryPlanType.PMDReturn;
                    }
                }

                switch (filter.Type)
                {
                    case DeliveryPlanType.PMDReturn:
                    case DeliveryPlanType.PMDRecycle:
                    case DeliveryPlanType.DispatchAdvice:
                    case DeliveryPlanType.NG:
                    case DeliveryPlanType.Invoice:
                        var responseDaInv = await _apiService.SearchDaInvoice(filter, pageNumber, _pageSize);
                        total = responseDaInv.TotalRecord;
                        items = responseDaInv.Records ?? new List<DeliveryPlanModel>();
                        break;
                    case DeliveryPlanType.OrderPlan:
                        var responseOrderPlan = await _apiService.SearchOrderPlan(filter, pageNumber, _pageSize);
                        total = responseOrderPlan.TotalRecord;
                        items = responseOrderPlan.Records ?? new List<OrderPlan>();
                        break;
                }

                var model = new DeliveryPlanViewModel()
                {
                    Items = items,
                    Filter = filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/DeliveryPlan/Index.cshtml", (model, new List<DAInvIsJPTViewModel>()));
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportDeliveryPlan(IFormFile file, DeliveryPlanType type)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        switch (type)
                        {
                            case DeliveryPlanType.PMDReturn:
                            case DeliveryPlanType.PMDRecycle:
                            case DeliveryPlanType.NG:
                            case DeliveryPlanType.Invoice:
                                dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.InvoiceHeader, Constants.IndexHeader);
                                if (dt != null && dt.Columns.Count == Constants.InvoiceHeader.Count)
                                {
                                    List<InvoiceImport>? invoices = Function.DataTatbleToInvoice(dt);
                                    if (type == DeliveryPlanType.PMDReturn)
                                    {
                                        bool NotPMGReturn = invoices.Where(x => !x.InvoiceNo.Contains("PMD Return")).Any();
                                        if (NotPMGReturn)
                                        {
                                            throw new Exception(_loc.Get("Msg_DeliveryNoteMustContainPmdReturn"));
                                        }
                                    }
                                    else if (type == DeliveryPlanType.PMDRecycle)
                                    {
                                        bool NoPMDRecycle = invoices.Where(x => !x.InvoiceNo.Contains("PMD Recycle")).Any();
                                        if (NoPMDRecycle)
                                        {
                                            throw new Exception(_loc.Get("Msg_DeliveryNoteMustContainPmdRecycle"));
                                        }
                                    }

                                    if (invoices != null && invoices.Count > 0)
                                    {
                                        return PartialView("~/Views/DeliveryPlan/_ImportInvoiceModal.cshtml", invoices);
                                    }
                                }
                                break;

                            case DeliveryPlanType.OrderPlan:
                                dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.PlanOrderHeader, null, true);
                                if (dt != null && dt.Columns.Count == Constants.PlanOrderHeader.Count)
                                {
                                    var planOrder = await _apiService.GetPlanOrderNumber();
                                    if (planOrder == null)
                                    {
                                        return BadRequest(_loc.Get("Msg_PlanordernumberIsNotValid"));
                                    }
                                    string planOrderNumber = string.Empty;
                                    planOrderNumber = planOrder.PlanOrderNumber;

                                    List<PlanOrderImport>? planOrders = Function.DataTatbleToPlanOrder(dt, planOrderNumber);
                                    if (planOrders != null && planOrders.Count > 0)
                                    {
                                        return PartialView("~/Views/DeliveryPlan/_ImportPlanOrderModal.cshtml", planOrders);
                                    }
                                }
                                break;
                        }
                    }

                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> ViewDeliveryPlanDetail(int id, DeliveryPlanType type)
        {
            try
            {
                var deliveryPlan = await _apiService.GetDeliveryPlans(id, type);
                return PartialView("~/Views/DeliveryPlan/_ViewDeliveryPlanDetailModal.cshtml", deliveryPlan);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportInvoice([FromBody] List<InvoiceImport> invoices)
        {
            try
            {
                await _apiService.ImportInvoice(invoices);
                var countDataData = invoices.SelectMany(e => e.Details.SelectMany(e => e.DetailItems)).Count();
                return Json(new { success = true, countdata = countDataData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> ConfirmImportPlanOrder([FromBody] List<PlanOrderImport> planOrders)
        {
            try
            {
                await _apiService.ImportPlanOrder(planOrders);
                var countData = planOrders.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> PrintReceivingCardByDaInvId(DeliveryPlanType type, int id, string no)
        {
            try
            {
                CreateReceivingCardByDAInvID request = new CreateReceivingCardByDAInvID()
                {
                    Type = int.Parse(type.ToEnumMemberAttrValue()),
                    Id = id,
                };
                List<ReceivingCard>? listRC = await _apiService.PrintReceivingCardByDaInvId(request);
                if (listRC == null || listRC.Count == 0)
                {
                    return BadRequest(_loc.Get("Msg_NoReceivingCardHasBeenCreated"));
                }
                var dataJson = JsonConvert.SerializeObject(listRC);
                ViewBag.DeliveryPlanId = id;
                ViewBag.DeliveryPlanNo = no;
                var tuple = new Tuple<List<ReceivingCard>, int, long, string?>(listRC, request.Type, request.Id, null);
                return PartialView("~/Views/DeliveryPlan/_ListReceivingCard.cshtml", tuple);

            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        //[HttpGet]
        public async Task<IActionResult> PrintReceivingCard(DeliveryPlanType type, int id)
        {
            try
            {
                CreateReceivingCardByDAInvID request = new CreateReceivingCardByDAInvID()
                {
                    Type = int.Parse(type.ToEnumMemberAttrValue()),
                    Id = id,
                    IsPreview = false,
                };
                List<ReceivingCard>? listRC = await _apiService.PrintReceivingCardByDaInvId(request);
                string? dainvNO = listRC.Select(x => x.DAInvNo).FirstOrDefault();
                byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/DeliveryPlan/_PrintListReceivingCardJPT.cshtml", listRC);
                return File(bytesRC, "application/pdf", string.Format("{0}.pdf", dainvNO));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmReceivingCards(string ids)
        {
            try
            {
                var details = ids.Split(";").Select(int.Parse).ToList();

                var request = new ComfirmJPTRequest
                {
                    Ids = details
                };
                await _apiService.ConfirmReceivingCards(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        //[HttpGet]
        //public IActionResult ConfirmBackFlush()
        //{
        //    return PartialView("~/Views/DeliveryPlan/_ConfirmBackFlushModal.cshtml");
        //}

        //[HttpPost]
        //public async Task<IActionResult> ConfirmBackFlush(string selectedItems)
        //{
        //    if (!ModelState.IsValid)
        //    {
        //        var message = string.Join(" | ", ModelState.Values
        //        .SelectMany(v => v.Errors)
        //        .Select(e => e.ErrorMessage));
        //        return BadRequest(message);
        //    }

        //    try
        //    {
        //        var request = new ConfirmBackflushRequest()
        //        {
        //            PlanOrderNumber = selectedItems.Split(";").ToList(),
        //        };

        //        await _apiService.ConfirmBackFlush(request);

        //        return Json(new { success = true });
        //    }
        //    catch (Exception ex)
        //    {
        //        return BadRequest(ex.Message);
        //    }
        //}

        [HttpPost]
        public async Task<IActionResult> ConfirmQtyRC(long id, double QuantityNew)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }
            try
            {
                await _apiService.UpdateQtyRC(id, QuantityNew);
                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> SearchByMaterial(int selectView, int index, string? searchText, byte type, int id)
        {
            try
            {
                var result = new List<ReceivingCard>();
                CreateReceivingCardByDAInvID request = new CreateReceivingCardByDAInvID()
                {
                    Type = Convert.ToInt32(type),
                    Id = id,
                };
                List<ReceivingCard>? listRC = await _apiService.PrintReceivingCardByDaInvId(request);
                if (!string.IsNullOrEmpty(searchText))
                {
                    TempData[searchText] = searchText;
                    // Lọc dữ liệu từ nguồn dữ liệu gốc (Model) dựa trên searchText
                    result = listRC.Where(item => item.Material.ToLower().Contains(searchText.Trim().ToLower())).ToList();
                }
                else
                {
                    result = listRC.ToList();
                }
                var tuple = new Tuple<List<ReceivingCard>, int, long, string?>(result, request.Type, request.Id, searchText);
                if (selectView == 0)
                {
                    return PartialView("~/Views/DeliveryPlan/_ListReceivingCard.cshtml", tuple);
                }
                else
                {
                    return PartialView("~/Views/Shared/_ReceivingCard.cshtml", tuple.Item1[index]);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public IActionResult DeletePlanOrder(string? material, string? orderplan, string? plant, string? sloc, string date)
        {
            try
            {
                DeletePlanNotYetGR model = new DeletePlanNotYetGR();
                model.Date = date;
                model.Material = material;
                model.PlanOrder = orderplan;
                model.Plant = plant;
                model.Sloc = sloc;
                return PartialView("~/Views/DeliveryPlan/_DeleteOrderPlant.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpGet]
        public IActionResult DeletePlanOrderWithParameter(string material, string orderplan, string plant, string sloc, string date)
        {
            try
            {
                DeletePlanNotYetGR model = new DeletePlanNotYetGR();
                model.Date = date;
                model.Material = material;
                model.PlanOrder = orderplan;
                model.Plant = plant;
                model.Sloc = sloc;
                return PartialView("~/Views/DeliveryPlan/_DeleteOrderPlant.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeletePlanOrder(DeletePlanNotYetGR request)
        {
            try
            {
                await _apiService.DeletePlanOrderNotYetGR(request.Date);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult DeleteDeliveryPlan(long id)
        {
            try
            {
                var model = new DeleteObject()
                {
                    Id = id.ToString(),
                    Action = "ConfirmDeleteDeliveryPlan",
                    Controller = "DeliveryPlan"
                };
                return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteDeliveryPlan(long id)
        {
            try
            {
                await _apiService.DeleteDeliveryPlan(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        #region hai.dinhduc1

        [HttpPost]
        public IActionResult DeleteMultiplePlanOrder(string planOrderNumber)
        {
            try
            {
                var model = new DeleteObject()
                {
                    Id = planOrderNumber,
                    Action = "ConfirmDeleteDeliveryPlan",
                    Controller = "DeliveryPlan"
                };
                return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteMultiplePlanOrder(string id)
        {
            try
            {
                await _apiService.DeleteMultiplePlanOrder(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult DeleteMultipleInvoice(string poNo)
        {
            try
            {
                var model = new DeleteObject()
                {
                    Id = poNo,
                    Action = "ConfirmDeleteDeliveryPlan",
                    Controller = "DeliveryPlan"
                };
                return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteMultipleInvoice(string id)
        {
            try
            {
                await _apiService.DeleteMultipleInvoice(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        #endregion

        [HttpGet]

        public async Task<IActionResult> PrintRCJPT(int type, string date, string no)
        {
            try
            {
                var models = await _apiService.GetDAInvIsJPT(type, date, no);
                return PartialView("~/Views/DeliveryPlan/_ListJPT.cshtml", models);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public IActionResult DeleteInvoiceConfirm(string date)
        {
            try
            {
                DeletePlanNotYetGR model = new DeletePlanNotYetGR();
                model.Date = date;
                return PartialView("~/Views/DeliveryPlan/_DeleteInvoiceNotYetGR.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> DeleteInvoiceNotYetGR(DeletePlanNotYetGR request)
        {
            try
            {
                await _apiService.DeleteInvoiceNotYetGR(request.Date);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}

