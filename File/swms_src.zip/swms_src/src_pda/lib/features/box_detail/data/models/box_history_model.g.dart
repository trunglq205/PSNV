// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'box_history_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

BoxHistoryModel _$BoxHistoryModelFromJson(Map<String, dynamic> json) =>
    BoxHistoryModel(
      header: BoxHistoryHeaderModel.fromJson(
        json['header'] as Map<String, dynamic>,
      ),
      events:
          (json['events'] as List<dynamic>?)
              ?.map((e) => BoxEventModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          [],
    );

Map<String, dynamic> _$BoxHistoryModelToJson(BoxHistoryModel instance) =>
    <String, dynamic>{'header': instance.header, 'events': instance.events};

EventLocatorModel _$EventLocatorModelFromJson(Map<String, dynamic> json) =>
    EventLocatorModel(
      locatorCode: json['locatorCode'] as String,
      areaCode: json['areaCode'] as String?,
    );

Map<String, dynamic> _$EventLocatorModelToJson(EventLocatorModel instance) =>
    <String, dynamic>{
      'locatorCode': instance.locatorCode,
      'areaCode': ?instance.areaCode,
    };

BoxEventModel _$BoxEventModelFromJson(
  Map<String, dynamic> json,
) => BoxEventModel(
  id: (json['id'] as num).toInt(),
  eventCode: json['eventCode'] as String,
  eventAt: DateTime.parse(json['eventAt'] as String),
  inherited: json['inherited'] as bool? ?? false,
  actor: json['actor'] as String?,
  palletCode: json['palletCode'] as String?,
  fromLocator: json['fromLocator'] == null
      ? null
      : EventLocatorModel.fromJson(json['fromLocator'] as Map<String, dynamic>),
  toLocator: json['toLocator'] == null
      ? null
      : EventLocatorModel.fromJson(json['toLocator'] as Map<String, dynamic>),
  refNo: json['refNo'] as String?,
  note: json['note'] as String?,
  payload: json['payload'] as String?,
);

Map<String, dynamic> _$BoxEventModelToJson(BoxEventModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'eventCode': instance.eventCode,
      'eventAt': instance.eventAt.toIso8601String(),
      'actor': ?instance.actor,
      'inherited': instance.inherited,
      'palletCode': ?instance.palletCode,
      'fromLocator': ?instance.fromLocator,
      'toLocator': ?instance.toLocator,
      'refNo': ?instance.refNo,
      'note': ?instance.note,
      'payload': ?instance.payload,
    };

BoxHistoryHeaderModel _$BoxHistoryHeaderModelFromJson(
  Map<String, dynamic> json,
) => BoxHistoryHeaderModel(
  boxId: (json['boxId'] as num).toInt(),
  boxNo: json['boxNo'] as String,
  lineCount: (json['lineCount'] as num?)?.toInt() ?? 0,
  isDeleted: json['isDeleted'] as bool? ?? false,
  palletCode: json['palletCode'] as String?,
  model: json['model'] as String?,
  totalQty: (json['totalQty'] as num?)?.toInt(),
  oqcStatus: (json['oqcStatus'] as num?)?.toInt(),
  currentLocator: json['currentLocator'] == null
      ? null
      : EventLocatorModel.fromJson(
          json['currentLocator'] as Map<String, dynamic>,
        ),
);

Map<String, dynamic> _$BoxHistoryHeaderModelToJson(
  BoxHistoryHeaderModel instance,
) => <String, dynamic>{
  'boxId': instance.boxId,
  'boxNo': instance.boxNo,
  'palletCode': ?instance.palletCode,
  'model': ?instance.model,
  'lineCount': instance.lineCount,
  'totalQty': ?instance.totalQty,
  'oqcStatus': ?instance.oqcStatus,
  'currentLocator': ?instance.currentLocator,
  'isDeleted': instance.isDeleted,
};
