// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ocr_check_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

OCRCheckRequestModel _$OCRCheckRequestModelFromJson(
        Map<String, dynamic> json) =>
    OCRCheckRequestModel(
      reelID: json['reelID'] as String,
      material: json['material'] as String,
      oCR: json['oCR'] as String,
      userID: json['userID'] as String,
    );

Map<String, dynamic> _$OCRCheckRequestModelToJson(
        OCRCheckRequestModel instance) =>
    <String, dynamic>{
      'reelID': instance.reelID,
      'material': instance.material,
      'oCR': instance.oCR,
      'userID': instance.userID,
    };
