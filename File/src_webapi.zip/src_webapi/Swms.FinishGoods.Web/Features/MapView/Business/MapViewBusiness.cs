using Swms.FinishGoods.Web.Features.MapView.Business.Models;
using Swms.FinishGoods.Web.Features.MapView.Client;
using Swms.FinishGoods.Web.Shared.Business.Base;
using Swms.FinishGoods.Web.Shared.Business.Models;

namespace Swms.FinishGoods.Web.Features.MapView.Business;

public class MapViewBusiness : BaseBusiness, IMapViewBusiness
{
    private readonly IMapViewApi _api;
    public MapViewBusiness(IMapViewApi api, ILogger<MapViewBusiness> logger, ErrorHandler errorHandler)
        : base(logger, errorHandler) => _api = api;

    public Task<Result<MapViewLayoutDto>> GetAsync(string areaCode)
        => ExecuteAsync(() => _api.GetAsync(areaCode));
}
