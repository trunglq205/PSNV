import 'package:swms_finish_goods/features/shipment_instruction/data/datasources/shipment_instruction_remote_data_source.dart';
import 'package:swms_finish_goods/features/shipment_instruction/data/models/pick_task_detail_model.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/repositories/shipment_instruction_repository.dart';

class ShipmentInstructionRepositoryImpl
    implements ShipmentInstructionRepository {
  final ShipmentInstructionRemoteDataSource _remote;

  const ShipmentInstructionRepositoryImpl(this._remote);

  @override
  Future<ShipmentInstructionPage> getList({
    SiStatus? status,
    int page = 1,
    int size = 20,
  }) async {
    final res = await _remote.fetchList(
      docStatus: status?.key,
      page: page,
      size: size,
    );
    return res.toEntity();
  }

  @override
  Future<ShipmentInstructionDetail> getDetail(int id) async {
    final res = await _remote.fetchDetail(id);
    return res.toEntity();
  }

  @override
  Future<PickTaskDetail> getPickTask(PickTask task) async =>
      _toDetail(task, await _remote.fetchPickTask(task.id));

  @override
  Future<PickTaskDetail> confirmPallet(
    PickTask task,
    String palletCode,
  ) async => _toDetail(
    task,
    await _remote.confirmPallet(
      task.id,
      ConfirmPalletRequest(palletCode.trim()),
    ),
  );

  @override
  Future<PickTaskDetail> pickBox(PickTask task, String boxNo) async =>
      _toDetail(
        task,
        await _remote.pickBox(task.id, PickBoxRequest(boxNo.trim())),
      );

  @override
  Future<PickTaskDetail> unpickBox(PickTask task, String boxNo) async =>
      _toDetail(task, await _remote.unpickBox(task.id, boxNo.trim()));

  @override
  Future<PickTaskDetail> stageVanning(
    PickTask task, {
    required String palletCode,
    required String locatorCode,
  }) async => _toDetail(
    task,
    await _remote.stageVanning(
      task.id,
      StageVanningRequest(
        palletCode: palletCode.trim(),
        locatorCode: locatorCode.trim(),
      ),
    ),
  );

  static PickTaskDetail _toDetail(PickTask task, PickTaskDetailModel m) =>
      m.toEntity(model: task.model, poNo: task.poNo);
}
