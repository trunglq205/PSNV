﻿using SWMS_WebTool.Models.Layout;
using System.Drawing;

namespace SWMS_WebTool.Models.Responses
{
    public class OrderBlockResponse
    {
        public string Name;
        public double X;
        public double Y;
        public double Width;
        public double Height;
    }
    public class ListSuggestKittingResponse
    {
        public List<KittingListDetail> Records { get; set; }
        public int TotalRecord { get; set; }
        public List<OrderBlockResponse> OrderBlock { get; set; }
        public List<Node> SuggestPath { get; set; }
    }

    public class SuggestKittingResponse
    {
        public Floor LayoutMap { get; set; }
        public List<OrderBlockResponse> OrderBlock { get; set; }
        public List<Node> SuggestPath { get; set; }
    }
}
