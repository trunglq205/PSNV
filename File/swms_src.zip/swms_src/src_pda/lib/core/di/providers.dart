import 'package:dio/dio.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:swms_finish_goods/config/app_config.dart';
import 'package:swms_finish_goods/core/network/certificate_service.dart';
import 'package:swms_finish_goods/core/network/dio_client.dart';
import 'package:swms_finish_goods/core/storage/secure_storage_service.dart';
import 'package:swms_finish_goods/core/utils/app_local_storage.dart';

part 'providers.g.dart';

/// === Hạ tầng dùng chung — DI bằng Riverpod ===

@Riverpod(keepAlive: true)
Future<AppLocalStorage> appLocalManager(Ref ref) async {
  final prefs = await SharedPreferences.getInstance();
  const secure = FlutterSecureStorage();
  return AppLocalStorage(secure, prefs);
}

@Riverpod(keepAlive: true)
SecureStorageService secureStorage(Ref ref) {
  final storage = ref.watch(appLocalManagerProvider).requireValue;
  return SecureStorageService(storage);
}

@Riverpod(keepAlive: true)
Dio dio(Ref ref) => DioClient.create(
  baseUrl: AppConfig.baseUrl,
  appStorage: ref.watch(appLocalManagerProvider).requireValue,
  storage: ref.watch(secureStorageProvider),
  trustedCertificate: CertificateService.instance.caBytes,
);
