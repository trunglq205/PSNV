import 'dart:io';

import 'package:swms_finish_goods/features/abnormal_report/data/datasources/ng_remote_data_source.dart';
import 'package:swms_finish_goods/features/abnormal_report/data/models/ng_models.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/repositories/ng_repository.dart';

class NgRepositoryImpl implements NgRepository {
  final NgRemoteDataSource _remote;
  NgRepositoryImpl(this._remote);

  @override
  Future<List<NgReport>> fetchList({
    String? status,
    String? ngType,
    String? keyword,
    DateTime? day,
  }) async {
    // Lọc 1 ngày: từ 00:00 hôm đó đến trước 00:00 hôm sau. Gửi dạng ISO theo
    // giờ địa phương, không đổi sang UTC — phiếu ghi theo giờ máy chủ nhà máy.
    String? f, t2;
    if (day != null) {
      final d0 = DateTime(day.year, day.month, day.day);
      f = _iso(d0);
      t2 = _iso(d0.add(const Duration(days: 1)));
    }
    final rows = await _remote.fetchList(
      status: status,
      ngType: ngType,
      from: f,
      to: t2,
      keyword: keyword,
    );
    return rows.map((e) => e.toEntity()).toList();
  }

  static String _iso(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
      '${d.month.toString().padLeft(2, '0')}-'
      '${d.day.toString().padLeft(2, '0')}T00:00:00';

  @override
  Future<NgDetail> fetchDetail(int id) async => (await _remote.fetchDetail(id)).toEntity();

  @override
  Future<List<NgType>> fetchTypes() async {
    final rows = await _remote.fetchTypes();
    return rows.map((e) => e.toEntity()).toList(growable: false);
  }

  @override
  Future<NgPalletBrief> checkPallet(String code) async =>
      (await _remote.checkPallet(code.trim())).toEntity();

  @override
  Future<({int id, String docNo})> create({
    required String palletCode,
    required String ngType,
    required List<NgDraftItem> items,
    String? description,
  }) async {
    final res = await _remote.create(CreateNgReportModel(
      palletCode: palletCode,
      ngType: ngType,
      description: description,
      items: items.map(_toItemModel).toList(),
    ));
    return (id: res.id, docNo: res.docNo);
  }

  @override
  Future<void> uploadPhoto(int id, File file) => _remote.uploadPhoto(id, file);

  /// Mục phạm vi ảnh hưởng: entity -> model gửi lên. Gửi thẳng, không suy diễn
  /// gì thêm — server nhận qty_affected <= 0 hoặc null thì tự đặt về 1.
  static CreateNgItemModel _toItemModel(NgDraftItem it) => CreateNgItemModel(
        scope: it.scope,
        code: it.code,
        qtyAffected: it.qtyAffected,
        note: it.note,
      );
}
