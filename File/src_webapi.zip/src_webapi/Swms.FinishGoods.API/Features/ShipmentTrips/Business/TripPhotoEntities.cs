namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

/// <summary>1 dòng wms.shipment_trip_photos. File gốc nằm trên đĩa; DB giữ đường dẫn tương đối.</summary>
public class TripPhotoRow
{
    public long Id { get; set; }
    public long TripId { get; set; }
    public string ItemKey { get; set; } = "";
    /// <summary>Pallet / cọc / hàng thứ mấy (1..n). NULL = ảnh theo chuyến.</summary>
    public int? UnitNo { get; set; }
    /// <summary>Ảnh theo pallet: pallet thật (PDA quét tem). NULL với ảnh theo chuyến / cọc / hàng.</summary>
    public long? PalletId { get; set; }
    /// <summary>Mã pallet (wms.pallets.pallet_id) — chỉ đọc, join khi lấy ảnh.</summary>
    public string? PalletCode { get; set; }
    /// <summary>Ảnh thứ mấy trong mục (1..PerUnit).</summary>
    public int SlotNo { get; set; } = 1;
    public string FilePath { get; set; } = "";
    public string FileName { get; set; } = "";
    public string? ContentType { get; set; }
    public long? SizeBytes { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
}
