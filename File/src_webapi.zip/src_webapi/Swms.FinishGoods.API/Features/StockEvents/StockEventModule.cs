﻿using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;

namespace Swms.FinishGoods.API.Features.StockEvents
{
    public static class StockEventModule
    {
        /// <summary>
        /// Đăng ký trong Program.cs: services.AddStockEventFeature();
        ///
        /// PHẢI đăng ký TRƯỚC (hoặc cùng chỗ với) AddPalletFeature / AddBoxFeature
        /// vì LotRepository và BoxRepository đều inject IStockEventWriter.
        ///
        /// NGOÀI RA cần thêm một dòng vào Program.cs:
        ///     Dapper.DefaultTypeMap.MatchNamesWithUnderscores = true;
        /// Ba proc lịch sử trả cột snake_case (theo convention SQL của dự án).
        /// Thiếu dòng này thì Dapper map ra toàn null mà KHÔNG báo lỗi.
        /// Đây là cờ cộng thêm, không phá các truy vấn đang alias PascalCase.
        /// </summary>
        public static IServiceCollection AddStockEventFeature(this IServiceCollection services)
        {
            services.AddScoped<IStockEventService, StockEventService>();
            services.AddScoped<IStockEventRepository, StockEventRepository>();
            services.AddScoped<IStockEventWriter, StockEventWriter>();
            return services;
        }
    }
}