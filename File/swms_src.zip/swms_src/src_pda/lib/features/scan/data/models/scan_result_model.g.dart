// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'scan_result_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ScanResultModel _$ScanResultModelFromJson(Map<String, dynamic> json) =>
    ScanResultModel(
      code: json['code'] as String,
      type: json['type'] as String,
      id: (json['id'] as num?)?.toInt(),
      areaCode: json['areaCode'] as String?,
    );

Map<String, dynamic> _$ScanResultModelToJson(ScanResultModel instance) =>
    <String, dynamic>{
      'code': instance.code,
      'type': instance.type,
      'id': ?instance.id,
      'areaCode': ?instance.areaCode,
    };
