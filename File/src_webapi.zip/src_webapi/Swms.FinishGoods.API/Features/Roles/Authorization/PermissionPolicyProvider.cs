using Microsoft.AspNetCore.Authorization;
using Microsoft.Extensions.Options;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Sinh policy động cho mỗi quyền "perm:{code}" — khỏi phải đăng ký thủ công
/// từng policy trong Program.cs. Bất kỳ [RequirePermission("x.y")] nào cũng
/// tự có policy tương ứng.
/// </summary>
public sealed class PermissionPolicyProvider : IAuthorizationPolicyProvider
{
    private readonly DefaultAuthorizationPolicyProvider _fallback;

    public PermissionPolicyProvider(IOptions<AuthorizationOptions> options)
        => _fallback = new DefaultAuthorizationPolicyProvider(options);

    public Task<AuthorizationPolicy> GetDefaultPolicyAsync()
        => _fallback.GetDefaultPolicyAsync();

    public Task<AuthorizationPolicy?> GetFallbackPolicyAsync()
        => _fallback.GetFallbackPolicyAsync();

    public Task<AuthorizationPolicy?> GetPolicyAsync(string policyName)
    {
        var permission = PermissionPolicy.ExtractPermission(policyName);
        if (permission is not null)
        {
            var policy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .AddRequirements(new PermissionRequirement(permission))
                .Build();
            return Task.FromResult<AuthorizationPolicy?>(policy);
        }
        return _fallback.GetPolicyAsync(policyName);
    }
}
