﻿using System.Net.Http.Headers;

namespace SWMS_WebTool.Services.Interceptors
{
    public class AuthenticationInterceptor : DelegatingHandler
    {
        private IHttpContextAccessor _httpContextAccessor;

        public AuthenticationInterceptor(IHttpContextAccessor httpContextAccessor)
        {
            _httpContextAccessor = httpContextAccessor;
        }
        protected override async Task<HttpResponseMessage> SendAsync(
            HttpRequestMessage request, CancellationToken cancellationToken)
        {
            if (request.Headers.Contains("Authentication"))
            {
                var accessToken = _httpContextAccessor.HttpContext?.Session.GetString("SWMSToken");

                request.Headers.Remove("Authentication");
                request.Headers.Authorization = new AuthenticationHeaderValue("Bearer", accessToken);
            }

            return await base.SendAsync(request, cancellationToken);
        }
    }
}
