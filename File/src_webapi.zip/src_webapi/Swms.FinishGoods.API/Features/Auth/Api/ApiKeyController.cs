﻿using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.Auth.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;

namespace Swms.FinishGoods.API.Features.Auth.Api;

[ApiController]
[Route("api/auth/api-keys")]
// TODO: đổi "admin.api_key.manage" cho khớp code quyền admin trong PermissionCatalog.
//[RequirePermissionByCode("admin.api_key.manage")]
public class ApiKeyController : ControllerBase
{
    private readonly IApiKeyService _service;

    public ApiKeyController(IApiKeyService service) => _service = service;

    // LẤY (cấp key mới). FullKey chỉ trả về ĐÚNG MỘT LẦN ở đây.
    [HttpPost]
    public async Task<ActionResult<ApiKeyIssuedResponse>> Create(CreateApiKeyRequest request)
        => Ok(await _service.CreateAsync(request, User.Identity?.Name));

    // ĐỔI (rotate): sinh key mới, vô hiệu key cũ.
    [HttpPost("{id:long}/rotate")]
    public async Task<ActionResult<ApiKeyIssuedResponse>> Rotate(long id)
        => Ok(await _service.RotateAsync(id, User.Identity?.Name));

    // Thu hồi hẳn một key.
    [HttpPost("{id:long}/revoke")]
    public async Task<IActionResult> Revoke(long id)
    {
        await _service.RevokeAsync(id, User.Identity?.Name);
        return NoContent();
    }

    // Liệt kê key (không chứa key gốc).
    [HttpGet]
    public async Task<ActionResult<IReadOnlyList<ApiKeyInfo>>> List()
        => Ok(await _service.ListAsync());
}