using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.PartCard.Business.Models;
using Swms.FinishGoods.Web.Shared.App;
using Swms.FinishGoods.Web.Shared.App.CsvIo;
using System.Globalization;

namespace Swms.FinishGoods.Web.Features.PartCard.App.Csvlo;

// ─────────────────────────────────────────────────────────────
//  Khai báo CSV cho Part Card. Mỗi dòng CSV = 1 dòng hàng.
//  MỘT file duy nhất chứa được cả 2 loại phiếu; loại được nhận diện
//  theo cột "service_part" ở mức THÙNG (box):
//
//    • Oversea (service part): bất kỳ dòng nào của (po_no + box)
//      có service_part = Y  →  CẢ thùng là oversea. Mọi dòng của thùng đó
//      trở thành inner box (kể cả dòng không điền Y).
//
//    • Hàng thường: thùng không có dòng nào Y. Mỗi MÃ HÀNG trong thùng
//      thành 1 phiếu riêng (phiếu thường chỉ hiển thị 1 mã + số lượng);
//      dòng trùng mã trong cùng thùng sẽ được CỘNG DỒN số lượng.
//
//  Parse hoàn toàn client-side qua CsvImportDialog — KHÔNG gửi file lên server.
//
//  LƯU Ý: Key của cột PHẢI trùng header trong file CSV. Header CSV dùng
//  snake_case; row.Get(Key) đọc theo đúng header đó.
// ─────────────────────────────────────────────────────────────
public static class PartCardCsvSchema
{
    // Giá trị cột "oqc_check" được coi là ĐÃ CHECK.
    private const string OqcCheckedValue = "ASSY";

    // Category mặc định khi cột "category" để trống.
    private const int DefaultCategory = 310;

    // Các giá trị cột "service_part" được coi là BẬT oversea.
    private static readonly string[] ServicePartTruthy = { "Y", "YES", "1", "TRUE", "X" };

    // ── Xuất xứ ──────────────────────────────────────────────
    // Cột "origin" trong CSV nhập KEY 2 CHỮ (ISO 3166-1 alpha-2) và LƯU đúng
    // key đó (viết hoa). Tên đầy đủ chỉ để tham chiếu/hiển thị.
    // Danh sách phải khớp enum bên app PDA.
    private static readonly (string Code, string Name)[] OriginList =
    {
        ("CN", "China"),
        ("DE", "Germany"),
        ("ID", "Indonesia"),
        ("JP", "Japan"),
        ("MY", "Malaysia"),
        ("PH", "Philippines"),
        ("SG", "Singapore"),
        ("KR", "South Korea"),
        ("TW", "Taiwan"),
        ("TH", "Thailand"),
        ("US", "USA"),
        ("VN", "Vietnam"),
    };

    private static readonly Dictionary<string, string> OriginByCode =
        OriginList.ToDictionary(o => o.Code, o => o.Name, StringComparer.OrdinalIgnoreCase);

    // Chuỗi "CN, DE, ..." để hiển thị trong thông báo lỗi.
    private static readonly string OriginCodesHint =
        string.Join(", ", OriginList.Select(o => o.Code));

    // Key mặc định khi cột "origin" để trống.
    private const string DefaultOriginCode = "";

    public static CsvSchema<PartCardImportRow> BuildSchema(IStringLocalizer L) => new()
    {
        FileBaseName = "swms_part_cards",
        MaxImportRows = 500,
        Columns = new List<CsvColumn<PartCardImportRow>>
        {
            // ── Cấp phiếu (thùng ngoài) ──
            new() { Key = "box",            Description = L["PartCardCsv.Col.Box"],         Required = true,  Get = r => r.BoxNo,                             Example = "1" },
            new() { Key = "category",       Description = L["PartCardCsv.Col.Category"],    Required = false, Get = r => r.Category,                          Example = "310" },
            new() { Key = "po_no",          Description = L["PartCardCsv.Col.PoNo"],        Required = false, Get = r => r.PoNo,                              Example = "D62P118213" },
            new() { Key = "customer_po_no", Description = L["PartCardCsv.Col.CustPoNo"],    Required = false, Get = r => r.CustomerPoNo,                      Example = "4500051710" },
            new() { Key = "model",          Description = L["PartCardCsv.Col.Model"],       Required = true,  Get = r => r.Model,                             Example = "H80343G00EU/AS-SP-MW" },
            new() { Key = "qty",            Description = L["PartCardCsv.Col.Qty"],         Required = true,  Get = r => r.Qty,                               Example = "24" },
            // Xuất xứ: key 2 chữ (CN, VN, ...).
            new() { Key = "origin", Description = L["PartCardCsv.Col.Origin"],              Required = false, Get = r => r.Origin,                            Example = "CN" },            // ── Kích thước ngoài (chung cho phiếu) ──
            new() { Key = "length",         Description = L["PartCardCsv.Col.Length"],      Required = false, Get = r => r.OuterLength,                       Example = "80" },
            new() { Key = "width",          Description = L["PartCardCsv.Col.Width"],       Required = false, Get = r => r.OuterWidth,                        Example = "60" },
            new() { Key = "height",         Description = L["PartCardCsv.Col.Height"],      Required = false, Get = r => r.OuterHeight,                       Example = "50" },
            new() { Key = "weight",         Description = L["PartCardCsv.Col.Weight"],      Required = false, Get = r => r.OuterWeight,                       Example = "10.5" },
            // ── Inner box (chỉ dùng cho phiếu oversea) ──
            new() { Key = "inner_box",      Description = L["PartCardCsv.Col.InnerBox"],    Required = false, Get = r => r.InnerBox,                          Example = "1" },
            // ── Cột quyết định loại phiếu ──
            new() { Key = "service_part",   Description = L["PartCardCsv.Col.ServicePart"], Required = false, Get = r => r.ServicePart ? "Y" : "",            Example = "Y" },
            // ── OQC check (chỉ có nghĩa với phiếu oversea) — "ASSY" = đã check ──
            new() { Key = "oqc_check",      Description = L["PartCardCsv.Col.OqcCheck"],    Required = false, Get = r => r.OqcChecked ? OqcCheckedValue : "", Example = OqcCheckedValue },
            new() { Key = "date",           Description = L["PartCardCsv.Col.Date"],        Required = true,  Get = r => r.Date,                              Example = "08/10/2026" },
        },
        TemplateExamples = new List<IReadOnlyList<string>>
        {
            // ── Box 1: service part oversea, 2 inner box → 1 phiếu oversea ──
            new[] { "1", "310", "4500051710", "D62P118213", "H80343G00EU/AS-SP-MW", "24", "CN", "80", "60", "50", "18.5", "1", "Y", "ASSY","08/10/2026" },
            new[] { "1", "310", "4500051710", "D62P118213", "H3019-3850-MW", "12", "CN", "80", "60", "50", "18.5", "2", "Y", "","08/10/2026" },

            // ── Box 2: hàng thường (service_part trống) → 1 phiếu thường ──
            new[] { "2", "310", "4500051710", "D62P118213", "2M210-M1K1-VP-MW", "8", "VN", "30", "20", "15", "5", "", "", "","08/10/2026" },

            // ── Box 3: hàng thường, 2 mã khác nhau → tách thành 2 phiếu ──
            new[] { "3", "210", "", "", "KX-DT321-V4", "40", "VN", "60", "40", "35", "12", "", "", "","08/10/2026" },
            new[] { "3", "210", "", "", "KX-DT343-V4", "20", "VN", "60", "40", "35", "12", "", "", "","08/10/2026" },
        },
        FooterNote = L["PartCardCsv.Footer"],
    };

    // Validate + dựng 1 dòng import từ CSV.
    public static CsvBindResult<PartCardImportRow> Bind(CsvRowAccessor row, IStringLocalizer L)
    {
        var errs = new List<string>();

        var box = row.Get("box");
        var category = row.Get("category");
        var poNo = row.Get("po_no");
        var model = row.Get("model");
        var qty = row.Get("qty");
        var servicePart = row.Get("service_part");
        var originRaw = row.Get("origin");
        var date = row.Get("date");

        var isServicePart = IsTruthy(servicePart);

        if (string.IsNullOrWhiteSpace(box)) errs.Add(L["PartCardCsv.Err.BoxEmpty"]);
        if (string.IsNullOrWhiteSpace(model)) errs.Add(L["PartCardCsv.Err.ModelEmpty"]);

        // Category không bắt buộc — trống thì dùng mặc định; có thì phải là số.
        if (!string.IsNullOrWhiteSpace(category) && !int.TryParse(category.Trim(), out _))
            errs.Add(string.Format(L["PartCardCsv.Err.CategoryInvalid"], category));

        if (!string.IsNullOrWhiteSpace(qty) && !int.TryParse(qty.Trim(), out var qtyVal))
            errs.Add(string.Format(L["PartCardCsv.Err.QtyInvalid"], qty));
        else
        {
            qtyVal = string.IsNullOrWhiteSpace(qty) ? 0 : int.Parse(qty.Trim());
            // Hàng thường: phiếu chỉ có mã + số lượng nên số lượng bắt buộc > 0.
            if (!isServicePart && qtyVal <= 0)
                errs.Add(L["PartCardCsv.Err.QtyRequired"]);
        }

        // Xuất xứ: trống → mặc định VN; có thì phải là key 2 chữ trong danh sách.
        // {0} = giá trị nhập, {1} = danh sách key hợp lệ.
        var originCode = ResolveOrigin(originRaw);
        if (originCode is null)
            errs.Add(string.Format(L["PartCardCsv.Err.OriginInvalid"], originRaw.Trim(), OriginCodesHint));

        if (errs.Count > 0) return CsvBindResult<PartCardImportRow>.Invalid(errs);

        return CsvBindResult<PartCardImportRow>.Ok(new PartCardImportRow
        {
            BoxNo = box.Trim(),
            Category = category.Trim(),
            PoNo = poNo.Trim(),
            Date = date.Trim(),
            CustomerPoNo = row.Get("customer_po_no").Trim(),
            OuterLength = ReadDecimal(row, "length"),
            OuterWidth = ReadDecimal(row, "width"),
            OuterHeight = ReadDecimal(row, "height"),
            OuterWeight = ReadDecimal(row, "weight"),
            ServicePart = isServicePart,

            Model = model.Trim(),
            InnerBox = row.Get("inner_box").Trim(),
            OqcChecked = IsOqcChecked(row.Get("oqc_check")),
            Qty = string.IsNullOrWhiteSpace(qty) ? "" : qty.Trim(),
            Origin = originCode!,
        });
    }

    // Cột hiển thị trong bảng preview của dialog.
    public static IReadOnlyList<CsvPreviewColumn<PartCardImportRow>> BuildPreviewColumns(IStringLocalizer L) => new[]
    {
        new CsvPreviewColumn<PartCardImportRow> { Header = L["PartCardCsv.Preview.Box"],   Value = r => r.BoxNo },
        new CsvPreviewColumn<PartCardImportRow>
        {
            Header = L["PartCardCsv.Preview.Type"],
            Value  = r => r.ServicePart ? L["PartCardCsv.Type.Oversea"].Value : L["PartCardCsv.Type.Normal"].Value
        },
        new CsvPreviewColumn<PartCardImportRow> { Header = L["PartCardCsv.Preview.PoNo"],  Value = r => r.PoNo },
        new CsvPreviewColumn<PartCardImportRow> { Header = L["PartCardCsv.Preview.Model"], Value = r => r.Model },
        new CsvPreviewColumn<PartCardImportRow> { Header = L["PartCardCsv.Preview.Qty"],   Value = r => r.Qty },
        new CsvPreviewColumn<PartCardImportRow> { Header = L["PartCardCsv.Preview.Category"], Value = r => r.Category },
        new CsvPreviewColumn<PartCardImportRow> { Header = L["PartCardCsv.Preview.Inner"], Value = r => r.InnerBox },
        new CsvPreviewColumn<PartCardImportRow> { Header = L["PartCardCsv.Preview.Oqc"],   Value = r => r.OqcChecked ? OqcCheckedValue : "" },
    };

    // ── Gộp dòng CSV thành phiếu ─────────────────────────────
    // Bước 1: xác định thùng nào là oversea (có ít nhất 1 dòng service_part = Y).
    // Bước 2: gộp theo loại.
    //   • Oversea → gộp theo (PoNo + Box), mọi dòng thành inner box.
    //   • Thường  → gộp theo (PoNo + Box + Model), cộng dồn qty nếu trùng mã.
    // Giữ nguyên thứ tự xuất hiện trong file.
    public static List<PartCardModel> GroupIntoCards(IReadOnlyList<PartCardImportRow> rows)
    {
        var overseaBoxes = rows
            .Where(r => r.ServicePart)
            .Select(BoxKey)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);

        var cards = new List<PartCardModel>();
        var index = new Dictionary<string, PartCardModel>(StringComparer.OrdinalIgnoreCase);

        foreach (var r in rows)
        {
            var isOversea = overseaBoxes.Contains(BoxKey(r));

            // Thường: mỗi mã hàng là 1 phiếu riêng. Oversea: cả thùng là 1 phiếu.
            var key = isOversea
                ? $"SP|{BoxKey(r)}"
                : $"NM|{BoxKey(r)}|{r.Model}";

            if (!index.TryGetValue(key, out var card))
            {
                card = NewCard(r, isOversea);
                index[key] = card;
                cards.Add(card);
            }

            if (isOversea)
            {
                card.Rows.Add(new PartCardRow
                {
                    Model = r.Model,
                    InnerBox = r.InnerBox,
                    Qty = ParseInt(r.Qty),
                    Origin = r.Origin,
                    OqcChecked = r.OqcChecked,
                });
            }
            else
            {
                // Dòng trùng mã trong cùng thùng → cộng dồn số lượng.
                card.Qty = (card.Qty ?? 0) + ParseInt(r.Qty);
            }
        }

        // Phiếu oversea rỗng (không nên xảy ra) → giữ 1 dòng trống cho form.
        foreach (var c in cards)
            if (c.Rows.Count == 0) c.Rows.Add(new PartCardRow());

        return cards;
    }

    // ── Helpers ──────────────────────────────────────────────
    private static string BoxKey(PartCardImportRow r) => $"{r.PoNo}|{r.BoxNo}";

    private static PartCardModel NewCard(PartCardImportRow r, bool isOversea) => new()
    {
        BoxNo = r.BoxNo,
        Category = string.IsNullOrWhiteSpace(r.Category) ? 0 : ParseCategory(r.Category),
        PoNo = r.PoNo,
        CustomerPoNo = r.CustomerPoNo,
        ProductionDate = r.Date,
        // Kích thước ngoài lấy từ dòng đầu của thùng.
        Length = ToDec(r.OuterLength),
        Width = ToDec(r.OuterWidth),
        Height = ToDec(r.OuterHeight),
        Weight = ToDec(r.OuterWeight),
        Model = r.Model,
        // Qty cộng dồn ở vòng lặp (hàng thường); phiếu oversea dùng Rows.
        Qty = 0,
        Origin = r.Origin,
        IsOverseaService = isOversea,
        Rows = new List<PartCardRow>(),
    };

    // Validate key 2 chữ và trả về key đã chuẩn hoá VIẾT HOA ("cn" → "CN").
    // Trống → mặc định; key không có trong danh sách → null.
    // Tên đầy đủ ("China") KHÔNG được chấp nhận.
    private static string? ResolveOrigin(string? code)
    {
        var t = code?.Trim();
        if (string.IsNullOrEmpty(t)) return DefaultOriginCode;
        return OriginByCode.ContainsKey(t) ? t.ToUpperInvariant() : null;
    }

    // Key 2 chữ → tên đầy đủ để hiển thị/in ("CN" → "China").
    // Không khớp (vd. dữ liệu cũ đã lưu sẵn tên) thì trả nguyên giá trị.
    public static string OriginNameOf(string? code)
    {
        var t = code?.Trim() ?? "";
        return OriginByCode.TryGetValue(t, out var name) ? name : t;
    }

    // Parse số thập phân từ CSV/Excel: chấp nhận "18.25" và "18,25".
    // KHÔNG hỗ trợ dấu hàng nghìn (kích thước/cân nặng không cần) —
    // nhờ vậy không bao giờ hiểu nhầm 18,25 → 1825.
    private static bool TryParseDec(string? s, out decimal v)
    {
        v = 0m;
        if (string.IsNullOrWhiteSpace(s)) return false;

        var t = s.Trim().Replace(" ", "").Replace(',', '.');
        if (t.Count(c => c == '.') > 1) return false;   // "1.234.5" → không hợp lệ

        return decimal.TryParse(
            t,
            NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign,
            CultureInfo.InvariantCulture,
            out v);
    }

    private static decimal ToDec(string? s)
        => TryParseDec(s, out var v) ? v : 0m;

    // Trống hoặc sai → ""; hợp lệ → chuỗi chuẩn dấu chấm ("18,25" → "18.25").
    private static string ReadDecimal(CsvRowAccessor row, string key)
        => TryParseDec(row.Get(key), out var v)
            ? v.ToString(CultureInfo.InvariantCulture)
            : "";

    private static int ParseCategory(string s)
        => int.TryParse(s?.Trim(), out var v) ? v : DefaultCategory;

    private static int ParseInt(string s)
        => int.TryParse(s?.Trim(), out var v) ? v : 0;

    // Chỉ đúng giá trị "ASSY" (không phân biệt hoa thường) mới tính là đã OQC check.
    private static bool IsOqcChecked(string? s)
        => string.Equals(s?.Trim(), OqcCheckedValue, StringComparison.OrdinalIgnoreCase);

    private static bool IsTruthy(string s)
        => !string.IsNullOrWhiteSpace(s)
           && ServicePartTruthy.Contains(s.Trim(), StringComparer.OrdinalIgnoreCase);
}