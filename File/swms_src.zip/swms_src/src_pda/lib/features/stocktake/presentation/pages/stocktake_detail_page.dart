import 'dart:async';
import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/stocktake/domain/entities/stocktake_entities.dart';
import 'package:swms_finish_goods/features/stocktake/presentation/providers/stocktake_providers.dart';
import 'package:swms_finish_goods/features/stocktake/presentation/widgets/stocktake_count_sheet.dart';

/// Chi tiết 1 phiếu: quét mã vị trí + ĐẾM INLINE (không bottom sheet -> ô scan luôn giữ focus).
@RoutePage()
class StocktakeDetailPage extends ConsumerStatefulWidget {
  final int id;

  const StocktakeDetailPage({super.key, required this.id});

  @override
  ConsumerState<StocktakeDetailPage> createState() =>
      _StocktakeDetailPageState();
}

class _StocktakeDetailPageState extends ConsumerState<StocktakeDetailPage> {
  final _scanKey = GlobalKey<_ScanBoxState>();
  final _scroll = ScrollController();

  /// Ô chưa đếm kế tiếp lần gần nhất đã cuộn tới — đổi thì cuộn lại.
  String? _lastNext;

  // Chiều cao cố định để tính được vị trí cuộn chính xác.
  static const double _itemH = 80;    // thẻ 72 + lề dưới 8
  static const double _headerH = 34;  // tiêu đề khu

  @override
  void dispose() {
    _scroll.dispose();
    super.dispose();
  }

  /// Cuộn sao cho ô kế tiếp nằm gần đầu danh sách (chừa một ô phía trên để thấy ô vừa xong).
  void _scrollToOffset(double offset) {
    if (!_scroll.hasClients) return;
    final target = (offset - _itemH).clamp(0.0, _scroll.position.maxScrollExtent);
    _scroll.animateTo(target,
        duration: const Duration(milliseconds: 350), curve: Curves.easeOutCubic);
  }

  /// Tấm đếm đang mở: mã quét thuộc về tấm đếm (vd mã pallet phát sinh), trang bỏ qua.
  bool _sheetOpen = false;

  void _onScan(String code) {
    if (_sheetOpen) return;
    if (code.trim().isEmpty) {
      _scanKey.currentState?.refocus();
      return;
    }
    _openLocation(code.trim());
  }

  Future<void> _openLocation(String locator) async {
    final d = ref.read(stocktakeDetailProvider(widget.id)).value;
    if (d == null) return;
    final match = d.lines
        .where((l) => l.locatorCode.toUpperCase() == locator.toUpperCase())
        .toList();
    if (match.isEmpty) {
      AppToastHelper.toastInfo(
        context,
        LocaleKeys.stocktake_locator_not_in_sheet.tr(),
      );
      return;
    }
    _sheetOpen = true;
    bool? changed;
    try {
      changed = await showModalBottomSheet<bool>(
        context: context,
        isScrollControlled: true,
        backgroundColor: Colors.transparent,
        builder: (_) => StocktakeCountSheet(countId: widget.id, lines: match),
      );
    } finally {
      _sheetOpen = false;
    }
    if (changed == true) ref.invalidate(stocktakeDetailProvider(widget.id));
  }

  Future<void> _closeSheet(CountDetail d) async {
    final ok = await showDialog<bool>(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(LocaleKeys.stocktake_close_title.tr()),
        content: Text(LocaleKeys.stocktake_close_confirm.tr()),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: Text(LocaleKeys.common_cancel.tr()),
          ),
          FilledButton(
            onPressed: () => Navigator.pop(context, true),
            child: Text(LocaleKeys.stocktake_close_yes.tr()),
          ),
        ],
      ),
    );
    if (ok != true) return;
    try {
      await ref.read(stocktakeRepositoryProvider).closeCount(widget.id);
      if (mounted) {
        AppToastHelper.toastInfo(
          context,
          LocaleKeys.stocktake_closed_toast.tr(),
        );
        if (!context.mounted) return;
        await context.router.maybePop();
      }
    } catch (e) {
      if (mounted) {
        AppToastHelper.toastError(context, e.toString());
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(stocktakeDetailProvider(widget.id));
    return Scaffold(
      resizeToAvoidBottomInset: true,
      appBar: AppBar(title: Text(LocaleKeys.stocktake_title.tr())),
      body: async.when(
        skipLoadingOnReload: true,
        loading: () => const Center(child: CircularProgressIndicator()),
        error: (e, _) => Center(
          child: Padding(padding: const EdgeInsets.all(24), child: Text('$e')),
        ),
        data: (d) {
          final grouped = <String, List<CountLine>>{};
          for (final l in d.lines) {
            grouped.putIfAbsent(l.locatorCode, () => []).add(l);
          }
          // Thứ tự đi theo bản đồ (server tính sẵn) — CỐ ĐỊNH, ô đếm xong không di chuyển
          // để công nhân không mất vị trí; chỉ mờ đi tại chỗ.
          int seqOf(String code) =>
              grouped[code]!.map((l) => l.walkSeq).reduce((a, b) => a < b ? a : b);
          // Cùng thứ tự đi (hoặc chưa có toạ độ trên bản đồ) thì so tự nhiên:
          // A1-2-1 đứng trước A1-10-1, không so chuỗi thuần.
          final locators = grouped.keys.toList()
            ..sort((a, b) {
              final c = seqOf(a).compareTo(seqOf(b));
              return c != 0 ? c : _naturalCompare(a, b);
            });

          // Dựng danh sách hiển thị: chèn tiêu đề mỗi khi sang khu mới.
          final rows = <_Row>[];
          var y = 0.0;
          String? curArea;
          final multiArea = grouped.values
              .map((ls) => ls.first.areaCode)
              .toSet()
              .length > 1;
          for (final code in locators) {
            final area = grouped[code]!.first.areaName ?? grouped[code]!.first.areaCode;
            if (multiArea && area != curArea) {
              rows.add(_Row(area: area ?? '—', offset: y));
              y += _headerH;
              curArea = area;
            }
            rows.add(_Row(code: code, offset: y));
            y += _itemH;
          }

          // Ô chưa đếm kế tiếp theo thứ tự đi
          final nextCode = locators.firstWhere(
            (c) => !grouped[c]!.every((l) => l.isCounted),
            orElse: () => '',
          );
          if (nextCode.isNotEmpty && nextCode != _lastNext) {
            _lastNext = nextCode;
            final off = rows.firstWhere((r) => r.code == nextCode).offset;
            WidgetsBinding.instance.addPostFrameCallback((_) => _scrollToOffset(off));
          }
          final locked = d.header.docStatus == 'closed';
          final allCounted =
              d.header.countedLines == d.header.totalLines &&
              d.header.totalLines > 0;

          return Column(
            children: [
              _Header(header: d.header),
              if (!locked) _ScanBox(key: _scanKey, onScan: _onScan),
              // Danh sách vị trí + khu vực đếm inline (cuộn chung để không tràn khi bàn phím bung)
              Expanded(
                child: Column(
                  children: [
                    const _QtyHeader(),
                    Expanded(
                      child: ListView.builder(
                  controller: _scroll,
                  padding: EdgeInsets.fromLTRB(
                    12,
                    4,
                    12,
                    MediaQuery.of(context).viewInsets.bottom + 24,
                  ),
                  itemCount: rows.length,
                  itemBuilder: (_, i) {
                    final r = rows[i];

                    // Tiêu đề khu
                    if (r.code == null) {
                      return SizedBox(
                        height: _headerH,
                        child: Align(
                          alignment: Alignment.bottomLeft,
                          child: Padding(
                            padding: const EdgeInsets.only(left: 4, bottom: 6),
                            child: Text(
                              r.area!.toUpperCase(),
                              style: const TextStyle(
                                fontSize: 11,
                                fontWeight: FontWeight.w800,
                                letterSpacing: .5,
                                color: Color(0xFF6B7C8E),
                              ),
                            ),
                          ),
                        ),
                      );
                    }

                    final code = r.code!;
                    final lines = grouped[code]!;
                    final counted = lines.where((l) => l.isCounted).length;
                    final total = lines.length;
                    final diff = lines.where((l) => l.isDiscrepancy).length;
                    final found = lines.where((l) => l.isFound).length;
                    final emptyOnly = lines.every((l) => l.isEmptySlot);
                    final done = counted == total;
                    final isNext = code == nextCode;
                    final order = locators.indexOf(code) + 1;

                    return SizedBox(
                      height: _itemH,
                      child: Padding(
                        padding: const EdgeInsets.only(bottom: 8),
                        child: Opacity(
                          // Đếm xong: mờ đi tại chỗ, không di chuyển
                          opacity: done ? 0.45 : 1,
                          child: Card(
                            margin: EdgeInsets.zero,
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(12),
                              side: isNext
                                  ? const BorderSide(color: Color(0xFF2E8650), width: 2)
                                  : BorderSide.none,
                            ),
                            child: Center(
                              child: ListTile(
                                visualDensity: VisualDensity.compact,
                                // BẮT BUỘC scan vị trí mới mở đếm (không cho tap chọn)
                                leading: CircleAvatar(
                                  radius: 18,
                                  backgroundColor: done
                                      ? const Color(0xFFDFF0E4)
                                      : isNext
                                          ? const Color(0xFF2E8650)
                                          : const Color(0xFFF1F4F7),
                                  child: done
                                      ? const Icon(Icons.check,
                                          size: 18, color: Color(0xFF2E8650))
                                      : Text(
                                          '$order',
                                          style: TextStyle(
                                            fontSize: 12,
                                            fontWeight: FontWeight.w800,
                                            color: isNext ? Colors.white : Colors.black54,
                                          ),
                                        ),
                                ),
                                // Mã vị trí chiếm hết chiều ngang: mã lưu kho dài
                                // (1.B13A.2.04) không còn bị nhãn nào che. Ô kế tiếp
                                // đã nhận ra được nhờ viền xanh + số thứ tự nền xanh.
                                title: Text(
                                  code,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontWeight: FontWeight.w700),
                                ),
                                subtitle: Text(
                                  // Ô trống (kiểm cuối tháng theo ô): chỉ cần xác nhận trống
                                  emptyOnly
                                      ? (done
                                          ? LocaleKeys.stocktake_empty_confirmed.tr()
                                          : LocaleKeys.stocktake_empty_todo.tr())
                                      : '$counted/$total ${LocaleKeys.stocktake_counted_word.tr()}'
                                        '${diff > 0 ? " · $diff ${LocaleKeys.stocktake_diff_short.tr()}" : ""}'
                                        '${found > 0 ? " · ${LocaleKeys.stocktake_found_count.tr(args: ["$found"])}" : ""}',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: found > 0 ? const Color(0xFFB26A00) : null,
                                  ),
                                ),
                                trailing: _QtyCells(lines: lines),
                              ),
                            ),
                          ),
                        ),
                      ),
                    );
                  },
                      ),
                    ),
                  ],
                ),
              ),
              if (!locked)
                SafeArea(
                  child: Padding(
                    padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
                    child: SizedBox(
                      width: double.infinity,
                      child: FilledButton.icon(
                        onPressed: allCounted ? () => _closeSheet(d) : null,
                        icon: const Icon(Icons.lock_outline),
                        label: Text(
                          allCounted
                              ? LocaleKeys.stocktake_close_action.tr()
                              : LocaleKeys.stocktake_close_disabled.tr(),
                        ),
                      ),
                    ),
                  ),
                ),
            ],
          );
        },
      ),
    );
  }
}

/// FocusNode giữ focus nhưng KHÔNG yêu cầu bàn phím ảo (scanner = bàn phím vật lý).
/// Ô quét mã — dùng BarcodeScannerButton (UI chuẩn dự án) + nghe scanStream (Zebra DataWedge).
/// Không phụ thuộc TextField/focus/bàn phím ảo.
class _ScanBox extends ConsumerStatefulWidget {
  final ValueChanged<String> onScan;

  const _ScanBox({super.key, required this.onScan});

  @override
  ConsumerState<_ScanBox> createState() => _ScanBoxState();
}

class _ScanBoxState extends ConsumerState<_ScanBox> {
  StreamSubscription<String>? _sub;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      final code = data.trim();
      if (code.isNotEmpty) widget.onScan(code);
    });
  }

  /// Giữ nguyên API để page gọi qua GlobalKey (no-op vì không cần refocus).
  void refocus() {}

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
      child: BarcodeScannerButton(
        scanningLabel: LocaleKeys.stocktake_scan_locator.tr(),
      ),
    );
  }
}

class _Header extends StatelessWidget {
  final CountSummary header;

  const _Header({required this.header});

  @override
  Widget build(BuildContext context) {
    final pct = (header.progress * 100).round();
    return Container(
      color: const Color(0xFFF7F9FB),
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            header.docNo,
            style: const TextStyle(fontWeight: FontWeight.w800, fontSize: 15),
          ),
          const SizedBox(height: 2),
          Text(
            '${header.countedLines}/${header.totalLines} ${LocaleKeys.stocktake_counted_word.tr()} · $pct%',
            style: const TextStyle(fontSize: 12, color: Colors.black54),
          ),
          const SizedBox(height: 8),
          ClipRRect(
            borderRadius: BorderRadius.circular(999),
            child: LinearProgressIndicator(
              value: header.progress,
              minHeight: 6,
              backgroundColor: const Color(0xFFEEF2F6),
              valueColor: const AlwaysStoppedAnimation(Color(0xFF2E8650)),
            ),
          ),
        ],
      ),
    );
  }
}

/// Một dòng của danh sách kiểm kê: tiêu đề khu (area) hoặc một vị trí (code).
class _Row {
  final String? area;
  final String? code;
  final double offset;   // vị trí dọc trong danh sách, để cuộn tới
  const _Row({this.area, this.code, required this.offset});
}

final _naturalToken = RegExp(r'\d+|\D+');

/// So sánh "tự nhiên": đoạn số so theo giá trị, đoạn chữ so theo chuỗi.
/// A1-2-1 < A1-10-1;  1.B12A.3.02 < 1.B12A.3.10.
int _naturalCompare(String a, String b) {
  final ta = _naturalToken.allMatches(a).map((m) => m.group(0)!).toList();
  final tb = _naturalToken.allMatches(b).map((m) => m.group(0)!).toList();
  for (var i = 0; i < ta.length && i < tb.length; i++) {
    final na = int.tryParse(ta[i]);
    final nb = int.tryParse(tb[i]);
    final c = (na != null && nb != null) ? na.compareTo(nb) : ta[i].compareTo(tb[i]);
    if (c != 0) return c;
  }
  return ta.length.compareTo(tb.length);
}

/// Bề rộng mỗi cột số — tiêu đề và từng dòng dùng chung để thẳng cột.
const double _qtyColW = 46;

/// Tiêu đề 3 cột số của danh sách kiểm kê.
class _QtyHeader extends StatelessWidget {
  const _QtyHeader();

  @override
  Widget build(BuildContext context) {
    Widget cell(String t) => SizedBox(
          width: _qtyColW,
          child: Text(
            t,
            textAlign: TextAlign.right,
            style: const TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: Color(0xFF6B7C8E),
            ),
          ),
        );
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 2, 28, 4),
      child: Row(
        children: [
          Expanded(
            child: Text(
              LocaleKeys.stocktake_locator_word.tr().toUpperCase(),
              style: const TextStyle(
                fontSize: 10,
                fontWeight: FontWeight.w800,
                letterSpacing: .5,
                color: Color(0xFF6B7C8E),
              ),
            ),
          ),
          cell(LocaleKeys.stocktake_qty_system_head.tr()),
          cell(LocaleKeys.stocktake_qty_count_head.tr()),
          cell(LocaleKeys.stocktake_qty_diff_head.tr()),
        ],
      ),
    );
  }
}

/// 3 con số của một vị trí: tổng hệ thống, tổng thực tế đã đếm, chênh lệch.
class _QtyCells extends StatelessWidget {
  final List<CountLine> lines;
  const _QtyCells({required this.lines});

  @override
  Widget build(BuildContext context) {
    final sys = lines.fold<int>(0, (a, l) => a + l.qtySystem);
    final countedLines = lines.where((l) => l.isCounted).toList();
    final hasCount = countedLines.isNotEmpty;
    // Chỉ cộng phần đã đếm; chưa đếm dòng nào thì để trống thay vì hiện 0.
    final cnt = countedLines.fold<int>(0, (a, l) => a + (l.qtyCount ?? 0));
    final sysOfCounted = countedLines.fold<int>(0, (a, l) => a + l.qtySystem);
    final diff = cnt - sysOfCounted;

    Widget cell(String t, {Color? color, FontWeight weight = FontWeight.w600}) => SizedBox(
          width: _qtyColW,
          child: Text(
            t,
            textAlign: TextAlign.right,
            style: TextStyle(fontSize: 13, fontWeight: weight, color: color),
          ),
        );

    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        cell('$sys', color: const Color(0xFF5A6B7D)),
        cell(hasCount ? '$cnt' : '—'),
        cell(
          hasCount ? (diff > 0 ? '+$diff' : '$diff') : '—',
          color: diff == 0 ? const Color(0xFF5A6B7D) : const Color(0xFFC62828),
          weight: diff == 0 ? FontWeight.w600 : FontWeight.w800,
        ),
      ],
    );
  }
}
