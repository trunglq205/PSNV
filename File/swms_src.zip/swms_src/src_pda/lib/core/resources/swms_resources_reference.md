# SWMS Finish Goods — Tổng hợp Resources (Design Tokens / Theme)

> Tài liệu tham chiếu nhanh cho toàn bộ resource trong `core/resources/`.
> Import gọn qua: `import 'package:swms_finish_goods/core/resources/resources.dart';`
> (file `resources.dart` re-export tất cả: app_colors, app_dimens, app_shadows, app_text_styles, app_theme, theme_extension)

---

## 1. Kiến trúc theme

- **`AppColors`** — màu raw (hằng số), dịch trực tiếp từ `tokens.css`. **Widget KHÔNG gọi trực tiếp**, đọc qua Theme / ThemeExtension.
- **`SwmsColors` (ThemeExtension)** — gói các token không vừa với `ColorScheme` chuẩn (tint, semantic bg, thang chữ 4 cấp, border…). Tự đổi theo light/dark. Đọc qua `context.swms.<token>`.
- **`AppTheme`** — dựng `ThemeData` light & dark từ token, gắn `SwmsColors` vào `extensions`.
- **`ThemeModeNotifier`** (Riverpod, keepAlive) — giữ `ThemeMode` runtime (`themeModeProvider`).

```dart
// Cách đọc trong widget
final c = context.swms;          // SwmsColors theo light/dark
Container(color: c.successBg);
Text('...', style: Theme.of(context).textTheme.titleLarge);

// Đổi theme
ref.read(themeModeProvider.notifier).toggle();
ref.read(themeModeProvider.notifier).set(ThemeMode.dark);
```

---

## 2. Màu — `AppColors`

### Primary (blue)
| Token | Hex | Ghi chú |
|---|---|---|
| `primary` | `#0F6CBD` | màu chính |
| `primaryDark` | `#115EA3` | |
| `primaryLight` | `#2886DE` | |
| `primaryTint` | `#E5F1FB` | |
| `primaryTint2` | `#CFE4F7` | |

### Semantic (light)
| Token | Hex | | Token | Hex |
|---|---|---|---|---|
| `success` | `#2E7D32` | | `successBg` | `#E8F5E9` |
| `warning` | `#E65100` | | `warningBg` | `#FFF3E0` |
| `danger` | `#C62828` | | `dangerBg` | `#FFEBEE` |

### Neutral / Surface (light)
| Token | Hex | Token | Hex |
|---|---|---|---|
| `bg` | `#F5F7FA` | `card` | `#FFFFFF` |
| `card2` | `#FAFBFC` | `border` | `#E5E7EB` |
| `border2` | `#D1D5DB` | | |
| `text1` | `#1A1A2E` | `text2` | `#4B5563` |
| `text3` | `#6B7280` | `text4` | `#9CA3AF` |

### Accent palette (phân loại entity khi quét)
| Nhóm | base | tint | fg |
|---|---|---|---|
| Blue | `#1976D2` | `#E3F2FD` | `#0D47A1` |
| Orange | `#E65100` | `#FFF3E0` | `#BF360C` |
| Purple | `#7B1FA2` | `#F3E5F5` | `#4A148C` |
| Teal | `#00838F` | `#E0F2F1` | `#006064` |

### Dark theme overrides
| Token | Hex | Token | Hex |
|---|---|---|---|
| `darkBg` | `#0F172A` | `darkCard` | `#1E293B` |
| `darkCard2` | `#243049` | `darkBorder` | `#334155` |
| `darkBorder2` | `#475569` | | |
| `darkText1` | `#F1F5F9` | `darkText2` | `#CBD5E1` |
| `darkText3` | `#94A3B8` | `darkText4` | `#64748B` |

### SwmsColors riêng cho dark (alpha overrides)
| Token | Giá trị | Tương đương |
|---|---|---|
| `primaryTint` | `0x330F6CBD` | rgba(15,108,189, .20) |
| `primaryTint2` | `0x520F6CBD` | rgba(15,108,189, .32) |
| `successBg` | `0x2E2E7D32` | success @ ~18% |
| `warningBg` | `0x2EE65100` | warning @ ~18% |
| `dangerBg` | `0x33C62828` | danger @ ~20% |

---

## 3. Kích thước — `AppDimens`

### Spacing
| Token | px | | Token | px |
|---|---|---|---|---|
| `xs` | 4 | | `lg` | 24 |
| `sm` | 8 | | `xl` | 32 |
| `md` | 16 | | | |

### Radius (PDA · bo góc lớn, mềm)
| Token | px | Dùng cho |
|---|---|---|
| `rCard` | 14 | thẻ |
| `rBtn` | 12 | nút |
| `rInput` | 10 | ô nhập |

### Touch targets (TC25 glove-friendly)
| Token | px | Dùng cho |
|---|---|---|
| `hitSm` | 36 | nhỏ |
| `hitMd` | 44 | mục bấm tối thiểu |
| `hitLg` | 52 | CTA chính cuối màn |

### Density
| Token | px | Ghi chú |
|---|---|---|
| `rowH` | 44 | chiều cao hàng |
| `rowHCompact` | 36 | khi `data-density="compact"` |

---

## 4. Đổ bóng — `AppShadows`

| Token | Mô tả |
|---|---|
| `s1` | bóng nhẹ (offset 0–1, blur 2–3) |
| `s2` | bóng vừa (offset 2–4, blur 4–6) |
| `s4` | bóng nổi (offset 4–10, blur 6–15) |

Mỗi token là `List<BoxShadow>` (2 layer), dùng cho `BoxDecoration(boxShadow: ...)`.

---

## 5. Kiểu chữ — `AppTextStyles`

Font: **Inter** (`sans`) + **JetBrains Mono** (`mono`, dùng cho mã quét).

| Token | Size | Weight | Height | Dùng cho |
|---|---|---|---|---|
| `h1` | 21 | w800 | 1.25 | tiêu đề lớn |
| `h2` | 17 | w700 | 1.3 | tiêu đề phụ |
| `title` | 15 | w600 | 1.3 | tiêu đề mục |
| `body` | 13 | w400 | 1.45 | nội dung |
| `bodyStrong` | 13 | w600 | 1.45 | nội dung nhấn |
| `label` | 12 | w600 | 1.2 | nhãn / nút |
| `caption` | 10 | w500 | 1.4 | chú thích |
| `code` | 14 (mono) | w500 | 1.3 | mã vạch/pallet, hoa, `letterSpacing 1.2` |

### Map vào TextTheme (trong AppTheme)
| Material slot | AppTextStyle | Màu |
|---|---|---|
| `headlineLarge` | h1 | text1 |
| `headlineMedium` | h2 | text1 |
| `titleLarge` | title | text1 |
| `bodyLarge` | body | text1 |
| `bodyMedium` | body | text2 |
| `labelLarge` | label | text1 |
| `bodySmall` | caption | text3 |

---

## 6. Component theme (AppTheme — đã cấu hình sẵn)

| Component | Cấu hình chính |
|---|---|
| **Input** | filled, fill = card/darkCard; bo `rInput` (10); enabled border = `border`, default = `border2`; focused = primary width 2; error = danger; padding `md` (16) |
| **FilledButton** | cao `hitMd` (44), bo `rBtn` (12), textStyle = label |
| **Card** | màu card/darkCard, elevation 0, bo `rCard` (14), viền `border` |
| **AppBar** | nền `bg`, foreground `text1`, elevation 0, không center title, title style = `title` |
| **Divider** | màu `border` |
| **ColorScheme** | `fromSeed(primary)`, error = danger, surface = card; `surfaceContainerLowest` = bg |

---

*Cập nhật khi sửa file trong `core/resources/`. Nguồn gốc token: `tokens.css` (surface PDA).*
