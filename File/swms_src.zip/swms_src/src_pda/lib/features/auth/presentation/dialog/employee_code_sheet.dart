import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:pin_code_fields/pin_code_fields.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_bottom_sheet.dart';

/// Mở bottom sheet đăng nhập bằng mã nhân viên (7 ký tự).
Future<String?> showEmployeeCodeSheet(BuildContext context) {
  return showAppBottomSheet<String>(
    context,
    builder: (_) => const _EmployeeCodeSheet(),
  );
}

class _EmployeeCodeSheet extends StatefulWidget {
  const _EmployeeCodeSheet();

  @override
  State<_EmployeeCodeSheet> createState() => _EmployeeCodeSheetState();
}

class _EmployeeCodeSheetState extends State<_EmployeeCodeSheet> {
  static const int _length = 7;

  final PinInputController _pin = PinInputController();

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      _pin.requestFocus();
    });
    _pin.addListener(_keepKeyboard);
  }

  void _keepKeyboard() {
    if (!_pin.hasFocus && mounted) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted) _pin.requestFocus();
      });
    }
  }

  @override
  void dispose() {
    _pin.removeListener(_keepKeyboard);
    _pin.dispose();
    super.dispose();
  }

  void _submit(String code) {
    if (code.length == _length) {
      _pin.unfocus();
      Navigator.of(context).pop(code);
    }
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppBottomSheet(
      leading: const _BadgeIcon(),
      title: LocaleKeys.login_employee_code_title.tr(),
      subtitle: LocaleKeys.login_employee_code_subtitle.tr(),
      // Nhập xong là tự đóng -> không có thanh nút đáy.
      bodyPadding: const EdgeInsets.fromLTRB(
        AppDimens.md,
        AppDimens.md,
        AppDimens.md,
        AppDimens.sm,
      ),
      // Nhả focus trước khi pop, tránh bàn phím nhấp nháy lúc sheet đóng.
      onClose: () {
        _pin.removeListener(_keepKeyboard);
        _pin.unfocus();
        Navigator.of(context).pop();
      },
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          MaterialPinField(
            length: _length,
            pinController: _pin,
            autoFocus: true,
            inputFormatters: [FilteringTextInputFormatter.digitsOnly],
            theme: MaterialPinTheme(
              cellSize: const Size(40, 50),
              borderRadius: BorderRadius.circular(10),
              focusedBorderWidth: 1.5,
              textStyle: AppTextStyles.code.copyWith(
                fontSize: 24,
                fontWeight: FontWeight.w700,
                letterSpacing: 0,
                color: swms.text1,
              ),
              // borders
              borderColor: swms.border2,
              focusedBorderColor: swms.primary,
              filledBorderColor: swms.primary,
              // fills — đồng nhất nền sheet
              fillColor: swms.card,
              focusedFillColor: swms.card,
              filledFillColor: swms.card,
              // cursor
              cursorColor: swms.primary,
              // tắt shake mặc định nếu không dùng error
              enableErrorShake: false,
            ),
            onCompleted: _submit,
          ),
          const SizedBox(height: AppDimens.sm),
          Text(
            LocaleKeys.login_employee_code_hint.tr(),
            textAlign: TextAlign.center,
            style: AppTextStyles.body.copyWith(color: swms.text2),
          ),
          const SizedBox(height: 2),
          Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: LocaleKeys.login_example.tr(),
                  style: AppTextStyles.body.copyWith(color: swms.text3),
                ),
                TextSpan(
                  text: '2015701',
                  style: AppTextStyles.code.copyWith(
                    fontWeight: FontWeight.w700,
                    letterSpacing: 0,
                    color: swms.primary,
                  ),
                ),
              ],
            ),
            textAlign: TextAlign.center,
          ),
        ],
      ),
    );
  }
}

/// Huy hiệu vuông bo góc, nền gradient xanh — dấu nhận biết màn đăng nhập.
class _BadgeIcon extends StatelessWidget {
  const _BadgeIcon();

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Container(
      width: 38,
      height: 38,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(10),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [AppColors.primaryLight, swms.primary],
        ),
      ),
      child: const Icon(Icons.badge_outlined, color: Colors.white, size: 20),
    );
  }
}