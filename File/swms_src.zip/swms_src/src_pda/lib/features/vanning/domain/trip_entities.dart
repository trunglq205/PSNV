import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';

/// Trạng thái chuyến xe. Mã khớp `status` của API (ShipmentTripService).
enum TripStatus {
  planned('planned', LocaleKeys.vanning_trip_status_planned),
  arrived('arrived', LocaleKeys.vanning_trip_status_arrived),
  sealed('sealed', LocaleKeys.vanning_trip_status_sealed),
  departed('departed', LocaleKeys.vanning_trip_status_departed),
  cancelled('cancelled', LocaleKeys.vanning_trip_status_cancelled);

  const TripStatus(this.code, this.labelKey);
  final String code;
  final String labelKey;

  /// Còn làm được trên bãi (chụp ảnh, gộp pallet).
  bool get isOpen => this == planned || this == arrived || this == sealed;

  /// Mã lạ coi như "đã đặt xe": vẫn cho mở xem, server tự chặn thao tác sai.
  static TripStatus fromCode(String? code) => values.firstWhere(
        (s) => s.code == code?.toLowerCase(),
        orElse: () => TripStatus.planned,
      );
}

/// container -> bộ ảnh FCL + kiểm cont; xe tải / xe máy -> bộ ảnh AIR / LCL.
enum TripVehicle {
  container('container', LocaleKeys.vanning_trip_vehicle_container),
  truck('truck', LocaleKeys.vanning_trip_vehicle_truck),
  motorbike('motorbike', LocaleKeys.vanning_trip_vehicle_motorbike);

  const TripVehicle(this.code, this.labelKey);
  final String code;
  final String labelKey;

  static TripVehicle fromCode(String? code) => values.firstWhere(
        (v) => v.code == code?.toLowerCase(),
        orElse: () => TripVehicle.truck,
      );
}

class TripItem {
  final int id;
  final String tripNo;
  final TripVehicle vehicle;
  final String? plateNo;
  final String? containerNo;
  final String? containerSize;
  final String? sealNo;
  final String? forwarderCode;
  final DateTime? plannedArrivalAt;
  final TripStatus status;
  final List<String> siNos;
  final int pallets;

  const TripItem({
    required this.id,
    required this.tripNo,
    required this.vehicle,
    this.plateNo,
    this.containerNo,
    this.containerSize,
    this.sealNo,
    this.forwarderCode,
    this.plannedArrivalAt,
    required this.status,
    this.siNos = const [],
    this.pallets = 0,
  });

  bool get isContainer => vehicle == TripVehicle.container;

  /// Số hiện to nhất: container -> số cont, xe tải -> biển số.
  String get mainNo =>
      (isContainer ? containerNo ?? plateNo : plateNo) ?? tripNo;

  /// So khớp khi quét: số cont (QR cửa cont), biển số hoặc mã chuyến; bỏ gạch / chấm / khoảng trắng.
  bool matches(String code) {
    final c = _norm(code);
    if (c.isEmpty) return false;
    return [containerNo, plateNo, tripNo]
        .whereType<String>()
        .any((v) => _norm(v) == c);
  }

  static String _norm(String v) =>
      v.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
}
