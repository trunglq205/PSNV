import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_pick_dialog.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_origin.dart';

/// Mở dialog chọn Origin. Trả về null nếu huỷ.
Future<PartCardOrigin?> showPickOriginDialog(
  BuildContext context, {
  PartCardOrigin? selected,
}) async {
  return await showPickDialog<PartCardOrigin>(
    context,
    title: 'Origin',
    items: PartCardOrigin.values,
    labelOf: (o) => '${o.code} - ${o.label}',
    selected: selected,
  );
}
