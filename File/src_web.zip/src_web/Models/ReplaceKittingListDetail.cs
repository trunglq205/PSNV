﻿namespace SWMS_WebTool.Models
{
    public class ReplaceKittingListDetail
    {
        public long MaterialId { get; set; }
        public string Material { get; set; }
        public double Quantity { get; set; }
        public string MaterialReplace { get; set; }
        public double QuantityReplace { get; set; }
    }
}
