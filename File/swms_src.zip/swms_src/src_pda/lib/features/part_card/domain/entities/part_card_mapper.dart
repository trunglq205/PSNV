import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_line.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_origin.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';

/// Đổi tem ĐÃ IN ([PartCard] đọc từ payload) sang dữ liệu phiếu.
///
/// Dùng chung cho Sửa / Tách / Gộp — trước đây nằm rải trong notifier màn in.
abstract final class PartCardMapper {
  static String normModel(String model) => model.trim().toUpperCase();

  /// Số thùng của 1 mã trên tem; tem cũ không ghi → 1.
  static int boxOf(PartModel m) => m.cartonQty > 0 ? m.cartonQty : 1;

  /// Payload không ghi layout nên suy ra: nhiều dòng / có PO / dòng đầu nhiều
  /// thùng / Cate gom mã ⇒ nhiều mã. Đoán sai thì user đổi bằng switch.
  static PartCardMode modeOf(PartCard card) {
    final multi =
        card.models.length > 1 ||
        card.models.first.cartonQty > 1 ||
        card.psnvPo.trim().isNotEmpty ||
        card.customerPo.trim().isNotEmpty ||
        partCardMultiCategories.contains(card.category.value);
    return multi ? PartCardMode.multi : PartCardMode.single;
  }

  /// 1 dòng mã của tem (giữ số thùng của tem).
  static PartCardLine lineOf(PartModel m) =>
      PartCardLine.empty(normModel(m.model)).copyWith(
        box: boxOf(m),
        quantity: m.quantity,
        origin: PartCardOrigin.tryParse(m.country),
      );

  /// Dựng phiếu từ tem. Chế độ 1 mã: chỉ dòng đầu, `box` = 1.
  static PartCardForm formOf(PartCard card, PartCardMode mode) {
    final first = card.models.first;

    // Dim / Weight có thể nằm ở cấp card (DIM= / WT=) hoặc cấp dòng model.
    // Không đọc được → để trống, form sẽ báo thiếu cho user nhập.
    final dim =
        parseDimension(card.dimension) ?? parseDimension(first.dimension);
    final weight = card.weight > 0 ? card.weight : first.weight;

    var form = PartCardForm.empty(model: normModel(first.model), mode: mode)
        .copyWith(
          category: card.category,
          productionDate: card.productionDate,
          psnvPo: card.psnvPo.trim(),
          cusPo: card.customerPo.trim(),
          length: dim?[0],
          width: dim?[1],
          height: dim?[2],
          weight: weight > 0 ? weight : null,
          quantity: first.quantity,
          origin: PartCardOrigin.tryParse(first.country),
        );

    if (mode.isSingle) return form;

    form = form.updateLineAt(0, form.lines.first.copyWith(box: boxOf(first)));
    for (final m in card.models.skip(1)) {
      if (!form.canAddLine) break;
      form = form.addLine(lineOf(m));
    }
    return form;
  }
}
