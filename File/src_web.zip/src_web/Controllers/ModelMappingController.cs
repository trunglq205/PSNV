﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using System.Data;
using Microsoft.EntityFrameworkCore;

namespace SWMS_WebTool.Controllers
{
    public class ModelMappingController : BaseController
    {
        private readonly ApiService _apiService;

        public ModelMappingController(ApiService apiService)
        {
            _apiService = apiService;
        }
        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] ModelMappingFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new ModelMappingFilter();
                int total = 10;
                IEnumerable<ModelMapping> items = new List<ModelMapping>();
                var responseData = await _apiService.GetDataModelMapping(_filter, pageNumber, _pageSize);
                total = responseData.TotalRecord;
                items = responseData.Records ?? new List<ModelMapping>();
                var model = new ModelMappingViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,

                };
                return View("Views/ModelMapping/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpGet]
        public IActionResult CreateModelMapping()
        {
            return PartialView("~/Views/ModelMapping/_CreateViewModal.cshtml", new ModelMapping());
        }


        [HttpPost]
        public async Task<IActionResult> CreateModelMapping([FromBody] List<ModelMapping> request)
        {
            try
            {
                await _apiService.ImportModelMapping(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmCreateModelMapping(ModelMapping request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var model = new ModelMapping()
                {
                    Plant = request.Plant,
                    Category = request.Category,
                    ModelJTF = request.ModelJTF,
                    ModelSWMS = request.ModelSWMS,
                    Note = request.Note
                };
                await _apiService.ImportModelMapping(new List<ModelMapping> { model });
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportModelMapping(IFormFile file, KittingTab tab)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.ModelMappingHeader, Constants.IndexModelMappingHeader);
                        if (dt != null && dt.Columns.Count == Constants.ModelMappingHeader.Count)
                        {
                            List<ModelMapping>? planImports = Function.DataTatbleToModelMapping(dt);
                            if (planImports != null && planImports.Count > 0)
                            {
                                return PartialView("~/Views/ModelMapping/_ImportModelMappingModal.cshtml", planImports);
                            }
                        }
                    }

                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportModelMapping([FromBody] List<ModelMapping> request)
        {
            try
            {
                await _apiService.ImportModelMapping(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
    }
}
