import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/qr_label.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/core/widgets/common/printer_status_bar.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_receive_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_instruction_providers.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_receive_notifier.dart';
import 'package:swms_finish_goods/shared/presentation/label_print_dialog.dart';
import 'package:swms_finish_goods/shared/presentation/printer_picker_dialog.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2a — SCS WH nhận hàng back vào phiếu.
//
//  Vào từ màn Chỉ thị back hàng (chạm phiếu → Tạo Pallet ID). KHÔNG dùng màn
//  "Tạo Pallet ID" trong Nhận hàng: màn đó đi theo thẻ in / GTIN / mã model,
//  còn ở đây mọi thứ bám vào phiếu và quét tới cấp serial.
//
//  Trình tự: chọn model → quét mã thùng → quét serial từng sản phẩm trong
//  thùng → Xong thùng → thùng tiếp → Lưu. Server cấp Pallet ID, máy in nhãn.
//
//  Mã quét được là thùng hay serial thì phân biệt theo GIAI ĐOẠN, không đoán
//  theo hình dạng mã — xem ghi chú ở return_receive_notifier.dart.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class ReturnReceivePage extends ConsumerStatefulWidget {
  const ReturnReceivePage({super.key, required this.docId});

  final int docId;

  @override
  ConsumerState<ReturnReceivePage> createState() => _ReturnReceivePageState();
}

class _ReturnReceivePageState extends ConsumerState<ReturnReceivePage> {
  StreamSubscription<String>? _sub;

  /// Chặn bấm hai lần khi đang lưu / in (overlay do appActionProvider lo).
  bool _saving = false;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Page đã dispose trong lúc chờ → không gán, tránh rò listener.
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      ref.read(returnReceiveProvider.notifier).onScan(data);
    });
  }

  /// Ngưng listener của page khi mở dialog tự nghe scan (chọn máy in = quét
  /// MAC) — nếu không, mã MAC rơi vào notifier như một serial.
  Future<T> _withScanPaused<T>(Future<T> Function() action) async {
    await _sub?.cancel();
    _sub = null;
    try {
      return await action();
    } finally {
      if (mounted) await _listen();
    }
  }

  Future<void> _pickPrinter() => _withScanPaused(() async {
        if (!mounted) return;
        await pickPrinter(context, ref);
      });

  /// Model mặc định: phiếu một model thì chọn luôn, WH không phải bấm thêm.
  ///
  /// Hoãn sang sau frame: sửa state của provider NGAY TRONG build là Riverpod
  /// ném lỗi. Gọi lại mỗi lần build không tốn gì — đã chọn thì thoát ngay.
  void _autoPickModel(ReturnInstruction doc) {
    if (doc.lines.length != 1) return;
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (!mounted) return;
      if (ref.read(returnReceiveProvider).activeModel != null) return;
      ref
          .read(returnReceiveProvider.notifier)
          .setActiveModel(doc.lines.first.model);
    });
  }

  Future<void> _save(ReturnInstruction doc) async {
    if (_saving) return;
    setState(() => _saving = true);
    try {
      // Lỗi đã được appActionProvider bắt + toast → null.
      final result =
          await ref.read(returnReceiveProvider.notifier).submit(doc.id);
      if (!mounted || result == null) return;

      // Phiếu đã đổi SL thực nhận → màn này và màn danh sách đều phải đọc lại.
      ref.invalidate(returnInstructionDetailProvider(doc.id));
      ref.invalidate(returnInstructionListProvider);

      await _printOrOffer(result);
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  /// Pallet ĐÃ tạo ở server — in lỗi không rollback được gì, nên chỉ báo và
  /// mời in lại. Cùng cách xử lý với màn Nhận hàng.
  ///
  /// Dùng [QrLabelData] (lớp tem có tách `qr` / `caption`) chứ không dùng
  /// `PalletLabelData` của màn Nhận hàng: tem hàng back cần badge RW / RB để
  /// nhận ra từ xa, mà lớp cũ in QR và chữ từ CÙNG một biến nên không chèn
  /// được gì vào chữ mà không làm bẩn QR.
  ///
  /// QR vẫn là 12 ký tự Pallet ID — API validate `^\d{12}$` nên QR có đuôi sẽ
  /// bị từ chối ở mọi màn quét.
  Future<void> _printOrOffer(ReturnReceiveResult result) async {
    // `.code` chứ không phải chính enum: badgeForDisposition nhận chuỗi
    // disposition của pallet ('rework' / 'refurbish'), và `ReturnGoodsType.code`
    // đúng là hai chuỗi đó — nên badge trên tem hàng back khớp badge trên tem
    // pallet thường, cùng một hàm, không có bảng tra thứ hai để lệch.
    final badge = QrLabelData.badgeForDisposition(result.doc.goodsType.code);
    final label = QrLabelData.pallet(result.lotNo, badge: badge);
    final subtitle =
        badge == null ? result.lotNo : '${result.lotNo} · $badge';

    final printed = await printLabel(ref, label);
    if (!mounted) return;

    if (printed) {
      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_receive_toast_saved_printed.tr(namedArgs: {
          'lotNo': result.lotNo,
          'count': '${result.serialCount}',
        }),
      );
      _warnIfOver(result);
      return;
    }

    final retry = await AppDialogHelper.confirm(
      context,
      title: LocaleKeys.return_receive_print_failed_title.tr(),
      message: LocaleKeys.return_receive_print_failed_message
          .tr(namedArgs: {'lotNo': result.lotNo}),
      confirmText: LocaleKeys.return_receive_print_retry.tr(),
      cancelText: LocaleKeys.return_receive_print_later.tr(),
    );
    if (!mounted) return;

    if (retry) {
      // Dialog in có nút đổi máy (quét MAC) → ngưng listener của page.
      await _withScanPaused(() async {
        if (!mounted) return;
        await showLabelPrintDialog(
          context,
          title: LocaleKeys.label_print_title.tr(),
          subtitle: subtitle,
          label: label,
        );
      });
      if (!mounted) return;
    }
    _warnIfOver(result);
  }

  /// Nhận vượt chỉ thị: nói ra một lần, KHÔNG chặn. Hàng về nhiều hơn khách
  /// báo là chuyện thường và bước báo FA sẽ mang số thực tế.
  void _warnIfOver(ReturnReceiveResult result) {
    if (!result.overReceived) return;
    AppToastHelper.toastWarning(
      context,
      LocaleKeys.return_receive_over_warning.tr(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(returnInstructionDetailProvider(widget.docId));

    // Đọc thẳng từ AsyncData chứ không qua getter `.valueOrNull`: riverpod 3
    // đã bỏ getter đó, còn khớp mẫu thì đúng ở mọi phiên bản. Cùng cách với
    // `ngTypesOf` ở features/abnormal_report.
    final doc = async is AsyncData<ReturnInstruction> ? async.value : null;

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.return_receive_title.tr(),
        subtitle: doc?.docNo ?? LocaleKeys.return_receive_subtitle.tr(),
      ),
      body: switch (async) {
        AsyncError(:final error) => AppErrorView.page(
            message: ref.read(errorHandlerProvider).getMessage(error),
            onRetry: () =>
                ref.invalidate(returnInstructionDetailProvider(widget.docId)),
          ),
        _ => doc == null ? const AppLoading() : _body(doc),
      },
      bottomNavigationBar: doc == null ? null : _bottom(doc),
    );
  }

  /// Bước hiện tại, 1-based, cho [AppStepperBar].
  ///
  /// Quy trình LẶP: xong một thùng là về bước 2 để quét thùng kế tiếp. Thanh
  /// bước vì thế không chạy một chiều 1→2→3 mà quay lại — đó là đúng việc đang
  /// làm, không phải lỗi.
  static int _stepOf(ReturnReceiveState draft) {
    if (draft.activeModel == null) return 1;
    return draft.isScanningSerials ? 3 : 2;
  }

  Widget _body(ReturnInstruction doc) {
    _autoPickModel(doc);

    final draft = ref.watch(returnReceiveProvider);
    final notifier = ref.read(returnReceiveProvider.notifier);
    final printer = ref.watch(selectedPrinterProvider);
    final step = _stepOf(draft);

    // Phiếu đã đóng thì chỉ xem: server cũng chặn, nhưng để WH quét cả pallet
    // rồi mới báo lỗi thì quá muộn.
    if (!doc.isOpen) {
      return Padding(
        padding: const EdgeInsets.all(AppDimens.md),
        child: AppErrorView.widget(
          message: LocaleKeys.return_receive_doc_closed.tr(),
        ),
      );
    }

    return ListView(
      padding: const EdgeInsets.all(AppDimens.md),
      children: [
        AppStepperBar(
          current: step,
          steps: [
            StepItem(LocaleKeys.return_receive_step_model.tr()),
            StepItem(LocaleKeys.return_receive_step_box.tr()),
            StepItem(LocaleKeys.return_receive_step_serial.tr()),
          ],
        ),
        const SizedBox(height: AppDimens.sm),

        _ProgressCard(doc: doc, draft: draft),
        const SizedBox(height: AppDimens.sm),

        _ModelPicker(
          doc: doc,
          draft: draft,
          // Đổi model giữa lúc đang quét dở một thùng là gán sai model cho
          // serial đã quét → chỉ cho đổi khi chưa mở thùng.
          enabled: !draft.isScanningSerials,
          onPick: notifier.setActiveModel,
        ),
        const SizedBox(height: AppDimens.md),

        // ── Khung quét: nói thẳng ĐANG CHỜ QUÉT GÌ ──
        // Bước 1 KHÔNG hiện khung: một khung quét đang chạy scan line mà quét
        // vào lại báo lỗi là mời người ta làm sai.
        if (step == 1)
          const _PickModelPrompt()
        else ...[
          BarcodeScannerButton(
            state: _saving ? ScannerState.loading : ScannerState.scanning,
            scanningLabel: step == 2
                ? LocaleKeys.return_receive_scan_box_label.tr()
                : LocaleKeys.return_receive_scan_serial_label.tr(),
            loadingLabel: LocaleKeys.return_receive_scan_saving.tr(),
          ),
          const SizedBox(height: AppDimens.sm),
          _ScanHint(
            text: step == 2
                ? LocaleKeys.return_receive_hint_scan_box.tr()
                : LocaleKeys.return_receive_hint_scan_serial.tr(),
          ),
        ],

        const SizedBox(height: AppDimens.sm),

        if (draft.isScanningSerials)
          _CurrentBoxCard(
            draft: draft,
            onRemoveSerial: notifier.removeSerial,
            onFinish: () => _guard(notifier.finishBox),
            onCancel: notifier.cancelCurrentBox,
          )
        else
          // Hàng về rời, không còn thùng để quét.
          Center(
            child: AppButton(
              label: LocaleKeys.return_receive_box_no_code.tr(),
              variant: AppButtonVariant.subtle,
              size: AppButtonSize.sm,
              icon: Icons.inbox_outlined,
              isFullWidth: false,
              onPressed: () => _guard(notifier.openBoxWithoutCode),
            ),
          ),

        if (draft.boxes.isNotEmpty) ...[
          const SizedBox(height: AppDimens.sm),
          _DoneBoxList(boxes: draft.boxes, onRemove: notifier.removeBox),
        ],

        const SizedBox(height: AppDimens.sm),
        PrinterStatusBar(
          device: printer,
          onChange: _saving ? null : _pickPrinter,
        ),
        const SizedBox(height: AppDimens.lg),
      ],
    );
  }

  /// Chạy một lệnh đồng bộ của notifier và hiện lỗi nghiệp vụ bằng toast.
  ///
  /// Các lệnh này không đi qua appActionProvider (không có gì để chờ), nên
  /// nếu không bắt ở đây thì ném vào void và màn hình đứng im.
  void _guard(void Function() action) {
    try {
      action();
    } catch (e) {
      AppToastHelper.toastError(
        context,
        ref.read(errorHandlerProvider).getMessage(e),
      );
    }
  }

  Widget _bottom(ReturnInstruction doc) {
    if (!doc.isOpen) {
      return AppBottomHint(text: LocaleKeys.return_receive_doc_closed.tr());
    }

    final draft = ref.watch(returnReceiveProvider);
    final canSave = draft.hasAnything && !_saving;

    return AppBottomHint(
      child: Row(
        children: [
          // onPressed = null là BackIconButton TỰ pop (hành vi mặc định của nó),
          // nên muốn chặn back lúc đang lưu phải truyền một callback rỗng.
          BackIconButton(onPressed: _saving ? () {} : null),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: AppButton(
              label: LocaleKeys.return_receive_btn_save
                  .tr(namedArgs: {'count': '${draft.serialCount}'}),
              variant: AppButtonVariant.success,
              icon: Icons.print_rounded,
              isFullWidth: false,
              isLoading: _saving,
              onPressed: canSave ? () => _save(doc) : null,
            ),
          ),
        ],
      ),
    );
  }
}

// ── Tiến độ phiếu ───────────────────────────────────────────

class _ProgressCard extends StatelessWidget {
  const _ProgressCard({required this.doc, required this.draft});

  final ReturnInstruction doc;
  final ReturnReceiveState draft;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    // Cộng cả bản nháp chưa lưu: WH cần thấy "còn phải nhận bao nhiêu" NGAY
    // khi đang quét, chứ không phải sau khi bấm Lưu.
    final received = doc.receivedQty + draft.serialCount;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  doc.docNo,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: c.text1,
                  ),
                ),
              ),
              switch (doc.goodsType) {
                ReturnGoodsType.rework =>
                  StatusPill.warning(context, label: doc.goodsType.labelKey.tr()),
                ReturnGoodsType.refurbish =>
                  StatusPill.info(context, label: doc.goodsType.labelKey.tr()),
              },
            ],
          ),
          if (doc.customer != null && doc.customer!.isNotEmpty) ...[
            const SizedBox(height: 2),
            Text(doc.customer!,
                style: AppTextStyles.caption.copyWith(color: c.text2)),
          ],
          const SizedBox(height: AppDimens.sm),
          Row(
            children: [
              Icon(Icons.inventory_2_outlined, size: 15, color: c.text3),
              const SizedBox(width: 4),
              Text(
                LocaleKeys.return_receive_progress.tr(namedArgs: {
                  'received': '$received',
                  'total': '${doc.totalQty}',
                }),
                style: AppTextStyles.bodyStrong.copyWith(color: c.text1),
              ),
              const Spacer(),
              if (draft.serialCount > 0)
                Text(
                  LocaleKeys.return_receive_draft_count
                      .tr(namedArgs: {'count': '${draft.serialCount}'}),
                  style: AppTextStyles.caption.copyWith(color: c.warning),
                ),
            ],
          ),
        ],
      ),
    );
  }
}

// ── Chọn model cho thùng kế tiếp ────────────────────────────

class _ModelPicker extends StatelessWidget {
  const _ModelPicker({
    required this.doc,
    required this.draft,
    required this.enabled,
    required this.onPick,
  });

  final ReturnInstruction doc;
  final ReturnReceiveState draft;
  final bool enabled;
  final ValueChanged<String> onPick;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          enabled
              ? LocaleKeys.return_receive_pick_model.tr()
              : LocaleKeys.return_receive_model_locked.tr(),
          style: AppTextStyles.caption.copyWith(color: c.text3),
        ),
        const SizedBox(height: 4),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final l in doc.lines)
              _ModelChip(
                line: l,
                // Còn lại tính cả bản nháp: quét thêm là số tụt ngay.
                remaining: l.remainingQty - draft.draftCountFor(l.model),
                selected: draft.activeModel != null &&
                    draft.activeModel!.toUpperCase() == l.model.toUpperCase(),
                enabled: enabled,
                onTap: () => onPick(l.model),
              ),
          ],
        ),
      ],
    );
  }
}

class _ModelChip extends StatelessWidget {
  const _ModelChip({
    required this.line,
    required this.remaining,
    required this.selected,
    required this.enabled,
    required this.onTap,
  });

  final ReturnInstructionLine line;
  final int remaining;
  final bool selected;
  final bool enabled;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    // Ba trạng thái: còn phải nhận (thường) · đã đủ (xanh) · đã vượt (cam).
    final (Color bg, Color fg) = remaining < 0
        ? (c.warningBg, c.warning)
        : remaining == 0
            ? (c.successBg, c.success)
            : (c.card2, c.text1);

    return Opacity(
      opacity: enabled ? 1.0 : 0.55,
      child: Material(
        color: selected ? c.primaryTint : bg,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        child: InkWell(
          onTap: enabled ? onTap : null,
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(AppDimens.rInput),
              border: Border.all(
                color: selected ? c.primary : c.border,
                width: selected ? 1.6 : 1.0,
              ),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  line.model,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 12,
                    fontWeight: FontWeight.w700,
                    color: selected ? c.primary : fg,
                  ),
                ),
                Text(
                  remaining < 0
                      ? LocaleKeys.return_receive_over
                          .tr(namedArgs: {'qty': '${-remaining}'})
                      : LocaleKeys.return_receive_remaining
                          .tr(namedArgs: {'qty': '$remaining'}),
                  style: AppTextStyles.caption.copyWith(
                    fontSize: 10.5,
                    color: selected ? c.primary : fg,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

// ── Bước 1: chưa chọn model ─────────────────────────────────

/// Thay cho khung quét ở bước 1. Không dùng khung quét ở đây có chủ ý — xem
/// ghi chú tại chỗ gọi.
class _PickModelPrompt extends StatelessWidget {
  const _PickModelPrompt();

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        children: [
          Icon(Icons.touch_app_outlined, size: 34, color: c.text3),
          const SizedBox(height: AppDimens.sm),
          Text(
            LocaleKeys.return_receive_hint_pick_model.tr(),
            textAlign: TextAlign.center,
            style: AppTextStyles.body.copyWith(color: c.text2),
          ),
        ],
      ),
    );
  }
}

/// Dòng nhắc dưới khung quét — nói rõ việc kế tiếp phải làm gì.
class _ScanHint extends StatelessWidget {
  const _ScanHint({required this.text});

  final String text;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.arrow_upward_rounded, size: 14, color: c.text3),
        const SizedBox(width: 4),
        Flexible(
          child: Text(
            text,
            textAlign: TextAlign.center,
            style: AppTextStyles.caption.copyWith(color: c.text2),
          ),
        ),
      ],
    );
  }
}

// ── Thùng đang quét serial ──────────────────────────────────

class _CurrentBoxCard extends StatelessWidget {
  const _CurrentBoxCard({
    required this.draft,
    required this.onRemoveSerial,
    required this.onFinish,
    required this.onCancel,
  });

  final ReturnReceiveState draft;
  final ValueChanged<int> onRemoveSerial;
  final VoidCallback onFinish;
  final VoidCallback onCancel;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final box = draft.current!;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.inbox_rounded, size: 16, color: c.primary),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  box.boxNo ?? LocaleKeys.return_receive_box_no_code_label.tr(),
                  style: AppTextStyles.code.copyWith(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: c.text1,
                  ),
                ),
              ),
              StatusPill.info(context, label: box.model),
            ],
          ),
          const SizedBox(height: AppDimens.sm),
          Text(
            LocaleKeys.return_receive_serial_count
                .tr(namedArgs: {'count': '${box.serials.length}'}),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
          const SizedBox(height: 4),

          // Thùng chưa có serial thì không nhắc lại gì ở đây: dòng nhắc đã nằm
          // ngay dưới khung quét phía trên, lặp hai lần chỉ làm thẻ dài ra.
          if (box.serials.isNotEmpty)
            // Serial mới nhất lên ĐẦU: trên PDA người quét nhìn vào đầu danh
            // sách để xác nhận con vừa quét, không phải cuộn xuống đáy.
            Column(
              children: [
                for (var i = box.serials.length - 1; i >= 0; i--)
                  _SerialRow(
                    index: i,
                    serialNo: box.serials[i],
                    onRemove: () => onRemoveSerial(i),
                  ),
              ],
            ),

          const SizedBox(height: AppDimens.sm),
          Row(
            children: [
              Expanded(
                child: AppButton(
                  label: LocaleKeys.return_receive_btn_finish_box.tr(),
                  variant: AppButtonVariant.primary,
                  size: AppButtonSize.sm,
                  icon: Icons.check_rounded,
                  isFullWidth: false,
                  onPressed: onFinish,
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              AppButton(
                label: LocaleKeys.return_receive_btn_cancel_box.tr(),
                variant: AppButtonVariant.subtle,
                size: AppButtonSize.sm,
                isFullWidth: false,
                onPressed: onCancel,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SerialRow extends StatelessWidget {
  const _SerialRow({
    required this.index,
    required this.serialNo,
    required this.onRemove,
  });

  final int index;
  final String serialNo;
  final VoidCallback onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          SizedBox(
            width: 26,
            child: Text('${index + 1}',
                style: AppTextStyles.caption.copyWith(color: c.text3)),
          ),
          Expanded(
            child: Text(
              serialNo,
              style: AppTextStyles.code.copyWith(fontSize: 12, color: c.text1),
            ),
          ),
          IconButton(
            visualDensity: VisualDensity.compact,
            constraints: const BoxConstraints(minWidth: 32, minHeight: 32),
            padding: EdgeInsets.zero,
            icon: Icon(Icons.close_rounded, size: 16, color: c.text3),
            tooltip: LocaleKeys.return_receive_remove_serial.tr(),
            onPressed: onRemove,
          ),
        ],
      ),
    );
  }
}

// ── Thùng đã xong, chờ lưu ──────────────────────────────────

class _DoneBoxList extends StatelessWidget {
  const _DoneBoxList({required this.boxes, required this.onRemove});

  final List<ReturnBoxDraft> boxes;
  final ValueChanged<int> onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_receive_done_boxes
                .tr(namedArgs: {'count': '${boxes.length}'}),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
          const SizedBox(height: 4),
          for (var i = 0; i < boxes.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 3),
              child: Row(
                children: [
                  Icon(Icons.check_circle_outline, size: 15, color: c.success),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      boxes[i].boxNo ??
                          LocaleKeys.return_receive_box_no_code_label.tr(),
                      style: AppTextStyles.code
                          .copyWith(fontSize: 12, color: c.text1),
                    ),
                  ),
                  Text(
                    '${boxes[i].model}  ·  ${boxes[i].serials.length}',
                    style: AppTextStyles.caption.copyWith(color: c.text2),
                  ),
                  IconButton(
                    visualDensity: VisualDensity.compact,
                    constraints:
                        const BoxConstraints(minWidth: 32, minHeight: 32),
                    padding: EdgeInsets.zero,
                    icon: Icon(Icons.delete_outline, size: 17, color: c.text3),
                    tooltip: LocaleKeys.return_receive_remove_box.tr(),
                    onPressed: () => onRemove(i),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}
