﻿using SWMS_WebTool.Models;

namespace SWMS_WebTool.ViewModels
{
    public class ReceivingCardDetailViewModel
    {
        public List<ReceivingCardDetail> Records { get; set; }
        public string DeliveryPlanNo { get; set; }
        public string DeliveryPlanItem { get; set; }
        public string PurchaseOrderNo { get; set; }
        public string PurchaseOrderItem { get; set; }
        public double PlanQuantity { get; set; }
        public double ActualQuantity { get; set; }
        public string Material { get; set; }
        public string UserStored { get; set; }
        public string UserGR { get; set; }
        public DateTime? DateStored { get; set; }
        public DateTime? DateGR { get; set; }
    }
}
