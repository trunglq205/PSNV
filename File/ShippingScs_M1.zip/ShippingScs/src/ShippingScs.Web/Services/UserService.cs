using System.Security.Claims;
using Dapper;
using Microsoft.AspNetCore.Identity;
using ShippingScs.Web.Data;
using ShippingScs.Web.Models;

namespace ShippingScs.Web.Services;

/// <summary>Lỗi nghiệp vụ hiển thị thẳng cho người dùng (controller bắt và đưa vào ModelState/TempData).</summary>
public class BusinessException : Exception
{
    public BusinessException(string message) : base(message) { }
}

public class UserService
{
    private readonly Db _db;
    private readonly ChangeLogService _log;
    // Chỉ dùng PasswordHasher của ASP.NET Core Identity (có sẵn trong framework), không dùng cả bộ Identity.
    private readonly PasswordHasher<AppUser> _hasher = new();

    private const string SelectColumns =
        "Id, UserName, FullName, Email, PicCode, Role, PasswordHash, IsActive, CreatedAt, UpdatedAt";

    public UserService(Db db, ChangeLogService log)
    {
        _db = db;
        _log = log;
    }

    public async Task<int> CountAsync()
    {
        using var conn = _db.Connection();
        return await conn.ExecuteScalarAsync<int>("SELECT COUNT(*) FROM dbo.Users");
    }

    public async Task<List<AppUser>> ListAsync()
    {
        using var conn = _db.Connection();
        var rows = await conn.QueryAsync<AppUser>(
            $"SELECT {SelectColumns} FROM dbo.Users ORDER BY IsActive DESC, UserName");
        return rows.AsList();
    }

    public async Task<AppUser?> GetAsync(int id)
    {
        using var conn = _db.Connection();
        return await conn.QuerySingleOrDefaultAsync<AppUser>(
            $"SELECT {SelectColumns} FROM dbo.Users WHERE Id = @id", new { id });
    }

    /// <summary>Tra user theo mã PIC trong file Excel. "X DUNG" = "X.DUNG" = "x.dung".</summary>
    public async Task<AppUser?> FindByPicCodeAsync(string picCode)
    {
        using var conn = _db.Connection();
        return await conn.QuerySingleOrDefaultAsync<AppUser>(
            $"SELECT {SelectColumns} FROM dbo.Users WHERE PicKey = @key",
            new { key = NormalizePicCode(picCode) });
    }

    public static string NormalizePicCode(string picCode) =>
        picCode.Replace(" ", "").Replace(".", "").ToUpperInvariant();

    /// <summary>Kiểm tra đăng nhập. Trả null nếu sai tên/mật khẩu hoặc tài khoản đã khoá.</summary>
    public async Task<AppUser?> ValidateLoginAsync(string userName, string password)
    {
        AppUser? user;
        using (var conn = _db.Connection())
        {
            user = await conn.QuerySingleOrDefaultAsync<AppUser>(
                $"SELECT {SelectColumns} FROM dbo.Users WHERE UserName = @userName",
                new { userName = userName.Trim() });
        }

        if (user == null || !user.IsActive) return null;

        var result = _hasher.VerifyHashedPassword(user, user.PasswordHash, password);
        if (result == PasswordVerificationResult.Failed) return null;

        if (result == PasswordVerificationResult.SuccessRehashNeeded)
            await SetPasswordHashAsync(user.Id, _hasher.HashPassword(user, password));

        return user;
    }

    public async Task<int> CreateAsync(UserEditModel model, int? byUserId = null)
    {
        if (string.IsNullOrWhiteSpace(model.NewPassword))
            throw new BusinessException("Nhập mật khẩu cho tài khoản mới.");
        ValidateRole(model.Role);

        var user = new AppUser { UserName = model.UserName.Trim() };
        var hash = _hasher.HashPassword(user, model.NewPassword);

        using var conn = _db.Connection();
        await EnsureUniqueAsync(conn, 0, model);

        var id = await conn.ExecuteScalarAsync<int>(@"
            INSERT INTO dbo.Users (UserName, FullName, Email, PicCode, Role, PasswordHash, IsActive)
            OUTPUT INSERTED.Id
            VALUES (@UserName, @FullName, @Email, @PicCode, @Role, @PasswordHash, @IsActive)",
            new
            {
                UserName = model.UserName.Trim(),
                FullName = model.FullName.Trim(),
                Email = Clean(model.Email),
                PicCode = Clean(model.PicCode),
                model.Role,
                PasswordHash = hash,
                model.IsActive,
            });

        await _log.WriteAsync("User", model.UserName.Trim(), "Create",
            $"Tạo user {model.UserName.Trim()} ({model.Role})", null, byUserId);
        return id;
    }

    public async Task UpdateAsync(UserEditModel model, int? byUserId)
    {
        ValidateRole(model.Role);

        var old = await GetAsync(model.Id) ?? throw new BusinessException("Không tìm thấy user.");

        using var conn = _db.Connection();
        await EnsureUniqueAsync(conn, model.Id, model);

        // Không để hệ thống mất admin cuối cùng (tự hạ quyền hoặc khoá admin cuối)
        var losesAdmin = old.Role == Roles.Admin && old.IsActive
                         && (model.Role != Roles.Admin || !model.IsActive);
        if (losesAdmin)
        {
            var activeAdmins = await conn.ExecuteScalarAsync<int>(
                "SELECT COUNT(*) FROM dbo.Users WHERE Role = 'Admin' AND IsActive = 1");
            if (activeAdmins <= 1)
                throw new BusinessException("Phải còn ít nhất 1 Admin đang hoạt động.");
        }

        await conn.ExecuteAsync(@"
            UPDATE dbo.Users
               SET UserName = @UserName, FullName = @FullName, Email = @Email, PicCode = @PicCode,
                   Role = @Role, IsActive = @IsActive, UpdatedAt = SYSDATETIME()
             WHERE Id = @Id",
            new
            {
                model.Id,
                UserName = model.UserName.Trim(),
                FullName = model.FullName.Trim(),
                Email = Clean(model.Email),
                PicCode = Clean(model.PicCode),
                model.Role,
                model.IsActive,
            });

        if (!string.IsNullOrWhiteSpace(model.NewPassword))
            await SetPasswordHashAsync(model.Id, _hasher.HashPassword(old, model.NewPassword));

        await _log.WriteAsync("User", model.UserName.Trim(), "Update", $"Sửa user {model.UserName.Trim()}",
            new
            {
                old = new { old.Role, old.IsActive, old.PicCode },
                @new = new { model.Role, model.IsActive, PicCode = Clean(model.PicCode) },
                passwordChanged = !string.IsNullOrWhiteSpace(model.NewPassword),
            },
            byUserId);
    }

    public static ClaimsPrincipal ToPrincipal(AppUser user)
    {
        var claims = new List<Claim>
        {
            new(ClaimTypes.NameIdentifier, user.Id.ToString()),
            new(ClaimTypes.Name, user.UserName),
            new("FullName", user.FullName),
            new(ClaimTypes.Role, user.Role),
        };
        if (!string.IsNullOrEmpty(user.PicCode)) claims.Add(new Claim("PicCode", user.PicCode));

        return new ClaimsPrincipal(new ClaimsIdentity(claims, "Cookies"));
    }

    private async Task SetPasswordHashAsync(int id, string hash)
    {
        using var conn = _db.Connection();
        await conn.ExecuteAsync(
            "UPDATE dbo.Users SET PasswordHash = @hash, UpdatedAt = SYSDATETIME() WHERE Id = @id",
            new { id, hash });
    }

    private static async Task EnsureUniqueAsync(System.Data.IDbConnection conn, int id, UserEditModel model)
    {
        var nameTaken = await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM dbo.Users WHERE UserName = @name AND Id <> @id",
            new { name = model.UserName.Trim(), id });
        if (nameTaken > 0) throw new BusinessException("Tên đăng nhập đã tồn tại.");

        var pic = Clean(model.PicCode);
        if (pic == null) return;

        var picTaken = await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(*) FROM dbo.Users WHERE PicKey = @key AND Id <> @id",
            new { key = NormalizePicCode(pic), id });
        if (picTaken > 0) throw new BusinessException($"Mã PIC '{pic}' đã gán cho user khác.");
    }

    private static void ValidateRole(string role)
    {
        if (!Roles.All.Contains(role)) throw new BusinessException("Role không hợp lệ.");
    }

    private static string? Clean(string? value) =>
        string.IsNullOrWhiteSpace(value) ? null : value.Trim();
}
