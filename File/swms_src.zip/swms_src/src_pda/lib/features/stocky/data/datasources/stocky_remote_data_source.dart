import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/stocky/data/models/stocky_cart_model.dart';

part 'stocky_remote_data_source.g.dart';

/// Đường dẫn PHẢI có tiền tố `/api`: BASE_URL trong `config/*.json` chỉ tới
/// host + port, không chứa `/api` (xem `app_config.dart`). Bản trước khai
/// `/stocky-carts/...` nên mọi request sẽ 404 — mock che mất, chưa ai thấy.
@RestApi()
abstract class StockyRemoteDataSource {
  factory StockyRemoteDataSource(Dio dio, {String baseUrl}) =
      _StockyRemoteDataSource;

  /// Danh sách xe kèm vị trí và tình trạng rỗng / có hàng.
  ///
  /// Tên tham số query là camelCase (`hasGoods`): ASP.NET model binding so tên
  /// KHÔNG phân biệt hoa thường nhưng CÓ phân biệt dấu gạch dưới, nên
  /// `has_goods` sẽ không khớp vào `StockyQuery.HasGoods`.
  @GET('/api/stocky-carts')
  Future<List<StockyCartModel>> list({
    @Query('status') String? status,
    @Query('hasGoods') bool? hasGoods,
    @Query('keyword') String? keyword,
  });

  /// [mode] = 'in' | 'fa' | 'out' — server kiểm trạng thái xe theo đúng chiều
  /// và trả 409 kèm câu thông báo đã dịch khi sai chiều.
  @GET('/api/stocky-carts/{code}')
  Future<StockyCartModel> lookup(
    @Path('code') String code,
    @Query('mode') String mode,
  );

  /// Nhận một lô xe vào kho: xe mới từ vendor, hoặc xe đang ở FA đưa về.
  /// Quyền `stocky.create`.
  @POST('/api/stocky-carts/receive')
  Future<StockySubmitResultModel> receive(@Body() StockyBatchRequest body);

  /// Đẩy một lô xe sang FA. Xe VẪN được quản lý, chỉ đổi vị trí.
  /// Quyền `stocky.transfer`.
  @POST('/api/stocky-carts/export-fa')
  Future<StockySubmitResultModel> exportFa(@Body() StockyBatchRequest body);

  /// Trả một lô xe VỀ VENDOR — xe rời hệ thống. Quyền `stocky.transfer`.
  ///
  /// ⚠ Trước đây hàm này được nút "Xuất sang FA" gọi, nên xuất sang FA là xe
  /// bị ghi nhận như đã trả vendor và biến mất khỏi danh sách theo dõi. Xuất
  /// FA giờ dùng [exportFa].
  @POST('/api/stocky-carts/return')
  Future<StockySubmitResultModel> returnCarts(@Body() StockyBatchRequest body);
}
