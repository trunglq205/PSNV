namespace Swms.FinishGoods.API.Features.HdSoft.Business;

/*  SI bên HD soft = 1 phiếu C_Order có SINo (+ các dòng C_OrderLine).

    Cột chuẩn iDempiere (DocumentNo, DocStatus, DateOrdered, QtyEntered…) đọc thẳng.
    Các trường SAP gửi riêng (etd, eta, contactno, packingno…) là cột tuỳ biến của HD soft:
    repository dò trong information_schema, có cột nào thì đọc cột đó, đưa về chuỗi trong
    Fields với khoá = TÊN TRƯỜNG PAYLOAD SAP (xem SapSiRequest) để so được với SWMS.       */

public class HdSoftSiOrder
{
    public long OrderId { get; init; }
    public string SiNo { get; init; } = "";
    public string DocumentNo { get; init; } = "";
    /// <summary>DR, IP, CO, CL, VO, RE… — xem HdSoftDocStatus.</summary>
    public string? DocStatus { get; init; }
    public string? BPartnerCode { get; init; }
    public string? WarehouseCode { get; init; }
    public string? OrgCode { get; init; }
    public DateTime? DateOrdered { get; init; }
    public DateTime? DatePromised { get; init; }
    public string? Description { get; init; }
    public DateTime Created { get; init; }
    public DateTime? Updated { get; init; }

    /// <summary>Số phiếu C_Order còn hoạt động cùng SINo (mỗi revision có thể là 1 phiếu).
    /// Phiếu đang so là phiếu chưa huỷ, tạo mới nhất.</summary>
    public int OrderCount { get; init; }

    /// <summary>Trường SAP (destport, etd, contactno…) -> giá trị dạng chuỗi. Chỉ có khoá của cột tồn tại.</summary>
    public IReadOnlyDictionary<string, string?> Fields { get; init; } = new Dictionary<string, string?>();

    public List<HdSoftSiLine> Lines { get; } = new();

    public string? Field(string name) => Fields.TryGetValue(name, out var v) ? v : null;
}

public class HdSoftSiLine
{
    public long LineId { get; init; }
    public int LineNo { get; init; }
    /// <summary>M_Product.Value nguyên bản (có thể có hậu tố -V4).</summary>
    public string ProductValue { get; init; } = "";
    /// <summary>Mã model theo cách SWMS dùng (bỏ -V4).</summary>
    public string Model => HdSoftModel.Normalize(ProductValue);
    public decimal QtyEntered { get; init; }
    public decimal QtyDelivered { get; init; }
    public string? Uom { get; init; }
    public string? Description { get; init; }

    /// <summary>packingno, packingitems, so, soitem -> giá trị. Chỉ có khoá của cột tồn tại.</summary>
    public IReadOnlyDictionary<string, string?> Fields { get; init; } = new Dictionary<string, string?>();

    public string? Field(string name) => Fields.TryGetValue(name, out var v) ? v : null;
}

/// <summary>1 trường SAP đã tìm được cột bên HD soft. Kind: date | time | text (cách đưa về chuỗi).</summary>
public record HdSoftSiColumn(string Field, string Column, string DataType, string Kind);

/// <summary>Kết quả dò cột tuỳ biến của C_Order / C_OrderLine.</summary>
public class HdSoftSiSchema
{
    public IReadOnlyList<HdSoftSiColumn> Header { get; init; } = Array.Empty<HdSoftSiColumn>();
    public IReadOnlyList<HdSoftSiColumn> Line { get; init; } = Array.Empty<HdSoftSiColumn>();
    /// <summary>Trường SAP không tìm thấy cột nào bên HD soft.</summary>
    public IReadOnlyList<string> MissingHeader { get; init; } = Array.Empty<string>();
    public IReadOnlyList<string> MissingLine { get; init; } = Array.Empty<string>();
    public DateTime LoadedAt { get; init; }

    public bool HasHeader(string field) => Header.Any(c => c.Field == field);
    public bool HasLine(string field) => Line.Any(c => c.Field == field);
}
