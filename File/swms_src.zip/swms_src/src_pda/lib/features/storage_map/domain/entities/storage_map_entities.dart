import 'package:flutter/foundation.dart';

/// Độ chứa của 1 vị trí (cột) trong kệ — dùng tô màu top-down.
@immutable
class PositionOcc {
  final int position;
  final int total;
  final int occupied;

  const PositionOcc({
    required this.position,
    required this.total,
    required this.occupied,
  });

  double get ratio => total <= 0 ? 0 : occupied / total;
}

/// 1 khối trên bản đồ top-down: kệ (rack) hoặc khu chức năng (decor).
@immutable
class TopMapBlock {
  final int id;
  final String kind; // 'rack' | 'zone' | 'locator' (ô pallet đặt trên sàn)
  final String? rackCode;
  final String? label;
  final String? color;
  final int gridX;
  final int gridY;
  final int gridW;
  final int gridH;
  final int totalSlots;
  final int occupiedSlots;
  final List<PositionOcc> positions;

  // --- ô pallet đặt trên sàn ---
  final String? locatorCode;
  final String? status;          // empty | not_inspected | under_inspection | pending_result | inspection_exempt | pass | ng
  final bool isUrgent;
  final String? model;
  final String? palletId;
  final int? boxCount;
  final DateTime? productionDate;

  const TopMapBlock({
    required this.id,
    required this.kind,
    required this.gridX,
    required this.gridY,
    required this.gridW,
    required this.gridH,
    this.rackCode,
    this.label,
    this.color,
    this.totalSlots = 0,
    this.occupiedSlots = 0,
    this.positions = const [],
    this.locatorCode,
    this.status,
    this.isUrgent = false,
    this.model,
    this.palletId,
    this.boxCount,
    this.productionDate,
  });

  bool get isRack => kind == 'rack';

  /// Ô pallet đặt trên sàn (không thuộc kệ). API trả 'locator', bản cũ có thể là 'pallet'.
  bool get isPallet => kind == 'locator' || kind == 'pallet';

  /// Ô pallet đang có hàng.
  bool get hasStock => palletId != null && palletId!.isNotEmpty;
  double get ratio => totalSlots <= 0 ? 0 : occupiedSlots / totalSlots;
}

/// Bản đồ top-down khu Storage.
@immutable
class StorageTopMap {
  final int cols;
  final int rows;
  final List<TopMapBlock> blocks;

  const StorageTopMap({
    required this.cols,
    required this.rows,
    this.blocks = const [],
  });
}

/// 1 ô/ngăn trên mặt cắt kệ.
@immutable
class ElevationCell {
  final int locatorId;
  final String locatorCode;
  final int location; // vị trí (cột)
  final int floor; // tầng
  final String slotKind; // 'pallet' | 'shelf'
  final String? level; // null=pallet; 'A'(dưới)/'B'(trên)=giá lửng
  final bool occupied;
  final String? palletId;
  final String? model;
  final int? boxCount;
  final DateTime? productionDate;
  final String? disposition; // 'refurbish' | 'rework' | null
  final bool stopShipment;

  /// Trạng thái kiểm của pallet — tô nền ô giống bản đồ Receiving.
  final String? status;
  final bool isUrgent;

  const ElevationCell({
    required this.locatorId,
    required this.locatorCode,
    required this.location,
    required this.floor,
    required this.slotKind,
    required this.occupied,
    this.level,
    this.palletId,
    this.model,
    this.boxCount,
    this.productionDate,
    this.disposition,
    this.stopShipment = false,
    this.status,
    this.isUrgent = false,
  });

  bool get isShelf => slotKind == 'shelf';
}

/// Mặt cắt (side view) của 1 kệ.
@immutable
class RackElevation {
  final String rackCode;
  final List<ElevationCell> cells;

  const RackElevation({required this.rackCode, this.cells = const []});
}


/// Bản đồ kho để chọn xem (storing / receiving / vanning).
class WarehouseArea {
  final int id;
  final String areaCode;
  final String areaName;
  final String mapType;

  const WarehouseArea({
    required this.id,
    required this.areaCode,
    required this.areaName,
    required this.mapType,
  });
}

/// Một vị trí nằm ở đâu trên bản đồ — dùng để mở sơ đồ và focus đúng kệ/ô.
class LocatorLocation {
  final String locatorCode;
  final String? areaCode;
  final String? areaName;
  final String? mapType;
  final String? rackCode;   // null nếu là ô pallet đặt trên sàn
  final int? rackCol;       // vị trí trong kệ
  final int? rackRow;       // tầng kệ
  final String? rackLevel;  // ngăn giá lửng A/B

  const LocatorLocation({
    required this.locatorCode,
    this.areaCode,
    this.areaName,
    this.mapType,
    this.rackCode,
    this.rackCol,
    this.rackRow,
    this.rackLevel,
  });

  bool get inRack => rackCode != null && rackCode!.isNotEmpty;
}

/// Một dòng serial trong pallet.
class PalletSerial {
  final String? boxNo;
  final String? model;
  final String? serialNo;
  final int? qty;

  const PalletSerial({this.boxNo, this.model, this.serialNo, this.qty});
}
