﻿using System.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Models.Responses;
using System.Net;
using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Controllers
{
    public class InventoryController : BaseController
    {
        private readonly ApiService _apiService;

        public InventoryController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] InventoryFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
            var _filter = filter ?? new InventoryFilter();
            int total = 10;
            IEnumerable<Inventory> items = new List<Inventory>();
            var model = new InventoryViewModel()
            {
                Items = items,
                Filter = _filter,
                PageNumber = pageNumber,
                PageSize = _pageSize,
                TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                Total = total,
            };
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> SearchInventory([FromQuery] InventoryFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new InventoryFilter();
                var response = await _apiService.SearchInventory(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<Inventory>();

                var model = new InventoryViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/Inventory/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> SearchInventoryGoodReceipt([FromQuery] InvenoryGoodReceiptFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new InvenoryGoodReceiptFilter();
                var response = await _apiService.SearchGoodReceipt(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<InventoryGoodReceipt>();

                var model = new InvenoryGoodReceiptViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return PartialView("Views/Inventory/SearchInventoryGoodReceipt.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> SearchStoredQuantity([FromQuery] InventoryStoredQuantityFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new InventoryStoredQuantityFilter();
                var response = await _apiService.SearchStoredQuantity(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<InventoryStoredQuantity>();


                var model = new InventoryStoredQuantityViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return PartialView("Views/Inventory/SearchStoredQuantity.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> SearchInventoryMovedOut([FromQuery] InventoryMovedOutFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new InventoryMovedOutFilter();
                var response = await _apiService.SearchMovedOut(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<InventotyMovedOut>();


                var model = new InventoryMovedOutViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return PartialView("Views/Inventory/SearchInventoryMovedOut.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportSapStock(IFormFile file)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.SapStockHeader, Constants.IndexSapStockHeader);
                        if (dt != null && dt.Columns.Count == Constants.SapStockHeader.Count)
                        {

                            List<SapStockImport>? sapImports = Function.DataTatbleToSapStock(dt);
                            if (sapImports != null && sapImports.Count > 0)
                            {
                                return PartialView("~/Views/Inventory/_ImportSapStockModal.cshtml", sapImports);
                            }
                        }
                    }
                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportSapStock([FromBody] List<SapStockImport> request)
        {
            try
            {
                await _apiService.ImportSapStock(request);
                var countData = request.Count;
                return Json(new { success = true, countdata = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        [HttpPost]
        public async Task<IActionResult> GetBoxBalance([FromBody] List<QtyBalanceResponse> res)
        {
            var viewModels = res.Select(d => new QtyBoxBalanceViewModel
            {
                Material = d.Material,
                Sloc = d.Sloc,
                Barcode = d.Barcode,
                Plant = d.Plant,
                ID = d.ID,
                Qty = d.Qty,
                IsManual = d.IsManual
            }).ToList();

            return PartialView("~/Views/Inventory/_Detail_Box_Form.cshtml", viewModels);
        }
        [HttpGet]
        public async Task<IActionResult> SearchSapStock([FromQuery] SapStockFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
            var _filter = filter ?? new SapStockFilter();
            var response = await _apiService.SearchSAPStock(_filter, pageNumber, _pageSize);

            var total = response.TotalRecord;
            var items = response.Records ?? new List<SAPStock>();
            var model = new SapStockViewModel()
            {
                Items = items,
                Filter = _filter,
                PageNumber = pageNumber,
                PageSize = _pageSize,
                TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                Total = total,
            };
            return View("Views/Inventory/SearchSapStockView.cshtml", model);
        }

        [HttpGet]
        public async Task<IActionResult> SearchInventoryFormBalance([FromQuery] InventoryFormFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
            var responseDropdown = await _apiService.GetAllMasterSloc(new MasterSlocFilter(), Constants.PagingDefault, Constants.PageMaximum);
            var _filter = filter ?? new InventoryFormFilter();
            if (string.IsNullOrEmpty(filter.Sloc) && !string.IsNullOrEmpty(filter.Plant) && !string.IsNullOrEmpty(filter.Category))
            {
                var listSloc = responseDropdown.Records.Where(s => s.Plant == filter.Plant && s.Category == filter.Category).Select(x => x.Sloc).Distinct().ToList();
                _filter.Sloc = string.Join(",", listSloc);
            }
            var isSearchConfirm = _filter.BalanceType != null && _filter.BalanceType.ToEnumMemberAttrValue() == "2";
            var response = await _apiService.SearchInventoryFormOK(_filter.Plant, _filter.Material, _filter.Sloc, _filter.IsAll, _filter.BalanceType != null ? _filter.BalanceType.ToEnumMemberAttrValue() : string.Empty, pageNumber, isSearchConfirm ? Constants.PageMaximum : _pageSize);

            ViewBag.SelectPlants = new SelectList(responseDropdown.Records.Select(x => x.Plant).Distinct().ToList());
            ViewBag.Categorys = new SelectList(responseDropdown.Records.Where(s => !string.IsNullOrEmpty(filter.Plant) ? s.Plant == filter.Plant : s.Plant == "").Select(x => x.Category).Distinct().ToList());
            ViewBag.Slocs = new SelectList(responseDropdown.Records.Where(s => !string.IsNullOrEmpty(filter.Plant) && !string.IsNullOrEmpty(filter.Category) ? s.Plant == filter.Plant && s.Category == filter.Category : s.Plant == "").Select(x => x.Sloc).Distinct().ToList());
            var total = response.TotalRecord;
            var items = response.Records ?? new List<InventoryForm>();
            var records = isSearchConfirm ? items.Where(e => e.IsConfirm == true || e.QtyReCheck != 0).ToList() : items.ToList();
            var countReCord = isSearchConfirm ? records.Count() : 0;
            var model = new InventoryFormViewModel()
            {
                Items = records,
                Filter = _filter,
                PageNumber = pageNumber,
                PageSize = isSearchConfirm ? countReCord : _pageSize,
                TotalPage = isSearchConfirm ? 1 : (int)Math.Ceiling((double)total / _pageSize),
                Total = isSearchConfirm ? countReCord : total
            };
            return View("Views/Inventory/SearchInventoryFormBalance.cshtml", model);
        }

        //[HttpPost]
        //public async Task<IActionResult> DeleteInventoryOld([FromBody] InventoryFormFilter? _filter)
        //{
        //    try
        //    {
        //        if (!_filter.StartDate.HasValue && !_filter.EndDate.HasValue)
        //        {
        //            return BadRequest("Vui lòng chọn StartDate, EndDate trước khi xóa!");
        //        }
        //        await _apiService.AutoDeleteInventoryOld(new AutoBalanceRequest());
        //        return Json(new { success = true });
        //    }
        //    catch (Exception e)
        //    {
        //        return BadRequest(e.Message);
        //    }
        //}

        [HttpGet]
        public async Task<IActionResult> SearchInventoryFormKitting([FromQuery] InventoryFormKittingFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
            var responseDropdown = await _apiService.GetAllMasterSloc(new MasterSlocFilter(), Constants.PagingDefault, Constants.PageMaximum);
            var _filter = filter ?? new InventoryFormKittingFilter();
            if (string.IsNullOrEmpty(filter.Sloc) && !string.IsNullOrEmpty(filter.Plant) && !string.IsNullOrEmpty(filter.Category))
            {
                var listSloc = responseDropdown.Records.Where(s => s.Plant == filter.Plant && s.Category == filter.Category).Select(x => x.Sloc).Distinct().ToList();
                _filter.Sloc = string.Join(",", listSloc);
            }
            var isSearchConfirm = _filter.BalanceType != null && _filter.BalanceType.ToEnumMemberAttrValue() == "2";
            var response = await _apiService.SearchInventoryFormOKbyclosedate(_filter.Plant, _filter.Material, _filter.Sloc, _filter.IsAll, _filter.BalanceType != null ? _filter.BalanceType.ToEnumMemberAttrValue() : string.Empty, _filter.InventoryCloseDate, pageNumber, isSearchConfirm ? Constants.PageMaximum : _pageSize);

            ViewBag.SelectPlants = new SelectList(responseDropdown.Records.Select(x => x.Plant).Distinct().ToList());
            ViewBag.Categorys = new SelectList(responseDropdown.Records.Where(s => !string.IsNullOrEmpty(filter.Plant) ? s.Plant == filter.Plant : s.Plant == "").Select(x => x.Category).Distinct().ToList());
            ViewBag.Slocs = new SelectList(responseDropdown.Records.Where(s => !string.IsNullOrEmpty(filter.Plant) && !string.IsNullOrEmpty(filter.Category) ? s.Plant == filter.Plant && s.Category == filter.Category : s.Plant == "").Select(x => x.Sloc).Distinct().ToList());
            var total = response.TotalRecord;
            var items = response.Records ?? new List<InventoryForm>();
            var records = isSearchConfirm ? items.Where(e => e.IsConfirm == true || e.QtyReCheck != 0).ToList() : items.ToList();
            var countReCord = isSearchConfirm ? records.Count() : 0;
            var model = new InventoryFormKittingViewModel()
            {
                Items = records,
                Filter = _filter,
                PageNumber = pageNumber,
                PageSize = isSearchConfirm ? countReCord : _pageSize,
                TotalPage = isSearchConfirm ? 1 : (int)Math.Ceiling((double)total / _pageSize),
                Total = isSearchConfirm ? countReCord : total
            };
            return View("Views/Inventory/SearchInventoryFormKitting.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateBox([FromBody] List<QtyBalanceResponse> items)
        {
            try
            {

                await _apiService.UpdateBoxTemp(items);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> Confirm([FromBody] InventoryForm request)
        {
            try
            {
                var newRequest = new ConfirmBalanceRequest
                {
                    Plant = request.Plant,
                    Sloc = request.Sloc,
                    Material = request.Material,
                    Quantity = request.QtyReCheck
                };
                await _apiService.ConfirmBalanceQty(newRequest);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> AutoBalance([FromBody] InventoryFormFilter? _filter)
        {
            try
            {
                //var response = await _apiService.SearchInventoryFormOK(_filter.Plant, _filter.Material, _filter.Sloc, _filter.IsAll, 1, 9999999);
                //var items = response.Records ?? new List<InventoryForm>();

                await _apiService.AutoBalance(new AutoBalanceRequest
                {
                    Material = _filter.Material,
                    Sloc = _filter.Sloc,
                    Plant = _filter.Plant
                });
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmALLBox([FromBody] InventoryFormFilter? _filter)
        {
            try
            {
                var response = await _apiService.SearchInventoryFormOK(_filter.Plant, _filter.Material, _filter.Sloc, _filter.IsAll, string.Empty, 1, 9999999);
                var items = response.Records ?? new List<InventoryForm>();

                var lstRequest = items.Where(value => value.QtyReCheck != 0 || value.IsConfirm).ToList();
                if (lstRequest.Any())
                {
                    await _apiService.ConfirmALLBalanceQty(lstRequest.Select(e => new ConfirmBalanceRequest
                    {
                        Material = e.Material,
                        Sloc = e.Sloc,
                        Plant = e.Plant,
                        Quantity = e.QtyReCheck
                    }).ToList());
                    return Json(new { success = true });

                }
                return null;
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> DisQtyInventoryOld([FromBody] InventoryFormFilter filterData)
        {
            try
            {
                var request = new DisAndEnableQtyRequestVM
                {
                    EndDate = filterData.EndDate.ToString(Constants.YYYY_MM_DD),
                    StartDate = filterData.EndDate.ToString(Constants.YYYY_MM_DD),
                    Sloc = filterData.Sloc,
                    Category = filterData.Category,
                    KittingType = filterData.Type.ToEnumMemberAttrValue(),
                    IsEnable = false
                };
                await _apiService.AutoDisAndEnableQty(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> EnableQtyInventoryOld([FromBody] InventoryFormFilter filterData)
        {
            try
            {

                var request = new DisAndEnableQtyRequestVM
                {
                    EndDate = filterData.EndDate.ToString(Constants.YYYY_MM_DD),
                    StartDate = filterData.EndDate.ToString(Constants.YYYY_MM_DD),
                    Sloc = filterData.Sloc,
                    Category = filterData.Category,
                    KittingType = filterData.Type.ToEnumMemberAttrValue(),
                    IsEnable = true
                };
                await _apiService.AutoDisAndEnableQty(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<SelectList> OnChangePlantSloc(string plant, string category)
        {
            var responseDropdown = await _apiService.GetAllMasterSloc(new MasterSlocFilter(), Constants.PagingDefault, Constants.PageMaximum);
            var lstData = new SelectList(responseDropdown.Records.Where(s => s.Plant == plant && s.Category == category).Select(x => x.Sloc).Distinct().ToList());
            ViewBag.Slocs = lstData;
            return lstData;
        }

        [HttpPost]
        public async Task<SelectList> OnChangePlantCategory(string plant)
        {
            var responseDropdown = await _apiService.GetAllMasterSloc(new MasterSlocFilter(), Constants.PagingDefault, Constants.PageMaximum);
            var lstData = new SelectList(responseDropdown.Records.Where(s => s.Plant == plant).Select(x => x.Category).Distinct().ToList());
            ViewBag.Categorys = lstData;
            return lstData;
        }
    }
}
