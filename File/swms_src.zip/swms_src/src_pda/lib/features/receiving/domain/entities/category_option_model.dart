import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';

part 'category_option_model.g.dart';

/// Khớp `CategoryOptionResponse(int Code, string? Name)` phía API.
@JsonSerializable()
class CategoryOptionModel {
  final int code;
  final String? name;

  const CategoryOptionModel({required this.code, this.name});

  factory CategoryOptionModel.fromJson(Map<String, dynamic> json) =>
      _$CategoryOptionModelFromJson(json);

  Map<String, dynamic> toJson() => _$CategoryOptionModelToJson(this);

  /// Name trống → in mã số, để tem không bao giờ có ô Cate rỗng.
  Category toEntity() {
    final n = name?.trim();
    return Category(value: code, key: (n == null || n.isEmpty) ? '$code' : n);
  }
}