import 'package:injectable/injectable.dart';
import 'package:smart_warehouse/services/api_service.dart';
import 'package:smart_warehouse/services/models/request/robot_call_request_model.dart';
import 'package:smart_warehouse/services/models/request/robot_outpallet_request_model.dart';

@injectable
class RobotRepository{
  RobotRepository(this._apiService);
  final ApiService _apiService;
  Future<String?> CallRobot(RobotCallRequestModel request) async {
    return _apiService.Robot_call(request);
  }
  Future<String?> Outpallet(RobotOutpalletRequestModel request) async {
    return _apiService.Robot_outpallet(request);
  }

}