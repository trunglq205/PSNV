using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using System.ComponentModel.DataAnnotations;
using Microsoft.CSharp;

namespace SWMS_WebTool.ViewModels
{
    public class PrinterDeviceViewModel : TableViewModel<PrinterDevice, PrinterDeviceFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, PrinterDeviceFilter? filter = null)
        {
            return new
            {
                ID = filter?.ID ?? Filter.ID,
                MacAddress = filter?.MacAddress ?? Filter.MacAddress,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class CreateUpdatePrinterDeviceViewModel
    {
        [Required(ErrorMessage = "ID is required.")]
        public string ID { get; set; }
        [Display(Name = "Mac Address")]
        [Required(ErrorMessage = "Mac MacAddress is required.")]
        public string MacAddress { get; set; }
    }
}
