using Swms.FinishGoods.API.Features.PartCards.Api;
using Swms.FinishGoods.API.Shared.Models;

namespace Swms.FinishGoods.API.Features.PartCards.DataAccess;

public interface IPartCardRepository
{
    Task<PartCard?> GetByIdAsync(long id);
    Task<(IReadOnlyList<PartCard> Items, int Total)> GetPagedAsync(PartCardQuery query);
    Task<long> AddAsync(PartCard entity);

    // Phiếu chưa xoá có payload khớp tuyệt đối (kèm rows). Mới nhất trước.
    Task<IReadOnlyList<PartCard>> GetByPayloadsAsync(IReadOnlyCollection<string> payloads);

    // Truy vết phiếu [id], kể cả phiếu đã xoá mềm. Exists = false nếu id chưa từng tồn tại.
    Task<PartCardLineage> GetLineageAsync(long id);

    // Tách / gộp: tạo [replacements] + xoá mềm [sources] trong 1 transaction.
    // Khoá dòng nguồn (UPDLOCK, HOLDLOCK) rồi kiểm tra lại: còn tồn tại, payload chưa đổi,
    // chưa khoá tay, chưa vào OQC. Sai 1 phiếu là rollback toàn bộ.
    // Ghi nguồn gốc (mọi phiếu mới × mọi phiếu nguồn) vào wms.part_card_lineage.
    // [action]: PartCardLineageAction.Split | Merge.
    Task<PartCardReplaceResult> ReplaceAsync(
        IReadOnlyList<PartCard> sources, IReadOnlyList<PartCard> replacements,
        string action, string? userId);
    // Lưu nhiều phiếu (header + rows) trong 1 transaction; trả về id đã tạo.
    Task<List<long>> AddManyAsync(IReadOnlyList<PartCard> entities);

    // Sửa toàn bộ phiếu: update header + thay toàn bộ rows, trong 1 transaction.
    // entity.Id là phiếu cần sửa. Không đụng printed_at/by, created_at/by.
    // Ghi payload CŨ vào wms.part_card_lineage (action = edit) cùng transaction.
    Task<PartCardUpdateResult> UpdateAsync(PartCard entity, string? userId);

    // Cập nhật kích thước / trọng lượng cấp phiếu; trả false nếu không tìm thấy.
    Task<bool> UpdateDimensionsAsync(long id, decimal? length, decimal? width,
        decimal? height, decimal? weight, string? userId);

    // Xoá mềm (is_deleted = 1) các phiếu theo id.
    // Phiếu đang khoá KHÔNG bị xoá và được trả về ở Locked.
    Task<PartCardDeleteResult> SoftDeleteAsync(IReadOnlyCollection<long> ids, string? userId);

    // Khoá (locked = true) / mở khoá (locked = false) các phiếu theo id.
    Task<PartCardLockResult> SetLockedAsync(IReadOnlyCollection<long> ids, bool locked, string? userId);
}

// Kết quả xoá mềm. Id không nằm ở cả 2 list = không tồn tại / đã xoá trước đó.
public record PartCardDeleteResult(List<long> Deleted, List<long> Locked);

// Kết quả khoá / mở khoá.
//   Changed   — thực sự đổi trạng thái.
//   Unchanged — tồn tại nhưng đã ở sẵn trạng thái đích.
// Id không nằm ở cả 2 list = không tồn tại / đã xoá.
public record PartCardLockResult(List<long> Changed, List<long> Unchanged);

// 1 dòng truy vết đọc từ DB. RelatedId = phiếu BÊN KIA (nguồn hoặc phiếu sinh ra).
public sealed class PartCardLineageRow
{
    public string Action { get; set; } = "";
    public long RelatedId { get; set; }
    public string? Payload { get; set; }
    public bool IsDeleted { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
}

public record PartCardLineage(
    bool Exists, List<PartCardLineageRow> Sources, List<PartCardLineageRow> Derived);

// Giá trị cột wms.part_card_lineage.action (khớp CHECK constraint).
public static class PartCardLineageAction
{
    public const string Edit = "edit";
    public const string Split = "split";
    public const string Merge = "merge";
}

// Kết quả tách / gộp.
//   BlockedId — phiếu nguồn làm hỏng thao tác (khi Status <> Replaced).
//   NewIds    — id các phiếu vừa tạo, đúng thứ tự replacements (khi Replaced).
public record PartCardReplaceResult(PartCardReplaceStatus Status, long? BlockedId, List<long> NewIds);

public enum PartCardReplaceStatus
{
    Replaced,
    // Phiếu nguồn đã bị xoá / sửa (payload đổi) sau lúc đọc — vd máy khác vừa tách / gộp.
    Changed,
    // Phiếu nguồn đang khoá tay (is_locked = 1).
    Locked,
    // Phiếu nguồn đã vào quy trình OQC (Status_OQC <> 0).
    OqcLocked,
}

// Kết quả sửa phiếu.
public enum PartCardUpdateResult
{
    Updated,
    // Không tồn tại hoặc đã xoá mềm.
    NotFound,
    // Phiếu đã vào quy trình OQC (Status_OQC <> 0) — không cho sửa.
    Locked,
}