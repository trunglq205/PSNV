﻿namespace SWMS_WebTool.Models.Requests
{
    public class CreateUpdateFloorRequest
    {
        public long? Id { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public int Width { get; set; }
        public int Height { get; set; }

    }
}
