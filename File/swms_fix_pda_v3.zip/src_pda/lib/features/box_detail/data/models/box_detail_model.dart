import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart';

part 'box_detail_model.g.dart';

/// Khớp `BoxDetailResponse` của API.
///   GET   /api/boxes/{id}/detail
///   GET   /api/boxes/by-box-no/{boxNo}/detail?palletId=
///   PATCH /api/boxes/{id}
@JsonSerializable()
class BoxDetailModel {
  final int id;
  final String boxNo;
  final String? primaryModel;
  final int totalQty;
  final int serialCount;
  final String? customerPo;
  final String? psnvPo;
  final DateTime? productionDate;
  final String? oqcStatus;
  final int lotId;
  final String lotNo;
  /// Null được — xem ghi chú ở PalletBoxModel.payload.
  final String? payload;
  final int? locatorId;
  final String? locatorCode;
  final String? areaCode;
  final String? areaName;
  final List<BoxSerialModel> serials;

  const BoxDetailModel({
    required this.id,
    required this.boxNo,
    required this.totalQty,
    required this.serialCount,
    required this.lotId,
    required this.lotNo,
    this.payload,
    this.primaryModel,
    this.customerPo,
    this.psnvPo,
    this.productionDate,
    this.oqcStatus,
    this.locatorId,
    this.locatorCode,
    this.areaCode,
    this.areaName,
    this.serials = const [],
  });

  factory BoxDetailModel.fromJson(Map<String, dynamic> json) =>
      _$BoxDetailModelFromJson(json);

  BoxDetail toEntity() => BoxDetail(
    id: id,
    boxNo: boxNo,
    primaryModel: primaryModel,
    totalQty: totalQty,
    serialCount: serialCount,
    customerPo: customerPo,
    psnvPo: psnvPo,
    productionDate: productionDate,
    oqcStatus: InspectionStatus.fromKey(oqcStatus),
    lotId: lotId,
    lotNo: lotNo,
    payload: payload,
    locatorId: locatorId,
    locatorCode: locatorCode,
    areaCode: areaCode,
    areaName: areaName,
    serials: serials.map((e) => e.toEntity()).toList(),
  );
}

@JsonSerializable()
class BoxSerialModel {
  final int id;
  final String serialNo;
  final String model;

  const BoxSerialModel({
    required this.id,
    required this.serialNo,
    required this.model,
  });

  factory BoxSerialModel.fromJson(Map<String, dynamic> json) =>
      _$BoxSerialModelFromJson(json);

  BoxSerial toEntity() => BoxSerial(id: id, serialNo: serialNo, model: model);
}

/// Body PATCH /api/boxes/{id}.
/// `includeIfNull: true` — null nghĩa là XOÁ giá trị, không phải bỏ qua field.
@JsonSerializable(includeIfNull: true, createFactory: false)
class BoxPatchRequest {
  final String? customerPo;
  final String? psnvPo;

  const BoxPatchRequest({required this.customerPo, required this.psnvPo});

  Map<String, dynamic> toJson() => _$BoxPatchRequestToJson(this);
}
