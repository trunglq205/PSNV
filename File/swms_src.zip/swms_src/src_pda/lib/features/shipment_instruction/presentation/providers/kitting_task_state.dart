import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';

/// Bước của màn lấy hàng tại 1 vị trí.
///   Pallet chẵn: pickPallet → vanning → done
///   Pallet lẻ  : pickBoxes  → split   → vanning → done
enum KittingStep { pickPallet, pickBoxes, split, vanning, done }

class KittingTaskState {
  /// Dữ liệu màn lấy hàng từ server (task mới nhất + thùng).
  final AsyncValue<PickTaskDetail> detail;

  /// Pallet ID vừa quét khớp (chỉ dùng với lấy nguyên pallet).
  final String? scannedPalletCode;

  /// Đủ thùng trong lần mở này mà pallet còn thùng → chờ tách.
  final bool splitPending;

  /// Pallet đem ra vanning do người dùng quét — chỉ cần khi client không tự
  /// biết (sau khi tách: lot mới).
  final String? stagePalletCode;

  /// Mã vị trí vanning vừa quét, chưa lưu.
  final String? scannedVanningCode;

  /// Đang gửi 1 lệnh ghi (quét thùng / xác nhận / gỡ / lưu vanning) — chặn quét chồng.
  final bool busy;

  const KittingTaskState({
    this.detail = const AsyncValue.loading(),
    this.scannedPalletCode,
    this.splitPending = false,
    this.stagePalletCode,
    this.scannedVanningCode,
    this.busy = false,
  });

  int get pickedBoxCount => detail.value?.pickedBoxCount ?? 0;

  /// Pallet còn thùng chưa lấy → phải tách thùng đã lấy ra pallet riêng.
  bool get hasRemainingBoxes =>
      detail.value?.boxes.any((b) => b.state != PickBoxState.picked) ?? false;

  /// Bản mới nhất từ server; chưa nạp xong thì dùng task từ tuyến.
  PickTask taskOr(PickTask fallback) => detail.value?.task ?? fallback;

  KittingStep stepFor(PickTask fallback) {
    final t = taskOr(fallback);
    if (!t.isDone) {
      return t.mode == PickMode.wholePallet
          ? KittingStep.pickPallet
          : KittingStep.pickBoxes;
    }
    if (splitPending) return KittingStep.split;
    if ((t.stagedLocatorCode ?? '').isEmpty) return KittingStep.vanning;
    return KittingStep.done;
  }

  /// Pallet cần đưa ra vanning:
  ///   - nguyên pallet → chính pallet của task
  ///   - pallet lẻ     → luôn phải quét tem pallet chứa thùng đã lấy
  ///                     (null = chưa quét)
  String? vanningPalletFor(PickTask fallback) {
    if (stagePalletCode != null) return stagePalletCode;
    final t = taskOr(fallback);
    return t.mode == PickMode.wholePallet ? t.palletCode : null;
  }

  KittingTaskState copyWith({
    AsyncValue<PickTaskDetail>? detail,
    String? scannedPalletCode,
    bool clearScannedPallet = false,
    bool? splitPending,
    String? stagePalletCode,
    bool clearStagePallet = false,
    String? scannedVanningCode,
    bool clearScannedVanning = false,
    bool? busy,
  }) => KittingTaskState(
    detail: detail ?? this.detail,
    scannedPalletCode: clearScannedPallet
        ? null
        : (scannedPalletCode ?? this.scannedPalletCode),
    splitPending: splitPending ?? this.splitPending,
    stagePalletCode: clearStagePallet
        ? null
        : (stagePalletCode ?? this.stagePalletCode),
    scannedVanningCode: clearScannedVanning
        ? null
        : (scannedVanningCode ?? this.scannedVanningCode),
    busy: busy ?? this.busy,
  );
}