﻿using Refit;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models.Layout;
using SWMS_WebTool.Models.PMD;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Models.Responses;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Services
{
    public interface ApiService
    {
        #region Authentication
        [Post("/signinweb")]
        Task<LoginRespone> Login([Body] LoginRequest request);

        [Headers("Authentication: :true:")]
        [Put("/changepassword")]
        Task<LoginRespone> ChangePassword([Body] ChangePasswordRequest request);

        [Headers("Authentication: :true:")]
        [Post("/signout")]
        Task Logout();
        #endregion

        #region Delivery plan
        [Get("/deliveryplan/searchdeliveryplanitem")]
        Task<SearchResponse<DeliveryPlanModel>> SearchDaInvoice(DeliveryPlanFilter filter, int pageNumber, int pageSize);

        [Get("/deliveryplan/search_plan_order")]
        Task<SearchResponse<OrderPlan>> SearchOrderPlan(DeliveryPlanFilter filter, int pageNumber, int pageSize);

        [Get("/deliveryplan/get")]
        Task<DAInv> GetDeliveryPlans(int daInvId, DeliveryPlanType type);

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/createInvoice")]
        Task ImportInvoice([Body] List<InvoiceImport> invoices);

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/create_plan_order")]
        Task ImportPlanOrder([Body] List<PlanOrderImport> planOrders);

        [Headers("Authentication: :true:")]
        [Post("/receivingcard/createbydainvid")]
        Task<List<ReceivingCard>> PrintReceivingCardByDaInvId(CreateReceivingCardByDAInvID request);

        [Headers("Authentication: :true:")]
        [Put("/receivingcard/confirms")]
        Task ConfirmReceivingCards([Body] ComfirmJPTRequest request);

        [Get("/deliveryplan/gettimesimportplanorder")]
        Task<PlanOrderNumberRespone> GetPlanOrderNumber();

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/deleteplanorder")]
        Task DeletePlanOrder(string material, string planOrderNumber, string plant, string sloc);

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/deletedeliveryplan")]
        Task DeleteDeliveryPlan(long id);

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/delete-multiple-planOrder")]
        Task DeleteMultiplePlanOrder(string planOrderNumber);

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/delete-multiple-invoice")]
        Task DeleteMultipleInvoice(string poNo);

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/deleteinvoicenotyetgr")]
        Task DeleteInvoiceNotYetGR(string date);

        [Headers("Authentication: :true:")]
        [Post("/deliveryplan/deleteplanordernotyetgr")]
        Task DeletePlanOrderNotYetGR(string date);

        #endregion

        #region Good Receipt
        [Get("/goodreceipt/getgoodreceipts")]
        Task<SearchResponse<GoodReceipt>> SearchGoodReceipts(GoodReceiptFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/goodreceipt/updatetrackingnobyvendorcode")]
        Task InputTrackingNumber(UpdateTrackingNoByVendorCodeRequest request);

        [Headers("Authentication: :true:")]
        [Post("/goodreceipt/confirmgoodreceipt")]
        Task ConfirmGoodReceipts(ConfirmGoodReceiptRequest request);

        [Headers("Authentication: :true:")]
        [Put("/goodreceipt/confirmbackflush")]
        Task ConfirmBackFlush(ConfirmBackflushRequest request);

        [Headers("Authentication: :true:")]
        [Post("/goodreceipt/updatetruckingnobyupload")]
        Task ImportTrackingNumberByFile([Body] List<TrackingNumberImport> trackings);

        [Headers("Authentication: :true:")]
        [Post("/receivingcard/addscheduleprint")]
        Task CreateScheduleRC([Body] ReceivingSchedule request);

        [Get("/receivingcard/getschedulerc")]
        Task<ReceivingSchedule> GetScheduleRC();

        [Get("/receivingcard/searchreceivingcarddetail")]
        Task<ReceivingCardDetailViewModel> GetReceivingCardDetailByReceivingCardId(int type, long daInvoiceItemDetailId);

        #endregion

        #region Barcode NG
        [Get("/historyprint/getall")]
        Task<SearchResponse<BarcodeNG>> SearchBarcodeNG(BarcodeNGFilter filter, int pageNumber, int pageSize);
        #endregion

        #region SMT Panacim
        [Get("/definesmt/getpanacim")]
        Task<List<SMTPanacim>> SearchSMTPanacim(int receivingCardId, DateTime? date);

        [Headers("Authentication: :true:")]
        [Post("/definesmt/importnopanacim")]
        Task ImportNoPrintPanacim([Body] List<ImportNoPrintPanacim> requests);
        #endregion

        #region Receiving Card
        [Get("/receivingcard/read")]
        Task<ReceivingCard> GetReceivingCard(int receivingCardId);

        [Get("/receivingcard/searchsmtpanasim")]
        Task<SearchResponse<ReceivingCard>> SearchRCPanacim(SMTPanacimFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Put("/receivingcard/confirm")]
        Task UpdateQtyRC(long id, double quantity);

        [Headers("Authentication: :true:")]
        [Put("/receivingcard/revertforweb")]
        Task RevertRCGR(string Material, string DeliveryPlanNo, Byte Type);

        #endregion

        #region PO Pending
        [Get("/goodreceipt/searchpopending")]
        Task<SearchResponse<PurchaseOrderPending>> SearchPOPending(POPendingFilter filter, int pageNumber, int pageSize);

        #endregion

        #region Printer Device
        [Get("/printerdevice/getall")]
        Task<SearchResponse<PrinterDevice>> SearchPrinterDevice(PrinterDeviceFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/printerdevice/create")]
        Task CreatePrinterDevice(List<PrinterDevice> printerDevices);

        [Headers("Authentication: :true:")]
        [Put("/printerdevice/delete")]
        Task DeletePrinterDevice(List<string> printerDevices);
        #endregion

        #region Vendor
        [Get("/vendor/search")]
        Task<SearchResponse<Vendor>> SearchVendors(VendorFilter filter, int pageNumber, int pageSize);

        [Get("/vendor/read")]
        Task<Vendor> ReadVendor(string vendorCode);

        [Headers("Authentication: :true:")]
        [Post("/vendor/create")]
        Task CreateVendor(List<Vendor> vendors);

        [Headers("Authentication: :true:")]
        [Post("/vendor/update")]
        Task UpdateVendor(Vendor vendor);

        [Headers("Authentication: :true:")]
        [Put("/vendor/delete")]
        Task DeleteVendor(string vendercode);
        #endregion

        #region User
        [Get("/user/getall")]
        Task<SearchResponse<User>> SearchUsers(UserFilter filter, int pageNumber, int pageSize);

        [Get("/user/getuserbyuserid")]
        Task<User> GetUserByUserId(string userId);

        [Headers("Authentication: :true:")]
        [Post("/user/create")]
        Task CreateUser(CreateUserRequest request);

        [Headers("Authentication: :true:")]

        [Put("/user/delete")]
        Task DeleteUser(string userid);
        #endregion

        #region Material Info
        [Get("/qm/getall")]
        Task<SearchResponse<QM>> SearchQM(MaterialFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/qm/create")]
        Task ImportQM([Body] List<QM> qm);

        [Get("/typefrequency/getall")]
        Task<SearchResponse<TypeFrequency>> SearchTypeFrequency(MaterialFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/typefrequency/create")]
        Task ImportTypeFrequency([Body] List<TypeFrequency> typeFrequency);

        [Get("/urgent/getall")]
        Task<SearchResponse<UrgentULCOCRH>> SearchUrgent(MaterialFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/urgent/create")]
        Task ImportUrgent([Body] List<UrgentULCOCRH> urgentULCOCRH);

        [Get("/ulcocrh/getall")]
        Task<SearchResponse<UrgentULCOCRH>> SearchULCOCRH(MaterialFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/ulcocrh/create")]
        Task ImportULCOCRH([Body] List<UrgentULCOCRH> urgentULCOCRH);

        [Get("/material/getstandardpacking")]
        Task<SearchResponse<StandardPacking>> SearchStandardPacking(MaterialFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/material/createstandardpacking")]
        Task CreateStandardPacking([Body] List<StandardPacking> request);
        [Headers("Authentication: :false:")]
        [Post("/typefrequency/checktypef")]
        Task<List<CheckTypeFrequencyResponse>> CheckMasterTypeFrequency([Body] List<CheckTypeFrequencyImport> request);
        #endregion

        #region Layout
        [Get("/layout/layoutdetail")]
        Task<Floor> GetLayoutDetail(int id);

        [Headers("Authentication: :true:")]
        [Post("/layout/create_widget")]
        Task CreateWidget(CreateWidgetRequest request);
        #endregion

        #region Zone

        [Headers("Authentication: :true:")]
        [Post("/zone/create")]
        Task<Zone> CreateZone(CreateUpdateZoneRequest zone);

        [Headers("Authentication: :true:")]
        [Post("/zone/delete")]
        Task DeleteZone(long id);

        [Headers("Authentication: :true:")]
        [Post("/zone/update")]
        Task<Zone> UpdateZoneAsync(UpdateZoneRequest zone);
        #endregion

        #region Rack        
        [Headers("Authentication: :true:")]
        [Post("/rack/create")]
        Task<Rack> CreateRack(CreateUpdateRackRequest request);

        [Headers("Authentication: :true:")]
        [Post("/rack/delete")]
        Task DeleteRack(long id);

        [Headers("Authentication: :true:")]
        [Put("/rack/update")]
        Task<Rack> UpdateRack(UpdateRackRequest request);

        #endregion

        #region Floor
        [Get("/floor/getfloors")]
        Task<List<Floor>> GetFloors();

        [Headers("Authentication: :true:")]
        [Post("/floor/create")]
        Task CreateFloor(CreateUpdateFloorRequest floor);


        [Headers("Authentication: :true:")]
        [Post("/floor/update")]
        Task UpdateFloorAsync(CreateUpdateFloorRequest floor);

        [Headers("Authentication: :true:")]
        [Post("/floor/delete")]
        Task DeleteFloor(long id);
        #endregion

        #region Block
        [Get("/block/search")]
        Task<SearchResponse<BlockEntity>> SearchBlock(BlockFilter filter, int pageNumber, int pageSize);
        #endregion

        #region Category
        [Get("/category/search")]
        Task<SearchResponse<Category>> SearchCategory(CategoryFilter filter, int pageNumber, int pageSize);

        [Get("/category/getallcategoryplant")]
        Task<List<CategoryPlantMaster>> GetCategoryPlanMaster();

        [Get("/category/getcategorykittingtype")]
        Task<List<CategoryKittingtype>> GetCategoryKittingtype();

        [Headers("Authentication: :true:")]
        [Post("/category/save")]
        Task SaveCategory(Category request);

        [Headers("Authentication: :true:")]
        [Put("/category/delete")]
        Task DeleteCategory(string categoryId);
        #endregion

        #region Storage
        [Get("/storage/search")]
        Task<SearchResponse<ReceivingCardStorage>> SearchRCStorage(ReceivingCardStorageFilter filter, int pageNumber, int pageSize);

        [Get("/storage/searchcheckstorage")]
        Task<SearchResponse<CheckStorage>> SearchCheckStorage(CheckStorageFilter filter, int pageNumber, int pageSize);

        [Get("/storage/getrcstoragedetail")]
        Task<IEnumerable<RCStorageDetailViewModel>> GetRCStorageDetails(RCStorageDetailRequest request);

        [Get("/storage/getrctempdetail")]
        Task<IEnumerable<RCTempDetailViewModel>> GetRCTempDetails(RCStorageDetailRequest request);
        [Get("/storage/searchlayoutcapacity")]
        Task<SearchResponse<LayoutCapacity>> SearchLayoutCapacity(LayoutCapacityFilter filter, int pageNumber, int pageSize);
        #endregion

        #region Kitting
        //Tuấn Anh comment
        [Headers("Authentication: :true:")]
        [Post("/kitting/importkittinglist")]
        Task<IEnumerable<KittingListResponse>> CreateKittingList([Body] List<KittingListRequest> request);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createkittingplan")]
        Task ImportKittingPlan([Body] List<KittingPlanImport> request);

        [Get("/kitting/getdatakittingfa")]
        Task<SearchResponse<KittingPlan>> GetDataKittingFA(KittingPlanFilter filter, int PageNumber, int PageSize);

        [Get("/kitting/getdataplanfa")]
        Task<SearchResponse<KittingPlan>> GetDataKittingPlanFA(KittingPlanFilter filter, int PageNumber, int PageSize);

        [Get("/kitting/getdataplandip")]
        Task<SearchResponse<KittingPlan>> GetDataKittingPlanDIP(KittingPlanFilter filter, int PageNumber, int PageSize);
        [Get("/kitting/getdatakittingdip")]
        Task<SearchResponse<KittingPlan>> GetDataKittingDIP(KittingPlanFilter filter, int pageNumber, int pageSize);
        [Get("/kitting/getdatakittingsubcon")]
        Task<SearchResponse<KittingPlan>> GetDataKittingSubcon(KittingPlanFilter filter, int PageNumber, int PageSize);
        [Get("/kitting/getdatakittingoutside")]
        Task<SearchResponse<KittingPlan>> GetDataKittingOutside(KittingPlanFilter filter, int PageNumber, int PageSize);
        [Headers("Authentication: :true:")]
        [Post("/kitting/createdatakittingfa")]
        Task ImportKittingPlanFA([Body] List<KittingPlanImport> request);

        [Headers("Authentication: :true:")]
        [Post("/kitting/importmodelmapping")]
        Task ImportModelMapping([Body] List<ModelMapping> request);

        [Get("/kitting/getmodelmapping")]
        Task<SearchResponse<ModelMapping>> GetDataModelMapping(ModelMappingFilter filter, int PageNumber, int PageSize);

        [Get("/kitting/getmodelkittingdip")]
        Task<SearchResponse<DataKittingDIPModel>> GetModelKittingDIP(ModelMappingFilter filter, int PageNumber, int PageSize);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createkittingline")]
        Task CreateKittingLine([Body] List<KittingListFARequest> request);

        [Get("/kitting/getkittingline")]
        Task<SearchResponse<KittingPlan>> GetKittingLine(KittingPlanFilter filter, int PageNumber, int PageSize);

        [Headers("Authentication: :true:")]
        [Post("/kitting/deletekittingplanfa")]
        Task DeleteKittingPlanFA([Body] List<int> ids);

        [Headers("Authentication: :true:")]
        [Post("/kitting/deletekittingplandip")]
        Task DeleteKittingPlanDIP([Body] List<int> ids);

        [Headers("Authentication: :true:")]
        [Post("/kitting/deletemodelkittingdip")]
        Task DeleteModelKittingDIP([Body] List<int> ids);

        [Headers("Authentication: :true:")]
        [Post("/kitting/deletekittingplansubcon")]
        Task DeleteKittingPlanSubcon([Body] List<int> ids);

        [Headers("Authentication: :true:")]
        [Post("/kitting/deletekittingplanoutside")]
        Task DeleteKittingPlanOutside([Body] List<int> ids);

        [Headers("Authentication: :true:")]
        [Post("/kitting/deletekittinglist")]
        Task DeleteKittingList([Body] List<int> ids);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createdatakittingdip")]
        Task ImportKittingPlanDIP([Body] List<KittingPlanDIPImport> request);

        [Headers("Authentication: :true:")]
        [Post("/kitting/importmodelkittingdip")]
        Task ImportActualPlanDIP([Body] List<ActualPlanImport> request);

        [Get("/kitting/searchkittinglist")]
        Task<SearchResponse<KittingList>> SearchKittingList(KittingListFilter filter, int PageNumber, int PageSize);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createdatakittingsubcon")]
        Task ImportKittingPlanSubcon([Body] List<KittingPlanImport> request);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createdatakittingoutside")]
        Task ImportKittingPlanOutside([Body] List<KittingPlanImport> request);

        [Get("/kitting/getkittinglistbyktingid")]
        Task<List<KittingListDetail>> GetKittingListDetailByKTLId(long id);

        [Get("/kitting/searchkittinglistdetailbyuser")]
        Task<SearchResponse<KittingListDetail>> SearchKittingListDetailByUserKitting(SearchKittingListDetails request, int pageNumber, int pageSize);

        [Get("/kitting/gethistorykittingdelete")]
        Task<List<KittingList>> GetHistoryKittingDelete(byte tab, int PageNumber, int PageSize);

        [Headers("Authentication: :true:")]
        [Post("/kitting/revertkittinglist")]
        Task RevertKittingList(string ids);

        [Get("/kitting/searchkittingreport")]
        Task<SearchResponse<KittingReport>> SearchKittingReport(KittingFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/kitting/replacekittinglistdetail")]
        Task ReplaceKittingListDetail([Body] ReplaceKittingListDetailRequest request);

        [Get("/kitting/getkittinglistdetailbyid")]
        Task<KittingListDetail> GetKittingListDetailByID(long id);

        [Get("/storage/getlocationfirstinbymaterial")]
        Task<LocationFirstInByMaterialResponseVM> GetLocationFirstInByMaterial(string material);

        [Headers("Authentication: :true:")]
        [Put("/kitting/transferkitting")]
        Task TransferKittingList(string newPicUser, long kittinglistid);

        [Headers("Authentication: :true:")]
        [Put("/kitting/transferkittingmaterial")]
        Task TransferKittingListMaterial(string newPicUser, string listID);

        [Headers("Authentication: :true:")]
        [Put("/kitting/confirmkittingsubcon")]
        Task ConfirmKittingSubconJPT([Body] List<ConfirmKittingSubconRequest> requests);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createkittingcardoutside")]
        Task<IEnumerable<KittingCardOutsideResponse>> CreateKittingCardOutside([Body] List<CreateKittingCardOtherRequest> requests);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createkittingcardsubcon")]
        Task<IEnumerable<KittingCardOutsideResponse>> CreateKittingCardSubcon([Body] List<CreateKittingCardOtherRequest> requests);


        //Tuấn Anh sửa
        [Get("/kitting/reprintkitting")]
        //Task<IEnumerable<KittingListResponse>> ReprintKittingList(long Id);
        Task<IEnumerable<KittingListResponse>> ReprintKittingList(long Id);

        [Get("/kitting/gethistorykittingtransfer")]
        Task<IEnumerable<HistoryTransferKitting>> GetHistoryKittingTransfer(string picuser);

        [Get("/kitting/getuploadno")]
        Task<IEnumerable<string>> GetUploadNo(byte? kittingType, string deliveryDate);

        [Get("/kitting/getuploadnokittingplan")]
        Task<IEnumerable<string>> GetUploadNoKittingPlan(byte? kittingType, string deliveryDate);

        [Headers("Authentication: :true:")]
        [Post("/kitting/deletekittinglistdetail")]
        Task DeleteKittingListDetails([Body] List<int> ids);

        [Get("/layout/smartwarehouskittingemap")]
        Task<ListSuggestKittingResponse> GetListSuggestKitting(GetListSuggestKittingRequest request);
        [Get("/layout/suggestkitting")]
        Task<SuggestKittingResponse> SuggestKitting([Body] List<string> locations);

        [Get("/kitting/getrulekitting")]
        Task<IEnumerable<RuleKitting>> GetAllRuleKitting(SearchRuleKittingRequest request);

        [Get("/kitting/getdatakittingfaauto")]
        Task<SearchResponse<KittingPlan>> GetDataKittingFAAuto(KittingPlanFilter filter, int PageNumber, int PageSize);

        [Get("/kitting/getkittinglistbykey")]
        Task<KittingList> GetKittingListByID(Int64? id, string barcode);

        [Headers("Authentication: :true:")]
        [Post("/kitting/updatesupplyreason")]
        Task UpdateSupplyReason([Body] UpdateSupplyRequest request);

        [Headers("Authentication: :true:")]
        [Post("/kitting/createblocksapschedule")]
        Task CreateBlockSapSchedule([Body] BlockSapScheduleRequest request);

        [Get("/kitting/getallblocksapschedule")]
        Task<IEnumerable<BlockSapSchedule>> GetALlBlockSapSchedule();

        [Headers("Authentication: :true:")]
        [Post("/kitting/createblocksapscheduleplan")]
        Task CreateBlockSapSchedulePlan([Body] List<BlockSapSchedulePlanRequest> request);

        [Get("/kitting/getallblocksapscheduleplan")]
        Task<IEnumerable<BlockSapSchedulePlan>> GetALlBlockSapSchedulePlan();
        #endregion

        #region Material Detail
        [Get("/materialdetail/getall")]
        Task<SearchResponse<MaterialDetail>> GetAllMaterialDetail(int pageNumber, int pageSize);

        [Get("/materialdetail/getbyid")]
        Task<MaterialDetail> GetMaterialDetailById(long id);

        [Headers("Authentication: :true:")]
        [Post("/materialdetail/createorupdate")]
        Task CreateOrUpdateMaterialDetail([Body] MaterialDetailRequest request);

        [Headers("Authentication: :true:")]
        [Post("/materialdetail/delete")]
        Task DeleteMaterialDetail(long id);

        [Headers("Authentication: :true:")]
        [Post("/materialdetail/importdata")]
        Task ImportMaterialDetail([Body] List<ImportMaterialDetailViewModel> request);

        [Headers("Authentication: :true:")]
        [Post("/materialdetail/uploadimage")]
        Task UploadImageMaterialDetail([Body] UploadImageRequest request);

        [Headers("Authentication: :true:")]
        [Post("/materialdetail/uploadmultipleimage")]
        Task UploadImageMaterialDetail([Body] UploadMultipleRequestVM request);
        #endregion

        #region Inventory
        [Get("/inventory/search")]
        Task<SearchResponse<Inventory>> SearchInventory(InventoryFilter filter, int pageNumber, int pageSize);

        [Get("/inventory/searchgoodreceipt")]
        Task<SearchResponse<InventoryGoodReceipt>> SearchGoodReceipt(InvenoryGoodReceiptFilter filter, int pageNumber, int pageSize);

        [Get("/inventory/searchstored")]
        Task<SearchResponse<InventoryStoredQuantity>> SearchStoredQuantity(InventoryStoredQuantityFilter filter, int pageNumber, int pageSize);

        [Get("/inventory/searchmovedout")]
        Task<SearchResponse<InventotyMovedOut>> SearchMovedOut(InventoryMovedOutFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/inventory/createsapstock")]
        Task ImportSapStock([Body] List<SapStockImport> request);
        [Get("/inventory/getqtybalancebox")]
        Task<SearchResponse<InventoryForm>> GetQtyBalanceBox(string plant, string material, string sloc, bool? isAll, int PageNumber, int PageSize);


        [Headers("Authentication: :true:")]
        [Post("/inventory/confirmbalanceqty")]
        Task ConfirmBalanceQty([Body] ConfirmBalanceRequest request);
        [Headers("Authentication: :true:")]
        [Post("/inventory/confirmallbalanceqty")]
        Task ConfirmALLBalanceQty([Body] List<ConfirmBalanceRequest> request);
        [Post("/inventory/updateboxtemp")]
        Task UpdateBoxTemp([Body] List<QtyBalanceResponse> request);
        [Get("/inventory/searchsapstock")]
        Task<SearchResponse<SAPStock>> SearchSAPStock(SapStockFilter filter, int pageNumber, int pageSize);

        [Get("/inventory/getlistinventoryok")]
        Task<SearchResponse<InventoryForm>> SearchInventoryFormOK(string plant, string material, string sloc, bool? isAll, string balanceType, int PageNumber, int PageSize);

        [Get("/inventory/getlistinventoryokbyclosedate")]
        Task<SearchResponse<InventoryForm>> SearchInventoryFormOKbyclosedate(string plant, string material, string sloc, bool? isAll, string balanceType,DateTime inventoryclosedate,  int PageNumber, int PageSize);

        [Get("/inventory/getlistoverdue")]
        Task<SearchResponse<ExpiredGoods>> SearchExpiredGoods(ExpiredGoodsFilter filter, int PageNumber, int PageSize);

        [Headers("Authentication: :true:")]
        [Post("/inventory/autobalance")]
        Task AutoBalance([Body] AutoBalanceRequest request);

        [Headers("Authentication: :true:")]
        [Post("/inventory/disandenableqty")]
        Task AutoDisAndEnableQty([Body] DisAndEnableQtyRequestVM request);
        #endregion

        #region Plan Print Panacim

        [Headers("Authentication: :true:")]
        [Post("/definesmt/createplanprintpanacim")]
        Task ImportPlanPrintPanacim([Body] List<ImportPlanPanacim> requests);

        [Get("/definesmt/searchplanprintpanacim")]
        Task<SearchResponse<PlanPrintPanacim>> SearchPlanPrintPanacim(PlanPanacimFilter filter, int pageNumber, int pageSize);
        #endregion



        #region PMD

        [Get("/PMD/searchPurgingRunnerNGPMD")]
        Task<SearchResponse<PurgingRunnerNGPMD>> PurgingRunnerNGPMDSearch(PurgingRunnerNGPMDFilter filter, int pageNumber, int pageSize);

        [Headers("Authentication: :true:")]
        [Post("/PMD/deletePurgingRunnerNGPMD")]
        Task<SearchResponse<PurgingRunnerNGPMD>> DeletePurgingRunnerNGPMD(PurgingRunnerNGPMD item);

        [Headers("Authentication: :true:")]
        [Post("/PMD/confirmpurgingrunnerngpmd")]
        Task<SearchResponse<PurgingRunnerNGPMD>> ConfirmPurgingRunnerNGPMD(PurgingRunnerNGPMD item);

        [Headers("Authentication: :true:")]
        [Post("/PMD/confirmpurgingrunnerngpmdall")]
        Task<SearchResponse<PurgingRunnerNGPMD>> ConfirmPurgingRunnerNGPMDAll( List<PurgingRunnerNGPMD> items);



        [Get("/PMD/searchPMDReturn")]
        Task<SearchResponse<PMDReturnRecycleModel>> PMDReturnSearch(PMDReturnRecycleFilter filter, int pageNumber, int pageSize);

        [Get("/PMD/searchPMDRecycle")]
        Task<SearchResponse<PMDReturnRecycleModel>> PMDRecycleSearch(PMDReturnRecycleFilter filter, int pageNumber, int pageSize);



        #endregion


        #region Trolley
        [Get("/trolley/getall")]
        Task<SearchResponse<TrolleyResponse>> GetAllTrolley(TrolleyFilter filter, int pageNumber, int pageSize);

        [Get("/trolley/getbyid")]
        Task<Trolley> GetTrolleyById(long id);

        [Headers("Authentication: :true:")]
        [Post("/trolley/create")]
        Task<Trolley> CreateTrolley(CreateTrolleyRequest request);


        [Headers("Authentication: :true:")]
        [Post("/trolley/delete")]
        Task DeleteTrolley(long id);
        #endregion

        #region Supply
        [Get("/trolleykitting/getsupply")]
        Task<SearchResponse<Supply>> GetSupply(SupplyRequestVM filter, int pageNumber, int pageSize);

        [Get("/trolleykitting/getall")]
        Task<List<TrolleyKitting>> GetAllTrolleyKitting([Query] string category, string? model = null, string? date = null, string? time = null, string? line = null, string? material = null);
        #endregion

        #region Backflush

        [Get("/goodreceipt/searchbackflush")]
        Task<SearchResponse<BackFlush>> SearchBackFlush(BackFlushFilter filter, int pageNumber, int pageSize);

        [Get("/goodreceipt/searchbackflushdetail")]
        Task<List<BackFlushDetailResponseVM>> SearchBackFlushDetail(long receivingCardId);
        #endregion

        #region Master Sloc
        [Get("/mastersloc/getall")]
        Task<SearchResponse<MasterSloc>> GetAllMasterSloc(MasterSlocFilter filter, int pageNumber, int pageSize);

        [Get("/goodreceipt/dainvisjpt")]
        Task<List<DAInvIsJPTViewModel>> GetDAInvIsJPT();

        [Headers("Authentication: :true:")]
        [Post("/mastersloc/import")]
        Task ImportMasterSloc([Body] List<ImportMasterSlocViewModel> requests);
        #endregion

        #region Abnormal Report

        [Get("/abnormalreport/getall")]
        Task<SearchResponse<AbnormalReport>> GetAllAbnormalReport([Query] AbnormalReportFilter request);

        [Get("/abnormalreport/getbyid")]
        Task<AbnormalReport> GetAbnormalReportById([Query] Guid id);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/create")]
        Task<CreateReportResponse> CreateUpdateAbnormalReport([Body] AbnormalReportRequestVM request);

        [Headers("Authentication: :true:")]
        [Put("/abnormalreport/delete")]
        Task DeleteAbnormalReport([Query] Guid id);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/sendtoiqcpus")]
        Task SendToIQCPUS([Query] Guid id);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/confirmiqc")]
        Task ConfirmIQCAbnormalReport([Body] IQCConfirmRequestVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/approveiqc")]
        Task ApproveIQCAbnormalReport([Body] ApproveRequestVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/requestupdateiqc")]
        Task RequestUpdateIQCAbnormalReport([Body] RequestUpdateVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/confirmpus")]
        Task ConfirmPUSAbnormalReport([Body] PUSConfirmRequestVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/approvepus")]
        Task ApprovePUSAbnormalReport([Body] ApproveRequestVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/requestupdatepus")]
        Task RequestUpdatePUSAbnormalReport([Body] RequestUpdateVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/confirmmcs")]
        Task ConfirmMCSAbnormalReport([Body] MCSConfirmRequestVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/approvemcs")]
        Task ApproveMCSAbnormalReport([Body] ApproveRequestVM request);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/requestupdatemcs")]
        Task RequestUpdateMCSAbnormalReport([Body] RequestUpdateVM request);


        [Get("/abnormalreport/images")]
        Task<List<AbnormalReportImageVM>> GetReportImages([Query] Guid reportId);

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/uploadimage")]
        Task UploadReportImage([Body] AbnormalReportImageUploadRequest request); 


        [Headers("Authentication: :true:")]
        [Delete("/abnormalreport/deleteimage")]
        Task DeleteReportImage([Query] Guid imageId);

        #endregion

        #region Abnormal Report Email Config

        [Get("/abnormalreport/emailconfig/get")]
        Task<AbnormalReportEmailConfigRequest> GetAbnormalReportEmailConfig();

        [Headers("Authentication: :true:")]
        [Post("/abnormalreport/emailconfig/save")]
        Task SaveAbnormalReportEmailConfig([Body] AbnormalReportEmailConfigRequest request);

        #endregion

        [Get("/layout/infogenqr")]
        Task<List<GetInfoLocationForGenQRResponseVM>> GetInfoLocationForGens(long id, int isLocation);

        [Get("/goodreceipt/dainvisjpt")]
        Task<List<DAInvIsJPTViewModel>> GetDAInvIsJPT(int type, string date, string no);
    }
}
