﻿using System.Data;
using Dapper;
using Swms.FinishGoods.API.Features.OqcSamples.Business.Entities;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.OqcSamples.DataAccess
{
    public class OqcSampleRepository : IOqcSampleRepository
    {
        private readonly IDbConnectionFactory _factory;
        public OqcSampleRepository(IDbConnectionFactory factory) => _factory = factory;

        public async Task<PalletLocationResult?> GetLocationAsync(
            string model, DateTime? productionDate, string? payload)
        {
            using var conn = _factory.Create();
            // SP trả PalletId/Locator -> Dapper map thẳng record, không map tay.
            return await conn.QueryFirstOrDefaultAsync<PalletLocationResult>(
                "wms.usp_oqc_get_locations",
                new { model, production_date = productionDate, payload },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<int> SampleAsync(
            string model, string productionDate, string? lotName, string? user,
            string? barcode, string? line = null)
        {
            using var conn = _factory.Create();
            return await conn.ExecuteScalarAsync<int>(
                "wms.usp_oqc_sample",
                new
                {
                    model,
                    production_date = productionDate,   // ISO yyyy-MM-dd (service chuẩn hoá)
                    line,
                    lot_name = lotName,
                    user,
                    barcode,
                },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<int> ReturnAsync(string model, string productionDate, string? barcode, string? user)
        {
            using var conn = _factory.Create();
            return await conn.ExecuteScalarAsync<int>(
                "wms.usp_oqc_return",
                new { model, production_date = productionDate, user, barcode },
                commandType: CommandType.StoredProcedure);
        }

        public async Task<int> UpdateStatusAsync(
            string model, int statusCode, string? lotName, string? user)
        {
            using var conn = _factory.Create();
            return await conn.ExecuteScalarAsync<int>(
                "wms.usp_oqc_update_status",
                new
                {
                    model,
                    status = statusCode,
                    lot_name = lotName,
                    user,
                },
                commandType: CommandType.StoredProcedure);
        }
    }
}