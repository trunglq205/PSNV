// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ng_models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

NgReportModel _$NgReportModelFromJson(Map<String, dynamic> json) =>
    NgReportModel(
      id: (json['id'] as num).toInt(),
      docNo: json['docNo'] as String,
      ngType: json['ngType'] as String,
      discoveredAt: DateTime.parse(json['discoveredAt'] as String),
      docStatus: json['docStatus'] as String,
      currentStep: json['currentStep'] as String,
      leaderStatus: json['leaderStatus'] as String,
      faStatus: json['faStatus'] as String,
      oqcStatus: json['oqcStatus'] as String,
      resolution: json['resolution'] as String,
      itemCount: (json['itemCount'] as num).toInt(),
      qtyAffected: (json['qtyAffected'] as num).toInt(),
      photoCount: (json['photoCount'] as num).toInt(),
      isWholePallet: json['isWholePallet'] as bool? ?? false,
      palletCode: json['palletCode'] as String?,
      model: json['model'] as String?,
      faResolution: json['faResolution'] as String?,
      createdBy: json['createdBy'] as String?,
    );

NgItemModel _$NgItemModelFromJson(Map<String, dynamic> json) => NgItemModel(
  id: (json['id'] as num).toInt(),
  scope: json['scope'] as String,
  qtyAffected: (json['qtyAffected'] as num).toInt(),
  code: json['code'] as String?,
  note: json['note'] as String?,
);

NgPhotoModel _$NgPhotoModelFromJson(Map<String, dynamic> json) => NgPhotoModel(
  id: (json['id'] as num).toInt(),
  fileName: json['fileName'] as String,
  sortOrder: (json['sortOrder'] as num).toInt(),
  caption: json['caption'] as String?,
);

NgApprovalModel _$NgApprovalModelFromJson(Map<String, dynamic> json) =>
    NgApprovalModel(
      id: (json['id'] as num).toInt(),
      step: json['step'] as String,
      action: json['action'] as String,
      actedAt: DateTime.parse(json['actedAt'] as String),
      resolution: json['resolution'] as String?,
      comment: json['comment'] as String?,
      actedBy: json['actedBy'] as String?,
    );

NgDetailModel _$NgDetailModelFromJson(
  Map<String, dynamic> json,
) => NgDetailModel(
  header: NgReportModel.fromJson(json['header'] as Map<String, dynamic>),
  items: (json['items'] as List<dynamic>)
      .map((e) => NgItemModel.fromJson(e as Map<String, dynamic>))
      .toList(),
  photos: (json['photos'] as List<dynamic>)
      .map((e) => NgPhotoModel.fromJson(e as Map<String, dynamic>))
      .toList(),
  approvals: (json['approvals'] as List<dynamic>)
      .map((e) => NgApprovalModel.fromJson(e as Map<String, dynamic>))
      .toList(),
  description: json['description'] as String?,
  leaderBy: json['leaderBy'] as String?,
  leaderAt: json['leaderAt'] == null
      ? null
      : DateTime.parse(json['leaderAt'] as String),
  leaderComment: json['leaderComment'] as String?,
  faBy: json['faBy'] as String?,
  faAt: json['faAt'] == null ? null : DateTime.parse(json['faAt'] as String),
  faComment: json['faComment'] as String?,
  oqcBy: json['oqcBy'] as String?,
  oqcAt: json['oqcAt'] == null ? null : DateTime.parse(json['oqcAt'] as String),
  oqcComment: json['oqcComment'] as String?,
  finalizedBy: json['finalizedBy'] as String?,
  finalizedAt: json['finalizedAt'] == null
      ? null
      : DateTime.parse(json['finalizedAt'] as String),
  finalComment: json['finalComment'] as String?,
  cancelledBy: json['cancelledBy'] as String?,
  cancelledAt: json['cancelledAt'] == null
      ? null
      : DateTime.parse(json['cancelledAt'] as String),
  cancelReason: json['cancelReason'] as String?,
);

Map<String, dynamic> _$CreateNgItemModelToJson(CreateNgItemModel instance) =>
    <String, dynamic>{
      'scope': instance.scope,
      'code': ?instance.code,
      'qtyAffected': ?instance.qtyAffected,
      'note': ?instance.note,
    };

Map<String, dynamic> _$CreateNgReportModelToJson(
  CreateNgReportModel instance,
) => <String, dynamic>{
  'palletCode': instance.palletCode,
  'ngType': instance.ngType,
  'description': ?instance.description,
  'items': instance.items,
};

CreateNgResultModel _$CreateNgResultModelFromJson(Map<String, dynamic> json) =>
    CreateNgResultModel(
      id: (json['id'] as num).toInt(),
      docNo: json['docNo'] as String,
    );

NgPalletCheckModel _$NgPalletCheckModelFromJson(Map<String, dynamic> json) =>
    NgPalletCheckModel(
      id: (json['id'] as num).toInt(),
      code: json['code'] as String,
      isUrgent: json['isUrgent'] as bool? ?? false,
      model: json['model'] as String?,
      boxCount: (json['boxCount'] as num?)?.toInt(),
      inspectionStatus: json['inspectionStatus'] as String?,
      productionDate: json['productionDate'] == null
          ? null
          : DateTime.parse(json['productionDate'] as String),
      locatorCode: json['locatorCode'] as String?,
      areaName: json['areaName'] as String?,
    );

NgTypeModel _$NgTypeModelFromJson(Map<String, dynamic> json) => NgTypeModel(
  code: json['code'] as String,
  name: json['name'] as String,
  note: json['note'] as String?,
  requiresOqc: json['requiresOqc'] as bool? ?? true,
);
