namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Số phiên bản của bộ nhớ đệm quyền. Tăng lên một là mọi mục đã đệm trở nên
/// không với tới được, vì khoá đệm có kèm số này.
///
/// VÌ SAO KHÔNG XOÁ THEO TỪNG USER: <c>DbCachedUserPermissionProvider</c> đệm
/// theo <c>perms:user:{id}</c>, nhưng thứ thay đổi lại là quyền của một ROLE —
/// ảnh hưởng mọi user mang role đó, mà lúc sửa role ta không có danh sách user
/// trong tay. Truy ngược ra danh sách rồi xoá từng khoá là thêm một câu query
/// và vẫn sót user vừa được gán role trong cùng lúc. Đổi số phiên bản thì không
/// cần biết ai bị ảnh hưởng.
///
/// Mục cũ không bị xoá ngay mà tự hết hạn sau TTL (5 phút) — chấp nhận được, nó
/// chỉ chiếm chỗ chứ không còn ai đọc tới.
///
/// ⚠ Chỉ có tác dụng TRONG MỘT TIẾN TRÌNH. Chạy nhiều instance API sau cân bằng
/// tải thì instance khác vẫn giữ bộ đệm cũ cho tới khi hết TTL. Đây là giới hạn
/// sẵn có của <c>IMemoryCache</c> mà bản gốc cũng đã chịu, không phải điều lớp
/// này làm tệ đi. Muốn hết hẳn thì phải chuyển bộ đệm sang Redis hoặc bỏ đệm.
/// </summary>
public sealed class PermissionCacheVersion
{
    private long _version;

    public long Current => Interlocked.Read(ref _version);

    /// <summary>Gọi sau MỌI thay đổi ảnh hưởng tới quyền hiệu lực của user.</summary>
    public void Bump() => Interlocked.Increment(ref _version);
}
