using Swms.FinishGoods.API.Features.StowagePlans.Api;

namespace Swms.FinishGoods.API.Features.StowagePlans.Business;

public interface IStowagePlanService
{
    /// <summary>Chuyến container còn mở (mỗi chuyến 1 plan) + plan không gắn chuyến.</summary>
    Task<List<VanningPlanSummaryDto>> GetListAsync(StowagePlanQuery query);

    /// <summary>planNo = số plan đã lưu, hoặc "VP-T{tripId}" cho chuyến chưa lập sơ đồ.</summary>
    Task<StowagePlanDto> GetAsync(string planNo);

    /// <summary>Thay toàn bộ sơ đồ. Chuyến chưa có plan thì tạo plan mới gắn chuyến.</summary>
    Task<StowagePlanDto> SaveAsync(string planNo, SaveStowagePlanRequest request);
}
