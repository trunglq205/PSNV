using Swms.FinishGoods.API.Features.Stocky.Business;
using Swms.FinishGoods.API.Features.Stocky.DataAccess;

namespace Swms.FinishGoods.API.Features.Stocky;

public static class StockyModule
{
    public static IServiceCollection AddStockyFeature(
        this IServiceCollection services, IConfiguration configuration)
    {
        // Kiểm cấu hình NGAY LÚC KHỞI ĐỘNG. Thiếu mã ô đậu xe / ô FA thì API
        // không lên, thay vì lên rồi đổ 500 vào mặt người đầu tiên bấm nút
        // Stocky — mà lỗi đó lại xảy ra ở hiện trường, giữa ca.
        //
        // Cố tình VỨT kết quả đi: StockyService đọc lại mỗi request để sửa
        // appsettings trên server có hiệu lực ngay, không phải restart. Giữ
        // lại thành singleton là mất tính chất đó.
        _ = StockyOptions.Validated(configuration);

        services.AddScoped<IStockyService, StockyService>();
        services.AddScoped<IStockyRepository, StockyRepository>();
        return services;
    }
}

// ServiceCollectionExtensions.AddFeatures():
//   .AddStockyFeature()
