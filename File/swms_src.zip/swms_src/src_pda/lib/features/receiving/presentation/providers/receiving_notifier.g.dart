// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'receiving_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ReceivingNotifier)
final receivingProvider = ReceivingNotifierProvider._();

final class ReceivingNotifierProvider
    extends $NotifierProvider<ReceivingNotifier, ReceivingState> {
  ReceivingNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'receivingProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$receivingNotifierHash();

  @$internal
  @override
  ReceivingNotifier create() => ReceivingNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReceivingState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReceivingState>(value),
    );
  }
}

String _$receivingNotifierHash() => r'b87a8e8d4364dffe31a3885d562e9ab470664d9b';

abstract class _$ReceivingNotifier extends $Notifier<ReceivingState> {
  ReceivingState build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<ReceivingState, ReceivingState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ReceivingState, ReceivingState>,
              ReceivingState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
