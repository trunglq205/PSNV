using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Client;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.Auth;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.App.Pages;

public partial class ReturnBackRequests
{
    [Inject] private IReturnBackRequestBusiness Biz { get; set; } = default!;

    /// <summary>
    /// Danh sách chỉ thị nhận hàng cho ô chọn ở dialog soạn yêu cầu. Gọi API
    /// chỉ thị trực tiếp — chỉ cần một danh sách đọc, không đáng dựng thêm một
    /// lớp business chỉ để bọc một lời gọi.
    /// </summary>
    [Inject] private IReturnInstructionApi DocApi { get; set; } = default!;

    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private PermissionState Perm { get; set; } = default!;

    // ───────────────────────────── Quyền ─────────────────────────────
    // GIỮ KHỚP TỪNG DÒNG với attribute trên ReturnBackRequestsController.
    // Lệch một chỗ là hoặc thấy nút rồi ăn 403, hoặc có quyền mà không thấy
    // nút — cả hai đều khó lần ra vì Has() trả false IM LẶNG.

    /// <summary>B1 — FA tạo / sửa yêu cầu.</summary>
    private bool MayRequest => Perm.Has(Perms.rework_refurbish_request_back.Key());

    /// <summary>B2 — quản lý FA duyệt.</summary>
    private bool MayApproveFa => Perm.Has(Perms.rework_refurbish_approve_fa.Key());

    /// <summary>B3 — SCS WH xác nhận và tạo chỉ thị back.</summary>
    private bool MayProcess => Perm.Has(Perms.rework_refurbish_process.Key());

    /// <summary>B4 — quản lý SCS duyệt cho back.</summary>
    private bool MayApproveScs => Perm.Has(Perms.rework_refurbish_approve_scs.Key());

    // Nút = QUYỀN **AND** ĐÚNG BƯỚC. Lớp "đúng bước" là thứ làm cho duyệt có
    // nghĩa: role khai sai cũng không nhảy được hàng, và server còn chặn lần
    // nữa bằng điều kiện bước nằm trong câu UPDATE.

    private bool CanEdit(ReturnBackRequestDto r)
        => r.IsOpen
           && r.CurrentStep is BackStep.FaApprove or BackStep.ScsInstruct
           && (MayRequest || MayProcess);

    private bool CanApproveFa(ReturnBackRequestDto r)
        => r.IsOpen && r.CurrentStep == BackStep.FaApprove && MayApproveFa;

    private bool CanInstruct(ReturnBackRequestDto r)
        => r.IsOpen && r.CurrentStep == BackStep.ScsInstruct && MayProcess;

    private bool CanApproveScs(ReturnBackRequestDto r)
        => r.IsOpen && r.CurrentStep == BackStep.ScsApprove && MayApproveScs;

    /// <summary>
    /// Huỷ: ai đang giữ bước cũng phải dừng được, không phải chờ bên kia.
    /// Đã duyệt xong B4 thì KHÔNG huỷ được — hàng ở FA rồi.
    /// </summary>
    private bool CanCancel(ReturnBackRequestDto r)
        => r.IsOpen && (MayRequest || MayApproveFa || MayApproveScs);

    // ───────────────────────── Tab hàng đợi ─────────────────────────

    /// <summary>
    /// Tab lọc theo BƯỚC (ba tab giữa) hoặc theo TRẠNG THÁI (hai tab cuối).
    /// Bước <c>done</c> gồm cả đã-cho-back và đã-huỷ, nên hai cái đó phải lọc
    /// bằng status mới tách ra được.
    /// </summary>
    private sealed record TabDef(string Key, string LabelKey, string? Step, string? Status);

    private static readonly TabDef[] Tabs =
    {
        new("", "Return.Back.Tab.All", null, null),
        new("fa", "Return.Back.Tab.FaApprove", BackStep.FaApprove, null),
        new("wh", "Return.Back.Tab.ScsInstruct", BackStep.ScsInstruct, null),
        new("scs", "Return.Back.Tab.ScsApprove", BackStep.ScsApprove, null),
        new("ok", "Return.Back.Tab.Approved", null, BackStatus.ScsApproved),
        new("x", "Return.Back.Tab.Cancelled", null, BackStatus.Cancelled),
    };

    private string _tab = "";
    private string _keyword = "";

    private List<ReturnBackRequestDto> _all = new();
    private List<ReturnInstructionDto> _docs = new();
    private List<BackAvailableModelDto> _available = new();

    private bool _loading, _saving;
    private string? _error, _formError;
    private long? _expanded;

    /// <summary>
    /// Lọc tab ở CLIENT, không gọi lại API mỗi lần đổi tab: cả màn chỉ vài
    /// trăm dòng, mà đếm số trên tab thì buộc phải có toàn bộ dữ liệu — gọi
    /// API cho từng tab sẽ thành sáu lượt gọi chỉ để vẽ sáu con số.
    /// </summary>
    private List<ReturnBackRequestDto> Rows
    {
        get
        {
            var t = Tabs.FirstOrDefault(x => x.Key == _tab) ?? Tabs[0];
            return _all.Where(r => Match(r, t)).ToList();
        }
    }

    private static bool Match(ReturnBackRequestDto r, TabDef t)
        => (t.Step is null || r.CurrentStep == t.Step)
           && (t.Status is null || r.ReqStatus == t.Status);

    private int CountOf(string key)
    {
        var t = Tabs.FirstOrDefault(x => x.Key == key) ?? Tabs[0];
        return _all.Count(r => Match(r, t));
    }

    /// <summary>
    /// Đổi tab KHÔNG gọi lại API: dữ liệu đã có đủ, lọc ở client. Đóng dòng
    /// đang bung vì dòng đó gần như chắc chắn không thuộc tab mới.
    /// </summary>
    private void SwitchTab(string key)
    {
        if (_tab == key) return;
        _tab = key;
        _expanded = null;
    }

    private async Task OnKeyword(ChangeEventArgs e)
    {
        _keyword = e.Value?.ToString() ?? "";
        await Load();
    }

    protected override async Task OnInitializedAsync() => await Load();

    private async Task Load()
    {
        _loading = true;
        _error = null;
        StateHasChanged();
        try
        {
            // KHÔNG truyền step/status: tab lọc ở client để đếm được số trên tab.
            var res = await Biz.GetListAsync(keyword: _keyword);
            if (res.IsSuccess && res.Value is not null)
            {
                _all = res.Value;
                if (_expanded is { } id && _all.All(r => r.Id != id)) _expanded = null;
            }
            else
            {
                _error = res.Message;
            }
        }
        finally
        {
            _loading = false;
            StateHasChanged();
        }
    }

    private void Toggle(long id) => _expanded = _expanded == id ? null : id;

    // ─────────────────────── Nhãn + mốc thời gian ───────────────────────

    private string StepLabel(ReturnBackRequestDto r)
    {
        if (r.IsCancelled) return L["Return.Back.Step.Cancelled"];
        if (r.IsApproved) return L["Return.Back.Step.Approved"];
        return r.CurrentStep switch
        {
            BackStep.FaApprove => L["Return.Back.Step.FaApprove"],
            BackStep.ScsInstruct => L["Return.Back.Step.ScsInstruct"],
            BackStep.ScsApprove => L["Return.Back.Step.ScsApprove"],
            _ => r.CurrentStep,
        };
    }

    private sealed record StepCell(string LabelKey, string Who, string State);

    /// <summary>
    /// Bốn mốc của một yêu cầu. Hiện cả người và lúc: "đang chờ quản lý SCS" mà
    /// không biết chờ từ bao giờ thì không ai biết có phải đi nhắc hay không.
    /// </summary>
    private List<StepCell> StepTrail(ReturnBackRequestDto r)
    {
        var done = "done";
        var wait = "wait";
        var idle = "idle";

        string W(string? who, DateTime? at)
            => at is null ? "—" : $"{who} · {at:dd/MM HH:mm}";

        var faState = r.FaApprovedAt is not null ? done
            : r.CurrentStep == BackStep.FaApprove && r.IsOpen ? wait : idle;
        var whState = r.ScsInstructedAt is not null ? done
            : r.CurrentStep == BackStep.ScsInstruct && r.IsOpen ? wait : idle;
        var scsState = r.ScsApprovedAt is not null ? done
            : r.CurrentStep == BackStep.ScsApprove && r.IsOpen ? wait : idle;

        return
        [
            new("Return.Back.Step.Requested", W(r.RequestedBy, r.RequestedAt), done),
            new("Return.Back.Step.FaApprove", W(r.FaApprovedBy, r.FaApprovedAt), faState),
            new("Return.Back.Step.ScsInstruct", W(r.ScsInstructedBy, r.ScsInstructedAt), whState),
            new("Return.Back.Step.ScsApprove", W(r.ScsApprovedBy, r.ScsApprovedAt), scsState),
        ];
    }

    // ───────────────────── Dialog soạn / sửa ─────────────────────

    /// <summary>Bản nháp của dialog — sửa ở đây không đụng dữ liệu đang hiện.</summary>
    private sealed class FormModel
    {
        public long DocId { get; set; }
        public string ReqNo { get; set; } = "";
        public string? Note { get; set; }
        public List<ReturnBackRequestLineDto> Lines { get; set; } = new();
    }

    private FormModel? _form;
    private long? _editId;

    private int FormTotalQty => _form?.Lines.Sum(l => l.Qty) ?? 0;

    /// <summary>
    /// Lưu được khi: đã chọn phiếu, có ít nhất một dòng đủ model + SL, và
    /// KHÔNG dòng nào xin quá SL kho còn gắp được. Chặn ở đây để người dùng
    /// không bấm Lưu rồi mới nhận lỗi từ server.
    /// </summary>
    private bool CanSubmitForm
        => _form is { DocId: > 0 }
           && _form.Lines.Count > 0
           && _form.Lines.All(l => !string.IsNullOrWhiteSpace(l.Model)
                                   && l.Qty > 0
                                   && l.Qty <= AvailableOf(l.Model))
           && _form.Lines.Select(l => l.Model).Distinct(StringComparer.OrdinalIgnoreCase).Count()
              == _form.Lines.Count;

    private int AvailableOf(string? model)
    {
        if (string.IsNullOrWhiteSpace(model)) return 0;
        var a = _available.FirstOrDefault(x =>
            string.Equals(x.Model, model, StringComparison.OrdinalIgnoreCase));
        var have = a?.AvailableQty ?? 0;

        // Khi SỬA, số serial đã gắp cho chính dòng này không còn nằm trong
        // "available" nữa (nó đã bị đóng dấu back_request_id). Cộng lại để
        // người sửa không bị bắt giảm số xuống dưới cái họ đang có.
        if (_editId is not null)
        {
            var mine = _form?.Lines.FirstOrDefault(l =>
                string.Equals(l.Model, model, StringComparison.OrdinalIgnoreCase));
            have += mine?.AssignedQty ?? 0;
        }
        return have;
    }

    private async Task OpenCreate()
    {
        _editId = null;
        _formError = null;
        _available = new();
        _form = new FormModel();
        await LoadDocsAsync();
    }

    private async Task OpenEdit(ReturnBackRequestDto r)
    {
        _editId = r.Id;
        _formError = null;
        _form = new FormModel
        {
            DocId = r.DocId,
            ReqNo = r.ReqNo,
            Note = r.Note,
            Lines = r.Lines.Select(l => l.Clone()).ToList(),
        };
        await LoadAvailableAsync(r.DocId);
    }

    private void CloseForm()
    {
        _form = null;
        _editId = null;
        _formError = null;
    }

    /// <summary>
    /// Chỉ liệt kê phiếu CÒN MỞ hoặc đã chốt — phiếu huỷ thì server cũng chặn,
    /// nên đưa vào danh sách chỉ để người dùng chọn rồi ăn lỗi.
    /// </summary>
    private async Task LoadDocsAsync()
    {
        try
        {
            var all = await DocApi.GetListAsync();
            _docs = all.Where(d => !string.Equals(
                d.DocStatus, ReturnDocStatus.Cancelled, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
        catch (Exception ex) { _formError = Describe(ex); }
    }

    private async Task LoadAvailableAsync(long docId)
    {
        var res = await Biz.GetAvailableAsync(docId);
        _available = res.IsSuccess && res.Value is not null ? res.Value : new();
        if (!res.IsSuccess) _formError = res.Message;
    }

    private async Task OnDocChanged(ChangeEventArgs e)
    {
        if (_form is null) return;
        _form.DocId = long.TryParse(e.Value?.ToString(), out var id) ? id : 0;
        _form.Lines.Clear();
        _available = new();
        if (_form.DocId > 0)
        {
            await LoadAvailableAsync(_form.DocId);
            // Mồi sẵn một dòng: màn trống với một nút "+" là bước thừa.
            if (_available.Count > 0) AddLine();
        }
    }

    private void AddLine()
        => _form?.Lines.Add(new ReturnBackRequestLineDto { Qty = 0 });

    private void RemoveLine(int ix)
    {
        if (_form is null || ix < 0 || ix >= _form.Lines.Count) return;
        _form.Lines.RemoveAt(ix);
    }

    private void OnModelChanged(int ix, ChangeEventArgs e)
    {
        if (_form is null || ix < 0 || ix >= _form.Lines.Count) return;
        var line = _form.Lines[ix];
        line.Model = e.Value?.ToString() ?? "";

        // Đổi model thì SL cũ gần như chắc chắn vượt kho của model mới — kẹp
        // lại thay vì để nút Lưu tắt mà người dùng không hiểu vì sao.
        var cap = AvailableOf(line.Model);
        if (line.Qty > cap) line.Qty = cap;
    }

    private void OnQtyChanged(int ix, ChangeEventArgs e)
    {
        if (_form is null || ix < 0 || ix >= _form.Lines.Count) return;
        var line = _form.Lines[ix];
        line.Qty = int.TryParse(e.Value?.ToString(), out var q) && q > 0 ? q : 0;
    }

    private async Task SubmitForm()
    {
        if (_form is null || !CanSubmitForm) return;
        _saving = true;
        _formError = null;
        StateHasChanged();
        try
        {
            var lines = _form.Lines.Select(l => new BackRequestLineRequestDto
            {
                Model = l.Model.Trim(),
                Qty = l.Qty,
                Note = l.Note,
            }).ToList();

            var res = _editId is { } id
                ? await Biz.UpdateAsync(id, new UpdateBackRequestRequestDto
                {
                    Note = _form.Note,
                    Lines = lines,
                })
                : await Biz.CreateAsync(new CreateBackRequestRequestDto
                {
                    DocId = _form.DocId,
                    Note = _form.Note,
                    Lines = lines,
                });

            if (!res.IsSuccess)
            {
                _formError = res.Message;
                return;
            }

            CloseForm();
            await Load();
        }
        finally
        {
            _saving = false;
            StateHasChanged();
        }
    }

    // ───────────────────── Dialog xác nhận ─────────────────────

    private enum BackAction { ApproveFa, Instruct, ApproveScs, Cancel }

    private ReturnBackRequestDto? _asking;
    private BackAction _action;
    private string? _comment;

    private string AskTitleKey => _action switch
    {
        BackAction.ApproveFa => "Return.Back.ApproveFaTitle",
        BackAction.Instruct => "Return.Back.InstructTitle",
        BackAction.ApproveScs => "Return.Back.ApproveScsTitle",
        _ => "Return.Back.CancelTitle",
    };

    private string AskConfirmKey => _action switch
    {
        BackAction.ApproveFa => "Return.Back.ApproveFa",
        BackAction.Instruct => "Return.Back.Instruct",
        BackAction.ApproveScs => "Return.Back.ApproveScs",
        _ => "Return.Back.Cancel",
    };

    private void Ask(ReturnBackRequestDto r, BackAction action)
    {
        _asking = r;
        _action = action;
        _comment = null;
        _formError = null;
    }

    private void CloseAsk()
    {
        _asking = null;
        _formError = null;
    }

    private async Task ConfirmAsk()
    {
        if (_asking is null) return;
        var id = _asking.Id;
        _saving = true;
        _formError = null;
        StateHasChanged();
        try
        {
            var res = _action switch
            {
                BackAction.ApproveFa => await Biz.ApproveFaAsync(id, _comment),
                BackAction.Instruct => await Biz.InstructAsync(id, _comment),
                BackAction.ApproveScs => await Biz.ApproveScsAsync(id, _comment),
                _ => await Biz.CancelAsync(id, _comment),
            };

            if (!res.IsSuccess)
            {
                // Lỗi hay gặp nhất ở đây là "có người vừa xử lý trước" (409).
                // Giữ dialog mở để người dùng đọc được câu đó, rồi tải lại
                // danh sách để họ thấy trạng thái mới.
                _formError = res.Message;
                await Load();
                return;
            }

            CloseAsk();
            await Load();
        }
        finally
        {
            _saving = false;
            StateHasChanged();
        }
    }

    private static string Describe(Exception ex) =>
        ex is Refit.ApiException api && !string.IsNullOrWhiteSpace(api.Content)
            ? ExtractTitle(api.Content) ?? api.Message
            : ex.Message;

    private static string? ExtractTitle(string content)
    {
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(content);
            return doc.RootElement.TryGetProperty("title", out var t) ? t.GetString() : null;
        }
        catch { return null; }
    }
}
