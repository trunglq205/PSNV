import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';

/// Một màn, hai chế độ: [selected] == null → danh sách; khác null → đang
/// kiểm container đó. Phần kiểm reset mỗi lần mở container khác.
@immutable
class ContainerCheckState {
  // ── Danh sách ──────────────────────────────────────────────
  /// Danh sách có loading / lỗi riêng; khung quét vẫn dùng được khi danh
  /// sách lỗi — quét QR không phụ thuộc danh sách.
  final AsyncValue<List<ContainerItem>> containers;

  /// Đang tra QR ngoài danh sách — khoá quét để không mở 2 lần.
  final bool resolving;

  // ── Đang kiểm ──────────────────────────────────────────────
  /// Dòng đã chọn — hiện ngay tiêu đề + thẻ đầu trong lúc tải chi tiết.
  final ContainerItem? selected;
  final AsyncValue<ContainerItem> detail;
  final Set<ContainerCondition> checked;
  final Map<ContainerPhotoSlot, String> photos;
  final bool submitting;

  const ContainerCheckState({
    this.containers = const AsyncValue.loading(),
    this.resolving = false,
    this.selected,
    this.detail = const AsyncValue.loading(),
    this.checked = const {},
    this.photos = const {},
    this.submitting = false,
  });

  bool get inspecting => selected != null;

  ContainerItem? get detailValue => detail.value;

  /// Chi tiết về rồi thì lấy bản mới (trạng thái có thể đã đổi từ máy khác).
  ContainerItem? get current => detailValue ?? selected;

  /// Chỉ container "chờ kiểm" mới chốt được kết quả; đang đóng / hoàn thành
  /// là đã kiểm rồi → chỉ xem.
  bool get editable =>
      detailValue?.status == ContainerStatus.verify && !submitting;

  bool get allChecked => checked.length == ContainerCondition.values.length;
  bool get allPhotos => photos.length == ContainerPhotoSlot.values.length;

  bool get canPass => editable && allChecked && allPhotos;

  /// Không đạt không cần đủ checklist (hỏng ở đâu thì để trống ở đó), nhưng
  /// phải mở được container đã.
  bool get canFail => editable;

  /// Đã tick / chụp mà chưa chốt → rời chế độ kiểm phải hỏi trước.
  bool get dirty => checked.isNotEmpty || photos.isNotEmpty;

  ContainerCheckState copyWith({
    AsyncValue<List<ContainerItem>>? containers,
    bool? resolving,
    AsyncValue<ContainerItem>? detail,
    Set<ContainerCondition>? checked,
    Map<ContainerPhotoSlot, String>? photos,
    bool? submitting,
  }) =>
      ContainerCheckState(
        containers: containers ?? this.containers,
        resolving: resolving ?? this.resolving,
        // selected chỉ đổi qua openInspection / closeInspection.
        selected: selected,
        detail: detail ?? this.detail,
        checked: checked ?? this.checked,
        photos: photos ?? this.photos,
        submitting: submitting ?? this.submitting,
      );

  /// Mở container: giữ danh sách, xoá sạch phần kiểm của container trước.
  ContainerCheckState openInspection(ContainerItem item) =>
      ContainerCheckState(containers: containers, selected: item);

  /// Về danh sách: giữ danh sách, bỏ phần kiểm.
  ContainerCheckState closeInspection() =>
      ContainerCheckState(containers: containers);
}
