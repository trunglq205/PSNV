// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'storage_map_models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PositionOccModel _$PositionOccModelFromJson(Map<String, dynamic> json) =>
    PositionOccModel(
      position: (json['position'] as num).toInt(),
      total: (json['total'] as num).toInt(),
      occupied: (json['occupied'] as num).toInt(),
    );

Map<String, dynamic> _$PositionOccModelToJson(PositionOccModel instance) =>
    <String, dynamic>{
      'position': instance.position,
      'total': instance.total,
      'occupied': instance.occupied,
    };

TopMapBlockModel _$TopMapBlockModelFromJson(Map<String, dynamic> json) =>
    TopMapBlockModel(
      id: (json['id'] as num).toInt(),
      kind: json['kind'] as String,
      gridX: (json['gridX'] as num).toInt(),
      gridY: (json['gridY'] as num).toInt(),
      gridW: (json['gridW'] as num).toInt(),
      gridH: (json['gridH'] as num).toInt(),
      rackCode: json['rackCode'] as String?,
      label: json['label'] as String?,
      color: json['color'] as String?,
      totalSlots: (json['totalSlots'] as num?)?.toInt() ?? 0,
      occupiedSlots: (json['occupiedSlots'] as num?)?.toInt() ?? 0,
      positions:
          (json['positions'] as List<dynamic>?)
              ?.map((e) => PositionOccModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
      locatorCode: json['locatorCode'] as String?,
      status: json['status'] as String?,
      isUrgent: json['isUrgent'] as bool? ?? false,
      model: json['model'] as String?,
      palletId: json['palletId'] as String?,
      boxCount: (json['boxCount'] as num?)?.toInt(),
      productionDate: json['productionDate'] == null
          ? null
          : DateTime.parse(json['productionDate'] as String),
    );

Map<String, dynamic> _$TopMapBlockModelToJson(TopMapBlockModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'kind': instance.kind,
      'rackCode': ?instance.rackCode,
      'label': ?instance.label,
      'color': ?instance.color,
      'gridX': instance.gridX,
      'gridY': instance.gridY,
      'gridW': instance.gridW,
      'gridH': instance.gridH,
      'totalSlots': instance.totalSlots,
      'occupiedSlots': instance.occupiedSlots,
      'positions': instance.positions,
      'locatorCode': ?instance.locatorCode,
      'status': ?instance.status,
      'isUrgent': instance.isUrgent,
      'model': ?instance.model,
      'palletId': ?instance.palletId,
      'boxCount': ?instance.boxCount,
      'productionDate': ?instance.productionDate?.toIso8601String(),
    };

StorageTopMapModel _$StorageTopMapModelFromJson(Map<String, dynamic> json) =>
    StorageTopMapModel(
      cols: (json['cols'] as num).toInt(),
      rows: (json['rows'] as num).toInt(),
      blocks:
          (json['blocks'] as List<dynamic>?)
              ?.map((e) => TopMapBlockModel.fromJson(e as Map<String, dynamic>))
              .toList() ??
          const [],
    );

Map<String, dynamic> _$StorageTopMapModelToJson(StorageTopMapModel instance) =>
    <String, dynamic>{
      'cols': instance.cols,
      'rows': instance.rows,
      'blocks': instance.blocks,
    };

ElevationCellModel _$ElevationCellModelFromJson(Map<String, dynamic> json) =>
    ElevationCellModel(
      locatorId: (json['locatorId'] as num).toInt(),
      locatorCode: json['locatorCode'] as String,
      location: (json['location'] as num).toInt(),
      floor: (json['floor'] as num).toInt(),
      slotKind: json['slotKind'] as String,
      occupied: json['occupied'] as bool,
      level: json['level'] as String?,
      palletId: json['palletId'] as String?,
      model: json['model'] as String?,
      boxCount: (json['boxCount'] as num?)?.toInt(),
      productionDate: json['productionDate'] == null
          ? null
          : DateTime.parse(json['productionDate'] as String),
      disposition: json['disposition'] as String?,
      stopShipment: json['stopShipment'] as bool? ?? false,
      status: json['status'] as String?,
      isUrgent: json['isUrgent'] as bool? ?? false,
    );

Map<String, dynamic> _$ElevationCellModelToJson(ElevationCellModel instance) =>
    <String, dynamic>{
      'locatorId': instance.locatorId,
      'locatorCode': instance.locatorCode,
      'location': instance.location,
      'floor': instance.floor,
      'slotKind': instance.slotKind,
      'level': ?instance.level,
      'occupied': instance.occupied,
      'palletId': ?instance.palletId,
      'model': ?instance.model,
      'boxCount': ?instance.boxCount,
      'productionDate': ?instance.productionDate?.toIso8601String(),
      'disposition': ?instance.disposition,
      'stopShipment': instance.stopShipment,
      'status': ?instance.status,
      'isUrgent': instance.isUrgent,
    };

RackElevationModel _$RackElevationModelFromJson(Map<String, dynamic> json) =>
    RackElevationModel(
      rackCode: json['rackCode'] as String,
      cells:
          (json['cells'] as List<dynamic>?)
              ?.map(
                (e) => ElevationCellModel.fromJson(e as Map<String, dynamic>),
              )
              .toList() ??
          const [],
    );

Map<String, dynamic> _$RackElevationModelToJson(RackElevationModel instance) =>
    <String, dynamic>{'rackCode': instance.rackCode, 'cells': instance.cells};

WarehouseAreaModel _$WarehouseAreaModelFromJson(Map<String, dynamic> json) =>
    WarehouseAreaModel(
      id: (json['id'] as num).toInt(),
      areaCode: json['areaCode'] as String,
      areaName: json['areaName'] as String,
      mapType: json['mapType'] as String,
    );

Map<String, dynamic> _$WarehouseAreaModelToJson(WarehouseAreaModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'areaCode': instance.areaCode,
      'areaName': instance.areaName,
      'mapType': instance.mapType,
    };

LocatorLocationModel _$LocatorLocationModelFromJson(
  Map<String, dynamic> json,
) => LocatorLocationModel(
  locatorCode: json['locatorCode'] as String,
  areaCode: json['areaCode'] as String?,
  areaName: json['areaName'] as String?,
  mapType: json['mapType'] as String?,
  rackCode: json['rackCode'] as String?,
  rackCol: (json['rackCol'] as num?)?.toInt(),
  rackRow: (json['rackRow'] as num?)?.toInt(),
  rackLevel: json['rackLevel'] as String?,
);

Map<String, dynamic> _$LocatorLocationModelToJson(
  LocatorLocationModel instance,
) => <String, dynamic>{
  'locatorCode': instance.locatorCode,
  'areaCode': ?instance.areaCode,
  'areaName': ?instance.areaName,
  'mapType': ?instance.mapType,
  'rackCode': ?instance.rackCode,
  'rackCol': ?instance.rackCol,
  'rackRow': ?instance.rackRow,
  'rackLevel': ?instance.rackLevel,
};

PalletSerialModel _$PalletSerialModelFromJson(Map<String, dynamic> json) =>
    PalletSerialModel(
      boxNo: json['boxNo'] as String?,
      model: json['model'] as String?,
      serialNo: json['serialNo'] as String?,
      qty: (json['qty'] as num?)?.toInt(),
    );

Map<String, dynamic> _$PalletSerialModelToJson(PalletSerialModel instance) =>
    <String, dynamic>{
      'boxNo': ?instance.boxNo,
      'model': ?instance.model,
      'serialNo': ?instance.serialNo,
      'qty': ?instance.qty,
    };
