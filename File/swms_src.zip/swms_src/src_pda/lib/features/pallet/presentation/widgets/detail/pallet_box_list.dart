import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';

/// Danh sách thùng trong pallet.
class PalletBoxList extends StatelessWidget {
  final List<PalletBox> boxes;
  final int collapsedCount;
  final VoidCallback? onFindMissing;
  final void Function(PalletBox box)? onBoxTap;

  const PalletBoxList({
    super.key,
    required this.boxes,
    this.collapsedCount = 3,
    this.onFindMissing,
    this.onBoxTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppExpandableList<PalletBox>(
      items: boxes,
      grouped: true,
      collapsedCount: collapsedCount,
      title: LocaleKeys.pallet_detail_box_list.tr(args: ['${boxes.length}']),
      showMoreLabel: (hidden) =>
          LocaleKeys.pallet_detail_show_more.tr(args: ['$hidden']),
      headerAction: onFindMissing == null
          ? null
          : AppButton(
        label: LocaleKeys.pallet_detail_find_missing_box.tr(),
        icon: Icons.search,
        variant: AppButtonVariant.subtle,
        size: AppButtonSize.sm,
        isFullWidth: false,
        onPressed: onFindMissing,
      ),
      itemBuilder: (context, box, _) => AppExpandableRow(
        icon: Icons.inventory_2_outlined,
        iconColor: swms.primary,
        iconBackground: swms.primaryTint,
        title: box.boxNo,
        subtitle: box.primaryModel == null
            ? null
            : LocaleKeys.pallet_detail_box_meta.tr(
          args: [box.primaryModel!, '${box.totalQty}'],
        ),
        onTap: onBoxTap == null ? null : () => onBoxTap!(box),
      ),
    );
  }
}