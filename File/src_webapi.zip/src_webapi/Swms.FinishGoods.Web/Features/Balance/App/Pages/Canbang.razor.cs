using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.Balance.Business.Models;
using Swms.FinishGoods.Web.Features.Balance.Client;
using Swms.FinishGoods.Web.Resources;

namespace Swms.FinishGoods.Web.Features.Balance.App.Pages;

public partial class Canbang
{
    [Inject] private IBalanceApi Api { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;

    private List<BalanceDocSummaryDto> _rows = new();
    private bool _loading = true;
    private string _tab = "pending"; // pending | processing | issued | all

    private BalanceDocSummaryDto? _sel;
    private BalanceDocDetailDto? _detail;
    private bool _detailLoading;
    private bool _busy;

    protected override async Task OnInitializedAsync() => await Load();

    private bool IsIssued => _detail?.Header.DocStatus == "issued";
    private int Remaining => _detail is null ? 0 : _detail.Lines.Count - _detail.Header.ResolvedLines;

    private void SetTab(string t) { _tab = t; _ = Load(); }

    private async Task Load()
    {
        _loading = true; StateHasChanged();
        try
        {
            string? filter = _tab == "all" ? null : _tab;
            _rows = await Api.GetDocsAsync(filter);
            if (_sel is not null && _rows.All(r => r.Id != _sel.Id)) { _sel = null; _detail = null; }
        }
        finally { _loading = false; StateHasChanged(); }
    }

    private async Task Select(BalanceDocSummaryDto c)
    {
        _sel = c;
        _detailLoading = true; _detail = null; StateHasChanged();
        try { _detail = await Api.GetDocAsync(c.Id); }
        finally { _detailLoading = false; StateHasChanged(); }
    }

    private Task ChooseCount(BalanceLineDto line) => Choose(line, "count");
    private Task ChooseSystem(BalanceLineDto line) => Choose(line, "system");

    private async Task Choose(BalanceLineDto line, string resolution)
    {
        if (_sel is null || _detail is null) return;
        _busy = true; StateHasChanged();
        try
        {
            await Api.SetLineAsync(_sel.Id, line.LineId, new SetResolutionRequestDto { Resolution = resolution });
            // cập nhật cục bộ để không phải load lại toàn bộ
            line.Resolution = resolution;
            _detail.Header.ResolvedLines = _detail.Lines.Count(l => l.Resolution is not null);
            if (_sel.DocStatus == "pending") _sel.DocStatus = "processing";
        }
        finally { _busy = false; StateHasChanged(); }
    }

    private async Task DoIssueFa()
    {
        if (_sel is null || Remaining > 0) return;
        _busy = true; StateHasChanged();
        try
        {
            var r = await Api.IssueFaAsync(_sel.Id);
            // reload danh sách + chi tiết
            await Load();
            var reloaded = _rows.FirstOrDefault(x => x.Id == _sel.Id);
            if (reloaded is not null) await Select(reloaded);
        }
        finally { _busy = false; StateHasChanged(); }
    }

    private static string Qty(decimal v) => v.ToString("0.####", System.Globalization.CultureInfo.InvariantCulture);

    private string StatusLabel(string s) => s switch
    {
        "pending" => L["Balance.StatusPending"],
        "processing" => L["Balance.StatusProcessing"],
        "issued" => L["Balance.StatusIssued"],
        _ => s
    };

    private static string StatusClass(string s) => s switch
    {
        "pending" => "warning",
        "processing" => "info",
        "issued" => "success",
        _ => "dim"
    };

    private string ResolutionLabel(string? r) => r switch
    {
        "count" => L["Balance.PickCount"],
        "system" => L["Balance.PickSystem"],
        _ => "—"
    };
}
