import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_event.dart';

part 'box_history_model.g.dart';

/// Khớp `BoxHistoryResponse` của API — `GET /api/boxes/{id}/history`.
@JsonSerializable()
class BoxHistoryModel {
  final BoxHistoryHeaderModel header;

  @JsonKey(defaultValue: <BoxEventModel>[])
  final List<BoxEventModel> events;

  const BoxHistoryModel({required this.header, this.events = const []});

  factory BoxHistoryModel.fromJson(Map<String, dynamic> json) =>
      _$BoxHistoryModelFromJson(json);

  BoxHistory toEntity() => BoxHistory(
    header: header.toEntity(),
    events: events.map((e) => e.toEntity()).toList(),
  );
}

/// Khớp `LocatorRef`: { locatorCode, areaCode }.
/// API trả null cho event không đổi vị trí — không phải object rỗng.
@JsonSerializable()
class EventLocatorModel {
  final String locatorCode;
  final String? areaCode;

  const EventLocatorModel({required this.locatorCode, this.areaCode});

  factory EventLocatorModel.fromJson(Map<String, dynamic> json) =>
      _$EventLocatorModelFromJson(json);

  EventLocator toEntity() =>
      EventLocator(locatorCode: locatorCode, areaCode: areaCode);
}

@JsonSerializable()
class BoxEventModel {
  final int id;
  final String eventCode;
  final DateTime eventAt;
  final String? actor;

  /// false khi server không trả (không nên xảy ra, nhưng đừng để crash).
  @JsonKey(defaultValue: false)
  final bool inherited;

  final String? palletCode;
  final EventLocatorModel? fromLocator;
  final EventLocatorModel? toLocator;
  final String? refNo;
  final String? note;
  final String? payload;

  const BoxEventModel({
    required this.id,
    required this.eventCode,
    required this.eventAt,
    required this.inherited,
    this.actor,
    this.palletCode,
    this.fromLocator,
    this.toLocator,
    this.refNo,
    this.note,
    this.payload,
  });

  factory BoxEventModel.fromJson(Map<String, dynamic> json) =>
      _$BoxEventModelFromJson(json);

  BoxEvent toEntity() => BoxEvent(
    id: id,
    eventCode: eventCode,
    eventAt: eventAt,
    actor: actor,
    inherited: inherited,
    palletCode: palletCode,
    fromLocator: fromLocator?.toEntity(),
    toLocator: toLocator?.toEntity(),
    refNo: refNo,
    note: note,
    payload: payload,
  );
}

@JsonSerializable()
class BoxHistoryHeaderModel {
  final int boxId;
  final String boxNo;
  final String? palletCode;
  final String? model;

  @JsonKey(defaultValue: 0)
  final int lineCount;

  final int? totalQty;
  final int? oqcStatus;
  final EventLocatorModel? currentLocator;

  @JsonKey(defaultValue: false)
  final bool isDeleted;

  const BoxHistoryHeaderModel({
    required this.boxId,
    required this.boxNo,
    required this.lineCount,
    required this.isDeleted,
    this.palletCode,
    this.model,
    this.totalQty,
    this.oqcStatus,
    this.currentLocator,
  });

  factory BoxHistoryHeaderModel.fromJson(Map<String, dynamic> json) =>
      _$BoxHistoryHeaderModelFromJson(json);

  BoxHistoryHeader toEntity() => BoxHistoryHeader(
    boxId: boxId,
    boxNo: boxNo,
    palletCode: palletCode,
    model: model,
    lineCount: lineCount,
    totalQty: totalQty,
    oqcStatus: oqcStatus,
    currentLocator: currentLocator?.toEntity(),
    isDeleted: isDeleted,
  );
}