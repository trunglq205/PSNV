﻿using System.Reflection.Emit;

namespace SWMS_WebTool.Models.Layout
{
    public class Point
    {
        public Point(double x, double y)
        {
            X = x; Y = y;
        }

        public double X { get; set; }
        public double Y { get; set; }
    }

    public abstract class Shape : Widget
    {
        public Shape() { }

        public Shape(KonvaObject konvaObject) : base(konvaObject) { }
    }

    public class Rectangle : Shape
    {
        public Rectangle() { }
        public Rectangle(KonvaObject konvaObject) : base(konvaObject) { }
        public override WidgetType Type => WidgetType.Rectangle;
        protected override KonvaClassType ClassName => KonvaClassType.Rect; 
    }

    public class Circle : Shape {
        public Circle() { }

        public Circle(KonvaObject konvaObject) : base(konvaObject) {
            Radius = konvaObject.Attrs.Radius ?? 0;
        }

        public override WidgetType Type => WidgetType.Circle;
        protected override KonvaClassType ClassName => KonvaClassType.Circle; 


        public double Radius { get; set; }

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.Radius = Radius;
            return attrs;
        }
    }

    public class Line : Shape {
        public Line() { }

        public Line(KonvaObject konvaObject) : base(konvaObject) {
            Points = new List<Point>();

            var points = konvaObject.Attrs.Points;
            for(int i = 0; i < points.Count; i+=2)
            {
                Points.Add(new Point(points[i], points[i + 1]));
            }
        }

        public override WidgetType Type { get => WidgetType.Line; }
        protected override KonvaClassType ClassName { get => KonvaClassType.Line; }

        public List<Point> Points;

        protected override KonvaAttr ToKonvaAttr()
        {
            var points = new List<double>();
            Points.ForEach((point) =>
            {
                points.AddRange(new List<double>() { point.X, point.Y });
            });
            var attrs = base.ToKonvaAttr();
            attrs.Points = points;
            return attrs;
        }
    }

}
