const kSiDash = '—';

String siOrDash(String? s) =>
    (s == null || s.trim().isEmpty) ? kSiDash : s.trim();

/// Ghép các phần khác rỗng bằng [sep] (mặc định " · ").
String siJoin(Iterable<String?> parts, {String sep = ' · '}) => parts
    .where((e) => e != null && e.trim().isNotEmpty)
    .map((e) => e!.trim())
    .join(sep);