﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.ViewModels
{
    public class DeliveryPlanViewModel : TableViewModel<DeliveryPlan, DeliveryPlanFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, DeliveryPlanFilter? filter = null)
        {
            return new
            {
                Type = filter?.Type ?? Filter.Type,
                VendorCode = filter?.VendorCode ?? Filter.VendorCode,
                No = filter?.No ?? Filter.No,
                Material = filter?.Material ?? Filter.Material,
                PoNo = filter?.PoNo ?? Filter.PoNo,
                PoItem = filter?.PoItem ?? Filter.PoItem,
                PlanOrderNumber = filter?.PlanOrderNumber ?? Filter.PlanOrderNumber,
                Date = (filter?.Date ?? Filter.Date ?? DateTime.Now).ToString("yyyy-MM-dd"),
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class ConfirmQtyRCViewModel
    {
        public long Id { get; set; }
        public string? Material { get; set; }
        public double QuantityOld { get; set; }
        [Required]
        public double QuantityNew { get; set; }
    }
}
