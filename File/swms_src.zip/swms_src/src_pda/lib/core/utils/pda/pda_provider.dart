import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/utils/pda/pda.dart';
import 'package:swms_finish_goods/core/utils/pda/zebra_pda.dart';

final pdaProvider = FutureProvider<PdaDevice>((ref) async {
  ref.keepAlive();
  final pda = ZebraPda();
  await pda.initialize();
  ref.onDispose(pda.dispose);
  return pda;
});