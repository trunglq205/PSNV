using System.Data;
using Microsoft.Data.SqlClient;

namespace ShippingScs.Web.Data;

/// <summary>Tạo kết nối SQL Server. Dapper tự mở/đóng kết nối khi chạy lệnh.</summary>
public class Db
{
    private readonly string _connectionString;

    public Db(IConfiguration configuration)
    {
        _connectionString = configuration.GetConnectionString("Default")
            ?? throw new InvalidOperationException("Missing ConnectionStrings:Default in appsettings.json");
    }

    public IDbConnection Connection() => new SqlConnection(_connectionString);
}
