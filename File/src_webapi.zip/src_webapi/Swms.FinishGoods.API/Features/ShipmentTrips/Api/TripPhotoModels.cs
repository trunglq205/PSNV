using System.ComponentModel.DataAnnotations;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

// Ảnh minh chứng hàng xuất theo chuyến. PDA upload, Web chỉ xem.
// Khớp IShipmentTripApi (Refit) bên Web và màn chụp ảnh bên PDA.

// ── Request ─────────────────────────────────────────────────
/// <summary>
/// multipart/form-data. ItemKey lấy từ Items của GET {id}/photos (vd fcl.cont.corner).
/// PalletCode: ảnh theo pallet — mã pallet quét từ tem (bắt buộc, pallet phải thuộc chuyến).
/// UnitNo: ảnh theo cọc (= coc_no) / hàng (hàng thứ mấy) — bỏ trống với ảnh theo chuyến / pallet.
/// SlotNo: ảnh thứ mấy trong mục (1..PerUnit) — bỏ trống được khi mục chỉ có 1 ảnh.
/// Gửi lại cùng ItemKey + UnitNo + SlotNo = chụp lại, ảnh cũ bị thay.
/// </summary>
public class TripPhotoUploadRequest
{
    [Required] public IFormFile File { get; set; } = default!;
    [Required, MaxLength(40)] public string ItemKey { get; set; } = "";
    [Range(1, 999)] public int? UnitNo { get; set; }
    [MaxLength(30)] public string? PalletCode { get; set; }
    [Range(1, 20)] public int? SlotNo { get; set; }
}

// ── Response ────────────────────────────────────────────────
public record TripPhotoResponse(
    long Id, string ItemKey, int? UnitNo, int SlotNo,
    string FileName, long? SizeBytes, DateTime CreatedAt, string? CreatedBy,
    string? PalletCode = null)
{
    public static TripPhotoResponse From(TripPhotoRow r) => new(
        r.Id, r.ItemKey, r.UnitNo, r.SlotNo, r.FileName, r.SizeBytes, r.CreatedAt, r.CreatedBy, r.PalletCode);
}

/// <summary>1 Pallet List của chuyến (pallet thuộc chuyến còn hàng). CocNo: đã ghép vào cọc nào (null = chưa).
/// Have / Required: ảnh theo pallet của riêng pallet này.</summary>
public record TripPalletListResponse(
    string Code, int BoxCount, int Pcs, string? LocatorCode, int? CocNo, int Have, int Required);

/// <summary>
/// 1 mục ảnh bắt buộc của chuyến. Unit: trip | pallet | coc | row.
/// Units = số đơn vị ước tính (trip = 1); Required = PerUnit × Units; Have = số ảnh đã có.
/// </summary>
public record TripPhotoItemResponse(
    int Step, string StepTitle, string Key, string Label, string? Note,
    int PerUnit, string Unit, int Units, int Required, int Have, string[]? SlotLabels);

/// <summary>
/// Màn chụp ảnh PDA và tab "Ảnh minh chứng" của Web dùng chung. CanUpload = chuyến còn mở
/// (chưa xuất cổng / huỷ) — PDA dựa vào đây để khoá nút chụp.
/// Inspection: lần kiểm container mới nhất (null = chưa kiểm / không phải container).
/// Pallets: số Pallet List thật (pallet thuộc chuyến còn hàng); chưa phân pallet thì ước tính theo SI.
/// Cocs: số cọc đã ghép nếu có, không thì ước tính 2 pallet / cọc.
/// PalletLists / Stacks: danh sách thật cho màn PDA (ảnh theo pallet, ghép cọc).
/// </summary>
public record TripPhotoListResponse(
    long TripId, string TripNo, string VehicleType, string Status, bool CanUpload,
    int Pallets, int Cocs, int Rows,
    int Required, int Have,
    List<TripPhotoItemResponse> Items,
    List<TripPhotoResponse> Photos,
    TripInspectionResponse? Inspection = null,
    List<TripPalletListResponse>? PalletLists = null,
    List<TripStackResponse>? Stacks = null);
