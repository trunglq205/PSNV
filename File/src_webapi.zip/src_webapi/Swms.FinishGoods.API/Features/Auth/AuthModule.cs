using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Authorization;
using Microsoft.IdentityModel.Tokens;
using Swms.FinishGoods.API.Features.Auth.Business;
using Swms.FinishGoods.API.Features.Auth.Common;
using Swms.FinishGoods.API.Features.Auth.DataAccess;
using Swms.FinishGoods.API.Shared.Business;
using System.Text;

namespace Swms.FinishGoods.API.Features.Auth;

public static class AuthModule
{
    public static IServiceCollection AddAuthFeature(
        this IServiceCollection services, IConfiguration config)
    {
        var jwt = config.GetSection("Jwt").Get<JwtOptions>()
                  ?? throw new InvalidOperationException("Thiếu cấu hình 'Jwt' trong appsettings.");
        services.AddSingleton(jwt);

        services.AddScoped<IAuthService, AuthService>();
        services.AddSingleton<IPasswordHasher, PasswordHasher>();

        // --- API Key (cho hệ thống ngoài: QMS, SAP, HRM, ...) ---
        services.AddScoped<IApiKeyRepository, ApiKeyRepository>();
        services.AddScoped<IApiKeyService, ApiKeyService>();

        services.AddAuthentication(options =>
        {
            // Policy scheme "Smart": có X-Api-Key -> ApiKey, còn lại -> JWT.
            options.DefaultScheme = "Smart";
            options.DefaultAuthenticateScheme = "Smart";
            options.DefaultChallengeScheme = "Smart";
        })
            .AddPolicyScheme("Smart", "JWT or ApiKey", options =>
            {
                options.ForwardDefaultSelector = ctx =>
                    ctx.Request.Headers.ContainsKey(ApiKeyAuthenticationOptions.HeaderName)
                        ? ApiKeyAuthenticationOptions.Scheme
                        : JwtBearerDefaults.AuthenticationScheme;
            })
            .AddJwtBearer(JwtBearerDefaults.AuthenticationScheme, options =>
            {
                options.TokenValidationParameters = new TokenValidationParameters
                {
                    ValidateIssuer = true,
                    ValidateAudience = true,
                    ValidateLifetime = true,
                    ValidateIssuerSigningKey = true,
                    ValidIssuer = jwt.Issuer,
                    ValidAudience = jwt.Audience,
                    IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(jwt.Secret)),
                    ClockSkew = TimeSpan.FromMinutes(1)
                };
            })
            .AddScheme<ApiKeyAuthenticationOptions, ApiKeyAuthenticationHandler>(
                ApiKeyAuthenticationOptions.Scheme, _ => { });

        services.AddAuthorization(options =>
        {
            options.FallbackPolicy = new AuthorizationPolicyBuilder()
                .RequireAuthenticatedUser()
                .Build();
        });
        return services;
    }
}