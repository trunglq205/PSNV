using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.Stocky.Business;

namespace Swms.FinishGoods.API.Features.Stocky.Api;

/// <summary>
/// Quản lý xe Stocky. Route <c>api/stocky-carts</c> giữ ĐÚNG đường dẫn PDA đã
/// khai sẵn trong <c>stocky_remote_data_source.dart</c> — đổi ở đây là phải đổi
/// cả PDA.
///
/// Ba chiều tách thành BA endpoint chứ không gộp một endpoint nhận tham số
/// mode: mỗi chiều một quyền riêng, mà <c>[RequirePermission]</c> gắn theo
/// action nên gộp lại sẽ không gắn được quyền đúng cho từng chiều.
///
/// Ba chiều, phân biệt theo việc xe CÓ CÒN ĐƯỢC QUẢN LÝ KHÔNG:
///   <c>receive</c>   — vào kho. Xe mới từ vendor, hoặc xe từ FA đưa về.
///   <c>export-fa</c> — sang FA. Xe VẪN được quản lý, chỉ đổi vị trí.
///   <c>return</c>    — về vendor. Xe RỜI hệ thống.
/// </summary>
[ApiController]
[Route("api/stocky-carts")]
public class StockyController : ControllerBase
{
    private readonly IStockyService _service;
    public StockyController(IStockyService service) => _service = service;

    /// <summary>
    /// Danh sách xe kèm vị trí hiện tại và tình trạng rỗng / có hàng.
    /// Dùng cho cả màn danh sách trên PDA và dialog bên Web.
    /// </summary>
    [HttpGet]
    [RequirePermission<Perms.Receiving.Stocky.View>]
    public async Task<ActionResult<IReadOnlyList<StockyCartResponse>>> GetList(
        [FromQuery] StockyQuery query)
        => Ok(await _service.GetListAsync(query));

    /// <summary>
    /// Tra một xe vừa quét theo chiều <paramref name="mode"/> (in | fa | out).
    /// Sai chiều trả 409 kèm câu thông báo đã dịch.
    /// </summary>
    [HttpGet("{code}")]
    [RequirePermission<Perms.Receiving.Stocky.View>]
    public async Task<ActionResult<StockyLookupResponse>> Lookup(
        string code, [FromQuery] string? mode)
        => Ok(await _service.LookupAsync(code, mode));

    /// <summary>Nhận một lô xe từ vendor vào kho.</summary>
    [HttpPost("receive")]
    [RequirePermission<Perms.Receiving.Stocky.Create>]
    public async Task<ActionResult<StockySubmitResponse>> Receive(
        [FromBody] StockyBatchRequest request)
        => Ok(await _service.ReceiveAsync(request));

    /// <summary>
    /// Đẩy một lô xe sang FA. Xe VẪN nằm trong danh sách theo dõi, chỉ đổi vị
    /// trí sang ô FA.
    /// </summary>
    [HttpPost("export-fa")]
    [RequirePermission<Perms.Receiving.Stocky.Transfer>]
    public async Task<ActionResult<StockySubmitResponse>> ExportToFa(
        [FromBody] StockyBatchRequest request)
        => Ok(await _service.ExportToFaAsync(request));

    /// <summary>
    /// Trả một lô xe VỀ VENDOR — xe rời hệ thống.
    ///
    /// ⚠ Endpoint này KHÔNG đổi tên dù nghĩa đã thu hẹp: trước đây PDA gọi nó
    /// cho nút "Xuất sang FA". Bản PDA cũ còn chạy ngoài hiện trường sẽ trả
    /// nhầm xe về vendor, nên phải cập nhật PDA cùng lúc với API.
    ///
    /// Dùng chung quyền <c>stocky.transfer</c> với xuất FA để khỏi phải cấp
    /// lại quyền cho các role hiện có. Muốn siết riêng thì đổi sang
    /// <c>Perms.Receiving.Stocky.Delete</c> và cấp lại quyền cho role.
    /// </summary>
    /// <summary>
    /// Đặt MỘT xe vào MỘT ô trong kho. Hàng trên xe đi theo xe.
    ///
    /// Dùng lại quyền <c>stocky.transfer</c> như xuất FA: cùng là đổi chỗ đứng
    /// của xe, thêm một lá quyền nữa chỉ tạo thêm chỗ để quên gán.
    /// </summary>
    [HttpPost("place")]
    [RequirePermission<Perms.Receiving.Stocky.Transfer>]
    public async Task<ActionResult<StockyPlaceResponse>> Place(
        [FromBody] StockyPlaceRequest request)
        => Ok(await _service.PlaceAsync(request));

    [HttpPost("return")]
    [RequirePermission<Perms.Receiving.Stocky.Transfer>]
    public async Task<ActionResult<StockySubmitResponse>> Return(
        [FromBody] StockyBatchRequest request)
        => Ok(await _service.ReturnAsync(request));
}
