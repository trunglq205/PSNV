﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using System.Drawing.Printing;

namespace SWMS_WebTool.ViewModels
{
    public class ExpiredGoodsViewModel : TableViewModel<ExpiredGoods, ExpiredGoodsFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, ExpiredGoodsFilter? filter = null)
        {
            return new
            {
                Material = filter?.Material ?? Filter.Material,
                Plant = filter?.Plant ?? Filter.Plant,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Category = filter?.Category ?? Filter.Category,
                IsAll = filter?.IsAll,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
                Selectdate = filter?.Selectdate ?? Filter.Selectdate,
            };
        }
    }
}
