part of 'exceptions.dart';

/// Lỗi nghiệp vụ khi quét gộp pallet / box vào Pallet List (màn Vanning).
/// Kiểm tra phía client trước khi gọi API — lỗi cùng SI / cùng tuyến do
/// server trả về (ServerException).
sealed class VanningException extends AppException {
  const VanningException(super.message, {required super.code});
}

/// Quét lại chính pallet gốc thay vì mục cần gộp.
class VanningScanIsBaseException extends VanningException {
  const VanningScanIsBaseException()
      : super(
    'Đây là pallet gốc, hãy quét pallet / box cần gộp',
    code: 'error.vanning_scan_is_base',
  );
}

class VanningAlreadyScannedException extends VanningException {
  const VanningAlreadyScannedException(this.itemCode)
      : super(
    'Mã "$itemCode" đã được quét rồi',
    code: 'error.vanning_already_scanned',
  );

  final String itemCode;

  @override
  Map<String, String> get namedArgs => {'code': itemCode};
}

/// Pallet đôi chỉ chồng pallet — box lẻ phải gộp ở tab Pallet List.
class VanningDoublePalletBoxException extends VanningException {
  const VanningDoublePalletBoxException()
      : super(
    'Pallet đôi chỉ nhận pallet, không nhận box',
    code: 'error.vanning_double_pallet_box',
  );
}

/// Pallet đôi = pallet gốc + đúng 1 pallet chồng lên.
class VanningDoublePalletFullException extends VanningException {
  const VanningDoublePalletFullException()
      : super(
    'Pallet đôi chỉ chồng được 1 pallet',
    code: 'error.vanning_double_pallet_full',
  );
}