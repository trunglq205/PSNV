namespace Swms.FinishGoods.API.Features.MapView;

/// <summary>Tồn theo từng vị trí (cột) của 1 kệ — để tô từng khoang trên khối kệ.</summary>
public class RackPositionOcc
{
    public long RackId { get; set; }
    public int Position { get; set; }
    public int Total { get; set; }
    public int Occupied { get; set; }
}

/// <summary>Lot đang nằm trên 1 ô pallet.</summary>
public class MapViewLot
{
    public long LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public int? BoxCount { get; set; }
    public DateTime? ProductionDate { get; set; }
    public string Status { get; set; } = "empty";
    public bool IsUrgent { get; set; }

    /// <summary>
    /// rework | refurbish | null (hàng thường) — bản đồ vẽ dấu RW/RB cạnh
    /// Pallet ID. Lùi về <c>return_instructions.goods_type</c> khi cột
    /// <c>pallets.disposition</c> chưa có dấu.
    /// </summary>
    public string? Disposition { get; set; }
}

/// <summary>
/// Khối trên bản đồ xem trạng thái — DÙNG CHUNG cho mọi map_type.
/// (<c>Disposition</c> ở cuối lớp: dấu RW/RB của ô.)
/// rack   : hiển thị tỉ lệ chiếm chỗ, bấm mở mặt đứng
/// pallet : hiển thị trạng thái kiểm, bấm xem lot
/// zone   : khối trang trí, không có trạng thái
/// </summary>
public class MapViewBlock
{
    public long Id { get; set; }
    public string Kind { get; set; } = "zone";     // rack | pallet | zone

    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; }
    public int GridH { get; set; }
    public string? Label { get; set; }
    public string? Color { get; set; }
    public string? Arrow { get; set; }

    // --- rack ---
    public long? RackId { get; set; }
    public string? RackCode { get; set; }
    public int TotalSlots { get; set; }
    public int OccupiedSlots { get; set; }
    public List<RackPositionOcc> Positions { get; set; } = new();

    // --- pallet ---
    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string Status { get; set; } = "empty";
    public bool IsUrgent { get; set; }
    public string? Model { get; set; }

    /// <summary>
    /// rework | refurbish | null — Ô NÀY có hàng tái gia công (lot đầu tiên có
    /// dấu). Bản đồ vẽ một dấu nhỏ ở góc ô; từng pallet nói ở dialog danh sách.
    /// </summary>
    public string? Disposition { get; set; }

    public List<MapViewLot> Lots { get; set; } = new();
}

/// <summary>Thống kê chiếm chỗ toàn bản đồ (đếm cả ô con trong kệ và giá lửng).</summary>
public class MapViewSummary
{
    public int TotalSlots { get; set; }        // tổng ô chứa được hàng
    public int OccupiedSlots { get; set; }     // ô đang có hàng
    public int EmptySlots => TotalSlots - OccupiedSlots;
    public double OccupiedPercent => TotalSlots == 0 ? 0
        : Math.Round(OccupiedSlots * 100.0 / TotalSlots, 1);

    // Tách theo loại để nhìn nhanh
    public int RackTotalSlots { get; set; }
    public int RackOccupiedSlots { get; set; }
    public int PalletTotalSlots { get; set; }
    public int PalletOccupiedSlots { get; set; }
}

public class MapViewLayout
{
    public long AreaId { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public string MapType { get; set; } = "storing";
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public List<MapViewBlock> Blocks { get; set; } = new();
    public MapViewSummary Summary { get; set; } = new();
}
