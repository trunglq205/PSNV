import 'dart:async';

import 'package:flutter_datawedge/flutter_datawedge.dart';
import 'package:swms_finish_goods/core/utils/pda/data_wedge_config.dart';
import 'package:swms_finish_goods/core/utils/pda/pda.dart';

class ZebraPda implements PdaDevice {
  static const String _profileName = 'FlutterDataWedge';

  /// Tham số decoder áp cho profile của app.
  static const Map<String, String> _barcodeParams = <String, String>{
    'scanner_selection': 'auto',
    'scanner_input_enabled': 'true',

    // Interleaved 2 of 5
    'decoder_i2of5': 'true',
    'decoder_i2of5_length1': '6',   // độ dài tối thiểu
    'decoder_i2of5_length2': '20',  // độ dài tối đa
    'decoder_i2of5_redundancy': 'true',
    'decoder_i2of5_check_digit': '0',
    'decoder_i2of5_report_check_digit': 'false',
    'decoder_i2of5_convert_to_ean13': 'false',
    'decoder_i2of5_security_level': '1',
  };

  late final FlutterDataWedge _dataWedge;
  StreamSubscription<ScanResult>? _onScanSubscription;

  final StreamController<String> _scanController =
  StreamController<String>.broadcast();

  bool _initialized = false;

  @override
  Stream<String> get scanStream => _scanController.stream;

  @override
  Future<void> initialize() async {
    if (_initialized) return;

    _dataWedge = FlutterDataWedge();
    await _dataWedge.initialize();
    await _dataWedge.createDefaultProfile(profileName: _profileName);

    // DataWedge xử lý CREATE_PROFILE bất đồng bộ.
    // SET_CONFIG bắn ngay sau đó có thể rơi vào lúc profile chưa tồn tại.
    await Future<void>.delayed(const Duration(milliseconds: 500));
    await DataWedgeConfig.setBarcodeParams(
      profileName: _profileName,
      params: _barcodeParams,
    );

    _onScanSubscription = _dataWedge.onScanResult.listen((result) {
      if (!_scanController.isClosed) {
        _scanController.add(result.data);
      }
    });

    _initialized = true;
  }

  @override
  void dispose() {
    _onScanSubscription?.cancel();
    _onScanSubscription = null;
    _scanController.close();
    _initialized = false;
  }
}