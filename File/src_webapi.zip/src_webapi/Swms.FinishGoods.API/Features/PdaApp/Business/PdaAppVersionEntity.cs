namespace Swms.FinishGoods.Api.Features.PdaApp;

/// <summary>
/// Domain entity map bảng master.pda_app_versions. Không lộ ra ngoài — chỉ trả PdaAppVersionResponse.
/// Mỗi bản ghi là một phiên bản APK đã công bố; bản đang phát hành có is_current = 1.
/// </summary>
public class PdaAppVersionEntity
{
    public long Id { get; set; }
    public string Version { get; set; } = "";        // versionName Android, vd "1.2.0" (business key, UNIQUE)
    public int VersionCode { get; set; }             // versionCode Android (tăng dần)
    public string ReleaseNote { get; set; } = "";
    public string ApkPath { get; set; } = "";        // đường dẫn/khoá lưu file trên storage (nội bộ)
    public string ApkUrl { get; set; } = "";         // URL công khai để tải/QR
    public long SizeBytes { get; set; }
    public bool ForceUpdate { get; set; }
    public bool IsCurrent { get; set; }              // bản đang phát hành (chỉ 1 bản = 1)
    public DateTime PublishedAt { get; set; }

    // Audit
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>Metadata đọc từ file APK khi công bố (versionName + versionCode).</summary>
public sealed record ApkInfo(string Version, int VersionCode);
