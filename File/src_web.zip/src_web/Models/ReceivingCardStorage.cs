﻿
namespace SWMS_WebTool.Models
{
    public record ReceivingCardStorage
    {
        public long ReceivingCardID { get; set; }

        public double? TotalQuantity { get; set; }
        public double? CurrentQuantity { get; set; }

        public string Plant { get; set; }

        public string Material { get; set; }
        public string MaterialType { get; set; }
        public string MaterialFrequency { get; set; }

        public string Sloc { get; set; }

        public string Category { get; set; }
        public string DANo { get; set; }
        public string VendorCode { get; set; }
        public string QC_Check { get; set; }
        public string PositionTem { get; set; }
        public string PositionStorage { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? StorageDate { get; set; }
        public string UserStorage { get; set; }
        public string StatusStorage { get; set; }
        public int BoxQuantity { get; set; }
        public string QuantityCheck { get; set; }
        public int Total { get; set; }
    }
}
