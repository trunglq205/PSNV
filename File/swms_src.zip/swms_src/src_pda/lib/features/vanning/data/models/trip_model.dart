import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/vanning/domain/trip_entities.dart';

part 'trip_model.g.dart';

// Khớp TripResponse (Features/ShipmentTrips/Api/ShipmentTripModels.cs).
// Tên field camelCase như JSON mặc định của ASP.NET — KHÔNG dùng FieldRename.snake.

@JsonSerializable(createToJson: false)
class TripSiModel {
  final int siId;
  final String siNo;
  final String? shipMode;

  /// Số pallet của SI này trên xe này (xe tải bắt buộc; container trống = cả SI).
  final int? pltPlanned;
  final int siPltTotal;

  const TripSiModel({
    required this.siId,
    required this.siNo,
    this.shipMode,
    this.pltPlanned,
    this.siPltTotal = 0,
  });

  int get pallets => pltPlanned ?? siPltTotal;

  factory TripSiModel.fromJson(Map<String, dynamic> json) =>
      _$TripSiModelFromJson(json);
}

@JsonSerializable(createToJson: false)
class TripModel {
  final int id;
  final String tripNo;
  final String vehicleType;
  final String? plateNo;
  final String? containerNo;
  final String? containerSize;
  final String? sealNo;
  final String? forwarderCode;
  final DateTime? plannedArrivalAt;
  final String status;
  final List<TripSiModel> sis;

  const TripModel({
    required this.id,
    required this.tripNo,
    required this.vehicleType,
    this.plateNo,
    this.containerNo,
    this.containerSize,
    this.sealNo,
    this.forwarderCode,
    this.plannedArrivalAt,
    required this.status,
    this.sis = const [],
  });

  factory TripModel.fromJson(Map<String, dynamic> json) =>
      _$TripModelFromJson(json);

  TripItem toEntity() => TripItem(
        id: id,
        tripNo: tripNo,
        vehicle: TripVehicle.fromCode(vehicleType),
        plateNo: plateNo,
        containerNo: containerNo,
        containerSize: containerSize,
        sealNo: sealNo,
        forwarderCode: forwarderCode,
        plannedArrivalAt: plannedArrivalAt,
        status: TripStatus.fromCode(status),
        siNos: sis.map((s) => s.siNo).toList(),
        pallets: sis.fold(0, (s, x) => s + x.pallets),
      );
}
