part of 'exceptions.dart';

/// Lỗi nghiệp vụ màn Stowage Plan.
sealed class StowageException extends AppException {
  const StowageException(super.message, {required super.code});
}

/// Container quét được chưa có sơ đồ xếp (chưa chạy 3D loading / chưa gán SI).
class StowagePlanNotFoundException extends StowageException {
  const StowagePlanNotFoundException(this.containerNo)
      : super(
    'Container "$containerNo" chưa có sơ đồ xếp',
    code: 'error.stowage_plan_not_found',
  );

  final String containerNo;

  @override
  Map<String, String> get namedArgs => {'code': containerNo};
}

/// Quét lại Pallet List đã quét cho ô đang xếp.
class StowagePalletListDuplicateException extends StowageException {
  const StowagePalletListDuplicateException(this.palletListCode)
      : super(
    'Pallet List "$palletListCode" đã quét rồi',
    code: 'error.stowage_pallet_list_duplicate',
  );

  final String palletListCode;

  @override
  Map<String, String> get namedArgs => {'code': palletListCode};
}

/// Pallet List không thuộc vị trí này (khác SI / khác loại pallet / đã xếp
/// ở ô khác) — server trả về khi kiểm.
class StowagePalletListMismatchException extends StowageException {
  const StowagePalletListMismatchException(this.palletListCode, this.towerNo)
      : super(
    'Pallet List "$palletListCode" không xếp vào Tower $towerNo',
    code: 'error.stowage_pallet_list_mismatch',
  );

  final String palletListCode;
  final String towerNo;

  @override
  Map<String, String> get namedArgs => {'code': palletListCode, 'tower': towerNo};
}

/// Xác nhận khi chưa quét đủ Pallet List / chưa có ảnh. UI đã khoá nút,
/// đây là chốt chặn thứ hai ở notifier.
class StowagePlaceIncompleteException extends StowageException {
  const StowagePlaceIncompleteException()
      : super(
    'Chưa quét đủ Pallet List hoặc chưa chụp ảnh minh chứng',
    code: 'error.stowage_place_incomplete',
  );
}
