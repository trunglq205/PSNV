using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.HdSoft.Shortage.App;
using Swms.FinishGoods.Web.Features.HdSoft.Shortage.Business;
using Swms.FinishGoods.Web.Features.HdSoft.Shortage.Client;
using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.App;
using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business;
using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Client;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Client;
using Swms.FinishGoods.Web.Features.ShipmentInstructions.App.Addons;
using Swms.FinishGoods.Web.Features.Shortages.App.Addons;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.HdSoft;

/// <summary>Phần chạy song song với HD soft (hệ thống cũ) phía Web. TẠM THỜI.
/// Khi hệ thống ổn định: xoá thư mục Features/HdSoft + dòng AddHdSoftFeature trong Program.cs là xong.
/// Màn SI / Hàng thiếu không phải sửa gì — nút HD soft gắn qua điểm cắm (ISiScreenAddon,
/// IShortageScreenAddon), không tham chiếu ngược.</summary>
public static class HdSoftModule
{
    /// <summary>Gọi trong Program.cs SAU AddShipmentInstructionFeature và AddShortageFeature
    /// (đối chiếu SI dùng IShipmentInstructionApi để tạo SI).</summary>
    public static IServiceCollection AddHdSoftFeature(this IServiceCollection services, ApiClientContext api)
    {
        // Đối chiếu SI SWMS ↔ HD soft — nút trên màn SI
        services.AddApiClient<ISiHdSoftCompareApi>(api);
        services.AddScoped<ISiHdSoftCompareBusiness, SiHdSoftCompareBusiness>();
        services.AddSingleton<ISiScreenAddon, SiHdSoftAddon>();

        // Hàng thiếu tính trên HD soft — nút trên màn Hàng thiếu
        services.AddApiClient<IHdSoftShortageApi>(api);
        services.AddScoped<IHdSoftShortageBusiness, HdSoftShortageBusiness>();
        services.AddSingleton<IShortageScreenAddon, ShortageHdSoftAddon>();

        // ── So tồn SWMS ↔ HD soft ──
        services.AddApiClient<IHdSoftCompareApi>(api);
        services.AddScoped<IHdSoftCompareBusiness, HdSoftCompareBusiness>();
        return services;
    }
}
