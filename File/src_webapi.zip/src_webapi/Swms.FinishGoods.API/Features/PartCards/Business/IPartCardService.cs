using Microsoft.AspNetCore.Http;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.PartCards.Api;

namespace Swms.FinishGoods.API.Features.PartCards.Business;

public interface IPartCardService
{
    Task<PartCardResponse> SavePrintHistoryAsync(SavePrintRequest request);
    // Lưu lịch sử in (1 hoặc nhiều phiếu) khi bấm "Hoàn thành".
    Task<List<PartCardResponse>> SavePrintHistoryAsync(IReadOnlyList<SavePrintRequest> requests);

    // Danh sách lịch sử in (phân trang).
    Task<PagedResult<PartCardResponse>> GetPrintHistoryAsync(PartCardQuery query);

    // Chi tiết 1 lần in (để in lại).
    Task<PartCardResponse> GetPrintHistoryByIdAsync(long id);

    // Sửa toàn bộ nội dung phiếu (header + dòng hàng); trả về phiếu sau khi sửa.
    // Ném NotFound nếu không tồn tại / đã xoá, BusinessRule nếu phiếu đã vào quy trình OQC.
    Task<PartCardResponse> UpdatePrintHistoryAsync(long id, SavePrintRequest request);

    // Truy vết 1 phiếu (cả phiếu đã xoá mềm). Ném NotFound nếu id chưa từng tồn tại.
    Task<PartCardLineageResponse> GetLineageAsync(long id);

    // Tách 1 phiếu 1 mã, 1 thùng thành nhiều phiếu; trả về các phiếu mới.
    // Ném NotFound nếu phiếu nguồn không tồn tại / đã xoá; BusinessRule nếu sai số lượng,
    // phiếu nguồn đang khoá / đã vào OQC / vừa bị đổi ở máy khác.
    Task<List<PartCardResponse>> SplitAsync(SplitPartCardRequest request);

    // Gộp nhiều phiếu thành 1 phiếu nhiều mã; trả về phiếu gộp. Lỗi như SplitAsync.
    Task<PartCardResponse> MergeAsync(MergePartCardsRequest request);

    // Cập nhật kích thước / trọng lượng cấp phiếu; trả về phiếu sau cập nhật.
    Task<PartCardResponse> UpdateDimensionsAsync(long id, UpdateDimensionsRequest request);

    // Xoá mềm 1 phiếu; ném NotFound nếu không tồn tại / đã xoá,
    // BusinessRule nếu phiếu đang khoá.
    Task DeletePrintHistoryAsync(long id);

    // Xoá mềm nhiều phiếu; trả về số phiếu đã xoá + các id không tìm thấy + các id đang khoá.
    // Phiếu đang khoá bị bỏ qua, các phiếu còn lại vẫn xoá.
    Task<DeletePartCardsResponse> DeletePrintHistoryAsync(IReadOnlyList<long> ids);

    // Khoá / mở khoá 1 phiếu; trả về phiếu sau thao tác. Ném NotFound nếu không tồn tại / đã xoá.
    // Idempotent: phiếu đã ở sẵn trạng thái đích thì vẫn trả về bình thường.
    Task<PartCardResponse> LockPrintHistoryAsync(long id);
    Task<PartCardResponse> UnlockPrintHistoryAsync(long id);

    // Khoá / mở khoá nhiều phiếu; trả về số phiếu đổi trạng thái + id đã ở sẵn trạng thái đích
    // + id không tìm thấy.
    Task<LockPartCardsResponse> LockPrintHistoryAsync(IReadOnlyList<long> ids);
    Task<LockPartCardsResponse> UnlockPrintHistoryAsync(IReadOnlyList<long> ids);
}