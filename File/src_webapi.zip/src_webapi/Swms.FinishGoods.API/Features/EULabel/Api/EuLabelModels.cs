namespace Swms.FinishGoods.API.Features.EuLabel.Api;

/// <summary>Đăng nhập bằng thẻ nhân viên — mã thẻ = UserName, không mật khẩu.</summary>
public sealed record CardLoginRequest(string CardCode);

/// <summary>Đăng nhập PDA — check tài khoản/mật khẩu trong DB In tem.</summary>
public sealed record EuLabelLoginRequest(
    string UserName,
    string Password);   // mật khẩu thô, API tự hash SHA-256 khớp với desktop

/// <summary>
/// Kết quả đăng nhập. Success=false nếu sai tài khoản/mật khẩu.
/// Khi thành công trả UserId để PDA gửi kèm mỗi lần confirm.
/// </summary>
public sealed record EuLabelLoginResponse(
    bool Success,
    int UserId,
    string UserName,
    string DisplayName,
    string Role);

/// <summary>Yêu cầu xác nhận 1 tem đã dán (từ PDA).</summary>
public sealed record HandoverConfirmRequest(
    string Key,          // QrContent đầy đủ hoặc SerialNo
    int ConfirmedBy);    // AppUserId của người xác nhận

/// <summary>
/// Kết quả xác nhận. Result: 1 = OK, -1 = đã xác nhận trước đó, 0 = không tìm thấy.
/// </summary>
public sealed record HandoverConfirmResponse(
    int Result,
    string Message);

/// <summary>Tổng kết đối chiếu 1 lô.</summary>
public sealed record HandoverJobSummaryResponse(
    int Total,
    int Confirmed,
    int NotConfirmed);

/// <summary>1 dòng serial trong chi tiết lô (cho PDA hiển thị).</summary>
public sealed record HandoverSerialRow(
    string SerialNo,
    int UnitNo,
    string Status,
    DateTime? UsedAt,
    string? ConfirmSource,
    string? ConfirmedByName);

/// <summary>
/// Kết quả tìm lô từ 1 QR tem: thông tin lô + tổng kết + toàn bộ serial của lô.
/// found=false nếu QR không thuộc lô nào.
/// </summary>
public sealed record JobByTagResponse(
    bool Found,
    int PrintJobId,
    string SiList,
    HandoverJobSummaryResponse? Summary,
    List<HandoverSerialRow> Serials);