// HdSoftDbConnectionFactory.cs
using System.Data;
using Npgsql;

namespace Swms.FinishGoods.API.Features.HdSoft.DataAccess;

public interface IHdSoftDbConnectionFactory
{
    IDbConnection Create();
}

public class HdSoftDbConnectionFactory : IHdSoftDbConnectionFactory
{
    private readonly string _connectionString;

    public HdSoftDbConnectionFactory(IConfiguration config)
    {
        _connectionString = config.GetConnectionString("HdSoft")
            ?? throw new InvalidOperationException("Thiếu ConnectionStrings:HdSoft");
    }

    public IDbConnection Create() => new NpgsqlConnection(_connectionString);
}
