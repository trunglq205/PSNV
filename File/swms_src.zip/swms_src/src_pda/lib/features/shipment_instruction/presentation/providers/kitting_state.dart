import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';

class KittingState {
  /// SI đang soạn. `AsyncData(null)` = không có SI nào ở trạng thái đang soạn.
  final AsyncValue<ShipmentInstructionDetail?> si;

  /// Tuyến lấy hàng: nhiệm vụ của mọi dòng, theo thứ tự server tính.
  /// Tính 1 lần khi nạp xong SI — không để UI tự gom/sort mỗi lần build.
  final List<PickTask> route;

  const KittingState({
    this.si = const AsyncValue.loading(),
    this.route = const [],
  });

  KittingState copyWith({
    AsyncValue<ShipmentInstructionDetail?>? si,
    List<PickTask>? route,
  }) => KittingState(si: si ?? this.si, route: route ?? this.route);
}