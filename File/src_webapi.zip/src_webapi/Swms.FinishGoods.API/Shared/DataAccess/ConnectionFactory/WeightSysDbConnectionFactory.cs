using System.Data;
using Microsoft.Data.SqlClient;

namespace Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

/// <summary>
/// Tạo IDbConnection trỏ tới database của hệ thống WeightSys (khác instance với DB chính SWMS).
/// Tách riêng khỏi IDbConnectionFactory mặc định để không nhầm connection string.
/// </summary>
public interface IWeightSysConnectionFactory
{
    IDbConnection Create();
}

public class WeightSysDbConnectionFactory : IWeightSysConnectionFactory
{
    private readonly string _connStr;

    public WeightSysDbConnectionFactory(IConfiguration cfg)
        => _connStr = cfg.GetConnectionString("WeightSysDb")
                      ?? throw new InvalidOperationException(
                          "Missing connection string 'WeightSysDb' in configuration.");

    public IDbConnection Create() => new SqlConnection(_connStr);
}
