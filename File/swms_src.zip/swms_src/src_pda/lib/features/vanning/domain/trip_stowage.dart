// Stowage Plan của chuyến trên PDA (GET /shipment-trips/{id}/stowage).
// Văn phòng lập plan (cọc C01…, tầng dưới / trên, hàng × làn trong cont);
// PDA ghi thực tế: ghép Pallet List vào cọc (Pallet Stack) và xếp cọc vào cont (Stowage).

/// 1 tầng của cọc theo plan. [tier] 1 = dưới, 2 = trên.
class StowageTier {
  final int tier;
  final String? planPalletCode;
  final String? siNo;
  final String? palletSize;

  const StowageTier({
    required this.tier,
    this.planPalletCode,
    this.siNo,
    this.palletSize,
  });
}

/// 1 cọc trong container của chuyến.
class StowageColumn {
  final String code;

  /// Số trong mã cọc (C07 → 7) — đơn vị của ảnh "Cọc pallet".
  final int cocNo;

  /// 0 = sát đầu cont. null = plan chưa đặt cọc vào ô.
  final int? rowNo;

  /// 0 = trái, 1 = phải.
  final int? laneNo;
  final List<StowageTier> tiers;

  /// Pallet List thật đã ghép (null = chưa ghép).
  final String? bottomCode;
  final String? topCode;
  final DateTime? stackedAt;
  final DateTime? placedAt;
  final String? placedBy;

  const StowageColumn({
    required this.code,
    required this.cocNo,
    this.rowNo,
    this.laneNo,
    this.tiers = const [],
    this.bottomCode,
    this.topCode,
    this.stackedAt,
    this.placedAt,
    this.placedBy,
  });

  bool get stacked => bottomCode != null;
  bool get placed => placedAt != null;

  /// Plan có tầng trên → ghép phải quét đủ 2 Pallet List.
  bool get needsTop => tiers.any((t) => t.tier == 2);
  int get tierCount => needsTop ? 2 : 1;

  StowageTier? tierOf(int tier) {
    for (final t in tiers) {
      if (t.tier == tier) return t;
    }
    return null;
  }

  /// Mã quét có phải 1 trong 2 pallet đã ghép vào cọc này.
  bool holds(String code) {
    final c = code.toUpperCase();
    return bottomCode?.toUpperCase() == c || topCode?.toUpperCase() == c;
  }
}

class TripStowage {
  final int tripId;
  final String planNo;
  final String planStatus;
  final String shipMode;
  final String containerType;
  final int rows;
  final int lanes;
  final int stackedCount;
  final int placedCount;

  /// Chuyến còn mở → ghép / xếp được.
  final bool canEdit;
  final List<StowageColumn> columns;

  const TripStowage({
    required this.tripId,
    required this.planNo,
    required this.planStatus,
    required this.shipMode,
    required this.containerType,
    required this.rows,
    required this.lanes,
    required this.stackedCount,
    required this.placedCount,
    required this.canEdit,
    required this.columns,
  });

  int get total => columns.length;

  StowageColumn? find(String code) {
    final c = code.toUpperCase();
    for (final col in columns) {
      if (col.code.toUpperCase() == c) return col;
    }
    return null;
  }

  StowageColumn? at(int row, int lane) {
    for (final c in columns) {
      if (c.rowNo == row && c.laneNo == lane) return c;
    }
    return null;
  }

  /// Cọc đang chứa pallet [code] (đã ghép).
  StowageColumn? holding(String code) {
    for (final c in columns) {
      if (c.holds(code)) return c;
    }
    return null;
  }

  /// Cọc kế tiếp theo thứ tự plan (hàng → làn) chưa đạt điều kiện [done], tính sau [afterCode].
  StowageColumn? nextWhere(bool Function(StowageColumn c) done, {String? afterCode}) {
    final start = afterCode == null
        ? 0
        : columns.indexWhere((c) => c.code == afterCode) + 1;
    for (var i = 0; i < columns.length; i++) {
      final c = columns[(start + i) % columns.length];
      if (!done(c)) return c;
    }
    return null;
  }
}
