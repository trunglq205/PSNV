// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'router_provider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(appRouter)
final appRouterProvider = AppRouterProvider._();

final class AppRouterProvider
    extends $FunctionalProvider<AppRouter, AppRouter, AppRouter>
    with $Provider<AppRouter> {
  AppRouterProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'appRouterProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$appRouterHash();

  @$internal
  @override
  $ProviderElement<AppRouter> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  AppRouter create(Ref ref) {
    return appRouter(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(AppRouter value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<AppRouter>(value),
    );
  }
}

String _$appRouterHash() => r'fc1228daa214cc1ad475cfdeafc6db36a6a237b5';

/// Theo dõi vòng đời route — để màn pause/resume scan khi bị che/quay lại.

@ProviderFor(routeObserver)
final routeObserverProvider = RouteObserverProvider._();

/// Theo dõi vòng đời route — để màn pause/resume scan khi bị che/quay lại.

final class RouteObserverProvider
    extends
        $FunctionalProvider<
          RouteObserver<ModalRoute<void>>,
          RouteObserver<ModalRoute<void>>,
          RouteObserver<ModalRoute<void>>
        >
    with $Provider<RouteObserver<ModalRoute<void>>> {
  /// Theo dõi vòng đời route — để màn pause/resume scan khi bị che/quay lại.
  RouteObserverProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'routeObserverProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$routeObserverHash();

  @$internal
  @override
  $ProviderElement<RouteObserver<ModalRoute<void>>> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  RouteObserver<ModalRoute<void>> create(Ref ref) {
    return routeObserver(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(RouteObserver<ModalRoute<void>> value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<RouteObserver<ModalRoute<void>>>(
        value,
      ),
    );
  }
}

String _$routeObserverHash() => r'8a140576712c4c055d4a3133b12a4701081de63b';
