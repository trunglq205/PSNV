import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/router/app_route_paths.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/storage_suggestion.dart';
import 'package:swms_finish_goods/features/pallet/presentation/dialogs/storage_info_dialog.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/master_draft.dart';
import 'package:swms_finish_goods/features/pallet/presentation/utils/pallet_i18n.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/flow/pallet_flow_pallet_card.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/flow/pallet_flow_parts.dart';

/// Bước 2 dùng chung: thẻ pallet + chọn hành động + nhánh tương ứng.
///   - Nhiều hành động  -> hàng nút chọn.
///   - Có gợi ý vị trí  -> thẻ gợi ý (chỉ tham khảo, bắt buộc quét thật).
///   - Hành động cần quét (gán / chuyển / lưu kho) -> khung quét vị trí đích.
///   - Rời / out        -> chỉ nhắc xác nhận.
///
/// Gợi ý vị trí nay đến từ endpoint riêng `.../storage-suggestion` nên nhận qua
/// [suggestion] (AsyncValue) chứ không đọc `pallet.suggestedLocator` nữa —
/// nhờ vậy loading / lỗi của phần gợi ý không ảnh hưởng tới phần còn lại.
///
/// Các khối giao diện nhỏ (nhãn mục, hộp nhắc, nút chọn, mã đã quét) dùng
/// chung từ `pallet_flow_parts.dart` để các màn flow khác (Tách pallet…)
/// hiển thị đồng nhất.
class PalletFlowActionBody extends StatelessWidget {
  const PalletFlowActionBody({
    super.key,
    required this.pallet,
    required this.actions,
    required this.action,
    required this.scannedLocatorCode,
    required this.onActionChanged,
    required this.onClearLocator,
    this.suggestion = const AsyncValue.data(null),
    this.palletHeightCm,
    this.masterDraft,
    this.onRetrySuggestion,
    this.onStorageInfoSaved,
  });

  final Pallet pallet;

  /// Hành động khả dụng đã lọc theo màn.
  final List<PalletAction> actions;
  final PalletAction? action;
  final String? scannedLocatorCode;
  final ValueChanged<PalletAction> onActionChanged;
  final VoidCallback onClearLocator;

  /// Gợi ý vị trí lưu kho. `AsyncData(null)` = màn này không dùng gợi ý.
  final AsyncValue<StorageSuggestion?> suggestion;

  /// Chiều cao pallet đang áp dụng (cm), hiện trên thẻ gợi ý.
  final int? palletHeightCm;

  /// Khai báo master vừa nhập trong phiên — chỉ để chọn sẵn khi mở lại dialog.
  final MasterDraft? masterDraft;

  final VoidCallback? onRetrySuggestion;

  /// Người dùng vừa bổ sung chiều cao / master ở thẻ gợi ý.
  /// Wire vào notifier để gọi lại `.../storage-suggestion`.
  final ValueChanged<StorageInfoResult>? onStorageInfoSaved;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final data = suggestion.value;
    final locator = data?.suggestedLocator;
    final scanned = scannedLocatorCode;
    final matchesSuggestion =
        locator != null && scanned != null && scanned == locator.locatorCode;
    // null khi chưa chọn hành động, hoặc hành động không cần quét (rời/out).
    final scanLocatorKey = action?.scanLocatorKey;

    // Chỉ dựng khối gợi ý khi màn thực sự có dùng (storing): các màn khác
    // giữ nguyên `AsyncData(null)` nên không tốn chỗ.
    //
    // `actions.isEmpty` cũng ẩn: không lưu kho được thì gợi ý chỗ để chỉ làm
    // nhiễu, mà chỗ đó cũng không ai giữ. Notifier đã không gọi API trong
    // trường hợp này; điều kiện ở đây là chốt chặn cho dữ liệu còn sót.
    final showsSuggestionBlock =
        actions.isNotEmpty &&
        (suggestion.isLoading || data != null || suggestion.hasError);

    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          PalletFlowPalletCard(pallet: pallet),
          const SizedBox(height: AppDimens.md),

          // ── Hành động ──
          if (actions.isEmpty)
            PalletFlowHintBox(
              icon: Icons.block,
              tone: swms.warning,
              bg: swms.warningBg,
              text: LocaleKeys.pallet_flow_no_action_hint.tr(),
            )
          else if (actions.length > 1) ...[
            PalletFlowSectionLabel(LocaleKeys.pallet_flow_choose_action.tr()),
            const SizedBox(height: AppDimens.sm),
            Row(
              children: [
                for (final a in actions) ...[
                  Expanded(
                    child: _ActionButton(
                      action: a,
                      // Pallet đang TRONG KHO (server chỉ trả moveStoring cho
                      // pallet ở khu lưu trữ) mà lại có moveReceiving ⇒ đó là
                      // OUT KHO ra khu nhận hàng để giao FA, không phải xếp lại
                      // chỗ. Hai việc khác hẳn nhau mà nhãn mặc định của cả hai
                      // đều là "Chuyển" — bấm nhầm là ghi sổ đã giao hàng.
                      outOfStorage: a == PalletAction.moveReceiving &&
                          actions.contains(PalletAction.moveStoring),
                      selected: action == a,
                      onTap: () => onActionChanged(a),
                    ),
                  ),
                  if (a != actions.last) const SizedBox(width: AppDimens.sm),
                ],
              ],
            ),
            const SizedBox(height: AppDimens.md),
          ],

          // ── Gợi ý vị trí (chỉ màn Lưu kho) ──
          if (showsSuggestionBlock) ...[
            PalletFlowSectionLabel(
              LocaleKeys.pallet_flow_suggested_location.tr(),
            ),
            const SizedBox(height: AppDimens.sm),
            switch (suggestion) {
              AsyncLoading() => const _SuggestionSkeleton(),
              AsyncError() => _SuggestionError(onRetry: onRetrySuggestion),
              _ => _SuggestionCard(
                itemCode: pallet.displayModels,
                suggestion: data!,
                matched: matchesSuggestion,
                palletHeightCm: palletHeightCm,
                masterDraft: masterDraft,
                onStorageInfoSaved: onStorageInfoSaved,
              ),
            },
            const SizedBox(height: AppDimens.md),
          ],

          // ── Khung quét vị trí đích ──
          if (scanLocatorKey != null) ...[
            PalletFlowSectionLabel(scanLocatorKey.tr()),
            const SizedBox(height: AppDimens.sm),
            if (scanned == null)
              BarcodeScannerButton(
                scanningLabel: LocaleKeys.pallet_flow_scan_locator_label.tr(),
              )
            else
              PalletFlowScannedCode(
                label: LocaleKeys.pallet_flow_target_location.tr(),
                code: scanned,
                onClear: onClearLocator,
                clearTooltip: LocaleKeys.pallet_flow_rescan.tr(),
                // Có gợi ý mà quét khác -> nhắc, vẫn cho lưu.
                warning: (locator != null && !matchesSuggestion)
                    ? LocaleKeys.pallet_flow_mismatch_hint.tr()
                    : null,
              ),
          ],
        ],
      ),
    );
  }
}

/// Nút chọn hành động (Gán / Rời / Chuyển / Lưu kho / Vanning).
/// Chỉ map [PalletAction] -> icon + tông; giao diện dùng chung
/// [PalletFlowChoiceButton].
class _ActionButton extends StatelessWidget {
  const _ActionButton({
    required this.action,
    required this.selected,
    required this.onTap,
    this.outOfStorage = false,
  });

  final PalletAction action;
  final bool selected;
  final VoidCallback onTap;

  /// Hành động này là "out kho ra khu nhận hàng" chứ không phải chuyển vị trí
  /// thường — đổi nhãn và icon cho khỏi nhầm với nút Chuyển bên cạnh.
  final bool outOfStorage;

  @override
  Widget build(BuildContext context) {
    final icon = switch (action) {
      PalletAction.assign => Icons.add_location_alt_outlined,
      PalletAction.moveReceiving ||
      PalletAction.moveStoring ||
      PalletAction.moveVanning => Icons.swap_horiz,
      PalletAction.store => Icons.warehouse_outlined,
      PalletAction.vanning => Icons.local_shipping_outlined,
    };

    return PalletFlowChoiceButton(
      icon: outOfStorage ? Icons.local_shipping_outlined : icon,
      label: outOfStorage
          ? LocaleKeys.pallet_flow_action_out_to_receiving.tr()
          : action.labelKey.tr(),
      selected: selected,
      onTap: onTap,
    );
  }
}

/// Khung chờ khi đang gọi `.../storage-suggestion`.
class _SuggestionSkeleton extends StatelessWidget {
  const _SuggestionSkeleton();

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 18,
            height: 18,
            child: CircularProgressIndicator(strokeWidth: 2, color: swms.text4),
          ),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text(
              LocaleKeys.pallet_flow_suggestion_loading.tr(),
              style: AppTextStyles.caption.copyWith(color: swms.text3),
            ),
          ),
        ],
      ),
    );
  }
}

/// Gợi ý hỏng — KHÔNG chặn lưu kho, chỉ báo và cho thử lại.
class _SuggestionError extends StatelessWidget {
  const _SuggestionError({this.onRetry});

  final VoidCallback? onRetry;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.fromLTRB(
        AppDimens.md,
        AppDimens.sm,
        AppDimens.xs,
        AppDimens.sm,
      ),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Icon(Icons.cloud_off_outlined, size: 18, color: swms.text4),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text(
              LocaleKeys.pallet_flow_suggestion_error.tr(),
              style: AppTextStyles.caption.copyWith(color: swms.text3),
            ),
          ),
          if (onRetry != null)
            TextButton(
              onPressed: onRetry,
              child: Text(LocaleKeys.pallet_flow_suggestion_retry.tr()),
            ),
        ],
      ),
    );
  }
}

/// Thẻ gợi ý vị trí — CHỈ tham khảo, không có nút "dùng luôn" để tránh lưu nhầm.
///
/// Hai tông theo mockup:
///   - Đủ master (xanh)   : icon `map`, bấm thẻ -> mở bản đồ kho.
///   - Thiếu master (đỏ)  : icon `error_outline`, thêm nút ⓘ mở dialog bổ sung
///                          chiều cao pallet / cập nhật master.
///
/// "Thiếu master" nay suy từ `strategy` do server trả, không đoán qua areaCode:
/// server biết chính xác model có khai `suggest_area` hay không.
class _SuggestionCard extends StatelessWidget {
  const _SuggestionCard({
    required this.suggestion,
    required this.matched,
    required this.itemCode,
    this.palletHeightCm,
    this.masterDraft,
    this.onStorageInfoSaved,
  });

  final String itemCode;
  final StorageSuggestion suggestion;

  /// Vị trí đã quét trùng với gợi ý.
  final bool matched;

  final int? palletHeightCm;
  final MasterDraft? masterDraft;
  final ValueChanged<StorageInfoResult>? onStorageInfoSaved;

  SuggestedLocator? get _locator => suggestion.suggestedLocator;

  /// Cấu hình master hiện có của model, do server trả nguyên trạng.
  ModelMasterConfig? get _master => suggestion.master;

  /// Đã khai `suggest_area`. Đọc thẳng từ khối `master`, không suy qua
  /// `strategy` nữa: strategy chỉ cho biết KHU lấy từ đâu, nên model khai tầng
  /// mà chưa khai khu từng bị đọc nhầm thành chưa có master.
  bool get _hasMaster => _master?.hasArea ?? false;

  bool get _hasHeight => (palletHeightCm ?? 0) > 0;

  /// Đã có căn cứ chọn tầng. Dùng `master.rackRows` chứ KHÔNG dùng
  /// `suggestedRackRows`: từ khi server ưu tiên chiều cao trước master,
  /// `suggestedRackRows` có thể là kết quả của quy tắc chiều cao, đọc nó sẽ
  /// tưởng master đã khai tầng trong khi cột đó vẫn trống.
  bool get _hasRackRowBasis => _master?.hasArea ?? false;

  /// Tông cảnh báo CHỈ khi vừa thiếu master vừa chưa nhập chiều cao.
  /// Nhập chiều cao rồi thì server đã đủ căn cứ chọn tầng (≤70 giá lửng ·
  /// ≤135 tầng 2-3 · ≤155 tầng 1 · còn lại tầng 4), gợi ý dùng được — báo đỏ
  /// nữa chỉ làm thao tác viên chai với cảnh báo.
  bool get _needsMasterInfo => !_hasRackRowBasis && !_hasHeight;

  // Nút ⓘ LUÔN hiện, kể cả khi đã có master: nó là đường duy nhất để nhập /
  // sửa chiều cao. Có master mà chưa khai suggest_rack_row thì server vẫn rơi
  // về quy tắc chiều cao, nên chiều cao vẫn có tác dụng. Chỉ tab "Khai báo
  // master" bị ẩn — khai lại khu/tầng cho mã đã có master là thừa và dễ ghi đè
  // nhầm cấu hình đang đúng.

  /// `Khu lưu trữ · Tầng 2 · Cao 140cm · Last lot: A-03-03`
  String? get _subtitle {
    final loc = _locator;
    final parts = <String>[
      if (_needsMasterInfo)
        LocaleKeys.pallet_flow_missing_master.tr()
      else if (suggestion.suggestedAreaName?.isNotEmpty ?? false)
        suggestion.suggestedAreaName!
      else if (suggestion.suggestedAreaCode?.isNotEmpty ?? false)
        suggestion.suggestedAreaCode!,

      if (loc != null)
        if (loc.isShelf)
          LocaleKeys.pallet_flow_shelf.tr() +
              (loc.rackLevel?.isNotEmpty ?? false ? ' ${loc.rackLevel}' : '')
        else if (loc.rackRow != null)
          LocaleKeys.pallet_flow_rack_row.tr(args: ['${loc.rackRow}']),

      // Nhập rồi thì hiện luôn ở phụ đề — thao tác viên tự kiểm được mình
      // vừa gõ đúng số chưa, và biết gợi ý đang dựa trên chiều cao nào.
      if (_hasHeight)
        LocaleKeys.pallet_flow_pallet_height.tr(args: ['$palletHeightCm']),

      if (suggestion.lastLot != null)
        LocaleKeys.pallet_flow_last_lot_short.tr(
          args: [suggestion.lastLot!.locatorCode],
        ),
    ];
    return parts.isEmpty ? null : parts.join(' · ');
  }

  /// Bản nháp chỉ dùng được khi đúng model của gợi ý đang xem.
  MasterDraft? get _draft {
    final d = masterDraft;
    return (d != null && d.matches(suggestion.model)) ? d : null;
  }

  void _openStorageMap(BuildContext context) {
    final loc = _locator;
    if (loc == null) return;
    // Màn sơ đồ nhận ?locator=: tự chọn đúng bản đồ, căn giữa và nhấp nháy
    // tại kệ/ô đó; bấm vào kệ thì mặt cắt chọn sẵn ô đích.
    final locator = Uri.encodeQueryComponent(loc.locatorCode);
    context.router.pushPath('${AppRoutePaths.storageMap}?locator=$locator');
  }

  Future<void> _openStorageInfo(BuildContext context) async {
    final result = await showStorageInfoDialog(
      context,
      itemCode: itemCode,
      // Mở lại dialog thì vòng quay bắt đầu từ số đã nhập lần trước, không
      // nhảy về 120 — thao tác viên chỉnh 140 -> 150 chỉ quay 1 nấc.
      initialHeightCm: palletHeightCm,
      // Đã khai khu trong master -> chỉ còn tab nhập chiều cao.
      allowMasterMode: !_hasMaster,
      // Chọn sẵn đúng thứ vừa khai trong phiên. `matches` chặn trường hợp bản
      // nháp còn của model trước: chọn sẵn khu của model khác rồi để thao tác
      // viên bấm Xác nhận là ghi nhầm master, mà màn hình không có dấu hiệu gì.
      //
      // Không lấy `suggestedAreaCode` làm giá trị chọn sẵn: đó là khu của vị
      // trí server gợi ý (có thể suy từ last lot), không phải khu khai trong
      // master — và nó là code, không phải id. Khối `master` mới là chỗ đúng.
      //
      // rackRowOptions dùng mặc định [1, 2, 3, 4] — khớp RackRowRule.Min/Max.
      // Đổi số tầng ở server thì đổi cả mặc định trong showStorageInfoDialog.
      // Ưu tiên bản nháp trong phiên, không có thì lấy master server vừa trả —
      // nhờ vậy lần đầu mở đã chọn sẵn đúng thứ đang nằm trong DB.
      initialAreaId: _draft?.areaId ?? _master?.areaId,
      initialRackRows: _draft?.rackRows ?? _master?.rackRows ?? const [],
    );
    if (result != null) onStorageInfoSaved?.call(result);
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final radius = BorderRadius.circular(AppDimens.rCard);
    final loc = _locator;

    // Thiếu master thì đổi sang tông cảnh báo để thao tác viên biết cần bổ sung.
    final tone = _needsMasterInfo ? swms.danger : swms.primary;
    final bg = _needsMasterInfo
        ? swms.dangerBg
        : swms.primary.withValues(alpha: .08);
    final sub = _subtitle;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Material(
          color: bg,
          borderRadius: radius,
          child: InkWell(
            onTap: loc == null ? null : () => _openStorageMap(context),
            borderRadius: radius,
            child: Container(
              padding: const EdgeInsets.fromLTRB(
                14,
                AppDimens.sm,
                AppDimens.xs,
                AppDimens.sm,
              ),
              decoration: BoxDecoration(
                borderRadius: radius,
                border: Border.all(color: tone.withValues(alpha: .45)),
              ),
              child: Row(
                spacing: 10,
                children: [
                  Icon(
                    loc == null ? Icons.search_off : Icons.map_outlined,
                    size: 24,
                    color: tone,
                  ),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          // Hết chỗ trống: server vẫn trả 200 nhưng không có
                          // vị trí nào -> nói thẳng thay vì để thẻ trống.
                          loc?.locatorCode ??
                              LocaleKeys.pallet_flow_suggestion_none.tr(),
                          style: AppTextStyles.title.copyWith(
                            fontWeight: FontWeight.w800,
                            color: tone,
                            letterSpacing: .3,
                          ),
                        ),
                        if (sub != null) ...[
                          const SizedBox(height: 2),
                          Text(
                            sub,
                            style: AppTextStyles.caption.copyWith(
                              color: swms.text3,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  // Luôn hiện: đường duy nhất để nhập / sửa chiều cao pallet.
                  // IconButton nằm ngoài InkWell của thẻ nên tap không lan ra.
                  IconButton(
                    onPressed: () => _openStorageInfo(context),
                    icon: const Icon(Icons.info_outline, size: 22),
                    color: tone,
                    tooltip: LocaleKeys.pallet_flow_storage_info_title.tr(),
                    visualDensity: VisualDensity.compact,
                    padding: const EdgeInsets.all(6),
                    constraints: const BoxConstraints(),
                  ),
                  if (loc != null)
                    Icon(Icons.chevron_right, size: 22, color: swms.text4),
                ],
              ),
            ),
          ),
        ),

        // Cảnh báo mềm từ server (đã dịch sẵn theo Accept-Language):
        // lệch tầng, phải nới khu, thiếu chiều cao...
        for (final w in suggestion.warnings) ...[
          const SizedBox(height: AppDimens.xs),
          Row(
            children: [
              Icon(Icons.info_outline, size: 14, color: swms.warning),
              const SizedBox(width: AppDimens.xs),
              Expanded(
                child: Text(
                  w,
                  style: AppTextStyles.caption.copyWith(color: swms.warning),
                ),
              ),
            ],
          ),
        ],
      ],
    );
  }
}
