﻿namespace Swms.FinishGoods.API.Extensions
{
    public static class LocalizationExtensions

    {
        public static IServiceCollection AddAppLocalization(this IServiceCollection services, IConfiguration configuration)
            => services
                .AddLocalization()
                .Configure<RequestLocalizationOptions>(options =>
                {
                    var supportedCultures = new[] { "vi", "en", "ja", "zh" };

                    options.SetDefaultCulture("en")               
                           .AddSupportedCultures(supportedCultures)      
                           .AddSupportedUICultures(supportedCultures);  

                });
    }

}
