using Dapper;
using Swms.FinishGoods.API.Features.Foss.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.WeightSys.DataAccess;

public class WeightSysRepository : IWeightSysRepository
{
    private readonly IWeightSysConnectionFactory _weightFactory;

    public WeightSysRepository(IFossDbConnectionFactory factory, IWeightSysConnectionFactory weightFactory)
    {
        _weightFactory = weightFactory;
    }

    private static string ResolveWeightTableName(FossCategory category)
        => $"Weight{TableSuffix(category)}";

    private static string TableSuffix(FossCategory category)
        => category == FossCategory.Default
            ? string.Empty
            : $"_{category}";

    public async Task<IReadOnlyCollection<WeightDto>> GetSerialWeightAsync(
        FossCategory category,
        string model,
        List<string> serials)
    {
        var tableName = ResolveWeightTableName(category);

        var sql = $"""
        SELECT
            TMR_DATE            AS TmrDate,
            STR_PROCESS         AS Process,
            STR_PROCESS_FACTORY AS ProcessFactory,
            STR_SERIAL          AS Serial,
            QNT_BASE_PRODUCT    AS Weight
        FROM dbo.[{tableName}]
        WHERE (
                STR_PROCESS = @ProcessFactory
                OR STR_PROCESS_FACTORY = CONCAT(@ProcessFactory, '-V4')
              )
          AND STR_SERIAL IN @Serials;
        """;

        using var conn = _weightFactory.Create();

        var result = await conn.QueryAsync<WeightDto>(
            sql,
            new
            {
                ProcessFactory = model,
                Serials = serials
            });

        return result.ToList();
    }
}
