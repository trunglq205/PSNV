﻿using SWMS_WebTool.Models.PMD;

namespace SWMS_WebTool.ViewModels
{
    public class PMDReturnRecycleViewModel : TableViewModel<PMDReturnRecycleModel, PMDReturnRecycleFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, PMDReturnRecycleFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                TimeCreate = filter?.TimeCreate ?? DateTime.Now,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
