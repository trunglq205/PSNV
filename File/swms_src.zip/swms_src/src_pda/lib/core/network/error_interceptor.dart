import 'package:dio/dio.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';

class ErrorInterceptor extends Interceptor {
  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    final AppException mapped = switch (err.type) {
      DioExceptionType.connectionTimeout ||
      DioExceptionType.sendTimeout ||
      DioExceptionType.receiveTimeout => const TimeoutException(
        'Request timed out',
      ),
      DioExceptionType.connectionError => const NetworkException(
        'No internet connection',
      ),
      DioExceptionType.badResponse => _mapStatus(err.response),
      DioExceptionType.cancel => const UnknownException('Request cancelled'),
      _ => const UnknownException('Unexpected error'),
    };

    handler.reject(
      DioException(
        requestOptions: err.requestOptions,
        response: err.response,
        type: err.type,
        message: err.message,
        error: mapped,
      ),
    );
  }

  AppException _mapStatus(Response<dynamic>? response) {
    final code = response?.statusCode;
    final message = _extractMessage(response);

    if (code == null) {
      return ServerException(message ?? 'Request failed', statusCode: code);
    }

    return switch (code) {
      401 =>
        response?.requestOptions.path == '/api/auth/login'
            ? ServerException(message ?? 'Unauthorized')
            : UnauthorizedException(message ?? 'Unauthorized'),
      403 => ForbiddenException(message ?? 'Forbidden'),
      404 => NotFoundException(message ?? 'Resource not found'),
      >= 500 => ServerException(message ?? 'Server error', statusCode: code),
      int() => ServerException(message ?? 'Request failed', statusCode: code),
    };
  }

  /// Lấy message từ response.data theo cấu trúc:
  /// { status, title, details, traceId }
  String? _extractMessage(Response<dynamic>? response) {
    final data = response?.data;
    if (data is! Map) return null;

    final details = data['details'];
    if (details is String && details.trim().isNotEmpty) {
      return details;
    }

    final title = data['title'];
    if (title is String && title.trim().isNotEmpty) {
      return title;
    }

    return null;
  }
}
