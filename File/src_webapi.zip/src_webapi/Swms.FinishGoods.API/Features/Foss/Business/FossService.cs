using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Features.Foss.Api;
using Swms.FinishGoods.API.Features.Foss.DataAccess;

namespace Swms.FinishGoods.API.Features.Foss.Business;

public class FossService : IFossService
{
    private readonly IFossPalletRepository _repo;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public FossService(
        IFossPalletRepository repo,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _localizer = localizer;
    }

    public async Task<List<FossPalletItemResponse>> GetPalletByBarcodeAsync(string barcode)
    {
        if (string.IsNullOrWhiteSpace(barcode))
            throw new ArgumentException(_localizer["Foss.BarcodeRequired"]);

        var trimmed = barcode.Trim();

        var category = FossCategoryExtensions.FromBarcodePrefix(trimmed);
        if (category is null)
            throw new NotFoundException(
                _localizer["Foss.CategoryNotFound", trimmed[..Math.Min(3, trimmed.Length)]]);

        var rows = await _repo.GetByBarcodeAsync(category.Value, trimmed);

        if (rows.Count == 0)
            throw new NotFoundException(_localizer["Foss.PalletNotFound", barcode]);

        return rows.Select(FossPalletItemResponse.From).ToList();
    }

    public async Task<List<string>> GetTodayPalletsAsync()
    {
        var pallets = await _repo.GetTodayPalletsAsync();

        return pallets.ToList();
    }

    /// <summary>Số thùng / serial / mốc shrink cuối theo pallet — 1 câu nhẹ cho mỗi bảng category.</summary>
    public async Task<Dictionary<string, FossPalletSummary>> GetPalletSummariesAsync(
        IReadOnlyCollection<string> barcodes)
    {
        var map = new Dictionary<string, FossPalletSummary>(StringComparer.OrdinalIgnoreCase);

        var groups = barcodes
            .Select(b => (b ?? "").Trim())
            .Where(b => b.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .GroupBy(FossCategoryExtensions.FromBarcodePrefix)
            .Where(g => g.Key is not null)
            .ToList();

        var results = await Task.WhenAll(
            groups.Select(g => _repo.GetPalletSummariesAsync(g.Key!.Value, g.ToList())));

        foreach (var row in results.SelectMany(r => r))
            map.TryAdd(row.PalletNo, row);

        return map;
    }
}
