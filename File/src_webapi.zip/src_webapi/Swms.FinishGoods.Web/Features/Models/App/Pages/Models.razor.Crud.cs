using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Shared.App.Toast;

namespace Swms.FinishGoods.Web.Features.Models.App.Pages;

// Cum thao tac voi 1 model: xem chi tiet, them/sua (modal),
// bat/tat trang thai, xac nhan xoa. (Localizer `L` khai bao o Models.razor.cs)
//
// Phan quan ly danh muc (category) da chuyen sang Models.razor.Categories.cs.
public partial class Models
{
    // ── Detail ───────────────────────────────────────────────
    private AppModel? _detailModel;
    private void OpenDetail(AppModel m) => _detailModel = m;

    // ── Modal them / sua ─────────────────────────────────────
    private bool _modalOpen;
    private bool _isEdit;
    private AppModel _form = new();
    private int _editingId;
    private string? _codeServerError;

    private void OpenCreate()
    {
        _isEdit = false;
        _editingId = 0;
        _codeServerError = null;
        _form = new AppModel
        {
            IsActive = true,
            GTIN = "",
            CategoryCode = _categoryOptions.FirstOrDefault()?.Code ?? 0,
            SuggestAreaId = null,
            SuggestRackRow = new(),
        };
        _modalOpen = true;
    }

    private void OpenEdit(AppModel m)
    {
        _isEdit = true;
        _editingId = m.Id;
        _codeServerError = null;
        _form = m.Clone();
        _modalOpen = true;
    }

    private void CloseModal()
    {
        _modalOpen = false;
        _codeServerError = null;
    }

    private async Task OnFormSave(AppModel form)
    {
        if (_isEdit)
        {
            var request = new UpdateModelRequest
            {
                CategoryId = form.CategoryCode,
                GTIN = string.IsNullOrWhiteSpace(form.GTIN) ? null : form.GTIN.Trim(),
                Origin = OriginRule.Normalize(form.Origin),
                Length = form.Length,
                Width = form.Width,
                Height = form.Height,
                StandardPacking = form.StandardPacking,
                LayerLimit = form.LayerLimit,
                LayerCount = form.LayerCount,
                StackingLength = form.StackingLength,
                StackingWidth = form.StackingWidth,
                SuggestAreaId = form.SuggestAreaId,
                SuggestRackRow = NullIfEmpty(form.SuggestRackRow),
                IsActive = form.IsActive,
            };
            var result = await ModelBusiness.UpdateAsync(_editingId, request);
            if (!result.IsSuccess)
            {
                Toast.Error(result.ErrorMessage ?? L["Models.Toast.SaveFailed"]);
                return;
            }
            Toast.Success(L["Models.Toast.Saved"]);
        }
        else
        {
            var request = new CreateModelRequest
            {
                Code = form.Code.Trim(),
                GTIN = string.IsNullOrWhiteSpace(form.GTIN) ? null : form.GTIN.Trim(),
                Origin = OriginRule.Normalize(form.Origin),
                CategoryId = form.CategoryCode,
                Length = form.Length,
                Width = form.Width,
                Height = form.Height,
                StandardPacking = form.StandardPacking,
                LayerLimit = form.LayerLimit,
                LayerCount = form.LayerCount,
                StackingLength = form.StackingLength,
                StackingWidth = form.StackingWidth,
                SuggestAreaId = form.SuggestAreaId,
                SuggestRackRow = NullIfEmpty(form.SuggestRackRow),
                IsActive = form.IsActive,
            };
            var result = await ModelBusiness.CreateAsync(request);
            if (!result.IsSuccess)
            {
                if ((result.ErrorMessage ?? "").Contains("code", StringComparison.OrdinalIgnoreCase))
                    _codeServerError = result.ErrorMessage;
                Toast.Error(result.ErrorMessage ?? L["Models.Toast.CreateFailed"]);
                StateHasChanged();
                return;
            }
            Toast.Success(L["Models.Toast.Created"]);
        }

        CloseModal();
        await ReloadAsync();
    }

    // Danh sach rong -> gui null cho API (nghia la "xoa goi y"), tranh gui mang []
    // roi backend phai tu doan y dinh.
    private static List<int>? NullIfEmpty(List<int>? rows)
        => rows is null || rows.Count == 0 ? null : rows.Distinct().OrderBy(x => x).ToList();

    private void OnDetailEdit(AppModel m)
    {
        _detailModel = null;
        OpenEdit(m);
    }

    // ── Confirm xoa ──────────────────────────────────────────
    private AppModel? _confirmTarget;
    private void OpenDeleteConfirm(AppModel m) => _confirmTarget = m;

    private async Task OnDeleteConfirmed(AppModel target)
    {
        var result = await ModelBusiness.DeleteAsync(target.Id);
        _confirmTarget = null;
        if (!result.IsSuccess)
        {
            Toast.Error(result.ErrorMessage ?? L["Models.Toast.DeleteFailed"]);
            return;
        }
        Toast.Success(L["Models.Toast.Deleted", target.Code]);
        await ReloadAsync();
    }
}
