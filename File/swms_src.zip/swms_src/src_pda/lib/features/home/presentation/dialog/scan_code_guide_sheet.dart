import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';

/// Sheet hướng dẫn quét. Quét được mã → đóng sheet và TRẢ VỀ mã đó;
/// Home tự phân loại + điều hướng (một chỗ xử lý duy nhất).
///
/// Trả `null` khi người dùng đóng sheet mà không quét.
Future<String?> showScanCodeGuideSheet(BuildContext context) {
  return showModalBottomSheet<String>(
    context: context,
    isScrollControlled: true,
    backgroundColor: Colors.transparent,
    barrierColor: Colors.black54,
    builder: (_) => const _ScanCodeGuideSheet(),
  );
}

class _ScanCodeGuideSheet extends ConsumerStatefulWidget {
  const _ScanCodeGuideSheet();

  @override
  ConsumerState<_ScanCodeGuideSheet> createState() =>
      _ScanCodeGuideSheetState();
}

class _ScanCodeGuideSheetState extends ConsumerState<_ScanCodeGuideSheet> {
  StreamSubscription<String>? _sub;
  bool _done = false;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  // Nghe scanStream ngay trong sheet vì listener của Home bị ngắt khi sheet mở.
  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Sheet đã đóng trong lúc chờ → không gắn listener (tránh rò).
    if (!mounted) return;
    _sub = pda.scanStream.listen(_onScan);
  }

  void _onScan(String raw) {
    final code = raw.trim();
    if (code.isEmpty || _done || !mounted) return;
    _done = true; // quét dồn 2 lần chỉ pop 1 lần
    Navigator.of(context).pop(code);
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final swms = context.swms;
    final mq = MediaQuery.of(context);

    return Container(
      constraints: BoxConstraints(maxHeight: mq.size.height * 0.90),
      decoration: BoxDecoration(
        color: cs.surface,
        borderRadius: const BorderRadius.vertical(top: Radius.circular(20)),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // ── Handle ────────────────────────────────────────────────────────
          Container(
            width: 36,
            height: 4,
            margin: const EdgeInsets.only(top: 10, bottom: 4),
            decoration: BoxDecoration(
              color: cs.onSurface.withValues(alpha: 0.12),
              borderRadius: BorderRadius.circular(2),
            ),
          ),

          // ── Header ────────────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.fromLTRB(
              AppDimens.md,
              AppDimens.sm,
              AppDimens.sm,
              0,
            ),
            child: Row(
              children: [
                Container(
                  width: 40,
                  height: 40,
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(11),
                    gradient: const LinearGradient(
                      begin: Alignment.topLeft,
                      end: Alignment.bottomRight,
                      colors: [Color(0xFF42A5F5), AppColors.primary],
                    ),
                  ),
                  child: const Icon(
                    Icons.barcode_reader,
                    color: Colors.white,
                    size: 20,
                  ),
                ),
                const SizedBox(width: AppDimens.sm + AppDimens.xs),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        LocaleKeys.scan_guide_title.tr(),
                        style: AppTextStyles.title.copyWith(color: swms.text1),
                      ),
                      const SizedBox(height: 2),
                      Text(
                        LocaleKeys.scan_guide_subtitle.tr(),
                        style: AppTextStyles.caption.copyWith(
                          color: swms.text3,
                        ),
                      ),
                    ],
                  ),
                ),
                IconButton(
                  onPressed: () => Navigator.of(context).pop(),
                  icon: Icon(Icons.close_rounded, size: 18, color: swms.text2),
                ),
              ],
            ),
          ),

          const SizedBox(height: AppDimens.sm),

          // ── Scanner minh hoạ ──────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppDimens.md),
            child: BarcodeScannerButton(
              scanningLabel: LocaleKeys.scan_guide_scanner_hint.tr(),
            ),
          ),

          const SizedBox(height: AppDimens.md),

          // ── Divider label ─────────────────────────────────────────────────
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: AppDimens.md),
            child: Row(
              children: [
                Expanded(child: Divider(color: swms.border, height: 1)),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: AppDimens.sm),
                  child: Text(
                    LocaleKeys.scan_guide_supported_count.tr(),
                    style: AppTextStyles.caption.copyWith(color: swms.text3),
                  ),
                ),
                Expanded(child: Divider(color: swms.border, height: 1)),
              ],
            ),
          ),

          const SizedBox(height: AppDimens.sm),

          // ── Grid 2 cột ────────────────────────────────────────────────────
          Flexible(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(
                AppDimens.md,
                0,
                AppDimens.md,
                AppDimens.lg,
              ),
              child: GridView.count(
                crossAxisCount: 2,
                crossAxisSpacing: AppDimens.sm,
                mainAxisSpacing: AppDimens.sm,
                childAspectRatio: 3,
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                children: _codeTypes()
                    .map((type) => _CodeTypeCard(type: type))
                    .toList(),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Card từng loại mã
// ─────────────────────────────────────────────────────────────────────────────

class _CodeTypeCard extends StatelessWidget {
  const _CodeTypeCard({required this.type});

  final _CodeType type;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.sm,
        vertical: AppDimens.sm,
      ),
      child: Row(
        children: [
          Container(
            width: 32,
            height: 32,
            decoration: BoxDecoration(
              color: type.iconBg,
              borderRadius: BorderRadius.circular(9),
            ),
            child: Icon(type.icon, color: type.iconColor, size: 18),
          ),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  type.label,
                  style: AppTextStyles.label.copyWith(color: swms.text1),
                  overflow: TextOverflow.ellipsis,
                ),
                const SizedBox(height: 2),
                Text(
                  type.example,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 8,
                    color: AppColors.primary,
                    letterSpacing: 0.6,
                  ),
                  overflow: TextOverflow.ellipsis,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Data — label lấy từ locale, example là mã kỹ thuật (không dịch)
// ─────────────────────────────────────────────────────────────────────────────

class _CodeType {
  final String label;
  final String example;
  final IconData icon;
  final Color iconColor;
  final Color iconBg;

  const _CodeType({
    required this.label,
    required this.example,
    required this.icon,
    required this.iconColor,
    required this.iconBg,
  });
}

List<_CodeType> _codeTypes() => [
  _CodeType(
    label: LocaleKeys.scan_guide_type_pallet.tr(),
    example: 'PLT-RECV-101A',
    icon: Icons.view_week_outlined,
    iconColor: const Color(0xFF00838F),
    iconBg: const Color(0x1500838F),
  ),
  _CodeType(
    label: LocaleKeys.scan_guide_type_box.tr(),
    example: 'BOX-LOT0507-FOAM-007',
    icon: Icons.inventory_2_outlined,
    iconColor: const Color(0xFF6A1B9A),
    iconBg: const Color(0x156A1B9A),
  ),
  _CodeType(
    label: LocaleKeys.scan_guide_type_serial.tr(),
    example: 'SN-PNL43-2026-A0119',
    icon: Icons.qr_code_2_rounded,
    iconColor: const Color(0xFF9A3412),
    iconBg: const Color(0x159A3412),
  ),
  _CodeType(
    label: LocaleKeys.scan_guide_type_staging.tr(),
    example: 'P001',
    icon: Icons.dashboard_outlined,
    iconColor: const Color(0xFFE65100),
    iconBg: const Color(0x15E65100),
  ),
  _CodeType(
    label: LocaleKeys.scan_guide_type_location.tr(),
    example: 'A-03-02-1',
    icon: Icons.grid_view_rounded,
    iconColor: const Color(0xFF2E7D32),
    iconBg: const Color(0x152E7D32),
  ),
  _CodeType(
    label: LocaleKeys.scan_guide_type_dock.tr(),
    example: 'S-DOCK-12',
    icon: Icons.local_shipping_outlined,
    iconColor: const Color(0xFF1565C0),
    iconBg: const Color(0x151565C0),
  ),
];
