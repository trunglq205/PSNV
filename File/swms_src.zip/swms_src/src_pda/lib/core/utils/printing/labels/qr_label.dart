import 'package:swms_finish_goods/core/utils/printing/labels/label.dart';
import 'package:swms_finish_goods/core/utils/printing/sato/sbpl.dart';
import 'package:swms_finish_goods/core/utils/printing/tspl/tspl.dart';

/// Tem 50×50 mm: QR bên phải + 1 dòng chữ dọc bên trái + badge tuỳ chọn.
///
/// Dùng chung cho:
/// - Tem pallet: QR = chữ = Lot No ([QrLabelData.pallet]).
/// - In lại tem box: QR = payload của box, chữ = Box No ([QrLabelData.box]).
///
/// Payload box dài hơn Lot No nhiều ⇒ QR lên version cao hơn. Cỡ module
/// (cell) tự giảm theo độ dài [qr] để QR luôn nằm gọn trong khổ tem.
class QrLabelData extends Label {
  const QrLabelData({required this.qr, required this.caption, this.badge});

  /// Tem pallet. [badge] để in ký hiệu loại hàng đặc biệt (RW / RB).
  const QrLabelData.pallet(String lotNo, {this.badge})
    : qr = lotNo,
      caption = lotNo;

  const QrLabelData.box({required String payload, required String boxNo})
    : qr = payload,
      caption = boxNo,
      badge = null;

  /// Nội dung QR — PHẢI giữ nguyên từng ký tự để quét lại ra đúng đối tượng.
  ///
  /// Với Pallet ID, đây LUÔN là 12 ký tự chuẩn và KHÔNG được nối thêm gì:
  /// `CreateLotRequest.LotNo` bên API validate `^\d{12}$`, nên một QR có đuôi
  /// sẽ bị chính server từ chối ở mọi màn quét.
  final String qr;

  /// Chữ dọc bên trái (chỉ để người đọc).
  final String caption;

  /// Ký hiệu to in ở khoảng trống dưới QR — `RW` / `RB` cho hàng rework /
  /// refurbish, `null` với hàng thường.
  ///
  /// Tách khỏi [caption] thay vì nối `-RW` vào cuối chuỗi ID vì hai lý do:
  /// mục đích của nó là nhận ra loại hàng khi ĐỨNG XA, mà 2 ký tự nhỏ ở cuối
  /// một chuỗi dọc 12 ký tự thì phải lại gần mới đọc được; và chuỗi caption
  /// 12 ký tự font "4" đã dài 288 dot tính từ y=40, nối thêm 3 ký tự là hết
  /// đúng ở y=400 — sát mép tem, lệch giấy một chút là cụt chữ.
  ///
  /// Giữ ngắn (1–3 ký tự). Dài hơn sẽ tràn khỏi ô badge.
  final String? badge;

  /// Ký hiệu tem theo loại hàng đặc biệt của pallet.
  ///
  /// Nhận CÙNG từ vựng của `wms.pallets.disposition` và
  /// `wms.return_instructions.goods_type`, nên dùng được cả lúc tạo pallet
  /// (biết `goodsType` từ phiếu) lẫn lúc in lại tem (biết `disposition` từ
  /// pallet). Hàng thường / giá trị lạ → `null`, tem in như cũ.
  ///
  /// ⚠ GIỮ KHỚP ký hiệu với bản đồ kho ở CẢ HAI app — PDA
  /// `rack_elevation_sheet.dart` và web `RackElevation.DispCode`. Người trong
  /// kho đọc tem rồi đối chiếu bản đồ; ba chỗ ghi khác nhau là họ phải dịch
  /// trong đầu. Đổi ở đây thì đổi cả hai chỗ kia.
  static String? badgeForDisposition(String? disposition) =>
      switch (disposition) {
        'rework' => 'RW',
        'refurbish' => 'RB',
        _ => null,
      };

  /// Số module/cạnh của QR mức ECC L, byte mode, theo độ dài payload:
  /// v1 ≤17 · v2 ≤32 · v3 ≤53 · v4 ≤78 · v5 ≤106 · v6 ≤134 ký tự.
  int get _modules {
    final n = qr.length;
    if (n <= 17) return 21;
    if (n <= 32) return 25;
    if (n <= 53) return 29;
    if (n <= 78) return 33;
    if (n <= 106) return 37;
    return 41;
  }

  /// Chọn cell sao cho cạnh QR không vượt [maxDots], trần [maxCell].
  int _cellFor(int maxDots, int maxCell) {
    final cell = maxDots ~/ _modules;
    return cell.clamp(1, maxCell);
  }

  // ═══ SBPL ════════════════════════════════════════════════════════════════

  /// QR đặt ở H0084, khổ H0400 ⇒ còn ~300 dot. Lot No (v1) giữ nguyên
  /// size 10 như template gốc.
  String get _sbplQrSize => _cellFor(300, 10).toString().padLeft(2, '0');

  /// Thứ tự PHẢI khớp với thứ tự `%s` xuất hiện trong [_sbplBody].
  List<String> get _sbplValues => [
    _sbplQrSize, // 1: 2D30,L,<size>,1,0
    ...qrPair(qr), // 2-3: DN<len>,<data> — H0084 V00064
    caption, // 4: H0044 V00320
  ];

  /// Khối badge SBPL, nối sau thân tem. Dùng ĐÚNG khuôn lệnh của caption
  /// (đã in thật, biết chạy được), chỉ đổi vị trí và cỡ chữ.
  ///
  /// ⚠ Toạ độ [_sbplBadgeH] / [_sbplBadgeV] là ƯỚC theo khổ V00400 H0400 và
  /// vị trí QR (H0084 V00064) — CHƯA in thử. In tem đầu tiên rồi căn lại hai
  /// hằng này nếu badge lệch; không phải sửa chỗ nào khác.
  static const _sbplBadgeH = '0240';
  static const _sbplBadgeV = '00300';
  static const _sbplBadgeFont = '080,084';

  String get _sbplBadge {
    final b = badge;
    if (b == null || b.isEmpty) return '';
    return '\x1B%0\x1BH$_sbplBadgeH\x1BV$_sbplBadgeV'
        '\x1BP02\x1BRH0,SATOSANS.ttf,1,$_sbplBadgeFont,$b';
  }

  @override
  String get sbplSetup => _sbplSetup;

  @override
  String toSbpl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    return buildSbpl(_sbplBody, _sbplValues) +
        _sbplBadge +
        Sbpl.quantity(copies) +
        Sbpl.end +
        Sbpl.etx;
  }

  // Block 1 — cấu hình khổ tem 50×50 (V00400 H0400), gửi một lần mỗi phiên.
  static const _sbplSetup =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00400H0400\x1BZ';

  // Block 2 — nội dung nhãn, 4 chỗ `%s`. Template gốc có size QR cố định
  // `L,10,1` — đổi thành `%s` để co theo payload. Đã CẮT đuôi
  // `ESC Q1 ESC Z ETX`: [toSbpl] tự sinh để đổi được số bản in.
  static const _sbplBody =
      '\x02\x1BA\x1BA3V+00000H+0000\x1BCS4\x1B#F5\x1BA1V00400H0400\x1BZ\x03\x02\x1BA\x1BPS\x1BW'
      'KNewLabel\x1B%0\x1BH0084\x1BV00064\x1B2D30,L,%s,1,0\x1BDN%s,%s\x1B%0\x1BH0044\x1BV00320'
      '\x1BP02\x1BRH0,SATOSANS.ttf,1,042,044,%s';

  // ═══ TSPL ════════════════════════════════════════════════════════════════
  //
  // CHƯA in thử trên MJ8001 — toạ độ ước từ bản SBPL, căn lại bằng các hằng
  // bên dưới. Khổ 51×50 mm = 408×400 dot (203 dpi).
  //
  // Text rotation 90: điểm (x,y) là góc trên-trái TRƯỚC khi xoay ⇒ chữ chạy
  // xuống dưới theo y, thân chữ lấn sang TRÁI của x. Nên x là mép PHẢI
  // của cột chữ.

  static const _qrX = 150;
  static const _qrY = 95;

  /// Chỗ trống cho QR: từ x=150 tới mép phải còn ~250 dot. Lot No (v1,
  /// 21 module) giữ cell 10 = 210 dot như trước.
  static const _qrMaxDots = 250;
  static const _qrMaxCell = 10;

  /// Font "4" = 24×32 dot/ký tự ⇒ 12 ký tự dài 288 dot theo trục y.
  static const _captionX = 80;
  static const _captionY = 40;
  static const _captionFont = '4';

  // ── Badge RW / RB ───────────────────────────────────────────────
  //
  // Chỗ trống dưới QR: QR cao nhất 210 dot từ y=95 ⇒ hết ở y=305, còn dải
  // y 310..400. Badge font "4" (24×32) nhân 2 = 48×64 dot/ký tự:
  //   2 ký tự  →  96 dot ngang, 64 dot dọc
  //   x 230..326 (khổ 408)  ·  y 322..386 (khổ 400)
  // Khung bao ngoài 214..342 × 310..398 — vẫn trong tem, không chạm QR và
  // không chạm cột caption (thân chữ caption nằm quanh x 48..80).
  static const _badgeX = 230;
  static const _badgeY = 322;
  static const _badgeFont = '4';
  static const _badgeMul = 2;

  static const _badgeBoxX1 = 214;
  static const _badgeBoxY1 = 310;
  static const _badgeBoxX2 = 342;
  static const _badgeBoxY2 = 398;
  static const _badgeBoxThickness = 4;

  @override
  List<String> get tsplSetup => _tsplSetup;

  static const _tsplSetup = [
    'SIZE 51 mm,50 mm',
    'GAP 0,0',
    'DIRECTION 1,0',
    'REFERENCE 0,0',
    'DENSITY 8',
    'SPEED 4',
  ];

  @override
  List<String> toTspl({int copies = 1}) {
    if (copies < 1) throw ArgumentError.value(copies, 'copies', 'phải >= 1');
    final cell = _cellFor(_qrMaxDots, _qrMaxCell);
    final b = badge;
    return [
      Tspl.cls,
      Tspl.qrcode(_qrX, _qrY, 'L', cell, 'A', 0, qr),
      // In 2 lần lệch 1 dot = giả đậm (font bitmap không có bold).
      Tspl.text(_captionX, _captionY, _captionFont, 90, 1, 1, caption),
      Tspl.text(_captionX, _captionY + 1, _captionFont, 90, 1, 1, caption),
      if (b != null && b.isNotEmpty) ...[
        Tspl.box(
          _badgeBoxX1,
          _badgeBoxY1,
          _badgeBoxX2,
          _badgeBoxY2,
          _badgeBoxThickness,
        ),
        Tspl.text(_badgeX, _badgeY, _badgeFont, 0, _badgeMul, _badgeMul, b),
        Tspl.text(_badgeX + 1, _badgeY, _badgeFont, 0, _badgeMul, _badgeMul, b),
      ],
      Tspl.print(copies),
    ];
  }
}
