﻿using Swms.FinishGoods.API.Features.TempLocMap.Business;
using Swms.FinishGoods.API.Features.TempLocMap.DataAccess;

namespace Swms.FinishGoods.API.Features.TempLocMap;

public static class TempLocMapModule
{
    public static IServiceCollection AddTempLocMapFeature(this IServiceCollection services)
    {
        services.AddScoped<ITempLocMapService, TempLocMapService>();
        services.AddScoped<ITempLocMapRepository, TempLocMapRepository>();
        return services;
    }
}