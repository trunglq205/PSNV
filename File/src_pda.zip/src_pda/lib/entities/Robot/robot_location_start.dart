class RobotLocationStart{
  RobotLocationStart({required this.Qrcode, required this.IsUgent});
  final String Qrcode;
  final bool IsUgent;
}