using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Features.Models.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.Models.Business;

public class ModelBusiness : BaseBusiness, IModelBusiness
{
    private readonly IModelApi _api;

    public ModelBusiness(IModelApi api, ILogger<ModelBusiness> logger, ErrorHandler errorHandler) : base(logger, errorHandler)
    {
        _api = api;
    }

    public Task<Result<PagedResult<ModelDto>>> GetPagedAsync(ModelQuery query)
        => ExecuteAsync(() => _api.GetAllAsync(query));

    public Task<Result<ModelDto>> GetByIdAsync(int id)
        => ExecuteAsync(() => _api.GetByIdAsync(id));

    public Task<Result<ModelDto>> CreateAsync(CreateModelRequest request)
        => ExecuteAsync(() => _api.CreateAsync(request));

    public Task<Result<List<ModelDto>>> BulkCreateAsync(IReadOnlyList<CreateModelRequest> request)
        => ExecuteAsync(() => _api.BulkCreateAsync(request));

    public Task<Result<BulkUpsertResult>> BulkUpsertAsync(IReadOnlyList<UpsertModelRequest> items)
        => ExecuteAsync(() => _api.BulkUpsertAsync(items));

    public Task<Result> UpdateAsync(int id, UpdateModelRequest request)
        => ExecuteAsync(() => _api.UpdateAsync(id, request));

    public Task<Result> DeleteAsync(int id)
        => ExecuteAsync(() => _api.DeleteAsync(id));

    // ── Category ────────────────────────────────────────────────────────────

    public Task<Result<List<CategoryDto>>> GetCategoriesAsync(CategoryQuery? query = null)
        => ExecuteAsync(() => _api.GetCategoriesAsync(query ?? new CategoryQuery()));

    public Task<Result<CategoryDto>> CreateCategoryAsync(CreateCategoryRequest request)
        => ExecuteAsync(() => _api.CreateCategoryAsync(request));

    public Task<Result> UpdateCategoryAsync(int code, UpdateCategoryRequest request)
        => ExecuteAsync(() => _api.UpdateCategoryAsync(code, request));

    public Task<Result> DeleteCategoryAsync(int code)
        => ExecuteAsync(() => _api.DeleteCategoryAsync(code));

    // ── Warehouse area ──────────────────────────────────────────────────────

    public Task<Result<List<WarehouseAreaDto>>> GetWarehouseAreasAsync()
        => ExecuteAsync(() => _api.GetWarehouseAreasAsync());
}
