using Swms.FinishGoods.API.Features.Foss.PalletSync.Api;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.StockEvents.Business;

namespace Swms.FinishGoods.API.Features.Foss.PalletSync.Business
{
    /// <summary>
    /// Ghi dữ liệu Foss vào pallet SWMS: tạo pallet, bổ sung thùng / serial, đồng bộ OQC.
    /// Bản có <c>PalletInclude</c> phục vụ API (trả chi tiết pallet); bản có
    /// <c>IntegrationSyncContext</c> phục vụ job nền (không dựng response, không ném lỗi nghiệp vụ).
    /// </summary>
    public interface IPalletFossSyncService
    {
        // ── API (PDA / Web) ──

        /// <summary>
        /// Tạo lot từ Foss theo mã quét (idempotent: lot đã có thì bổ sung thùng còn thiếu rồi trả về).
        /// Tách khỏi GET vì đây là thao tác ghi.
        /// </summary>
        Task<PalletDetailResponse> CreateFromFossAsync(string lotNo, PalletInclude include);

        /// <summary>Bổ sung thùng / serial còn thiếu từ Foss, báo rõ lý do từng thùng bị bỏ qua.</summary>
        Task<FossTopUpResponse> TopUpFromFossAsync(string lotNo, PalletInclude include);

        /// <summary>
        /// Đồng bộ OQC: ghi boxes.oqc_status + pallets.inspection_status.
        /// Thùng payload "Card_ID=..." lấy từ part_cards, còn lại lấy từ Foss.
        /// Lot box_count không có thùng -> không đổi gì.
        /// </summary>
        Task<PalletDetailResponse> SyncOqcStatusAsync(string lotNo, PalletInclude include);

        // ── Job nền ──

        /// <summary>Tạo pallet nếu SWMS chưa có. True = vừa tạo mới.</summary>
        Task<bool> TryCreateFromFossAsync(string lotNo, IntegrationSyncContext sync);

        /// <summary>Bổ sung thùng; pallet không phù hợp thì trả None thay vì ném lỗi.</summary>
        Task<FossTopUpResult> TopUpFromFossAsync(string lotNo, IntegrationSyncContext sync);

        /// <summary>Đồng bộ OQC không dựng response. True = có thay đổi.</summary>
        Task<bool> SyncOqcQuietAsync(string lotNo, IntegrationSyncContext sync);
    }
}
