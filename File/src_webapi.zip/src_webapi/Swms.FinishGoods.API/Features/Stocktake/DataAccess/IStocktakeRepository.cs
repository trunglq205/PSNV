namespace Swms.FinishGoods.API.Features.Stocktake.DataAccess;

public interface IStocktakeRepository
{
    Task<IReadOnlyList<CountSummary>> GetCountsAsync(string? type, string? status, DateTime? from, DateTime? to);
    Task<CountDetail?> GetCountAsync(long id);
    /// <summary>Tạo phiếu + snapshot lines theo loại (morning/monthly). Trả (id, docNo, lineCount).</summary>
    Task<(int LocatorCount, int LineCount)> PreviewAsync(string type, IReadOnlyList<string>? areaCodes);
    Task<CreateCountResult> CreateAsync(string type, IReadOnlyList<string>? areaCodes, string? description, long? userId);
    /// <summary>Chỉ ghi ghi chú của 1 dòng; trả false nếu phiếu đã đóng.</summary>
    Task<bool> SetNoteAsync(long lineId, string? note, long? userId);

    Task SetCountAsync(long lineId, int qtyCount, string? note, int? boxCountCounted, long? userId);
    Task CloseAsync(long id, long? userId);

    /// <summary>Danh sách mã bản đồ lưu kho (map_type = storing).</summary>
    Task<IReadOnlyList<string>> GetStoringAreaCodesAsync();
    Task<AddFoundResult> AddFoundAsync(long countId, long locatorId, string palletCode, long? userId);
}
