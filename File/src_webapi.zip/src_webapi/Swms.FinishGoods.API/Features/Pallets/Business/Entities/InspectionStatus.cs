namespace Swms.FinishGoods.API.Features.Pallets.Business.Entities
{
    public static class InspectionStatus
    {
        public const string NotInspected = "not_inspected";
        public const string UnderInspection = "under_inspection";
        public const string PendingResult = "pending_result";
        public const string Pass = "pass";
        public const string Ng = "ng";
        public const string InspectionExempt = "inspection_exempt";
    }
}
