﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models
{
    public class BlockEntity
    {
        public long BlockId {  get; set; }
        public string Name { get; set; }
        public bool IsStored {  get; set; }
        
    }
}
