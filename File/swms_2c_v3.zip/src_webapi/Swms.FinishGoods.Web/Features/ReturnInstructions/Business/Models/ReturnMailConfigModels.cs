namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

// Cấu hình email của màn Tái gia công (chỉ thị back hàng rework / refurbish).
//
// Vì sao có bản DTO riêng ở đây thay vì dùng lại của màn Hàng thiếu hay Hàng
// bất thường: bộ của Hàng thiếu nằm trong Features/Shortages và CỐ ĐỊNH module
// "SHIP" ngay trong dialog, nên hai sự kiện của màn này (module RECEIVING)
// không bao giờ hiện ra ở đó. Bộ của Hàng bất thường thì nằm trong
// Features/AbnormalReports — mã của người khác; phụ thuộc vào đó nghĩa là họ
// đổi tên hay dời file là màn này gãy.
//
// Hợp đồng thật sự là các endpoint /api/email-configs/*, nên ở đây gọi thẳng
// endpoint. Cùng lý do đã ghi trong NgMailConfigModels — khi nào team quyết
// gộp thành MỘT màn cấu hình email dùng chung thì cả ba bộ này biến mất cùng
// nhau.

/// <summary>Một loại mail (<c>master.email_events</c>) kèm mẫu tiêu đề và nội dung.</summary>
public class ReturnEmailEventDto
{
    public string Code { get; set; } = "";
    public string Module { get; set; } = "";
    public string Name { get; set; } = "";
    public string? Description { get; set; }
    public string SubjectTemplate { get; set; } = "";
    public string BodyTemplate { get; set; } = "";
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

/// <summary>Một dòng người nhận (<c>master.email_config</c>).</summary>
public class ReturnEmailConfigDto
{
    public long Id { get; set; }
    public string EventCode { get; set; } = "";
    public string? Department { get; set; }
    public string? SubCode { get; set; }
    public string? Category { get; set; }
    public string? Model { get; set; }
    public string? AreaCode { get; set; }
    public string RecipientType { get; set; } = "TO";
    public long? UserId { get; set; }

    /// <summary>Có thể chứa NHIỀU địa chỉ ngăn bởi dấu phẩy — đó là cách khai nhóm.</summary>
    public string Email { get; set; } = "";
    public string? DisplayName { get; set; }
    public bool IsActive { get; set; } = true;

    /// <summary>Bản sao để sửa trong form mà không đụng vào dòng đang hiện trên bảng.</summary>
    public ReturnEmailConfigDto Clone() => (ReturnEmailConfigDto)MemberwiseClone();
}

/// <summary>Thân request lưu người nhận. Khớp <c>SaveEmailConfigRequest</c> bên API.</summary>
public class SaveReturnEmailConfigRequestDto
{
    public string EventCode { get; set; } = "";
    public string? Department { get; set; }
    public string? SubCode { get; set; }
    public string? Category { get; set; }
    public string? Model { get; set; }
    public string? AreaCode { get; set; }
    public string RecipientType { get; set; } = "TO";
    public long? UserId { get; set; }
    public string? Email { get; set; }
    public string? DisplayName { get; set; }
    public bool IsActive { get; set; } = true;
}

/// <summary>Thân request lưu mẫu thư.</summary>
public class SaveReturnTemplateRequestDto
{
    public string Subject { get; set; } = "";
    public string? Body { get; set; }
}

/// <summary>
/// Các loại mail của màn Tái gia công, theo đúng thứ tự xảy ra.
///
/// Giữ hai mã riêng (không gộp một mã) vì mẫu thư nằm trên
/// <c>master.email_events</c> khoá theo <c>code</c>: một mã = một mẫu. Hai mail
/// này nội dung khác hẳn nhau — một cái là bảng model + SL kỳ vọng, một cái là
/// bảng lệch kế hoạch vs thực nhận — nên không nhồi vào một mẫu được.
/// <c>master.email_event_subtypes</c> KHÔNG có cột mẫu (chỉ name_key /
/// severity), nên sub_code cũng không giải quyết được.
/// </summary>
public static class ReturnMailEvents
{
    /// <summary>Bước 1 — Office tạo chỉ thị, báo FA model + SL kỳ vọng.</summary>
    public const string Created = "RETURN_INSTRUCTION_CREATED";

    /// <summary>Bước 2 — WH chốt thực nhận, báo FA số thực tế kèm bảng lệch.</summary>
    public const string Actual = "RETURN_ACTUAL_CONFIRMED";

    // ─── Mục 2c · nhận lại hàng về FA: ĐÚNG HAI mã ───
    // Giữ KHỚP với hai hằng số trong ReturnBackRequestService bên API và với
    // return_back_mail_schema.sql. Lệch một mã là dialog mở ra trống rỗng.
    //
    // Chỉ hai chỗ hàng đổi tay giữa hai bộ phận mới có mail. FA tạo đề nghị
    // (B1) không gửi — quản lý FA ngồi cùng bộ phận. Giữa B2 và B3 cũng không
    // gửi — SCS Office tự thông báo cho kho ngoài hệ thống.

    /// <summary>B2 — quản lý FA xác nhận. TO: SCS Office, CC: FA.</summary>
    public const string BackFaApproved = "RETURN_BACK_FA_APPROVED";

    /// <summary>B3 — SCS WH quét pallet giao hàng xong. TO: FA, CC: SCS.</summary>
    public const string BackDelivered = "RETURN_BACK_DELIVERED";
}

/// <summary>
/// Dialog bánh răng dùng cho HAI màn, mỗi màn một bộ sự kiện. Không tách thành
/// hai component: thân một tab giống nhau hoàn toàn, chỉ khác mã sự kiện và
/// danh sách biến — tách ra là hai bản sao rồi sửa một bên quên bên kia.
/// </summary>
public enum ReturnMailScope
{
    /// <summary>Màn Phiếu chỉ thị — 2 bước (tạo chỉ thị · chốt thực nhận).</summary>
    Instruction,

    /// <summary>Màn Yêu cầu back hàng — 2 lá mail của mục 2c.</summary>
    BackRequest,
}
