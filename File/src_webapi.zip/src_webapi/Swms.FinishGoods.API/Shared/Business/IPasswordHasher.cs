namespace Swms.FinishGoods.API.Shared.Business;

public interface IPasswordHasher
{
    string Hash(string password);
    bool Verify(string password, string hash);
}
