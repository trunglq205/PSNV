using Swms.FinishGoods.API.Features.HdSoft.Api;

namespace Swms.FinishGoods.API.Features.HdSoft.Business
{
    public interface IHdSoftService
    {
        Task<List<HdSoftLotHistoryItemResponse>> GetLotHistoryAsync(string lot);
        Task<List<HdSoftPalletStockResponse>> GetPalletsInStockAsync(string? warehouse);
        Task<IReadOnlyDictionary<string, HdSoftLastMovementRow>> GetLastMovementsAsync(
            IReadOnlyList<string> lots);

        public Task<IReadOnlyDictionary<string, IReadOnlyList<HdSoftLotLocationRow>>> GetCurrentLocationsAsync(
            IReadOnlyList<string> lots);

        // ── Shipment Instruction (C_Order) ──────────────────
        /// <summary>SI theo SINo: phiếu C_Order mới nhất chưa huỷ + dòng. Không có -> NotFound.</summary>
        Task<HdSoftSiResponse> GetSiAsync(string siNo);
        /// <summary>Trường SAP nào đọc được từ cột nào (kiểm tra cấu hình HdSoft:SiColumns).</summary>
        Task<HdSoftSiColumnsResponse> GetSiColumnsAsync();

        /// <summary>Hàng thiếu theo ngày vanning: nhu cầu còn mở của SI so với tồn kho HD soft, chia tồn theo vanning sớm trước.</summary>
        Task<HdSoftShortageResponse> GetShortagesAsync(HdSoftShortageQuery query);

        // Dùng nội bộ cho so sánh SI SWMS <-> HD soft
        Task<IReadOnlyList<HdSoftSiOrder>> GetSiOrdersAsync(IReadOnlyCollection<string> siNos);
        Task<IReadOnlyList<string>> GetSiNosByEtdAsync(DateTime from, DateTime toExclusive, string? warehouse);
        Task<HdSoftSiSchema> GetSiSchemaAsync();
    }
}
