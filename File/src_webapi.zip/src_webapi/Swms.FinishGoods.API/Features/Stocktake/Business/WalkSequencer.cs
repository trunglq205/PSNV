namespace Swms.FinishGoods.API.Features.Stocktake.Business;

/// <summary>Toạ độ một vị trí trên bản đồ — đầu vào của bộ tính thứ tự đi.</summary>
public sealed class LocatorGeo
{
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = string.Empty;
    public string? AreaCode { get; set; }
    public int AreaRows { get; set; }

    // Thuộc kệ
    public long? RackId { get; set; }
    public int? RackPositions { get; set; }   // số vị trí của kệ
    public int? RackCol { get; set; }         // vị trí trong kệ
    public int? RackRow { get; set; }         // tầng kệ
    public string? RackLevel { get; set; }    // ngăn giá lửng A/B

    // Khối trên bản đồ: của kệ (nếu thuộc kệ) hoặc của chính ô pallet
    public int? GridX { get; set; }
    public int? GridY { get; set; }
    public int? GridW { get; set; }
    public int? GridH { get; set; }
}

/// <summary>
/// Tính thứ tự đi kiểm kê theo đường ngắn, kiểu chữ S qua các lối đi.
///
///  1. Gom khối   — mỗi kệ là một khối; ô pallet sàn tách theo HÀNG (hoặc cột), vì tem QR
///                  chỉ quét được từ phía lối đi — hai hàng dính nhau là hai hàng dựa lưng.
///  2. Ghép lối   — hai khối song song cách nhau một lối đi (0,4–2,4 m) là hai mặt của
///                  cùng một lối. Khối dựa lưng nhau (khe hẹp hơn) không ghép.
///  3. Nối lối    — xuất phát góc dưới-trái; luôn vào lối có đầu gần nhất. Lối một mặt:
///                  đi một lượt, ra đầu kia. Lối hai mặt: đi hết mặt này, quay đầu đi hết
///                  mặt kia, ra lại đầu vừa vào. Các mặt kệ vì thế nối thành chữ S.
///                  Sau đó tối ưu 2-opt + dời đoạn để gỡ các lối "mồ côi" và các khối
///                  bị chen giữa chừng (cách chọn gần nhất hay để sót rồi phải quay lại).
///  4. Trong lối  — KIỂM LẦN LƯỢT TỪNG DÃY: hết mặt kệ gần phía vừa tới, rồi mới sang mặt
///                  đối diện (chiều ngược lại). Mã chạy liền mạch theo tem trên kệ, không
///                  nhảy qua lại hai bên. Trong một vị trí: tầng thấp lên cao; A trước B.
///
/// Không giải bài toán đường đi ngắn nhất thật (TSP): kết quả tối ưu về toán nhưng
/// nhảy cóc, công nhân khó đoán ô tiếp theo. Chữ S gần tối ưu mà dễ đi theo.
/// Quy ước vị trí trong kệ khớp cách PDA vẽ: vị trí 1 ở cuối trục (dưới / phải).
/// </summary>
public static class WalkSequencer
{
    private const double AisleMin = 2;    // 0.4 m — khe vẽ trên bản đồ là lối đi; sát nhau (< 0,4 m) là dựa lưng
    private const double AisleMax = 12;   // 2.4 m — xa hơn không coi là hai bên một lối đi
    private const int    MaxOptimize = 300; // quá nhiều lối thì bỏ bước tối ưu cho nhanh
    private const double MinOverlap = 0.5;

    /// <summary>Trả về số thứ tự đi (1..n) cho từng vị trí, nối các khu theo mã khu.</summary>
    public static Dictionary<long, int> Sequence(IEnumerable<LocatorGeo> geos)
    {
        var result = new Dictionary<long, int>();
        var seq = 0;
        foreach (var area in geos.GroupBy(g => g.AreaCode ?? string.Empty)
                                 .OrderBy(g => g.Key, StringComparer.OrdinalIgnoreCase))
        {
            foreach (var id in SequenceArea(area.ToList()))
                if (!result.ContainsKey(id)) result[id] = ++seq;
        }
        return result;
    }

    // ------------------------------------------------------------------ một khu

    private static List<long> SequenceArea(List<LocatorGeo> geos)
    {
        var placed = geos.Where(g => g.GridX is not null && g.GridW > 0 && g.GridH > 0).ToList();
        var unplaced = geos.Except(placed)
                           .OrderBy(g => g.LocatorCode, NaturalCodeComparer.Instance)
                           .Select(g => g.LocatorId);

        var blocks = BuildBlocks(placed);
        var aisles = PairIntoAisles(blocks, placed.FirstOrDefault()?.AreaRows ?? 0);
        var start = new Pt(0, placed.FirstOrDefault()?.AreaRows ?? 0);   // góc dưới-trái

        // Dựng lộ trình bằng cách chọn lối gần nhất, rồi tối ưu lại.
        var tour = new List<(Aisle A, bool FromLow)>();
        var pos = start;
        var left = aisles.ToList();
        while (left.Count > 0)
        {
            Aisle best = left[0];
            bool fromLow = true;
            double bestD = double.MaxValue;
            foreach (var a in left)
            {
                var dLow = Manhattan(pos, a.LowEnd);
                var dHigh = Manhattan(pos, a.HighEnd);
                if (dLow < bestD) { bestD = dLow; best = a; fromLow = true; }
                if (dHigh < bestD) { bestD = dHigh; best = a; fromLow = false; }
            }
            tour.Add((A: best, FromLow: fromLow));
            pos = best.Exit(fromLow);
            left.Remove(best);
        }

        if (tour.Count <= MaxOptimize) tour = Optimize(start, tour);

        var order = new List<long>();
        pos = start;
        foreach (var (a, fl) in tour)
        {
            order.AddRange(a.Walk(fl, pos));   // biết vừa tới từ đâu để chọn mặt kệ đi trước
            pos = a.Exit(fl);
        }

        order.AddRange(unplaced);   // ô chưa đặt lên bản đồ: xếp cuối theo mã
        return order;
    }

    // ------------------------------------------------------------------ tối ưu lộ trình

    /// <summary>Tổng quãng di chuyển GIỮA các lối (đi trong lối là cố định, không tính).</summary>
    private static double TourCost(Pt start, List<(Aisle A, bool FromLow)> tour)
    {
        var pos = start; double cost = 0;
        foreach (var (a, fl) in tour)
        {
            cost += Manhattan(pos, a.Entry(fl));
            pos = a.Exit(fl);
        }
        return cost;
    }

    /// <summary>
    /// Luân phiên 2-opt và dời đoạn, mỗi phép chạy đến khi ổn định,
    /// lặp lại cho tới khi cả hai không còn rút ngắn được nữa.
    /// </summary>
    private static List<(Aisle A, bool FromLow)> Optimize(Pt start, List<(Aisle A, bool FromLow)> tour)
    {
        var best = tour.ToList();
        var bestCost = TourCost(start, best);
        // Dời đoạn dài tốn thời gian O(n^4): khu lớn thì chỉ dời đoạn ngắn.
        var maxLen = best.Count <= 60 ? 12 : 3;

        for (var round = 0; round < 50; round++)
        {
            var before = bestCost;
            TwoOpt(start, ref best, ref bestCost);
            MoveSegments(start, ref best, ref bestCost, maxLen);
            if (bestCost >= before - 1e-9) break;
        }
        return best;
    }

    /// <summary>
    /// Đi ngược một đoạn lộ trình: đảo thứ tự, lối một lượt thì lật chiều;
    /// lối quay đầu vào và ra cùng một đầu nên giữ nguyên.
    /// </summary>
    private static IEnumerable<(Aisle A, bool FromLow)> Reversed(IEnumerable<(Aisle A, bool FromLow)> seg)
        => seg.Reverse().Select(t => (A: t.A, FromLow: t.A.UTurn ? t.FromLow : !t.FromLow));

    /// <summary>Đảo ngược một đoạn lộ trình (xem <see cref="Reversed"/>).</summary>
    private static void TwoOpt(Pt start, ref List<(Aisle A, bool FromLow)> best, ref double bestCost)
    {
        bool improved;
        do
        {
            improved = false;
            for (var i = 0; i < best.Count; i++)
                for (var j = i; j < best.Count; j++)
                {
                    var cand = best.Take(i)
                        .Concat(Reversed(best.Skip(i).Take(j - i + 1)))
                        .Concat(best.Skip(j + 1)).ToList();
                    var c = TourCost(start, cand);
                    if (c < bestCost - 1e-9) { best = cand; bestCost = c; improved = true; }
                }
        } while (improved);
    }

    /// <summary>
    /// Nhấc nguyên một đoạn 1..maxLen lối liên tiếp, cắm sang chỗ khác theo 4 biến thể:
    /// giữ nguyên, lật chiều, đảo thứ tự, đảo thứ tự + lật chiều.
    /// Cần thiết để dời cả một khối (vd khối T của FA) mà không phá thứ tự bên trong.
    /// </summary>
    private static void MoveSegments(Pt start, ref List<(Aisle A, bool FromLow)> best,
                                     ref double bestCost, int maxLen)
    {
        bool improved;
        do
        {
            improved = false;
            var n = best.Count;
            for (var len = 1; len <= Math.Min(maxLen, n); len++)
                for (var i = 0; i + len <= n; i++)
                {
                    var seg  = best.GetRange(i, len);
                    var rest = best.Take(i).Concat(best.Skip(i + len)).ToList();
                    var variants = new[]
                    {
                        seg,                                                                         // giữ nguyên
                        Reversed(seg).ToList(),                                                      // đi ngược cả đoạn
                        seg.Select(t => (A: t.A, FromLow: !t.FromLow)).ToList(),                     // lật chiều (lối quay đầu: đổi đầu vào)
                        Enumerable.Reverse(seg).ToList()                                             // đảo thứ tự
                    };
                    for (var j = 0; j <= rest.Count; j++)
                        foreach (var v in variants)
                        {
                            var cand = rest.Take(j).Concat(v).Concat(rest.Skip(j)).ToList();
                            var c = TourCost(start, cand);
                            if (c < bestCost - 1e-9) { best = cand; bestCost = c; improved = true; }
                        }
                }
        } while (improved);
    }

    // ------------------------------------------------------------------ gom khối

    private static List<Block> BuildBlocks(List<LocatorGeo> placed)
    {
        var blocks = new List<Block>();

        // Kệ: mỗi kệ một khối, hình chữ nhật lấy từ bản đồ
        foreach (var g in placed.Where(x => x.RackId is not null).GroupBy(x => x.RackId!.Value))
        {
            var f = g.First();
            var r = new Rect(f.GridX!.Value, f.GridY!.Value, f.GridW!.Value, f.GridH!.Value);
            var b = new Block(r);
            foreach (var c in g) b.Cells.Add(RackCell(c, r));
            blocks.Add(b);
        }

        // Ô pallet sàn: gom các ô dính nhau thành cụm (union-find), rồi TÁCH cụm theo hàng
        // (hoặc theo cột nếu cụm xếp dọc như khối T). Mỗi hàng là một khối riêng vì tem QR
        // chỉ quét được từ phía lối đi của hàng đó — hai hàng dính nhau là hai hàng dựa lưng.
        var singles = placed.Where(x => x.RackId is null).ToList();
        var rects = singles.Select(s => new Rect(s.GridX!.Value, s.GridY!.Value, s.GridW!.Value, s.GridH!.Value)).ToList();
        var parent = Enumerable.Range(0, singles.Count).ToArray();
        int Find(int i) { while (parent[i] != i) i = parent[i] = parent[parent[i]]; return i; }

        var rowLinks = new List<int>();   // chỉ số ô đầu của mỗi cặp dính nhau CÙNG HÀNG
        var colLinks = new List<int>();   // ... CÙNG CỘT
        for (var i = 0; i < singles.Count; i++)
            for (var j = i + 1; j < singles.Count; j++)
            {
                var a = rects[i]; var b = rects[j];
                if (!a.Touches(b)) continue;
                parent[Find(i)] = Find(j);
                if (a.Y == b.Y && a.H == b.H) rowLinks.Add(i);
                else if (a.X == b.X && a.W == b.W) colLinks.Add(i);
            }

        var rowCount = rowLinks.GroupBy(Find).ToDictionary(g => g.Key, g => g.Count());
        var colCount = colLinks.GroupBy(Find).ToDictionary(g => g.Key, g => g.Count());

        foreach (var comp in Enumerable.Range(0, singles.Count).GroupBy(Find))
        {
            // Cụm có nhiều cặp dính theo hàng hơn -> tách theo hàng; ngược lại tách theo cột.
            var byRow = rowCount.GetValueOrDefault(comp.Key) >= colCount.GetValueOrDefault(comp.Key);
            foreach (var line in comp.GroupBy(i => byRow ? rects[i].Y : rects[i].X))
            {
                var idx = line.ToList();
                var b = new Block(Rect.Union(idx.Select(i => rects[i])));
                foreach (var i in idx)
                    b.Cells.Add(new Cell(singles[i].LocatorId, rects[i].Cx, rects[i].Cy, 0, null));
                blocks.Add(b);
            }
        }
        return blocks;
    }

    /// <summary>Toạ độ tâm của một ô trong kệ. Vị trí 1 ở cuối trục (dưới / phải) như PDA vẽ.</summary>
    private static Cell RackCell(LocatorGeo g, Rect r)
    {
        var n = Math.Max(1, g.RackPositions ?? 1);
        var col = Math.Clamp(g.RackCol ?? 1, 1, n);
        var t = 1.0 - (col - 0.5) / n;   // 0..1 dọc trục dài, vị trí 1 gần cuối

        return r.Vertical
            ? new Cell(g.LocatorId, r.Cx, r.Y + t * r.H, g.RackRow ?? 0, g.RackLevel)
            : new Cell(g.LocatorId, r.X + t * r.W, r.Cy, g.RackRow ?? 0, g.RackLevel);
    }

    // ------------------------------------------------------------------ ghép lối

    private static List<Aisle> PairIntoAisles(List<Block> blocks, int areaRows)
    {
        var start = new Pt(0, areaRows);
        var cands = new List<(Block a, Block b, double gap, double dist)>();

        for (var i = 0; i < blocks.Count; i++)
            for (var j = i + 1; j < blocks.Count; j++)
            {
                var a = blocks[i]; var b = blocks[j];
                if (a.R.Vertical != b.R.Vertical) continue;

                var gap = a.R.Vertical ? GapX(a.R, b.R) : GapY(a.R, b.R);
                if (gap < AisleMin || gap > AisleMax) continue;

                var ov = a.R.Vertical ? OverlapY(a.R, b.R) : OverlapX(a.R, b.R);
                var shorter = Math.Min(a.R.Long, b.R.Long);
                if (shorter <= 0 || ov / shorter < MinOverlap) continue;

                // Có khối khác chen vào giữa thì hai khối không đối diện qua một lối đi.
                if (IsBlocked(a, b, blocks)) continue;

                var mid = new Pt((a.R.Cx + b.R.Cx) / 2, (a.R.Cy + b.R.Cy) / 2);
                cands.Add((a, b, gap, Manhattan(start, mid)));
            }

        // Ưu tiên lối hẹp nhất; ngang nhau thì cặp gần điểm xuất phát trước
        var used = new HashSet<Block>();
        var aisles = new List<Aisle>();
        foreach (var c in cands.OrderBy(c => c.gap).ThenBy(c => c.dist))
        {
            if (used.Contains(c.a) || used.Contains(c.b)) continue;
            used.Add(c.a); used.Add(c.b);
            aisles.Add(new Aisle(c.a, c.b));
        }
        foreach (var b in blocks.Where(b => !used.Contains(b)))
            aisles.Add(new Aisle(b, null));

        return aisles;
    }

    /// <summary>Có khối nào nằm trong khe giữa a và b (vùng hai khối cùng phủ) không.</summary>
    private static bool IsBlocked(Block a, Block b, List<Block> blocks)
    {
        double x0, x1, y0, y1;
        if (a.R.Vertical)
        {
            x0 = Math.Min(a.R.Right, b.R.Right); x1 = Math.Max(a.R.X, b.R.X);
            y0 = Math.Max(a.R.Y, b.R.Y);         y1 = Math.Min(a.R.Bottom, b.R.Bottom);
        }
        else
        {
            y0 = Math.Min(a.R.Bottom, b.R.Bottom); y1 = Math.Max(a.R.Y, b.R.Y);
            x0 = Math.Max(a.R.X, b.R.X);           x1 = Math.Min(a.R.Right, b.R.Right);
        }
        foreach (var c in blocks)
        {
            if (ReferenceEquals(c, a) || ReferenceEquals(c, b)) continue;
            if (c.R.X < x1 && c.R.Right > x0 && c.R.Y < y1 && c.R.Bottom > y0) return true;
        }
        return false;
    }

    // ------------------------------------------------------------------ hình học

    private static double Manhattan(Pt a, Pt b) => Math.Abs(a.X - b.X) + Math.Abs(a.Y - b.Y);
    private static double GapX(Rect a, Rect b) => Math.Max(a.X, b.X) - Math.Min(a.Right, b.Right);
    private static double GapY(Rect a, Rect b) => Math.Max(a.Y, b.Y) - Math.Min(a.Bottom, b.Bottom);
    private static double OverlapX(Rect a, Rect b) => Math.Max(0, Math.Min(a.Right, b.Right) - Math.Max(a.X, b.X));
    private static double OverlapY(Rect a, Rect b) => Math.Max(0, Math.Min(a.Bottom, b.Bottom) - Math.Max(a.Y, b.Y));

    private readonly record struct Pt(double X, double Y);

    private sealed record Rect(double X, double Y, double W, double H)
    {
        public double Right => X + W;
        public double Bottom => Y + H;
        public double Cx => X + W / 2;
        public double Cy => Y + H / 2;
        public bool Vertical => H >= W;
        public double Long => Vertical ? H : W;

        /// <summary>Hai ô chạm nhau (dính cạnh) — dùng để gom ô pallet sàn thành khối.</summary>
        public bool Touches(Rect o)
            => X <= o.Right + 0.5 && o.X <= Right + 0.5
            && Y <= o.Bottom + 0.5 && o.Y <= Bottom + 0.5;

        public static Rect Union(IEnumerable<Rect> rs)
        {
            var l = rs.ToList();
            var x = l.Min(r => r.X); var y = l.Min(r => r.Y);
            return new Rect(x, y, l.Max(r => r.Right) - x, l.Max(r => r.Bottom) - y);
        }
    }

    private sealed record Cell(long LocatorId, double X, double Y, int Floor, string? Level);

    private sealed class Block
    {
        public Rect R { get; }
        public List<Cell> Cells { get; } = new();
        public Block(Rect r) => R = r;
    }

    /// <summary>Một lối đi: một mặt kệ, hoặc hai mặt kệ đối diện (đi hết mặt này rồi quay đầu).</summary>
    private sealed class Aisle
    {
        private readonly Block _a;
        private readonly Block? _b;
        private readonly bool _vertical;
        public Pt LowEnd { get; }    // đầu có toạ độ trục dài nhỏ (trên / trái)
        public Pt HighEnd { get; }   // đầu còn lại (dưới / phải)

        public Aisle(Block a, Block? b)
        {
            _a = a; _b = b;
            _vertical = a.R.Vertical;
            var all = b is null ? new[] { a.R } : new[] { a.R, b.R };
            var u = Rect.Union(all);
            // Trục ngang của lối: giữa hai khối nếu có cặp, không thì giữa khối
            var cx = b is null ? u.Cx : (a.R.Cx + b.R.Cx) / 2;
            var cy = b is null ? u.Cy : (a.R.Cy + b.R.Cy) / 2;
            LowEnd  = _vertical ? new Pt(cx, u.Y)      : new Pt(u.X, cy);
            HighEnd = _vertical ? new Pt(cx, u.Bottom) : new Pt(u.Right, cy);
        }

        /// <summary>Lối hai mặt: đi hết mặt này, quay đầu đi mặt kia -> ra lại đầu vừa vào.</summary>
        public bool UTurn => _b is not null;

        public Pt Entry(bool fromLow) => fromLow ? LowEnd : HighEnd;
        public Pt Exit(bool fromLow) => UTurn ? Entry(fromLow) : (fromLow ? HighEnd : LowEnd);

        /// <summary>
        /// Thứ tự ô khi đi lối này, vào từ đầu thấp (fromLow) hoặc đầu cao.
        /// Lối hai mặt: mặt gần phía vừa tới (<paramref name="cameFrom"/>) đi trước, rồi quay đầu
        /// đi mặt còn lại theo chiều ngược lại — quét từ trái sang, các mặt kệ nối thành chữ S.
        /// </summary>
        public IEnumerable<long> Walk(bool fromLow, Pt cameFrom)
        {
            if (_b is null) return Face(_a, fromLow);

            double Side(Block k) => _vertical ? k.R.Cx : k.R.Cy;
            var p = _vertical ? cameFrom.X : cameFrom.Y;
            var aFirst = (Math.Abs(p - Side(_a)), Side(_a)).CompareTo((Math.Abs(p - Side(_b)), Side(_b))) <= 0;
            var (first, second) = aFirst ? (_a, _b) : (_b, _a);

            return Face(first, fromLow).Concat(Face(second, !fromLow));
        }

        /// <summary>Các ô của một mặt kệ theo chiều đi; trong một vị trí: tầng thấp lên cao, A trước B.</summary>
        private IEnumerable<long> Face(Block b, bool forward)
        {
            // Làm tròn toạ độ dọc lối để các tầng của cùng một vị trí đi liền nhau
            double Along(Cell c) => Math.Round(_vertical ? c.Y : c.X, 1);
            double Across(Cell c) => _vertical ? c.X : c.Y;

            var ordered = forward
                ? b.Cells.OrderBy(c => Along(c))
                : b.Cells.OrderByDescending(c => Along(c));

            return ordered
                .ThenBy(c => Across(c))
                .ThenBy(c => c.Floor)
                .ThenBy(c => c.Level ?? string.Empty, StringComparer.Ordinal)
                .Select(c => c.LocatorId);
        }
    }
}

/// So sánh mã vị trí "tự nhiên": đoạn số so theo giá trị (A1-2-1 &lt; A1-10-1; 1.B12A.3.02 &lt; 1.B12A.3.10).
public sealed class NaturalCodeComparer : IComparer<string?>
{
    public static readonly NaturalCodeComparer Instance = new();

    public int Compare(string? a, string? b)
    {
        if (ReferenceEquals(a, b)) return 0;
        if (a is null) return -1;
        if (b is null) return 1;

        int i = 0, j = 0;
        while (i < a.Length && j < b.Length)
        {
            if (char.IsDigit(a[i]) && char.IsDigit(b[j]))
            {
                int si = i, sj = j;
                while (i < a.Length && char.IsDigit(a[i])) i++;
                while (j < b.Length && char.IsDigit(b[j])) j++;
                var na = a.AsSpan(si, i - si).TrimStart('0');
                var nb = b.AsSpan(sj, j - sj).TrimStart('0');
                if (na.Length != nb.Length) return na.Length.CompareTo(nb.Length);
                int c = na.CompareTo(nb, StringComparison.Ordinal);
                if (c != 0) return c;
            }
            else
            {
                int c = char.ToUpperInvariant(a[i]).CompareTo(char.ToUpperInvariant(b[j]));
                if (c != 0) return c;
                i++; j++;
            }
        }
        return (a.Length - i).CompareTo(b.Length - j);
    }
}
