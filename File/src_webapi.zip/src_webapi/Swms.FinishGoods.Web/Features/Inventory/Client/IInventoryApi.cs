using Refit;
using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.Client;

/// <summary>
/// HTTP của màn Tồn kho — phần SWMS thuần: danh sách, thống kê, aging, chi tiết lot,
/// lịch sử, master. Route /api/pallets/... vẫn là của feature Pallets phía API.
///
/// Không còn ở đây:
///   so / xử lý chênh lệch HD soft -> HdSoftCompare/Client/IHdSoftCompareApi
///   job đồng bộ (/api/sync)       -> Features/Sync/Client/ISyncApi
/// </summary>
public interface IInventoryApi
{
    // ── Tồn kho ──

    /// <summary>Danh sách lot đang tồn (inv.stock_onhand JOIN wms.pallets).</summary>
    [Get("/api/inventory")]
    Task<PagedResult<InventoryItemDto>> GetAllAsync([Query] InventoryQuery query);

    /// <summary>Thống kê 5 khu vực theo cùng bộ lọc (bỏ qua Area).</summary>
    [Get("/api/inventory/areas")]
    Task<List<InventoryAreaDto>> GetAreasAsync([Query] InventoryQuery query);

    /// <summary>Phân bố tuổi tồn theo bucket (Aging / FIFO).</summary>
    [Get("/api/inventory/aging")]
    Task<List<InventoryAgingBucketDto>> GetAgingAsync([Query] InventoryQuery query);

    // ── Chi tiết lot + lịch sử (route /api/pallets) ──

    /// <summary>Chi tiết lot kèm box/line — nguồn dữ liệu cho cột phải của dialog.</summary>
    [Get("/api/pallets/{id}")]
    Task<InventoryItemDto> GetByIdAsync(long id);

    /// <summary>Timeline đầy đủ của lot — cột trái của dialog.</summary>
    [Get("/api/pallets/{id}/history")]
    Task<StockHistoryDto> GetHistoryAsync(long id);

    /// <summary>
    /// Catalog loại event. Gọi một lần cho cả vòng đời ứng dụng —
    /// xem <c>StockEventCatalog</c>.
    /// </summary>
    [Get("/api/stock-event-types")]
    Task<StockEventTypeListDto> GetEventTypesAsync([Query] string? subjectType = null);

    // ── Master ──

    /// <summary>Option category cho select nhanh + dialog in tem.</summary>
    [Get("/api/categories/options")]
    Task<List<CategoryOptionDto>> GetCategoryOptionsAsync();
}
