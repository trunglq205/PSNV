
import 'package:freezed_annotation/freezed_annotation.dart';
import 'package:smart_warehouse/entities/Robot/robot_location_start.dart';
import 'package:smart_warehouse/shared/base/base_state.dart';
import 'package:smart_warehouse/shared/common/error_entity.dart';

part 'callamr_state.freezed.dart';

@freezed
class CallAMRState extends BaseState with _$CallAMRState {
  factory CallAMRState({
    @Default(PageStatus.initial) PageStatus pageStatus,
    @Default(false) bool processing,
    @Default(null) ErrorEntity? errorEntity,
    @Default(null) RobotLocationStart? robotLocationStart,
  }) = _CallAMRState;
}

