using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

public class ReturnBackFlowRepository : IReturnBackFlowRepository
{
    private readonly IDbConnectionFactory _factory;
    public ReturnBackFlowRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<bool> RequestAsync(
        long docId, string? note, IReadOnlyList<BackReqLine> lines, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        // Header và dòng đề nghị phải đi CÙNG một transaction: ghi được header
        // rồi hỏng lúc ghi dòng là phiếu mang trạng thái "FA đã đề nghị" mà
        // không có dòng nào — quản lý FA mở ra duyệt một đề nghị trống.
        // Trả về SỐ LẦN vừa mở, null = không đề nghị được.
        var round = await RequestHeaderAsync(conn, tx, docId, note, user);
        if (round is null) { tx.Rollback(); return false; }

        // KHÔNG còn xoá dòng của lượt trước (bản cũ DELETE sạch vì chỉ mục
        // ux_rbl_doc_model chặn trùng (doc, model)). Từ 12/11 chỉ mục là
        // (doc_id, round, model) nên dòng cũ không chặn dòng mới, và lịch sử
        // "lần 1 xin bao nhiêu" PHẢI ở lại — tiến trình con hiện đúng con số đó.
        if (lines.Count > 0)
            await conn.ExecuteAsync("""
                INSERT INTO wms.return_back_lines
                    (doc_id, round, model, req_qty, created_at, created_by)
                VALUES
                    (@docId, @round, @model, @reqQty, SYSDATETIME(), @user);
                """,
                lines.Select(l => new
                {
                    docId,
                    round = round.Value,
                    model = l.Model,
                    reqQty = l.ReqQty,
                    user,
                }), tx);

        // Dòng mốc của LẦN này. asked_qty là ẢNH CHỤP: NULL = FA không khai
        // dòng nào = xin toàn bộ phần còn ở kho LÚC NÀY. Suy lại sau một lượt
        // giao sẽ ra số khác, nên phải chụp.
        await conn.ExecuteAsync("""
            INSERT INTO wms.return_back_rounds (doc_id, round, asked_qty)
            VALUES (@docId, @round, @asked);
            """,
            new
            {
                docId,
                round = round.Value,
                asked = lines.Count > 0 ? lines.Sum(l => l.ReqQty) : (int?)null,
            }, tx);

        await SyncRoundAsync(conn, tx, docId);

        tx.Commit();
        return true;
    }

    /// <summary>
    /// Chép mốc của lần ĐANG MỞ từ các cột <c>back_*</c> của phiếu sang dòng
    /// <c>wms.return_back_rounds</c> tương ứng.
    ///
    /// Vì sao có hai chỗ giữ cùng một thứ: các cột <c>back_*</c> là thứ MỌI câu
    /// đọc danh sách / lọc / mail / PDA đang dùng, bỏ chúng là phải viết lại
    /// toàn bộ câu đọc của feature. Bảng rounds là thứ DUY NHẤT giữ được mốc
    /// của những lần ĐÃ XONG (cột back_* bị lần sau ghi đè).
    ///
    /// Nên luật là: mọi bước của luồng back ghi cột back_* xong thì gọi hàm này
    /// TRONG CÙNG transaction. Chép TẤT CẢ cột, không chép chọn lọc — chép
    /// chọn lọc là sớm muộn quên một cột. Câu soát lệch: mục 7 của
    /// return_back_round_schema.sql.
    /// </summary>
    private static Task SyncRoundAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction? tx, long docId)
        => conn.ExecuteAsync("""
            UPDATE r
            SET    r.note            = d.back_note,
                   r.requested_by    = d.back_requested_by,
                   r.requested_at    = d.back_requested_at,
                   r.fa_approved_by  = d.back_approved_by,
                   r.fa_approved_at  = d.back_approved_at,
                   r.fa_comment      = d.back_fa_comment,
                   r.scs_approved_by = d.back_scs_approved_by,
                   r.scs_approved_at = d.back_scs_approved_at,
                   r.scs_comment     = d.back_scs_comment,
                   r.delivered_by    = d.back_delivered_by,
                   r.delivered_at    = d.back_delivered_at,
                   r.cancelled_by    = d.back_cancelled_by,
                   r.cancelled_at    = d.back_cancelled_at,
                   r.cancel_reason   = d.back_cancel_reason
            FROM   wms.return_back_rounds r
            JOIN   wms.return_instructions d
                   ON d.id = r.doc_id AND r.round = d.back_round
            WHERE  d.id = @docId;
            """, new { docId }, tx);

    /// <summary>
    /// Mở một lần đề nghị mới. Trả SỐ LẦN vừa mở, null = không mở được.
    /// </summary>
    private static async Task<int?> RequestHeaderAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx,
        long docId, string? note, string? user)
    {
        // Điều kiện đề nghị được, HẾT trong một câu:
        //   phiếu còn sống · chưa huỷ · KHÔNG có lần nào đang chạy (chưa đề
        //   nghị, hoặc lần trước đã huỷ / đã giao xong) · CÒN con nào ở kho.
        //
        // 'delivered' thêm vào 12/11 — đó chính là "đề nghị tiếp": lần trước
        // giao xong rồi mà kho vẫn còn hàng của phiếu.
        //
        // Lượt đề nghị mới phải xoá sạch dấu của lần trước — cả ba mốc duyệt,
        // ba ô ý kiến và bộ huỷ. Để sót một ô là màn hình hiện đề nghị mới kèm
        // "lý do huỷ" của lượt trước. Mốc cũ KHÔNG mất: SyncRoundAsync đã chép
        // sang dòng lần trước trước khi lần này mở.
        //
        // OUTPUT inserted.back_round: lấy số lần ngay trong câu UPDATE. Đọc lại
        // bằng một câu SELECT sau đó là mở cửa cho hai người bấm cùng lúc cùng
        // đọc ra một số.
        return await conn.QuerySingleOrDefaultAsync<int?>("""
            UPDATE d
            SET    d.back_round          = d.back_round + 1,
                   d.back_status         = N'fa_requested',
                   d.back_note           = @note,
                   d.back_requested_by   = @user,
                   d.back_requested_at   = SYSDATETIME(),
                   d.back_approved_by    = NULL,
                   d.back_approved_at    = NULL,
                   d.back_fa_comment     = NULL,
                   d.back_scs_approved_by = NULL,
                   d.back_scs_approved_at = NULL,
                   d.back_delivered_by   = NULL,
                   d.back_delivered_at   = NULL,
                   d.back_scs_comment    = NULL,
                   d.back_cancelled_by   = NULL,
                   d.back_cancelled_at   = NULL,
                   d.back_cancel_reason  = NULL,
                   d.updated_at          = SYSDATETIME(),
                   d.updated_by          = @user
            OUTPUT inserted.back_round
            FROM   wms.return_instructions d
            WHERE  d.id = @docId
              AND  d.is_deleted = 0
              AND  d.doc_status <> N'cancelled'
              AND  (d.back_status IS NULL
                    OR d.back_status IN (N'cancelled', N'delivered'))
              AND  EXISTS (SELECT 1 FROM wms.return_instruction_serials s
                           WHERE s.doc_id = d.id AND s.status = N'received'
                             AND s.is_deleted = 0);
            """, new { docId, note, user }, tx);
    }

    /// <summary>
    /// B3 — quản lý SCS xác nhận (thêm 10/11). Sau bước này SCS WH mới được
    /// tách pallet và quét giao.
    ///
    /// Điều kiện <c>back_status = 'fa_approved'</c> nằm TRONG câu UPDATE: hai
    /// người duyệt cùng lúc thì người sau cập nhật 0 dòng và nhận 409, chứ
    /// không ghi đè mốc của người đầu.
    ///
    /// KHÔNG bắn mail — xem ghi chú ở <c>ReturnBackFlowService</c>.
    /// </summary>
    public async Task<bool> ScsApproveAsync(long docId, string? comment, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    back_status           = N'scs_approved',
                   back_scs_approved_by  = @user,
                   back_scs_approved_at  = SYSDATETIME(),
                   back_scs_comment      = @comment,
                   updated_at            = SYSDATETIME(),
                   updated_by            = @user
            WHERE  id = @docId AND is_deleted = 0
              AND  back_status = N'fa_approved';
            """, new { docId, comment, user }, tx);

        if (n == 0) { tx.Rollback(); return false; }

        await SyncRoundAsync(conn, tx, docId);
        tx.Commit();
        return true;
    }

    public async Task<bool> UpdateNoteAsync(long docId, string? note, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    back_note  = @note,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  id = @docId AND is_deleted = 0
              AND  back_status = N'fa_requested';
            """, new { docId, note, user }, tx);

        if (n == 0) { tx.Rollback(); return false; }

        // Ghi chú cũng phải chép sang dòng lần đang mở: tiến trình con đọc ghi
        // chú từ đó. Bỏ sót chỗ này là sửa ghi chú xong màn hình vẫn hiện câu cũ.
        await SyncRoundAsync(conn, tx, docId);
        tx.Commit();
        return true;
    }

    public async Task<bool> ApproveAsync(long docId, string? comment, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    back_status       = N'fa_approved',
                   back_approved_by  = @user,
                   back_approved_at  = SYSDATETIME(),
                   back_fa_comment   = @comment,
                   updated_at        = SYSDATETIME(),
                   updated_by        = @user
            WHERE  id = @docId AND is_deleted = 0
              AND  back_status = N'fa_requested';
            """, new { docId, comment, user }, tx);

        if (n == 0) { tx.Rollback(); return false; }

        await SyncRoundAsync(conn, tx, docId);
        tx.Commit();
        return true;
    }

    public async Task<bool> CancelAsync(long docId, string? reason, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        // NOT EXISTS nằm TRONG câu UPDATE, không kiểm trước rồi ghi sau: giữa
        // hai lệnh đó WH có thể vừa quét xong một pallet, và lúc ấy huỷ là để
        // lại một lô hàng ở FA mà không đề nghị nào đứng tên.
        var n = await conn.ExecuteAsync("""
            UPDATE d
            SET    d.back_status        = N'cancelled',
                   d.back_cancelled_by  = @user,
                   d.back_cancelled_at  = SYSDATETIME(),
                   d.back_cancel_reason = @reason,
                   d.updated_at         = SYSDATETIME(),
                   d.updated_by         = @user
            FROM   wms.return_instructions d
            WHERE  d.id = @docId
              AND  d.is_deleted = 0
              AND  d.back_status IN (N'fa_requested', N'fa_approved', N'scs_approved')
              AND  NOT EXISTS (SELECT 1 FROM wms.return_instruction_serials s
                               WHERE s.doc_id = d.id AND s.sent_fa_at IS NOT NULL
                                 AND s.is_deleted = 0);
            """, new { docId, reason, user }, tx);

        if (n == 0) { tx.Rollback(); return false; }

        await SyncRoundAsync(conn, tx, docId);
        tx.Commit();
        return true;
    }

    public async Task<ReturnBackPalletTarget?> FindDeliverableByPalletAsync(long palletId)
    {
        using var conn = _factory.Create();

        // GROUP BY để một pallet về đúng MỘT dòng. Trên thực tế một pallet chỉ
        // thuộc một phiếu, nhưng câu này không dựa vào điều đó: nếu dữ liệu có
        // pallet dính hai phiếu thì TOP 1 lấy phiếu nhiều hàng chờ giao nhất,
        // chứ không ném — người quét không sửa được chuyện đó bằng cách thử lại.
        return await conn.QueryFirstOrDefaultAsync<ReturnBackPalletTarget>("""
            SELECT TOP 1
                   d.id          AS [DocId],
                   d.doc_no      AS [DocNo],
                   d.back_status AS [BackStatus],
                   COUNT(*)      AS [ReceivedQty]
            FROM   wms.return_instruction_serials s
            JOIN   wms.return_instructions d
                   ON d.id = s.doc_id AND d.is_deleted = 0
            WHERE  s.pallet_id  = @palletId
              AND  s.status     = N'received'
              AND  s.is_deleted = 0
            GROUP BY d.id, d.doc_no, d.back_status
            ORDER BY COUNT(*) DESC;
            """, new { palletId });
    }

    public async Task<ReturnBackMoveDelivered> DeliverOnMoveAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletId,
        string lotNo,
        string? user)
    {
        // Khoá phiếu (UPDLOCK, HOLDLOCK) rồi mới đọc trạng thái: hai WH đẩy hai
        // pallet con của cùng phiếu vào khu nhận hàng cùng lúc thì người sau xếp
        // hàng chờ, chứ không cùng đọc "còn hàng" rồi cùng đóng phiếu.
        var head = await conn.QuerySingleOrDefaultAsync<HeadRow>("""
            SELECT TOP 1 d.id         AS [Id],
                         d.back_status AS [BackStatus],
                         d.back_round  AS [BackRound]
            FROM   wms.return_instructions d WITH (UPDLOCK, HOLDLOCK)
            WHERE  d.id = @docId AND d.is_deleted = 0;
            """, new { docId }, tx);

        // Trả cờ, KHÔNG ném từ đây: repository không có localizer nên ném ở đây
        // là ném thông báo tiếng Anh cứng cho người quét. Tầng nghiệp vụ
        // (ReturnBackMoveGate) đọc cờ rồi ném bản đã dịch — vẫn nằm trong
        // transaction đổi vị trí, nên pallet vẫn không bị chuyển.
        if (head is null)
            return new ReturnBackMoveDelivered { DocGone = true };

        if (head.BackStatus != ReturnBackStatus.ScsApproved)
            return new ReturnBackMoveDelivered { WrongStep = true, BackStatus = head.BackStatus };

        var round = head.BackRound;

        // ── TRẦN CỦA LẦN NÀY, XÉT THEO MODEL (chốt 12/11) ────────────────
        //
        // FA xin theo model nên trần cũng phải theo model. Pallet 500 con mà
        // lần này chỉ xin 20 thì KHÔNG cho đẩy: SCS WH phải tách pallet cho
        // khớp rồi mới giao. Bản trước 12/11 đánh HẾT serial 'received' trên
        // pallet sang at_fa, nên xin 20 mà đẩy pallet 500 là sổ ghi giao 500,
        // lần đề nghị đóng luôn và 480 con biến thành "đã giao".
        //
        // Không khai dòng nào = xin TOÀN BỘ phần còn ở kho -> không có trần.
        var needs = (await conn.QueryAsync<NeedRow>("""
            SELECT  l.model          AS [Model],
                    l.req_qty        AS [ReqQty],
                    ISNULL(d.qty, 0) AS [DeliveredQty]
            FROM    wms.return_back_lines l
            OUTER APPLY (
                -- Đã giao bao nhiêu con của model này TRONG lần này. Đếm từ sổ
                -- serial (cột back_round đóng ngay trong câu UPDATE đổi sang
                -- at_fa) — nhật ký giao chỉ đếm theo pallet nên không chia
                -- được theo model.
                SELECT COUNT(*) AS qty
                FROM   wms.return_instruction_serials s
                WHERE  s.doc_id     = l.doc_id
                  AND  s.back_round = l.round
                  AND  s.model      = l.model
                  AND  s.is_deleted = 0
            ) d
            WHERE   l.doc_id = @docId AND l.round = @round;
            """, new { docId, round }, tx)).ToList();

        if (needs.Count > 0)
        {
            var onPallet = (await conn.QueryAsync<PalletModelRow>("""
                SELECT  s.model  AS [Model],
                        COUNT(*) AS [Qty]
                FROM    wms.return_instruction_serials s
                WHERE   s.doc_id    = @docId
                  AND   s.pallet_id = @palletId
                  AND   s.status    = N'received'
                  AND   s.is_deleted = 0
                GROUP BY s.model;
                """, new { docId, palletId }, tx)).ToList();

            foreach (var p in onPallet)
            {
                var need = needs.FirstOrDefault(n =>
                    string.Equals(n.Model, p.Model, StringComparison.OrdinalIgnoreCase));

                // Model không có trong đề nghị -> trần 0, cũng vào nhánh chặn.
                // Đúng: lần này FA không xin model đó.
                var shortQty = need?.Short ?? 0;

                if (p.Qty > shortQty)
                    return new ReturnBackMoveDelivered
                    {
                        TooMany = true,
                        TooManyModel = p.Model,
                        TooManyOnPallet = p.Qty,
                        TooManyNeed = shortQty,
                        Round = round,
                    };
            }
        }

        var moved = await conn.ExecuteAsync("""
            UPDATE s
            SET    s.status     = N'at_fa',
                   s.back_round = @round,
                   s.sent_fa_at = SYSDATETIME(),
                   s.updated_at = SYSDATETIME(),
                   s.updated_by = @user
            FROM   wms.return_instruction_serials s
            WHERE  s.doc_id    = @docId
              AND  s.pallet_id = @palletId
              AND  s.status    = N'received'
              AND  s.is_deleted = 0;
            """, new { docId, palletId, round, user }, tx);

        // Ghi nhật ký CẢ KHI moved = 0: sau này tra ra được là pallet đó đã ra
        // khu nhận hàng rồi mà nó không còn con nào của phiếu — khác hẳn với
        // "chưa đưa pallet nào ra".
        await conn.ExecuteAsync("""
            INSERT INTO wms.return_back_deliveries
                (doc_id, round, pallet_id, lot_no, serial_count, delivered_at, delivered_by)
            VALUES (@docId, @round, @palletId, @lotNo, @moved, SYSDATETIME(), @user);
            """, new { docId, round, palletId, lotNo, moved, user }, tx);

        // Còn con nào ở 'received' không — đếm theo PHIẾU. Đây là định nghĩa duy
        // nhất của "còn hàng chưa giao"; không có tổng nào lưu sẵn để lệch.
        var remain = await conn.ExecuteScalarAsync<int>("""
            SELECT COUNT(*)
            FROM   wms.return_instruction_serials s
            WHERE  s.doc_id = @docId AND s.status = N'received' AND s.is_deleted = 0;
            """, new { docId }, tx);

        // LẦN NÀY xong chưa:
        //   · có khai dòng  -> mọi dòng đã đủ SL đã xin;
        //   · không khai dòng (xin toàn bộ) -> chỉ xong khi kho hết hàng phiếu.
        //
        // Đây là thay đổi lớn của 12/11: trước đó lần đề nghị chỉ đóng khi KHO
        // HẾT HÀNG, nên FA xin một phần thì phiếu đứng mãi ở bước giao hàng và
        // không ai đề nghị tiếp được.
        var shortLines = needs.Count == 0 ? 0 : await conn.ExecuteScalarAsync<int>("""
            SELECT COUNT(*)
            FROM   wms.return_back_lines l
            OUTER APPLY (
                SELECT COUNT(*) AS qty
                FROM   wms.return_instruction_serials s
                WHERE  s.doc_id     = l.doc_id
                  AND  s.back_round = l.round
                  AND  s.model      = l.model
                  AND  s.is_deleted = 0
            ) d
            WHERE  l.doc_id = @docId AND l.round = @round
              AND  ISNULL(d.qty, 0) < l.req_qty;
            """, new { docId, round }, tx);

        var roundDone = needs.Count == 0 ? remain == 0 : shortLines == 0;

        if (roundDone || remain == 0)
        {
            await conn.ExecuteAsync("""
                UPDATE wms.return_instructions
                SET    back_status       = N'delivered',
                       back_delivered_by = @user,
                       back_delivered_at = SYSDATETIME(),
                       updated_at        = SYSDATETIME(),
                       updated_by        = @user
                WHERE  id = @docId;
                """, new { docId, user }, tx);

            // Chép mốc sang dòng LẦN NÀY ngay: lần sau mở ra sẽ xoá sạch các
            // cột back_*, không chép bây giờ là mất dấu "lần này ai giao, lúc
            // nào" và tiến trình con của lần này trống.
            await SyncRoundAsync(conn, tx, docId);
        }

        return new ReturnBackMoveDelivered
        {
            DeliveredQty = moved,
            RemainQty = remain,
            Completed = roundDone || remain == 0,
            Round = round,
        };
    }

    public async Task<IReadOnlyList<ReturnBackDelivery>> GetDeliveriesAsync(long docId)
    {
        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<ReturnBackDelivery>("""
            SELECT  d.id           AS [Id],
                    d.doc_id       AS [DocId],
                    d.pallet_id    AS [PalletId],
                    d.lot_no       AS [LotNo],
                    d.serial_count AS [SerialCount],
                    d.delivered_at AS [DeliveredAt],
                    d.delivered_by AS [DeliveredBy]
            FROM    wms.return_back_deliveries d
            WHERE   d.doc_id = @docId
            ORDER BY d.delivered_at DESC, d.id DESC;
            """, new { docId });
        return rows.ToList();
    }

    public async Task<IReadOnlyList<BackModelQty>> GetRemainByModelAsync(long docId)
    {
        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<BackModelQty>("""
            SELECT  s.model  AS [Model],
                    COUNT(*) AS [Qty]
            FROM    wms.return_instruction_serials s
            WHERE   s.doc_id = @docId AND s.status = N'received' AND s.is_deleted = 0
            GROUP BY s.model
            ORDER BY s.model;
            """, new { docId });
        return rows.ToList();
    }

    private sealed class HeadRow
    {
        public long Id { get; set; }
        public string? BackStatus { get; set; }
        public int BackRound { get; set; }
    }

    /// <summary>SL xin và SL đã giao của MỘT model trong RIÊNG lần đang mở.</summary>
    private sealed class NeedRow
    {
        public string Model { get; set; } = string.Empty;
        public int ReqQty { get; set; }
        public int DeliveredQty { get; set; }
        public int Short => ReqQty - DeliveredQty;
    }

    /// <summary>SL của một model đang nằm trên pallet sắp đưa ra khu nhận hàng.</summary>
    private sealed class PalletModelRow
    {
        public string Model { get; set; } = string.Empty;
        public int Qty { get; set; }
    }
}
