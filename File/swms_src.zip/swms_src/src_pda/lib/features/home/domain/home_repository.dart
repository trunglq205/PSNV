import 'package:swms_finish_goods/features/home/domain/home_entities.dart';
import 'package:swms_finish_goods/features/home/domain/scan_result.dart';

/// Hợp đồng repository Home — domain layer, không biết nguồn dữ liệu.
abstract interface class HomeRepository {
  /// Nạp danh sách "việc của tôi" (remote).
  Future<List<AssignmentData>> getAssignments();

  /// Nạp các key cụm đang ghim (local).
  Future<Set<String>> getPinnedGroups();

  /// Lưu các key cụm đang ghim (local).
  Future<void> savePinnedGroups(Set<String> keys);

  /// Phân loại mã vừa quét ở Home → loại đối tượng để mở đúng màn (remote).
  Future<ScanResult> resolveScan(String code);
}
