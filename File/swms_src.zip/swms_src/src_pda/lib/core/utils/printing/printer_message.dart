import 'package:swms_finish_goods/core/utils/printing/printer.dart';

/// Map lỗi máy in ra message cho người dùng.
///
/// Tập trung một chỗ để `appActionProvider` và các màn hình hiển thị giống
/// nhau. Khi có l10n thì đổi các literal ở đây sang LocaleKeys.
String printerMessage(Object error) => switch (error) {
      // Lỗi giữa lô — phải nói rõ đã ra mấy tờ, nếu không công nhân
      // sẽ in lại toàn bộ và ra thừa phiếu.
      PrinterBatchException(:final printed, :final total) when printed > 0 =>
        'Đã in $printed/$total phiếu rồi dừng. '
            'Bấm "Lưu lịch sử in" để ghi $printed phiếu đã ra, '
            'sau đó in tiếp phần còn lại.',
      PrinterException(type: PrinterErrorType.bluetoothOff) =>
        'Vui lòng bật Bluetooth',
      PrinterException(type: PrinterErrorType.permission) =>
        'Chưa cấp quyền Bluetooth cho ứng dụng',
      PrinterException(type: PrinterErrorType.noPrinter) => 'Chưa chọn máy in',
      PrinterException(type: PrinterErrorType.connect) =>
        'Không kết nối được máy in. Kiểm tra máy đã bật và trong tầm chưa.',
      PrinterException(type: PrinterErrorType.print) =>
        'Máy in không phản hồi. Kiểm tra giấy và nắp đầu in.',
      PrinterException(type: PrinterErrorType.invalidData) =>
        'Dữ liệu phiếu không hợp lệ',
      _ => 'Lỗi máy in không xác định',
    };
