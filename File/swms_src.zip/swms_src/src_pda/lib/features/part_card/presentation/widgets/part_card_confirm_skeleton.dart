import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/widgets/common/app_skeleton.dart';

/// Skeleton bước xác nhận — hiện trong lúc tải lịch sử in, bố cục khớp
/// [PartCardConfirmBody] (1 mã / nhiều mã) để chuyển sang form không bị giật.
class PartCardConfirmSkeleton extends StatelessWidget {
  const PartCardConfirmSkeleton({super.key, this.multi = false});

  final bool multi;

  /// Chiều cao ≈ 1 `_InfoCell` (padding 10 + label + 6 + value + 10).
  static const double _cell = 58;
  static const double _gap = 12;

  @override
  Widget build(BuildContext context) {
    return AppShimmer(
      child: ListView(
        physics: const NeverScrollableScrollPhysics(),
        children: [
          // Dải gợi ý hộp: padding 8 + tiêu đề ~14 + 6 + viên + padding 8
          const Bone(height: AppDimens.hitSm + 36, radius: AppDimens.rCard),
          const SizedBox(height: AppDimens.sm),
          _row(const [1, 1, 1], height: AppDimens.hitSm, gap: AppDimens.sm),
          const SizedBox(height: AppDimens.sm),

          // Header
          if (multi) ...[
            _row(const [1, 1]), // PSNV PO · CUS PO
            const SizedBox(height: _gap),
            _row(const [1, 1]), // Cate · MFD
          ] else ...[
            _row(const [2, 1]), // Model · Cate
            const SizedBox(height: _gap),
            _row(const [1]), // Quantity
          ],
          const SizedBox(height: _gap),

          // Length · Width · Height · Weight
          _row(const [1, 1, 1, 1], gap: 8),
          const SizedBox(height: _gap),

          if (multi) ...[
            const Bone(width: 110, height: 10),
            const SizedBox(height: AppDimens.sm),
            const Bone(height: 72, radius: AppDimens.rCard), // dòng mã
            const SizedBox(height: 8),
            const Bone(height: 36, radius: AppDimens.rInput), // Total
          ] else
            _row(const [1]), // Production Date
        ],
      ),
    );
  }

  static Widget _row(
      List<int> flexes, {
        double height = _cell,
        double gap = _gap,
      }) => Row(
    spacing: gap,
    children: [
      for (final f in flexes)
        Expanded(
          flex: f,
          child: Bone(height: height, radius: AppDimens.rInput),
        ),
    ],
  );
}