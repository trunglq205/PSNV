// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'update_return_card_pmd_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

UpdateReturnCardPmdRequestModel _$UpdateReturnCardPmdRequestModelFromJson(
        Map<String, dynamic> json) =>
    UpdateReturnCardPmdRequestModel(
      id: (json['id'] as num).toInt(),
      quantity: (json['quantity'] as num).toDouble(),
      unit: json['unit'] as String,
      userIDUpdate: json['userIDUpdate'] as String,
      statusRecycle: json['statusRecycle'] as String,
    );

Map<String, dynamic> _$UpdateReturnCardPmdRequestModelToJson(
        UpdateReturnCardPmdRequestModel instance) =>
    <String, dynamic>{
      'id': instance.id,
      'quantity': instance.quantity,
      'unit': instance.unit,
      'userIDUpdate': instance.userIDUpdate,
      'statusRecycle': instance.statusRecycle,
    };
