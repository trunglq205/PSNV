using Microsoft.AspNetCore.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Authorization;

namespace Swms.FinishGoods.API.Features.Roles;

public static class PermissionAuthorizationModule
{
    /// <summary>
    /// Đăng ký toàn bộ hạ tầng phân quyền theo permission.
    /// Chọn 1 trong 2 chiến lược nguồn quyền qua tham số <paramref name="useJwtClaims"/>.
    ///
    /// Cả 2 chiến lược đều hỗ trợ API key: principal của API key mang quyền trong
    /// claim "perm" nên luôn đọc được qua ClaimsUserPermissionProvider.
    /// </summary>
    public static IServiceCollection AddPermissionAuthorization(
        this IServiceCollection services, bool useJwtClaims = false)
    {
        services.AddMemoryCache();

        // SINGLETON, không Scoped: số phiên bản phải sống qua mọi request thì
        // việc tăng nó ở request sửa quyền mới vô hiệu được bộ đệm của các
        // request sau. Đăng ký ở đây chứ không trong nhánh if: RoleService tăng
        // số này không cần biết đang dùng chiến lược nguồn quyền nào.
        services.AddSingleton<PermissionCacheVersion>();

        services.AddSingleton<IAuthorizationPolicyProvider, PermissionPolicyProvider>();
        services.AddScoped<IAuthorizationHandler, PermissionAuthorizationHandler>();
        services.AddSingleton<IAuthorizationMiddlewareResultHandler, PermissionAuthorizationResultHandler>();

        if (useJwtClaims)
        {
            // Quyền nằm trong claim cho cả user JWT lẫn API key -> dùng thẳng Claims provider.
            services.AddScoped<IUserPermissionProvider, ClaimsUserPermissionProvider>();
        }
        else
        {
            // User thường: quyền từ DB (cache). API key: quyền từ claim.
            // Composite route theo claim "auth_method".
            services.AddScoped<ClaimsUserPermissionProvider>();
            services.AddScoped<DbCachedUserPermissionProvider>();
            services.AddScoped<IUserPermissionProvider, CompositeUserPermissionProvider>();
        }

        return services;
    }
}