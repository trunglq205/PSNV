import 'dart:io';

import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';

/// Lưới chụp và xem ảnh đính kèm — dùng chung cho mọi tính năng cần ảnh
/// (hàng bất thường, kiểm kê, hư hỏng kệ…).
///
/// Widget KHÔNG tự sửa danh sách và KHÔNG tự tải lên: nó báo thay đổi qua
/// [onChanged], việc gửi lên server do màn gọi tự lo vì mỗi tính năng có
/// endpoint riêng.
///
/// ```dart
/// AppPhotoGrid(
///   photos: _photos,
///   onChanged: (list) => setState(() => _photos = list),
/// )
/// ```
class AppPhotoGrid extends StatelessWidget {
  /// Ảnh đang có trên máy.
  final List<File> photos;

  /// Gọi khi thêm hoặc bớt ảnh. Trả về danh sách MỚI, không sửa tại chỗ.
  final ValueChanged<List<File>> onChanged;

  /// Số ảnh tối đa; đạt ngưỡng thì ẩn nút chụp.
  final int maxPhotos;

  /// Cạnh mỗi ô ảnh. Mặc định 88 — vừa ngón tay có găng.
  final double tileSize;

  /// Cho chọn từ thư viện, không chỉ chụp mới.
  final bool allowGallery;

  /// Khoá thao tác: đang gửi, hoặc phiếu đã chốt.
  final bool readOnly;

  /// Nhãn trong hộp chọn nguồn ảnh. Để màn gọi truyền chuỗi đã dịch.
  final String cameraLabel;
  final String galleryLabel;

  const AppPhotoGrid({
    super.key,
    required this.photos,
    required this.onChanged,
    this.maxPhotos = 5,
    this.tileSize = 88,
    this.allowGallery = true,
    this.readOnly = false,
    this.cameraLabel = 'Chụp ảnh',
    this.galleryLabel = 'Chọn từ thư viện',
  });

  Future<void> _add(BuildContext context) async {
    if (photos.length >= maxPhotos) return;

    final source = allowGallery ? await _pickSource(context) : ImageSource.camera;
    if (source == null) return;

    // Giảm kích thước ngay trên máy: mạng kho yếu, ảnh 12MP tải rất lâu.
    // Server vẫn nén thêm 1 lần khi lưu.
    final shot = await ImagePicker().pickImage(
      source: source,
      maxWidth: 3000,
      imageQuality: 90,
    );
    if (shot == null) return;

    onChanged([...photos, File(shot.path)]);
  }

  Future<ImageSource?> _pickSource(BuildContext context) {
    final swms = context.swms;
    return showModalBottomSheet<ImageSource>(
      context: context,
      backgroundColor: swms.card,
      builder: (ctx) => SafeArea(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ListTile(
              leading: Icon(Icons.photo_camera_outlined, color: swms.primary),
              title: Text(cameraLabel),
              onTap: () => Navigator.pop(ctx, ImageSource.camera),
            ),
            ListTile(
              leading: Icon(Icons.photo_library_outlined, color: swms.primary),
              title: Text(galleryLabel),
              onTap: () => Navigator.pop(ctx, ImageSource.gallery),
            ),
          ],
        ),
      ),
    );
  }

  void _remove(int index) => onChanged([...photos]..removeAt(index));

  void _preview(BuildContext context, File file) => showDialog<void>(
        context: context,
        builder: (_) => Dialog(
          insetPadding: const EdgeInsets.all(12),
          backgroundColor: Colors.transparent,
          child: InteractiveViewer(child: Image.file(file)),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: [
        ...photos.asMap().entries.map(
              (e) => Stack(
                children: [
                  InkWell(
                    onTap: () => _preview(context, e.value),
                    borderRadius: BorderRadius.circular(8),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: Image.file(
                        e.value,
                        width: tileSize,
                        height: tileSize,
                        fit: BoxFit.cover,
                      ),
                    ),
                  ),
                  if (!readOnly)
                    Positioned(
                      right: 0,
                      top: 0,
                      child: InkWell(
                        onTap: () => _remove(e.key),
                        child: Container(
                          padding: const EdgeInsets.all(3),
                          decoration: const BoxDecoration(
                            color: Colors.black54,
                            shape: BoxShape.circle,
                          ),
                          child: const Icon(Icons.close, size: 14, color: Colors.white),
                        ),
                      ),
                    ),
                ],
              ),
            ),
        if (!readOnly && photos.length < maxPhotos)
          InkWell(
            onTap: () => _add(context),
            borderRadius: BorderRadius.circular(8),
            child: Container(
              width: tileSize,
              height: tileSize,
              decoration: BoxDecoration(
                color: swms.card2,
                border: Border.all(color: swms.border),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Icon(Icons.photo_camera_outlined, color: swms.text3),
            ),
          ),
      ],
    );
  }
}
