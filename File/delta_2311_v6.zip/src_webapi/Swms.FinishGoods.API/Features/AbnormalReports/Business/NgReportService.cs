using System.Globalization;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.AbnormalReports.Api;
using Swms.FinishGoods.API.Features.AbnormalReports.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.Business.Media;
using Swms.FinishGoods.API.Shared.Reporting;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.AbnormalReports.Business;

public class NgReportService : INgReportService
{
    /// <summary>Số ảnh tối đa mỗi phiếu.</summary>
    private const int MaxPhotos = 5;
    /// <summary>Dung lượng tối đa 1 ảnh nhận từ máy ảnh (byte).</summary>
    private const long MaxPhotoBytes = 25L * 1024 * 1024;

    /// <summary>
    /// Định dạng ngày-giờ của mọi ô ngày trong file Excel xuất ra. Là định dạng
    /// của Ô, không phải chuỗi: giá trị trong ô vẫn là ngày nên lọc, sắp xếp
    /// và tính khoảng cách ngày trong Excel đều chạy.
    /// </summary>
    private const string DateTimeFmt = "dd/MM/yyyy HH:mm";

    private static readonly string[] Resolutions = { "replace", "accept", "return", "scrap" };
    private static readonly string[] Scopes = { "pallet", "box", "serial" };

    /// <summary>
    /// Mã sự kiện mail, đã có sẵn trong master.email_events với module
    /// 'RECEIVING' và name_key 'email.RECEIVING_ABNORMAL' (đã có bản dịch 4
    /// ngôn ngữ). Dùng lại event này chứ KHÔNG khai event mới: nếu tạo thêm
    /// một event gần trùng ý thì màn Cấu hình email hiện hai dòng trông như
    /// nhau, người cấu hình người nhận không biết chọn dòng nào.
    /// </summary>
    private const string MailEventAbnormal = "RECEIVING_ABNORMAL";

    private readonly INgReportRepository _repo;
    private readonly IImageStorage _storage;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly IMailSender _mail;
    private readonly IExcelReportBuilder _excel;
    private readonly ILogger<NgReportService> _logger;

    /// <summary>
    /// Địa chỉ gốc của web, khai ở appsettings: <c>"Web": { "BaseUrl": "..." }</c>.
    /// Dùng để dựng link mở thẳng phiếu trong mail. Không khai thì chỗ giữ
    /// {Link} thành rỗng — mail vẫn gửi, chỉ mất nút bấm.
    /// </summary>
    private readonly string? _webBaseUrl;

    public NgReportService(
        INgReportRepository repo,
        IImageStorage storage,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        IMailSender mail,
        IExcelReportBuilder excel,
        IConfiguration config,
        ILogger<NgReportService> logger)
    {
        _repo = repo;
        _storage = storage;
        _currentUser = currentUser;
        _localizer = localizer;
        _mail = mail;
        _excel = excel;
        _logger = logger;
        _webBaseUrl = config["Web:BaseUrl"]?.Trim().TrimEnd('/');
    }

    /// <summary>Tên hiển thị, ghi vào *_by để hiện ra giao diện.</summary>
    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    /// <summary>Mã nhân viên — duy nhất, dùng để SO SÁNH người, không để hiện.</summary>
    private string? ActorCode => _currentUser.EmployeeCode;

    /// <summary>
    /// Loại lỗi cho danh sách thả xuống của Web và PDA, nhãn đã theo ngôn ngữ
    /// người gọi. Giải nghĩa ở phía server chứ không trả cả 4 cột tên: hai
    /// client khỏi phải tự chọn cột, và quy tắc lùi về tiếng Việt khi thiếu
    /// bản dịch chỉ viết một lần.
    /// </summary>
    public async Task<IReadOnlyList<NgTypeResponse>> GetTypesAsync()
    {
        var lang = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
        return (await _repo.GetTypesAsync())
            .Select(t => new NgTypeResponse(
                t.Code, t.NameFor(lang), t.NoteFor(lang), t.RequiresOqc))
            .ToList();
    }

    /// <summary>
    /// Danh mục cho màn QUẢN TRỊ: trả thô cả 4 ngôn ngữ, không dịch sẵn như
    /// <see cref="GetTypesAsync"/> — người quản trị phải sửa được từng bản dịch.
    /// </summary>
    public async Task<IReadOnlyList<NgTypeAdminResponse>> GetTypesForAdminAsync()
        => (await _repo.GetTypesForAdminAsync())
            .Select(t => new NgTypeAdminResponse(
                t.Code, t.NameVi, t.NameEn, t.NameJa, t.NameZh,
                t.NoteVi, t.NoteEn, t.NoteJa, t.NoteZh,
                t.RequiresOqc, t.SortOrder, t.IsActive, t.UsedByReports))
            .ToList();

    public async Task SaveTypeAsync(SaveNgTypeRequest r)
    {
        // Chuẩn hoá mã về chữ thường: mọi mã đang có đều viết thường, mà
        // collation của cột là CI nên "Packaging" và "packaging" đụng nhau ở
        // khoá chính. Chuẩn hoá sớm thì người dùng nhận lỗi rõ ràng, không phải
        // một lỗi khoá chính khó hiểu từ SQL Server.
        var code = (r.Code ?? "").Trim().ToLowerInvariant();
        if (code.Length == 0)
            throw new BusinessRuleException(_localizer["Ng.Err.TypeCodeRequired"]);

        var nameVi = (r.NameVi ?? "").Trim();
        if (nameVi.Length == 0)
            throw new BusinessRuleException(_localizer["Ng.Err.TypeNameRequired"]);

        await _repo.UpsertTypeAsync(new NgTypeRow
        {
            Code = code,
            NameVi = nameVi,
            NameEn = Blank(r.NameEn),
            NameJa = Blank(r.NameJa),
            NameZh = Blank(r.NameZh),
            NoteVi = Blank(r.NoteVi),
            NoteEn = Blank(r.NoteEn),
            NoteJa = Blank(r.NoteJa),
            NoteZh = Blank(r.NoteZh),
            RequiresOqc = r.RequiresOqc,
            SortOrder = r.SortOrder,
            IsActive = r.IsActive,
        }, Actor);
    }

    /// <summary>
    /// Xoá một loại lỗi. CHẶN nếu còn phiếu đang mang mã đó: xoá đi thì những
    /// phiếu cũ mất tên loại lỗi, chỉ còn trơ lại cái mã. Muốn ngưng dùng thì
    /// tắt (is_active = 0) — loại đã tắt không hiện cho người lập phiếu nữa
    /// nhưng phiếu cũ vẫn đọc được tên.
    /// </summary>
    public async Task DeleteTypeAsync(string code)
    {
        code = (code ?? "").Trim().ToLowerInvariant();

        var used = await _repo.CountReportsOfTypeAsync(code);
        if (used > 0)
            throw new BusinessRuleException(_localizer["Ng.Err.TypeInUse", code, used]);

        if (!await _repo.SoftDeleteTypeAsync(code, Actor))
            throw new NotFoundException(_localizer["Ng.Err.TypeNotFound", code]);
    }

    /// <summary>Ô để trống lưu thành NULL, không phải chuỗi rỗng.</summary>
    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    /// <summary>
    /// Mã loại lỗi có dùng được không. Đọc thẳng bảng mỗi lần thay vì nhớ đệm:
    /// tạo và sửa phiếu không phải thao tác dày, mà nhớ đệm thì thêm một loại
    /// lỗi xong phải khởi động lại API mới thấy — đúng thứ vừa bỏ đi.
    /// </summary>
    private async Task<bool> IsValidTypeAsync(string code)
        => !string.IsNullOrWhiteSpace(code)
           && (await _repo.GetTypesAsync()).Any(t => t.Code == code);

    public async Task<IReadOnlyList<NgReportSummaryResponse>> GetListAsync(
        string? status, string? ngType, DateTime? from, DateTime? to, string? keyword)
    {
        var rows = await _repo.GetListAsync(status, ngType, from, to, keyword);
        return rows.Select(NgReportSummaryResponse.From).ToList();
    }

    // ===================== XUẤT EXCEL DANH SÁCH =====================
    // Một phiếu một dòng, KHÔNG bung mục phạm vi và ảnh thành dòng con: file
    // này để theo dõi cả rổ phiếu (ai đang giữ, kết luận ra sao), xem chi tiết
    // từng phiếu thì mở phiếu. Bù lại mỗi dòng mang đủ mọi mốc của 5 bước nên
    // không phải mở phiếu mới biết nó đang tắc ở đâu.

    private sealed record NgListRow(
        int LineNo, string DocNo, DateTime DiscoveredAt,
        string? PalletCode, string? Model, string? Category, string TypeName,
        string Scope, int QtyAffected, int PhotoCount, string? Description,
        string Status, string Step,
        string? CreatedBy, DateTime? CreatedAt,
        string? LeaderBy, DateTime? LeaderAt,
        string OqcStatus, string? OqcBy, DateTime? OqcAt,
        string FaResolution, string? FaBy, DateTime? FaAt,
        string Resolution, string? FinalizedBy, DateTime? FinalizedAt,
        string? CancelReason);

    public async Task<(byte[] Bytes, string FileName)> BuildListReportAsync(
        string? status, string? ngType, DateTime? from, DateTime? to, string? keyword,
        string? faRes = null, string? oqc = null, string? finalRes = null)
    {
        // ĐÚNG hàm mà màn danh sách đang gọi, cùng bộ lọc ⟹ file xuất ra khớp
        // với những gì người dùng đang xem, không phải một tập khác.
        IEnumerable<NgReport> q = await _repo.GetListAsync(status, ngType, from, to, keyword);

        // 3 bộ lọc dưới đây màn hình lọc tại trình duyệt, nên server phải lọc
        // lại y hệt. GIỮ ĐỒNG BỘ với AbnormalReport.razor.cs > ApplyStatus():
        // sửa một bên mà quên bên kia là file lệch với màn hình.
        if (!string.IsNullOrWhiteSpace(faRes))
            // "pending" ở ô FA nghĩa là FA CHƯA duyệt — xét fa_status, không
            // xét fa_resolution: phiếu FA chưa duyệt có fa_resolution NULL chứ
            // không phải chuỗi 'pending', so bằng resolution sẽ ra rỗng.
            q = faRes == "pending"
                ? q.Where(x => x.FaStatus != "approved")
                : q.Where(x => x.FaResolution == faRes);

        if (!string.IsNullOrWhiteSpace(oqc)) q = q.Where(x => x.OqcStatus == oqc);
        if (!string.IsNullOrWhiteSpace(finalRes)) q = q.Where(x => x.Resolution == finalRes);

        var rows = q.ToList();

        var lang = CultureInfo.CurrentUICulture.TwoLetterISOLanguageName;
        string L(string key) => _localizer[key];

        // Nhãn theo mã trong DB. Thiếu bản dịch thì hiện MÃ THÔ chứ không hiện
        // tên khoá: thêm một trạng thái mới ở DB mà quên thêm nhãn thì ô đó ra
        // "in_review", đọc được; ra "Ng.Status.in_review" thì không.
        string Label(string prefix, string? value)
        {
            if (string.IsNullOrWhiteSpace(value)) return string.Empty;
            var s = _localizer[prefix + value];
            return s.ResourceNotFound ? value : s.Value;
        }

        // Tên loại lỗi lấy cả loại ĐÃ TẮT (GetTypesForAdminAsync không lọc
        // is_active): phiếu cũ mang loại nay đã ngưng vẫn phải đọc ra tên, chứ
        // không tụt về mã thô chỉ vì loại đó không còn cho lập phiếu mới.
        var types = (await _repo.GetTypesForAdminAsync())
            .GroupBy(t => t.Code, StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First().NameFor(lang), StringComparer.OrdinalIgnoreCase);
        string TypeName(string code) =>
            !string.IsNullOrWhiteSpace(code) && types.TryGetValue(code, out var n) ? n : code;

        var data = rows.Select((n, i) => new NgListRow(
            i + 1, n.DocNo, n.DiscoveredAt,
            n.PalletCode, n.Model,
            // TÊN danh mục (master.categories.name), KHÔNG phải mã. Chỉ lùi về
            // mã khi mã cate của pallet chưa khai trong master.categories —
            // lúc đó ô để trống còn tệ hơn, người đọc không biết là chưa khai
            // hay là chưa tải xong. Đúng quy tắc màn chi tiết đang dùng: hiện
            // nhãn, còn mã nằm ở tooltip.
            Blank(n.CategoryName) ?? Blank(n.CategoryCode),
            TypeName(n.NgType),
            // "Cả pallet" thay vì "1 cái": phiếu lỗi cả pallet có mỗi mục
            // qty_affected = 1 nên con số đó vô nghĩa, in ra làm người đọc
            // tưởng chỉ 1 sản phẩm bị lỗi.
            n.IsWholePallet ? L("Ng.Rep.WholePallet")
                            : string.Format(L("Ng.Rep.ItemsN"), n.ItemCount),
            n.QtyAffected, n.PhotoCount, Blank(n.Description),
            Label("Ng.Status.", n.DocStatus),
            Label("Ng.Step.", n.CurrentStep),
            Blank(n.CreatedBy), n.CreatedAt,
            Blank(n.LeaderBy), n.LeaderAt,
            Label("Ng.Oqc.", n.OqcStatus), Blank(n.OqcBy), n.OqcAt,
            Label("Ng.Res.", n.FaResolution), Blank(n.FaBy), n.FaAt,
            Label("Ng.Res.", n.Resolution), Blank(n.FinalizedBy), n.FinalizedAt,
            Blank(n.CancelReason))).ToList();

        var all = L("Ng.Rep.FilterAll");
        string D(DateTime? d) => d?.ToString("dd/MM/yyyy") ?? all;

        // Nhãn của MỘT Ô LỌC: bỏ trống = "Tất cả", "pending" = "Chờ", còn lại
        // tra nhãn theo nhóm của ô đó.
        string Pick(string? v, Func<string, string> label) =>
            string.IsNullOrWhiteSpace(v) ? all
            : v == "pending" ? L("Ng.Rep.FilterWaiting")
            : label(v);

        var report = new ExcelTableReport<NgListRow>
        {
            SheetName = L("Ng.Rep.Sheet"),
            Title = L("Ng.Rep.Title"),
            // In lại bộ lọc: không có dòng này thì mở file ra một tuần sau
            // không ai biết nó là cả năm hay chỉ một tuần, đã lọc trạng thái gì.
            Meta = new List<(string, string)>
            {
                (L("Ng.Status"),          string.IsNullOrWhiteSpace(status) ? all : Label("Ng.Status.", status)),
                (L("Ng.Type"),            string.IsNullOrWhiteSpace(ngType) ? all : TypeName(ngType)),
                (L("Ng.Rep.FilterRange"), $"{D(from)} — {D(to)}"),
                (L("Ng.Rep.FilterKey"),   Blank(keyword) ?? all),
                // "pending" ở 3 ô này là "chưa xong", không phải một hướng xử
                // lý tên là pending — nên nhãn riêng chứ không tra Ng.Res.
                (L("Ng.Rep.FaResolution"), Pick(faRes,    v => Label("Ng.Res.", v))),
                (L("Ng.Rep.OqcResult"),    Pick(oqc,      v => Label("Ng.Oqc.", v))),
                (L("Ng.Resolution"),       Pick(finalRes, v => Label("Ng.Res.", v))),
                (L("Ng.Rep.ExportedAt"),  DateTime.Now.ToString("dd/MM/yyyy HH:mm")),
                (L("Ng.Rep.ExportedBy"),  Actor ?? string.Empty),
            },
            Summary = new List<(string, string)>
            {
                (L("Ng.Rep.TotalDocs"), data.Count.ToString(CultureInfo.InvariantCulture)),
                (L("Ng.Status.draft"),      rows.Count(x => x.DocStatus == "draft").ToString(CultureInfo.InvariantCulture)),
                (L("Ng.Status.in_review"),  rows.Count(x => x.DocStatus == "in_review").ToString(CultureInfo.InvariantCulture)),
                (L("Ng.Status.ready_to_finalize"), rows.Count(x => x.DocStatus == "ready_to_finalize").ToString(CultureInfo.InvariantCulture)),
                (L("Ng.Status.finalized"),  rows.Count(x => x.DocStatus == "finalized").ToString(CultureInfo.InvariantCulture)),
                (L("Ng.Status.cancelled"),  rows.Count(x => x.DocStatus == "cancelled").ToString(CultureInfo.InvariantCulture)),
                (L("Ng.Rep.TotalQty"),  rows.Sum(x => x.QtyAffected).ToString(CultureInfo.InvariantCulture)),
            },
            // Ngày giữ KIỂU NGÀY (không đổi thành chuỗi) để lọc và sắp xếp
            // trong Excel chạy đúng; chuỗi "dd/MM" sẽ sắp theo chữ cái.
            Columns = new List<ReportColumn<NgListRow>>
            {
                new() { Header = L("Ng.Rep.No"), Value = r => r.LineNo, Numeric = true, Width = 5 },
                new() { Header = L("Ng.DocNo"), Value = r => r.DocNo, Width = 16 },
                new() { Header = L("Ng.DiscoveredAt"), Value = r => r.DiscoveredAt, NumberFormat = DateTimeFmt, Width = 15 },
                new() { Header = L("Ng.Rep.Pallet"), Value = r => r.PalletCode, Width = 16 },
                new() { Header = L("Ng.Rep.Model"), Value = r => r.Model, Width = 18 },
                new() { Header = L("Ng.Rep.Category"), Value = r => r.Category, Width = 20 },
                new() { Header = L("Ng.Type"), Value = r => r.TypeName, Width = 18 },
                new() { Header = L("Ng.Rep.Scope"), Value = r => r.Scope, Width = 12 },
                new() { Header = L("Ng.Rep.QtyAffected"), Value = r => r.QtyAffected, Numeric = true, Width = 9 },
                new() { Header = L("Ng.Rep.PhotoCount"), Value = r => r.PhotoCount, Numeric = true, Width = 7 },
                new() { Header = L("Ng.Rep.Description"), Value = r => r.Description, Width = 40 },
                new() { Header = L("Ng.Status"), Value = r => r.Status, Width = 13 },
                new() { Header = L("Ng.Rep.CurrentStep"), Value = r => r.Step, Width = 22 },
                new() { Header = L("Ng.Rep.CreatedBy"), Value = r => r.CreatedBy, Width = 16 },
                new() { Header = L("Ng.Rep.CreatedAt"), Value = r => r.CreatedAt, NumberFormat = DateTimeFmt, Width = 15 },
                new() { Header = L("Ng.Rep.LeaderBy"), Value = r => r.LeaderBy, Width = 16 },
                new() { Header = L("Ng.Rep.LeaderAt"), Value = r => r.LeaderAt, NumberFormat = DateTimeFmt, Width = 15 },
                new() { Header = L("Ng.Rep.OqcResult"), Value = r => r.OqcStatus, Width = 13 },
                new() { Header = L("Ng.Rep.OqcBy"), Value = r => r.OqcBy, Width = 16 },
                new() { Header = L("Ng.Rep.OqcAt"), Value = r => r.OqcAt, NumberFormat = DateTimeFmt, Width = 15 },
                new() { Header = L("Ng.Rep.FaResolution"), Value = r => r.FaResolution, Width = 13 },
                new() { Header = L("Ng.Rep.FaBy"), Value = r => r.FaBy, Width = 16 },
                new() { Header = L("Ng.Rep.FaAt"), Value = r => r.FaAt, NumberFormat = DateTimeFmt, Width = 15 },
                new() { Header = L("Ng.Resolution"), Value = r => r.Resolution, Width = 13 },
                new() { Header = L("Ng.Rep.FinalizedBy"), Value = r => r.FinalizedBy, Width = 16 },
                new() { Header = L("Ng.Rep.FinalizedAt"), Value = r => r.FinalizedAt, NumberFormat = DateTimeFmt, Width = 15 },
                new() { Header = L("Ng.Rep.CancelReason"), Value = r => r.CancelReason, Width = 28 },
            },
            Rows = data,
            // Ghim STT + Số phiếu: bảng 27 cột, cuộn sang cột Ngày chốt mà mất
            // số phiếu thì không biết đang đọc dòng của phiếu nào.
            FreezeColumns = 2,
        };

        // Tên file mang mốc thời gian: người dùng xuất nhiều lần trong ngày,
        // trùng tên là file sau ghi đè file trước trong thư mục Tải về.
        var name = $"{L("Ng.Rep.FilePrefix")}_{DateTime.Now:yyyyMMdd_HHmm}.xlsx";
        return (_excel.BuildTable(report), name);
    }

    public async Task<NgReportDetailResponse> GetAsync(long id)
    {
        var d = await _repo.GetAsync(id) ?? throw NotFound();
        return NgReportDetailResponse.From(d, ActorCode);
    }

    public async Task<NgPalletCheckResponse> CheckPalletAsync(string palletCode)
    {
        var code = (palletCode ?? string.Empty).Trim();
        if (code.Length == 0)
            throw new BusinessRuleException(_localizer["Ng.Err.PalletRequired"]);

        var brief = await _repo.FindPalletBriefAsync(code)
                    ?? throw new NotFoundException(_localizer["Ng.Err.PalletNotFound", code]);

        return NgPalletCheckResponse.From(brief);
    }

    public async Task<CreateNgReportResponse> CreateAsync(CreateNgReportRequest request)
    {
        var palletCode = (request.PalletCode ?? string.Empty).Trim();
        if (palletCode.Length == 0)
            throw new BusinessRuleException(_localizer["Ng.Err.PalletRequired"]);

        var ngType = (request.NgType ?? string.Empty).Trim();
        if (!await IsValidTypeAsync(ngType))
            throw new BusinessRuleException(_localizer["Ng.Err.TypeInvalid"]);

        var lotId = await _repo.FindPalletAsync(palletCode)
                    ?? throw new NotFoundException(_localizer["Ng.Err.PalletNotFound", palletCode]);

        // Cả pallet thì khỏi quét lại, lấy luôn pallet của phiếu.
        // Box và serial bắt buộc có mã đã quét.
        var items = BuildItems(request.Items, lotId, palletCode);

        var header = new NgReport
        {
            LotId = lotId,
            NgType = ngType,
            Description = request.Description,
            DiscoveredAt = DateTime.Now
        };

        var (id, docNo) = await _repo.CreateAsync(header, items, Actor);
        return new CreateNgReportResponse(id, docNo);
    }

    public async Task UpdateAsync(long id, UpdateNgReportRequest request)
    {
        var header = await _repo.GetHeaderAsync(id) ?? throw NotFound();
        if (header.DocStatus != "draft")
            throw new BusinessRuleException(_localizer["Ng.Err.EditLocked"]);

        var ngType = (request.NgType ?? string.Empty).Trim();
        if (!await IsValidTypeAsync(ngType))
            throw new BusinessRuleException(_localizer["Ng.Err.TypeInvalid"]);

        var items = BuildItems(request.Items, header.LotId, header.PalletCode);

        var ok = await _repo.UpdateDraftAsync(id, ngType, request.Description, items, Actor);
        if (!ok) throw new BusinessRuleException(_localizer["Ng.Err.EditLocked"]);
    }

    public async Task DeletePhotoAsync(long photoId)
    {
        var ok = await _repo.DeletePhotoAsync(photoId, Actor);
        if (!ok) throw new BusinessRuleException(_localizer["Ng.Err.EditLocked"]);
    }

    /// <summary>Dựng danh sách phạm vi ảnh hưởng dùng chung cho tạo mới và sửa.</summary>
    private List<NgItem> BuildItems(List<CreateNgItemRequest>? raw, long? lotId, string? palletCode)
    {
        var items = (raw ?? new List<CreateNgItemRequest>())
            .Where(i => i is not null)
            .Select(i => new NgItem
            {
                Scope = (i.Scope ?? string.Empty).Trim(),
                Code = i.Code?.Trim(),
                QtyAffected = i.QtyAffected is > 0 ? i.QtyAffected.Value : 1,
                Note = i.Note
            })
            .ToList();

        if (items.Count == 0)
            throw new BusinessRuleException(_localizer["Ng.Err.ItemRequired"]);
        if (items.Any(i => !Scopes.Contains(i.Scope)))
            throw new BusinessRuleException(_localizer["Ng.Err.ScopeInvalid"]);

        foreach (var it in items)
        {
            if (it.Scope == "pallet") { it.PalletId = lotId; it.Code ??= palletCode; }
            else if (string.IsNullOrWhiteSpace(it.Code))
                throw new BusinessRuleException(_localizer["Ng.Err.ItemCodeRequired"]);
        }

        return items;
    }

    public async Task<long> AddPhotoAsync(long id, Stream content, string fileName, long length)
    {
        var header = await _repo.GetHeaderAsync(id) ?? throw NotFound();
        if (header.DocStatus is not ("draft" or "submitted" or "in_review"))
            throw new BusinessRuleException(_localizer["Ng.Err.PhotoLocked"]);

        if (length <= 0 || length > MaxPhotoBytes)
            throw new BusinessRuleException(_localizer["Ng.Err.PhotoTooLarge"]);

        var count = await _repo.CountPhotosAsync(id);
        if (count >= MaxPhotos)
            throw new BusinessRuleException(_localizer["Ng.Err.PhotoLimit", MaxPhotos]);

        StoredImage saved;
        try
        {
            // "ng" là thư mục riêng của tính năng trong kho ảnh chung
            saved = await _storage.SaveAsync(content, "ng", header.DocNo, fileName);
        }
        catch (NotAnImageException)
        {
            // File không phải ảnh, hoặc ảnh hỏng/dựng sẵn để phá bộ giải mã.
            throw new BusinessRuleException(_localizer["Ng.Err.NotAnImage"]);
        }
        await _repo.AddPhotoAsync(new NgPhoto
        {
            NgId = id,
            FilePath = saved.RelativePath,
            FileName = saved.FileName,
            ContentType = saved.ContentType,
            SizeBytes = saved.SizeBytes
        }, Actor);

        return id;
    }

    public async Task<(Stream Content, string ContentType, string FileName)> GetPhotoAsync(long photoId, string size)
    {
        // Hai nguyên nhân khác nhau phải có hai câu khác nhau: trước đây cùng
        // dùng Ng.Err.PhotoNotFound nên không biết là THIẾU DÒNG trong DB hay
        // THIẾU FILE trên ổ đĩa.
        var photo = await _repo.GetPhotoAsync(photoId)
                    ?? throw new NotFoundException(_localizer["Ng.Err.PhotoRowMissing", photoId]);

        var resolved = _storage.Resolve(photo.FilePath, size)
                       ?? throw new NotFoundException(
                              _localizer["Ng.Err.PhotoFileMissing", photo.FilePath, _storage.Root]);

        return (File.OpenRead(resolved.FullPath), resolved.ContentType, photo.FileName);
    }

    // ---------- Các bước duyệt ----------

    /// <summary>
    /// Bước 2 sẽ gửi mail cho ai. Dùng ĐÚNG hai lệnh tra mà
    /// <see cref="NotifyLeaderApprovedAsync"/> dùng — nếu xem trước và lúc gửi
    /// đi theo hai đường khác nhau thì sớm muộn chúng lệch nhau, và màn xem
    /// trước còn tệ hơn không có vì nó khiến người ta tin nhầm.
    ///
    /// Chỉ ĐỌC, không ghi gì: gọi lúc mở hộp xác nhận, người dùng bấm Huỷ cũng
    /// không để lại dấu vết nào.
    /// </summary>
    public async Task<MailPreviewResponse> GetMailPreviewAsync(long id)
    {
        var h = await _repo.GetHeaderAsync(id) ?? throw NotFound();

        var tpl = await _repo.GetMailTemplateAsync(MailEventAbnormal);
        var templateReady = tpl is not null
                            && !string.IsNullOrWhiteSpace(tpl.Subject)
                            && !string.IsNullOrWhiteSpace(tpl.Body);

        var recipients = await ResolveRecipientsAsync(h);

        return new MailPreviewResponse(
            h.CategoryCode,
            h.CategoryName,
            h.Model,
            _mail.Enabled,
            templateReady,
            recipients
                .Select(r => new MailPreviewRecipient(r.Type, r.Email, r.DisplayName))
                .ToList());
    }

    public async Task LeaderReviewAsync(long id, LeaderReviewRequest request)
    {
        var h = await _repo.GetHeaderAsync(id) ?? throw NotFound();
        if (h.DocStatus != "draft")
            throw new BusinessRuleException(_localizer["Ng.Err.NotWaitingLeader"]);

        var action = (request.Action ?? string.Empty).Trim();
        if (action is not ("submit" or "cancel"))
            throw new BusinessRuleException(_localizer["Ng.Err.ActionInvalid"]);
        if (action == "cancel" && string.IsNullOrWhiteSpace(request.Comment))
            throw new BusinessRuleException(_localizer["Ng.Err.CancelReasonRequired"]);

        // Model không cần OQC thì chốt NGAY tại đây: phiếu ghi oqc_status =
        // 'skipped' và nhảy thẳng sang bước FA. Không tra lại lúc hiển thị, để
        // phiếu giữ đúng lịch sử khi quy tắc đổi về sau.
        var skipOqc = action == "submit" && !await RequiresOqcAsync(h);

        await _repo.ApplyStepAsync(id, "leader", action, null, request.Comment, Actor, ActorCode, skipOqc);

        // Duyệt xong mới thông báo. Huỷ phiếu thì không gửi cho ai.
        if (action == "submit")
            await NotifyLeaderApprovedAsync(h);
    }

    /// <summary>
    /// Bước 2 xong -> mail cho OQC và FA CÙNG LÚC. Hai bên tự trao đổi, nhưng
    /// OQC vẫn phải là người duyệt trước (service chặn ở FaConfirmAsync).
    ///
    /// Hàm này KHÔNG được phép ném lỗi: phiếu đã ghi xong ở câu trên rồi, nếu
    /// để lỗi mail vọt lên thì Leader thấy báo đỏ và bấm duyệt lại — lần 2 sẽ
    /// bị chặn vì phiếu không còn ở draft, thành ra bế tắc vì một lỗi hạ tầng.
    /// </summary>
    private async Task NotifyLeaderApprovedAsync(NgReport h)
    {
        try
        {
            var tpl = await _repo.GetMailTemplateAsync(MailEventAbnormal);

            // Phân biệt 2 trường hợp khác nhau, vì cách xử lý giống nhau nhưng
            // nguyên nhân khác nhau và người đọc log cần biết sửa ở đâu:
            //   - không có dòng  -> chưa khai sự kiện trong master.email_events
            //   - có dòng, mẫu rỗng -> đã khai nhưng chưa soạn nội dung mail
            // Mẫu rỗng mà vẫn gửi thì người nhận được một mail trắng không tiêu
            // đề, tệ hơn là không gửi.
            if (tpl is null)
            {
                _logger.LogWarning(
                    "Chua khai su kien mail {Event} trong master.email_events — khong gui mail phieu {DocNo}.",
                    MailEventAbnormal, h.DocNo);
                return;
            }
            if (string.IsNullOrWhiteSpace(tpl.Subject) || string.IsNullOrWhiteSpace(tpl.Body))
            {
                _logger.LogWarning(
                    "Su kien {Event} chua co mau tieu de/than mail (subject_template hoac body_template rong) "
                    + "— khong gui mail phieu {DocNo}. Soan noi dung tren man Cau hinh email.",
                    MailEventAbnormal, h.DocNo);
                return;
            }

            // Người nhận lấy hết từ master.email_config. Bộ phận nào được thông
            // báo do CẤU HÌNH quyết định, không liệt kê trong code — thêm bộ
            // phận mới vào màn Cấu hình email là nó tự nhận, không phải build lại.
            // Truyền cate + model vào: hàm tra chọn TO theo tầng đặc thù nhất
            // khớp được, nên phiếu có người quản lý cate riêng thì CHỈ người đó
            // nhận TO, người khai chung bị loại khỏi TO (khai CC thì vẫn nhận).
            var recipients = await ResolveRecipientsAsync(h);

            // Tên loại lỗi thay vì mã: mail cũ ghi "Loại bất thường: packaging",
            // người nhận phải tự dịch trong đầu. Tra ở đây một lần rồi truyền
            // vào, vì Fill() là hàm đồng bộ.
            var typeName = (await _repo.GetTypesAsync())
                .FirstOrDefault(t => t.Code == h.NgType)?.NameVi;

            // Mẫu viết bằng MARKDOWN -> dựng HTML có khung (MarkdownMail, dùng chung với
            // mail hàng thiếu). Thẻ HTML gõ trong mẫu hiện thành chữ (DisableHtml).
            var subject = Fill(tpl.Subject, h, typeName, FillMode.Plain).Trim();
            var body = MarkdownMail.Render(subject,
                Fill(tpl.Body, h, typeName, FillMode.Markdown), MarkdownMail.Orange);

            // From giữ cố định là địa chỉ hệ thống; tên hiển thị và Reply-To
            // mang người vừa duyệt, để người nhận bấm Trả lời là về đúng họ.
            var replyTo = await _repo.GetUserEmailAsync(ActorCode);

            await _mail.SendAsync(recipients, subject, body, Actor, replyTo);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Loi khi gui mail buoc 2 cho phieu {DocNo} — phieu VAN da duyet xong.", h.DocNo);
        }
    }

    /// <summary>
    /// Người nhận mail bước 2: lấy từ master.email_config theo cate + model,
    /// rồi cộng thêm CHÍNH NGƯỜI ĐANG DUYỆT vào CC — mail của họ đọc từ
    /// master.users theo employee_code của phiên đăng nhập, không khai trong
    /// email_config vì người duyệt đổi theo từng phiếu.
    ///
    /// Dùng CHUNG cho cả xem trước lẫn lúc gửi thật. Tách làm hai đường thì
    /// sớm muộn chúng lệch nhau, và màn xem trước còn tệ hơn không có vì nó
    /// khiến người ta tin nhầm.
    ///
    /// Bỏ qua nếu người duyệt đã có tên trong danh sách cấu hình: thêm lần nữa
    /// sẽ ra hai dòng cùng một địa chỉ, và nếu họ đang ở TO thì chèn thêm CC
    /// còn làm họ tụt xuống hàng "chỉ để biết".
    /// </summary>
    private async Task<List<MailRecipient>> ResolveRecipientsAsync(NgReport h)
    {
        var list = await _repo.GetMailRecipientsAsync(
            MailEventAbnormal, h.CategoryCode, h.Model);

        return MailRecipientList.WithActorCc(list, await _repo.GetUserEmailAsync(ActorCode), Actor);
    }

    /// <summary>
    /// Phiếu này có phải qua OQC không, theo master.ng_types.requires_oqc.
    ///
    /// Không có dòng quy tắc nào khớp ⟹ MẶC ĐỊNH VẪN QUA OQC. Chọn mặc định
    /// theo hướng an toàn: bảng chưa khai, khai thiếu hay khai sai đều giữ
    /// nguyên hành vi đang chạy, chứ không âm thầm bỏ qua một bước kiểm.
    /// </summary>
    private async Task<bool> RequiresOqcAsync(NgReport h)
        => await _repo.GetRequiresOqcAsync(h.NgType) ?? true;

    /// <summary>
    /// Thay chỗ giữ trong mẫu mail. Giữ danh sách nhỏ và tường minh thay vì
    /// dựng engine template — chỗ giữ lạ sẽ còn nguyên trong mail, nhìn là biết
    /// đã gõ sai, hơn là biến mất âm thầm.
    /// </summary>
    /// <summary>
    /// Link mở thẳng phiếu trên web. Chưa khai Web:BaseUrl thì trả rỗng và ghi
    /// log: mail vẫn gửi được, nhưng người nhận mất đường vào phiếu nên đáng
    /// báo chứ không nên im lặng.
    /// </summary>
    private string BuildLink(NgReport h)
    {
        if (string.IsNullOrWhiteSpace(_webBaseUrl))
        {
            _logger.LogWarning(
                "Chua khai Web:BaseUrl trong appsettings — mail phieu {DocNo} se khong co link mo phieu.",
                h.DocNo);
            return string.Empty;
        }
        // Dùng SỐ PHIẾU chứ không phải id: màn hình điền nó vào ô tìm kiếm rồi
        // tìm, nên người dùng thấy rõ vì sao danh sách chỉ còn một dòng. Số
        // phiếu cũng là thứ người ta đọc được và nhắc lại cho nhau, khác với id.
        return $"{_webBaseUrl}/abnormal-report?docNo={Uri.EscapeDataString(h.DocNo)}";
    }

    /// <summary>Cách thoát giá trị khi điền vào mẫu.</summary>
    private enum FillMode
    {
        /// <summary>Tiêu đề mail: chữ thuần, không thoát gì.</summary>
        Plain,
        /// <summary>Nội dung markdown: thoát ký tự markdown để "*" hay "#" trong mô tả hiện y nguyên.</summary>
        Markdown,
    }

    /// <param name="typeName">
    /// Tên loại lỗi để hiện trong mail. Rỗng thì lùi về mã — thà hiện
    /// "packaging" còn hơn để trống chỗ đó trong mail.
    /// </param>
    private string Fill(string? template, NgReport h, string? typeName, FillMode mode)
    {
        if (string.IsNullOrWhiteSpace(template)) return string.Empty;

        // Chỉ dựng link khi mẫu thật sự dùng tới — nếu không, mẫu nào không có
        // {Link} cũng sinh ra một dòng cảnh báo thiếu Web:BaseUrl, lấp hết log.
        var link = template.Contains("{Link}", StringComparison.Ordinal)
            ? BuildLink(h)
            : string.Empty;

        Func<string?, string> enc = mode == FillMode.Markdown ? MarkdownMail.Escape : v => v ?? "";

        // GIỮ KHỚP danh sách biến với NgSettingsDialog bên Web (TemplateVars).
        // Link KHÔNG thoát markdown — thoát làm hỏng địa chỉ.
        return template
            .Replace("{Link}", link)
            .Replace("{DocNo}", enc(h.DocNo))
            .Replace("{PalletCode}", enc(h.PalletCode))
            .Replace("{Model}", enc(h.Model))
            .Replace("{NgType}", enc(string.IsNullOrWhiteSpace(typeName) ? h.NgType : typeName))
            .Replace("{Description}", enc(h.Description))
            .Replace("{LeaderBy}", enc(h.LeaderBy))
            .Replace("{DiscoveredAt}", enc(h.DiscoveredAt.ToString("dd/MM/yyyy HH:mm")))
            .Replace("{Now}", enc(DateTime.Now.ToString("dd/MM/yyyy HH:mm")));
    }

    /// <summary>
    /// FA kết luận OK hoặc NG.
    ///
    /// NG thì BẮT BUỘC kèm hướng xử lý, và phiếu sang bước "FA xử lý" chứ
    /// chưa quay về OQC — người xử lý phải làm xong rồi xác nhận
    /// (<see cref="FaFixDoneAsync"/>) thì OQC mới có cái để đánh giá lại.
    ///
    /// OK thì repository tự quyết: trùng kết luận OQC là đóng phiếu, ngược
    /// kết luận OQC là trả về OQC đánh giá lại.
    /// </summary>
    public async Task FaConfirmAsync(long id, FaConfirmRequest request)
    {
        var h = await _repo.GetHeaderAsync(id) ?? throw NotFound();
        RequireInReview(h);

        // Đang ở bước FA xử lý thì đường đi là nút "đã xử lý xong", không
        // phải đánh giá lại từ đầu.
        if (h.CurrentStep == "fa_fix")
            throw new BusinessRuleException(_localizer["Ng.Err.FaFixPending"]);

        // Luồng tuần tự: OQC kết luận trước, FA mới đánh giá. 'skipped' là
        // loại lỗi không cần qua OQC — vẫn đi tiếp bình thường.
        if (h.OqcStatus == "pending")
            throw new BusinessRuleException(_localizer["Ng.Err.WaitOqc"]);
        if (h.FaStatus == "approved" && h.FaResult == "ok")
            throw new BusinessRuleException(_localizer["Ng.Err.FaDone"]);

        var result = (request.Result ?? string.Empty).Trim();
        if (result is not ("ok" or "ng"))
            throw new BusinessRuleException(_localizer["Ng.Err.FaResultInvalid"]);

        // Biến phụ không-null rồi mới gán ra ngoài: truyền thẳng một string?
        // vào Contains sẽ dính cảnh báo CS8604, mà dự án này bật nullable.
        string? resolution = null;
        if (result == "ng")
        {
            var res = (request.Resolution ?? string.Empty).Trim();
            if (!Resolutions.Contains(res))
                throw new BusinessRuleException(_localizer["Ng.Err.ResolutionInvalid"]);
            resolution = res;
        }

        await _repo.ApplyStepAsync(id, "fa", result, resolution, request.Comment, Actor);
    }

    /// <summary>
    /// FA báo đã xử lý xong lượt NG của mình.
    ///
    /// Không cho tự nghiệm thu: xác nhận xong thì hàng quay lại OQC đánh giá
    /// lại, và vòng mới bắt đầu. Riêng loại lỗi vốn không qua OQC thì không
    /// có ai để đánh giá lại nên phiếu đóng luôn — đúng yêu cầu "không áp
    /// dụng việc OQC check với trường hợp không cần qua OQC".
    /// </summary>
    public async Task FaFixDoneAsync(long id, FaFixDoneRequest request)
    {
        var h = await _repo.GetHeaderAsync(id) ?? throw NotFound();
        RequireInReview(h);

        if (h.CurrentStep != "fa_fix")
            throw new BusinessRuleException(_localizer["Ng.Err.NotFaFix"]);

        await _repo.ApplyStepAsync(id, "fa_fix", "done", null, request.Comment, Actor);
    }

    public async Task OqcConfirmAsync(long id, OqcConfirmRequest request)
    {
        var h = await _repo.GetHeaderAsync(id) ?? throw NotFound();
        RequireInReview(h);

        // Loại lỗi không cần qua OQC thì OQC không có vai trò gì ở phiếu này.
        // Chặn ở đây để một lần bấm nhầm không kéo phiếu vào vòng đánh giá mà
        // quy tắc đã nói là bỏ qua.
        if (h.OqcStatus == "skipped")
            throw new BusinessRuleException(_localizer["Ng.Err.OqcSkipped"]);

        // Trong MỘT vòng, OQC kết luận rồi thì không sửa lại được — FA đã dựa
        // vào kết luận đó để quyết định. Sang vòng mới repository đặt lại
        // oqc_status = 'pending' nên OQC đánh giá lại được bình thường.
        if (h.OqcStatus != "pending")
            throw new BusinessRuleException(_localizer["Ng.Err.OqcDone"]);

        var result = (request.Result ?? string.Empty).Trim();
        if (result is not ("ok" or "ng"))
            throw new BusinessRuleException(_localizer["Ng.Err.OqcResultInvalid"]);

        await _repo.ApplyStepAsync(id, "oqc", result, null, request.Comment, Actor);
    }

    // Bước "SCS Supervisor chốt" đã BỎ (23/11). Phiếu tự đóng khi OQC và FA
    // cùng kết luận OK — xem ApplyStepAsync. Lá quyền abnormal_report.finalize
    // vẫn khai trong Perms nhưng không còn gác endpoint nào: xoá lá rồi khai
    // lại đúng tên cũ sẽ làm SỐNG LẠI quyền của mọi role từng được gán.

    /// <summary>OQC và FA chỉ thao tác khi Leader đã duyệt và phiếu chưa chốt/huỷ.</summary>
    private void RequireInReview(NgReport h)
    {
        if (h.LeaderStatus != "submitted")
            throw new BusinessRuleException(_localizer["Ng.Err.LeaderNotSubmitted"]);
        if (h.DocStatus is "finalized" or "cancelled")
            throw new BusinessRuleException(_localizer["Ng.Err.AlreadyClosed"]);
    }

    private NotFoundException NotFound() => new(_localizer["Ng.Err.NotFound"]);
}
