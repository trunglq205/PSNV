using Swms.FinishGoods.API.Features.Pallets.Api;

namespace Swms.FinishGoods.API.Features.Pallets.Business
{
    public interface IStorageSuggestionService
    {
        /// <summary>Gợi ý vị trí lưu kho theo id pallet (khoá số).</summary>
        Task<StorageSuggestionResponse> SuggestByIdAsync(long palletId, int? palletHeightCm);

        /// <summary>Gợi ý vị trí lưu kho theo mã quét (cột wms.pallets.pallet_id).</summary>
        Task<StorageSuggestionResponse> SuggestByLotNoAsync(string lotNo, int? palletHeightCm);
    }
}
