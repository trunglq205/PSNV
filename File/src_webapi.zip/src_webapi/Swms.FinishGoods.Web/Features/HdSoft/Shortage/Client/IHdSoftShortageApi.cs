using Refit;
using Swms.FinishGoods.Web.Features.HdSoft.Shortage.Business.Models;

namespace Swms.FinishGoods.Web.Features.HdSoft.Shortage.Client
{
    /// <summary>Hàng thiếu trên HD soft (hệ thống cũ). Khớp HdSoftController.GetShortages bên API.
    /// Tách khỏi IShortageApi để không đụng bản mock đang implement interface đó.</summary>
    public interface IHdSoftShortageApi
    {
        /// <summary>warehouse "" = mọi kho; onlyShort = false để web tự lọc, đổi qua lại không phải gọi lại.</summary>
        [Get("/api/hdsoft/si/shortages")]
        Task<HdSoftShortageDto> GetAsync(
            [Query(Format = "yyyy-MM-dd")] DateTime from,
            [Query(Format = "yyyy-MM-dd")] DateTime to,
            string? warehouse,
            bool onlyShort);
    }
}
