using Swms.FinishGoods.Web.Shared.Business.Models;

namespace Swms.FinishGoods.Web.Features.Models.Business.Models;

/// <summary>
/// Tham số truy vấn danh sách model: filter + phân trang.
/// Kế thừa PagedQuery để có sẵn Page/PageSize.
/// (Các field cần khớp với ModelQuery phía API core.)
/// </summary>
public class ModelQuery : PagedQuery
{
    public string? GTIN { get; set; }
    public string? Code { get; set; }

    /// <summary>Lọc theo danh mục (master.categories.code). Null = tất cả.</summary>
    public int? CategoryCode { get; set; }

    public int? SuggestAreaId { get; set; }

    /// <summary>Mã xuất xứ 2 chữ cái. Null = tất cả.</summary>
    public string? Origin { get; set; }

    public bool? IsActive { get; set; }
    public DateTime? CreatedFrom { get; set; }
    public DateTime? CreatedTo { get; set; }
}
