import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/logger/app_logger.dart';

/// Log tập trung mọi thay đổi state của provider — tương đương BlocObserver.
base class AppProviderObserver extends ProviderObserver {
  const AppProviderObserver();

  @override
  void didUpdateProvider(
    ProviderObserverContext context,
    Object? previousValue,
    Object? newValue,
  ) {
    logger.i(
      '[UPDATE] ${context.provider.name ?? context.provider.runtimeType}: $newValue',
    );
    super.didUpdateProvider(context, previousValue, newValue);
  }

  @override
  void providerDidFail(
    ProviderObserverContext context,
    Object error,
    StackTrace stackTrace,
  ) {
    logger.e(
      '[FAIL] ${context.provider.name ?? context.provider.runtimeType}',
      error: error,
      stackTrace: stackTrace,
    );
    super.providerDidFail(context, error, stackTrace);
  }
}
