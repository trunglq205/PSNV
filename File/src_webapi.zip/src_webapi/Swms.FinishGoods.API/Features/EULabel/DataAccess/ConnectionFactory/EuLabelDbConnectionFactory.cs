using System.Data;
using Microsoft.Data.SqlClient;

namespace Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

/// <summary>
/// Tạo IDbConnection trỏ tới database EU Label Tool (In tem EU) — khác instance với DB chính SWMS.
/// Tách riêng để không nhầm connection string. Dùng cho các endpoint bàn giao tem.
/// </summary>
public interface IEuLabelDbConnectionFactory
{
    IDbConnection Create();
}

public class EuLabelDbConnectionFactory : IEuLabelDbConnectionFactory
{
    private readonly string _connStr;

    public EuLabelDbConnectionFactory(IConfiguration cfg)
        => _connStr = cfg.GetConnectionString("EuLabelDb")
                      ?? throw new InvalidOperationException(
                          "Missing connection string 'EuLabelDb' in configuration.");

    public IDbConnection Create() => new SqlConnection(_connStr);
}
