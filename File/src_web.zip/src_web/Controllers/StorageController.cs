﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class StorageController : BaseController
    {
        private readonly ApiService _apiService;
        public StorageController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] ReceivingCardStorageFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new ReceivingCardStorageFilter();
                var response = await _apiService.SearchRCStorage(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<ReceivingCardStorage>();


                var model = new ReceivingCardStorageViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> CheckStorage([FromQuery] CheckStorageFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new CheckStorageFilter();
                var response = await _apiService.SearchCheckStorage(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<CheckStorage>();

                var model = new CheckStorageViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> LayoutCapacity([FromQuery] LayoutCapacityFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new LayoutCapacityFilter();
                var response = await _apiService.SearchLayoutCapacity(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<LayoutCapacity>();

                var model = new LayoutCapacityViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View(model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { e.Message });
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetRCStorageDetails(RCStorageDetailRequest request)
        {
            try
            {
                var model = await _apiService.GetRCStorageDetails(request) ?? new List<RCStorageDetailViewModel>();
                return PartialView("~/Views/Storage/_RCStorageDetail.cshtml", model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpGet]
        public async Task<IActionResult> GetRCTempDetails(RCStorageDetailRequest request)
        {
            try
            {
                var model = await _apiService.GetRCTempDetails(request) ?? new List<RCTempDetailViewModel>();
                return PartialView("~/Views/Storage/_RCTempDetail.cshtml", model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetQrcodeRC(int id)
        {
            try
            {
                var receivingCard = await _apiService.GetReceivingCard(id);
                
                return PartialView("Views/Shared/_ReceivingCard.cshtml", receivingCard);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}