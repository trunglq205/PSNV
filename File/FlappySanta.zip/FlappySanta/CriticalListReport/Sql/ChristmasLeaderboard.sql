﻿-- =========================================================
-- BXH Flappy Santa mùa Giáng sinh (bảng tblGameScore có sẵn, KHÔNG cần tạo bảng mới)
-- Mặc định: 13/10 → chốt lúc 13:00 ngày 30/12 (đổi trong appsettings: GameSeason:christmas:From/To/EndTime)
-- Hits = điểm (server tự tính), DurationMs = thời gian bay, Throws = số lần bấm bay,
-- UsedAuto = 1: lượt bị loại (dữ liệu không khớp / thời gian bất thường)
-- =========================================================
DECLARE @From DATETIME2 = DATEFROMPARTS(YEAR(GETDATE()), 10, 13);
DECLARE @To   DATETIME2 = DATETIME2FROMPARTS(YEAR(GETDATE()), 12, 30, 13, 0, 0, 0, 0);   -- 13:00 ngày 30/12

;WITH best AS (
    SELECT *, ROW_NUMBER() OVER (PARTITION BY Username ORDER BY Hits DESC, PlayedAt) AS rn
    FROM dbo.tblGameScore
    WHERE Theme = 'christmas' AND UsedAuto = 0 AND Hits > 0
      AND PlayedAt >= @From AND PlayedAt < @To
)
SELECT ROW_NUMBER() OVER (ORDER BY Hits DESC, PlayedAt) AS [Hạng], FullName, Username,
       Hits AS [Điểm], DurationMs / 1000.0 AS [Giây bay], Throws AS [Số lần bấm], PlayedAt
FROM best WHERE rn = 1;

-- Kiểm tra trước khi trao giải: toàn bộ lượt của 1 người (kể cả lượt bị loại UsedAuto = 1)
-- SELECT * FROM dbo.tblGameScore WHERE Theme = 'christmas' AND Username = N'...' ORDER BY PlayedAt DESC;
