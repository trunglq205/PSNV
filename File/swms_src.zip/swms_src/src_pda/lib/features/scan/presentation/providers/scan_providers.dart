import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/scan/data/datasources/scan_remote_data_source.dart';
import 'package:swms_finish_goods/features/scan/data/repositories/scan_repository_impl.dart';
import 'package:swms_finish_goods/features/scan/domain/repositories/scan_repository.dart';

part 'scan_providers.g.dart';

@riverpod
ScanRemoteDataSource scanRemoteDataSource(Ref ref) {
  return ScanRemoteDataSource(ref.watch(dioProvider));
}

@riverpod
ScanRepository scanRepository(Ref ref) {
  return ScanRepositoryImpl(ref.watch(scanRemoteDataSourceProvider));
}
