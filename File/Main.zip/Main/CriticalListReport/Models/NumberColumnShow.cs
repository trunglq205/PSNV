﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("NumberColumnShow")]
    public class NumberColumnShow
    {
        [Key]
        public byte DataSource { get; set; } // 0 = SAP, 1 = TCode

        public int? ColumnAirSummary { get; set; } = 0;
        public string? EndValidDate { get; set; }
        public int? ValidGWAir { get; set; }
        public bool IsOverride { get; set; }
        public DateTime? OverrideEndValidDate { get; set; }
        public int? ValidGWAirOtherPlant { get; set; }
        public bool IsMR { get; set; }
    }
}
