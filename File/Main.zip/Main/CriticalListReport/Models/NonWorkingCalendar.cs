﻿using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    [Table("NonWorkingCalendar")]
    public class NonWorkingCalendar
    {
        public int ID { get; set; }
        public DateTime? FromDate { get; set; }
    }
}
