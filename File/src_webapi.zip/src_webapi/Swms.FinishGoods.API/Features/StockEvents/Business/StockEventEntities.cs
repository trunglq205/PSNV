﻿namespace Swms.FinishGoods.API.Features.StockEvents.Business.Entities
{
    /// <summary>
    /// Một event ghi vào wms.stock_events.
    ///
    /// Caller chỉ truyền KHOÁ SỐ (PalletId / BoxId / FromLocatorId / ToLocatorId).
    /// Mọi snapshot (pallet_code, stocky_code, box_no, locator_code, map_type,
    /// area_code) do proc wms.usp_stock_event_add tự tra — không nhân bản logic
    /// lookup ở tầng C#.
    ///
    /// KHÔNG cắt gì ở đây: bảng vẫn ghi đủ mọi cột. Việc gọn chỉ áp dụng cho
    /// phần ĐỌC RA (các *Row / *Header bên dưới).
    /// </summary>
    public sealed class StockEvent
    {
        public string SubjectType { get; init; } = StockEventSubjects.Pallet;

        /// <summary>Bắt buộc khi SubjectType = pallet. Với box: null -> proc tự lấy boxes.lot_id.</summary>
        public long? PalletId { get; init; }

        /// <summary>Bắt buộc khi SubjectType = box.</summary>
        public long? BoxId { get; init; }

        public string EventCode { get; init; } = default!;

        /// <summary>_currentUser.FullName — KHÔNG phải user id.</summary>
        public string? Actor { get; init; }

        public string Source { get; init; } = StockEventSources.Web;

        public long? FromLocatorId { get; init; }
        public long? ToLocatorId { get; init; }

        public string? RefType { get; init; }
        public long? RefId { get; init; }
        public string? RefNo { get; init; }

        /// <summary>Pallet nguồn/đích khi tách, hoặc pallet cũ khi box đổi pallet.</summary>
        public long? RelatedPalletId { get; init; }

        public int? BoxCountBefore { get; init; }
        public int? BoxCountAfter { get; init; }

        public string? Note { get; init; }

        /// <summary>JSON tự do. Phải hợp lệ (CHECK ISJSON ở DB).</summary>
        public string? Payload { get; init; }

        /// <summary>Null -> proc dùng SYSDATETIME(). Chỉ set khi backfill dữ liệu cũ.</summary>
        public DateTime? EventAt { get; init; }
    }

    /// <summary>
    /// Thông tin event mà tầng Service quyết định và truyền xuống Repository.
    ///
    /// Tồn tại vì trước đây MoveIntent dừng lại ở tầng Service — repository không
    /// biết thao tác là gán tạm hay lưu kho nên lịch sử ghi giống hệt nhau.
    /// </summary>
    public sealed record StockEventContext(
        string EventCode,
        string? Actor,
        string Source = StockEventSources.Web,
        string? Note = null,
        string? Payload = null);

    // ── Dữ liệu đọc ra ────────────────────────────────────────────────
    //
    // Nhãn / màu / icon KHÔNG nằm trong các lớp dưới đây. Chúng chỉ có 29 tổ hợp
    // nhưng nếu gửi kèm từng dòng thì timeline 50 event là 50 lần lặp cùng chuỗi.
    // Client tải StockEventType một lần rồi tra theo EventCode.

    /// <summary>Một dòng catalog master.stock_event_types.</summary>
    public sealed class StockEventType
    {
        public string Code { get; set; } = default!;

        /// <summary>
        /// Hiện luôn bằng "stock_event." + Code. Giữ cột ở DB để sau này đổi key
        /// i18n mà không phải đổi code (code đã nằm trong dữ liệu lịch sử).
        /// </summary>
        public string NameKey { get; set; } = default!;

        public string SubjectType { get; set; } = default!;
        public string GroupCode { get; set; } = default!;
        public string ColorToken { get; set; } = default!;
        public string? Icon { get; set; }
        public int SortOrder { get; set; }
    }

    /// <summary>
    /// Một dòng timeline PALLET.
    ///
    /// Bỏ so với bản đầu: SubjectType (timeline pallet luôn 'pallet'),
    /// PalletId/PalletCode (bằng header), BoxId/BoxNo (luôn null), Inherited
    /// (luôn false), RefType (suy được từ EventCode), RefId / RelatedPalletId
    /// (chưa có màn nào điều hướng tới), Source (hiện luôn là WEB).
    /// </summary>
    public sealed class PalletEventRow
    {
        public long Id { get; set; }
        public string EventCode { get; set; } = default!;
        public DateTime EventAt { get; set; }
        public string? Actor { get; set; }

        public string? FromLocatorCode { get; set; }
        public string? FromAreaCode { get; set; }
        public string? ToLocatorCode { get; set; }
        public string? ToAreaCode { get; set; }

        public string? RefNo { get; set; }

        /// <summary>Pallet đối ứng khi tách — đủ để gọi by-lot-no/{code}/history.</summary>
        public string? RelatedPalletCode { get; set; }

        public int? BoxCountBefore { get; set; }
        public int? BoxCountAfter { get; set; }

        public string? Note { get; set; }
        public string? Payload { get; set; }
    }

    /// <summary>
    /// Một dòng timeline BOX.
    ///
    /// <see cref="Inherited"/> thay luôn vai trò của SubjectType: ở timeline box
    /// thì subject_type = 'box' ⟺ inherited = false, hai trường nói cùng một điều.
    /// </summary>
    public sealed class BoxEventRow
    {
        public long Id { get; set; }
        public string EventCode { get; set; } = default!;
        public DateTime EventAt { get; set; }
        public string? Actor { get; set; }

        /// <summary>true = kế thừa từ pallet chứa thùng, false = thao tác trên chính thùng.</summary>
        public bool Inherited { get; set; }

        /// <summary>Pallet chứa thùng TẠI THỜI ĐIỂM đó — đổi sau mỗi lần tách.</summary>
        public string? PalletCode { get; set; }

        public string? FromLocatorCode { get; set; }
        public string? FromAreaCode { get; set; }
        public string? ToLocatorCode { get; set; }
        public string? ToAreaCode { get; set; }

        public string? RefNo { get; set; }
        public string? Note { get; set; }
        public string? Payload { get; set; }
    }

    /// <summary>
    /// Dòng timeline rút gọn kèm khi QUÉT pallet (?include=history) — 4 cột.
    /// Bối cảnh khác màn lịch sử: màn hình PDA nhỏ, mạng kho yếu, người dùng chỉ
    /// liếc "pallet này vừa đi đâu".
    /// </summary>
    public sealed class PalletEventBrief
    {
        public string EventCode { get; init; } = "";
        public DateTime EventAt { get; init; }
        public string? Actor { get; init; }
        public string? Source { get; init; }
        public string? FromLocatorCode { get; init; }
        public string? ToLocatorCode { get; init; }
        public string? ToAreaCode { get; init; }
    }

    /// <summary>
    /// Header màn lịch sử pallet.
    ///
    /// Bỏ so với bản đầu: LotType, CategoryCode/Name, DetailLevel, Disposition,
    /// IsUrgent, CurrentMapType (màn này không dùng); CreatedAt/By, SapStatus,
    /// SapPushedAt, StopShipment (timeline đã kể qua PALLET_CREATED / SAP_PUSHED /
    /// STOP_SHIPMENT_* — hai nguồn cho cùng một sự thật là chỗ dễ lệch nhất).
    /// </summary>
    public sealed class PalletHistoryHeader
    {
        public long PalletId { get; set; }
        public string PalletCode { get; set; } = default!;
        public string? StockyCode { get; set; }
        public string? Model { get; set; }
        public int? BoxCount { get; set; }
        public string InspectionStatus { get; set; } = default!;
        public DateTime? ProductionDate { get; set; }
        public string? CurrentLocatorCode { get; set; }
        public string? CurrentAreaCode { get; set; }
        public bool IsDeleted { get; set; }
    }

    /// <summary>Header màn lịch sử box.</summary>
    public sealed class BoxHistoryHeader
    {
        public long BoxId { get; set; }
        public string BoxNo { get; set; } = default!;
        public string? PalletCode { get; set; }
        public string? Model { get; set; }

        /// <summary>
        /// int? để khớp cột wms.boxes.oqc_status (giá trị 0/2/3/4/5 — xem
        /// FossPalletMapper). Lưu ý BoxDetailEntity.OqcStatus đang khai string?,
        /// hai chỗ lệch nhau; Dapper che được bằng Convert.ChangeType nhưng nên
        /// thống nhất về int? khi có dịp.
        /// </summary>
        public int? OqcStatus { get; set; }

        public string? CurrentLocatorCode { get; set; }
        public string? CurrentAreaCode { get; set; }
        public bool IsDeleted { get; set; }
        public int LineCount { get; set; }
        public int? TotalQty { get; set; }
    }

    /// <summary>Kết quả đọc lịch sử pallet: header + timeline.</summary>
    public sealed class PalletHistory
    {
        public PalletHistoryHeader Header { get; set; } = default!;
        public IReadOnlyList<PalletEventRow> Events { get; set; } = [];
    }

    /// <summary>Kết quả đọc lịch sử box: header + timeline.</summary>
    public sealed class BoxHistory
    {
        public BoxHistoryHeader Header { get; set; } = default!;
        public IReadOnlyList<BoxEventRow> Events { get; set; } = [];
    }

    /// <summary>Bộ lọc timeline pallet.</summary>
    public sealed class StockEventFilter
    {
        public DateTime? From { get; init; }
        public DateTime? To { get; init; }

        /// <summary>CSV event_code. Null = tất cả.</summary>
        public string? Codes { get; init; }

        /// <summary>CSV group_code. Null = tất cả.</summary>
        public string? Groups { get; init; }
    }
}