using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Users.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.Users.Api;

[ApiController]
[Route("api/users")]
public class UsersController : ControllerBase
{
    private readonly IUserService _service;
    public UsersController(IUserService service) => _service = service;

    [HttpGet]
    [RequirePermission<Perms.System.Users.View>]
    public async Task<ActionResult<PagedResult<UserResponse>>> GetAll([FromQuery] UserQuery query)
        => Ok(await _service.GetPagedAsync(query));

    [HttpGet("{id:int}")]
    [RequirePermission<Perms.System.Users.View>]
    public async Task<ActionResult<UserResponse>> GetById(int id)
    {
        var item = await _service.GetByIdAsync(id);
        return Ok(item);
    }

    [HttpPost]
    [RequirePermission<Perms.System.Users.Create>]
    public async Task<ActionResult<UserResponse>> Create(CreateUserRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpPost("bulk")]
    [RequirePermission<Perms.System.Users.Create>]
    public async Task<ActionResult<List<UserResponse>>> BulkCreate(IReadOnlyList<CreateUserRequest> request)
        => Ok(await _service.BulkCreateAsync(request));

    [HttpPut("{id:int}")]
    [RequirePermission<Perms.System.Users.Update>]
    public async Task<IActionResult> Update(int id, UpdateUserRequest request)
    {
        await _service.UpdateAsync(id, request);
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    [RequirePermission<Perms.System.Users.Delete>]
    public async Task<IActionResult> Delete(int id)
    {
        await _service.DeleteAsync(id);
        return NoContent();
    }

    [HttpGet("dept-counts")]
    [RequirePermission<Perms.System.Users.View>]
    public async Task<ActionResult<UserDeptCountResponse>> GetDeptCounts()
        => Ok(await _service.GetDeptCountsAsync());

    [HttpPost("{id:int}/reset-password")]
    [RequirePermission<Perms.System.Users.ResetPwd>]
    public async Task<IActionResult> ResetPassword(int id)
    {
        await _service.ResetPasswordAsync(id);
        return NoContent();
    }

    [HttpGet("role-options")]
    [RequirePermission<Perms.System.Users.View>]
    public async Task<ActionResult<List<RoleOptionResponse>>> GetRoleOptions()
        => Ok(await _service.GetRoleOptionsAsync());
}