﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class LayoutCapacityViewModel : TableViewModel<LayoutCapacity, LayoutCapacityFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, LayoutCapacityFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Category = filter?.Category ?? Filter.Category,
                TypeSloc = filter?.TypeSloc ?? Filter.TypeSloc,
                PicUser = filter?.PicUser ?? Filter.PicUser,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
