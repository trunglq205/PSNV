import 'package:flutter/foundation.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/storage_suggestion.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/master_draft.dart';

/// Bước của luồng vị trí.
enum PalletFlowStep {
  /// Bước 1 — quét mã pallet.
  scanPallet,

  /// Bước 2 — chọn hành động + quét mã vị trí (nếu cần) + xác nhận.
  action;

  int get number => index + 1;

  static PalletFlowStep fromNumber(int n) =>
      PalletFlowStep.values[(n - 1).clamp(0, PalletFlowStep.values.length - 1)];
}

/// State dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
///
/// [pallet] là `AsyncValue` để `BaseNotifierMixin.executePartial` cập nhật
/// loading → data | error ngay trong state (UI hiện inline ở bước 1).
/// Các mutation (gán/rời/lưu) vẫn đi qua `appActionProvider`.
@immutable
class PalletFlowState {
  final PalletFlowStep step;

  /// Mã vừa quét ở bước 1 (để "thử lại" khi lookup lỗi).
  final String? lastLotNo;

  /// Kết quả lookup. `AsyncData(null)` = chưa quét gì.
  final AsyncValue<Pallet?> pallet;

  /// Gợi ý vị trí lưu kho — CHỈ màn Storing dùng.
  ///
  /// Tách khỏi [pallet] vì đây là lời khuyên, không phải dữ liệu bắt buộc:
  /// hỏng thì chỉ mất phần gợi ý, thao tác viên vẫn quét vị trí và lưu bình
  /// thường. Giữ riêng `AsyncValue` để hiện loading/lỗi ngay trong thẻ gợi ý
  /// mà không đụng tới `pallet`.
  final AsyncValue<StorageSuggestion?> suggestion;

  /// Chiều cao pallet (cm) do thao tác viên nhập ở dialog bổ sung thông tin.
  /// Null = chưa nhập → server gợi ý không lọc theo tầng và trả cảnh báo.
  final int? palletHeightCm;

  /// Khai báo master vừa PATCH thành công trong phiên (xem [MasterDraft]).
  ///
  /// CHỈ để chọn sẵn ô khi mở lại dialog — không dùng để hiển thị gợi ý, cũng
  /// không phải nguồn sự thật. Nguồn sự thật là `master.models`, và [suggestion]
  /// đã nạp lại sau mỗi lần lưu.
  ///
  /// Khác [palletHeightCm] ở chỗ nó gắn với MODEL chứ không gắn với pallet, nên
  /// không bị xoá khi quét pallet mới; việc đối chiếu model do UI làm qua
  /// [MasterDraft.matches].
  final MasterDraft? masterDraft;

  /// Hành động khả dụng đã lọc theo màn.
  final List<PalletAction> actions;

  /// Hành động đang chọn ở bước 2.
  final PalletAction? action;

  /// Mã vị trí đích đã quét (null khi chưa quét).
  final String? scannedLocatorCode;

  /// Kết quả thao tác gần nhất (để hiện toast).
  final LocatorChangeResult? lastResult;

  const PalletFlowState({
    this.step = PalletFlowStep.scanPallet,
    this.lastLotNo,
    this.pallet = const AsyncValue.data(null),
    this.suggestion = const AsyncValue.data(null),
    this.palletHeightCm,
    this.masterDraft,
    this.actions = const [],
    this.action,
    this.scannedLocatorCode,
    this.lastResult,
  });

  Pallet? get currentPallet => pallet.value;

  bool get canSubmit {
    final a = action;
    if (currentPallet == null || a == null) return false;
    // Out kho: không có vị trí đích để quét -> xác nhận được ngay.
    if (!a.needsLocator) return true;
    return scannedLocatorCode != null && scannedLocatorCode!.isNotEmpty;
  }

  PalletFlowState copyWith({
    PalletFlowStep? step,
    String? lastLotNo,
    AsyncValue<Pallet?>? pallet,
    AsyncValue<StorageSuggestion?>? suggestion,
    int? palletHeightCm,
    MasterDraft? masterDraft,
    List<PalletAction>? actions,
    PalletAction? action,
    String? scannedLocatorCode,
    LocatorChangeResult? lastResult,
    bool clearAction = false,
    bool clearLocatorCode = false,
    bool clearResult = false,
    bool clearSuggestion = false,
    bool clearHeight = false,
    bool clearMasterDraft = false,
  }) {
    return PalletFlowState(
      step: step ?? this.step,
      lastLotNo: lastLotNo ?? this.lastLotNo,
      pallet: pallet ?? this.pallet,
      suggestion: clearSuggestion
          ? const AsyncValue.data(null)
          : (suggestion ?? this.suggestion),
      palletHeightCm: clearHeight
          ? null
          : (palletHeightCm ?? this.palletHeightCm),
      // Cần cờ clear riêng: `masterDraft: null` trong copyWith nghĩa là "không
      // đổi", không phải "xoá" — giống hệt cách clearHeight đang xử lý.
      masterDraft: clearMasterDraft ? null : (masterDraft ?? this.masterDraft),
      actions: actions ?? this.actions,
      action: clearAction ? null : (action ?? this.action),
      scannedLocatorCode: clearLocatorCode
          ? null
          : (scannedLocatorCode ?? this.scannedLocatorCode),
      lastResult: clearResult ? null : (lastResult ?? this.lastResult),
    );
  }
}