import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/extensions/navigation_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/buttons/back_icon_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_bottom_hint.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/kitting_notifier.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_header_card.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_route_list.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/kitting_skeleton.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

// ─────────────────────────────────────────────────────────────
//  Soạn hàng (Kitting) — tuyến lấy hàng của 1 SI.
//  Không truyền siId → tự mở SI đang soạn đầu tiên.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class KittingScreen extends ConsumerWidget {
  final int? siId;

  const KittingScreen({super.key, @QueryParam('siId') this.siId});

  void _openSiList(BuildContext context) =>
      context.pushRoute(const ShipmentInstructionListRoute());

  void _openMap(BuildContext context) => context.pushRoute(StorageMapRoute());

  /// Mở vị trí [task]; lấy xong (màn trả true) thì tự mở vị trí chưa lấy
  /// kế tiếp — lặp tới khi hết vị trí hoặc thao tác viên bấm back.
  Future<void> _openKittingTask(
    BuildContext context,
    WidgetRef ref,
    List<PickTask> route,
    PickTask task,
  ) async {
    await context.openKittingTask(route, task, siId: siId);
    // Về tới màn tuyến (hết vị trí, hoặc bấm back giữa chừng) → cập nhật.
    if (context.mounted) await ref.read(kittingProvider(siId).notifier).load();
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final provider = kittingProvider(siId);
    final state = ref.watch(provider);
    final notifier = ref.read(provider.notifier);

    final si = state.si.value;
    final route = state.route;

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.kitting_title.tr(),
        subtitle: si == null ? null : siJoin([si.siNo, si.portOfDischarge]),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: notifier.load),
        ],
      ),
      body: state.si.when(
        loading: () => const KittingSkeleton(),
        error: (e, _) => Center(
          child: AppErrorView.widget(
            message: LocaleKeys.kitting_load_error.tr(),
            onRetry: notifier.load,
          ),
        ),
        data: (si) => si == null
            ? _NoPickingSi(onOpenList: () => _openSiList(context))
            : RefreshIndicator(
                onRefresh: notifier.load,
                child: ListView(
                  physics: const AlwaysScrollableScrollPhysics(),
                  padding: const EdgeInsets.all(AppDimens.md),
                  children: [
                    KittingHeaderCard(
                      si: si,
                      route: route,
                      onChangeSi: () => _openSiList(context),
                      onOpenMap: () => _openMap(context),
                    ),
                    const SizedBox(height: AppDimens.md),
                    if (route.isEmpty)
                      Padding(
                        padding: const EdgeInsets.only(top: AppDimens.xl),
                        child: Text(
                          LocaleKeys.kitting_empty_tasks.tr(),
                          textAlign: TextAlign.center,
                          style: AppTextStyles.body.copyWith(
                            color: context.swms.text3,
                          ),
                        ),
                      )
                    else
                      KittingRouteList(
                        tasks: route,
                        onTap: (task) =>
                            _openKittingTask(context, ref, route, task),
                      ),
                  ],
                ),
              ),
      ),
      bottomNavigationBar: _buildBottom(context, ref, route),
    );
  }

  Widget? _buildBottom(
    BuildContext context,
    WidgetRef ref,
    List<PickTask> route,
  ) {
    if (route.isEmpty) return null;

    final pending = route.where((t) => !t.isDone);
    if (pending.isEmpty) {
      return AppBottomHint(text: LocaleKeys.kitting_all_done.tr());
    }

    return AppBottomHint(
      child: Row(
        children: [
          const BackIconButton(),
          const SizedBox(width: AppDimens.sm),
          // Expanded cho AppButton chiều rộng hữu hạn — cùng cách PalletFlowPage.
          Expanded(
            child: AppButton(
              label: LocaleKeys.kitting_next_location.tr(
                args: ['${pending.length}'],
              ),
              icon: Icons.place_outlined,
              isFullWidth: false,
              // Đi tới vị trí chưa lấy đầu tiên theo thứ tự tuyến.
              onPressed: () =>
                  _openKittingTask(context, ref, route, pending.first),
            ),
          ),
        ],
      ),
    );
  }
}

/// Không có SI nào ở trạng thái đang soạn.
class _NoPickingSi extends StatelessWidget {
  final VoidCallback onOpenList;

  const _NoPickingSi({required this.onOpenList});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.inventory_2_outlined, size: 48, color: swms.text4),
            const SizedBox(height: AppDimens.sm),
            Text(
              LocaleKeys.kitting_no_picking_si.tr(),
              textAlign: TextAlign.center,
              style: AppTextStyles.body.copyWith(color: swms.text3),
            ),
            const SizedBox(height: AppDimens.md),
            AppButton(
              label: LocaleKeys.kitting_go_si_list.tr(),
              icon: Icons.list_alt,
              size: AppButtonSize.sm,
              isFullWidth: false,
              onPressed: onOpenList,
            ),
          ],
        ),
      ),
    );
  }
}
