namespace Swms.FinishGoods.API.Features.StowagePlans.DataAccess;

public interface IStowagePlanRepository
{
    // ── Danh sách ───────────────────────────────────────────
    /// <summary>Chuyến container còn mở (planned / arrived / sealed) + plan đã gắn (nếu có).</summary>
    Task<List<PlanListRow>> GetTripPlansAsync(string? q, DateTime? from, DateTime? toExclusive, int max);
    /// <summary>Plan không gắn chuyến nào (sau này: lập theo order).</summary>
    Task<List<PlanListRow>> GetStandalonePlansAsync(string? q, DateTime? from, DateTime? toExclusive, int max);

    // ── Chi tiết ────────────────────────────────────────────
    Task<PlanRow?> GetPlanAsync(string planNo);
    /// <summary>Plan đang gắn chuyến này (qua stowage_plan_containers), chưa xoá.</summary>
    Task<string?> GetPlanNoOfTripAsync(long tripId);
    Task<TripHeadRow?> GetTripAsync(long tripId);
    Task<List<PlanContainerRow>> GetContainersAsync(long planId);
    Task<List<StowSiRow>> GetTripSisAsync(long tripId);
    Task<List<StowSiRow>> GetPlanSisAsync(long planId);
    Task<List<StowBoxRow>> GetBoxesAsync(IReadOnlyCollection<long> siIds);
    Task<List<StowColumnRow>> GetColumnsAsync(long planId);
    Task<List<StowPalletRow>> GetPalletsAsync(long planId);
    Task<List<StowPalletBoxRow>> GetPalletBoxesAsync(long planId);

    // ── Ghi ─────────────────────────────────────────────────
    /// <summary>Tạo / cập nhật header, đồng bộ SI + số container, thay toàn bộ cọc / pallet / box. Trả về plan id.</summary>
    Task<long> SaveAsync(PlanSave save);
}