// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'scan_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(scanRemoteDataSource)
final scanRemoteDataSourceProvider = ScanRemoteDataSourceProvider._();

final class ScanRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ScanRemoteDataSource,
          ScanRemoteDataSource,
          ScanRemoteDataSource
        >
    with $Provider<ScanRemoteDataSource> {
  ScanRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'scanRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$scanRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ScanRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ScanRemoteDataSource create(Ref ref) {
    return scanRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ScanRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ScanRemoteDataSource>(value),
    );
  }
}

String _$scanRemoteDataSourceHash() =>
    r'5be6187938be1d1ef290e78e335499424bb09ae2';

@ProviderFor(scanRepository)
final scanRepositoryProvider = ScanRepositoryProvider._();

final class ScanRepositoryProvider
    extends $FunctionalProvider<ScanRepository, ScanRepository, ScanRepository>
    with $Provider<ScanRepository> {
  ScanRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'scanRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$scanRepositoryHash();

  @$internal
  @override
  $ProviderElement<ScanRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  ScanRepository create(Ref ref) {
    return scanRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ScanRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ScanRepository>(value),
    );
  }
}

String _$scanRepositoryHash() => r'3e719b962dbb1014143710238128234371ef141e';
