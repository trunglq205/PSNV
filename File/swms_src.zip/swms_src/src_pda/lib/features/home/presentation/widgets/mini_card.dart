import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';

/// Thẻ chức năng nhỏ trong cụm: icon tone + tên.
class MiniCard extends StatelessWidget {
  final FeatureItem item;
  final Color tone;
  final Color toneBg;
  final VoidCallback? onTap;

  const MiniCard({
    super.key,
    required this.item,
    required this.tone,
    required this.toneBg,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      borderRadius: 12,
      onTap: onTap,
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.sm,
        vertical: 8,
      ),
      child: Row(
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(
              color: toneBg,
              borderRadius: BorderRadius.circular(AppDimens.sm),
            ),
            child: Icon(item.icon, size: 16, color: tone),
          ),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text(
              item.nameKey.tr(),
              style: AppTextStyles.label.copyWith(color: swms.text1),
              maxLines: 2,
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
