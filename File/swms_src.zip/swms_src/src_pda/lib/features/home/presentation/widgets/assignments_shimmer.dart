import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_skeleton.dart';

/// Skeleton loading cho khối "Việc của tôi".
class AssignmentsShimmer extends StatelessWidget {
  /// Số thẻ giả hiển thị khi loading.
  final int count;

  const AssignmentsShimmer({super.key, this.count = 1});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        const SizedBox(height: AppDimens.md),
        // Tiêu đề giả nằm ngoài card → bọc AppShimmer trực tiếp.
        const AppShimmer(
          child: Row(
            children: [
              Bone.circle(size: 12),
              SizedBox(width: 6),
              Bone(width: 90, height: 11),
            ],
          ),
        ),
        const SizedBox(height: AppDimens.sm),
        for (int i = 0; i < count; i++) ...[
          const _AssignmentSkeleton(),
          if (i != count - 1) const SizedBox(height: 4),
        ],
      ],
    );
  }
}

class _AssignmentSkeleton extends StatelessWidget {
  const _AssignmentSkeleton();

  @override
  Widget build(BuildContext context) {
    return const SkeletonCard(
      padding: EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Row 1: icon + label + chip hạn
          Row(
            children: [
              Bone(width: 22, height: 22),
              SizedBox(width: 6),
              Bone(width: 110),
              Spacer(),
              Bone(width: 64, height: 18, radius: 10),
            ],
          ),
          SizedBox(height: 8),
          // Row 2: code + sub
          Row(
            children: [
              Bone(width: 130),
              SizedBox(width: 8),
              Bone(width: 80, height: 10),
            ],
          ),
          SizedBox(height: 10),
          // Row 3: progress + số
          Row(
            children: [
              Expanded(child: Bone(height: 5, radius: 999)),
              SizedBox(width: 8),
              Bone(width: 56, height: 10),
            ],
          ),
        ],
      ),
    );
  }
}