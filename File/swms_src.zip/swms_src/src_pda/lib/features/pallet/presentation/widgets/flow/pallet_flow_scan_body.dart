import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';

/// Bước 1: khung quét mã pallet (barcode/QR trên tem pallet).
class PalletFlowScanBody extends StatelessWidget {
  const PalletFlowScanBody({super.key});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.only(bottom: AppDimens.sm),
          child: Text(
            LocaleKeys.pallet_flow_scan_pallet_label.tr(),
            style: AppTextStyles.label.copyWith(
              fontWeight: FontWeight.w700,
              color: swms.text3,
            ),
          ),
        ),
        BarcodeScannerButton(
          scanningLabel: LocaleKeys.pallet_flow_scan_pallet_on_label.tr(),
        ),
        const SizedBox(height: AppDimens.md),
        Container(
          padding: const EdgeInsets.all(AppDimens.md),
          decoration: BoxDecoration(
            color: swms.card2,
            borderRadius: BorderRadius.circular(AppDimens.rCard),
            border: Border.all(color: swms.border),
          ),
          child: Row(
            children: [
              Icon(Icons.info_outline, size: 18, color: swms.text3),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Text(
                  LocaleKeys.pallet_flow_scan_pallet_hint.tr(),
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
