import 'package:dio/dio.dart';
import 'package:swms_finish_goods/features/part_card/data/datasources/part_card_remote_data_source.dart';
import 'package:swms_finish_goods/features/part_card/data/models/part_card_response_model.dart';
import 'package:swms_finish_goods/features/part_card/data/models/print_history_request_model.dart';
import 'package:swms_finish_goods/features/part_card/data/models/split_merge_request_model.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_suggestion.dart';
import 'package:swms_finish_goods/features/part_card/domain/repositories/part_card_repository.dart';

/// Lịch sử in Part Card: đọc để gợi ý, lưu sau khi in, sửa / tách / gộp.
class PartCardRepositoryImpl implements PartCardRepository {
  final PartCardRemoteDataSource _remote;

  const PartCardRepositoryImpl(this._remote);

  /// Số phiếu gần nhất dùng để thống kê (= Size tối đa API cho phép).
  static const int _historySize = 100;

  @override
  Future<List<PartCardHistorySample>> getHistorySamples(String model) async {
    final key = model.trim().toUpperCase();
    final page = await _remote.getPrintHistory(key, 1, _historySize);

    return [
      for (final card in page.items ?? const <PartCardResponseModel>[])
        ?card.toSample(key),
    ];
  }

  @override
  Future<List<PartCardPrintHistory>> savePrintHistory(
    List<PartCardPrintParams> items,
  ) async {
    final response = await _remote.savePrintHistoryBulk(
      items.map(PrintHistoryRequestModel.fromParams).toList(),
    );

    return response.toEntities();
  }

  @override
  Future<int?> findIdByPayload(String payload) async {
    final page = await _remote.findByPayload(payload, 1, 1);
    return page.items?.firstOrNull?.id;
  }

  @override
  Future<bool> updatePrintHistory(int id, PartCardPrintParams item) async {
    try {
      await _remote.updatePrintHistory(
        id,
        PrintHistoryRequestModel.fromParams(item),
      );
      return true;
    } on DioException catch (e) {
      // 404 = phiếu không còn → để tầng trên hỏi user có tạo mới không.
      if (e.response?.statusCode == 404) return false;
      rethrow;
    }
  }

  @override
  Future<List<PartCardPrintHistory>> splitPrintHistory(
    String sourcePayload,
    List<PartCardPrintParams> items,
  ) async {
    final response = await _remote.splitPrintHistory(
      SplitPrintRequestModel(
        sourcePayload: sourcePayload,
        items: items.map(PrintHistoryRequestModel.fromParams).toList(),
      ),
    );
    return response.toEntities();
  }

  @override
  Future<PartCardPrintHistory> mergePrintHistory(
    List<String> sourcePayloads,
    PartCardPrintParams item,
  ) async {
    final response = await _remote.mergePrintHistory(
      MergePrintRequestModel(
        sourcePayloads: sourcePayloads,
        item: PrintHistoryRequestModel.fromParams(item),
      ),
    );
    return response.toEntity();
  }
}
