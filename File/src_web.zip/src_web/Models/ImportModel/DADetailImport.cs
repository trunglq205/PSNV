﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class DADetailImport
    {
        /// <summary>
        /// DeliveryDate
        /// </summary>
        public string? DeliveryDate { get; set; }
        /// <summary>
        /// Plant
        /// </summary>
        public string? Plant { get; set; }
        /// <summary>
        /// Material
        /// </summary>
        public string? Material { get; set; }
        /// <summary>
        /// TotalQuantity
        /// </summary>
        public double TotalQuantity { get; set; }
        /// <summary>
        /// Sloc
        /// </summary>
        public string? Sloc { get; set; }
        public List<DAItemDetailImport>? DetailItems { get; set;}

    }
}
