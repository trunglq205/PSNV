﻿using Newtonsoft.Json;

namespace SWMS_WebTool.Models
{
    public class OrderPlan : DeliveryPlan
    {
        [JsonProperty("planOrderNumber")]
        public string OrderPlanNumber { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }
        [JsonProperty("planOrderQuantity")]
        public int PlanQuantity { get; set; }
        [JsonProperty("grQuantity")]
        public int ActualQuantity { get; set; }
        [JsonProperty("postingDate")]
        public string Date { get; set; }
        public DeliveryPlanStatus Status { get; set; }
        public bool? IsWD { get; set; }

        public double ReceivedProcess
        {
            get { return (double)ActualQuantity / PlanQuantity * 100; }
        }
    }
}
