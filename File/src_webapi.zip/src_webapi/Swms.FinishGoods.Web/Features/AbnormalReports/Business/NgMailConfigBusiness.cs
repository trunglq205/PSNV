using Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;
using Swms.FinishGoods.Web.Features.AbnormalReports.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.AbnormalReports.Business;

public class NgMailConfigBusiness : BaseBusiness, INgMailConfigBusiness
{
    private readonly INgMailConfigApi _api;

    public NgMailConfigBusiness(INgMailConfigApi api, ILogger<NgMailConfigBusiness> logger,
        ErrorHandler errorHandler) : base(logger, errorHandler) => _api = api;

    /// <summary>
    /// API không có endpoint lấy 1 event, chỉ có danh sách. Gọi không kèm module
    /// rồi lọc tại chỗ: danh sách này chỉ vài dòng, và làm vậy thì không phải
    /// đoán event của Hàng bất thường nằm ở module nào — đoán sai là màn trắng
    /// mà không báo lỗi gì.
    /// </summary>
    public Task<Result<NgEmailEventDto?>> GetEventAsync(string eventCode)
        => ExecuteAsync(async () =>
        {
            var all = await _api.GetEventsAsync(null);
            return all.FirstOrDefault(e =>
                string.Equals(e.Code, eventCode, StringComparison.OrdinalIgnoreCase));
        });

    public Task<Result<List<NgEmailConfigDto>>> GetConfigsAsync(string eventCode)
        => ExecuteAsync(() => _api.GetConfigsAsync(eventCode));

    public Task<Result> SaveConfigAsync(NgEmailConfigDto c)
        => ExecuteAsync(async () =>
        {
            var body = new SaveNgEmailConfigRequestDto
            {
                EventCode = c.EventCode,
                Department = Blank(c.Department),
                SubCode = Blank(c.SubCode),
                Category = Blank(c.Category),
                Model = Blank(c.Model),
                AreaCode = Blank(c.AreaCode),
                RecipientType = c.RecipientType,
                UserId = c.UserId,
                Email = Blank(c.Email),
                DisplayName = Blank(c.DisplayName),
                IsActive = c.IsActive,
            };

            if (c.Id == 0) await _api.CreateConfigAsync(body);
            else await _api.UpdateConfigAsync(c.Id, body);
        });

    public Task<Result> DeleteConfigAsync(long id)
        => ExecuteAsync(() => _api.DeleteConfigAsync(id));

    public Task<Result> SaveTemplateAsync(string eventCode, string subject, string? body)
        => ExecuteAsync(() => _api.SaveTemplateAsync(eventCode,
            new SaveNgTemplateRequestDto { Subject = subject, Body = body }));

    /// <summary>
    /// Ô để trống phải gửi đi là NULL, không phải chuỗi rỗng. Hai thứ này mang
    /// nghĩa khác hẳn nhau trong master.email_config: NULL ở một cột nghĩa là
    /// "áp cho MỌI giá trị", còn chuỗi rỗng là một giá trị cụ thể chẳng khớp ai.
    /// </summary>
    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}
