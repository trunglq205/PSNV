﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace SWMS_WebTool.Models.Filters
{
    public class SupplyFilter : BaseFilter
    {
        public String CurrentTime { get; set; } = DateTime.Now.ToString("HH:mm");
        public string Category { get; set; }
        public string Line { get; set; }
        public string Modal { get; set; }
        public bool IsLoadByTime { get; set; } = true;
        public DateTime DeliveryDate { get; set; } = DateTime.Now;
        public ActionStatusEnum? Status { get; set; }
        public SupplyStatusEnum? SupplyStatus { get; set; }
        public KittingTab Tab { get; set; }
        public KittingType? Type { get; set; }
    }

    public class SupplyRequestVM
    {
        public string CurrentTime { get; set; }
        public string Category { get; set; }
        public string Line { get; set; }
        public string Model { get; set; }
        public string DeliveryDate { get; set; }
        public byte ActionStatus { get; set; } = 0;
    }

    public enum ActionStatusEnum
    {
        [EnumMember(Value = "0")]
        [Description("Status_Empty2")]
        Empty,

        [EnumMember(Value = "1")]
        [Description("Status_Kitting")]
        Kitting,

        [EnumMember(Value = "2")]
        [Description("Status_Checked")]
        Checked,

        [EnumMember(Value = "3")]
        [Description("Status_Supplied")]
        Supplied,
    }

    public enum SupplyStatusEnum : byte
    {
        [EnumMember(Value = "0")]
        [Description("Status_Waiting")]
        Waiting = 0,

        [EnumMember(Value = "3")]
        [Description("Status_Delay")]
        Delay = 3,

        [EnumMember(Value = "2")]
        [Description("Status_Ok")]
        Ok = 2,

        [EnumMember(Value = "4")]
        [Description("Status_Stop")]
        Stop = 4,
    }
}
