// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'robot_call_request_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

RobotCallRequestModel _$RobotCallRequestModelFromJson(
        Map<String, dynamic> json) =>
    RobotCallRequestModel(
      qrcode: json['qrcode'] as String,
      isUgent: json['isUgent'] as bool,
      isCancel: json['isCancel'] as bool,
    );

Map<String, dynamic> _$RobotCallRequestModelToJson(
        RobotCallRequestModel instance) =>
    <String, dynamic>{
      'qrcode': instance.qrcode,
      'isUgent': instance.isUgent,
      'isCancel': instance.isCancel,
    };
