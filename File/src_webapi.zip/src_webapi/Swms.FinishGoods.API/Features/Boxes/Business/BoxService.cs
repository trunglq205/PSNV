﻿using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Boxes.Api;
using Swms.FinishGoods.API.Features.Boxes.DataAccess;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.Boxes.Business
{
    public interface IBoxService
    {
        /// <summary>Chi tiết box theo id (định danh duy nhất).</summary>
        Task<BoxDetailResponse?> GetBoxDetailAsync(long id);

        /// <summary>
        /// Chi tiết box theo box_no khi quét. box_no không duy nhất toàn cục,
        /// nên cần palletId để lọc; nếu vẫn còn nhiều kết quả thì báo lỗi.
        /// </summary>
        Task<BoxDetailResponse?> GetBoxDetailByBoxNoAsync(string boxNo, string? palletId);

        /// <summary>Cập nhật PO theo id.</summary>
        Task<BoxDetailResponse?> UpdatePoAsync(long id, BoxPatchRequest req);
    }

    public class BoxService : IBoxService
    {
        private readonly IBoxRepository _repo;
        private readonly ICurrentUser _currentUser;

        public BoxService(IBoxRepository repo, ICurrentUser currentUser)
        {
            _repo = repo;
            _currentUser = currentUser;
        }

        public async Task<BoxDetailResponse?> GetBoxDetailAsync(long id)
        {
            if (id <= 0) return null;

            var box = await _repo.GetByIdAsync(id);
            return box is null ? null : BoxDetailResponse.From(box);
        }

        public async Task<BoxDetailResponse?> GetBoxDetailByBoxNoAsync(string boxNo, string? palletId)
        {
            boxNo = (boxNo ?? "").Trim();
            if (boxNo.Length == 0) return null;

            palletId = Normalize(palletId);

            var boxes = await _repo.FindByBoxNoAsync(boxNo, palletId);
            if (boxes.Count == 0) return null;

            if (boxes.Count > 1)
                throw new NotFoundException("Box.Ambiguous");

            return BoxDetailResponse.From(boxes[0]);
        }

        public async Task<BoxDetailResponse?> UpdatePoAsync(long id, BoxPatchRequest req)
        {
            if (id <= 0) return null;

            var customerPo = Normalize(req.CustomerPo);
            var psnvPo = Normalize(req.PsnvPo);

            // actor đi kèm để repository ghi được BOX_PO_CHANGED và cột updated_by
            // (trước đây UPDATE không set updated_by).
            var affected = await _repo.UpdatePoAsync(
                id, customerPo, psnvPo, _currentUser.FullName);

            if (affected == 0) return null;

            var box = await _repo.GetByIdAsync(id);
            return box is null ? null : BoxDetailResponse.From(box);
        }

        // null hoặc rỗng => null (xoá giá trị)
        private static string? Normalize(string? value)
        {
            var v = (value ?? "").Trim();
            return v.Length == 0 ? null : v;
        }
    }
}