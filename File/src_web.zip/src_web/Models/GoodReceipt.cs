﻿using System.ComponentModel.DataAnnotations;
using Newtonsoft.Json;
using SWMS_WebTool.Models.Responses;

namespace SWMS_WebTool.Models
{
    public class GoodReceipt
	{
        public int Id { get; set; }
        public DeliveryPlanType Type { get; set; }
        public string VendorCode { get; set; }
        public string DeliveryPlanNo { get; set; }
        public string DeliveryPlanItem { get; set; }
        [JsonProperty("poNo")]
        public string PurchaseOrderNo { get; set; }
        [JsonProperty("poItem")]
        public string PurchaseOrderItem { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }
        public string Urgent { get; set; }
        public double ActualQuantity { get; set; }
        public double PlanQuantity { get; set; }
        public string TrackingNumber { get; set; }
        public DeliveryPlanStatus Status { get; set; }
        [DataType(DataType.Date)]

        public DateTime? CreatedDate { get; set; }
        public DateTime? DatePlant { get; set; }

        [DataType(DataType.Date)]
        [JsonProperty("updatedDate")]

        public DateTime? ReceivedDate { get; set; }
        public DateTime? ReceivingCardDate { get; set; }
        public DateTime? DateTimeToSAP { get; set; }
        public string ReceivingCardTime { get; set; }
        [DataType(DataType.Date)]
        [JsonProperty("storedtime")]

        public DateTime? StoredDate { get; set; }

        public string iqcpl { get; set; }
        public string rosh { get; set; }    

        public double ReceivedProcess
        {
            get { return (double)ActualQuantity / PlanQuantity * 100; }
        }
        public class ConfirmInputModel
        {
            public List<InputTrackingNumberResponse> selectedItems { get; set; }
            public string trackingnumber { get; set; }
        }
    }
}

