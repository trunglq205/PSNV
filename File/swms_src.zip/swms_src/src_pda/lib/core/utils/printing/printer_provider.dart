import 'dart:convert';

import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/label.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/utils/printing/sato/bluetooth_discovery.dart';
import 'package:swms_finish_goods/core/utils/printing/sato/sato_printer.dart';
import 'package:swms_finish_goods/core/utils/printing/tspl/tspl_printer.dart';

part 'printer_provider.g.dart';

const _kSelectedPrinterKey = 'printer.selected';

// ─── Hạ tầng ───────────────────────────────────────────────────────────────

/// MỘT driver cho MỖI ngôn ngữ (family theo [PrinterLanguage]).
///
/// keepAlive: driver giữ hàng đợi job nội bộ để chống double-tap.
/// Nếu để autoDispose, hàng đợi bị reset mỗi lần rời màn hình.
@Riverpod(keepAlive: true)
Printer printer(Ref ref, PrinterLanguage language) {
  final Printer printer = switch (language) {
    PrinterLanguage.sbpl => SatoPrinter(),
    PrinterLanguage.tspl => TsplPrinter(),
  };
  ref.onDispose(printer.dispose);
  return printer;
}

@Riverpod(keepAlive: true)
BluetoothDiscovery bluetoothDiscovery(Ref ref) => const BluetoothDiscovery();

/// Danh sách máy in đã ghép đôi. autoDispose để mỗi lần mở màn hình chọn
/// máy in là đọc lại — công nhân có thể vừa pair thêm máy trong Settings.
///
/// Mỗi thiết bị được điền [PrinterLanguage] ĐOÁN theo tên; UI chọn máy
/// phải cho người dùng sửa lại trước khi [SelectedPrinter.select].
@riverpod
Future<List<PrinterDevice>> pairedPrinters(Ref ref) async {
  final devices = await ref
      .watch(bluetoothDiscoveryProvider)
      .pairedDevices()
      .timeout(
    const Duration(seconds: 5),
    onTimeout: () => throw const PrinterException(
      PrinterErrorType.connect,
      message: 'Không đọc được danh sách máy in (hết thời gian chờ quyền Bluetooth)',
    ),
  );
  return devices
      .map((d) => d.copyWith(language: PrinterLanguage.guessFromName(d.name)))
      .toList(growable: false);
}

// ─── Máy in đang chọn (nhớ giữa các lần mở app) ─────────────────────────────

/// Lưu MAC + ngôn ngữ sau lần chọn đầu để công nhân không phải chọn lại
/// mỗi phiên.
@Riverpod(keepAlive: true)
class SelectedPrinter extends _$SelectedPrinter {
  @override
  PrinterDevice? build() {
    // requireValue theo đúng pattern của secureStorageProvider — yêu cầu
    // appLocalManagerProvider đã được warm-up trước ở main().
    final raw = ref
        .watch(appLocalManagerProvider)
        .requireValue
        .readString(_kSelectedPrinterKey);

    if (raw == null || raw.isEmpty) return null;
    try {
      return PrinterDevice.fromJson(jsonDecode(raw) as Map<String, dynamic>);
    } catch (_) {
      // Dữ liệu cũ/hỏng: coi như chưa chọn. Không cho crash lúc khởi động.
      return null;
    }
  }

  /// Chỉ ghi nhận lựa chọn — KHÔNG kết nối. Kết nối xảy ra lúc in.
  ///
  /// [device.language] được lưu theo — chọn sai ngôn ngữ thì tem ra rác,
  /// nên UI phải hiện rõ SATO/TSPL trước khi gọi.
  Future<void> select(PrinterDevice device) async {
    state = device;
    await ref
        .read(appLocalManagerProvider)
        .requireValue
        .writeString(_kSelectedPrinterKey, jsonEncode(device.toJson()));
  }

  Future<void> clear() async {
    state = null;
    await ref
        .read(appLocalManagerProvider)
        .requireValue
        .remove(_kSelectedPrinterKey);
  }
}

// ─── Điểm vào duy nhất của UI ───────────────────────────────────────────────

typedef _PrintJob =
    Future<void> Function(Printer printer, PrinterDevice device);

/// UI không biết SATO, không biết TSPL, không biết Bluetooth.
///
/// Driver chọn theo `language` của máy in đang chọn; tem tự sinh lệnh
/// đúng ngôn ngữ qua [Label.toBytes].
///
/// Trạng thái in nằm luôn trong [state]:
/// - `isLoading` → đang in, disable nút
/// - `hasError`  → lỗi, đọc `error` để hiện message
@riverpod
class PrintController extends _$PrintController {
  @override
  FutureOr<void> build() {}

  /// In MỘT tem ([PartCardData], [PartCardMultiData]...) [copies] bản.
  Future<void> printLabel(Label label, {int copies = 1}) => _run(
    (printer, device) => printer.printBytes(
      device,
      label.toBytes(language: device.language, copies: copies),
    ),
  );

  /// Nhiều tem khác nhau (CÙNG loại) trong MỘT phiên kết nối.
  Future<void> printLabels(List<Label> labels) => _run(
    (printer, device) => printer.printBytes(
      device,
      Label.batchToBytes(language: device.language, labels: labels),
    ),
  );

  Future<void> _run(_PrintJob job) async {
    final device = ref.read(selectedPrinterProvider);
    if (device == null) {
      state = AsyncError(
        const PrinterException(
          PrinterErrorType.connect,
          message: 'Chưa chọn máy in',
        ),
        StackTrace.current,
      );
      return;
    }
    final printer = ref.read(printerProvider(device.language));
    state = const AsyncLoading();
    state = await AsyncValue.guard(() => job(printer, device));
  }
}
