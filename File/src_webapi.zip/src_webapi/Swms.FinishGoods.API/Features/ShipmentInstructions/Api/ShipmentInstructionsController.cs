using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Microsoft.AspNetCore.Authorization;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

[ApiController]
[Route("api/shipment-instructions")]
public class ShipmentInstructionsController : ControllerBase
{
    private readonly IShipmentInstructionService _service;
    public ShipmentInstructionsController(IShipmentInstructionService service) => _service = service;

    // ── Danh sách / chi tiết ────────────────────────────────

    [HttpGet]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<PagedResult<SiListItemResponse>>> GetAll([FromQuery] SiQuery query)
        => Ok(await _service.GetPagedAsync(query));

    [HttpGet("status-counts")]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<SiStatusCountResponse>> GetStatusCounts()
        => Ok(await _service.GetStatusCountsAsync());

    [HttpGet("{id:long}")]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<SiDetailResponse>> GetById(long id)
        => Ok(await _service.GetByIdAsync(id));

    /// <summary>Lịch sử SAP gửi SI này: ai sửa (pic), lúc nào, đổi gì — mới nhất trước.
    /// onlyChanges = true: bỏ các lần không đổi gì / bị từ chối.</summary>
    [HttpGet("{id:long}/history")]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<List<SiHistoryItemResponse>>> GetHistory(long id, [FromQuery] bool onlyChanges = false)
        => Ok(await _service.GetHistoryAsync(id, onlyChanges));

    // ── Header ──────────────────────────────────────────────

    [HttpPost]
    [RequirePermission<Perms.Outbound.Si.Create>]
    public async Task<ActionResult<SiDetailResponse>> Create(CreateSiRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    /// <summary>Nhận SI từ SAP với payload NGUYÊN DẠNG của SAP (documentno, sino, c_orderline…).
    /// Cùng 1 sino gửi nhiều lần (sửa lại / lên revision) -> cập nhật vào phiếu đã có.
    /// 201 = tạo mới, 200 = đã cập nhật hoặc không có gì đổi,
    /// 409 = revision cũ hơn phiếu đang có / doc_no đã thuộc phiếu khác,
    /// 400 = payload thiếu / sai, hoặc thay đổi đụng dòng đã phân bổ (liệt kê từng lỗi).
    /// Ai sửa / lúc nào / đổi gì: SapInboundLogFilter ghi vào sap_inbound_logs.</summary>
    [HttpPost("sap")]
    [AllowAnonymous]
    [ServiceFilter(typeof(SapInboundLogFilter))]
    public async Task<ActionResult<SiDetailResponse>> CreateFromSap(SapSiRequest request)
    {
        var (si, created) = await _service.CreateFromSapAsync(request);
        return created ? CreatedAtAction(nameof(GetById), new { id = si.Id }, si) : Ok(si);
    }

    [HttpPut("{id:long}")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<IActionResult> Update(long id, UpdateSiRequest request)
    {
        await _service.UpdateAsync(id, request);
        return NoContent();
    }

    [HttpDelete("{id:long}")]
    [RequirePermission<Perms.Outbound.Si.Delete>]
    public async Task<IActionResult> Delete(long id)
    {
        await _service.DeleteAsync(id);
        return NoContent();
    }

    [HttpPost("{id:long}/cancel")]
    [RequirePermission<Perms.Outbound.Si.Cancel>]
    public async Task<IActionResult> Cancel(long id, CancelSiRequest request)
    {
        await _service.CancelAsync(id, request);
        return NoContent();
    }

    /// <summary>Đánh dấu SI đã hoàn thành — chỉ đổi trạng thái, không kiểm tra hàng đã lấy / đã vanning.</summary>
    [HttpPost("{id:long}/complete")]
    [RequirePermission<Perms.Outbound.Si.Completed>]
    public async Task<IActionResult> Complete(long id)
    {
        await _service.CompleteAsync(id);
        return NoContent();
    }

    // ── Line ────────────────────────────────────────────────

    [HttpPost("{id:long}/lines")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<ActionResult<SiLineResponse>> AddLine(long id, SiLineRequest request)
        => Ok(await _service.AddLineAsync(id, request));

    [HttpPut("lines/{lineId:long}")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<IActionResult> UpdateLine(long lineId, SiLineRequest request)
    {
        await _service.UpdateLineAsync(lineId, request);
        return NoContent();
    }

    [HttpDelete("lines/{lineId:long}")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<IActionResult> DeleteLine(long lineId)
    {
        await _service.DeleteLineAsync(lineId);
        return NoContent();
    }

    /// <summary>QtyCut = tổng số cắt của dòng; null = bỏ cắt.</summary>
    [HttpPost("lines/{lineId:long}/cut")]
    [RequirePermission<Perms.Outbound.Si.Cut>]
    public async Task<IActionResult> CutLine(long lineId, CutLineRequest request)
    {
        await _service.CutLineAsync(lineId, request);
        return NoContent();
    }

    // ── Phân bổ ─────────────────────────────────────────────

    /// <summary>LineId = null: cả phiếu. Dòng có mã thùng chỉ định chạy chế độ designated, còn lại FIFO.</summary>
    [HttpPost("{id:long}/allocate")]
    [RequirePermission<Perms.Outbound.Si.Allocate>]
    public async Task<ActionResult<AllocateResponse>> Allocate(long id, AllocateRequest request)
        => Ok(await _service.AllocateAsync(id, request));

    [HttpGet("{id:long}/tasks")]
    [RequirePermission<Perms.Outbound.Si.View>]
    public async Task<ActionResult<List<SiTaskResponse>>> GetTasks(long id)
        => Ok(await _service.GetTasksAsync(id));

    [HttpPut("tasks/{taskId:long}")]
    [RequirePermission<Perms.Outbound.Si.Allocate>]
    public async Task<IActionResult> UpdateTask(long taskId, UpdateTaskRequest request)
    {
        await _service.UpdateTaskAsync(taskId, request);
        return NoContent();
    }

    [HttpDelete("tasks/{taskId:long}")]
    [RequirePermission<Perms.Outbound.Si.Allocate>]
    public async Task<IActionResult> ReleaseTask(long taskId)
    {
        await _service.ReleaseTaskAsync(taskId);
        return NoContent();
    }

    // ── Mã thùng chỉ định ───────────────────────────────────

    /// <summary>Replace = true: thay danh sách cũ (chỉ phần chưa vào kế hoạch). Khớp ngay sau khi lưu.</summary>
    [HttpPost("lines/{lineId:long}/boxes")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<ActionResult<List<SiBoxResponse>>> DesignateBoxes(long lineId, DesignateBoxesRequest request)
        => Ok(await _service.DesignateBoxesAsync(lineId, request));

    [HttpPost("lines/{lineId:long}/boxes/rematch")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<ActionResult<List<SiBoxResponse>>> RematchBoxes(long lineId)
        => Ok(await _service.RematchBoxesAsync(lineId));

    [HttpPut("boxes/{id:long}/resolve")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<IActionResult> ResolveBox(long id, ResolveBoxRequest request)
    {
        await _service.ResolveBoxAsync(id, request);
        return NoContent();
    }

    [HttpDelete("boxes/{id:long}")]
    [RequirePermission<Perms.Outbound.Si.Update>]
    public async Task<IActionResult> DeleteBox(long id)
    {
        await _service.DeleteBoxAsync(id);
        return NoContent();
    }

    // ── Lấy hàng (PDA) ──────────────────────────────────────

    /// <summary>Màn lấy hàng tại 1 vị trí: dòng kế hoạch + thùng (fifo / chỉ định) kèm trạng thái.</summary>
    [HttpGet("tasks/{taskId:long}/pick")]
    [RequirePermission<Perms.Outbound.Si.Pick>]
    public async Task<ActionResult<PickTaskDetailResponse>> GetPickTask(long taskId)
        => Ok(await _service.GetPickTaskAsync(taskId));

    /// <summary>Lấy nguyên pallet: Pallet ID quét phải khớp, đóng dòng kế hoạch.</summary>
    [HttpPost("tasks/{taskId:long}/confirm-pallet")]
    [RequirePermission<Perms.Outbound.Si.Pick>]
    public async Task<ActionResult<PickTaskDetailResponse>> ConfirmPallet(long taskId, ConfirmPalletRequest request)
        => Ok(await _service.ConfirmPalletAsync(taskId, request));

    /// <summary>Quét 1 thùng (fifo / chỉ định). Đủ thùng tự đóng dòng kế hoạch.</summary>
    [HttpPost("tasks/{taskId:long}/boxes")]
    [RequirePermission<Perms.Outbound.Si.Pick>]
    public async Task<ActionResult<PickTaskDetailResponse>> PickBox(long taskId, PickBoxRequest request)
        => Ok(await _service.PickBoxAsync(taskId, request));

    /// <summary>Gỡ thùng quét nhầm.</summary>
    [HttpDelete("tasks/{taskId:long}/boxes/{boxNo}")]
    [RequirePermission<Perms.Outbound.Si.Pick>]
    public async Task<ActionResult<PickTaskDetailResponse>> UnpickBox(long taskId, string boxNo)
        => Ok(await _service.UnpickBoxAsync(taskId, boxNo));

    // ── Vanning (PDA) ───────────────────────────────────────

    /// <summary>Lưu pallet tại vị trí vanning: pallet phải chứa hàng đã lấy, vị trí phải thuộc khu vanning
    /// (và khớp vị trí chỉ định nếu có). Không lưu cột riêng — dời pallet sang vị trí đó.</summary>
    [HttpPost("tasks/{taskId:long}/vanning")]
    [RequirePermission<Perms.Outbound.Si.Pick>]
    public async Task<ActionResult<PickTaskDetailResponse>> StageVanning(long taskId, StageVanningRequest request)
        => Ok(await _service.StageVanningAsync(taskId, request));
}