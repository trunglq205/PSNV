﻿namespace SWMS_WebTool.Models
{

    public class TrolleyRequest
    {
        public string Name { get; set; }
        public string Code { get; set; }
        public string Category { get; set; }
    }
}
