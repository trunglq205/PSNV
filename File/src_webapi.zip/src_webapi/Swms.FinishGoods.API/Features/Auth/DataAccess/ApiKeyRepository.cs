﻿using Dapper;
using Swms.FinishGoods.API.Features.Auth.Business;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Auth.DataAccess;

public sealed class ApiKeyRepository : IApiKeyRepository
{
    private readonly IDbConnectionFactory _factory;

    public ApiKeyRepository(IDbConnectionFactory factory) => _factory = factory;

    // Cột dùng chung — alias snake_case -> PascalCase (giống mẫu PartCardRepository).
    private const string Columns = """
        id AS Id,
        client_name AS ClientName,
        key_prefix AS KeyPrefix,
        key_hash AS KeyHash,
        permissions_csv AS PermissionsCsv,
        is_active AS IsActive,
        expires_at AS ExpiresAt,
        last_used_at AS LastUsedAt,
        revoked_at AS RevokedAt,
        is_deleted AS IsDeleted,
        created_at AS CreatedAt,
        created_by AS CreatedBy,
        updated_at AS UpdatedAt,
        updated_by AS UpdatedBy
        """;

    private const string InsertSql = """
        INSERT INTO master.api_keys
            (client_name, key_prefix, key_hash, permissions_csv,
             is_active, expires_at, is_deleted, created_at, created_by)
        VALUES
            (@ClientName, @KeyPrefix, @KeyHash, @PermissionsCsv,
             @IsActive, @ExpiresAt, 0, @CreatedAt, @CreatedBy);
        SELECT CAST(SCOPE_IDENTITY() AS bigint);
        """;

    public async Task<long> CreateAsync(ApiKey k)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<long>(InsertSql, k);
    }

    public async Task<ApiKey?> GetByPrefixAsync(string prefix)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {Columns} FROM master.api_keys
            WHERE key_prefix = @prefix AND is_deleted = 0;
            """;
        return await conn.QueryFirstOrDefaultAsync<ApiKey>(sql, new { prefix });
    }

    public async Task<ApiKey?> GetByIdAsync(long id)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {Columns} FROM master.api_keys
            WHERE id = @id AND is_deleted = 0 AND is_active = 1;
            """;
        return await conn.QueryFirstOrDefaultAsync<ApiKey>(sql, new { id });
    }

    public async Task<IReadOnlyList<ApiKey>> ListAsync()
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {Columns} FROM master.api_keys
            WHERE is_deleted = 0 AND is_active = 1
            ORDER BY client_name, created_at DESC;
            """;
        return (await conn.QueryAsync<ApiKey>(sql)).ToList();
    }

    public async Task UpdateLastUsedAsync(long id, DateTime utcNow)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync(
            "UPDATE master.api_keys SET last_used_at = @utcNow WHERE id = @id",
            new { id, utcNow });
    }

    public async Task RevokeAsync(long id, DateTime utcNow, string? by)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.api_keys
            SET is_active = 0, revoked_at = @utcNow,
                updated_at = @utcNow, updated_by = @by
            WHERE id = @id;
            """;
        await conn.ExecuteAsync(sql, new { id, utcNow, by });
    }

    // Trong 1 transaction: revoke MỌI key active cùng client, rồi insert key mới.
    public async Task<long> RotateForClientAsync(ApiKey newKey, string clientName, DateTime utcNow, string? by)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string revokeSql = """
            UPDATE master.api_keys
            SET is_active = 0, revoked_at = @utcNow,
                updated_at = @utcNow, updated_by = @by
            WHERE client_name = @clientName AND is_active = 1 AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(revokeSql, new { clientName, utcNow, by }, tx);

        var newId = await conn.ExecuteScalarAsync<long>(InsertSql, newKey, tx);

        tx.Commit();
        return newId;
    }
}