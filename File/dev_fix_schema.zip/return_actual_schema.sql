/* ============================================================================
   MỤC 2b — Chốt SL thực nhận và báo FA số thực tế.

   Chạy MỘT LẦN trên DB SWMS, SAU return_receiving_schema.sql. Idempotent.

   Tạo ra:
     1. 4 cột trên wms.return_instructions: dấu vết chốt thực nhận + dấu vết
        mail báo số thực tế.
     2. Sự kiện mail RETURN_ACTUAL_CONFIRMED trong master.email_events.

   KHÔNG lưu SL thực nhận thành cột:
     SL thực nhận = số serial trong wms.return_instruction_serials, đếm là ra.
     Lưu thêm một con số đếm được là phải nhớ cập nhật ở mọi đường ghi serial
     (nhận hàng, huỷ pallet, giao FA, nhận lại, xuất) — quên một đường là lệch
     vĩnh viễn, mà đây lại đúng là con số đem đi so với chỉ thị.

   KHÔNG ghi SL thực nhận đè lên wms.return_instruction_lines.qty:
     qty là MỐC để so. Ghi đè nó là mất luôn cái để so, và bảng lệch
     plan vs thực tế từ đó về sau luôn báo lệch = 0.
   ============================================================================ */
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ---------- 0. Tiền đề ---------- */
IF OBJECT_ID(N'wms.return_instructions', N'U') IS NULL
BEGIN
    RAISERROR(N'Chua co bang wms.return_instructions — chay return_instruction_schema.sql truoc.', 16, 1);
    RETURN;
END;

IF OBJECT_ID(N'wms.return_instruction_serials', N'U') IS NULL
BEGIN
    RAISERROR(N'Chua co bang wms.return_instruction_serials — chay return_receiving_schema.sql truoc.', 16, 1);
    RETURN;
END;

/* ---------- 1. Cột dấu vết chốt thực nhận ---------- */
/* ⚠ Mỗi ALTER bọc trong EXEC, và MỌI câu nhắc tới các cột này về sau cũng phải
   bọc EXEC. Cả file là một batch (không có GO), mà SQL Server bind tên cột
   theo cấu trúc bảng tại lúc compile CẢ batch — câu ALTER chưa kịp chạy thì
   batch đã lỗi 207 và không câu nào được thực thi. Cùng cái bẫy đã gặp ở
   return_receiving_schema.sql. */

IF COL_LENGTH(N'wms.return_instructions', N'closed_at') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_instructions ADD closed_at DATETIME2(0) NULL');
    PRINT N'+ closed_at';
END
ELSE PRINT N'= closed_at da co';

IF COL_LENGTH(N'wms.return_instructions', N'closed_by') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_instructions ADD closed_by NVARCHAR(100) NULL');
    PRINT N'+ closed_by';
END
ELSE PRINT N'= closed_by da co';

/* Dấu vết mail BÁO SỐ THỰC TẾ — tách riêng khỏi mail_sent_at (mail báo lúc
   TẠO phiếu). Dùng chung một cột là không phân biệt được "FA đã biết phiếu"
   với "FA đã biết số thực nhận", mà đó là hai việc khác nhau. */
IF COL_LENGTH(N'wms.return_instructions', N'actual_mail_sent_at') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_instructions ADD actual_mail_sent_at DATETIME2(0) NULL');
    PRINT N'+ actual_mail_sent_at';
END
ELSE PRINT N'= actual_mail_sent_at da co';

IF COL_LENGTH(N'wms.return_instructions', N'actual_mail_sent_to') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.return_instructions ADD actual_mail_sent_to NVARCHAR(2000) NULL');
    PRINT N'+ actual_mail_sent_to';
END
ELSE PRINT N'= actual_mail_sent_to da co';

/* ---------- 2. Sự kiện mail báo số thực tế ---------- */
/* Người nhận KHÔNG khai ở đây: khai trong màn Cấu hình email
   (master.email_config) với department = 'FA'. Thêm bộ phận khác vào cấu hình
   là họ tự nhận, không phải build lại. */

DECLARE @subject nvarchar(400) =
    N'[SWMS] SL thực nhận {DocNo} ({GoodsType}) — kế hoạch {PlanQty}, thực nhận {ActualQty}{DiffLabel}';

/* Mẫu viết bằng MARKDOWN, không phải HTML — đúng quy ước của hệ thống (giống
   mail hàng thiếu và hàng bất thường): API dựng HTML từ markdown lúc gửi
   (Shared/Business/Mail/MarkdownMail.cs), còn màn Cấu hình email trên web
   render cùng một pipeline để XEM TRƯỚC ra đúng lá mail sẽ gửi. Nhét thẻ HTML
   vào đây thì phần xem trước hiện ra nguyên thẻ cho người dùng đọc. */
DECLARE @body nvarchar(max) =
N'Kính gửi FA,

SCS WH đã nhận xong hàng của chỉ thị **{DocNo}**. Số lượng thực nhận như sau.

| Thông tin | Nội dung |
|---|---|
| Loại hàng | **{GoodsType}** |
| Khách hàng | {Customer} |
| SL theo chỉ thị | {PlanQty} |
| SL thực nhận | **{ActualQty}** |
| Chênh lệch | **{DiffQty}** |
| Chốt lúc | {ClosedAt} — {ClosedBy} |

**Chi tiết theo model:**
{DiffTable}
Ghi chú: {Note}

Xem trên hệ thống: {Link}

*Mail tự động từ SWMS Finish Goods — {Now}*';

IF NOT EXISTS (SELECT 1 FROM master.email_events WHERE code = N'RETURN_ACTUAL_CONFIRMED')
BEGIN
    INSERT INTO master.email_events
        (code, module, name_key, description, subject_template, body_template,
         is_active, sort_order)
    VALUES
        (N'RETURN_ACTUAL_CONFIRMED',
         N'RECEIVING',
         N'email.RETURN_ACTUAL_CONFIRMED',
         N'Báo FA số lượng THỰC NHẬN khi SCS WH chốt phiếu back hàng (kèm bảng lệch so với chỉ thị)',
         @subject,
         @body,
         1,
         /* Đặt cuối nhóm RECEIVING đang có, không chen vào giữa. */
         (SELECT ISNULL(MAX(sort_order), 0) + 1 FROM master.email_events WHERE module = N'RECEIVING'));

    PRINT N'+ Da them su kien mail RETURN_ACTUAL_CONFIRMED';
END
ELSE
BEGIN
    /* Đã có từ lần chạy trước — chỉ cập nhật mẫu khi CHƯA ai sửa tay
       (updated_at còn NULL). Người dùng đã chỉnh mẫu trong màn Cấu hình email
       thì tôn trọng, không đè. Cùng quy ước với mục 1. */
    UPDATE master.email_events
    SET subject_template = @subject,
        body_template    = @body
    WHERE code = N'RETURN_ACTUAL_CONFIRMED'
      AND updated_at IS NULL;

    PRINT N'= Su kien RETURN_ACTUAL_CONFIRMED da co'
        + IIF(@@ROWCOUNT > 0, N' — da cap nhat lai mau.', N' — mau da duoc sua tay, giu nguyen.');
END;

/* ---------- 3. Kiểm lại ---------- */
SELECT N'Cot moi tren wms.return_instructions' AS section;

SELECT c.name, t.name AS kieu, c.max_length, c.is_nullable
FROM   sys.columns c
JOIN   sys.types   t ON t.user_type_id = c.user_type_id
WHERE  c.object_id = OBJECT_ID(N'wms.return_instructions')
  AND  c.name IN (N'closed_at', N'closed_by', N'actual_mail_sent_at', N'actual_mail_sent_to')
ORDER BY c.name;

SELECT N'Su kien mail' AS section;

/* con_the_html: mẫu đã bị sửa tay thành HTML thì script này KHÔNG đè (updated_at
   khác NULL), và màn Cấu hình email sẽ hiện nguyên thẻ trong phần xem trước —
   soi luôn ở đây để biết phải vào sửa lại bằng markdown, chứ không đi tìm. */
SELECT code, module, is_active, sort_order,
       LEFT(subject_template, 80) AS subject_dau,
       da_sua_tay   = IIF(updated_at IS NULL, N'khong', N'CO'),
       con_the_html = IIF(body_template LIKE N'%<p>%'
                       OR body_template LIKE N'%<table%'
                       OR body_template LIKE N'%<b>%', N'CON — sua lai bang markdown', N'khong')
FROM   master.email_events
WHERE  code IN (N'RETURN_INSTRUCTION_CREATED', N'RETURN_ACTUAL_CONFIRMED')
ORDER BY sort_order;

SELECT N'Nguoi nhan da khai chua' AS section;

/* Chưa khai người nhận thì mail không gửi được, và màn hình sẽ hiện "chưa báo
   FA" — kiểm luôn ở đây để không phải đi tìm. */
SELECT su_kien = N'RETURN_ACTUAL_CONFIRMED',
       so_nguoi_nhan = (SELECT COUNT(*)
                        FROM master.fn_email_recipients(
                                 N'RETURN_ACTUAL_CONFIRMED', NULL, NULL, NULL, NULL, NULL));

SELECT N'So lieu phieu' AS section;

/* Bọc EXEC vì có nhắc closed_at — xem ghi chú ở mục 1. */
EXEC(N'
    SELECT so_phieu_dang_mo   = SUM(IIF(doc_status = N''open'', 1, 0)),
           so_phieu_da_chot   = SUM(IIF(closed_at IS NOT NULL, 1, 0)),
           so_phieu_da_bao_FA = SUM(IIF(actual_mail_sent_at IS NOT NULL, 1, 0))
    FROM   wms.return_instructions
    WHERE  is_deleted = 0');
