import 'package:swms_finish_goods/features/receiving/data/datasources/receiving_remote_data_source.dart';
import 'package:swms_finish_goods/features/receiving/data/models/create_lot_request_model.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/create_lot_params.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/lot_entities.dart';
import 'package:swms_finish_goods/features/receiving/domain/repositories/receiving_repository.dart';
import 'package:swms_finish_goods/shared/data/datasource/model_remote_data_source.dart';
import 'package:swms_finish_goods/shared/data/models/model_response_model.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// Đối chiếu/tạo pallet lấy remote.
class ReceivingRepositoryImpl implements ReceivingRepository {
  final ReceivingRemoteDataSource _remote;
  final ModelRemoteDataSource _modelRemote;

  const ReceivingRepositoryImpl(this._remote, this._modelRemote);

  @override
  Future<CreatedLot> createLot(CreateLotParams params) async {
    // Chặn sớm các lỗi 422 ngay trên máy quét, khỏi tốn 1 vòng request.
    params.validate();

    // Lot active ngay sau 201 — không còn bước confirm.
    final response = await _remote.createLot(
      CreateLotRequestModel.fromParams(params),
    );
    return response.toEntity();
  }

  @override
  Future<ModelInfo> getModelInfo(String barcode) async {
    final response = await _modelRemote.fetchModelByCode(barcode.trim());

    return response.toEntity();
  }

  @override
  Future<ModelInfo> getModelInfoByGTIN(String barcode) async {
    final response = await _modelRemote.fetchModelByGTIN(barcode.trim());

    return response.toEntity();
  }

  @override
  Future<NextLotNo> getNextLotNo(int categoryCode) async {
    final response = await _remote.fetchNextLotNo(categoryCode);
    return response.toEntity();
  }
}