enum ChangeLocationType {
  oneByOne,
  all,
}
