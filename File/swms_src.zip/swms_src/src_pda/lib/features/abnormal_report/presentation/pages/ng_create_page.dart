import 'dart:async';
import 'dart:io';

import 'package:auto_route/auto_route.dart';
import 'package:dio/dio.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';
import 'package:swms_finish_goods/features/abnormal_report/presentation/providers/ng_providers.dart';

/// Bước 1 — SCS tạo phiếu: quét pallet, chọn phạm vi ảnh hưởng (bắt buộc
/// trước), chọn loại lỗi, chụp ảnh, mô tả. Phiếu tạo ra ở trạng thái nháp và
/// nằm chờ Leader SCS duyệt.
@RoutePage()
class NgCreatePage extends ConsumerStatefulWidget {
  const NgCreatePage({super.key});

  @override
  ConsumerState<NgCreatePage> createState() => _NgCreatePageState();
}

class _NgCreatePageState extends ConsumerState<NgCreatePage> {
  static const _maxPhotos = 5;

  final _palletCtrl = TextEditingController();
  final _codeCtrl = TextEditingController();
  final _descCtrl = TextEditingController();

  /// Loại lỗi đang chọn. null = danh mục chưa tải xong; lúc đó nút Gửi bị
  /// chặn, nên không có đường nào tạo phiếu thiếu loại lỗi.
  String? _ngType;

  /// Phạm vi ảnh hưởng — chọn 1 cho cả phiếu, theo đúng form nghiệp vụ.
  String _scope = 'serial';

  /// Mã đã quét, giữ riêng theo từng phạm vi để đổi qua lại không mất dữ liệu.
  final Map<String, List<String>> _codes = {'box': [], 'serial': []};

  List<File> _photos = [];
  bool _busy = false;
  StreamSubscription<String>? _scanSub;

  /// Pallet đã tra được trên hệ thống. null = chưa tra hoặc mã không tồn tại;
  /// khi null thì không cho gửi phiếu.
  NgPalletBrief? _palletInfo;
  bool _checking = false;
  String? _palletError;

  /// Mã ứng với [_palletInfo] — để biết người dùng có sửa tay sau khi tra xong.
  String _checkedCode = '';

  @override
  void initState() {
    super.initState();
    _listenScanner();
  }

  /// Máy quét cứng: chưa có pallet thì mã đầu tiên là pallet, sau đó mỗi mã
  /// quét được là 1 mục trong phạm vi đang chọn.
  Future<void> _listenScanner() async {
    final pda = await ref.read(pdaProvider.future);
    if (!mounted) return;
    _scanSub = pda.scanStream.listen((data) {
      if (!mounted || _busy) return;
      final code = data.trim();
      if (code.isEmpty) return;
      if (_palletInfo == null) {
        _palletCtrl.text = code;
        _checkPallet();
      } else if (_scope != 'pallet') {
        _addCode(code);
      }
    });
  }

  @override
  void dispose() {
    _scanSub?.cancel();
    _palletCtrl.dispose();
    _codeCtrl.dispose();
    _descCtrl.dispose();
    super.dispose();
  }

  String get _pallet => _palletCtrl.text.trim();
  List<String> get _items => _codes[_scope] ?? const [];

  /// Tra mã pallet trên hệ thống. Mã không có thì chặn ngay tại đây, để công
  /// nhân không điền hết phiếu và chụp ảnh rồi mới bị server từ chối.
  Future<void> _checkPallet() async {
    final code = _pallet;
    if (code.isEmpty) {
      setState(() {
        _palletInfo = null;
        _palletError = null;
        _checkedCode = '';
      });
      return;
    }
    if (_checking) return;

    setState(() {
      _checking = true;
      _palletError = null;
      _palletInfo = null;
    });
    try {
      final info = await ref.read(ngRepositoryProvider).checkPallet(code);
      if (!mounted) return;
      setState(() {
        _palletInfo = info;
        _checkedCode = code;
        _checking = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _palletError = _isNotFound(e)
            ? LocaleKeys.ng_pallet_not_found.tr(args: [code])
            : _errText(e);
        _checking = false;
      });
    }
  }

  /// 404 tới dưới 2 dạng: NotFoundException do ErrorInterceptor bọc, hoặc
  /// DioException thô nếu chưa qua interceptor.
  static bool _isNotFound(Object e) {
    if (e is NotFoundException) return true;
    if (e is DioException) {
      return e.error is NotFoundException || e.response?.statusCode == 404;
    }
    return false;
  }

  static String _errText(Object e) {
    if (e is AppException) return e.message;
    if (e is DioException && e.error is AppException) {
      return (e.error as AppException).message;
    }
    return '$e';
  }

  void _addCode(String raw) {
    final code = raw.trim();
    if (code.isEmpty) return;
    final list = _codes[_scope]!;
    if (list.contains(code)) {
      AppToastHelper.toastWarning(context, LocaleKeys.ng_item_duplicated.tr());
      _codeCtrl.clear();
      return;
    }
    setState(() {
      list.add(code);
      _codeCtrl.clear();
    });
  }

  /// Cả pallet thì không cần quét gì thêm — 1 mục trỏ vào chính pallet đó.
  List<NgDraftItem> _buildItems() => _scope == 'pallet'
      ? [NgDraftItem(scope: 'pallet', code: _pallet)]
      : _items.map((c) => NgDraftItem(scope: _scope, code: c)).toList();

  bool get _palletOk => _palletInfo != null && _checkedCode == _pallet;

  // _ngType != null: danh mục loại lỗi chưa tải xong (hoặc tải lỗi) thì không
  // cho gửi. Trước đây loại lỗi mặc định là hằng trong code nên không bao giờ
  // rỗng; giờ nó đến từ DB nên phải chặn ở đây.
  bool get _canSubmit => !_busy && !_checking && _palletOk && _ngType != null &&
      (_scope == 'pallet' || _items.isNotEmpty);

  Future<void> _submit() async {
    if (!_palletOk) {
      AppToastHelper.toastWarning(context, LocaleKeys.ng_err_need_pallet.tr());
      return;
    }
    if (_scope != 'pallet' && _items.isEmpty) {
      AppToastHelper.toastWarning(context, LocaleKeys.ng_err_need_item.tr());
      return;
    }

    setState(() => _busy = true);
    try {
      final repo = ref.read(ngRepositoryProvider);
      final created = await repo.create(
        palletCode: _pallet,
        ngType: _ngType!,
        items: _buildItems(),
        description:
            _descCtrl.text.trim().isEmpty ? null : _descCtrl.text.trim(),
      );

      // Ảnh tải lên SAU khi đã có phiếu. Lỗi 1 ảnh không làm hỏng cả phiếu —
      // người dùng bổ sung lại được ở màn chi tiết.
      var failed = 0;
      for (final f in _photos) {
        try {
          await repo.uploadPhoto(created.id, f);
        } catch (_) {
          failed++;
        }
      }

      if (!mounted) return;
      if (failed > 0) {
        AppToastHelper.toastWarning(
          context,
          LocaleKeys.ng_photo_partial.tr(args: ['$failed']),
        );
      } else {
        AppToastHelper.toastSuccess(
          context,
          LocaleKeys.ng_created.tr(args: [created.docNo]),
        );
      }
      await context.router.maybePop(true);
    } catch (e) {
      if (!mounted) return;
      AppToastHelper.toastError(context, '$e');
      setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    // Chọn sẵn loại lỗi đầu danh mục, giữ đúng hành vi cũ (trước đây mặc định
    // là 'packaging'). Phải làm sau khung hình vì không được setState trong
    // build; kiểm cả trường hợp danh mục đã nằm sẵn trong cache keepAlive,
    // lúc đó ref.listen không bắn vì chẳng có gì thay đổi.
    final loadedTypes = ngTypesOf(ref.watch(ngTypesProvider));
    if (_ngType == null && loadedTypes != null && loadedTypes.isNotEmpty) {
      WidgetsBinding.instance.addPostFrameCallback((_) {
        if (mounted && _ngType == null) {
          setState(() => _ngType = loadedTypes.first.code);
        }
      });
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(LocaleKeys.ng_new.tr()),
        bottom: PreferredSize(
          preferredSize: const Size.fromHeight(18),
          child: Padding(
            padding: const EdgeInsets.only(left: 16, bottom: 6),
            child: Align(
              alignment: Alignment.centerLeft,
              child: Text(
                LocaleKeys.ng_create_subtitle.tr(),
                style: TextStyle(fontSize: 11, color: swms.text3),
              ),
            ),
          ),
        ),
      ),
      body: ListView(
        padding: const EdgeInsets.fromLTRB(12, 12, 12, 20),
        children: [
          AppStepperBar(
            current: 1,
            steps: [
              StepItem(LocaleKeys.ng_mini_step_create.tr()),
              StepItem(LocaleKeys.ng_mini_step_leader.tr()),
              StepItem(LocaleKeys.ng_mini_step_fa_oqc.tr()),
              StepItem(LocaleKeys.ng_mini_step_finalize.tr()),
            ],
          ),

          // ── Lô hàng ───────────────────────────────────────────────────
          const SizedBox(height: 12),
          _Section(
            title: LocaleKeys.ng_pallet.tr(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: AppTextField(
                        kind: AppInputKind.code,
                        controller: _palletCtrl,
                        hint: LocaleKeys.ng_pallet_hint.tr(),
                        enabled: !_busy && !_checking,
                        suffixIcon: Icon(Icons.qr_code_scanner,
                            size: 18, color: swms.text3),
                        // Sửa tay thì bỏ kết quả tra cũ: không để mã mới đi
                        // kèm thông tin của pallet trước đó.
                        onChanged: (_) => setState(() {
                          _palletInfo = null;
                          _palletError = null;
                        }),
                        onSubmitted: (_) => _checkPallet(),
                      ),
                    ),
                    const SizedBox(width: 8),
                    AppButton(
                      label: LocaleKeys.ng_pallet_check.tr(),
                      isFullWidth: false,
                      variant: AppButtonVariant.neutral,
                      isLoading: _checking,
                      onPressed:
                          _busy || _pallet.isEmpty ? null : _checkPallet,
                    ),
                  ],
                ),
                if (_palletError != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: _ErrorBanner(text: _palletError!),
                  ),
                if (_palletOk)
                  Padding(
                    padding: const EdgeInsets.only(top: 8),
                    child: _PalletCard(info: _palletInfo!),
                  ),
              ],
            ),
          ),

          // ── Phạm vi ảnh hưởng (bắt buộc chọn trước) ───────────────────
          const SizedBox(height: 10),
          _Section(
            title: LocaleKeys.ng_scope_title.tr(),
            badge: LocaleKeys.ng_scope_required.tr(),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                SizedBox(
                  width: double.infinity,
                  child: SegmentedButton<String>(
                    showSelectedIcon: false,
                    segments: NgConst.scopes
                        .map((s) => ButtonSegment(
                              value: s,
                              label: Text(
                                'ng.scope.$s'.tr(),
                                style: const TextStyle(fontSize: 12),
                              ),
                            ))
                        .toList(),
                    selected: {_scope},
                    onSelectionChanged: _busy
                        ? null
                        : (s) => setState(() => _scope = s.first),
                  ),
                ),
                const SizedBox(height: 10),
                if (_scope == 'pallet')
                  _InfoBanner(
                    text: LocaleKeys.ng_scope_hint_pallet.tr(
                      args: [_pallet.isEmpty ? '—' : _pallet],
                    ),
                  )
                else
                  Row(
                    children: [
                      Expanded(
                        child: AppTextField(
                          kind: AppInputKind.code,
                          controller: _codeCtrl,
                          label: _scope == 'serial'
                              ? LocaleKeys.ng_scan_serial.tr()
                              : LocaleKeys.ng_scan_box.tr(),
                          enabled: !_busy,
                          onSubmitted: _addCode,
                        ),
                      ),
                      const SizedBox(width: 8),
                      AppButton(
                        label: LocaleKeys.ng_add.tr(),
                        isFullWidth: false,
                        onPressed:
                            _busy ? null : () => _addCode(_codeCtrl.text),
                      ),
                    ],
                  ),
                const SizedBox(height: 8),
                Text(
                  'ng.scope_note.$_scope'.tr(),
                  style: TextStyle(fontSize: 11, height: 1.45, color: swms.text3),
                ),
              ],
            ),
          ),

          // ── Mã đã thêm ────────────────────────────────────────────────
          if (_scope != 'pallet') ...[
            const SizedBox(height: 10),
            _Section(
              title: LocaleKeys.ng_items_added.tr(),
              trailing: '${_items.length} ${LocaleKeys.ng_item_word.tr()}',
              child: _items.isEmpty
                  ? Padding(
                      padding: const EdgeInsets.symmetric(vertical: 10),
                      child: Center(
                        child: Text(
                          LocaleKeys.ng_items_empty_hint.tr(),
                          textAlign: TextAlign.center,
                          style: TextStyle(fontSize: 11.5, color: swms.text3),
                        ),
                      ),
                    )
                  : Column(
                      children: _items.asMap().entries.map((e) {
                        final last = e.key == _items.length - 1;
                        return Container(
                          padding: const EdgeInsets.symmetric(vertical: 7),
                          decoration: BoxDecoration(
                            border: last
                                ? null
                                : Border(
                                    bottom: BorderSide(color: swms.border)),
                          ),
                          child: Row(
                            children: [
                              _ScopeTag(scope: _scope),
                              const SizedBox(width: 8),
                              Expanded(
                                child: Text(
                                  e.value,
                                  overflow: TextOverflow.ellipsis,
                                  style: TextStyle(
                                    fontSize: 12.5,
                                    fontWeight: FontWeight.w700,
                                    color: swms.text1,
                                  ),
                                ),
                              ),
                              IconButton(
                                icon: const Icon(Icons.close, size: 17),
                                visualDensity: VisualDensity.compact,
                                onPressed: _busy
                                    ? null
                                    : () => setState(
                                        () => _codes[_scope]!.removeAt(e.key)),
                              ),
                            ],
                          ),
                        );
                      }).toList(),
                    ),
            ),
          ],

          // ── Loại lỗi ──────────────────────────────────────────────────
          const SizedBox(height: 10),
          _Section(
            title: LocaleKeys.ng_type_title.tr(),
            child: switch (ref.watch(ngTypesProvider)) {
              // Danh mục tải từ master.ng_types. Lỗi mạng thì hiện nút thử
              // lại chứ không để danh sách rỗng im lặng — không chọn được
              // loại lỗi là không lập được phiếu.
              AsyncData(:final value) => AppRadioCardGroup<String>(
                  value: _ngType,
                  onChanged:
                      _busy ? null : (v) => setState(() => _ngType = v),
                  items: value
                      .map((t) => RadioCardItem(
                            value: t.code,
                            title: t.name,
                            subtitle: t.note ?? '',
                            icon: _typeIcon(t.code),
                          ))
                      .toList(),
                ),
              AsyncError() => Row(
                  children: [
                    Expanded(child: Text(LocaleKeys.error_network.tr())),
                    TextButton(
                      onPressed: () => ref.invalidate(ngTypesProvider),
                      child: Text(LocaleKeys.common_retry.tr()),
                    ),
                  ],
                ),
              _ => const Padding(
                  padding: EdgeInsets.symmetric(vertical: 12),
                  child: Center(child: CircularProgressIndicator()),
                ),
            },
          ),

          // ── Ảnh ───────────────────────────────────────────────────────
          const SizedBox(height: 10),
          _Section(
            title: LocaleKeys.ng_photos.tr(),
            trailing: LocaleKeys.ng_photos_count
                .tr(args: ['${_photos.length}', '$_maxPhotos']),
            child: AppPhotoGrid(
              photos: _photos,
              readOnly: _busy,
              cameraLabel: LocaleKeys.ng_photo_camera.tr(),
              galleryLabel: LocaleKeys.ng_photo_gallery.tr(),
              onChanged: (list) => setState(() => _photos = list),
            ),
          ),

          // ── Mô tả ─────────────────────────────────────────────────────
          const SizedBox(height: 10),
          _Section(
            title: LocaleKeys.ng_description.tr(),
            child: AppTextField(
              controller: _descCtrl,
              hint: LocaleKeys.ng_description_hint.tr(),
              enabled: !_busy,
              maxLines: 3,
            ),
          ),

          // ── Nhắc luồng duyệt ──────────────────────────────────────────
          const SizedBox(height: 12),
          const _WorkflowHint(),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: AppButton(
                  label: LocaleKeys.ng_cancel_create.tr(),
                  variant: AppButtonVariant.neutral,
                  size: AppButtonSize.lg,
                  onPressed: _busy ? null : () => context.router.maybePop(),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                flex: 2,
                child: AppButton(
                  label: LocaleKeys.ng_create_submit.tr(),
                  size: AppButtonSize.lg,
                  isLoading: _busy,
                  onPressed: _canSubmit ? _submit : null,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  static IconData _typeIcon(String type) => switch (type) {
        'packaging' => Icons.inventory_2_outlined,
        'product' => Icons.broken_image_outlined,
        'qty_mismatch' => Icons.numbers_outlined,
        'model_mismatch' => Icons.sync_problem_outlined,
        _ => Icons.event_busy_outlined,
      };
}

/// Khối nội dung có tiêu đề, nhãn đỏ bắt buộc và số đếm bên phải.
class _Section extends StatelessWidget {
  final String title;
  final String? badge;
  final String? trailing;
  final Widget child;

  const _Section({
    required this.title,
    required this.child,
    this.badge,
    this.trailing,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 10, 12, 12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                title,
                style: TextStyle(
                  fontSize: 12.5,
                  fontWeight: FontWeight.w800,
                  color: swms.text1,
                ),
              ),
              if (badge != null) ...[
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    badge!,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: swms.danger,
                    ),
                  ),
                ),
              ] else
                const Spacer(),
              if (trailing != null)
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 2),
                  decoration: BoxDecoration(
                    color: swms.card2,
                    borderRadius: BorderRadius.circular(10),
                  ),
                  child: Text(
                    trailing!,
                    style: TextStyle(
                      fontSize: 10.5,
                      fontWeight: FontWeight.w700,
                      color: swms.text2,
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: 10),
          child,
        ],
      ),
    );
  }
}

/// Dải nền xanh nhạt — dùng cho trường hợp "cả pallet", không cần quét thêm.
class _InfoBanner extends StatelessWidget {
  final String text;
  const _InfoBanner({required this.text});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 11),
      decoration: BoxDecoration(
        color: swms.primaryTint,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: swms.border),
      ),
      child: Row(
        children: [
          Icon(Icons.task_alt, size: 15, color: swms.primaryDark),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(
                fontSize: 11.5,
                height: 1.4,
                color: swms.primaryDark,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Mã pallet không tra được — chặn gửi phiếu, nói rõ lý do.
class _ErrorBanner extends StatelessWidget {
  final String text;
  const _ErrorBanner({required this.text});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 8, horizontal: 10),
      decoration: BoxDecoration(
        color: swms.dangerBg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: swms.danger),
      ),
      child: Row(
        children: [
          Icon(Icons.error_outline, size: 15, color: swms.danger),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              text,
              style: TextStyle(fontSize: 11.5, height: 1.4, color: swms.danger),
            ),
          ),
        ],
      ),
    );
  }
}

/// Pallet đã tra được — hiện model, số thùng, vị trí để công nhân đối chiếu
/// bằng mắt rằng mình quét đúng pallet.
class _PalletCard extends StatelessWidget {
  final NgPalletBrief info;
  const _PalletCard({required this.info});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final bits = <String>[
      if (info.model != null && info.model!.isNotEmpty) info.model!,
      if (info.boxCount != null)
        '${info.boxCount} ${LocaleKeys.ng_box_word.tr()}',
      if (info.locatorCode != null && info.locatorCode!.isNotEmpty)
        info.locatorCode!
      else
        LocaleKeys.ng_pallet_no_location.tr(),
    ];
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 9, horizontal: 11),
      decoration: BoxDecoration(
        color: swms.successBg,
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: swms.success),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.check_circle_outline, size: 15, color: swms.success),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Expanded(
                      child: Text(
                        info.code,
                        style: TextStyle(
                          fontSize: 12.5,
                          fontWeight: FontWeight.w800,
                          color: swms.text1,
                        ),
                      ),
                    ),
                    if (info.isUrgent)
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 6, vertical: 1),
                        decoration: BoxDecoration(
                          color: swms.danger,
                          borderRadius: BorderRadius.circular(5),
                        ),
                        child: Text(
                          LocaleKeys.ng_pallet_urgent.tr(),
                          style: const TextStyle(
                            fontSize: 9,
                            fontWeight: FontWeight.w800,
                            color: Colors.white,
                          ),
                        ),
                      ),
                  ],
                ),
                if (bits.isNotEmpty)
                  Padding(
                    padding: const EdgeInsets.only(top: 2),
                    child: Text(
                      bits.join('  ·  '),
                      style: TextStyle(fontSize: 11, color: swms.text2),
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _WorkflowHint extends StatelessWidget {
  const _WorkflowHint();

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 10, horizontal: 12),
      decoration: BoxDecoration(
        color: swms.primaryTint,
        borderRadius: BorderRadius.circular(10),
        border: Border.all(color: swms.primaryTint2),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Container(
            width: 26,
            height: 26,
            decoration: BoxDecoration(color: swms.primary, shape: BoxShape.circle),
            child: const Icon(Icons.notifications_none,
                size: 14, color: Colors.white),
          ),
          const SizedBox(width: 10),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  LocaleKeys.ng_workflow_title.tr(),
                  style: TextStyle(
                    fontSize: 11,
                    fontWeight: FontWeight.w800,
                    color: swms.primaryDark,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  LocaleKeys.ng_workflow_hint.tr(),
                  style: TextStyle(
                    fontSize: 11,
                    height: 1.45,
                    color: swms.primaryDark,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _ScopeTag extends StatelessWidget {
  final String scope;
  const _ScopeTag({required this.scope});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final (bg, fg) = switch (scope) {
      'pallet' => (swms.primaryTint, swms.primaryDark),
      'box' => (swms.successBg, swms.success),
      _ => (swms.warningBg, swms.warning),
    };
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(color: bg, borderRadius: BorderRadius.circular(6)),
      child: Text(
        'ng.scope.$scope'.tr().toUpperCase(),
        style: TextStyle(fontSize: 9.5, fontWeight: FontWeight.w800, color: fg),
      ),
    );
  }
}
