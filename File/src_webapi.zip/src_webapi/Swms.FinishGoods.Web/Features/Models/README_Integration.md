# Feature Models — Hướng dẫn tích hợp

## 1. Cấu trúc (đặt vào `Features/Models/`)

```
Features/Models/
├── App/
│   ├── Pages/
│   │   ├── Models.razor
│   │   ├── Models.razor.cs
│   │   ├── Models.razor.Crud.cs
│   │   ├── Models.razor.Selection.cs
│   │   ├── Models.razor.ImportExport.cs
│   │   ├── ModelFormDialog.razor
│   │   └── ModelDetailDialog.razor
│   └── Csvlo/
│       └── ModelCsvSchema.cs
├── Business/
│   ├── IModelBusiness.cs
│   ├── ModelBusiness.cs
│   └── Models/
│       ├── AppModel.cs          (+ CategoryOptionDto)
│       ├── ModelDto.cs
│       ├── CreateModelRequest.cs
│       ├── UpdateModelRequest.cs
│       └── ModelQuery.cs
└── Client/
    └── IModelApi.cs
```

## 2. Đăng ký DI (Program.cs — cùng chỗ với các `I…Api` khác)

```csharp
builder.Services
    .AddRefitClient<IModelApi>()
    .ConfigureHttpClient(c => c.BaseAddress = new Uri(apiBaseUrl)); // dùng chung config/handler

builder.Services.AddScoped<IModelBusiness, ModelBusiness>();
```

## 3. Resource (đa ngôn ngữ)

Paste 4 block trong `Models_ResourceKeys.txt` vào đúng 4 file
`SharedResource_{en,vi,zh,ja}.resx`. Đã kiểm tra 4 block cùng tập key.

## 4. Menu

Thêm mục menu trái trỏ tới `/models` (hoặc `/master/models`), dùng key `Nav.*`
(tạo thêm `Nav.Models` nếu chưa có — nhớ thêm cả 4 ngôn ngữ).

## 5. ⚠ Việc backend cần bổ sung

1. **Endpoint category options** — FE cần dropdown danh mục cho form + filter,
   và để resolve `category_code → CategoryId` khi import CSV. `ModelsController`
   hiện chưa có; thêm (tương tự `role-options` của Users):

   ```csharp
   [HttpGet("category-options")]
   [RequirePermission<Perms.System.Models.View>]
   public async Task<ActionResult<List<CategoryOptionResponse>>> GetCategoryOptions()
       => Ok(await _service.GetCategoryOptionsAsync());
   // CategoryOptionResponse: Id, Code, Name
   ```

   Nếu đã có API Categories riêng (vd `/api/categories/options`) thì chỉ cần đổi
   route trong `IModelApi.GetCategoryOptionsAsync` cho trỏ đúng.

2. **Khớp shape DTO** — `ModelDto` phía web giả định `ModelResponse` trả:
   `Id, Code, CategoryId, CategoryCode, CategoryName, Length, Width, Height,
   Weight, StandardPacking, IsActive, CreatedAt`. Nếu backend chưa join trả
   `CategoryCode`/`CategoryName`, nên bổ sung để hiển thị cột danh mục và
   export CSV không phải gọi thêm.

3. **Khớp `ModelQuery`** — web gửi: `Code, CategoryId, IsActive, CreatedFrom,
   CreatedTo, Page, Size`. Đảm bảo `ModelQuery` phía API có cùng field.

4. **Bulk conflict** — import dùng `ErrorCode.BulkConflict` +
   `GetDetails<ConflictDetail>()` và đọc `c.Code` (Users đọc `c.EmployeeCode`).
   Kiểm tra `ConflictDetail` có property `Code`; nếu tên khác thì sửa 1 dòng
   trong `Models.razor.ImportExport.cs`.

## 6. Ghi chú thiết kế (theo pattern Users)

- `Code` là business key → **không cho sửa khi edit** (input disabled, và
  `UpdateModelRequest` không chứa `Code`) — giống Users không cho đổi EmployeeCode.
- Bulk actions (activate/deactivate/delete nhiều dòng) đang là stub chờ endpoint
  backend, giống `Users.razor.Selection.cs`.
- CSV import nhập theo `category_code`; FE resolve sang `CategoryId` bằng option
  list đã nạp ở `OnFirstLoadAsync`, báo lỗi nếu mã danh mục không tồn tại.

## 7. Checklist test

- [ ] Tìm theo mã model, lọc danh mục / trạng thái / ngày tạo, phân trang, URL state.
- [ ] Thêm / sửa / xoá; validate form (code, category, dims > 0, weight > 0, packing > 0).
- [ ] Kích hoạt / ngừng dùng từ row menu.
- [ ] Tải template, import CSV (kể cả file có mã trùng + category code sai), export theo filter.
- [ ] Đổi ngôn ngữ runtime — không còn chuỗi cứng.
