// ─────────────────────────────────────────────────────────────
//  B5 — kết quả một lượt FA đến lấy hàng RW/RB.
//
//  Viết TAY, không json_serializable: cùng lý do với cả bộ mục 2c/2d —
//  build_runner trong source hiện tại đang vỡ (hai file cùng khai
//  `@RoutePage() class VanningPage`), nên thêm một `.g.dart` là không sinh được.
// ─────────────────────────────────────────────────────────────

class FaPickupResult {
  const FaPickupResult({
    required this.docId,
    required this.docNo,
    required this.round,
    required this.lotNo,
    required this.locatorCode,
    required this.pickedQty,
    required this.remainQty,
    required this.completed,
  });

  final int docId;
  final String? docNo;

  /// Lần đề nghị mà lượt lấy này thuộc về.
  final int round;

  final String? lotNo;

  /// Vị trí pallet vừa rời khỏi — nhắc lại cho người quét đối chiếu.
  final String? locatorCode;

  /// Số serial vừa chuyển sang "đang ở FA".
  final int pickedQty;

  /// Số con của phiếu còn ở kho SCS sau lượt này.
  final int remainQty;

  /// Lượt này làm XONG lần đề nghị đang mở.
  final bool completed;
}
