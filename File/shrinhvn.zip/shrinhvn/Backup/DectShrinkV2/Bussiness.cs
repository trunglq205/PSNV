﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;

namespace DectShrinkV2
{
    class Bussiness
    {
        ConnectSQL conn = new ConnectSQL();
        

        public DataTable Get_Model_PalletID(string Source_pallet,string Category)
        {
            string[] arrParam = { "@Source_pallet","@Category" };
            object[] arrValue = { Source_pallet, Category };
            return conn.TableWithParameter("Get_Model_PalletID_new", arrParam, arrValue);
        }

        //Get_Outer_carton
        public DataTable Get_Outer_carton(string STR_PROCESS_FACTORY, string Outer_carton,string Category)
        {
            string[] arrParam = { "@STR_PROCESS_FACTORY" ,"@Outer_carton","@Category"};
            object[] arrValue = { STR_PROCESS_FACTORY, Outer_carton, Category };
            return conn.TableWithParameter("Get_Outer_carton", arrParam, arrValue);
        }
        //Get_All_Serial_Outercarton
        public DataTable Get_All_Serial_Outercarton(string STR_PROCESS_FACTORY, string Outer_carton, string Serial_outer,string Category)
        {
            string[] arrParam = { "@STR_PROCESS_FACTORY", "@Outer_carton" ,"@Serial_outer","@Category"};
            object[] arrValue = { STR_PROCESS_FACTORY, Outer_carton, Serial_outer,Category };
            return conn.TableWithParameter("Get_All_Serial_Outercarton", arrParam, arrValue);
        }

        public DataTable Get_All_Serial_Outercarton_sound(string STR_PROCESS_FACTORY, string Outer_carton, string Serial_outer, string Category)
        {
            string[] arrParam = { "@STR_PROCESS_FACTORY", "@Outer_carton", "@Serial_outer", "@Category" };
            object[] arrValue = { STR_PROCESS_FACTORY, Outer_carton, Serial_outer, Category };
            //return conn.TableWithParameter("Get_All_Serial_Outercarton_sound", arrParam, arrValue);
            //edit cho viec chay cham o shrink palet
            return conn.TableWithParameter("Get_All_Serial_Outercarton_sound_test", arrParam, arrValue);
        }
        public DataTable CheckVeryFile(string Serial_outer,string Cate)
        {
            string[] arrParam = {  "@SerialOut", "@Cate" };
            object[] arrValue = { Serial_outer, Cate };
            return conn.TableWithParameter("GET_Check_Veryify", arrParam, arrValue);
        }

        public DataTable LoafModel_PostCode(string Serial_outer, string Cate)
        {
            string[] arrParam = { "@SerialOut", "@Cate" };
            object[] arrValue = { Serial_outer, Cate };
            return conn.TableWithParameter("GET_Check_Veryify", arrParam, arrValue);
        }

        //InsertToPallet_OuterCarton

        public bool InsertToPallet_OuterCarton(string STR_PROCESS_FACTORY, string Outer_carton, string Serial_outer, string PalletID, string sUsername,string Category)
        {
            //int kq;
            string[] arrParam = { "@STR_PROCESS_FACTORY", "@Outer_carton", "@Serial_outer","@PalletID","@sUsername","@Category" };
            object[] arrValue = { STR_PROCESS_FACTORY, Outer_carton, Serial_outer,PalletID, sUsername,Category };
            if (conn.ExcuteStored_bool("InsertToPallet_OuterCarton", arrParam, arrValue))
                return true;
            else
                return false;
        }

        public bool InsertToPallet_OuterCarton_sound(string STR_PROCESS_FACTORY, string Outer_carton, string Serial_outer, string PalletID, string sUsername, string Category)
        {
            //int kq;
            string[] arrParam = { "@STR_PROCESS_FACTORY", "@Outer_carton", "@Serial_outer", "@PalletID", "@sUsername", "@Category" };
            object[] arrValue = { STR_PROCESS_FACTORY, Outer_carton, Serial_outer, PalletID, sUsername, Category };
            if (conn.ExcuteStored_bool("InsertToPallet_OuterCarton_sound", arrParam, arrValue))
                return true;
            else
                return false;
        }

        public bool InsertToPallet_OuterCarton_DP(string STR_PROCESS_FACTORY, string Outer_carton, string Serial_outer, string PalletID, string sUsername, string Category)
        {
            //int kq;
            string[] arrParam = { "@STR_PROCESS_FACTORY", "@Outer_carton", "@Serial_outer", "@PalletID", "@sUsername", "@Category" };
            object[] arrValue = { STR_PROCESS_FACTORY, Outer_carton, Serial_outer, PalletID, sUsername, Category };
            //if (conn.ExcuteStored_bool("InsertToPallet_OuterCarton_DP", arrParam, arrValue))
            //sua loi cham
            if (conn.ExcuteStored_bool("InsertToPallet_OuterCarton_DP_test", arrParam, arrValue))
                return true;
            else
                return false;
        }

    }
}
