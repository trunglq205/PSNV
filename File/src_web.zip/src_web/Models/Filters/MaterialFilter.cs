﻿namespace SWMS_WebTool.Models.Filters
{
    public class MaterialFilter: BaseFilter
    {
        public MaterialInfoType Type { get; set; }
        public string? Material { get; set; }
    }
}
