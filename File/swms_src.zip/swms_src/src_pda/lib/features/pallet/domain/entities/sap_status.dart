import 'package:easy_localization/easy_localization.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart'
    show StatusColor;

/// Trạng thái đẩy SAP — khớp enum `SapStatus : byte` của API.
enum SapStatus {
  /// 0 — Chưa hoàn thành. Sẵn sàng để worker quét.
  notReady(0, 'not_ready'),

  /// 1 — Đang đẩy. Worker đã claim, đang sinh/ghi file CSV.
  pushing(1, 'pushing'),

  /// 2 — Đã đẩy. File CSV đã nằm trên share, chờ SAP nhận.
  pushed(2, 'pushed'),

  /// 3 — Lỗi. Ghi file thất bại hoặc SAP trả NG. Vòng sau sẽ quét lại.
  error(3, 'error'),

  /// 4 — Hoàn thành. File đã biến mất khỏi folder ⇒ SAP đã nhận.
  completed(4, 'completed');

  final int code;
  final String key;

  const SapStatus(this.code, this.key);

  /// null nếu [code] null hoặc mã lạ (không throw).
  static SapStatus? fromCode(int? code) {
    if (code == null) return null;
    for (final s in SapStatus.values) {
      if (s.code == code) return s;
    }
    return null;
  }

  @override
  String toString() => 'sap_status.$key'.tr();
}

extension SapStatusColor on SapStatus {
  StatusColor get color => switch (this) {
    SapStatus.notReady => const StatusColor(AppColors.text4, AppColors.card2),
    SapStatus.pushing => const StatusColor(
      AppColors.warning,
      AppColors.warningBg,
    ),
    SapStatus.pushed => const StatusColor(
      AppColors.primaryLight,
      AppColors.primaryTint,
    ),
    SapStatus.error => const StatusColor(AppColors.danger, AppColors.dangerBg),
    SapStatus.completed => const StatusColor(
      AppColors.success,
      AppColors.successBg,
    ),
  };
}
