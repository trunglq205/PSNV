namespace Swms.FinishGoods.API.Features.Auth;

// Đọc từ appsettings: "Jwt": { ... }
public class JwtOptions
{
    public string Secret { get; set; } = string.Empty;   // >= 32 ký tự
    public string Issuer { get; set; } = "Swms.FinishGoods";
    public string Audience { get; set; } = "Swms.FinishGoods.Web";
    public int ExpiryMinutes { get; set; } = 480;          // 8 giờ
}
