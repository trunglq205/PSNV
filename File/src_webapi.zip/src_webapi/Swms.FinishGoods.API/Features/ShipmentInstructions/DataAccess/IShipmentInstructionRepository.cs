using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;
using Swms.FinishGoods.API.Features.StockEvents.Api;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

public interface IShipmentInstructionRepository
{
    // ── Đọc ─────────────────────────────────────────────────
    Task<(IReadOnlyList<SiListRow> Items, int Total)> GetPagedAsync(SiQuery query);
    Task<Dictionary<string, int>> GetStatusCountsAsync();
    Task<SiDetail?> GetDetailAsync(long id);
    Task<SiHeader?> GetHeaderAsync(long id);
    Task<SiLine?> GetLineAsync(long lineId);
    Task<SiTask?> GetTaskAsync(long taskId);
    Task<SiBox?> GetBoxAsync(long id);
    Task<List<SiBox>> GetBoxesByLineAsync(long lineId);

    Task<bool> DocNoExistsAsync(string docNo, long? excludeId);
    /// <summary>Id phiếu (chưa xoá) theo doc_no; null = chưa có.</summary>
    Task<long?> GetIdByDocNoAsync(string docNo);
    /// <summary>Id phiếu đang dùng theo si_no (chưa xoá, chưa huỷ; nhiều phiếu thì lấy phiếu mới nhất). null = chưa có.</summary>
    Task<long?> GetActiveIdBySiNoAsync(string siNo);
    Task<bool> HasPickedAsync(long siId);
    Task<bool> LineLockedAsync(long lineId);   // đã có kế hoạch hoặc thùng chỉ định

    // ── Header ──────────────────────────────────────────────
    Task<long> AddAsync(SiHeader header, IReadOnlyList<SiLine> lines);
    /// <summary>lines = null: chỉ sửa header. Có lines: đồng bộ — line đã khoá được giữ nguyên.</summary>
    Task<bool> UpdateAsync(SiHeader header, IReadOnlyList<SiLine>? lines);
    /// <summary>SAP gửi lại SI đã có: ghi header kèm doc_no / revision mới và đồng bộ TOÀN BỘ dòng
    /// (kể cả dòng đã có kế hoạch — service đã kiểm tra). Found = false: phiếu không còn.
    /// LockedLineId: dòng SAP bỏ nhưng vừa được phân bổ -> đã rollback, không ghi gì.</summary>
    Task<(bool Found, long? LockedLineId)> ApplySapRevisionAsync(SiHeader header, IReadOnlyList<SiLine> lines);
    Task<bool> SoftDeleteAsync(long id, string? actor);
    Task<bool> CancelAsync(long id, string reason, string? actor);
    /// <summary>Đổi doc_status -> completed. Không kiểm tra hàng đã lấy / đã vanning.
    /// false = phiếu không còn, đã xoá, hoặc đã completed / cancelled.</summary>
    Task<bool> CompleteAsync(long id, string? actor);

    // ── Line ────────────────────────────────────────────────
    Task<long> AddLineAsync(SiLine line);
    Task<bool> UpdateLineAsync(SiLine line);
    Task<bool> DeleteLineAsync(long lineId);
    Task<bool> SetCutAsync(long lineId, int? qtyCut, string? actor);

    // ── Phân bổ ─────────────────────────────────────────────
    Task<int> AllocateAsync(long siId, long? lineId, long? toLocatorId, string? assignedTo, string? actor);
    Task<bool> UpdateTaskAsync(long taskId, long? toLocatorId, string? assignedTo);
    Task<bool> ReleaseTaskAsync(long taskId);

    // ── Mã thùng chỉ định ───────────────────────────────────
    Task<int> AddDesignatedBoxesAsync(long lineId, IReadOnlyList<string> boxNos, bool replace);
    Task MatchDesignatedBoxesAsync(long lineId);
    Task<bool> ResolveBoxAsync(long id, long boxId);
    Task<bool> DeleteBoxAsync(long id);
    /// <summary>Thùng boxId có khớp (box_no + model) của dòng chỉ định id không.</summary>
    Task<bool> BoxMatchesAsync(long id, long boxId);
    Task<bool> BoxHeldAsync(long boxId, long excludeId);

    // ── Lấy hàng (PDA) ──────────────────────────────────────
    Task<List<PickBoxRow>> GetPickBoxesAsync(long taskId);
    Task<bool> ConfirmPalletAsync(long taskId, string? actor);
    /// <summary>designated = true: đánh dấu thùng chỉ định; false (fifo): thêm dòng _boxes. Đủ thùng tự đóng dòng kế hoạch.</summary>
    Task<PickScanResult> PickBoxAsync(long taskId, long lineId, long boxId, string boxNo, bool designated, string? actor);
    /// <summary>Gỡ 1 thùng đã quét; dòng kế hoạch đã đóng mà hụt thùng thì mở lại pending.</summary>
    Task<bool> UnpickBoxAsync(long taskId, long boxId, bool designated);

    // ── Vanning (PDA) ───────────────────────────────────────
    Task<LocatorRow?> GetLocatorByCodeAsync(string locatorCode);
    Task<long?> GetPalletIdByCodeAsync(string palletCode);
    /// <summary>Số thùng đã quét của dòng kế hoạch KHÔNG nằm trên palletId (phải = 0 mới được đưa ra vanning).</summary>
    Task<int> CountPickedBoxesOffPalletAsync(long taskId, long palletId);
    /// <summary>Số thùng còn trên palletId mà không phải thùng đã quét của dòng kế hoạch (pallet gốc chưa tách).</summary>
    Task<int> CountForeignBoxesOnPalletAsync(long taskId, long palletId);
    /// <summary>Dời pallet sang vị trí vanning. false = pallet không tồn tại / đã xoá.</summary>
    Task<bool> MovePalletToLocatorAsync(long palletId, long locatorId, long taskId, string? actor);

    // ── So sánh với HD soft ─────────────────────────────────
    /// <summary>Mỗi si_no 1 phiếu chưa xoá: ưu tiên phiếu chưa huỷ, rồi phiếu mới nhất. Tối đa ~2000 si_no / lần.</summary>
    Task<List<SiHeader>> GetHeadersBySiNosAsync(IReadOnlyCollection<string> siNos);
    /// <summary>Dòng (kèm pending / picked) của các phiếu. Tối đa ~2000 id / lần.</summary>
    Task<List<SiLine>> GetLinesBySiIdsAsync(IReadOnlyCollection<long> siIds);
    /// <summary>si_no của phiếu (chưa xoá, chưa huỷ) có ETD trong [from, toExclusive).</summary>
    Task<List<string>> GetSiNosByEtdAsync(DateTime from, DateTime toExclusive);

    /// <summary>si_no của phiếu (chưa xoá, chưa huỷ) có vanning = COALESCE(vanning_date, etd_date)
    /// trong [from, toExclusive). Cùng định nghĩa vanning với màn Hàng thiếu.</summary>
    Task<List<string>> GetSiNosByVanningAsync(DateTime from, DateTime toExclusive);
}