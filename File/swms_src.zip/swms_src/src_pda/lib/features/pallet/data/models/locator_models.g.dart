// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'locator_models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LocatorRequestModel _$LocatorRequestModelFromJson(Map<String, dynamic> json) =>
    LocatorRequestModel(
      locatorCode: json['locatorCode'] as String,
      allowedMapType: json['allowedMapType'] as String?,
    );

Map<String, dynamic> _$LocatorRequestModelToJson(
  LocatorRequestModel instance,
) => <String, dynamic>{
  'locatorCode': instance.locatorCode,
  'allowedMapType': ?instance.allowedMapType,
};

LocatorChangeResponseModel _$LocatorChangeResponseModelFromJson(
  Map<String, dynamic> json,
) => LocatorChangeResponseModel(
  lotId: (json['lotId'] as num).toInt(),
  lotNo: json['lotNo'] as String,
  fromLocatorId: (json['fromLocatorId'] as num?)?.toInt(),
  fromLocatorCode: json['fromLocatorCode'] as String?,
  toLocatorId: (json['toLocatorId'] as num?)?.toInt(),
  toLocatorCode: json['toLocatorCode'] as String?,
  warning: json['warning'] as String?,
);

Map<String, dynamic> _$LocatorChangeResponseModelToJson(
  LocatorChangeResponseModel instance,
) => <String, dynamic>{
  'lotId': instance.lotId,
  'lotNo': instance.lotNo,
  'fromLocatorId': ?instance.fromLocatorId,
  'fromLocatorCode': ?instance.fromLocatorCode,
  'toLocatorId': ?instance.toLocatorId,
  'toLocatorCode': ?instance.toLocatorCode,
  'warning': ?instance.warning,
};
