import 'package:auto_route/auto_route.dart';
import 'package:flutter/widgets.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';

extension NavigationExtensions on BuildContext {
  /// Mở màn Soạn hàng cho [siId] mà không chồng thêm màn:
  ///   - Stack đã có Kitting ĐÚNG SI này → back về đó.
  ///   - Stack có Kitting của SI khác → back về đó rồi thay bằng SI mới
  ///     (luồng "Đổi SI": Kitting → danh sách SI → chọn SI khác).
  ///   - Chưa có → push.
  Future<void> openKitting(int? siId) async {
    final router = this.router;
    final existing = router.stack
        .where((p) => p.name == KittingRoute.name)
        .lastOrNull;

    if (existing == null) {
      await router.push(KittingRoute(siId: siId));
      return;
    }

    router.popUntilRouteWithName(KittingRoute.name);

    // siId nằm ở query param (@QueryParam) nên đọc từ queryParams,
    // args chỉ có khi route được push bằng object.
    final currentId = existing.routeData.queryParams.optInt('siId');
    if (currentId != siId) {
      await router.replace(KittingRoute(siId: siId));
    }
  }

  /// Mở màn lấy hàng cho [task] trên tuyến [route].
  /// [siId] = khoá kittingProvider của màn tuyến (null khi tự chọn SI).
  Future<bool> openKittingTask(
    List<PickTask> route,
    PickTask task, {
    int? siId,
  }) async {
    final done = await router.push<bool>(_kittingTaskRoute(route, task, siId));
    return done == true;
  }

  /// Thay màn lấy hàng hiện tại bằng vị trí [task] — không chồng thêm màn.
  Future<void> replaceKittingTask(
    List<PickTask> route,
    PickTask task, {
    int? siId,
  }) => router.replace(_kittingTaskRoute(route, task, siId));

  static KittingTaskRoute _kittingTaskRoute(
    List<PickTask> route,
    PickTask task,
    int? siId,
  ) {
    final i = route.indexWhere((t) => t.id == task.id);
    return KittingTaskRoute(
      task: task,
      siId: siId,
      index: i + 1,
      total: route.length,
      next: route.nextPendingAfter(task),
    );
  }
}
