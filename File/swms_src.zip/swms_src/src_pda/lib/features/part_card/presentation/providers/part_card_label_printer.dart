import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/label.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/part_card.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/part_card_multi.dart';
import 'package:swms_finish_goods/core/utils/printing/printer_provider.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';

// ─────────────────────────────────────────────────────────────
//  In nhãn Part Card — dùng chung cho màn in mới và màn Sửa/Tách/Gộp.
// ─────────────────────────────────────────────────────────────

/// In [jobs] trong MỘT phiên kết nối với máy in đang chọn.
///
/// [onPrinted] được gọi với index của job vừa được máy XÁC NHẬN đã ra giấy
/// (SATO: ACK; TSPL: đã đẩy xong + chờ đủ thời gian tiêu buffer). Lỗi máy in
/// ném ra nguyên trạng — caller tự quyết giữ lại phần nào.
Future<void> printPartCardJobs(
    Ref ref,
    List<PartCardPrintJob> jobs, {
      required void Function(int index) onPrinted,
    }) async {
  final device = ref.read(selectedPrinterProvider);
  if (device == null) throw const PrinterException(PrinterErrorType.noPrinter);

  final printer = ref.read(printerProvider(device.language));
  final payloads = jobs
      .map((j) => partCardLabel(j.form, j.cardId).toBytes(language: device.language))
      .toList(growable: false);

  await printer.printBatch(device, payloads, onPrinted: onPrinted);
}

/// Layout tem theo `form.mode`.
Label partCardLabel(PartCardForm form, String cardId) =>
    form.mode.isMulti ? _multiData(form, cardId) : _singleData(form, cardId);

PartCardData _singleData(PartCardForm form, String cardId) => PartCardData(
  qrLarge: form.buildMainPayload(cardId),
  qrSmall: form.buildLegacyPayload(cardId),
  model: form.model,
  qty: form.quantity.toString(),
  origin: form.origin?.code ?? '',
  category: form.categoryText ?? '',
  proDate: form.productionDateText,
  dimensionCm3: form.dimension,
  weightKg: form.weightText,
);

PartCardMultiData _multiData(PartCardForm form, String cardId) =>
    PartCardMultiData(
      qrNew: form.buildMainPayload(cardId),
      qrOld: form.buildLegacyPayload(cardId),
      psnvPo: form.psnvPo.trim(),
      cusPo: form.cusPo.trim(),
      mfd: form.productionDateText,
      category: form.categoryText ?? '',
      dimensionCm3: form.dimension,
      weightKg: form.weightText,
      rows: form.lines
          .map(
            (l) => PartCardMultiRow(
          model: l.model,
          box: '${l.box}',
          qty: '${l.quantity}',
          origin: l.origin?.code ?? '',
          oqc: PartCardMultiData.oqcMark(l.oqcChecked),
        ),
      )
          .toList(growable: false),
      totalBox: '${form.totalBox}',
      totalQty: '${form.totalPcs}',
      totalOqc: PartCardMultiData.oqcMark(form.anyOqcChecked),
    );