import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/box_detail/data/datasources/box_detail_remote_data_source.dart';
import 'package:swms_finish_goods/features/box_detail/data/repositories/box_detail_repository_impl.dart';
import 'package:swms_finish_goods/features/box_detail/domain/repositories/box_detail_repository.dart';

part 'box_detail_providers.g.dart';

@riverpod
BoxDetailRemoteDataSource boxDetailRemoteDataSource(Ref ref) {
  return BoxDetailRemoteDataSource(ref.watch(dioProvider));
}

@riverpod
BoxDetailRepository boxDetailRepository(Ref ref) {
  return BoxDetailRepositoryImpl(ref.watch(boxDetailRemoteDataSourceProvider));
}