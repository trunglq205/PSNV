import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_event.dart';

/// State phức hợp của màn Box Detail — tách sẵn để thêm field khác
/// (in nhãn, NG…) mà không đổi cấu trúc.
class BoxDetailState {
  final AsyncValue<BoxDetail> detail;

  /// Lịch sử thùng. AsyncValue RIÊNG, không gộp vào [detail]: timeline hỏng
  /// thì màn vẫn xem được thông tin thùng và sửa PO bình thường.
  final AsyncValue<BoxHistory> history;

  /// Đang chỉ hiện thao tác trên CHÍNH thùng này (bỏ event kế thừa từ pallet
  /// chứa nó). Lọc ở server nên đổi giá trị là phải gọi lại API — xem
  /// `BoxDetailNotifier.setHistoryOwnOnly`.
  final bool historyOwnOnly;

  const BoxDetailState({
    this.detail = const AsyncValue.loading(),
    this.history = const AsyncValue.loading(),
    this.historyOwnOnly = false,
  });

  BoxDetailState copyWith({
    AsyncValue<BoxDetail>? detail,
    AsyncValue<BoxHistory>? history,
    bool? historyOwnOnly,
  }) => BoxDetailState(
    detail: detail ?? this.detail,
    history: history ?? this.history,
    historyOwnOnly: historyOwnOnly ?? this.historyOwnOnly,
  );
}