// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'permission_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

/// Mã quyền của user đang đăng nhập, lấy từ `GET /api/auth/me`.
///
/// Vì sao KHÔNG đọc `homeProvider`: màn Home có sẵn danh sách này trong state
/// của nó, nhưng state đó chỉ có khi đã đi qua màn Home. Vào màn bằng
/// deep-link hoặc khi hệ điều hành dựng lại app thì state rỗng và MỌI nút sẽ
/// bị ẩn oan — mà nút bị ẩn thì người dùng không có cách nào biết là do chưa
/// nạp quyền hay do không có quyền. Provider riêng thì màn nào cần tự nạp.
///
/// `keepAlive`: quyền không đổi trong một lần đăng nhập, mà màn nào cũng hỏi.
/// Đổi role thì phải đăng nhập lại — phía API còn cache 5 phút
/// (`perms:user:{userId}`) nên invalidate ngay cũng chưa chắc ra số mới.

@ProviderFor(myPermissions)
final myPermissionsProvider = MyPermissionsProvider._();

/// Mã quyền của user đang đăng nhập, lấy từ `GET /api/auth/me`.
///
/// Vì sao KHÔNG đọc `homeProvider`: màn Home có sẵn danh sách này trong state
/// của nó, nhưng state đó chỉ có khi đã đi qua màn Home. Vào màn bằng
/// deep-link hoặc khi hệ điều hành dựng lại app thì state rỗng và MỌI nút sẽ
/// bị ẩn oan — mà nút bị ẩn thì người dùng không có cách nào biết là do chưa
/// nạp quyền hay do không có quyền. Provider riêng thì màn nào cần tự nạp.
///
/// `keepAlive`: quyền không đổi trong một lần đăng nhập, mà màn nào cũng hỏi.
/// Đổi role thì phải đăng nhập lại — phía API còn cache 5 phút
/// (`perms:user:{userId}`) nên invalidate ngay cũng chưa chắc ra số mới.

final class MyPermissionsProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<String>>,
          List<String>,
          FutureOr<List<String>>
        >
    with $FutureModifier<List<String>>, $FutureProvider<List<String>> {
  /// Mã quyền của user đang đăng nhập, lấy từ `GET /api/auth/me`.
  ///
  /// Vì sao KHÔNG đọc `homeProvider`: màn Home có sẵn danh sách này trong state
  /// của nó, nhưng state đó chỉ có khi đã đi qua màn Home. Vào màn bằng
  /// deep-link hoặc khi hệ điều hành dựng lại app thì state rỗng và MỌI nút sẽ
  /// bị ẩn oan — mà nút bị ẩn thì người dùng không có cách nào biết là do chưa
  /// nạp quyền hay do không có quyền. Provider riêng thì màn nào cần tự nạp.
  ///
  /// `keepAlive`: quyền không đổi trong một lần đăng nhập, mà màn nào cũng hỏi.
  /// Đổi role thì phải đăng nhập lại — phía API còn cache 5 phút
  /// (`perms:user:{userId}`) nên invalidate ngay cũng chưa chắc ra số mới.
  MyPermissionsProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'myPermissionsProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$myPermissionsHash();

  @$internal
  @override
  $FutureProviderElement<List<String>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<String>> create(Ref ref) {
    return myPermissions(ref);
  }
}

String _$myPermissionsHash() => r'0f4c1d7a93b5e2684ac0d1f5b7e3920c8ad64175';
