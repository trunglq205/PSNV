﻿namespace SWMS_WebTool.Models.DataKitting
{
    public class TimeAndType
    {
        public string Time { get; set; }
        public string Type { get; set; }
        public string Model { get; set; }
        public string Line { get; set; }
        public string SpecialPart { get; set; }
        public string Plant { get; set; }
        //Tuấn Anh sửa process MW
        //public string PositionFA { get; set; }
    }
    public class TimeAndTypeComparer : IEqualityComparer<TimeAndType>
    {
        public bool Equals(TimeAndType x, TimeAndType y)
        {
            if (x == null || y == null)
                return false;
            //Tuấn Anh sửa
           //return x.Time == y.Time && x.Type == y.Type && x.Model == y.Model && x.Line == y.Line && x.SpecialPart == y.SpecialPart && x.Plant == y.Plant && x.PositionFA == y.PositionFA;
            return x.Time == y.Time && x.Type == y.Type && x.Model == y.Model && x.Line == y.Line && x.SpecialPart == y.SpecialPart && x.Plant == y.Plant;
        }

        public int GetHashCode(TimeAndType obj)
        {
            if (obj == null)
                return 0;

            int hashTime = obj.Time == null ? 0 : obj.Time.GetHashCode();
            int hashType = obj.Type == null ? 0 : obj.Type.GetHashCode();
            int hashModel = obj.Model == null ? 0 : obj.Model.GetHashCode();
            int hashLinel = obj.Line == null ? 0 : obj.Line.GetHashCode();
            int hashSpecialPart = obj.SpecialPart == null ? 0 : obj.SpecialPart.GetHashCode();
            int hashPlant = obj.Plant == null ? 0 : obj.Plant.GetHashCode();
            //Tuấn Anh thêm
            //int hashPositionFA = obj.PositionFA == null ? 0 : obj.PositionFA.GetHashCode();

            //Tuấn Anh sửa
            //return hashTime ^ hashType ^ hashModel ^ hashLinel ^ hashSpecialPart ^ hashPlant ^ hashPositionFA;
            return hashTime ^ hashType ^ hashModel ^ hashLinel ^ hashSpecialPart ^ hashPlant;
        }
    }

    public class CustomKey
    {
        public string Model { get; set; }
        public string Type { get; set; }
        public string Time { get; set; }
        public string Line { get; set; }
        public string SpecialPart { get; set; }
        public string Plant { get; set; }
        //Tuấn Anh sửa process MW
        public string PositionFA { get; set; }

        public override int GetHashCode()
        {
            //Tuấn Anh sửa
            return HashCode.Combine(Type, Model, Time, Line, SpecialPart, Plant,PositionFA);
            //return HashCode.Combine(Type, Model, Time, Line, SpecialPart, Plant);

        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            CustomKey other = (CustomKey)obj;
            //return this.Type == other.Type &&
            //       this.Model == other.Model &&
            //       this.Time == other.Time &&
            //       this.Line == other.Line &&
            //       this.SpecialPart == other.SpecialPart &&
            //       this.Plant == other.Plant &&
            //       this.PositionFA == other.PositionFA;

            return this.Type == other.Type &&
                   this.Model == other.Model &&
                   this.Time == other.Time &&
                   this.Line == other.Line &&
                   this.SpecialPart == other.SpecialPart &&
                   this.Plant == other.Plant;
        }
    }
    public class TimeAndTypeProces
    {
        public string Time { get; set; }
        public string Type { get; set; }
        public string Model { get; set; }
        public string Line { get; set; }
        public string SpecialPart { get; set; }
        public string Plant { get; set; }
        //Tuấn Anh sửa process MW
        public string PositionFA { get; set; }
    }
    public class TimeAndTypeComparerProcess : IEqualityComparer<TimeAndTypeProces>
    {
        public bool Equals(TimeAndTypeProces x, TimeAndTypeProces y)
        {
            if (x == null || y == null)
                return false;
            //Tuấn Anh sửa
            return x.Time == y.Time && x.Type == y.Type && x.Model == y.Model && x.Line == y.Line && x.SpecialPart == y.SpecialPart && x.Plant == y.Plant && x.PositionFA == y.PositionFA;
            //return x.Time == y.Time && x.Type == y.Type && x.Model == y.Model && x.Line == y.Line && x.SpecialPart == y.SpecialPart && x.Plant == y.Plant;
        }

        public int GetHashCode(TimeAndTypeProces obj)
        {
            if (obj == null)
                return 0;

            int hashTime = obj.Time == null ? 0 : obj.Time.GetHashCode();
            int hashType = obj.Type == null ? 0 : obj.Type.GetHashCode();
            int hashModel = obj.Model == null ? 0 : obj.Model.GetHashCode();
            int hashLinel = obj.Line == null ? 0 : obj.Line.GetHashCode();
            int hashSpecialPart = obj.SpecialPart == null ? 0 : obj.SpecialPart.GetHashCode();
            int hashPlant = obj.Plant == null ? 0 : obj.Plant.GetHashCode();
            //Tuấn Anh thêm
            int hashPositionFA = obj.PositionFA == null ? 0 : obj.PositionFA.GetHashCode();

            //Tuấn Anh sửa
            return hashTime ^ hashType ^ hashModel ^ hashLinel ^ hashSpecialPart ^ hashPlant ^ hashPositionFA;
            //return hashTime ^ hashType ^ hashModel ^ hashLinel ^ hashSpecialPart ^ hashPlant;
        }
    }

    public class CustomKeyProcess
    {
        public string Model { get; set; }
        public string Type { get; set; }
        public string Time { get; set; }
        public string Line { get; set; }
        public string SpecialPart { get; set; }
        public string Plant { get; set; }
        //Tuấn Anh sửa process MW
        public string PositionFA { get; set; }

        public override int GetHashCode()
        {
            //Tuấn Anh sửa
            return HashCode.Combine(Type, Model, Time, Line, SpecialPart, Plant, PositionFA);
            //return HashCode.Combine(Type, Model, Time, Line, SpecialPart, Plant);

        }

        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
                return false;

            CustomKeyProcess other = (CustomKeyProcess)obj;
            return this.Type == other.Type &&
                   this.Model == other.Model &&
                   this.Time == other.Time &&
                   this.Line == other.Line &&
                   this.SpecialPart == other.SpecialPart &&
                   this.Plant == other.Plant &&
                   this.PositionFA == other.PositionFA;

            //return this.Type == other.Type &&
            //       this.Model == other.Model &&
            //       this.Time == other.Time &&
            //       this.Line == other.Line &&
            //       this.SpecialPart == other.SpecialPart &&
            //       this.Plant == other.Plant;
        }
    }
}
