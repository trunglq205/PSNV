using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.HdSoft.PalletSync.Business;
using Swms.FinishGoods.API.Features.Pallets.Api;

namespace Swms.FinishGoods.API.Features.HdSoft.PalletSync.Api
{
    /// <summary>
    /// Đồng bộ vị trí pallet theo HD soft. Tách khỏi PalletController nhưng giữ prefix
    /// api/pallets nên PDA / Web không phải đổi URL.
    /// </summary>
    [ApiController]
    [Route("api/pallets")]
    public class PalletHdSoftController : ControllerBase
    {
        private readonly IPalletHdSoftSyncService _service;
        public PalletHdSoftController(IPalletHdSoftSyncService service) => _service = service;

        /// <summary>
        /// Đồng bộ vị trí 1 pallet theo VỊ TRÍ ĐANG TỒN bên HD soft (M_StorageOnhand).
        /// Không còn tồn mà giao dịch cuối là M- / C- thì gán si_no = CUSTOMER + rời vị trí.
        /// Pallet phải có sẵn trong SWMS, chưa có thì 404 — PDA gọi from-foss trước.
        /// VD: POST /api/pallets/by-lot-no/210260504092/hdsoft-sync
        /// </summary>
        [HttpPost("by-lot-no/{lotNo}/hdsoft-sync")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<HdSoftSyncResponse>> SyncFromHdSoft(
            string lotNo, [FromQuery] string? include)
            => Ok(await _service.SyncFromHdSoftAsync(lotNo, PalletIncludeParser.Parse(include)));

        /// <summary>
        /// Đồng bộ vị trí nhiều pallet theo HD soft (tối đa 200/lần).
        /// Pallet phải có sẵn trong SWMS. Gom 1 câu SQL bên HD soft cho cả nhóm.
        /// </summary>
        [HttpPost("hdsoft-sync-batch")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<List<HdSoftSyncBatchItem>>> SyncFromHdSoftBatch(
            [FromBody] HdSoftSyncBatchRequest request)
            => Ok(await _service.SyncFromHdSoftBatchAsync(request.LotNos));
    }
}
