﻿using SWMS_WebTool.Utils.Extensions;
using Newtonsoft.Json;
using SWMS_WebTool.Utils;

namespace SWMS_WebTool.Models.Layout
{
    public class Floor : Layout
    {
        public Floor() { }

        public Floor(KonvaObject konvaObject) 
        {
            var children = konvaObject.Children?.FirstOrDefault()?.Children?.SkipWhile(e => e.Attrs.Name.ToEnum<WidgetType>() == WidgetType.Wall);

            var widgets = children?.Select(e => WidgetFactory.BuildWidget(e)).ToList() ?? new List<Widget>();

            Id = konvaObject.Attrs.Id; 
            FloorName = konvaObject.Attrs.Title ?? "";
            Width = konvaObject.Attrs.Width;
            Height = konvaObject.Attrs.Height;
            Widgets = widgets;

            string[] arr = konvaObject.Attrs.CustomData?.Split(";") ?? new string[3];
            FloorId = arr[0]?.ToInt() ?? 0;
            FloorName = arr[1];
            FloorCode = arr[2];
        }

        public string FloorName { get; set; }
        public int FloorId { get; set; }
        public string FloorCode { get; set; }

        public override WidgetType Type => WidgetType.Floor;
        protected override KonvaClassType ClassName => KonvaClassType.Stage;

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.CustomData = $"{FloorId};{FloorName};{FloorCode}";
            return attrs;
        }

        public List<Node> FindRackBoundingBoxs(List<string> blockNames)
        {
            var result = new List<Node>();

            var allRack = new List<Rack>();
            Widgets.ForEach(floorItem =>
            {
                if (floorItem is Layout)
                {
                    (floorItem as Layout)?.Widgets.ForEach(widget =>
                    {
                        if (widget is Rack) allRack.Add(widget as Rack);
                    });
                }
            });

            blockNames.ForEach(blockName =>
            {
                var block = new Block(blockName);
                if (block.FloorCode != FloorCode)
                {
                    return;
                }

                var rack = allRack.FirstOrDefault(e => e.RackCode == block.RackCode);

                if (rack != null)
                {
                    var blockRect = rack.FindBlock(blockName);

                    if (blockRect != null)
                    {
                        var centerPoint = blockRect.GetCenterPoint();
                        var centerX = (int)Math.Round(centerPoint.Item1 / Constants.CELL_SIZE);
                        var centerY = (int)Math.Round(centerPoint.Item2 / Constants.CELL_SIZE);
                        var node = new Node(centerX,centerY, blockName)
                        { BoundingBox = blockRect};
                        result.Add(node);
                    }
                }
            });
            return result;
        }
    }
}
