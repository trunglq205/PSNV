namespace Swms.FinishGoods.Web.Features.Models.Business.Models;

/// <summary>
/// Khu vực kho — dùng cho dropdown "khu vực gợi ý" ở form/filter và để resolve
/// suggest_area code → Id khi import CSV.
///
/// ⚠ Khớp shape với response của GET /api/warehouse-areas. Nếu endpoint thật trả
/// tên field khác (vd AreaCode/AreaName) thì sửa ở đây và ở IModelApi.
/// </summary>
public class WarehouseAreaDto
{
    /// <summary>Khoá chính — chính là giá trị ghi vào cột models.suggest_area.</summary>
    public int Id { get; set; }

    /// <summary>Mã khu vực (business key) — hiển thị cho người dùng, dùng trong CSV.</summary>
    public string AreaCode { get; set; } = "";

    public string? AreaName { get; set; }
}

/// <summary>Tham số lọc cho GET /api/warehouse-areas (không phân trang).</summary>
public class WarehouseAreaQuery
{
    public string? Code { get; set; }
    public string? Name { get; set; }
}
