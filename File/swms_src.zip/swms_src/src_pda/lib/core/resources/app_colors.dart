import 'package:flutter/material.dart';

/// Màu raw cho surface PDA (xanh lá) — dịch trực tiếp từ tokens.css.
/// Tên biến giữ nguyên theo design token để đối chiếu dễ dàng.
/// Widget KHÔNG gọi trực tiếp lớp này; đọc qua Theme/AppColorsExtension.
abstract final class AppColors {
  const AppColors._();

  // ── Primary (blue) ──
  static const Color primary = Color(0xFF0F6CBD);       // --primary
  static const Color primaryDark = Color(0xFF115EA3);   // --primary-dark
  static const Color primaryLight = Color(0xFF2886DE);  // --primary-light
  static const Color primaryTint = Color(0xFFE5F1FB);   // --primary-tint
  static const Color primaryTint2 = Color(0xFFCFE4F7);  // --primary-tint-2

  // ── Semantic ──
  static const Color success = Color(0xFF2E7D32);
  static const Color successBg = Color(0xFFE8F5E9);
  static const Color warning = Color(0xFFE65100);
  static const Color warningBg = Color(0xFFFFF3E0);
  static const Color danger = Color(0xFFC62828);
  static const Color dangerBg = Color(0xFFFFEBEE);

  // ── Neutral / surface (light) ──
  static const Color bg = Color(0xFFF5F7FA);
  static const Color card = Color(0xFFFFFFFF);
  static const Color card2 = Color(0xFFFAFBFC);
  static const Color border = Color(0xFFE5E7EB);
  static const Color border2 = Color(0xFFD1D5DB);
  static const Color text1 = Color(0xFF1A1A2E);
  static const Color text2 = Color(0xFF4B5563);
  static const Color text3 = Color(0xFF6B7280);
  static const Color text4 = Color(0xFF9CA3AF);

  // ── Accent palette (phân loại entity khi quét) ──
  static const Color accentBlue = Color(0xFF1976D2);
  static const Color accentBlueTint = Color(0xFFE3F2FD);
  static const Color accentBlueFg = Color(0xFF0D47A1);
  static const Color accentOrange = Color(0xFFE65100);
  static const Color accentOrangeTint = Color(0xFFFFF3E0);
  static const Color accentOrangeFg = Color(0xFFBF360C);
  static const Color accentPurple = Color(0xFF7B1FA2);
  static const Color accentPurpleTint = Color(0xFFF3E5F5);
  static const Color accentPurpleFg = Color(0xFF4A148C);
  static const Color accentTeal = Color(0xFF00838F);
  static const Color accentTealTint = Color(0xFFE0F2F1);
  static const Color accentTealFg = Color(0xFF006064);

  // ── Dark theme overrides (data-theme="dark") ──
  static const Color darkBg = Color(0xFF0F172A);
  static const Color darkCard = Color(0xFF1E293B);
  static const Color darkCard2 = Color(0xFF243049);
  static const Color darkBorder = Color(0xFF334155);
  static const Color darkBorder2 = Color(0xFF475569);
  static const Color darkText1 = Color(0xFFF1F5F9);
  static const Color darkText2 = Color(0xFFCBD5E1);
  static const Color darkText3 = Color(0xFF94A3B8);
  static const Color darkText4 = Color(0xFF64748B);
}
