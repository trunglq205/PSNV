﻿using Swms.FinishGoods.Api.Features.Categories;
using Swms.FinishGoods.Api.Features.Models;
using Swms.FinishGoods.Api.Features.PdaApp;
using Swms.FinishGoods.Api.Features.Roles;
using Swms.FinishGoods.API.Features.AbnormalReports;
using Swms.FinishGoods.API.Features.Auth;
using Swms.FinishGoods.API.Features.Balance;
using Swms.FinishGoods.API.Features.Boxes;
using Swms.FinishGoods.API.Features.EmailConfigs;
using Swms.FinishGoods.API.Features.EuLabel;
using Swms.FinishGoods.API.Features.Foss;
using Swms.FinishGoods.API.Features.HdSoft;
using Swms.FinishGoods.API.Features.Inventory;
using Swms.FinishGoods.API.Features.MapDesigner;
using Swms.FinishGoods.API.Features.MapView;
using Swms.FinishGoods.API.Features.OqcSamples;
using Swms.FinishGoods.API.Features.Pallets;
using Swms.FinishGoods.API.Features.PartCards;
using Swms.FinishGoods.API.Features.ReturnInstructions;
using Swms.FinishGoods.API.Features.Roles;
using Swms.FinishGoods.API.Features.Scan;
using Swms.FinishGoods.API.Features.ShipmentInstructions;
using Swms.FinishGoods.API.Features.ShipmentTrips;
using Swms.FinishGoods.API.Features.Shortages;
using Swms.FinishGoods.API.Features.StockEvents;
using Swms.FinishGoods.API.Features.Stocktake;
using Swms.FinishGoods.API.Features.Stocky;
using Swms.FinishGoods.API.Features.StorageMap;
using Swms.FinishGoods.API.Features.StowagePlans;
using Swms.FinishGoods.API.Features.Sync;
using Swms.FinishGoods.API.Features.TempLocMap;
using Swms.FinishGoods.API.Features.Users;
using Swms.FinishGoods.API.Features.WarehouseAreas;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.Business.Media;
using Swms.FinishGoods.API.Shared.Reporting;

namespace Swms.FinishGoods.API.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddFeatures(this IServiceCollection services, IConfiguration configuration)
        => services
            .AddAuthFeature(configuration)
            .AddUserFeature()
            .AddRoleFeature()
            .AddFossFeature()
            .AddPartCardFeature()
            .AddTempLocMapFeature()
            .AddStorageMapFeature()
            .AddStocktakeFeature()
            .AddWarehouseAreasFeature()
            .AddMapDesignerFeature()
            .AddMapViewFeature()
            .AddBalanceFeature()
            .AddAbnormalReportFeature()
            .AddSingleton<IImageStorage, ImageStorage>()
            .AddSingleton<IExcelReportBuilder, ClosedXmlReportBuilder>()
            // Gửi mail dùng chung cho mọi tính năng. Tắt/bật bằng Mail:Enabled
            // trong appsettings — không khai thì chỉ ghi log, không gửi.
            .AddSingleton<IMailSender, SmtpMailSender>()
            .AddLotFeature()
            .AddOqcSampleFeature()
            .AddModelFeature()
            .AddScanFeature()
            .AddBoxFeature()
            .AddEuLabelFeature()
            .AddPdaAppFeature()
            .AddCategoryFeature()
            .AddInventoryFeature()
            .AddStockEventFeature()
            .AddShortageFeature()
            .AddEmailConfigFeature()
            .AddHdSoftFeature()
            .AddSyncFeature()
            .AddShipmentInstructionFeature()
            .AddShipmentTripFeature()
            .AddWeightSysFeature()
            .AddStowagePlanFeature()
            .AddReturnInstructionFeature()
            .AddStockyFeature(configuration)
            .AddPermissionAuthorization();
}