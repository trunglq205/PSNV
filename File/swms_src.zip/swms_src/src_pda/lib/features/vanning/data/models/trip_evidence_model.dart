import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/vanning/data/models/merge_session_model.dart';
import 'package:swms_finish_goods/features/vanning/domain/trip_evidence.dart';

part 'trip_evidence_model.g.dart';

// Khớp TripPhotoListResponse / TripPhotoItemResponse / TripPhotoResponse (TripPhotoModels.cs)
// và TripInspectionRequest / Response (TripVanningModels.cs). JSON camelCase.

@JsonSerializable(createToJson: false)
class TripPhotoItemModel {
  final int step;
  final String stepTitle;
  final String key;
  final String label;
  final String? note;
  final int perUnit;
  final String unit;
  final int units;
  final List<String>? slotLabels;

  const TripPhotoItemModel({
    required this.step,
    required this.stepTitle,
    required this.key,
    required this.label,
    this.note,
    required this.perUnit,
    required this.unit,
    required this.units,
    this.slotLabels,
  });

  factory TripPhotoItemModel.fromJson(Map<String, dynamic> json) =>
      _$TripPhotoItemModelFromJson(json);

  PhotoItemDef toEntity() => PhotoItemDef(
        step: step,
        stepTitle: stepTitle,
        key: key,
        label: label,
        note: note,
        perUnit: perUnit,
        unit: PhotoUnit.fromCode(unit),
        units: units,
        slotLabels: slotLabels ?? const [],
      );
}

@JsonSerializable(createToJson: false)
class TripPhotoModel {
  final int id;
  final String itemKey;
  final int? unitNo;
  final String? palletCode;
  final int slotNo;
  final DateTime createdAt;
  final String? createdBy;

  const TripPhotoModel({
    required this.id,
    required this.itemKey,
    this.unitNo,
    this.palletCode,
    required this.slotNo,
    required this.createdAt,
    this.createdBy,
  });

  factory TripPhotoModel.fromJson(Map<String, dynamic> json) =>
      _$TripPhotoModelFromJson(json);

  TripPhoto toEntity() => TripPhoto(
        id: id,
        itemKey: itemKey,
        unitNo: unitNo,
        palletCode: palletCode,
        slotNo: slotNo,
        createdAt: createdAt,
        createdBy: createdBy,
      );
}

@JsonSerializable(createToJson: false)
class TripInspectionModel {
  final String result;
  final List<String> passedConditions;
  final String? note;
  final String? containerNo;
  final DateTime inspectedAt;
  final String? inspectedBy;

  const TripInspectionModel({
    required this.result,
    this.passedConditions = const [],
    this.note,
    this.containerNo,
    required this.inspectedAt,
    this.inspectedBy,
  });

  factory TripInspectionModel.fromJson(Map<String, dynamic> json) =>
      _$TripInspectionModelFromJson(json);

  TripInspection toEntity() => TripInspection(
        result: InspectionResult.fromCode(result),
        passedConditions: passedConditions
            .map(ContainerCondition.fromCode)
            .whereType<ContainerCondition>()
            .toSet(),
        note: note,
        containerNo: containerNo,
        inspectedAt: inspectedAt,
        inspectedBy: inspectedBy,
      );
}

@JsonSerializable(createToJson: false)
class TripPalletListModel {
  final String code;
  final int boxCount;
  final int pcs;
  final String? locatorCode;
  final int? cocNo;

  const TripPalletListModel({
    required this.code,
    this.boxCount = 0,
    this.pcs = 0,
    this.locatorCode,
    this.cocNo,
  });

  factory TripPalletListModel.fromJson(Map<String, dynamic> json) =>
      _$TripPalletListModelFromJson(json);

  TripPalletList toEntity() => TripPalletList(
        code: code,
        boxCount: boxCount,
        pcs: pcs,
        locatorCode: locatorCode,
        cocNo: cocNo,
      );
}

@JsonSerializable(createToJson: false)
class TripEvidenceModel {
  final int tripId;
  final bool canUpload;
  final int pallets;
  final int cocs;
  final int rows;
  final List<TripPhotoItemModel> items;
  final List<TripPhotoModel> photos;
  final TripInspectionModel? inspection;
  final List<TripPalletListModel>? palletLists;
  final List<TripStackModel>? stacks;

  const TripEvidenceModel({
    required this.tripId,
    required this.canUpload,
    this.pallets = 0,
    this.cocs = 0,
    this.rows = 0,
    this.items = const [],
    this.photos = const [],
    this.inspection,
    this.palletLists,
    this.stacks,
  });

  factory TripEvidenceModel.fromJson(Map<String, dynamic> json) =>
      _$TripEvidenceModelFromJson(json);

  TripEvidence toEntity() => TripEvidence(
        tripId: tripId,
        canUpload: canUpload,
        pallets: pallets,
        cocs: cocs,
        rows: rows,
        items: items.map((i) => i.toEntity()).toList(),
        photos: photos.map((p) => p.toEntity()).toList(),
        inspection: inspection?.toEntity(),
        palletLists: [for (final p in palletLists ?? const <TripPalletListModel>[]) p.toEntity()],
        stacks: [for (final s in stacks ?? const <TripStackModel>[]) s.toEntity()],
      );
}

/// Body POST /shipment-trips/{id}/inspection.
@JsonSerializable(createFactory: false)
class TripInspectionRequestModel {
  final String result;
  final List<String> passedConditions;
  final String? note;

  const TripInspectionRequestModel({
    required this.result,
    required this.passedConditions,
    this.note,
  });

  Map<String, dynamic> toJson() => _$TripInspectionRequestModelToJson(this);
}
