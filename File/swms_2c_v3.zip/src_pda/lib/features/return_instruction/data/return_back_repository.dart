import 'package:dio/dio.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_back_model.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2c — truy cập API, gọi Dio TRỰC TIẾP thay vì qua retrofit.
//
//  Cùng lý do đã ghi ở return_back_model.dart: bộ mục 2c làm sao để KHÔNG cần
//  chạy build_runner, và @RestApi thì buộc phải sinh `.g.dart`.
//
//  Vẫn đi qua Dio CHUNG của app (`dioProvider`) nên giữ nguyên baseUrl, token
//  và ErrorInterceptor — câu thông báo lỗi của server vẫn tới được
//  ErrorHandler y như mọi màn khác.
//
//  Đường dẫn PHẢI có tiền tố `/api`: BASE_URL trong `config/*.json` chỉ tới
//  host + port (xem `app_config.dart`).
// ─────────────────────────────────────────────────────────────

class ReturnBackRepository {
  final Dio _dio;
  const ReturnBackRepository(this._dio);

  static const _base = '/api/return-back-requests';

  /// Danh sách đề nghị. [step] lọc theo bước — PDA chỉ cần `scs_deliver`.
  ///
  /// KHÔNG bắt DioException để bọc lại: ErrorInterceptor đã lấy câu thông báo
  /// của server và ErrorHandler hiện nguyên câu đó — bọc lại chỉ còn câu chung
  /// chung, mất thông tin.
  Future<List<BackRequest>> fetchList({int? docId, String? step}) async {
    final res = await _dio.get<Object?>(
      _base,
      queryParameters: <String, Object?>{
        if (docId != null) 'docId': docId,
        if (step != null) 'step': step,
      },
    );
    final data = res.data;
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => backRequestFromJson(e.cast<String, Object?>()))
        .toList();
  }

  Future<BackRequest> fetchById(int id) async {
    final res = await _dio.get<Map<String, Object?>>('$_base/$id');
    return backRequestFromJson(res.data ?? const {});
  }

  /// Nhật ký pallet đã giao, mới nhất trước.
  Future<List<BackDelivery>> fetchDeliveries(int id) async {
    final res = await _dio.get<Object?>('$_base/$id/deliveries');
    final data = res.data;
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => backDeliveryFromJson(e.cast<String, Object?>()))
        .toList();
  }

  /// Giao hàng: gửi NHIỀU Pallet ID trong MỘT lượt.
  ///
  /// Gửi cả cụm chứ không mỗi pallet một request: FA phải nhận MỘT lá thư liệt
  /// kê đủ pallet, và server chỉ gửi thư ở lượt làm xong cả đề nghị — bắn từng
  /// mã là FA nhận năm lá thư cho một chuyến xe.
  Future<BackDeliverResult> deliver({
    required int id,
    required List<String> lotNos,
    String? comment,
  }) async {
    final res = await _dio.post<Map<String, Object?>>(
      '$_base/$id/deliver',
      data: <String, Object?>{
        'lotNos': lotNos,
        if (comment != null && comment.trim().isNotEmpty)
          'comment': comment.trim(),
      },
    );
    return backDeliverResultFromJson(res.data ?? const {});
  }
}
