﻿using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.Api.Features.Categories.Api;

// ── QUERY (filter cho list, không phân trang) ────────────────────────
public class CategoryQuery
{
    public string? Code { get; set; }
    public string? Name { get; set; }
    public string? PlantCode { get; set; }
    public string? Product { get; set; }
}

// ── REQUEST (input) ──────────────────────────────────────────────────
// Create: code là business key do người dùng nhập.
public record CreateCategoryRequest(
    [Required, MaxLength(50)] int Code,
    [MaxLength(200)] string? Name,
    [MaxLength(500)] string? Description,
    [MaxLength(50)] string? Bd,
    [MaxLength(10)] string? PlantCode,
    [MaxLength(50)] string? Product,
    [MaxLength(50)] string? SlockPmd,
    [MaxLength(50)] string? SlockFa,
    [MaxLength(50)] string? SlockScs,
    [MaxLength(50)] string? SlockJpt,
    [MaxLength(50)] string? SlockPort,
    [MaxLength(50)] string? ProductionVersion);

// Update: KHÔNG cho đổi code (là khóa) — code lấy từ route.
public record UpdateCategoryRequest(
    [MaxLength(200)] string? Name,
    [MaxLength(500)] string? Description,
    [MaxLength(50)] string? Bd,
    [MaxLength(10)] string? PlantCode,
    [MaxLength(50)] string? Product,
    [MaxLength(50)] string? SlockPmd,
    [MaxLength(50)] string? SlockFa,
    [MaxLength(50)] string? SlockScs,
    [MaxLength(50)] string? SlockJpt,
    [MaxLength(50)] string? SlockPort,
    [MaxLength(50)] string? ProductionVersion);

// ── RESPONSE (output) ────────────────────────────────────────────────
public record CategoryResponse(
    int Code, string? Name, string? Description, string? Bd, string? PlantCode,
    string? Product, string? SlockPmd, string? SlockFa, string? SlockScs,
    string? SlockJpt, string? SlockPort, string? ProductionVersion, DateTime CreatedAt)
{
    public static CategoryResponse From(CategoryEntity c)
        => new(c.Code, c.Name, c.Description, c.Bd, c.PlantCode, c.Product,
               c.SlockPmd, c.SlockFa, c.SlockScs, c.SlockJpt, c.SlockPort,
               c.ProductionVersion, c.CreatedAt);
}

/// <summary>Row option gọn cho dropdown FE.</summary>
public record CategoryOptionResponse(int Code, string? Name, string? Product)
{
    public static CategoryOptionResponse From(CategoryEntity c) => new(c.Code, c.Name, c.Product);
}