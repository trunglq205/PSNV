import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_text_field.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';

/// Bước 1: nhập model bằng tay HOẶC quét barcode.
///
/// Quét kitting card → chỉ lấy field đầu tiên; quét QR model → lấy nguyên mã.
/// Việc tách chuỗi do notifier lo (`modelFromScan`), widget này chỉ nhập tay.
///
/// Chế độ nhiều mã cũng bắt đầu bằng ĐÚNG 1 mã ở bước này — các mã còn lại
/// quét thêm ở bước 2.
class PartCardInputBody extends StatefulWidget {
  const PartCardInputBody({
    super.key,
    required this.value,
    required this.mode,
    required this.onChanged,
    required this.onSubmit,
  });

  /// Giá trị model hiện tại trong state (có thể do quét ghi vào).
  final String value;

  final PartCardMode mode;

  final ValueChanged<String> onChanged;

  /// Enter trên bàn phím → tra model luôn.
  final VoidCallback onSubmit;

  @override
  State<PartCardInputBody> createState() => _PartCardInputBodyState();
}

class _PartCardInputBodyState extends State<PartCardInputBody> {
  late final TextEditingController _controller = TextEditingController(
    text: widget.value,
  );

  @override
  void didUpdateWidget(PartCardInputBody oldWidget) {
    super.didUpdateWidget(oldWidget);
    // State đổi từ ngoài (vừa quét) → đồng bộ lại ô nhập.
    if (widget.value != _controller.text) {
      _controller.value = TextEditingValue(
        text: widget.value,
        selection: TextSelection.collapsed(offset: widget.value.length),
      );
    }
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return ListView(
      children: [
        AppCard(
          padding: const EdgeInsets.symmetric(vertical: 12, horizontal: 10),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              _SectionLabel(LocaleKeys.part_card_input_label.tr()),
              const SizedBox(height: AppDimens.sm),
              AppTextField(
                kind: AppInputKind.code,
                value: widget.value,
                hint: LocaleKeys.part_card_input_hint.tr(),
                textInputAction: TextInputAction.search,
                prefixIcon: Icon(
                  Icons.keyboard_alt_outlined,
                  size: 18,
                  color: swms.text3,
                ),
                onChanged: widget.onChanged,
                onSubmitted: (_) => widget.onSubmit(),
              ),
            ],
          ),
        ),

        const SizedBox(height: AppDimens.md),

        // Vạch phân cách "hoặc"
        Row(
          children: [
            Expanded(child: Divider(color: swms.border)),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: AppDimens.sm),
              child: Text(
                LocaleKeys.part_card_input_or.tr(),
                style: AppTextStyles.caption.copyWith(
                  fontWeight: FontWeight.w700,
                  letterSpacing: .5,
                  color: swms.text4,
                ),
              ),
            ),
            Expanded(child: Divider(color: swms.border)),
          ],
        ),

        const SizedBox(height: AppDimens.md),

        // Khung quét — quét kitting card hoặc QR model
        BarcodeScannerButton(
          scanningLabel: LocaleKeys.part_card_input_scan_label.tr(),
        ),

        const SizedBox(height: AppDimens.sm),
        Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 1),
              child: Icon(
                Icons.info_outline_rounded,
                size: 12,
                color: swms.primary,
              ),
            ),
            const SizedBox(width: 6),
            Expanded(
              child: Text(
                widget.mode.isMulti
                    ? LocaleKeys.part_card_input_scan_hint_multi.tr()
                    : LocaleKeys.part_card_input_scan_hint.tr(),
                style: AppTextStyles.caption.copyWith(
                  fontSize: 10.5,
                  height: 1.4,
                  color: swms.text3,
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}

class _SectionLabel extends StatelessWidget {
  const _SectionLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text.toUpperCase(),
      style: AppTextStyles.caption.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: .3,
        color: context.swms.text3,
      ),
    );
  }
}
