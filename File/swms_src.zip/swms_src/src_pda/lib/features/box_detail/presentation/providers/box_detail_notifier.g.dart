// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'box_detail_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Notifier family theo boxId (id là định danh duy nhất, không dùng boxNo).

@ProviderFor(BoxDetailNotifier)
final boxDetailProvider = BoxDetailNotifierFamily._();

/// Notifier family theo boxId (id là định danh duy nhất, không dùng boxNo).
final class BoxDetailNotifierProvider
    extends $NotifierProvider<BoxDetailNotifier, BoxDetailState> {
  /// Notifier family theo boxId (id là định danh duy nhất, không dùng boxNo).
  BoxDetailNotifierProvider._({
    required BoxDetailNotifierFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'boxDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$boxDetailNotifierHash();

  @override
  String toString() {
    return r'boxDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  BoxDetailNotifier create() => BoxDetailNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(BoxDetailState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<BoxDetailState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is BoxDetailNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$boxDetailNotifierHash() => r'ca88385c57a826164e7e3c56c145fad1565139ce';

/// Notifier family theo boxId (id là định danh duy nhất, không dùng boxNo).

final class BoxDetailNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          BoxDetailNotifier,
          BoxDetailState,
          BoxDetailState,
          BoxDetailState,
          int
        > {
  BoxDetailNotifierFamily._()
    : super(
        retry: null,
        name: r'boxDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Notifier family theo boxId (id là định danh duy nhất, không dùng boxNo).

  BoxDetailNotifierProvider call(int boxId) =>
      BoxDetailNotifierProvider._(argument: boxId, from: this);

  @override
  String toString() => r'boxDetailProvider';
}

/// Notifier family theo boxId (id là định danh duy nhất, không dùng boxNo).

abstract class _$BoxDetailNotifier extends $Notifier<BoxDetailState> {
  late final _$args = ref.$arg as int;
  int get boxId => _$args;

  BoxDetailState build(int boxId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<BoxDetailState, BoxDetailState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<BoxDetailState, BoxDetailState>,
              BoxDetailState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
