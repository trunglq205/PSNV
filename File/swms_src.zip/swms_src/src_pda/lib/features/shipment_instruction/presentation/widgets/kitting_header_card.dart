import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';

/// Thẻ đầu màn Soạn hàng: mã SI + đổi SI + tiến độ tuyến + mở bản đồ.
class KittingHeaderCard extends StatelessWidget {
  final ShipmentInstructionDetail si;
  final List<PickTask> route;
  final VoidCallback onChangeSi;
  final VoidCallback? onOpenMap;

  const KittingHeaderCard({
    super.key,
    required this.si,
    required this.route,
    required this.onChangeSi,
    this.onOpenMap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final done = route.where((t) => t.isDone).length;
    final planned = route.fold(0, (a, t) => a + t.qtyPlanned);
    final picked = route.fold(0, (a, t) => a + t.qtyPicked);
    // floor: 99.6% không hiện 100% khi còn thiếu.
    final pct = planned <= 0 ? 0 : (picked * 100 / planned).floor();

    return AppCard(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 8),
      child: Row(
        children: [
          Tooltip(
            message: LocaleKeys.kitting_change_si.tr(),
            child: InkWell(
              onTap: onChangeSi,
              customBorder: const CircleBorder(),
              child: SizedBox.square(
                dimension: AppDimens.hitMd,
                child: Center(
                  child: Container(
                    width: 32,
                    height: 32,
                    decoration: BoxDecoration(
                      color: swms.warning,
                      borderRadius: BorderRadius.circular(AppDimens.rInput - 2),
                    ),
                    child: const Icon(
                      Icons.swap_horiz,
                      size: 18,
                      color: Colors.white,
                    ),
                  ),
                ),
              ),
            ),
          ),
          const SizedBox(width: 4),
          // Tên SI + tiến độ chiếm hết phần còn lại — 2 nút bên phải đã gọn.
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  si.siNo,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 15,
                    letterSpacing: 0,
                    fontWeight: FontWeight.w700,
                    color: swms.text1,
                  ),
                ),
                Text(
                  LocaleKeys.kitting_progress.tr(
                    args: ['$done', '${route.length}', '$pct'],
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ],
            ),
          ),
          const SizedBox(width: AppDimens.sm),
          AppButton(
            label: LocaleKeys.kitting_view_map.tr(),
            icon: Icons.navigation_rounded,
            size: AppButtonSize.sm,
            isFullWidth: false,
            onPressed: onOpenMap,
          ),
        ],
      ),
    );
  }
}
