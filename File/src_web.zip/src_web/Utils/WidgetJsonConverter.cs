﻿using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using SWMS_WebTool.Models.Layout;

namespace SWMS_WebTool.Utils
{
    public class WidgetJsonConverter : JsonConverter
    {
        public override bool CanConvert(Type objectType)
        {
            return objectType == typeof(Widget);
        }

        public override object ReadJson(JsonReader reader, Type objectType, object existingValue, JsonSerializer serializer)
        {
            JObject jo = JObject.Load(reader);
            try
            {
                switch ((WidgetType)jo["type"].Value<int>())
                {
                    case WidgetType.Floor:
                         return jo.ToObject<Floor>(serializer);
                    case WidgetType.Zone:
                        return jo.ToObject<Zone>(serializer);
                    case WidgetType.Rack:

                        try
                        {
                            return jo.ToObject<Rack>(serializer);
                        }
                        catch (Exception ex)
                        {

                            throw ex;
                        }
                        
                           
                        

                       
                    case WidgetType.Text:
                        return jo.ToObject<Text>(serializer);
                    case WidgetType.SingleDoor:
                        return jo.ToObject<SingleDoor>(serializer);
                    case WidgetType.DoubleDoor:
                        return jo.ToObject<DoubleDoor>(serializer);
                    case WidgetType.NoDoor:
                        return jo.ToObject<NoDoor>(serializer);
                    case WidgetType.Rectangle:
                        return jo.ToObject<Rectangle>(serializer);
                    case WidgetType.Circle:
                        return jo.ToObject<Circle>(serializer);
                    case WidgetType.Line:
                        return jo.ToObject<Line>(serializer);
                    case WidgetType.RobotLine:
                        return jo.ToObject<RobotLine>(serializer);
                    case WidgetType.Stair:
                        return jo.ToObject<Stair>(serializer);
                    case WidgetType.Arrow:
                        return jo.ToObject<Arrow>(serializer);
                    case WidgetType.ArrowFill:
                        return jo.ToObject<ArrowFill>(serializer);
                    case WidgetType.Folklift:
                        return jo.ToObject<Folklift>(serializer);
                    case WidgetType.FolkliftWorking:
                        return jo.ToObject<FolkliftWorking>(serializer);
                    case WidgetType.Container:
                        return jo.ToObject<Container>(serializer);
                    case WidgetType.Folklift2:
                        return jo.ToObject<Folklift2>(serializer);
                    case WidgetType.Container2:
                        return jo.ToObject<Container2>(serializer);
                    case WidgetType.Trolley:
                        return jo.ToObject<Trolley>(serializer);
                    default:
                        throw new Exception("Unknown type");
                }
            }
            catch (Exception ex)
            {

                throw new Exception(ex.ToString());
            }
            
        }

        public override void WriteJson(JsonWriter writer, object value, JsonSerializer serializer)
        {
            throw new NotImplementedException();
        }
    }
}
