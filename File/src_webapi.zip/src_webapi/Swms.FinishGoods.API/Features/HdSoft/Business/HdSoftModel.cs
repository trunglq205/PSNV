namespace Swms.FinishGoods.API.Features.HdSoft.Business;

/// <summary>Mã model bên HD soft (M_Product.Value) mang hậu tố "-V4"; SWMS dùng mã không hậu tố.</summary>
public static class HdSoftModel
{
    public static string Normalize(string? productValue)
    {
        var v = productValue?.Trim() ?? "";
        return v.EndsWith("-V4", StringComparison.OrdinalIgnoreCase) ? v[..^3] : v;
    }
}

/// <summary>DocStatus chuẩn iDempiere.</summary>
public static class HdSoftDocStatus
{
    private static readonly Dictionary<string, string> Names = new(StringComparer.OrdinalIgnoreCase)
    {
        ["DR"] = "Nháp",
        ["IP"] = "Đang xử lý",
        ["IN"] = "Không hợp lệ",
        ["AP"] = "Đã duyệt",
        ["NA"] = "Không duyệt",
        ["WC"] = "Chờ xác nhận",
        ["WP"] = "Chờ thanh toán",
        ["CO"] = "Đã hoàn thành",
        ["CL"] = "Đã đóng",
        ["VO"] = "Đã huỷ",
        ["RE"] = "Đã đảo",
    };

    public static string? Name(string? code)
        => code is null ? null : Names.TryGetValue(code.Trim(), out var n) ? n : code.Trim();

    /// <summary>Phiếu bị huỷ / đảo — tương đương 'cancelled' bên SWMS.</summary>
    public static bool IsCancelled(string? code)
        => code?.Trim().ToUpperInvariant() is "VO" or "RE";
}

/// <summary>ETD của 1 phiếu C_Order: trường SAP "etd" nếu đọc được ngày, không thì DatePromised.</summary>
public static class HdSoftSiEtd
{
    private static readonly string[] Formats =
    {
        "yyyy-MM-dd", "yyyyMMdd", "yyyy-MM-ddTHH:mm:ss", "yyyy-MM-dd HH:mm:ss", "dd.MM.yyyy", "d.M.yyyy", "dd/MM/yyyy",
    };

    public static DateTime? Of(HdSoftSiOrder o)
    {
        var raw = o.Field("etd")?.Trim();
        if (!string.IsNullOrEmpty(raw)
            && DateTime.TryParseExact(raw, Formats, System.Globalization.CultureInfo.InvariantCulture,
                   System.Globalization.DateTimeStyles.None, out var d))
            return d.Date;
        return o.DatePromised?.Date;
    }
}

/// <summary>Ngày vanning của 1 phiếu C_Order: "Loading date : dd.MM.yyyy" trong headernote3
/// (cùng nguồn SapSiMapper dùng cho vanning_date bên SWMS). Không có -> null.</summary>
public static class HdSoftSiVanning
{
    private static readonly System.Text.RegularExpressions.Regex LoadingDate = new(
        @"loading\s*date\s*:\s*([0-9]{1,2}[./][0-9]{1,2}[./][0-9]{4})",
        System.Text.RegularExpressions.RegexOptions.IgnoreCase | System.Text.RegularExpressions.RegexOptions.Compiled);

    private static readonly string[] Formats = { "dd.MM.yyyy", "d.M.yyyy", "dd/MM/yyyy", "d/M/yyyy" };

    public static DateTime? Of(HdSoftSiOrder o)
    {
        var m = LoadingDate.Match(o.Field("headernote3") ?? "");
        return m.Success
               && DateTime.TryParseExact(m.Groups[1].Value, Formats, System.Globalization.CultureInfo.InvariantCulture,
                      System.Globalization.DateTimeStyles.None, out var d)
            ? d.Date
            : null;
    }
}
