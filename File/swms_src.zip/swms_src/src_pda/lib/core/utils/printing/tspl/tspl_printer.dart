import 'dart:async';
import 'dart:typed_data';

import 'package:flutter_bluetooth_serial_plus/flutter_bluetooth_serial_plus.dart';

import 'package:swms_finish_goods/core/utils/printing/printer.dart';

/// Máy in TSPL (MJ8001...) qua Bluetooth SPP.
///
/// Cùng chiến lược **connect-per-job** và hàng đợi chống double-tap như
/// `SatoPrinter`. Khác biệt duy nhất: TSPL **không có bắt tay** ENQ/ACK —
/// máy nuốt lệnh rồi im lặng. Vì thế sau mỗi nhãn phải chờ [settleDelay]
/// cho máy tiêu hết buffer trước khi gửi tiếp hoặc đóng socket; đóng ngay
/// sau `allSent` thì tem ra cụt hoặc không ra (đã thử thực tế: 800 ms).
///
/// Hệ quả: `printed` trong [PrinterBatchException] nghĩa là "đã đẩy hết
/// xuống socket và chờ đủ settle", KHÔNG phải máy xác nhận. Mất kết nối
/// đúng lúc máy đang in nhãn cuối thì số này có thể lệch 1.
///
/// Dù không dùng dữ liệu vào, VẪN PHẢI listen `conn.input`: plugin đóng
/// `StreamController` của input trong `close()`, mà `close()` của một
/// controller single-subscription CHƯA TỪNG có listener thì không bao giờ
/// hoàn tất ⇒ `_close()` treo ⇒ Future của job không bao giờ xong ⇒ UI
/// loading vĩnh viễn dù tem đã ra giấy. (SatoPrinter không dính vì nó
/// listen sẵn để bắt ACK.)
///
/// ~50 dòng queue/connect/close trùng với `SatoPrinter` — cố ý chưa tách
/// base class để không đụng driver SATO đang chạy. Tách sau khi TSPL ổn.
class TsplPrinter implements Printer {
  TsplPrinter({
    this.connectTimeout = const Duration(seconds: 15),
    this.settleDelay = const Duration(milliseconds: 800),
    this.closeTimeout = const Duration(seconds: 3),
  });

  /// Giới hạn thời gian mở SPP. Không có timeout thì máy in tắt nguồn
  /// sẽ làm Future treo vô hạn và UI đứng im.
  final Duration connectTimeout;

  /// Thời gian chờ sau khi flush mỗi nhãn để máy tiêu buffer.
  final Duration settleDelay;

  /// Giới hạn thời gian đóng socket. Máy đã tắt/ra khỏi tầm thì `close()`
  /// có thể treo — mà lúc này tem đã ra giấy rồi, không được để UI kẹt.
  final Duration closeTimeout;

  BluetoothConnection? _conn;
  StreamSubscription<Uint8List>? _inputSub;
  Future<void>? _inFlight;
  bool _disposed = false;

  @override
  bool get isBusy => _inFlight != null;

  @override
  Future<void> printBytes(PrinterDevice device, List<int> bytes) =>
      printBatch(device, [bytes]);

  @override
  Future<void> printBatch(
      PrinterDevice device,
      List<List<int>> payloads, {
        void Function(int index)? onPrinted,
      }) {
    if (_disposed) {
      throw const PrinterException(
        PrinterErrorType.print,
        message: 'Printer đã dispose',
      );
    }
    if (payloads.isEmpty || payloads.any((p) => p.isEmpty)) {
      throw const PrinterException(
        PrinterErrorType.invalidData,
        message: 'Payload rỗng',
      );
    }

    // Xếp hàng: nút In bị double-tap là chuyện thường, và 2 socket SPP mở
    // song song tới cùng một máy in thì cả hai đều fail.
    late final Future<void> job;
    job = (_inFlight ?? Future<void>.value())
    // Lỗi của job trước không được làm job sau bị huỷ.
        .then<void>((_) {}, onError: (_) {})
        .then((_) => _runBatch(device, payloads, onPrinted))
        .whenComplete(() {
      if (identical(_inFlight, job)) _inFlight = null;
    });
    _inFlight = job;
    return job;
  }

  Future<void> _runBatch(
      PrinterDevice device,
      List<List<int>> payloads,
      void Function(int index)? onPrinted,
      ) async {
    var printed = 0;
    try {
      final conn = await BluetoothConnection.toAddress(
        device.macAddress,
      ).timeout(connectTimeout);
      _conn = conn;
      if (!conn.isConnected) {
        throw const PrinterException(
          PrinterErrorType.connect,
          message: 'Mở được socket nhưng không ở trạng thái connected',
        );
      }

      // Phải có listener — xem doc của class. Byte máy in trả về (nếu có)
      // không dùng tới, chỉ drain cho stream chạy.
      _inputSub = conn.input.listen(
            (_) {},
        onError: (Object _) {},
        cancelOnError: false,
      );

      for (var i = 0; i < payloads.length; i++) {
        await _sendOne(conn, payloads[i]);
        printed++;
        onPrinted?.call(i);
      }
    } on PrinterException catch (e) {
      throw _wrapBatch(e, printed, payloads.length);
    } on TimeoutException catch (e) {
      throw PrinterBatchException(
        printed: printed,
        total: payloads.length,
        type: PrinterErrorType.connect,
        message: 'Hết thời gian kết nối tới ${device.macAddress}',
        cause: e,
      );
    } on Object catch (e) {
      // Mất kết nối giữa chừng, máy tắt nguồn, socket bị OS đóng...
      throw PrinterBatchException(
        printed: printed,
        total: payloads.length,
        type: PrinterErrorType.print,
        cause: e,
      );
    } finally {
      // Luôn đóng — kể cả khi lỗi. Đây là toàn bộ điểm mấu chốt của
      // chiến lược connect-per-job.
      await _close();
    }
  }

  PrinterBatchException _wrapBatch(PrinterException e, int printed, int total) =>
      e is PrinterBatchException
          ? e
          : PrinterBatchException(
        printed: printed,
        total: total,
        type: e.type,
        message: e.message,
        cause: e.cause,
      );

  Future<void> _sendOne(BluetoothConnection conn, List<int> bytes) async {
    if (!conn.isConnected) {
      throw const PrinterException(
        PrinterErrorType.print,
        message: 'Mất kết nối giữa lô in',
      );
    }
    conn.output.add(Uint8List.fromList(bytes));
    // Phải chờ buffer đẩy hết — gửi tiếp khi chưa flush sẽ ra tem thiếu.
    await conn.output.allSent;
    // Không có ACK để chờ — chờ máy tiêu buffer theo thời gian.
    await Future<void>.delayed(settleDelay);
  }

  Future<void> _close() async {
    await _inputSub?.cancel();
    _inputSub = null;
    final conn = _conn;
    _conn = null;
    try {
      await conn?.close().timeout(closeTimeout);
    } catch (_) {
      // Đóng socket đã chết hoặc quá hạn thì bỏ qua — tem đã ra giấy,
      // không có gì để cứu và càng không được để job treo ở đây.
    }
  }

  @override
  Future<void> dispose() async {
    _disposed = true;
    try {
      await _inFlight;
    } catch (_) {
      // Job đang chạy tự lo lỗi của nó.
    }
    await _close();
  }
}