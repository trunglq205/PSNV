import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/extensions/datetime_extensions.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';

/// Số thập phân trong payload tem. Nhận cả dấu chấm lẫn dấu PHẨY thập phân:
/// tem in từ PDA ghi `1.5`, tem in từ web ghi theo culture vi-VN `1,5000`
/// (`double.tryParse('1,5000')` trả null → trước đây weight luôn = 0).
double? _parseDecimal(String? raw) =>
    raw == null ? null : double.tryParse(raw.trim().replaceAll(',', '.'));

class PartCard {
  final String cardId;
  final Category category;
  final String psnvPo;
  final String customerPo;
  final DateTime productionDate;
  final String dimension;
  final double weight;
  final List<PartModel> models;
  final String payload;

  String? get model => models.singleOrNull?.model;

  const PartCard({
    required this.cardId,
    required this.category,
    required this.psnvPo,
    required this.customerPo,
    required this.productionDate,
    required this.dimension,
    required this.weight,
    required this.models,
    required this.payload,
  });

  /// `CATE=` nhận cả tên (key) lẫn mã số (value) — giống bản enum cũ:
  /// thử tên trước, rồi mới tới mã.
  static Category? _resolveCategory(String cate, List<Category> categories) =>
      categories.byKey(cate) ?? categories.byValue(int.tryParse(cate));

  static void validatePayload(
    Map<String, String> map,
    List<Category> categories,
  ) {
    if ((map['ID'] ?? '').trim().isEmpty) {
      throw const InvalidPayloadException();
    }

    final mfd = (map['MFD'] ?? '').trim();
    if (mfd.isEmpty) {
      throw const MissingPayloadFieldException('MFD');
    }
    if (mfd.toDateOrNull() == null) {
      throw InvalidPayloadFieldException(field: 'MFD', value: mfd);
    }

    final cate = (map['CATE'] ?? '').trim();
    if (cate.isEmpty) {
      throw const MissingPayloadFieldException('CATE');
    }

    if (_resolveCategory(cate, categories) == null) {
      throw InvalidPayloadFieldException(field: 'CATE', value: cate);
    }
  }

  /// [categories] = danh mục Cate từ API (`ref.readCategories()`).
  factory PartCard.fromPayload(String payload, List<Category> categories) {
    final Map<String, String> map = {};

    for (final item in payload.split('|')) {
      final index = item.indexOf('=');
      if (index == -1) continue;

      final key = item.substring(0, index);
      final value = item.substring(index + 1);

      map[key] = value;
    }

    validatePayload(map, categories);

    final mfd = map['MFD'];
    final models = (map['MODELS'] ?? '')
        .split(';')
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty)
        .map(PartModel.fromString)
        .toList();

    // validatePayload đã đảm bảo tra được.
    final category = _resolveCategory(map['CATE']!.trim(), categories)!;

    return PartCard(
      cardId: map['ID']!,
      category: category,
      psnvPo: map['PSNV_PO'] ?? '',
      customerPo: map['CUS_PO'] ?? '',
      productionDate: mfd.toDateOrNull() ?? DateTime.now(),
      dimension: map['DIM'] ?? '',
      weight: _parseDecimal(map['WT']) ?? 0.0,
      models: models,
      payload: payload,
    );
  }

  @override
  bool operator ==(Object other) =>
      identical(this, other) ||
      other is PartCard &&
          runtimeType == other.runtimeType &&
          cardId == other.cardId;

  @override
  int get hashCode => cardId.hashCode;

  @override
  String toString() {
    return 'PartCard(cardId: $cardId, cate: $category, psnvPo: $psnvPo, customerPo: $customerPo, productionDate: $productionDate, dimension: $dimension, weight: $weight, models: $models)';
  }
}

class PartModel {
  final String model;
  final int quantity;
  final String country;
  final int cartonQty;
  final String dimension;
  final double weight;

  const PartModel({
    required this.model,
    required this.quantity,
    required this.country,
    required this.cartonQty,
    required this.dimension,
    required this.weight,
  });

  factory PartModel.fromString(String value) {
    final parts = value.split(',');

    return PartModel(
      model: parts.isNotEmpty ? parts[0] : '',
      quantity: parts.length > 1 ? int.tryParse(parts[1]) ?? 0 : 0,
      country: parts.length > 2 ? parts[2] : '',
      cartonQty: parts.length > 3 ? int.tryParse(parts[3]) ?? 0 : 0,
      dimension: parts.length > 4 ? parts[4] : '',
      weight: parts.length > 5 ? _parseDecimal(parts[5]) ?? 0 : 0,
    );
  }

  @override
  String toString() {
    return 'PartModel(model: $model, quantity: $quantity, country: $country, cartonQty: $cartonQty, dimension: $dimension, weight: $weight)';
  }
}
