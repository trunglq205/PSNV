using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.Balance.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.Balance.Api;

[ApiController]
[Route("api/balance")]
public class BalanceController : ControllerBase
{
    private readonly IBalanceService _service;
    public BalanceController(IBalanceService service) => _service = service;

    /// <summary>Danh sách phiếu cân bằng (lọc theo trạng thái: pending | processing | issued).</summary>
    [HttpGet("docs")]
    [RequirePermission<Perms.Storage.Balance.View>]
    public async Task<ActionResult<IReadOnlyList<BalanceDocSummaryResponse>>> GetDocs([FromQuery] string? status)
        => Ok(await _service.GetDocsAsync(status));

    /// <summary>Chi tiết 1 phiếu cân bằng: header + các dòng lệch.</summary>
    [HttpGet("docs/{id:long}")]
    [RequirePermission<Perms.Storage.Balance.View>]
    public async Task<ActionResult<BalanceDocDetailResponse>> GetDoc(long id)
        => Ok(await _service.GetDocAsync(id));

    /// <summary>Chọn hướng xử lý cho 1 dòng: 'count' (tin PDA) | 'system' (giữ hệ thống).</summary>
    [HttpPost("docs/{docId:long}/lines/{lineId:long}/resolution")]
    [RequirePermission<Perms.Storage.Balance.Approve>]
    public async Task<IActionResult> SetLine(long docId, long lineId, [FromBody] SetResolutionRequest req)
    { await _service.SetLineResolutionAsync(docId, lineId, req); return NoContent(); }

    /// <summary>Chọn hướng cho nhiều dòng cùng lúc.</summary>
    [HttpPost("docs/{docId:long}/lines/resolution")]
    [RequirePermission<Perms.Storage.Balance.Approve>]
    public async Task<IActionResult> SetLines(long docId, [FromBody] BulkResolutionRequest req)
    { await _service.SetLinesResolutionAsync(docId, req); return NoContent(); }

    /// <summary>Issue FA & đóng phiếu: cập nhật tồn, sinh bút toán, đóng CB, sinh mã FA.</summary>
    [HttpPost("docs/{id:long}/issue-fa")]
    [RequirePermission<Perms.Storage.Balance.Approve>]
    public async Task<ActionResult<IssueFaResultResponse>> IssueFa(long id)
        => Ok(await _service.IssueFaAsync(id));
}
