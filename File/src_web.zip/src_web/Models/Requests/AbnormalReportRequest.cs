﻿namespace SWMS_WebTool.Models.Requests
{
    /// <summary>
    /// Tạo / cập nhật báo cáo từ MCS
    /// </summary>
    public class AbnormalReportRequestVM
    {
        public Guid? Id { get; set; }
        public DateTime DiscoveryDate { get; set; }
        public DateTime? ReceivingDate { get; set; }

        // Product info
        public string? PartNumber { get; set; }
        public string? PartName { get; set; }
        public string? VendorCode { get; set; }
        public string? IssuingSLOC { get; set; }
        public string? ReceivingSLOC { get; set; }
        public string? InvoiceNumber { get; set; }
        public int InvoiceQuantity { get; set; }
        public int AbnormalQuantity { get; set; }   // âm = thiếu, dương = thừa
        public string? Supplier { get; set; }
        public string? ShippingCompany { get; set; }
        public string? DiscoveryLocation { get; set; }
        public string? DiscoveredBy { get; set; }

        // Problem type
        public bool ProblemTypeA { get; set; }
        public bool ProblemTypeB { get; set; }
        public bool ProblemTypeC { get; set; }
        public string? ProblemDescriptionA { get; set; }
        public string? ProblemDescriptionB { get; set; }
        public string? ProblemDescriptionC { get; set; }

        // MCS
        public bool RequiresIQC { get; set; }
        public SupplierType SupplierType { get; set; }

        // Ảnh đính kèm
        public List<ImageUploadItem>? Images { get; set; }
    }

    public class ImageUploadItem
    {
        public IFormFile? File { get; set; }
        public string? Comment { get; set; }
    }

    public class AbnormalReportImageUploadRequest
    {
        public Guid ReportId { get; set; }
        public string FileData { get; set; } = string.Empty;  // Base64 string
        public string FileName { get; set; } = string.Empty;  // Tên gốc
        public string MimeType { get; set; } = "image/jpeg";  // image/jpeg, image/png...
        public string? Comment { get; set; }
    }

    /// <summary>
    /// Response sau khi tạo report — trả về ReportId để upload ảnh tiếp
    /// </summary>
    public class CreateReportResponse
    {
        public int Result { get; set; }
        public Guid? ReportId { get; set; }
    }

    /// <summary>
    /// IQC xác nhận kết quả kiểm tra
    /// </summary>
    public class IQCConfirmRequestVM
    {
        public Guid ReportId { get; set; }

        /// <summary>1 = OK, 2 = NG</summary>
        public byte IQCResult { get; set; }

        public string? IQCNote { get; set; }
    }

    /// <summary>
    /// PUS xác nhận hành động xử lý
    /// </summary>
    public class PUSConfirmRequestVM
    {
        public Guid ReportId { get; set; }

        /// <summary>1 = ReportOnly, 2 = MaterialMovementSlip</summary>
        public byte PUSAction { get; set; }

        public string? PUSNote { get; set; }
    }

    /// <summary>
    /// MCS xác nhận kết thúc → ReportStatus 1 → 2
    /// </summary>
    public class MCSConfirmRequestVM
    {
        public Guid ReportId { get; set; }
        public string? MCSNote { get; set; }
    }

    public class ApproveRequestVM
    {
        public Guid ReportId { get; set; }
        public string? LeaderNote { get; set; }
    }

    public class RequestUpdateVM
    {
        public Guid ReportId { get; set; }
        public string? LeaderNote { get; set; }
    }

}
