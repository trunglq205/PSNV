using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Microsoft.JSInterop;
using Swms.FinishGoods.Web.Features.Stocktake.Business;
using Swms.FinishGoods.Web.Features.Stocktake.Business.Models;
using Swms.FinishGoods.Web.Features.Stocktake.Client;
using Swms.FinishGoods.Web.Features.WarehouseAreas.Business;
using Swms.FinishGoods.Web.Features.WarehouseAreas.Business.Models;
using Swms.FinishGoods.Web.Resources;

namespace Swms.FinishGoods.Web.Features.Stocktake.App.Pages;

public partial class Kiemke
{
    [Inject] private IStocktakeBusiness Business { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private IJSRuntime JS { get; set; } = default!;
    [Inject] private IWarehouseAreasBusiness AreasBusiness { get; set; } = default!;

    private string? _error;   // thêm mới — hiện lỗi lên UI thay vì im lặng

    private List<CountSummaryDto> _all = new();
    private List<CountSummaryDto> _rows = new();
    private List<CountSummaryDto> _active = new();
    private List<CountSummaryDto> _closed = new();
    private bool _loading = true;

    private string _tab = "morning";
    private DateTime? _fDate;
    private string _fStatus = string.Empty;

    // chi tiết
    private CountSummaryDto? _sel;
    private CountDetailDto? _detail;
    private bool _detailLoading;
    private int _total, _counted, _match, _disc;

    // tạo phiếu
    private bool _showCreate;
    // Chỉ tạo phiếu cuối tháng; phiếu buổi sáng do hệ thống tự sinh theo biến động hôm qua.
    private const string CreateType = "monthly";

    /// <summary>Các bản đồ được tích khi tạo phiếu; rỗng = mọi bản đồ lưu kho.</summary>
    private readonly HashSet<string> _newAreas = new(StringComparer.OrdinalIgnoreCase);
    private List<WarehouseAreaSummaryDto> _areas = [];
    private string? _newDesc;
    private CountPreviewDto? _preview;
    private bool _busy;

    protected override async Task OnInitializedAsync() => await Load();

    private async Task Load()
    {
        _loading = true; _error = null; StateHasChanged();

        var r = await Business.GetCountsAsync();
        if (r.IsSuccess && r.Value is not null)
        {
            _all = r.Value;
            ApplyFilter();
        }
        else
        {
            _error = r.ErrorMessage ?? L["Stocktake.Load.Failed"];
        }

        _loading = false; StateHasChanged();
    }

    private void SetTab(string t) { _tab = t; ApplyFilter(); }

    private void ApplyFilter()
    {
        IEnumerable<CountSummaryDto> q = _all.Where(c => c.CountType == _tab);
        if (_fDate is not null) q = q.Where(c => c.CountDate.Date == _fDate.Value.Date);
        if (!string.IsNullOrEmpty(_fStatus)) q = q.Where(c => c.DocStatus == _fStatus);
        _rows = q.OrderByDescending(c => c.Id).ToList();
        _active = _rows.Where(c => c.DocStatus is "pending" or "counting").ToList();
        _closed = _rows.Where(c => c.DocStatus is "closed").ToList();
        // giữ lựa chọn nếu vẫn còn, ngược lại chọn phần tử đầu
        if (_sel is not null && _rows.All(c => c.Id != _sel.Id)) { _sel = null; _detail = null; }
    }

    private void ClearFilter() { _fDate = null; _fStatus = string.Empty; ApplyFilter(); }

    private async Task Select(CountSummaryDto c)
    {
        _sel = c;
        _detailLoading = true; _detail = null; StateHasChanged();

        var r = await Business.GetCountAsync(c.Id);
        if (r.IsSuccess && r.Value is not null)
        {
            _detail = r.Value;
            _total = _detail.Lines.Count;
            _counted = _detail.Lines.Count(l => l.QtyCount != null);
            _match = _detail.Lines.Count(l => l.QtyCount != null && l.QtyCount.Value == l.QtySystem);
            _disc = _detail.Lines.Count(l => l.QtyCount != null && l.QtyCount.Value != l.QtySystem);
        }
        else
        {
            _error = r.ErrorMessage ?? L["Stocktake.Detail.Failed"];
            _total = _counted = _match = _disc = 0;
        }

        _detailLoading = false; StateHasChanged();
    }

    private int Pct => _total == 0 ? 0 : (int)Math.Round(100.0 * _counted / _total);
    private static int CardPct(CountSummaryDto c) => c.TotalLines == 0 ? 0 : (int)Math.Round(100.0 * c.CountedLines / c.TotalLines);

    /// <summary>Dòng đã đếm và số thực tế khác số hệ thống — mới cần giải trình.</summary>
    private static bool HasDiscrepancy(CountLineDto l)
        => l.QtyCount is not null && l.QtyCount.Value != l.QtySystem;

    /// <summary>
    /// Số dòng hiển thị của ô ghi chú, ước theo độ dài nội dung (khoảng 26 ký tự/dòng).
    /// Trong lúc gõ thì CSS field-sizing lo việc giãn thêm.
    /// </summary>
    private static int NoteRows(string? note)
    {
        if (string.IsNullOrEmpty(note)) return 1;
        var lines = note.Split('\n').Length;
        var wrapped = (int)Math.Ceiling(note.Length / 26.0);
        return Math.Clamp(Math.Max(lines, wrapped), 1, 5);
    }

    /// <summary>Dòng vừa lưu ghi chú xong — để nháy xanh một nhịp.</summary>
    private long? _noteSaved;

    /// <summary>Phiếu đã đóng hoặc huỷ thì không cho sửa ghi chú.</summary>
    private bool NoteLocked => _detail?.Header.DocStatus is "closed" or "cancelled";

    /// <summary>Lưu ghi chú khi rời ô nhập; không đụng số đếm.</summary>
    private async Task SaveNote(CountLineDto line, string? value)
    {
        var note = string.IsNullOrWhiteSpace(value) ? null : value.Trim();
        if (note == line.Note) return;

        var r = await Business.SetNoteAsync(line.Id, note);
        if (!r.IsSuccess) return;

        line.Note = note;          // cập nhật tại chỗ, khỏi tải lại cả phiếu
        _noteSaved = line.Id;
        StateHasChanged();

        await Task.Delay(900);
        _noteSaved = null;
    }

    /// <summary>Lọc danh sách theo ô KPI đang chọn: all | counted | match | disc.</summary>
    private string _lineFilter = "all";

    private void SetLineFilter(string key) =>
        _lineFilter = _lineFilter == key ? "all" : key;   // bấm lại ô đang chọn = bỏ lọc

    /// <summary>
    /// Phiếu SÁNG: mặc định chỉ hiện pallet đã có biến động vị trí.
    ///
    /// Phiếu sáng chọn phạm vi theo Ô chứ không theo pallet, nên một ô 5 pallet
    /// mà chỉ 1 cái vừa chuyển vào vẫn ra đủ 5 dòng. Người đọc báo cáo cần biết
    /// cái nào đã động — phần còn lại là nền, bật lên khi cần đối chiếu.
    /// </summary>
    private bool _movedOnly = true;

    private bool IsMorning => _detail?.Header.CountType == "morning";

    /// <summary>Lọc "chỉ pallet có biến động" chỉ có nghĩa với phiếu sáng.</summary>
    private bool MovedFilterOn => IsMorning && _movedOnly;

    private void ToggleMovedOnly() => _movedOnly = !_movedOnly;

    private IEnumerable<CountLineDto> FilteredLines()
    {
        IEnumerable<CountLineDto> lines = _detail?.Lines ?? new List<CountLineDto>();

        // Giữ lại cả dòng ĐÃ ĐẾM và pallet PHÁT SINH dù không có biến động:
        // ẩn một dòng người ta vừa nhập số vào là mất dấu công đã làm, còn
        // pallet phát sinh thì bản thân nó đã là bất thường cần nhìn thấy.
        if (MovedFilterOn)
            lines = lines.Where(l => l.IsMoved || l.IsFound || l.QtyCount is not null);

        return _lineFilter switch
        {
            "counted" => lines.Where(l => l.QtyCount is not null),
            "match" => lines.Where(l => l.QtyCount is not null && l.QtyCount.Value == l.QtySystem),
            "disc" => lines.Where(l => l.QtyCount is not null && l.QtyCount.Value != l.QtySystem),
            _ => lines
        };
    }

    /// <summary>Số dòng bị lọc "chỉ biến động" giấu đi — để nút nói rõ còn bao nhiêu.</summary>
    private int HiddenByMovedFilter
    {
        get
        {
            if (!MovedFilterOn) return 0;
            var all = _detail?.Lines ?? new List<CountLineDto>();
            return all.Count(l => !(l.IsMoved || l.IsFound || l.QtyCount is not null));
        }
    }

    private int FilteredCount => FilteredLines().Count();

    private IEnumerable<IGrouping<string, CountLineDto>> Grouped()
        => FilteredLines()
            .GroupBy(l => Rack(l.LocatorCode))
            .OrderBy(g => g.Key);

    private static string Rack(string code)
    {
        var i = code.IndexOf('-');
        return i > 0 ? code[..i] : code;
    }

    private (string Label, string Cls, string? Note) LineState(CountLineDto l)
    {
        if (l.QtyCount is null) return (L["Stocktake.LineWait"], "dim", null);
        var d = l.QtyCount.Value - l.QtySystem;
        if (d == 0) return ("OK", "success", null);
        var note = d < 0
            ? string.Format(L["Stocktake.NoteShort"], Qty(-d))
            : string.Format(L["Stocktake.NoteOver"], Qty(d));
        return (L["Stocktake.LineDiff"], "warning", note);
    }

    private static string Qty(int v) => v.ToString(System.Globalization.CultureInfo.InvariantCulture);
    private static string Qty(int? v) => v is null ? "—" : Qty(v.Value);

    private string Title(CountSummaryDto c)
        => !string.IsNullOrWhiteSpace(c.Description)
            ? c.Description!
            : $"{L["Stocktake.CountWord"]} {TypeLabel(c.CountType).ToLowerInvariant()} {c.CountDate:dd/MM/yyyy}";

    private async Task ExportReport()
    {
        if (_sel is null) return;
        _busy = true; _error = null; StateHasChanged();

        var r = await Business.DownloadReportAsync(_sel.Id);
        if (r.IsSuccess && r.Value is not null)
        {
            await JS.InvokeVoidAsync("swmsSaveFile", $"{_sel.DocNo}.xlsx",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                Convert.ToBase64String(r.Value));
        }
        else
        {
            _error = r.ErrorMessage ?? L["Stocktake.Export.Failed"];
        }

        _busy = false; StateHasChanged();
    }

    // ===== tạo phiếu =====
    private async Task OpenCreate()
    {
        _showCreate = true;
        _newAreas.Clear();
        _newDesc = null;
        _preview = null;
        if (_areas.Count == 0)
        {
            try { _areas = await AreasBusiness.ListAsync("storing"); }
            catch { _areas = []; }   // không lấy được danh sách thì vẫn tạo được phiếu "mọi bản đồ"
        }
    }
    private void CloseCreate() => _showCreate = false;
    /// <summary>Đã tích hết, hoặc chưa tích cái nào — cả hai đều nghĩa là "tất cả".</summary>
    private bool AllMapsPicked => _newAreas.Count == 0 || _newAreas.Count == _areas.Count;

    private void ToggleAllMaps(ChangeEventArgs e)
    {
        _newAreas.Clear();                 // rỗng = tất cả
        _preview = null;
    }

    private void ToggleMap(string code, ChangeEventArgs e)
    {
        var on = e.Value is bool b && b;
        // Đang ở trạng thái "tất cả" mà bỏ tích 1 bản đồ -> chuyển thành tích những cái còn lại
        if (!on && _newAreas.Count == 0)
        {
            foreach (var a in _areas) _newAreas.Add(a.AreaCode);
        }

        if (on) _newAreas.Add(code); else _newAreas.Remove(code);

        if (_newAreas.Count == _areas.Count) _newAreas.Clear();   // tích hết = tất cả
        _preview = null;
    }

    /// <summary>Danh sách gửi lên API; rỗng = mọi bản đồ lưu kho.</summary>
    private string[]? PickedAreas() => _newAreas.Count == 0 ? null : _newAreas.ToArray();

    private async Task DoPreview()
    {
        _busy = true; _error = null; StateHasChanged();

        var r = await Business.PreviewAsync(CreateType, PickedAreas());
        if (r.IsSuccess) _preview = r.Value;
        else _error = r.ErrorMessage ?? L["Stocktake.Preview.Failed"];

        _busy = false; StateHasChanged();
    }

    private async Task DoCreate()
    {
        if (_preview is null || _preview.LineCount == 0) return;
        _busy = true; _error = null; StateHasChanged();

        var r = await Business.CreateAsync(new CreateCountRequestDto
        {
            CountType = CreateType,
            Description = _newDesc,
            AreaCodes = PickedAreas()?.ToList(),
        });
        if (r.IsSuccess && r.Value is not null)
        {
            _showCreate = false;
            _tab = CreateType;
            _busy = false;              // nhả busy trước vì Load/Select tự StateHasChanged
            await Load();
            var created = _all.FirstOrDefault(c => c.Id == r.Value.Id);
            if (created is not null) await Select(created);
            return;
        }

        _error = r.ErrorMessage ?? L["Stocktake.Create.Failed"];
        _busy = false; StateHasChanged();
    }

    // ===== nhãn =====
    private string TypeLabel(string? t) => t switch
    {
        "morning" => L["Stocktake.TypeMorning"],
        "monthly" => L["Stocktake.TypeMonthly"],
        "shipment" => L["Stocktake.TypeShipment"],
        _ => t ?? string.Empty
    };

    private string StatusLabel(string s) => s switch
    {
        "pending" => L["Stocktake.StatusPending"],
        "counting" => L["Stocktake.StatusCounting"],
        "closed" => L["Stocktake.StatusClosed"],
        _ => s
    };

    private static string StatusClass(string s) => s switch
    {
        "pending" => "dim",
        "counting" => "warning",
        "closed" => "success",
        _ => "dim"
    };
}
