import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_timeline.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_event.dart';
import 'package:swms_finish_goods/shared/domain/entities/stock_event.dart';

/// Lịch sử thùng — bọc [AppTimeline] và lo phần nghiệp vụ.
///
/// Điểm khác lịch sử pallet: mỗi mốc có cờ [BoxEvent.inherited].
///   false — thao tác trên chính thùng này
///   true  — kế thừa từ pallet chứa nó (thùng không tự đi lưu kho)
///
/// Hai mức được vẽ khác nhau (`muted`) và có công tắc lọc. Nếu trộn phẳng,
/// người dùng sẽ tưởng có ai quét riêng từng thùng.
class BoxHistoryTimeline extends StatelessWidget {
  final List<BoxEvent> events;

  /// Đang chỉ hiện thao tác trên chính thùng.
  final bool ownOnly;

  /// Bật/tắt bộ lọc. Gọi lại API vì việc lọc nằm ở server.
  final ValueChanged<bool> onOwnOnlyChanged;

  /// Đang tải lại sau khi đổi bộ lọc — khoá công tắc để tránh bấm dồn.
  final bool loading;

  const BoxHistoryTimeline({
    super.key,
    required this.events,
    required this.ownOnly,
    required this.onOwnOnlyChanged,
    this.loading = false,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  'box_detail.history'.tr(),
                  style: AppTextStyles.label.copyWith(color: swms.text3),
                ),
              ),
              // Công tắc đặt ngay cạnh tiêu đề: người dùng thấy ngay là timeline
              // đang hiện gì, không phải cuộn xuống tìm.
              _OwnOnlyToggle(
                value: ownOnly,
                onChanged: loading ? null : onOwnOnlyChanged,
              ),
            ],
          ),
          const SizedBox(height: AppDimens.md),
          if (events.isEmpty)
            Text(
              ownOnly
                  ? 'box_detail.no_own_history'.tr()
                  : 'box_detail.no_history'.tr(),
              style: AppTextStyles.body.copyWith(color: swms.text3),
            )
          else
            AppTimeline(items: events.map((e) => _toItem(context, e)).toList()),
        ],
      ),
    );
  }

  AppTimelineItem _toItem(BuildContext context, BoxEvent e) => AppTimelineItem(
    // Mã event -> chuỗi i18n theo quy ước "stock_event.<CODE>".
    // Thiếu key thì easy_localization trả về chính key, timeline vẫn đọc được.
    title: e.labelKey.tr(),
    code: e.place?.display,
    description: _description(e),
    meta: _meta(e),
    tone: _tone(e.tone),
    muted: e.inherited,
  );

  /// Dòng mô tả — ghép những gì thực sự có, bỏ qua phần rỗng.
  static String? _description(BoxEvent e) {
    final parts = <String>[];

    // Chỉ hiện đường đi khi có CẢ nguồn lẫn đích; một chiều thì `code` cạnh
    // tiêu đề đã nói đủ.
    if (e.hasMovePath) {
      parts.add('${e.fromLocator!.display} → ${e.toLocator!.display}');
    }

    // Với event kế thừa, pallet nào mới là thông tin đáng giá: thùng từng nằm
    // trên pallet khác sau mỗi lần tách.
    if (e.inherited && (e.palletCode?.isNotEmpty ?? false)) {
      parts.add('box_detail.on_pallet'.tr(args: [e.palletCode!]));
    }

    if (e.refNo?.isNotEmpty ?? false) parts.add(e.refNo!);
    if (e.note?.isNotEmpty ?? false) parts.add(e.note!);

    return parts.isEmpty ? null : parts.join('\n');
  }

  static AppTimelineTone _tone(StockEventTone tone) => switch (tone) {
    StockEventTone.success => AppTimelineTone.success,
    StockEventTone.warning => AppTimelineTone.warning,
    StockEventTone.danger => AppTimelineTone.danger,
    StockEventTone.neutral => AppTimelineTone.neutral,
  };

  /// "14:37 15/09/2026 · Trần Đình Đức"
  static String _meta(BoxEvent e) {
    final d = e.eventAt;
    String two(int v) => v.toString().padLeft(2, '0');
    final time =
        '${two(d.hour)}:${two(d.minute)} ${two(d.day)}/${two(d.month)}/${d.year}';

    final actor = e.actor?.trim() ?? '';
    return actor.isEmpty ? time : '$time · $actor';
  }
}

/// Công tắc "chỉ thao tác trên thùng này". Dạng chip cho vừa mật độ PDA —
/// `AppSwitch` (44×26) quá to để nằm cạnh một dòng nhãn 12px.
class _OwnOnlyToggle extends StatelessWidget {
  final bool value;
  final ValueChanged<bool>? onChanged;

  const _OwnOnlyToggle({required this.value, required this.onChanged});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final enabled = onChanged != null;

    return Opacity(
      opacity: enabled ? 1 : 0.5,
      child: InkWell(
        onTap: enabled ? () => onChanged!(!value) : null,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          decoration: BoxDecoration(
            color: value ? swms.primaryTint : Colors.transparent,
            border: Border.all(color: value ? swms.primary : swms.border2),
            borderRadius: BorderRadius.circular(AppDimens.rInput),
          ),
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(
                value ? Icons.filter_alt : Icons.filter_alt_outlined,
                size: 14,
                color: value ? swms.primary : swms.text3,
              ),
              const SizedBox(width: 5),
              Text(
                'box_detail.own_only'.tr(),
                style: AppTextStyles.caption.copyWith(
                  color: value ? swms.primary : swms.text3,
                  fontWeight: FontWeight.w700,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}