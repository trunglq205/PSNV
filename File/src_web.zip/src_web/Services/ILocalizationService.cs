﻿namespace SWMS_WebTool.Services
{
    public interface ILocalizationService
    {
        string Get(string key);
        string Get(string key, params object[] args);
        string CurrentLanguage { get; }
    }
}