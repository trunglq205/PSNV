import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_timeline.dart';
import 'package:swms_finish_goods/shared/domain/entities/stock_event.dart';

/// Lịch sử pallet — bọc [AppTimeline] và lo phần nghiệp vụ: dịch mã event,
/// đổi sắc thái, format thời gian.
///
/// Dữ liệu là bản RÚT GỌN (10 mốc gần nhất, 4 trường) kèm theo khi quét —
/// xem [PalletEvent]. Không có from→to, số thùng hay ghi chú; muốn đầy đủ thì
/// phải gọi `GET /api/pallets/{id}/history`.
class PalletHistoryTimeline extends StatelessWidget {
  final List<PalletEvent> history;

  const PalletHistoryTimeline({super.key, required this.history});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    if (history.isEmpty) {
      return AppCard(
        child: Text(
          LocaleKeys.pallet_detail_no_history.tr(),
          style: AppTextStyles.body.copyWith(color: swms.text3),
        ),
      );
    }

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.pallet_detail_history.tr(),
            style: AppTextStyles.label.copyWith(color: swms.text3),
          ),
          const SizedBox(height: AppDimens.md),
          AppTimeline(items: history.map(_toItem).toList()),
        ],
      ),
    );
  }

  AppTimelineItem _toItem(PalletEvent e) => AppTimelineItem(
    // Mã event -> chuỗi i18n theo quy ước "stock_event.<CODE>".
    // Thiếu key thì easy_localization trả về chính key, timeline vẫn đọc được.
    title: e.labelKey.tr(),
    code: e.toLocatorCode,
    meta: _meta(e),
    tone: _tone(e.tone),
  );

  static AppTimelineTone _tone(StockEventTone tone) => switch (tone) {
    StockEventTone.success => AppTimelineTone.success,
    StockEventTone.warning => AppTimelineTone.warning,
    StockEventTone.danger => AppTimelineTone.danger,
    StockEventTone.neutral => AppTimelineTone.neutral,
  };

  /// "14:37 15/09/2026 · Trần Đình Đức"
  static String _meta(PalletEvent e) {
    final d = e.eventAt;
    String two(int v) => v.toString().padLeft(2, '0');
    final time =
        '${two(d.hour)}:${two(d.minute)} ${two(d.day)}/${two(d.month)}/${d.year}';

    final actor = e.actor?.trim() ?? '';
    return actor.isEmpty ? time : '$time · $actor';
  }
}