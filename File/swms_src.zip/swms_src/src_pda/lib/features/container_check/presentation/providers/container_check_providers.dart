import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/container_check/data/container_check_repository_impl.dart';
import 'package:swms_finish_goods/features/container_check/data/datasources/container_check_remote_data_source.dart';
import 'package:swms_finish_goods/features/container_check/domain/repositories/container_check_repository.dart';

part 'container_check_providers.g.dart';

@riverpod
ContainerCheckRemoteDataSource containerCheckRemoteDataSource(Ref ref) =>
    ContainerCheckRemoteDataSource(ref.watch(dioProvider));

@riverpod
ContainerCheckRepository containerCheckRepository(Ref ref) =>
    ContainerCheckRepositoryImpl(ref.watch(containerCheckRemoteDataSourceProvider));
