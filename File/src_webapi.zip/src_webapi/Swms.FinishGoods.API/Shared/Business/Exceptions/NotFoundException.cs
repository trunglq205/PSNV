namespace Swms.FinishGoods.API.Common.Business.Exceptions;

public class NotFoundException : Exception
{
    public NotFoundException(string message) : base(message) { }
}
