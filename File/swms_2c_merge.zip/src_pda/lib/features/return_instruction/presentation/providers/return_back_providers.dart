import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/return_instruction/data/return_back_repository.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Provider của mục 2c — khai THỦ CÔNG, không dùng @riverpod.
//
//  Cùng lý do đã ghi ở return_back_model.dart: bộ mục 2c làm sao để không cần
//  chạy build_runner. @riverpod sinh `.g.dart`, provider thủ công thì không.
//  Đây là cách `errorHandlerProvider` và `pdaProvider` trong core vẫn đang
//  dùng, nên không phải lối đi lạ trong source này.
//
//  KHÔNG còn provider danh sách đề nghị: sau khi gộp thì mỗi phiếu có đúng một
//  luồng back, và trạng thái của nó đã nằm trong dữ liệu phiếu
//  (`returnInstructionListProvider`) rồi — một provider nữa chỉ là một lượt gọi
//  API lặp lại cùng con số.
// ─────────────────────────────────────────────────────────────

final returnBackRepositoryProvider = Provider<ReturnBackRepository>(
  (ref) => ReturnBackRepository(ref.watch(dioProvider)),
);

/// SL còn ở kho theo model của một phiếu.
///
/// `docId` là tham số family nên phải so sánh được bằng `==` — int thì được.
final backRemainProvider =
    FutureProvider.family<List<BackRemainModel>, int>((ref, docId) =>
        ref.watch(returnBackRepositoryProvider).fetchRemain(docId));

/// Nhật ký pallet đã giao của một phiếu.
final backDeliveriesProvider =
    FutureProvider.family<List<BackDelivery>, int>((ref, docId) =>
        ref.watch(returnBackRepositoryProvider).fetchDeliveries(docId));
