﻿namespace SWMS_WebTool.Models
{
    public class DeletePlanNotYetGR
    {
        public string? Date {  get; set; }
        public string? PlanOrder {  get; set; }
        public string? Plant {  get; set; }
        public string? Material {  get; set; }
        public string? Sloc {  get; set; }
    }
}
