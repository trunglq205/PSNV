import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_confirm_body.dart';

/// Bước setup màn Tách.
///
/// ```
/// ┌ TEM NGUỒN 🔒 C123 · MODEL ········ 300 pcs ┐
/// │ ✓ Còn lại: 0            Thùng 3/3          │
/// └────────────────────────────────────────────┘
/// (Tem 1 · 200) (Tem 2 · 100) (+)          [🗑]
/// ┌ form đầy đủ của tem đang chọn ─────────────┐
/// │ PartCardConfirmBody (PO, Cate, MFD, Dim,   │
/// │ Weight, Box, Qty, Origin, OQC)             │
/// └────────────────────────────────────────────┘
/// ```
///
/// Mỗi tem con là 1 phiếu đầy đủ, sửa tự do như in mới. Ràng buộc chéo DUY
/// NHẤT: tổng Qty = tem nguồn — thanh "Còn lại" báo, nút Xác nhận chặn.
///
/// Controlled — dữ liệu ở notifier; widget chỉ giữ tem đang chọn.
class PartCardSplitBody extends StatefulWidget {
  const PartCardSplitBody({
    super.key,
    required this.source,
    required this.cardId,
    required this.parts,
    required this.remaining,
    required this.onPartChanged,
    required this.onAdd,
    required this.onRemove,
    this.maxParts = 99,
  });

  /// Phiếu NGUỒN (chỉ đọc).
  final PartCardForm source;
  final String cardId;

  /// Tem con — phiếu đầy đủ.
  final List<PartCardForm> parts;

  /// Pcs chưa chia (âm = chia vượt).
  final int remaining;

  final void Function(int index, PartCardForm part) onPartChanged;
  final VoidCallback onAdd;
  final ValueChanged<int> onRemove;

  /// Phải khớp `PartCardActionNotifier.maxSplitParts`.
  final int maxParts;

  @override
  State<PartCardSplitBody> createState() => _PartCardSplitBodyState();
}

class _PartCardSplitBodyState extends State<PartCardSplitBody> {
  int _selected = 0;

  @override
  void didUpdateWidget(PartCardSplitBody oldWidget) {
    super.didUpdateWidget(oldWidget);
    final n = widget.parts.length;
    if (n > oldWidget.parts.length) {
      // Vừa thêm → mở luôn tem mới để nhập.
      _selected = n - 1;
    } else if (_selected >= n) {
      _selected = n - 1;
    }
  }

  @override
  Widget build(BuildContext context) {
    final parts = widget.parts;
    if (parts.isEmpty) return const SizedBox.shrink();

    final i = _selected.clamp(0, parts.length - 1);
    final boxTotal = parts.fold(0, (sum, p) => sum + p.totalBox);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        _SplitHeader(
          source: widget.source,
          cardId: widget.cardId,
          remaining: widget.remaining,
          boxTotal: boxTotal,
        ),
        const SizedBox(height: AppDimens.sm),
        _PartTabs(
          parts: parts,
          selected: i,
          onSelect: (j) => setState(() => _selected = j),
          onAdd: parts.length < widget.maxParts ? widget.onAdd : null,
          onRemove: parts.length > 2 ? () => widget.onRemove(i) : null,
        ),
        const SizedBox(height: AppDimens.sm),
        Expanded(
          child: PartCardConfirmBody(
            // Đổi tem → cuộn về đầu form.
            key: ValueKey('split-part-$i'),
            form: parts[i],
            mode: PartCardMode.multi,
            onChanged: (f) => widget.onPartChanged(i, f),
            // Tem con chỉ 1 mã của tem nguồn → không thêm mã.
          ),
        ),
      ],
    );
  }
}

/// Tem nguồn (gọn 1 dòng) + thanh "Còn lại".
class _SplitHeader extends StatelessWidget {
  const _SplitHeader({
    required this.source,
    required this.cardId,
    required this.remaining,
    required this.boxTotal,
  });

  final PartCardForm source;
  final String cardId;
  final int remaining;
  final int boxTotal;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final ok = remaining == 0;
    final color = ok ? swms.success : swms.danger;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 8, 12, 8),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            spacing: 6,
            children: [
              Icon(Icons.lock_outline, size: 11, color: swms.text4),
              Text(
                LocaleKeys.part_card_split_source.tr().toUpperCase(),
                style: AppTextStyles.caption.copyWith(
                  fontSize: 10,
                  fontWeight: FontWeight.w700,
                  letterSpacing: .3,
                  color: swms.text3,
                ),
              ),
              Text(
                cardId,
                style: AppTextStyles.code.copyWith(
                  fontSize: 11,
                  fontWeight: FontWeight.w700,
                  color: swms.text2,
                ),
              ),
              Expanded(
                child: Text(
                  source.model,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 11.5,
                    fontWeight: FontWeight.w800,
                    color: swms.text1,
                  ),
                ),
              ),
              Text(
                '${source.totalPcs} pcs',
                style: AppTextStyles.code.copyWith(
                  fontSize: 11.5,
                  fontWeight: FontWeight.w800,
                  color: swms.text1,
                ),
              ),
            ],
          ),
          const SizedBox(height: 6),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: color.withValues(alpha: .08),
              borderRadius: BorderRadius.circular(AppDimens.rInput),
              border: Border.all(color: color.withValues(alpha: .35)),
            ),
            child: Row(
              children: [
                Icon(
                  ok ? Icons.check_circle_rounded : Icons.error_outline_rounded,
                  size: 14,
                  color: color,
                ),
                const SizedBox(width: 6),
                Expanded(
                  child: Text(
                    LocaleKeys.part_card_split_remaining.tr(
                      namedArgs: {'qty': '$remaining'},
                    ),
                    style: AppTextStyles.caption.copyWith(
                      fontWeight: FontWeight.w800,
                      color: color,
                    ),
                  ),
                ),
                // Thùng chỉ để tham khảo — không chặn.
                Text(
                  '${LocaleKeys.part_card_field_box.tr()} '
                      '$boxTotal/${source.totalBox}',
                  style: AppTextStyles.caption.copyWith(
                    fontWeight: FontWeight.w700,
                    color: swms.text3,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Dải chọn tem con + nút thêm / xoá tem đang chọn.
class _PartTabs extends StatelessWidget {
  const _PartTabs({
    required this.parts,
    required this.selected,
    required this.onSelect,
    required this.onAdd,
    required this.onRemove,
  });

  final List<PartCardForm> parts;
  final int selected;
  final ValueChanged<int> onSelect;

  /// null = đã đủ số tem tối đa.
  final VoidCallback? onAdd;

  /// null = không xoá được (tối thiểu 2 tem con).
  final VoidCallback? onRemove;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Row(
      children: [
        Expanded(
          child: SingleChildScrollView(
            scrollDirection: Axis.horizontal,
            child: Row(
              spacing: AppDimens.sm,
              children: [
                for (var i = 0; i < parts.length; i++)
                  _PartPill(
                    no: i + 1,
                    form: parts[i],
                    selected: i == selected,
                    onTap: () => onSelect(i),
                  ),
                _AddPill(onTap: onAdd),
              ],
            ),
          ),
        ),
        const SizedBox(width: AppDimens.xs),
        SizedBox.square(
          dimension: AppDimens.hitSm,
          child: IconButton(
            padding: EdgeInsets.zero,
            onPressed: onRemove,
            icon: Icon(
              Icons.delete_outline_rounded,
              size: 20,
              color: onRemove == null ? swms.text4 : swms.danger,
            ),
          ),
        ),
      ],
    );
  }
}

/// 1 tem con: "Tem n · qty pcs". Thiếu field / Qty = 0 → viền đỏ + icon.
class _PartPill extends StatelessWidget {
  const _PartPill({
    required this.no,
    required this.form,
    required this.selected,
    required this.onTap,
  });

  final int no;
  final PartCardForm form;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final bad = !form.isComplete || form.totalPcs <= 0;
    final fg = selected ? Colors.white : (bad ? swms.danger : swms.text1);
    final borderColor = selected
        ? Colors.transparent
        : (bad ? swms.danger.withValues(alpha: .45) : swms.border);

    return Material(
      color: selected ? swms.primary : swms.card2,
      shape: StadiumBorder(side: BorderSide(color: borderColor)),
      child: InkWell(
        onTap: onTap,
        customBorder: const StadiumBorder(),
        child: Container(
          height: AppDimens.hitSm,
          padding: const EdgeInsets.symmetric(horizontal: 12),
          alignment: Alignment.center,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            spacing: 6,
            children: [
              if (bad) Icon(Icons.error_outline_rounded, size: 13, color: fg),
              Text(
                LocaleKeys.part_card_split_part.tr(namedArgs: {'no': '$no'}),
                style: AppTextStyles.caption.copyWith(
                  fontWeight: FontWeight.w800,
                  color: fg,
                ),
              ),
              Text(
                '${form.totalPcs}',
                style: AppTextStyles.code.copyWith(
                  fontSize: 12,
                  fontWeight: FontWeight.w700,
                  color: selected ? Colors.white.withValues(alpha: .85) : fg,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _AddPill extends StatelessWidget {
  const _AddPill({required this.onTap});

  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final enabled = onTap != null;
    final color = enabled ? swms.primary : swms.text4;

    return Material(
      color: swms.card2,
      shape: StadiumBorder(
        side: BorderSide(color: color.withValues(alpha: .45), width: 1.2),
      ),
      child: InkWell(
        onTap: onTap,
        customBorder: const StadiumBorder(),
        child: SizedBox(
          width: AppDimens.hitSm + 8,
          height: AppDimens.hitSm,
          child: Icon(Icons.add_rounded, size: 20, color: color),
        ),
      ),
    );
  }
}