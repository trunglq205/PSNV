import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/extensions/datetime_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_history_entry.dart';

/// Thẻ hiển thị phiên quét dở còn lưu trong máy (bước 1).
class ReceivingHistoryCard extends StatelessWidget {
  const ReceivingHistoryCard({
    super.key,
    required this.entry,
    required this.onResume,
    required this.onDelete,
  });

  final ReceivingHistoryEntry entry;
  final VoidCallback onResume;
  final VoidCallback onDelete;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final model = entry.modelName;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        border: Border.all(color: swms.primary.withValues(alpha: .25)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Icon(Icons.history_rounded, size: 16, color: swms.primary),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  LocaleKeys.receiving_history_available.tr(),
                  style: AppTextStyles.caption.copyWith(
                    color: swms.text3,
                    fontWeight: FontWeight.w700,
                    letterSpacing: .3,
                  ),
                ),
              ),
              Text(
                entry.savedAt.hhMMDDMM,
                style: AppTextStyles.caption.copyWith(color: swms.text4),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Row(
            children: [
              _Chip(
                text: _modeLabel(entry.mode),
                color: AppColors.accentBlueFg,
                bg: AppColors.accentBlueTint,
              ),
              const SizedBox(width: 5),
              if (model != null) ...[
                Expanded(
                  child: Text(
                    model,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.code.copyWith(
                      fontSize: 12,
                      fontWeight: FontWeight.w800,
                      color: swms.text1,
                      letterSpacing: 0,
                    ),
                  ),
                ),
                const SizedBox(width: 5),
              ],
              _Chip(
                text: '${entry.itemCount} ${entry.unitKey.tr()}',
                color: AppColors.primaryDark,
                bg: swms.successBg,
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: AppButton(
                  size: .sm,
                  isFullWidth: false,
                  variant: .neutral,
                  icon: Icons.delete_outline_rounded,
                  label: LocaleKeys.receiving_history_delete.tr(),
                  onPressed: onDelete,
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                flex: 2,
                child: AppButton(
                  size: .sm,
                  isFullWidth: false,
                  label: LocaleKeys.receiving_history_resume.tr(),
                  onPressed: onResume,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  String _modeLabel(ReceivingMode mode) => switch (mode) {
    ReceivingMode.box => LocaleKeys.receiving_mode_box.tr(),
    ReceivingMode.model => LocaleKeys.receiving_mode_model.tr(),
    ReceivingMode.gtin => LocaleKeys.receiving_mode_gtin.tr(),
  };
}

class _Chip extends StatelessWidget {
  const _Chip({required this.text, required this.color, required this.bg});

  final String text;
  final Color color;
  final Color bg;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(5),
      ),
      child: Text(
        text,
        style: AppTextStyles.label.copyWith(
          fontWeight: FontWeight.w800,
          color: color,
        ),
      ),
    );
  }
}
