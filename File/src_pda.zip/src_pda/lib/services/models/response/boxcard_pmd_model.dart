import 'package:json_annotation/json_annotation.dart';
import 'package:smart_warehouse/services/models/request/receiving_card_model.dart';

import 'base_response_model.dart';

part 'boxcard_pmd_model.g.dart';

@JsonSerializable()
class BoxcardPMDModel extends BaseResponseModel  {
  BoxcardPMDModel({
    required this.id,
    required this.quantity
  });

  factory BoxcardPMDModel.fromJson(Map<String, dynamic> json) =>
      _$BoxcardPMDModelFromJson(json);
  final int id;
  final double quantity;
  @override
  Map<String, dynamic> toJson() => _$BoxcardPMDModelToJson(this);
}