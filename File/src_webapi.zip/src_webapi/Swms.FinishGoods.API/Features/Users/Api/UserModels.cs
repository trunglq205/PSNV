using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Shared.Models;
using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.Users.Api;

// Request / response DTOs cho feature User. Khớp với IUserApi (Refit) bên Web.

public class UserQuery : PagedQuery
{
    public string? Department { get; set; }   // SCS | FA | OQC | SEC | IT
    public bool? IsActive { get; set; }
    public string? Name { get; set; }
    public string? Email { get; set; }
    public string? EmployeeCode { get; set; }
    public bool? RecentLogin { get; set; }    // true = đăng nhập trong 24h
    public DateTime? CreatedFrom { get; set; }
    public DateTime? CreatedTo { get; set; }
}

public record CreateUserRequest(
    [Required, MaxLength(50)] string FullName,
    [MaxLength(100), EmailAddress] string? Email,
    [Required] string Department,
    [Required, MaxLength(10)] string EmployeeCode,
    // Để trống: mật khẩu mặc định = EmployeeCode (theo Users.Form.PasswordHint).
    string? Password,
    bool IsActive,
    List<string> RoleCodes);

// Không có Password: đổi mật khẩu dùng luồng reset-password riêng.
public record UpdateUserRequest(
    [Required, MaxLength(50)] string FullName,
    [MaxLength(100), EmailAddress] string? Email,
    [Required] string Department,
    [Required, MaxLength(10)] string EmployeeCode,
    bool IsActive,
    List<string> RoleCodes);

public record UserResponse(
    int Id, string FullName, string Email, string Department,
    string EmployeeCode, bool IsActive, DateTime? LastLoginAt,
    DateTime CreatedAt, List<string> RoleCodes)
{
    public static UserResponse From(User u)
        => new(u.Id, u.FullName, u.Email ?? string.Empty, u.Department,
               u.EmployeeCode, u.IsActive, u.LastLoginAt, u.CreatedAt,
               u.RoleCodes ?? new());
}

// Số lượng user theo phòng ban (cho tab filter). Key "" = tổng tất cả.
public record UserDeptCountResponse(Dictionary<string, int> Counts);

public record RoleOptionResponse(string Code, string Name, string Dot)
{
    public static RoleOptionResponse From(Role r) => new(r.Code, r.Name, r.Dot);
}

public sealed record DuplicateUserInfo(int? Id, string EmployeeCode, string Reason);