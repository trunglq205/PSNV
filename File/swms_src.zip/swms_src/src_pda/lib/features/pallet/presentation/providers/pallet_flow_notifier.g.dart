// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'pallet_flow_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Notifier dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
/// Family theo [PalletFlow] nên mỗi màn có state riêng.
///
///   Bước 1: quét pallet → `by-lot-no/{lotNo}?include=<flow.include>`
///           (loading/error nằm trong `state.pallet` nhờ `executePartial`).
///           Riêng màn Lưu kho gọi thêm `.../storage-suggestion` ở nền.
///   Bước 2: chọn hành động (đã lọc theo màn) → quét vị trí nếu cần → xác nhận.
///   Xong  : về bước 1, giữ `lastResult` để UI hiện toast.

@ProviderFor(PalletFlowNotifier)
final palletFlowProvider = PalletFlowNotifierFamily._();

/// Notifier dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
/// Family theo [PalletFlow] nên mỗi màn có state riêng.
///
///   Bước 1: quét pallet → `by-lot-no/{lotNo}?include=<flow.include>`
///           (loading/error nằm trong `state.pallet` nhờ `executePartial`).
///           Riêng màn Lưu kho gọi thêm `.../storage-suggestion` ở nền.
///   Bước 2: chọn hành động (đã lọc theo màn) → quét vị trí nếu cần → xác nhận.
///   Xong  : về bước 1, giữ `lastResult` để UI hiện toast.
final class PalletFlowNotifierProvider
    extends $NotifierProvider<PalletFlowNotifier, PalletFlowState> {
  /// Notifier dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
  /// Family theo [PalletFlow] nên mỗi màn có state riêng.
  ///
  ///   Bước 1: quét pallet → `by-lot-no/{lotNo}?include=<flow.include>`
  ///           (loading/error nằm trong `state.pallet` nhờ `executePartial`).
  ///           Riêng màn Lưu kho gọi thêm `.../storage-suggestion` ở nền.
  ///   Bước 2: chọn hành động (đã lọc theo màn) → quét vị trí nếu cần → xác nhận.
  ///   Xong  : về bước 1, giữ `lastResult` để UI hiện toast.
  PalletFlowNotifierProvider._({
    required PalletFlowNotifierFamily super.from,
    required PalletFlow super.argument,
  }) : super(
         retry: null,
         name: r'palletFlowProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$palletFlowNotifierHash();

  @override
  String toString() {
    return r'palletFlowProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  PalletFlowNotifier create() => PalletFlowNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PalletFlowState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PalletFlowState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is PalletFlowNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$palletFlowNotifierHash() =>
    r'3482506b0bd37ab117c579c33a20d9e432204edc';

/// Notifier dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
/// Family theo [PalletFlow] nên mỗi màn có state riêng.
///
///   Bước 1: quét pallet → `by-lot-no/{lotNo}?include=<flow.include>`
///           (loading/error nằm trong `state.pallet` nhờ `executePartial`).
///           Riêng màn Lưu kho gọi thêm `.../storage-suggestion` ở nền.
///   Bước 2: chọn hành động (đã lọc theo màn) → quét vị trí nếu cần → xác nhận.
///   Xong  : về bước 1, giữ `lastResult` để UI hiện toast.

final class PalletFlowNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          PalletFlowNotifier,
          PalletFlowState,
          PalletFlowState,
          PalletFlowState,
          PalletFlow
        > {
  PalletFlowNotifierFamily._()
    : super(
        retry: null,
        name: r'palletFlowProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Notifier dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
  /// Family theo [PalletFlow] nên mỗi màn có state riêng.
  ///
  ///   Bước 1: quét pallet → `by-lot-no/{lotNo}?include=<flow.include>`
  ///           (loading/error nằm trong `state.pallet` nhờ `executePartial`).
  ///           Riêng màn Lưu kho gọi thêm `.../storage-suggestion` ở nền.
  ///   Bước 2: chọn hành động (đã lọc theo màn) → quét vị trí nếu cần → xác nhận.
  ///   Xong  : về bước 1, giữ `lastResult` để UI hiện toast.

  PalletFlowNotifierProvider call(PalletFlow flow) =>
      PalletFlowNotifierProvider._(argument: flow, from: this);

  @override
  String toString() => r'palletFlowProvider';
}

/// Notifier dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
/// Family theo [PalletFlow] nên mỗi màn có state riêng.
///
///   Bước 1: quét pallet → `by-lot-no/{lotNo}?include=<flow.include>`
///           (loading/error nằm trong `state.pallet` nhờ `executePartial`).
///           Riêng màn Lưu kho gọi thêm `.../storage-suggestion` ở nền.
///   Bước 2: chọn hành động (đã lọc theo màn) → quét vị trí nếu cần → xác nhận.
///   Xong  : về bước 1, giữ `lastResult` để UI hiện toast.

abstract class _$PalletFlowNotifier extends $Notifier<PalletFlowState> {
  late final _$args = ref.$arg as PalletFlow;
  PalletFlow get flow => _$args;

  PalletFlowState build(PalletFlow flow);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<PalletFlowState, PalletFlowState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<PalletFlowState, PalletFlowState>,
              PalletFlowState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
