import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/qr_label.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/dialogs/box_po_edit_dialog.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/providers/box_detail_notifier.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/widgets/box_action_list.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/widgets/box_history_timeline.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/widgets/box_info_card.dart';
import 'package:swms_finish_goods/features/box_detail/presentation/widgets/box_serial_list.dart';
import 'package:swms_finish_goods/shared/presentation/label_print_dialog.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Box Detail. Định danh bằng boxId (box_no KHÔNG duy nhất).
//  Quick Scan phải resolve boxNo → id trước khi điều hướng vào đây.
//  "In lại tem" → dialog in tem: QR = payload của box, chữ = Box No.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class BoxDetailScreen extends ConsumerWidget {
  final int boxId;

  const BoxDetailScreen({super.key, @PathParam('boxId') required this.boxId});

  Future<void> _editPo(BuildContext context, WidgetRef ref) async {
    final box = ref.read(boxDetailProvider(boxId)).detail.value;
    if (box == null) return;

    final result = await showBoxPoEditDialog(
      context,
      customerPo: box.customerPo,
      psnvPo: box.psnvPo,
    );
    if (result == null) return;

    // Mutation → overlay toàn màn + error message tập trung.
    await ref
        .read(appActionProvider.notifier)
        .run(
          () => ref
          .read(boxDetailProvider(boxId).notifier)
          .updatePo(customerPo: result.customerPo, psnvPo: result.psnvPo),
    );
  }

  /// QR của tem box = payload. Không có payload thì không dựng lại được
  /// tem (in QR khác đi thì quét không ra box) → báo lỗi, không mở dialog.
  Future<void> _reprint(BuildContext context, BoxDetail box) async {
    final payload = box.payload.trim();
    if (payload.isEmpty) {
      AppToastHelper.toastError(context, LocaleKeys.label_no_payload.tr());
      return;
    }

    await showLabelPrintDialog(
      context,
      title: LocaleKeys.label_box_print_title.tr(),
      subtitle: box.boxNo,
      label: QrLabelData.box(payload: payload, boxNo: box.boxNo),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(boxDetailProvider(boxId));
    final notifier = ref.read(boxDetailProvider(boxId).notifier);

    return Scaffold(
      appBar: AppTopBar(
        title: 'box_detail.title'.tr(),
        subtitle: 'box_detail.subtitle'.tr(),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            // Làm mới cả hai: timeline cũng có thể đã đổi do người khác thao tác.
            onPressed: () {
              notifier.load();
              notifier.loadHistory();
            },
          ),
        ],
      ),
      body: state.detail.when(
        loading: () => const AppLoading(),
        error: (e, _) => AppErrorView.page(
          message: 'box_detail.load_error'.tr(),
          onRetry: notifier.load,
        ),
        data: (box) => ListView(
          padding: const EdgeInsets.all(AppDimens.md),
          children: [
            BoxInfoCard(box: box, onEditPo: () => _editPo(context, ref)),
            const SizedBox(height: AppDimens.md),
            BoxActionList(
              box: box,
              // Xem pallet chứa box -> mở màn Pallet Detail của lot chứa.
              onViewPallet: () => context.router.pop(),
              onReprint: () => _reprint(context, box),
              onReportNg: () {}, // báo NG — xử lý sau
            ),
            const SizedBox(height: AppDimens.md),
            BoxSerialList(
              serials: box.serials,
              onFindMissing: () {}, // tìm serial mất — làm sau
            ),
            const SizedBox(height: AppDimens.md),

            // Lịch sử có AsyncValue RIÊNG: hỏng thì chỉ khối này báo lỗi,
            // thông tin thùng và sửa PO vẫn dùng được.
            state.history.when(
              loading: () => const Padding(
                padding: EdgeInsets.symmetric(vertical: AppDimens.lg),
                child: AppLoading(),
              ),
              error: (e, _) => AppErrorView.widget(
                message: 'box_detail.history_load_error'.tr(),
                onRetry: notifier.loadHistory,
              ),
              data: (history) => BoxHistoryTimeline(
                events: history.events,
                ownOnly: state.historyOwnOnly,
                onOwnOnlyChanged: notifier.setHistoryOwnOnly,
                loading: state.history.isLoading,
              ),
            ),
          ],
        ),
      ),
    );
  }
}