import 'package:flutter/material.dart';

/// Bộ màu của một trạng thái kiểm: nền, viền, chữ.
class StatusColors {
  final Color bg;
  final Color border;
  final Color fg;
  const StatusColors(this.bg, this.border, this.fg);
}

/// Tông màu OQC của map Receiving, NỀN PHA NHẠT 60% cho đỡ nặng mắt
/// (ô kệ nằm liền nhau nên mảng màu dày hơn map Receiving); viền giữ màu gốc đậm.
/// Dùng chung cho sơ đồ kho và mặt cắt kệ để không bao giờ lệch màu.
StatusColors statusColors(String? status) {
  switch (status) {
    case 'not_inspected': // Vàng — chưa lấy mẫu
      return const StatusColors(Color(0xFFFFE695), Color(0xFFD9AC0B), Color(0xFF4A3B00));
    case 'under_inspection': // Cam — đang kiểm
      return const StatusColors(Color(0xFFF9CA7B), Color(0xFFD98A0B), Color(0xFF5C3D00));
    case 'pending_result': // Xanh dương nhạt — chờ kết quả
      return const StatusColors(Color(0xFFBBDFF0), Color(0xFF5AA8CC), Color(0xFF0B3A4A));
    case 'inspection_exempt': // Xanh dương đậm — miễn kiểm
      return const StatusColors(Color(0xFF73A3D9), Color(0xFF0D47A1), Color(0xFF0D3A73));
    case 'pass': // Xanh lá — OK
      return const StatusColors(Color(0xFF8CD9A6), Color(0xFF2E9E52), Color(0xFF1E6B3C));
    case 'ng': // Đỏ — NG
      return const StatusColors(Color(0xFFEF8886), Color(0xFFB71C1C), Color(0xFF8E1B1B));
    default: // Trắng — trống
      return const StatusColors(Color(0xFFFFFFFF), Color(0xFFC7CDD6), Color(0xFF8A94A0));
  }
}

/// Viền xanh nước biển cho hàng xuất khẩn (--st-urgent-frame của map Receiving).
const Color kUrgentFrame = Color(0xFF14328C);
