// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'storage_suggestion_models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

StorageSuggestionModel _$StorageSuggestionModelFromJson(
  Map<String, dynamic> json,
) => StorageSuggestionModel(
  lotNo: json['lotNo'] as String,
  model: json['model'] as String?,
  strategy: json['strategy'] as String?,
  master: json['master'] == null
      ? null
      : ModelMasterConfigModel.fromJson(json['master'] as Map<String, dynamic>),
  suggestedAreaCode: json['suggestedAreaCode'] as String?,
  suggestedAreaName: json['suggestedAreaName'] as String?,
  suggestedRackRows:
      (json['suggestedRackRows'] as List<dynamic>?)
          ?.map((e) => (e as num).toInt())
          .toList() ??
      const [],
  suggestedSlotKind: json['suggestedSlotKind'] as String?,
  suggestedLocator: json['suggestedLocator'] == null
      ? null
      : SuggestedLocatorModel.fromJson(
          json['suggestedLocator'] as Map<String, dynamic>,
        ),
  alternatives:
      (json['alternatives'] as List<dynamic>?)
          ?.map(
            (e) => SuggestedLocatorModel.fromJson(e as Map<String, dynamic>),
          )
          .toList() ??
      const [],
  lastLot: json['lastLot'] == null
      ? null
      : LastLotLocationModel.fromJson(json['lastLot'] as Map<String, dynamic>),
  warnings:
      (json['warnings'] as List<dynamic>?)?.map((e) => e as String).toList() ??
      const [],
);

ModelMasterConfigModel _$ModelMasterConfigModelFromJson(
  Map<String, dynamic> json,
) => ModelMasterConfigModel(
  areaId: (json['areaId'] as num?)?.toInt(),
  areaCode: json['areaCode'] as String?,
  rackRows:
      (json['rackRows'] as List<dynamic>?)
          ?.map((e) => (e as num).toInt())
          .toList() ??
      const [],
);

SuggestedLocatorModel _$SuggestedLocatorModelFromJson(
  Map<String, dynamic> json,
) => SuggestedLocatorModel(
  locatorId: (json['locatorId'] as num).toInt(),
  locatorCode: json['locatorCode'] as String,
  rackCode: json['rackCode'] as String?,
  rackRow: (json['rackRow'] as num?)?.toInt(),
  rackLevel: json['rackLevel'] as String?,
  slotKind: json['slotKind'] as String?,
);

LastLotLocationModel _$LastLotLocationModelFromJson(
  Map<String, dynamic> json,
) => LastLotLocationModel(
  lotNo: json['lotNo'] as String,
  locatorCode: json['locatorCode'] as String,
  rackCode: json['rackCode'] as String?,
  rackRow: (json['rackRow'] as num?)?.toInt(),
  matchedBy: json['matchedBy'] as String?,
);
