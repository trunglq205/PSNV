﻿using Refit;
using Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;
using Swms.FinishGoods.Web.Features.AbnormalReports.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.AbnormalReports.Business;

public class NgReportBusiness : BaseBusiness, INgReportBusiness
{
    private readonly INgReportApi _api;

    public NgReportBusiness(INgReportApi api, ILogger<NgReportBusiness> logger, ErrorHandler errorHandler)
        : base(logger, errorHandler) => _api = api;

    public Task<Result<List<NgReportSummaryDto>>> GetListAsync(string? status = null, string? ngType = null,
        DateTime? from = null, DateTime? to = null, string? keyword = null)
        => ExecuteAsync(() => _api.GetListAsync(status, ngType, from, to, keyword));

    public Task<Result<NgReportDetailDto>> GetAsync(long id)
        => ExecuteAsync(() => _api.GetAsync(id));

    public Task<Result<FileDownload>> DownloadListReportAsync(
        string? status, string? ngType, DateTime? from, DateTime? to, string? keyword,
        string? faRes, string? oqc, string? finalRes)
        => ExecuteAsync(async () =>
        {
            // HttpResponseMessage không để lọt lên page: đọc bytes rồi dispose
            // ngay tại đây, giống GetPhotoDataUriAsync.
            using var res = await _api.DownloadListReportAsync(
                status, ngType, from, to, keyword, faRes, oqc, finalRes);

            // KHÔNG dùng EnsureSuccessStatusCode: nó ném HttpRequestException
            // trần, mà ErrorHandler gom mọi HttpRequestException thành "Không
            // kết nối được server" — 403 vì thiếu quyền sẽ trông như lỗi mạng.
            if (!res.IsSuccessStatusCode)
                throw await ApiException.Create(
                    res.RequestMessage!, res.RequestMessage!.Method, res, new RefitSettings());

            var bytes = await res.Content.ReadAsByteArrayAsync();
            if (bytes.Length == 0)
                throw new InvalidOperationException("empty body");

            // FileNameStar là bản RFC 5987 (giữ được chữ có dấu); FileName là
            // bản ASCII. Thiếu cả hai thì mới tự đặt tên — để rơi vào tên rỗng
            // thì trình duyệt lưu ra file không có đuôi, bấm vào không mở được.
            var cd = res.Content.Headers.ContentDisposition;
            var name = cd?.FileNameStar ?? cd?.FileName?.Trim('"');
            if (string.IsNullOrWhiteSpace(name)) name = "abnormal-reports.xlsx";

            return new FileDownload(name, bytes);
        });

    public Task<Result<string>> GetPhotoDataUriAsync(long photoId, string size = "thumb")
        => ExecuteAsync(async () =>
        {
            // Ảnh đi qua API có xác thực nên không nhúng URL trực tiếp được;
            // tải về rồi dựng data-uri. Ảnh thu nhỏ chỉ ~3KB nên không nặng.
            using var res = await _api.GetPhotoAsync(photoId, size);

            if (!res.IsSuccessStatusCode)
            {
                // KHÔNG dùng EnsureSuccessStatusCode: nó ném HttpRequestException
                // trần, mà ErrorHandler gom mọi HttpRequestException thành
                // "Không kết nối được server" — che mất 404/403 thật và khiến
                // lỗi file-không-tồn-tại trông như lỗi mạng.
                // Ném ApiException để đi đúng nhánh map theo status code.
                throw await ApiException.Create(
                    res.RequestMessage!, res.RequestMessage!.Method, res, new RefitSettings());
            }

            var bytes = await res.Content.ReadAsByteArrayAsync();
            if (bytes.Length == 0)
                throw new InvalidOperationException("empty body");

            var type = res.Content.Headers.ContentType?.MediaType ?? "image/jpeg";
            return $"data:{type};base64,{Convert.ToBase64String(bytes)}";
        });

    public Task<Result> UpdateAsync(long id, UpdateNgReportRequestDto request)
        => ExecuteAsync(() => _api.UpdateAsync(id, request));

    public Task<Result> DeletePhotoAsync(long photoId)
        => ExecuteAsync(() => _api.DeletePhotoAsync(photoId));

    public Task<Result<List<NgTypeDto>>> GetTypesAsync()
        => ExecuteAsync(() => _api.GetTypesAsync());

    public Task<Result<MailPreviewDto>> GetMailPreviewAsync(long id)
        => ExecuteAsync(() => _api.GetMailPreviewAsync(id));

    public Task<Result> LeaderReviewAsync(long id, LeaderReviewRequestDto request)
        => ExecuteAsync(() => _api.LeaderReviewAsync(id, request));

    public Task<Result> FaConfirmAsync(long id, FaConfirmRequestDto request)
        => ExecuteAsync(() => _api.FaConfirmAsync(id, request));

    public Task<Result> OqcConfirmAsync(long id, OqcConfirmRequestDto request)
        => ExecuteAsync(() => _api.OqcConfirmAsync(id, request));

    public Task<Result> FaFixDoneAsync(long id, FaFixDoneRequestDto request)
        => ExecuteAsync(() => _api.FaFixDoneAsync(id, request));
    // ---- Quản trị danh mục loại lỗi ----

    public Task<Result<List<NgTypeAdminDto>>> GetTypesForAdminAsync()
        => ExecuteAsync(() => _api.GetTypesForAdminAsync());

    public Task<Result> SaveTypeAsync(NgTypeAdminDto t)
        => ExecuteAsync(() => _api.SaveTypeAsync(new SaveNgTypeRequestDto
        {
            Code = t.Code,
            NameVi = t.NameVi,
            NameEn = Blank(t.NameEn),
            NameJa = Blank(t.NameJa),
            NameZh = Blank(t.NameZh),
            NoteVi = Blank(t.NoteVi),
            NoteEn = Blank(t.NoteEn),
            NoteJa = Blank(t.NoteJa),
            NoteZh = Blank(t.NoteZh),
            RequiresOqc = t.RequiresOqc,
            SortOrder = t.SortOrder,
            IsActive = t.IsActive,
        }));

    public Task<Result> DeleteTypeAsync(string code)
        => ExecuteAsync(() => _api.DeleteTypeAsync(code));

    /// <summary>Ô để trống gửi đi là NULL, không phải chuỗi rỗng.</summary>
    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}
