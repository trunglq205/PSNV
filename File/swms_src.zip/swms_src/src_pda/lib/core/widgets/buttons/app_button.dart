import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Biến thể nút theo design system PDA.
enum AppButtonVariant { primary, neutral, success, warning, danger, subtle }

/// sm = 36px · md = 44px · block = 52px full-width (CTA cuối màn).
enum AppButtonSize { sm, md, lg }

/// Nút bấm SWMS PDA — glove-friendly, bo 12px.
/// Màu lấy từ token qua context.swms; isLoading tự khoá nút.
///
/// `isFullWidth: false` → nút co theo nội dung, đặt được trong `Row` mà không
/// cần bọc `Expanded` (nút trong header thẻ, góc phải thẻ danh sách...).
class AppButton extends StatelessWidget {
  final String label;
  final VoidCallback? onPressed;
  final AppButtonVariant variant;
  final AppButtonSize size;
  final IconData? icon;
  final bool isFullWidth;
  final bool isLoading;

  bool get _iconOnly => label.isEmpty && icon != null;

  double get _iconSize => size == AppButtonSize.sm ? 16 : 18;

  const AppButton({
    super.key,
    required this.label,
    this.onPressed,
    this.variant = AppButtonVariant.primary,
    this.size = AppButtonSize.md,
    this.icon,
    this.isFullWidth = true,
    this.isLoading = false,
  });

  double get _height => switch (size) {
    AppButtonSize.sm => AppDimens.hitSm,
    AppButtonSize.md => AppDimens.hitMd,
    AppButtonSize.lg => AppDimens.hitLg,
  };

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    // (nền, chữ, viền) theo variant
    final (Color bg, Color fg, Color? side) = switch (variant) {
      AppButtonVariant.primary => (AppColors.primary, Colors.white, null),
      AppButtonVariant.success => (swms.success, Colors.white, null),
      AppButtonVariant.warning => (swms.warning, Colors.white, null),
      AppButtonVariant.danger => (swms.danger, Colors.white, null),
      AppButtonVariant.neutral => (
        Theme.of(context).colorScheme.surface,
        swms.text1,
        swms.border2,
      ),
      AppButtonVariant.subtle => (
        swms.primaryTint,
        AppColors.primaryDark,
        null,
      ),
    };

    final onTap = isLoading ? null : onPressed;

    final child = isLoading
        ? SizedBox(
            width: 20,
            height: 20,
            child: CircularProgressIndicator(strokeWidth: 2.4, color: fg),
          )
        : LayoutBuilder(
            builder: (context, constraints) {
              final text = Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                softWrap: false,
              );
              return Row(
                mainAxisSize: MainAxisSize.min,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  if (icon != null) ...[
                    Icon(icon, size: _iconSize, color: fg),
                    if (label.isNotEmpty)
                      SizedBox(
                        width: size == AppButtonSize.sm ? AppDimens.xs : AppDimens.sm,
                      ),
                  ],
                  if (label.isNotEmpty)
                    // Flexible (để ellipsis) chỉ hợp lệ khi bề ngang hữu hạn.
                    // Nút co theo nội dung nằm trong Row → bề ngang vô hạn,
                    // Flexible sẽ ném "non-zero flex but unbounded width".
                    constraints.hasBoundedWidth ? Flexible(child: text) : text,
                ],
              );
            },
          );

    return SizedBox(
      width: isFullWidth ? double.infinity : (_iconOnly ? _height : null),
      height: _height,
      child: FilledButton(
        onPressed: onTap,
        style: FilledButton.styleFrom(
          // Ghi đè theme FilledButton (minimumSize = Size.fromHeight → rộng tối
          // thiểu vô cực). Rộng 0: full-width đã do SizedBox bên ngoài lo,
          // nút co theo nội dung thì không bị kéo ra vô cực trong Row.
          minimumSize: Size(_iconOnly ? _height : 0, _height),
          backgroundColor: bg,
          foregroundColor: fg,
          disabledBackgroundColor: bg.withValues(alpha: 0.4),
          disabledForegroundColor: fg.withValues(alpha: 0.7),
          padding: const EdgeInsets.symmetric(horizontal: AppDimens.md),
          textStyle: const TextStyle(
            fontFamily: 'Inter',
            fontSize: 12,
            fontWeight: FontWeight.w600,
          ),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppDimens.rBtn),
            side: side != null ? BorderSide(color: side) : BorderSide.none,
          ),
        ),
        child: child,
      ),
    );
  }
}
