import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/extensions/navigation_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_bottom_hint.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_detail_notifier.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_line_list.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_summary_card.dart';

// ─────────────────────────────────────────────────────────────
//  Chi tiết Chỉ thị lấy hàng. Định danh bằng siId.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class ShipmentInstructionDetailScreen extends ConsumerWidget {
  final int siId;

  const ShipmentInstructionDetailScreen({
    super.key,
    @PathParam('siId') required this.siId,
  });

  static String _title(ShipmentInstructionDetail si) =>
      siJoin([si.siNo, si.revision]);

  static String? _subtitle(ShipmentInstructionDetail si) {
    final s = siJoin([si.shipMode, si.portOfDischarge]);
    return s.isEmpty ? null : s;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(shipmentInstructionDetailProvider(siId));
    final notifier = ref.read(shipmentInstructionDetailProvider(siId).notifier);
    final si = state.detail.value;

    return Scaffold(
      appBar: AppTopBar(
        title: si == null
            ? LocaleKeys.shipment_instruction_title.tr()
            : _title(si),
        subtitle: si == null ? null : _subtitle(si),
        actions: [
          IconButton(icon: const Icon(Icons.refresh), onPressed: notifier.load),
        ],
      ),
      body: state.detail.when(
        loading: () => const AppLoading(),
        error: (e, _) => Center(
          child: AppErrorView.widget(
            message: LocaleKeys.shipment_instruction_detail_load_error.tr(),
            onRetry: notifier.load,
          ),
        ),
        data: (si) => RefreshIndicator(
          onRefresh: notifier.load,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.all(AppDimens.md),
            children: [
              SiSummaryCard(si: si),
              const SizedBox(height: AppDimens.md),
              SiLineList(lines: si.lines),
            ],
          ),
        ),
      ),
      // CTA cố định đáy màn — chỉ khi còn soạn được.
      bottomNavigationBar: (si?.status?.canPick ?? false)
          ? AppBottomHint(
              child: AppButton(
                label: LocaleKeys.shipment_instruction_start_picking.tr(),
                icon: Icons.pan_tool_alt_outlined,
                size: AppButtonSize.lg,
                onPressed: () {
                  context.openKitting(si?.id);
                },
              ),
            )
          : null,
    );
  }
}
