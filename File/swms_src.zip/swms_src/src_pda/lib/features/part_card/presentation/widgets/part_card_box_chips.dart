import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_suggestion.dart';

/// Dải gợi ý "hộp hay dùng" ở bước xác nhận.
///
/// Cố ý KHÁC ô nhập: nền tint cả khối, nút dạng viên thuốc, đã chọn = đặc màu
/// → nhìn là biết "gợi ý để bấm", không phải dữ liệu đang nhập.
/// Không có gợi ý → không chiếm chỗ.
class PartCardBoxChips extends StatelessWidget {
  const PartCardBoxChips({
    super.key,
    required this.boxes,
    required this.form,
    required this.onSelected,
    this.enabled = true,
  });

  final List<PartCardSuggestion> boxes;
  final PartCardForm form;
  final ValueChanged<PartCardSuggestion> onSelected;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    if (boxes.isEmpty) return const SizedBox.shrink();

    final swms = context.swms;

    return Padding(
      // Tách khỏi khối Model / Cate bên dưới.
      padding: const EdgeInsets.only(bottom: AppDimens.sm),
      child: Container(
        padding: const EdgeInsets.fromLTRB(8, 8, 8, 8),
        decoration: BoxDecoration(
          color: swms.primaryTint,
          borderRadius: BorderRadius.circular(AppDimens.rCard),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Padding(
              padding: const EdgeInsets.only(left: 2),
              child: Row(
                spacing: 4,
                children: [
                  Icon(Icons.auto_awesome_rounded, size: 12, color: swms.primary),
                  Text(
                    LocaleKeys.part_card_box_suggest_title.tr(),
                    style: AppTextStyles.caption.copyWith(
                      fontSize: 10,
                      fontWeight: FontWeight.w800,
                      letterSpacing: .3,
                      color: swms.primaryDark,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 6),
            Row(
              spacing: AppDimens.sm,
              children: [
                for (final box in boxes)
                  Expanded(
                    child: _BoxPill(
                      box: box,
                      selected: box.isSameBox(form),
                      onTap: enabled ? () => onSelected(box) : null,
                    ),
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BoxPill extends StatelessWidget {
  const _BoxPill({required this.box, required this.selected, this.onTap});

  final PartCardSuggestion box;
  final bool selected;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    const shape = StadiumBorder();

    return Opacity(
      opacity: onTap == null ? 0.4 : 1,
      child: Material(
        color: selected ? swms.primary : swms.card,
        shape: shape,
        elevation: selected ? 0 : 0.5,
        shadowColor: swms.primary.withValues(alpha: .3),
        child: InkWell(
          onTap: onTap,
          customBorder: shape,
          child: SizedBox(
            // Glove-friendly: cao bằng nút nhỏ, cả viên đều bấm được.
            height: AppDimens.hitSm,
            child: Padding(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              // Ô hẹp → thu nhỏ cả cụm cho vừa, KHÔNG tràn / cắt chữ.
              child: FittedBox(
                fit: BoxFit.scaleDown,
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  spacing: 5,
                  children: [
                    Text(
                      box.boxText,
                      style: AppTextStyles.code.copyWith(
                        fontSize: 12,
                        fontWeight: FontWeight.w800,
                        color: selected ? Colors.white : swms.primaryDark,
                      ),
                    ),
                    Text(
                      LocaleKeys.part_card_box_suggest_count.tr(
                        namedArgs: {'count': '${box.count}'},
                      ),
                      style: AppTextStyles.caption.copyWith(
                        fontSize: 10,
                        fontWeight: FontWeight.w600,
                        color: selected
                            ? Colors.white.withValues(alpha: .8)
                            : swms.text3,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}