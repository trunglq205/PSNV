import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';

/// Danh sách hành động khả dụng cho pallet.
/// Hành động phụ thuộc trạng thái (Lưu kho, Chuyển/Out) do server quyết định
/// qua `allowedActions` — không tự suy từ `hasLocator`.
class PalletActionList extends StatelessWidget {
  final Pallet pallet;
  final VoidCallback? onMoveTemp;
  final VoidCallback? onSplit;
  final VoidCallback? onStore;
  final VoidCallback? onWarehouseMove;
  final VoidCallback? onReprint;

  const PalletActionList({
    super.key,
    required this.pallet,
    this.onMoveTemp,
    this.onSplit,
    this.onStore,
    this.onWarehouseMove,
    this.onReprint,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    // Đã lưu kho (có vị trí, không còn "store") mà server cho move/release
    // -> hiện lối vào màn Chuyển / Out.
    final showWarehouseMove =
        pallet.hasLocator && !pallet.canStore && (pallet.canMove);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(
            left: AppDimens.xs,
            bottom: AppDimens.xs,
          ),
          child: Text(
            LocaleKeys.pallet_detail_actions.tr(),
            style: AppTextStyles.label.copyWith(color: swms.text3),
          ),
        ),
        _ActionRow(
          icon: Icons.swap_horiz,
          iconColor: swms.warning,
          iconBg: swms.warningBg,
          title: pallet.hasLocator
              ? LocaleKeys.pallet_detail_act_temp.tr()
              : LocaleKeys.pallet_detail_act_assign_temp.tr(),
          subtitle: pallet.hasLocator
              ? LocaleKeys.pallet_detail_act_temp_sub.tr(
                  args: [pallet.locatorCode!],
                )
              : LocaleKeys.pallet_detail_act_assign_temp_sub.tr(),
          onTap: onMoveTemp,
        ),
        _ActionRow(
          icon: Icons.call_split,
          iconColor: swms.primary,
          iconBg: swms.primaryTint,
          title: LocaleKeys.pallet_detail_act_split.tr(),
          subtitle: LocaleKeys.pallet_detail_act_split_sub.tr(),
          onTap: onSplit,
        ),
        if (pallet.canStore)
          _ActionRow(
            icon: Icons.warehouse_outlined,
            iconColor: swms.success,
            iconBg: swms.successBg,
            title: LocaleKeys.pallet_detail_act_store.tr(),
            subtitle: LocaleKeys.pallet_detail_act_store_sub.tr(),
            onTap: onStore,
          ),
        if (showWarehouseMove && onWarehouseMove != null)
          _ActionRow(
            icon: Icons.move_down_outlined,
            iconColor: swms.primary,
            iconBg: swms.primaryTint,
            title: LocaleKeys.pallet_detail_act_warehouse_move.tr(),
            subtitle: LocaleKeys.pallet_detail_act_warehouse_move_sub.tr(
              args: [pallet.locatorCode!],
            ),
            onTap: onWarehouseMove,
          ),
        _ActionRow(
          icon: Icons.print_outlined,
          iconColor: swms.text2,
          iconBg: swms.card2,
          title: LocaleKeys.pallet_detail_act_reprint.tr(),
          subtitle: LocaleKeys.pallet_detail_act_reprint_sub.tr(
            args: [pallet.lotNo],
          ),
          onTap: onReprint,
        ),
      ],
    );
  }
}

class _ActionRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  const _ActionRow({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.xs),
      child: AppCard(
        onTap: onTap,
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(AppDimens.rBtn),
              ),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(width: AppDimens.sm),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: AppTextStyles.caption.copyWith(color: swms.text3),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: swms.text4, size: 20),
          ],
        ),
      ),
    );
  }
}
