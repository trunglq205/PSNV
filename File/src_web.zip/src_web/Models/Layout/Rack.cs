﻿using System.ComponentModel;
using System.Linq;
using System.Text;
using SWMS_WebTool.Utils.Extensions;

namespace SWMS_WebTool.Models.Layout
{
    public enum TypeSloc
    {
        [Description("Status_FA")]
        FA = 0,
        [Description("Status_DIP")]
        DIP = 1,
        [Description("Status_JPT")]
        JPT = 2,
        [Description("Status_Special")]
        Special = 4,
    }
    public enum RackDetailType
    {
        [Description("Status_BigRack1F1")]
        BigRack1F1 = 0,
        [Description("Status_BigRack1F2")]
        BigRack1F2 = 1,
        [Description("Status_BigRack2F")]
        BigRack2F = 2,
        [Description("Status_SmallWhiteRack")]
        SmallWhiteRack = 3,
        [Description("Status_SmallBlueRack")]
        SmallBlueRack = 4,
        [Description("Status_SmallGreyRack")]
        SmallGreyRack = 5,
        [Description("Status_Pallet")]
        Pallet = 7,
    }

    public static class RackTypeExtensions
    {
        public static string GetImage(this RackDetailType value)
        {
            switch (value)
            {
                case RackDetailType.BigRack1F1:
                    return "/img/BigRack1F1.png";
                case RackDetailType.BigRack1F2:
                    return "/img/BigRack1F2.png";
                case RackDetailType.BigRack2F:
                    return "/img/BigRack2F.png";
                case RackDetailType.SmallWhiteRack:
                    return "/img/SmallRackWhite.png";
                case RackDetailType.SmallBlueRack:
                    return "/img/SmallRackBlue.png";
                case RackDetailType.SmallGreyRack:
                    return "/img/SmallRackGrey.png";
                case RackDetailType.Pallet:
                    return "/img/pallet.jpg";
            }

            return "";
        }

        public static double GetBorderWidth(this RackDetailType value)
        {
            switch (value)
            {
                case RackDetailType.BigRack1F1:
                case RackDetailType.BigRack1F2:
                case RackDetailType.BigRack2F:
                    return 5;
                case RackDetailType.SmallWhiteRack:
                case RackDetailType.SmallBlueRack:
                case RackDetailType.SmallGreyRack:
                    return 3;
            }

            return 3;
        }

        public static string GetRackType(this RackDetailType value)
        {
            switch (value)
            {
                case RackDetailType.BigRack1F1:
                case RackDetailType.BigRack1F2:
                case RackDetailType.BigRack2F:
                    return "Big part";
                case RackDetailType.SmallWhiteRack:
                case RackDetailType.SmallBlueRack:
                case RackDetailType.SmallGreyRack:
                    return "Small part";
            }

            return "Pallet";
        }
    }

    public class Rack : Widget
    {
        public Rack() { }

        public Rack(KonvaObject konvaObject) : base(konvaObject)
        {

            //Tuấn Anh sửa
            var arr = konvaObject.Attrs.CustomData?.Split(";");

            if (arr?.Length != 11)
            {
                return;
            }
            try
            {
              

                Data = konvaObject.Attrs.Data ?? "";
                RackId = int.Parse(arr[0]);
                NumberOfLayer = int.Parse(arr[1]);
                NumberOfUnit = int.Parse(arr[2]);
                RackCode = arr[3];
                RackType = arr[4];
                RackDetailType = arr[5].ToEnum<RackDetailType>();
                Category = arr[6];
                TypeSloc = arr[7].ToEnum<TypeSloc>();
                IsPL = bool.Parse(arr[8]);
                PIC = arr[9];
                JIT = arr[10];
            }
            catch (Exception ex)
            {

                throw;
            }
          
        }

        public string PIC;
        public string RackCode;
        public int NumberOfLayer;
        public int NumberOfUnit;
        public RackDetailType RackDetailType;
        public string RackType;
        public int RackId;
        public string Category;
        public TypeSloc TypeSloc;
        public bool IsPL = false;
        public string JIT;

        public string Data { get; set; }


        public override WidgetType Type => WidgetType.Rack;
        protected override KonvaClassType ClassName => KonvaClassType.Path;

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();

            StringBuilder sb = new StringBuilder($"M 0 0 L {Width} 0 L {Width} {Height} L 0 {Height} Z");


            var widthUnit = Width / NumberOfUnit;
            for (int i = 1; i < NumberOfUnit; i++)
            {
                sb.Append($" M {i * widthUnit} 0 L {i * widthUnit} {Height}");
            }

            attrs.Data = sb.ToString();
            attrs.Stroke = IsPL ? "rgb(255, 0, 0)" : JIT != "" ? "rgb(194, 113, 5)" : "#000000";
            attrs.CustomData = $"{RackId};{NumberOfLayer};{NumberOfUnit};{RackCode};{RackType};{RackDetailType};{Category};{TypeSloc.GetString()};{IsPL};{PIC};{JIT}";
            attrs.StrokeWidth = RackDetailType.GetBorderWidth();
            return attrs;
        }

        public override KonvaObject ToKonvaObject()
        {
            var attrs = ToKonvaAttr();
            attrs.X = 0;
            attrs.Y = 0;
            attrs.Rotation = 0;
            attrs.Draggable = false;
            attrs.Locked = true;
            attrs.Name = WidgetType.Wall.GetString();

            var isSmallRack = RackDetailType.GetString()[0] == 'S';
            var widthUnit = Width / NumberOfUnit;
            var fontSize  = Height < 50 ? 15 : widthUnit > 110 ? 40 : widthUnit > 70  ? 20 : 15;
            var palletSize = (widthUnit < Height ? widthUnit : Height) - 10;

            var isRotation = Rotation == 180 || Rotation == -180;

            var children = new List<KonvaObject>()
            {
                new KonvaObject()
                {
                    ClassName = KonvaClassType.Path.GetString(),
                    Attrs = attrs
                },
                new KonvaObject()
                {
                    ClassName = KonvaClassType.Text.GetString(),
                    Attrs = new KonvaAttr()
                    {
                        X = (isRotation ? widthUnit : 0) + (isSmallRack ? 5 : 10) * (isRotation ? -1: 1),
                        Y = (isRotation ? Height : 0) + (Height /2 - fontSize/2)* (isRotation ? -1: 1),
                        Text = RackCode,
                        Width = widthUnit - (isSmallRack ? 5 : 10),
                        Height = fontSize,
                        FontSize = fontSize,
                        FontStyle = "bold",
                        Fill = "#000000",
                        Rotation = isRotation ? Rotation : null,
                        Locked = true,
                        Name = WidgetType.Wall.GetString(),
                    }
                },
            };

            if (RackDetailType == RackDetailType.Pallet && NumberOfUnit > 1)
            {
                children.Add(new KonvaObject()
                {
                    Attrs = new KonvaAttr()
                    {
                        X = Width - palletSize - 5,
                        Y = (Height - palletSize)/2,
                        Width = palletSize,
                        Height = palletSize,
                        Name = WidgetType.Pallet.ToString(),
                        Locked = true,
                    },
                    ClassName = KonvaClassType.Image.GetString(),
                });
            }

            return new KonvaObject()
            {
                ClassName = KonvaClassType.Group.GetString(),
                Attrs = ToKonvaAttr(),
                Children = children
            };
        }

        public BoundingBox? FindBlock(string blockName)
        {
            var block = new Block(blockName);

            if(BoundingBox == null)
            {
                return null;
            }

            var widthUnit = BoundingBox.Width / NumberOfUnit;
            var heightUnit = BoundingBox.Height / NumberOfUnit;

            switch ((int)Math.Round(Rotation ?? 0))
            {
                case 90:
                    return new BoundingBox() { 
                        X = BoundingBox.X,
                        Y = BoundingBox.Y + (block.Unit - 1) * heightUnit,
                        Width = BoundingBox.Width,
                        Height = heightUnit,
                    };
                case -90:
                    return new BoundingBox()
                    {
                        X = BoundingBox.X,
                        Y = BoundingBox.Y + BoundingBox.Height - block.Unit * heightUnit,
                        Width = BoundingBox.Width,
                        Height = heightUnit,
                    };
                case 180:
                case -180:
                    return new BoundingBox()
                    {
                        X = BoundingBox.X + BoundingBox.Width - block.Unit * widthUnit,
                        Y = BoundingBox.Y,
                        Width = widthUnit,
                        Height = BoundingBox.Height,
                    };
                default:
                    return new BoundingBox()
                    {
                        X = BoundingBox.X + (block.Unit - 1) * widthUnit,
                        Y = BoundingBox.Y,
                        Width = widthUnit,
                        Height = BoundingBox.Height,
                    };
            }
        }
    }
}
