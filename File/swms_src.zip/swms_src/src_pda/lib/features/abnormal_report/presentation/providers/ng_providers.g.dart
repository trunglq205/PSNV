// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ng_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(ngRepository)
final ngRepositoryProvider = NgRepositoryProvider._();

final class NgRepositoryProvider
    extends $FunctionalProvider<NgRepository, NgRepository, NgRepository>
    with $Provider<NgRepository> {
  NgRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'ngRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$ngRepositoryHash();

  @$internal
  @override
  $ProviderElement<NgRepository> $createElement($ProviderPointer pointer) =>
      $ProviderElement(pointer);

  @override
  NgRepository create(Ref ref) {
    return ngRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(NgRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<NgRepository>(value),
    );
  }
}

String _$ngRepositoryHash() => r'a9c7535b91da9a3b3aac246a23ed328e3959230b';

/// Danh sách phiếu của 1 ngày. [day] dạng 'yyyy-MM-dd'; rỗng = mọi ngày.
///
/// Dùng chuỗi làm tham số thay vì DateTime để Riverpod so sánh được bằng ==
/// (hai DateTime cùng ngày nhưng khác giờ sẽ tạo ra 2 provider khác nhau).

@ProviderFor(ngList)
final ngListProvider = NgListFamily._();

/// Danh sách phiếu của 1 ngày. [day] dạng 'yyyy-MM-dd'; rỗng = mọi ngày.
///
/// Dùng chuỗi làm tham số thay vì DateTime để Riverpod so sánh được bằng ==
/// (hai DateTime cùng ngày nhưng khác giờ sẽ tạo ra 2 provider khác nhau).

final class NgListProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<NgReport>>,
          List<NgReport>,
          FutureOr<List<NgReport>>
        >
    with $FutureModifier<List<NgReport>>, $FutureProvider<List<NgReport>> {
  /// Danh sách phiếu của 1 ngày. [day] dạng 'yyyy-MM-dd'; rỗng = mọi ngày.
  ///
  /// Dùng chuỗi làm tham số thay vì DateTime để Riverpod so sánh được bằng ==
  /// (hai DateTime cùng ngày nhưng khác giờ sẽ tạo ra 2 provider khác nhau).
  NgListProvider._({
    required NgListFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'ngListProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$ngListHash();

  @override
  String toString() {
    return r'ngListProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<List<NgReport>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<NgReport>> create(Ref ref) {
    final argument = this.argument as String;
    return ngList(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is NgListProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$ngListHash() => r'1e95bde1329718b4585aa5a131d7ad85f63570b5';

/// Danh sách phiếu của 1 ngày. [day] dạng 'yyyy-MM-dd'; rỗng = mọi ngày.
///
/// Dùng chuỗi làm tham số thay vì DateTime để Riverpod so sánh được bằng ==
/// (hai DateTime cùng ngày nhưng khác giờ sẽ tạo ra 2 provider khác nhau).

final class NgListFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<List<NgReport>>, String> {
  NgListFamily._()
    : super(
        retry: null,
        name: r'ngListProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Danh sách phiếu của 1 ngày. [day] dạng 'yyyy-MM-dd'; rỗng = mọi ngày.
  ///
  /// Dùng chuỗi làm tham số thay vì DateTime để Riverpod so sánh được bằng ==
  /// (hai DateTime cùng ngày nhưng khác giờ sẽ tạo ra 2 provider khác nhau).

  NgListProvider call(String day) =>
      NgListProvider._(argument: day, from: this);

  @override
  String toString() => r'ngListProvider';
}

/// Chi tiết 1 phiếu.

@ProviderFor(ngDetail)
final ngDetailProvider = NgDetailFamily._();

/// Chi tiết 1 phiếu.

final class NgDetailProvider
    extends
        $FunctionalProvider<AsyncValue<NgDetail>, NgDetail, FutureOr<NgDetail>>
    with $FutureModifier<NgDetail>, $FutureProvider<NgDetail> {
  /// Chi tiết 1 phiếu.
  NgDetailProvider._({
    required NgDetailFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'ngDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$ngDetailHash();

  @override
  String toString() {
    return r'ngDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<NgDetail> $createElement($ProviderPointer pointer) =>
      $FutureProviderElement(pointer);

  @override
  FutureOr<NgDetail> create(Ref ref) {
    final argument = this.argument as int;
    return ngDetail(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is NgDetailProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$ngDetailHash() => r'0e825c299554709c2adf13b14fd243052980973a';

/// Chi tiết 1 phiếu.

final class NgDetailFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<NgDetail>, int> {
  NgDetailFamily._()
    : super(
        retry: null,
        name: r'ngDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Chi tiết 1 phiếu.

  NgDetailProvider call(int id) => NgDetailProvider._(argument: id, from: this);

  @override
  String toString() => r'ngDetailProvider';
}

/// Danh mục loại lỗi — tải 1 lần, giữ suốt phiên, giống cách danh mục Cate
/// đang làm. Danh sách này đổi rất thưa (thêm một loại lỗi là việc của tháng,
/// không phải của phút) nên không đáng tải lại mỗi lần mở màn hình.

@ProviderFor(ngTypes)
final ngTypesProvider = NgTypesProvider._();

/// Danh mục loại lỗi — tải 1 lần, giữ suốt phiên, giống cách danh mục Cate
/// đang làm. Danh sách này đổi rất thưa (thêm một loại lỗi là việc của tháng,
/// không phải của phút) nên không đáng tải lại mỗi lần mở màn hình.

final class NgTypesProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<NgType>>,
          List<NgType>,
          FutureOr<List<NgType>>
        >
    with $FutureModifier<List<NgType>>, $FutureProvider<List<NgType>> {
  /// Danh mục loại lỗi — tải 1 lần, giữ suốt phiên, giống cách danh mục Cate
  /// đang làm. Danh sách này đổi rất thưa (thêm một loại lỗi là việc của tháng,
  /// không phải của phút) nên không đáng tải lại mỗi lần mở màn hình.
  NgTypesProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'ngTypesProvider',
        isAutoDispose: false,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$ngTypesHash();

  @$internal
  @override
  $FutureProviderElement<List<NgType>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<NgType>> create(Ref ref) {
    return ngTypes(ref);
  }
}

String _$ngTypesHash() => r'0a2be63b5932bb87d04e4011cbb089f7760b503d';
