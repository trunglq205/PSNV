using System.Security.Claims;
using Microsoft.Extensions.Caching.Memory;
using Swms.FinishGoods.Api.Features.Roles.Business;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// CHIẾN LƯỢC A — Quyền nằm trong JWT claims (nhét lúc login).
/// Nhanh nhất (không chạm DB mỗi request) nhưng quyền chỉ refresh khi cấp lại token.
/// Claim type "perm", mỗi quyền một claim.
/// </summary>
public sealed class ClaimsUserPermissionProvider : IUserPermissionProvider
{
    public const string PermissionClaimType = "perm";
    public const string SystemRoleClaimValue = "__system__"; // đánh dấu full quyền

    public Task<IReadOnlySet<string>> GetPermissionsAsync(ClaimsPrincipal user)
    {
        // User hệ thống ⟹ full quyền theo catalog
        if (user.HasClaim(PermissionClaimType, SystemRoleClaimValue))
            return Task.FromResult<IReadOnlySet<string>>(
                PermissionCatalog.AllCodes.ToHashSet(StringComparer.OrdinalIgnoreCase));

        var set = user.FindAll(PermissionClaimType)
            .Select(c => c.Value)
            .ToHashSet(StringComparer.OrdinalIgnoreCase);
        return Task.FromResult<IReadOnlySet<string>>(set);
    }
}

/// <summary>
/// CHIẾN LƯỢC B — Quyền query từ DB, cache ngắn hạn theo user.
/// Đổi quyền có hiệu lực sau khi cache hết hạn (vài phút), không cần cấp lại token.
/// </summary>
public sealed class DbCachedUserPermissionProvider : IUserPermissionProvider
{
    private static readonly TimeSpan Ttl = TimeSpan.FromMinutes(5);

    private readonly IRoleService _roleService;     // đã có GetMyPermissionsAsync
    private readonly IMemoryCache _cache;
    private readonly PermissionCacheVersion _version;

    public DbCachedUserPermissionProvider(
        IRoleService roleService, IMemoryCache cache, PermissionCacheVersion version)
    {
        _roleService = roleService;
        _cache = cache;
        _version = version;
    }

    public async Task<IReadOnlySet<string>> GetPermissionsAsync(ClaimsPrincipal user)
    {
        var userId = user.FindFirst(ClaimTypes.NameIdentifier)?.Value
                     ?? user.FindFirst("sub")?.Value;
        if (string.IsNullOrEmpty(userId))
            return new HashSet<string>();

        // Số phiên bản NẰM TRONG KHOÁ: đổi quyền của một role là tăng số đó,
        // mọi mục đã đệm lập tức không với tới được mà không cần biết role đó
        // đang gán cho những ai. Xem PermissionCacheVersion.
        //
        // Thiếu phần này thì UI và API nhìn hai nguồn khác nhau: AuthController
        // trả quyền ĐỌC THẲNG TỪ DB nên menu và nút hiện ra ngay sau khi cấp
        // quyền, trong khi tầng authorization vẫn xét bộ đệm cũ tới 5 phút —
        // người dùng vào được màn hình rồi ăn "Bạn không có quyền thực hiện
        // thao tác này", và đăng xuất đăng nhập lại cũng không chữa được vì
        // khoá đệm theo user id chứ không theo token.
        var key = $"perms:user:{userId}:v{_version.Current}";
        var set = await _cache.GetOrCreateAsync(key, async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = Ttl;
            var list = await _roleService.GetMyPermissionsAsync();
            return (IReadOnlySet<string>)list.ToHashSet(StringComparer.OrdinalIgnoreCase);
        });
        return set ?? new HashSet<string>();
    }

    /// <summary>
    /// Xoá đệm của ĐÚNG MỘT user. Giữ lại cho trường hợp đã biết chắc user nào
    /// bị ảnh hưởng; đổi quyền của role thì dùng <see cref="PermissionCacheVersion.Bump"/>.
    /// </summary>
    public void Invalidate(string userId)
        => _cache.Remove($"perms:user:{userId}:v{_version.Current}");
}
