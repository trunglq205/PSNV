import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/utils/feedback/feedback_provider.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/qr_label.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_pallet_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_fa_pallet_providers.dart';
import 'package:swms_finish_goods/shared/presentation/label_print_dialog.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2d — FA quét serial đóng lại Pallet ID sau khi rework xong.
//
//  Vào từ màn Tái gia công: chạm phiếu → "Đóng Pallet ID" → quét.
//
//  KHÁC MỤC 2a Ở ĐIỂM QUAN TRỌNG NHẤT: serial lạ KHÔNG BỊ CHẶN. Màn này cảnh
//  báo ngay tại chỗ rồi cho quét tiếp, và server ghi nhật ký để SCS WH đặt
//  riêng những con đó ra. Chặn FA đứng chờ SCS là làm đứng cả bàn rework.
//  (Quyết định nghiệp vụ 05/11, cố ý khác mô tả "lạ thì chặn" trong xlsx.)
//
//  FA KHÔNG CHỌN MODEL: sổ serial đã biết mỗi con thuộc model nào. PDA tải sổ
//  MỘT LẦN (`GET {docId}/serial-index`) rồi tra ngay trên máy, không hỏi server
//  từng con — bàn rework quét liên tục. Và CHẶN QUÉT đến khi sổ tải xong: tra
//  trên một cái sổ rỗng thì con nào cũng ra "lạ".
//
//  QUÉT HAI CẤP, phân biệt theo GIAI ĐOẠN chứ không đoán theo hình dạng mã
//  (cùng nguyên tắc với mục 2a): chưa có thùng mở → mã quét là MÃ THÙNG; đã có
//  thùng mở → mã quét là SERIAL.
//
//  ĐIỀU HƯỚNG BẰNG MaterialPageRoute, không khai route auto_route. Thêm một
//  @RoutePage là phải sinh lại app_router.gr.dart — file DÙNG CHUNG cả app, mà
//  build_runner trong source hiện tại đang vỡ (hai file cùng khai
//  `@RoutePage() class VanningPage`).
//
//  QUYỀN: `rework_refurbish.process_fa`, khớp
//  `[RequirePermission<…ProcessFa>]` trên `POST {docId}/fa-pallets`. Màn này
//  không kiểm lại quyền — chỗ gọi đã ẩn nút khi không có.
// ─────────────────────────────────────────────────────────────

/// Mở màn FA đóng pallet cho một phiếu.
///
/// Trả `true` khi đã đóng được pallet nào — chỗ gọi dùng nó để tải lại danh sách.
Future<bool> openFaPalletPage(
  BuildContext context, {
  required int docId,
  required String docNo,
  required ReturnGoodsType goodsType,
}) async {
  final changed = await Navigator.of(context).push<bool>(
    MaterialPageRoute(
      builder: (_) =>
          _FaScanPage(docId: docId, docNo: docNo, goodsType: goodsType),
    ),
  );
  return changed ?? false;
}

class _FaScanPage extends ConsumerStatefulWidget {
  const _FaScanPage({
    required this.docId,
    required this.docNo,
    required this.goodsType,
  });

  final int docId;
  final String docNo;
  final ReturnGoodsType goodsType;

  @override
  ConsumerState<_FaScanPage> createState() => _FaScanPageState();
}

class _FaScanPageState extends ConsumerState<_FaScanPage> {
  StreamSubscription<String>? _sub;

  /// Các thùng đã đóng xong trong lượt này.
  final List<FaScanBox> _boxes = [];

  /// Thùng đang mở. Null = đang ở giai đoạn quét MÃ THÙNG.
  String? _openBoxNo;
  bool _openBoxHasNo = false;
  final List<FaScannedSerial> _openSerials = [];

  bool _saving = false;
  bool _changed = false;

  /// Kết quả lượt vừa đóng — giữ trên màn để FA đọc Pallet ID và danh sách lệch.
  FaPalletResult? _last;

  bool get _boxOpen => _openBoxNo != null || _openBoxHasNo;

  /// Tổng serial sẽ gửi, kể cả con đã biết là lệch — server là bên ghi nhật ký.
  int get _totalSerials =>
      _boxes.fold(0, (n, b) => n + b.serials.length) + _openSerials.length;

  int get _totalOk =>
      _boxes.fold(0, (n, b) => n + b.okCount) +
      _openSerials.where((s) => s.verdict.isOk).length;

  int get _totalBad => _totalSerials - _totalOk;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Page đã dispose trong lúc chờ → không gán, tránh rò listener.
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      _onScan(data);
    });
  }

  /// Ngưng listener của page trong lúc mở dialog có quét riêng (đổi máy in).
  Future<void> _withScanPaused(Future<void> Function() body) async {
    await _sub?.cancel();
    _sub = null;
    try {
      await body();
    } finally {
      if (mounted) await _listen();
    }
  }

  // ── Nhận mã quét ──────────────────────────────────────────

  void _onScan(String raw) {
    final code = raw.trim();
    if (code.isEmpty || _saving) return;

    // Sổ chưa tải xong thì KHÔNG nhận: tra trên sổ rỗng là con nào cũng "lạ",
    // và FA sẽ tưởng cả pallet là hàng sai.
    final index = _indexOrNull();
    if (index == null) {
      ref.read(appFeedbackProvider).error();
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_fa_wait_index.tr(),
      );
      return;
    }

    if (!_boxOpen) {
      _openBox(code);
      return;
    }
    _addSerial(code, index);
  }

  FaSerialIndex? _indexOrNull() {
    final async = ref.read(faSerialIndexProvider(widget.docId));
    return async is AsyncData<FaSerialIndex> ? async.value : null;
  }

  void _openBox(String code) {
    final dup = _boxes.any(
        (b) => (b.boxNo ?? '').toLowerCase() == code.toLowerCase());
    if (dup) {
      ref.read(appFeedbackProvider).error();
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_fa_box_dup.tr(namedArgs: {'box': code}),
      );
      return;
    }

    ref.read(appFeedbackProvider).success();
    setState(() {
      _openBoxNo = code;
      _openBoxHasNo = true;
      _openSerials.clear();
    });
  }

  /// Thùng không quét được mã — server tự đặt `{lotNo}-nn`.
  void _openBoxWithoutNo() {
    if (_boxOpen) return;
    setState(() {
      _openBoxNo = null;
      _openBoxHasNo = true;
      _openSerials.clear();
    });
  }

  /// Thêm một serial vào thùng đang mở, kèm kết luận tra sổ TẠI MÁY.
  ///
  /// Con lệch VẪN được thêm: nó phải tới server để vào nhật ký. Chỉ đổi màu và
  /// kêu tiếng lỗi để FA biết ngay mà đặt riêng ra.
  void _addSerial(String code, FaSerialIndex index) {
    final seen = _boxes.any((b) => b.serials
            .any((s) => s.serial.toLowerCase() == code.toLowerCase())) ||
        _openSerials.any((s) => s.serial.toLowerCase() == code.toLowerCase());

    if (seen) {
      ref.read(appFeedbackProvider).error();
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_fa_serial_dup.tr(namedArgs: {'serial': code}),
      );
      return;
    }

    final row = index.lookup(code);
    final FaScannedSerial item;
    if (row == null) {
      item = FaScannedSerial(serial: code, verdict: FaScanVerdict.unknown);
    } else if (row.status != 'at_fa') {
      item = FaScannedSerial(
        serial: code,
        verdict: FaScanVerdict.wrongStatus,
        model: row.model,
        foundStatus: row.status,
      );
    } else {
      item = FaScannedSerial(
        serial: code,
        verdict: FaScanVerdict.ok,
        model: row.model,
      );
    }

    final fb = ref.read(appFeedbackProvider);
    item.verdict.isOk ? fb.success() : fb.error();

    setState(() => _openSerials.add(item));

    if (!item.verdict.isOk) {
      AppToastHelper.toastWarning(
        context,
        item.verdict == FaScanVerdict.wrongStatus
            ? LocaleKeys.return_fa_warn_status.tr(namedArgs: {
                'serial': code,
                'status': _statusLabel(item.foundStatus),
              })
            : LocaleKeys.return_fa_warn_unknown.tr(namedArgs: {'serial': code}),
      );
    }
  }

  void _finishBox() {
    if (!_boxOpen || _openSerials.isEmpty) return;
    setState(() {
      _boxes.add(FaScanBox(
        boxNo: _openBoxNo,
        serials: List<FaScannedSerial>.from(_openSerials),
      ));
      _openBoxNo = null;
      _openBoxHasNo = false;
      _openSerials.clear();
    });
  }

  void _cancelBox() {
    setState(() {
      _openBoxNo = null;
      _openBoxHasNo = false;
      _openSerials.clear();
    });
  }

  void _removeBox(int ix) {
    if (ix < 0 || ix >= _boxes.length) return;
    setState(() => _boxes.removeAt(ix));
  }

  void _removeOpenSerial(int ix) {
    if (ix < 0 || ix >= _openSerials.length) return;
    setState(() => _openSerials.removeAt(ix));
  }

  // ── Gửi ───────────────────────────────────────────────────

  Future<void> _submit() async {
    if (_saving) return;

    // Thùng đang mở mà còn serial thì đóng giúp: FA bấm "Đóng pallet" là đã
    // xong việc, bắt họ bấm thêm "Xong thùng" chỉ để mất hàng vừa quét.
    if (_boxOpen && _openSerials.isNotEmpty) _finishBox();
    if (_boxes.isEmpty) return;

    final ok = await showConfirmDialog(
      context,
      title: LocaleKeys.return_fa_confirm_title.tr(),
      message: _totalBad > 0
          ? LocaleKeys.return_fa_confirm_msg_bad.tr(namedArgs: {
              'ok': '$_totalOk',
              'bad': '$_totalBad',
              'docNo': widget.docNo,
            })
          : LocaleKeys.return_fa_confirm_msg.tr(namedArgs: {
              'count': '$_totalOk',
              'docNo': widget.docNo,
            }),
      confirmLabel: LocaleKeys.return_fa_confirm_ok.tr(),
      confirmVariant: AppButtonVariant.success,
    );
    if (!ok || !mounted) return;

    setState(() => _saving = true);
    try {
      // Lỗi API đã được appActionProvider bắt + toast → null. Trường hợp KHÔNG
      // con nào khớp thì server ném lỗi SAU KHI đã ghi nhật ký, nên danh sách
      // quét được giữ lại để FA soát chứ không xoá.
      final res = await ref.read(appActionProvider.notifier).run(
            () => ref.read(returnFaPalletRepositoryProvider).createPallet(
                  docId: widget.docId,
                  boxes: List<FaScanBox>.from(_boxes),
                ),
          );
      if (!mounted || res == null) {
        // Nhật ký có thể đã được ghi dù request lỗi → tải lại cho đúng.
        ref.invalidate(faMismatchesProvider(widget.docId));
        return;
      }

      setState(() {
        _last = res;
        _changed = true;
        // Chỉ xoá khi server ĐÃ nhận: xoá trước rồi gọi hỏng là FA quét lại cả
        // pallet.
        _boxes.clear();
      });

      ref.invalidate(faSerialIndexProvider(widget.docId));
      ref.invalidate(faMismatchesProvider(widget.docId));

      await _printOrOffer(res);
      if (!mounted) return;

      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_fa_done.tr(namedArgs: {
          'lotNo': res.lotNo,
          'count': '${res.serialCount}',
        }),
      );
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  /// In tem pallet mới. Dùng [QrLabelData] để QR vẫn là 12 ký tự Pallet ID còn
  /// RW/RB đi thành badge riêng — cùng lớp tem với mục 2a và màn Chi tiết pallet.
  Future<void> _printOrOffer(FaPalletResult res) async {
    final badge = QrLabelData.badgeForDisposition(widget.goodsType.code);
    final label = QrLabelData.pallet(res.lotNo, badge: badge);
    final subtitle = badge == null ? res.lotNo : '${res.lotNo} · $badge';

    final printed = await printLabel(ref, label);
    if (!mounted || printed) return;

    final retry = await AppDialogHelper.confirm(
      context,
      title: LocaleKeys.return_fa_print_failed_title.tr(),
      message: LocaleKeys.return_fa_print_failed_message
          .tr(namedArgs: {'lotNo': res.lotNo}),
      confirmText: LocaleKeys.return_fa_print_retry.tr(),
      cancelText: LocaleKeys.return_fa_print_later.tr(),
    );
    if (!mounted || !retry) return;

    // Dialog in có nút đổi máy (quét MAC) → ngưng listener của page.
    await _withScanPaused(() async {
      if (!mounted) return;
      await showLabelPrintDialog(
        context,
        title: LocaleKeys.label_print_title.tr(),
        subtitle: subtitle,
        label: label,
      );
    });
  }

  // ── Vẽ ────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final indexAsync = ref.watch(faSerialIndexProvider(widget.docId));
    final loading = indexAsync is! AsyncData<FaSerialIndex>;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) async {
        if (didPop) return;
        // Còn hàng đã quét chưa gửi: hỏi lại. Thoát im lặng là mất cả pallet
        // vừa quét mà không ai biết.
        if (_totalSerials > 0 && !_saving) {
          final leave = await showConfirmDialog(
            context,
            title: LocaleKeys.return_fa_leave_title.tr(),
            message: LocaleKeys.return_fa_leave_msg
                .tr(namedArgs: {'count': '$_totalSerials'}),
            confirmLabel: LocaleKeys.return_fa_leave_ok.tr(),
            confirmVariant: AppButtonVariant.danger,
          );
          if (!leave || !mounted) return;
        }
        if (mounted) Navigator.of(context).pop(_changed);
      },
      child: Scaffold(
        appBar: AppTopBar(
          title: LocaleKeys.return_fa_title.tr(),
          subtitle: widget.docNo,
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView(
                padding: const EdgeInsets.all(AppDimens.md),
                children: [
                  _Summary(
                    index: indexAsync is AsyncData<FaSerialIndex>
                        ? indexAsync.value
                        : null,
                    ok: _totalOk,
                    bad: _totalBad,
                    boxes: _boxes.length + (_boxOpen ? 1 : 0),
                  ),
                  const SizedBox(height: AppDimens.sm),

                  BarcodeScannerButton(
                    state: _saving || loading
                        ? ScannerState.loading
                        : ScannerState.scanning,
                    scanningLabel: _boxOpen
                        ? LocaleKeys.return_fa_scan_serial.tr()
                        : LocaleKeys.return_fa_scan_box.tr(),
                    loadingLabel: loading
                        ? LocaleKeys.return_fa_loading_index.tr()
                        : LocaleKeys.return_fa_saving.tr(),
                  ),
                  const SizedBox(height: 6),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(Icons.arrow_upward_rounded, size: 14, color: c.text3),
                      const SizedBox(width: 4),
                      Flexible(
                        child: Text(
                          _boxOpen
                              ? LocaleKeys.return_fa_hint_serial.tr()
                              : LocaleKeys.return_fa_hint_box.tr(),
                          textAlign: TextAlign.center,
                          style: AppTextStyles.caption.copyWith(color: c.text2),
                        ),
                      ),
                    ],
                  ),

                  // Giai đoạn mã thùng: cho mở thùng không mã.
                  if (!_boxOpen && !loading) ...[
                    const SizedBox(height: AppDimens.sm),
                    AppButton(
                      label: LocaleKeys.return_fa_btn_box_no_code.tr(),
                      variant: AppButtonVariant.neutral,
                      size: AppButtonSize.sm,
                      icon: Icons.inventory_2_outlined,
                      onPressed: _openBoxWithoutNo,
                    ),
                  ],

                  if (_boxOpen) ...[
                    const SizedBox(height: AppDimens.sm),
                    _OpenBox(
                      boxNo: _openBoxNo,
                      serials: _openSerials,
                      onRemove: _removeOpenSerial,
                      onFinish: _openSerials.isEmpty ? null : _finishBox,
                      onCancel: _cancelBox,
                      statusLabel: _statusLabel,
                    ),
                  ],

                  if (_boxes.isNotEmpty) ...[
                    const SizedBox(height: AppDimens.sm),
                    _DoneBoxes(boxes: _boxes, onRemove: _removeBox),
                  ],

                  if (_last case final r?) ...[
                    const SizedBox(height: AppDimens.sm),
                    _LastResult(result: r, statusLabel: _statusLabel),
                  ],
                ],
              ),
            ),

            // CTA ghim đáy màn: FA đeo găng, nút phải ở chỗ ngón tay tới được
            // mà không cuộn.
            Padding(
              padding: const EdgeInsets.all(AppDimens.md),
              child: AppButton(
                label: _totalSerials == 0
                    ? LocaleKeys.return_fa_btn_submit_empty.tr()
                    : LocaleKeys.return_fa_btn_submit
                        .tr(namedArgs: {'count': '$_totalSerials'}),
                variant: AppButtonVariant.success,
                size: AppButtonSize.lg,
                icon: Icons.inventory_2_outlined,
                isLoading: _saving,
                onPressed: _totalSerials == 0 || loading ? null : _submit,
              ),
            ),
          ],
        ),
      ),
    );
  }

  /// Nhãn trạng thái serial. Mã lạ từ server thì hiện nguyên mã thay vì chuỗi
  /// rỗng — FA đọc được "ng" còn hơn đọc được khoảng trắng.
  String _statusLabel(String? status) => switch (status) {
        'received' => LocaleKeys.return_fa_status_received.tr(),
        'at_fa' => LocaleKeys.return_fa_status_at_fa.tr(),
        'returned' => LocaleKeys.return_fa_status_returned.tr(),
        'shipped' => LocaleKeys.return_fa_status_shipped.tr(),
        'ng' => LocaleKeys.return_fa_status_ng.tr(),
        _ => status ?? '—',
      };
}

// ── Các khối nhỏ ────────────────────────────────────────────

/// Số liệu: sổ đã tải bao nhiêu con, còn bao nhiêu ở FA, lượt này quét được gì.
class _Summary extends StatelessWidget {
  const _Summary({
    required this.index,
    required this.ok,
    required this.bad,
    required this.boxes,
  });

  final FaSerialIndex? index;
  final int ok;
  final int bad;
  final int boxes;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (index == null)
            Row(
              children: [
                const SizedBox(
                  width: 14,
                  height: 14,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
                const SizedBox(width: 8),
                Text(
                  LocaleKeys.return_fa_loading_index.tr(),
                  style: AppTextStyles.caption.copyWith(color: c.text2),
                ),
              ],
            )
          else
            Text(
              LocaleKeys.return_fa_index_loaded.tr(namedArgs: {
                'total': '${index!.length}',
                'atFa': '${index!.atFaCount}',
              }),
              style: AppTextStyles.caption.copyWith(color: c.text2),
            ),
          const SizedBox(height: 6),
          Wrap(
            spacing: 6,
            runSpacing: 6,
            children: [
              StatusPill.success(
                context,
                label: LocaleKeys.return_fa_pill_ok
                    .tr(namedArgs: {'n': '$ok'}),
              ),
              if (bad > 0)
                StatusPill.warning(
                  context,
                  label: LocaleKeys.return_fa_pill_bad
                      .tr(namedArgs: {'n': '$bad'}),
                ),
              StatusPill.info(
                context,
                label: LocaleKeys.return_fa_pill_boxes
                    .tr(namedArgs: {'n': '$boxes'}),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Thùng đang mở: danh sách serial vừa quét, tô màu theo kết luận tra sổ.
class _OpenBox extends StatelessWidget {
  const _OpenBox({
    required this.boxNo,
    required this.serials,
    required this.onRemove,
    required this.onFinish,
    required this.onCancel,
    required this.statusLabel,
  });

  final String? boxNo;
  final List<FaScannedSerial> serials;
  final void Function(int) onRemove;
  final VoidCallback? onFinish;
  final VoidCallback onCancel;
  final String Function(String?) statusLabel;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            boxNo == null
                ? LocaleKeys.return_fa_open_box_no_code.tr()
                : LocaleKeys.return_fa_open_box.tr(namedArgs: {'box': boxNo!}),
            style: AppTextStyles.bodyStrong.copyWith(color: c.text1),
          ),
          const SizedBox(height: 6),
          if (serials.isEmpty)
            Text(
              LocaleKeys.return_fa_open_box_empty.tr(),
              style: AppTextStyles.caption.copyWith(color: c.text3),
            )
          else
            for (var i = 0; i < serials.length; i++)
              _SerialRow(
                item: serials[i],
                statusLabel: statusLabel,
                onRemove: () => onRemove(i),
              ),
          const SizedBox(height: AppDimens.sm),
          Row(
            children: [
              Expanded(
                child: AppButton(
                  label: LocaleKeys.return_fa_btn_finish_box.tr(),
                  variant: AppButtonVariant.primary,
                  size: AppButtonSize.sm,
                  icon: Icons.check,
                  onPressed: onFinish,
                ),
              ),
              const SizedBox(width: 6),
              AppButton(
                label: LocaleKeys.return_fa_btn_cancel_box.tr(),
                variant: AppButtonVariant.danger,
                size: AppButtonSize.sm,
                onPressed: onCancel,
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _SerialRow extends StatelessWidget {
  const _SerialRow({
    required this.item,
    required this.statusLabel,
    this.onRemove,
  });

  final FaScannedSerial item;
  final String Function(String?) statusLabel;
  final VoidCallback? onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    // Màu theo kết luận: xanh vào được pallet, cam sai trạng thái, đỏ lạ hẳn.
    final (Color tone, IconData icon) = switch (item.verdict) {
      FaScanVerdict.ok => (c.success, Icons.check_circle_outline),
      FaScanVerdict.wrongStatus => (c.warning, Icons.error_outline),
      FaScanVerdict.unknown => (c.danger, Icons.help_outline),
    };

    final note = switch (item.verdict) {
      FaScanVerdict.ok => item.model,
      FaScanVerdict.wrongStatus =>
        '${item.model ?? ''} · ${statusLabel(item.foundStatus)}',
      FaScanVerdict.unknown => LocaleKeys.return_fa_note_unknown.tr(),
    };

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 2),
      child: Row(
        children: [
          Icon(icon, size: 16, color: tone),
          const SizedBox(width: 6),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.serial,
                  style: AppTextStyles.body.copyWith(color: c.text1),
                  overflow: TextOverflow.ellipsis,
                ),
                if (note != null && note.trim().isNotEmpty)
                  Text(
                    note,
                    style: AppTextStyles.caption.copyWith(color: tone),
                    overflow: TextOverflow.ellipsis,
                  ),
              ],
            ),
          ),
          if (onRemove != null)
            IconButton(
              icon: const Icon(Icons.close, size: 16),
              visualDensity: VisualDensity.compact,
              tooltip: LocaleKeys.return_fa_remove_serial.tr(),
              onPressed: onRemove,
            ),
        ],
      ),
    );
  }
}

/// Các thùng đã đóng xong, chờ gửi.
class _DoneBoxes extends StatelessWidget {
  const _DoneBoxes({required this.boxes, required this.onRemove});

  final List<FaScanBox> boxes;
  final void Function(int) onRemove;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            LocaleKeys.return_fa_done_boxes
                .tr(namedArgs: {'n': '${boxes.length}'}),
            style: AppTextStyles.bodyStrong.copyWith(color: c.text1),
          ),
          const SizedBox(height: 4),
          for (var i = 0; i < boxes.length; i++)
            Padding(
              padding: const EdgeInsets.symmetric(vertical: 2),
              child: Row(
                children: [
                  Icon(Icons.inventory_2_outlined, size: 16, color: c.text3),
                  const SizedBox(width: 6),
                  Expanded(
                    child: Text(
                      boxes[i].boxNo ??
                          LocaleKeys.return_fa_box_auto
                              .tr(namedArgs: {'n': '${i + 1}'}),
                      style: AppTextStyles.body.copyWith(color: c.text1),
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  Text(
                    LocaleKeys.return_fa_box_counts.tr(namedArgs: {
                      'ok': '${boxes[i].okCount}',
                      'bad': '${boxes[i].badCount}',
                    }),
                    style: AppTextStyles.caption.copyWith(color: c.text2),
                  ),
                  IconButton(
                    icon: const Icon(Icons.close, size: 16),
                    visualDensity: VisualDensity.compact,
                    tooltip: LocaleKeys.return_fa_remove_box.tr(),
                    onPressed: () => onRemove(i),
                  ),
                ],
              ),
            ),
        ],
      ),
    );
  }
}

/// Kết quả lượt vừa đóng: Pallet ID + nhật ký lệch CÒN MỞ của cả phiếu.
class _LastResult extends StatelessWidget {
  const _LastResult({required this.result, required this.statusLabel});

  final FaPalletResult result;
  final String Function(String?) statusLabel;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.check_circle, size: 18, color: c.success),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  result.lotNo,
                  style: AppTextStyles.bodyStrong.copyWith(color: c.text1),
                ),
              ),
            ],
          ),
          const SizedBox(height: 4),
          Text(
            LocaleKeys.return_fa_result_counts.tr(namedArgs: {
              'serials': '${result.serialCount}',
              'boxes': '${result.boxCount}',
            }),
            style: AppTextStyles.caption.copyWith(color: c.text2),
          ),

          if (result.mismatches.isNotEmpty) ...[
            const SizedBox(height: AppDimens.sm),
            Text(
              LocaleKeys.return_fa_mismatch_title
                  .tr(namedArgs: {'n': '${result.mismatches.length}'}),
              style: AppTextStyles.bodyStrong.copyWith(color: c.warning),
            ),
            const SizedBox(height: 2),
            Text(
              LocaleKeys.return_fa_mismatch_hint.tr(),
              style: AppTextStyles.caption.copyWith(color: c.text2),
            ),
            const SizedBox(height: 4),
            for (final m in result.mismatches)
              Padding(
                padding: const EdgeInsets.symmetric(vertical: 2),
                child: Row(
                  children: [
                    Icon(Icons.error_outline, size: 15, color: c.warning),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            m.serial,
                            style: AppTextStyles.body.copyWith(color: c.text1),
                            overflow: TextOverflow.ellipsis,
                          ),
                          Text(
                            _reasonText(m),
                            style:
                                AppTextStyles.caption.copyWith(color: c.text2),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
              ),
          ],
        ],
      ),
    );
  }

  String _reasonText(FaMismatch m) => switch (m.reason) {
        'other_doc' => LocaleKeys.return_fa_reason_other_doc
            .tr(namedArgs: {'docNo': m.otherDocNo ?? '—'}),
        'wrong_status' => LocaleKeys.return_fa_reason_wrong_status
            .tr(namedArgs: {'status': statusLabel(m.foundStatus)}),
        _ => LocaleKeys.return_fa_reason_not_in_doc.tr(),
      };
}
