using Dapper;
using Swms.FinishGoods.API.Features.WeightSys.PalletSync.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Text.Json;

namespace Swms.FinishGoods.API.Features.WeightSys.PalletSync.DataAccess;

public class PalletWeightRepository : IPalletWeightRepository
{
    private readonly IDbConnectionFactory _factory;

    public PalletWeightRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    public async Task<IReadOnlyList<SerialItem>>
    GetSerialForWeightSyncAsync(string palletId)
    {
        const string sql = """
            SELECT
                b.id AS BoxId,
                bl.serial_no AS Serial,
                bl.model AS Model
            FROM wms.box_lines bl
            JOIN wms.boxes b
                ON b.id = bl.box_id
                AND b.is_deleted = 0
            JOIN wms.pallets p
                ON p.id = b.lot_id
                AND p.is_deleted = 0
            WHERE p.pallet_id = @PalletId
              AND bl.is_deleted = 0;
            """;

        using var conn = _factory.Create();

        var rows = await conn.QueryAsync<SerialItem>(
            sql,
            new { PalletId = palletId });

        return rows.ToList();
    }


    public async Task<int> UpdateBoxWeightAsync(
        long boxId,
        decimal weight,
        string? user)
    {
        const string sql = """
            UPDATE wms.boxes
            SET weight = @Weight,
                updated_at = SYSDATETIME(),
                updated_by = @User
            WHERE id = @BoxId
              AND is_deleted = 0;
            """;

        using var conn = _factory.Create();

        return await conn.ExecuteAsync(
            sql,
            new
            {
                BoxId = boxId,
                Weight = weight,
                User = user
            });
    }

    public async Task<int> UpdateBoxWeightsAsync(
    IReadOnlyDictionary<long, decimal> weights,
    string? user)
    {
        if (weights.Count == 0)
            return 0;

        const string sql = """
            UPDATE b
            SET b.weight = j.weight,
                b.updated_at = SYSDATETIME(),
                b.updated_by = @User
            FROM wms.boxes b
            JOIN OPENJSON(@Items)
            WITH
            (
                box_id bigint '$.box_id',
                weight decimal(18,3) '$.weight'
            ) j
                ON j.box_id = b.id
            WHERE b.is_deleted = 0;
            """;

        var items = JsonSerializer.Serialize(
            weights.Select(x => new
            {
                box_id = x.Key,
                weight = x.Value
            }));

        using var conn = _factory.Create();

        return await conn.ExecuteAsync(
            sql,
            new
            {
                Items = items,
                User = user
            });
    }
}