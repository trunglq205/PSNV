using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Features.Models.Client;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Client;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.Auth;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.App.Pages;

/// <summary>
/// Màn quản lý chỉ thị back hàng — mục 1 của quy trình return / refurbish.
///
/// SCS Office nhập model + SL khách báo trả về; tạo xong hệ thống tự gửi mail
/// báo FA (người nhận khai trong màn Cấu hình email, sự kiện
/// <c>RETURN_INSTRUCTION_CREATED</c>). SCS WH xem cùng dữ liệu này trên PDA.
///
/// MÀN NÀY CÕNG CẢ MỤC 2C — luồng nhận lại hàng về FA, ba bước trên chính
/// phiếu. Một màn cho cả ba bên (FA, quản lý FA, SCS WH), tách việc bằng bộ lọc
/// hàng đợi + quyền trên từng nút. Không dựng màn riêng: sau khi gộp thì đề
/// nghị back LÀ một mặt của phiếu, hai màn là hai nơi nhìn cùng một dòng.
/// </summary>
public partial class ReworkRefurbish
{
    [Inject] private IReturnInstructionApi Api { get; set; } = default!;
    [Inject] private IModelApi ModelApi { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private PermissionState Perm { get; set; } = default!;
    [Inject] private NavigationManager Nav { get; set; } = default!;

    /// <summary>null = tất cả. Thứ tự tab trên màn hình.</summary>
    private static readonly string?[] StatusTabs =
        { ReturnDocStatus.Open, ReturnDocStatus.Completed, ReturnDocStatus.Cancelled, null };

    private List<ReturnInstructionDto> _rows = new();
    private List<string> _models = new();

    /// <summary>
    /// Pallet hàng return theo từng phiếu, nạp LAZY khi bung dòng: danh sách
    /// phiếu có thể vài trăm dòng, nạp pallet của tất cả ngay từ đầu là vài
    /// trăm request cho thứ người dùng chỉ xem một hai phiếu.
    /// Không có khoá trong dictionary = đang nạp.
    /// </summary>
    private readonly Dictionary<long, List<ReturnPalletDto>> _pallets = new();

    private bool _loading = true;
    private string? _error;

    private string? _status = ReturnDocStatus.Open;
    private string _goodsType = "";
    private string _keyword = "";
    private DateTime? _fromDate;
    private DateTime? _toDate;

    /// <summary>
    /// Phiếu đang mở dialog chi tiết. null = không mở.
    ///
    /// Giữ cả DTO chứ không chỉ id: dialog vẽ ngay từ dữ liệu đã có trong danh
    /// sách, không phải gọi lại API chỉ để lấy đúng dòng vừa bấm.
    /// </summary>
    private ReturnInstructionDto? _detail;

    // ── Menu thao tác của từng dòng ──
    //
    // Một phiếu có thể mở tới 6 nút cùng lúc (chốt thực nhận · sửa · xoá ·
    // đề nghị nhận lại · xác nhận · giao hàng · huỷ). Bày hết ra cột cuối thì
    // bảng bị đẩy ngang và mỗi dòng cao gấp đôi, nên gom vào một menu.
    //
    // Giữ ID chứ không giữ bool: chỉ MỘT menu được mở tại một thời điểm —
    // mỗi dòng một cờ riêng thì mở dòng này không đóng dòng kia, và người dùng
    // thấy hai menu chồng nhau.
    private long? _menu;

    private void ToggleMenu(long id) => _menu = _menu == id ? null : id;

    private void CloseMenu() => _menu = null;

    // Điều kiện của từng mục. Tách ra thành hàm chứ không viết thẳng trong
    // markup: mỗi điều kiện dùng HAI lần (một lần quyết định có hiện mục đó,
    // một lần quyết định có hiện cả NHÓM) — viết hai lần là sớm muộn lệch.

    /// <summary>
    /// Chốt thực nhận: chỉ khi đã nhận được hàng — chốt phiếu trống là gửi FA
    /// bảng toàn số 0.
    ///
    /// SCS WH <c>hoặc</c> SCS Office, khớp <c>RequireAnyPermission&lt;Process,
    /// Create&gt;</c> ở controller và <c>_mayClose</c> bên PDA: WH chốt tại máy
    /// PDA ngay lúc quét xong, Office chốt trên Web khi WH báo miệng. Trước đây
    /// chỗ này chỉ xét <c>MayCreate</c>, nên user SCS WH gọi được API và thấy
    /// nút trên PDA mà trên Web lại không có mục nào — lệch gương ba bên.
    /// </summary>
    private bool CanCloseDoc(ReturnInstructionDto d)
        => (MayCreate || MayProcess) && d.IsOpen && d.HasReceipt;

    private bool CanEditDoc(ReturnInstructionDto d) => MayCreate && d.IsOpen;

    private bool CanDeleteDoc(ReturnInstructionDto d) => MayCreate && d.IsOpen;

    private bool CanReopenDoc(ReturnInstructionDto d) => MayCreate && d.IsCompleted;

    /// <summary>Nhóm "Phiếu chỉ thị" có mục nào không.</summary>
    private bool AnyDocAction(ReturnInstructionDto d)
        => CanCloseDoc(d) || CanEditDoc(d) || CanDeleteDoc(d) || CanReopenDoc(d);

    /// <summary>Nhóm "Nhận lại hàng" có mục nào không.</summary>
    private bool AnyBackAction(ReturnInstructionDto d)
        => CanRequestBack(d) || CanEditBackNote(d) || CanApproveBack(d)
           || CanApproveBackScs(d) || CanCancelBack(d);

    /// <summary>
    /// Không có mục nào thì KHÔNG dựng nút ba chấm: một nút bấm vào hiện menu
    /// rỗng còn khó chịu hơn là không có nút.
    /// </summary>
    private bool HasAnyAction(ReturnInstructionDto d)
        => AnyDocAction(d) || AnyBackAction(d);

    // ── Bộ lọc hàng đợi của luồng back ──
    //
    // Lọc ở CLIENT, không thêm tham số cho API: dữ liệu đã tải đủ, mà đếm số
    // trên từng mục thì buộc phải có toàn bộ — gọi API cho từng mục sẽ thành
    // năm lượt gọi chỉ để vẽ năm con số.
    //
    // Dùng <select> chứ không thêm một hàng tab nữa: hàng tab trên đã dành cho
    // trạng thái phiếu, hai hàng tab cạnh nhau thì không ai biết cái nào lọc gì.

    /// <summary>"" = không lọc theo luồng back.</summary>
    private string _backFilter = "";

    /// <summary>Giá trị bộ lọc. Thứ tự đúng thứ tự hiện trên màn.</summary>
    private static readonly string[] BackFilters =
        { "", "none", BackStep.FaApprove, BackStep.ScsApprove, BackStep.ScsDeliver, "delivered" };

    private static bool MatchBack(ReturnInstructionDto d, string filter) => filter switch
    {
        "" => true,
        "none" => !d.Back.Requested || d.Back.IsCancelled,
        "delivered" => d.Back.IsDelivered,
        var step => d.Back.IsOpen && d.Back.Step == step,
    };

    /// <summary>Dòng sau khi lọc hàng đợi back.</summary>
    private List<ReturnInstructionDto> Rows
        => _backFilter.Length == 0
            ? _rows
            : _rows.Where(d => MatchBack(d, _backFilter)).ToList();

    private int BackCount(string filter) => _rows.Count(d => MatchBack(d, filter));

    private void SetBackFilter(ChangeEventArgs e)
    {
        CloseMenu();
        _backFilter = e.Value?.ToString() ?? "";
        // Phiếu đang mở dialog gần như chắc chắn không thuộc mục mới — đóng
        // lại để không còn một dialog nói về dòng đã biến mất khỏi bảng.
        if (_detail is { } d && Rows.All(r => r.Id != d.Id)) _detail = null;
    }

    // ── form tạo / sửa ──────────────────────────────────────
    private ReturnInstructionRequestDto? _form;
    private long? _editId;
    private string? _editDocNo;
    private string? _formError;
    private bool _saving;

    private ReturnInstructionDto? _deleting;

    /// <summary>Pallet đang chờ xác nhận huỷ lần nhận, kèm phiếu của nó.</summary>
    private (ReturnInstructionDto Doc, ReturnPalletDto Pallet)? _releasing;

    /// <summary>Phiếu đang chờ xác nhận chốt thực nhận (dialog hiện bảng lệch).</summary>
    private ReturnInstructionDto? _closing;

    /// <summary>Phiếu đang chờ xác nhận mở lại.</summary>
    private ReturnInstructionDto? _reopening;

    private bool MayCreate => Perm.Has(Perms.rework_refurbish_create.Key());

    // ── Quyền của luồng nhận lại hàng (mục 2c) ──
    // GIỮ KHỚP TỪNG DÒNG với attribute trên ReturnBackFlowController. Lệch một
    // chỗ là hoặc thấy nút rồi ăn 403, hoặc có quyền mà không thấy nút — cả hai
    // đều khó lần ra vì Has() trả false IM LẶNG.

    /// <summary>B1 — FA đề nghị / sửa ghi chú.</summary>
    private bool MayRequestBack => Perm.Has(Perms.rework_refurbish_request_back.Key());

    /// <summary>B2 — quản lý FA xác nhận.</summary>
    private bool MayApproveFa => Perm.Has(Perms.rework_refurbish_approve_fa.Key());

    /// <summary>B3 — quản lý SCS xác nhận (thêm 10/11).</summary>
    private bool MayApproveScs => Perm.Has(Perms.rework_refurbish_approve_scs.Key());

    /// <summary>B4 — SCS WH quét pallet giao hàng.</summary>
    private bool MayProcess => Perm.Has(Perms.rework_refurbish_process.Key());

    // Nút = QUYỀN **AND** ĐÚNG BƯỚC. Lớp "đúng bước" là thứ làm cho xác nhận có
    // nghĩa: role khai sai cũng không nhảy được bước, và server còn chặn lần
    // nữa bằng điều kiện bước nằm trong câu UPDATE.

    private bool CanRequestBack(ReturnInstructionDto d)
        => MayRequestBack && d.Back.CanRequest;

    /// <summary>Sửa ghi chú: chỉ FA, chỉ khi còn chờ quản lý FA.</summary>
    private bool CanEditBackNote(ReturnInstructionDto d)
        => MayRequestBack && d.Back.Status == BackStatus.FaRequested;

    private bool CanApproveBack(ReturnInstructionDto d)
        => MayApproveFa && d.Back.Status == BackStatus.FaRequested;

    /// <summary>B3 — quản lý SCS xác nhận. Chỉ khi quản lý FA đã duyệt.</summary>
    private bool CanApproveBackScs(ReturnInstructionDto d)
        => MayApproveScs && d.Back.Status == BackStatus.FaApproved;

    // CanDeliverBack đã XOÁ (11/11): web không còn nút giao hàng. Cờ
    // Back.CanDeliver vẫn còn trong response và vẫn dùng — nhưng để trả lời
    // "hàng đã được phép out kho chưa", hiển thị ở bước 7 của process, chứ
    // không còn gác một nút bấm nào.

    /// <summary>
    /// Huỷ: ai đang giữ bước cũng phải dừng được, không phải chờ bên kia.
    /// ĐÃ GIAO ĐƯỢC CON NÀO thì KHÔNG huỷ — hàng ở FA rồi, huỷ là để lại một lô
    /// hàng ở FA mà không có đề nghị nào đứng tên.
    /// </summary>
    private bool CanCancelBack(ReturnInstructionDto d)
        => d.Back.IsOpen && !d.Back.IsPartlyDelivered
           && (MayRequestBack || MayApproveFa || MayApproveScs || MayProcess);

    /// <summary>
    /// Quyền sửa cấu hình email là quyền HỆ THỐNG (<c>email_config.update</c>),
    /// không phải quyền của màn này — ai sửa được mail của module khác thì cũng
    /// sửa được ở đây. Cùng cách với màn Hàng bất thường.
    /// </summary>
    private bool MayEmailConfig => Perm.Has(Perms.email_config_update.Key());

    /// <summary>Dialog cấu hình 2 mail của quy trình back hàng.</summary>
    private bool _mailCfgOpen;

    private int FormTotalQty => _form?.Lines.Sum(l => l.Qty) ?? 0;

    /// <summary>
    /// Ngày về dự kiến tách riêng khỏi DTO: input type=date bind vào
    /// <c>DateTime?</c> được, nhưng để nguyên trong DTO thì phần giờ của
    /// DateTime.MinValue lọt xuống API. Gán lại lúc Lưu.
    /// </summary>
    private DateTime? _formExpectedDate;

    protected override async Task OnInitializedAsync()
    {
        // Mail báo FA mang link kèm ?docNo=... — mở link là lọc sẵn đúng phiếu,
        // người nhận không phải tự tìm trong danh sách.
        if (QueryHelpers.ParseQuery(new Uri(Nav.Uri).Query).TryGetValue("docNo", out var docNo))
        {
            _keyword = docNo.ToString();
            _status = null;                 // phiếu có thể đã đóng
        }

        await LoadModels();
        await Load();
    }

    /// <summary>
    /// Trang lấy mỗi lần khi nạp danh mục model. Cùng giá trị với
    /// <c>PartCards.MasterFetchSize</c> — hai màn cùng nạp toàn bộ danh mục
    /// nên dùng chung một cỡ trang để hành vi giống nhau.
    /// </summary>
    private const int ModelFetchSize = 9999;

    /// <summary>
    /// Nạp mã model một lần cho datalist, thay vì gọi lại server theo từng ký
    /// tự gõ: danh mục model của nhà máy cỡ vài nghìn dòng, tải một lần rẻ hơn
    /// nhiều so với một request mỗi lần gõ.
    ///
    /// Lặp theo trang cho tới khi hết, đúng cách <c>PartCards</c> đang làm:
    /// xin một trang thật lớn rồi tin là đã lấy hết là sai khi danh mục vượt
    /// cỡ trang, và lỗi đó im lặng — vài model cuối bảng chữ cái đơn giản là
    /// không gợi ý được.
    /// </summary>
    private async Task LoadModels()
    {
        var codes = new List<string>();
        try
        {
            for (var page = 1; ; page++)
            {
                // PagedQuery dùng tên `Size`, KHÔNG phải `PageSize`.
                var res = await ModelApi.GetAllAsync(
                    new ModelQuery { Page = page, Size = ModelFetchSize });

                var items = res.Items;
                if (items is null || items.Count == 0) break;

                codes.AddRange(items.Select(m => m.Code).Where(c => !string.IsNullOrWhiteSpace(c)));

                if (items.Count < ModelFetchSize) break;
            }
        }
        catch
        {
            // Datalist chỉ là gợi ý gõ nhanh. Tải hỏng thì vẫn nhập tay được,
            // và server vẫn kiểm model có trong danh mục hay không — nên nuốt
            // lỗi ở đây thay vì chặn cả màn hình.
        }

        _models = codes.Distinct(StringComparer.OrdinalIgnoreCase)
                       .OrderBy(c => c, StringComparer.OrdinalIgnoreCase)
                       .ToList();
    }

    private void SetStatus(string? s) { _status = s; _ = Load(); }

    private async Task OnKeywordKey(Microsoft.AspNetCore.Components.Web.KeyboardEventArgs e)
    {
        if (e.Key == "Enter") await Load();
    }

    private async Task Load()
    {
        _loading = true; _error = null; CloseMenu(); StateHasChanged();
        try
        {
            _rows = await Api.GetListAsync(
                status: _status,
                goodsType: string.IsNullOrWhiteSpace(_goodsType) ? null : _goodsType,
                keyword: string.IsNullOrWhiteSpace(_keyword) ? null : _keyword.Trim(),
                fromDate: _fromDate,
                toDate: _toDate);

            // Dialog đang mở mà phiếu biến mất khỏi kết quả lọc thì đóng lại.
            // Còn nếu vẫn còn, TRỎ LẠI vào bản ghi mới: giữ DTO cũ là dialog
            // hiện số liệu trước lúc tải lại, mà Load() thường được gọi ngay
            // sau một thao tác vừa làm đổi chính những số đó.
            if (_detail is { } d)
                _detail = _rows.FirstOrDefault(r => r.Id == d.Id);

            // Ba bảng con nạp lazy — xoá cache để lần mở sau đọc lại số mới.
            _pallets.Clear();
            _backDeliveries.Clear();
            _mismatches.Clear();
            if (_detail is { } stillOpen)
            {
                _ = LoadPallets(stillOpen.Id);
                _ = LoadBackDeliveries(stillOpen.Id);
                _ = LoadMismatches(stillOpen.Id);
            }
        }
        catch (Exception ex) { _error = Describe(ex); }
        finally { _loading = false; StateHasChanged(); }
    }

    /// <summary>
    /// Mở dialog chi tiết phiếu.
    ///
    /// Dialog chứ không bung dòng tại chỗ (đổi 11/11): chi tiết gồm sáu khối
    /// (dòng chỉ thị · pallet · timeline · nhật ký giao · nhật ký lệch · ghi
    /// chú), nhét vào một ô `colspan` thì dòng dưới bị đẩy xuống cả màn hình và
    /// người đọc mất luôn ngữ cảnh bảng. Cùng khuôn với màn Hàng bất thường.
    ///
    /// Ba bảng con nạp SONG SONG và không await: dialog mở ra ngay với phần đã
    /// có sẵn trong `doc`, ba khối kia tự hiện khi về. Chờ cả ba rồi mới mở là
    /// một khoảng đứng hình mà không có gì để nhìn.
    /// </summary>
    private void OpenDetail(ReturnInstructionDto d)
    {
        CloseMenu();
        _detail = d;
        _ = LoadPallets(d.Id);
        _ = LoadBackDeliveries(d.Id);
        _ = LoadMismatches(d.Id);
    }

    private void CloseDetail() => _detail = null;

    /// <summary>
    /// Pallet của một phiếu. Nạp lại mỗi lần bung: WH đang quét hàng trong lúc
    /// Office mở màn này, cache lại là Office nhìn số cũ mà không biết.
    /// Lỗi thì coi như không có pallet — không chặn cả màn hình vì một bảng con.
    /// </summary>
    private async Task LoadPallets(long docId)
    {
        _pallets.Remove(docId);
        StateHasChanged();
        try
        {
            _pallets[docId] = await Api.GetPalletsAsync(docId);
        }
        catch
        {
            _pallets[docId] = new List<ReturnPalletDto>();
        }
        StateHasChanged();
    }

    // ── tạo / sửa ───────────────────────────────────────────

    private void OpenCreate()
    {
        _editId = null;
        _editDocNo = null;
        _formError = null;
        _formExpectedDate = null;
        // Mặc định theo tab loại đang lọc: người dùng đang xem Rework thì
        // gần như chắc chắn đang tạo phiếu Rework.
        _form = new ReturnInstructionRequestDto
        {
            GoodsType = string.IsNullOrWhiteSpace(_goodsType) ? ReturnGoodsType.Rework : _goodsType,
        };
        AddLine();
    }

    private void OpenEdit(ReturnInstructionDto d)
    {
        CloseMenu();
        _editId = d.Id;
        _editDocNo = d.DocNo;
        _formError = null;
        _formExpectedDate = d.ExpectedDate;
        _form = new ReturnInstructionRequestDto
        {
            GoodsType = d.GoodsType,
            Customer = d.Customer,
            Note = d.Note,
            // COPY sang object mới, không trỏ thẳng vào _rows: người dùng sửa
            // rồi bấm Huỷ thì bảng nền phải nguyên như cũ.
            Lines = d.Lines.Select(l => new ReturnInstructionLineRequestDto
            {
                Model = l.Model,
                Qty = l.Qty,
                Note = l.Note,
            }).ToList(),
        };
        if (_form.Lines.Count == 0) AddLine();
    }

    private void CloseForm() { _form = null; _formError = null; }

    private void AddLine() => _form?.Lines.Add(new ReturnInstructionLineRequestDto { Qty = 1 });

    private void RemoveLine(int idx)
    {
        if (_form is null || idx < 0 || idx >= _form.Lines.Count) return;
        _form.Lines.RemoveAt(idx);
        // Luôn chừa lại một dòng trống: bảng rỗng trông như hỏng, và người
        // dùng phải đi tìm nút Thêm dòng.
        if (_form.Lines.Count == 0) AddLine();
    }

    private async Task Save()
    {
        if (_form is null) return;

        // Kiểm sơ ở client để người dùng khỏi chờ một vòng mạng mới biết
        // thiếu ô. Server vẫn kiểm lại đầy đủ — đây chỉ là lớp cho nhanh.
        var lines = _form.Lines
            .Where(l => !string.IsNullOrWhiteSpace(l.Model))
            .ToList();

        if (lines.Count == 0) { _formError = L["Return.Err.LinesRequired"]; return; }
        if (lines.Any(l => l.Qty <= 0)) { _formError = L["Return.Err.QtyPositive"]; return; }

        // Loại hàng đã ở đầu phiếu nên trùng chỉ còn xét theo model.
        var dup = lines.GroupBy(l => l.Model.Trim().ToUpperInvariant())
                       .FirstOrDefault(g => g.Count() > 1);
        if (dup is not null)
        {
            _formError = L["Return.Err.DuplicateLine", dup.First().Model];
            return;
        }

        _saving = true; _formError = null; StateHasChanged();
        try
        {
            var body = new ReturnInstructionRequestDto
            {
                GoodsType = _form.GoodsType,
                Customer = _form.Customer,
                ExpectedDate = _formExpectedDate?.Date,
                Note = _form.Note,
                Lines = lines.Select(l => new ReturnInstructionLineRequestDto
                {
                    Model = l.Model.Trim(),
                    Qty = l.Qty,
                    Note = string.IsNullOrWhiteSpace(l.Note) ? null : l.Note.Trim(),
                }).ToList(),
            };

            if (_editId is { } id) await Api.UpdateAsync(id, body);
            else await Api.CreateAsync(body);

            _form = null;
            await Load();
        }
        catch (Exception ex) { _formError = Describe(ex); }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── xoá ─────────────────────────────────────────────────

    private void AskDelete(ReturnInstructionDto d)
    {
        CloseMenu();
        _deleting = d;
    }

    private async Task ConfirmDelete()
    {
        if (_deleting is null) return;
        _saving = true; StateHasChanged();
        try
        {
            await Api.DeleteAsync(_deleting.Id);
            _deleting = null;
            await Load();
        }
        catch (Exception ex) { _error = Describe(ex); _deleting = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── chốt thực nhận / mở lại (mục 2b) ────────────────────

    private void AskClose(ReturnInstructionDto d)
    {
        CloseMenu();
        _closing = d;
    }

    private void AskReopen(ReturnInstructionDto d)
    {
        CloseMenu();
        _reopening = d;
    }

    /// <summary>
    /// Chốt thực nhận. Server đóng phiếu RỒI tự gửi mail báo FA số thực tế —
    /// nên dialog phải cho người bấm xem bảng lệch trước, vì đó chính là nội
    /// dung FA sẽ đọc.
    /// </summary>
    private async Task ConfirmClose()
    {
        if (_closing is null) return;

        _saving = true; StateHasChanged();
        try
        {
            var saved = await Api.CloseAsync(_closing.Id);
            _closing = null;
            await Load();

            // Mail hỏng KHÔNG làm đổ việc chốt — nói ra để Office biết mà xử
            // lý tay, thay vì tưởng FA đã nhận được số.
            if (saved.ActualMailSentAt is null)
                _error = L["Return.ClosedButMailFailed", saved.DocNo];
        }
        catch (Exception ex) { _error = Describe(ex); _closing = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    private async Task ConfirmReopen()
    {
        if (_reopening is null) return;

        _saving = true; StateHasChanged();
        try
        {
            await Api.ReopenAsync(_reopening.Id);
            _reopening = null;
            await Load();
        }
        catch (Exception ex) { _error = Describe(ex); _reopening = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── hiển thị lệch ───────────────────────────────────────

    /// <summary>Số lệch kèm dấu: <c>+6</c> / <c>-6</c> / <c>0</c>.</summary>
    private static string Signed(int qty) => qty > 0 ? $"+{qty:N0}" : qty.ToString("N0");

    private static string DiffClass(int qty) =>
        qty > 0 ? "ri-over" : qty < 0 ? "ri-short" : "ri-done";

    private static string DiffPill(int qty) =>
        qty > 0 ? "warn" : qty < 0 ? "st-short" : "ok";

    private string DiffState(int qty) =>
        qty > 0 ? L["Return.Diff.Over"]
        : qty < 0 ? L["Return.Diff.Short"]
        : L["Return.Diff.Exact"];

    // ── huỷ một lần nhận ────────────────────────────────────

    private void AskReleasePallet(ReturnInstructionDto doc, ReturnPalletDto pallet)
    {
        _releasing = (doc, pallet);
        _formError = null;
    }

    private void CloseRelease()
    {
        _releasing = null;
        _formError = null;
    }

    /// <summary>
    /// Huỷ pallet đã nhận. Việc QUAN TRỌNG là nó giải phóng serial khỏi sổ:
    /// không có đường này thì một pallet quét sai khoá vĩnh viễn những con hàng
    /// đó khỏi mọi phiếu về sau.
    ///
    /// Từ 11/11 server CHẶN khi pallet còn serial đã rời kho (at_fa / returned /
    /// shipped / ng) và trả 409 kèm câu nói rõ trạng thái nào đang chặn.
    /// </summary>
    private async Task ConfirmReleasePallet()
    {
        if (_releasing is not { } r) return;

        _saving = true; _formError = null; StateHasChanged();
        try
        {
            await Api.ReleasePalletAsync(r.Doc.Id, r.Pallet.Id);
            CloseRelease();
            await Load();                 // SL thực nhận đã đổi
            await LoadPallets(r.Doc.Id);  // bảng pallet cũng đã đổi
        }
        catch (Exception ex)
        {
            // GIỮ dialog mở và hiện lỗi BÊN TRONG nó. Trước đây gán `_error` rồi
            // đóng dialog: banner `_error` nằm ở đầu trang, tức SAU overlay của
            // dialog chi tiết, nên người dùng mất popup mà không thấy lý do.
            _formError = Describe(ex);
        }
        finally { _saving = false; StateHasChanged(); }
    }

    /// <summary>
    // ═══════════════ Mục 2c · luồng nhận lại hàng về FA ═══════════════

    /// <summary>
    /// Nhật ký pallet đã giao theo từng phiếu, nạp LAZY khi bung dòng — cùng lý
    /// do với <see cref="_pallets"/>. Không có khoá = đang nạp.
    /// </summary>
    private readonly Dictionary<long, List<BackDeliveryDto>> _backDeliveries = new();

    private List<BackDeliveryDto> DeliveriesOf(long docId)
        => _backDeliveries.TryGetValue(docId, out var v) ? v : new();

    private async Task LoadBackDeliveries(long docId)
    {
        _backDeliveries.Remove(docId);
        try
        {
            _backDeliveries[docId] = await Api.GetBackDeliveriesAsync(docId);
        }
        catch
        {
            // Nhật ký là thông tin tham khảo. Tải hỏng thì coi như chưa giao gì
            // — không chặn cả màn hình vì một bảng con.
            _backDeliveries[docId] = new List<BackDeliveryDto>();
        }
        StateHasChanged();
    }

    /// <summary>Nhãn trạng thái luồng back. null = chưa ai đề nghị.</summary>
    private string BackLabel(ReturnInstructionDto d) => d.Back.Status switch
    {
        null => L["Return.Back.St.None"],
        BackStatus.FaRequested => L["Return.Back.St.FaRequested"],
        BackStatus.FaApproved => L["Return.Back.St.FaApproved"],
        BackStatus.ScsApproved => L["Return.Back.St.ScsApproved"],
        BackStatus.Delivered => L["Return.Back.St.Delivered"],
        BackStatus.Cancelled => L["Return.Back.St.Cancelled"],
        var s => s,
    };

    /// <summary>
    /// SL FA đã xin trên một phiếu.
    ///
    /// Danh sách dòng RỖNG nghĩa là "xin toàn bộ phần còn ở kho" (hoặc phiếu
    /// được đề nghị trước 10/11), nên lúc đó trả về chính SL còn ở kho — không
    /// trả 0, vì 0 làm người duyệt tưởng đề nghị trống.
    /// </summary>
    private static int BackAskedQty(ReturnInstructionDto d)
        => d.Back.Lines.Count > 0
            ? d.Back.Lines.Sum(l => l.ReqQty)
            : d.Back.RemainQty;

    /// <summary>Lớp CSS của chip trạng thái — dùng chuỗi status làm hậu tố.</summary>
    private static string BackPill(ReturnInstructionDto d)
        => d.Back.Status is null ? "bk-none" : $"bk-{d.Back.Status}";

    /// <summary>
    /// Timeline của phiếu. Hiện cả người và lúc: "đang chờ SCS giao hàng" mà
    /// không biết chờ từ bao giờ thì không ai biết có phải đi nhắc hay không.
    ///
    /// Mốc cuối ghi "đang giao dở" khi đã giao được pallet nào mà chưa hết —
    /// một cột trống ở đó làm WH tưởng chưa ai làm gì và quét lại từ đầu.
    /// </summary>
    /// <summary>
    /// Một bước trên timeline của phiếu.
    /// </summary>
    /// <param name="No">Số in trong ô tròn khi bước chưa xong.</param>
    /// <param name="Title">Tên bước, đã dịch.</param>
    /// <param name="State">
    /// <c>done</c> | <c>current</c> | <c>pending</c> — ĐÚNG ba tên class của
    /// <c>.step-v</c> trong swms-theme.css. Không đặt tên riêng rồi map: đặt
    /// tên riêng là thêm một bảng tra để quên.
    /// </param>
    /// <param name="Meta">Dòng phụ "người · thời điểm", hoặc lời giải thích.</param>
    /// <param name="Badge">Chip phụ bên phải tên bước, vd SL đã giao.</param>
    /// <param name="IsCancel">
    /// Bước kết thúc bằng HUỶ. Vẫn là <c>done</c> (việc đã xảy ra, ô tròn tô
    /// đặc) nhưng đánh dấu ✕ chứ không phải ✓ — huỷ mà hiện dấu tick thì đọc
    /// lướt thành "đã xong tốt đẹp".
    /// </param>
    /// <param name="Subs">
    /// Các bước CON của bước này (thêm 12/11) — ba mốc duyệt-giao của một lần
    /// đề nghị. Vẽ NGANG, thụt vào, ngay trong thân bước cha: xếp dọc thì một
    /// phiếu đi ba lần là timeline dài 15 dòng và không còn đọc ra được lần nào
    /// thuộc lần nào.
    /// </param>
    private sealed record DocStep(
        int No, string Title, string State, string Meta,
        string? Badge = null, bool IsCancel = false,
        List<SubStep>? Subs = null);

    /// <summary>Một mốc trong dải ngang của bước cha.</summary>
    private sealed record SubStep(
        int No, string Title, string State, string Meta,
        string? Badge = null, bool IsCancel = false);

    /// <summary>
    /// Timeline của CẢ vòng đời phiếu, dùng <c>.stepper-v</c> của design system
    /// — cùng thành phần với màn Hàng bất thường, nên hai màn đọc giống nhau.
    ///
    /// Gộp HAI giai đoạn vào MỘT timeline chứ không vẽ hai cái rời:
    ///   · Nhận hàng từ khách: tạo chỉ thị → WH quét nhận → chốt thực nhận
    ///   · Trả về FA:          FA đề nghị → QL FA → QL SCS → WH giao
    /// Giai đoạn sau chỉ xảy ra SAU giai đoạn trước, nên xếp nối tiếp là đúng
    /// trình tự thời gian; tách hai khối bắt người đọc tự ghép lại.
    ///
    /// Bốn bước của luồng back CHỈ hiện khi FA đã đề nghị: phần lớn phiếu không
    /// có vòng này, thêm bốn bước xám vào mọi phiếu chỉ làm timeline dài gấp đôi
    /// mà không nói thêm gì.
    /// </summary>
    private List<DocStep> DocSteps(ReturnInstructionDto d)
    {
        const string done = "done";
        const string cur = "current";
        const string idle = "pending";

        string W(string? who, DateTime? at)
            => at is null ? L["Return.Step.NotYet"].Value : $"{who} · {at:dd/MM/yyyy HH:mm}";

        var steps = new List<DocStep>
        {
            new(1, L["Return.Step.Created"].Value, done, W(d.CreatedBy, d.CreatedAt)),
        };

        // Bước nhận hàng: bám SỐ ĐÃ NHẬN chứ không bám trạng thái phiếu — WH quét
        // dở thì phiếu vẫn 'open', mà bước này rõ ràng đang chạy.
        var recvState = d.ReceivedQty > 0 ? (d.ClosedAt is not null ? done : cur) : idle;
        steps.Add(new(2, L["Return.Step.Receive"].Value, recvState,
            d.ReceivedQty > 0
                ? L["Return.Step.ReceivedQty", d.ReceivedQty, d.TotalQty].Value
                : L["Return.Step.NotYet"].Value));

        // Chốt thực nhận: mốc đóng phiếu + đã báo FA hay chưa.
        var closeState = d.ClosedAt is not null ? done
            : d.ReceivedQty > 0 ? cur : idle;
        steps.Add(new(3, L["Return.Step.Close"].Value, closeState,
            W(d.ClosedBy, d.ClosedAt),
            d.ClosedAt is not null
                ? L[d.ActualMailSentAt is not null
                    ? "Return.Step.MailSent" : "Return.Step.MailNotSent"].Value
                : null));

        var b = d.Back;
        if (!b.Requested) return steps;

        // ── MỖI LẦN ĐỀ NGHỊ MỘT TIẾN TRÌNH CON (12/11) ──────────────────
        //
        // Trước đó timeline chỉ gánh được MỘT lượt back, nên FA xin một phần là
        // bước giao hàng tick xong trong khi hàng vẫn còn ở kho và không ai
        // thấy "còn lần nữa". Nay: một bước cha cho mỗi lần (kèm chip
        // xin/đã giao) + ba bước con là ba mốc duyệt-giao của riêng lần đó.
        //
        // Rounds RỖNG = DB chưa chạy return_back_round_schema.sql -> lùi về bốn
        // bước phẳng của bản cũ, KHÔNG để timeline trống.
        if (b.Rounds.Count == 0)
        {
            AddFlatBackSteps(steps, d, done, cur, idle, W);
            return steps;
        }

        foreach (var r in b.Rounds)
        {
            // Lần ĐANG mở = số lần của phiếu và chưa đóng. Chỉ lần đó mới có
            // bước "đang chờ"; các lần cũ đã xong hết hoặc đã huỷ.
            var isCur = r.Round == b.Round && !r.IsClosed;

            // Bám MỐC THỜI GIAN của chính lần đó, không bám status của phiếu:
            // status chỉ nói về lần đang mở.
            var subs = new List<SubStep>
            {
                new(1, L["Return.Back.Step.FaApprove"].Value,
                    r.FaApprovedAt is not null ? done
                        : isCur && b.Step == BackStep.FaApprove ? cur : idle,
                    W(r.FaApprovedBy, r.FaApprovedAt)),

                new(2, L["Return.Back.Step.ScsApprove"].Value,
                    r.ScsApprovedAt is not null ? done
                        : isCur && b.Step == BackStep.ScsApprove ? cur : idle,
                    W(r.ScsApprovedBy, r.ScsApprovedAt)),

                // Bước giao không có nút nào trên web; đang đến lượt thì dòng
                // phụ nói đúng việc phải làm trên PDA.
                new(3, L["Return.Back.Step.ScsDeliver"].Value,
                    r.DeliveredAt is not null ? done
                        : isCur && b.Step == BackStep.ScsDeliver ? cur : idle,
                    r.DeliveredAt is not null
                        ? W(r.DeliveredBy, r.DeliveredAt)
                        : isCur && b.Step == BackStep.ScsDeliver
                            ? L["Return.Back.Step.ScsDeliverHint"].Value
                            : L["Return.Step.NotYet"].Value,
                    RoundProgress(r)),
            };

            // Huỷ: KHÔNG xoá các mốc đã đi qua, chỉ gắn thêm một mốc cuối dải.
            if (r.CancelledAt is not null)
                subs.Add(new(4, L["Return.Back.Step.Cancelled"].Value, done,
                    W(r.CancelledBy, r.CancelledAt), r.CancelReason,
                    IsCancel: true));

            steps.Add(new(steps.Count + 1,
                L["Return.Back.Round.Title", r.Round].Value,
                r.IsClosed ? done : isCur ? cur : idle,
                W(r.RequestedBy, r.RequestedAt),
                RoundBadge(r),
                Subs: subs));
        }

        // Lần vừa rồi đã đóng mà kho vẫn còn hàng của phiếu -> việc còn lại là
        // FA đề nghị tiếp. Không có bước này thì timeline kết thúc bằng một dấu
        // tick và đọc ra thành "xong cả phiếu".
        if (b.CanRequestAgain)
            steps.Add(new(steps.Count + 1,
                L["Return.Back.Step.WaitNextRequest"].Value, cur,
                L["Return.Back.Step.WaitNextHint", b.RemainQty].Value));

        return steps;
    }

    /// <summary>
    /// Bốn bước back PHẲNG của bản trước 12/11 — chỉ dùng khi API không trả
    /// <c>Rounds</c> (DB chưa chạy script đánh số lần).
    /// </summary>
    private void AddFlatBackSteps(
        List<DocStep> steps, ReturnInstructionDto d,
        string done, string cur, string idle, Func<string?, DateTime?, string> W)
    {
        var b = d.Back;

        steps.Add(new(steps.Count + 1, L["Return.Back.Step.Requested"].Value, done,
            W(b.RequestedBy, b.RequestedAt),
            BackAskedQty(d) > 0 ? L["Return.Back.AskedQty", BackAskedQty(d)].Value : null));

        steps.Add(new(steps.Count + 1, L["Return.Back.Step.FaApprove"].Value,
            b.ApprovedAt is not null ? done : b.IsOpen && b.Step == BackStep.FaApprove ? cur : idle,
            W(b.ApprovedBy, b.ApprovedAt)));

        steps.Add(new(steps.Count + 1, L["Return.Back.Step.ScsApprove"].Value,
            b.ScsApprovedAt is not null ? done : b.IsOpen && b.Step == BackStep.ScsApprove ? cur : idle,
            W(b.ScsApprovedBy, b.ScsApprovedAt)));

        steps.Add(new(steps.Count + 1, L["Return.Back.Step.ScsDeliver"].Value,
            b.IsDelivered ? done : b.IsOpen && b.Step == BackStep.ScsDeliver ? cur : idle,
            b.IsDelivered ? W(b.DeliveredBy, b.DeliveredAt)
            : b.IsOpen && b.Step == BackStep.ScsDeliver
                ? L["Return.Back.Step.ScsDeliverHint"].Value
                : L["Return.Step.NotYet"].Value,
            b.IsDelivered || b.IsPartlyDelivered
                // Cùng lý do với RoundProgress: giao đủ rồi mà chip vẫn ghi
                // "Đang giao dở" thì đọc ra là còn dở dang.
                ? L["Return.Back.Round.Progress", b.SentQty, b.SentQty + b.RemainQty].Value
                : null));

        if (b.IsCancelled)
            steps.Add(new(steps.Count + 1, L["Return.Back.Step.Cancelled"].Value, done,
                W(b.CancelledBy, b.CancelledAt), b.CancelReason, IsCancel: true));
    }

    /// <summary>
    /// Chip của bước cha: lần này xin bao nhiêu, đã giao bao nhiêu.
    /// <c>AskedQty</c> null = lần đó xin TOÀN BỘ phần còn ở kho.
    /// </summary>
    private string RoundBadge(BackRoundDto r)
        => r.AskedQty is { } ask
            ? L["Return.Back.Round.Badge", ask, r.DeliveredQty].Value
            : L["Return.Back.Round.BadgeAll", r.DeliveredQty].Value;

    /// <summary>
    /// Chip của mốc giao hàng trong một lần: "đã giao 12/20".
    ///
    /// KHÔNG dùng Return.Back.Partly ("Đang giao dở — {0}/{1} con"): câu đó
    /// khẳng định đang dở, nên lần đã giao đủ vẫn hiện "Đang giao dở — 3/3".
    /// Chip chỉ nên nói CON SỐ; xong hay chưa đã có ô tròn ✓ nói rồi.
    ///
    /// Lần xin toàn bộ không có mẫu số -> không vẽ chip, tránh hiện "12/0".
    /// </summary>
    private string? RoundProgress(BackRoundDto r)
        => r.AskedQty is { } ask
            ? L["Return.Back.Round.Progress", r.DeliveredQty, ask].Value
            : null;

    /// <summary>
    /// Ô tròn đầu bước: ✓ khi xong, còn lại là số thứ tự — cùng quy ước với màn
    /// Hàng bất thường.
    /// </summary>
    private static string StepMark(DocStep s) => s.IsCancel ? "✕"
        : s.State == "done" ? "✓" : s.No.ToString();

    // ── Dialog đề nghị / sửa ghi chú ──

    private ReturnInstructionDto? _backForm;
    private bool _backFormIsEdit;
    private string? _backNote;

    /// <summary>
    /// SL còn ở kho theo model. Vừa là TRẦN của ô nhập, vừa là con số FA nhìn
    /// để biết xin được tối đa bao nhiêu. null = đang nạp.
    /// </summary>
    private List<BackRemainModelDto>? _backRemain;

    /// <summary>
    /// SL FA đang xin, theo model (thêm 10/11 — FA xin được một phần).
    ///
    /// Mặc định điền SẴN bằng SL còn ở kho: "lấy hết" vẫn là trường hợp thường
    /// gặp nhất, nên FA chỉ phải sửa khi muốn lấy một phần.
    /// </summary>
    private readonly Dictionary<string, int> _backReq = new();

    private async Task OpenBackForm(ReturnInstructionDto d, bool isEdit)
    {
        CloseMenu();
        _backForm = d;
        _backFormIsEdit = isEdit;
        _backNote = isEdit ? d.Back.Note : null;
        _backRemain = null;
        _backReq.Clear();
        _formError = null;
        StateHasChanged();

        try
        {
            _backRemain = await Api.GetBackRemainAsync(d.Id);

            // Sửa ghi chú thì giữ nguyên SL đã xin lần trước; đề nghị mới thì
            // điền sẵn toàn bộ phần còn ở kho.
            var prev = isEdit
                ? d.Back.Lines.ToDictionary(
                    l => l.Model, l => l.ReqQty, StringComparer.OrdinalIgnoreCase)
                : new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);

            foreach (var r in _backRemain)
                _backReq[r.Model] = prev.TryGetValue(r.Model, out var q)
                    ? Math.Min(q, r.Qty)
                    : r.Qty;
        }
        catch (Exception ex)
        {
            _formError = Describe(ex);
            _backRemain = new List<BackRemainModelDto>();
        }
        StateHasChanged();
    }

    private void CloseBackForm()
    {
        _backForm = null;
        _backRemain = null;
        _backReq.Clear();
        _formError = null;
    }

    private int BackRemainTotal => _backRemain?.Sum(x => x.Qty) ?? 0;

    /// <summary>Tổng FA đang xin — hiện ở chân bảng để đối chiếu nhanh.</summary>
    private int BackReqTotal => _backReq.Values.Where(v => v > 0).Sum();

    private int ReqQtyOf(string model)
        => _backReq.TryGetValue(model, out var v) ? v : 0;

    /// <summary>
    /// Kẹp giá trị nhập vào [0, SL còn ở kho] NGAY TẠI Ô.
    ///
    /// Chặn ở đây chứ không chỉ chờ server: gõ nhầm 1000 rồi bấm Gửi mới biết
    /// sai là FA phải mở lại dialog và nhập lại từ đầu. Server vẫn kiểm lần nữa
    /// (<c>QtyOverRemain</c>) vì đây chỉ là màn hình.
    /// </summary>
    private void SetReqQty(string model, int max, ChangeEventArgs e)
    {
        var raw = e.Value?.ToString();
        var v = int.TryParse(raw, out var n) ? n : 0;
        _backReq[model] = Math.Clamp(v, 0, max);
    }

    private async Task SubmitBackForm()
    {
        if (_backForm is null) return;
        var id = _backForm.Id;

        // Bỏ hẳn dòng SL 0: không xin model đó, khác với "xin 0 con".
        var lines = _backReq
            .Where(kv => kv.Value > 0)
            .Select(kv => new BackReqLineDto { Model = kv.Key, ReqQty = kv.Value })
            .ToList();

        if (lines.Count == 0)
        {
            _formError = L["Return.Back.Err.NothingPicked"];
            StateHasChanged();
            return;
        }

        _saving = true; _formError = null; StateHasChanged();
        try
        {
            var body = new RequestBackRequestDto { Note = Blank(_backNote), Lines = lines };
            if (_backFormIsEdit)
                await Api.UpdateBackNoteAsync(id, body);
            else
                await Api.RequestBackAsync(id, body);

            CloseBackForm();
            await Load();
        }
        catch (Exception ex) { _formError = Describe(ex); }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── Dialog xác nhận / huỷ ──

    private enum BackAction { Approve, ApproveScs, Cancel }

    private ReturnInstructionDto? _backAsking;
    private BackAction _backAction;
    private string? _backComment;

    private string BackAskTitleKey => _backAction switch
    {
        BackAction.Approve => "Return.Back.ApproveTitle",
        BackAction.ApproveScs => "Return.Back.ApproveScsTitle",
        _ => "Return.Back.CancelTitle",
    };

    private string BackAskConfirmKey => _backAction switch
    {
        BackAction.Approve => "Return.Back.Approve",
        BackAction.ApproveScs => "Return.Back.ApproveScs",
        _ => "Return.Back.Cancel",
    };

    private void AskBack(ReturnInstructionDto d, BackAction action)
    {
        CloseMenu();
        _backAsking = d;
        _backAction = action;
        _backComment = null;
        _formError = null;
    }

    private void CloseBackAsk()
    {
        _backAsking = null;
        _formError = null;
    }

    private async Task ConfirmBackAsk()
    {
        if (_backAsking is null) return;
        var id = _backAsking.Id;
        _saving = true; _formError = null; StateHasChanged();
        try
        {
            var body = new BackDecisionRequestDto { Comment = Blank(_backComment) };
            switch (_backAction)
            {
                case BackAction.Approve:
                    await Api.ApproveBackAsync(id, body);
                    break;
                case BackAction.ApproveScs:
                    await Api.ApproveBackScsAsync(id, body);
                    break;
                default:
                    await Api.CancelBackAsync(id, body);
                    break;
            }

            CloseBackAsk();
            await Load();
        }
        catch (Exception ex)
        {
            // Lỗi hay gặp nhất ở đây là "có người vừa xử lý trước" (409). Giữ
            // dialog mở để người dùng đọc được câu đó, rồi tải lại danh sách để
            // họ thấy trạng thái mới.
            _formError = Describe(ex);
            await Load();
        }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── Dialog giao hàng đã XOÁ (11/11) ──
    //
    // Giao hàng cho FA không còn là thao tác bấm nút ở đâu cả: SCS WH out hàng
    // khỏi kho rồi đặt pallet vào một vị trí thuộc bản đồ Nhận hàng, và chính
    // việc đó là hành động giao (ghi sổ ở API: ReturnBackMoveGate).
    //
    // Không giữ lại đường nhập tay cho văn phòng: đó sẽ là một đường giao hàng
    // không đi qua vị trí kho, tức lọt cổng duyệt của quản lý SCS.

    // ───────── Mục 2d — nhật ký serial lệch của FA ─────────
    //
    // FA quét serial đóng lại Pallet ID trên PDA; con nào không khớp sổ thì
    // KHÔNG bị chặn mà vào nhật ký này. Việc của màn Web là để SCS đọc rồi đánh
    // dấu đã đặt riêng ra. Bên Web KHÔNG có chỗ đóng pallet — việc đó chỉ ở PDA.

    private readonly Dictionary<long, List<ReturnMismatchDto>> _mismatches = new();

    /// <summary>
    /// Hiện cả dòng đã xử lý. Một cờ CHUNG, không theo từng phiếu: người dùng
    /// bật nó lên là đang muốn soát lại nhật ký, và họ soát lần lượt từng phiếu.
    /// </summary>
    private bool _showResolvedMismatch;

    /// <summary>Không có khoá = đang nạp. Xem ghi chú ở <see cref="_pallets"/>.</summary>
    private List<ReturnMismatchDto> MismatchesOf(long docId)
        => _mismatches.TryGetValue(docId, out var v) ? v : new();

    /// <summary>
    /// Dòng hiện trên bảng, theo cờ xem-hết. Luôn lọc từ danh sách ĐẦY ĐỦ đã
    /// nạp, nên <see cref="OpenMismatchCount"/> vẫn đúng khi bật xem hết.
    /// </summary>
    private List<ReturnMismatchDto> MismatchRows(long docId)
        => _showResolvedMismatch
            ? MismatchesOf(docId)
            : MismatchesOf(docId).Where(m => !m.IsResolved).ToList();

    private int OpenMismatchCount(long docId)
        => MismatchesOf(docId).Count(m => !m.IsResolved);

    private async Task LoadMismatches(long docId)
    {
        _mismatches.Remove(docId);
        try
        {
            // openOnly = false: xin CẢ dòng đã xử lý rồi lọc ở client, để con số
            // "còn n chưa xử lý" không đổi khi người dùng bật xem hết.
            _mismatches[docId] = await Api.GetMismatchesAsync(docId, openOnly: false);
        }
        catch
        {
            // DB chưa chạy return_fa_pallet_schema.sql thì endpoint này 500.
            // Coi như nhật ký rỗng — KHÔNG làm chết cả màn hình vì một bảng con
            // của một mục chưa triển khai xong.
            _mismatches[docId] = new List<ReturnMismatchDto>();
        }
        StateHasChanged();
    }

    /// <summary>
    /// Đóng một dòng nhật ký: SCS WH là người đặt hàng riêng ra, nhưng Office
    /// cũng phải đóng được — khớp
    /// <c>RequireAnyPermission&lt;Process, Create&gt;</c> ở controller.
    /// </summary>
    private bool CanResolveMismatch(ReturnMismatchDto m)
        => (MayProcess || MayCreate) && !m.IsResolved;

    /// <summary>Khoá dịch của lý do. Mã lạ thì về <c>not_in_doc</c>.</summary>
    private static string MismatchReasonKey(ReturnMismatchDto m) => m.Reason switch
    {
        ReturnMismatchReason.OtherDoc => "Return.Fa.Reason.OtherDoc",
        ReturnMismatchReason.WrongStatus => "Return.Fa.Reason.WrongStatus",
        _ => "Return.Fa.Reason.NotInDoc",
    };

    /// <summary>
    /// Nhãn trạng thái serial. Mã lạ từ server thì hiện NGUYÊN MÃ, không ghép
    /// khoá dịch: ghép rồi mà thiếu khoá thì màn hình hiện ra chuỗi
    /// <c>Return.Fa.Status.xyz</c> — người dùng đọc được "xyz" còn hơn.
    /// </summary>
    private string MismatchStatusLabel(string? status) => status switch
    {
        null or "" => "—",
        ReturnSerialStatus.Received => L["Return.Fa.Status.Received"],
        ReturnSerialStatus.AtFa => L["Return.Fa.Status.AtFa"],
        ReturnSerialStatus.Returned => L["Return.Fa.Status.Returned"],
        ReturnSerialStatus.Shipped => L["Return.Fa.Status.Shipped"],
        ReturnSerialStatus.Ng => L["Return.Fa.Status.Ng"],
        _ => status,
    };

    // ── Dialog đánh dấu đã xử lý ──

    private ReturnMismatchDto? _mmAsking;
    private string? _mmNote;

    private void AskResolveMismatch(ReturnMismatchDto m)
    {
        CloseMenu();
        _mmAsking = m;
        _mmNote = null;
        _formError = null;
    }

    private void CloseResolveMismatch()
    {
        _mmAsking = null;
        _mmNote = null;
        _formError = null;
    }

    private async Task SubmitResolveMismatch()
    {
        if (_mmAsking is null) return;
        var docId = _mmAsking.DocId;
        var id = _mmAsking.Id;

        _saving = true; _formError = null; StateHasChanged();
        try
        {
            await Api.ResolveMismatchAsync(docId, id,
                new ResolveMismatchRequestDto { Note = Blank(_mmNote) });

            CloseResolveMismatch();
            // Nạp lại ĐÚNG nhật ký của phiếu đó, không Load() cả danh sách: số
            // liệu phiếu không đổi (đóng dòng nhật ký KHÔNG đổi trạng thái
            // serial), nên tải lại cả màn là một lượt gọi API vô ích.
            await LoadMismatches(docId);
        }
        catch (Exception ex) { _formError = Describe(ex); }
        finally { _saving = false; StateHasChanged(); }
    }

    /// <summary>Ô trống gửi lên thành NULL, không phải chuỗi rỗng.</summary>
    private static string? Blank(string? s)
        => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    /// <summary>
    /// Câu lỗi hiện cho người dùng. API trả envelope {status, title, ...} và
    /// <c>title</c> ĐÃ là câu đã dịch, nên ưu tiên dùng nguyên câu đó thay vì
    /// một câu chung chung — nó nói rõ model nào sai, phiếu nào khoá.
    /// </summary>
    private string Describe(Exception ex) =>
        ex is Refit.ApiException api && !string.IsNullOrWhiteSpace(api.Content)
            ? ExtractTitle(api.Content) ?? api.Message
            : ex.Message;

    private static string? ExtractTitle(string content)
    {
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(content);
            return doc.RootElement.TryGetProperty("title", out var t) ? t.GetString() : null;
        }
        catch { return null; }
    }
}
