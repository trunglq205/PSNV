namespace Swms.FinishGoods.API.Features.StowagePlans.DataAccess;

// Entity đọc/ghi bằng Dapper — tên property khớp alias trong SQL của StowagePlanRepository.

/// <summary>1 dòng danh sách: chuyến xe (container / xe tải, có / chưa có plan) hoặc plan không gắn chuyến.</summary>
public class PlanListRow
{
    public long? TripId { get; set; }
    public string? TripNo { get; set; }
    /// <summary>container | truck (null = plan không gắn chuyến).</summary>
    public string? VehicleType { get; set; }
    public long? PlanId { get; set; }
    public string? PlanNo { get; set; }
    public string UnitKind { get; set; } = "CONT";
    public string? UnitNo { get; set; }
    public string? ContainerType { get; set; }
    public string? ShipMode { get; set; }
    public string? Destination { get; set; }
    public string? PlanStatus { get; set; }
    public int SiCount { get; set; }
    public int BoxCount { get; set; }
    public int TotalColumns { get; set; }
    public int PlacedColumns { get; set; }
    public DateTime? PlannedArrivalAt { get; set; }
}

/// <summary>1 dòng wms.stowage_plans.</summary>
public class PlanRow
{
    public long Id { get; set; }
    public string PlanNo { get; set; } = "";
    public string UnitKind { get; set; } = "CONT";
    public string ShipMode { get; set; } = "FCL";
    public string ContainerType { get; set; } = "";
    public string? ForwarderCode { get; set; }
    public DateTime? VanningDate { get; set; }
    public DateTime? EtdDate { get; set; }
    public string? Destination { get; set; }
    public string BaseType { get; set; } = "no_base";
    public string Status { get; set; } = "not_started";
    public int TotalBoxes { get; set; }
    public int TotalPallets { get; set; }
    public int TotalColumns { get; set; }
    public int PlacedColumns { get; set; }
    public decimal? TotalWeightKg { get; set; }
    public DateTime? SavedAt { get; set; }
    public string? SavedBy { get; set; }
}

/// <summary>Chuyến xe — chỉ các cột màn Stowage Plan cần.</summary>
public class TripHeadRow
{
    public long Id { get; set; }
    public string? TripNo { get; set; }
    public string VehicleType { get; set; } = "";
    public string? ContainerNo { get; set; }
    public string? PlateNo { get; set; }
    public string? ContainerSize { get; set; }
    public string? ForwarderCode { get; set; }
    public DateTime? PlannedArrivalAt { get; set; }
    public string Status { get; set; } = "";
}

public class PlanContainerRow
{
    public int ContainerIndex { get; set; }
    public long? TripId { get; set; }
    public string? UnitNo { get; set; }
}

/// <summary>SI của plan / chuyến. Color chỉ có khi đọc từ stowage_plan_sis.</summary>
public class StowSiRow
{
    public long SiId { get; set; }
    public string SiNo { get; set; } = "";
    public string? ConsigneeCode { get; set; }
    public string? ShipMode { get; set; }
    public string? ForwarderCode { get; set; }
    public DateTime EtdDate { get; set; }
    public DateTime? VanningDate { get; set; }
    public string? Destination { get; set; }
    /// <summary>shipment_instructions.packing_type — quyết định loại đế pallet.</summary>
    public string? PackingType { get; set; }
    public string? Color { get; set; }
}

/// <summary>Thùng cần xếp (wms.fn_stowage_si_boxes): box thật (SiBoxId) hoặc thùng dự kiến khi chưa lấy hàng
/// (SiLineId + CartonSeq, số thùng = số lượng / standard_packing).</summary>
public class StowBoxRow
{
    public long? SiBoxId { get; set; }
    public long? SiLineId { get; set; }
    public int? CartonSeq { get; set; }
    public string? BoxNo { get; set; }
    public int LineNo { get; set; }
    public long SiId { get; set; }
    public string SiNo { get; set; } = "";
    public string Model { get; set; } = "";
    public double? Length { get; set; }
    public double? Width { get; set; }
    public double? Height { get; set; }
    public double? Weight { get; set; }
    public int? LayerLimit { get; set; }
    public bool IsEstimated { get; set; }
    /// <summary>Số cái trong thùng (null = không biết).</summary>
    public int? Qty { get; set; }
    /// <summary>Cate của model (master.models.category_id). null = master chưa khai.</summary>
    public string? Category { get; set; }
    public int? LayerCount { get; set; }
    /// <summary>Cách xếp 1 tầng (master): số thùng theo chiều dài thùng × theo chiều rộng thùng. null = tự tính.</summary>
    public int? StackingLength { get; set; }
    public int? StackingWidth { get; set; }

    /// <summary>Định danh trong DB (không phải khoá gửi Web).</summary>
    public string Ident => SiBoxId is { } id ? $"b{id}" : $"v{SiLineId}-{CartonSeq}";
}

public class StowColumnRow
{
    public long Id { get; set; }
    public string Code { get; set; } = "";
    public int? ContainerIndex { get; set; }
    public int? RowNo { get; set; }
    public int? LaneNo { get; set; }
    public bool Rotated { get; set; }
}

public class StowPalletRow
{
    public long Id { get; set; }
    public long ColumnId { get; set; }
    public int Tier { get; set; }
    public string Code { get; set; } = "";
    public long SiId { get; set; }
    public string PalletSize { get; set; } = "S1210";
    public double LengthCm { get; set; }
    public double WidthCm { get; set; }
}

public class StowPalletBoxRow
{
    public long StowagePalletId { get; set; }
    public long? SiBoxId { get; set; }
    public long? SiLineId { get; set; }
    public int? CartonSeq { get; set; }

    public string Ident => SiBoxId is { } id ? $"b{id}" : $"v{SiLineId}-{CartonSeq}";
}

/// <summary>1 thùng trên pallet khi lưu: box thật HOẶC (dòng SI + số thứ tự thùng).</summary>
public record BoxRef(long? SiBoxId, long? SiLineId, int? CartonSeq);

// ── Ghi ─────────────────────────────────────────────────────
/// <summary>Toàn bộ dữ liệu 1 lần "Lưu sơ đồ" — repository ghi trong 1 transaction.
/// Key = khoá tạm do service gán (để nối cọc ↔ pallet ↔ box trước khi có id thật).</summary>
public class PlanSave
{
    public PlanRow Plan { get; set; } = new();           // Id = 0: tạo mới
    public long? TripId { get; set; }                     // gắn vào container #0 khi tạo mới
    public string? UnitNo { get; set; }
    public int ContainerCount { get; set; } = 1;
    public List<(long SiId, int Sort)> Sis { get; set; } = new();
    public List<ColumnSave> Columns { get; set; } = new();
    public List<PalletSave> Pallets { get; set; } = new();
    public string? Actor { get; set; }
}

public class ColumnSave
{
    public string Key { get; set; } = "";
    public string Code { get; set; } = "";
    public int? ContainerIndex { get; set; }
    public int? RowNo { get; set; }
    public int? LaneNo { get; set; }
    /// <summary>Xoay ngang: cạnh rộng pallet nằm dọc container.</summary>
    public bool Rotated { get; set; }
}

public class PalletSave
{
    public string ColumnKey { get; set; } = "";
    public int Tier { get; set; }
    public string Code { get; set; } = "";
    public long SiId { get; set; }
    public string PalletSize { get; set; } = "S1210";
    public double LengthCm { get; set; }
    public double WidthCm { get; set; }
    public List<BoxRef> Boxes { get; set; } = new();
}