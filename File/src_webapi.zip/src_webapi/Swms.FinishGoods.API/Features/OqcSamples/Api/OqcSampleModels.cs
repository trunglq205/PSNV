﻿using System.ComponentModel.DataAnnotations;
using System.Text.Json.Serialization;

namespace Swms.FinishGoods.API.Features.OqcSamples.Api
{
    // ── Request (snake_case theo contract) ────────────────────
    // JsonPropertyName -> [property:] (gắn cho property).
    // Required/MaxLength để trần -> gắn cho PARAMETER, để validator nhận đúng.

    /// <summary>get-locations: tra pallet + vị trí để OQC trả mẫu về.</summary>
    public record OqcGetLocationsRequest(
        [property: JsonPropertyName("model")][Required, MaxLength(50)] string Model,
        [property: JsonPropertyName("production_date")][Required] string ProductionDate,
        [property: JsonPropertyName("payload")][Required, MaxLength(500)] string Payload);

    /// <summary>
    /// sample: lấy mẫu 1 box (payload) -> 2; phần còn lại của lô (model + ngày SX) -> 3.
    /// LotName gán cho cả lô khi lấy mẫu.
    /// </summary>
    public record OqcSampleActionRequest(
        [property: JsonPropertyName("model")][Required, MaxLength(50)] string Model,
        [property: JsonPropertyName("production_date")][Required] string ProductionDate,
        [property: JsonPropertyName("payload")][Required, MaxLength(1000)] string Payload,
        [property: JsonPropertyName("lot_name")][Required, MaxLength(50)] string LotName,
        [property: JsonPropertyName("line")][MaxLength(50)] string? Line = null);

    /// <summary>return: trả 1 box về (theo payload) -> chờ kết quả (3).</summary>
    public record OqcReturnRequest(
        [property: JsonPropertyName("model")][Required, MaxLength(50)] string Model,
        [property: JsonPropertyName("production_date")][Required] string ProductionDate,
        [property: JsonPropertyName("payload")][Required, MaxLength(1000)] string Payload);

    /// <summary>update-status: ghi kết quả kiểm (ok|ng) cho CẢ LOT (theo lot_name).</summary>
    public record OqcUpdateStatusRequest(
        [property: JsonPropertyName("model")][Required, MaxLength(50)] string Model,
        [property: JsonPropertyName("status")][Required, MaxLength(20)] string Status,
        [property: JsonPropertyName("lot_name")][Required, MaxLength(50)] string LotName);

    // ── Response ──────────────────────────────────────────────

    public record OqcLocationResponse(
        [property: JsonPropertyName("locator")] string? Locator,
        [property: JsonPropertyName("pallet_id")] string PalletId);

    public record OqcOkResponse(
        [property: JsonPropertyName("result")] string Result = "ok");

    // ── Error codes ───────────────────────────────────────────

    public static class OqcErrors
    {
        public const string ProductionDateInvalid = "Lot.Oqc.ProductionDateInvalid";  // 422
        public const string StatusInvalid = "Lot.Oqc.StatusInvalid";          // 422
        public const string PalletNotFound = "Lot.Oqc.PalletNotFound";         // 404
        public const string NothingToSample = "Lot.Oqc.NothingToSample";        // 422
    }
}