using Swms.FinishGoods.Web.Features.MapDesigner.Business.Models;
using Swms.FinishGoods.Web.Features.MapDesigner.Client;
using Swms.FinishGoods.Web.Shared.Business.Base;
using Swms.FinishGoods.Web.Shared.Business.Models;

namespace Swms.FinishGoods.Web.Features.MapDesigner.Business;

public class MapDesignerBusiness : BaseBusiness, IMapDesignerBusiness
{
    private readonly IMapDesignerApi _api;

    public MapDesignerBusiness(IMapDesignerApi api, ILogger<MapDesignerBusiness> logger, ErrorHandler errorHandler)
        : base(logger, errorHandler) => _api = api;

    public Task<Result<MapLayoutDto>> GetLayoutAsync(string areaCode)
        => ExecuteAsync(() => _api.GetLayoutAsync(areaCode));

    public Task<Result> SaveLayoutAsync(string areaCode, List<MapBlockDto> blocks)
        => ExecuteAsync(() => _api.SaveLayoutAsync(areaCode, blocks));

    public Task<Result<long>> CreateRackAsync(string areaCode, CreateRackInputDto input)
        => ExecuteAsync(() => _api.CreateRackAsync(areaCode, input));

    public Task<Result> DeleteRackAsync(string areaCode, string rackCode)
        => ExecuteAsync(() => _api.DeleteRackAsync(areaCode, rackCode));
}
