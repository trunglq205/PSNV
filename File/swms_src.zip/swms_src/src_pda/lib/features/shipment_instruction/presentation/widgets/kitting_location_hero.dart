import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/pick_task_ui.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

/// Thẻ nền xanh đậm đầu màn: mã vị trí thật to + cách lấy tại vị trí này.
class KittingLocationHero extends StatelessWidget {
  final PickTask task;
  final VoidCallback? onOpenMap;

  const KittingLocationHero({super.key, required this.task, this.onOpenMap});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    const white = Colors.white;

    final isPallet = task.mode == PickMode.wholePallet;
    final title = switch (task.mode) {
      PickMode.wholePallet => LocaleKeys.kitting_task_take_whole_pallet.tr(),
      PickMode.fifoBox => LocaleKeys.kitting_task_take_fifo.tr(
        args: ['${task.boxPlanned}'],
      ),
      PickMode.designatedBox => LocaleKeys.kitting_task_take_designated.tr(
        args: ['${task.boxPlanned}'],
      ),
      null => siOrDash(task.modeKey),
    };
    final sub = siJoin([
      // Không có locator thì Pallet ID đã lên dòng to → không lặp lại.
      if (task.hasLocator) task.palletCode,
      '${task.qtyPlanned} pcs',
      if ((task.poNo ?? '').isNotEmpty) 'PO ${task.poNo}',
    ]);

    return Container(
      padding: const EdgeInsets.all(AppDimens.md),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [swms.primaryDark, swms.primary],
        ),
        borderRadius: BorderRadius.circular(AppDimens.rCard),
        boxShadow: AppShadows.s2,
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    if (!task.hasLocator)
                      Text(
                        LocaleKeys.kitting_no_locator.tr(),
                        style: AppTextStyles.caption.copyWith(
                          fontWeight: FontWeight.w600,
                          color: white.withValues(alpha: .82),
                        ),
                      ),
                    Text(
                      task.locationLabel,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: AppTextStyles.code.copyWith(
                        // Pallet ID 12 số dài hơn mã vị trí → giảm cỡ cho vừa.
                        fontSize: task.hasLocator ? 28 : 22,
                        fontWeight: FontWeight.w800,
                        letterSpacing: 1,
                        color: white,
                      ),
                    ),
                  ],
                ),
              ),
              if (task.hasLocator && onOpenMap != null) ...[
                const SizedBox(width: AppDimens.sm),
                AppButton(
                  label: LocaleKeys.kitting_view_map.tr(),
                  icon: Icons.navigation_rounded,
                  variant: AppButtonVariant.neutral,
                  size: AppButtonSize.sm,
                  isFullWidth: false,
                  onPressed: onOpenMap!,
                ),
              ],
            ],
          ),
          const SizedBox(height: 10),
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 8),
            decoration: BoxDecoration(
              color: white.withValues(alpha: .14),
              border: Border.all(color: white.withValues(alpha: .22)),
              borderRadius: BorderRadius.circular(AppDimens.rInput),
            ),
            child: Row(
              children: [
                Container(
                  width: 30,
                  height: 30,
                  decoration: BoxDecoration(
                    color: white.withValues(alpha: .2),
                    borderRadius: BorderRadius.circular(AppDimens.sm),
                  ),
                  child: Icon(
                    isPallet
                        ? Icons.view_module_outlined
                        : Icons.inventory_2_outlined,
                    size: 18,
                    color: white,
                  ),
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        title,
                        style: AppTextStyles.bodyStrong.copyWith(
                          fontSize: 14,
                          fontWeight: FontWeight.w700,
                          color: white,
                        ),
                      ),
                      Text(
                        sub,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.code.copyWith(
                          fontSize: 11,
                          letterSpacing: 0,
                          color: white.withValues(alpha: .82),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
