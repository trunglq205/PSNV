# Phân quyền FA / SCS trên màn Tái gia công — đợt 1

6 file + **1 chỗ phải tự chèn tay** (xem mục 4). Không có script SQL: quyền mới
được `PermissionCatalogSeeder` tự seed khi API khởi động.

## 1. Cách tách đã chọn

Tách bằng **quyền**, không bằng cột `department`. Bộ phận được mã hoá vào **tên
quyền**, đúng cách màn Hàng bất thường đang làm (`Perms.cs:42-72`: *"MỖI BƯỚC
MỘT QUYỀN RIÊNG để một người không gánh được hai bước liền nhau"*).

Lý do không dùng `master.users.department` dù cột đó có thật:
- `ICurrentUser` không mang department, JWT cũng không có claim đó — business
  logic phía API hiện **không có đường nào đọc được** nó.
- Trong code có **hai danh sách department khác nhau**: `UserService.cs:20-22`
  là `{SCS, FA, OQC, SEC, IT}`, `EmailConfigService.cs:30` là
  `{FA, OQC, VP, SCS, SEC, IT}`. Không có bảng master.
- Thêm department vào phân quyền là dựng hệ phân quyền **thứ hai song song** —
  hai nguồn sự thật cho cùng câu hỏi "tôi được bấm cái này không".

Department giữ nguyên việc của nó: **ai nhận mail** (`master.email_config`).

## 2. Thay đổi

### API — `Features/Roles/Catalog/Perms.cs`

- Thêm `Perms.Pda.PdaReceiving.ReturnReceive` → mã `pda_receiving.return_receive`.
  Tile "Chỉ thị back hàng" trên Home của PDA gác bằng quyền này.
- Thêm doc comment cho `ReworkRefurbish`: ghi rõ bước nào dùng quyền nào, và
  **4 quyền sẽ khai khi dựng mục 2c/2d** (`request_back`, `approve_fa`,
  `approve_scs`, `process_fa`). Chưa khai bây giờ vì chưa có endpoint —
  quyền khai mà không gác gì thì admin tick vào không hiểu để làm gì.
- Ghi lại cái bẫy: `Approve` / `Print` đang khai mà **không gác endpoint nào**.
  Đừng xoá bằng cách sửa code — seeder MERGE theo code, xoá rồi khai lại đúng
  tên cũ sẽ bật `is_deleted` về 0 và **làm sống lại quyền của mọi role từng
  được gán**. Phải xử lý bằng script như `db/ng_perms_split.sql`.

### Web — `ReworkRefurbish.razor` + `.razor.cs`

**Lỗi đang có**: trang chỉ kiểm `rework_refurbish_create`. User WH chỉ có
`Process` vào màn web thì **không thấy nút nào**, dù API cho phép họ chốt thực
nhận và huỷ lần nhận.

- Thêm `MayProcess` và `MayCloseOrRelease = MayProcess || MayCreate`, khớp
  **từng dòng** với attribute ở controller (có comment đối chiếu cạnh nhau).
- Nút hàng trong bảng đổi từ chuỗi `if / else if` sang **`@if` độc lập**: chuỗi
  else-if làm user chỉ có `Process` bị bỏ qua cả nhánh và mất luôn nút Chốt.
  Các điều kiện loại trừ nhau theo *trạng thái phiếu* nên `@if` riêng vẫn đúng.
  Cùng cách với `AbnormalReport.razor:508-542`.

| Nút | Trước | Sau |
|---|---|---|
| Chốt thực nhận | `MayCreate && IsOpen && HasReceipt` | `IsOpen && HasReceipt && (Process‖Create)` |
| Sửa / Xoá | `MayCreate && IsOpen` | `IsOpen && MayCreate` |
| Mở lại | `MayCreate && IsCompleted` | `IsCompleted && MayCreate` |
| Huỷ lần nhận | `MayCreate && IsOpen` | `IsOpen && (Process‖Create)` |

Không cần sửa `Shared/Auth/Perms.cs`: enum `rework_refurbish_process` và dòng
map `=> "rework_refurbish.process"` đã có sẵn.

### PDA — 2 file mới + 1 file sửa

**Mới** `lib/shared/presentation/providers/permission_providers.dart` (+ `.g.dart`)

`myPermissionsProvider` — mã quyền của user, lấy từ `GET /api/auth/me`, dùng
chung cho mọi màn.

Vì sao **không** đọc `homeProvider`: màn Home có sẵn danh sách quyền trong
state của nó, nhưng state đó chỉ có khi đã đi qua Home. Vào bằng deep-link hoặc
khi OS dựng lại app thì state rỗng và **mọi nút bị ẩn oan** — mà nút bị ẩn thì
người dùng không có cách nào biết là chưa nạp quyền hay không có quyền.

Kèm extension `.can(key)`: đang nạp / lỗi → `false` (chưa biết chắc thì chưa
hiện nút). Dùng khớp mẫu `AsyncData` chứ không dùng `valueOrNull` — riverpod
3.3.2 đã bỏ getter đó.

`keepAlive: true` vì quyền không đổi trong một lần đăng nhập. Lưu ý: phía API
còn **cache 5 phút** (`IMemoryCache`, key `perms:user:{userId}`) — sửa role rồi
phải chờ, đăng xuất đăng nhập lại cũng chưa chắc ra ngay.

**Sửa** `features/return_instruction/presentation/return_instruction_list_page.dart`

Trước: nút luôn hiện, không kiểm gì — API trả 403 thì user ăn toast đỏ giữa lúc
đang quét hàng và tưởng máy hỏng.

| Nút | Quyền | Khớp endpoint |
|---|---|---|
| Tạo Pallet ID | `rework_refurbish.process` | `POST {id}/pallets` |
| Chốt thực nhận | `process` ‖ `create` | `POST {id}/close` |

Cả hàng nút chỉ dựng khi có ít nhất một nút, nên user chỉ có quyền XEM (SCS
Office, FA) không thấy khoảng trống thừa dưới phiếu.

## 3. Role cần khai sau khi build

Vào màn Roles, matrix 3 cấp sẽ tự có quyền mới (seeder đọc `Perms.cs` lúc API
khởi động).

| Role | Quyền |
|---|---|
| SCS Office | `rework_refurbish.view` + `.create` |
| SCS WH | `rework_refurbish.view` + `.process` + `pda_receiving.return_receive` |
| FA | `rework_refurbish.view` (xem thôi, tới 2c/2d mới thêm) |
| Quản lý SCS / FA | tới 2c mới có quyền duyệt — gắn thêm vào role người đang làm, **không cần account mới** |

WH phải có **đủ ba** quyền: `pda_receiving.return_receive` để thấy tile,
`rework_refurbish.view` để gọi được API danh sách, `.process` để quét. Đây cũng
là cách tile Thùng NG đang hoạt động (`pda_receiving.abnormal_report` +
`abnormal_report.view`), không phải cái gì mới.

## 4. ⚠ Phải chèn tay — `home_notifier.dart`

Tôi **không gửi kèm** `lib/features/home/presentation/providers/home_notifier.dart`:
bản của tôi dựng từ zip cũ hơn, nhóm **Xuất hàng** trong đó khác bản 02/11 của
anh (thứ tự tile và icon Stowage / Container). Ghi đè là lặp lại đúng lỗi
`app_router.gr.dart` hôm trước.

Mở file đó, tìm `FeatureItem` của **Tạo Pallet ID** trong nhóm `inbound`:

```dart
FeatureItem(
  key: 'pda_receiving.receive',
  nameKey: LocaleKeys.home_feature_create_pallet,
  icon: Icons.qr_code,
  routeName: AppRoutePaths.receiving,
),
```

**Nếu đã có** tile `routeName: AppRoutePaths.returnInstruction` thì chỉ cần sửa
`key` của nó từ `'rework_refurbish.view'` thành `'pda_receiving.return_receive'`.

**Nếu chưa có**, chèn ngay bên dưới:

```dart
// Gác bằng quyền PDA chứ không phải rework_refurbish.view: View là
// quyền XEM màn web, SCS Office và FA đều có — họ không quét hàng nên
// không cần tile này. Cùng cách với tile Thùng NG ở dưới.
FeatureItem(
  key: 'pda_receiving.return_receive',
  routeName: AppRoutePaths.returnInstruction,
  nameKey: LocaleKeys.home_feature_return_instruction,
  icon: Icons.assignment_return_outlined,
),
```

Khoá dịch `home.feature.return_instruction` đã có đủ 4 ngôn ngữ từ đợt trước,
không phải thêm gì.

## 5. Thứ tự áp dụng

1. Ghi đè 6 file.
2. Chèn tay tile PDA (mục 4).
3. Build lại API → seeder tự thêm `pda_receiving.return_receive` vào
   `master.permissions`.
4. Vào màn Roles tick quyền theo bảng ở mục 3.
5. Build Web + PDA. PDA **không cần** `build_runner`: `.g.dart` của provider
   mới đã gửi kèm, và không file generated dùng chung nào bị sửa.

## 6. Chưa làm

- **Màn `return_receive_page.dart` chưa tự kiểm quyền.** Vào được chỉ bằng nút
  "Tạo Pallet ID" (đã gác), nên đường duy nhất lọt vào là deep-link — lúc đó
  API vẫn chặn lúc lưu. Thêm guard ở đầu màn thì sạch hơn, nói là tôi làm.
- **4 quyền của 2c/2d** (`request_back`, `approve_fa`, `approve_scs`,
  `process_fa`) chỉ mới ghi trong comment. Khai khi dựng bước đó.
- **Chưa có cột "đang chờ bên nào"**. Màn NG dùng `current_step`
  (`created|oqc_confirm|fa_confirm|scs_finalize|done`) + sub-status từng bên để
  nút hiện theo `trạng thái AND quyền`. `return_instructions.doc_status` hiện
  CHECK `('open','completed','cancelled')` — mở rộng khi làm 2c (nhớ bọc
  `EXEC(N'…')` vì CHECK constraint phải drop rồi tạo lại).
- **Nav chỉ ẩn menu, biết URL vẫn mở được trang.** Toàn hệ thống đang vậy
  (`_Imports.razor` chỉ có `[Authorize]` trơn, không có policy theo trang).
  Gate thật nằm ở attribute API — chỗ đó đúng rồi.
