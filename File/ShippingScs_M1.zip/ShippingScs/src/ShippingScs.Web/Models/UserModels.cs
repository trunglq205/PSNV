using System.ComponentModel.DataAnnotations;

namespace ShippingScs.Web.Models;

public static class Roles
{
    public const string Admin = "Admin";
    public const string Pic = "PIC";
    public const string Viewer = "Viewer";

    // Dùng cho [Authorize(Roles = ...)]
    public const string AdminOrPic = Admin + "," + Pic;

    public static readonly string[] All = { Admin, Pic, Viewer };
}

/// <summary>Dòng trong bảng Users.</summary>
public class AppUser
{
    public int Id { get; set; }
    public string UserName { get; set; } = "";
    public string FullName { get; set; } = "";
    public string? Email { get; set; }
    public string? PicCode { get; set; }
    public string Role { get; set; } = Roles.Viewer;
    public string PasswordHash { get; set; } = "";
    public bool IsActive { get; set; }
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

public class LoginModel
{
    [Required(ErrorMessage = "Nhập tên đăng nhập")]
    public string UserName { get; set; } = "";

    [Required(ErrorMessage = "Nhập mật khẩu")]
    [DataType(DataType.Password)]
    public string Password { get; set; } = "";

    public string? ReturnUrl { get; set; }
}

public class UserEditModel
{
    public int Id { get; set; }

    [Required(ErrorMessage = "Nhập tên đăng nhập"), StringLength(50)]
    public string UserName { get; set; } = "";

    [Required(ErrorMessage = "Nhập họ tên"), StringLength(100)]
    public string FullName { get; set; } = "";

    [EmailAddress(ErrorMessage = "Email không hợp lệ"), StringLength(200)]
    public string? Email { get; set; }

    [StringLength(30)]
    [Display(Name = "Mã PIC (như trong file Excel)")]
    public string? PicCode { get; set; }

    [Required]
    public string Role { get; set; } = Roles.Pic;

    public bool IsActive { get; set; } = true;

    // Bắt buộc khi tạo mới; khi sửa để trống = giữ mật khẩu cũ
    [DataType(DataType.Password), StringLength(100, MinimumLength = 6, ErrorMessage = "Mật khẩu tối thiểu 6 ký tự")]
    public string? NewPassword { get; set; }
}
