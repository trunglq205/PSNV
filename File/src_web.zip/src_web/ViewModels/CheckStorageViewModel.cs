﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class CheckStorageViewModel : TableViewModel<CheckStorage, CheckStorageFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, CheckStorageFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Category = filter?.Category ?? Filter.Category,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Material = filter?.Material ?? Filter.Material,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
        
    }
}
