﻿namespace Swms.FinishGoods.Web.Features.Auth.Business.Models;

public class MeResponse
{
    public string Username { get; set; } = "";
    public List<string> Role { get; set; } = new();
}