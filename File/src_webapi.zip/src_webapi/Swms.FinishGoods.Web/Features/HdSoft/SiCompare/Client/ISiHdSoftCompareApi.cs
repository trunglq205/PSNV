using Refit;
using Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Business.Models;

namespace Swms.FinishGoods.Web.Features.HdSoft.SiCompare.Client
{
    /// <summary>Đối chiếu SI với HD soft (hệ thống cũ). Khớp SiHdSoftCompareController bên API.
    /// Tách khỏi IShipmentInstructionApi để không đụng các bản mock đang implement interface đó.</summary>
    public interface ISiHdSoftCompareApi
    {
        /// <summary>SI có vanning date trong [from, to] ở SWMS hoặc HD soft (from không được trước hôm nay).
        /// Vanning = COALESCE(vanning_date, etd_date) — cùng định nghĩa màn Hàng thiếu.
        /// warehouse lọc phía HD soft: "PSNV" = 1 kho, "" = mọi kho (gửi null thì API dùng mặc định PSNV).</summary>
        [Get("/api/shipment-instructions/hdsoft-compare")]
        Task<SiCompareListDto> GetListAsync(
            [Query(Format = "yyyy-MM-dd")] DateTime from,
            [Query(Format = "yyyy-MM-dd")] DateTime to,
            string? warehouse,
            bool onlyIssues);

        /// <summary>Chi tiết 1 SI: từng trường header + từng dòng hai bên.</summary>
        [Get("/api/shipment-instructions/hdsoft-compare/{siNo}")]
        Task<SiCompareDetailDto> GetDetailAsync(string siNo);
    }
}
