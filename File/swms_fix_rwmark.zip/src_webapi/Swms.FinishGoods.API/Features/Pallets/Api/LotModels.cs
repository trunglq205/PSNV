using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Api;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using System.Text.Json.Serialization;

namespace Swms.FinishGoods.API.Features.Pallets.Api
{
    /// <summary>
    /// detailLevel trên JSON là snake_case: "serial" | "box_line" | "box_count".
    /// Tự viết converter thay vì dựa vào JsonNamingPolicy.SnakeCaseLower (chỉ có
    /// từ .NET 8) để chạy được trên mọi phiên bản, đồng thời vẫn chấp nhận
    /// biến thể cũ "BoxLine" / "box-line" cho client chưa kịp đổi.
    /// </summary>
    public sealed class LotDetailLevelConverter : JsonConverter<PalletDetailLevel>
    {
        public override PalletDetailLevel Read(
            ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType != JsonTokenType.String)
                throw new JsonException(
                    "detailLevel phải là chuỗi: serial | box_line | box_count.");

            return Parse(reader.GetString());
        }

        public override void Write(
            Utf8JsonWriter writer, PalletDetailLevel value, JsonSerializerOptions options)
            => writer.WriteStringValue(value.ToDbValue());

        public static PalletDetailLevel Parse(string? raw)
        {
            // Bỏ _ và - rồi so khớp không phân biệt hoa thường:
            // "box_line" = "BoxLine" = "box-line" = "boxline".
            var key = (raw ?? "").Trim().Replace("_", "").Replace("-", "").ToLowerInvariant();

            return key switch
            {
                "serial" => PalletDetailLevel.Serial,
                "boxline" => PalletDetailLevel.BoxLine,
                "boxcount" => PalletDetailLevel.BoxCount,
                _ => throw new JsonException(
                    $"detailLevel không hợp lệ: '{raw}'. Cho phép: serial | box_line | box_count.")
            };
        }
    }

    [JsonConverter(typeof(LotDetailLevelConverter))]
    public enum PalletDetailLevel { Serial, BoxLine, BoxCount }
    // Lưu ý: attribute trên enum này chỉ có tác dụng khi KHÔNG có converter enum
    // nào trong options.Converters. Với cấu hình hiện tại của Program.cs thì
    // property-level attribute trong CreateLotRequest mới là cái ăn.

    /// <summary>
    /// lotType trên JSON là snake_case: "pallet" | "stocky".
    /// Cùng khuôn mẫu với LotDetailLevelConverter.
    /// </summary>
    public sealed class PalletTypeConverter : JsonConverter<PalletType>
    {
        public override PalletType Read(
            ref Utf8JsonReader reader, Type typeToConvert, JsonSerializerOptions options)
        {
            if (reader.TokenType != JsonTokenType.String)
                throw new JsonException("lotType phải là chuỗi: pallet | stocky.");

            return Parse(reader.GetString());
        }

        public override void Write(
            Utf8JsonWriter writer, PalletType value, JsonSerializerOptions options)
            => writer.WriteStringValue(value.ToDbValue());

        public static PalletType Parse(string? raw)
        {
            var key = (raw ?? "").Trim().Replace("_", "").Replace("-", "").ToLowerInvariant();

            return key switch
            {
                "pallet" => PalletType.Pallet,
                "stocky" => PalletType.Stocky,
                "stockycart" => PalletType.Stocky,   // alias cho client cũ
                _ => throw new JsonException(
                    $"lotType không hợp lệ: '{raw}'. Cho phép: pallet | stocky.")
            };
        }
    }

    [JsonConverter(typeof(PalletTypeConverter))]
    public enum PalletType { Pallet, Stocky }

    /// <summary>Chuyển enum sang chuỗi snake_case để ghi DB.</summary>
    public static class LotDetailLevelExtensions
    {
        public static string ToDbValue(this PalletDetailLevel level) => level switch
        {
            PalletDetailLevel.Serial => "serial",
            PalletDetailLevel.BoxLine => "box_line",
            PalletDetailLevel.BoxCount => "box_count",
            _ => throw new ArgumentOutOfRangeException(nameof(level))
        };

        public static string ToDbValue(this PalletType type) => type switch
        {
            PalletType.Pallet => "pallet",
            PalletType.Stocky => "stocky",
            _ => throw new ArgumentOutOfRangeException(nameof(type))
        };
    }

    // ── Request ───────────────────────────────────────────────
    public record CreatePalletRequest(
        // [property: JsonConverter] BẮT BUỘC ở đây: converter đăng ký trong
        // options.Converters (Program.cs) có độ ưu tiên CAO HƠN attribute đặt
        // trên type enum, nên chỉ attribute mức property mới thắng được.
        [property: JsonConverter(typeof(LotDetailLevelConverter))]
        [Required] PalletDetailLevel? DetailLevel,

        // Client tự sinh. Format <CategoryCode:3><YYMMDD><Seq:3> = 12 chữ số.
        // Server chỉ kiểm tra format + trùng, KHÔNG tự sinh.
        [Required, RegularExpression(@"^\d{12}$")] string LotNo,

        [Required, Range(1, 999)] int CategoryCode,

        [property: JsonConverter(typeof(PalletTypeConverter))]
        [Required] PalletType? LotType,                       // pallet | stocky

        // BẮT BUỘC khi LotType = stocky; CẤM khi LotType = pallet.
        [MaxLength(50)] string? StockyCode,

        // Chỉ dùng khi DetailLevel = BoxCount — lưu thẳng, khỏi JOIN master.models.
        [MaxLength(50)] string? Model,
        [Range(1, int.MaxValue)] int? StandardPacking,
        DateTime? ProductionDate,

        int? BoxCount,                                     // BẮT BUỘC khi BoxCount; bỏ qua khi Serial|BoxLine
        List<CreateBoxRequest>? Boxes);                 // BẮT BUỘC khi Serial|BoxLine; CẤM khi BoxCount

    public record CreateBoxRequest(
        [Required, MaxLength(50)] string BoxNo,            // = Card_ID
        [MaxLength(50)] string? PsnvPo,
        [MaxLength(50)] string? CustomerPo,
        DateTime? ProductionDate,                          // null -> server lấy MIN(lines.productionDate)
        string? RawPayload,                                // chuỗi quét gốc, lưu nguyên văn
        [Required, MinLength(1)] List<CreateBoxLineRequest> Lines);

    public record CreateBoxLineRequest(
        [Required, MaxLength(50)] string Model,

        // Serial: server tự set = 1, client không cần gửi.
        // BoxLine: bắt buộc, >= 1.
        [Range(1, int.MaxValue)] int? Qty,

        [MaxLength(50)] string? SerialNo,
        DateTime? ProductionDate,

        // Số lượng inner carton trong box (KHÔNG phải pcs/carton).
        // pcsPerCarton = Qty / CartonCount. Map vào cột box_lines.carton_qty.
        [Range(1, int.MaxValue)] int? CartonCount);

    // ── Query ─────────────────────────────────────────────────
    public class PalletQuery : PagedQuery
    {
        public string? LotNo { get; set; }
        public int? CategoryCode { get; set; }
        public string? LotType { get; set; }
        public string? Model { get; set; }
        public string? StockyCode { get; set; }
        public string? DetailLevel { get; set; }        // snake_case
        public string? InspectionStatus { get; set; }
        public bool? IsUrgent { get; set; }
        public long? LocatorId { get; set; }
        public int? SapStatus { get; set; }   // lọc đúng 1 trạng thái
        public bool? SapPushed { get; set; }   // true = đã đẩy, false = chưa đẩy
        public DateTime? SapPushedFrom { get; set; }
        public DateTime? SapPushedTo { get; set; }
        public DateTime? ProductionFrom { get; set; }
        public DateTime? ProductionTo { get; set; }    public DateTime? CreatedFrom { get; set; }
        public DateTime? CreatedTo { get; set; }
    
    }

    public record NextLotNoResponse(string LotNo, int CategoryCode, string DatePart, int Sequence);

    // ── Error ─────────────────────────────────────────────────
    /// <summary>
    /// Shape thống nhất cho lỗi nghiệp vụ (HTTP 422) và lỗi trùng (HTTP 409).
    /// Lỗi DataAnnotations / JSON hỏng vẫn trả ProblemDetails mặc định (HTTP 400).
    /// </summary>
    public record ErrorResponse(
        string Code,
        string Message,
        IReadOnlyList<string>? Details = null);

    /// <summary>Mã lỗi nghiệp vụ của POST /api/lots.</summary>
    public static class LotErrors
    {
        // lotNo
        public const string LotNoInvalidFormat = "Lot.LotNoInvalidFormat";
        public const string LotNoCategoryMismatch = "Lot.LotNoCategoryMismatch";
        public const string LotNoDuplicated = "Lot.LotNoDuplicated";           // 409

        // master
        public const string CategoryNotFound = "Lot.CategoryNotFound";
        // Lot.LotTypeInvalid / Lot.DetailLevelInvalid không còn là lỗi nghiệp vụ:
        // converter chặn ngay lúc deserialize -> HTTP 400 ProblemDetails.

        // stocky
        public const string StockyCodeRequired = "Lot.StockyCodeRequired";
        public const string StockyCodeNotAllowed = "Lot.StockyCodeNotAllowed";

        // cấu trúc theo detailLevel
        public const string BoxesRequired = "Lot.BoxesRequired";
        public const string BoxesNotAllowedForBoxCount = "Lot.BoxesNotAllowedForBoxCount";
        public const string BoxCountRequired = "Lot.BoxCountRequired";
        public const string BoxLinesRequired = "Lot.BoxLinesRequired";
        public const string BoxNoDuplicated = "Lot.BoxNoDuplicated";

        // line
        public const string SerialNoRequired = "Lot.SerialNoRequired";
        public const string SerialNotAllowed = "Lot.SerialNotAllowed";
        public const string SerialDuplicated = "Lot.SerialDuplicated";
        public const string QtyRequired = "Lot.QtyRequired";
        public const string QtyNotDivisibleByCartonCount = "Lot.QtyNotDivisibleByCartonCount";
    }

    // ── Response ──────────────────────────────────────────────
    public record CreatePalletResponse(long Id, string LotNo, string DetailLevel, int BoxCount, int LineCount)
    {
        public static CreatePalletResponse From(Pallet lot, int lineCount)
            => new(lot.Id, lot.LotNo, lot.DetailLevel, lot.BoxCount ?? lot.Boxes.Count, lineCount);
    }

    public record PalletResponse(
        long Id,
        string LotNo,
        int CategoryCode,
        string CategoryName,
        string LotType,
        string? StockyCode,
        long? LocatorId,
        string? LocatorCode,
        string? AreaCode,
        string DetailLevel,
        int? BoxCount,
        int? TotalQty,
        string? Model,
        string InspectionStatus,
        bool IsUrgent,
        int? SapStatus,
        DateTime? SapPushedAt,
        DateTime? ProductionDate,
        DateTime CreatedAt,
        string? CreatedBy,
        List<BoxResponse> Boxes)
    {
        public static PalletResponse From(Pallet lot) => new(
            lot.Id, lot.LotNo, lot.CategoryCode, lot.CategoryName, lot.LotType, lot.StockyCode, lot.LocatorId, lot.LocatorCode, lot.AreaCode,
            lot.DetailLevel, lot.BoxCount, lot.TotalQty,
            lot.Model, lot.InspectionStatus,
            lot.IsUrgent, lot.SapStatus, lot.SapPushedAt, lot.ProductionDate,
            lot.CreatedAt, lot.CreatedBy,
            lot.Boxes.Select(BoxResponse.From).ToList());
    }

    public record BoxResponse(
    long Id,
    string BoxNo,
    string? PsnvPo,
    string? CustomerPo,
    string? Line,
    int? OqcStatus,
    string? LotName,
    string? payload,
    decimal? Length,
    decimal? Width,
    decimal? Height,
    decimal? Weight,
    DateTime? ProductionDate,
    List<BoxLineResponse> Lines)
    {
        public static BoxResponse From(Box b) => new(
            b.Id, b.BoxNo, b.PsnvPo, b.CustomerPo,
            b.Line, b.OQCStatus, b.LotName, b.RawPayload, 
            b.Length, b.Width, b.Height, b.Weight,
            b.ProductionDate,
            b.Lines.Select(BoxLineResponse.From).ToList());
    }

    public record BoxLineResponse(
        long Id,
        string Model,
        int Qty,
        string? SerialNo,
        DateTime? ProductionDate,
        int? CartonCount)
    {
        public static BoxLineResponse From(BoxLine l) => new(
            l.Id, l.Model, l.Qty, l.SerialNo, l.ProductionDate, l.CartonCount);
    }

    // ── Quét pallet (PDA / Quick Scan / Lưu kho) ──────────────────

    /// <summary>
    /// Phần dữ liệu phụ cần nạp thêm khi quét pallet. Truyền qua query
    /// <c>?include=boxes,history,suggestion</c> (không phân biệt hoa thường,
    /// giá trị lạ bị bỏ qua). Mặc định None -> chỉ thông tin lot + vị trí + model.
    /// </summary>
    [Flags]
    public enum PalletInclude
    {
        None = 0,
        Boxes = 1,
        History = 2,
        All = Boxes | History,
    }

    public static class PalletIncludeParser
    {
        public static PalletInclude Parse(string? raw)
        {
            if (string.IsNullOrWhiteSpace(raw)) return PalletInclude.None;

            var result = PalletInclude.None;
            foreach (var part in raw.Split(',', StringSplitOptions.RemoveEmptyEntries
                                              | StringSplitOptions.TrimEntries))
            {
                var key = part.Replace("_", "").Replace("-", "").ToLowerInvariant();
                result |= key switch
                {
                    "boxes" or "box" => PalletInclude.Boxes,
                    "history" => PalletInclude.History,
                    "all" => PalletInclude.All,
                    _ => PalletInclude.None,      // giá trị lạ -> bỏ qua, không 400
                };
            }
            return result;
        }
    }

    /// <summary>Tổng hợp theo model trong lot (gộp từ tất cả box).</summary>
    public record PalletModelSummary(string Model, int Qty, int BoxCount)
    {
        public static PalletModelSummary From(PalletModelQty m)
            => new(m.Model, m.TotalQty, m.BoxCount);
    }

    // LocatorHistoryResponse đã XOÁ. Lịch sử giờ đọc từ wms.stock_events.
    //
    // BREAKING CHANGE với client: ?include=history đổi shape response.
    // Cũ: locatorCode / fromStatus / toStatus / changedAt / changedBy
    // Mới: PalletEventBriefResponse — eventCode / eventAt / actor / toLocatorCode,
    //      tối đa 10 dòng gần nhất.
    //
    // CỐ Ý khác với timeline của màn lịch sử đầy đủ (PalletEventResponse, 12
    // trường): đây là phần kèm khi QUÉT trên PDA — màn hình nhỏ, mạng kho yếu,
    // người dùng chỉ liếc "pallet này vừa đi đâu". Cần đầy đủ thì gọi
    // GET /api/pallets/by-lot-no/{lotNo}/history.
    //
    // Route và tên flag include=history GIỮ NGUYÊN nên PDA không phải đổi URL,
    // nhưng Web + Flutter phải deploy đồng thời.

    /// <summary>
    /// Kết quả quét pallet — dùng chung cho Vị trí tạm, Quick Scan và Lưu kho.
    /// Thông tin lot + vị trí + tổng hợp model luôn có; <c>Boxes</c>, <c>History</c>,
    /// <c>SuggestedLocator</c> chỉ được nạp khi client yêu cầu qua <c>include</c>
    /// (null = không yêu cầu, khác với danh sách rỗng = có yêu cầu nhưng không có dữ liệu).
    /// </summary>
    public record PalletDetailResponse(
        long Id,
        string LotNo,
        int CategoryCode,
        string? CategoryName,
        string LotType,
        string? StockyCode,
        string DetailLevel,
        int? BoxCount,
        int? TotalQty,
        string InspectionStatus,
        bool IsUrgent,
        int? SapStatus,
        DateTime? SapPushedAt,
        DateTime? ProductionDate,
        string? Models,
        long? LocatorId,
        string? LocatorCode,
        string? AreaCode,
        string? AreaName,

        // Disposition: rework | refurbish | null (hàng thường).
        //
        // Thêm 12/11. PDA đã có sẵn chỗ vẽ badge RW/RB (QrLabelData
        // .badgeForDisposition) nhưng response này KHÔNG trả cột đó, nên không
        // màn hình nào trên PDA đánh dấu được pallet tái gia công — nhìn y hệt
        // pallet hàng thường.
        string? Disposition,

        // Pallet đang giữ serial của phiếu back hàng. Xem PalletLocationInfo
        // .IsReturnBack: nó là cái quyết định có nút "Out kho" hay không, nên
        // trả ra để soi được tại máy khi nút không hiện.
        bool IsReturnBack,

        IReadOnlyList<string> AllowedActions,
        IReadOnlyList<PalletModelSummary> ModelSummary,
        IReadOnlyList<BoxResponse>? Boxes,
        IReadOnlyList<PalletEventBriefResponse>? History)
    {
        public static PalletDetailResponse From(
            PalletLocationInfo info,
            IReadOnlyList<PalletModelQty> modelQtys,
            Pallet? full = null,
            IReadOnlyList<PalletEventBrief>? history = null
        )
        {
            return new PalletDetailResponse(
                info.Id, info.LotNo, info.CategoryCode, info.CategoryName,
                info.LotType, info.StockyCode, info.DetailLevel,
                info.BoxCount, info.TotalQty,
                info.InspectionStatus, info.IsUrgent,
                info.SapStatus, info.SapPushedAt, info.ProductionDate,
                info.Models,
                info.LocatorId, info.LocatorCode, info.AreaCode, info.AreaName,
                info.Disposition, info.IsReturnBack,
                BuildAllowedActions(info),
                modelQtys.Select(PalletModelSummary.From).ToList(),
                full?.Boxes.Select(BoxResponse.From).ToList(),
                history?.Select(PalletEventBriefResponse.From).ToList());
        }

        /// <summary>
        /// Hành động được phép — dùng để ẩn/hiện nút. Mỗi loại khu có move riêng
        /// để màn nào chỉ thấy đúng thao tác của khu đó.
        /// </summary>
        /// <summary>
        /// Những thao tác màn hình được phép mở cho pallet này.
        ///
        /// ⚠ ĐÂY LÀ CỔNG CHẶN THẬT, KHÔNG PHẢI GỢI Ý GIAO DIỆN. PDA lọc danh
        /// sách này xuống đúng MỘT action cho mỗi màn (PalletFlow.actionsFor),
        /// nên thiếu một action ở đây là màn đó TRẮNG TRƠN — người dùng đọc ra
        /// thành "bị chặn", không phải "chưa có nút".
        ///
        /// Và nó phải khớp với các cổng chặn thật ở tầng nghiệp vụ
        /// (PalletService.EnsureStorable, IReturnBackMoveGate): lệch một bên là
        /// hoặc thấy nút rồi ăn lỗi, hoặc được phép mà không thấy nút.
        /// </summary>
        private static IReadOnlyList<string> BuildAllowedActions(PalletLocationInfo x)
        {
            // Hàng tái gia công (disposition rework/refurbish) KHÔNG đi theo
            // vòng đời của hàng sản xuất, nên ba nhánh dưới đây đều phải tách:
            //
            //  1. Nó mang inspection_status = 'ng' suốt vòng đời — NG là BẢN
            //     CHẤT của hàng tái gia công, không phải kết quả OQC. Mọi điều
            //     kiện `is "pass"` đều trượt.
            //  2. Nó KHÔNG qua khu nhận hàng: SCS WH tạo Pallet ID ngay tại chỗ
            //     dỡ hàng của khách, nên lưu kho thẳng từ trạng thái chưa có vị trí.
            //  3. Nó PHẢI ra được khu Nhận hàng TỪ TRONG KHO — đó chính là hành
            //     động giao cho FA, và là đường duy nhất để giao.
            //
            // HOẶC IsReturnBack: pallet đang giữ serial của phiếu back nhưng cột
            // disposition chưa có dấu (dữ liệu cũ, hoặc sửa tay dưới DB). Chỉ
            // soi disposition thì những pallet đó mất nút "Out kho" và WH đọc ra
            // thành "chức năng chưa làm". Cổng duyệt thật vẫn là
            // IReturnBackMoveGate nên mở nút ở đây không mở đường cho hàng thường.
            var isRework = !string.IsNullOrWhiteSpace(x.Disposition) || x.IsReturnBack;

            // Chưa gán vị trí.
            if (x.LocatorId is null)
            {
                // Hàng thường: chỉ gán vào khu nhận hàng.
                // Hàng RW/RB: lưu kho thẳng được luôn (điểm 2).
                if (isRework) return new[] { "assign", "store" };
                return new[] { "assign" };
            }

            var mapType = x.MapType;

            if (mapType == MapTypes.Receiving)
            {
                // Lưu kho được khi đã có kết quả kiểm, HOẶC là hàng RW/RB
                // (điểm 1 — nếu xét theo trạng thái kiểm thì không bao giờ mở).
                var canStore = x.InspectionStatus is "pass" or "pending_result" || isRework;
                if (canStore) return new[] { "move_receiving", "store" };
                return new[] { "move_receiving" };
            }

            if (mapType == MapTypes.Storing)
            {
                // Hàng RW/RB: thêm đường ra khu Nhận hàng = giao cho FA (điểm 3).
                // KHÔNG có "vanning" — hàng tái gia công không được đóng cont,
                // và nhánh `is "pass"` cũng không bao giờ trúng vì nó là 'ng'.
                if (isRework) return new[] { "move_storing", "move_receiving" };

                if (x.InspectionStatus is "pass") return new[] { "move_storing", "vanning" };
                return new[] { "move_storing" };
            }

            if (mapType == MapTypes.Vanning) return new[] { "move_vanning" };

            return Array.Empty<string>();
        }
    }

    /// <summary>Gán / chuyển lot sang vị trí có mã locatorCode.</summary>
    public record AssignLocatorRequest(
        [Required][MaxLength(50)] string LocatorCode,
        string? AllowedMapType = null);

    /// <summary>
    /// Kết quả gán / chuyển / rời vị trí.
    /// Warning != null khi vị trí đích đã có lot khác (vẫn cho, chỉ cảnh báo).
    /// </summary>
    public record LocatorChangeResponse(
        long LotId,
        string LotNo,
        long? FromLocatorId,
        string? FromLocatorCode,
        long? ToLocatorId,
        string? ToLocatorCode,
        string? Warning);

    // ── Sửa SL pallet box_count ────────────────────────────────────

    /// <summary>
    /// PUT /api/pallets/{id}/box-count. Tổng SL = BoxCount × StandardPacking.
    /// StandardPacking null = giữ quy cách hiện tại của pallet.
    /// Reason ghi vào payload event (vd "hdsoft_compare") để biết sửa từ đâu.
    /// </summary>
    public record UpdateBoxCountRequest(
        [Range(1, int.MaxValue)] int BoxCount,
        [Range(1, int.MaxValue)] int? StandardPacking,
        int? ExpectedQty,
        [MaxLength(50)] string? Reason);

    public record UpdateBoxCountResponse(
        long LotId,
        string LotNo,
        int BoxCountBefore,
        int BoxCountAfter,
        int StandardPackingBefore,
        int StandardPackingAfter,
        int QtyBefore,
        int QtyAfter);

    /// <summary>Trạng thái trước khi sửa, đọc trong cùng transaction.</summary>
    public record BoxCountUpdateResult(int BoxCountBefore, int StandardPackingBefore);

    // ── Xoá thùng khỏi pallet ──────────────────────────────────────

    /// <summary>
    /// POST /api/pallets/{id}/boxes/delete. Chỉ pallet serial / box_line (box_count không có thùng).
    /// Reason ghi vào payload event (vd "hdsoft_compare") để biết xoá từ đâu.
    /// </summary>
    public record DeleteBoxesRequest(
        [Required, MinLength(1), MaxLength(500)] List<long> BoxIds,
        [MaxLength(50)] string? Reason);

    public record DeleteBoxesResponse(
        long LotId,
        string LotNo,
        int BoxesDeleted,
        int LinesDeleted,
        int QtyDeleted,
        int BoxCountBefore,
        int BoxCountAfter);

    // ── Tách pallet ────────────────────────────────────────────────

    /// <summary>Loại pallet đích khi tách.</summary>
    public enum SplitTargetType
    {
        Existing, // tách sang lot đã có
        New,      // tách sang lot mới (tự sinh pallet_id)
    }

    /// <summary>
    /// Yêu cầu tách pallet.
    ///
    /// Hai cách tách, chọn theo detail_level của pallet GỐC chứ không theo
    /// client gửi gì:
    ///   serial / box_line -> <paramref name="BoxIds"/>, quét từng thùng.
    ///   box_count         -> <paramref name="BoxQty"/>, vì loại này chỉ có số
    ///                        thùng, không có dòng nào trong wms.boxes để quét.
    /// </summary>
    /// <param name="ConfirmModelMismatch">
    /// Người dùng đã thấy cảnh báo "pallet đích khác model" và đồng ý tách.
    ///
    /// Mặc định false — khác model vẫn bị chặn bằng Split.ModelMismatch như
    /// trước, nên client cũ không đổi hành vi. Chỉ khi client gửi true thì
    /// server mới cho gộp, và ghi lại việc bỏ qua cảnh báo vào note/payload
    /// của 2 event PALLET_SPLIT_OUT / PALLET_SPLIT_IN.
    ///
    /// KHÔNG nới cho category (luôn chặn) và KHÔNG nới cho pallet box_count
    /// (xem chú thích trong PalletService.SplitInternalAsync).
    /// </param>
    public record SplitPalletRequest(
        string SourceLotNo,
        IReadOnlyList<long> BoxIds,
        SplitTargetType TargetType,
        string? TargetLotNo,          // chỉ dùng khi TargetType = Existing
        int? BoxQty = null,           // chỉ dùng khi pallet gốc là box_count
        bool ConfirmModelMismatch = false);

    /// <summary>Kết quả tách.</summary>
    public record SplitPalletResponse(
        string SourceLotNo,
        int SourceRemainingBoxes,
        string TargetLotNo,
        bool TargetIsNew,
        int MovedBoxes);
}
