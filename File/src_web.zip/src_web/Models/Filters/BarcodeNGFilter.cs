﻿using Refit;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class BarcodeNGFilter : BaseFilter
    {
        public BarcodeType? Type { get; set; }
        public string? Vendor { get; set; }
        [Display(Name = "Delivery Plan")]
        public string? DeliveryPlanNo { get; set; }
        public string? Plant { get; set; }
        public string? Category { get; set; }
        public string? Sloc { get; set; }
        public string? Material { get; set; }
        [Display(Name = "Date Print")]
        [Query(Format = "yyyy-MM-dd")]
        public DateTime? DatePrint { get; set; } = DateTime.Now;

    }
}
