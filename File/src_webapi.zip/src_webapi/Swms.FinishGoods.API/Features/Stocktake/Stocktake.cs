namespace Swms.FinishGoods.API.Features.Stocktake;

/// <summary>Tóm tắt 1 phiếu kiểm kê (cho danh sách).</summary>
public class CountSummary
{
    public long Id { get; set; }
    public string DocNo { get; set; } = string.Empty;
    public string? CountType { get; set; }        // morning | shipment | monthly
    public DateTime CountDate { get; set; }
    public string DocStatus { get; set; } = "draft"; // draft | counting | counted | confirmed
    public string? SourceRef { get; set; }
    public string? Description { get; set; }
    public int TotalLines { get; set; }
    public int CountedLines { get; set; }
    public int DiscrepancyLines { get; set; }

    /// <summary>
    /// Số dòng PHẢI ĐẾM (is_required = 1) và số trong đó đã đếm.
    ///
    /// Tách khỏi TotalLines/CountedLines chứ không thay nghĩa chúng: phiếu
    /// sáng vẫn mang đủ mọi pallet của ô để Web hiện được bối cảnh, nên
    /// "phiếu có bao nhiêu dòng" và "còn phải đếm bao nhiêu" là hai con số
    /// khác nhau. Tiến độ và nút đóng phiếu đi theo CẶP DƯỚI.
    /// </summary>
    public int RequiredLines { get; set; }
    public int CountedRequiredLines { get; set; }
    public DateTime CreatedAt { get; set; }
}

/// <summary>1 dòng kiểm kê = 1 pallet (lot) tại 1 vị trí.</summary>
public class CountLine
{
    public long Id { get; set; }
    public int LineNo { get; set; }
    public int ProductId { get; set; }
    public string? ProductName { get; set; }
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = string.Empty;
    public long? LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public int QtySystem { get; set; }
    public int? QtyCount { get; set; }

    /// <summary>Số box theo hệ thống; số lượng = box x StandardPacking.</summary>
    public int? BoxCountSystem { get; set; }
    /// <summary>Số box người kiểm đếm được (dấu vết nhập tay).</summary>
    public int? BoxCountCounted { get; set; }
    /// <summary>Số cái/box của model, chụp lúc tạo phiếu (master.models).</summary>
    public int? StandardPacking { get; set; }

    public bool IsAdjusted { get; set; }
    public string? Note { get; set; }

    /// <summary>Pallet phát sinh: tìm thấy ở ô này khi kiểm, hệ thống không ghi ở đây.</summary>
    public bool IsFound { get; set; }
    /// <summary>Vị trí hệ thống đang ghi cho pallet phát sinh (lúc quét).</summary>
    public string? SystemLocatorCode { get; set; }

    /// <summary>
    /// Dòng này có phải ĐẾM hay không — chốt lúc TẠO phiếu, không tính lại.
    ///
    /// Phiếu SÁNG chọn phạm vi theo Ô: ô nào có biến động thì mọi pallet đang
    /// đứng ở đó đều thành dòng. Một ô sẵn 3 model từ hôm trước, hôm nay thêm
    /// 1 model, thì phiếu có 4 dòng nhưng chỉ 1 dòng phải đếm. Cờ này tách
    /// đúng dòng đó; 3 dòng kia vẫn nằm trong phiếu để người đọc trên Web thấy
    /// đủ bối cảnh của ô, nhưng không vào tiến độ và không chặn đóng phiếu.
    ///
    /// Ô có biến động mà pallet đã chuyển đi hết sinh một dòng Ô TRỐNG, và
    /// dòng đó LÀ phải kiểm — người đi kiểm xác nhận ô rỗng thật.
    ///
    /// Phiếu CUỐI THÁNG kiểm hết mọi ô nên mọi dòng đều true.
    /// </summary>
    public bool IsRequired { get; set; } = true;

    /// <summary>Thứ tự đi kiểm kê theo bản đồ (1 = kiểm đầu tiên).</summary>
    public int WalkSeq { get; set; }
    public string? AreaCode { get; set; }
    public string? AreaName { get; set; }
}

public class CountDetail
{
    public CountSummary Header { get; set; } = new();
    public IReadOnlyList<CountLine> Lines { get; set; } = new List<CountLine>();
}

public class CreateCountResult
{
    public long Id { get; set; }
    public string DocNo { get; set; } = string.Empty;
    public int LineCount { get; set; }
}

/// <summary>Kết quả ghi pallet phát sinh.</summary>
public class AddFoundResult
{
    public long LineId { get; set; }
    /// <summary>false = pallet vốn thuộc ô này (đã có dòng) — không tạo dòng mới.</summary>
    public bool Created { get; set; }
}
