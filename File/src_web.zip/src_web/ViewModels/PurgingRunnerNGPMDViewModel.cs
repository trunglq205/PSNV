﻿using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.PMD;

namespace SWMS_WebTool.ViewModels
{
    public class PurgingRunnerNGPMDViewModel : TableViewModel<PurgingRunnerNGPMD, PurgingRunnerNGPMDFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, PurgingRunnerNGPMDFilter? filter = null)
        {
            return new
            {
                Plant = filter?.Plant ?? Filter.Plant,
                Material = filter?.Material ?? Filter.Material,
                TimeCreate = filter?.TimeCreate ?? DateTime.Now,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
