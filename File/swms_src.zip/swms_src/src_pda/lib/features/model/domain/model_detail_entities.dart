/// Chi tiết model (Quick Scan / tra cứu). Khớp ModelResponse của API.
///
/// Kích thước (length/width/height, cargo*) tính bằng **mm**.
/// boxPerLayer / boxPerPallet / setPerPallet / cargo* do SERVER tính ra,
/// null khi model chưa cấu hình xếp pallet — app không tự tính lại.
class ModelDetail {
  /// Rack hiện có 4 tầng — khớp RackRowRule.Min/Max của API.
  static const int rackRowMin = 1;
  static const int rackRowMax = 4;

  final int id;
  final String code;
  final String? gtin;

  final int categoryId;
  final int categoryCode;
  final String categoryName;

  final int length;
  final int width;
  final int height;
  final int standardPacking;

  // Quy cách xếp pallet
  final int? layerLimit;
  final int? layerCount;
  final int? stackingLength;
  final int? stackingWidth;
  final int? boxPerLayer;
  final int? boxPerPallet;
  final int? setPerPallet;
  final int? cargoLength;
  final int? cargoWidth;
  final int? cargoHeight;

  // Gợi ý lưu kho
  final int? suggestAreaId;
  final String? suggestAreaCode;
  final String? suggestAreaName;
  final List<int> suggestRackRow;

  final bool isActive;
  final DateTime? createdAt;

  const ModelDetail({
    required this.id,
    required this.code,
    required this.categoryId,
    required this.categoryCode,
    required this.categoryName,
    required this.length,
    required this.width,
    required this.height,
    required this.standardPacking,
    required this.isActive,
    this.gtin,
    this.layerLimit,
    this.layerCount,
    this.stackingLength,
    this.stackingWidth,
    this.boxPerLayer,
    this.boxPerPallet,
    this.setPerPallet,
    this.cargoLength,
    this.cargoWidth,
    this.cargoHeight,
    this.suggestAreaId,
    this.suggestAreaCode,
    this.suggestAreaName,
    this.suggestRackRow = const [],
    this.createdAt,
  });

  bool get hasStacking => boxPerPallet != null;
  bool get hasSuggestArea => suggestAreaId != null;
  bool get hasSuggestion => hasSuggestArea || suggestRackRow.isNotEmpty;

  /// Copy riêng cho tầng rack gợi ý (optimistic update).
  ModelDetail copyWithRackRows(List<int> rows) => _copySuggestion(
    areaId: suggestAreaId,
    areaCode: suggestAreaCode,
    areaName: suggestAreaName,
    rows: rows,
  );

  /// Copy riêng cho khu gợi ý (optimistic update). Nhận null tường minh.
  ModelDetail copyWithSuggestArea({
    required int? id,
    required String? code,
    required String? name,
  }) => _copySuggestion(
    areaId: id,
    areaCode: code,
    areaName: name,
    rows: suggestRackRow,
  );

  ModelDetail _copySuggestion({
    required int? areaId,
    required String? areaCode,
    required String? areaName,
    required List<int> rows,
  }) => ModelDetail(
    id: id,
    code: code,
    gtin: gtin,
    categoryId: categoryId,
    categoryCode: categoryCode,
    categoryName: categoryName,
    length: length,
    width: width,
    height: height,
    standardPacking: standardPacking,
    layerLimit: layerLimit,
    layerCount: layerCount,
    stackingLength: stackingLength,
    stackingWidth: stackingWidth,
    boxPerLayer: boxPerLayer,
    boxPerPallet: boxPerPallet,
    setPerPallet: setPerPallet,
    cargoLength: cargoLength,
    cargoWidth: cargoWidth,
    cargoHeight: cargoHeight,
    suggestAreaId: areaId,
    suggestAreaCode: areaCode,
    suggestAreaName: areaName,
    suggestRackRow: rows,
    isActive: isActive,
    createdAt: createdAt,
  );
}

/// Giá trị form chỉnh sửa model. Khớp UpdateModelRequest của API
/// (`PUT /api/models/{id}`) — PUT ghi đè TOÀN BỘ nên phải mang đủ mọi field,
/// kể cả gợi ý lưu kho (giữ nguyên từ bản hiện tại).
///
/// Không có isActive: PDA luôn gửi true (xem ModelUpdateRequest.fromEdit).
class ModelEdit {
  // Giới hạn khớp DataAnnotations của API.
  static const int maxDimension = 100000;
  static const int maxLayer = 100;
  static const int maxStacking = 100;
  static const int maxGtinLength = 14;

  final String? gtin;
  final int length;
  final int width;
  final int height;
  final int standardPacking;
  final int? layerLimit;
  final int? layerCount;
  final int? stackingLength;
  final int? stackingWidth;
  final int? suggestAreaId;
  final List<int> suggestRackRow;

  const ModelEdit({
    required this.gtin,
    required this.length,
    required this.width,
    required this.height,
    required this.standardPacking,
    required this.layerLimit,
    required this.layerCount,
    required this.stackingLength,
    required this.stackingWidth,
    required this.suggestAreaId,
    required this.suggestRackRow,
  });
}