﻿using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class CategoryFilter : BaseFilter
    {
        [Display(Name = "Category Name")]
        public string CategoryName { get; set; }

        [Display(Name = "Short Name")]
        public string ShortName { get; set; }

    }
}
