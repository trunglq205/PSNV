import 'package:flutter/foundation.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_suggestion.dart';

/// State màn IN MỚI Part Card — ĐỒNG BỘ.
/// Loading/error của call API do `appActionProvider` lo (giống Receiving).
///
/// Sửa / tách / gộp tem đã in KHÔNG ở đây — xem `PartCardActionState`.
@immutable
class PartCardState {
  const PartCardState({
    this.mode = PartCardMode.single,
    this.step = PartCardStep.input,
    this.modelInput = '',
    this.form,
    this.copies = 1,
    this.pendingHistory = const [],
    this.suggestions = PartCardSuggestions.empty,
    this.loadingSuggestions = false,
  });

  /// 1 mã / nhiều mã trên cùng 1 tem.
  final PartCardMode mode;

  /// Bước hiện tại.
  final PartCardStep step;

  /// Chuỗi model đang nhập tay / vừa quét ở bước 1.
  final String modelInput;

  /// Dữ liệu nhãn — tự điền từ lịch sử in, user sửa được ở bước 2.
  final PartCardForm? form;

  /// Số phiếu cần in (bulk), mỗi phiếu 1 Card_ID riêng. 1–999.
  final int copies;

  /// Gợi ý từ lịch sử in của model đầu: tự điền + chip hộp hay dùng.
  final PartCardSuggestions suggestions;

  /// Đang tải lịch sử in để tự điền — UI hiện skeleton thay vì form rỗng
  /// (form rỗng sẽ báo thiếu field → nháy đỏ).
  final bool loadingSuggestions;

  /// Các phiếu ĐÃ IN RA GIẤY nhưng CHƯA lưu được lịch sử.
  /// Có giá trị → bấm lại chỉ gọi API, KHÔNG in lại.
  final List<PartCardPrintParams> pendingHistory;

  /// Số dòng sẽ bị xoá nếu đổi sang chế độ 1 mã (0 = không mất gì).
  /// UI dùng để quyết định có hỏi xác nhận hay không.
  int get droppedOnSingle {
    final count = form?.lines.length ?? 0;
    return count > 1 ? count - 1 : 0;
  }

  bool get canLookup => modelInput.trim().isNotEmpty;

  bool get hasPrinted => pendingHistory.isNotEmpty;

  PartCardState copyWith({
    PartCardMode? mode,
    PartCardStep? step,
    String? modelInput,
    PartCardForm? form,
    int? copies,
    List<PartCardPrintParams>? pendingHistory,
    PartCardSuggestions? suggestions,
    bool? loadingSuggestions,
    bool clearForm = false,
    bool clearPending = false,
  }) {
    return PartCardState(
      mode: mode ?? this.mode,
      step: step ?? this.step,
      modelInput: modelInput ?? this.modelInput,
      form: clearForm ? null : form ?? this.form,
      copies: copies ?? this.copies,
      pendingHistory: clearPending
          ? const []
          : pendingHistory ?? this.pendingHistory,
      suggestions: clearForm
          ? PartCardSuggestions.empty
          : suggestions ?? this.suggestions,
      loadingSuggestions: loadingSuggestions ?? this.loadingSuggestions,
    );
  }
}
