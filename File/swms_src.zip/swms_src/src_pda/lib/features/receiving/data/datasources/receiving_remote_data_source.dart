import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/receiving/data/models/create_lot_request_model.dart';
import 'package:swms_finish_goods/features/receiving/data/models/create_lot_response_model.dart';
import 'package:swms_finish_goods/features/receiving/data/models/next_lot_no_model.dart';

part 'receiving_remote_data_source.g.dart';

@RestApi()
abstract class ReceivingRemoteDataSource {
  factory ReceivingRemoteDataSource(Dio dio, {String baseUrl}) =
      _ReceivingRemoteDataSource;

  /// POST tạo pallet mới. Hỗ trợ cả 4 case:
  /// - serial:    pallet → box → serial (mỗi serial 1 line, qty = 1)
  /// - box_line:  pallet → box (có/không inner carton), không serial
  /// - box_count: chỉ khai số box, không có box detail
  @POST('/api/pallets')
  Future<CreateLotResponseModel> createLot(@Body() CreateLotRequestModel body);

  /// POST kích hoạt lot nháp (is_deleted 1 → 0) sau khi in nhãn thành công.
  @POST('/api/pallets/{id}/confirm')
  Future<CreateLotResponseModel> confirmCreateLot(@Path('id') int id);

  /// GET đề xuất lotNo kế tiếp cho category theo ngày server.
  /// Không giữ chỗ: hai lần quét sát nhau có thể nhận cùng số — khi POST
  /// /api/pallets bị 409 Lot.LotNoDuplicated thì gọi lại để xin số mới.
  @GET('/api/pallets/next-lot-no')
  Future<NextLotNoModel> fetchNextLotNo(
    @Query('categoryCode') int categoryCode,
  );
}
