import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/utils/printing/printer.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/printer_status_bar.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_text_field.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/presentation/widgets/part_card_preview_card.dart';

/// Bước 3: kết nối máy in → chọn số phiếu → xem preview → in.
///
/// Màn này chỉ IN MỚI — mỗi phiếu 1 Card_ID mới.
class PartCardPrintBody extends StatelessWidget {
  const PartCardPrintBody({
    super.key,
    required this.form,
    required this.mode,
    required this.printer,
    required this.copies,
    required this.onCopiesChanged,
    this.printed = false,
    this.onChangePrinter,
  });

  final PartCardForm form;
  final PartCardMode mode;

  /// Máy in đang chọn (`selectedPrinterProvider`); null = chưa chọn.
  final PrinterDevice? printer;

  /// Số phiếu sẽ in (mỗi phiếu 1 Card_ID riêng).
  final int copies;
  final ValueChanged<int> onCopiesChanged;

  /// Đã in ra giấy nhưng chưa lưu được lịch sử.
  final bool printed;

  final VoidCallback? onChangePrinter;

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: [
        PrinterStatusBar(device: printer, onChange: onChangePrinter),
        const SizedBox(height: AppDimens.sm),
        _CopiesBar(value: copies, onChanged: onCopiesChanged),
        const SizedBox(height: AppDimens.sm),
        PartCardPreviewCard(
          form: form,
          mode: mode,
          success: printed,
          status: printed
              ? LocaleKeys.part_card_print_status_printed.tr()
              : LocaleKeys.part_card_print_status_waiting.tr(),
        ),
      ],
    );
  }
}

/// Số phiếu cần in — gõ trực tiếp hoặc tăng/giảm bằng nút.
class _CopiesBar extends StatefulWidget {
  const _CopiesBar({required this.value, required this.onChanged});

  final int value;
  final ValueChanged<int> onChanged;

  static const int min = 1;
  static const int max = 999;
  static const int maxDigits = '$max'.length;

  @override
  State<_CopiesBar> createState() => _CopiesBarState();
}

class _CopiesBarState extends State<_CopiesBar> {
  final _controller = TextEditingController();
  final _focusNode = FocusNode();

  @override
  void initState() {
    super.initState();
    _controller.text = '${widget.value}';
    _focusNode.addListener(_onFocusChange);
  }

  @override
  void dispose() {
    _focusNode
      ..removeListener(_onFocusChange)
      ..dispose();
    _controller.dispose();
    super.dispose();
  }

  void _onFocusChange() {
    if (_focusNode.hasFocus) {
      // Chọn hết để gõ đè.
      _controller.selection = TextSelection(
        baseOffset: 0,
        extentOffset: _controller.text.length,
      );
    } else {
      _commit();
    }
  }

  /// Đang gõ: chỉ đẩy lên parent khi số hợp lệ.
  void _onTextChanged(String text) {
    final n = int.tryParse(text);
    if (n != null &&
        n >= _CopiesBar.min &&
        n <= _CopiesBar.max &&
        n != widget.value) {
      widget.onChanged(n);
    }
  }

  /// Rời ô / Done: ô trống hoặc 0 → về giá trị hợp lệ.
  void _commit() {
    final n = (int.tryParse(_controller.text) ?? widget.value)
        .clamp(_CopiesBar.min, _CopiesBar.max);
    if (n != widget.value) widget.onChanged(n);
    // value không đổi thì AppTextField không tự ghi đè → sửa tay.
    if (_controller.text != '$n') {
      _controller.value = TextEditingValue(
        text: '$n',
        selection: TextSelection.collapsed(offset: '$n'.length),
      );
    }
  }

  void _step(int delta) {
    final n = (widget.value + delta).clamp(_CopiesBar.min, _CopiesBar.max);
    if (n != widget.value) widget.onChanged(n);
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final value = widget.value;

    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Row(
        children: [
          Expanded(
            child: Text(
              LocaleKeys.part_card_print_copies_label.tr(),
              style: AppTextStyles.caption.copyWith(
                fontWeight: FontWeight.w700,
                letterSpacing: .3,
                color: swms.text3,
              ),
            ),
          ),
          _RoundIconButton(
            icon: Icons.remove_rounded,
            onTap: value > _CopiesBar.min ? () => _step(-1) : null,
          ),
          const SizedBox(width: AppDimens.xs),
          SizedBox(
            width: 72,
            child: AppTextField(
              kind: AppInputKind.number,
              controller: _controller,
              focusNode: _focusNode,
              value: '$value',
              dense: true,
              filled: true,
              textAlign: TextAlign.center,
              fontSize: 18,
              maxLength: _CopiesBar.maxDigits,
              onChanged: _onTextChanged,
              onSubmitted: (_) => _commit(),
            ),
          ),
          const SizedBox(width: AppDimens.xs),
          _RoundIconButton(
            icon: Icons.add_rounded,
            primary: true,
            onTap: value < _CopiesBar.max ? () => _step(1) : null,
          ),
        ],
      ),
    );
  }
}

class _RoundIconButton extends StatelessWidget {
  const _RoundIconButton({
    required this.icon,
    required this.onTap,
    this.primary = false,
  });

  final IconData icon;
  final VoidCallback? onTap;
  final bool primary;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final enabled = onTap != null;

    return Material(
      color: primary && enabled ? swms.success : swms.card2,
      borderRadius: BorderRadius.circular(AppDimens.sm),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(AppDimens.sm),
        child: SizedBox(
          width: AppDimens.hitSm,
          height: AppDimens.hitSm,
          child: Icon(
            icon,
            size: 18,
            color: !enabled
                ? swms.text4
                : (primary ? Colors.white : swms.text2),
          ),
        ),
      ),
    );
  }
}
