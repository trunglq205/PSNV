﻿namespace SWMS_WebTool.Models
{
    public class BlockSapSchedule : AuditableEntity
    {
        public byte? KittingType { get; set; }
        public DateTime? BlockDate { get; set; }
        public string BlockTime { get; set; }
        public DateTime? OpenDate { get; set; }
        public string OpenTime { get; set; }
    }

    public class BlockSapSchedulePlan : AuditableEntity
    {
        public byte? KittingType { get; set; }
        public string Plant { get; set; }
        public string Category { get; set; }
    }
}
