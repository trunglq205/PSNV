namespace Swms.FinishGoods.API.Features.WeightSys.PalletSync.Business;

public interface IPalletWeightSyncService
{
    Task<int> SyncBoxWeightAsync(string palletId);
}