using Microsoft.Extensions.Localization;
using Microsoft.Extensions.Logging;
using Swms.FinishGoods.Api.Features.Models.Business;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Foss.Api;
using Swms.FinishGoods.API.Features.Foss.Business;
using Swms.FinishGoods.API.Features.Foss.PalletSync.Api;
using Swms.FinishGoods.API.Features.Foss.PalletSync.DataAccess;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.WeightSys.Business;
using Swms.FinishGoods.API.Features.WeightSys.PalletSync.Business;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.Foss.PalletSync.Business
{
    /// <summary>Kết quả bổ sung thùng / serial từ Foss cho pallet đã có.</summary>
    public sealed record FossTopUpResult(
        int BoxesAdded,
        int LinesAdded,
        bool OqcChanged,
        int FossBoxCount = 0,
        IReadOnlyList<FossSkippedBox>? Skipped = null)
    {
        public static readonly FossTopUpResult None = new(0, 0, false);
        public bool Changed => BoxesAdded > 0 || LinesAdded > 0;
    }

    /// <summary>
    /// Đồng bộ Foss -> pallet SWMS (trước đây nằm trong PalletService).
    ///   - Tạo pallet từ Foss (from-foss, job FA)
    ///   - Bổ sung thùng / serial Foss thêm sau khi SWMS đã tạo (foss-top-up, job FA)
    ///   - Đồng bộ OQC theo từng thùng: part_cards hoặc Foss STATUS_FA (oqc-sync, job OQC)
    ///
    /// Không tự đổi vị trí. Phần nghiệp vụ SWMS (dựng response quét) gọi qua IPalletService.
    /// </summary>
    public class PalletFossSyncService : IPalletFossSyncService
    {
        /// <summary>Lấy từ bảng quy đổi của enum thay vì gõ chuỗi — cùng nguồn với PalletService.</summary>
        private static readonly string DetailLevelBoxCount =
            PalletDetailLevel.BoxCount.ToDbValue();

        /// <summary>Thùng tạo từ thẻ in có raw_payload bắt đầu bằng tiền tố này.</summary>
        private const string PartCardPayloadPrefix = "Card_ID=";

        private readonly IPalletService _pallets;
        private readonly ILotRepository _repo;
        private readonly IPalletFossRepository _fossRepo;
        private readonly ICategoryRepository _categoryRepo;
        private readonly IFossService _fossService;
        private readonly IModelService _modelService;
        private readonly IPalletWeightSyncService _weightService;
        private readonly ICurrentUser _currentUser;
        private readonly IStringLocalizer<SharedResource> _localizer;
        private readonly ILogger<PalletFossSyncService> _logger;

        public PalletFossSyncService(
            IPalletService pallets,
            ILotRepository repo,
            IPalletFossRepository fossRepo,
            ICategoryRepository categoryRepo,
            IFossService fossService,
            IModelService modelService,
            ICurrentUser currentUser,
            IPalletWeightSyncService weightService,
            IStringLocalizer<SharedResource> localizer,
            ILogger<PalletFossSyncService> logger)
        {
            _pallets = pallets;
            _repo = repo;
            _fossRepo = fossRepo;
            _categoryRepo = categoryRepo;
            _fossService = fossService;
            _modelService = modelService;
            _weightService = weightService;
            _currentUser = currentUser;
            _localizer = localizer;
            _logger = logger;
        }

        // ── Tạo pallet từ Foss ───────────────────────────────────────

        /// <summary>
        /// Tạo lot từ Foss theo mã quét.
        ///   - Chưa có trong SWMS -> tạo từ Foss.
        ///   - Đã có -> bổ sung thùng / serial Foss thêm vào sau lần tạo (Foss tạo pallet
        ///     chưa xong mà SWMS đã lấy). Bổ sung lỗi (Foss sập, timeout...) KHÔNG chặn quét:
        ///     pallet đã có thì vẫn trả như cũ.
        /// </summary>
        public async Task<PalletDetailResponse> CreateFromFossAsync(string lotNo, PalletInclude include)
        {
            lotNo = NormalizeLotNo(lotNo);
            var sync = new IntegrationSyncContext(StockEventSources.Foss, _currentUser.FullName);

            var info = await _repo.GetLocationInfoByLotNoAsync(lotNo);
            if (info is null)
            {
                info = await CreateLotFromFossAsync(lotNo, sync);
            }
            else
            {
                try
                {
                    if ((await TopUpFromFossAsync(lotNo, sync)).Changed)
                        info = await _repo.GetLocationInfoByIdAsync(info.Id) ?? info;
                }
                catch (Exception ex)
                {
                    _logger.LogWarning(ex, "Foss top-up failed for {LotNo}", lotNo);
                }
            }

            return await _pallets.BuildDetailAsync(info, include);
        }

        // ── Bổ sung thùng từ Foss ────────────────────────────────────

        /// <summary>
        /// API POST /{lotNo}/foss-top-up: bổ sung thùng / serial còn thiếu từ Foss cho 1 pallet,
        /// trả chi tiết pallet sau khi bổ sung kèm lý do từng thùng bị bỏ qua.
        /// Khác bản job nền: pallet không phù hợp thì báo lỗi rõ lý do thay vì bỏ qua.
        /// </summary>
        public async Task<FossTopUpResponse> TopUpFromFossAsync(string lotNo, PalletInclude include)
        {
            lotNo = NormalizeLotNo(lotNo);
            var sync = new IntegrationSyncContext(StockEventSources.Foss, _currentUser.FullName);

            var r = await TopUpCoreAsync(lotNo, sync, strict: true);

            var info = await _repo.GetLocationInfoByLotNoAsync(lotNo)
                ?? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"]);
            var detail = await _pallets.BuildDetailAsync(info, include);

            var skipped = (r.Skipped ?? [])
                .Select(s => new FossSkippedBoxResponse(
                    s.BoxNo,
                    s.Reason,
                    s.HeldByPalletId,
                    SkipMessage(s)))
                .ToList();

            var byPallet = skipped
                .GroupBy(s => (s.HeldByPalletId, s.Reason))
                .Select(g => new FossSkippedGroupResponse(g.Key.HeldByPalletId, g.Key.Reason, g.Count()))
                .OrderByDescending(g => g.Count)
                .ToList();

            return new FossTopUpResponse(
                detail,
                ResultMessage(info.LotNo, r, skipped.Count, byPallet),
                r.FossBoxCount,
                r.BoxesAdded,
                r.LinesAdded,
                skipped.Count,
                byPallet,
                skipped,
                r.OqcChanged);
        }

        /// <summary>Job nền / luồng quét PDA: pallet không phù hợp thì trả None, không ném lỗi.</summary>
        public Task<FossTopUpResult> TopUpFromFossAsync(string lotNo, IntegrationSyncContext sync)
            => TopUpCoreAsync(lotNo, sync, strict: false);

        /// <summary>"model|box_no" — box_no chỉ duy nhất trong phạm vi 1 model.</summary>
        private static string BoxKey(Box b)
        {
            // Entity Box không mang model -> lấy từ line đầu tiên có model.
            var model = b.Lines.Select(l => l.Model).FirstOrDefault(m => !string.IsNullOrWhiteSpace(m));
            return $"{(model ?? "").Trim()}|{(b.BoxNo ?? "").Trim()}";
        }

        /// <summary>"model|serial" — serial chỉ duy nhất trong phạm vi 1 model.</summary>
        private static string LineKey(BoxLine l)
            => $"{(l.Model ?? "").Trim()}|{(l.SerialNo ?? "").Trim()}";

        /// <summary>Lý do 1 thùng bị bỏ qua. Mã lạ (thêm sau mà quên dịch) thì trả nguyên mã.</summary>
        private string SkipMessage(FossSkippedBox s) => s.Reason switch
        {
            FossSkipReasons.BoxOnOtherPallet =>
                _localizer["Lot.FossTopUp.Skip.BoxOnOtherPallet", s.BoxNo, s.HeldByPalletId ?? "?"],
            FossSkipReasons.SerialsOnOtherPallet =>
                _localizer["Lot.FossTopUp.Skip.SerialsOnOtherPallet", s.BoxNo, s.HeldByPalletId ?? "?"],
            FossSkipReasons.AlreadyOnThisPallet =>
                _localizer["Lot.FossTopUp.Skip.AlreadyOnThisPallet", s.BoxNo],
            _ => s.Reason,
        };

        /// <summary>Câu tóm tắt kết quả cho người bấm.</summary>
        private string ResultMessage(
            string lotNo, FossTopUpResult r, int skippedCount, IReadOnlyList<FossSkippedGroupResponse> byPallet)
        {
            var parts = new List<string>();

            if (r.Changed)
                parts.Add(_localizer["Lot.FossTopUp.Result.Added", r.BoxesAdded, r.LinesAdded]);
            else if (skippedCount == 0)
                return _localizer["Lot.FossTopUp.Result.UpToDate", lotNo, r.FossBoxCount];

            if (skippedCount > 0)
            {
                var pallets = string.Join(", ", byPallet
                    .Where(g => g.HeldByPalletId is not null)
                    .Select(g => $"{g.HeldByPalletId} ({g.Count})"));
                parts.Add(_localizer["Lot.FossTopUp.Result.Skipped", skippedCount, pallets]);
            }

            return string.Join(" ", parts);
        }

        /// <summary>
        /// Bổ sung thùng / serial mà Foss thêm vào SAU khi SWMS đã tạo pallet.
        /// So theo box_no (= SERIAL_OUTER) và serial_no. Chỉ thêm, không xoá:
        /// thùng biến mất khỏi Foss không tự gỡ khỏi SWMS.
        /// Thùng / serial đã nằm trên pallet active KHÁC (đã tách đi) không bị kéo về —
        /// repo kiểm lại trong transaction và trả lý do từng thùng bị bỏ qua.
        ///
        /// <paramref name="strict"/> = true (gọi tay qua API): pallet không phù hợp -> ném lỗi có lý do.
        /// false (job nền, quét PDA): bỏ qua lặng lẽ.
        /// </summary>
        private async Task<FossTopUpResult> TopUpCoreAsync(
            string lotNo, IntegrationSyncContext sync, bool strict)
        {
            lotNo = NormalizeLotNo(lotNo);

            FossTopUpResult Skip(string key, params object[] args) => strict
                ? throw new BusinessRuleException(_localizer[key, args])
                : FossTopUpResult.None;

            var lot = await _repo.GetByLotNoAsync(lotNo);
            if (lot is null)
                return strict
                    ? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"])
                    : FossTopUpResult.None;

            if (string.Equals(lot.DetailLevel, DetailLevelBoxCount, StringComparison.OrdinalIgnoreCase))
                return Skip("Lot.FossTopUp.BoxCountNotSupported", lot.LotNo);

            if (lot.Boxes.Any(IsPartCardBox))
                return Skip("Lot.FossTopUp.NotFossPallet", lot.LotNo);

            if (!string.IsNullOrWhiteSpace(lot.SiNo) && lot.LocatorId is null)
                return Skip("Lot.FossTopUp.Shipped", lot.LotNo);

            // strict: để NotFoundException của Foss ("Foss.PalletNotFound") đi thẳng ra API.
            List<FossPalletItemResponse> foss;
            try
            {
                foss = await _fossService.GetPalletByBarcodeAsync(lot.LotNo);
            }
            catch (NotFoundException) when (!strict)
            {
                return FossTopUpResult.None;
            }

            var modelNo = foss.FirstOrDefault()?.ModelNo;
            if (modelNo is null)
                return strict
                    ? throw new NotFoundException(_localizer["Foss.PalletNotFound", lot.LotNo])
                    : FossTopUpResult.None;

            // Dựng lại bằng chính mapper lúc tạo để thùng mới có cùng shape
            // (CreatedAt = DATEINSERT, OQC, Line, LotName...).
            var modelInfo = await _modelService.GetByCodeAsync(modelNo);
            var fossBoxCount = foss
                .Select(e => $"{(e.ModelNo ?? "").Trim()}|{(e.BoxNo ?? "").Trim()}")
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .Count();
            var fossLot = FossPalletMapper.ToLot(
                foss,
                lot.LotNo,
                lot.CategoryCode,
                modelInfo.StandardPallet == fossBoxCount,
                foss.Min(e => e.OQCStatus) ?? 0,
                foss.FirstOrDefault()?.ShrinkBy ?? sync.Actor ?? "");

            // Khoá (model, box_no): SERIAL_OUTER chỉ duy nhất trong 1 model.
            var existing = lot.Boxes
                .GroupBy(BoxKey, StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);

            var newBoxes = new List<Box>();
            var newLines = new List<(long BoxId, BoxLine Line)>();

            foreach (var fb in fossLot.Boxes)
            {
                if (!existing.TryGetValue(BoxKey(fb), out var eb))
                {
                    newBoxes.Add(fb);
                    continue;
                }

                // Thùng đã có nhưng lúc tạo mới có một phần serial. Khoá (model, serial).
                var have = eb.Lines
                    .Where(l => !string.IsNullOrWhiteSpace(l.SerialNo))
                    .Select(LineKey)
                    .ToHashSet(StringComparer.OrdinalIgnoreCase);

                newLines.AddRange(fb.Lines
                    .Where(l => !string.IsNullOrWhiteSpace(l.SerialNo) && !have.Contains(LineKey(l)))
                    .Select(l => (eb.Id, l)));
            }

            if (newBoxes.Count == 0 && newLines.Count == 0)
                return new FossTopUpResult(0, 0, false, fossBoxCount);

            var ctx = sync.ToEventContext(StockEventCodes.PalletBoxesAdded, new
            {
                fossBoxCount,
                swmsBoxCountBefore = lot.Boxes.Count,
                candidateBoxes = newBoxes.Count,
                candidateLines = newLines.Count,
            });

            var added = await _fossRepo.AppendFossBoxesAsync(
                lot.Id, newBoxes, newLines, modelInfo.StandardPallet, sync.Actor ?? "", ctx);

            if (added.BoxesAdded == 0 && added.LinesAdded == 0)
                return new FossTopUpResult(0, 0, false, fossBoxCount, added.Skipped);

            // Thùng mới mang OQC riêng -> tính lại inspection_status. Dùng lại dữ liệu Foss vừa đọc.
            var oqcChanged = (await SyncOqcCoreAsync(lot.LotNo, sync, foss)).Changed;

            return new FossTopUpResult(
                added.BoxesAdded, added.LinesAdded, oqcChanged, fossBoxCount, added.Skipped);
        }

        // ── Job nền: tạo pallet ───────────────────────────────────────

        /// <summary>
        /// Bản nhẹ của CreateFromFossAsync cho job nền: không dựng PalletDetailResponse
        /// (bỏ 2–4 câu SQL / pallet). True = vừa tạo mới.
        /// Pallet đã có thì KHÔNG bổ sung ở đây — job gọi TopUpFromFossAsync riêng
        /// cho danh sách GetFossTopUpCandidatesAsync.
        /// </summary>
        public async Task<bool> TryCreateFromFossAsync(string lotNo, IntegrationSyncContext sync)
        {
            lotNo = NormalizeLotNo(lotNo);
            if (await _repo.ExistsLotNoAsync(lotNo)) return false;

            await CreateLotFromFossAsync(lotNo, sync);
            return true;
        }

        // ── Đồng bộ OQC ──────────────────────────────────────────────

        /// <summary>Đồng bộ OQC không dựng response. True = có thay đổi (thùng hoặc pallet).</summary>
        public async Task<bool> SyncOqcQuietAsync(string lotNo, IntegrationSyncContext sync)
            => (await SyncOqcCoreAsync(lotNo, sync)).Changed;

        /// <summary>
        /// API oqc-sync: đồng bộ OQC rồi trả cùng shape GET by-lot-no.
        /// Nguồn theo TỪNG THÙNG: payload "Card_ID=..." -> part_cards, còn lại -> Foss STATUS_FA.
        /// </summary>
        public async Task<PalletDetailResponse> SyncOqcStatusAsync(string lotNo, PalletInclude include)
        {
            var (lotId, _) = await SyncOqcCoreAsync(
                lotNo, new IntegrationSyncContext(StockEventSources.Foss, _currentUser.FullName));

            var info = await _repo.GetLocationInfoByIdAsync(lotId)
                ?? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"]);
            return await _pallets.BuildDetailAsync(info, include);
        }

        /// <summary>
        /// Lõi đồng bộ OQC — logic giữ nguyên bản cũ, thêm 1 điểm: KHÔNG có gì đổi thì
        /// không mở transaction ghi DB (đa số pallet ở mỗi lần bấm rơi vào trường hợp này).
        ///
        /// <paramref name="fossItems"/> != null: dùng dữ liệu Foss đã đọc sẵn (luồng top-up),
        /// không gọi Foss lần nữa.
        /// </summary>
        private async Task<(long LotId, bool Changed)> SyncOqcCoreAsync(
            string lotNo, IntegrationSyncContext sync,
            IReadOnlyList<FossPalletItemResponse>? fossItems = null)
        {
            lotNo = NormalizeLotNo(lotNo);

            var lot = await _repo.GetByLotNoAsync(lotNo)
                ?? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"]);

            // box_count không có thùng vật lý -> không có gì để đồng bộ.
            if (lot.DetailLevel == "box_count") return (lot.Id, false);

            // Nguồn theo TỪNG THÙNG: payload "Card_ID=..." -> part_cards, còn lại -> Foss.
            // Không tra part_cards cho thùng Foss: raw_payload = SERIAL_OUTER sẽ khớp nhầm.
            var cardPayloads = lot.Boxes
                .Where(IsPartCardBox)
                .Select(b => b.RawPayload!)
                .Distinct()
                .ToList();

            IReadOnlyDictionary<string, PartCardInfo> cards = cardPayloads.Count > 0
                ? await _repo.GetPartCardsByPayloadAsync(cardPayloads)
                : new Dictionary<string, PartCardInfo>();

            var fossByBox = lot.Boxes.Any(b => !IsPartCardBox(b))
                ? (fossItems is not null
                    ? ToFossStatusMap(fossItems)
                    : await TryGetFossStatusesAsync(lotNo) ?? new Dictionary<string, int>())
                : new Dictionary<string, int>();

            int? SourceOf(Box b) => IsPartCardBox(b)
                ? (cards.TryGetValue(b.RawPayload!, out var c) ? c.OqcStatus : null)
                : (fossByBox.TryGetValue(b.BoxNo, out var s) ? s : null);

            var changes = new Dictionary<long, int>();
            var finalStatuses = new List<int>();
            foreach (var box in lot.Boxes)
            {
                var src = SourceOf(box);
                finalStatuses.Add(src ?? box.OQCStatus ?? 0);
                if (src is not null && src != box.OQCStatus) changes[box.Id] = src.Value;
            }

            var palletStatus =
                lot.InspectionStatus == InspectionStatus.InspectionExempt || finalStatuses.Count == 0
                    ? lot.InspectionStatus
                    : FossPalletMapper.ToInspectionStatus(finalStatuses.Min(), lot.EvenLot ?? false);

            var palletChanged = !string.Equals(palletStatus, lot.InspectionStatus, StringComparison.Ordinal);
            if (changes.Count == 0 && !palletChanged) return (lot.Id, false);

            var ctx = sync.ToEventContext(StockEventCodes.OqcSynced, new
            {
                inspectionBefore = lot.InspectionStatus,
                inspectionAfter = palletStatus,
                changedBoxes = changes.Count,
                totalBoxes = lot.Boxes.Count,
            });

            await _fossRepo.UpdateOqcStatusAsync(
                lot.Id, changes, palletStatus, _currentUser.FullName ?? "", ctx);

            return (lot.Id, true);
        }

        private static bool IsPartCardBox(Box b) =>
            b.RawPayload?.StartsWith(PartCardPayloadPrefix, StringComparison.OrdinalIgnoreCase) == true;

        /// <summary>STATUS_FA theo BoxNo (mức thấp nhất trong thùng); null nếu pallet không có trên Foss.</summary>
        private async Task<Dictionary<string, int>?> TryGetFossStatusesAsync(string lotNo)
        {
            try
            {
                return ToFossStatusMap(await _fossService.GetPalletByBarcodeAsync(lotNo));
            }
            catch (NotFoundException)
            {
                return null;
            }
        }

        private static Dictionary<string, int> ToFossStatusMap(IEnumerable<FossPalletItemResponse> items)
            => items
                .Where(i => i.OQCStatus is not null)
                .GroupBy(i => i.BoxNo)
                .ToDictionary(g => g.Key, g => (int)g.Min(i => i.OQCStatus)!.Value);

        private async Task<PalletLocationInfo> CreateLotFromFossAsync(string lotNo, IntegrationSyncContext sync)
        {
            var pallet = await _fossService.GetPalletByBarcodeAsync(lotNo);

            var model = pallet.FirstOrDefault()?.ModelNo
                ?? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"]);

            var categoryCode = int.TryParse(lotNo[..Math.Min(3, lotNo.Length)], out var code) ? code : 0;
            var category = await _categoryRepo.GetByCodeAsync(categoryCode)
                ?? throw new NotFoundException(_localizer["Lot.CategoryNotFound", categoryCode]);

            var modelInfo = await _modelService.GetByCodeAsync(model);
            var boxCount = pallet.DistinctBy(e => e.BoxNo).Count();
            var isEvenPallet = modelInfo.StandardPallet == boxCount;
            var oqcStatus = pallet.Min(e => e.OQCStatus) ?? 0;
            var createBy = pallet.FirstOrDefault()?.ShrinkBy ?? sync.Actor ?? "";

            var lotFromFoss = FossPalletMapper.ToLot(pallet, lotNo, category.Code, isEvenPallet, oqcStatus, createBy);

            await _repo.AddAsync(lotFromFoss, PalletOrigins.Foss, sync.Source, sync: sync);
            await _weightService.SyncBoxWeightAsync(lotNo);

            return await _repo.GetLocationInfoByLotNoAsync(lotNo)
                ?? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"]);
        }


        private string NormalizeLotNo(string? lotNo) => PalletLotNo.Normalize(lotNo, _localizer);
    }
}
