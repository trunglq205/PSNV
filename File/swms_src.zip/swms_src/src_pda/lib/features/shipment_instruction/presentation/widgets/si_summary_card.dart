import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/extensions/datetime_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_progress_bar.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_info_grid.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_status_ui.dart';

/// Thẻ tổng quan chỉ thị: trạng thái, tiến độ, mốc thời gian, yêu cầu,
/// và khối "Thông tin chứng từ" thu gọn.
class SiSummaryCard extends StatelessWidget {
  final ShipmentInstructionDetail si;

  const SiSummaryCard({super.key, required this.si});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    final requirements = siJoin([
      if (si.isSerialRequired) LocaleKeys.shipment_instruction_req_serial.tr(),
      if (si.isCaseMark) LocaleKeys.shipment_instruction_req_case_mark.tr(),
      if (si.isWhiteFilm) LocaleKeys.shipment_instruction_req_white_film.tr(),
    ]);

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              si.status.pill(context, rawKey: si.statusKey),
              const Spacer(),
              Text.rich(
                TextSpan(
                  children: [
                    TextSpan(
                      text: '${si.qtyFulfilled}',
                      style: AppTextStyles.title.copyWith(
                        color: swms.text1,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                    TextSpan(text: ' / ${si.qtyRequired} pcs'),
                  ],
                ),
                style: AppTextStyles.label.copyWith(
                  color: swms.text2,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ],
          ),
          const SizedBox(height: 9),
          AppProgressBar(value: si.progress, height: 8),

          if (si.status == SiStatus.picking && si.qtyShort > 0) ...[
            const SizedBox(height: 7),
            Text(
              LocaleKeys.shipment_instruction_short_pcs
                  .tr(args: ['${si.qtyShort}']),
              style: AppTextStyles.label.copyWith(color: swms.danger),
            ),
          ],
          if (si.qtyCut > 0) ...[
            const SizedBox(height: AppDimens.xs),
            Text(
              LocaleKeys.shipment_instruction_cut_qty.tr(args: ['${si.qtyCut}']),
              style: AppTextStyles.label.copyWith(color: swms.warning),
            ),
          ],

          const Divider(height: AppDimens.lg),

          SiInfoGrid(
            items: [
              SiInfoItem(
                LocaleKeys.shipment_instruction_etd.tr(),
                si.etdDate?.ddMMyyyy ?? kSiDash,
                mono: true,
              ),
              SiInfoItem(
                LocaleKeys.shipment_instruction_cut_off.tr(),
                si.cutOffAt?.hhMMDDMM ?? kSiDash,
                mono: true,
              ),
              // API mới trả toAreaId, chưa có mã khu → tạm hiện id.
              SiInfoItem(
                LocaleKeys.shipment_instruction_staging_area.tr(),
                si.toAreaId == null ? kSiDash : '#${si.toAreaId}',
                mono: true,
              ),
              SiInfoItem(
                LocaleKeys.shipment_instruction_requirements.tr(),
                siOrDash(requirements),
              ),
            ],
          ),

          const SizedBox(height: AppDimens.sm),
          _DocInfoSection(si: si),
        ],
      ),
    );
  }
}

/// "Thông tin chứng từ" — mặc định thu gọn, công nhân ít khi cần.
class _DocInfoSection extends StatefulWidget {
  final ShipmentInstructionDetail si;
  const _DocInfoSection({required this.si});

  @override
  State<_DocInfoSection> createState() => _DocInfoSectionState();
}

class _DocInfoSectionState extends State<_DocInfoSection> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final si = widget.si;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        InkWell(
          onTap: () => setState(() => _expanded = !_expanded),
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          child: ConstrainedBox(
            constraints: const BoxConstraints(minHeight: AppDimens.hitSm),
            child: Row(
              children: [
                Text(
                  LocaleKeys.shipment_instruction_doc_info.tr(),
                  style: AppTextStyles.label.copyWith(color: swms.primary),
                ),
                const SizedBox(width: AppDimens.xs),
                AnimatedRotation(
                  turns: _expanded ? 0.5 : 0,
                  duration: const Duration(milliseconds: 180),
                  child: Icon(
                    Icons.expand_more_rounded,
                    size: 18,
                    color: swms.primary,
                  ),
                ),
              ],
            ),
          ),
        ),
        AnimatedSize(
          duration: const Duration(milliseconds: 180),
          alignment: Alignment.topCenter,
          child: !_expanded
              ? const SizedBox(width: double.infinity)
              : Padding(
                  padding: const EdgeInsets.only(top: AppDimens.xs),
                  child: SiInfoGrid(
                    items: [
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_doc_no.tr(),
                        si.docNo,
                        mono: true,
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_packing_list.tr(),
                        siOrDash(si.packingListNo),
                        mono: true,
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_eta.tr(),
                        si.etaDate?.ddMMyyyy ?? kSiDash,
                        mono: true,
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_vanning.tr(),
                        si.vanningDate?.ddMMyyyy ?? kSiDash,
                        mono: true,
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_category.tr(),
                        siOrDash(si.category),
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_port_of_loading.tr(),
                        siOrDash(si.portOfLoading),
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_port_of_discharge.tr(),
                        siOrDash(siJoin([si.portOfDischarge, si.countryCode])),
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_forwarder.tr(),
                        siOrDash(si.forwarderCode),
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_carrier.tr(),
                        siOrDash(si.carrierCode),
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_consignee.tr(),
                        siOrDash(si.consigneeCode),
                        mono: true,
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_packing.tr(),
                        siOrDash(si.packingType),
                      ),
                      SiInfoItem(
                        LocaleKeys.shipment_instruction_pic.tr(),
                        siOrDash(si.picName),
                      ),
                    ],
                  ),
                ),
        ),
      ],
    );
  }
}
