using Swms.FinishGoods.Web.Features.Auth.Business;
using Swms.FinishGoods.Web.Features.Models.Business;
using Swms.FinishGoods.Web.Features.PartCard.Business;
using Swms.FinishGoods.Web.Features.Roles.Business;
using Swms.FinishGoods.Web.Features.Settings.Business;
using Swms.FinishGoods.Web.Features.Users.Business;
using Swms.FinishGoods.Web.Shared.Business.Base;
using Swms.FinishGoods.Web.Shared.Business.Profile;

namespace Swms.FinishGoods.Web.Extensions;

/// <summary>
/// LAYER 2 — đăng ký các service nghiệp vụ phía UI.
/// Thêm feature mới: thêm 1 dòng AddScoped&lt;IXxxService, XxxService&gt;.
/// </summary>
public static class BusinessServiceExtensions
{
    public static IServiceCollection AddBusinessServices(this IServiceCollection services)
    {
        services.AddSingleton<ErrorHandler>();

        services.AddScoped<IAuthBusiness, AuthBusiness>();

        services.AddScoped<IUserBusiness, UserBusiness>();

        services.AddScoped<IRoleBusiness, RoleBusiness>();

        services.AddScoped<IProfileBusiness, ProfileBusiness>();

        services.AddScoped<IPartCardBusiness, PartCardBusiness>();

        services.AddScoped<IModelBusiness, ModelBusiness>();

        services.AddScoped<ISettingsBusiness, SettingsBusiness>();

        return services;
    }
}
