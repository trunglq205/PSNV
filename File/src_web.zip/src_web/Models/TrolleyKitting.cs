﻿using Refit;

namespace SWMS_WebTool.Models
{
    public enum TrolleyKittingStatus
    {
        Empty = 0,
        Picking = 1,
        Completed = 2,
        MovingOutTrolleyMap = 3,
        PushOntoLine = 4
    }

    public class TrolleyKitting
    {
        public string TrolleyName { get; set; }
        public string TrolleyCode { get; set; }
        public string BarCode { get; set; }
        public TrolleyKittingStatus? ActionStatus { get; set; }
        public string Description { get; set; }
        public string Time { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Model { get; set; }
        public string Line { get; set; }
        public int? ModelQuantity { get; set; }
        public string Category { get; set; }
        public string KittingTimeType { get; set; }
        public string PIC { get; set; }

        public bool IsUrgent
        {
            get
            {
                var arr = Time?.Split(":");

                if (arr == null || arr.Length < 2 || Deliverydate == null) return false;

                var hour = int.Parse(arr[0]);
                var minute = int.Parse(arr[1]);

                var date = new DateTime(Deliverydate.Value.Year, Deliverydate.Value.Month, Deliverydate.Value.Day, hour, minute, 0);
                if (hour >= 0 && hour <6)
                {
                    date = date.AddDays(1);
                }
                return DateTime.Now.AddHours(1) >= date;
            }
        }
        public string TrolleyFill
        {
            get
            {
                switch (ActionStatus)
                {
                    case TrolleyKittingStatus.Picking:
                        return "#FFFF00";
                    case TrolleyKittingStatus.Completed:
                    case TrolleyKittingStatus.MovingOutTrolleyMap:
                    case TrolleyKittingStatus.PushOntoLine:
                        return "#A9D08E";
                    default:
                        return "#FFFFFF";
                }
            }
        }
    }
}
