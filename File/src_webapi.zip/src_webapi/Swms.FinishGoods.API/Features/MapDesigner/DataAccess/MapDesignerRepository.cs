using Dapper;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.MapDesigner.DataAccess;

/// <summary>
/// Truy cập layout bản đồ DÙNG CHUNG cho mọi map_type.
/// Nguồn dữ liệu: master.locator_map (+ racks, locators, warehouse_areas).
/// </summary>
public class MapDesignerRepository : IMapDesignerRepository
{
    private readonly IDbConnectionFactory _factory;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public MapDesignerRepository(
        IDbConnectionFactory factory,
        IStringLocalizer<SharedResource> localizer)
    {
        _factory = factory;
        _localizer = localizer;
    }

    public async Task<MapLayout?> GetLayoutAsync(string areaCode)
    {
        using var conn = _factory.Create();

        const string areaSql = """
            SELECT id AS AreaId, area_code AS AreaCode, area_name AS AreaName,
                   map_type AS MapType, cols AS Cols, rows AS Rows, cell_meters AS CellMeters
            FROM master.warehouse_areas
            WHERE area_code = @areaCode AND is_deleted = 0;
            """;
        var layout = await conn.QueryFirstOrDefaultAsync<MapLayout>(areaSql, new { areaCode });
        if (layout is null) return null;

        // Lấy đủ 3 loại block trong 1 query.
        const string blocksSql = """
            SELECT  m.id            AS Id,
                    m.target_type   AS Kind,
                    m.rack_id       AS RackId,
                    r.rack_code     AS RackCode,
                    r.rows          AS RackRows,
                    r.cols          AS RackCols,
                    m.locator_id    AS LocatorId,
                    l.locator_code  AS LocatorCode,
                    l.current_status AS CurrentStatus,
                    m.grid_x        AS GridX,
                    m.grid_y        AS GridY,
                    m.grid_w        AS GridW,
                    m.grid_h        AS GridH,
                    m.label         AS Label,
                    m.color         AS Color,
                    m.arrow         AS Arrow,
                    m.sort_order    AS SortOrder
            FROM master.locator_map m
            LEFT JOIN master.racks    r ON r.id = m.rack_id    AND r.is_deleted = 0
            LEFT JOIN master.locators l ON l.id = m.locator_id AND l.is_deleted = 0
            WHERE m.parent_type = N'area' AND m.parent_id = @areaId AND m.is_deleted = 0
            ORDER BY m.sort_order, m.id;
            """;
        var blocks = await conn.QueryAsync<MapBlock>(blocksSql, new { areaId = layout.AreaId });

        // DB lưu target_type = locator; UI gọi là pallet cho dễ hiểu.
        layout.Blocks = blocks.Select(b =>
        {
            if (b.Kind == "locator") b.Kind = "pallet";
            return b;
        }).ToList();

        return layout;
    }

    public async Task SaveLayoutAsync(string areaCode, IReadOnlyList<MapBlock> blocks, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var areaId = await conn.ExecuteScalarAsync<long?>(
                "SELECT id FROM master.warehouse_areas WHERE area_code = @areaCode AND is_deleted = 0",
                new { areaCode }, tx)
                ?? throw new NotFoundException(_localizer["MapDesign.Err.AreaNotFound", areaCode]);

            // 1) Xoá mềm mọi block KHÔNG còn trong danh sách gửi lên.
            //    Rack bị xoá khỏi map -> chỉ gỡ khối, KHÔNG xoá rack/locator nghiệp vụ.
            var keptIds = blocks.Where(b => b.Id.HasValue).Select(b => b.Id!.Value).ToList();
            await conn.ExecuteAsync("""
                UPDATE master.locator_map
                SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE parent_type = N'area' AND parent_id = @areaId AND is_deleted = 0
                  AND (@hasKept = 0 OR id NOT IN @keptIds);
                """, new
            {
                areaId,
                user,
                hasKept = keptIds.Count > 0 ? 1 : 0,
                keptIds = keptIds.Count > 0 ? keptIds : new List<long> { -1 }
            }, tx);

            // Phải cập nhật CẢ target_type/rack_id/locator_id: đổi tên hay đổi loại khối
            // mà không sửa mấy cột này thì khối vẫn trỏ về đối tượng cũ.
            const string updBlock = """
                UPDATE master.locator_map
                SET target_type = @TargetType, rack_id = @RackId, locator_id = @LocatorId,
                    grid_x = @GridX, grid_y = @GridY, grid_w = @GridW, grid_h = @GridH,
                    label = @Label, color = @Color, arrow = @Arrow, sort_order = @SortOrder,
                    is_deleted = 0, updated_at = SYSDATETIME(), updated_by = @user
                WHERE id = @Id AND parent_type = N'area' AND parent_id = @areaId;
                """;

            const string insBlock = """
                INSERT INTO master.locator_map
                    (parent_type, parent_id, target_type, rack_id, locator_id,
                     grid_x, grid_y, grid_w, grid_h, label, color, arrow,
                     sort_order, is_active, is_deleted, created_at, created_by)
                VALUES
                    (N'area', @areaId, @TargetType, @RackId, @LocatorId,
                     @GridX, @GridY, @GridW, @GridH, @Label, @Color, @Arrow,
                     @SortOrder, 1, 0, SYSDATETIME(), @user);
                """;

            // Ô đang giữ mã này (nếu có) — locator_code là duy nhất toàn hệ.
            const string ownerOfCode =
                "SELECT TOP 1 id FROM master.locators WHERE locator_code = @Code AND is_deleted = 0;";

            // ĐỔI TÊN ô sẵn có (khối đã có locator_id) — không tạo ô mới.
            const string renameLocator = """
                UPDATE master.locators
                SET locator_code = @Code, area_id = @AreaId, sort_order = @Sort,
                    updated_at = SYSDATETIME(), updated_by = @User
                WHERE id = @Id;
                """;

            // Khối pallet mới và mã chưa ai dùng -> tạo ô mới.
            const string insLocator = """
                INSERT INTO master.locators
                    (locator_code, area_id, slot_kind, current_status,
                     sort_order, is_active, is_deleted, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@Code, @AreaId, N'pallet', N'empty',
                        @Sort, 1, 0, SYSDATETIME(), @User);
                """;

            int sortOrder = 1;
            foreach (var b in blocks)
            {
                var kind = (b.Kind ?? "zone").Trim().ToLowerInvariant();
                long? locatorId = b.LocatorId;

                // Block pallet: đảm bảo có locator nghiệp vụ tương ứng.
                if (kind == "pallet")
                {
                    var code = (b.LocatorCode ?? "").Trim().ToUpperInvariant();
                    if (code.Length == 0)
                        throw new BusinessRuleException(_localizer["MapDesign.Err.PalletCodeRequired"]);

                    var owner = await conn.ExecuteScalarAsync<long?>(ownerOfCode, new { Code = code }, tx);

                    if (b.LocatorId.HasValue)
                    {
                        // Khối đã có ô: đây là ĐỔI TÊN ô đó. Trước đây code khớp theo mã nên
                        // đổi tên sinh ra ô mới, còn khối vẫn trỏ ô cũ.
                        if (owner.HasValue && owner.Value != b.LocatorId.Value)
                            throw new BusinessRuleException(_localizer["MapDesign.Err.PalletCodeDuplicated", code]);

                        await conn.ExecuteAsync(renameLocator, new
                        {
                            Code = code, AreaId = areaId, Sort = sortOrder, User = user, Id = b.LocatorId.Value
                        }, tx);
                        locatorId = b.LocatorId.Value;
                    }
                    else
                    {
                        // Khối mới: dùng lại ô sẵn có nếu trùng mã, không thì tạo ô mới.
                        locatorId = owner ?? await conn.ExecuteScalarAsync<long>(insLocator,
                            new { Code = code, AreaId = areaId, Sort = sortOrder, User = user }, tx);
                    }
                }

                // target_type trong DB: pallet -> locator
                var targetType = kind switch
                {
                    "rack" => "rack",
                    "pallet" => "locator",
                    _ => "zone"
                };

                var p = new
                {
                    b.Id,
                    areaId,
                    TargetType = targetType,
                    RackId = kind == "rack" ? b.RackId : null,
                    LocatorId = kind == "pallet" ? locatorId : null,
                    b.GridX, b.GridY, b.GridW, b.GridH,
                    b.Label,
                    b.Color,
                    b.Arrow,
                    SortOrder = sortOrder++,
                    user
                };

                if (b.Id.HasValue)
                {
                    var n = await conn.ExecuteAsync(updBlock, p, tx);
                    if (n == 0) await conn.ExecuteAsync(insBlock, p, tx);
                }
                else
                {
                    await conn.ExecuteAsync(insBlock, p, tx);
                }
            }

            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<long> CreateRackAsync(string areaCode, CreateRackInput input, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var areaId = await conn.ExecuteScalarAsync<long?>(
                "SELECT id FROM master.warehouse_areas WHERE area_code = @areaCode AND is_deleted = 0",
                new { areaCode }, tx)
                ?? throw new NotFoundException(_localizer["MapDesign.Err.AreaNotFound", areaCode]);

            var code = input.RackCode.Trim().ToUpperInvariant();
            var exists = await conn.ExecuteScalarAsync<int>(
                "SELECT COUNT(1) FROM master.racks WHERE rack_code = @code AND is_deleted = 0",
                new { code }, tx);
            if (exists > 0) throw new ConflictException(_localizer["Storage.Err.RackExists", code]);

            var rackId = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO master.racks
                    (rack_code, rack_name, area_id, rows, cols, sort_order, is_active, is_deleted, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@code, @name, @areaId, @floors, @positions, 100, 1, 0, SYSDATETIME(), @user);
                """, new
            {
                code,
                name = string.IsNullOrWhiteSpace(input.RackName) ? "Rack " + code : input.RackName!.Trim(),
                areaId,
                floors = input.Floors,
                positions = input.Positions,
                user
            }, tx);

            const string insLoc = """
                INSERT INTO master.locators
                    (locator_code, area_id, rack_id, rack_row, rack_col, rack_level, slot_kind,
                     current_status, sort_order, is_active, is_deleted, created_at, created_by)
                VALUES (@Code, @AreaId, @RackId, @Row, @Col, @Level, @Kind,
                        N'empty', @Sort, 1, 0, SYSDATETIME(), @User);
                """;

            var shelfSet = new HashSet<int>(input.ShelfPositions ?? Array.Empty<int>());
            int sort = 0;
            for (int pos = 1; pos <= input.Positions; pos++)
            {
                if (shelfSet.Contains(pos))
                {
                    // Giá lửng: tầng 1 chia 2 ngăn A/B, các tầng trên là pallet thường.
                    await conn.ExecuteAsync(insLoc, new { Code = $"{code}-{pos}-1-A", AreaId = areaId, RackId = rackId, Row = 1, Col = pos, Level = "A", Kind = "shelf", Sort = ++sort, User = user }, tx);
                    await conn.ExecuteAsync(insLoc, new { Code = $"{code}-{pos}-1-B", AreaId = areaId, RackId = rackId, Row = 1, Col = pos, Level = "B", Kind = "shelf", Sort = ++sort, User = user }, tx);
                    for (int fl = 2; fl <= input.Floors; fl++)
                        await conn.ExecuteAsync(insLoc, new { Code = $"{code}-{pos}-{fl}", AreaId = areaId, RackId = rackId, Row = fl, Col = pos, Level = (string?)null, Kind = "pallet", Sort = ++sort, User = user }, tx);
                }
                else
                {
                    for (int fl = 1; fl <= input.Floors; fl++)
                        await conn.ExecuteAsync(insLoc, new { Code = $"{code}-{pos}-{fl}", AreaId = areaId, RackId = rackId, Row = fl, Col = pos, Level = (string?)null, Kind = "pallet", Sort = ++sort, User = user }, tx);
                }
            }

            await conn.ExecuteAsync("""
                INSERT INTO master.locator_map
                    (parent_type, parent_id, target_type, rack_id, grid_x, grid_y, grid_w, grid_h,
                     sort_order, is_active, is_deleted, created_at, created_by)
                VALUES (N'area', @areaId, N'rack', @rackId, @gridX, @gridY, @gridW, @gridH,
                        100, 1, 0, SYSDATETIME(), @user);
                """, new
            {
                areaId, rackId,
                gridX = input.GridX, gridY = input.GridY,
                gridW = input.GridW, gridH = input.GridH,
                user
            }, tx);

            tx.Commit();
            return rackId;
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<bool> RackHasStockAsync(string areaCode, string rackCode)
    {
        using var conn = _factory.Create();
        var cnt = await conn.ExecuteScalarAsync<int>("""
            SELECT COUNT(1)
            FROM wms.pallets p
            JOIN master.locators l ON l.id = p.locator_id AND l.is_deleted = 0
            JOIN master.racks    r ON r.id = l.rack_id    AND r.is_deleted = 0
            JOIN master.warehouse_areas a ON a.id = r.area_id AND a.is_deleted = 0
            WHERE a.area_code = @areaCode AND r.rack_code = @rackCode AND p.is_deleted = 0;
            """, new { areaCode, rackCode });
        return cnt > 0;
    }

    public async Task DeleteRackAsync(string areaCode, string rackCode, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var rackId = await conn.ExecuteScalarAsync<long?>("""
                SELECT r.id FROM master.racks r
                JOIN master.warehouse_areas a ON a.id = r.area_id AND a.is_deleted = 0
                WHERE a.area_code = @areaCode AND r.rack_code = @rackCode AND r.is_deleted = 0;
                """, new { areaCode, rackCode }, tx)
                ?? throw new NotFoundException(_localizer["Storage.Err.RackNotFound", rackCode]);

            // Gỡ khối khỏi map, xoá mềm locator con rồi xoá mềm rack.
            await conn.ExecuteAsync("""
                UPDATE master.locator_map SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE rack_id = @rackId AND is_deleted = 0;
                """, new { rackId, user }, tx);

            await conn.ExecuteAsync("""
                UPDATE master.locators SET is_deleted = 1, is_active = 0,
                       updated_at = SYSDATETIME(), updated_by = @user
                WHERE rack_id = @rackId AND is_deleted = 0;
                """, new { rackId, user }, tx);

            await conn.ExecuteAsync("""
                UPDATE master.racks SET is_deleted = 1, is_active = 0,
                       updated_at = SYSDATETIME(), updated_by = @user
                WHERE id = @rackId;
                """, new { rackId, user }, tx);

            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<bool> LocatorCodeExistsAsync(string locatorCode, long? exceptLocatorId = null)
    {
        using var conn = _factory.Create();
        var cnt = await conn.ExecuteScalarAsync<int>("""
            SELECT COUNT(1) FROM master.locators
            WHERE locator_code = @locatorCode AND is_deleted = 0
              AND (@exceptId IS NULL OR id <> @exceptId);
            """, new { locatorCode, exceptId = exceptLocatorId });
        return cnt > 0;
    }
}
