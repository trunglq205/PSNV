namespace Swms.FinishGoods.API.Features.Sync.Business;

public enum SyncJobKind { Fa, Oqc, HdSoft, All }
public enum SyncPhase { Idle, Running, Done, Cancelled, Failed }

public sealed record SyncLogItem(DateTime At, string Step, string LotNo, bool IsError, string Message);

public sealed record SyncStatusResponse(
    string Kind,
    string Actor,
    bool Full,
    string Phase,
    string? Step,
    int StepTotal,
    int StepProcessed,
    int Created,
    int OqcChanged,
    int LocatorChanged,
    int Failed,
    int Warnings,
    DateTime? StartedAt,
    DateTime? FinishedAt,
    string? Error,
    IReadOnlyList<SyncLogItem> Logs)
{
    public static SyncStatusResponse Idle { get; } = new(
        "", "", false, nameof(SyncPhase.Idle), null,
        0, 0, 0, 0, 0, 0, 0, null, null, null, []);
}

/// <summary>
/// Tiến độ của 1 lần chạy. Được cập nhật từ nhiều luồng song song nên bộ đếm là
/// FIELD (để dùng Interlocked); ra ngoài luôn qua <see cref="Snapshot"/>.
/// </summary>
public sealed class SyncProgress
{
    private const int MaxLogs = 300;
    public int ToppedUp;
    private readonly object _gate = new();
    private readonly Queue<SyncLogItem> _logs = new();

    public required SyncJobKind Kind { get; init; }
    public required string Actor { get; init; }
    public bool Full { get; init; }
    public DateTime StartedAt { get; } = DateTime.Now;
    public DateTime? FinishedAt { get; set; }
    public SyncPhase Phase { get; set; } = SyncPhase.Running;
    public string? Error { get; set; }
    public string? Step { get; private set; }

    public int StepTotal;
    public int StepProcessed;
    public int Created;
    public int OqcChanged;
    public int LocatorChanged;
    public int Failed;
    public int Warnings;

    public void BeginStep(string step, int total)
    {
        Step = step;
        Volatile.Write(ref StepTotal, total);
        Volatile.Write(ref StepProcessed, 0);
    }

    public void Warn(string step, string lotNo, string message)
    {
        Interlocked.Increment(ref Warnings);
        Add(new SyncLogItem(DateTime.Now, step, lotNo, false, message));
    }

    public void Fail(string step, string lotNo, string message)
    {
        Interlocked.Increment(ref Failed);
        Add(new SyncLogItem(DateTime.Now, step, lotNo, true, message));
    }

    private void Add(SyncLogItem item)
    {
        lock (_gate)
        {
            _logs.Enqueue(item);
            while (_logs.Count > MaxLogs) _logs.Dequeue();
        }
    }

    public SyncStatusResponse Snapshot()
    {
        SyncLogItem[] logs;
        lock (_gate) logs = _logs.Reverse().ToArray(); // mới nhất trước

        return new SyncStatusResponse(
            Kind.ToString(), Actor, Full, Phase.ToString(), Step,
            Volatile.Read(ref StepTotal), Volatile.Read(ref StepProcessed),
            Volatile.Read(ref Created), Volatile.Read(ref OqcChanged),
            Volatile.Read(ref LocatorChanged), Volatile.Read(ref Failed),
            Volatile.Read(ref Warnings),
            StartedAt, FinishedAt, Error, logs);
    }
}
