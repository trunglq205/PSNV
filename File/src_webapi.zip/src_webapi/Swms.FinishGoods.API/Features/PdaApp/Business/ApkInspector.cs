using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System.IO.Compression;
using System.Net;
using System.Net.Sockets;
using System.Text;

namespace Swms.FinishGoods.Api.Features.PdaApp.Business;

/// <summary>
/// Đọc versionName/versionCode từ binary AndroidManifest.xml bên trong APK (APK = ZIP).
/// Parse tối giản binary XML (AXML) để lấy 2 attribute versionName/versionCode ở tag &lt;manifest&gt;,
/// không cần aapt/Android SDK trên server.
///
/// LƯU Ý: đây là parser gọn đủ dùng cho APK chuẩn. Nếu APK build khác thường không đọc được,
/// thay bằng thư viện chuyên dụng (vd apk-parser) — chỉ cần đổi implementation này, service không đổi.
/// </summary>
public class ApkInspector : IApkInspector
{
    public async Task<ApkInfo> ReadAsync(Stream apk, CancellationToken ct = default)
    {
        // Copy sang MemoryStream để ZipArchive seek được (IFormFile stream có thể không seek).
        using var ms = new MemoryStream();
        await apk.CopyToAsync(ms, ct);
        ms.Position = 0;

        byte[] manifest;
        try
        {
            using var zip = new ZipArchive(ms, ZipArchiveMode.Read, leaveOpen: true);
            var entry = zip.GetEntry("AndroidManifest.xml")
                        ?? throw new InvalidApkException("APK thiếu AndroidManifest.xml.");
            using var es = entry.Open();
            using var buf = new MemoryStream();
            await es.CopyToAsync(buf, ct);
            manifest = buf.ToArray();
        }
        catch (InvalidDataException)
        {
            throw new InvalidApkException("File không phải APK hợp lệ (không mở được ZIP).");
        }

        var (versionName, versionCode) = ParseAxml(manifest);
        if (string.IsNullOrWhiteSpace(versionName) || versionCode <= 0)
            throw new InvalidApkException("Không đọc được versionName/versionCode từ APK.");

        return new ApkInfo(versionName!, versionCode);
    }

    // Parse tối giản Android binary XML để lấy versionName (string) + versionCode (int)
    // từ các attribute của tag <manifest>. Dựa trên cấu trúc AXML chunk chuẩn.
    private static (string? versionName, int versionCode) ParseAxml(byte[] data)
    {
        // Đọc string pool.
        // AXML: [0]=0x00080003 magic, [1]=fileSize, tiếp theo là các chunk.
        // String chunk: type 0x001C0001.
        var strings = new List<string>();
        int pos = 8; // bỏ header file (magic + size)

        // Tìm string pool chunk.
        int stringChunkStart = FindChunk(data, 0x001C0001, 8);
        if (stringChunkStart >= 0)
            strings = ReadStringPool(data, stringChunkStart);

        // Duyệt các start-tag để tìm "manifest" và đọc attribute.
        // Start element chunk: type 0x00100102.
        int p = pos;
        while (p + pos <= data.Length)
        {
            int type = ReadInt(data, p);
            int size = ReadInt(data, p + 4);
            if (size <= 0) break;

            if (type == 0x00100102) // START_TAG
            {
                // layout: header(8) lineNo(4) comment(4) ns(4) name(4) flags(4) attrCount(2)...(2) ... attrs
                int nameIdx = ReadInt(data, p + 20);
                string tag = Str(strings, nameIdx);
                if (tag == "manifest")
                {
                    int attrCount = ReadShort(data, p + 28);
                    int attrStart = p + 36;
                    string? versionName = null;
                    int versionCode = 0;

                    for (int i = 0; i < attrCount; i++)
                    {
                        int a = attrStart + i * 20;
                        int aName = ReadInt(data, a + 4);
                        int aRawValue = ReadInt(data, a + 8);   // string value index (-1 nếu là số)
                        int aData = ReadInt(data, a + 16);      // typed value

                        string attr = Str(strings, aName);
                        if (attr == "versionName")
                            versionName = aRawValue != -1 ? Str(strings, aRawValue) : aData.ToString();
                        else if (attr == "versionCode")
                            versionCode = aData;
                    }
                    return (versionName, versionCode);
                }
            }
            p += size;
        }
        return (null, 0);
    }

    private static int FindChunk(byte[] d, int type, int from)
    {
        int p = from;
        while (p + 8 <= d.Length)
        {
            int t = ReadInt(d, p);
            int s = ReadInt(d, p + 4);
            if (s <= 0) break;
            if (t == type) return p;
            p += s;
        }
        return -1;
    }

    private static List<string> ReadStringPool(byte[] d, int start)
    {
        var result = new List<string>();
        int stringCount = ReadInt(d, start + 8);
        int flags = ReadInt(d, start + 16);
        bool utf8 = (flags & (1 << 8)) != 0;
        int stringsStart = start + ReadInt(d, start + 20);

        for (int i = 0; i < stringCount; i++)
        {
            int offset = stringsStart + ReadInt(d, start + 28 + i * 4);
            if (offset < 0 || offset >= d.Length) { result.Add(""); continue; }
            result.Add(utf8 ? ReadUtf8(d, offset) : ReadUtf16(d, offset));
        }
        return result;
    }

    private static string ReadUtf16(byte[] d, int off)
    {
        int len = d[off] | (d[off + 1] << 8);
        return Encoding.Unicode.GetString(d, off + 2, len * 2);
    }

    private static string ReadUtf8(byte[] d, int off)
    {
        // UTF-8: 2 độ dài (chars, bytes) — mỗi cái 1–2 byte. Lấy byte-length.
        int p = off;
        p += (d[p] & 0x80) != 0 ? 2 : 1;          // bỏ char-length
        int byteLen = d[p];
        p += (byteLen & 0x80) != 0 ? 2 : 1;
        if ((d[off + ((d[off] & 0x80) != 0 ? 2 : 1)] & 0x80) != 0)
            byteLen = ((byteLen & 0x7F) << 8) | d[p - 1];
        return Encoding.UTF8.GetString(d, p, byteLen);
    }

    private static string Str(List<string> pool, int idx)
        => idx >= 0 && idx < pool.Count ? pool[idx] : "";

    private static int ReadInt(byte[] d, int p)
        => d[p] | (d[p + 1] << 8) | (d[p + 2] << 16) | (d[p + 3] << 24);

    private static int ReadShort(byte[] d, int p)
        => d[p] | (d[p + 1] << 8);
}

/// <summary>
/// Lưu APK xuống thư mục cấu hình sẵn và dựng URL công khai từ IP LAN của server.
/// </summary>
public class LocalApkStorage : IApkStorage
{
    private readonly string _root;
    private readonly string _baseUrl;

    public LocalApkStorage(IConfiguration config, IHttpContextAccessor httpContextAccessor)
    {
        _root = "downloads";
        var request = httpContextAccessor.HttpContext?.Request;
        var scheme = request?.Scheme ?? "http";
        var host = request?.Host.Value ?? "localhost";
        _baseUrl = $"{scheme}://{host}";
    }

    public async Task<(string Path, string Url)> SaveAsync(
        Stream apk, string version, string fileName, CancellationToken ct = default)
    {
        Directory.CreateDirectory(_root);
        var safeName = $"app_{version}.apk";
        var full = Path.Combine(_root, safeName);

        await using (var fs = new FileStream(full, FileMode.Create, FileAccess.Write))
        {
            if (apk.CanSeek) apk.Position = 0;
            await apk.CopyToAsync(fs, ct);
        }

        var url = $"{_baseUrl}/download/{safeName}";
        return (full, url);
    }
}