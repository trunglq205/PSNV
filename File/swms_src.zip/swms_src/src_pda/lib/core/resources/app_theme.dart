import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Theme PDA — light & dark, dựng từ token SWMS.
abstract final class AppTheme {
  const AppTheme._();

  static ThemeData get light => _build(Brightness.light);

  static ThemeData get dark => _build(Brightness.dark);

  static ThemeData _build(Brightness b) {
    final isDark = b == Brightness.dark;
    final swms = isDark ? SwmsColors.dark : SwmsColors.light;

    final scheme =
        ColorScheme.fromSeed(
          seedColor: AppColors.primary,
          brightness: b,
          primary: AppColors.primary,
          error: AppColors.danger,
          surface: isDark ? AppColors.darkCard : AppColors.card,
        ).copyWith(
          surfaceContainerLowest: isDark ? AppColors.darkBg : AppColors.bg,
        );

    final textColor = swms.text1;

    return ThemeData(
      useMaterial3: true,
      brightness: b,
      colorScheme: scheme,
      scaffoldBackgroundColor: isDark ? AppColors.darkBg : AppColors.bg,
      fontFamily: AppTextStyles.sans,
      extensions: [swms],
      textTheme: TextTheme(
        headlineLarge: AppTextStyles.h1.copyWith(color: textColor),
        headlineMedium: AppTextStyles.h2.copyWith(color: textColor),
        titleLarge: AppTextStyles.title.copyWith(color: textColor),
        bodyLarge: AppTextStyles.body.copyWith(color: textColor),
        bodyMedium: AppTextStyles.body.copyWith(color: swms.text2),
        labelLarge: AppTextStyles.label.copyWith(color: textColor),
        bodySmall: AppTextStyles.caption.copyWith(color: swms.text3),
      ),
      // Input — bo 10px, viền theo token, nền card
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: isDark ? AppColors.darkCard : AppColors.card,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: AppDimens.md,
          vertical: AppDimens.md,
        ),
        border: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          borderSide: BorderSide(color: swms.border2),
        ),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          borderSide: BorderSide(color: swms.border),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          borderSide: const BorderSide(color: AppColors.primary, width: 2),
        ),
        errorBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(AppDimens.rInput),
          borderSide: const BorderSide(color: AppColors.danger),
        ),
      ),
      // Button mặc định — cao 44px, bo 12px
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(AppDimens.hitMd),
          textStyle: AppTextStyles.label,
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(AppDimens.rBtn),
          ),
        ),
      ),
      cardTheme: CardThemeData(
        color: isDark ? AppColors.darkCard : AppColors.card,
        elevation: 0,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(AppDimens.rCard),
          side: BorderSide(color: swms.border),
        ),
      ),
      appBarTheme: AppBarTheme(
        backgroundColor: AppColors.bg,
        foregroundColor: AppColors.text1,
        elevation: 0,
        centerTitle: false,
        titleTextStyle: AppTextStyles.title.copyWith(color: AppColors.text1),
      ),
      dividerTheme: DividerThemeData(color: swms.border),
    );
  }
}
