using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.ImportModel
{
    public class KittingPlanDIPImport
    {
        public string Plant { get; set; }
        public string FinishGoods { get; set; }
        public string Material { get; set; }
        public string Assembly { get; set; }
        public string Lvl { get; set; }
        public string MovingType { get; set; }
        public string Descriptions { get; set; }
        public double AssemblyQuantity { get; set; }
        public double MaterialQuantity { get; set; }
        public string Vendor { get; set; }
        public string Sloc { get; set; }
        public string Category { get; set; }
        public bool IsUrgent { get; set; }
        public DateTime? Deliverydate { get; set; }
    }

    public class ImportKittingListDIPViewModel
    {
        [Display(Name = "Delevery date")]
        [Required(ErrorMessage = "Delivery date is required.")]
        public DateTime? DeleveryDate { get; set; } = DateTime.Now;

        [Display(Name = "Plant")]
        [Required(ErrorMessage = "Plant field is required.")]
        public string? Plant { get; set; }

        [Display(Name = "Category")]
        [Required(ErrorMessage = "Category field is required.")]
        public string? Category { get; set; }

        public IEnumerable<KittingPlanDIPImport> KittingPlanDIPImports { get; set; }
    }
}
