using System.Data;
using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.Models;
using Swms.FinishGoods.API.Features.Users.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Users.DataAccess;

public class UserRepository : IUserRepository
{
    private readonly IDbConnectionFactory _factory;

    public UserRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    // Cột user dùng chung cho GetById / GetByEmployeeCode (tránh lặp).
    private const string UserColumns = """
        id, full_name AS FullName, email, department,
        employee_code AS EmployeeCode, password_hash AS PasswordHash,
        is_active AS IsActive, is_deleted AS IsDeleted,
        last_login_at AS LastLoginAt, created_at AS CreatedAt, updated_at AS UpdatedAt
        """;

    public async Task<User?> GetByIdAsync(int id)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {UserColumns}
            FROM master.users
            WHERE id = @id AND is_deleted = 0;
 
            SELECT r.code
            FROM master.user_roles ur
            JOIN master.roles r ON r.id = ur.role_id
            WHERE ur.user_id = @id;
            """;

        using var multi = await conn.QueryMultipleAsync(sql, new { id });
        return await ReadUserWithRolesAsync(multi);
    }

    public async Task<User?> GetByEmployeeCodeAsync(string code)
    {
        using var conn = _factory.Create();
        // Role join phải đi qua users để lấy user_id — user_roles KHÔNG có employee_code.
        var sql = $"""
            SELECT {UserColumns}
            FROM master.users
            WHERE employee_code = @code AND is_deleted = 0;
 
            SELECT r.code
            FROM master.user_roles ur
            JOIN master.roles r ON r.id = ur.role_id
            JOIN master.users u ON u.id = ur.user_id
            WHERE u.employee_code = @code AND u.is_deleted = 0;
            """;

        using var multi = await conn.QueryMultipleAsync(sql, new { code });
        return await ReadUserWithRolesAsync(multi);
    }

    // Đọc 1 user + danh sách role từ 2 result set của QueryMultiple.
    private static async Task<User?> ReadUserWithRolesAsync(SqlMapper.GridReader multi)
    {
        var user = await multi.ReadFirstOrDefaultAsync<User>();
        if (user is null) return null;
        user.RoleCodes = (await multi.ReadAsync<string>()).ToList();
        return user;
    }

    public async Task<(IReadOnlyList<User> Items, int Total)> GetPagedAsync(UserQuery query)
    {
        using var conn = _factory.Create();

        // RecentLogin: true = đăng nhập trong 24h; false = chưa/quá 24h.
        const string filter = """
            is_deleted = 0
            AND (@Keyword      IS NULL OR full_name LIKE '%' + @Keyword + '%' OR employee_code LIKE '%' + @Keyword + '%' OR email LIKE '%' + @Keyword + '%')
            AND (@Department   IS NULL OR department = @Department)
            AND (@IsActive     IS NULL OR is_active = @IsActive)
            AND (@Name         IS NULL OR full_name LIKE '%' + @Name + '%')
            AND (@Email        IS NULL OR email LIKE '%' + @Email + '%')
            AND (@EmployeeCode IS NULL OR employee_code LIKE '%' + @EmployeeCode + '%')
            AND (@RecentLogin  IS NULL
                 OR (@RecentLogin = 1 AND last_login_at IS NOT NULL AND last_login_at >= DATEADD(HOUR, -24, SYSDATETIME()))
                 OR (@RecentLogin = 0 AND (last_login_at IS NULL OR last_login_at < DATEADD(HOUR, -24, SYSDATETIME()))))
            AND (@CreatedFrom  IS NULL OR created_at >= @CreatedFrom)
            AND (@CreatedTo    IS NULL OR created_at <= @CreatedTo)
            """;

        var sql = $"""
            SELECT id, full_name AS FullName, email, department,
                   employee_code AS EmployeeCode, is_active AS IsActive,
                   last_login_at AS LastLoginAt, created_at AS CreatedAt, updated_at AS UpdatedAt
            FROM master.users
            WHERE {filter}
            ORDER BY id
            OFFSET (@Page - 1) * @Size ROWS FETCH NEXT @Size ROWS ONLY;

            SELECT COUNT(*) FROM master.users WHERE {filter};
            """;

        using var multi = await conn.QueryMultipleAsync(sql, query);
        var items = (await multi.ReadAsync<User>()).ToList();
        var total = await multi.ReadFirstAsync<int>();

        // Nạp role cho các user của trang hiện tại trong 1 query.
        if (items.Count > 0)
        {
            const string rolesSql = """
                SELECT ur.user_id AS UserId, r.code AS Code
                FROM master.user_roles ur
                JOIN master.roles r ON r.id = ur.role_id
                WHERE ur.user_id IN @Ids;
                """;
            var pairs = await conn.QueryAsync<(int UserId, string Code)>(
                rolesSql, new { Ids = items.Select(i => i.Id).ToArray() });

            var map = pairs.GroupBy(p => p.UserId)
                           .ToDictionary(g => g.Key, g => g.Select(x => x.Code).ToList());
            foreach (var u in items)
                u.RoleCodes = map.TryGetValue(u.Id, out var rc) ? rc : new();
        }

        return (items, total);
    }

    public async Task<int> AddAsync(User entity, IReadOnlyList<string> roleCodes)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        const string insertSql = """
        INSERT INTO master.users
            (full_name, email, department, employee_code,
             password_hash, is_active, is_deleted, created_at, created_by)
        VALUES
            (@FullName, @Email, @Department, @EmployeeCode,
             @PasswordHash, @IsActive, 0, @CreatedAt, @CreatedBy);
        SELECT CAST(SCOPE_IDENTITY() AS int);
        """;
        var id = await conn.ExecuteScalarAsync<int>(insertSql, entity, tx);
        await ReplaceRolesAsync(conn, tx, id, roleCodes);
        tx.Commit();
        return id;
    }

    public async Task<List<int>> AddManyAsync(IReadOnlyList<User> entities)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string insertSql = """
    INSERT INTO master.users
        (full_name, email, department, employee_code,
         password_hash, is_active, is_deleted, created_at, created_by)
    VALUES
        (@FullName, @Email, @Department, @EmployeeCode,
         @PasswordHash, @IsActive, 0, @CreatedAt, @CreatedBy);
    SELECT CAST(SCOPE_IDENTITY() AS int);
    """;

        var ids = new List<int>(entities.Count);
        foreach (var entity in entities)
        {
            var id = await conn.ExecuteScalarAsync<int>(insertSql, entity, tx);
            await ReplaceRolesAsync(conn, tx, id, entity.RoleCodes);
            ids.Add(id);
        }

        tx.Commit();
        return ids;
    }

    public async Task<bool> UpdateAsync(User entity, IReadOnlyList<string> roleCodes)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        const string updateSql = """
        UPDATE master.users
        SET full_name = @FullName,
            email = @Email,
            department = @Department,
            is_active = @IsActive,
            updated_at = @UpdatedAt,
            updated_by = @UpdatedBy
        WHERE id = @Id AND is_deleted = 0;
        """;
        var affected = await conn.ExecuteAsync(updateSql, entity, tx);
        if (affected == 0)
        {
            tx.Rollback();
            return false;
        }
        await ReplaceRolesAsync(conn, tx, entity.Id, roleCodes);
        tx.Commit();
        return true;
    }

    public async Task<bool> UpdateLastLoginAsync(long id, DateTime lastLoginAt)
    {
        using var conn = _factory.Create();
        const string updateSql = """
        UPDATE master.users
        SET last_login_at = @LastLoginAt
        WHERE id = @Id AND is_deleted = 0;
        """;
        var affected = await conn.ExecuteAsync(updateSql, new { Id = id, LastLoginAt = lastLoginAt });
        return affected > 0;
    }

    public async Task<bool> SoftDeleteAsync(int id, string? userId)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.users
            SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @userId
            WHERE id = @id AND is_deleted = 0;
            """;
        return await conn.ExecuteAsync(sql, new { id, userId }) > 0;
    }

    public async Task<bool> EmployeeCodeExistsAsync(string employeeCode, int? excludeId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT COUNT(1) FROM master.users
            WHERE employee_code = @employeeCode AND is_deleted = 0
              AND (@excludeId IS NULL OR id <> @excludeId);
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { employeeCode, excludeId }) > 0;
    }

    public async Task<IReadOnlyList<(int Id, string EmployeeCode)>> GetExistingEmployeeCodesAsync(IReadOnlyList<string> empCodes)
    {
        using var conn = _factory.Create();
        const string sql = """
             SELECT id, employee_code
             FROM master.users
             WHERE is_deleted = 0
               AND employee_code IN @Codes;
        """;
        var rows = await conn.QueryAsync<(int Id, string EmployeeCode)>(sql, new { Codes = empCodes });
        return rows.ToList();
    }

    public async Task UpdatePasswordHashAsync(int id, string passwordHash, string? userId)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.users
            SET password_hash = @passwordHash, updated_at = SYSDATETIME(), updated_by = @userId
            WHERE id = @id AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(sql, new { id, passwordHash, userId });
    }

    public async Task<Dictionary<string, int>> GetDeptCountsAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT department AS Department, COUNT(*) AS Cnt
            FROM master.users
            WHERE is_deleted = 0
            GROUP BY department;

            SELECT COUNT(*) FROM master.users WHERE is_deleted = 0;
            """;

        using var multi = await conn.QueryMultipleAsync(sql);
        var rows = await multi.ReadAsync<(string Department, int Cnt)>();
        var total = await multi.ReadFirstAsync<int>();

        var result = rows.ToDictionary(r => r.Department, r => r.Cnt);
        result[""] = total;   // key rỗng = tổng tất cả
        return result;
    }

    public async Task<IReadOnlyList<Role>> GetAllRolesAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT id, code, name, description, dot
            FROM master.roles
            WHERE is_deleted = 0
            ORDER BY id;
            """;
        return (await conn.QueryAsync<Role>(sql)).ToList();
    }

    // Xoá hết role hiện tại rồi gắn lại theo code — đơn giản, đúng cho cả create/update.
    private static async Task ReplaceRolesAsync(
        IDbConnection conn, IDbTransaction tx, int userId, IReadOnlyList<string> roleCodes)
    {
        await conn.ExecuteAsync(
            "DELETE FROM master.user_roles WHERE user_id = @userId;",
            new { userId }, tx);

        if (roleCodes.Count == 0) return;

        const string insertSql = """
            INSERT INTO master.user_roles (user_id, role_id)
            SELECT @userId, r.id
            FROM master.roles r
            WHERE r.code = @code AND r.is_deleted = 0;
            """;
        foreach (var code in roleCodes)
            await conn.ExecuteAsync(insertSql, new { userId, code }, tx);
    }
}