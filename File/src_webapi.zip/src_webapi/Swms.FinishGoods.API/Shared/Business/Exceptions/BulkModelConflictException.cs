using Swms.FinishGoods.Api.Features.Models.Api;

namespace Swms.FinishGoods.API.Shared.Business.Exceptions;

/// <summary>
/// Ném khi bulk create có bản ghi trùng (trong DB hoặc nội bộ batch).
/// Middleware map sang HTTP 409 + payload chứa danh sách conflict để FE hiển thị
/// (khớp ErrorCode.BulkConflict + ConflictDetail phía Web).
/// </summary>
public sealed class BulkModelConflictException : Exception
{
    public IReadOnlyList<DuplicateModelInfo> Conflicts { get; }

    public BulkModelConflictException(string message, IReadOnlyList<DuplicateModelInfo> conflicts)
        : base(message) => Conflicts = conflicts;
}
