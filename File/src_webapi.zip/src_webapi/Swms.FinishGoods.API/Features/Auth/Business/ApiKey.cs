﻿using System.Security.Cryptography;

namespace Swms.FinishGoods.API.Features.Auth.Business;

// Một API key cấp cho hệ thống ngoài (QMS, SAP, HRM, ...).
// Map với master.api_keys. Giá trị key CỐ ĐỊNH đến khi revoke/rotate.
// Chỉ lưu hash, không lưu plaintext.
public class ApiKey
{
    public long Id { get; set; }
    public string ClientName { get; set; } = string.Empty;
    public string KeyPrefix { get; set; } = string.Empty;
    public string KeyHash { get; set; } = string.Empty;
    public string PermissionsCsv { get; set; } = string.Empty;
    public bool IsActive { get; set; } = true;
    public DateTime? ExpiresAt { get; set; }
    public DateTime? LastUsedAt { get; set; }
    public DateTime? RevokedAt { get; set; }
    public bool IsDeleted { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    public IReadOnlyList<string> Permissions =>
        PermissionsCsv.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
}

// Sinh key ngẫu nhiên. fullKey chỉ hiện MỘT lần khi cấp/rotate.
public static class ApiKeyGenerator
{
    public const int PrefixLength = 12;

    // Trả về (fullKey đưa client 1 lần, prefix lưu DB để tra nhanh).
    public static (string fullKey, string prefix) Create(string clientName)
    {
        var raw = Convert.ToBase64String(RandomNumberGenerator.GetBytes(32))
                         .Replace("+", "").Replace("/", "").Replace("=", "");
        var slug = new string(clientName.ToLowerInvariant()
                        .Where(char.IsLetterOrDigit).Take(6).ToArray());
        if (slug.Length == 0) slug = "svc";
        var fullKey = $"sk_{slug}_{raw}";
        var prefix = fullKey[..PrefixLength];
        return (fullKey, prefix);
    }
}