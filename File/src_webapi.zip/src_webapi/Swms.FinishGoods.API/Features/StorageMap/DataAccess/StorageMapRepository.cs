using Dapper;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.StorageMap.DataAccess;

public class StorageMapRepository : IStorageMapRepository
{
    private readonly IDbConnectionFactory _factory;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public StorageMapRepository(
        IDbConnectionFactory factory,
        IStringLocalizer<SharedResource> localizer)
    {
        _factory = factory;
        _localizer = localizer;
    }

    public async Task<IReadOnlyList<RackSummary>> GetRacksAsync(string areaCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT  r.id                                                     AS Id,
                    r.rack_code                                              AS RackCode,
                    r.rack_name                                             AS RackName,
                    /* DISTINCT l.id ở cả bốn con số: LEFT JOIN sang wms.pallets
                       nhân ô có nhiều lô ra nhiều dòng, nên COUNT/SUM thường
                       sẽ đếm LÔ chứ không đếm Ô. Xem ghi chú dài ở posSql
                       trong GetTopMapAsync. */
                    COUNT(DISTINCT l.id)                                     AS TotalSlots,
                    COUNT(DISTINCT CASE WHEN p.id IS NOT NULL THEN l.id END) AS OccupiedSlots,
                    COUNT(DISTINCT CASE WHEN l.slot_kind = N'pallet' THEN l.id END) AS PalletSlots,
                    COUNT(DISTINCT CASE WHEN l.slot_kind = N'shelf'  THEN l.id END) AS ShelfSlots,
                    r.sort_order                                            AS SortOrder
            FROM        master.racks r
            JOIN        master.warehouse_areas a ON a.id = r.area_id AND a.is_deleted = 0
            LEFT JOIN   master.locators l        ON l.rack_id = r.id AND l.is_deleted = 0
            LEFT JOIN   wms.pallets    p         ON p.locator_id = l.id AND p.is_deleted = 0
            WHERE a.area_code = @AreaCode AND r.is_deleted = 0
            GROUP BY r.id, r.rack_code, r.rack_name, r.sort_order
            ORDER BY r.sort_order, r.rack_code;
            """;
        return (await conn.QueryAsync<RackSummary>(sql, new { AreaCode = areaCode })).ToList();
    }

    public async Task<RackSummary?> GetRackByCodeAsync(string areaCode, string rackCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT  r.id                                                     AS Id,
                    r.rack_code                                              AS RackCode,
                    r.rack_name                                             AS RackName,
                    /* DISTINCT l.id: xem ghi chú ở GetRacksAsync. */
                    COUNT(DISTINCT l.id)                                     AS TotalSlots,
                    COUNT(DISTINCT CASE WHEN p.id IS NOT NULL THEN l.id END) AS OccupiedSlots,
                    COUNT(DISTINCT CASE WHEN l.slot_kind = N'pallet' THEN l.id END) AS PalletSlots,
                    COUNT(DISTINCT CASE WHEN l.slot_kind = N'shelf'  THEN l.id END) AS ShelfSlots,
                    r.sort_order                                            AS SortOrder,
                    r.cols                                                  AS Cols,
                    r.rows                                                  AS Rows
            FROM        master.racks r
            JOIN        master.warehouse_areas a ON a.id = r.area_id AND a.is_deleted = 0
            LEFT JOIN   master.locators l        ON l.rack_id = r.id AND l.is_deleted = 0
            LEFT JOIN   wms.pallets    p         ON p.locator_id = l.id AND p.is_deleted = 0
            WHERE a.area_code = @AreaCode AND r.rack_code = @RackCode AND r.is_deleted = 0
            GROUP BY r.id, r.rack_code, r.rack_name, r.sort_order, r.cols, r.rows;
            """;
        return await conn.QuerySingleOrDefaultAsync<RackSummary>(
            sql, new { AreaCode = areaCode, RackCode = rackCode });
    }

    public async Task<IReadOnlyList<ElevationLocator>> GetElevationAsync(string areaCode, string rackCode)
    {
        using var conn = _factory.Create();

        // 1) Mỗi ô đúng 1 dòng. Thông tin pallet lấy của pallet mới nhất để vẽ mặt cắt.
        const string cellSql = """
            SELECT  l.id           AS LocatorId,
                    l.locator_code AS LocatorCode,
                    l.rack_col     AS Location,
                    l.rack_row     AS Floor,
                    l.slot_kind    AS SlotKind,
                    l.rack_level   AS Level,
                    CAST(CASE WHEN p.id IS NULL THEN 0 ELSE 1 END AS bit) AS Occupied,
                    RTRIM(p.pallet_id) AS PalletId,
                    p.model            AS Model,
                    p.box_count        AS BoxCount,
                    p.production_date  AS ProductionDate,
                    p.disposition      AS Disposition,
                    ISNULL(p.stop_shipment, 0) AS StopShipment,
                    p.inspection_status AS Status,
                    ISNULL(p.is_urgent, 0) AS IsUrgent
            FROM        master.racks r
            JOIN        master.warehouse_areas a ON a.id = r.area_id AND a.is_deleted = 0
            JOIN        master.locators l        ON l.rack_id = r.id AND l.is_deleted = 0
            OUTER APPLY (
                -- model: pallet serial / box_line KHÔNG ghi cột pallets.model
                -- (model nằm ở box_lines), nên đọc thẳng x.model sẽ ra trống cho
                -- đúng hai loại đó. Gộp từ box_lines trước, rỗng mới rơi về cột
                -- của pallet (đường của box_count). Cùng quy ước LocationInfoSql.
                SELECT TOP 1 x.id, x.pallet_id,
                             COALESCE(
                                 (SELECT STRING_AGG(z.model, ', ')
                                  FROM (SELECT DISTINCT bl.model
                                        FROM wms.boxes bx
                                        JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                                        WHERE bx.lot_id = x.id AND bx.is_deleted = 0) z),
                                 x.model) AS model,
                             x.box_count,
                             x.production_date, x.disposition, x.stop_shipment,
                             x.inspection_status, x.is_urgent
                FROM wms.pallets x
                WHERE x.locator_id = l.id AND x.is_deleted = 0
                ORDER BY x.id DESC
            ) p
            WHERE a.area_code = @AreaCode AND r.rack_code = @RackCode AND r.is_deleted = 0
            ORDER BY l.rack_col, l.rack_row, l.rack_level;
            """;
        var cells = (await conn.QueryAsync<ElevationLocator>(
            cellSql, new { AreaCode = areaCode, RackCode = rackCode })).ToList();

        // 2) Toàn bộ pallet của kệ — ghép vào từng ô để xem chi tiết khi ô chứa nhiều pallet.
        const string palletSql = """
            SELECT  l.id               AS LocatorId,
                    p.id               AS LotId,
                    RTRIM(p.pallet_id) AS PalletId,
                    -- Xem chú thích ở cellSql: gộp box_lines trước, rỗng mới
                    -- rơi về pallets.model (đường của box_count).
                    COALESCE(
                        (SELECT STRING_AGG(z.model, ', ')
                         FROM (SELECT DISTINCT bl.model
                               FROM wms.boxes bx
                               JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                               WHERE bx.lot_id = p.id AND bx.is_deleted = 0) z),
                        p.model) AS Model,
                    p.box_count        AS BoxCount,
                    p.production_date  AS ProductionDate,
                    p.disposition      AS Disposition,
                    ISNULL(p.stop_shipment, 0) AS StopShipment,
                    p.inspection_status AS Status,
                    ISNULL(p.is_urgent, 0) AS IsUrgent
            FROM        master.racks r
            JOIN        master.warehouse_areas a ON a.id = r.area_id AND a.is_deleted = 0
            JOIN        master.locators l        ON l.rack_id = r.id AND l.is_deleted = 0
            JOIN        wms.pallets  p           ON p.locator_id = l.id AND p.is_deleted = 0
            WHERE a.area_code = @AreaCode AND r.rack_code = @RackCode AND r.is_deleted = 0
            ORDER BY l.id, p.id DESC;
            """;
        var rows = await conn.QueryAsync<(long LocatorId, long LotId, string? PalletId,
                                          string? Model, int? BoxCount, DateTime? ProductionDate,
                                          string? Disposition, bool StopShipment)>(
            palletSql, new { AreaCode = areaCode, RackCode = rackCode });

        var byLocator = rows.GroupBy(x => x.LocatorId)
            .ToDictionary(g => g.Key, g => g.Select(x => new ElevationPallet
            {
                LotId = x.LotId,
                PalletId = x.PalletId,
                Model = x.Model,
                BoxCount = x.BoxCount,
                ProductionDate = x.ProductionDate,
                Disposition = x.Disposition,
                StopShipment = x.StopShipment
            }).ToList());

        foreach (var c in cells)
            if (byLocator.TryGetValue(c.LocatorId, out var list))
                c.Pallets = list;

        return cells;
    }

    public async Task<TopMap?> GetTopMapAsync(string areaCode)
    {
        using var conn = _factory.Create();

        const string areaSql = """
            SELECT TOP 1 area_code AS AreaCode, cols AS Cols, rows AS Rows,
                   CAST(cell_meters AS float) AS CellMeters
            FROM master.warehouse_areas
            WHERE area_code = @AreaCode AND is_deleted = 0;
            """;
        var map = await conn.QuerySingleOrDefaultAsync<TopMap>(areaSql, new { AreaCode = areaCode });
        if (map is null) return null;

        const string blocksSql = """
            SELECT  m.id          AS Id,
                    m.target_type AS Kind,
                    r.id          AS RackId,
                    r.rack_code   AS RackCode,
                    m.label       AS Label,
                    m.color       AS Color,
                    m.grid_x      AS GridX,
                    m.grid_y      AS GridY,
                    m.grid_w      AS GridW,
                    m.grid_h      AS GridH,
                    ISNULL(rc.TotalSlots, 0)    AS TotalSlots,
                    ISNULL(rc.OccupiedSlots, 0) AS OccupiedSlots,
                    lo.id           AS LocatorId,
                    lo.locator_code AS LocatorCode,
                    pl.inspection_status AS Status,
                    ISNULL(pl.is_urgent, 0)     AS IsUrgent,
                    pl.pallet_id      AS PalletId,
                    pl.box_count      AS BoxCount,
                    pl.production_date AS ProductionDate,
                    -- Pallet box_count không có box_lines -> model nằm ở cột
                    -- pallets.model. Thiếu fallback thì loại này hiện model trống
                    -- trên Storage top-map. Cùng quy ước với LocationInfoSql.
                    pl.models         AS Model
            FROM        master.locator_map m
            JOIN        master.warehouse_areas a ON a.id = m.parent_id AND a.area_code = @AreaCode AND a.is_deleted = 0
            LEFT JOIN   master.racks r           ON r.id = m.rack_id AND r.is_deleted = 0
            LEFT JOIN   master.locators lo        ON lo.id = m.locator_id AND lo.is_deleted = 0
            OUTER APPLY (
                SELECT TOP 1 p.inspection_status, p.is_urgent, p.pallet_id,
                       p.box_count, p.production_date,
                       COALESCE(
                           (SELECT STRING_AGG(z.model, ', ')
                            FROM (SELECT DISTINCT bl.model
                                  FROM wms.boxes bx
                                  JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                                  WHERE bx.lot_id = p.id AND bx.is_deleted = 0) z),
                           p.model) AS models
                FROM wms.pallets p
                WHERE p.locator_id = lo.id AND p.is_deleted = 0
                ORDER BY p.id DESC
            ) pl
            OUTER APPLY (
                /* Đếm theo Ô, không theo LÔ — một ô nhiều lô thì LEFT JOIN
                   nhân dòng. Xem ghi chú ở posSql bên dưới. Đây là hai con số
                   in ở nhãn chân dãy "E1 (24/58)". */
                SELECT COUNT(DISTINCT l.id) AS TotalSlots,
                       COUNT(DISTINCT CASE WHEN p.id IS NOT NULL THEN l.id END) AS OccupiedSlots
                FROM      master.locators l
                LEFT JOIN wms.pallets   p ON p.locator_id = l.id AND p.is_deleted = 0
                WHERE l.rack_id = m.rack_id AND l.is_deleted = 0
            ) rc
            WHERE m.parent_type = N'area'
              AND m.target_type IN (N'rack', N'zone', N'locator')
              AND m.is_deleted = 0
            ORDER BY m.sort_order;
            """;
        var blocks = (await conn.QueryAsync<TopMapBlock>(blocksSql, new { AreaCode = areaCode })).ToList();

        // Tồn theo từng vị trí (bao) của mọi kệ trong khu -> để chia ô top-down.
        const string posSql = """
            SELECT  l.rack_id  AS RackId,
                    l.rack_col AS Position,
                    /* PHẢI là COUNT(DISTINCT l.id), KHÔNG phải COUNT(l.id).
                       Một ô có thể chứa NHIỀU lô (wms.pallets nhiều dòng cùng
                       locator_id — xem OUTER APPLY pl ở trên dùng TOP 1 chính
                       vì vậy). LEFT JOIN nhân ô đó ra nhiều dòng, nên
                       COUNT(l.id) đếm số LÔ chứ không đếm số Ô: vị trí 5 tầng
                       mà 2 tầng mỗi tầng 2 lô sẽ ra 7, và vì tầng nào cũng có
                       hàng nên Occupied cũng 7 -> nhãn hiện "7/7". */
                    COUNT(DISTINCT l.id) AS Total,
                    /* Ô CÓ HÀNG, đếm theo ô. CASE trả NULL cho ô trống và
                       COUNT bỏ qua NULL, nên ô trống không bị tính. */
                    COUNT(DISTINCT CASE WHEN p.id IS NOT NULL THEN l.id END) AS Occupied
            FROM        master.locators l
            JOIN        master.racks r           ON r.id = l.rack_id AND r.is_deleted = 0
            JOIN        master.warehouse_areas a ON a.id = r.area_id AND a.area_code = @AreaCode AND a.is_deleted = 0
            LEFT JOIN   wms.pallets p            ON p.locator_id = l.id AND p.is_deleted = 0
            WHERE l.is_deleted = 0
            GROUP BY l.rack_id, l.rack_col;
            """;
        var posList = (await conn.QueryAsync<PositionOcc>(posSql, new { AreaCode = areaCode })).ToList();
        var byRack = posList.GroupBy(x => x.RackId)
                            .ToDictionary(g => g.Key, g => g.OrderBy(x => x.Position).ToList());
        foreach (var b in blocks)
            if (b.RackId is long rid && byRack.TryGetValue(rid, out var ps))
                b.Positions = ps;

        map.Blocks = blocks;
        return map;
    }


    public async Task SaveTopMapAsync(string areaCode, IReadOnlyList<SaveTopMapBlock> blocks, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var areaId = await conn.ExecuteScalarAsync<long?>(
                "SELECT id FROM master.warehouse_areas WHERE area_code = @areaCode AND is_deleted = 0",
                new { areaCode }, tx);
            if (areaId is null) throw new NotFoundException(_localizer["Storage.Err.AreaNotFound"]);

            var keptIds = blocks.Where(b => b.Id.HasValue).Select(b => b.Id!.Value).ToList();

            const string softDel = """
                UPDATE master.locator_map
                SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE parent_type = N'area' AND parent_id = @areaId
                  AND target_type IN (N'rack', N'zone') AND is_deleted = 0
                  AND (@hasKept = 0 OR id NOT IN @keptIds);
                """;
            await conn.ExecuteAsync(softDel, new
            {
                areaId,
                user,
                hasKept = keptIds.Count > 0 ? 1 : 0,
                keptIds = keptIds.Count > 0 ? keptIds : new List<long> { -1 }
            }, tx);

            const string upd = """
                UPDATE master.locator_map
                SET grid_x = @GridX, grid_y = @GridY, grid_w = @GridW, grid_h = @GridH,
                    label = @Label, color = @Color, sort_order = @SortOrder,
                    is_deleted = 0, updated_at = SYSDATETIME(), updated_by = @user
                WHERE id = @Id AND parent_type = N'area' AND parent_id = @areaId;
                """;
            const string ins = """
                INSERT INTO master.locator_map
                    (parent_type, parent_id, target_type, rack_id,
                     grid_x, grid_y, grid_w, grid_h, label, color,
                     sort_order, is_active, is_deleted, created_at, created_by)
                VALUES
                    (N'area', @areaId, N'zone', NULL,
                     @GridX, @GridY, @GridW, @GridH, @Label, @Color,
                     @SortOrder, 1, 0, SYSDATETIME(), @user);
                """;

            int so = 1;
            foreach (var b in blocks)
            {
                var p = new
                {
                    b.Id, areaId, Kind = b.Kind, b.RackId,
                    b.GridX, b.GridY, b.GridW, b.GridH,
                    b.Label, b.Color, SortOrder = so++, user
                };
                if (b.Id.HasValue)
                {
                    var n = await conn.ExecuteAsync(upd, p, tx);
                    if (n == 0) await conn.ExecuteAsync(ins, p, tx);
                }
                else
                {
                    await conn.ExecuteAsync(ins, p, tx);
                }
            }

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }


    public async Task CreateRackAsync(string areaCode, string code, int positions, int floors, IReadOnlyList<int> shelfPositions,
        int gridX, int gridY, int gridW, int gridH, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var areaId = await conn.ExecuteScalarAsync<long?>(
                "SELECT id FROM master.warehouse_areas WHERE area_code = @areaCode AND is_deleted = 0",
                new { areaCode }, tx) ?? throw new NotFoundException(_localizer["Storage.Err.AreaNotFound"]);

            var exists = await conn.ExecuteScalarAsync<int>(
                "SELECT COUNT(1) FROM master.racks WHERE rack_code = @code AND is_deleted = 0",
                new { code }, tx);
            if (exists > 0) throw new ConflictException(_localizer["Storage.Err.RackExists", code]);

            var rackId = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO master.racks
                    (rack_code, rack_name, area_id, rows, cols, sort_order, is_active, is_deleted, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@code, @name, @areaId, @floors, @positions, 100, 1, 0, SYSDATETIME(), @user);
                """, new { code, name = "Rack " + code, areaId, floors, positions, user }, tx);

            const string insLoc = """
                INSERT INTO master.locators
                    (locator_code, area_id, rack_id, rack_row, rack_col, rack_level, slot_kind,
                     current_status, sort_order, is_active, is_deleted, created_at, created_by)
                VALUES (@Code, @AreaId, @RackId, @Row, @Col, @Level, @Kind,
                        N'empty', @Sort, 1, 0, SYSDATETIME(), @User);
                """;

            var shelfSet = new HashSet<int>(shelfPositions ?? Array.Empty<int>());
            int sort = 0;
            for (int pos = 1; pos <= positions; pos++)
            {
                if (shelfSet.Contains(pos))
                {
                    // giá lửng: tầng 1 chia 2 ngăn A/B + tầng 2-4 pallet
                    await conn.ExecuteAsync(insLoc, new { Code = BuildCellCode(code, pos, 1, "A"), AreaId = areaId, RackId = rackId, Row = 1, Col = pos, Level = "A", Kind = "shelf", Sort = ++sort, User = user }, tx);
                    await conn.ExecuteAsync(insLoc, new { Code = BuildCellCode(code, pos, 1, "B"), AreaId = areaId, RackId = rackId, Row = 1, Col = pos, Level = "B", Kind = "shelf", Sort = ++sort, User = user }, tx);
                    for (int fl = 2; fl <= floors; fl++)
                        await conn.ExecuteAsync(insLoc, new { Code = BuildCellCode(code, pos, fl), AreaId = areaId, RackId = rackId, Row = fl, Col = pos, Level = (string?)null, Kind = "pallet", Sort = ++sort, User = user }, tx);
                }
                else
                {
                    // pallet 4 tầng
                    for (int fl = 1; fl <= floors; fl++)
                        await conn.ExecuteAsync(insLoc, new { Code = BuildCellCode(code, pos, fl), AreaId = areaId, RackId = rackId, Row = fl, Col = pos, Level = (string?)null, Kind = "pallet", Sort = ++sort, User = user }, tx);
                }
            }

            await conn.ExecuteAsync("""
                INSERT INTO master.locator_map
                    (parent_type, parent_id, target_type, rack_id, grid_x, grid_y, grid_w, grid_h,
                     sort_order, is_active, is_deleted, created_at, created_by)
                VALUES (N'area', @areaId, N'rack', @rackId, @gridX, @gridY, @gridW, @gridH,
                        100, 1, 0, SYSDATETIME(), @user);
                """, new { areaId, rackId, gridX, gridY, gridW, gridH, user }, tx);

            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task DeleteRackAsync(string areaCode, string rackCode, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var rackId = await conn.ExecuteScalarAsync<long?>("""
                SELECT r.id FROM master.racks r
                JOIN master.warehouse_areas a ON a.id = r.area_id
                WHERE a.area_code = @areaCode AND r.rack_code = @rackCode AND r.is_deleted = 0;
                """, new { areaCode, rackCode }, tx) ?? throw new NotFoundException(_localizer["Storage.Err.RackNotFound", rackCode]);

            var occupied = await conn.ExecuteScalarAsync<int>("""
                SELECT COUNT(1) FROM wms.pallets p
                JOIN master.locators l ON l.id = p.locator_id
                WHERE l.rack_id = @rackId AND p.is_deleted = 0 AND l.is_deleted = 0;
                """, new { rackId }, tx);
            if (occupied > 0) throw new BusinessRuleException(_localizer["Storage.Err.RackHasStock"]);

            var p = new { rackId, user };
            // soft-delete: giữ dữ liệu, chỉ đánh dấu is_deleted
            await conn.ExecuteAsync("UPDATE master.locator_map SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user WHERE rack_id = @rackId AND is_deleted = 0;", p, tx);
            await conn.ExecuteAsync("UPDATE master.locators   SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user WHERE rack_id = @rackId AND is_deleted = 0;", p, tx);
            await conn.ExecuteAsync("UPDATE master.racks       SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user WHERE id = @rackId;", p, tx);

            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }


    /// <summary>
    /// Sinh mã ô theo đúng quy ước của kệ đang thao tác.
    ///   Mã kệ có dấu chấm (1.B12A) -> {kệ}.{tầng}.{vị trí 2 chữ số}  — kiểu MCS
    ///   Mã kệ thường     (E1)      -> {kệ}-{vị trí}-{tầng}           — kiểu mặc định
    /// Ghép cứng bằng dấu gạch sẽ tạo mã lệch với tem đã dán ngoài kho.
    /// </summary>
    private static string BuildCellCode(string rackCode, int position, int floor, string? level = null)
    {
        var dotted = rackCode.Contains('.');
        var code = dotted
            ? $"{rackCode}.{floor}.{position:00}"
            : $"{rackCode}-{position}-{floor}";
        return level is null ? code : code + (dotted ? "." : "-") + level;
    }

    public async Task SetCellKindAsync(string areaCode, string rackCode, int position, int floor, string kind, string? user)
    {
        kind = kind is "pallet" or "shelf" or "none" ? kind : "pallet";
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var rackId = await conn.ExecuteScalarAsync<long?>("""
                SELECT r.id FROM master.racks r
                JOIN master.warehouse_areas a ON a.id = r.area_id
                WHERE a.area_code = @areaCode AND r.rack_code = @rackCode AND r.is_deleted = 0;
                """, new { areaCode, rackCode }, tx) ?? throw new NotFoundException(_localizer["Storage.Err.RackNotFound", rackCode]);

            var active = (await conn.QueryAsync<ElevationLocator>("""
                SELECT l.id AS LocatorId, l.slot_kind AS SlotKind, l.rack_level AS Level,
                       CAST(CASE WHEN EXISTS (SELECT 1 FROM wms.pallets p WHERE p.locator_id = l.id AND p.is_deleted = 0) THEN 1 ELSE 0 END AS bit) AS Occupied
                FROM master.locators l
                WHERE l.rack_id = @rackId AND l.rack_col = @position AND l.rack_row = @floor AND l.is_deleted = 0;
                """, new { rackId, position, floor }, tx)).ToList();
            if (active.Any(x => x.Occupied)) throw new BusinessRuleException(_localizer["Storage.Err.CellHasPallet"]);

            var hasShelf = active.Any(x => x.SlotKind == "shelf");
            var hasPallet = active.Any(x => x.SlotKind != "shelf");
            var areaIdRack = await conn.ExecuteScalarAsync<long>("SELECT area_id FROM master.racks WHERE id = @rackId;", new { rackId }, tx);
            string palCode = BuildCellCode(rackCode, position, floor),
                   aCode   = BuildCellCode(rackCode, position, floor, "A"),
                   bCode   = BuildCellCode(rackCode, position, floor, "B");

            async Task SoftDel(long id) => await conn.ExecuteAsync("UPDATE master.locators SET is_deleted=1, updated_at=SYSDATETIME(), updated_by=@user WHERE id=@id;", new { user, id }, tx);
            async Task<int> Revive(string levelSql, string code, string slot) => await conn.ExecuteAsync($$"""
                UPDATE master.locators SET is_deleted=0, locator_code=@code, rack_level={{levelSql}}, slot_kind=@slot, current_status=N'empty', updated_at=SYSDATETIME(), updated_by=@user
                WHERE rack_id=@rackId AND rack_col=@position AND rack_row=@floor AND rack_level {{(levelSql=="NULL" ? "IS NULL" : "= "+levelSql)}} AND is_deleted=1;
                """, new { code, slot, rackId, position, floor, user }, tx);
            async Task Ins(string levelSql, string code, string slot) => await conn.ExecuteAsync($$"""
                INSERT INTO master.locators (locator_code, area_id, rack_id, rack_row, rack_col, rack_level, slot_kind, current_status, sort_order, is_active, is_deleted, created_at, created_by)
                VALUES (@code, @areaId, @rackId, @floor, @position, {{levelSql}}, @slot, N'empty', (SELECT ISNULL(MAX(sort_order),0)+1 FROM master.locators WHERE rack_id=@rackId), 1, 0, SYSDATETIME(), @user);
                """, new { code, areaId = areaIdRack, rackId, floor, position, slot, user }, tx);
            // Hồi sinh theo locator_code (bất kể rack_level cũ) — tránh INSERT trùng mã.
            async Task<int> ReviveByCode(string levelSql, string code, string slot) => await conn.ExecuteAsync($$"""
                UPDATE master.locators
                SET is_deleted=0, rack_id=@rackId, rack_col=@position, rack_row=@floor,
                    rack_level={{levelSql}}, slot_kind=@slot, current_status=N'empty',
                    is_active=1, updated_at=SYSDATETIME(), updated_by=@user
                WHERE locator_code=@code;
                """, new { code, slot, rackId, position, floor, user }, tx);

            async Task Ensure(string levelSql, string code, string slot)
            {
                if (await Revive(levelSql, code, slot) > 0) return;
                if (await ReviveByCode(levelSql, code, slot) > 0) return;
                await Ins(levelSql, code, slot);
            }

            if (kind == "none")
            {
                foreach (var c in active) await SoftDel(c.LocatorId);
                tx.Commit(); return;
            }

            if (kind == "pallet")
            {
                if (hasPallet && !hasShelf) { tx.Commit(); return; }
                if (hasShelf)
                {
                    var a = active.FirstOrDefault(x => x.Level == "A") ?? active.First(x => x.SlotKind == "shelf");
                    await conn.ExecuteAsync("UPDATE master.locators SET locator_code=@code, rack_level=NULL, slot_kind=N'pallet', updated_at=SYSDATETIME(), updated_by=@user WHERE id=@id;", new { code = palCode, user, id = a.LocatorId }, tx);
                    foreach (var o in active.Where(x => x.LocatorId != a.LocatorId)) await SoftDel(o.LocatorId);
                }
                else { await Ensure("NULL", palCode, "pallet"); }   // X -> pallet
                tx.Commit(); return;
            }

            // kind == "shelf"
            if (hasShelf) { tx.Commit(); return; }
            if (hasPallet)
            {
                var pal = active.First(x => x.SlotKind != "shelf");
                await conn.ExecuteAsync("UPDATE master.locators SET locator_code=@code, rack_level=N'A', slot_kind=N'shelf', updated_at=SYSDATETIME(), updated_by=@user WHERE id=@id;", new { code = aCode, user, id = pal.LocatorId }, tx);
            }
            else { await Ensure("N'A'", aCode, "shelf"); }
            await Ensure("N'B'", bCode, "shelf");
            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<LocatorLocation?> LocateAsync(string locatorCode)
    {
        const string sql = """
            SELECT TOP 1
                   l.locator_code AS [LocatorCode],
                   a.area_code    AS [AreaCode],
                   a.area_name    AS [AreaName],
                   a.map_type     AS [MapType],
                   r.rack_code    AS [RackCode],
                   l.rack_col     AS [RackCol],
                   l.rack_row     AS [RackRow],
                   l.rack_level   AS [RackLevel]
            FROM master.locators l
            LEFT JOIN master.warehouse_areas a ON a.id = l.area_id
            LEFT JOIN master.racks r           ON r.id = l.rack_id AND r.is_deleted = 0
            WHERE l.locator_code = @locatorCode AND l.is_deleted = 0;
            """;
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<LocatorLocation>(sql, new { locatorCode });
    }

    public async Task<IReadOnlyList<PalletSerial>> GetSerialsAsync(string palletCode)
    {
        const string sql = """
            SELECT  b.box_no     AS [BoxNo],
                    bl.model     AS [Model],
                    bl.serial_no AS [SerialNo],
                    bl.qty       AS [Qty]
            FROM        wms.pallets   p
            JOIN        wms.boxes     b  ON b.lot_id = p.id AND b.is_deleted = 0
            LEFT JOIN   wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
            WHERE RTRIM(p.pallet_id) = @palletCode AND p.is_deleted = 0
            ORDER BY b.box_no, bl.serial_no;
            """;
        using var conn = _factory.Create();
        return (await conn.QueryAsync<PalletSerial>(sql, new { palletCode })).ToList();
    }
}
