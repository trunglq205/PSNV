﻿
namespace SWMS_WebTool.Models.Filters
{
    public class ZoneFilter : BaseFilter
    {
        public long FloorId {  get; set; }
    }
}
