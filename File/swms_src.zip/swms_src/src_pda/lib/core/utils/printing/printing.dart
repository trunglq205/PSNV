/// API công khai của subsystem in ấn.
///
/// Phần còn lại của app CHỈ được import file này. Nhờ vậy `sato/` và `tspl/`
/// là chi tiết nội bộ: thêm hãng máy in hoặc thêm loại tem
/// không làm vỡ chỗ nào bên ngoài.
///
/// ```dart
/// import 'package:swms_finish_goods/core/printing/printing.dart';
/// ```
library;

export 'labels/label.dart' show Label;
export 'labels/part_card.dart' show PartCardData;
export 'labels/part_card_multi.dart' show PartCardMultiData, PartCardMultiRow;
export 'printer.dart'
    show
    Printer,
    PrinterDevice,
    PrinterErrorType,
    PrinterException,
    PrinterLanguage;
export 'printer_provider.dart'
    show
    pairedPrintersProvider,
    selectedPrinterProvider;