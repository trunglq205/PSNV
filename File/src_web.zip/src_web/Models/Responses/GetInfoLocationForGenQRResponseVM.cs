﻿namespace SWMS_WebTool.Models.Responses
{
    public class GetInfoLocationForGenQRResponseVM
    {
        public string BarCode { get; set; }
        public string LocationName { get; set; }
    }
}
