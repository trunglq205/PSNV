// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shipment_instruction_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ShipmentInstructionPageModel _$ShipmentInstructionPageModelFromJson(
  Map<String, dynamic> json,
) => ShipmentInstructionPageModel(
  items:
      (json['items'] as List<dynamic>?)
          ?.map(
            (e) => ShipmentInstructionListItemModel.fromJson(
              e as Map<String, dynamic>,
            ),
          )
          .toList() ??
      const [],
  totalCount: (json['totalCount'] as num?)?.toInt() ?? 0,
  page: (json['page'] as num?)?.toInt() ?? 1,
  size: (json['size'] as num?)?.toInt() ?? 20,
  totalPages: (json['totalPages'] as num?)?.toInt() ?? 0,
  statusCounts: (json['statusCounts'] as Map<String, dynamic>?)?.map(
    (k, e) => MapEntry(k, (e as num).toInt()),
  ),
);

ShipmentInstructionListItemModel _$ShipmentInstructionListItemModelFromJson(
  Map<String, dynamic> json,
) => ShipmentInstructionListItemModel(
  id: (json['id'] as num).toInt(),
  docNo: json['docNo'] as String,
  siNo: json['siNo'] as String,
  revision: json['revision'] as String?,
  category: json['category'] as String?,
  shipMode: json['shipMode'] as String?,
  docStatus: json['docStatus'] as String?,
  etdDate: json['etdDate'] == null
      ? null
      : DateTime.parse(json['etdDate'] as String),
  etaDate: json['etaDate'] == null
      ? null
      : DateTime.parse(json['etaDate'] as String),
  vanningDate: json['vanningDate'] == null
      ? null
      : DateTime.parse(json['vanningDate'] as String),
  cutOffAt: json['cutOffAt'] == null
      ? null
      : DateTime.parse(json['cutOffAt'] as String),
  consigneeCode: json['consigneeCode'] as String?,
  countryCode: json['countryCode'] as String?,
  forwarderCode: json['forwarderCode'] as String?,
  picName: json['picName'] as String?,
  isSerialRequired: json['isSerialRequired'] as bool? ?? false,
  lineCount: (json['lineCount'] as num?)?.toInt() ?? 0,
  packingListCount: (json['packingListCount'] as num?)?.toInt() ?? 0,
  modelCount: (json['modelCount'] as num?)?.toInt() ?? 0,
  modelsPreview: json['modelsPreview'] as String?,
  poNos: json['poNos'] as String?,
  qtyRequired: (json['qtyRequired'] as num?)?.toInt() ?? 0,
  qtyFulfilled: (json['qtyFulfilled'] as num?)?.toInt() ?? 0,
  qtyCut: (json['qtyCut'] as num?)?.toInt() ?? 0,
  qtyShort: (json['qtyShort'] as num?)?.toInt() ?? 0,
  totalPlt: (json['totalPlt'] as num?)?.toInt() ?? 0,
  totalCtn: (json['totalCtn'] as num?)?.toInt() ?? 0,
  unmatchedBoxCount: (json['unmatchedBoxCount'] as num?)?.toInt() ?? 0,
);

ShipmentInstructionDetailModel _$ShipmentInstructionDetailModelFromJson(
  Map<String, dynamic> json,
) => ShipmentInstructionDetailModel(
  id: (json['id'] as num).toInt(),
  docNo: json['docNo'] as String,
  siNo: json['siNo'] as String,
  revision: json['revision'] as String?,
  category: json['category'] as String?,
  shipMode: json['shipMode'] as String?,
  docStatus: json['docStatus'] as String?,
  etdDate: json['etdDate'] == null
      ? null
      : DateTime.parse(json['etdDate'] as String),
  etaDate: json['etaDate'] == null
      ? null
      : DateTime.parse(json['etaDate'] as String),
  vanningDate: json['vanningDate'] == null
      ? null
      : DateTime.parse(json['vanningDate'] as String),
  cutOffAt: json['cutOffAt'] == null
      ? null
      : DateTime.parse(json['cutOffAt'] as String),
  portOfLoading: json['portOfLoading'] as String?,
  portOfDischarge: json['portOfDischarge'] as String?,
  countryCode: json['countryCode'] as String?,
  forwarderCode: json['forwarderCode'] as String?,
  carrierCode: json['carrierCode'] as String?,
  consigneeCode: json['consigneeCode'] as String?,
  packingType: json['packingType'] as String?,
  isWhiteFilm: json['isWhiteFilm'] as bool? ?? false,
  isCaseMark: json['isCaseMark'] as bool? ?? false,
  isSerialRequired: json['isSerialRequired'] as bool? ?? false,
  picName: json['picName'] as String?,
  toAreaId: (json['toAreaId'] as num?)?.toInt(),
  description: json['description'] as String?,
  headerNote: json['headerNote'] as Map<String, dynamic>?,
  createdAt: json['createdAt'] == null
      ? null
      : DateTime.parse(json['createdAt'] as String),
  createdBy: json['createdBy'] as String?,
  lines:
      (json['lines'] as List<dynamic>?)
          ?.map(
            (e) => ShipmentInstructionLineModel.fromJson(
              e as Map<String, dynamic>,
            ),
          )
          .toList() ??
      const [],
);

ShipmentInstructionLineModel _$ShipmentInstructionLineModelFromJson(
  Map<String, dynamic> json,
) => ShipmentInstructionLineModel(
  id: (json['id'] as num).toInt(),
  lineNo: (json['lineNo'] as num).toInt(),
  model: json['model'] as String,
  customerMaterial: json['customerMaterial'] as String?,
  poNo: json['poNo'] as String?,
  packingListNo: json['packingListNo'] as String?,
  packingItemNo: json['packingItemNo'] as String?,
  invoiceNo: json['invoiceNo'] as String?,
  soNo: json['soNo'] as String?,
  soItemNo: json['soItemNo'] as String?,
  qtyRequired: (json['qtyRequired'] as num?)?.toInt() ?? 0,
  uom: json['uom'] as String?,
  plt: (json['plt'] as num?)?.toInt() ?? 0,
  ctn: (json['ctn'] as num?)?.toInt() ?? 0,
  qtyCut: (json['qtyCut'] as num?)?.toInt(),
  cutBy: json['cutBy'] as String?,
  cutAt: json['cutAt'] == null ? null : DateTime.parse(json['cutAt'] as String),
  qtyPending: (json['qtyPending'] as num?)?.toInt() ?? 0,
  qtyPicked: (json['qtyPicked'] as num?)?.toInt() ?? 0,
  qtyShort: (json['qtyShort'] as num?)?.toInt() ?? 0,
  tasks:
      (json['tasks'] as List<dynamic>?)
          ?.map((e) => PickTaskModel.fromJson(e as Map<String, dynamic>))
          .toList() ??
      const [],
);

PickTaskModel _$PickTaskModelFromJson(Map<String, dynamic> json) =>
    PickTaskModel(
      id: (json['id'] as num).toInt(),
      lineId: (json['lineId'] as num).toInt(),
      seq: (json['seq'] as num?)?.toInt(),
      locatorCode: json['locatorCode'] as String?,
      areaCode: json['areaCode'] as String?,
      palletCode: json['palletCode'] as String?,
      pickMode: json['pickMode'] as String?,
      unitType: json['unitType'] as String?,
      isFifo: json['isFifo'] as bool? ?? false,
      toLocatorCode: json['toLocatorCode'] as String?,
      stagedLocatorCode: json['stagedLocatorCode'] as String?,
      stagedAt: json['stagedAt'] == null
          ? null
          : DateTime.parse(json['stagedAt'] as String),
      boxPlanned: (json['boxPlanned'] as num?)?.toInt() ?? 0,
      boxPicked: (json['boxPicked'] as num?)?.toInt() ?? 0,
      qtyPlanned: (json['qtyPlanned'] as num?)?.toInt() ?? 0,
      shipmentStatus: json['shipmentStatus'] as String?,
      productionDate: json['productionDate'] == null
          ? null
          : DateTime.parse(json['productionDate'] as String),
      pickedAt: json['pickedAt'] == null
          ? null
          : DateTime.parse(json['pickedAt'] as String),
      pickedBy: json['pickedBy'] as String?,
      skipReason: json['skipReason'] as String?,
    );
