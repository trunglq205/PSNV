import 'dart:math';

import 'package:flutter/foundation.dart' hide Category;
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_line.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_origin.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

abstract final class PartCardField {
  static const model = 'Model';
  static const qty = 'Qty';
  static const box = 'Box';
  static const length = 'Length';
  static const width = 'Width';
  static const height = 'Height';
  static const weight = 'Weight';
  static const origin = 'Origin';
  static const cate = 'Cate';
}

/// Dữ liệu 1 phiếu Part Card.
///
/// Phiếu = phần **card-level** (Dim / Weight / Cate / MFD / PO) + N **dòng mã**
/// ([PartCardLine]). Chế độ `single` = đúng 1 dòng, `box` = 1 → payload và nhãn
/// in ra y hệt bản cũ.
///
/// Bước 2 fill từ [ModelInfo] rồi cho user sửa lại nếu lệch thực tế
/// (Model / Category KHÓA ở chế độ single — sửa nghĩa là quét sai model).
@immutable
class PartCardForm {
  const PartCardForm({
    required this.lines,
    required this.productionDate,
    this.mode = PartCardMode.single,
    this.category,
    this.length = 0,
    this.width = 0,
    this.height = 0,
    this.weight = 0,
    this.psnvPo = '',
    this.cusPo = '',
  });

  /// Số mã tối đa in được trên 1 tem.
  ///
  /// Template SBPL nhiều mã có ĐÚNG 3 dòng cố định (`PartCardMultiData.maxRows`)
  /// — số thứ tự 1/2/3 và các đường kẻ vẽ sẵn, không giãn thêm được.
  static const int maxLines = 3;

  /// Danh sách mã trên phiếu. LUÔN có ít nhất 1 phần tử sau bước 1.
  final List<PartCardLine> lines;

  final Category? category;

  final double length; // cm
  final double width; // cm
  final double height; // cm
  final double weight; // kg

  final DateTime productionDate;

  /// PO nội bộ PSNV — chỉ in ở chế độ multi. Rỗng = không in.
  final String psnvPo;

  /// PO khách hàng — chỉ in ở chế độ multi. Rỗng = không in.
  final String cusPo;

  /// 1 mã ↔ nhiều mã — quyết định layout tem + cờ multi khi lưu lịch sử.
  final PartCardMode mode;

  /// Có ít nhất 1 dòng đã OQC check — ô OQC dòng Total in "X" khi KHÔNG có.
  bool get anyOqcChecked => lines.any((l) => l.oqcChecked);

  /// Fill từ thông tin model lấy ở API.
  factory PartCardForm.fromModelInfo(
    ModelInfo info, {
    PartCardMode mode = PartCardMode.single,
  }) {
    final now = DateTime.now();
    return PartCardForm(
      lines: [PartCardLine.fromModelInfo(info)],
      mode: mode,
      category: info.category,
      productionDate: DateTime(now.year, now.month, now.day),
      length: info.length.toDouble(),
      width: info.width.toDouble(),
      height: info.height.toDouble(),
    );
  }

  factory PartCardForm.empty({
    required String model,
    PartCardMode mode = PartCardMode.single,
  }) {
    final now = DateTime.now();
    return PartCardForm(
      lines: [PartCardLine.empty(model)],
      mode: mode,
      productionDate: DateTime(now.year, now.month, now.day),
    );
  }

  // ── Dẫn xuất — dòng đầu (giữ API cũ cho chế độ single) ─────
  PartCardLine? get firstLine => lines.isEmpty ? null : lines.first;

  String get model => firstLine?.model ?? '';

  /// pcs / thùng của dòng đầu (= standard packing khi tạo model mới).
  int get quantity => firstLine?.quantity ?? 0;

  PartCardOrigin? get origin => firstLine?.origin;

  // ── Dẫn xuất — card-level ──────────────────────────────────
  String get dimension =>
      '${formatDecimal(length)}x${formatDecimal(width)}x${formatDecimal(height)}';

  String get weightText => formatDecimal(weight);

  /// Mã category in trên nhãn (vd `MW`).
  String? get categoryText => category?.key;

  String get productionDateText => formatDisplayDate(productionDate);

  bool get hasDimension => length > 0 && width > 0 && height > 0;

  /// Tổng số thùng của cả phiếu.
  int get totalBox => lines.fold(0, (sum, l) => sum + l.box);

  /// Tổng pcs của cả phiếu = Σ(box × qty).
  int get totalPcs => lines.fold(0, (sum, l) => sum + l.quantity);

  bool get canAddLine => lines.length < maxLines;

  /// Còn mã nào chưa có trên hệ thống (phải createModel trước khi in).
  bool get hasNewModel => lines.any((l) => l.isNewModel);

  int indexOfModel(String code) {
    final key = code.trim().toUpperCase();
    return lines.indexWhere((l) => l.model.trim().toUpperCase() == key);
  }

  bool hasModel(String code) => indexOfModel(code) >= 0;

  // ── Thao tác dòng ──────────────────────────────────────────
  PartCardForm addLine(PartCardLine line) => copyWith(lines: [...lines, line]);

  PartCardForm updateLineAt(int index, PartCardLine line) {
    if (index < 0 || index >= lines.length) return this;
    final next = [...lines]..[index] = line;
    return copyWith(lines: next);
  }

  PartCardForm removeLineAt(int index) {
    if (index < 0 || index >= lines.length || lines.length <= 1) return this;
    final next = [...lines]..removeAt(index);
    return copyWith(lines: next);
  }

  /// Quét trùng mã → cộng thêm 1 thùng cho dòng cũ (không thêm dòng mới).
  PartCardForm bumpBox(String code) {
    final i = indexOfModel(code);
    if (i < 0) return this;
    return updateLineAt(i, lines[i].copyWith(box: lines[i].box + 1));
  }

  /// Form chỉ chứa 1 dòng — dùng cho `createModel` từng mã một.
  PartCardForm singleLine(PartCardLine line) => copyWith(lines: [line]);

  // ── Kiểm tra ───────────────────────────────────────────────
  /// Đủ dữ liệu để in chưa.
  bool get isComplete =>
      lines.isNotEmpty &&
      lines.every((l) => l.isComplete) &&
      hasDimension &&
      weight > 0 &&
      category != null;

  /// Field còn thiếu — để báo cho user ở bước 2.
  List<String> get missingFields => [
    if (lines.isEmpty || lines.any((l) => l.model.trim().isEmpty))
      PartCardField.model,
    if (lines.any((l) => l.box <= 0)) PartCardField.box,
    if (lines.isEmpty || lines.any((l) => l.quantity <= 0)) PartCardField.qty,
    if (length <= 0) PartCardField.length,
    if (width <= 0) PartCardField.width,
    if (height <= 0) PartCardField.height,
    if (weight <= 0) PartCardField.weight,
    if (mode == .multi && lines.any((l) => l.origin == null))
      PartCardField.origin,
    if (category == null) PartCardField.cate,
  ];

  // ── QR chính: payload có Card_ID, key=value ──
  //
  // MODELS = `model,qty,origin,box` — nhiều mã ngăn nhau bằng `;`.
  // Single 1 dòng box=1 ⇒ chuỗi y hệt bản cũ.
  String buildMainPayload(String cardId) {
    final models = lines
        .map((l) => '${l.model.trim()},${l.quantity},${l.origin?.code ?? ''},${l.box}')
        .join(';');

    final parts = <String>[
      'ID=$cardId',
      'CATE=${category?.value}',
      'MFD=${formatIsoDate(productionDate)}',
      if (hasDimension) 'DIM=$dimension',
      if (weight > 0) 'WT=$weightText',
      if (psnvPo.trim().isNotEmpty) 'PSNV_PO=${psnvPo.trim()}',
      if (cusPo.trim().isNotEmpty) 'CUS_PO=${cusPo.trim()}',
      'MODELS=$models',
    ];
    return parts.join('|');
  }

  // ── QR legacy ──
  // • Service part oversea (multi): 1 chuỗi mô tả, ngày d/m/yyyy (không đệm 0)
  //   PSNV PO No.{po}, Customer PO No.{cusPo}, Packing Date: {d/m/yyyy},
  //   PSNV Model: {model}:{box},{qty},{origin}; {model}:{box},{qty},{origin}
  // • Hàng thường (single):
  //   {model};{qty};{weight};{vol};{dd-mm-yyyy};{model}{rand};{category}
  String buildLegacyPayload(String legacyRand) {
    if (mode == .multi) {
      final dateSlash =
          '${productionDate.day}/${productionDate.month}/${productionDate.year}';

      final models = lines
          .where((l) => l.model.trim().isNotEmpty)
          .map(
            (l) =>
                '${l.model.trim()}:${l.box},${l.quantity},${l.origin?.code ?? ''}',
          )
          .join('; ');

      return 'PSNV PO No.${psnvPo.trim()}, Customer PO No.${cusPo.trim()}, '
          'Packing Date: $dateSlash, PSNV Model: $models';
    }

    final day = productionDate.day.toString().padLeft(2, '0');
    final month = productionDate.month.toString().padLeft(2, '0');
    final dateDash = '$day-$month-${productionDate.year}';

    final volumeM3 = hasDimension
        ? ((length * width * height) / 1000000).toStringAsFixed(4)
        : '';

    final modelTrim = model.trim();
    return '$modelTrim;$quantity;$weightText;$volumeM3;$dateDash;'
        '$modelTrim$legacyRand;${categoryText ?? ''}';
  }

  /// [model] / [quantity] / [origin] tác động lên DÒNG ĐẦU — giữ nguyên cách
  /// gọi cũ của màn single.
  PartCardForm copyWith({
    List<PartCardLine>? lines,
    PartCardMode? mode,
    Category? category,
    String? model,
    int? quantity,
    double? length,
    double? width,
    double? height,
    double? weight,
    PartCardOrigin? origin,
    DateTime? productionDate,
    String? psnvPo,
    String? cusPo,
  }) {
    var next = lines ?? this.lines;

    if ((model != null || quantity != null || origin != null) &&
        next.isNotEmpty) {
      next = [
        next.first.copyWith(model: model, quantity: quantity, origin: origin),
        ...next.skip(1),
      ];
    }

    return PartCardForm(
      lines: next,
      mode: mode ?? this.mode,
      category: category ?? this.category,
      length: length ?? this.length,
      width: width ?? this.width,
      height: height ?? this.height,
      weight: weight ?? this.weight,
      productionDate: productionDate ?? this.productionDate,
      psnvPo: psnvPo ?? this.psnvPo,
      cusPo: cusPo ?? this.cusPo,
    );
  }
}

/// Sinh Card_ID 10 số (giống bản đang chạy).
class PartCardId {
  PartCardId._();

  static final Random _rand = Random();

  static String generate() =>
      List.generate(10, (_) => _rand.nextInt(10)).join();
}
