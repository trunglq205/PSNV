﻿using Microsoft.Data.SqlClient;   // hoặc System.Data.SqlClient tùy project
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using System.Text.Json;

namespace Swms.FinishGoods.API.Common.Api;

public class ExceptionHandlingMiddleware
{
    private readonly RequestDelegate _next;
    private readonly ILogger<ExceptionHandlingMiddleware> _logger;

    public ExceptionHandlingMiddleware(RequestDelegate next, ILogger<ExceptionHandlingMiddleware> logger)
    {
        _next = next;
        _logger = logger;
    }

    public async Task InvokeAsync(HttpContext context)
    {
        try
        {
            await _next(context);
        }
        catch (Exception ex)
        {
            var (status, title) = ex switch
            {
                NotFoundException => (StatusCodes.Status404NotFound, ex.Message),
                BusinessRuleException => (StatusCodes.Status400BadRequest, ex.Message),
                ConflictException => (StatusCodes.Status409Conflict, ex.Message),
                BulkUserConflictException => (StatusCodes.Status409Conflict, ex.Message),
                ForbiddenException => (StatusCodes.Status403Forbidden, ex.Message),
                UnauthorizedException => (StatusCodes.Status401Unauthorized, ex.Message),

                // Lỗi DB: dịch một số mã phổ biến sang thông báo có nghĩa
                SqlException sqlEx => MapSqlException(sqlEx),

                _ => (StatusCodes.Status500InternalServerError, ex.Message ?? "An unexpected error occurred.")
            };

            // Log đầy đủ cho lỗi 500 và mọi lỗi SQL (kể cả khi đã dịch sang 4xx)
            if (status == StatusCodes.Status500InternalServerError)
                _logger.LogError(ex, "Unhandled exception. TraceId={TraceId}", context.TraceIdentifier);
            else if (ex is SqlException sqlEx)
                _logger.LogWarning(sqlEx,
                    "SQL exception. Number={Number}, Line={Line}, TraceId={TraceId}",
                    sqlEx.Number, sqlEx.LineNumber, context.TraceIdentifier);

            // Lấy chi tiết bổ sung nếu có
            object? details = ex switch
            {
                BulkUserConflictException bce => bce.Conflicts,
                _ => null
            };

            context.Response.StatusCode = status;
            context.Response.ContentType = "application/json";
            var payload = JsonSerializer.Serialize(new
            {
                status,
                title,
                details,
                traceId = context.TraceIdentifier
            });
            await context.Response.WriteAsync(payload);
        }
    }

    private static (int status, string title) MapSqlException(SqlException ex) => ex.Number switch
    {
        // ===== Lỗi do dữ liệu người dùng → map sang 4xx, thông báo có nghĩa =====

        // Vi phạm ràng buộc UNIQUE / khóa chính / chỉ mục unique → dữ liệu trùng
        2627 or 2601 => (StatusCodes.Status409Conflict, "Dữ liệu đã tồn tại."),

        // Vi phạm FOREIGN KEY hoặc CHECK constraint
        547 => (StatusCodes.Status400BadRequest, "Dữ liệu tham chiếu không hợp lệ hoặc vi phạm ràng buộc."),

        // Chuỗi/dữ liệu vượt quá độ dài cột (truncate)
        2628 or 8152 => (StatusCodes.Status400BadRequest, "Dữ liệu vượt quá độ dài cho phép."),

        // Chèn NULL vào cột NOT NULL
        515 => (StatusCodes.Status400BadRequest, "Thiếu dữ liệu bắt buộc."),

        // Lỗi chuyển đổi kiểu dữ liệu (vd: chuỗi → số), lỗi 8114 bạn từng gặp
        8114 or 245 or 8115 => (StatusCodes.Status400BadRequest, "Dữ liệu không đúng định dạng."),

        // Chia cho 0
        8134 => (StatusCodes.Status400BadRequest, "Lỗi tính toán: chia cho 0."),

        // ===== Lỗi do lập trình viên → để 500, KHÔNG lộ chi tiết, chỉ log kỹ =====

        // Lỗi cú pháp SQL / tên không hợp lệ
        102 or 105 or 156 or 170 => (StatusCodes.Status500InternalServerError, "Lỗi truy vấn dữ liệu."),

        // Tên cột không hợp lệ
        207 => (StatusCodes.Status500InternalServerError, "Lỗi truy vấn dữ liệu."),

        // Tên đối tượng (bảng/view) không hợp lệ
        208 => (StatusCodes.Status500InternalServerError, "Lỗi truy vấn dữ liệu."),

        // Số lượng tham số / cột không khớp
        8144 or 8145 or 213 => (StatusCodes.Status500InternalServerError, "Lỗi truy vấn dữ liệu."),

        // Phải khai báo biến vô hướng (thường do thiếu tham số)
        137 => (StatusCodes.Status500InternalServerError, "Lỗi truy vấn dữ liệu."),

        // Tên tham số đã được khai báo
        134 => (StatusCodes.Status500InternalServerError, "Lỗi truy vấn dữ liệu."),

        // ===== Lỗi hạ tầng / kết nối → 503, có thể thử lại =====

        // Timeout
        -2 => (StatusCodes.Status504GatewayTimeout, "Yêu cầu xử lý quá lâu, vui lòng thử lại."),

        // Không kết nối được tới server / network
        53 or 17 or 4060 or 18456 => (StatusCodes.Status503ServiceUnavailable, "Không thể kết nối cơ sở dữ liệu."),

        // Deadlock — giao dịch bị chọn làm nạn nhân, nên thử lại
        1205 => (StatusCodes.Status409Conflict, "Hệ thống đang bận, vui lòng thử lại."),

        // Hết thời gian chờ khóa (lock timeout)
        1222 => (StatusCodes.Status409Conflict, "Dữ liệu đang được xử lý bởi yêu cầu khác, vui lòng thử lại."),

        // ===== Mặc định =====
        _ => (StatusCodes.Status500InternalServerError, "Lỗi cơ sở dữ liệu.")
    };
}

public static class ExceptionHandlingMiddlewareExtensions
{
    public static IApplicationBuilder UseExceptionHandling(this IApplicationBuilder app)
        => app.UseMiddleware<ExceptionHandlingMiddleware>();
}