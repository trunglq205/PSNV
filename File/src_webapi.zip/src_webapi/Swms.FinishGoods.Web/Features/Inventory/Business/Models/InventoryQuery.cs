using Swms.FinishGoods.Web.Shared.Business.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.Business.Models;

/// <summary>
/// Tham số truy vấn tồn kho: filter + phân trang. Khớp <c>InventoryQuery</c> của API.
///
/// TRƯỚC ĐÂY kế thừa PalletQuery. Giờ kế thừa thẳng PagedQuery và khai lại các
/// trường dùng chung — Inventory không còn phụ thuộc feature Pallet.
///
/// Các trường KHÔNG mang sang vì màn Tồn kho không dùng: StockyCode, LocatorId,
/// IsEvenPallet, SapPushed/SapPushedFrom/SapPushedTo. Cần lại thì thêm vào đây
/// và bổ sung ở API.
/// </summary>
public class InventoryQuery : PagedQuery
{
    // ── Dùng chung với truy vấn pallet ──

    /// <summary>Tìm theo lot no.</summary>
    public string? LotNo { get; set; }

    /// <summary>Nhiều category, phân tách dấu phẩy (vd "310,410"). Null = tất cả.</summary>
    public string? Categories { get; set; }

    /// <summary>pallet | stocky — ĐÚNG giá trị trong DB, xem PalletType.ToDbValue().</summary>
    public string? LotType { get; set; }

    /// <summary>serial | box_line | box_count.</summary>
    public string? DetailLevel { get; set; }

    /// <summary>Nhiều trạng thái OQC, phân tách dấu phẩy: not_inspected | under_inspection |
    /// pending_result | pass | ng | inspection_exempt.</summary>
    public string? Inspections { get; set; }

    /// <summary>Tìm theo model (lot hoặc box_lines).</summary>
    public string? Model { get; set; }

    public bool? IsUrgent { get; set; }

    /// <summary>Nhiều trạng thái SAP (0..4), phân tách dấu phẩy. Có 0 thì API tính cả sap_status NULL.</summary>
    public string? SapStatuses { get; set; }

    public DateTime? ProductionFrom { get; set; }
    public DateTime? ProductionTo { get; set; }
    public DateTime? CreatedFrom { get; set; }
    public DateTime? CreatedTo { get; set; }

    // ── Đặc thù tồn kho ──

    /// <summary>receiving | storing | vanning | jupiter | borrowed. Null = tất cả.</summary>
    public string? Area { get; set; }

    /// <summary>Tìm theo Box No hoặc Serial No.</summary>
    public string? BoxOrSerial { get; set; }

    public int? QtyMin { get; set; }
    public int? QtyMax { get; set; }

    /// <summary>created_desc (mặc định) | pd_asc | pd_desc | qty_desc.</summary>
    public string? Sort { get; set; }
}
