﻿using System.Security.Principal;

namespace SWMS_WebTool.Utils
{
    public static class UserHelpers
    {
        public static bool IsEditor(this IPrincipal user)
        {

            var userSection = user.GetType;
            if (string.IsNullOrEmpty(user?.Identity?.Name))
            {
                return false;

            }
            else
            {
                return true;

            }
        }
    }
}
