using System.Globalization;
using System.Text.Json;
using Microsoft.Extensions.Localization;
using Refit;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Features.Inventory.Client;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business;

/// <summary>
/// So tồn SWMS ↔ HD soft và xử lý chênh lệch (trước đây nằm trong InventoryBusiness).
/// Tồn SWMS đọc qua IInventoryApi; HD soft + thao tác pallet qua IHdSoftCompareApi.
/// </summary>
public class HdSoftCompareBusiness : BaseBusiness, IHdSoftCompareBusiness
{
    private readonly IInventoryApi _api;
    private readonly IHdSoftCompareApi _hdApi;
    private readonly IStringLocalizer<SharedResource> _l;

    public HdSoftCompareBusiness(
        IInventoryApi api,
        IHdSoftCompareApi hdApi,
        IStringLocalizer<SharedResource> localizer,
        ILogger<HdSoftCompareBusiness> logger,
        ErrorHandler errorHandler)
        : base(logger, errorHandler)
    {
        _api = api;
        _hdApi = hdApi;
        _l = localizer;
    }

    /// <summary>Trần số pallet SWMS tải cho 1 lần so (mỗi trang 1 request).</summary>
    private const int CompareMaxLots = 20_000;
    private const int ComparePageSize = 200;
    /// <summary>Số pallet nhiều model tải chi tiết song song mỗi lượt.</summary>
    private const int CompareParallel = 6;

    public Task<Result<AppStockCompareResult>> CompareWithHdSoftAsync(
        string? warehouse, IProgress<StockCompareProgress>? progress = null, CancellationToken ct = default)
        => ExecuteAsync(async () =>
        {
            // HD soft 1 lần gọi — chạy song song trong lúc lật trang SWMS
            var hdTask = _hdApi.GetHdSoftPalletsInStockAsync(warehouse);

            // ── 1. Toàn bộ tồn SWMS. Không áp bộ lọc màn hình: HD soft không lọc được như vậy ──
            var pallets = new List<AppInventoryItem>();
            var page = 1;
            var total = 0;
            while (true)
            {
                ct.ThrowIfCancellationRequested();
                var r = await _api.GetAllAsync(new InventoryQuery { Page = page, Size = ComparePageSize });
                var items = r.Items.ToList();
                total = r.TotalCount;
                pallets.AddRange(items.Select(InventoryItemDto.ToViewModel));
                progress?.Report(new("list", pallets.Count, total));

                // API có thể giới hạn Size nhỏ hơn -> dừng theo TotalCount
                if (items.Count == 0 || pallets.Count >= total || pallets.Count >= CompareMaxLots) break;
                page++;
            }
            if (pallets.Count > CompareMaxLots) pallets.RemoveRange(CompareMaxLots, pallets.Count - CompareMaxLots);
            var truncated = total > pallets.Count;

            // ── 2. Số lượng theo model. Pallet 1 model: lấy luôn TotalQty.
            //       Pallet nhiều model / API list không trả model: tải chi tiết, cộng theo box line. ──
            var units = new List<SwmsStockUnit>(pallets.Count);
            var need = new List<AppInventoryItem>();
            foreach (var p in pallets)
            {
                if (p.Models.Count == 1) units.Add(new SwmsStockUnit(p, p.Models[0], p.TotalQty));
                else need.Add(p);
            }

            var failed = new List<string>();
            for (var i = 0; i < need.Count; i += CompareParallel)
            {
                ct.ThrowIfCancellationRequested();
                var batch = need.Skip(i).Take(CompareParallel).ToList();
                var details = await Task.WhenAll(batch.Select(async p =>
                {
                    try { return await _api.GetByIdAsync(p.Id); }
                    catch (Exception) when (!ct.IsCancellationRequested) { return null; }
                }));

                for (var k = 0; k < batch.Count; k++)
                {
                    var p = batch[k];
                    var lines = details[k]?.Boxes.SelectMany(b => b.Lines)
                                       .Where(l => !string.IsNullOrWhiteSpace(l.Model))
                                       .ToList();
                    if (lines is { Count: > 0 })
                    {
                        units.AddRange(lines
                            .GroupBy(l => l.Model.Trim(), StringComparer.OrdinalIgnoreCase)
                            .Select(g => new SwmsStockUnit(p, g.Key, g.Sum(l => l.Qty))));
                    }
                    else
                    {
                        // Lỗi tải / lot box_count không có line: tính cả pallet theo model của lot
                        if (details[k] is null) failed.Add(p.StockyCode ?? p.LotNo);
                        units.Add(new SwmsStockUnit(p, p.Model ?? "", p.TotalQty));
                    }
                }
                progress?.Report(new("detail", Math.Min(i + CompareParallel, need.Count), need.Count));
            }

            var hd = await hdTask;
            return InventoryStockComparer.Compare(pallets, units, hd, warehouse, truncated, failed);
        });

    // ══════════════════════════════════════════════════════════════
    //  Xử lý chênh lệch HD soft — từng dòng
    // ══════════════════════════════════════════════════════════════

    public Task<Result<string?>> ApplyHdRowActionAsync(HdRowAction a, int? packing)
        => ExecuteAsync(() => a.Kind switch
        {
            HdActKind.Create => CreateFromHdAsync(a, RequirePacking(a, packing)),
            HdActKind.Delete => DeleteExtraAsync(a),
            HdActKind.Qty => UpdateQtyAsync(a, RequirePacking(a, packing)),
            HdActKind.Sync => SyncLocatorAsync(a),
            HdActKind.TopUp => TopUpFromFossAsync(a),
            // "boxes" cần chọn thùng trong dialog -> đi qua DeleteBoxesAsync, không qua đây.
            _ => throw new InvalidOperationException($"Hành động không hỗ trợ: {a.Kind}"),
        });

    public Task<Result<AppInventoryItem>> GetPalletDetailAsync(long id)
        => ExecuteAsync(async () => InventoryItemDto.ToViewModel(await _api.GetByIdAsync(id)));

    public Task<Result<DeleteBoxesResultDto>> DeleteBoxesAsync(long lotId, IReadOnlyList<long> boxIds)
        => ExecuteAsync(() => _hdApi.DeleteBoxesAsync(lotId, new DeleteBoxesRequestDto
        {
            BoxIds = boxIds.Distinct().ToList(),
            Reason = "hdsoft_compare",
        }));

    /// <summary>Pallet box_count lưu SL = box_count × standard_packing -> SL phải chia hết quy cách.</summary>
    private int RequirePacking(HdRowAction a, int? packing)
    {
        if (packing is not > 0) throw new InvalidOperationException(_l["Inventory.Act.PackingRequired"]);
        if (a.Qty % packing.Value != 0)
            throw new InvalidOperationException(_l["Inventory.Act.PackingNotDivisible", a.Qty, packing.Value]);
        return packing.Value;
    }

    /// <summary>
    /// Thiếu ở SWMS: POST /api/pallets (box_count, mã = mã pallet HD soft) rồi PUT .../locator.
    /// Ngày SX lấy từ mã &lt;cat:3&gt;&lt;yymmdd:6&gt;&lt;seq:3&gt; để aging / FIFO không reset về hôm nay.
    /// </summary>
    private async Task<string?> CreateFromHdAsync(HdRowAction a, int packing)
    {
        var created = await _hdApi.CreatePalletAsync(new CreatePalletRequestDto
        {
            LotNo = a.Pallet,
            CategoryCode = int.Parse(a.Pallet[..3], CultureInfo.InvariantCulture),
            Model = a.Model,
            BoxCount = a.Qty / packing,
            StandardPacking = packing,
            ProductionDate = ParseExact(a.Pallet.Substring(3, 6), "yyMMdd"),
        });

        return await TryAssignLocatorAsync(created.Id, a.Locator);
    }

    /// <summary>Thừa ở SWMS: DELETE /api/pallets/{id} (xoá mềm, có event PALLET_DELETED).</summary>
    private async Task<string?> DeleteExtraAsync(HdRowAction a)
    {
        await _hdApi.DeletePalletAsync(a.Lot!.Id);
        return null;
    }

    /// <summary>
    /// Lệch SL pallet box_count: PUT /api/pallets/{id}/box-count. Giữ ID + lịch sử.
    /// ExpectedQty = SL lúc so -> người khác vừa sửa thì API trả 409, không đè.
    /// </summary>
    private async Task<string?> UpdateQtyAsync(HdRowAction a, int packing)
    {
        await _hdApi.UpdateBoxCountAsync(a.Lot!.Id, new UpdateBoxCountRequestDto
        {
            BoxCount = a.Qty / packing,
            StandardPacking = packing,
            ExpectedQty = a.OldQty,
            Reason = "hdsoft_compare",
        });
        return null;
    }

    /// <summary>Mã pallet có ở cả 2 bên nhưng khác vị trí: POST .../hdsoft-sync (theo vị trí đang tồn bên HD soft).</summary>
    private async Task<string?> SyncLocatorAsync(HdRowAction a)
    {
        var r = await _hdApi.SyncHdSoftLocatorAsync(a.Pallet);
        if (r.Warnings.Count > 0) return string.Join("; ", r.Warnings);
        return r.Actions.Count == 0 ? _l["Inventory.Act.SyncNoChange"].Value : null;
    }

    /// <summary>
    /// Lệch SL âm trên pallet serial / box_line: POST .../foss-top-up.
    /// Thêm đủ, không bỏ qua thùng nào -> sạch; còn lại trả câu tóm tắt của server làm cảnh báo
    /// (không có gì để thêm, hoặc thùng đã nằm trên pallet khác).
    /// </summary>
    private async Task<string?> TopUpFromFossAsync(HdRowAction a)
    {
        var r = await _hdApi.TopUpFromFossAsync(a.Lot?.LotNo.Trim() ?? a.Pallet);
        var added = r.BoxesAdded + r.LinesAdded > 0;
        return added && r.SkippedBoxes == 0 ? null : r.Message;
    }

    /// <summary>
    /// Gán vị trí sau khi tạo. Lỗi (vị trí không có trong master...) không rollback pallet đã tạo —
    /// trả cảnh báo để người dùng gán tay.
    /// </summary>
    private async Task<string?> TryAssignLocatorAsync(long lotId, string? locator)
    {
        if (string.IsNullOrWhiteSpace(locator)) return null;
        try
        {
            var r = await _hdApi.AssignLocatorAsync(lotId, new AssignLocatorRequestDto { LocatorCode = locator });
            return r.Warning;
        }
        catch (ApiException ex)
        {
            return _l["Inventory.Act.LocatorFailed", locator, ApiMessage(ex)];
        }
    }

    /// <summary>Lấy "message" trong body lỗi (ErrorResponse / ProblemDetails), không có thì dùng message HTTP.</summary>
    private static string ApiMessage(ApiException ex)
    {
        try
        {
            if (!string.IsNullOrWhiteSpace(ex.Content))
            {
                using var doc = JsonDocument.Parse(ex.Content);
                foreach (var name in new[] { "message", "detail", "title" })
                    if (doc.RootElement.TryGetProperty(name, out var v) && v.ValueKind == JsonValueKind.String)
                        return v.GetString()!;
            }
        }
        catch (JsonException) { }
        return ex.Message;
    }

    private static DateTime? ParseExact(string? s, string format)
        => DateTime.TryParseExact(s, format, CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d : null;
}
