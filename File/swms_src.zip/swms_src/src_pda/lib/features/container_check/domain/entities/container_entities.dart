import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';

/// Trạng thái kiểm container. Mã khớp giá trị `status` server trả về.
enum ContainerStatus {
  verify('verify', LocaleKeys.container_check_status_verify),
  loading('loading', LocaleKeys.container_check_status_loading),
  done('done', LocaleKeys.container_check_status_done);

  const ContainerStatus(this.code, this.labelKey);

  final String code;

  /// LocaleKeys — UI gọi `.tr()` khi render.
  final String labelKey;

  /// Mã lạ coi như "chờ kiểm": an toàn hơn vì vẫn buộc người dùng kiểm lại.
  static ContainerStatus fromCode(String? code) => values.firstWhere(
        (s) => s.code == code?.toLowerCase(),
        orElse: () => ContainerStatus.verify,
      );
}

/// Màu lot để công nhân nhận diện container ngoài bãi — dán tem màu lên cửa.
/// Màu cố định theo mã lot phía app, không lấy từ API.
enum LotColor {
  a('A', LocaleKeys.container_check_lot_red, Color(0xFFE53935)),
  b('B', LocaleKeys.container_check_lot_blue, Color(0xFF1E88E5)),
  c('C', LocaleKeys.container_check_lot_green, Color(0xFF43A047)),
  d('D', LocaleKeys.container_check_lot_orange, Color(0xFFFB8C00));

  const LotColor(this.code, this.labelKey, this.swatch);

  final String code;
  final String labelKey;
  final Color swatch;

  /// null = lot chưa có màu quy định → UI ẩn chip.
  static LotColor? fromCode(String? code) {
    final v = code?.trim().toUpperCase();
    for (final l in values) {
      if (l.code == v) return l;
    }
    return null;
  }
}

class ContainerItem {
  final int id;

  /// Số container, vd "CMAU-7382041-3".
  final String containerNo;
  final String sealNo;
  final String siCode;

  /// Loại container hiển thị nguyên văn, vd "40' HC", "20' GP".
  final String type;
  final LotColor? lot;
  final ContainerStatus status;

  const ContainerItem({
    required this.id,
    required this.containerNo,
    required this.sealNo,
    required this.siCode,
    required this.type,
    required this.lot,
    required this.status,
  });

  /// So khớp khi quét: QR có thể in kèm/không kèm dấu gạch.
  bool matches(String code) => _norm(containerNo) == _norm(code);

  static String _norm(String v) =>
      v.toUpperCase().replaceAll(RegExp(r'[^A-Z0-9]'), '');
}
