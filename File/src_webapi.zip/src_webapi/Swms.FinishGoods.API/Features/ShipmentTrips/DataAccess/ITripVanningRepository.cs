using Swms.FinishGoods.API.Features.ShipmentTrips.Business;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

/// <summary>Vanning trên PDA: kiểm container, pallet / thùng thuộc chuyến, pallet đôi.
/// Phần chuyển thùng (gộp Pallet List) KHÔNG nằm ở đây — đi qua IPalletService.SplitAsync.</summary>
public interface ITripVanningRepository
{
    // ── Kiểm container ──
    /// <summary>Lần kiểm mới nhất của chuyến; null = chưa kiểm.</summary>
    Task<TripInspectionRow?> GetLatestInspectionAsync(long tripId);
    Task<long> AddInspectionAsync(TripInspectionRow row);

    // ── Pallet / thùng thuộc chuyến ──
    /// <summary>Mọi pallet thuộc SI đang gắn chuyến (bỏ pallet đã skipped / đã xoá).</summary>
    Task<List<TripPalletInfo>> GetTripPalletsAsync(long tripId);
    /// <summary>Tra 1 pallet theo mã quét (pallet_id). InScope cho biết có thuộc chuyến không.</summary>
    Task<TripPalletInfo?> FindPalletAsync(long tripId, string code);
    /// <summary>Tra thùng theo số thùng — có thể ra nhiều dòng (box_no chỉ unique trong 1 pallet).</summary>
    Task<List<TripBoxInfo>> FindBoxesAsync(long tripId, string boxNo);
    Task<List<long>> GetBoxIdsAsync(long palletId);
    /// <summary>Ghi pallet gốc vào Pallet List của chuyến (pallet rỗng mới lấy ra không thuộc SI nào).</summary>
    Task AddTripPalletAsync(long tripId, long palletId, string? user);
    /// <summary>Chuyến còn mở (planned / arrived / sealed) đang gắn 1 trong các SI — tra chuyến từ pallet.</summary>
    Task<List<long>> GetOpenTripIdsBySisAsync(IReadOnlyCollection<long> siIds);

    // ── Cọc đã ghép (theo Stowage Plan) — ghi ở ITripStowageRepository ──
    Task<List<TripStackRow>> GetStacksAsync(long tripId);
}