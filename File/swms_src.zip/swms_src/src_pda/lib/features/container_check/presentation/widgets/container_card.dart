import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_skeleton.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_entities.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/container_status_pill.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/lot_chip.dart';

class ContainerCard extends StatelessWidget {
  final ContainerItem item;
  final VoidCallback? onTap;

  const ContainerCard({super.key, required this.item, this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return AppCard(
      padding: const EdgeInsets.all(AppDimens.sm + 4),
      onTap: onTap,
      child: Row(
        children: [
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  item.containerNo,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: c.text1,
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  LocaleKeys.container_check_card_meta.tr(namedArgs: {
                    'type': item.type,
                    'seal': item.sealNo,
                  }),
                  style: AppTextStyles.caption.copyWith(color: c.text3),
                ),
                const SizedBox(height: 6),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  crossAxisAlignment: WrapCrossAlignment.center,
                  children: [
                    if (item.lot != null) LotChip(lot: item.lot!),
                    ContainerStatusPill(status: item.status),
                  ],
                ),
              ],
            ),
          ),
          Icon(Icons.chevron_right_rounded, size: 20, color: c.text4),
        ],
      ),
    );
  }
}

/// Giữ chỗ lúc tải danh sách — cùng chiều cao [ContainerCard] để không nhảy.
class ContainerListSkeleton extends StatelessWidget {
  const ContainerListSkeleton({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        for (var i = 0; i < 4; i++) ...[
          const SkeletonCard(
            padding: EdgeInsets.all(AppDimens.sm + 4),
            child: Row(
              children: [
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Bone(width: 150, height: 14), // số container
                      SizedBox(height: 6),
                      Bone(width: 190, height: 10), // loại · seal
                      SizedBox(height: 8),
                      Row(
                        children: [
                          Bone(width: 56, height: 18), // chip lot
                          SizedBox(width: 6),
                          Bone(width: 72, height: 18), // pill trạng thái
                        ],
                      ),
                    ],
                  ),
                ),
                Bone(width: 12, height: 20), // chevron
              ],
            ),
          ),
          const SizedBox(height: 6),
        ],
      ],
    );
  }
}