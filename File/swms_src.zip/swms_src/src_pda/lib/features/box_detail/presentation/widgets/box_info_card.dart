import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/inspection_status.dart';

/// Thẻ thông tin chính của box: mã box, trạng thái OQC, vị trí (theo lot),
/// model/qty, và khối PO cho phép chỉnh sửa qua [onEditPo].
class BoxInfoCard extends StatelessWidget {
  final BoxDetail box;
  final VoidCallback? onEditPo;

  const BoxInfoCard({super.key, required this.box, this.onEditPo});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    const dash = '—';

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 40,
                height: 40,
                decoration: BoxDecoration(
                  color: swms.primaryTint,
                  borderRadius: BorderRadius.circular(AppDimens.rBtn),
                ),
                child: Icon(
                  Icons.inbox_outlined,
                  color: swms.primary,
                  size: 22,
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      LocaleKeys.box_detail_box_id.tr(),
                      style: AppTextStyles.caption.copyWith(color: swms.text3),
                    ),
                    Text(
                      box.boxNo,
                      style: AppTextStyles.title.copyWith(
                        color: swms.text1,
                      ),
                    ),
                  ],
                ),
              ),
              StatusPill(
                label: 'OQC ${box.oqcStatusOrDefault}',
                background: box.oqcStatusOrDefault.color.bg,
                foreground: box.oqcStatusOrDefault.color.fg,
              ),
            ],
          ),

          const SizedBox(height: AppDimens.sm),

          // Vị trí ăn theo lot chứa box.
          if (box.hasLocator)
            StatusPill.info(
              context,
              label: '${box.areaCode ?? ''} - ${box.locatorCode ?? ''}',
              icon: Icons.location_on_outlined,
            )
          else
            StatusPill.warning(
              context,
              label: LocaleKeys.box_detail_no_storage.tr(),
              icon: Icons.location_on_outlined,
            ),

          const Divider(height: AppDimens.lg),

          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _InfoField(
                  label: LocaleKeys.box_detail_lot.tr(),
                  child: Text(
                    box.lotNo,
                    style: AppTextStyles.bodyStrong.copyWith(
                      color: swms.text1,
                    ),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _InfoField(
                  label: LocaleKeys.box_detail_packing_date.tr(),
                  child: Text(
                    box.productionDate == null
                        ? dash
                        : DateFormat('dd/MM/yyyy').format(box.productionDate!),
                    style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                  ),
                ),
              ),
            ],
          ),

          const SizedBox(height: AppDimens.sm),

          Text(
            LocaleKeys.box_detail_model.tr(),
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
          const SizedBox(height: AppDimens.xs),
          Text(
            box.primaryModel ?? dash,
            style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
          ),

          const SizedBox(height: AppDimens.sm),

          Row(
            children: [
              Expanded(
                child: _MiniStat(
                  label: LocaleKeys.box_detail_total_qty.tr(),
                  value: '${box.totalQty}',
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _MiniStat(
                  label: LocaleKeys.box_detail_serial_count.tr(),
                  value: '${box.serialCount}',
                ),
              ),
            ],
          ),

          const Divider(height: AppDimens.lg),

          // ── Khối PO (chỉnh sửa được) ─────────────────────────────────
          Row(
            children: [
              Expanded(
                child: Text(
                  LocaleKeys.box_detail_po_section.tr(),
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ),
              if (onEditPo != null)
              // Touch target đủ lớn cho tay đeo găng.
                InkWell(
                  onTap: onEditPo,
                  borderRadius: BorderRadius.circular(AppDimens.rBtn),
                  child: Padding(
                    padding: const EdgeInsets.symmetric(
                      horizontal: AppDimens.sm,
                      vertical: AppDimens.xs,
                    ),
                    child: Row(
                      mainAxisSize: MainAxisSize.min,
                      children: [
                        Icon(
                          Icons.edit_outlined,
                          size: 16,
                          color: swms.primary,
                        ),
                        const SizedBox(width: AppDimens.xs),
                        Text(
                          LocaleKeys.box_detail_edit_po.tr(),
                          style: AppTextStyles.bodyStrong.copyWith(
                            color: swms.primary,
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
          const SizedBox(height: AppDimens.xs),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Expanded(
                child: _InfoField(
                  label: LocaleKeys.box_detail_customer_po.tr(),
                  child: Text(
                    box.customerPo ?? dash,
                    style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _InfoField(
                  label: LocaleKeys.box_detail_psnv_po.tr(),
                  child: Text(
                    box.psnvPo ?? dash,
                    style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                    overflow: TextOverflow.ellipsis,
                  ),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _MiniStat extends StatelessWidget {
  final String label;
  final String value;

  const _MiniStat({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(
        vertical: AppDimens.sm,
        horizontal: AppDimens.sm,
      ),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
      ),
      child: Column(
        children: [
          Text(value, style: AppTextStyles.h2.copyWith(color: swms.text1)),
          Text(label, style: AppTextStyles.caption.copyWith(color: swms.text3)),
        ],
      ),
    );
  }
}

class _InfoField extends StatelessWidget {
  final String label;
  final Widget child;

  const _InfoField({required this.label, required this.child});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          label,
          style: AppTextStyles.caption.copyWith(color: context.swms.text3),
        ),
        const SizedBox(height: AppDimens.xs),
        child,
      ],
    );
  }
}