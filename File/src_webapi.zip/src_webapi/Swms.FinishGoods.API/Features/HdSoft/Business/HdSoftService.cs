using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.HdSoft.Api;
using Swms.FinishGoods.API.Features.HdSoft.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;

namespace Swms.FinishGoods.API.Features.HdSoft.Business
{
    public class HdSoftService : IHdSoftService
    {
        private readonly IHdSoftLotRepository _repo;
        private readonly IHdSoftSiRepository _siRepo;
        private readonly IStringLocalizer<SharedResource> _localizer;

        public HdSoftService(
            IHdSoftLotRepository repo,
            IHdSoftSiRepository siRepo,
            IStringLocalizer<SharedResource> localizer)
        {
            _repo = repo;
            _siRepo = siRepo;
            _localizer = localizer;
        }

        public async Task<List<HdSoftLotHistoryItemResponse>> GetLotHistoryAsync(string lot)
        {
            if (string.IsNullOrWhiteSpace(lot))
                throw new ArgumentException(_localizer["HdSoft.LotRequired"]);

            var trimmed = lot.Trim();

            var rows = await _repo.GetLotHistoryAsync(trimmed);

            if (rows.Count == 0)
                throw new NotFoundException(_localizer["HdSoft.LotNotFound", trimmed]);

            return rows.Select(HdSoftLotHistoryItemResponse.From).ToList();
        }

        public async Task<List<HdSoftPalletStockResponse>> GetPalletsInStockAsync(string? warehouse)
        {
            var rows = await _repo.GetPalletsInStockAsync(
                string.IsNullOrWhiteSpace(warehouse) ? null : warehouse.Trim());
            return rows.Select(HdSoftPalletStockResponse.From).ToList();
        }

        public Task<IReadOnlyDictionary<string, HdSoftLastMovementRow>> GetLastMovementsAsync(
            IReadOnlyList<string> lots)
            => _repo.GetLastMovementsAsync(lots);

        public Task<IReadOnlyDictionary<string, IReadOnlyList<HdSoftLotLocationRow>>> GetCurrentLocationsAsync(
            IReadOnlyList<string> lots)
            => _repo.GetCurrentLocationsAsync(lots);

        // ═══════════════════════════════════════════════════════════════
        //  Shipment Instruction (C_Order)
        // ═══════════════════════════════════════════════════════════════

        public async Task<HdSoftSiResponse> GetSiAsync(string siNo)
        {
            if (string.IsNullOrWhiteSpace(siNo))
                throw new ArgumentException(_localizer["HdSoft.SiNoRequired"]);

            var trimmed = siNo.Trim();
            var order = (await _siRepo.GetOrdersAsync(new[] { trimmed })).FirstOrDefault()
                ?? throw new NotFoundException(_localizer["HdSoft.SiNotFound", trimmed]);
            return HdSoftSiResponse.From(order);
        }

        public async Task<HdSoftSiColumnsResponse> GetSiColumnsAsync()
            => HdSoftSiColumnsResponse.From(await _siRepo.GetSchemaAsync());

        public Task<IReadOnlyList<HdSoftSiOrder>> GetSiOrdersAsync(IReadOnlyCollection<string> siNos)
            => _siRepo.GetOrdersAsync(siNos);

        public Task<IReadOnlyList<string>> GetSiNosByEtdAsync(
            DateTime from, DateTime toExclusive, string? warehouse)
            => _siRepo.GetSiNosByEtdAsync(from, toExclusive, warehouse);

        public Task<HdSoftSiSchema> GetSiSchemaAsync() => _siRepo.GetSchemaAsync();

        // ═══════════════════════════════════════════════════════════════
        //  Hàng thiếu theo ngày vanning
        // ═══════════════════════════════════════════════════════════════

        private const int MaxShortageDays = 62;

        // Vanning luôn trước ETD; ETD thường cách vanning vài ngày tới vài tuần.
        // Lọc thô theo ETD rộng hơn khoảng ngày này rồi mới lọc đúng theo vanning.
        private const int EtdAfterVanningDays = 45;

        /*  Nhu cầu  = SI (chưa huỷ) có NGÀY VANNING trong khoảng, mỗi dòng: QtyEntered − QtyDelivered (> 0).
                       Vanning = "Loading date" trong headernote3; không có thì lấy ETD.
            Cung     = QtyOnHand của model trong kho (M_StorageOnhand), gộp mã -V4 / không -V4.
            Chia tồn theo vanning sớm trước (cùng ngày: ETD, SI No, số dòng) — dòng nào hết tồn là thiếu.
            Chưa trừ SI có vanning TRƯỚC khoảng ngày mà chưa giao: muốn tính cả thì để from sớm hơn. */
        public async Task<HdSoftShortageResponse> GetShortagesAsync(HdSoftShortageQuery query)
        {
            var from = query.From!.Value.Date;
            var to = query.To!.Value.Date;
            if (to < from)
                throw new BusinessRuleException(_localizer["SiCompare.RangeInvalid"]);
            if ((to - from).TotalDays + 1 > MaxShortageDays)
                throw new BusinessRuleException(_localizer["SiCompare.RangeTooWide", MaxShortageDays]);

            var toExclusive = to.AddDays(1);
            var warehouse = string.IsNullOrWhiteSpace(query.Warehouse) ? null : query.Warehouse.Trim();

            // headernote3 là text tự do, SQL không lọc được -> lọc thô theo ETD, rồi lọc vanning ở đây
            var siNos = await _siRepo.GetSiNosByEtdAsync(from, toExclusive.AddDays(EtdAfterVanningDays), warehouse);
            var orders = await _siRepo.GetOrdersAsync(siNos);

            var demand = orders
                .Where(o => !HdSoftDocStatus.IsCancelled(o.DocStatus))
                .Select(o =>
                {
                    var etd = HdSoftSiEtd.Of(o);
                    return (Order: o, Etd: etd, Vanning: HdSoftSiVanning.Of(o) ?? etd);
                })
                .Where(x => x.Vanning is { } v && v >= from && v < toExclusive)
                .SelectMany(x => x.Order.Lines.Select(l => (x.Order, Vanning: x.Vanning!.Value, x.Etd, Line: l,
                                                           Open: l.QtyEntered - l.QtyDelivered)))
                .Where(x => x.Open > 0 && x.Line.Model.Length > 0)
                .OrderBy(x => x.Vanning)
                .ThenBy(x => x.Etd ?? DateTime.MaxValue)
                .ThenBy(x => x.Order.SiNo, StringComparer.OrdinalIgnoreCase)
                .ThenBy(x => x.Line.LineNo)
                .ToList();

            // Tồn theo model đã chuẩn hoá (-V4 và không -V4 là cùng 1 hàng)
            var onHandRaw = await _siRepo.GetOnHandByProductAsync(
                demand.Select(x => x.Line.ProductValue).Distinct().ToList(), warehouse);
            var onHand = onHandRaw
                .GroupBy(kv => HdSoftModel.Normalize(kv.Key), StringComparer.OrdinalIgnoreCase)
                .ToDictionary(g => g.Key, g => g.Sum(kv => kv.Value), StringComparer.OrdinalIgnoreCase);
            var remaining = new Dictionary<string, decimal>(onHand, StringComparer.OrdinalIgnoreCase);

            var lines = new List<HdSoftShortageLineResponse>(demand.Count);
            foreach (var (order, vanning, etd, line, open) in demand)
            {
                var model = line.Model;
                var avail = remaining.GetValueOrDefault(model);
                var alloc = Math.Min(avail, open);
                remaining[model] = avail - alloc;
                lines.Add(new HdSoftShortageLineResponse(
                    vanning, etd, order.SiNo, order.DocumentNo, line.LineNo, model, line.Field("packingno"),
                    open, avail, alloc, open - alloc));
            }

            var days = lines.GroupBy(l => l.VanningDate).OrderBy(g => g.Key)
                .Select(g => new HdSoftShortageDayResponse(
                    g.Key, g.Select(l => l.SiNo).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
                    g.Sum(l => l.QtyOpen), g.Sum(l => l.QtyShort), g.Count(l => l.QtyShort > 0)))
                .ToList();

            var models = lines.GroupBy(l => l.Model, StringComparer.OrdinalIgnoreCase)
                .Select(g => new HdSoftShortageModelResponse(
                    g.Key, onHand.GetValueOrDefault(g.Key), g.Sum(l => l.QtyOpen), g.Sum(l => l.QtyShort),
                    g.Where(l => l.QtyShort > 0).Select(l => (DateTime?)l.VanningDate).Min(),
                    g.Select(l => l.SiNo).Distinct(StringComparer.OrdinalIgnoreCase).Count()))
                .OrderByDescending(m => m.QtyShort > 0)
                .ThenBy(m => m.FirstShortVanning ?? DateTime.MaxValue)
                .ThenByDescending(m => m.QtyShort)
                .ThenBy(m => m.Model)
                .ToList();

            var shownLines = query.OnlyShort ? lines.Where(l => l.QtyShort > 0).ToList() : lines;
            var shownModels = query.OnlyShort ? models.Where(m => m.QtyShort > 0).ToList() : models;

            return new HdSoftShortageResponse(
                from, to, warehouse,
                lines.Select(l => l.SiNo).Distinct(StringComparer.OrdinalIgnoreCase).Count(),
                lines.Sum(l => l.QtyOpen), lines.Sum(l => l.QtyShort),
                days, shownModels, shownLines, DateTime.Now);
        }
    }
}
