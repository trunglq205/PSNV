namespace Swms.FinishGoods.API.Features.ReturnInstructions;

/// <summary>
/// Đề nghị nhận lại hàng về FA (mục 2c). BA bước, mỗi bước MỘT QUYỀN:
///   B1 FA tạo đề nghị                  → request_back   (không mail)
///   B2 quản lý FA xác nhận             → approve_fa     (mail SCS Office, CC FA)
///   B3 SCS WH quét Pallet ID giao hàng → process        (mail FA, CC SCS)
///
/// KHÔNG có bước duyệt của quản lý SCS (quyết định 09/11): khi SCS WH chuyển
/// hàng là đã có thông báo của SCS Office, và lúc chuyển cũng bắn mail — thêm
/// một lớp duyệt nữa chỉ làm chậm. Quyền <c>approve_scs</c> vì vậy không còn
/// chỗ dùng, nhưng vẫn khai trong Perms.cs (seeder MERGE theo code, xoá rồi
/// khai lại sẽ làm sống lại quyền của mọi role từng được gán).
///
/// LẤY LÀ LẤY HẾT: một đề nghị bao trọn phần còn lại của phiếu, nên dòng
/// model + SL SUY TỪ PHIẾU chứ không do FA nhập. Hàng đi theo CẢ PALLET —
/// serial lấy đúng theo pallet SCS WH quét, không gắp FIFO theo số lượng.
/// </summary>
public sealed class ReturnBackRequest
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public string ReqNo { get; set; } = default!;
    public string ReqStatus { get; set; } = ReturnBackStatus.FaRequested;
    public string CurrentStep { get; set; } = ReturnBackStep.FaApprove;
    public string? Note { get; set; }

    public string? RequestedBy { get; set; }
    public DateTime RequestedAt { get; set; }

    public string? FaApprovedBy { get; set; }
    public DateTime? FaApprovedAt { get; set; }
    public string? FaComment { get; set; }

    /// <summary>Ghi chú của kho lúc xác nhận giao hàng (B3).</summary>
    public string? ScsComment { get; set; }

    /// <summary>Ai bấm xác nhận giao hàng (B3) — SCS WH.</summary>
    public string? DeliveredBy { get; set; }

    /// <summary>
    /// Lúc giao XONG cả đề nghị. NULL khi còn hàng chưa giao, dù đã giao vài
    /// pallet — mốc của từng lượt quét nằm ở <c>wms.return_back_deliveries</c>.
    /// </summary>
    public DateTime? DeliveredAt { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    /// <summary>Số phiếu của chỉ thị nhận hàng — tiện cho màn hình và mail.</summary>
    public string? DocNo { get; set; }

    /// <summary>Loại hàng của chỉ thị (<c>rework</c> | <c>refurbish</c>).</summary>
    public string? GoodsType { get; set; }

    public List<ReturnBackRequestLine> Lines { get; set; } = [];

    /// <summary>Tổng SL của đề nghị — suy từ phiếu, không ai nhập.</summary>
    public int TotalQty => Lines.Sum(l => l.Qty);

    public int ModelCount => Lines.Count;

    /// <summary>
    /// Số serial ĐÃ gắp cho đề nghị này. Đếm từ sổ serial, KHÔNG lưu cột —
    /// cùng nguyên tắc với SL thực nhận ở mục 2b. Bằng 0 trước khi B4 chạy.
    /// </summary>
    public int AssignedQty { get; set; }

    /// <summary>Số serial của đề nghị này FA đã giao lại (mục 3).</summary>
    public int ReturnedQty { get; set; }

    /// <summary>
    /// Số con ĐANG ở FA chưa về. Đếm thẳng <c>status = at_fa</c> chứ KHÔNG lấy
    /// <see cref="AssignedQty"/> − <see cref="ReturnedQty"/>: con đã đánh
    /// <c>ng</c> không còn chờ về, trừ kiểu kia sẽ cộng nó vào đây và SCS đi
    /// đòi một lô hàng không bao giờ tới.
    /// </summary>
    public int AtFaQty { get; set; }

    public bool IsCancelled => ReqStatus == ReturnBackStatus.Cancelled;

    /// <summary>Đã cho back — hàng đang (hoặc đã từng) ở FA.</summary>
    /// <summary>Đã giao xong — không còn con nào để giao.</summary>
    public bool IsDelivered => ReqStatus == ReturnBackStatus.Delivered;

    /// <summary>Còn sửa / huỷ được: chưa duyệt xong và chưa huỷ.</summary>
    public bool IsOpen => !IsDelivered && !IsCancelled;

    /// <summary>
    /// Đã giao được ít nhất một pallet nhưng chưa hết. Màn hình cần phân biệt
    /// với "chưa giao gì" để WH biết đang dở dang.
    ///
    /// Bám <see cref="AssignedQty"/> chứ không <see cref="AtFaQty"/>: hàng đã
    /// giao rồi FA trả lại hết (mục 3) thì AtFaQty về 0, mà lượt giao đó vẫn
    /// đã xảy ra — "chưa giao gì" là nói sai và sẽ mở lại nút Huỷ.
    /// </summary>
    public bool IsPartlyDelivered => !IsDelivered && AssignedQty > 0;

    /// <summary>
    /// Còn bao nhiêu con CHƯA GIAO lần nào — con số SCS WH đọc để biết phải
    /// đẩy thêm mấy pallet.
    ///
    /// Trừ <see cref="AssignedQty"/> chứ KHÔNG trừ
    /// <c>AtFaQty + ReturnedQty</c>: con đã giao rồi mà bị đánh <c>ng</c> thì
    /// không còn ở FA lẫn chưa về, trừ kiểu kia sẽ tính nó là "chưa giao" và
    /// kho đi tìm một con đã bỏ.
    /// </summary>
    public int RemainQty => Math.Max(0, TotalQty - AssignedQty);
}

public sealed class ReturnBackRequestLine
{
    public long Id { get; set; }
    public long RequestId { get; set; }
    public int LineNo { get; set; }
    public string Model { get; set; } = default!;

    /// <summary>
    /// SL của model này trong đề nghị — SUY TỪ PHIẾU lúc tạo, không do FA
    /// nhập. Số thực đã giao nằm ở <see cref="AssignedQty"/>.
    /// </summary>
    public int Qty { get; set; }

    public string? Note { get; set; }

    /// <summary>Số serial đã gắp cho model này — đếm từ sổ serial.</summary>
    public int AssignedQty { get; set; }

    /// <summary>Số serial của model này FA đã giao lại.</summary>
    public int ReturnedQty { get; set; }

    /// <summary>
    /// SL kho CÒN gắp được cho model này (serial <c>received</c>, chưa thuộc
    /// lượt back nào). Chỉ điền ở màn soạn đề nghị, để CHO XEM phần sẽ lấy về.
    /// </summary>
    public int AvailableQty { get; set; }

    /// <summary>Chưa giao đủ SL của model này.</summary>
    public bool Short => AssignedQty < Qty;
}

/// <summary>
/// Trạng thái yêu cầu back. Khớp CHECK <c>ck_rbr_status</c>.
/// </summary>
public static class ReturnBackStatus
{
    /// <summary>FA vừa tạo, chờ quản lý FA xác nhận.</summary>
    public const string FaRequested = "fa_requested";

    /// <summary>Quản lý FA đã xác nhận, chờ SCS WH giao hàng.</summary>
    public const string FaApproved = "fa_approved";

    /// <summary>SCS WH đã giao xong — không còn con nào ở <c>received</c>.</summary>
    public const string Delivered = "delivered";

    /// <summary>Huỷ ở bất kỳ bước nào TRƯỚC khi giao.</summary>
    public const string Cancelled = "cancelled";

    public const string ReqPrefix = "BK";
}

/// <summary>
/// ĐANG CHỜ AI. Khớp CHECK <c>ck_rbr_step</c>.
///
/// Tách khỏi <see cref="ReturnBackStatus"/> vì màn hình lọc hàng đợi theo bước
/// ("đang chờ tôi"), còn trạng thái là để đọc lịch sử. Cùng cách
/// <c>ng_reports</c> tách <c>doc_status</c> và <c>current_step</c>.
/// </summary>
public static class ReturnBackStep
{
    /// <summary>Chờ quản lý FA xác nhận.</summary>
    public const string FaApprove = "fa_approve";

    /// <summary>Chờ SCS WH quét Pallet ID giao hàng.</summary>
    public const string ScsDeliver = "scs_deliver";

    /// <summary>Xong — đã giao hết, hoặc đã huỷ.</summary>
    public const string Done = "done";
}

/// <summary>
/// Một lượt SCS WH quét MỘT Pallet ID giao cho FA
/// (<c>wms.return_back_deliveries</c>).
///
/// Giữ cả <see cref="LotNo"/> dạng chữ chứ không chỉ id: đến mục 2d thì FA
/// đóng lại pallet MỚI, pallet cũ có thể bị tách hoặc biến mất, mà nhật ký
/// phải sống lâu hơn pallet.
/// </summary>
public sealed class ReturnBackDelivery
{
    public long Id { get; set; }
    public long RequestId { get; set; }
    public long? PalletId { get; set; }
    public string LotNo { get; set; } = default!;

    /// <summary>Số serial chuyển sang <c>at_fa</c> trong lần quét pallet này.</summary>
    public int SerialCount { get; set; }

    public DateTime DeliveredAt { get; set; }
    public string? DeliveredBy { get; set; }
}

/// <summary>
/// Kết quả một lượt SCS WH quét pallet giao hàng.
///
/// KHÔNG ném lỗi cho từng pallet không tìm thấy: WH quét 5 cái, một cái sai thì
/// 4 cái kia vẫn phải đi. Mã sai gom vào <see cref="NotFoundLots"/> để màn hình
/// nói rõ cái nào.
/// </summary>
public sealed class ReturnBackDeliverResult
{
    /// <summary>Không có đề nghị nào mang id đó.</summary>
    public bool NotFound { get; set; }

    /// <summary>Đề nghị không ở bước chờ giao (chưa duyệt, đã giao xong, hoặc đã huỷ).</summary>
    public bool WrongStep { get; set; }

    /// <summary>Mã pallet quét ra mà không có trong hệ thống.</summary>
    public List<string> NotFoundLots { get; } = [];

    /// <summary>Từng pallet đã giao trong lượt này, kèm số serial chuyển được.</summary>
    public List<ReturnBackDelivery> Pallets { get; } = [];

    /// <summary>Tổng serial chuyển sang <c>at_fa</c> trong lượt này.</summary>
    public int DeliveredQty { get; set; }

    /// <summary>Còn bao nhiêu con của phiếu chưa giao, sau lượt này.</summary>
    public int RemainQty { get; set; }

    /// <summary>Lượt này làm đề nghị giao XONG — mail báo FA gửi khi cờ này bật.</summary>
    public bool Completed { get; set; }

    /// <summary>Có pallet nào thực sự chuyển được con nào không.</summary>
    public bool AnyMoved => DeliveredQty > 0;
}
