using System.Globalization;
using Dapper;
using Swms.FinishGoods.API.Features.HdSoft.Business;

namespace Swms.FinishGoods.API.Features.HdSoft.DataAccess;

/*  Đọc SI (C_Order có SINo) từ DB HD soft — PostgreSQL, read-only.

    Cột chuẩn iDempiere đọc thẳng. Cột SAP tuỳ biến thì DÒ trước trong information_schema:
    có cột nào mới ghép vào SELECT, nên thiếu cột không làm hỏng câu truy vấn.
    Tên cột ghép vào SQL chỉ lấy từ information_schema (đã tồn tại thật) và được đặt trong
    ngoặc kép -> không có đường injection, kể cả khi tên cột đến từ appsettings.

    Đổi tên cột không cần sửa code: appsettings
        "HdSoft": { "SiColumns": { "po": "poreference", "etd": "x_etd", "m3": "" } }
    khoá = trường SAP, giá trị = cột; chuỗi rỗng = bỏ trường đó.                            */
public class HdSoftSiRepository : IHdSoftSiRepository
{
    // Trường SAP -> cột cùng tên (đổi tên qua HdSoft:SiColumns). Kind quyết định cách đưa timestamp về chuỗi.
    private sealed record FieldDef(string Field, string Kind);

    private static readonly FieldDef[] HeaderFields =
    {
        new("driverphoneno", "text"),    // "Ver: First"
        new("destport", "text"),         // cảng xuất
        new("contactname", "text"),      // consignee
        new("contactno", "text"),        // ship mode
        new("tripcount", "text"),        // cảng đến
        new("promotioncode", "text"),    // nước đến
        new("cuttime", "time"),
        new("packingtype", "text"),
        new("palletlist", "text"),
        new("m3", "text"),
        new("headernote3", "text"),      // loading date, T/S deadline, forwarder…
        new("casemark", "text"),
        new("qrinfor", "text"),
        new("pic", "text"),
        new("etd", "date"),
        new("eta", "date"),
        new("po", "text"),
        new("invoiceno", "text"),
    };

    private static readonly FieldDef[] LineFields =
    {
        new("packingno", "text"),
        new("packingitems", "text"),
        new("so", "text"),
        new("soitem", "text"),
    };

    private const string SchemaSql = """
        SELECT table_name::text AS t, column_name::text AS c, data_type::text AS d
        FROM information_schema.columns
        WHERE table_schema = 'adempiere' AND table_name IN ('c_order', 'c_orderline');
        """;

    private static readonly TimeSpan SchemaTtl = TimeSpan.FromMinutes(30);
    private static readonly SemaphoreSlim SchemaLock = new(1, 1);
    private static volatile HdSoftSiSchema? _schema;

    private readonly IHdSoftDbConnectionFactory _factory;
    private readonly IReadOnlyDictionary<string, string> _overrides;

    public HdSoftSiRepository(IHdSoftDbConnectionFactory factory, IConfiguration config)
    {
        _factory = factory;
        _overrides = config.GetSection("HdSoft:SiColumns").GetChildren()
            .ToDictionary(c => c.Key.Trim().ToLowerInvariant(),
                          c => (c.Value ?? "").Trim().ToLowerInvariant());
    }

    // ═══════════════════════════════════════════════════════════════
    //  Dò cột
    // ═══════════════════════════════════════════════════════════════

    public async Task<HdSoftSiSchema> GetSchemaAsync()
    {
        if (_schema is { } cached && DateTime.UtcNow - cached.LoadedAt < SchemaTtl) return cached;

        await SchemaLock.WaitAsync();
        try
        {
            if (_schema is { } again && DateTime.UtcNow - again.LoadedAt < SchemaTtl) return again;

            using var conn = _factory.Create();
            var rows = (await conn.QueryAsync<(string T, string C, string D)>(SchemaSql, commandTimeout: 30)).ToList();
            var order = rows.Where(r => r.T == "c_order").ToDictionary(r => r.C, r => r.D);
            var line = rows.Where(r => r.T == "c_orderline").ToDictionary(r => r.C, r => r.D);

            var missingHeader = new List<string>();
            var missingLine = new List<string>();
            var schema = new HdSoftSiSchema
            {
                Header = Resolve(HeaderFields, order, missingHeader),
                Line = Resolve(LineFields, line, missingLine),
                MissingHeader = missingHeader,
                MissingLine = missingLine,
                LoadedAt = DateTime.UtcNow,
            };
            _schema = schema;
            return schema;
        }
        finally
        {
            SchemaLock.Release();
        }
    }

    private List<HdSoftSiColumn> Resolve(
        IEnumerable<FieldDef> defs, IReadOnlyDictionary<string, string> columns, List<string> missing)
    {
        var result = new List<HdSoftSiColumn>();
        foreach (var def in defs)
        {
            // Mặc định cột cùng tên trường; appsettings đổi tên, chuỗi rỗng = bỏ trường
            var col = _overrides.TryGetValue(def.Field, out var o) ? o : def.Field;
            if (col.Length == 0 || !columns.ContainsKey(col)) missing.Add(def.Field);
            else result.Add(new HdSoftSiColumn(def.Field, col, columns[col], def.Kind));
        }
        return result;
    }

    /// <summary>Biểu thức đưa cột về text. Timestamp format sẵn để khớp cách SAP gửi (yyyy-MM-dd).</summary>
    private static string Expr(string alias, HdSoftSiColumn c)
    {
        var quoted = "\"" + c.Column.Replace("\"", "\"\"") + "\"";
        var col = alias + "." + quoted;
        var isTime = c.DataType.StartsWith("timestamp", StringComparison.Ordinal) || c.DataType == "date";
        if (!isTime) return $"{col}::text";
        return c.Kind switch
        {
            "date" => $"to_char({col}, 'YYYY-MM-DD')",
            "time" => $"to_char({col}, 'HH24:MI')",
            _ => $"to_char({col}, 'YYYY-MM-DD HH24:MI:SS')",
        };
    }

    private static string ExtraColumns(string alias, IEnumerable<HdSoftSiColumn> cols)
        => string.Concat(cols.Select(c => $",\n       {Expr(alias, c)} AS f_{c.Field}"));

    // ═══════════════════════════════════════════════════════════════
    //  Phiếu + dòng
    // ═══════════════════════════════════════════════════════════════

    /*  Mỗi SINo lấy 1 phiếu: bỏ phiếu đã huỷ / đảo (VO, RE) nếu còn phiếu khác, rồi lấy
        phiếu tạo mới nhất (HD soft có thể giữ mỗi revision 1 phiếu).
        So khớp SINo không phân biệt hoa thường / khoảng trắng.                           */
    public async Task<IReadOnlyList<HdSoftSiOrder>> GetOrdersAsync(IReadOnlyCollection<string> siNos)
    {
        var keys = siNos.Select(x => x?.Trim().ToUpperInvariant() ?? "")
                        .Where(x => x.Length > 0)
                        .Distinct()
                        .ToArray();
        if (keys.Length == 0) return Array.Empty<HdSoftSiOrder>();

        var schema = await GetSchemaAsync();

        var headerSql = $"""
            SELECT DISTINCT ON (UPPER(TRIM(o.sino)))
                   o.c_order_id::bigint   AS order_id,
                   TRIM(o.sino)           AS si_no,
                   o.documentno           AS document_no,
                   o.docstatus            AS doc_status,
                   bp.value               AS bpartner_code,
                   w.value                AS warehouse_code,
                   org.value              AS org_code,
                   o.dateordered          AS date_ordered,
                   o.datepromised         AS date_promised,
                   o.description          AS description,
                   o.created              AS created,
                   o.updated              AS updated,
                   (COUNT(*) OVER (PARTITION BY UPPER(TRIM(o.sino))))::int AS order_count{ExtraColumns("o", schema.Header)}
            FROM adempiere.c_order o
            LEFT JOIN adempiere.c_bpartner  bp  ON bp.c_bpartner_id  = o.c_bpartner_id
            LEFT JOIN adempiere.m_warehouse w   ON w.m_warehouse_id  = o.m_warehouse_id
            LEFT JOIN adempiere.ad_org      org ON org.ad_org_id     = o.ad_org_id
            WHERE o.isactive = 'Y'
              AND UPPER(TRIM(o.sino)) = ANY(@SiNos)
            ORDER BY UPPER(TRIM(o.sino)),
                     CASE WHEN o.docstatus IN ('VO', 'RE') THEN 1 ELSE 0 END,
                     o.created DESC, o.c_order_id DESC
            """;

        var lineSql = $"""
            SELECT ol.c_order_id::bigint      AS order_id,
                   ol.c_orderline_id::bigint  AS line_id,
                   ol.line::int               AS line_no,
                   p.value                    AS product_value,
                   ol.qtyentered              AS qty_entered,
                   ol.qtydelivered            AS qty_delivered,
                   u.uomsymbol                AS uom,
                   ol.description             AS description{ExtraColumns("ol", schema.Line)}
            FROM adempiere.c_orderline ol
            LEFT JOIN adempiere.m_product p ON p.m_product_id = ol.m_product_id
            LEFT JOIN adempiere.c_uom     u ON u.c_uom_id     = ol.c_uom_id
            WHERE ol.isactive = 'Y'
              AND ol.c_order_id = ANY(CAST(@OrderIds AS numeric[]))
            ORDER BY ol.c_order_id, ol.line, ol.c_orderline_id
            """;

        using var conn = _factory.Create();

        var orders = (await conn.QueryAsync(headerSql, new { SiNos = keys }, commandTimeout: 120))
            .Select(r => ReadOrder((IDictionary<string, object>)r, schema))
            .ToList();
        if (orders.Count == 0) return orders;

        var byId = orders.ToDictionary(o => o.OrderId);
        var lineRows = await conn.QueryAsync(
            lineSql, new { OrderIds = byId.Keys.ToArray() }, commandTimeout: 120);
        foreach (var row in lineRows)
        {
            var d = (IDictionary<string, object>)row;
            if (byId.TryGetValue(Long(d, "order_id"), out var order))
                order.Lines.Add(ReadLine(d, schema));
        }
        return orders;
    }

    /*  ETD bên HD soft: cột etd (trường SAP) nếu có và là kiểu ngày — so sánh được trực tiếp.
        Cột etd dạng text (định dạng không chắc) hoặc không có -> dùng datepromised (chuẩn iDempiere,
        "Ngày dự kiến giao"). Phiếu đã huỷ / đảo không lấy: xuất tương lai thì không còn ý nghĩa. */
    public async Task<IReadOnlyList<string>> GetSiNosByEtdAsync(
        DateTime from, DateTime toExclusive, string? warehouse)
    {
        var schema = await GetSchemaAsync();
        var etd = schema.Header.FirstOrDefault(c => c.Field == "etd");
        var etdCol = etd is not null
                     && (etd.DataType.StartsWith("timestamp", StringComparison.Ordinal) || etd.DataType == "date")
            ? "o.\"" + etd.Column.Replace("\"", "\"\"") + "\""
            : "o.datepromised";

        var sql = $"""
            SELECT DISTINCT TRIM(o.sino)
            FROM adempiere.c_order o
            LEFT JOIN adempiere.m_warehouse w ON w.m_warehouse_id = o.m_warehouse_id
            WHERE o.isactive = 'Y'
              AND o.sino IS NOT NULL AND TRIM(o.sino) <> ''
              AND COALESCE(o.docstatus, '') NOT IN ('VO', 'RE')
              AND {etdCol} >= @From AND {etdCol} < @To
              AND (@Warehouse::text IS NULL OR w.value = @Warehouse::text);
            """;
        using var conn = _factory.Create();
        // Unspecified: cột ngày là timestamp không múi giờ (giống HdSoftLotRepository).
        var rows = await conn.QueryAsync<string>(sql, new
        {
            From = DateTime.SpecifyKind(from, DateTimeKind.Unspecified),
            To = DateTime.SpecifyKind(toExclusive, DateTimeKind.Unspecified),
            Warehouse = string.IsNullOrWhiteSpace(warehouse) ? null : warehouse.Trim(),
        }, commandTimeout: 120);
        return rows.ToList();
    }

    // ═══════════════════════════════════════════════════════════════
    //  Đọc dòng dynamic (alias Postgres luôn là chữ thường)
    // ═══════════════════════════════════════════════════════════════

    private static HdSoftSiOrder ReadOrder(IDictionary<string, object> d, HdSoftSiSchema schema) => new()
    {
        OrderId = Long(d, "order_id"),
        SiNo = Str(d, "si_no") ?? "",
        DocumentNo = Str(d, "document_no") ?? "",
        DocStatus = Str(d, "doc_status"),
        BPartnerCode = Str(d, "bpartner_code"),
        WarehouseCode = Str(d, "warehouse_code"),
        OrgCode = Str(d, "org_code"),
        DateOrdered = Date(d, "date_ordered"),
        DatePromised = Date(d, "date_promised"),
        Description = Str(d, "description"),
        Created = Date(d, "created") ?? default,
        Updated = Date(d, "updated"),
        OrderCount = (int)Long(d, "order_count"),
        Fields = schema.Header.ToDictionary(c => c.Field, c => Str(d, $"f_{c.Field}")),
    };

    private static HdSoftSiLine ReadLine(IDictionary<string, object> d, HdSoftSiSchema schema) => new()
    {
        LineId = Long(d, "line_id"),
        LineNo = (int)Long(d, "line_no"),
        ProductValue = Str(d, "product_value") ?? "",
        QtyEntered = Dec(d, "qty_entered"),
        QtyDelivered = Dec(d, "qty_delivered"),
        Uom = Str(d, "uom"),
        Description = Str(d, "description"),
        Fields = schema.Line.ToDictionary(c => c.Field, c => Str(d, $"f_{c.Field}")),
    };

    private static object? Get(IDictionary<string, object> d, string key)
        => d.TryGetValue(key, out var v) && v is not null and not DBNull ? v : null;

    private static string? Str(IDictionary<string, object> d, string key)
    {
        var s = Convert.ToString(Get(d, key), CultureInfo.InvariantCulture)?.Trim();
        return string.IsNullOrEmpty(s) ? null : s;
    }

    private static long Long(IDictionary<string, object> d, string key)
        => Get(d, key) is { } v ? Convert.ToInt64(v, CultureInfo.InvariantCulture) : 0;

    private static decimal Dec(IDictionary<string, object> d, string key)
        => Get(d, key) is { } v ? Convert.ToDecimal(v, CultureInfo.InvariantCulture) : 0m;

    private static DateTime? Date(IDictionary<string, object> d, string key)
        => Get(d, key) switch
        {
            DateTime dt => dt,
            DateTimeOffset dto => dto.DateTime,
            DateOnly dO => dO.ToDateTime(TimeOnly.MinValue),
            _ => null,
        };

    public async Task<IReadOnlyDictionary<string, decimal>> GetOnHandByProductAsync(
    IReadOnlyCollection<string> productValues, string? warehouse)
    {
        var products = productValues.Where(p => !string.IsNullOrWhiteSpace(p)).Distinct().ToArray();
        if (products.Length == 0) return new Dictionary<string, decimal>();

        const string sql = """
            SELECT p.value                AS product,
                   SUM(so.qtyonhand)      AS qty
            FROM adempiere.m_storageonhand so
            JOIN adempiere.m_product   p ON p.m_product_id   = so.m_product_id
            JOIN adempiere.m_locator   l ON l.m_locator_id   = so.m_locator_id
            JOIN adempiere.m_warehouse w ON w.m_warehouse_id = l.m_warehouse_id
            WHERE so.qtyonhand > 0
              AND p.value = ANY(@Products)
              AND (@Warehouse::text IS NULL OR w.value = @Warehouse::text)
            GROUP BY p.value;
            """;

        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<(string Product, decimal Qty)>(sql, new
        {
            Products = products,
            Warehouse = string.IsNullOrWhiteSpace(warehouse) ? null : warehouse.Trim(),
        }, commandTimeout: 120);
        return rows.ToDictionary(r => r.Product, r => r.Qty);
    }
}
