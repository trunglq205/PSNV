﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class frmStep4cs : Form
    {
        WebService objService = new WebService();
        string id;
        string rs_indentity;
        public frmStep4cs(string id, string MODEL, string ext, string rs_indentity, string sPalletNo, bool is_cont, int remain)
        {
            InitializeComponent();
            this.WindowState = FormWindowState.Normal;
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            KeyPreview = true;

            this.id = id;
            txtByHand.Text = MODEL;
            txtExtension.Text = ext;
            this.rs_indentity = rs_indentity;
            if (!is_cont)
            {
                txtQuantyStanddard.Text = totalBefore();
            }
            else
            {
                int a = int.Parse(totalBefore());

                txtQuantyStanddard.Text = (a - remain).ToString();
            }

            txtPallet.Text = sPalletNo;


            string dt = sPalletNo.Substring(3, 6);
            string year = dt.Substring(0, 2);
            string month = dt.Substring(2, 2);
            string day = (dt.Substring(4, 2));
            //MessageBox.Show("Y:" + year + " M:" + month + " " + day);
            string tt = sPalletNo.Substring(9, 3);
            //MessageBox.Show(tt);
            lblYear.Text = "20" + year + "-" + month + "-" + day;
            lblSTT.Text = tt;





        }
        public string totalBefore()
        {
            return objService.count_model(txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim());
        }
        private void txtExtension_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtByHand.Focus();

            }
        }

        private void txtByHand_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                txtByHand.Text = txtByHand.Text.ToUpper().Trim();
                txtSerial.Focus();
            }
        }



        private void txtRescan_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string data = txtRescan.Text.Replace('*', ' ');
                data = data.Replace('%', ' ');
                data = data.Trim();
                txtRescan.Text = data;
                if (txtRescan.Text.Trim() != txtByHand.Text.Trim())
                {
                    lblStatus.Text = "2 model khong khop nhau";

                    txtRescan.Clear();
                    txtRescan.Focus();
                    txtSerial.Clear();
                    lblStatus.ForeColor = Color.Red;
                    lblStatus.BackColor = Color.Black;
                }
                else
                {

                    txtSerial.Focus();
                }
            }

        }

        private void txtSerial_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string rs = objService.veryModelandSerial(txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim(), txtSerial.Text.Trim(), rs_indentity.ToString());
                if (rs == "1")
                {
                    lblStatus.ForeColor = Color.Green;
                    lblStatus.BackColor = Color.Yellow;
                    int count = int.Parse(txtQuantyStanddard.Text.Trim());
                    count = count - 1;
                    txtQuantyStanddard.Text = count + "";
                    lblStatus.Text = "OK";
                    txtSerial.SelectAll();
                    txtSerial.Focus();





                }
                else if (rs == "2")
                {
                    lblStatus.BackColor = System.Drawing.Color.Black;
                    lblStatus.ForeColor = System.Drawing.Color.Red;
                    lblStatus.Text = "QUET ROI";

                    txtSerial.Focus();
                    txtSerial.SelectAll();


                }
                else if (rs == "3")
                {
                    lblStatus.BackColor = System.Drawing.Color.Black;
                    lblStatus.ForeColor = System.Drawing.Color.Red;
                    lblStatus.Text = "KHONG TON TAI";

                    txtSerial.Focus(); txtSerial.SelectAll();




                }

            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            int total_now = int.Parse(txtQuantyStanddard.Text);
            int total_db = int.Parse(totalBefore());
            int actual_scanned = total_db - total_now;
            string content = "So luong tieu chuan:\t" + total_db;
            content += "\nSo luong da quet:\t" + actual_scanned;
            content += "\nSo luong con lai:\t" + total_now;
            if (MessageBox.Show("Ban co muon thoat hay khong?\n" + content, "EXIT", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
            {
                int rs = objService.TBLSHRINKPRE_UpdateTotal(int.Parse(rs_indentity), actual_scanned);
                this.Close();
            }
        }

        private void frmStep4cs_KeyDown(object sender, KeyEventArgs e)
        {
            switch (e.KeyCode)
            {
                case Keys.Back:
                    if (!(txtSerial.Focus() || txtRescan.Focus() || txtRescan.Focus()))
                        btnClose_Click(sender, e);
                    break;
                case Keys.Escape:
                    btnClose_Click(sender, e);
                    break;


            }
        }

        private void txtRescan_TextChanged(object sender, EventArgs e)
        {
            if (txtRescan.Text.Trim().Contains('%'))
            {
                txtRescan.Text = txtRescan.Text.Replace('%', ' ');
                txtRescan.Text = txtRescan.Text.Trim();
            }
        }

        private void txtSerial_TextChanged(object sender, EventArgs e)
        {
            if (txtSerial.Text.Trim().Contains('%'))
            {
                txtSerial.Text = txtSerial.Text.Replace('%', ' ');
                txtSerial.Text = txtSerial.Text.Trim();
            }

        }

        private void txtByHand_TextChanged(object sender, EventArgs e)
        {
            if (txtByHand.Text.Trim().Contains('%'))
            {
                txtByHand.Text = txtByHand.Text.Replace('%', ' ');
                txtByHand.Text = txtByHand.Text.Trim();
            }
        }

        private void lblStatus_TextChanged(object sender, EventArgs e)
        {

        }
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Escape)
            {
                e.Handled = true;   // stop annoying beep
            }

            // call base handler...
            base.OnKeyPress(e);
        }
        private void frmStep4cs_Load(object sender, EventArgs e)
        {
            FormBorderStyle = FormBorderStyle.None;

        }

        private void txtQuantyStanddard_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnResetText_Click(object sender, EventArgs e)
        {
            txtRescan.Text = "";
            txtSerial.Text = "";
            txtRescan.Focus();
        }

        private void lblStatus_Click(object sender, EventArgs e)
        {

        }


    }
}
