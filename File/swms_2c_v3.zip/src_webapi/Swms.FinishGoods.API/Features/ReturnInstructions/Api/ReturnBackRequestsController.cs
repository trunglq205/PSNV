using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.ReturnInstructions.Business;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// Đề nghị nhận lại hàng về FA — mục 2c.
///
/// BA bước, mỗi bước MỘT QUYỀN, để một người không gánh được hai bước liền nhau
/// (cùng khuôn với màn Hàng bất thường):
///   B1 FA tạo đề nghị                  → <c>RequestBack</c>   (không mail)
///   B2 quản lý FA xác nhận             → <c>ApproveFa</c>      (mail SCS Office, CC FA)
///   B3 SCS WH quét Pallet ID giao hàng → <c>Process</c>        (mail FA, CC SCS)
///
/// KHÔNG còn bước duyệt của quản lý SCS: SCS WH chỉ chuyển hàng sau khi đã có
/// thông báo của SCS Office, và lúc chuyển cũng bắn mail — thêm một lớp duyệt
/// nữa chỉ làm chậm mà không ai đọc thêm được gì.
///
/// Serial chỉ chuyển <c>at_fa</c> ở B3, THEO PALLET SCS WH quét. Trước đó đề
/// nghị chỉ là model + SL — gắp sớm là giữ hàng trong khi đề nghị còn có thể bị
/// huỷ.
/// </summary>
[ApiController]
[Route("api/return-back-requests")]
public class ReturnBackRequestsController : ControllerBase
{
    private readonly IReturnBackRequestService _service;
    public ReturnBackRequestsController(IReturnBackRequestService service) => _service = service;

    /// <summary>
    /// Danh sách đề nghị. Lọc được theo <c>step</c> để mỗi bên mở ra là thấy
    /// hàng đợi của mình, không phải tự lọc bằng mắt.
    /// </summary>
    [HttpGet]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<BackRequestResponse>>> GetList(
        [FromQuery] BackRequestQuery query)
        => Ok(await _service.GetListAsync(query));

    [HttpGet("{id:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<BackRequestResponse>> GetById(long id)
        => Ok(await _service.GetByIdAsync(id));

    /// <summary>
    /// Nhật ký pallet đã giao, mới nhất trước. Giao dần nhiều lượt thì WH phải
    /// tra được đã quét những pallet nào, không thể nhớ bằng đầu.
    /// </summary>
    [HttpGet("{id:long}/deliveries")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<BackDeliveryResponse>>> GetDeliveries(long id)
        => Ok(await _service.GetDeliveriesAsync(id));

    /// <summary>
    /// SL còn gắp được theo model của một chỉ thị — màn soạn đề nghị gọi để CHO
    /// XEM phần hàng sẽ lấy về. Chỉ cần quyền xem.
    /// </summary>
    [HttpGet("available/{docId:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<BackAvailableModelResponse>>> GetAvailable(long docId)
        => Ok(await _service.GetAvailableAsync(docId));

    /// <summary>B1 — FA tạo đề nghị. Body chỉ có <c>DocId</c> + ghi chú.</summary>
    [HttpPost]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.RequestBack>]
    public async Task<ActionResult<BackRequestResponse>> Create(
        [FromBody] CreateBackRequestRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    /// <summary>
    /// Sửa ghi chú khi còn chờ quản lý FA.
    ///
    /// Chỉ quyền <c>RequestBack</c>: dòng model + SL nay suy từ phiếu nên SCS WH
    /// không còn gì để chỉnh, mà mở quyền cho họ ở đây là mở cả ô ghi chú của FA.
    /// </summary>
    [HttpPut("{id:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.RequestBack>]
    public async Task<ActionResult<BackRequestResponse>> Update(
        long id, [FromBody] UpdateBackRequestRequest request)
        => Ok(await _service.UpdateAsync(id, request));

    /// <summary>B2 — quản lý FA xác nhận. Lá mail sang SCS Office đi từ đây.</summary>
    [HttpPost("{id:long}/approve-fa")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.ApproveFa>]
    public async Task<ActionResult<BackRequestResponse>> ApproveFa(
        long id, [FromBody] BackRequestDecisionRequest request)
        => Ok(await _service.ApproveFaAsync(id, request));

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA. Gọi được NHIỀU LẦN cho một
    /// đề nghị (giao dần từng xe); mail báo FA chỉ đi ở lượt làm xong cả đề nghị.
    /// </summary>
    [HttpPost("{id:long}/deliver")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<BackDeliverResponse>> Deliver(
        long id, [FromBody] DeliverBackRequest request)
        => Ok(await _service.DeliverAsync(id, request));

    /// <summary>
    /// Huỷ đề nghị. Nhận cả ba quyền của ba bên: ai đang giữ bước cũng phải dừng
    /// được, chứ không phải chờ bên kia. Service chặn khi đã giao được con nào —
    /// lúc đó hàng ở FA rồi, huỷ là mất dấu lô hàng.
    /// </summary>
    [HttpPost("{id:long}/cancel")]
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.RequestBack,
                          Perms.Receiving.ReworkRefurbish.ApproveFa,
                          Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<BackRequestResponse>> Cancel(
        long id, [FromBody] BackRequestDecisionRequest request)
        => Ok(await _service.CancelAsync(id, request));
}
