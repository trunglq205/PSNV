# SWMS Finish Goods — Tổng hợp Widgets dùng chung

> Tài liệu tham chiếu nhanh cho toàn bộ widget trong `core/widgets/`.
> Import gọn qua: `import 'package:swms_finish_goods/core/widgets/widgets.dart';`
> **Barrel hiện chỉ re-export 11 file** — xem mục [Barrel](#barrel--widgetsdart) ở cuối, phần còn lại phải import trực tiếp.

---

## Cấu trúc thư mục

```
core/widgets/
├── buttons/
│   ├── app_button.dart            → AppButton
│   ├── back_icon_button.dart      → BackIconButton
│   └── glass_icon_button.dart     → AppGlassIconButton
├── common/
│   ├── app_bottom_hint.dart       → AppBottomHint
│   ├── app_card.dart              → AppCard
│   ├── app_error_view.dart        → AppErrorView
│   ├── app_expandable_list.dart   → AppExpandableList<T>
│   ├── app_loading.dart           → AppLoading
│   ├── app_stepper_bar.dart       → AppStepperBar, StepItem
│   ├── app_timeline.dart          → AppTimeline, AppTimelineItem, AppTimelineTone
│   ├── app_top_bar.dart           → AppTopBar
│   ├── barcode_scanner_widget.dart→ BarcodeScannerButton, ScannerState
│   ├── dashed_border.dart         → DashedBorder
│   ├── liquid_glass_feature_card.dart → LiquidGlassFeatureCard, Feature
│   └── status_pill.dart           → StatusPill
├── dialogs/
│   ├── app_dialog.dart            → AppDialog + AppDialogAction + showAppDialog…
│   ├── app_alert_dialog.dart      → AppAlertDialog
│   ├── app_alert_dialog_helper.dart → AppDialogHelper
│   ├── app_bottom_sheet.dart      → AppBottomSheet, showAppBottomSheet
│   ├── app_pick_dialog.dart       → showPickDialog
│   ├── app_toast.dart             → AppToastType
│   ├── app_toast_helper.dart      → AppToastHelper
│   ├── number_dial_dialog.dart    → showNumberDialDialog
│   └── update_progress_dialog.dart→ UpdateProgressDialog
├── inputs/
│   ├── app_dropdown.dart          → AppDropdown<T>
│   ├── app_radio_card_group.dart  → AppRadioCardGroup<T>, RadioCardItem
│   ├── app_switch.dart            → AppSwitch
│   ├── app_text_field.dart        → AppTextField, AppInputKind
│   └── app_toggle_switch.dart     → AppToggleSwitch
└── pickers/
    └── number_dial_picker.dart    → NumberDialPicker
```

---

## 1. Buttons

### `AppButton` — nút chính của design system PDA
Glove-friendly, bo `rBtn` (12px). Màu lấy từ token qua `context.swms`. `isLoading` tự khoá nút + hiện spinner 20px.

| Prop | Kiểu | Mặc định | Ghi chú |
|---|---|---|---|
| `label` | `String` | (bắt buộc) | rỗng = chỉ icon |
| `onPressed` | `VoidCallback?` | null | null = disabled |
| `variant` | `AppButtonVariant` | `primary` | xem bảng dưới |
| `size` | `AppButtonSize` | `md` | sm=`hitSm` · md=`hitMd` · lg=`hitLg` |
| `icon` | `IconData?` | null | icon trái, size 18 |
| `isFullWidth` | `bool` | `true` | |
| `isLoading` | `bool` | `false` | spinner, khoá nút |

**`AppButtonVariant`** → (nền, chữ, viền)

| Variant | Nền | Chữ | Viền |
|---|---|---|---|
| `primary` | primary | trắng | — |
| `success` | success | trắng | — |
| `warning` | warning | trắng | — |
| `danger` | danger | trắng | — |
| `neutral` | surface | text1 | border2 |
| `subtle` | primaryTint | primaryDark | — |

Chữ: Inter 12 / w600. Disabled: nền alpha 0.4, chữ alpha 0.7.

```dart
AppButton(label: 'Lưu', icon: Icons.save, onPressed: _save);
AppButton(label: 'Xoá', variant: AppButtonVariant.danger, onPressed: _del);
AppButton(label: 'Đang xử lý', isLoading: true);
```

### `BackIconButton` — nút quay lại viền mảnh
Ô 46px, viền `swms.border`, icon `chevron_left_rounded` màu text2. `onPressed` bỏ trống → `Navigator.maybePop`.

**Props**: `onPressed?`.

### `AppGlassIconButton` — nút icon nền kính
Bọc `GlassIconButton` (package `liquid_glass_widgets`). Icon size 18, trắng alpha 0.8.

**Props**: `icon` (bắt buộc), `onTap` (bắt buộc).

---

## 2. Common

### `AppCard` — thẻ nội dung cơ bản
Bo 14px, viền nhạt (`swms.border`), nền `colorScheme.surface`. Có `onTap` thì bọc `InkWell`.

| Prop | Kiểu | Mặc định |
|---|---|---|
| `child` | `Widget` | (bắt buộc) |
| `padding` | `EdgeInsetsGeometry` | `all(md)` = 16 |
| `borderRadius` | `double` | `rCard` = 14 |
| `onTap` | `VoidCallback?` | null |

### `StatusPill` — nhãn trạng thái
Nền tint nhạt + chữ đậm cùng tông (w700). Padding 10×5, bo `rInput` (10).

> **Không có enum tone**: dùng **factory constructor** (cần `context` để lấy token), hoặc constructor gốc khi cần màu tự do.

| Factory | Nền | Chữ |
|---|---|---|
| `StatusPill.success(context, label:, icon:)` | successBg | success |
| `StatusPill.warning(...)` | warningBg | warning |
| `StatusPill.danger(...)` | dangerBg | danger |
| `StatusPill.info(...)` | primaryTint | primaryDark |
| `StatusPill.neutral(...)` | border | text2 |

Constructor gốc: `StatusPill(label:, background:, foreground:, icon?)`.

```dart
StatusPill.success(context, label: 'Hoàn thành', icon: Icons.check);
```

### `AppTimeline` — dòng thời gian dọc
Chấm + đường nối, mốc mới nhất ở trên. Dùng chung cho lịch sử pallet / thùng. **Không** bọc sẵn `AppCard`, **không** tự xử lý trạng thái rỗng (items rỗng → `SizedBox.shrink`).

**`AppTimeline`**: `items` (`List<AppTimelineItem>`), `emphasizeFirst` (true — mốc đầu to hơn + có quầng màu, tắt khi mốc đầu không mang nghĩa "hiện tại").

**`AppTimelineItem`** — chỉ nhận **chuỗi đã format**, không nhận entity:

| Prop | Kiểu | Ghi chú |
|---|---|---|
| `title` | `String` | dòng chính, vd "Lưu kho" |
| `meta` | `String` | dòng chân: thời gian · người thực hiện |
| `code` | `String?` | mã in cùng dòng title, kiểu mono |
| `description` | `String?` | vd "Số thùng: 12 → 8" |
| `tone` | `AppTimelineTone` | `neutral` |
| `muted` | `bool` | false — mốc **kế thừa** (thao tác xảy ra trên pallet chứa thùng): chấm 7px, chữ nhạt |

**`AppTimelineTone`**: `success` · `warning` · `danger` · `info` (primary) · `neutral` (border2). Quầng sáng chỉ vẽ khi `emphasize` **và** tone ≠ neutral.

### `AppExpandableList<T>` — danh sách thu gọn / mở rộng
Hiện tối đa `collapsedCount` mục, bấm "hiện thêm" để xem hết. Dùng cho list con trong màn chi tiết (thùng trong pallet, serial trong thùng…).

| Prop | Kiểu | Mặc định |
|---|---|---|
| `items` | `List<T>` | (bắt buộc) |
| `itemBuilder` | `Widget Function(ctx, T, int)` | (bắt buộc) — `index` là vị trí thật |
| `title` | `String?` | null (đã `.tr()` sẵn ở phía gọi) |
| `headerAction` | `Widget?` | null — nút bên phải header |
| `collapsedCount` | `int` | 5 |
| `spacing` | `double` | `xs` |
| `collapsible` | `bool` | true — cho thu gọn lại |
| `initiallyExpanded` | `bool` | false |
| `showMoreLabel` | `String Function(int hidden)?` | `common.show_more` |
| `showLessLabel` | `String Function()?` | `common.show_less` |
| `empty` | `Widget?` | null (chỉ hiện header) |
| `crossAxisAlignment` | `CrossAxisAlignment` | `stretch` |
| `animate` | `bool` | true (`AnimatedSize` 180ms) |

### `AppStepperBar` — thanh các bước
Số tròn 20px + nhãn, nối bằng đường kẻ 2px. Bước hiện tại tô primary, bước khác nền surface + viền border2 + chữ text4.

**Props**: `current` (**1-based**), `steps` (`List<StepItem>`), `onStepTap` (`ValueChanged<int>?`, truyền số 1-based; null = không bấm được).

```dart
AppStepperBar(
  current: step,
  steps: const [StepItem('Quét Pallet'), StepItem('Xác nhận'), StepItem('Quét vị trí')],
  onStepTap: goStep,
);
```

### `AppTopBar` — AppBar dùng chung
`implements PreferredSizeWidget`. Nền surface, tiêu đề + phụ đề, viền mảnh dưới (`swms.border`). Bar 56 + divider 1 = 57. Nút back tự suy ra theo `Navigator.canPop`.

**Props**: `title` (bắt buộc), `subtitle?`, `showBack?` (null = auto), `onBack?`, `leading?`, `actions` (=[]).

### `AppBottomHint` — thanh nhắc cố định dưới đáy
Nền `surface` alpha 0.92, viền trên mảnh, bóng hắt lên. Tự cộng `MediaQuery.padding.bottom`. Mặc định: icon info + dòng chữ caption 11px; truyền `child` để thay bằng nút / nội dung khác.

**Props**: `text?`, `child?` — **phải có ít nhất một** (assert).

> TODO trong code: đổi `ReceivingBottomHint` thành alias của widget này rồi xoá bản cũ.

### `BarcodeScannerButton` — nút quét thẻ (state machine)
StatefulWidget, 3 trạng thái với `AnimatedSwitcher`. Cao mặc định 72px, bo `rBtn`, bóng `s2`, nền gradient theo trạng thái.

| `ScannerState` | Hiển thị | Gradient |
|---|---|---|
| `scanning` | barcode code128 + scan line đỏ animate + 4 góc xanh | đen |
| `loading` | spinner trắng + label | primary (xanh dương) |
| `success` | tick trắng + label | success (xanh lá) |

Scan line chỉ chạy ở `scanning` (tiết kiệm pin TC25), painter bọc `RepaintBoundary`.

**Props**: `state` (mặc định `scanning`), `scanningLabel` (bắt buộc), `loadingLabel?`, `successLabel?`, `height` (72). Label mặc định lấy từ `LocaleKeys.common_card_processing` / `common_card_success`.

### `LiquidGlassFeatureCard` — thẻ feature nền kính
Bọc `GlassCard` (package `liquid_glass_widgets`). Row: icon glass 32×32 + tiêu đề + phụ đề, chữ trắng. Nhận model `Feature(icon, title, sub)`.

### `AppErrorView` — view lỗi + nút retry
Dùng trong `AsyncValue.error`. Hai factory:

| Factory | Mô tả |
|---|---|
| `AppErrorView.page(...)` | toàn màn hình, có `Scaffold` + `AppBar`, icon 48 + nút `AppButton` variant danger |
| `AppErrorView.widget(...)` | nội tuyến: Row icon 16 + text + `TextButton` gạch chân |

**Props**: `message` (bắt buộc), `onRetry?`, `retryText` (='Thử lại').

### `AppLoading` — loading toàn màn
`Center(CircularProgressIndicator())`. Không có props.

### `DashedBorder` — viền nét đứt
`CustomPaint` vẽ viền nét đứt (dash 5, space 3) màu `AppColors.border`, padding 8.

**Props**: `child` (bắt buộc), `borderRadius` (=8).

---

## 3. Dialogs

### `AppDialog` — khung dialog gốc ⭐
**Mọi dialog trong app phải dựng từ đây** để cùng bo góc, khoảng cách, kiểu chữ. Chỉ lo phần **vỏ**, không giữ state — thân và trạng thái nút do widget gọi tự quản (StatefulWidget bọc ngoài, `ValueListenableBuilder`, Riverpod…).

Cấu trúc: **header** (hero · icon · title · subtitle · headerTrailing) + **thân** (message và/hoặc child) + **thanh nút đáy**.

| Prop | Kiểu | Mặc định | Ghi chú |
|---|---|---|---|
| `hero` | `Widget?` | null | khối nổi bật trên tiêu đề, thường là `AppDialogHeroIcon` |
| `title` | `String?` | null | bỏ trống → không dựng header |
| `subtitle` | `String?` | null | dòng phụ dưới tiêu đề |
| `message` | `String?` | null | chữ đơn giản, khỏi dựng `child`; có cả hai thì message nằm trên |
| `icon` | `IconData?` | null | icon 18px bên trái tiêu đề |
| `headerTrailing` | `Widget?` | null | nút phụ góc phải header |
| `headerTone` | `AppDialogHeaderTone?` | auto | `muted` khi `dividers`, ngược lại `plain` |
| `align` | `AppDialogAlign` | `center` | `start` cho dialog kiểu danh sách |
| `titleStyle` | `TextStyle?` | auto | `h2`, hoặc `title` khi `dividers` |
| `child` | `Widget?` | null | thân tự do |
| `actions` | `List<AppDialogAction>` | `[]` | rỗng = không có thanh nút |
| `scrollable` | `bool` | false | bọc thân trong `SingleChildScrollView` |
| `maxBodyHeight` | `double?` | null | đi kèm `scrollable` |
| `bodyPadding` | `EdgeInsetsGeometry?` | auto | `EdgeInsets.zero` cho list tràn viền |
| `dividers` | `bool` | false | kẻ ngăn header / thân / nút |
| `backgroundColor` | `Color?` | `swms.card` | **đừng để null** (surface = bg #F5F7FA → dialog xám hơn thẻ) |
| `insetPadding` | `EdgeInsets?` | 32×24 | |
| `maxTextScaleFactor` | `double?` | null | đặt 1.3 cho dialog có dial / lưới cố định chiều cao |

**`AppDialogHeaderTone`**: `plain` (không tô) · `muted` (`card2`) · `accent` (`primaryTint`, tiêu đề đổi sang `primaryDark`).
**`AppDialogAlign`**: `center` · `start`. Có `icon` hoặc `headerTrailing` → header thành Row và **luôn** canh trái.

**`AppDialogAction`** — một nút ở thanh đáy (render bằng `AppButton`, chia đều `Expanded`).
`onPressed: null` → nút mờ, **không ẩn** (ẩn thì thanh đáy đổi bố cục giữa chừng).

| Factory | Nội dung |
|---|---|
| `AppDialogAction.cancel(context, {label, result})` | neutral, pop kèm `result` (mặc định null) |
| `AppDialogAction.close(context, {label})` | neutral, pop — dialog chỉ đọc |
| `AppDialogAction.confirm({required onPressed, label, variant, icon, isLoading})` | primary; `onPressed: null` khi form chưa hợp lệ |

Nhãn mặc định: `LocaleKeys.common_cancel` / `common_close` / `common_confirm`.

**`AppDialogHeroIcon`** — icon tròn nền tint 12%, mặc định 64px (icon = 56.25% size).

**Hàm mở dialog**

| Hàm | Ghi chú |
|---|---|
| `showAppDialog<T>(context, {builder, barrierDismissible})` | **dùng thay `showDialog`** — barrier alpha .32 thay vì black54 |
| `showConfirmDialog(context, {title, message?, confirmLabel?, cancelLabel?, confirmVariant})` | `Future<bool>`, trả false khi huỷ; đặt `confirmVariant: danger` cho hành động phá dữ liệu |

```dart
AppDialog(
  title: 'Chọn khu',
  child: ...,
  actions: [
    AppDialogAction.cancel(context),
    AppDialogAction.confirm(onPressed: _canSave ? _save : null),
  ],
);
```

### `AppAlertDialog` — báo kết quả / hỏi xác nhận
Dựng trên `AppDialog`: hero icon tròn lớn + tiêu đề + mô tả. Trả `true`/`false` qua `Navigator.pop`.

| `AppAlertDialogType` | Icon | Màu | Variant nút xác nhận |
|---|---|---|---|
| `success` | check_circle | success | success |
| `error` | error | danger | danger |
| `info` | info | primary | primary |
| `confirm` | help | warning | warning |

**Props**: `type`, `title` (bắt buộc), `message?`, `confirmText` (='OK'), `cancelText?` (**null = không có nút huỷ**).

### `AppDialogHelper` — hàm tiện gọi (khuyến nghị dùng)

| Hàm | Trả về | Nút |
|---|---|---|
| `confirm(ctx, title:, message?, confirmText, cancelText)` | `Future<bool>` | Confirm / Cancel |
| `success(ctx, title:, message?, confirmText)` | `Future<void>` | OK |
| `error(ctx, title:, message?, confirmText)` | `Future<void>` | OK |
| `info(ctx, title:, message?, confirmText)` | `Future<void>` | OK |

```dart
final ok = await AppDialogHelper.confirm(context,
    title: 'Xác nhận xoá?', message: 'Không thể hoàn tác.');
```

### `AppBottomSheet` — khung bottom sheet
Song sinh với `AppDialog`: cùng token nền, cùng `AppDialogAction` cho thanh nút đáy. **Dùng sheet thay dialog khi nội dung có ô nhập** — sheet được đẩy lên theo `viewInsets` nên bàn phím không che ô đang gõ.

| Prop | Kiểu | Mặc định |
|---|---|---|
| `leading` / `icon` | `Widget?` / `IconData?` | null (có `leading` thì `icon` bị bỏ qua) |
| `title` / `subtitle` | `String?` | null |
| `trailing` | `List<Widget>` | `[]` — đứng trước nút X |
| `showClose` | `bool` | true (giữ true cả khi `isDismissible: false`) |
| `onClose` | `VoidCallback?` | `Navigator.pop()` |
| `showGrabber` | `bool` | true (tắt khi `enableDrag: false`) |
| `child` | `Widget?` | null |
| `actions` | `List<AppDialogAction>` | `[]` |
| `bodyPadding` | `EdgeInsetsGeometry?` | `all(md)` |
| `scrollable` | `bool` | true |
| `maxHeightFactor` | `double` | 0.9 |
| `backgroundColor` | `Color?` | `swms.card` |
| `dividers` | `bool` | true — kẻ dưới header |

**Mở**: `showAppBottomSheet<T>(context, {builder, isDismissible, enableDrag, useRootNavigator})` — luôn `isScrollControlled`, nền trong suốt, barrier alpha .32.

### `showPickDialog<T>` — chọn 1 giá trị trong danh sách ngắn
Chạm 1 dòng là chọn xong (chỉ có nút Huỷ). Trả `null` nếu huỷ. Danh sách dài hoặc cần tìm kiếm → làm màn riêng, đừng nhồi vào đây.

```dart
final origin = await showPickDialog<String>(
  context, title: 'Origin', items: kOrigins,
  labelOf: (o) => o, selected: form.origin,
);
```

### `showNumberDialDialog` — nhập số bằng dial
Trả `int` khi `decimalDigits = 0`, ngược lại `double`; `null` nếu huỷ. Nút Xác nhận **khoá** khi giá trị ngoài `minValue`–`maxValue`, kèm dòng nhắc đỏ (chỗ trống cố định 18px để dialog không nhảy). Khoá text scale 1.3.

**Params**: `title` (bắt buộc), `value` (num, bắt buộc), `unit?`, `decimalDigits` (=0), `minValue` (=0), `maxValue?`.

### `UpdateProgressDialog` — tiến trình tải bản cập nhật
`AlertDialog` + `PopScope(canPop: false)` (chặn nút back). `LinearProgressIndicator` 8px + `%`; `progress <= 0` → indeterminate.

**Props**: `progress` (0.0–1.0), `label?` (mặc định `LocaleKeys.update_downloading`), `onCancel?` (null = ẩn nút huỷ).

### `AppToastHelper` — toast (SnackBar floating)
Tự `hideCurrentSnackBar()` trước khi hiện cái mới. Nền = màu theo type, chữ trắng, bo 12, margin 16, mặc định 3 giây.

| Hàm | Type |
|---|---|
| `toast(ctx, message:, title?, type, duration, action?)` | tuỳ chọn |
| `toastSuccess(ctx, message, {title})` | success |
| `toastError(ctx, message, {title})` | error |
| `toastWarning(ctx, message, {title})` | warning |
| `toastInfo(ctx, message, {title})` | info |

**`AppToastType`** (extension `AppToastTypeX` cho `.color` / `.icon`): `success` (check_circle) · `error` (error) · `warning` (warning_amber) · `info` (info).

---

## 4. Inputs

### `AppTextField` — ô nhập chuẩn ⭐
Mọi biến thể đều là **một constructor**, khác nhau ở `kind` + vài cờ.

**`AppInputKind`**

| Kind | Viết hoa | Formatter | Bàn phím |
|---|---|---|---|
| `text` | none | — | mặc định, có autocorrect |
| `code` | characters | cấm khoảng trắng | mặc định |
| `number` | none | chỉ chữ số | `TextInputType.number` |

**Ba điểm hay sai khi tự viết, widget lo sẵn:**
1. Đổi `softKeyboard` phải nhả focus rồi focus lại thì input connection mới nhận `keyboardType` mới (xử lý trong `didUpdateWidget`).
2. Nút xoá **giữ lại focus** — nếu không, PDA quét tiếp sẽ rơi ra ngoài.
3. `value` đổi từ ngoài (vừa quét ghi vào state) → tự đồng bộ vào controller, con trỏ về cuối.

| Prop | Mặc định | Ghi chú |
|---|---|---|
| `kind` | `text` | |
| `controller` / `focusNode` | null | không truyền thì widget tự tạo & dispose |
| `value` | null | controlled — khác text hiện tại thì ghi đè |
| `label` / `hint` / `helperText` / `errorText` | null | |
| `dense` | false | padding gọn 10×10 |
| `filled` | false | nền `card2`, bỏ viền trạng thái thường |
| `enabled` / `readOnly` / `autofocus` / `obscureText` | | `obscureText` ép `maxLines = 1` |
| `clearable` | false | nút X, xoá xong giữ focus |
| `softKeyboard` | true | **false → `TextInputType.none`**: vẫn focus + con trỏ để nhận máy quét, không bung bàn phím mềm |
| `keyboardType` / `textCapitalization` / `autocorrect` | null | null = lấy theo `kind` |
| `textInputAction` | `done` | |
| `textAlign` | `start` | |
| `inputFormatters` | null | formatter của `kind` luôn chạy trước |
| `maxLines` / `maxLength` | 1 / null | có `maxLength` thì ẩn counter |
| `fontSize` / `borderRadius` | null / `rInput` | |
| `prefixIcon` / `suffixIcon` / `suffixText` | null | `clearable` chiếm chỗ `suffixIcon` khi có chữ |
| `onChanged` / `onSubmitted` / `onTap` | null | |

```dart
AppTextField(label: 'Ghi chú');                                   // form thường
AppTextField(kind: AppInputKind.code, hint: 'MODEL');             // ô mã
AppTextField(kind: AppInputKind.number, label: 'SL');             // ô số
AppTextField(softKeyboard: false, clearable: true, filled: true); // ô máy quét
```

### `AppDropdown<T>` — dropdown generic
`DropdownButtonFormField<T>`, `isExpanded`. Dùng cho enum/model.

**Props**: `value` (`T?`), `items` (`List<T>`), `itemLabel` (`String Function(T)`), `onChanged` (`ValueChanged<T?>?`), `label?`, `hint?`.

### `AppRadioCardGroup<T>` — nhóm radio dạng thẻ
Mỗi mục: icon vuông 36px + tiêu đề + phụ đề + chấm chọn 20px. Mục được chọn: viền primary 1.5, icon gradient xanh lá + bóng, chấm primary vành dày 6.

**Props**: `value` (`T?`), `items` (`List<RadioCardItem<T>>`), `onChanged` (`ValueChanged<T>?`), `spacing` (=`sm`).
**`RadioCardItem<T>`**: `value`, `title`, `subtitle`, `icon`.

```dart
AppRadioCardGroup<RecvMode>(
  value: mode,
  onChanged: (m) => setState(() => mode = m),
  items: const [
    RadioCardItem(value: RecvMode.pallet, title: 'Quét Pallet ID',
        subtitle: 'Pallet đã có QR sẵn', icon: Icons.grid_view_rounded),
    RadioCardItem(value: RecvMode.manual, title: 'Nhập tay',
        subtitle: 'Pallet không có mã', icon: Icons.edit_outlined),
  ],
);
```

### `AppSwitch` — công tắc bật/tắt
Track 44×26 bo tròn, núm trắng 20, **vùng chạm 44×44**. Bật = primary, tắt = border2. `onChanged: null` = disabled (opacity 0.4). Có `Semantics(toggled:, enabled:)`.

**Props**: `value` (bool), `onChanged` (`ValueChanged<bool>?`).

### `AppToggleSwitch` — công tắc pill có nhãn
Nhãn nằm **đối diện núm** và mô tả **trạng thái hiện tại** (giống OFF/ON), không phải hành động. Bề rộng tính theo nhãn dài nhất trong hai trạng thái → không giật khi bật/tắt. Bỏ `onLabel`/`offLabel` thì thành công tắc trơn.

```
 ( ) 1 MÃ            NHIỀU MÃ ( )
  tắt                      bật
```

| Prop | Kiểu | Mặc định |
|---|---|---|
| `value` | `bool` | (bắt buộc) |
| `onChanged` | `ValueChanged<bool>?` | (bắt buộc) — null = khoá |
| `onLabel` / `offLabel` | `String?` | null |
| `enabled` | `bool` | true |
| `height` | `double` | 28 |
| `activeColor` | `Color?` | `swms.primary` |

---

## 5. Pickers

### `NumberDialPicker` — chọn số bằng dial nhiều cột
Mỗi dial 1 chữ số 0–9 (kiểu khoá số): tối đa 5 nấc là tới chữ số cần chọn, không phụ thuộc độ lớn của số. Có haptic mỗi nấc, cột thập phân tô `card2`, cột nguyên tô `primaryTint`.

> **Uncontrolled**: `initialValue` chỉ đọc một lần lúc khởi tạo. Việc kiểm tra min/max thuộc về nơi gọi — thường dùng qua [`showNumberDialDialog`](#shownumberdialdialog--nhập-số-bằng-dial).

| Prop | Kiểu | Mặc định |
|---|---|---|
| `initialValue` | `num` | (bắt buộc) — âm coi như 0 |
| `onChanged` | `ValueChanged<num>` | (bắt buộc) |
| `decimalDigits` | `int` | 0 (assert 0–3) |
| `maxValue` | `num?` | null → tối thiểu 3 cột (999), tự nới theo `initialValue`; trần 7 cột |
| `unit` | `String?` | null |
| `separator` | `String` | `.` |
| `dialWidth` / `itemExtent` | `double` | `hitMd` |
| `visibleItems` | `int` | 3 |

---

## Barrel — `widgets.dart`

Hiện re-export **11 file**:

```dart
export 'buttons/app_button.dart';
export 'buttons/glass_icon_button.dart';
export 'common/app_card.dart';
export 'common/app_expandable_list.dart';
export 'common/barcode_scanner_widget.dart';
export 'common/liquid_glass_feature_card.dart';
export 'common/status_pill.dart';
export 'dialogs/app_alert_dialog.dart';
export 'dialogs/app_alert_dialog_helper.dart';
export 'inputs/app_dropdown.dart';
export 'inputs/app_text_field.dart';
```

**Chưa nằm trong barrel → phải import trực tiếp**: `back_icon_button`, `app_bottom_hint`, `app_error_view`, `app_loading`, `app_stepper_bar`, `app_timeline`, `app_top_bar`, `dashed_border`, `app_dialog`, `app_bottom_sheet`, `app_pick_dialog`, `app_toast`, `app_toast_helper`, `number_dial_dialog`, `update_progress_dialog`, `app_radio_card_group`, `app_switch`, `app_toggle_switch`, `number_dial_picker`.

Đề xuất bổ sung cho đủ bộ:

```dart
export 'buttons/back_icon_button.dart';
export 'common/app_bottom_hint.dart';
export 'common/app_error_view.dart';
export 'common/app_loading.dart';
export 'common/app_stepper_bar.dart';
export 'common/app_timeline.dart';
export 'common/app_top_bar.dart';
export 'common/dashed_border.dart';
export 'dialogs/app_bottom_sheet.dart';
export 'dialogs/app_dialog.dart';
export 'dialogs/app_pick_dialog.dart';
export 'dialogs/app_toast.dart';
export 'dialogs/app_toast_helper.dart';
export 'dialogs/number_dial_dialog.dart';
export 'dialogs/update_progress_dialog.dart';
export 'inputs/app_radio_card_group.dart';
export 'inputs/app_switch.dart';
export 'inputs/app_toggle_switch.dart';
export 'pickers/number_dial_picker.dart';
```

---

## Tóm tắt nhanh

| Widget | Nhóm | Dùng khi |
|---|---|---|
| `AppButton` | buttons | nút bấm chính (6 variant, 3 size) |
| `BackIconButton` | buttons | nút back viền mảnh (ngoài AppBar) |
| `AppGlassIconButton` | buttons | nút icon nền kính |
| `AppCard` | common | khối nội dung bo góc |
| `StatusPill` | common | nhãn trạng thái màu |
| `AppTimeline` | common | lịch sử pallet / thùng |
| `AppExpandableList<T>` | common | list con "hiện thêm / thu gọn" |
| `AppStepperBar` | common | quy trình nhiều bước |
| `AppTopBar` | common | AppBar có tiêu đề + phụ đề |
| `AppBottomHint` | common | thanh nhắc / nút cố định đáy màn |
| `BarcodeScannerButton` | common | quét thẻ (scanning/loading/success) |
| `LiquidGlassFeatureCard` | common | thẻ feature nền kính |
| `AppErrorView` | common | hiển thị lỗi + retry |
| `AppLoading` | common | loading toàn màn |
| `DashedBorder` | common | viền nét đứt |
| `AppDialog` | dialogs | **khung gốc mọi dialog** |
| `AppAlertDialog` / `AppDialogHelper` | dialogs | confirm / success / error / info |
| `AppBottomSheet` | dialogs | dialog **có ô nhập** (né bàn phím) |
| `showPickDialog` | dialogs | chọn 1 giá trị trong list ngắn |
| `showNumberDialDialog` | dialogs | nhập số bằng dial, có min/max |
| `UpdateProgressDialog` | dialogs | tiến trình tải bản cập nhật |
| `AppToastHelper` | dialogs | thông báo nhanh không chặn thao tác |
| `AppTextField` | inputs | mọi ô nhập (text / code / number / máy quét) |
| `AppDropdown<T>` | inputs | chọn từ danh sách |
| `AppRadioCardGroup<T>` | inputs | chọn 1 trong vài chế độ, có mô tả |
| `AppSwitch` | inputs | bật/tắt trơn |
| `AppToggleSwitch` | inputs | bật/tắt có nhãn trạng thái |
| `NumberDialPicker` | pickers | dial số (thường dùng qua dialog) |

*Cập nhật khi sửa file trong `core/widgets/`.*