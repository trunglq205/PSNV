import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/number_dial_dialog.dart';

/// Mở dialog chỉnh standard packing (số nguyên, 1–9999). Trả về null nếu huỷ.
Future<int?> showStdPackDialog(
  BuildContext context, {
  required int value,
}) async {
  final result = await showNumberDialDialog(
    context,
    title: 'receiving.edit_std_pack'.tr(),
    unit: 'receiving.pcs_per_box'.tr(),
    value: value,
    minValue: 1,
    maxValue: 9999,
  );
  return result?.round();
}
