using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Api.Features.Categories.Api;
using Swms.FinishGoods.Api.Features.Models.Api;
using Swms.FinishGoods.Api.Features.Models.DataAccess;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.Api.Features.Models.Business;

public class ModelService : IModelService
{
    private readonly IModelRepository _repo;
    private readonly ICategoryRepository _cateRepo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public ModelService(
        IModelRepository repo,
        ICategoryRepository cateRepo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _cateRepo = cateRepo;
        _currentUser = currentUser;
        _localizer = localizer;
    }

    public async Task<PagedResult<ModelResponse>> GetPagedAsync(ModelQuery query)
    {
        if (query.Page < 1) query.Page = 1;
        if (query.Size < 1) query.Size = 20;
        if (!string.IsNullOrWhiteSpace(query.Code)) query.Code = query.Code.Trim();
        query.GTIN = string.IsNullOrWhiteSpace(query.GTIN) ? null : query.GTIN.Trim();
        query.Origin = OriginRule.Normalize(query.Origin);   // " vn " -> "VN", rỗng -> null

        var paged = await _repo.GetPagedAsync(query);

        return new PagedResult<ModelResponse>(
            paged.Items.Select(ModelResponse.From).ToList(),
            paged.TotalCount,
            paged.Page,
            paged.Size);
    }

    public async Task<ModelResponse> GetByIdAsync(int id)
    {
        var entity = await _repo.GetByIdAsync(id);
        if (entity is null)
            throw new NotFoundException(_localizer["Models.NotFound", id]);
        return ModelResponse.From(entity);
    }

    public async Task<ModelResponse> GetByCodeAsync(string code)
    {
        code = (code ?? "").Trim();
        if (code.Length == 0)
            throw new BusinessRuleException(_localizer["Model.CodeRequired"]);

        var entity = await _repo.GetByCodeAsync(code);
        if (entity is null)
            throw new NotFoundException(_localizer["Model.NotFoundByCode", code]);

        return ModelResponse.From(entity);
    }

    public async Task<ModelResponse> GetByGTINAsync(string gtin)
    {
        gtin = (gtin ?? "").Trim();
        if (gtin.Length == 0)
            throw new BusinessRuleException(_localizer["Model.CodeRequired"]);

        var entity = await _repo.GetByGTINAsync(gtin);
        if (entity is null)
            throw new NotFoundException(_localizer["Model.NotFoundByCode", gtin]);

        return ModelResponse.From(entity);
    }

    public async Task<ModelResponse> CreateAsync(CreateModelRequest request)
    {
        var code = request.Code.Trim();

        // 1. Validate nghiệp vụ
        await EnsureCategoryExistsAsync(request.CategoryId);

        // 2. Check trùng
        if (await _repo.CodeExistsAsync(code, excludeId: null))
            throw new ConflictException(_localizer["Models.CodeExists", code]);

        // FIX: trước đây truyền nhầm `code` vào GtinExistsAsync -> check sai cột.
        if (!string.IsNullOrWhiteSpace(request.GTIN)
            && await _repo.GtinExistsAsync(request.GTIN.Trim(), excludeId: null))
            throw new ConflictException(_localizer["Models.GTINExists", request.GTIN.Trim()]);

        // 3. Build + insert
        var entity = BuildEntity(request, code);
        entity.CreatedBy = _currentUser.FullName;
        entity.Id = await _repo.AddAsync(entity);

        // 4. Trả bản ghi đầy đủ (kèm category name JOIN)
        return await GetByIdAsync(entity.Id);
    }

    public async Task<List<ModelResponse>> BulkCreateAsync(IReadOnlyList<CreateModelRequest> requests)
    {
        if (requests.Count == 0) return new();

        var normalized = requests
            .Select(r => r with { Code = r.Code.Trim() })
            .ToList();

        var conflicts = new List<DuplicateModelInfo>();

        // 1a. Trùng nội bộ batch
        var dupInBatch = normalized
            .GroupBy(r => r.Code, StringComparer.OrdinalIgnoreCase)
            .Where(g => g.Count() > 1)
            .Select(g => g.Key);
        foreach (var code in dupInBatch)
            conflicts.Add(new DuplicateModelInfo(null, code, _localizer["Models.Bulk.DuplicateInFile"]));

        // 1b. Trùng trong DB
        var codes = normalized.Select(r => r.Code).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var existing = await _repo.GetExistingCodesAsync(codes);
        foreach (var (id, code) in existing)
            conflicts.Add(new DuplicateModelInfo(id, code, _localizer["Models.Bulk.AlreadyExists"]));

        // 1c. Category không tồn tại
        var categoryIds = normalized.Select(r => r.CategoryId).Distinct().ToList();
        var cates = await _cateRepo.GetAllAsync(new CategoryQuery());
        var validIds = cates.Select(c => c.Code).ToHashSet();

        foreach (var catId in categoryIds)
            if (!validIds.Contains(catId))
                throw new BusinessRuleException(_localizer["Models.CategoryNotFound", catId]);

        if (conflicts.Count > 0)
            throw new BulkModelConflictException(_localizer["Models.Bulk.Conflict"], conflicts);

        // 2. Insert all-or-nothing
        var entities = normalized.Select(r =>
        {
            var e = BuildEntity(r, r.Code);
            e.CreatedBy = _currentUser.FullName;
            return e;
        }).ToList();

        await _repo.AddManyAsync(entities);

        // 3. Đọc lại theo code để trả response đầy đủ
        var inserted = await _repo.GetExistingCodesAsync(entities.Select(e => e.Code).ToList());
        var result = new List<ModelResponse>();
        foreach (var (id, _) in inserted)
        {
            var full = await _repo.GetByIdAsync(id);
            if (full is not null) result.Add(ModelResponse.From(full));
        }
        return result;
    }

    // ── Import upsert: mã đã tồn tại -> update; mã mới -> tạo mới ──────────
    // Khác BulkCreate ở chỗ mã trùng DB KHÔNG còn là lỗi mà chuyển sang update.
    //
    // Quy tắc "ô không điền" (field null / rỗng trong request):
    //   - Mã đã tồn tại: CHỈ ghi các field có giá trị; field không điền giữ nguyên giá trị trong DB.
    //   - Mã mới: phải đủ CategoryId + Length + Width + Height + StandardPacking mới tạo được.
    //   - Dòng không ghi được gì (mã mới thiếu field bắt buộc, hoặc mã đã có mà không điền ô nào)
    //     KHÔNG chặn cả file: bỏ qua và trả mã về trong BulkUpsertResult.SkippedCodes để FE báo lại.
    // Các dòng sai định dạng / trùng-trong-file / sai category đã được FE lọc trước.
    // Insert + update ghi trong 1 transaction.
    public async Task<BulkUpsertResult> BulkUpsertAsync(IReadOnlyList<UpsertModelRequest> requests)
    {
        if (requests.Count == 0) return BulkUpsertResult.Empty;

        // Chuẩn hoá + khử trùng code trong batch (dòng cuối ghi đè dòng trước cùng mã).
        var normalized = requests
            .Select(r => r with { Code = r.Code.Trim() })
            .Where(r => r.Code.Length > 0)
            .GroupBy(r => r.Code, StringComparer.OrdinalIgnoreCase)
            .Select(g => g.Last())
            .ToList();

        if (normalized.Count == 0) return BulkUpsertResult.Empty;

        // Validate category tồn tại — chỉ với dòng CÓ điền category (FE đã lọc, vẫn chặn để an toàn dữ liệu).
        var cates = await _cateRepo.GetAllAsync(new CategoryQuery());
        var validIds = cates.Select(c => c.Code).ToHashSet();
        foreach (var catId in normalized.Where(r => r.CategoryId.HasValue).Select(r => r.CategoryId!.Value).Distinct())
            if (!validIds.Contains(catId))
                throw new BusinessRuleException(_localizer["Models.CategoryNotFound", catId]);

        // Phân loại: mã đã có trong DB -> vá; còn lại -> insert.
        // Đọc đầy đủ bản ghi hiện có vì quy cách xếp pallet phải validate trên giá trị sau khi gộp.
        var codes = normalized.Select(r => r.Code).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var existing = await _repo.GetByCodesAsync(codes);
        var currentByCode = existing.ToDictionary(x => x.Code, StringComparer.OrdinalIgnoreCase);

        var toInsert = new List<ModelEntity>();
        var toUpdate = new List<ModelImportPatch>();
        var skipped = new List<string>();

        foreach (var r in normalized)
        {
            if (currentByCode.TryGetValue(r.Code, out var current))
            {
                var patch = BuildPatch(r, current);
                if (patch.IsEmpty)
                {
                    skipped.Add(r.Code);
                    continue;
                }
                patch.UpdatedBy = _currentUser.FullName;
                toUpdate.Add(patch);
            }
            else
            {
                if (!HasRequiredForCreate(r))
                {
                    skipped.Add(r.Code);
                    continue;
                }
                var e = BuildEntity(r, r.Code);
                e.CreatedBy = _currentUser.FullName;
                toInsert.Add(e);
            }
        }

        await _repo.UpsertManyAsync(toInsert, toUpdate);

        return new BulkUpsertResult(toInsert.Count, toUpdate.Count, skipped.Count, skipped);
    }

    public async Task UpdateAsync(int id, UpdateModelRequest request)
    {
        var existing = await _repo.GetByIdAsync(id);
        if (existing is null)
            throw new NotFoundException(_localizer["Models.NotFound", id]);

        if (request.GTIN != null && await _repo.GtinExistsAsync(request.GTIN, excludeId: id))
            throw new ConflictException(_localizer["Models.GTINExists", request.GTIN]);

        existing.GTIN = string.IsNullOrWhiteSpace(request.GTIN) ? null : request.GTIN.Trim();
        existing.Origin = OriginRule.Normalize(request.Origin);
        existing.Length = request.Length;
        existing.Width = request.Width;
        existing.Height = request.Height;
        existing.StandardPacking = request.StandardPacking;
        ValidateStacking(existing.Code, request.LayerLimit, request.LayerCount, request.StackingLength, request.StackingWidth);
        existing.LayerLimit = request.LayerLimit;
        existing.LayerCount = request.LayerCount;
        existing.StackingLength = request.StackingLength;
        existing.StackingWidth = request.StackingWidth;
        existing.SuggestAreaId = request.SuggestAreaId;
        existing.SuggestRackRow = NormalizeRackRow(request.SuggestRackRow, existing.Code);
        existing.IsActive = request.IsActive;
        existing.UpdatedBy = _currentUser.FullName;

        await _repo.UpdateAsync(existing);
    }

    // ── PATCH gợi ý lưu kho ───────────────────────────────────────────────
    // Chỉ đụng suggest_area + suggest_rack_row. Dùng cho dialog master ở PDA
    // và ô "gợi ý" trên Blazor — không bắt client phải gửi lại toàn bộ model.
    public async Task<ModelResponse> PatchSuggestionAsync(int id, PatchModelSuggestionRequest request)
    {
        var existing = await _repo.GetByIdAsync(id);
        if (existing is null)
            throw new NotFoundException(_localizer["Models.NotFound", id]);

        return await ApplySuggestionAsync(existing, request);
    }

    public async Task<ModelResponse> PatchSuggestionByCodeAsync(string code, PatchModelSuggestionRequest request)
    {
        code = (code ?? "").Trim();
        if (code.Length == 0)
            throw new BusinessRuleException(_localizer["Model.CodeRequired"]);

        var existing = await _repo.GetByCodeAsync(code);
        if (existing is null)
            throw new NotFoundException(_localizer["Model.NotFoundByCode", code]);

        return await ApplySuggestionAsync(existing, request);
    }

    // Validate TRƯỚC khi ghi: NormalizeRackRow throw nếu có tầng ngoài [1..4],
    // nên câu UPDATE chỉ chạy khi dữ liệu đã hợp lệ.
    private async Task<ModelResponse> ApplySuggestionAsync(ModelEntity existing, PatchModelSuggestionRequest request)
    {
        var rackRow = NormalizeRackRow(request.SuggestRackRow, existing.Code);

        var affected = await _repo.UpdateSuggestionAsync(
            existing.Id,
            request.SuggestAreaId,
            rackRow,
            _currentUser.FullName);

        // 0 dòng = model vừa bị soft-delete xen giữa lúc đọc và lúc ghi.
        if (affected == 0)
            throw new NotFoundException(_localizer["Models.NotFound", existing.Id]);

        return await GetByIdAsync(existing.Id);
    }

    public async Task DeleteAsync(int id)
    {
        var existing = await _repo.GetByIdAsync(id);
        if (existing is null)
            throw new NotFoundException(_localizer["Models.NotFound", id]);

        await _repo.SoftDeleteAsync(id, _currentUser.FullName);
    }

    // ── helpers ──────────────────────────────────────────────────────────
    private async Task EnsureCategoryExistsAsync(int categoryId)
    {
        var code = await _cateRepo.GetByCodeAsync(categoryId);
        if (code == null)
            throw new BusinessRuleException(_localizer["Models.CategoryNotFound", categoryId]);
    }

    /// <summary>
    /// Validate + quy đổi tầng rack từ dạng API (List&lt;int&gt;) sang dạng lưu DB (chuỗi).
    /// [3, 2, 3] -> "2,3". NULL/rỗng -> null. Mỗi giá trị phải nằm trong [Min..Max].
    /// </summary>
    private string? NormalizeRackRow(List<int>? rows, string code)
    {
        if (rows is null || rows.Count == 0) return null;

        if (rows.Any(r => r < RackRowRule.Min || r > RackRowRule.Max))
            throw new BusinessRuleException(_localizer[
                "Models.SuggestRackRowInvalid",
                code,
                string.Join(",", rows),
                RackRowRule.Min,
                RackRowRule.Max]);

        return RackRowRule.ToStorage(rows);
    }

    /// <summary>
    /// Quy cach xep pallet:
    ///  - LayerCount / StackingLength / StackingWidth: nhap du ca 3 hoac bo trong ca 3
    ///    (thieu 1 thi khong tinh duoc Box/pallet, Cargo).
    ///  - LayerCount khong vuot LayerLimit.
    /// Range (>0) da chan bang DataAnnotations o request.
    /// </summary>
    private void ValidateStacking(string code, int? layerLimit, int? layerCount, int? stackingLength, int? stackingWidth)
    {
        var filled = new[] { layerCount, stackingLength, stackingWidth }.Count(x => x.HasValue);
        if (filled is > 0 and < 3)
            throw new BusinessRuleException(_localizer["Models.StackingIncomplete", code]);

        if (layerCount.HasValue && layerLimit.HasValue && layerCount > layerLimit)
            throw new BusinessRuleException(_localizer["Models.LayerCountExceedsLimit", code, layerCount, layerLimit]);
    }

    private ModelEntity BuildEntity(CreateModelRequest r, string code)
    {
        ValidateStacking(code, r.LayerLimit, r.LayerCount, r.StackingLength, r.StackingWidth);
        return new()
        {
            Code = code,
            GTIN = string.IsNullOrWhiteSpace(r.GTIN) ? null : r.GTIN.Trim(),
            Origin = OriginRule.Normalize(r.Origin),
            CategoryId = r.CategoryId,
            Length = r.Length,
            Width = r.Width,
            Height = r.Height,
            StandardPacking = r.StandardPacking,
            LayerLimit = r.LayerLimit,
            LayerCount = r.LayerCount,
            StackingLength = r.StackingLength,
            StackingWidth = r.StackingWidth,
            SuggestAreaId = r.SuggestAreaId,
            SuggestRackRow = NormalizeRackRow(r.SuggestRackRow, code),
            IsActive = r.IsActive,
        };
    }

    /// <summary>Mã mới chỉ tạo được khi file điền đủ các cột NOT NULL của master.models.</summary>
    private static bool HasRequiredForCreate(UpsertModelRequest r)
        => r.CategoryId.HasValue && r.Length.HasValue && r.Width.HasValue
        && r.Height.HasValue && r.StandardPacking.HasValue;

    /// <summary>Dựng entity cho MÃ MỚI từ dòng import. Gọi sau khi HasRequiredForCreate = true.</summary>
    private ModelEntity BuildEntity(UpsertModelRequest r, string code)
    {
        ValidateStacking(code, r.LayerLimit, r.LayerCount, r.StackingLength, r.StackingWidth);
        return new()
        {
            Code = code,
            GTIN = string.IsNullOrWhiteSpace(r.GTIN) ? null : r.GTIN.Trim(),
            Origin = OriginRule.Normalize(r.Origin),
            CategoryId = r.CategoryId!.Value,
            Length = r.Length!.Value,
            Width = r.Width!.Value,
            Height = r.Height!.Value,
            StandardPacking = r.StandardPacking!.Value,
            LayerLimit = r.LayerLimit,
            LayerCount = r.LayerCount,
            StackingLength = r.StackingLength,
            StackingWidth = r.StackingWidth,
            SuggestAreaId = r.SuggestAreaId,
            SuggestRackRow = NormalizeRackRow(r.SuggestRackRow, code),
            IsActive = r.IsActive ?? true,
        };
    }

    /// <summary>
    /// Dựng bản vá cho MÃ ĐÃ TỒN TẠI: field nào dòng import có điền thì mang giá trị, còn lại null (= giữ nguyên).
    /// </summary>
    private ModelImportPatch BuildPatch(UpsertModelRequest r, ModelEntity current)
    {
        // Quy cách xếp pallet validate trên giá trị SAU KHI GỘP (ô không điền lấy từ DB) — vd file chỉ điền
        // layer_count thì stacking_length/width lấy của bản ghi hiện có. Chỉ kiểm tra khi file có đụng tới
        // nhóm cột này, để dữ liệu cũ chưa chuẩn không chặn việc cập nhật các cột khác.
        if (r.LayerLimit.HasValue || r.LayerCount.HasValue || r.StackingLength.HasValue || r.StackingWidth.HasValue)
            ValidateStacking(
                current.Code,
                r.LayerLimit ?? current.LayerLimit,
                r.LayerCount ?? current.LayerCount,
                r.StackingLength ?? current.StackingLength,
                r.StackingWidth ?? current.StackingWidth);

        return new()
        {
            Id = current.Id,
            GTIN = string.IsNullOrWhiteSpace(r.GTIN) ? null : r.GTIN.Trim(),
            Origin = OriginRule.Normalize(r.Origin),
            CategoryId = r.CategoryId,
            Length = r.Length,
            Width = r.Width,
            Height = r.Height,
            StandardPacking = r.StandardPacking,
            LayerLimit = r.LayerLimit,
            LayerCount = r.LayerCount,
            StackingLength = r.StackingLength,
            StackingWidth = r.StackingWidth,
            SuggestAreaId = r.SuggestAreaId,
            SuggestRackRow = NormalizeRackRow(r.SuggestRackRow, current.Code),   // null/rỗng -> null
            IsActive = r.IsActive,
        };
    }
}