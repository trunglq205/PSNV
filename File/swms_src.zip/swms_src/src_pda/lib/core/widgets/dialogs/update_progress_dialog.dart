// core/widgets/dialogs/update_progress_dialog.dart
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';

class UpdateProgressDialog extends StatelessWidget {
  final double progress; // 0.0 - 1.0, hoặc <=0 nếu indeterminate
  final String? label;
  final VoidCallback? onCancel; // null -> ẩn nút huỷ

  const UpdateProgressDialog({
    super.key,
    required this.progress,
    this.label,
    this.onCancel,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    final percent = (progress * 100).clamp(0, 100).toStringAsFixed(0);

    return PopScope(
      canPop: false, // chặn nút back
      child: AlertDialog(
        content: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              label ?? LocaleKeys.update_downloading.tr(),
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleMedium,
            ),
            const SizedBox(height: AppDimens.md),
            ClipRRect(
              borderRadius: BorderRadius.circular(AppDimens.sm),
              child: LinearProgressIndicator(
                value: progress <= 0 ? null : progress,
                minHeight: 8,
              ),
            ),
            const SizedBox(height: AppDimens.sm),
            Text(
              '$percent%',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                color: scheme.onSurfaceVariant,
              ),
            ),
            if (onCancel != null) ...[
              const SizedBox(height: AppDimens.lg),
              AppButton(
                label: LocaleKeys.update_cancel_button.tr(),
                onPressed: onCancel,
                variant: AppButtonVariant.neutral,
              ),
            ],
          ],
        ),
      ),
    );
  }
}