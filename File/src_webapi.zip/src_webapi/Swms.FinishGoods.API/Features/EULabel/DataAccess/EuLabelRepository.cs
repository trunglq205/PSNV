using System.Data;
using Dapper;
using Swms.FinishGoods.API.Features.EuLabel.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.EuLabel.DataAccess;

public interface IEuLabelRepository
{
    Task<EuLabelLoginResponse?> LoginAsync(string userName, string passwordHash);
    Task<EuLabelLoginResponse?> LoginByCardAsync(string cardCode);
    Task<HandoverConfirmResponse> ConfirmAsync(string key, int confirmedBy, string source);
    Task<HandoverJobSummaryResponse?> JobSummaryAsync(int printJobId);
    Task<(int printJobId, string siList)?> FindJobByTagAsync(string key);
    Task<List<HandoverSerialRow>> JobDetailAsync(int printJobId);
}

public class EuLabelRepository : IEuLabelRepository
{
    private readonly IEuLabelDbConnectionFactory _factory;
    public EuLabelRepository(IEuLabelDbConnectionFactory factory) => _factory = factory;

    public async Task<EuLabelLoginResponse?> LoginAsync(string userName, string passwordHash)
    {
        using var conn = _factory.Create();
        var p = new DynamicParameters();
        p.Add("@UserName", userName);
        p.Add("@PasswordHash", passwordHash);

        // usp_User_Login trả 1 dòng nếu đúng: AppUserId, UserName, DisplayName, Role
        var row = await conn.QueryFirstOrDefaultAsync(
            "usp_User_Login", p, commandType: CommandType.StoredProcedure);

        if (row is null) return null;
        return new EuLabelLoginResponse(
            true,
            (int)row.AppUserId,
            (string)row.UserName,
            (string?)row.DisplayName ?? "",
            (string?)row.Role ?? "");
    }

    public async Task<HandoverConfirmResponse> ConfirmAsync(string key, int confirmedBy, string source)
    {
        using var conn = _factory.Create();
        var p = new DynamicParameters();
        p.Add("@Key", key);
        p.Add("@ConfirmedBy", confirmedBy);
        p.Add("@Source", source);

        // SP usp_Handover_Confirm trả 1 dòng: Result (int) + Message (nvarchar).
        var row = await conn.QueryFirstOrDefaultAsync<HandoverConfirmResponse>(
            "usp_Handover_Confirm", p, commandType: CommandType.StoredProcedure);

        return row ?? new HandoverConfirmResponse(0, "Không có phản hồi từ DB");
    }

    public async Task<HandoverJobSummaryResponse?> JobSummaryAsync(int printJobId)
    {
        using var conn = _factory.Create();
        var p = new DynamicParameters();
        p.Add("@PrintJobId", printJobId);

        return await conn.QueryFirstOrDefaultAsync<HandoverJobSummaryResponse>(
            "usp_Handover_JobSummary", p, commandType: CommandType.StoredProcedure);
    }

    public async Task<EuLabelLoginResponse?> LoginByCardAsync(string cardCode)
    {
        using var conn = _factory.Create();
        var p = new DynamicParameters();
        p.Add("@CardCode", cardCode);

        var row = await conn.QueryFirstOrDefaultAsync(
            "usp_User_LoginByCard", p, commandType: CommandType.StoredProcedure);

        if (row is null) return null;
        return new EuLabelLoginResponse(
            true,
            (int)row.AppUserId,
            (string)row.UserName,
            (string?)row.DisplayName ?? "",
            (string?)row.Role ?? "");
    }

    public async Task<(int printJobId, string siList)?> FindJobByTagAsync(string key)
    {
        using var conn = _factory.Create();
        var p = new DynamicParameters();
        p.Add("@Key", key);

        var row = await conn.QueryFirstOrDefaultAsync(
            "usp_Handover_FindJobByTag", p, commandType: CommandType.StoredProcedure);

        if (row is null) return null;
        return ((int)row.PrintJobId, (string?)row.SiList ?? "");
    }

    public async Task<List<HandoverSerialRow>> JobDetailAsync(int printJobId)
    {
        using var conn = _factory.Create();
        var p = new DynamicParameters();
        p.Add("@PrintJobId", printJobId);

        var rows = await conn.QueryAsync<HandoverSerialRow>(
            "usp_Handover_JobDetail", p, commandType: CommandType.StoredProcedure);
        return rows.ToList();
    }
}