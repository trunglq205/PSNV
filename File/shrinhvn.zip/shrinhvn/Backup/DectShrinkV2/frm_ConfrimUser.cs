﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace DectShrinkV2
{
    public partial class frm_ConfrimUser : Form
    {
        public frm_ConfrimUser()
        {
            InitializeComponent();
        }

        private void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if(e.KeyCode ==Keys.Enter)
            {
                Untility._para.Pass_Admin = textBox1.Text.Trim();
                this.Close();
            }
        }

        private void frm_ConfrimUser_Load(object sender, EventArgs e)
        {

        }

        
    }
}
