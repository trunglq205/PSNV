import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_action_state.dart';

/// Danh sách tem nguồn của màn Gộp. Quét thêm tem ở PDA để thêm vào đây.
class PartCardMergeSources extends StatelessWidget {
  const PartCardMergeSources({
    super.key,
    required this.sources,
    required this.onRemove,
  });

  final List<PartCardSource> sources;

  /// null = khoá (đã lưu server).
  final ValueChanged<int>? onRemove;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    // Giữ ít nhất 1 tem — tem mở từ Home.
    final remove = sources.length > 1 ? onRemove : null;

    return AppCard(
      padding: const EdgeInsets.fromLTRB(12, 10, 0, 6),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          // Tiêu đề + gợi ý quét gộp chung 1 dòng.
          Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: LocaleKeys.part_card_merge_sources
                      .tr(namedArgs: {'count': '${sources.length}'})
                      .toUpperCase(),
                  style: TextStyle(
                    fontWeight: FontWeight.w800,
                    letterSpacing: .3,
                    color: swms.text3,
                  ),
                ),
                TextSpan(
                  text: '  ·  ${LocaleKeys.part_card_merge_scan_hint.tr(
                    namedArgs: {'max': '${PartCardForm.maxLines}'},
                  )}',
                  style: TextStyle(color: swms.primary),
                ),
              ],
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.caption.copyWith(fontSize: 10.5),
          ),
          for (var i = 0; i < sources.length; i++)
            _SourceRow(
              source: sources[i],
              onRemove: remove == null ? null : () => remove(i),
            ),
        ],
      ),
    );
  }
}

/// 1 tem nguồn: Card_ID · tóm tắt mã×thùng · nút xoá.
class _SourceRow extends StatelessWidget {
  const _SourceRow({required this.source, required this.onRemove});

  final PartCardSource source;
  final VoidCallback? onRemove;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Row(
      spacing: AppDimens.sm,
      children: [
        Text(
          source.cardId,
          style: AppTextStyles.code.copyWith(
            fontSize: 11.5,
            fontWeight: FontWeight.w800,
            color: swms.text1,
          ),
        ),
        Expanded(
          child: Text(
            source.summary,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.caption.copyWith(color: swms.text3),
          ),
        ),
        // Ô vuông hitSm — vẫn đủ to để bấm bằng găng tay, gọn hơn IconButton 48px.
        SizedBox.square(
          dimension: AppDimens.hitSm,
          child: IconButton(
            padding: EdgeInsets.zero,
            onPressed: onRemove,
            icon: Icon(
              Icons.close_rounded,
              size: 15,
              color: onRemove == null ? swms.text4 : swms.danger,
            ),
          ),
        ),
      ],
    );
  }
}