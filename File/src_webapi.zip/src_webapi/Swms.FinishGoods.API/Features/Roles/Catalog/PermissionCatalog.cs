using System.Reflection;
using System.Text;

namespace Swms.FinishGoods.Api.Features.Roles.Catalog;

/// <summary>
/// Catalog ĐỌC TỰ ĐỘNG từ cây <see cref="Perms"/> bằng reflection.
/// Không generator, không file sinh ra — Perms là nguồn sự thật duy nhất.
///
/// Cấu trúc đọc: Perms → (Module) → (Screen) → (Action = type lá).
///   module code = snake(Module.Name)
///   screen code = snake(Screen.Name)
///   perm   code = "{screenCode}.{snake(Action.Name)}"
/// </summary>
public static class PermissionCatalog
{
    public static IReadOnlyList<ModuleDef> Modules { get; } = Build();

    /// <summary>Tất cả permission code phẳng — "recv_pallet.view", "si.create"...</summary>
    public static IReadOnlyList<string> AllCodes { get; } =
        Modules.SelectMany(m => m.Screens)
               .SelectMany(s => s.Permissions.Select(p => p.Code))
               .ToList();

    private static readonly HashSet<string> _codeSet =
        new(AllCodes, StringComparer.OrdinalIgnoreCase);

    /// <summary>Map: type action lá → permission code. Dùng cho enforce strongly-typed.</summary>
    private static readonly Dictionary<Type, string> _typeToCode = BuildTypeMap();

    public static bool IsValid(string code) => _codeSet.Contains(code);

    public static IEnumerable<string> FilterValid(IEnumerable<string> codes) =>
        codes.Where(IsValid);

    /// <summary>Lấy permission code từ type action lá, vd CodeOf&lt;Perms.Receiving.Asn.Create&gt;().</summary>
    public static string CodeOf<TPermission>() where TPermission : class
        => CodeOf(typeof(TPermission));

    public static string CodeOf(Type permissionType)
        => _typeToCode.TryGetValue(permissionType, out var code)
            ? code
            : throw new ArgumentException(
                $"Type '{permissionType.FullName}' không phải một quyền hợp lệ trong Perms. " +
                $"Phải là type lá ở tầng action (vd Perms.Receiving.Asn.Create).");

    // ─────────────────────────── reflection ───────────────────────────

    private static IReadOnlyList<ModuleDef> Build()
    {
        var modules = new List<ModuleDef>();

        foreach (var moduleType in NestedTypes(typeof(Perms)))
        {
            var moduleCode = Snake(moduleType.Name);
            var screens = new List<ScreenDef>();

            foreach (var screenType in NestedTypes(moduleType))
            {
                var screenCode = Snake(screenType.Name);
                var perms = new List<PermDef>();

                foreach (var actionType in NestedTypes(screenType))
                {
                    var action = Snake(actionType.Name);
                    perms.Add(new PermDef(actionType, screenCode, action));
                }
                screens.Add(new ScreenDef(screenType, screenCode, perms));
            }
            modules.Add(new ModuleDef(moduleType, moduleCode, screens));
        }
        return modules;
    }

    private static Dictionary<Type, string> BuildTypeMap()
    {
        var map = new Dictionary<Type, string>();
        foreach (var m in Modules)
            foreach (var s in m.Screens)
                foreach (var p in s.Permissions)
                    map[p.Type] = p.Code;
        return map;
    }

    private static IEnumerable<Type> NestedTypes(Type t) =>
        t.GetNestedTypes(BindingFlags.Public);

    /// <summary>PascalCase → snake_case. "RecvPallet" → "recv_pallet", "ResetPwd" → "reset_pwd".</summary>
    internal static string Snake(string name)
    {
        var sb = new StringBuilder(name.Length + 4);
        for (int i = 0; i < name.Length; i++)
        {
            var c = name[i];
            if (char.IsUpper(c))
            {
                if (i > 0) sb.Append('_');
                sb.Append(char.ToLowerInvariant(c));
            }
            else sb.Append(c);
        }
        return sb.ToString();
    }
}

/// <summary>Module = cụm chức năng.</summary>
public sealed class ModuleDef
{
    public Type Type { get; }
    public string Code { get; }
    public IReadOnlyList<ScreenDef> Screens { get; }
    public string NameKey => $"Perm.Module.{Code}";

    public ModuleDef(Type type, string code, IEnumerable<ScreenDef> screens)
    {
        Type = type; Code = code; Screens = screens.ToList();
    }
}

/// <summary>Screen = màn hình thuộc module.</summary>
public sealed class ScreenDef
{
    public Type Type { get; }
    public string Code { get; }
    public IReadOnlyList<PermDef> Permissions { get; }
    public string NameKey => $"Perm.Screen.{Code}";

    public ScreenDef(Type type, string code, IEnumerable<PermDef> permissions)
    {
        Type = type; Code = code; Permissions = permissions.ToList();
    }
}

/// <summary>Quyền nguyên tử. Code = "{screen}.{action}".</summary>
public sealed class PermDef
{
    public Type Type { get; }                 // type lá, vd Perms.Receiving.Asn.Create
    public string ScreenCode { get; }
    public string Action { get; }
    public string Code { get; }               // "asn.create"
    public string NameKey => $"Perm.Item.{Code}";

    public PermDef(Type type, string screenCode, string action)
    {
        Type = type; ScreenCode = screenCode; Action = action;
        Code = $"{screenCode}.{action}";
    }
}