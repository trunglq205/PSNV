namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

/// <summary>
/// Một chỉ thị back hàng. Tên trường khớp JSON camelCase mà API trả về
/// (<c>ReturnInstructionResponse</c>) — Refit dùng System.Text.Json với chính
/// sách mặc định nên không cần khai thuộc tính đặt tên.
/// </summary>
public class ReturnInstructionDto
{
    public long Id { get; set; }

    /// <summary>RW-yyyyMMdd-### (rework) | RB-yyyyMMdd-### (refurbish).</summary>
    public string DocNo { get; set; } = string.Empty;

    /// <summary>
    /// rework | refurbish. MỘT PHIẾU MỘT LOẠI — loại nằm ở phiếu, không ở dòng.
    /// </summary>
    public string GoodsType { get; set; } = ReturnGoodsType.Rework;

    public string? Customer { get; set; }
    public DateTime? ExpectedDate { get; set; }

    /// <summary>open | completed | cancelled.</summary>
    public string DocStatus { get; set; } = ReturnDocStatus.Open;

    public string? Note { get; set; }
    public int ModelCount { get; set; }
    public int TotalQty { get; set; }

    /// <summary>SL thực nhận = số serial WH đã quét vào phiếu (mục 2a).</summary>
    public int ReceivedQty { get; set; }

    /// <summary>
    /// Có model nhận vượt SL chỉ thị. Cảnh báo, không phải lỗi — hàng về nhiều
    /// hơn khách báo là chuyện thường.
    /// </summary>
    public bool OverReceived { get; set; }

    /// <summary>Có model nhận thiếu. Cũng chỉ là cảnh báo.</summary>
    public bool ShortReceived { get; set; }

    /// <summary>Lệch cả phiếu = thực nhận − chỉ thị. Dương vượt, âm thiếu.</summary>
    public int DiffQty { get; set; }

    /// <summary>
    /// SL đang ở FA: mục 2c đã chỉ thị giao, FA chưa giao lại (mục 3). Con số
    /// quan trọng nhất của vòng đi–về — còn &gt; 0 là còn hàng ngoài kho.
    /// </summary>
    public int AtFaQty { get; set; }

    /// <summary>SL FA đã giao lại và SCS WH đã nhận (mục 3).</summary>
    public int ReturnedQty { get; set; }

    /// <summary>WH đã chốt SL thực nhận lúc nào. NULL = chưa chốt.</summary>
    public DateTime? ClosedAt { get; set; }
    public string? ClosedBy { get; set; }

    /// <summary>
    /// Đã báo FA SỐ THỰC NHẬN lúc nào — khác <see cref="MailSentAt"/> là mail
    /// lúc tạo phiếu.
    /// </summary>
    public DateTime? ActualMailSentAt { get; set; }
    public string? ActualMailSentTo { get; set; }

    /// <summary>Đã báo FA lúc nào. NULL = chưa gửi được, xem MailSentTo.</summary>
    public DateTime? MailSentAt { get; set; }
    public string? MailSentTo { get; set; }

    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }

    public List<ReturnInstructionLineDto> Lines { get; set; } = new();

    public bool IsOpen =>
        string.Equals(DocStatus, ReturnDocStatus.Open, StringComparison.OrdinalIgnoreCase);

    /// <summary>Đã đóng — mở lại được. Khác với đã huỷ.</summary>
    public bool IsCompleted =>
        string.Equals(DocStatus, ReturnDocStatus.Completed, StringComparison.OrdinalIgnoreCase);

    /// <summary>Đã nhận được hàng — điều kiện để chốt thực nhận.</summary>
    public bool HasReceipt => ReceivedQty > 0;

    /// <summary>
    /// Vòng đi–về với FA đã bắt đầu. Dùng để quyết định có hiện khối "Giao FA"
    /// hay không: phiếu chưa giao FA lần nào thì khối đó chỉ là ba số 0.
    /// </summary>
    public bool HasFaFlow => AtFaQty > 0 || ReturnedQty > 0;
}

public class ReturnInstructionLineDto
{
    public long Id { get; set; }
    public int LineNo { get; set; }
    public string Model { get; set; } = string.Empty;
    public int Qty { get; set; }

    /// <summary>SL thực nhận của model này — số serial đã quét vào phiếu.</summary>
    public int ReceivedQty { get; set; }

    /// <summary>Còn phải nhận. Âm = đã nhận vượt.</summary>
    public int RemainingQty { get; set; }

    /// <summary>Lệch = thực nhận − chỉ thị. Dương vượt, âm thiếu, 0 đủ.</summary>
    public int DiffQty { get; set; }

    /// <summary>SL của model này đang ở FA (mục 2c đã giao, chưa về).</summary>
    public int AtFaQty { get; set; }

    /// <summary>SL của model này FA đã giao lại và SCS đã nhận (mục 3).</summary>
    public int ReturnedQty { get; set; }

    public string? Note { get; set; }
}

/// <summary>
/// Một dòng nhật ký serial lệch (<c>wms.return_serial_mismatches</c>) — FA quét
/// ra con này khi đóng pallet ở mục 2d mà nó không khớp sổ của phiếu.
///
/// SCS cần nhìn thấy để đi tìm con hàng đó, rồi đánh dấu đã xử lý. KHÔNG chặn
/// FA đóng pallet: ghi lại rồi đi tiếp còn hơn bắt FA đứng chờ SCS.
/// </summary>
public class ReturnMismatchDto
{
    public long Id { get; set; }
    public long DocId { get; set; }

    /// <summary>Pallet FA đang đóng lúc quét ra con lệch. NULL = chưa cấp.</summary>
    public long? PalletId { get; set; }
    public string? LotNo { get; set; }

    public string Serial { get; set; } = string.Empty;

    /// <summary>Model tra được từ sổ. NULL với serial hoàn toàn lạ.</summary>
    public string? Model { get; set; }

    /// <summary>not_in_doc | wrong_status | other_doc — hậu tố khoá dịch.</summary>
    public string Reason { get; set; } = ReturnMismatchReason.NotInDoc;

    /// <summary>Trạng thái con đó đang mang, khi tra được.</summary>
    public string? FoundStatus { get; set; }

    /// <summary>Số phiếu đang giữ con này, với lý do <c>other_doc</c>.</summary>
    public string? OtherDocNo { get; set; }

    public DateTime ScannedAt { get; set; }
    public string? ScannedBy { get; set; }
    public DateTime? ResolvedAt { get; set; }
    public string? ResolvedBy { get; set; }
    public string? ResolveNote { get; set; }
    public bool IsResolved { get; set; }
}

/// <summary>Thân request đánh dấu đã xử lý một dòng nhật ký.</summary>
public class ResolveMismatchRequestDto
{
    public string? Note { get; set; }
}

/// <summary>
/// Giá trị cột <c>reason</c>, cũng là hậu tố khoá dịch
/// (<c>Return.Mismatch.Reason.*</c>).
/// </summary>
public static class ReturnMismatchReason
{
    /// <summary>Không có trong sổ của phiếu nào.</summary>
    public const string NotInDoc = "not_in_doc";

    /// <summary>Có trong phiếu này nhưng không ở <c>at_fa</c>.</summary>
    public const string WrongStatus = "wrong_status";

    /// <summary>Đang thuộc một phiếu khác.</summary>
    public const string OtherDoc = "other_doc";
}

/// <summary>
/// Một pallet hàng return WH đã nhận vào phiếu. Office chỉ XEM: pallet do WH
/// tạo trên PDA, màn Web không tạo được.
/// </summary>
public class ReturnPalletDto
{
    public long Id { get; set; }
    public string LotNo { get; set; } = string.Empty;
    public string? LocatorCode { get; set; }
    public int BoxCount { get; set; }
    public int SerialCount { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public List<ReturnPalletModelDto> Models { get; set; } = new();
}

public class ReturnPalletModelDto
{
    public string Model { get; set; } = string.Empty;
    public int SerialCount { get; set; }
}

/// <summary>Thân request tạo / sửa. Gửi nguyên danh sách dòng mong muốn.</summary>
public class ReturnInstructionRequestDto
{
    /// <summary>rework | refurbish. Khoá sau khi tạo — xem API.</summary>
    public string GoodsType { get; set; } = ReturnGoodsType.Rework;

    public string? Customer { get; set; }
    public DateTime? ExpectedDate { get; set; }
    public string? Note { get; set; }
    public List<ReturnInstructionLineRequestDto> Lines { get; set; } = new();
}

public class ReturnInstructionLineRequestDto
{
    public string Model { get; set; } = string.Empty;
    public int Qty { get; set; } = 1;
    public string? Note { get; set; }
}

/// <summary>
/// Giá trị cột <c>goods_type</c>, cũng là hậu tố khoá dịch
/// (<c>Return.GoodsType.*</c>). Trùng có chủ ý với
/// <c>wms.pallets.disposition</c> — xem ghi chú bên API.
/// </summary>
public static class ReturnGoodsType
{
    public const string Rework = "rework";
    public const string Refurbish = "refurbish";

    public static readonly string[] All = { Rework, Refurbish };
}

/// <summary>Giá trị cột <c>doc_status</c>, cũng là hậu tố khoá dịch.</summary>
public static class ReturnDocStatus
{
    public const string Open = "open";
    public const string Completed = "completed";
    public const string Cancelled = "cancelled";

    public static readonly string[] All = { Open, Completed, Cancelled };
}
