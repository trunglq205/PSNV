﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class DAItemDetailImport
    {
        /// <summary>
        /// DAItem
        /// </summary>
        public string? DAItem { get; set; }
        /// <summary>
        /// PONo
        /// </summary>
        public string? PONo { get; set; }
        /// <summary>
        /// POItem
        /// </summary>
        public string? POItem { get; set; }
        /// <summary>
        /// PlanQuantity
        /// </summary>
        public double PlanQuantity { get; set; }
        /// <summary>
        /// Status
        /// </summary>
        public int Status { get; set; }

    }
}
