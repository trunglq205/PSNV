﻿namespace SWMS_WebTool.Models.DataKitting
{
    public class DataKittingSubcon : DataKittingPL
    {
        public Int64 DataKittingSubconID { get; set; }
        public string ReceiptSloc { get; set; }
        public string MaterialDescription { get; set; }
        public DateTime? RequirementsDate { get; set; }
        public string PSNVStock { get; set; }
        public string KittingFrom { get; set; }
        public string KHFAN7 { get; set; }
        public string VenderName { get; set; }
    }
}
