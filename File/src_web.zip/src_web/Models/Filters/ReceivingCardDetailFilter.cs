﻿namespace SWMS_WebTool.Models.Filters
{
    public class ReceivingCardDetailFilter : BaseFilter
    {
        public DeliveryPlanType? Type { get; set; }
        public string? PO { get; set; }
        public string? POItem { get; set; }
        public string? DAItem { get; set; }
        public string? DANo { get; set; }
        public string? Material { get; set; }
    }
}
