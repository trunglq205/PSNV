using Swms.FinishGoods.Api.Features.Models.Api;
using Swms.FinishGoods.API.Common.Models; // PagedResult

namespace Swms.FinishGoods.Api.Features.Models.DataAccess;

public interface IModelRepository
{
    Task<ModelEntity?> GetByIdAsync(int id);
    Task<ModelEntity?> GetByCodeAsync(string code);
    Task<ModelEntity?> GetByGTINAsync(string gtin);

    /// <summary>Đọc đầy đủ các model theo danh sách mã (bỏ qua mã không tồn tại / đã soft-delete).</summary>
    Task<IReadOnlyList<ModelEntity>> GetByCodesAsync(IReadOnlyList<string> codes);

    Task<PagedResult<ModelEntity>> GetPagedAsync(ModelQuery query);
    Task<int> AddAsync(ModelEntity entity);
    Task AddManyAsync(IReadOnlyList<ModelEntity> entities);   // 1 transaction

    /// <summary>Insert mã mới + vá mã đã có (chỉ ghi field khác null của patch) trong 1 transaction.</summary>
    Task UpsertManyAsync(IReadOnlyList<ModelEntity> toInsert, IReadOnlyList<ModelImportPatch> toUpdate);

    Task UpdateAsync(ModelEntity entity);

    /// <summary>
    /// Partial update: chỉ ghi suggest_area + suggest_rack_row (+ updated_at/by).
    /// Trả về số dòng bị ảnh hưởng (0 = không tồn tại hoặc đã soft-delete).
    /// </summary>
    Task<int> UpdateSuggestionAsync(int id, int? suggestAreaId, string? suggestRackRow, string? updatedBy);

    Task SoftDeleteAsync(int id, string? deletedBy);

    // Check trùng code
    Task<bool> CodeExistsAsync(string code, int? excludeId);
    Task<bool> GtinExistsAsync(string code, int? excludeId);
    Task<IReadOnlyList<(int Id, string Code)>> GetExistingCodesAsync(IReadOnlyList<string> codes);
}