import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/repositories/shipment_instruction_repository.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/kitting_state.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_providers.dart';

part 'kitting_notifier.g.dart';

/// Màn Soạn hàng. Family theo [siId]:
///   - có siId (bấm "Soạn hàng" ở danh sách / chi tiết SI) → mở đúng SI đó.
///   - null (vào thẳng từ menu) → tự lấy SI đang soạn ĐẦU TIÊN.
@riverpod
class KittingNotifier extends _$KittingNotifier
    with BaseNotifierMixin<KittingState> {
  ShipmentInstructionRepository get _repo =>
      ref.read(shipmentInstructionRepositoryProvider);

  /// SI đã chọn tự động ở lần nạp đầu. Làm mới phải nạp lại ĐÚNG SI này —
  /// nếu tra lại "SI đang soạn đầu tiên" thì SI vừa soạn xong sẽ rời trạng
  /// thái picking, màn tự nhảy sang SI khác trước mắt thao tác viên.
  int? _resolvedId;

  @override
  KittingState build(int? siId) {
    Future.microtask(load);
    return const KittingState();
  }

  Future<void> load() => executePartial<ShipmentInstructionDetail?>(
    action: () async {
      final id = siId ?? _resolvedId ?? await _firstPickingId();
      if (id == null) return null;
      final detail = await _repo.getDetail(id);
      _resolvedId = detail.id;
      return detail;
    },
    getField: (s) => s.si,
    // Chỉ tính lại tuyến khi có dữ liệu mới. Lúc loading / lỗi giữ tuyến cũ,
    // để làm mới không làm nút đáy biến mất rồi hiện lại.
    setField: (s, f) => switch (f) {
      AsyncData(:final value) => s.copyWith(si: f, route: _buildRoute(value)),
      _ => s.copyWith(si: f),
    },
  );

  /// Tuyến = nhiệm vụ của mọi dòng.
  /// API có `seq` thì sắp theo đó; chưa có thì GIỮ NGUYÊN thứ tự API (trong
  /// 1 dòng server đang trả theo NSX cũ → mới, đúng FIFO). List.sort của Dart
  /// không ổn định, sort theo khoá toàn null sẽ xáo trộn thứ tự này.
  static List<PickTask> _buildRoute(ShipmentInstructionDetail? si) {
    if (si == null) return const [];
    final tasks = [for (final l in si.lines) ...l.tasks];
    if (tasks.every((t) => t.seq != null)) {
      tasks.sort((a, b) => a.seq!.compareTo(b.seq!));
    }
    return tasks;
  }

  /// SI đang soạn đầu tiên theo thứ tự mặc định của API danh sách.
  Future<int?> _firstPickingId() async {
    final page = await _repo.getList(
      status: SiStatus.picking,
      size: 1,
    );
    return page.items.isEmpty ? null : page.items.first.id;
  }
}
