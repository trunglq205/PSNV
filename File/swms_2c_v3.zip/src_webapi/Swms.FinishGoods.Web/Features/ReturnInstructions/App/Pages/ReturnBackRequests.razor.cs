using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Client;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.Auth;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.App.Pages;

public partial class ReturnBackRequests
{
    [Inject] private IReturnBackRequestBusiness Biz { get; set; } = default!;

    /// <summary>
    /// Danh sách chỉ thị nhận hàng cho ô chọn ở dialog soạn đề nghị. Gọi API
    /// chỉ thị trực tiếp — chỉ cần một danh sách đọc, không đáng dựng thêm một
    /// lớp business chỉ để bọc một lời gọi.
    /// </summary>
    [Inject] private IReturnInstructionApi DocApi { get; set; } = default!;

    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private PermissionState Perm { get; set; } = default!;

    // ───────────────────────────── Quyền ─────────────────────────────
    // GIỮ KHỚP TỪNG DÒNG với attribute trên ReturnBackRequestsController.
    // Lệch một chỗ là hoặc thấy nút rồi ăn 403, hoặc có quyền mà không thấy
    // nút — cả hai đều khó lần ra vì Has() trả false IM LẶNG.

    /// <summary>B1 — FA tạo / sửa đề nghị.</summary>
    private bool MayRequest => Perm.Has(Perms.rework_refurbish_request_back.Key());

    /// <summary>B2 — quản lý FA xác nhận.</summary>
    private bool MayApproveFa => Perm.Has(Perms.rework_refurbish_approve_fa.Key());

    /// <summary>B3 — SCS WH quét pallet giao hàng cho FA.</summary>
    private bool MayProcess => Perm.Has(Perms.rework_refurbish_process.Key());

    /// <summary>Quyen sua cau hinh email. Khong co thi banh rang khong hien.</summary>
    private bool MayEmailConfig => Perm.Has(Perms.email_config_update.Key());

    private bool _mailCfgOpen;

    // Nút = QUYỀN **AND** ĐÚNG BƯỚC. Lớp "đúng bước" là thứ làm cho xác nhận có
    // nghĩa: role khai sai cũng không nhảy được bước, và server còn chặn lần nữa
    // bằng điều kiện bước nằm trong câu UPDATE.

    /// <summary>
    /// Sửa: chỉ FA, chỉ khi còn chờ quản lý FA, và chỉ còn sửa được GHI CHÚ.
    /// Qua bước đó là SCS đã nhận mail với bảng số cụ thể.
    /// </summary>
    private bool CanEdit(ReturnBackRequestDto r)
        => r.IsOpen && r.CurrentStep == BackStep.FaApprove && MayRequest;

    private bool CanApproveFa(ReturnBackRequestDto r)
        => r.IsOpen && r.CurrentStep == BackStep.FaApprove && MayApproveFa;

    /// <summary>B3 — giao hàng. Gọi được NHIỀU LẦN: giao dần từng xe.</summary>
    private bool CanDeliver(ReturnBackRequestDto r)
        => r.IsOpen && r.CurrentStep == BackStep.ScsDeliver && MayProcess;

    /// <summary>
    /// Huỷ: ai đang giữ bước cũng phải dừng được, không phải chờ bên kia.
    /// ĐÃ GIAO ĐƯỢC CON NÀO thì KHÔNG huỷ được — hàng ở FA rồi, huỷ là để lại
    /// một lô hàng ở FA mà không có đề nghị nào đứng tên.
    /// </summary>
    private bool CanCancel(ReturnBackRequestDto r)
        => r.IsOpen && !r.IsPartlyDelivered
           && (MayRequest || MayApproveFa || MayProcess);

    // ───────────────────────── Tab hàng đợi ─────────────────────────

    /// <summary>
    /// Tab lọc theo BƯỚC (hai tab giữa) hoặc theo TRẠNG THÁI (hai tab cuối).
    /// Bước <c>done</c> gồm cả đã-giao-xong và đã-huỷ, nên hai cái đó phải lọc
    /// bằng status mới tách ra được.
    /// </summary>
    private sealed record TabDef(string Key, string LabelKey, string? Step, string? Status);

    private static readonly TabDef[] Tabs =
    {
        new("", "Return.Back.Tab.All", null, null),
        new("fa", "Return.Back.Tab.FaApprove", BackStep.FaApprove, null),
        new("wh", "Return.Back.Tab.ScsDeliver", BackStep.ScsDeliver, null),
        new("ok", "Return.Back.Tab.Delivered", null, BackStatus.Delivered),
        new("x", "Return.Back.Tab.Cancelled", null, BackStatus.Cancelled),
    };

    private string _tab = "";
    private string _keyword = "";

    private List<ReturnBackRequestDto> _all = new();
    private List<ReturnInstructionDto> _docs = new();

    /// <summary>
    /// Phần hàng sẽ lấy về của phiếu đang chọn — CHỈ ĐỂ XEM. Lấy là lấy hết nên
    /// đây đồng thời là đúng bảng dòng mà API sẽ dựng.
    /// </summary>
    private List<BackAvailableModelDto> _available = new();

    private bool _loading, _saving;
    private string? _error, _formError;
    private long? _expanded;

    /// <summary>
    /// Lọc tab ở CLIENT, không gọi lại API mỗi lần đổi tab: cả màn chỉ vài
    /// trăm dòng, mà đếm số trên tab thì buộc phải có toàn bộ dữ liệu — gọi
    /// API cho từng tab sẽ thành năm lượt gọi chỉ để vẽ năm con số.
    /// </summary>
    private List<ReturnBackRequestDto> Rows
    {
        get
        {
            var t = Tabs.FirstOrDefault(x => x.Key == _tab) ?? Tabs[0];
            return _all.Where(r => Match(r, t)).ToList();
        }
    }

    private static bool Match(ReturnBackRequestDto r, TabDef t)
        => (t.Step is null || r.CurrentStep == t.Step)
           && (t.Status is null || r.ReqStatus == t.Status);

    private int CountOf(string key)
    {
        var t = Tabs.FirstOrDefault(x => x.Key == key) ?? Tabs[0];
        return _all.Count(r => Match(r, t));
    }

    /// <summary>
    /// Đổi tab KHÔNG gọi lại API: dữ liệu đã có đủ, lọc ở client. Đóng dòng
    /// đang bung vì dòng đó gần như chắc chắn không thuộc tab mới.
    /// </summary>
    private void SwitchTab(string key)
    {
        if (_tab == key) return;
        _tab = key;
        _expanded = null;
    }

    private async Task OnKeyword(ChangeEventArgs e)
    {
        _keyword = e.Value?.ToString() ?? "";
        await Load();
    }

    protected override async Task OnInitializedAsync() => await Load();

    private async Task Load()
    {
        _loading = true;
        _error = null;
        StateHasChanged();
        try
        {
            // KHÔNG truyền step/status: tab lọc ở client để đếm được số trên tab.
            var res = await Biz.GetListAsync(keyword: _keyword);
            if (res.IsSuccess && res.Value is not null)
            {
                _all = res.Value;
                if (_expanded is { } id && _all.All(r => r.Id != id)) _expanded = null;
            }
            else
            {
                // Result<T> cua du an co ErrorMessage, KHONG co Message.
                // ErrorMessage co the null (vd ErrorCode.InvalidResponse) nen
                // phai co cau du phong, giong ListPageBase va man Storage.
                _error = res.ErrorMessage ?? L["Return.Back.LoadFailed"];
            }
        }
        finally
        {
            _loading = false;
            StateHasChanged();
        }
    }

    /// <summary>
    /// Bung dòng thì nạp luôn nhật ký pallet đã giao. Chỉ nạp khi bung, không
    /// nạp sẵn cho cả danh sách: màn có vài trăm dòng thì đó là vài trăm lượt
    /// gọi cho một bảng hầu như không ai mở.
    /// </summary>
    private async Task Toggle(long id)
    {
        if (_expanded == id)
        {
            _expanded = null;
            return;
        }
        _expanded = id;
        await LoadDeliveriesAsync(id);
    }

    private readonly Dictionary<long, List<BackDeliveryDto>> _deliveries = new();

    private async Task LoadDeliveriesAsync(long id)
    {
        var res = await Biz.GetDeliveriesAsync(id);
        _deliveries[id] = res.IsSuccess && res.Value is not null ? res.Value : new();
        StateHasChanged();
    }

    private List<BackDeliveryDto> DeliveriesOf(long id)
        => _deliveries.TryGetValue(id, out var v) ? v : new();

    // ─────────────────────── Nhãn + mốc thời gian ───────────────────────

    private string StepLabel(ReturnBackRequestDto r)
    {
        if (r.IsCancelled) return L["Return.Back.Step.Cancelled"];
        if (r.IsDelivered) return L["Return.Back.Step.Delivered"];
        return r.CurrentStep switch
        {
            BackStep.FaApprove => L["Return.Back.Step.FaApprove"],
            BackStep.ScsDeliver => L["Return.Back.Step.ScsDeliver"],
            _ => r.CurrentStep,
        };
    }

    private sealed record StepCell(string LabelKey, string Who, string State);

    /// <summary>
    /// Ba mốc của một đề nghị. Hiện cả người và lúc: "đang chờ SCS giao hàng" mà
    /// không biết chờ từ bao giờ thì không ai biết có phải đi nhắc hay không.
    ///
    /// Mốc cuối ghi "đang giao dở" khi đã giao được pallet nào mà chưa hết — một
    /// cột trống ở đó làm WH tưởng chưa ai làm gì và quét lại từ đầu.
    /// </summary>
    private List<StepCell> StepTrail(ReturnBackRequestDto r)
    {
        const string done = "done";
        const string wait = "wait";
        const string idle = "idle";

        string W(string? who, DateTime? at)
            => at is null ? "—" : $"{who} · {at:dd/MM HH:mm}";

        var faState = r.FaApprovedAt is not null ? done
            : r.CurrentStep == BackStep.FaApprove && r.IsOpen ? wait : idle;

        var dlState = r.IsDelivered ? done
            : r.CurrentStep == BackStep.ScsDeliver && r.IsOpen ? wait : idle;

        var dlWho = r.IsDelivered
            ? W(r.DeliveredBy, r.DeliveredAt)
            : r.IsPartlyDelivered
                ? L["Return.Back.Partly", r.AtFaQty, r.TotalQty].Value
                : "—";

        return
        [
            new("Return.Back.Step.Requested", W(r.RequestedBy, r.RequestedAt), done),
            new("Return.Back.Step.FaApprove", W(r.FaApprovedBy, r.FaApprovedAt), faState),
            new("Return.Back.Step.ScsDeliver", dlWho, dlState),
        ];
    }

    // ───────────────────── Dialog soạn / sửa ─────────────────────

    /// <summary>
    /// Bản nháp của dialog. KHÔNG có danh sách dòng: lấy là lấy HẾT nên model +
    /// SL do API suy từ phiếu, form chỉ CHO XEM qua <c>_available</c>.
    /// </summary>
    private sealed class FormModel
    {
        public long DocId { get; set; }
        public string ReqNo { get; set; } = "";
        public string? Note { get; set; }
    }

    private FormModel? _form;
    private long? _editId;

    /// <summary>Tổng SL sẽ lấy về — cộng từ bảng xem trước, không ai nhập.</summary>
    private int FormTotalQty => _available.Sum(a => a.AvailableQty);

    /// <summary>
    /// Lưu được khi: đã chọn phiếu và phiếu đó CÒN hàng ở kho. Không còn điều
    /// kiện nào về dòng — không ai nhập dòng nữa.
    ///
    /// Khi SỬA thì chỉ còn ghi chú, nên luôn lưu được.
    /// </summary>
    private bool CanSubmitForm
        => _editId is not null || (_form is { DocId: > 0 } && _available.Count > 0);

    private async Task OpenCreate()
    {
        _editId = null;
        _formError = null;
        _available = new();
        _form = new FormModel();
        await LoadDocsAsync();
    }

    private async Task OpenEdit(ReturnBackRequestDto r)
    {
        _editId = r.Id;
        _formError = null;
        _form = new FormModel
        {
            DocId = r.DocId,
            ReqNo = r.ReqNo,
            Note = r.Note,
        };
        // Bảng xem trước khi sửa lấy từ ĐỀ NGHỊ, không từ kho: sau khi tạo, kho
        // đã trừ phần này ra nên gọi available sẽ ra một bảng khác hẳn — và đó
        // là bảng của lần tạo sau, không phải của đề nghị đang sửa.
        _available = r.Lines
            .Select(l => new BackAvailableModelDto { Model = l.Model, AvailableQty = l.Qty })
            .ToList();
    }

    private void CloseForm()
    {
        _form = null;
        _editId = null;
        _formError = null;
    }

    /// <summary>
    /// Chỉ liệt kê phiếu CÒN MỞ hoặc đã chốt — phiếu huỷ thì server cũng chặn,
    /// nên đưa vào danh sách chỉ để người dùng chọn rồi ăn lỗi.
    /// </summary>
    private async Task LoadDocsAsync()
    {
        try
        {
            var all = await DocApi.GetListAsync();
            _docs = all.Where(d => !string.Equals(
                d.DocStatus, ReturnDocStatus.Cancelled, StringComparison.OrdinalIgnoreCase))
                .ToList();
        }
        catch (Exception ex) { _formError = Describe(ex); }
    }

    private async Task LoadAvailableAsync(long docId)
    {
        var res = await Biz.GetAvailableAsync(docId);
        _available = res.IsSuccess && res.Value is not null
            ? res.Value.Where(a => a.AvailableQty > 0)
                       .OrderBy(a => a.Model, StringComparer.OrdinalIgnoreCase).ToList()
            : new();
        if (!res.IsSuccess) _formError = res.ErrorMessage ?? L["Return.Back.LoadFailed"];
    }

    private async Task OnDocChanged(ChangeEventArgs e)
    {
        if (_form is null) return;
        _form.DocId = long.TryParse(e.Value?.ToString(), out var id) ? id : 0;
        _available = new();
        if (_form.DocId > 0) await LoadAvailableAsync(_form.DocId);
    }

    private async Task SubmitForm()
    {
        if (_form is null || !CanSubmitForm) return;
        _saving = true;
        _formError = null;
        StateHasChanged();
        try
        {
            var res = _editId is { } id
                ? await Biz.UpdateAsync(id, new UpdateBackRequestRequestDto { Note = _form.Note })
                : await Biz.CreateAsync(new CreateBackRequestRequestDto
                {
                    DocId = _form.DocId,
                    Note = _form.Note,
                });

            if (!res.IsSuccess)
            {
                _formError = res.ErrorMessage ?? L["Return.Back.SaveFailed"];
                return;
            }

            CloseForm();
            await Load();
        }
        finally
        {
            _saving = false;
            StateHasChanged();
        }
    }

    // ───────────────────── Dialog xác nhận / huỷ ─────────────────────

    private enum BackAction { ApproveFa, Cancel }

    private ReturnBackRequestDto? _asking;
    private BackAction _action;
    private string? _comment;

    private string AskTitleKey => _action == BackAction.ApproveFa
        ? "Return.Back.ApproveFaTitle"
        : "Return.Back.CancelTitle";

    private string AskConfirmKey => _action == BackAction.ApproveFa
        ? "Return.Back.ApproveFa"
        : "Return.Back.Cancel";

    private void Ask(ReturnBackRequestDto r, BackAction action)
    {
        _asking = r;
        _action = action;
        _comment = null;
        _formError = null;
    }

    private void CloseAsk()
    {
        _asking = null;
        _formError = null;
    }

    private async Task ConfirmAsk()
    {
        if (_asking is null) return;
        var id = _asking.Id;
        _saving = true;
        _formError = null;
        StateHasChanged();
        try
        {
            var res = _action == BackAction.ApproveFa
                ? await Biz.ApproveFaAsync(id, _comment)
                : await Biz.CancelAsync(id, _comment);

            if (!res.IsSuccess)
            {
                // Lỗi hay gặp nhất ở đây là "có người vừa xử lý trước" (409).
                // Giữ dialog mở để người dùng đọc được câu đó, rồi tải lại
                // danh sách để họ thấy trạng thái mới.
                _formError = res.ErrorMessage ?? L["Return.Back.SaveFailed"];
                await Load();
                return;
            }

            CloseAsk();
            await Load();
        }
        finally
        {
            _saving = false;
            StateHasChanged();
        }
    }

    // ───────────────────── Dialog giao hàng (B3) ─────────────────────
    //
    // Chỗ QUÉT thật là PDA — WH đứng cạnh pallet với máy quét. Dialog này là
    // đường NHẬP TAY cho văn phòng: dán danh sách Pallet ID, mỗi dòng một mã.
    // Vẫn gọi đúng endpoint của PDA nên hai đường không lệch nghiệp vụ.

    private ReturnBackRequestDto? _delivering;
    private string _lotText = "";
    private string? _deliverComment;
    private BackDeliverResultDto? _deliverResult;

    /// <summary>
    /// Mỗi dòng một mã. Tách theo dòng chứ không theo dấu phẩy: máy quét và
    /// Excel đều xuống dòng, còn Pallet ID thì không chứa dấu phẩy nên tách
    /// kiểu kia chỉ thêm cách gõ sai.
    /// </summary>
    private List<string> ParsedLots
        => _lotText.Split(['\n', '\r'], StringSplitOptions.RemoveEmptyEntries)
            .Select(x => x.Trim())
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

    private async Task OpenDeliver(ReturnBackRequestDto r)
    {
        _delivering = r;
        _lotText = "";
        _deliverComment = null;
        _deliverResult = null;
        _formError = null;
        await LoadDeliveriesAsync(r.Id);
    }

    private void CloseDeliver()
    {
        _delivering = null;
        _deliverResult = null;
        _formError = null;
    }

    private async Task ConfirmDeliver()
    {
        if (_delivering is null) return;
        var lots = ParsedLots;
        if (lots.Count == 0) return;

        var id = _delivering.Id;
        _saving = true;
        _formError = null;
        _deliverResult = null;
        StateHasChanged();
        try
        {
            var res = await Biz.DeliverAsync(id, lots, _deliverComment);

            if (!res.IsSuccess || res.Value is null)
            {
                _formError = res.ErrorMessage ?? L["Return.Back.SaveFailed"];
                return;
            }

            _deliverResult = res.Value;
            _lotText = "";

            // Giao XONG cả đề nghị thì đóng dialog — không còn gì để quét.
            // Còn dở dang thì GIỮ MỞ kèm kết quả lượt vừa rồi: WH quét tiếp xe
            // sau, và đóng lại rồi mở ra là mất luôn danh sách mã vừa sai.
            await Load();
            await LoadDeliveriesAsync(id);

            if (_deliverResult.Completed)
            {
                CloseDeliver();
                return;
            }

            _delivering = _all.FirstOrDefault(x => x.Id == id) ?? _delivering;
        }
        finally
        {
            _saving = false;
            StateHasChanged();
        }
    }

    private static string Describe(Exception ex) =>
        ex is Refit.ApiException api && !string.IsNullOrWhiteSpace(api.Content)
            ? ExtractTitle(api.Content) ?? api.Message
            : ex.Message;

    private static string? ExtractTitle(string content)
    {
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(content);
            return doc.RootElement.TryGetProperty("title", out var t) ? t.GetString() : null;
        }
        catch { return null; }
    }
}
