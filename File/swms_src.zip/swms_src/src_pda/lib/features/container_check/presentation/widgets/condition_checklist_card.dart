import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/container_check/domain/entities/container_inspection.dart';
import 'package:swms_finish_goods/features/container_check/presentation/widgets/inspect_section_header.dart';

class ConditionChecklistCard extends StatelessWidget {
  final Set<ContainerCondition> checked;

  /// null = chỉ xem.
  final ValueChanged<ContainerCondition>? onToggle;

  const ConditionChecklistCard({
    super.key,
    required this.checked,
    required this.onToggle,
  });

  @override
  Widget build(BuildContext context) {
    const all = ContainerCondition.values;
    return AppCard(
      padding: const EdgeInsets.all(AppDimens.sm + 4),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          InspectSectionHeader(
            title: LocaleKeys.container_check_conditions.tr(),
            done: checked.length,
            total: all.length,
          ),
          for (final cond in all)
            _ConditionRow(
              label: cond.labelKey.tr(),
              checked: checked.contains(cond),
              onTap: onToggle == null ? null : () => onToggle!(cond),
            ),
        ],
      ),
    );
  }
}

class _ConditionRow extends StatelessWidget {
  final String label;
  final bool checked;
  final VoidCallback? onTap;

  const _ConditionRow({required this.label, required this.checked, this.onTap});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(AppDimens.rInput),
      child: ConstrainedBox(
        // Cả dòng là vùng chạm, không chỉ ô tick — tay đeo găng.
        constraints: const BoxConstraints(minHeight: AppDimens.hitSm),
        child: Row(
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 120),
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                color: checked ? c.success : Colors.transparent,
                border: Border.all(
                  color: checked ? c.success : c.border2,
                  width: 1.5,
                ),
                borderRadius: BorderRadius.circular(6),
              ),
              child: checked
                  ? const Icon(Icons.check_rounded, size: 14, color: Colors.white)
                  : null,
            ),
            const SizedBox(width: 10),
            Expanded(
              child: Text(
                label,
                style: AppTextStyles.body.copyWith(
                  color: onTap == null && !checked ? c.text3 : c.text1,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
