import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/model/data/model_detail_model.dart';

part 'model_detail_remote_data_source.g.dart';

@RestApi()
abstract class ModelDetailRemoteDataSource {
  factory ModelDetailRemoteDataSource(Dio dio, {String baseUrl}) =
      _ModelDetailRemoteDataSource;

  /// Chi tiết model theo id (Quick Scan đã resolve code/GTIN → id).
  @GET('/api/models/{id}')
  Future<ModelDetailModel> fetchModelDetail(@Path('id') int id);

  /// Chỉnh sửa model. API trả 204 NoContent — muốn bản mới phải GET lại.
  @PUT('/api/models/{id}')
  Future<void> updateModel(@Path('id') int id, @Body() ModelUpdateRequest body);

  /// Cập nhật riêng gợi ý lưu kho (khu + tầng rack). null = xoá gợi ý.
  @PATCH('/api/models/{id}/suggestion')
  Future<ModelDetailModel> patchSuggestion(
    @Path('id') int id,
    @Body() ModelSuggestionPatchRequest body,
  );
}
