using Swms.FinishGoods.Web.Extensions;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Client;
using Swms.FinishGoods.Web.Shared.Client.Http;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions;

public static class ReturnInstructionModule
{
    public static IServiceCollection AddReturnInstructionFeature(
        this IServiceCollection services, ApiClientContext api)
    {
        services.AddApiClient<IReturnInstructionApi>(api);

        // Cấu hình email của riêng màn Tái gia công. Gọi endpoint dùng chung
        // /api/email-configs/* nhưng qua client riêng, để không phụ thuộc vào
        // bộ IEmailConfigApi đang nằm trong Features/Shortages (bộ đó còn viết
        // cứng module "SHIP" nên không liệt kê được sự kiện của màn này).
        services.AddApiClient<IReturnMailConfigApi>(api);
        services.AddScoped<IReturnMailConfigBusiness, ReturnMailConfigBusiness>();

        return services;
    }
}
