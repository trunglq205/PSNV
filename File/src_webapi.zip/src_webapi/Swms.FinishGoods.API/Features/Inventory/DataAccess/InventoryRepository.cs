using Dapper;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Inventory.Api;
using Swms.FinishGoods.API.Features.Inventory.Business.Entities;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Inventory.DataAccess
{
    /// <summary>
    /// Tồn kho = wms.pallets đang active (is_deleted = 0) + vị trí hiện tại.
    /// Nguồn vị trí: pallets.locator_id → master.locators (loc) → master.warehouse_areas (wa)
    /// → master.warehouses (wh). locators KHÔNG có warehouse_id trực tiếp — phải đi qua area_id
    /// của warehouse_areas rồi mới tới warehouse_id. locators dùng cột slot_kind (không phải
    /// locator_type) để phân storage | staging | reserve | vanning | production.
    /// Khi luồng xuất hàng bổ sung cờ "đã xuất" cho pallet, thêm điều kiện đó vào <see cref="InStockFilter"/>.
    ///
    /// Tối ưu (fix timeout khi search Model):
    ///  - 4 subquery tương quan (BoxCount / TotalQty / PrimaryModel / HasSerial) gộp thành 1 OUTER APPLY.
    ///  - Filter Model chỉ ghép vào SQL khi có giá trị, lọc bằng tập lot_id (quét box_lines 1 lần)
    ///    thay cho OR + EXISTS chạy lại cho từng pallet.
    ///  - @ModelLike gửi dạng varchar (IsAnsi) → không CONVERT_IMPLICIT trên cột varchar.
    ///  - COUNT không cần cột tính sẵn khi không lọc Area/Qty.
    ///  - OPTION (RECOMPILE) cho query catch-all (@X IS NULL OR ...).
    /// </summary>
    public class InventoryRepository : IInventoryRepository
    {
        private readonly IDbConnectionFactory _factory;
        public InventoryRepository(IDbConnectionFactory factory) => _factory = factory;

        // ── Quy ước map kho / khu → area key ─────────────────────────
        // Kho thành phẩm "nhà" duy nhất là SCS (master.warehouses hiện chỉ có
        // SCS · JUPITER · FA · MCS — không có PAPVN). FA/MCS là kho ngoài (borrowed),
        // mỗi kho có area riêng cùng area_code (xem master.warehouse_areas). Đổi tại
        // đây nếu master.warehouses thêm kho "nhà" khác.
        private const string HomeWarehouseCodes = "'SCS'";
        private const string JupiterWarehouseCode = "'JUPITER'";

        // Điểm nối cho cờ "đã xuất kho" sau này (vd: AND l.shipped_at IS NULL).
        private const string InStockFilter = "";

        /// <summary>Biểu thức SQL tính khu vực của 1 pallet (alias l/loc/wa/wh phải có sẵn trong FROM).</summary>
        private const string AreaKeyExpr = $"""
            CASE
                WHEN l.locator_id IS NULL AND l.si_no IS NOT NULL      THEN 'customer'
                WHEN l.locator_id IS NULL                              THEN 'fa'
                WHEN UPPER(wa.area_code) = 'RECEIVING'                 THEN 'receiving'
                WHEN UPPER(wa.area_code) = 'VANNING'                   THEN 'vanning'
                ELSE 'storing'
            END
            """;

        private const string FromJoins = """
            FROM wms.pallets l
            JOIN master.categories c            ON c.code = l.category_id
            LEFT JOIN master.locators loc       ON loc.id = l.locator_id AND loc.is_deleted = 0
            LEFT JOIN master.warehouse_areas wa ON wa.id = loc.area_id AND wa.is_deleted = 0
            LEFT JOIN master.warehouses wh      ON wh.id = wa.warehouse_id AND wh.is_deleted = 0
            """;

        /// <summary>
        /// Gom mọi số liệu từ boxes/box_lines của 1 pallet trong 1 lần đọc
        /// (trước đây là 4 subquery riêng → đọc box_lines 4 lần / pallet).
        /// </summary>
        private const string AggApply = """
            OUTER APPLY (
                SELECT COUNT(DISTINCT lb.id)                                     AS BoxCnt,
                       SUM(bl.qty)                                               AS SumQty,
                       MIN(bl.model)                                             AS FirstModel,
                       MAX(CASE WHEN bl.serial_no IS NOT NULL THEN 1 ELSE 0 END) AS AnySerial
                FROM wms.boxes lb
                LEFT JOIN wms.box_lines bl ON bl.box_id = lb.id AND bl.is_deleted = 0
                WHERE lb.lot_id = l.id AND lb.is_deleted = 0
            ) agg
            """;

        /// <summary>
        /// Chỉ ghép khi có Model. Lấy tập lot_id khớp model 1 lần (pallet-level + box-level)
        /// rồi IN — thay cho OR + EXISTS chạy lại cho từng pallet.
        /// </summary>
        private static string ModelFilter(InventoryQuery q) => string.IsNullOrWhiteSpace(q.Model) ? "" : """
            AND l.id IN (
                SELECT p2.id
                FROM wms.pallets p2
                WHERE p2.is_deleted = 0 AND p2.model LIKE @ModelLike
                UNION
                SELECT b.lot_id
                FROM wms.box_lines bl
                JOIN wms.boxes b ON b.id = bl.box_id AND b.is_deleted = 0
                WHERE bl.is_deleted = 0 AND bl.model LIKE @ModelLike)
            """;

        /// <summary>
        /// Lọc chọn nhiều: chỉ ghép khi có giá trị (như ModelFilter) — không chọn gì thì không có
        /// điều kiện, giữ được kế hoạch truy vấn gọn thay vì "@X IS NULL OR ...".
        /// </summary>
        private static string InFilter(int count, string condition) => count == 0 ? "" : $"AND {condition}";

        /// <summary>
        /// SAP: 0 = chưa đẩy. Bản ghi cũ để sap_status NULL cũng hiển thị là "chưa đẩy" trên Web,
        /// nên chọn 0 thì lấy cả NULL — trước đây lọc "= 0" làm sót các pallet này.
        /// </summary>
        private static string SapFilter(InventoryQuery q)
        {
            if (q.SapStatusList.Count == 0) return "";
            var orNull = q.SapStatusList.Contains(0) ? " OR l.sap_status IS NULL" : "";
            return $"AND (l.sap_status IN @SapStatusList{orNull})";
        }

        /// <summary>WHERE chung (chỉ dùng alias l, c) — dùng cho cả BaseSelect và COUNT rút gọn.</summary>
        private static string WhereClause(InventoryQuery q) => $"""
            WHERE l.is_deleted = 0
              {InStockFilter}
              AND (@LotNo            IS NULL OR l.pallet_id LIKE '%' + @LotNo + '%' OR l.stocky_code LIKE '%' + @LotNo + '%' )
              {InFilter(q.CategoryList.Count, "c.code IN @CategoryList")}
              AND (@LotType          IS NULL OR l.lot_type = @LotType)
              AND (@StockyCode       IS NULL OR l.stocky_code = @StockyCode)
              AND (@DetailLevel      IS NULL OR l.detail_level = @DetailLevel)
              {InFilter(q.InspectionList.Count, "l.inspection_status IN @InspectionList")}
              AND (@IsUrgent         IS NULL OR l.is_urgent = @IsUrgent)
              AND (@LocatorId        IS NULL OR l.locator_id = @LocatorId)
              AND (@ProductionFrom   IS NULL OR l.production_date >= @ProductionFrom)
              AND (@ProductionTo     IS NULL OR l.production_date <= @ProductionTo)
              AND (@CreatedFrom IS NULL OR l.created_at >= CAST(@CreatedFrom AS date))
              AND (@CreatedTo   IS NULL OR l.created_at <  DATEADD(day, 1, CAST(@CreatedTo AS date)))
              {SapFilter(q)}
              AND (@SapPushed        IS NULL
                   OR (@SapPushed = 1 AND l.sap_pushed_at IS NOT NULL)
                   OR (@SapPushed = 0 AND l.sap_pushed_at IS NULL))
              AND (@SapPushedFrom IS NULL OR l.sap_pushed_at >= CAST(@SapPushedFrom AS date))
              AND (@SapPushedTo   IS NULL OR l.sap_pushed_at <  DATEADD(day, 1, CAST(@SapPushedTo AS date)))
              {ModelFilter(q)}
              AND (@BoxOrSerial IS NULL
                   OR EXISTS (SELECT 1 FROM wms.boxes b
                              LEFT JOIN wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                              WHERE b.lot_id = l.id AND b.is_deleted = 0
                                AND (b.box_no LIKE '%' + @BoxOrSerial + '%'
                                  OR bl.serial_no LIKE '%' + @BoxOrSerial + '%')))
            """;

        /// <summary>
        /// Subquery "base": mọi pallet đang tồn + cột tính sẵn. Area/Qty lọc ở lớp ngoài
        /// (<see cref="OuterFilter"/>) vì cần cột tính sẵn.
        /// </summary>
        private static string BaseSelect(InventoryQuery q) => $"""
            SELECT
                l.id                AS Id,
                l.pallet_id         AS LotNo,
                c.code              AS CategoryCode,
                c.name              AS CategoryName,
                l.lot_type          AS LotType,
                l.stocky_code       AS StockyCode,
                l.si_no             AS SiNo,
                l.locator_id        AS LocatorId,
                loc.locator_code    AS LocatorCode,
                wa.area_code        AS AreaCode,
                l.detail_level      AS DetailLevel,
                COALESCE(l.box_count, agg.BoxCnt) AS BoxCount,
                l.standard_packing  AS StandardPacking,
                l.model             AS Model,
                l.inspection_status AS InspectionStatus,
                l.is_urgent         AS IsUrgent,
                l.production_date   AS ProductionDate,
                l.sap_status        AS SapStatus,
                l.sap_pushed_at     AS SapPushedAt,
                l.is_deleted        AS IsDeleted,
                l.created_at        AS CreatedAt,
                l.created_by        AS CreatedBy,
                l.updated_at        AS UpdatedAt,
                l.updated_by        AS UpdatedBy,
                CASE
                    WHEN l.detail_level = 'box_count'
                        THEN COALESCE(l.box_count, 0) * COALESCE(l.standard_packing, 0)
                    ELSE COALESCE(agg.SumQty, 0)
                END                 AS TotalQtySql,
                {AreaKeyExpr}       AS AreaKey,
                loc.locator_code    AS LocatorName,
                loc.slot_kind       AS LocatorType,
                wh.code             AS WarehouseCode,
                CASE WHEN wh.code IS NOT NULL
                      AND wh.code NOT IN ({HomeWarehouseCodes})
                      AND wh.code <> {JupiterWarehouseCode}
                     THEN wh.code END                                   AS BorrowedFrom,
                CAST(CASE WHEN wh.code = {JupiterWarehouseCode} THEN 1 ELSE 0 END AS bit) AS IsHeavy,
                CAST(CASE WHEN l.detail_level = 'serial' OR agg.AnySerial = 1
                     THEN 1 ELSE 0 END AS bit)                          AS HasSerial,
                COALESCE(l.model, agg.FirstModel)                       AS PrimaryModel
            {FromJoins}
            {AggApply}
            {WhereClause(q)}
            """;

        // Lọc lớp ngoài trên cột tính sẵn.
        private const string OuterFilter = """
            WHERE (@Area   IS NULL OR x.AreaKey = @Area)
              AND (@QtyMin IS NULL OR x.TotalQtySql >= @QtyMin)
              AND (@QtyMax IS NULL OR x.TotalQtySql <= @QtyMax)
            """;

        private static bool NeedsOuterFilter(InventoryQuery q, bool ignoreArea = false) =>
            (!ignoreArea && q.Area != null) || q.QtyMin != null || q.QtyMax != null;

        // Mọi @param trong SQL phải có mặt, thiếu 1 là SQL Server báo lỗi.
        private static object Params(InventoryQuery q, string? areaOverride = null, bool ignoreArea = false) => new
        {
            q.Page,
            q.Size,
            q.LotNo,
            q.CategoryList,
            // Gửi varchar (IsAnsi) để không CONVERT_IMPLICIT trên cột model varchar.
            // Nếu nghiệp vụ chấp nhận tìm theo đầu chuỗi, đổi thành q.Model.Trim() + "%"
            // để seek được index IX_box_lines_model.
            ModelLike = string.IsNullOrWhiteSpace(q.Model)
                ? null
                : new DbString { Value = "%" + q.Model.Trim() + "%", IsAnsi = true, Length = 200 },
            q.LotType,
            q.StockyCode,
            q.DetailLevel,
            q.InspectionList,
            q.IsUrgent,
            q.LocatorId,
            q.ProductionFrom,
            q.ProductionTo,
            q.CreatedFrom,
            q.CreatedTo,
            q.SapStatusList,
            q.SapPushed,
            q.SapPushedFrom,
            q.SapPushedTo,
            q.BoxOrSerial,
            Area = ignoreArea ? null : (areaOverride ?? q.Area),
            q.QtyMin,
            q.QtyMax,
        };

        // ── Danh sách ─────────────────────────────────────────────────
        public async Task<PagedResult<InventoryItem>> GetPagedAsync(InventoryQuery query, string orderBy)
        {
            using var conn = _factory.Create();

            // Không lọc Area/Qty → COUNT không cần tính AreaKey/TotalQty/OUTER APPLY.
            var countSql = NeedsOuterFilter(query)
                ? $"""
                  SELECT COUNT(*) FROM ({BaseSelect(query)}) x
                  {OuterFilter}
                  OPTION (RECOMPILE);
                  """
                : $"""
                  SELECT COUNT(*)
                  {FromJoins}
                  {WhereClause(query)}
                  OPTION (RECOMPILE);
                  """;

            var sql = $"""
                SELECT x.* FROM ({BaseSelect(query)}) x
                {OuterFilter}
                ORDER BY {orderBy}
                OFFSET (@Page - 1) * @Size ROWS FETCH NEXT @Size ROWS ONLY
                OPTION (RECOMPILE);

                {countSql}
                """;

            using var multi = await conn.QueryMultipleAsync(sql, Params(query));
            var items = (await multi.ReadAsync<InventoryItem>()).ToList();
            var total = await multi.ReadFirstAsync<int>();
            return new PagedResult<InventoryItem>(items, total, query.Page, query.Size);
        }

        // ── Card khu vực ──────────────────────────────────────────────
        public async Task<IReadOnlyList<InventoryAreaStat>> GetAreaStatsAsync(InventoryQuery query)
        {
            using var conn = _factory.Create();
            var sql = $"""
                SELECT x.AreaKey                     AS AreaKey,
                       COUNT(*)                      AS PalletCount,
                       SUM(x.BoxCount)               AS BoxCount,
                       SUM(x.TotalQtySql)            AS TotalQty,
                       COUNT(DISTINCT x.PrimaryModel) AS ModelCount
                FROM ({BaseSelect(query)}) x
                {OuterFilter}
                GROUP BY x.AreaKey
                OPTION (RECOMPILE);
                """;
            // Bỏ Area để 5 card luôn thấy đủ số nhau.
            return (await conn.QueryAsync<InventoryAreaStat>(sql, Params(query, ignoreArea: true))).ToList();
        }

        // ── Aging ─────────────────────────────────────────────────────
        public async Task<IReadOnlyList<InventoryAgingBucket>> GetAgingAsync(InventoryQuery query)
        {
            using var conn = _factory.Create();
            var sql = $"""
                WITH aged AS (
                    SELECT x.TotalQtySql,
                           DATEDIFF(day, x.ProductionDate, CAST(SYSDATETIME() AS date)) AS AgeDays
                    FROM ({BaseSelect(query)}) x
                    {OuterFilter}
                      AND x.ProductionDate IS NOT NULL
                )
                SELECT b.[Key], b.FromDays, b.ToDays,
                       COUNT(a.AgeDays)               AS PalletCount,
                       COALESCE(SUM(a.TotalQtySql), 0) AS TotalQty
                FROM (VALUES
                        ('lt30',   0,  29,   1),
                        ('d30_60', 30, 59,   2),
                        ('d60_90', 60, 89,   3),
                        ('gt90',   90, NULL, 4)) b([Key], FromDays, ToDays, Ord)
                LEFT JOIN aged a
                       ON a.AgeDays >= b.FromDays
                      AND (b.ToDays IS NULL OR a.AgeDays <= b.ToDays)
                GROUP BY b.[Key], b.FromDays, b.ToDays, b.Ord
                ORDER BY b.Ord
                OPTION (RECOMPILE);
                """;
            return (await conn.QueryAsync<InventoryAgingBucket>(sql, Params(query))).ToList();
        }
    }
}