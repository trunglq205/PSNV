// ─────────────────────────────────────────────────────────────
//  Entities cho feature Receiving (Nhận hàng · Quét & đối chiếu).
//  Quy trình 3 bước: Quét Pallet → Xác nhận → Quét vị trí.
// ─────────────────────────────────────────────────────────────

/// Phương thức nhận hàng người dùng chọn ở bước 1.
enum ReceivingMode {
  /// Quét Box — quét mã trên thùng hàng.
  box,

  /// Quét Material — quét mã hàng.
  model,

  /// Quét GTIN — quét mã vạch GTIN-14 trên thùng,
  /// sau đó map sang mã model tương ứng (VD: 14549980636876 -> VS-SGZ20L).
  gtin,
}

/// Ba bước của quy trình nhận hàng (1-based khi hiển thị).
enum ReceivingStep {
  scan, // 1
  confirm, // 2
  scanPallet, // 3
}

extension ReceivingStepX on ReceivingStep {
  /// Số thứ tự 1-based dùng cho step bar.
  int get number => index + 1;

  static ReceivingStep fromNumber(int n) =>
      ReceivingStep.values[(n - 1).clamp(0, ReceivingStep.values.length - 1)];
}

/// Dữ liệu một pallet sau khi quét/đối chiếu (bước 2).
/// Các trường *Key là LocaleKeys — UI gọi .tr() khi render.
class ReceivingPallet {
  final String palletId; // "PLT-RECV-101A"
  final String poCode; // mã PO / lô
  final String itemName; // tên hàng (động, không dịch)
  final int scanned; // số thùng đã quét
  final int expected; // số thùng dự kiến

  const ReceivingPallet({
    required this.palletId,
    required this.poCode,
    required this.itemName,
    required this.scanned,
    required this.expected,
  });

  double get progress => expected == 0 ? 0 : scanned / expected;

  bool get isComplete => scanned >= expected && expected > 0;
}
