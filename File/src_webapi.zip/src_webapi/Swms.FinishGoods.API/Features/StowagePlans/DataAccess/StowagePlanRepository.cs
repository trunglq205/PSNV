using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.StowagePlans.DataAccess;

/*  Bảng: wms.stowage_plans, stowage_plan_sis, stowage_plan_containers, stowage_columns,
          stowage_pallets, stowage_pallet_boxes (script 2026-10-29_stowage_plan.sql).
    Màn Stowage Plan hiện = chuyến xe (container: FCL; xe tải: AIR / LCL): plan gắn chuyến qua container #0
    (stowage_plan_containers.trip_id). Plan không gắn chuyến vẫn đọc / lưu được (lập theo order sau này). */
public class StowagePlanRepository : IStowagePlanRepository
{
    private readonly IDbConnectionFactory _factory;

    public StowagePlanRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    // SI trên chuyến / plan: destination ưu tiên header_note.destination, không có thì cảng dỡ
    private const string SiColumns = """
        s.id AS SiId, s.si_no AS SiNo, s.consignee_code AS ConsigneeCode, s.ship_mode AS ShipMode,
        s.forwarder_code AS ForwarderCode, s.etd_date AS EtdDate, s.vanning_date AS VanningDate,
        COALESCE(JSON_VALUE(s.header_note, '$.destination'), s.port_of_discharge) AS Destination,
        s.packing_type AS PackingType
        """;

    // ═══════════════════════════════════════════════════════════════
    //  Danh sách
    // ═══════════════════════════════════════════════════════════════

    public async Task<List<PlanListRow>> GetTripPlansAsync(string? q, DateTime? from, DateTime? toExclusive, int max)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT TOP (@max)
                   t.id AS TripId, t.trip_no AS TripNo, t.vehicle_type AS VehicleType, p.id AS PlanId, p.plan_no AS PlanNo, N'CONT' AS UnitKind,
                   COALESCE(t.container_no, t.plate_no) AS UnitNo,
                   COALESCE(t.container_size, p.container_type) AS ContainerType,
                   si.ShipMode, si.Destination, p.status AS PlanStatus,
                   ISNULL(si.SiCount, 0) AS SiCount, ISNULL(bx.BoxCount, 0) AS BoxCount,
                   ISNULL(p.total_columns, 0) AS TotalColumns, ISNULL(p.placed_columns, 0) AS PlacedColumns,
                   t.planned_arrival_at AS PlannedArrivalAt
            FROM wms.shipment_trips t
            LEFT JOIN wms.stowage_plan_containers c ON c.trip_id = t.id
            LEFT JOIN wms.stowage_plans p           ON p.id = c.plan_id AND p.is_deleted = 0
            OUTER APPLY (SELECT COUNT(1) AS SiCount,
                                MAX(s.ship_mode) AS ShipMode,
                                MIN(COALESCE(JSON_VALUE(s.header_note, '$.destination'), s.port_of_discharge)) AS Destination
                         FROM wms.shipment_trip_sis ts
                         JOIN wms.shipment_instructions s ON s.id = ts.si_id AND s.is_deleted = 0
                         WHERE ts.trip_id = t.id) si
            -- box thật + thùng dự kiến (chưa lấy hàng), cùng nguồn với màn chi tiết
            OUTER APPLY (SELECT COUNT(1) AS BoxCount
                         FROM wms.shipment_trip_sis ts
                         CROSS APPLY wms.fn_stowage_si_boxes(ts.si_id) f
                         WHERE ts.trip_id = t.id) bx
            WHERE t.is_deleted = 0
              AND t.status IN (N'planned', N'arrived', N'sealed')
              -- lọc ngày giống màn Chuyến xe: giờ dự kiến đến hoặc ngày vanning / ETD của SI trên chuyến
              AND (@from IS NULL
                   OR (t.planned_arrival_at >= @from AND t.planned_arrival_at < @toExclusive)
                   OR EXISTS (SELECT 1
                              FROM wms.shipment_trip_sis ts
                              JOIN wms.shipment_instructions s ON s.id = ts.si_id
                              WHERE ts.trip_id = t.id
                                AND COALESCE(s.vanning_date, s.etd_date) >= @from
                                AND COALESCE(s.vanning_date, s.etd_date) <  @toExclusive))
              AND (@q IS NULL
                   OR t.trip_no LIKE N'%' + @q + N'%'
                   OR t.container_no LIKE N'%' + @q + N'%'
                   OR t.plate_no LIKE N'%' + @q + N'%'
                   OR p.plan_no LIKE N'%' + @q + N'%'
                   OR EXISTS (SELECT 1
                              FROM wms.shipment_trip_sis ts
                              JOIN wms.shipment_instructions s ON s.id = ts.si_id
                              WHERE ts.trip_id = t.id
                                AND (s.si_no LIKE N'%' + @q + N'%'
                                     OR s.port_of_discharge LIKE N'%' + @q + N'%')))
            ORDER BY CASE WHEN t.planned_arrival_at IS NULL THEN 1 ELSE 0 END,
                     t.planned_arrival_at, t.id;
            """;
        return (await conn.QueryAsync<PlanListRow>(sql, new { q, from, toExclusive, max })).ToList();
    }

    public async Task<List<PlanListRow>> GetStandalonePlansAsync(string? q, DateTime? from, DateTime? toExclusive, int max)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT TOP (@max)
                   CAST(NULL AS bigint) AS TripId, CAST(NULL AS nvarchar(20)) AS TripNo, CAST(NULL AS nvarchar(10)) AS VehicleType, p.id AS PlanId, p.plan_no AS PlanNo, p.unit_kind AS UnitKind,
                   c0.unit_no AS UnitNo, p.container_type AS ContainerType, p.ship_mode AS ShipMode,
                   p.destination AS Destination, p.status AS PlanStatus,
                   (SELECT COUNT(1) FROM wms.stowage_plan_sis ps WHERE ps.plan_id = p.id) AS SiCount,
                   p.total_boxes AS BoxCount, p.total_columns AS TotalColumns, p.placed_columns AS PlacedColumns,
                   CAST(p.vanning_date AS datetime2(0)) AS PlannedArrivalAt
            FROM wms.stowage_plans p
            OUTER APPLY (SELECT TOP (1) c.unit_no
                         FROM wms.stowage_plan_containers c
                         WHERE c.plan_id = p.id
                         ORDER BY c.container_index) c0
            WHERE p.is_deleted = 0
              AND NOT EXISTS (SELECT 1 FROM wms.stowage_plan_containers c
                              WHERE c.plan_id = p.id AND c.trip_id IS NOT NULL)
              AND (@from IS NULL
                   OR (COALESCE(p.vanning_date, p.etd_date) >= @from
                       AND COALESCE(p.vanning_date, p.etd_date) < @toExclusive))
              AND (@q IS NULL
                   OR p.plan_no LIKE N'%' + @q + N'%'
                   OR c0.unit_no LIKE N'%' + @q + N'%'
                   OR p.destination LIKE N'%' + @q + N'%')
            ORDER BY CASE WHEN p.vanning_date IS NULL THEN 1 ELSE 0 END, p.vanning_date, p.id;
            """;
        return (await conn.QueryAsync<PlanListRow>(sql, new { q, from, toExclusive, max })).ToList();
    }

    // ═══════════════════════════════════════════════════════════════
    //  Chi tiết
    // ═══════════════════════════════════════════════════════════════

    public async Task<PlanRow?> GetPlanAsync(string planNo)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<PlanRow>("""
            SELECT id AS Id, plan_no AS PlanNo, unit_kind AS UnitKind, ship_mode AS ShipMode,
                   container_type AS ContainerType, forwarder_code AS ForwarderCode,
                   vanning_date AS VanningDate, etd_date AS EtdDate, destination AS Destination,
                   base_type AS BaseType, status AS Status,
                   total_boxes AS TotalBoxes, total_pallets AS TotalPallets,
                   total_columns AS TotalColumns, placed_columns AS PlacedColumns,
                   total_weight_kg AS TotalWeightKg, saved_at AS SavedAt, saved_by AS SavedBy
            FROM wms.stowage_plans
            WHERE plan_no = @planNo AND is_deleted = 0;
            """, new { planNo });
    }

    public async Task<string?> GetPlanNoOfTripAsync(long tripId)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<string?>("""
            SELECT p.plan_no
            FROM wms.stowage_plan_containers c
            JOIN wms.stowage_plans p ON p.id = c.plan_id AND p.is_deleted = 0
            WHERE c.trip_id = @tripId;
            """, new { tripId });
    }

    public async Task<TripHeadRow?> GetTripAsync(long tripId)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<TripHeadRow>("""
            SELECT id AS Id, trip_no AS TripNo, vehicle_type AS VehicleType, container_no AS ContainerNo, plate_no AS PlateNo,
                   container_size AS ContainerSize, forwarder_code AS ForwarderCode,
                   planned_arrival_at AS PlannedArrivalAt, status AS Status
            FROM wms.shipment_trips
            WHERE id = @tripId AND is_deleted = 0;
            """, new { tripId });
    }

    public async Task<List<PlanContainerRow>> GetContainersAsync(long planId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<PlanContainerRow>("""
            SELECT container_index AS ContainerIndex, trip_id AS TripId, unit_no AS UnitNo
            FROM wms.stowage_plan_containers
            WHERE plan_id = @planId
            ORDER BY container_index;
            """, new { planId })).ToList();
    }

    public async Task<List<StowSiRow>> GetTripSisAsync(long tripId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<StowSiRow>($"""
            SELECT {SiColumns}, CAST(NULL AS char(7)) AS Color
            FROM wms.shipment_trip_sis ts
            JOIN wms.shipment_instructions s ON s.id = ts.si_id AND s.is_deleted = 0
            WHERE ts.trip_id = @tripId
            ORDER BY s.si_no;
            """, new { tripId })).ToList();
    }

    public async Task<List<StowSiRow>> GetPlanSisAsync(long planId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<StowSiRow>($"""
            SELECT {SiColumns}, ps.color AS Color
            FROM wms.stowage_plan_sis ps
            JOIN wms.shipment_instructions s ON s.id = ps.si_id AND s.is_deleted = 0
            WHERE ps.plan_id = @planId
            ORDER BY ps.sort_order, s.si_no;
            """, new { planId })).ToList();
    }

    /*  Thùng cần xếp của các SI — quy tắc nằm ở wms.fn_stowage_si_boxes (script 2026-10-29b):
          dòng đã có box  -> box thật; kích thước part card > model, cân nặng boxes > part card > model
          dòng chưa có box -> thùng dự kiến = CEILING((qty_required - qty_cut) / models.standard_packing)  */
    public async Task<List<StowBoxRow>> GetBoxesAsync(IReadOnlyCollection<long> siIds)
    {
        if (siIds.Count == 0) return new();
        using var conn = _factory.Create();
        const string sql = """
            SELECT f.si_box_id AS SiBoxId, f.si_line_id AS SiLineId, f.carton_seq AS CartonSeq,
                   f.box_no AS BoxNo, f.line_no AS [LineNo], f.si_id AS SiId, f.si_no AS SiNo, f.model AS Model,
                   f.length_cm AS Length, f.width_cm AS Width, f.height_cm AS Height, f.weight_kg AS Weight,
                   f.layer_limit AS LayerLimit, f.is_estimated AS IsEstimated, f.qty AS Qty,
                   f.category AS Category, f.layer_count AS LayerCount,
                   f.stacking_length AS StackingLength, f.stacking_width AS StackingWidth
            FROM wms.shipment_instructions s
            CROSS APPLY wms.fn_stowage_si_boxes(s.id) f
            WHERE s.id IN @siIds
            ORDER BY f.si_no, f.line_no, f.box_no, f.carton_seq;
            """;
        return (await conn.QueryAsync<StowBoxRow>(sql, new { siIds })).ToList();
    }

    public async Task<List<StowColumnRow>> GetColumnsAsync(long planId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<StowColumnRow>("""
            SELECT id AS Id, code AS Code, container_index AS ContainerIndex,
                   row_no AS RowNo, CAST(lane_no AS int) AS LaneNo, rotated AS Rotated
            FROM wms.stowage_columns
            WHERE plan_id = @planId
            ORDER BY code;
            """, new { planId })).ToList();
    }

    public async Task<List<StowPalletRow>> GetPalletsAsync(long planId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<StowPalletRow>("""
            SELECT id AS Id, column_id AS ColumnId, CAST(tier AS int) AS Tier, code AS Code, si_id AS SiId,
                   pallet_size AS PalletSize, CAST(length_cm AS float) AS LengthCm, CAST(width_cm AS float) AS WidthCm
            FROM wms.stowage_pallets
            WHERE plan_id = @planId
            ORDER BY code;
            """, new { planId })).ToList();
    }

    public async Task<List<StowPalletBoxRow>> GetPalletBoxesAsync(long planId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<StowPalletBoxRow>("""
            SELECT stowage_pallet_id AS StowagePalletId, si_box_id AS SiBoxId,
                   si_line_id AS SiLineId, carton_seq AS CartonSeq
            FROM wms.stowage_pallet_boxes
            WHERE plan_id = @planId
            ORDER BY id;
            """, new { planId })).ToList();
    }

    // ═══════════════════════════════════════════════════════════════
    //  Ghi
    // ═══════════════════════════════════════════════════════════════

    private const string InsertPlanSql = """
        INSERT INTO wms.stowage_plans
            (plan_no, unit_kind, ship_mode, container_type, forwarder_code, vanning_date, etd_date, destination,
             base_type, status, total_boxes, total_pallets, total_columns, placed_columns, total_weight_kg,
             saved_at, saved_by, is_deleted, created_at, created_by)
        OUTPUT INSERTED.id
        VALUES
            (@PlanNo, @UnitKind, @ShipMode, @ContainerType, @ForwarderCode, @VanningDate, @EtdDate, @Destination,
             @BaseType, @Status, @TotalBoxes, @TotalPallets, @TotalColumns, @PlacedColumns, @TotalWeightKg,
             CASE WHEN @Status = N'saved' THEN SYSDATETIME() END,
             CASE WHEN @Status = N'saved' THEN @Actor END,
             0, SYSDATETIME(), @Actor);
        """;

    // Lưu nháp giữ saved_at / saved_by của lần lưu đủ trước đó
    private const string UpdatePlanSql = """
        UPDATE wms.stowage_plans
        SET ship_mode = @ShipMode, container_type = @ContainerType, forwarder_code = @ForwarderCode,
            vanning_date = @VanningDate, etd_date = @EtdDate, destination = @Destination,
            base_type = @BaseType, status = @Status,
            total_boxes = @TotalBoxes, total_pallets = @TotalPallets,
            total_columns = @TotalColumns, placed_columns = @PlacedColumns, total_weight_kg = @TotalWeightKg,
            saved_at = CASE WHEN @Status = N'saved' THEN SYSDATETIME() ELSE saved_at END,
            saved_by = CASE WHEN @Status = N'saved' THEN @Actor ELSE saved_by END,
            updated_at = SYSDATETIME(), updated_by = @Actor
        WHERE id = @Id AND is_deleted = 0;
        """;

    public async Task<long> SaveAsync(PlanSave save)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        var p = save.Plan;
        var head = new
        {
            p.Id,
            p.PlanNo,
            p.UnitKind,
            p.ShipMode,
            p.ContainerType,
            p.ForwarderCode,
            p.VanningDate,
            p.EtdDate,
            p.Destination,
            p.BaseType,
            p.Status,
            p.TotalBoxes,
            p.TotalPallets,
            p.TotalColumns,
            p.PlacedColumns,
            p.TotalWeightKg,
            save.Actor,
        };

        long planId;
        if (p.Id == 0)
        {
            planId = await conn.ExecuteScalarAsync<long>(InsertPlanSql, head, tx);
        }
        else
        {
            if (await conn.ExecuteAsync(UpdatePlanSql, head, tx) == 0)
            {
                tx.Rollback();
                return 0;                   // plan vừa bị xoá
            }
            planId = p.Id;
        }

        // 1. Bỏ sơ đồ cũ (con trước, cha sau)
        await conn.ExecuteAsync("""
            DELETE FROM wms.stowage_pallet_boxes WHERE plan_id = @planId;
            DELETE FROM wms.stowage_pallets      WHERE plan_id = @planId;
            DELETE FROM wms.stowage_columns      WHERE plan_id = @planId;
            """, new { planId }, tx);

        // 2. Số container: bỏ container thừa, thêm container thiếu (#0 gắn chuyến khi tạo mới)
        await conn.ExecuteAsync("""
            DELETE FROM wms.stowage_plan_containers WHERE plan_id = @planId AND container_index >= @count;
            """, new { planId, count = save.ContainerCount }, tx);
        for (var i = 0; i < save.ContainerCount; i++)
        {
            await conn.ExecuteAsync("""
                IF NOT EXISTS (SELECT 1 FROM wms.stowage_plan_containers WHERE plan_id = @planId AND container_index = @i)
                    INSERT INTO wms.stowage_plan_containers (plan_id, container_index, trip_id, unit_no, created_at, created_by)
                    VALUES (@planId, @i, @tripId, @unitNo, SYSDATETIME(), @actor);
                """, new
            {
                planId,
                i,
                tripId = i == 0 ? save.TripId : null,
                unitNo = i == 0 ? save.UnitNo : null,
                actor = save.Actor,
            }, tx);
        }
        // Container #0 gắn chuyến: số cont theo chuyến (văn phòng có thể vừa sửa)
        if (save.TripId is not null)
            await conn.ExecuteAsync("""
                UPDATE wms.stowage_plan_containers SET unit_no = @unitNo
                WHERE plan_id = @planId AND container_index = 0 AND trip_id = @tripId;
                """, new { planId, tripId = save.TripId, unitNo = save.UnitNo }, tx);

        // 3. SI: bỏ SI không còn, thêm SI mới, cập nhật thứ tự (giữ màu đã chọn)
        var siIds = save.Sis.Select(s => s.SiId).ToList();
        await conn.ExecuteAsync("""
            DELETE FROM wms.stowage_plan_sis WHERE plan_id = @planId AND si_id NOT IN @siIds;
            """, new { planId, siIds }, tx);
        foreach (var (siId, sort) in save.Sis)
        {
            await conn.ExecuteAsync("""
                IF EXISTS (SELECT 1 FROM wms.stowage_plan_sis WHERE plan_id = @planId AND si_id = @siId)
                    UPDATE wms.stowage_plan_sis SET sort_order = @sort WHERE plan_id = @planId AND si_id = @siId;
                ELSE
                    INSERT INTO wms.stowage_plan_sis (plan_id, si_id, sort_order, created_at, created_by)
                    VALUES (@planId, @siId, @sort, SYSDATETIME(), @actor);
                """, new { planId, siId, sort, actor = save.Actor }, tx);
        }

        // 4. Cọc
        var columnIds = new Dictionary<string, long>(StringComparer.Ordinal);
        foreach (var c in save.Columns)
        {
            columnIds[c.Key] = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.stowage_columns (plan_id, code, container_index, row_no, lane_no, rotated, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@planId, @Code, @ContainerIndex, @RowNo, @LaneNo, @Rotated, SYSDATETIME(), @actor);
                """, new { planId, c.Code, c.ContainerIndex, c.RowNo, c.LaneNo, Rotated = c.ContainerIndex is not null && c.Rotated, actor = save.Actor }, tx);
        }

        // 5. Pallet + box
        foreach (var pl in save.Pallets)
        {
            var palletId = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.stowage_pallets
                    (plan_id, column_id, tier, code, si_id, pallet_size, length_cm, width_cm, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@planId, @columnId, @Tier, @Code, @SiId, @PalletSize, @LengthCm, @WidthCm, SYSDATETIME(), @actor);
                """, new
            {
                planId,
                columnId = columnIds[pl.ColumnKey],
                pl.Tier,
                pl.Code,
                pl.SiId,
                pl.PalletSize,
                pl.LengthCm,
                pl.WidthCm,
                actor = save.Actor,
            }, tx);

            if (pl.Boxes.Count > 0)
                await conn.ExecuteAsync("""
                    INSERT INTO wms.stowage_pallet_boxes (plan_id, stowage_pallet_id, si_box_id, si_line_id, carton_seq)
                    VALUES (@planId, @palletId, @SiBoxId, @SiLineId, @CartonSeq);
                    """, pl.Boxes.Select(b => new { planId, palletId, b.SiBoxId, b.SiLineId, b.CartonSeq }), tx);
        }

        tx.Commit();
        return planId;
    }
}