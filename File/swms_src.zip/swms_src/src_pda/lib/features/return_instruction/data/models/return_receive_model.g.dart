// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_receive_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

Map<String, dynamic> _$ReceiveReturnBoxRequestModelToJson(
  ReceiveReturnBoxRequestModel instance,
) => <String, dynamic>{
  'boxNo': ?instance.boxNo,
  'model': instance.model,
  'serials': instance.serials,
};

Map<String, dynamic> _$ReceiveReturnRequestModelToJson(
  ReceiveReturnRequestModel instance,
) => <String, dynamic>{'boxes': instance.boxes};

ReceiveReturnResponseModel _$ReceiveReturnResponseModelFromJson(
  Map<String, dynamic> json,
) => ReceiveReturnResponseModel(
  palletId: (json['palletId'] as num).toInt(),
  lotNo: json['lotNo'] as String,
  doc: ReturnInstructionModel.fromJson(json['doc'] as Map<String, dynamic>),
  categoryCode: (json['categoryCode'] as num?)?.toInt() ?? 0,
  boxCount: (json['boxCount'] as num?)?.toInt() ?? 0,
  serialCount: (json['serialCount'] as num?)?.toInt() ?? 0,
  overReceived: json['overReceived'] as bool? ?? false,
);
