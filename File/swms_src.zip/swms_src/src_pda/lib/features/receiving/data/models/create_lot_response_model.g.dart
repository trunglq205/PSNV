// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'create_lot_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

CreateLotResponseModel _$CreateLotResponseModelFromJson(
  Map<String, dynamic> json,
) => CreateLotResponseModel(
  id: (json['id'] as num).toInt(),
  lotNo: json['lotNo'] as String,
  detailLevel: json['detailLevel'] as String,
  boxCount: (json['boxCount'] as num).toInt(),
  lineCount: (json['lineCount'] as num).toInt(),
);

Map<String, dynamic> _$CreateLotResponseModelToJson(
  CreateLotResponseModel instance,
) => <String, dynamic>{
  'id': instance.id,
  'lotNo': instance.lotNo,
  'detailLevel': instance.detailLevel,
  'boxCount': instance.boxCount,
  'lineCount': instance.lineCount,
};
