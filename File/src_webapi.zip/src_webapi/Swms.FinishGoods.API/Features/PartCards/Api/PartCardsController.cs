using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.PartCards.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.PartCards.Api;

[ApiController]
[Route("api/part-cards")]
public class PartCardsController : ControllerBase
{
    private readonly IPartCardService _service;
    public PartCardsController(IPartCardService service) => _service = service;

    // Lưu lịch sử in cho 1 phiếu.
    [HttpPost("print-history")]
    [RequirePermission<Perms.Receiving.PartCard.Print>]
    public async Task<ActionResult<PartCardResponse>> SavePrintHistory(
        [FromBody] SavePrintRequest request)
    {
        var result = await _service.SavePrintHistoryAsync(request);
        return CreatedAtAction(nameof(GetPrintHistoryById), new { id = result.Id }, result);
    }

    // Lưu lịch sử in (1 hoặc nhiều phiếu) khi bấm "Hoàn thành".
    [HttpPost("print-history/bulk")]
    [RequirePermission<Perms.Receiving.PartCard.Print>]
    public async Task<ActionResult<List<PartCardResponse>>> SavePrintHistory(
        [FromBody] IReadOnlyList<SavePrintRequest> request)
        => Ok(await _service.SavePrintHistoryAsync(request));

    // Truy vết 1 phiếu: sinh ra / sửa từ đâu + đã bị tách / gộp thành gì.
    // Xem được cả phiếu đã xoá mềm (phiếu nguồn sau tách / gộp).
    [HttpGet("{id:long}/lineage")]
    [RequirePermission<Perms.Receiving.PartCard.View>]
    public async Task<ActionResult<PartCardLineageResponse>> GetLineage(long id)
        => Ok(await _service.GetLineageAsync(id));

    // Tách 1 phiếu 1 mã, 1 thùng → nhiều phiếu. Tạo phiếu mới + xoá mềm phiếu nguồn
    // trong 1 transaction. Trả về các phiếu mới.
    [HttpPost("split")]
    [RequirePermission<Perms.Receiving.PartCard.Print>]
    public async Task<ActionResult<List<PartCardResponse>>> Split(
        [FromBody] SplitPartCardRequest request)
        => Ok(await _service.SplitAsync(request));

    // Gộp nhiều phiếu → 1 phiếu nhiều mã. Tạo phiếu mới + xoá mềm các phiếu nguồn
    // trong 1 transaction. Trả về phiếu gộp.
    [HttpPost("merge")]
    [RequirePermission<Perms.Receiving.PartCard.Print>]
    public async Task<ActionResult<PartCardResponse>> Merge(
        [FromBody] MergePartCardsRequest request)
        => Ok(await _service.MergeAsync(request));

    // Danh sách lịch sử in (phân trang).
    [HttpGet("print-history")]
    [RequirePermission<Perms.Receiving.PartCard.View>]
    public async Task<ActionResult<PagedResult<PartCardResponse>>> GetPrintHistory(
        [FromQuery] PartCardQuery query)
        => Ok(await _service.GetPrintHistoryAsync(query));

    // Chi tiết 1 lần in (để in lại).
    [HttpGet("print-history/{id:long}")]
    [RequirePermission<Perms.Receiving.PartCard.View>]
    public async Task<ActionResult<PartCardResponse>> GetPrintHistoryById(long id)
        => Ok(await _service.GetPrintHistoryByIdAsync(id));

    // Sửa toàn bộ nội dung 1 phiếu đã in (header + dòng hàng). Body giống lúc lưu.
    [HttpPut("print-history/{id:long}")]
    [RequirePermission<Perms.Receiving.PartCard.Print>]
    public async Task<ActionResult<PartCardResponse>> UpdatePrintHistory(
        long id, [FromBody] SavePrintRequest request)
        => Ok(await _service.UpdatePrintHistoryAsync(id, request));

    // Cập nhật kích thước / trọng lượng cho 1 phiếu đã in.
    [HttpPut("print-history/{id:long}/dimensions")]
    [RequirePermission<Perms.Receiving.PartCard.Print>]
    public async Task<ActionResult<PartCardResponse>> UpdateDimensions(
        long id, [FromBody] UpdateDimensionsRequest request)
        => Ok(await _service.UpdateDimensionsAsync(id, request));

    // Xoá (mềm) 1 phiếu đã in.
    [HttpDelete("print-history/{id:long}")]
    [RequirePermission<Perms.Receiving.PartCard.Delete>]
    public async Task<IActionResult> DeletePrintHistory(long id)
    {
        await _service.DeletePrintHistoryAsync(id);
        return NoContent();
    }

    // Xoá (mềm) nhiều phiếu. Dùng POST vì DELETE kèm body không được Refit / proxy hỗ trợ ổn định.
    [HttpPost("print-history/bulk-delete")]
    [RequirePermission<Perms.Receiving.PartCard.Delete>]
    public async Task<ActionResult<DeletePartCardsResponse>> DeletePrintHistoryBulk(
        [FromBody] DeletePartCardsRequest request)
        => Ok(await _service.DeletePrintHistoryAsync(request.Ids));

    // Khoá 1 phiếu — phiếu đang khoá không xoá được. Trả về phiếu sau khi khoá.
    [HttpPost("print-history/{id:long}/lock")]
    [RequirePermission<Perms.Receiving.PartCard.Lock>]
    public async Task<ActionResult<PartCardResponse>> LockPrintHistory(long id)
        => Ok(await _service.LockPrintHistoryAsync(id));

    // Khoá nhiều phiếu.
    [HttpPost("print-history/bulk-lock")]
    [RequirePermission<Perms.Receiving.PartCard.Lock>]
    public async Task<ActionResult<LockPartCardsResponse>> LockPrintHistoryBulk(
        [FromBody] LockPartCardsRequest request)
        => Ok(await _service.LockPrintHistoryAsync(request.Ids));

    // Mở khoá 1 phiếu. Trả về phiếu sau khi mở.
    [HttpPost("print-history/{id:long}/unlock")]
    [RequirePermission<Perms.Receiving.PartCard.Unlock>]
    public async Task<ActionResult<PartCardResponse>> UnlockPrintHistory(long id)
        => Ok(await _service.UnlockPrintHistoryAsync(id));

    // Mở khoá nhiều phiếu.
    [HttpPost("print-history/bulk-unlock")]
    [RequirePermission<Perms.Receiving.PartCard.Unlock>]
    public async Task<ActionResult<LockPartCardsResponse>> UnlockPrintHistoryBulk(
        [FromBody] LockPartCardsRequest request)
        => Ok(await _service.UnlockPrintHistoryAsync(request.Ids));
}