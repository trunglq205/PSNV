﻿namespace Swms.FinishGoods.API.Features.Boxes.Business
{
    /// <summary>Thông tin box + lot chứa + vị trí (từ lot).</summary>
    public class BoxDetailEntity
    {
        public long Id { get; set; }
        public string BoxNo { get; set; } = default!;
        public string? CustomerPo { get; set; }
        public string? PsnvPo { get; set; }
        public DateTime? ProductionDate { get; set; }

        // Trạng thái OQC của box
        public string? OqcStatus { get; set; }

        // Lot chứa box (Pallet ID = pallet_id)
        public long LotId { get; set; }
        public string LotNo { get; set; } = default!;
        public string Payload { get; set; } = default!;

        // Vị trí — ăn theo lot (box không có vị trí riêng)
        public long? LocatorId { get; set; }
        public string? LocatorCode { get; set; }
        public string? AreaCode { get; set; }
        public string? AreaName { get; set; }

        // Dòng sản phẩm trong box (model + serial)
        public List<BoxLineEntity> Lines { get; set; } = [];
    }

    /// <summary>Một dòng trong box: model + qty + serial.</summary>
    public class BoxLineEntity
    {
        public long Id { get; set; }
        public long BoxId { get; set; }
        public string Model { get; set; } = "";
        public int Qty { get; set; }
        public string? SerialNo { get; set; }
    }
}