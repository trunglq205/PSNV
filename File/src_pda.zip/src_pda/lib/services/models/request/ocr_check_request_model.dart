import 'package:freezed_annotation/freezed_annotation.dart';
import 'base_request_model.dart';

part 'ocr_check_request_model.g.dart';

@JsonSerializable()
class OCRCheckRequestModel extends BaseRequestModel {
  OCRCheckRequestModel(
  {
    required this.reelID, required this.material, required this.oCR, required this.userID,
  });
  factory OCRCheckRequestModel.fromJson(Map<String, dynamic> json) =>
      _$OCRCheckRequestModelFromJson(json);

  final String reelID;
  final String material;
  final String oCR;
  final String userID;

  @override
  Map<String, dynamic> toJson() => _$OCRCheckRequestModelToJson(this);
}
