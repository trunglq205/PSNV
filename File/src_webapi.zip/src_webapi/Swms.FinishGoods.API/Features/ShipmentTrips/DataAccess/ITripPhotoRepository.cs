using Swms.FinishGoods.API.Features.ShipmentTrips.Business;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

public interface ITripPhotoRepository
{
    /// <summary>Ảnh đang dùng của 1 chuyến, theo thứ tự mục / đơn vị / ô.</summary>
    Task<List<TripPhotoRow>> GetByTripAsync(long tripId);

    /// <summary>1 ảnh chưa xoá; null = không có.</summary>
    Task<TripPhotoRow?> GetAsync(long photoId);

    /// <summary>
    /// Ghi ảnh vào 1 ô. Ô đã có ảnh thì ảnh cũ bị xoá mềm trong CÙNG transaction,
    /// nên PDA chụp lại là thay ảnh, không sinh thêm ảnh thừa. Trả id ảnh mới
    /// và số ảnh cũ đã bị thay (0 hoặc 1).
    /// </summary>
    Task<(long Id, int Replaced)> ReplaceSlotAsync(TripPhotoRow photo);

    /// <summary>Xoá mềm 1 ảnh. false = ảnh không còn (đã xoá từ trước).</summary>
    Task<bool> SoftDeleteAsync(long photoId, string? user);
}
