using Dapper;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
// Hai using cho StockEvents, KHÔNG phải một: các hằng (StockEventCodes,
// StockEventSubjects, StockEventRefTypes) ở `…StockEvents.Business`, còn chính
// lớp StockEvent ở namespace CON `…Business.Entities`. Using namespace cha
// KHÔNG kéo theo namespace con ⇒ thiếu dòng Entities là CS0246 trên StockEvent.
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

public class ReturnInstructionRepository : IReturnInstructionRepository
{
    /// <summary>
    /// Số id phiếu mỗi câu khi nạp dòng / đếm SL thực nhận. Dapper trải
    /// <c>IN</c> thành từng parameter và SQL Server chỉ cho 2100 parameter một
    /// câu, nên danh sách phiếu dài phải chia lô.
    /// </summary>
    private const int DocIdChunk = 1000;

    private readonly IDbConnectionFactory _factory;

    /// <summary>
    /// Ghi wms.stock_events. Cần ở đây vì huỷ một lần nhận XOÁ MỘT PALLET mà
    /// không đi qua PalletService — không ghi event thì pallet biến khỏi bản đồ
    /// kho (mọi câu map lọc is_deleted = 0) và lịch sử vị trí không có dòng nào
    /// giải thích nó đi đâu.
    /// </summary>
    private readonly IStockEventWriter _events;

    public ReturnInstructionRepository(IDbConnectionFactory factory, IStockEventWriter events)
    {
        _factory = factory;
        _events = events;
    }

    /// <summary>
    /// Header + số dòng + tổng SL. Hai con số tổng tính bằng OUTER APPLY sang
    /// bảng dòng chứ KHÔNG lưu sẵn trên header: lưu sẵn là phải nhớ cập nhật ở
    /// mọi đường sửa dòng, và chỉ cần quên một đường là tổng sai vĩnh viễn.
    /// </summary>
    private const string HeaderSql = """
        SELECT  d.id            AS [Id],
                d.doc_no        AS [DocNo],
                d.goods_type    AS [GoodsType],
                d.customer      AS [Customer],
                d.expected_date AS [ExpectedDate],
                d.doc_status    AS [DocStatus],
                d.note          AS [Note],
                d.mail_sent_at  AS [MailSentAt],
                d.mail_sent_to  AS [MailSentTo],
                -- 4 cột của mục 2b. DB chưa chạy return_actual_schema.sql thì
                -- câu này lỗi 207 và CẢ màn danh sách phiếu chết — script là
                -- bắt buộc trước khi publish API, không phải tuỳ chọn.
                d.closed_at           AS [ClosedAt],
                d.closed_by           AS [ClosedBy],
                d.actual_mail_sent_at AS [ActualMailSentAt],
                -- 13 cột của mục 2c (luồng nhận lại hàng về FA, gộp vào phiếu).
                -- Cùng điều kiện với 4 cột trên: DB chưa chạy
                -- return_back_merge_schema.sql thì câu này lỗi 207 và CẢ màn
                -- danh sách phiếu chết. Script là bắt buộc trước khi publish.
                d.back_status         AS [BackStatus],
                -- back_round: LẦN đề nghị đang mở (0 = chưa đề nghị). Thêm
                -- 12/11 cùng return_back_round_schema.sql — DB chưa chạy script
                -- đó thì câu này lỗi 207 và CẢ màn danh sách phiếu chết.
                d.back_round          AS [BackRound],
                d.back_note           AS [BackNote],
                d.back_requested_by   AS [BackRequestedBy],
                d.back_requested_at   AS [BackRequestedAt],
                d.back_approved_by    AS [BackApprovedBy],
                d.back_approved_at    AS [BackApprovedAt],
                d.back_fa_comment     AS [BackFaComment],
                d.back_scs_approved_by AS [BackScsApprovedBy],
                d.back_scs_approved_at AS [BackScsApprovedAt],
                d.back_delivered_by   AS [BackDeliveredBy],
                d.back_delivered_at   AS [BackDeliveredAt],
                d.back_scs_comment    AS [BackScsComment],
                d.back_cancelled_by   AS [BackCancelledBy],
                d.back_cancelled_at   AS [BackCancelledAt],
                d.back_cancel_reason  AS [BackCancelReason],
                d.actual_mail_sent_to AS [ActualMailSentTo],
                d.created_at    AS [CreatedAt],
                d.created_by    AS [CreatedBy],
                d.updated_at    AS [UpdatedAt],
                d.updated_by    AS [UpdatedBy]
        FROM wms.return_instructions d
        WHERE d.is_deleted = 0
        """;

    public async Task<IReadOnlyList<ReturnInstruction>> GetListAsync(ReturnInstructionQuery query)
    {
        // Loại hàng nằm NGAY TRÊN PHIẾU nên lọc thẳng. Chỉ từ khoá model mới
        // phải nhìn sang bảng dòng, và dùng EXISTS chứ không JOIN: JOIN sẽ
        // nhân dòng phiếu lên theo số dòng khớp.
        //
        // Sắp theo NGÀY TẠO phiếu giảm dần, không theo expected_date: phiếu vừa
        // tạo phải nằm đầu danh sách, vì đó là phiếu người dùng vừa làm và đang
        // tìm. Sắp theo expected_date thì một phiếu tạo từ tuần trước mà hẹn
        // hàng về tháng sau lại chen lên trên phiếu vừa tạo, còn phiếu chưa khai
        // ngày dự kiến (NULL) thì nhảy hẳn lên đỉnh.
        //
        // id DESC chỉ để phá thế hoà: created_at là DATETIME2(0) nên hai phiếu
        // tạo trong cùng một giây bằng nhau, lúc đó id lớn hơn là phiếu sau.
        var sql = HeaderSql + """

              AND (@status    IS NULL OR d.doc_status = @status)
              AND (@goodsType IS NULL OR d.goods_type = @goodsType)
              AND (@fromDate  IS NULL OR d.expected_date >= @fromDate)
              AND (@toDate    IS NULL OR d.expected_date <= @toDate)
              AND (@kw IS NULL OR d.doc_no LIKE @kw OR d.customer LIKE @kw
                   OR EXISTS (SELECT 1 FROM wms.return_instruction_lines l2
                              WHERE l2.doc_id = d.id AND l2.is_deleted = 0
                                AND l2.model LIKE @kw))
            ORDER BY d.created_at DESC, d.id DESC;
            """;

        using var conn = _factory.Create();
        var rows = (await conn.QueryAsync<ReturnInstruction>(sql, new
        {
            status = Blank(query.Status),
            goodsType = Blank(query.GoodsType),
            fromDate = query.FromDate?.Date,
            toDate = query.ToDate?.Date,
            kw = Blank(query.Keyword) is { } k ? $"%{k}%" : null,
        })).ToList();

        if (rows.Count == 0) return rows;

        // Nạp dòng của TẤT CẢ phiếu bằng MỘT câu, rồi gom vào từng phiếu —
        // tránh N+1. Danh sách cần Lines để tính ModelCount/TotalQty, nhưng
        // không trả chi tiết ra response danh sách.
        var docIds = rows.Select(r => r.Id).ToList();
        var lines = await LoadLinesAsync(conn, docIds);
        foreach (var r in rows)
            r.Lines = lines.TryGetValue(r.Id, out var ls) ? ls : [];

        // Bốn con số của luồng back, MỘT câu cho cả danh sách.
        var back = await LoadBackCountsAsync(conn, docIds);
        foreach (var r in rows)
            if (back.TryGetValue(r.Id, out var b)) Apply(r, b);

        // SL FA xin lấy về, cũng MỘT câu cho cả danh sách.
        var req = await LoadBackLinesAsync(conn, docIds);
        foreach (var r in rows)
            r.BackLines = req.TryGetValue(r.Id, out var bl) ? bl : [];

        // Mốc từng LẦN đề nghị — màn danh sách vẽ tiến trình (có cả tiến trình
        // con) ngay trong thẻ phiếu nên phải nạp ở đây, MỘT câu cho cả danh
        // sách. Không gọi sang IReturnBackFlowRepository: một màn một lượt gọi,
        // và câu này cùng khuôn nuốt 207/208 với mấy câu trên.
        var rounds = await LoadBackRoundsAsync(conn, docIds);
        foreach (var r in rows)
            r.BackRounds = rounds.TryGetValue(r.Id, out var rr) ? rr : [];

        return rows;
    }

    public async Task<ReturnInstruction?> GetByIdAsync(long id)
    {
        using var conn = _factory.Create();
        var doc = await conn.QuerySingleOrDefaultAsync<ReturnInstruction>(
            HeaderSql + "\n  AND d.id = @id;", new { id });
        if (doc is null) return null;

        doc.Lines = (await LoadLinesAsync(conn, [id])).TryGetValue(id, out var ls) ? ls : [];

        var back = await LoadBackCountsAsync(conn, [id]);
        if (back.TryGetValue(id, out var b)) Apply(doc, b);

        doc.BackLines =
            (await LoadBackLinesAsync(conn, [id])).TryGetValue(id, out var bl) ? bl : [];

        doc.BackRounds =
            (await LoadBackRoundsAsync(conn, [id])).TryGetValue(id, out var rr) ? rr : [];

        return doc;
    }

    /// <summary>
    /// SL FA xin lấy về, theo model (<c>wms.return_back_lines</c>, có từ 10/11).
    ///
    /// Nuốt 207/208 y như <see cref="LoadBackCountsAsync"/>: DB chưa chạy
    /// <c>return_back_phase2_schema.sql</c> thì bảng chưa có, và CẢ MÀN Tái gia
    /// công sẽ 500 vì một bảng của một bước chưa triển khai xong. Rỗng là đúng
    /// nghĩa "chưa ai đề nghị gì".
    /// </summary>
    private static async Task<Dictionary<long, List<BackReqLine>>> LoadBackLinesAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> docIds)
    {
        if (docIds.Count == 0) return [];

        try
        {
            // CHỈ dòng của LẦN ĐANG MỞ (JOIN theo d.back_round). Trả hết mọi
            // lần là màn duyệt của quản lý FA cộng cả SL đã xin ở lần trước —
            // từ 12/11 dòng của các lần cũ KHÔNG bị xoá nữa, nên không lọc là
            // sai số ngay. Lịch sử từng lần đọc ở LoadBackRoundsAsync.
            var rows = await conn.QueryAsync<BackReqLine>("""
                SELECT  l.id             AS [Id],
                        l.doc_id         AS [DocId],
                        l.model          AS [Model],
                        l.req_qty        AS [ReqQty],
                        l.round          AS [Round],
                        ISNULL(g.qty, 0) AS [DeliveredQty]
                FROM   wms.return_back_lines l
                JOIN   wms.return_instructions d
                       ON d.id = l.doc_id AND l.round = d.back_round
                OUTER APPLY (
                    -- Đã giao bao nhiêu con của model này trong RIÊNG lần này.
                    SELECT COUNT(*) AS qty
                    FROM   wms.return_instruction_serials s
                    WHERE  s.doc_id     = l.doc_id
                      AND  s.back_round = l.round
                      AND  s.model      = l.model
                      AND  s.is_deleted = 0
                ) g
                WHERE  l.doc_id IN @docIds
                ORDER BY l.model;
                """, new { docIds });

            return rows.GroupBy(r => r.DocId)
                       .ToDictionary(g => g.Key, g => g.ToList());
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number is 207 or 208)
        {
            return [];
        }
    }

    /// <summary>
    /// Mốc của TỪNG lần đề nghị (<c>wms.return_back_rounds</c>) + SL đã giao
    /// của riêng lần đó, cũ trước mới.
    ///
    /// Nuốt 207/208 cùng lý do với <see cref="LoadBackLinesAsync"/>: DB chưa
    /// chạy <c>return_back_round_schema.sql</c> thì bảng chưa có, và rỗng đọc
    /// ra đúng nghĩa "chưa có lần nào" — màn hình lùi về tiến trình một lớp.
    /// </summary>
    private static async Task<Dictionary<long, List<ReturnBackRoundRow>>> LoadBackRoundsAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> docIds)
    {
        if (docIds.Count == 0) return [];

        try
        {
            var rows = await conn.QueryAsync<ReturnBackRoundRow>("""
                SELECT  r.id              AS [Id],
                        r.doc_id          AS [DocId],
                        r.round           AS [Round],
                        r.asked_qty       AS [AskedQty],
                        -- "Đã giao" = FA ĐÃ NHẬN (kind = 'pickup'). Đưa pallet ra
                        -- khu Nhận hàng chỉ là bước giao cho FA đến lấy, chưa
                        -- tính là giao xong — xem return_fa_pickup_schema.sql.
                        ISNULL(dl.pick_qty, 0) AS [DeliveredQty],
                        ISNULL(dl.hand_qty, 0) AS [HandoverQty],
                        -- Lùi về mốc 'pickup' cho dữ liệu trước 12/11: hồi đó
                        -- một lượt vừa là đưa ra vừa là giao, chỉ có một dòng.
                        ISNULL(hv.at_, pk.at_)  AS [HandoverAt],
                        ISNULL(hv.who, pk.who)  AS [HandoverBy],
                        lc.locators             AS [HandoverLocators],
                        pk.at_                  AS [PickedAt],
                        pk.who                  AS [PickedBy],
                        r.note            AS [Note],
                        r.requested_by    AS [RequestedBy],
                        r.requested_at    AS [RequestedAt],
                        r.fa_approved_by  AS [FaApprovedBy],
                        r.fa_approved_at  AS [FaApprovedAt],
                        r.fa_comment      AS [FaComment],
                        r.scs_approved_by AS [ScsApprovedBy],
                        r.scs_approved_at AS [ScsApprovedAt],
                        r.scs_comment     AS [ScsComment],
                        r.delivered_by    AS [DeliveredBy],
                        r.delivered_at    AS [DeliveredAt],
                        r.cancelled_by    AS [CancelledBy],
                        r.cancelled_at    AS [CancelledAt],
                        r.cancel_reason   AS [CancelReason]
                FROM    wms.return_back_rounds r
                OUTER APPLY (
                    SELECT SUM(CASE WHEN x.kind = N'handover' THEN x.serial_count ELSE 0 END) AS hand_qty,
                           SUM(CASE WHEN x.kind = N'pickup'   THEN x.serial_count ELSE 0 END) AS pick_qty
                    FROM   wms.return_back_deliveries x
                    WHERE  x.doc_id = r.doc_id AND x.round = r.round
                ) dl
                OUTER APPLY (
                    SELECT TOP 1 x.delivered_at AS at_, x.delivered_by AS who
                    FROM   wms.return_back_deliveries x
                    WHERE  x.doc_id = r.doc_id AND x.round = r.round
                      AND  x.kind = N'handover'
                    ORDER BY x.delivered_at DESC, x.id DESC
                ) hv
                OUTER APPLY (
                    SELECT TOP 1 x.delivered_at AS at_, x.delivered_by AS who
                    FROM   wms.return_back_deliveries x
                    WHERE  x.doc_id = r.doc_id AND x.round = r.round
                      AND  x.kind = N'pickup'
                    ORDER BY x.delivered_at DESC, x.id DESC
                ) pk
                OUTER APPLY (
                    -- DISTINCT trước rồi mới gộp: một vị trí nhận nhiều pallet
                    -- của cùng lần thì không lặp tên ô ra nhiều lần.
                    SELECT STRING_AGG(y.locator_code, N', ')
                           WITHIN GROUP (ORDER BY y.locator_code) AS locators
                    FROM (
                        SELECT DISTINCT x.locator_code
                        FROM   wms.return_back_deliveries x
                        WHERE  x.doc_id = r.doc_id AND x.round = r.round
                          AND  x.kind = N'handover'
                          AND  x.locator_code IS NOT NULL
                    ) y
                ) lc
                WHERE   r.doc_id IN @docIds
                ORDER BY r.doc_id, r.round;
                """, new { docIds });

            return rows.GroupBy(r => r.DocId)
                       .ToDictionary(g => g.Key, g => g.ToList());
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number is 207 or 208)
        {
            return [];
        }
    }

    private static void Apply(ReturnInstruction d, BackCountRow b)
    {
        d.BackRemainQty = b.RemainQty;
        d.BackSentQty = b.SentQty;
        d.AtFaQty = b.AtFaQty;
        d.BackReturnedQty = b.ReturnedQty;
    }

    private sealed class BackCountRow
    {
        public long DocId { get; set; }
        public int RemainQty { get; set; }
        public int SentQty { get; set; }
        public int AtFaQty { get; set; }
        public int ReturnedQty { get; set; }
    }

    /// <summary>
    /// Bốn con số của luồng nhận lại hàng, ĐẾM TRỰC TIẾP TỪ SỔ SERIAL. Không
    /// cột tổng nào được lưu trên header: bảng đề nghị cũ có <c>total_qty</c>
    /// lưu sẵn và nó đã lệch thật — FA đề nghị khi phiếu có 100 con, WH nhận
    /// thêm 50 con, rồi giao hết 150 mà tổng vẫn ghi 100.
    ///
    /// <c>SentQty</c> bám <c>sent_fa_at</c> chứ không bám <c>status='at_fa'</c>:
    /// hàng giao rồi FA trả lại hết thì status về <c>returned</c>, mà lượt giao
    /// đó vẫn đã xảy ra.
    ///
    /// Nuốt riêng lỗi 207/208: DB chưa chạy script của mục 2c thì màn danh sách
    /// phiếu vẫn phải mở được với bốn số bằng 0, chứ không trả 500 cho một màn
    /// vốn đã chạy tốt từ trước — cùng cách <see cref="LoadReceivedAsync"/> làm.
    /// </summary>
    private static async Task<Dictionary<long, BackCountRow>> LoadBackCountsAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> docIds)
    {
        const string sql = """
            SELECT  s.doc_id AS [DocId],
                    SUM(IIF(s.status = N'received', 1, 0))      AS [RemainQty],
                    SUM(IIF(s.sent_fa_at IS NOT NULL, 1, 0))    AS [SentQty],
                    SUM(IIF(s.status = N'at_fa', 1, 0))         AS [AtFaQty],
                    SUM(IIF(s.status = N'returned', 1, 0))      AS [ReturnedQty]
            FROM wms.return_instruction_serials s
            WHERE s.is_deleted = 0 AND s.doc_id IN @docIds
            GROUP BY s.doc_id;
            """;

        var result = new Dictionary<long, BackCountRow>();
        try
        {
            // Chia lô vì cùng lý do với LoadLinesAsync — xem ghi chú ở đó.
            foreach (var chunk in docIds.Chunk(DocIdChunk))
                foreach (var r in await conn.QueryAsync<BackCountRow>(
                             sql, new { docIds = chunk.ToList() }))
                    result[r.DocId] = r;
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number is 207 or 208)
        {
            // 208 = chưa có bảng sổ serial, 207 = chưa có cột sent_fa_at.
        }
        return result;
    }

    private static async Task<Dictionary<long, List<ReturnInstructionLine>>> LoadLinesAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> docIds)
    {
        const string sql = """
            SELECT  l.id         AS [Id],
                    l.doc_id     AS [DocId],
                    l.line_no    AS [LineNo],
                    l.model      AS [Model],
                    l.qty        AS [Qty],
                    l.note       AS [Note]
            FROM wms.return_instruction_lines l
            WHERE l.is_deleted = 0 AND l.doc_id IN @docIds
            ORDER BY l.doc_id, l.line_no, l.id;
            """;
        // Chia lô: Dapper trải IN thành từng parameter, SQL Server chỉ cho 2100
        // parameter một câu. Endpoint danh sách KHÔNG phân trang nên số phiếu
        // khớp bộ lọc có thể vượt ngưỡng đó, và lúc ấy cả màn hình chết.
        var rows = new List<ReturnInstructionLine>();
        foreach (var chunk in docIds.Chunk(DocIdChunk))
            rows.AddRange(
                await conn.QueryAsync<ReturnInstructionLine>(sql, new { docIds = chunk.ToList() }));

        // SL thực nhận: đếm sang sổ serial, không lưu sẵn trên dòng.
        var received = await LoadReceivedAsync(conn, docIds);
        foreach (var r in rows)
            if (received.TryGetValue(r.DocId, out var byModel)
                && byModel.TryGetValue(r.Model, out var qty))
                r.ReceivedQty = qty;

        return rows.GroupBy(r => r.DocId).ToDictionary(g => g.Key, g => g.ToList());
    }

    /// <summary>
    /// SL thực nhận theo (phiếu, model) = số serial đã đăng ký. Đếm MỌI trạng
    /// thái: con hàng đang ở FA hay đã trả về thì vẫn là đã nhận.
    ///
    /// Nuốt riêng lỗi 208 (Invalid object name): DB chưa chạy
    /// <c>return_receiving_schema.sql</c> thì màn danh sách phiếu vẫn phải mở
    /// được với SL thực nhận = 0, chứ không trả 500 cho một màn hình vốn đã
    /// chạy tốt trước khi có mục 2a.
    /// </summary>
    private static async Task<Dictionary<long, Dictionary<string, int>>> LoadReceivedAsync(
        System.Data.IDbConnection conn, IReadOnlyList<long> docIds)
    {
        const string sql = """
            SELECT  s.doc_id AS [DocId],
                    s.model  AS [Model],
                    COUNT(*) AS [Qty]
            FROM wms.return_instruction_serials s
            WHERE s.is_deleted = 0 AND s.doc_id IN @docIds
            GROUP BY s.doc_id, s.model;
            """;

        var result = new Dictionary<long, Dictionary<string, int>>();
        try
        {
            // Chia lô vì cùng lý do với LoadLinesAsync — xem ghi chú ở đó.
            foreach (var chunk in docIds.Chunk(DocIdChunk))
            {
                var rows = await conn.QueryAsync<ReceivedRow>(
                    sql, new { docIds = chunk.ToList() });

                foreach (var r in rows)
                {
                    if (!result.TryGetValue(r.DocId, out var byModel))
                        result[r.DocId] = byModel =
                            new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
                    byModel[r.Model] = r.Qty;
                }
            }
        }
        catch (Microsoft.Data.SqlClient.SqlException ex) when (ex.Number == 208)
        {
            return result;
        }
        return result;
    }

    private sealed class ReceivedRow
    {
        public long DocId { get; set; }
        public string Model { get; set; } = string.Empty;
        public int Qty { get; set; }
    }

    public async Task<long> CreateAsync(ReturnInstruction doc, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var docNo = await NextDocNoAsync(conn, tx, ReturnGoodsType.DocPrefix(doc.GoodsType));

            var id = await conn.ExecuteScalarAsync<long>("""
                INSERT INTO wms.return_instructions
                    (doc_no, goods_type, customer, expected_date, doc_status, note,
                     is_deleted, created_at, created_by)
                OUTPUT INSERTED.id
                VALUES (@docNo, @goodsType, @customer, @expectedDate, @status, @note,
                        0, SYSDATETIME(), @user);
                """,
                new
                {
                    docNo,
                    goodsType = doc.GoodsType,
                    customer = doc.Customer,
                    expectedDate = doc.ExpectedDate,
                    status = doc.DocStatus,
                    note = doc.Note,
                    user,
                }, tx);

            await InsertLinesAsync(conn, tx, id, doc.Lines, user);

            tx.Commit();
            doc.Id = id;
            doc.DocNo = docNo;
            return id;
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>
    /// Số phiếu kế tiếp trong ngày: <c>{prefix}-yyyyMMdd-###</c>, với prefix là
    /// <c>RW</c> (rework) hoặc <c>RB</c> (refurbish).
    ///
    /// Mỗi loại một dãy số riêng: bộ đếm chỉ nhìn các phiếu CÙNG tiền tố, nên
    /// RW-…-001 và RB-…-001 cùng tồn tại trong một ngày là bình thường.
    ///
    /// Tính trong CÙNG transaction với INSERT và khoá dải bằng
    /// <c>UPDLOCK, HOLDLOCK</c>: hai người bấm Lưu cùng lúc mà không khoá thì
    /// cả hai đọc ra cùng một số, người sau sẽ đâm vào
    /// <c>ux_return_instructions_doc_no</c>. Kể cả thế, unique index vẫn là
    /// lưới an toàn cuối — khoá chỉ để chuyện đó đừng xảy ra.
    ///
    /// Đọc cả dòng đã xoá mềm (không lọc is_deleted): xoá một phiếu rồi cấp
    /// lại đúng số đó cho phiếu mới sẽ làm hai phiếu khác nhau trùng số trong
    /// lịch sử và trong hộp thư của FA.
    /// </summary>
    private static async Task<string> NextDocNoAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx, string typePrefix)
    {
        var prefix = $"{typePrefix}-{DateTime.Now:yyyyMMdd}-";
        var next = await conn.ExecuteScalarAsync<int>("""
            SELECT ISNULL(MAX(TRY_CONVERT(int, RIGHT(doc_no, 3))), 0) + 1
            FROM   wms.return_instructions WITH (UPDLOCK, HOLDLOCK)
            WHERE  doc_no LIKE @prefix + '[0-9][0-9][0-9]';
            """, new { prefix }, tx);
        return prefix + next.ToString("D3");
    }

    private static async Task InsertLinesAsync(
        System.Data.IDbConnection conn, System.Data.IDbTransaction tx,
        long docId, IReadOnlyList<ReturnInstructionLine> lines, string? user)
    {
        const string sql = """
            INSERT INTO wms.return_instruction_lines
                (doc_id, line_no, model, qty, note,
                 is_deleted, created_at, created_by)
            VALUES (@docId, @lineNo, @model, @qty, @note,
                    0, SYSDATETIME(), @user);
            """;

        var n = 0;
        foreach (var l in lines)
            await conn.ExecuteAsync(sql, new
            {
                docId,
                lineNo = ++n,
                model = l.Model,
                qty = l.Qty,
                note = l.Note,
                user,
            }, tx);
    }

    public async Task<bool> UpdateAsync(ReturnInstruction doc, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var n = await conn.ExecuteAsync("""
                UPDATE wms.return_instructions
                SET    customer      = @customer,
                       expected_date = @expectedDate,
                       note          = @note,
                       updated_at    = SYSDATETIME(),
                       updated_by    = @user
                WHERE  id = @id AND is_deleted = 0;
                """,
                new
                {
                    id = doc.Id,
                    customer = doc.Customer,
                    expectedDate = doc.ExpectedDate,
                    note = doc.Note,
                    user,
                }, tx);

            if (n == 0) { tx.Rollback(); return false; }

            // Xoá mềm rồi chèn lại thay vì so từng dòng: danh sách ngắn (vài
            // chục dòng), và so khớp từng dòng để quyết thêm/sửa/xoá là chỗ dễ
            // sai hơn nhiều so với cái nó tiết kiệm được.
            //
            // Xoá MỀM vì mục 2 trở đi sẽ trỏ ngược về dòng chỉ thị — một dòng
            // từng tồn tại phải còn đọc được.
            await conn.ExecuteAsync("""
                UPDATE wms.return_instruction_lines
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  doc_id = @id AND is_deleted = 0;
                """, new { id = doc.Id, user }, tx);

            await InsertLinesAsync(conn, tx, doc.Id, doc.Lines, user);

            tx.Commit();
            return true;
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task<bool> SoftDeleteAsync(long id, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var n = await conn.ExecuteAsync("""
                UPDATE wms.return_instructions
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  id = @id AND is_deleted = 0;
                """, new { id, user }, tx);

            if (n == 0) { tx.Rollback(); return false; }

            await conn.ExecuteAsync("""
                UPDATE wms.return_instruction_lines
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  doc_id = @id AND is_deleted = 0;
                """, new { id, user }, tx);

            tx.Commit();
            return true;
        }
        catch { tx.Rollback(); throw; }
    }

    // ===================== Mục 2b: chốt thực nhận =====================

    public async Task<bool> CloseAsync(long id, string? user)
    {
        using var conn = _factory.Create();
        // Điều kiện doc_status = 'open' nằm TRONG câu UPDATE, không kiểm trước
        // rồi ghi sau: hai người cùng bấm Chốt thì người sau phải thấy 0 dòng
        // bị đổi, chứ không chốt lại và gửi FA hai lá mail.
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    doc_status = @completed,
                   closed_at  = SYSDATETIME(),
                   closed_by  = @user,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  id = @id AND is_deleted = 0 AND doc_status = @open;
            """, new
        {
            id,
            user,
            open = ReturnDocStatus.Open,
            completed = ReturnDocStatus.Completed,
        });
        return n > 0;
    }

    public async Task<bool> ReopenAsync(long id, string? user)
    {
        using var conn = _factory.Create();
        // KHÔNG xoá closed_at / actual_mail_sent_at: đó là dấu vết FA đã nhận
        // số nào, lúc nào. Chốt lại sẽ ghi đè bằng mốc mới.
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    doc_status = @open,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  id = @id AND is_deleted = 0 AND doc_status = @completed;
            """, new
        {
            id,
            user,
            open = ReturnDocStatus.Open,
            completed = ReturnDocStatus.Completed,
        });
        return n > 0;
    }

    public async Task MarkActualMailSentAsync(long id, string recipients)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    actual_mail_sent_at = SYSDATETIME(), actual_mail_sent_to = @recipients
            WHERE  id = @id;
            """, new { id, recipients });
    }

    public async Task MarkMailSentAsync(long id, string recipients)
    {
        using var conn = _factory.Create();
        await conn.ExecuteAsync("""
            UPDATE wms.return_instructions
            SET    mail_sent_at = SYSDATETIME(), mail_sent_to = @recipients
            WHERE  id = @id;
            """, new { id, recipients });
    }

    public async Task<IReadOnlyList<string>> FindUnknownModelsAsync(IReadOnlyList<string> models)
    {
        if (models.Count == 0) return [];

        using var conn = _factory.Create();
        // Trả về mã CÓ trong danh mục rồi lấy phần bù ở C#, thay vì nhét bảng
        // tạm vào SQL để lấy phần thiếu — danh sách chỉ vài chục mã.
        var known = (await conn.QueryAsync<string>("""
            SELECT m.code FROM master.models m
            WHERE m.is_deleted = 0 AND m.code IN @models;
            """, new { models })).ToHashSet(StringComparer.OrdinalIgnoreCase);

        return models.Where(m => !known.Contains(m)).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
    }

    public async Task<List<MailRecipient>> GetMailRecipientsAsync(string eventCode)
    {
        using var conn = _factory.Create();

        // ⚠ KHÔNG truyền NULL cho department.
        //
        // master.fn_email_recipients so KHỚP department, nên gọi với NULL thì
        // mọi dòng cấu hình có department (vd 'FA' — đúng cái sẽ khai cho FA
        // nhận mail) KHÔNG trả về, và mail im lặng không gửi.
        //
        // Cách đúng: liệt kê các BỘ PHẬN đang được cấu hình cho sự kiện này
        // rồi CROSS APPLY vào hàm tra. Nhờ vậy danh sách bộ phận nằm trong DỮ
        // LIỆU chứ không trong code — khai thêm một bộ phận trong màn Cấu hình
        // email là nó tự nhận mail, không phải build lại.
        //
        // Đây đúng khuôn đã dùng ở ShortageRepository.GetEventRecipientsAsync
        // và NgReportRepository.GetMailRecipientsAsync.
        const string sql = """
            SELECT DISTINCT
                   r.recipient_type AS Type, r.email AS Email, r.display_name AS DisplayName
            FROM   (SELECT DISTINCT c.department
                    FROM   master.email_config c
                    WHERE  c.event_code = @eventCode
                           AND c.is_active = 1 AND c.is_deleted = 0) d
            CROSS APPLY master.fn_email_recipients(
                            @eventCode, d.department, NULL, NULL, NULL, NULL) r;
            """;

        var rows = await conn.QueryAsync<MailRecipient>(sql, new { eventCode });

        // Normalize: một ô email được phép chứa nhiều địa chỉ ngăn bởi ',' hoặc
        // ';' (khai theo nhóm thay vì mỗi người một dòng), đã ở TO thì bỏ khỏi
        // CC/BCC, và khử trùng. Để nguyên cả cụm chuỗi thì SmtpMailSender nhận
        // một "địa chỉ" không hợp lệ và cả lá mail không đi.
        return MailRecipientList.Normalize(rows);
    }

    public async Task<MailTemplateRow?> GetMailTemplateAsync(string eventCode)
    {
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<MailTemplateRow>("""
            SELECT subject_template AS [Subject], body_template AS [Body]
            FROM   master.email_events
            WHERE  code = @eventCode AND is_active = 1;
            """, new { eventCode });
    }

    public async Task<string?> GetUserEmailAsync(string? employeeCode)
    {
        if (string.IsNullOrWhiteSpace(employeeCode)) return null;

        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<string?>("""
            SELECT TOP 1 u.email
            FROM   master.users u
            WHERE  u.employee_code = @employeeCode AND u.is_deleted = 0;
            """, new { employeeCode });
    }

    // ===================== Mục 2a: sổ serial =====================

    public async Task<IReadOnlyDictionary<string, int>> GetCategoryByModelAsync(
        IReadOnlyList<string> models)
    {
        var result = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
        if (models.Count == 0) return result;

        using var conn = _factory.Create();
        // category_id của master.models là MÃ category (JOIN master.categories.code),
        // không phải khoá nội bộ — xem ModelRepository. Pallet ID nhúng chính mã này.
        // JOIN master.categories, không chỉ kiểm category_id IS NOT NULL: model
        // mang mã category không còn trong danh mục thì phải rơi vào thông báo
        // "chưa khai category" của chính feature này, chứ không đi tới
        // GenerateNextLotNoAsync rồi trả 404 "Lot.CategoryNotFound" — một câu
        // nói về lot, giữa màn nhận hàng, không ai hiểu phải sửa ở đâu.
        var rows = await conn.QueryAsync<ModelCategoryRow>("""
            SELECT m.code        AS [Code],
                   m.category_id AS [CategoryCode]
            FROM   master.models     m
            JOIN   master.categories c ON c.code = m.category_id AND c.is_deleted = 0
            WHERE  m.is_deleted = 0 AND m.category_id IS NOT NULL
              AND  m.code IN @models;
            """, new { models = models.Distinct(StringComparer.OrdinalIgnoreCase).ToList() });

        foreach (var r in rows) result.TryAdd(r.Code, r.CategoryCode);
        return result;
    }

    private sealed class ModelCategoryRow
    {
        public string Code { get; set; } = string.Empty;
        public int CategoryCode { get; set; }
    }

    /// <summary>
    /// Chia lô 1000 mã mỗi câu: Dapper trải IN thành từng parameter, mà SQL
    /// Server chỉ cho 2100 parameter một câu — quét một pallet lớn là vượt.
    /// </summary>
    private const int SerialLookupChunk = 1000;

    public async Task<IReadOnlyList<ReturnSerialOwnerRow>> FindSerialOwnersAsync(
        IReadOnlyList<string> serials)
    {
        if (serials.Count == 0) return [];

        const string sql = """
            SELECT  s.serial_no AS [SerialNo],
                    s.doc_id    AS [DocId],
                    d.doc_no    AS [DocNo],
                    s.status    AS [Status]
            FROM wms.return_instruction_serials s
            -- d.is_deleted = 0 là BẮT BUỘC: thiếu nó thì WH nhận thông báo
            -- "serial này đang thuộc phiếu RW-…" trỏ vào một phiếu đã xoá mềm,
            -- mở ra thì 404 — bế tắc hoàn toàn ở cầu cảng.
            JOIN wms.return_instructions d ON d.id = s.doc_id AND d.is_deleted = 0
            WHERE s.is_deleted = 0
              -- Đã xuất cho khách thì thôi giữ chỗ: cùng một sản phẩm có thể bị
              -- trả về lần nữa và phải đăng ký được vào phiếu mới. Cùng điều kiện
              -- với unique index ux_ris_serial_open.
              AND s.status <> N'shipped'
              AND s.serial_no IN @serials;
            """;

        using var conn = _factory.Create();
        var all = new List<ReturnSerialOwnerRow>();

        foreach (var chunk in serials.Chunk(SerialLookupChunk))
            all.AddRange(await conn.QueryAsync<ReturnSerialOwnerRow>(
                sql, new { serials = chunk.ToList() }));

        return all;
    }

    public async Task RegisterSerialsAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletDbId,
        string disposition,
        IReadOnlyList<ReturnSerial> serials,
        string? user)
    {
        // Đóng dấu pallet là hàng return. disposition dùng CHUNG từ vựng với
        // return_instructions.goods_type (rework | refurbish) nên bản đồ kho vẽ
        // được badge RW/RB mà không cần lớp quy đổi nào.
        //
        // inspection_status = 'ng' (đổi 11/11, trước đó là 'inspection_exempt'):
        //   • Hàng khách trả về CHỜ TÁI GIA CÔNG thì đúng là NG — không phải
        //     "miễn kiểm". Nghiệp vụ cũng chốt pallet này mang trạng thái NG khi
        //     ra vị trí nhận hàng để giao FA, nên để NG từ đầu là nhất quán cả
        //     vòng đời, không có lúc nào bản đồ vẽ một màu khác.
        //   • Quan trọng hơn: bộ gom hàng xuất loại pallet bằng
        //     `inspection_status <> N'ng'` (ShipmentInstructionRepository).
        //     'inspection_exempt' LỌT bộ lọc đó, tức hàng tái gia công đang nằm
        //     trong kho có thể bị gom vào một chỉ thị xuất. 'ng' bịt đúng chỗ đó.
        //   • Vẫn không nằm chờ trong hàng đợi kiểm: 'ng' là trạng thái CUỐI,
        //     cùng nhóm với 'pass' / 'inspection_exempt' (OqcFinalStatuses).
        //
        // Đổi lại, nút "Lưu kho" phải mở theo disposition chứ không theo trạng
        // thái kiểm — xem PalletDetailResponse.BuildAllowedActions.
        await conn.ExecuteAsync("""
            UPDATE wms.pallets
            SET    disposition       = @disposition,
                   inspection_status = N'ng',
                   updated_at        = SYSDATETIME(),
                   updated_by        = @user
            WHERE  id = @palletDbId;
            """, new { disposition, palletDbId, user }, tx);

        if (serials.Count == 0) return;

        const string insert = """
            INSERT INTO wms.return_instruction_serials
                (doc_id, model, serial_no, box_no, pallet_id, status,
                 received_at, is_deleted, created_at, created_by)
            VALUES
                (@docId, @model, @serialNo, @boxNo, @palletDbId, @status,
                 SYSDATETIME(), 0, SYSDATETIME(), @user);
            """;

        await conn.ExecuteAsync(insert, serials.Select(s => new
        {
            docId,
            model = s.Model,
            serialNo = s.SerialNo,
            boxNo = s.BoxNo,
            palletDbId,
            status = ReturnSerialStatus.Received,
            user,
        }), tx);
    }

    public async Task<IReadOnlyList<ReturnPallet>> GetPalletsByDocAsync(long docId)
    {
        using var conn = _factory.Create();

        // Pallet của phiếu suy ra TỪ SỔ SERIAL, không từ một cột trên wms.pallets:
        // xem ghi chú ix_ris_pallet trong return_receiving_schema.sql.
        const string palletSql = """
            SELECT  p.id               AS [Id],
                    RTRIM(p.pallet_id) AS [LotNo],
                    loc.locator_code   AS [LocatorCode],
                    -- box_count nullable trong DB; pallet mức serial thì server
                    -- luôn tính nên không null, vẫn ISNULL cho chắc vì Dapper
                    -- map NULL vào int là ném lỗi.
                    ISNULL(p.box_count, 0) AS [BoxCount],
                    p.created_at        AS [CreatedAt],
                    p.created_by        AS [CreatedBy],
                    s.cnt              AS [SerialCount]
            FROM (
                SELECT pallet_id, COUNT(*) AS cnt
                FROM   wms.return_instruction_serials
                WHERE  doc_id = @docId AND is_deleted = 0 AND pallet_id IS NOT NULL
                GROUP BY pallet_id
            ) s
            -- p.is_deleted = 0: pallet đã xoá thì đừng còn hiện trong danh sách
            -- pallet của phiếu.
            JOIN      wms.pallets     p   ON p.id = s.pallet_id AND p.is_deleted = 0
            LEFT JOIN master.locators loc ON loc.id = p.locator_id
            ORDER BY p.id DESC;
            """;

        const string modelSql = """
            SELECT  pallet_id AS [PalletDbId],
                    model     AS [Model],
                    COUNT(*)  AS [Qty]
            FROM   wms.return_instruction_serials
            WHERE  doc_id = @docId AND is_deleted = 0 AND pallet_id IS NOT NULL
            GROUP BY pallet_id, model;
            """;

        var pallets = (await conn.QueryAsync<ReturnPallet>(palletSql, new { docId })).ToList();
        if (pallets.Count == 0) return pallets;

        var models = await conn.QueryAsync<PalletModelRow>(modelSql, new { docId });
        var byPallet = models.GroupBy(m => m.PalletDbId)
                             .ToDictionary(g => g.Key, g => g.ToList());

        foreach (var p in pallets)
            if (byPallet.TryGetValue(p.Id, out var rows))
                p.ModelCounts = rows.ToDictionary(r => r.Model, r => r.Qty, StringComparer.OrdinalIgnoreCase);

        return pallets;
    }

    private sealed class PalletModelRow
    {
        public long PalletDbId { get; set; }
        public string Model { get; set; } = string.Empty;
        public int Qty { get; set; }
    }

    public async Task<ReturnReleaseResult> ReleasePalletAsync(
        long docId, long palletDbId, string? docNo, string? user)
    {
        var result = new ReturnReleaseResult();

        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // 1) Khoá pallet (UPDLOCK, HOLDLOCK) rồi mới đọc. Hai người cùng bấm
            //    huỷ một pallet thì người sau xếp hàng chờ và thấy pallet đã xoá,
            //    chứ không cùng đọc "còn đó" rồi cùng ghi hai dòng lịch sử xoá.
            var pal = await conn.QuerySingleOrDefaultAsync<PalletRow>("""
                SELECT TOP 1
                       p.id                AS [Id],
                       RTRIM(p.pallet_id)  AS [LotNo],
                       p.locator_id        AS [LocatorId],
                       loc.locator_code    AS [LocatorCode],
                       (SELECT COUNT(*) FROM wms.boxes b
                        WHERE b.lot_id = p.id AND b.is_deleted = 0) AS [BoxCount]
                FROM      wms.pallets     p WITH (UPDLOCK, HOLDLOCK)
                LEFT JOIN master.locators loc
                       ON loc.id = p.locator_id AND loc.is_deleted = 0
                WHERE  p.id = @palletDbId AND p.is_deleted = 0;
                """, new { palletDbId }, tx);

            if (pal is null)
            {
                result.NotFound = true;
                tx.Rollback();
                return result;
            }

            result.LocatorCode = pal.LocatorCode;

            // 2) Sổ serial của PHIẾU NÀY trên pallet đó, gom theo trạng thái.
            //
            //    Kiểm TRONG transaction, không phải một câu SELECT riêng ở tầng
            //    service: giữa lúc service kiểm và lúc ghi, một lượt out kho có
            //    thể vừa đẩy serial sang at_fa.
            var byStatus = (await conn.QueryAsync<StatusRow>("""
                SELECT s.status AS [Status], COUNT(*) AS [Qty]
                FROM   wms.return_instruction_serials s
                WHERE  s.doc_id = @docId AND s.pallet_id = @palletDbId
                  AND  s.is_deleted = 0
                GROUP BY s.status;
                """, new { docId, palletDbId }, tx)).ToList();

            if (byStatus.Count == 0)
            {
                // Không dòng sổ nào ⇒ pallet không thuộc phiếu này. Chặn ở đây
                // để một request nhầm id không xoá pallet của phiếu khác, hay
                // xoá một pallet hàng thường.
                result.NotOfDoc = true;
                tx.Rollback();
                return result;
            }

            // CHẶN khi còn con nào KHÔNG ở 'received' — hàng đã rời kho SCS.
            //
            // Trước 11/11 câu UPDATE dưới không có điều kiện status, nên serial
            // đang ở at_fa cũng bị xoá mềm: hàng nằm ở FA mà sổ nói chưa từng
            // nhận, AtFaQty tụt lặng lẽ, và wms.return_back_deliveries còn dòng
            // nhật ký trỏ vào một pallet đã xoá. Huỷ lần nhận là để sửa một lượt
            // QUÉT SAI, không phải để rút lại hàng đã giao.
            var left = byStatus.FirstOrDefault(x => x.Status != ReturnSerialStatus.Received);
            if (left is not null)
            {
                result.HasLeftWarehouse = true;
                result.BlockingStatus = left.Status;
                result.BlockingQty = left.Qty;
                tx.Rollback();
                return result;
            }

            // 3) Xoá mềm sổ serial của đúng pallet đó trong đúng phiếu đó.
            //    Phải giải phóng serial, nếu không ux_ris_serial_open giữ chúng
            //    mãi và không bao giờ quét lại được vào pallet mới.
            //
            //    Điều kiện status vẫn để trong câu UPDATE dù đã kiểm ở trên: hai
            //    lớp cùng nói một điều, nhưng lớp này nằm trong chính câu ghi.
            result.FreedSerials = await conn.ExecuteAsync("""
                UPDATE wms.return_instruction_serials
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  doc_id = @docId AND pallet_id = @palletDbId
                  AND  status = N'received' AND is_deleted = 0;
                """, new { docId, palletDbId, user }, tx);

            // 4) Pallet cũng xoá mềm, cùng transaction: để lại một pallet rỗng mà
            //    serial đã tháo khỏi sổ là hai nguồn sự thật nói khác nhau.
            //
            //    NHẢ VỊ TRÍ (locator_id = NULL) trong cùng câu UPDATE: pallet đã
            //    lưu kho thì nó đang chiếm một ô kệ. Chỉ bật is_deleted là ô kệ
            //    hiện trống trên bản đồ (mọi câu map lọc is_deleted = 0) nhưng
            //    locator_id vẫn trỏ vào đó, nên mọi câu đếm theo locator_id còn
            //    tính nó.
            await conn.ExecuteAsync("""
                UPDATE wms.pallets
                SET    is_deleted = 1,
                       locator_id = NULL,
                       updated_at = SYSDATETIME(),
                       updated_by = @user
                WHERE  id = @palletDbId AND is_deleted = 0;
                """, new { palletDbId, user }, tx);

            await conn.ExecuteAsync("""
                UPDATE wms.boxes
                SET    is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE  lot_id = @palletDbId AND is_deleted = 0;
                """, new { palletDbId, user }, tx);

            await conn.ExecuteAsync("""
                UPDATE bl
                SET    bl.is_deleted = 1, bl.updated_at = SYSDATETIME(), bl.updated_by = @user
                FROM   wms.box_lines bl
                JOIN   wms.boxes b ON b.id = bl.box_id
                WHERE  b.lot_id = @palletDbId AND bl.is_deleted = 0;
                """, new { palletDbId, user }, tx);

            // 5) Ghi lịch sử — TRONG transaction, trước Commit.
            //
            //    PALLET_DELETED mang luôn from_locator_id: một dòng trả lời đủ
            //    "pallet mất lúc nào, lúc đó đang ở đâu, vì phiếu nào". Không ghi
            //    thêm STORAGE_OUT: hai dòng cho một thao tác làm timeline đọc ra
            //    như pallet ra khỏi kho rồi mới bị xoá, trong khi nó bị xoá TẠI
            //    vị trí đó.
            //
            //    KHÔNG mở khoá wms.part_cards như LotRepository.SoftDeleteAsync:
            //    pallet hàng return tạo với RawPayload = null ở mọi thùng
            //    (ReturnPalletRequestFactory) nên không có thẻ in nào bị khoá.
            await _events.WriteAsync(conn, tx, new StockEvent
            {
                SubjectType = StockEventSubjects.Pallet,
                PalletId = palletDbId,
                EventCode = StockEventCodes.PalletDeleted,
                Actor = user,
                FromLocatorId = pal.LocatorId,
                RefType = StockEventRefTypes.ReturnInstruction,
                RefId = docId,
                RefNo = docNo,
                BoxCountBefore = pal.BoxCount,
                BoxCountAfter = 0,
                Note = $"Huy lan nhan: giai phong {result.FreedSerials} serial khoi so phieu.",
            });

            tx.Commit();
            return result;
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>Hiện trạng pallet lúc huỷ lần nhận.</summary>
    private sealed class PalletRow
    {
        public long Id { get; set; }
        public string LotNo { get; set; } = string.Empty;
        public long? LocatorId { get; set; }
        public string? LocatorCode { get; set; }
        public int BoxCount { get; set; }
    }

    /// <summary>Số serial của phiếu trên pallet, gom theo trạng thái.</summary>
    private sealed class StatusRow
    {
        public string Status { get; set; } = string.Empty;
        public int Qty { get; set; }
    }

    public async Task<IReadOnlyList<ReturnSerial>> GetSerialsByDocAsync(long docId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<ReturnSerial>("""
            SELECT  s.id          AS [Id],
                    s.doc_id      AS [DocId],
                    s.model       AS [Model],
                    s.serial_no   AS [SerialNo],
                    s.box_no      AS [BoxNo],
                    s.pallet_id   AS [PalletDbId],
                    RTRIM(p.pallet_id) AS [PalletNo],
                    s.status      AS [Status],
                    s.received_at AS [ReceivedAt],
                    s.created_by  AS [CreatedBy]
            FROM      wms.return_instruction_serials s
            LEFT JOIN wms.pallets p ON p.id = s.pallet_id
            WHERE  s.doc_id = @docId AND s.is_deleted = 0
            ORDER BY s.model, s.serial_no;
            """, new { docId })).ToList();
    }

    // ───────────────── Mục 2d — FA đóng lại Pallet ID ─────────────────

    public async Task<IReadOnlyList<ReturnSerialIndexRow>> GetSerialIndexAsync(long docId)
    {
        using var conn = _factory.Create();

        // Ba cột, không ORDER BY: PDA nạp vào Map để tra theo serial, thứ tự
        // không dùng tới. Một phiếu vài nghìn dòng thì bỏ được ORDER BY là bỏ
        // được một lần sort.
        return (await conn.QueryAsync<ReturnSerialIndexRow>("""
            SELECT  s.serial_no AS [SerialNo],
                    s.model     AS [Model],
                    s.status    AS [Status]
            FROM   wms.return_instruction_serials s
            WHERE  s.doc_id = @docId AND s.is_deleted = 0;
            """, new { docId })).ToList();
    }

    public async Task<IReadOnlyList<ReturnSerialResolution>> ResolveSerialsAsync(
        IReadOnlyList<string> serials)
    {
        if (serials.Count == 0) return [];

        const string sql = """
            SELECT  s.serial_no AS [SerialNo],
                    s.doc_id    AS [DocId],
                    d.doc_no    AS [DocNo],
                    s.model     AS [Model],
                    s.status    AS [Status]
            FROM wms.return_instruction_serials s
            -- d.is_deleted = 0: cùng lý do đã ghi ở FindSerialOwnersAsync —
            -- không báo FA rằng serial thuộc một phiếu đã xoá mềm.
            JOIN wms.return_instructions d ON d.id = s.doc_id AND d.is_deleted = 0
            WHERE s.is_deleted = 0
              -- KHÔNG loại 'shipped' ở đây, khác FindSerialOwnersAsync: mục 2a
              -- cần biết "serial còn chỗ trống không", còn mục 2d cần biết "con
              -- này đã đi đâu" — một con đã xuất mà FA quét ra là chuyện phải
              -- vào nhật ký (wrong_status), không phải chuyện bỏ qua.
              AND s.serial_no IN @serials;
            """;

        using var conn = _factory.Create();
        var all = new List<ReturnSerialResolution>();

        foreach (var chunk in serials.Chunk(SerialLookupChunk))
            all.AddRange(await conn.QueryAsync<ReturnSerialResolution>(
                sql, new { serials = chunk.ToList() }));

        return all;
    }

    public async Task<int> AttachFaPalletAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletDbId,
        string disposition,
        IReadOnlyList<ReturnFaSerialRow> serials,
        string? user)
    {
        // Đóng dấu pallet mới y như pallet nhận ở mục 2a: cùng từ vựng
        // disposition (rework | refurbish) nên bản đồ kho và tem vẽ badge RW/RB
        // mà không cần lớp quy đổi.
        //
        // inspection_status = 'ng' y như pallet mục 2a (đổi 11/11, trước là
        // 'inspection_exempt'). Hàng FA rework xong CHƯA ai nghiệm thu lại:
        // 'inspection_exempt' lọt bộ lọc gom hàng xuất
        // (`inspection_status <> N'ng'`), nên nó có thể bị xuất đi mà không qua
        // bước nào xác nhận đã sửa được. Ai duyệt xong thì đổi trạng thái, chứ
        // không mặc định cho đi.
        await conn.ExecuteAsync("""
            UPDATE wms.pallets
            SET    disposition       = @disposition,
                   inspection_status = N'ng',
                   updated_at        = SYSDATETIME(),
                   updated_by        = @user
            WHERE  id = @palletDbId;
            """, new { disposition, palletDbId, user }, tx);

        if (serials.Count == 0) return 0;

        // CHUYỂN pallet của dòng sổ đã có, KHÔNG chèn dòng mới: con hàng này đã
        // được đăng ký từ mục 2a, chèn thêm là vỡ ux_ris_serial_open.
        //
        // status giữ nguyên at_fa — xem ghi chú ở interface.
        const string update = """
            UPDATE wms.return_instruction_serials
            SET    pallet_id  = @palletDbId,
                   box_no     = @boxNo,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  doc_id    = @docId
               AND serial_no = @serialNo
               AND is_deleted = 0
               AND status    = N'at_fa';
            """;

        return await conn.ExecuteAsync(update, serials.Select(s => new
        {
            docId,
            palletDbId,
            serialNo = s.SerialNo,
            boxNo = s.BoxNo,
            user,
        }), tx);
    }

    /// <summary>
    /// Câu INSERT dùng chung cho hai overload ghi nhật ký. Một chuỗi, không hai
    /// bản sao: hai bản là sớm muộn một bên thiếu cột.
    /// </summary>
    private const string MismatchInsertSql = """
        INSERT INTO wms.return_serial_mismatches
            (doc_id, pallet_id, serial_no, model, reason,
             found_status, other_doc_no, scanned_at, scanned_by,
             is_deleted, created_at, created_by)
        VALUES
            (@docId, @palletId, @serialNo, @model, @reason,
             @foundStatus, @otherDocNo, SYSDATETIME(), @user,
             0, SYSDATETIME(), @user);
        """;

    /// <summary>
    /// Một bộ tham số của <see cref="MismatchInsertSql"/>.
    ///
    /// Record có TÊN, không phải anonymous type, vì bộ tham số này dựng ở một
    /// hàm dùng chung cho hai overload — mà hàm thì không trả về được anonymous
    /// type. Và KHÔNG dùng <c>object[]</c>: Dapper suy tên tham số từ KIỂU phần
    /// tử của danh sách, nên một mảng <c>object</c> làm nó không thấy property
    /// nào và câu INSERT chạy với tham số rỗng.
    /// </summary>
    private sealed record MismatchParamRow(
        long DocId, long? PalletId, string SerialNo, string? Model,
        string Reason, string? FoundStatus, string? OtherDocNo, string? User);

    private static List<MismatchParamRow> MismatchParams(
        long docId, long? palletDbId,
        IReadOnlyList<ReturnSerialMismatch> rows, string? user)
        => rows.Select(r => new MismatchParamRow(
            docId, palletDbId, r.SerialNo, Blank(r.Model),
            r.Reason, Blank(r.FoundStatus), Blank(r.OtherDocNo), user)).ToList();

    public async Task AddMismatchesAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long? palletDbId,
        IReadOnlyList<ReturnSerialMismatch> rows,
        string? user)
    {
        if (rows.Count == 0) return;

        await conn.ExecuteAsync(
            MismatchInsertSql, MismatchParams(docId, palletDbId, rows, user), tx);
    }

    public async Task AddMismatchesAsync(
        long docId, IReadOnlyList<ReturnSerialMismatch> rows, string? user)
    {
        if (rows.Count == 0) return;

        using var conn = _factory.Create();

        // pallet_id = NULL: gọi bản này nghĩa là KHÔNG con nào khớp nên chẳng có
        // pallet nào được tạo. Cột để NULL đúng ý nghĩa, xem ghi chú trong
        // return_fa_pallet_schema.sql.
        await conn.ExecuteAsync(
            MismatchInsertSql, MismatchParams(docId, null, rows, user));
    }

    /// <summary>
    /// Cột của một dòng nhật ký. LEFT JOIN sang pallet để lấy mã 12 số cho màn
    /// hình — LEFT vì nhật ký cố tình sống lâu hơn pallet (không có FK), nên
    /// INNER JOIN sẽ làm dòng cũ biến mất đúng lúc cần tra lại nhất.
    /// </summary>
    private const string MismatchColumns = """
        SELECT  m.id           AS [Id],
                m.doc_id       AS [DocId],
                m.pallet_id    AS [PalletId],
                RTRIM(p.pallet_id) AS [LotNo],
                m.serial_no    AS [SerialNo],
                m.model        AS [Model],
                m.reason       AS [Reason],
                m.found_status AS [FoundStatus],
                m.other_doc_no AS [OtherDocNo],
                m.scanned_at   AS [ScannedAt],
                m.scanned_by   AS [ScannedBy],
                m.resolved_at  AS [ResolvedAt],
                m.resolved_by  AS [ResolvedBy],
                m.resolve_note AS [ResolveNote]
        FROM      wms.return_serial_mismatches m
        LEFT JOIN wms.pallets p ON p.id = m.pallet_id
        """;

    public async Task<IReadOnlyList<ReturnSerialMismatch>> GetMismatchesAsync(
        long docId, bool openOnly)
    {
        using var conn = _factory.Create();

        // @openOnly vào thẳng câu lệnh thay vì nối chuỗi: một kế hoạch thực thi
        // được cache cho cả hai nhánh, và không có đường nào cho SQL injection.
        //
        // ORDER BY có id DESC phá thế hoà: scanned_at là DATETIME2(0), cả một
        // lần quét 400 con rơi vào cùng một giây.
        var sql = MismatchColumns + """

            WHERE m.doc_id = @docId
              AND m.is_deleted = 0
              AND (@openOnly = 0 OR m.resolved_at IS NULL)
            ORDER BY m.scanned_at DESC, m.id DESC;
            """;

        return (await conn.QueryAsync<ReturnSerialMismatch>(
            sql, new { docId, openOnly = openOnly ? 1 : 0 })).ToList();
    }

    public async Task<ReturnSerialMismatch?> GetMismatchByIdAsync(long id)
    {
        using var conn = _factory.Create();

        var sql = MismatchColumns + """

            WHERE m.id = @id AND m.is_deleted = 0;
            """;

        return await conn.QuerySingleOrDefaultAsync<ReturnSerialMismatch>(sql, new { id });
    }

    public async Task<bool> ResolveMismatchAsync(long id, string? note, string? user)
    {
        using var conn = _factory.Create();

        // resolved_at IS NULL trong chính câu UPDATE — xem ghi chú ở interface.
        var n = await conn.ExecuteAsync("""
            UPDATE wms.return_serial_mismatches
            SET    resolved_at  = SYSDATETIME(),
                   resolved_by  = @user,
                   resolve_note = @note,
                   updated_at   = SYSDATETIME(),
                   updated_by   = @user
            WHERE  id = @id
               AND is_deleted = 0
               AND resolved_at IS NULL;
            """, new { id, note = Blank(note), user });

        return n > 0;
    }

    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}
