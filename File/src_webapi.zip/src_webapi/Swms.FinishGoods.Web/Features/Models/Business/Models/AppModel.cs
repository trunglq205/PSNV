namespace Swms.FinishGoods.Web.Features.Models.Business.Models;

/// <summary>
/// Quy tắc tầng rack — rack hiện có 4 tầng.
/// Phải khớp RackRowRule bên API core (và CK_models_suggest_rack_row trong DDL).
/// </summary>
public static class RackRowRule
{
    public const int Min = 1;
    public const int Max = 4;

    /// <summary>[1, 2, 3, 4] — dùng render nhóm checkbox trong form.</summary>
    public static IReadOnlyList<int> All { get; } =
        Enumerable.Range(Min, Max - Min + 1).ToList();

    /// <summary>
    /// Parse chuỗi tầng rack từ CSV. Chấp nhận nhiều loại phân cách ( , ; | / khoảng trắng )
    /// vì file do người dùng gõ tay. Trả về danh sách distinct + sắp tăng dần.
    /// Giá trị ngoài [Min..Max] trả về qua <paramref name="invalid"/> để caller báo lỗi.
    /// </summary>
    public static List<int> Parse(string? raw, out List<string> invalid)
    {
        invalid = new List<string>();
        var rows = new SortedSet<int>();
        if (string.IsNullOrWhiteSpace(raw)) return new List<int>();

        var parts = raw.Split(new[] { ',', ';', '|', '/', ' ', '\t' },
                              StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
        foreach (var p in parts)
        {
            if (int.TryParse(p, out var v) && v >= Min && v <= Max) rows.Add(v);
            else invalid.Add(p);
        }
        return rows.ToList();
    }

    /// <summary>
    /// Dạng ghi ra CSV. Dùng "|" thay vì "," để ô không chứa dấu phân cách của chính file CSV
    /// (tránh phụ thuộc vào việc exporter có bọc nháy kép hay không).
    /// </summary>
    public static string ToCsv(IEnumerable<int>? rows)
        => rows is null ? "" : string.Join('|', rows.Distinct().OrderBy(x => x));
}

/// <summary>1 dòng trong danh sách xuất xứ: mã 2 chữ cái + tên nước (+ tên gọi khác, dùng khi import CSV).</summary>
public sealed record OriginOption(string Code, string Name, string[]? Aliases = null)
{
    /// <summary>"VN - Vietnam" — cùng kiểu hiển thị với dropdown danh mục / khu vực.</summary>
    public string DisplayText => $"{Code} - {Name}";
}

/// <summary>
/// Danh sách xuất xứ được phép chọn + quy đổi mã. Mã lưu DB là 2 chữ cái viết HOA ("VN", "JP").
///
/// Thêm nước mới: thêm 1 dòng vào <see cref="All"/> (và enum tương ứng bên app PDA).
/// API core không cần sửa — OriginRule bên API và CK_models_origin chỉ kiểm tra "đúng 2 chữ cái".
/// </summary>
public static class OriginRule
{
    /// <summary>Định dạng mã gửi lên API: rỗng hoặc đúng 2 chữ cái — khớp OriginRule.Pattern bên API core.</summary>
    public const string Pattern = @"^\s*([A-Za-z]{2}\s*)?$";

    /// <summary>
    /// Sắp theo mã để khớp thứ tự hiển thị "MÃ - Tên" trong dropdown.
    /// ZZ = chưa xác định (có sẵn trong dữ liệu cũ, không phải mã nước).
    /// </summary>
    public static IReadOnlyList<OriginOption> All { get; } = new OriginOption[]
    {
        new("BE", "Belgium"),
        new("CH", "Switzerland"),
        new("CN", "China"),
        new("DE", "Germany"),
        new("GB", "United Kingdom", new[] { "UK" }),
        new("GR", "Greece"),
        new("HK", "Hong Kong"),
        new("ID", "Indonesia"),
        new("IL", "Israel"),
        new("IN", "India"),
        new("JP", "Japan"),
        new("KH", "Cambodia"),
        new("KR", "South Korea", new[] { "Korea" }),
        new("LK", "Sri Lanka"),
        new("MA", "Morocco"),
        new("MX", "Mexico"),
        new("MY", "Malaysia"),
        new("PH", "Philippines"),
        new("PL", "Poland"),
        new("SG", "Singapore"),
        new("TH", "Thailand"),
        new("TW", "Taiwan"),
        new("US", "USA"),
        new("VN", "Vietnam"),
        new("ZZ", "Unknown"),
    };

    /// <summary>Tra theo mã, không phân biệt hoa/thường: "vn" => VN. Không có => null.</summary>
    public static OriginOption? FindByCode(string? code)
    {
        var c = Normalize(code);
        return c is null ? null : All.FirstOrDefault(o => o.Code == c);
    }

    /// <summary>
    /// Tra theo mã HOẶC tên nước / tên gọi khác — dùng cho CSV gõ tay:
    /// "VN", "vietnam", "Korea" đều ra đúng dòng. Không có => null.
    /// </summary>
    public static OriginOption? Find(string? raw)
    {
        var s = raw?.Trim();
        if (string.IsNullOrEmpty(s)) return null;

        return FindByCode(s) ?? All.FirstOrDefault(o =>
            string.Equals(o.Name, s, StringComparison.OrdinalIgnoreCase)
            || (o.Aliases?.Any(a => string.Equals(a, s, StringComparison.OrdinalIgnoreCase)) ?? false));
    }

    /// <summary>
    /// "VN" => "VN - Vietnam" cho dialog chi tiết / tooltip. Rỗng => "".
    /// Mã không có trong danh sách (dữ liệu cũ) => trả nguyên mã để vẫn nhìn thấy.
    /// </summary>
    public static string Display(string? code)
        => FindByCode(code)?.DisplayText ?? Normalize(code) ?? "";

    /// <summary>" vn " => "VN". Rỗng/null => null (gửi null lên API = xoá xuất xứ).</summary>
    public static string? Normalize(string? raw)
        => string.IsNullOrWhiteSpace(raw) ? null : raw.Trim().ToUpperInvariant();
}

/// <summary>
/// Quy cách xếp pallet — phải khớp StackingRule + ValidateStacking bên API core.
/// Kích thước pallet tạm để hằng số 1200 × 1000 mm (chưa có master pallet).
/// </summary>
public static class StackingRule
{
    public const int PalletLength = 1200;   // mm
    public const int PalletWidth = 1000;    // mm
    public const int MaxLayer = 100;
    public const int MaxStacking = 100;

    /// <summary>mm -> chuỗi cm: 295 -> "29.5", 300 -> "30".</summary>
    public static string Cm(int mm)
        => (mm / 10m).ToString("0.#", System.Globalization.CultureInfo.InvariantCulture);

    /// <summary>Cargo (L × W, mm) nằm gọn trong pallet — xoay 90° cũng được.</summary>
    public static bool FitsPallet(int cargoLength, int cargoWidth)
        => (cargoLength <= PalletLength && cargoWidth <= PalletWidth)
        || (cargoLength <= PalletWidth && cargoWidth <= PalletLength);
}

// ── ViewModel dùng chung giữa trang và các dialog ──
public class AppModel
{
    public int Id { get; set; }
    public string Code { get; set; } = "";           // mã model (business key)
    public string GTIN { get; set; } = "";
    public string Origin { get; set; } = "";         // mã xuất xứ (OriginRule.All), vd "VN". Rỗng = chưa khai báo
    public int CategoryCode { get; set; }            // dùng cho CSV import/export
    public string CategoryName { get; set; } = "";
    public int Length { get; set; }                  // mm — kích thước carton
    public int Width { get; set; }                   // mm
    public int Height { get; set; }                  // mm
    public int StandardPacking { get; set; }         // set / box

    // ── Quy cách xếp pallet. Null = chưa cấu hình. ──
    public int? LayerLimit { get; set; }             // số tầng tối đa được chồng
    public int? LayerCount { get; set; }             // No of layer
    public int? StackingLength { get; set; }         // số thùng theo Length carton
    public int? StackingWidth { get; set; }          // số thùng theo Width carton

    /// <summary>Id khu vực gợi ý (FK). Null = chưa cấu hình. Đây là giá trị gửi lên API.</summary>
    public int? SuggestAreaId { get; set; }

    /// <summary>Mã khu vực — hiển thị + dùng cho CSV (FE resolve code → Id khi import).</summary>
    public string SuggestAreaCode { get; set; } = "";
    public string SuggestAreaName { get; set; } = "";

    /// <summary>Các tầng rack được phép lưu, vd [2, 3]. Rỗng = không cấu hình.</summary>
    public List<int> SuggestRackRow { get; set; } = new();

    public bool IsActive { get; set; } = true;
    public string CreatedAt { get; set; } = "";

    /// <summary>
    /// Chỉ có khi dòng này đọc từ CSV import: key các cột có điền giá trị (vd "origin", "length").
    /// Ô để trống = không điền = không gửi lên API (mã đã tồn tại thì giữ nguyên giá trị cũ).
    /// Null = không phải dòng import (dữ liệu từ API / form) -> coi như mọi cột đều có giá trị.
    /// </summary>
    public IReadOnlySet<string>? CsvFilled { get; set; }

    public bool IsCsvFilled(string columnKey) => CsvFilled?.Contains(columnKey) ?? true;

    // Tạo bản sao (dùng khi mở form sửa để không chỉnh trực tiếp bản gốc).
    // MemberwiseClone là shallow copy -> phải tự nhân bản List, nếu không form sửa
    // tầng rack sẽ ghi thẳng vào bản gốc trong danh sách dù người dùng bấm Huỷ.
    public AppModel Clone()
    {
        var copy = (AppModel)MemberwiseClone();
        copy.SuggestRackRow = new List<int>(SuggestRackRow);
        return copy;
    }

    // ── Giá trị tính ra (không lưu). Null khi chưa cấu hình xếp pallet. ──
    public bool HasStacking => LayerCount.HasValue && StackingLength.HasValue && StackingWidth.HasValue;

    public int? BoxPerLayer => StackingLength * StackingWidth;
    public int? BoxPerPallet => LayerCount * BoxPerLayer;              // thay Standard pallet
    public int? SetPerPallet => BoxPerPallet * StandardPacking;        // Set/plt

    public int? CargoLength => StackingLength * Length;                // mm
    public int? CargoWidth => StackingWidth * Width;                   // mm
    public int? CargoHeight => LayerCount * Height;                    // mm

    /// <summary>Kích thước carton "30 × 28 × 16" (cm).</summary>
    public string DimensionText =>
        $"{StackingRule.Cm(Length)} × {StackingRule.Cm(Width)} × {StackingRule.Cm(Height)}";

    /// <summary>Cargo only "120 × 84 × 96" (cm). Rỗng khi chưa cấu hình.</summary>
    public string CargoText => HasStacking
        ? $"{StackingRule.Cm(CargoLength!.Value)} × {StackingRule.Cm(CargoWidth!.Value)} × {StackingRule.Cm(CargoHeight!.Value)}"
        : "";

    /// <summary>"A01 - Khu A" cho cột danh sách / dialog chi tiết.</summary>
    public string SuggestAreaText => string.IsNullOrWhiteSpace(SuggestAreaCode)
        ? ""
        : string.IsNullOrWhiteSpace(SuggestAreaName) ? SuggestAreaCode : $"{SuggestAreaCode} - {SuggestAreaName}";

    /// <summary>"2, 3" cho cột danh sách / dialog chi tiết.</summary>
    public string SuggestRackRowText => SuggestRackRow.Count == 0
        ? ""
        : string.Join(", ", SuggestRackRow.OrderBy(x => x));

    /// <summary>Rút gọn dải liên tiếp cho cột danh sách: [1,2,3,4] -> "1–4"; [2,3] -> "2, 3".</summary>
    public string SuggestRackRowShort
    {
        get
        {
            var sorted = SuggestRackRow.Distinct().OrderBy(x => x).ToArray();
            var parts = new List<string>();
            for (int i = 0; i < sorted.Length; i++)
            {
                int start = sorted[i];
                while (i + 1 < sorted.Length && sorted[i + 1] == sorted[i] + 1) i++;
                parts.Add(sorted[i] - start >= 2 ? $"{start}–{sorted[i]}"
                        : sorted[i] == start ? $"{start}" : $"{start}, {sorted[i]}");
            }
            return string.Join(", ", parts);
        }
    }
}