﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class TrackingNumberImport
    {
        public string? Plant { get; set; }
        public string? VendorCode { get; set; }
        public string? InvoiceNo { get; set; }
        public string? TrackingNumber { get; set; }
        public string? Sloc { get; set; }
        public string? Material { get; set; }
        public string? PONo { get; set; }
        public string? POItem { get; set; }
    }
}
