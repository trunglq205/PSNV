using Swms.FinishGoods.Web.Features.Inventory.Business.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.Business;

/// <summary>
/// Cache catalog loại event (nhãn / nhóm / màu / icon).
///
/// Vì sao cần: API trả timeline KHÔNG kèm nhãn — 29 tổ hợp mà lặp ở mọi dòng thì
/// timeline 50 event là 50 lần lặp cùng chuỗi. Catalog tải một lần rồi tra theo
/// EventCode.
///
/// Đăng ký SINGLETON để sống qua các request, nhưng bản thân nó KHÔNG giữ Refit
/// client (client là scoped — nhét vào singleton sẽ hỏng DI). Thay vào đó nhận
/// loader từ tầng Business scoped ở lần gọi đầu.
/// </summary>
public sealed class StockEventCatalog
{
    private readonly SemaphoreSlim _gate = new(1, 1);
    private Dictionary<string, StockEventTypeDto> _map = new(StringComparer.OrdinalIgnoreCase);

    /// <summary>Hash nội dung catalog do API trả. Null = chưa tải lần nào.</summary>
    public string? Version { get; private set; }

    public bool IsLoaded => Version is not null;

    public StockEventTypeDto? Get(string code)
        => _map.TryGetValue(code, out var t) ? t : null;

    /// <summary>Tra theo nhóm — dùng khi dựng bộ lọc timeline.</summary>
    public IReadOnlyList<StockEventTypeDto> ByGroup(string groupCode)
        => _map.Values
               .Where(t => string.Equals(t.GroupCode, groupCode, StringComparison.OrdinalIgnoreCase))
               .OrderBy(t => t.SortOrder)
               .ToList();

    /// <summary>
    /// Tải catalog nếu chưa có. Lỗi mạng KHÔNG ném ra ngoài: timeline vẫn hiển thị
    /// được nhờ quy ước "stock_event." + code và màu mặc định, chỉ mất icon/nhóm.
    /// Lịch sử không nên chết vì một bảng master không tải được.
    /// </summary>
    public async Task EnsureLoadedAsync(Func<Task<StockEventTypeListDto?>> loader)
    {
        if (IsLoaded) return;

        await _gate.WaitAsync();
        try
        {
            if (IsLoaded) return;

            var list = await loader();
            if (list is null) return;

            _map = list.Types.ToDictionary(t => t.Code, StringComparer.OrdinalIgnoreCase);
            Version = list.Version;
        }
        catch
        {
            // Nuốt có chủ đích — xem chú thích trên.
        }
        finally
        {
            _gate.Release();
        }
    }

    /// <summary>Buộc tải lại ở lần EnsureLoadedAsync kế tiếp (sau khi đổi seed).</summary>
    public void Invalidate() => Version = null;
}
