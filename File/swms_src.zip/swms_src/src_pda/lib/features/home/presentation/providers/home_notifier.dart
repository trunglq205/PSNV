import 'package:flutter/material.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/router/app_route_paths.dart';
import 'package:swms_finish_goods/features/auth/domain/auth_repository.dart';
import 'package:swms_finish_goods/features/auth/presentation/providers/auth_providers.dart';
import 'package:swms_finish_goods/features/home/domain/home_entities.dart';
import 'package:swms_finish_goods/features/home/domain/home_repository.dart';
import 'package:swms_finish_goods/features/home/presentation/providers/home_providers.dart';
import 'package:swms_finish_goods/features/home/presentation/providers/home_state.dart';
import 'package:swms_finish_goods/shared/domain/roles_repository.dart';
import 'package:swms_finish_goods/shared/presentation/providers/providers.dart';

part 'home_notifier.g.dart';

const _toneStorage = Color(0xFF2E7D32);
const _toneStorageBg = Color(0xFFE8F5E9);
const _tonePicking = Color(0xFFF57C00);
const _tonePickingBg = Color(0xFFFFF3E0);
const _toneShipping = Color(0xFFC62828);
const _toneShippingBg = Color(0xFFFFEBEE);

// Dùng Notifier (không phải AsyncNotifier) vì state là HomeState thông thường;
// chỉ field assignments bên trong mới có loading.
@riverpod
class HomeNotifier extends _$HomeNotifier with BaseNotifierMixin<HomeState> {
  HomeRepository get _repo => ref.read(homeRepositoryProvider);

  AuthRepository get _authRepo => ref.read(authRepositoryProvider);

  RolesRepository get _rolesRepo => ref.read(rolesRepositoryProvider);

  @override
  HomeState build() => HomeState(groups: _staticGroups);

  void initData() {
    _loadUserInfo();
    _loadPinned();
    _loadAssignments();
    _loadFeatureGroup();
  }

  Future<void> _loadUserInfo() async {
    try {
      final userInfo = await _authRepo.getUserInfo();
      state = state.copyWith(
        fullName: userInfo.fullName,
        employeeCode: userInfo.employeeCode,
      );
    } catch (_) {}
  }

  Future<void> _loadPinned() async {
    try {
      final pinned = await _repo.getPinnedGroups();
      state = state.copyWith(pinned: pinned);
    } catch (_) {}
  }

  Future<void> _loadAssignments() => executePartial<List<AssignmentData>>(
    action: _repo.getAssignments,
    getField: (s) => s.assignments,
    setField: (s, v) => s.copyWith(assignments: v),
  );

  Future<void> _loadFeatureGroup() => executePartial<List<String>>(
    action: _rolesRepo.getPermissions,
    getField: (s) => s.permissions,
    setField: (s, v) => s.copyWith(permissions: v),
  );

  Future<void> refreshAssignments() => _loadAssignments();

  Future<void> refreshPermissions() => _loadFeatureGroup();

  Future<void> togglePin(String key) {
    final next = Set<String>.from(state.pinned);
    if (!next.remove(key)) next.add(key);
    return applyOptimistic(
      state.copyWith(pinned: next),
          (_) => _repo.savePinnedGroups(next),
    );
  }

  // ── Cấu hình cụm (tĩnh, không từ API) ───────────────────
  static final List<FeatureGroup> _staticGroups = [
    const FeatureGroup(
      key: 'inbound',
      titleKey: LocaleKeys.home_group_inbound,
      tone: AppColors.primary,
      toneBg: AppColors.primaryTint,
      items: [
        FeatureItem(
          key: 'pda_receiving.receive',
          nameKey: LocaleKeys.home_feature_part_card,
          icon: Icons.inventory_2,
          routeName: AppRoutePaths.partCard,
        ),
        FeatureItem(
          key: 'pda_receiving.receive',
          nameKey: LocaleKeys.home_feature_create_pallet,
          icon: Icons.qr_code,
          routeName: AppRoutePaths.receiving,
        ),
        FeatureItem(
          key: 'rework_refurbish.view',
          routeName: AppRoutePaths.returnInstruction,
          nameKey: LocaleKeys.home_feature_return_instruction,
          icon: Icons.assignment_return_outlined,
        ),
        FeatureItem(
          key: 'pda_receiving.abnormal_report',
          nameKey: LocaleKeys.home_feature_carton_ng,
          icon: Icons.warning_amber_rounded,
          routeName: AppRoutePaths.abnormalReport,
        ),
        FeatureItem(
          key: 'pda_receiving.temp_location',
          nameKey: LocaleKeys.home_feature_receive,
          icon: Icons.swap_horiz,
          routeName: AppRoutePaths.tempLocation,
        ),
      ],
    ),
    const FeatureGroup(
      key: 'storage',
      titleKey: LocaleKeys.home_group_storage,
      tone: _toneStorage,
      toneBg: _toneStorageBg,
      items: [
        FeatureItem(
          key: 'pda_storage.putaway',
          nameKey: LocaleKeys.home_feature_putaway,
          icon: Icons.shelves,
          routeName: AppRoutePaths.storing,
        ),
        FeatureItem(
          key: 'pda_storage.storage_map',
          nameKey: LocaleKeys.home_feature_storage_map,
          icon: Icons.map_outlined,
          routeName: AppRoutePaths.storageMap,
          alwaysVisible: true,
        ),
        FeatureItem(
          key: 'pda_storage.move',
          nameKey: LocaleKeys.home_feature_move,
          icon: Icons.swap_horiz,
          routeName: AppRoutePaths.warehouseMove,
        ),
        FeatureItem(
          key: 'pda_storage.stocktake_morning',
          nameKey: LocaleKeys.home_feature_stocktake_morning,
          icon: Icons.schedule,
          routeName: AppRoutePaths.stocktakeMorning,
          alwaysVisible: true,
        ),
        FeatureItem(
          key: 'pda_storage.stocktake_shipment',
          nameKey: LocaleKeys.home_feature_stocktake_shipment,
          icon: Icons.local_shipping_outlined,
          routeName: AppRoutePaths.stocktakeShipment,
          alwaysVisible: true,
        ),
        FeatureItem(
          key: 'pda_storage.stocktake_monthly',
          nameKey: LocaleKeys.home_feature_stocktake_monthly,
          icon: Icons.bar_chart,
          routeName: AppRoutePaths.stocktakeMonthly,
          alwaysVisible: true,
        ),
      ],
    ),
    const FeatureGroup(
      key: 'picking',
      titleKey: LocaleKeys.home_group_picking,
      tone: _tonePicking,
      toneBg: _tonePickingBg,
      items: [
        FeatureItem(
          key: 'si.view',
          routeName: AppRoutePaths.shipmentInstruction,
          nameKey: LocaleKeys.home_feature_si,
          icon: Icons.description_outlined,
        ),
        FeatureItem(
          key: 'picking.view',
          routeName: AppRoutePaths.kitting,
          nameKey: LocaleKeys.home_feature_pick,
          icon: Icons.outbox_outlined,
        ),
        FeatureItem(
          key: 'pda_outbound.tally',
          nameKey: LocaleKeys.home_feature_return_fa,
          icon: Icons.keyboard_return,
        ),
        FeatureItem(
          key: 'pda_outbound.emap_kitting',
          routeName: AppRoutePaths.vanningArea,
          nameKey: LocaleKeys.home_feature_emap_kitting,
          icon: Icons.grid_view,
        ),
      ],
    ),
    const FeatureGroup(
      key: 'shipping',
      titleKey: LocaleKeys.home_group_shipping,
      tone: _toneShipping,
      toneBg: _toneShippingBg,
      items: [
        // Theo thứ tự làm ngoài bãi: Pallet List → Pallet Stack → Stowage → Container → Hoàn tất
        FeatureItem(
          key: 'pda_shipping.vanning',
          routeName: AppRoutePaths.palletVanning,
          nameKey: LocaleKeys.home_feature_vanning,
          icon: Icons.merge_type_rounded,
        ),
        FeatureItem(
          key: 'pda_shipping.stowage',
          routeName: AppRoutePaths.stowagePlan,
          nameKey: LocaleKeys.home_feature_stowage,
          icon: Icons.grid_view,
        ),
        FeatureItem(
          key: 'pda_shipping.container',
          routeName: AppRoutePaths.containerCheck,
          nameKey: LocaleKeys.home_feature_container,
          icon: Icons.fact_check_outlined,
        ),
        FeatureItem(
          key: 'pda_shipping.container',
          routeName: AppRoutePaths.containerFinish,
          nameKey: LocaleKeys.home_feature_container_finish,
          icon: Icons.lock_outline_rounded,
        ),
        FeatureItem(
          key: 'pda_shipping.stowage',
          routeName: AppRoutePaths.stocky,
          nameKey: LocaleKeys.home_feature_stocky,
          icon: Icons.shopping_cart,
        ),
      ],
    ),
  ];
}