import 'package:dio/dio.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_back_model.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2c — truy cập API, gọi Dio TRỰC TIẾP thay vì qua retrofit.
//
//  Cùng lý do đã ghi ở return_back_model.dart: bộ mục 2c làm sao để KHÔNG cần
//  chạy build_runner, và @RestApi thì buộc phải sinh `.g.dart`.
//
//  Vẫn đi qua Dio CHUNG của app (`dioProvider`) nên giữ nguyên baseUrl, token
//  và ErrorInterceptor — câu thông báo lỗi của server vẫn tới được ErrorHandler
//  y như mọi màn khác.
//
//  Route treo trên PHIẾU (`/api/return-instructions/{id}/…`), không phải trên
//  một tài nguyên riêng: sau khi gộp thì luồng back là một mặt của phiếu.
//
//  Đường dẫn PHẢI có tiền tố `/api`: BASE_URL trong `config/*.json` chỉ tới
//  host + port (xem `app_config.dart`).
// ─────────────────────────────────────────────────────────────

class ReturnBackRepository {
  final Dio _dio;
  const ReturnBackRepository(this._dio);

  static String _base(int docId) => '/api/return-instructions/$docId';

  /// SL còn ở kho theo model — màn giao hàng hiện để WH soát đúng hàng.
  ///
  /// KHÔNG bắt DioException để bọc lại: ErrorInterceptor đã lấy câu thông báo
  /// của server và ErrorHandler hiện nguyên câu đó — bọc lại chỉ còn câu chung
  /// chung, mất thông tin.
  Future<List<BackRemainModel>> fetchRemain(int docId) async {
    final res = await _dio.get<Object?>('${_base(docId)}/back-remain');
    final data = res.data;
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => backRemainModelFromJson(e.cast<String, Object?>()))
        .toList();
  }

  /// Nhật ký pallet đã giao, mới nhất trước.
  Future<List<BackDelivery>> fetchDeliveries(int docId) async {
    final res = await _dio.get<Object?>('${_base(docId)}/back-deliveries');
    final data = res.data;
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => backDeliveryFromJson(e.cast<String, Object?>()))
        .toList();
  }

  /// Pallet hàng return của phiếu kèm vị trí trong kho.
  ///
  /// Dùng endpoint của mục 2a (`GET /pallets`) chứ không thêm endpoint mới: nó
  /// đã trả đúng `locatorCode` cho từng pallet, và màn web cũng đọc chính nó —
  /// hai màn cùng một nguồn thì không lệch nhau được.
  Future<List<BackPallet>> fetchPallets(int docId) async {
    final res = await _dio.get<Object?>('${_base(docId)}/pallets');
    final data = res.data;
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => backPalletFromJson(e.cast<String, Object?>()))
        .toList();
  }

  // deliver() đã XOÁ (11/11) cùng endpoint deliver-back bên API.
  //
  // Giao hàng cho FA giờ là việc đặt pallet vào một vị trí thuộc bản đồ Nhận
  // hàng, tức đi qua PUT /api/pallets/{id}/locator của màn vị trí tạm — không
  // còn lời gọi nào của riêng luồng back hàng.
  //
  // fetchDeliveries() ở trên GIỮ LẠI: nhật ký pallet đã giao vẫn đọc được.
}
