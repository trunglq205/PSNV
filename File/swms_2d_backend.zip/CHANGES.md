# Mục 2d — FA đóng lại Pallet ID sau rework (BACKEND)

16 file + 1 script SQL. **Nửa backend**; màn PDA cho FA ở gói kế tiếp.

⚠ **`Perms.cs` (API) và 4 resx API trong gói này thay bản ở `swms_2c_backend.zip`**
— cộng dồn.

## 1. Khác mục 2a ở ba điểm, và cả ba là lý do không dùng chung service

| | 2a — SCS WH nhận hàng khách trả | 2d — FA đóng pallet sau rework |
|---|---|---|
| Serial | **CHÈN** dòng mới vào sổ | **CẬP NHẬT** `pallet_id` của dòng sẵn có |
| Model | WH phải CHỌN model cho từng thùng | **suy từ sổ** — FA không nhập model |
| Serial lạ | **CHẶN**, không cho quét tiếp | **VẪN cho quét**, loại khỏi pallet + ghi nhật ký |

Điểm thứ ba là yêu cầu của anh. Nó kéo theo bảng nhật ký ở mục 2.

Trạng thái serial **giữ nguyên `at_fa`** sau khi FA đóng pallet: hàng vẫn ở FA,
chỉ là đã đóng thùng chờ giao. Mốc "đã về" là **mục 3**, do SCS quét nhận.
Nhờ vậy phân biệt được bằng dữ liệu, không cần giá trị status thứ sáu:

| Tình trạng thật | Trong sổ |
|---|---|
| đang rework ở FA | `at_fa`, `pallet_id` **NULL** |
| FA đã đóng pallet, chờ giao | `at_fa`, `pallet_id` = pallet FA |
| SCS đã nhận lại | `returned` (mục 3) |

## 2. `wms.return_serial_mismatches` — nhật ký serial lệch

**Vì sao phải có bảng, không chỉ hiện trên màn PDA:** người quét là **FA**,
người đặt hàng lạ riêng ra là **SCS WH** — hai người, hai thời điểm. Không lưu
thì SCS phụ thuộc vào việc FA có nhớ nói hay không.

**Vì sao không nhét vào sổ serial:** `ux_ris_serial_open` là UNIQUE trên
`serial_no` **toàn hệ thống**. Một con đang thuộc phiếu khác mà chèn thêm dòng
dưới `doc_id` này là vỡ index ngay.

Ba lý do tách riêng, vì FA xử lý khác nhau:

| `reason` | Nghĩa | FA làm gì |
|---|---|---|
| `not_in_doc` | không thuộc sổ nào | hàng lạ hoàn toàn, để riêng |
| `other_doc` | đang thuộc phiếu khác (ghi rõ **số phiếu**) | trả về đúng phiếu đó |
| `wrong_status` | đúng phiếu nhưng không ở `at_fa` (ghi rõ **status**) | tra lại lịch sử |

Có `resolved_at/by/note` để SCS đánh dấu đã xử lý, và index lọc
`resolved_at IS NULL` — màn hình cần **việc còn phải làm**, nhật ký cũ thì càng
ngày càng dài.

**Không** đặt unique trên `(doc_id, serial_no)`: FA quét lại con lạ lần hai là
một **sự kiện** khác, và đếm số lần quét sai cũng là thông tin.
**Không** đặt FK sang `wms.pallets`: pallet có thể bị xoá khi huỷ lần nhận, mà
nhật ký phải sống lâu hơn pallet.

## 3. Luồng xử lý một lần quét

1. Tra tất cả serial bằng `ResolveSerialsAsync` (**không lọc trạng thái**).
2. Phân loại: khớp → vào pallet; ba loại lệch → nhật ký.
3. **Không con nào khớp** → lưu nhật ký **TRƯỚC** rồi mới ném lỗi. Ném lỗi mà
   không lưu là mất sạch thông tin của cả lần quét, mà đó đúng là danh sách SCS
   cần.
4. Có con khớp → kiểm category (một pallet một category, vì Pallet ID nhúng mã
   category) → xin Pallet ID → tạo pallet.
5. **Trong CÙNG transaction tạo pallet**: gắn `pallet_id` vào serial khớp **và**
   ghi nhật ký kèm `pallet_id`. Pallet, sổ serial và nhật ký cùng sống cùng chết.
6. Response trả **nhật ký còn mở của cả phiếu**, không chỉ lần quét này: FA rời
   bàn là SCS đọc màn hình này, họ cần cả những con lần trước chưa ai xử lý.

Điều kiện `status = at_fa` nằm **trong câu UPDATE** khi gắn pallet: con vừa bị
người khác nhận về trong lúc FA đang quét thì không ăn, thay vì bị kéo ngược
trạng thái về `at_fa`.

## 4. `ResolveSerialsAsync` vs `FindSerialOwnersAsync` — hai hàm, không một hàm có cờ

Hàm cũ (mục 2a) lọc `status <> 'shipped'` — đúng cho 2a: hàng đã xuất thì thôi
giữ chỗ, vì cùng một sản phẩm có thể bị trả về lần nữa. Nhưng ở 2d, một con **đã
xuất** mà FA quét ra là chuyện phải nói rõ, không được rơi vào nhóm "không có
trong phiếu". Hàm mới cũng trả thêm `model` để PDA khỏi tra lần nữa.

## 5. `ReturnPalletRequestFactory` — tách khuôn pallet ra dùng chung

`BuildPalletRequest` trước nằm `private static` trong `ReturnInstructionService`
nên 2d không gọi được. Đã **chuyển ra** `Business/ReturnPalletRequestFactory.cs`
và sửa 2a gọi vào đó. Pallet hàng back phải **luôn mức serial, luôn một
category** — để mỗi service tự dựng là sớm muộn hai bên lệch nhau, mà lệch là
vỡ Pallet ID.

⚠ Vì vậy gói này có cả `ReturnInstructionService.cs` (đã bỏ hàm private đó).

## 6. Endpoint

| Method | Đường dẫn | Quyền |
|---|---|---|
| GET | `/api/return-instructions/{docId}/serial-index` | `view` |
| POST | `/api/return-instructions/{docId}/fa-pallets` | `process_fa` |
| GET | `/api/return-instructions/{docId}/mismatches?openOnly=true` | `view` |
| POST | `/api/return-instructions/{docId}/mismatches/{id}/resolve` | `process` ‖ `create` |

`serial-index` trả dạng **gọn** (`serial · model · status`), không dùng lại
`GET {id}/serials`: PDA tải **toàn bộ** serial của phiếu một lần để kiểm ngay lúc
quét. Một phiếu vài nghìn serial mà trả object đầy đủ là vài trăm KB; ba trường
là đủ. Trả cả con đã về / đã xuất để PDA phân biệt được ba loại cảnh báo.

`resolve` nhận cả `process` và `create`: người đặt hàng riêng ra là SCS WH, nhưng
Office cũng phải đóng được một dòng đã xử lý xong — cùng lý do hai bên đều chốt
được thực nhận ở 2b.

## 7. Quyền mới

| Lá | Dùng ở |
|---|---|
| `rework_refurbish.process_fa` | endpoint FA đóng pallet |
| `pda_receiving.return_fa_pallet` | tile "Tạo pallet sau rework" trên Home PDA |

Tách tile PDA riêng khỏi `pda_receiving.return_receive` vì **người dùng khác
hẳn**: FA chỉ cần tile của mình, không được thấy tile nhận hàng của WH.

## 8. i18n

12 khoá `Return.Fa.Err.*` vào **cả 4** resx API. Đã kiểm: 745 khoá mỗi file, tập
khoá **giống nhau**, placeholder khớp, 12/12 hằng `FaMsg` có khoá, và mỗi call
site truyền **đúng số tham số** câu dịch cần.

## 9. Áp dụng

1. Chạy `return_fa_pallet_schema.sql` (sau `return_back_request_schema.sql`).
2. Ghi đè 16 file.
3. Build API → seeder thêm 2 quyền mới.
4. Màn Roles: role FA thêm `rework_refurbish.process_fa` +
   `pda_receiving.return_fa_pallet` (và `rework_refurbish.view` nếu chưa có).
5. Test Swagger: `serial-index` lấy danh sách, rồi `fa-pallets` với vài serial
   `at_fa` **trộn** một serial lạ → xem response có `mismatchCount = 1` và
   `wms.return_serial_mismatches` có dòng mới.

## 10. Chưa có

- **Màn PDA cho FA** — gói kế tiếp.
- **Màn Web xem nhật ký lệch** — sẽ gộp vào gói mục 3 (khối "Đã giao lại" trên
  màn Tái gia công).
- **Mục 3** (SCS nhận lại pallet bằng một lần quét mã) — làm sau.
