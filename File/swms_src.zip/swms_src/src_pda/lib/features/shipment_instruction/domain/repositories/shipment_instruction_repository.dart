import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';

abstract class ShipmentInstructionRepository {
  /// Danh sách chỉ thị, phân trang. [status] null = tất cả.
  Future<ShipmentInstructionPage> getList({
    SiStatus? status,
    int page = 1,
    int size = 20,
  });

  /// Chi tiết chỉ thị kèm các dòng hàng.
  Future<ShipmentInstructionDetail> getDetail(int id);

  // Lấy hàng (PDA). Truyền cả task để giữ model / PO của dòng SI
  Future<PickTaskDetail> getPickTask(PickTask task);
  Future<PickTaskDetail> confirmPallet(PickTask task, String palletCode);
  Future<PickTaskDetail> pickBox(PickTask task, String boxNo);
  Future<PickTaskDetail> unpickBox(PickTask task, String boxNo);

  /// Lưu pallet tại vị trí vanning (bước cuối, sau khi đã lấy / tách).
  Future<PickTaskDetail> stageVanning(
      PickTask task, {
        required String palletCode,
        required String locatorCode,
      });
}