using Swms.FinishGoods.API.Common.Business;

namespace Swms.FinishGoods.API.Features.Sync.Business;

/// <summary>
/// Singleton giữ job đồng bộ đang chạy (chỉ chạy khi có người bấm nút).
///  - Chỉ 1 job tại 1 thời điểm — các bước cùng đụng vào vị trí / OQC của cùng
///    pallet, hai người bấm cùng lúc mà chạy chồng nhau là ghi đè lẫn nhau.
///  - Job chạy trên SERVER: đóng dialog, rời trang, tắt trình duyệt đều không dừng.
///  - Trạng thái để Web hỏi định kỳ qua GET /api/sync/status.
///
/// Phần việc thật nằm ở FossSyncJob (FA, OQC) và HdSoftSyncJob (vị trí).
///
/// Lưu ý: khoá này chỉ có hiệu lực trong 1 process. Chạy nhiều instance API sau
/// load balancer thì đổi sang sp_getapplock.
/// </summary>
public sealed class SyncRunner
{
    private readonly IServiceScopeFactory _scopes;
    private readonly ILogger<SyncRunner> _log;
    private readonly SemaphoreSlim _gate = new(1, 1);

    private volatile SyncProgress? _current;
    private CancellationTokenSource? _cts;

    public SyncRunner(IServiceScopeFactory scopes, ILogger<SyncRunner> log)
    {
        _scopes = scopes;
        _log = log;
    }

    /// <summary>Job đang chạy, hoặc lần chạy gần nhất.</summary>
    public SyncStatusResponse Status => _current?.Snapshot() ?? SyncStatusResponse.Idle;

    /// <summary>Khởi động nền rồi trả về ngay. False = đang có job khác.</summary>
    public bool TryStart(SyncJobKind kind, string actor, bool full)
    {
        if (!_gate.Wait(0)) return false;

        var cts = new CancellationTokenSource();
        var p = new SyncProgress { Kind = kind, Actor = actor, Full = full };
        _cts = cts;
        _current = p;

        // SuppressFlow: KHÔNG mang HttpContext của request sang job nền. Request trả về
        // xong là HttpContext bị huỷ, còn job thì vẫn chạy tiếp hàng phút.
        using (ExecutionContext.SuppressFlow())
            _ = Task.Run(() => RunCoreAsync(p, cts));

        return true;
    }

    public void Cancel()
    {
        try { _cts?.Cancel(); }
        catch (ObjectDisposedException) { /* job vừa kết thúc */ }
    }

    private async Task RunCoreAsync(SyncProgress p, CancellationTokenSource cts)
    {
        var ct = cts.Token;
        try
        {
            using var actorScope = ActorScope.Begin(p.Actor);
            await using var scope = _scopes.CreateAsyncScope();
            var foss = scope.ServiceProvider.GetRequiredService<IFossSyncJob>();
            var hdSoft = scope.ServiceProvider.GetRequiredService<IHdSoftSyncJob>();

            // Thứ tự có ý nghĩa: FA tạo pallet -> OQC -> vị trí.
            // Foss chạy trước để pallet có trong SWMS rồi HD soft mới gán vị trí được.
            if (p.Kind is SyncJobKind.Fa or SyncJobKind.All) await foss.SyncFaAsync(p, ct);
            if (p.Kind is SyncJobKind.Oqc or SyncJobKind.All) await foss.SyncOqcAsync(p, ct);
            if (p.Kind is SyncJobKind.HdSoft or SyncJobKind.All) await hdSoft.SyncHdSoftAsync(p, p.Full, ct);

            p.Phase = SyncPhase.Done;
        }
        catch (OperationCanceledException) when (ct.IsCancellationRequested)
        {
            p.Phase = SyncPhase.Cancelled;
        }
        catch (Exception ex)
        {
            _log.LogError(ex, "Pallet sync {Kind} failed", p.Kind);
            p.Phase = SyncPhase.Failed;
            p.Error = ex.Message;
        }
        finally
        {
            p.FinishedAt = DateTime.Now;

            _cts = null;
            cts.Dispose();
            _gate.Release();

            _log.LogInformation(
                "Pallet sync {Kind} by {Actor} {Phase} in {Seconds:0.0}s — created {Created}, oqc {Oqc}, locator {Locator}, failed {Failed}",
                p.Kind, p.Actor, p.Phase, (p.FinishedAt.Value - p.StartedAt).TotalSeconds,
                p.Created, p.OqcChanged, p.LocatorChanged, p.Failed);
        }
    }
}
