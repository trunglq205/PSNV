using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Features.Models.Client;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Client;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.Auth;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.App.Pages;

/// <summary>
/// Màn quản lý chỉ thị back hàng — mục 1 của quy trình return / refurbish.
///
/// SCS Office nhập model + SL khách báo trả về; tạo xong hệ thống tự gửi mail
/// báo FA (người nhận khai trong màn Cấu hình email, sự kiện
/// <c>RETURN_INSTRUCTION_CREATED</c>). SCS WH xem cùng dữ liệu này trên PDA.
/// </summary>
public partial class ReworkRefurbish
{
    [Inject] private IReturnInstructionApi Api { get; set; } = default!;
    [Inject] private IModelApi ModelApi { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;
    [Inject] private PermissionState Perm { get; set; } = default!;
    [Inject] private NavigationManager Nav { get; set; } = default!;

    /// <summary>null = tất cả. Thứ tự tab trên màn hình.</summary>
    private static readonly string?[] StatusTabs =
        { ReturnDocStatus.Open, ReturnDocStatus.Completed, ReturnDocStatus.Cancelled, null };

    private List<ReturnInstructionDto> _rows = new();
    private List<string> _models = new();

    /// <summary>
    /// Pallet hàng return theo từng phiếu, nạp LAZY khi bung dòng: danh sách
    /// phiếu có thể vài trăm dòng, nạp pallet của tất cả ngay từ đầu là vài
    /// trăm request cho thứ người dùng chỉ xem một hai phiếu.
    /// Không có khoá trong dictionary = đang nạp.
    /// </summary>
    private readonly Dictionary<long, List<ReturnPalletDto>> _pallets = new();

    /// <summary>
    /// Nhật ký serial lệch theo phiếu (mục 2d ghi khi FA đóng pallet). Nạp lazy
    /// cùng lúc với pallet, cùng lý do. Không có khoá = đang nạp.
    /// </summary>
    private readonly Dictionary<long, List<ReturnMismatchDto>> _mismatches = new();

    /// <summary>
    /// Mặc định CHỈ hiện dòng chưa xử lý: màn hình cần việc còn phải làm, nhật
    /// ký cũ thì càng ngày càng dài và đẩy việc mới xuống dưới.
    /// </summary>
    private bool _showResolvedMismatches;

    /// <summary>Dòng nhật ký đang chờ xác nhận đánh dấu đã xử lý, kèm phiếu.</summary>
    private (ReturnInstructionDto Doc, ReturnMismatchDto Row)? _resolving;

    /// <summary>Ghi chú người dùng gõ trong dialog đánh dấu đã xử lý.</summary>
    private string _resolveNote = "";

    private bool _loading = true;
    private string? _error;

    private string? _status = ReturnDocStatus.Open;
    private string _goodsType = "";
    private string _keyword = "";
    private DateTime? _fromDate;
    private DateTime? _toDate;

    private long? _expanded;

    // ── form tạo / sửa ──────────────────────────────────────
    private ReturnInstructionRequestDto? _form;
    private long? _editId;
    private string? _editDocNo;
    private string? _formError;
    private bool _saving;

    private ReturnInstructionDto? _deleting;

    /// <summary>Pallet đang chờ xác nhận huỷ lần nhận, kèm phiếu của nó.</summary>
    private (ReturnInstructionDto Doc, ReturnPalletDto Pallet)? _releasing;

    /// <summary>Phiếu đang chờ xác nhận chốt thực nhận (dialog hiện bảng lệch).</summary>
    private ReturnInstructionDto? _closing;

    /// <summary>Phiếu đang chờ xác nhận mở lại.</summary>
    private ReturnInstructionDto? _reopening;

    // ───────── Quyền ─────────
    // GIỮ KHỚP TỪNG DÒNG với attribute trên ReturnInstructionsController:
    // lệch một chỗ là hoặc user thấy nút rồi ăn 403, hoặc có quyền mà không
    // thấy nút. Hai cái đều khó lần ra vì Has() trả false IM LẶNG.
    //
    //   MayCreate   = [RequirePermission<...Create>]   POST, PUT, DELETE, reopen
    //   MayProcess  = [RequirePermission<...Process>]  POST {id}/pallets
    //   MayReceive  = [RequireAnyPermission<Process, Create>]  close, release
    //
    // Vì sao close/release nhận CẢ HAI: SCS WH chốt trên PDA, nhưng SCS Office
    // cũng phải chốt được trên web (quyết định nghiệp vụ 03/11) — hàng về rồi
    // mà WH không có máy thì phiếu không được treo.

    /// <summary>SCS Office: tạo / sửa / xoá phiếu, mở lại phiếu đã chốt.</summary>
    private bool MayCreate => Perm.Has(Perms.rework_refurbish_create.Key());

    /// <summary>SCS WH: quét thùng + serial để nhận hàng.</summary>
    private bool MayProcess => Perm.Has(Perms.rework_refurbish_process.Key());

    /// <summary>
    /// Chốt thực nhận và huỷ lần nhận — WH hoặc Office đều được, khớp
    /// <c>RequireAnyPermission&lt;Process, Create&gt;</c> ở controller.
    /// </summary>
    private bool MayCloseOrRelease => MayProcess || MayCreate;

    /// <summary>
    /// Quyền sửa cấu hình email là quyền HỆ THỐNG (<c>email_config.update</c>),
    /// không phải quyền của màn này — ai sửa được mail của module khác thì cũng
    /// sửa được ở đây. Cùng cách với màn Hàng bất thường.
    /// </summary>
    private bool MayEmailConfig => Perm.Has(Perms.email_config_update.Key());

    /// <summary>Dialog cấu hình 2 mail của quy trình back hàng.</summary>
    private bool _mailCfgOpen;

    private int FormTotalQty => _form?.Lines.Sum(l => l.Qty) ?? 0;

    /// <summary>
    /// Ngày về dự kiến tách riêng khỏi DTO: input type=date bind vào
    /// <c>DateTime?</c> được, nhưng để nguyên trong DTO thì phần giờ của
    /// DateTime.MinValue lọt xuống API. Gán lại lúc Lưu.
    /// </summary>
    private DateTime? _formExpectedDate;

    protected override async Task OnInitializedAsync()
    {
        // Mail báo FA mang link kèm ?docNo=... — mở link là lọc sẵn đúng phiếu,
        // người nhận không phải tự tìm trong danh sách.
        if (QueryHelpers.ParseQuery(new Uri(Nav.Uri).Query).TryGetValue("docNo", out var docNo))
        {
            _keyword = docNo.ToString();
            _status = null;                 // phiếu có thể đã đóng
        }

        await LoadModels();
        await Load();
    }

    /// <summary>
    /// Trang lấy mỗi lần khi nạp danh mục model. Cùng giá trị với
    /// <c>PartCards.MasterFetchSize</c> — hai màn cùng nạp toàn bộ danh mục
    /// nên dùng chung một cỡ trang để hành vi giống nhau.
    /// </summary>
    private const int ModelFetchSize = 9999;

    /// <summary>
    /// Nạp mã model một lần cho datalist, thay vì gọi lại server theo từng ký
    /// tự gõ: danh mục model của nhà máy cỡ vài nghìn dòng, tải một lần rẻ hơn
    /// nhiều so với một request mỗi lần gõ.
    ///
    /// Lặp theo trang cho tới khi hết, đúng cách <c>PartCards</c> đang làm:
    /// xin một trang thật lớn rồi tin là đã lấy hết là sai khi danh mục vượt
    /// cỡ trang, và lỗi đó im lặng — vài model cuối bảng chữ cái đơn giản là
    /// không gợi ý được.
    /// </summary>
    private async Task LoadModels()
    {
        var codes = new List<string>();
        try
        {
            for (var page = 1; ; page++)
            {
                // PagedQuery dùng tên `Size`, KHÔNG phải `PageSize`.
                var res = await ModelApi.GetAllAsync(
                    new ModelQuery { Page = page, Size = ModelFetchSize });

                var items = res.Items;
                if (items is null || items.Count == 0) break;

                codes.AddRange(items.Select(m => m.Code).Where(c => !string.IsNullOrWhiteSpace(c)));

                if (items.Count < ModelFetchSize) break;
            }
        }
        catch
        {
            // Datalist chỉ là gợi ý gõ nhanh. Tải hỏng thì vẫn nhập tay được,
            // và server vẫn kiểm model có trong danh mục hay không — nên nuốt
            // lỗi ở đây thay vì chặn cả màn hình.
        }

        _models = codes.Distinct(StringComparer.OrdinalIgnoreCase)
                       .OrderBy(c => c, StringComparer.OrdinalIgnoreCase)
                       .ToList();
    }

    private void SetStatus(string? s) { _status = s; _ = Load(); }

    private async Task OnKeywordKey(Microsoft.AspNetCore.Components.Web.KeyboardEventArgs e)
    {
        if (e.Key == "Enter") await Load();
    }

    private async Task Load()
    {
        _loading = true; _error = null; StateHasChanged();
        try
        {
            _rows = await Api.GetListAsync(
                status: _status,
                goodsType: string.IsNullOrWhiteSpace(_goodsType) ? null : _goodsType,
                keyword: string.IsNullOrWhiteSpace(_keyword) ? null : _keyword.Trim(),
                fromDate: _fromDate,
                toDate: _toDate);

            // Phiếu đang mở rộng mà biến mất khỏi kết quả lọc thì thu lại,
            // nếu không sẽ còn một hàng chi tiết mồ côi.
            if (_expanded is { } id && _rows.All(r => r.Id != id)) _expanded = null;

            // Bảng pallet + nhật ký lệch nạp lazy — xoá cache để lần bung sau
            // đọc lại số mới.
            _pallets.Clear();
            _mismatches.Clear();
            if (_expanded is { } stillOpen) _ = LoadDetail(stillOpen);
        }
        catch (Exception ex) { _error = Describe(ex); }
        finally { _loading = false; StateHasChanged(); }
    }

    private void Toggle(long id)
    {
        _expanded = _expanded == id ? null : id;
        if (_expanded == id) _ = LoadDetail(id);
    }

    /// <summary>
    /// Hai bảng con của phần chi tiết. Gọi SONG SONG rồi chờ cả hai: chúng
    /// không phụ thuộc nhau, nối tiếp là bắt người dùng chờ hai vòng mạng.
    /// </summary>
    private async Task LoadDetail(long docId)
        => await Task.WhenAll(LoadPallets(docId), LoadMismatches(docId));

    /// <summary>
    /// Pallet của một phiếu. Nạp lại mỗi lần bung: WH đang quét hàng trong lúc
    /// Office mở màn này, cache lại là Office nhìn số cũ mà không biết.
    /// Lỗi thì coi như không có pallet — không chặn cả màn hình vì một bảng con.
    /// </summary>
    private async Task LoadPallets(long docId)
    {
        _pallets.Remove(docId);
        StateHasChanged();
        try
        {
            _pallets[docId] = await Api.GetPalletsAsync(docId);
        }
        catch
        {
            _pallets[docId] = new List<ReturnPalletDto>();
        }
        StateHasChanged();
    }

    // ── nhật ký serial lệch (mục 2d) ────────────────────────

    /// <summary>
    /// Nhật ký serial lệch của một phiếu.
    ///
    /// Luôn xin CẢ dòng đã xử lý (<c>openOnly: false</c>) rồi lọc ở client: cái
    /// cần hiện là con số "còn bao nhiêu chưa xử lý", mà muốn có con số đó khi
    /// người dùng bật xem hết thì vẫn phải có cả hai nhóm trong tay. Nhật ký
    /// của một phiếu nhiều lắm vài chục dòng — không đáng một request nữa mỗi
    /// lần bật/tắt.
    ///
    /// Lỗi thì coi như nhật ký rỗng: bảng con không được làm chết cả màn hình,
    /// và DB chưa chạy <c>return_fa_pallet_schema.sql</c> thì endpoint này 500.
    /// </summary>
    private async Task LoadMismatches(long docId)
    {
        _mismatches.Remove(docId);
        StateHasChanged();
        try
        {
            _mismatches[docId] = await Api.GetMismatchesAsync(docId, openOnly: false);
        }
        catch
        {
            _mismatches[docId] = new List<ReturnMismatchDto>();
        }
        StateHasChanged();
    }

    /// <summary>Dòng nhật ký hiện trên bảng, theo công tắc "xem cả đã xử lý".</summary>
    private List<ReturnMismatchDto> VisibleMismatches(long docId)
        => !_mismatches.TryGetValue(docId, out var rows)
            ? new List<ReturnMismatchDto>()
            : (_showResolvedMismatches ? rows : rows.Where(r => !r.IsResolved).ToList());

    /// <summary>Số dòng CHƯA xử lý — con số quyết định có việc phải làm hay không.</summary>
    private int OpenMismatchCount(long docId)
        => _mismatches.TryGetValue(docId, out var rows)
            ? rows.Count(r => !r.IsResolved)
            : 0;

    private void AskResolveMismatch(ReturnInstructionDto doc, ReturnMismatchDto row)
    {
        _resolving = (doc, row);
        _resolveNote = "";
    }

    /// <summary>
    /// Đánh dấu đã xử lý. Chỉ ĐÓNG dòng nhật ký — KHÔNG sửa trạng thái con
    /// serial: nếu serial đó thuộc phiếu khác thì việc của nó nằm ở phiếu kia,
    /// còn ở đây chỉ ghi "SCS đã nhìn thấy và đã xử lý".
    /// </summary>
    private async Task ConfirmResolveMismatch()
    {
        if (_resolving is not { } r) return;

        _saving = true; StateHasChanged();
        try
        {
            var note = string.IsNullOrWhiteSpace(_resolveNote) ? null : _resolveNote.Trim();
            await Api.ResolveMismatchAsync(r.Doc.Id, r.Row.Id,
                new ResolveMismatchRequestDto { Note = note });

            _resolving = null;
            _resolveNote = "";
            await LoadMismatches(r.Doc.Id);
        }
        catch (Exception ex) { _error = Describe(ex); _resolving = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── tạo / sửa ───────────────────────────────────────────

    private void OpenCreate()
    {
        _editId = null;
        _editDocNo = null;
        _formError = null;
        _formExpectedDate = null;
        // Mặc định theo tab loại đang lọc: người dùng đang xem Rework thì
        // gần như chắc chắn đang tạo phiếu Rework.
        _form = new ReturnInstructionRequestDto
        {
            GoodsType = string.IsNullOrWhiteSpace(_goodsType) ? ReturnGoodsType.Rework : _goodsType,
        };
        AddLine();
    }

    private void OpenEdit(ReturnInstructionDto d)
    {
        _editId = d.Id;
        _editDocNo = d.DocNo;
        _formError = null;
        _formExpectedDate = d.ExpectedDate;
        _form = new ReturnInstructionRequestDto
        {
            GoodsType = d.GoodsType,
            Customer = d.Customer,
            Note = d.Note,
            // COPY sang object mới, không trỏ thẳng vào _rows: người dùng sửa
            // rồi bấm Huỷ thì bảng nền phải nguyên như cũ.
            Lines = d.Lines.Select(l => new ReturnInstructionLineRequestDto
            {
                Model = l.Model,
                Qty = l.Qty,
                Note = l.Note,
            }).ToList(),
        };
        if (_form.Lines.Count == 0) AddLine();
    }

    private void CloseForm() { _form = null; _formError = null; }

    private void AddLine() => _form?.Lines.Add(new ReturnInstructionLineRequestDto { Qty = 1 });

    private void RemoveLine(int idx)
    {
        if (_form is null || idx < 0 || idx >= _form.Lines.Count) return;
        _form.Lines.RemoveAt(idx);
        // Luôn chừa lại một dòng trống: bảng rỗng trông như hỏng, và người
        // dùng phải đi tìm nút Thêm dòng.
        if (_form.Lines.Count == 0) AddLine();
    }

    private async Task Save()
    {
        if (_form is null) return;

        // Kiểm sơ ở client để người dùng khỏi chờ một vòng mạng mới biết
        // thiếu ô. Server vẫn kiểm lại đầy đủ — đây chỉ là lớp cho nhanh.
        var lines = _form.Lines
            .Where(l => !string.IsNullOrWhiteSpace(l.Model))
            .ToList();

        if (lines.Count == 0) { _formError = L["Return.Err.LinesRequired"]; return; }
        if (lines.Any(l => l.Qty <= 0)) { _formError = L["Return.Err.QtyPositive"]; return; }

        // Loại hàng đã ở đầu phiếu nên trùng chỉ còn xét theo model.
        var dup = lines.GroupBy(l => l.Model.Trim().ToUpperInvariant())
                       .FirstOrDefault(g => g.Count() > 1);
        if (dup is not null)
        {
            _formError = L["Return.Err.DuplicateLine", dup.First().Model];
            return;
        }

        _saving = true; _formError = null; StateHasChanged();
        try
        {
            var body = new ReturnInstructionRequestDto
            {
                GoodsType = _form.GoodsType,
                Customer = _form.Customer,
                ExpectedDate = _formExpectedDate?.Date,
                Note = _form.Note,
                Lines = lines.Select(l => new ReturnInstructionLineRequestDto
                {
                    Model = l.Model.Trim(),
                    Qty = l.Qty,
                    Note = string.IsNullOrWhiteSpace(l.Note) ? null : l.Note.Trim(),
                }).ToList(),
            };

            if (_editId is { } id) await Api.UpdateAsync(id, body);
            else await Api.CreateAsync(body);

            _form = null;
            await Load();
        }
        catch (Exception ex) { _formError = Describe(ex); }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── xoá ─────────────────────────────────────────────────

    private void AskDelete(ReturnInstructionDto d) => _deleting = d;

    private async Task ConfirmDelete()
    {
        if (_deleting is null) return;
        _saving = true; StateHasChanged();
        try
        {
            await Api.DeleteAsync(_deleting.Id);
            _deleting = null;
            await Load();
        }
        catch (Exception ex) { _error = Describe(ex); _deleting = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── chốt thực nhận / mở lại (mục 2b) ────────────────────

    private void AskClose(ReturnInstructionDto d) => _closing = d;
    private void AskReopen(ReturnInstructionDto d) => _reopening = d;

    /// <summary>
    /// Chốt thực nhận. Server đóng phiếu RỒI tự gửi mail báo FA số thực tế —
    /// nên dialog phải cho người bấm xem bảng lệch trước, vì đó chính là nội
    /// dung FA sẽ đọc.
    /// </summary>
    private async Task ConfirmClose()
    {
        if (_closing is null) return;

        _saving = true; StateHasChanged();
        try
        {
            var saved = await Api.CloseAsync(_closing.Id);
            _closing = null;
            await Load();

            // Mail hỏng KHÔNG làm đổ việc chốt — nói ra để Office biết mà xử
            // lý tay, thay vì tưởng FA đã nhận được số.
            if (saved.ActualMailSentAt is null)
                _error = L["Return.ClosedButMailFailed", saved.DocNo];
        }
        catch (Exception ex) { _error = Describe(ex); _closing = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    private async Task ConfirmReopen()
    {
        if (_reopening is null) return;

        _saving = true; StateHasChanged();
        try
        {
            await Api.ReopenAsync(_reopening.Id);
            _reopening = null;
            await Load();
        }
        catch (Exception ex) { _error = Describe(ex); _reopening = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    // ── hiển thị lệch ───────────────────────────────────────

    /// <summary>Số lệch kèm dấu: <c>+6</c> / <c>-6</c> / <c>0</c>.</summary>
    private static string Signed(int qty) => qty > 0 ? $"+{qty:N0}" : qty.ToString("N0");

    private static string DiffClass(int qty) =>
        qty > 0 ? "ri-over" : qty < 0 ? "ri-short" : "ri-done";

    private static string DiffPill(int qty) =>
        qty > 0 ? "warn" : qty < 0 ? "st-short" : "ok";

    private string DiffState(int qty) =>
        qty > 0 ? L["Return.Diff.Over"]
        : qty < 0 ? L["Return.Diff.Short"]
        : L["Return.Diff.Exact"];

    /// <summary>
    /// Tô cột "Còn ở FA": &gt; 0 là CÒN HÀNG NGOÀI KHO, phải nổi lên. 0 thì làm
    /// mờ như các ô 0 khác — một bảng đầy số 0 đậm thì không còn số nào nổi.
    /// </summary>
    private static string AtFaClass(int qty) => qty > 0 ? "ri-atfa" : "ri-zero";

    /// <summary>
    /// Màu pill của lý do lệch. <c>other_doc</c> nặng nhất — con hàng đang
    /// thuộc phiếu khác, xử lý sai là hai phiếu cùng đếm một con.
    /// </summary>
    private static string MismatchPill(string reason) => reason switch
    {
        ReturnMismatchReason.OtherDoc => "st-short",
        ReturnMismatchReason.WrongStatus => "warn",
        _ => "st-cancelled",
    };

    // ── huỷ một lần nhận ────────────────────────────────────

    private void AskReleasePallet(ReturnInstructionDto doc, ReturnPalletDto pallet)
        => _releasing = (doc, pallet);

    /// <summary>
    /// Huỷ pallet đã nhận. Việc QUAN TRỌNG là nó giải phóng serial khỏi sổ:
    /// không có đường này thì một pallet quét sai khoá vĩnh viễn những con hàng
    /// đó khỏi mọi phiếu về sau.
    /// </summary>
    private async Task ConfirmReleasePallet()
    {
        if (_releasing is not { } r) return;

        _saving = true; StateHasChanged();
        try
        {
            await Api.ReleasePalletAsync(r.Doc.Id, r.Pallet.Id);
            _releasing = null;
            await Load();                 // SL thực nhận đã đổi
            await LoadPallets(r.Doc.Id);  // bảng pallet cũng đã đổi
        }
        catch (Exception ex) { _error = Describe(ex); _releasing = null; }
        finally { _saving = false; StateHasChanged(); }
    }

    /// <summary>
    /// Câu lỗi hiện cho người dùng. API trả envelope {status, title, ...} và
    /// <c>title</c> ĐÃ là câu đã dịch, nên ưu tiên dùng nguyên câu đó thay vì
    /// một câu chung chung — nó nói rõ model nào sai, phiếu nào khoá.
    /// </summary>
    private string Describe(Exception ex) =>
        ex is Refit.ApiException api && !string.IsNullOrWhiteSpace(api.Content)
            ? ExtractTitle(api.Content) ?? api.Message
            : ex.Message;

    private static string? ExtractTitle(string content)
    {
        try
        {
            using var doc = System.Text.Json.JsonDocument.Parse(content);
            return doc.RootElement.TryGetProperty("title", out var t) ? t.GetString() : null;
        }
        catch { return null; }
    }
}
