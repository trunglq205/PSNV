namespace Swms.FinishGoods.API.Features.StorageMap.Api;

/// <summary>Tóm tắt 1 kệ (cho danh sách/top-down).</summary>
public record RackSummaryResponse(
    string RackCode,
    string RackName,
    int TotalSlots,
    int OccupiedSlots,
    int PalletSlots,
    int ShelfSlots)
{
    public static RackSummaryResponse From(RackSummary r) =>
        new(r.RackCode, r.RackName, r.TotalSlots, r.OccupiedSlots, r.PalletSlots, r.ShelfSlots);
}

/// <summary>Một ô mặt đứng: location × floor + tình trạng chiếm chỗ.</summary>
/// <summary>Một pallet trong ô (ô có thể chứa nhiều pallet).</summary>
public record ElevationPalletResponse(
    long LotId,
    string? PalletId,
    string? Model,
    int? BoxCount,
    DateTime? ProductionDate,
    string? Disposition,
    bool StopShipment,
    string? Status,
    bool IsUrgent)
{
    public static ElevationPalletResponse From(ElevationPallet p) =>
        new(p.LotId, p.PalletId, p.Model, p.BoxCount, p.ProductionDate, p.Disposition, p.StopShipment,
            p.Status, p.IsUrgent);
}

public record ElevationCellResponse(
    long LocatorId,
    string LocatorCode,
    int Location,
    int Floor,
    string SlotKind,
    string? Level,
    bool Occupied,
    string? PalletId,
    string? Model,
    int? BoxCount,
    DateTime? ProductionDate,
    string? Disposition,
    bool StopShipment,
    string? Status,
    bool IsUrgent,
    IReadOnlyList<ElevationPalletResponse> Pallets)
{
    public static ElevationCellResponse From(ElevationLocator l) =>
        new(l.LocatorId, l.LocatorCode, l.Location, l.Floor, l.SlotKind, l.Level, l.Occupied, l.PalletId,
            l.Model, l.BoxCount, l.ProductionDate, l.Disposition, l.StopShipment, l.Status, l.IsUrgent,
            l.Pallets.Select(ElevationPalletResponse.From).ToList());
}

/// <summary>Mặt đứng đầy đủ của 1 kệ.</summary>
public record RackElevationResponse(
    string RackCode,
    string RackName,
    int MaxLocation,
    int MaxFloor,
    IReadOnlyList<ElevationCellResponse> Cells)
{
    public static RackElevationResponse From(RackSummary rack, IReadOnlyList<ElevationLocator> cells) =>
        new(
            rack.RackCode,
            rack.RackName,
            // Lưới ĐẦY ĐỦ theo kích thước kệ (vị trí × tầng); ô không có locator = X.
            rack.Cols > 0 ? rack.Cols : (cells.Count == 0 ? 0 : cells.Max(c => c.Location)),
            rack.Rows > 0 ? rack.Rows : (cells.Count == 0 ? 0 : cells.Max(c => c.Floor)),
            cells.Select(ElevationCellResponse.From).ToList());
}

/// <summary>Tồn theo từng vị trí (để chia ô trên top-down).</summary>
public record PositionOccResponse(int Position, int Total, int Occupied)
{
    public static PositionOccResponse From(PositionOcc p) => new(p.Position, p.Total, p.Occupied);
}

/// <summary>Một khối top-down (kệ/decor) + tỉ lệ chiếm chỗ.</summary>
public record TopMapBlockResponse(
    long Id,
    string Kind,
    string? RackCode,
    string? Label,
    string? Color,
    int GridX,
    int GridY,
    int GridW,
    int GridH,
    int TotalSlots,
    int OccupiedSlots,
    IReadOnlyList<PositionOccResponse> Positions,
    string? LocatorCode = null,
    string? Status = null,
    bool IsUrgent = false,
    string? Model = null,
    string? PalletId = null,
    int? BoxCount = null,
    DateTime? ProductionDate = null)
{
    public static TopMapBlockResponse From(TopMapBlock b) =>
        new(b.Id, b.Kind, b.RackCode, b.Label, b.Color,
            b.GridX, b.GridY, b.GridW, b.GridH, b.TotalSlots, b.OccupiedSlots,
            b.Positions.Select(PositionOccResponse.From).ToList(),
            b.LocatorCode, MapStatus(b.Status), b.IsUrgent,
            b.Model, b.PalletId, b.BoxCount, b.ProductionDate);

    // Đưa trạng thái về đúng key mà bản đồ dùng (khớp STATUS_META phía client).
    private static string MapStatus(string? s) => (s ?? "").ToLowerInvariant() switch
    {
        "pass" or "ok" => "pass",
        "ng" or "fail" => "ng",
        "under_inspection" or "inspecting" or "checking" => "under_inspection",
        "pending_result" or "waiting" or "wait_result" => "pending_result",
        "inspection_exempt" or "exempt" or "skip" => "inspection_exempt",
        "" => "empty",
        var v => v
    };
}

/// <summary>Sơ đồ top-down khu Storing.</summary>
public record TopMapResponse(
    string AreaCode,
    int Cols,
    int Rows,
    double CellMeters,
    IReadOnlyList<TopMapBlockResponse> Blocks)
{
    public static TopMapResponse From(TopMap m) =>
        new(m.AreaCode, m.Cols, m.Rows, m.CellMeters,
            m.Blocks.Select(TopMapBlockResponse.From).ToList());
}

/// <summary>Payload Lưu sơ đồ top-down.</summary>
public record SaveTopMapBlockRequest(
    long? Id, string Kind, long? RackId, string? Label, string? Color,
    int GridX, int GridY, int GridW, int GridH);

public record SaveTopMapRequest(IReadOnlyList<SaveTopMapBlockRequest> Blocks);

/// <summary>Tạo kệ mới trong editor.</summary>
public record CreateRackRequest(
    string Code, int Positions, int Floors, IReadOnlyList<int> ShelfPositions,
    int GridX, int GridY, int GridW, int GridH);

/// <summary>Đổi 1 ô pallet ⇄ giá lửng.</summary>
public record SetCellKindRequest(string RackCode, int Position, int Floor, string Kind, string? AreaCode = null);

/// <summary>Vị trí của một ô trên bản đồ — để PDA chọn đúng bản đồ và focus vào kệ/ô.</summary>
public record LocatorLocationResponse(
    string LocatorCode, string? AreaCode, string? AreaName, string? MapType,
    string? RackCode, int? RackCol, int? RackRow, string? RackLevel)
{
    public static LocatorLocationResponse From(LocatorLocation l) => new(
        l.LocatorCode, l.AreaCode, l.AreaName, l.MapType,
        l.RackCode, l.RackCol, l.RackRow, l.RackLevel);
}

/// <summary>Serial trong pallet — hiện khi xem chi tiết 1 ô của kệ.</summary>
public record PalletSerialResponse(string? BoxNo, string? Model, string? SerialNo, int? Qty)
{
    public static PalletSerialResponse From(PalletSerial s) => new(s.BoxNo, s.Model, s.SerialNo, s.Qty);
}
