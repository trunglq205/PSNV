﻿namespace SWMS_WebTool.Models.Responses
{
    public class TrolleyResponse
    {
        public string Barcode;
        public string Code;
    }
}
