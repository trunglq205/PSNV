using Swms.FinishGoods.Web.Features.ShipmentInstructions.App.Addons;

namespace Swms.FinishGoods.Web.Features.HdSoft.SiCompare.App;

/// <summary>Gắn nút "Đối chiếu HD soft" vào màn SI qua điểm cắm <see cref="ISiScreenAddon"/>:
///   - danh sách SI: mở <see cref="SiHdSoftCompareListDialog"/> (so theo khoảng ngày)
///   - dialog chi tiết SI: mở <see cref="SiCompareDialog"/> cho đúng SI đang xem.
/// Đăng ký ở HdSoftModule; xoá feature HD soft là màn SI tự mất 2 nút. Không gắn khối nào.</summary>
public sealed class SiHdSoftAddon : ISiScreenAddon
{
    private const string IcCompare =
        "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M7 7h13l-4-4M17 17H4l4 4'/></svg>";

    public int Order => 100;

    public SiAddonAction? ListAction { get; } =
        new("SiCmp.Btn.Open", "SiCmp.Lead", IcCompare, typeof(SiHdSoftCompareListDialog));

    public SiAddonAction? DetailAction { get; } =
        new("SiCmp.D.Open", "SiCmp.D.OpenHint", IcCompare, typeof(SiCompareDialog));

    public Type? DetailSection => null;
}