﻿using System;

namespace SWMS_WebTool.Utils
{
    public enum FlavorEnvironment
    {
        Develop,
        Staging
    }

    public static class EnvironmentExtensions
    {
        public static string GetBaseURL(this FlavorEnvironment value)
        {
            switch(value)
            {
                case FlavorEnvironment.Develop:
                    return "https://192.168.128.131:8024/";



                case FlavorEnvironment.Staging:
                    return "https://192.168.128.131:8024/";



                default:
                    return "https://192.168.128.131:8024/";
            }
        }

        public static string GetImageURL(this FlavorEnvironment value)
        {
            switch (value)
            {
                case FlavorEnvironment.Develop:
                    return "http://192.168.128.131:8025/";

                default:
                    return "http://192.168.128.131:8025/";
            }
        }
    }
}
