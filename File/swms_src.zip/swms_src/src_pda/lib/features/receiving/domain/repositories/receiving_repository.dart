import 'package:swms_finish_goods/features/receiving/domain/entities/create_lot_params.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/lot_entities.dart';
import 'package:swms_finish_goods/shared/domain/entities/model_info.dart';

/// Hợp đồng repository Receiving — domain layer, không biết nguồn dữ liệu.
abstract interface class ReceivingRepository {
  /// POST /api/pallets — tạo lot, **active ngay**, không có bước draft/confirm.
  /// Hỗ trợ cả 3 mức chi tiết qua [CreateLotParams]:
  /// serial / boxLine (có hoặc không inner carton) / boxCount.
  ///
  /// `lotNo` do client sinh và gửi lên; server chỉ kiểm tra format, khớp
  /// categoryCode và trùng (409 `Lot.LotNoDuplicated`).
  /// Trả [CreatedLot] gồm id, lotNo, detailLevel, boxCount, lineCount.
  Future<CreatedLot> createLot(CreateLotParams params);

  Future<ModelInfo> getModelInfo(String barcode);

  Future<ModelInfo> getModelInfoByGTIN(String barcode);

  /// GET /api/pallets/next-lot-no — xin lotNo kế tiếp cho [categoryCode] theo
  /// ngày server. Không giữ chỗ: nếu POST /api/pallets trả 409
  /// `Lot.LotNoDuplicated`, gọi lại hàm này để lấy số mới rồi thử lại.
  Future<NextLotNo> getNextLotNo(int categoryCode);
}