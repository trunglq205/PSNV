﻿namespace SWMS_WebTool.Models.PMD
{
    public class PMDReturnRecycleFilter:BaseFilter
    {
        public string? Lot { get; set; }
        public string? From { get; set; }
        public string? Plant { get; set; }
        public string? Material { get; set; }
        public string? Status { get; set; }
        public DateTime? TimeCreate { get; set; }
    }
}
