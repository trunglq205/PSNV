using Swms.FinishGoods.API.Features.Balance.Api;

namespace Swms.FinishGoods.API.Features.Balance.Business;

public interface IBalanceService
{
    Task<IReadOnlyList<BalanceDocSummaryResponse>> GetDocsAsync(string? status);
    Task<BalanceDocDetailResponse> GetDocAsync(long id);
    Task SetLineResolutionAsync(long docId, long lineId, SetResolutionRequest request);
    Task SetLinesResolutionAsync(long docId, BulkResolutionRequest request);
    Task<IssueFaResultResponse> IssueFaAsync(long docId);
}
