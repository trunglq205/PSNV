namespace SWMS_WebTool.Utils
{
    public static class Constants
    {
        public const FlavorEnvironment ENV = FlavorEnvironment.Develop;

        public const int PageLimit = 20;
        public const int PageMaximum = 999999;
        public const int PagingCount = 5;
        public const int PagingAll = 0;
        public const int PagingDefault = 1;

        public static List<string> DAHeader = new List<string> { "ReferenceNumber", "Plant", "VendorCode", "VendorName", "DANo", "DAItem", "Status", "PONo", "POItem", "Material", "Sloc", "PlanQuantity" };
        public static List<string> InvoiceHeader = new List<string> { "Plant", "VendorCode", "InvoiceNo", "InvoiceItem", "DeliveryDate", "Material", "PlanQuantity", "Unit", "PONo", "POItem", "Sloc" };
        public static List<int> IndexHeader = new List<int> { 1, 2, 3, 5, 6, 8, 9, 10, 13, 14, 30 };

        public static List<string> QMHeader = new List<string> { "Plant", "VendorCode", "Material", "Column1", "Rohs", "Column2", "PL", "Column3", "Column4" };
        public static List<string> TypeHeader = new List<string> { "No", "Plant", "Category", "Material", "Discription", "Sloc", "PL", "PositionFA", "KittingType", "SpecialPart", "Type" };
        public static List<string> FrequencyHeader = new List<string> { "No", "Plant", "Category", "Material", "Discription", "Sloc", "Frequency" };
        public static List<string> TypeFrequencyHeader = new List<string> { "No", "Plant", "Category", "Material", "Discription", "Sloc", "Position", "PositionFA", "KittingType", "SpecialPart", "Type", "Frequency" };
        public static List<string> TypeFrequencyHeaderCheck = new List<string> { "No", "Plant", "Category", "Material", "Discription", "Sloc", "Position", "PositionFA", "TypeKitting", "specialpart", "Type", "Frequency" };
        public static List<string> UrgentHeader = new List<string> { "Material", "Urgent" };
        public static List<string> UrgentHeaderCheck = new List<string> { "Material", "Status" };
        public static List<string> ULCOCRHHeader = new List<string> { "Material", "UL", "COC", "RH", "Remark" };

        public static List<string> ULCOCRHHeaderCheck = new List<string> { "Material", "UL", "COC", "RH", "Remark" };
        public static List<string> StandardPackingHearder = new List<string> { "Material", "Quantity" };
        public static List<string> DADetailHeader = new List<string> { "Material", "TotalQuantity", "Plant", "Sloc" };

        public static List<string> PlanOrderHeader = new List<string> { "Plant", "Material", "PlanOrderQuantity", "Sloc", "ProductionVersion", "WD" };
        //public static List<int> PlanOrderIndexHeader = new List<int> { 3, 6, 7, 10, 11, 15, 20 };
        public static List<string> InvoiceTrackingHeader = new List<string> { "Plant", "VendorCode", "InvoiceNo", "Material", "PONo", "POItem", "Sloc", "TrackingNumber" };
        public static List<int> InvoiceTrackingIndexHeader = new List<int> { 1, 2, 3, 8, 13, 14, 30, 32 };
        public static List<string> NoPrintPanacimHeader = new List<string> { "Plant", "Sloc", "Material" };
        public static List<int> IndexHeaderPanacim = new List<int> { 2, 3, 4 };

        public static List<string> KittingPlanFAHeader = new List<string> { "Reserv.No", "Plnt", "ReqmtsDate", "Recipient", "Itm", "Issu", "Bin", "Rep", "Bin1", "Material No", "Quantity", "Quantity1", "Description", "RoHS", "INS", "MvT", "F/G Material No", "Quantity ling grp" };
        public static List<string> KittingPlanDIPHeader = new List<string> { "Plant", "Material", "Component", "Component1", "LvL", "Material type", "Discription", "Quantity", "Quantity1", "Unit", "Spec.Procurement", "Bulk", "Currency", "Std.price(bef)", "Vendor", "Storage", };
        public static List<string> KittingPlanSubconHeader = new List<string> { "STT", "ISL", "Material", "Quantity staged", "RepLoc", "ReqmtsDate", "Line", "Material Description", "Plant", "PSNV_Stock", "KHFA_N7", "VenderName", "QUantity Actual", "Pallet" };
        public static List<string> KittingPlanOtherHeader = new List<string> { "No", "ISL", "Material", "Quantity staged", "RepLoc", "line", "Remark", "Reason", "ReqmtsDate", "Plant", "Tcode", "GroupName", "Account", "CostCenter" };
        public static List<string> ActualPlanDIPHeader = new List<string> { "Model", "Qty", "blog", "ProductDate", "Line", "Time", "Note", "SlocDIP", "Plant", "ModelFA" };
        public static List<int> IndexKittingHeader = new List<int> { 1, 2, 3, 4, 5, 6, 8, 9, 10, 11, 12 };
        public static List<int> IndexActualPlanDIPHeader = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 };
        public static List<int> IndexKittingFAHeader = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18 };
        public static List<int> IndexKittingPlanSubconHeader = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };
        public static List<int> IndexKittingPlanOtherHeader = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14 };
        public static List<string> MaterialDetailCheck = new List<string> { "Material", "Name", "Description" };
        public static List<string> ModelMappingHeader = new List<string> { "No", "Plant", "Cate", "Model JTF", "Model SWMS", "Note" };
        public static List<int> IndexModelMappingHeader = new List<int> { 1, 2, 3, 4, 5, 6 };
        public static List<int> IndexKittingDIPHeader = new List<int> { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 17, 35 };
        public static List<string> PlanPrintPanacimHeader = new List<string> { "Plant", "Material", "Category", "GRQuantity", "SPQ", "SoundbizQuantity", "ProjectorQuantity", "Invoice" };
        public static List<int> IndexHeaderPlanPanacim = new List<int> { 2, 3, 4, 9, 10, 11, 12, 13 };
        public static List<string> MasterSlocCheck = new List<string> { "No", "Plant", "Category", "Sloc", "Type", "Address", "Detail" };
        public static List<string> SapStockHeader = new List<string> { "Plnt", "MTyp", "Matl group", "Material", "Material description", "Standard price", "Standard price1", "per", "SLoc", "Total stock qty" };
        public static List<int> IndexSapStockHeader = new List<int> { 1, 2, 3, 4, 5, 8, 9, 10, 11, 12 };
        public static List<string> MasterTypeFrequencyHeaderCheck = new List<string> { "Sloc", "Material No", "Category" };
        public static List<string> BlockScheduleHeader = new List<string> { "Type", "Plant", "Category" };
        public static List<int> BlockScheduleIndex = new List<int> { 1, 2, 3 };


        public const string TIME = "Time";
        public const string PREPARATION = "Prepare";
        public const string ONETIME = "1Time";
        public const string NTIME = "N";
        public const string PREPARETEXT = "PREPARE GOODS";
        public const string ONETIMETEXT = "ONE-TIME EXPORT";
        public const string NTIMETEXT = "HOURLY EXPORT";
        public const string YYYY_MM_DD = "yyyy-MM-dd";
        public const string DD_MM_YYYY = "dd/MM/yyyy";
        public const string COMMON = "Common";
        public const string JIT = "JIT";
        public const string PROCESS = "Process";
        public const string SPECIAL = "Special";
        public const string TYPE = "Type";
        public const string ERROREMPTY_PLANT_CATE = "Please select Plant, Category, and ProDate";
        public const string REQUIRED_CATEGORY = "Please select Category and UploadNo!";
        public const string OVERTIME_SUPPLY = "PIC update time";
        public const int CELL_SIZE = 10;
        public static (int, int) TROLLEY_TV_LOCATION = (259, 526);
        public static (int, int) TROLLEY_MW_LOCATION = (307, 76);
        public static (int, int) TROLLEY_PJ_LOCATION = (68, 310);
        public static (int, int) TROLLEY_DP_DECT_SB_LOCATION = (387, 381);
    }
}

