import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';

/// Enum xác định kiểu hiển thị của [AppErrorView].
enum AppErrorViewType {
  /// Hiển thị toàn màn hình — dùng cho lỗi cấp page (Scaffold body).
  page,

  /// Hiển thị nội tuyến — dùng nhúng bên trong widget tree (list, card...).
  widget,
}

/// View hiển thị lỗi kèm nút thử lại — dùng trong AsyncValue.error.
///
/// Có 2 kiểu khởi tạo:
/// ```dart
/// // Toàn màn hình (có Scaffold + AppBar)
/// AppErrorView.page(message: 'Không tải được dữ liệu', onRetry: _reload);
///
/// // Nội tuyến (chỉ là Column trong widget tree)
/// AppErrorView.widget(message: 'Không tải được dữ liệu', onRetry: _reload);
/// ```
class AppErrorView extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final String retryText;
  final AppErrorViewType _type;

  // ─── Private canonical constructor ───────────────────────────────────────

  const AppErrorView._({
    super.key,
    required this.message,
    this.onRetry,
    this.retryText = 'Thử lại',
    required AppErrorViewType type,
  }) : _type = type;

  // ─── Factory constructors ─────────────────────────────────────────────────

  /// Kiểu **page**: bọc trong [Scaffold] có [AppBar] — dùng làm body của route.
  ///
  /// Thích hợp khi toàn bộ màn hình bị lỗi (network, auth...).
  factory AppErrorView.page({
    Key? key,
    required String message,
    VoidCallback? onRetry,
    String retryText = 'Thử lại',
  }) => AppErrorView._(
    key: key,
    message: message,
    onRetry: onRetry,
    retryText: retryText,
    type: AppErrorViewType.page,
  );

  /// Kiểu **widget**: chỉ là phần nội dung lỗi — nhúng vào widget tree.
  ///
  /// Thích hợp cho lỗi cục bộ trong list, card, tab content...
  factory AppErrorView.widget({
    Key? key,
    required String message,
    VoidCallback? onRetry,
    String retryText = 'Thử lại',
  }) => AppErrorView._(
    key: key,
    message: message,
    onRetry: onRetry,
    retryText: retryText,
    type: AppErrorViewType.widget,
  );

  // ─── Build ────────────────────────────────────────────────────────────────

  @override
  Widget build(BuildContext context) {
    return switch (_type) {
      AppErrorViewType.page => _PageErrorView(
        message: message,
        onRetry: onRetry,
        retryText: retryText,
      ),
      AppErrorViewType.widget => _WidgetErrorContent(
        message: message,
        onRetry: onRetry,
        retryText: retryText,
      ),
    };
  }
}

// ─── Page variant ─────────────────────────────────────────────────────────────

/// Lỗi toàn màn hình — có [Scaffold] và [AppBar].
class _PageErrorView extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final String retryText;

  const _PageErrorView({
    required this.message,
    required this.onRetry,
    required this.retryText,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(AppDimens.lg),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.error_outline_rounded, size: 48, color: scheme.error),
            const SizedBox(height: AppDimens.md),
            Text(
              message,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            if (onRetry != null) ...[
              const SizedBox(height: AppDimens.lg),
              AppButton(
                label: retryText,
                variant: AppButtonVariant.danger,
                onPressed: onRetry,
              ),
            ],
          ],
        ),
      ),
    );
  }
}

// ─── Widget variant content ───────────────────────────────────────────────────

/// Lỗi nội tuyến — icon nhỏ + text nằm ngang, retry nhỏ gọn.
class _WidgetErrorContent extends StatelessWidget {
  final String message;
  final VoidCallback? onRetry;
  final String retryText;

  const _WidgetErrorContent({
    required this.message,
    required this.onRetry,
    required this.retryText,
  });

  @override
  Widget build(BuildContext context) {
    final scheme = Theme.of(context).colorScheme;
    return Padding(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.error_outline_rounded, size: 16, color: scheme.error),
          const SizedBox(width: AppDimens.xs),
          Flexible(
            child: Text(
              message,
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: scheme.error),
            ),
          ),
          if (onRetry != null) ...[
            const SizedBox(width: AppDimens.sm),
            TextButton(
              onPressed: onRetry,
              child: Text(
                retryText,
                style: Theme.of(context).textTheme.bodySmall?.copyWith(
                  color: scheme.error,
                  decoration: TextDecoration.underline,
                ),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
