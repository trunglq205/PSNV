﻿using System.Data;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Models.Responses;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using Function = SWMS_WebTool.Utils.Function;

namespace SWMS_WebTool.Controllers
{
    public class MaterialController : BaseController
    {
        private readonly ApiService _apiService;

        public MaterialController(ApiService apiService)
        {
            _apiService = apiService;
        }

        // GET: /<controller>/
        public async Task<IActionResult> Index([FromQuery] MaterialFilter filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());

                int total = 1;
                IEnumerable<MaterialInfo> items = new List<MaterialInfo>();

                switch(filter.Type)
                {
                    case MaterialInfoType.QM:  
                        var responseQM = await _apiService.SearchQM(filter, pageNumber, _pageSize);
                        total = responseQM.TotalRecord;
                        items = responseQM.Records ?? new List<QM>();
                        break;
                    case MaterialInfoType.TypeAndFrequency:
                        var responseTypeAndFrequency = await _apiService.SearchTypeFrequency(filter, pageNumber, _pageSize);
                        total = responseTypeAndFrequency.TotalRecord;
                        items = responseTypeAndFrequency.Records ?? new List<TypeFrequency>();
                        break;
                    case MaterialInfoType.Urgent:
                        var responseUrgent = await _apiService.SearchUrgent(filter, pageNumber, _pageSize);
                        total = responseUrgent.TotalRecord;
                        items = responseUrgent.Records ?? new List<UrgentULCOCRH>();
                        break;
                    case MaterialInfoType.RHCOCUL:
                        var responseRHCOCUL = await _apiService.SearchULCOCRH(filter, pageNumber, _pageSize);
                        total = responseRHCOCUL.TotalRecord;
                        items = responseRHCOCUL.Records ?? new List<UrgentULCOCRH>();
                        break;
                    case MaterialInfoType.StandardPacking:
                        var responseStandardPacking = await _apiService.SearchStandardPacking(filter, pageNumber, _pageSize);
                        total = responseStandardPacking.TotalRecord;
                        items = responseStandardPacking.Records ?? new List<StandardPacking>();
                        break;
                }

                var model = new MaterialViewModel()
                {
                    Items = items,
                    Filter = filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/MaterialInfo/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportMaterialInfo(IFormFile file, MaterialInfoType type)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    switch (type)
                    {
                        case MaterialInfoType.TypeAndFrequency:
                            if (!Function.CheckHeaderExcel(filepath, "sheet1", Constants.TypeFrequencyHeaderCheck))
                            {
                                ViewBag.Error = _loc.Get("Msg_TheFileSFormatIsIncorectPleaseCheckAgain");
                                break;
                            }
                            dt = Function.GetDataTableFromExcel(filepath, "sheet1", Constants.TypeFrequencyHeader);
                            if (dt != null && dt.Columns.Count == Constants.TypeFrequencyHeader.Count)
                            {

                                List<TypeFrequency>? typeMaster = Function.DataTatbleToTypeMaster(dt);
                                string json = JsonConvert.SerializeObject(typeMaster);
                                if (typeMaster != null && typeMaster.Count > 0)
                                {
                                    return PartialView("~/Views/MaterialInfo/_ImportTypeFrequencyModal.cshtml", typeMaster);
                                }

                            }
                            else
                            {
                                ViewBag.Error = _loc.Get("Msg_ErrorOccurred");
                            }
                            break;

                        case MaterialInfoType.Urgent:
                            ViewBag.TitleType = _loc.Get("Msg_UrgentMaster");
                            if (!Function.CheckHeaderExcel(filepath, "sheet1", Constants.UrgentHeaderCheck))
                            {
                                ViewBag.Error = _loc.Get("Msg_TheFileSFormatIsIncorectPleaseCheckAgain");
                                break;
                            }
                            dt = Function.GetDataTableFromExcel(filepath, "sheet1", Constants.UrgentHeader);
                            if (dt != null && dt.Columns.Count == Constants.UrgentHeader.Count)
                            {

                                List<UrgentULCOCRH>? urgentyMaster = Function.DataTatbleToUrgentMaster(dt);
                                if (urgentyMaster != null && urgentyMaster.Count > 0)
                                {
                                    return PartialView("~/Views/MaterialInfo/_ImportUrgentModal.cshtml", urgentyMaster);
                                }
                            }
                            else
                            {
                                ViewBag.Error = _loc.Get("Msg_ErrorOccurred");
                            }
                            break;
                        case MaterialInfoType.RHCOCUL:
                            ViewBag.TitleType = _loc.Get("Msg_RhCocUlOtherMaster");
                            if (!Function.CheckHeaderExcel(filepath, "sheet1", Constants.ULCOCRHHeaderCheck))
                            {
                                ViewBag.Error = _loc.Get("Msg_TheFileSFormatIsIncorectPleaseCheckAgain");
                                break;
                            }
                            dt = Function.GetDataTableFromExcel(filepath, "sheet1", Constants.ULCOCRHHeader);
                            if (dt != null && dt.Columns.Count == Constants.ULCOCRHHeader.Count)
                            {

                                List<UrgentULCOCRH>? ulcocrkMaster = Function.DataTatbleToULCOCRKMaster(dt);
                                if (ulcocrkMaster != null && ulcocrkMaster.Count > 0)
                                {
                                    return PartialView("~/Views/MaterialInfo/_ImportRHCOCULModal.cshtml", ulcocrkMaster);
                                }
                            }
                            else
                            {
                                ViewBag.Error = _loc.Get("Msg_ErrorOccurred");
                            }
                            break;
                        case MaterialInfoType.StandardPacking:
                            ViewBag.TitleType = _loc.Get("Msg_StandardPackingMaster");
                            if (!Function.CheckHeaderExcel(filepath, "sheet1", Constants.StandardPackingHearder))
                            {
                                ViewBag.Error = _loc.Get("Msg_TheFileSFormatIsIncorectPleaseCheckAgain");
                                break;
                            }
                            dt = Function.GetDataTableFromExcel(filepath, "sheet1", Constants.StandardPackingHearder);
                            if (dt != null && dt.Columns.Count == Constants.StandardPackingHearder.Count)
                            {

                                List<StandardPacking>? standardMaster = Function.DataTatbleToStandardPackingMaster(dt);
                                if (standardMaster != null && standardMaster.Count > 0)
                                {
                                    return PartialView("~/Views/MaterialInfo/_ImportStandardBackingModal.cshtml", standardMaster);
                                }
                            }
                            else
                            {
                                ViewBag.Error = _loc.Get("Msg_ErrorOccurred");
                            }
                            break;
                    }
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportTypeFrequency([FromBody] List<TypeFrequency> typeFrequencies)
        {
            try
            {
                await _apiService.ImportTypeFrequency(typeFrequencies);
                return Json(new { success = true, countdata = typeFrequencies.Count });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportUrgent([FromBody] List<UrgentULCOCRH> urgentULCOCRHs)
        {
            try
            {
                await _apiService.ImportUrgent(urgentULCOCRHs);
                return Json(new { success = true, countdata = urgentULCOCRHs.Count });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportULCOCRH([FromBody] List<UrgentULCOCRH> urgentULCOCRHs)
        {
            try
            {
                await _apiService.ImportULCOCRH(urgentULCOCRHs);
                return Json(new { success = true, countdata = urgentULCOCRHs.Count });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }  
        
        [HttpPost]
        public async Task<IActionResult> ConfirmImportStandardPacking([FromBody] List<StandardPacking> standardBackings)
        {
            try
            {
                await _apiService.CreateStandardPacking(standardBackings);
                return Json(new { success = true, countdata = standardBackings.Count });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> MaterialCheck(IFormFile file)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "Uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (!Function.CheckHeaderExcel(filepath, "sheet1", Constants.MasterTypeFrequencyHeaderCheck))
                    {
                        return BadRequest(_loc.Get("Msg_FileFormatIncorect"));
                    }
                    dt = Function.GetDataTableFromExcel(filepath, "sheet1", Constants.MasterTypeFrequencyHeaderCheck);
                    if (dt != null && dt.Columns.Count == Constants.MasterTypeFrequencyHeaderCheck.Count)
                    {

                        List<CheckTypeFrequencyImport>? materials = Function.DataTatbleToTypeCheck(dt);


                        string jsonData = JsonConvert.SerializeObject(materials);
                        var rs = await _apiService.CheckMasterTypeFrequency(materials);
                        List<CheckTypeFrequencyResponse> listResult = new List<CheckTypeFrequencyResponse>();
                        if (rs != null)
                        {
                            listResult = rs.Where(x => x.IsExist == false).ToList();
                            return PartialView("~/Views/MaterialInfo/_ImportCheckTypeFrequencyModal.cshtml", listResult);
                            /*if (listResult != null && listResult.Count > 0)
                            {
                                return PartialView("~/Views/MaterialInfo/_ImportCheckTypeFrequencyModal.cshtml", listResult);
                            }*/
                        }
                        //string json = JsonConvert.SerializeObject(materials);

                    }
                    else
                    {
                        ViewBag.Error = _loc.Get("Msg_ErrorOccurred");
                    }
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
            return View();
        }
    }
}