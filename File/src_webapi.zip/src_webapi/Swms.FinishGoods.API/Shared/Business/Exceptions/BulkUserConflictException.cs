﻿using Swms.FinishGoods.API.Features.Users.Api;

namespace Swms.FinishGoods.API.Shared.Business.Exceptions
{
    public sealed class BulkUserConflictException : Exception
    {
        public IReadOnlyList<DuplicateUserInfo> Conflicts { get; }

        public BulkUserConflictException(string message, IReadOnlyList<DuplicateUserInfo> conflicts)
            : base(message)
        {
            Conflicts = conflicts;
        }
    }
}
