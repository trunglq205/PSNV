// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'part_card_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Màn IN MỚI Part Card. Tem đã in (sửa / tách / gộp) đi từ Home →
/// `PartCardActionNotifier`.

@ProviderFor(PartCardNotifier)
final partCardProvider = PartCardNotifierProvider._();

/// Màn IN MỚI Part Card. Tem đã in (sửa / tách / gộp) đi từ Home →
/// `PartCardActionNotifier`.
final class PartCardNotifierProvider
    extends $NotifierProvider<PartCardNotifier, PartCardState> {
  /// Màn IN MỚI Part Card. Tem đã in (sửa / tách / gộp) đi từ Home →
  /// `PartCardActionNotifier`.
  PartCardNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'partCardProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$partCardNotifierHash();

  @$internal
  @override
  PartCardNotifier create() => PartCardNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PartCardState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PartCardState>(value),
    );
  }
}

String _$partCardNotifierHash() => r'29502730fe3e30934c399f9efcc406d6fa15bb3c';

/// Màn IN MỚI Part Card. Tem đã in (sửa / tách / gộp) đi từ Home →
/// `PartCardActionNotifier`.

abstract class _$PartCardNotifier extends $Notifier<PartCardState> {
  PartCardState build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<PartCardState, PartCardState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<PartCardState, PartCardState>,
              PartCardState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
