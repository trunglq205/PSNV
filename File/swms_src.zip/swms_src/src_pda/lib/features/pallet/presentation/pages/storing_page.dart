import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/features/pallet/presentation/pages/pallet_flow_page.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow.dart';

/// Lưu kho — quét pallet (kèm gợi ý vị trí) → quét vị trí đích → lưu.
@RoutePage()
class StoringScreen extends StatelessWidget {
  /// Nếu truyền sẵn (từ Pallet Detail) thì tự lookup, bỏ bước quét.
  final String? lotNo;

  const StoringScreen({super.key, this.lotNo});

  @override
  Widget build(BuildContext context) =>
      PalletFlowPage(flow: PalletFlow.storing, lotNo: lotNo);
}
