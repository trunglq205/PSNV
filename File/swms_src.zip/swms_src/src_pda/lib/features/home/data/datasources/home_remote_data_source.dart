import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/home/data/models/assignment_model.dart';
import 'package:swms_finish_goods/features/home/data/models/scan_result_model.dart';

part 'home_remote_data_source.g.dart';

@RestApi()
abstract class HomeRemoteDataSource {
  factory HomeRemoteDataSource(Dio dio, {String baseUrl}) =
      _HomeRemoteDataSource;

  /// GET danh sách assignment của nhân viên đang đăng nhập.
  @GET('/home/assignments')
  Future<List<AssignmentModel>> fetchAssignments();

  /// Phân loại 1 mã quét ở Home. Luôn trả 200 kèm type (kể cả not_found).
  @GET('/api/scan/resolve')
  Future<ScanResultModel> resolveScan(@Query('code') String code);
}
