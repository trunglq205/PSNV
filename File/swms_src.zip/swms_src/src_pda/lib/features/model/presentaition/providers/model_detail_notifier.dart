import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_repository.dart';
import 'package:swms_finish_goods/features/model/presentaition/providers/model_detail_providers.dart';
import 'package:swms_finish_goods/features/model/presentaition/providers/model_detail_state.dart';

part 'model_detail_notifier.g.dart';

/// Notifier family theo modelId.
@riverpod
class ModelDetailNotifier extends _$ModelDetailNotifier
    with BaseNotifierMixin<ModelDetailState> {
  ModelDetailRepository get _repo => ref.read(modelDetailRepositoryProvider);

  @override
  ModelDetailState build(int modelId) {
    Future.microtask(load);
    return const ModelDetailState();
  }

  /// Đọc/lookup → executePartial (lỗi hiển thị inline trong vùng detail).
  Future<void> load() => executePartial<ModelDetail>(
    action: () => _repo.getDetail(modelId),
    getField: (s) => s.detail,
    setField: (s, f) => s.copyWith(detail: f),
  );

  /// Chỉnh sửa model (PUT). KHÔNG optimistic: các số tổng (thùng/pallet,
  /// kích thước kiện) do server tính lại, đoán trước ở client dễ lệch.
  /// Lỗi ném ra cho appActionProvider hiển thị; state giữ nguyên bản cũ.
  Future<void> updateModel(ModelEdit edit) async {
    final updated = await _repo.update(modelId, edit);
    state = state.copyWith(detail: AsyncValue.data(updated));
  }

  /// Cập nhật khu gợi ý — optimistic, rollback nếu lỗi.
  /// GỬI KÈM tầng rack hiện tại vì API ghi đè cả 2 cột gợi ý.
  Future<void> updateSuggestArea({
    required int id,
    required String? code,
    required String? name,
  }) async {
    final current = state.detail.value;
    if (current == null || current.suggestAreaId == id) return;

    final optimistic = current.copyWithSuggestArea(
      id: id,
      code: code,
      name: name,
    );

    await applyOptimistic(state.copyWith(detail: AsyncValue.data(optimistic)), (
        _,
        ) async {
      final updated = await _repo.updateSuggestion(
        id: modelId,
        suggestAreaId: id,
        suggestRackRow: current.suggestRackRow,
      );
      state = state.copyWith(detail: AsyncValue.data(updated));
    });
  }

  /// Cập nhật tầng rack gợi ý — optimistic, rollback nếu lỗi.
  ///
  /// API ghi đè cả 2 cột gợi ý nên GỬI KÈM khu hiện tại, nếu không sẽ xoá
  /// mất gợi ý khu. Danh sách rỗng = xoá gợi ý tầng.
  Future<void> updateRackRows(List<int> rows) async {
    final current = state.detail.value;
    if (current == null) return;

    final sorted = rows.toSet().toList()..sort();
    final optimistic = current.copyWithRackRows(sorted);

    await applyOptimistic(state.copyWith(detail: AsyncValue.data(optimistic)), (
        _,
        ) async {
      final updated = await _repo.updateSuggestion(
        id: modelId,
        suggestAreaId: current.suggestAreaId,
        suggestRackRow: sorted,
      );
      // Bản server-authoritative.
      state = state.copyWith(detail: AsyncValue.data(updated));
    });
  }
}