using Swms.FinishGoods.Web.Features.Auth.Business.Models;
using Swms.FinishGoods.Web.Features.Auth.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.Auth.Business;

public class AuthBusiness : BaseBusiness, IAuthBusiness
{
    private readonly IAuthApi _api;

    public AuthBusiness(IAuthApi api, ILogger<AuthBusiness> logger, ErrorHandler errorHandler) : base(logger, errorHandler)
    {
        _api = api;
    }

    public Task<Result<LoginResponse>> LoginAsync(string username, string password, bool remember)
        => ExecuteAsync(() =>
            _api.LoginAsync(new LoginRequest { Username = username, Password = password }));
}
