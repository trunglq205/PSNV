using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.Api.Features.PdaApp.DataAccess;

public class PdaAppRepository : IPdaAppRepository
{
    private readonly IDbConnectionFactory _factory;
    public PdaAppRepository(IDbConnectionFactory factory) => _factory = factory;

    // Cột dùng chung — alias snake_case → PascalCase.
    private const string SelectColumns = """
        id               AS Id,
        version          AS Version,
        version_code     AS VersionCode,
        release_note     AS ReleaseNote,
        apk_path         AS ApkPath,
        apk_url          AS ApkUrl,
        size_bytes       AS SizeBytes,
        force_update     AS ForceUpdate,
        is_current       AS IsCurrent,
        published_at     AS PublishedAt,
        created_at       AS CreatedAt,
        created_by       AS CreatedBy,
        updated_at       AS UpdatedAt,
        updated_by       AS UpdatedBy
        """;

    public async Task<IReadOnlyList<PdaAppVersionEntity>> GetAllAsync()
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {SelectColumns}
            FROM master.pda_app_versions
            WHERE is_deleted = 0
            ORDER BY version_code DESC;
            """;
        var rows = await conn.QueryAsync<PdaAppVersionEntity>(sql);
        return rows.ToList();
    }

    public async Task<PdaAppVersionEntity?> GetCurrentAsync()
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {SelectColumns}
            FROM master.pda_app_versions
            WHERE is_deleted = 0 AND is_current = 1;
            """;
        return await conn.QueryFirstOrDefaultAsync<PdaAppVersionEntity>(sql);
    }

    public async Task<PdaAppVersionEntity?> GetByIdAsync(long id)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {SelectColumns}
            FROM master.pda_app_versions
            WHERE id = @id AND is_deleted = 0;
            """;
        return await conn.QueryFirstOrDefaultAsync<PdaAppVersionEntity>(sql, new { id });
    }

    public async Task<bool> VersionExistsAsync(string version)
    {
        using var conn = _factory.Create();
        var sql = """
            SELECT COUNT(1) FROM master.pda_app_versions
            WHERE version = @version AND is_deleted = 0;
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { version }) > 0;
    }

    public async Task<int> GetMaxVersionCodeAsync()
    {
        using var conn = _factory.Create();
        var sql = """
            SELECT ISNULL(MAX(version_code), 0) FROM master.pda_app_versions
            WHERE is_deleted = 0;
            """;
        return await conn.ExecuteScalarAsync<int>(sql);
    }

    public async Task<long> PublishAsync(PdaAppVersionEntity e)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // 1. Bỏ cờ current của bản hiện hành (nếu có).
            const string clearCurrent = """
                UPDATE master.pda_app_versions
                SET is_current = 0, updated_at = SYSUTCDATETIME(), updated_by = @CreatedBy
                WHERE is_current = 1 AND is_deleted = 0;
                """;
            await conn.ExecuteAsync(clearCurrent, e, tx);

            // 2. Insert bản mới, đánh dấu là bản đang phát hành.
            const string insert = """
                INSERT INTO master.pda_app_versions
                    (version, version_code, release_note, apk_path, apk_url, size_bytes,
                     force_update, is_current, published_at, is_deleted, created_at, created_by)
                VALUES
                    (@Version, @VersionCode, @ReleaseNote, @ApkPath, @ApkUrl, @SizeBytes,
                     @ForceUpdate, 1, @PublishedAt, 0, SYSUTCDATETIME(), @CreatedBy);
                SELECT CAST(SCOPE_IDENTITY() AS bigint);
                """;
            var id = await conn.ExecuteScalarAsync<long>(insert, e, tx);

            tx.Commit();
            return id;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }
}
