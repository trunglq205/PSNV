import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/utils/feedback/feedback_provider.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';
import 'package:swms_finish_goods/features/stocky/presentation/providers/stocky_providers.dart';

// ─────────────────────────────────────────────────────────────
//  ĐẶT XE STOCKY VÀO Ô TRONG KHO (thêm 17/11)
//
//  Vì sao có màn này: trước đó ô của CHÍNH xe chỉ nhận được đúng hai giá trị,
//  cả hai lấy từ appsettings — bãi đậu (lúc nhập xe) và ô FA (lúc xuất FA).
//  Không có đường nào đặt một xe vào một ô cụ thể trong kho, nên xe đứng ở đâu
//  trong kho thì sổ không biết.
//
//  QUÉT XE TRƯỚC, RỒI QUÉT Ô (chốt 17/11) — từng cặp, mỗi lượt một xe, giống
//  khuôn màn chuyển vị trí pallet. Không gom lô: mỗi xe đứng một ô khác nhau,
//  gom lô là mời người dùng đặt cả chục xe vào cùng một ô vì bấm nhanh.
//
//  HÀNG TRÊN XE ĐI THEO XE (chốt 17/11): server chuyển ô cho từng pallet đang
//  ghi nằm trên xe, qua đúng cổng của slice Pallets — nên vẫn ghi lịch sử vị
//  trí, vẫn ghi sự kiện kho, và hàng RW/RB vẫn phải có duyệt của quản lý SCS
//  mới ra được khu Nhận hàng.
//
//  KHÔNG giới hạn khu: xe đứng được ở khu lưu trữ, khu nhận hàng, đâu cũng được.
//
//  Điều hướng bằng MaterialPageRoute, không khai @RoutePage — build_runner
//  trong source hiện tại đang vỡ (hai file cùng khai `@RoutePage() class
//  VanningPage`).
// ─────────────────────────────────────────────────────────────

/// Mở màn đặt xe. Trả `true` nếu đã đặt được xe nào — chỗ gọi dùng nó để tải
/// lại danh sách xe.
Future<bool> openStockyPlacePage(BuildContext context) async {
  final done = await Navigator.of(context).push<bool>(
    MaterialPageRoute(builder: (_) => const _StockyPlacePage()),
  );
  return done ?? false;
}

class _StockyPlacePage extends ConsumerStatefulWidget {
  const _StockyPlacePage();

  @override
  ConsumerState<_StockyPlacePage> createState() => _StockyPlacePageState();
}

class _StockyPlacePageState extends ConsumerState<_StockyPlacePage> {
  StreamSubscription<String>? _sub;
  bool _busy = false;

  /// Xe đang xử lý. null = đang chờ quét xe.
  StockyCart? _cart;

  /// Ô đích đã quét. null = đang chờ quét ô.
  String? _locator;

  /// Các lượt đã đặt TRONG PHIÊN này, mới nhất trước.
  final List<StockyPlaceResult> _done = [];

  bool get _waitingCart => _cart == null;

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      _onScan(data);
    });
  }

  // ── Quét ──────────────────────────────────────────────────

  Future<void> _onScan(String raw) async {
    final code = raw.trim();
    if (code.isEmpty || _busy) return;

    if (_waitingCart) {
      await _pickCart(code);
      return;
    }

    // Đã có xe -> mã này là Ô ĐÍCH. Không kiểm ở client: danh mục ô nằm ở
    // server, và server trả nguyên câu "Không có ô nào mang mã ..." nếu sai.
    setState(() => _locator = code);
    ref.read(appFeedbackProvider).success();
  }

  /// Tra xe vừa quét để hiện xe đang ở đâu và có hàng gì trên xe.
  ///
  /// Dùng `fetchList(keyword:)` chứ KHÔNG dùng `lookup(code, mode)`: `lookup`
  /// kiểm theo chiều nhập / xuất FA / trả vendor, mà đặt xe vào ô không thuộc
  /// chiều nào trong ba chiều đó — gọi lookup sẽ bị từ chối oan (vd xe đang
  /// trong kho thì chiều "nhập" báo lỗi đã ở trong kho).
  Future<void> _pickCart(String code) async {
    setState(() => _busy = true);
    try {
      final list = await ref
          .read(stockyRepositoryProvider)
          .fetchList(keyword: code);

      final found = list.where((c) => c.code.toLowerCase() == code.toLowerCase());
      if (found.isEmpty) {
        ref.read(appFeedbackProvider).error();
        if (mounted) {
          AppToastHelper.toastWarning(
            context,
            LocaleKeys.stocky_place_not_found.tr(namedArgs: {'code': code}),
          );
        }
        return;
      }

      ref.read(appFeedbackProvider).success();
      if (mounted) setState(() => _cart = found.first);
    } catch (e) {
      if (mounted) await ref.read(errorHandlerProvider).handle(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  // ── Chốt một lượt ─────────────────────────────────────────

  Future<void> _submit() async {
    final cart = _cart;
    final locator = _locator;
    if (cart == null || locator == null || _busy) return;

    setState(() => _busy = true);
    try {
      final res = await ref.read(stockyRepositoryProvider).place(
            code: cart.code,
            locatorCode: locator,
          );

      if (!mounted) return;
      ref.read(appFeedbackProvider).success();
      setState(() {
        _done.insert(0, res);
        _cart = null;
        _locator = null;
      });

      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.stocky_place_ok.tr(namedArgs: {
          'code': res.code,
          'loc': res.locatorCode,
        }),
      );
    } catch (e) {
      if (!mounted) return;
      // Hiện NGUYÊN câu của server: xe đã trả vendor · mã ô không có · hàng
      // RW/RB trên xe chưa được duyệt ra khu Nhận hàng — mỗi lý do một câu
      // riêng, bọc lại là mất thông tin.
      await ref.read(errorHandlerProvider).handle(context, e);
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  void _reset() {
    ref.read(appFeedbackProvider).success();
    setState(() {
      _cart = null;
      _locator = null;
    });
  }

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final cart = _cart;

    return PopScope(
      canPop: false,
      onPopInvokedWithResult: (didPop, _) {
        if (didPop) return;
        // Mỗi lượt đã ghi xong ngay lúc bấm, thoát ra không mất gì.
        Navigator.of(context).pop(_done.isNotEmpty);
      },
      child: Scaffold(
        appBar: AppTopBar(
          title: LocaleKeys.stocky_place_title.tr(),
          subtitle: LocaleKeys.stocky_place_subtitle.tr(),
        ),
        body: ListView(
          padding: const EdgeInsets.all(AppDimens.md),
          children: [
            BarcodeScannerButton(
              state: _busy ? ScannerState.loading : ScannerState.scanning,
              scanningLabel: _waitingCart
                  ? LocaleKeys.stocky_place_scan_cart.tr()
                  : LocaleKeys.stocky_place_scan_locator.tr(),
              loadingLabel: LocaleKeys.stocky_place_saving.tr(),
            ),
            const SizedBox(height: 6),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Icon(Icons.arrow_upward_rounded, size: 14, color: c.text3),
                const SizedBox(width: 4),
                Flexible(
                  child: Text(
                    _waitingCart
                        ? LocaleKeys.stocky_place_hint_cart.tr()
                        : LocaleKeys.stocky_place_hint_locator.tr(),
                    textAlign: TextAlign.center,
                    style: AppTextStyles.caption.copyWith(color: c.text2),
                  ),
                ),
              ],
            ),

            if (cart != null) ...[
              const SizedBox(height: AppDimens.sm),
              _CartCard(cart: cart, locator: _locator, onReset: _reset),
              const SizedBox(height: AppDimens.sm),
              AppButton(
                label: _locator == null
                    ? LocaleKeys.stocky_place_need_locator.tr()
                    : LocaleKeys.stocky_place_submit.tr(
                        namedArgs: {'loc': _locator!}),
                variant: AppButtonVariant.success,
                size: AppButtonSize.lg,
                icon: Icons.move_down_outlined,
                isLoading: _busy,
                onPressed: _locator == null || _busy ? null : _submit,
              ),
            ],

            if (_done.isNotEmpty) ...[
              const SizedBox(height: AppDimens.md),
              Text(
                LocaleKeys.stocky_place_done_title
                    .tr(namedArgs: {'n': '${_done.length}'}),
                style: AppTextStyles.caption.copyWith(color: c.text2),
              ),
              const SizedBox(height: AppDimens.sm),
              for (final row in _done) ...[
                _DoneRow(row: row),
                const SizedBox(height: AppDimens.sm),
              ],
            ],
          ],
        ),
      ),
    );
  }
}

/// Xe đang xử lý: đang ở đâu, trên xe có gì, sẽ đặt vào ô nào.
class _CartCard extends StatelessWidget {
  const _CartCard({
    required this.cart,
    required this.locator,
    required this.onReset,
  });

  final StockyCart cart;
  final String? locator;
  final VoidCallback onReset;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(Icons.shopping_cart_outlined, size: 18, color: c.text2),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  cart.code,
                  style: AppTextStyles.bodyStrong.copyWith(color: c.text1),
                ),
              ),
              IconButton(
                icon: const Icon(Icons.close, size: 18),
                visualDensity: VisualDensity.compact,
                tooltip: LocaleKeys.stocky_place_reset.tr(),
                onPressed: onReset,
              ),
            ],
          ),

          // Đang ở đâu -> sẽ sang đâu. Hiện cả hai để người đẩy xe đối chiếu
          // trước khi bấm, nhất là khi xe đang ở FA kéo về kho.
          Text(
            LocaleKeys.stocky_place_from.tr(namedArgs: {
              'loc': cart.locatorCode ?? '—',
            }),
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
          if (locator != null)
            Padding(
              padding: const EdgeInsets.only(top: 2),
              child: Row(
                children: [
                  Icon(Icons.arrow_forward_rounded, size: 14, color: c.success),
                  const SizedBox(width: 4),
                  Text(
                    LocaleKeys.stocky_place_to.tr(namedArgs: {'loc': locator!}),
                    style: AppTextStyles.bodyStrong.copyWith(color: c.success),
                  ),
                ],
              ),
            ),

          // Hàng trên xe: nói rõ nó ĐI THEO, vì đây là thứ dễ gây tranh cãi
          // nhất khi đối chiếu sổ sau này.
          if (cart.hasGoods) ...[
            const SizedBox(height: 6),
            Text(
              LocaleKeys.stocky_place_goods.tr(namedArgs: {
                'lots': '${cart.lotCount}',
                'qty': '${cart.qty}',
              }),
              style: AppTextStyles.caption.copyWith(color: c.warning),
            ),
          ],
        ],
      ),
    );
  }
}

/// Một lượt đã đặt xong trong phiên này.
class _DoneRow extends StatelessWidget {
  const _DoneRow({required this.row});

  final StockyPlaceResult row;

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Row(
        children: [
          Icon(Icons.check_circle, size: 20, color: c.success),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  row.code,
                  style: AppTextStyles.body.copyWith(
                    fontWeight: FontWeight.w800,
                    color: c.text1,
                  ),
                ),
                Text(
                  LocaleKeys.stocky_place_done_row.tr(namedArgs: {
                    'loc': row.locatorCode,
                    'lots': '${row.lotCount}',
                  }),
                  style: AppTextStyles.caption.copyWith(color: c.text3),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
