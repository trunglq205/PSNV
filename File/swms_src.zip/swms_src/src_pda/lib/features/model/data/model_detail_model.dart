import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';

part 'model_detail_model.g.dart';

/// Khớp `ModelResponse` của API — `GET /api/models/{id}`.
/// Property C# `GTIN` ra JSON camelCase là `gtin`.
@JsonSerializable(createToJson: false)
class ModelDetailModel {
  final int id;
  final String code;
  final String? gtin;
  final int categoryId;

  @JsonKey(defaultValue: 0)
  final int categoryCode;

  @JsonKey(defaultValue: '')
  final String categoryName;

  @JsonKey(defaultValue: 0)
  final int length;

  @JsonKey(defaultValue: 0)
  final int width;

  @JsonKey(defaultValue: 0)
  final int height;

  @JsonKey(defaultValue: 0)
  final int standardPacking;

  final int? layerLimit;
  final int? layerCount;
  final int? stackingLength;
  final int? stackingWidth;
  final int? boxPerLayer;
  final int? boxPerPallet;
  final int? setPerPallet;
  final int? cargoLength;
  final int? cargoWidth;
  final int? cargoHeight;

  final int? suggestAreaId;
  final String? suggestAreaCode;
  final String? suggestAreaName;

  /// API trả null khi chưa có gợi ý tầng — không phải mảng rỗng.
  final List<int>? suggestRackRow;

  @JsonKey(defaultValue: true)
  final bool isActive;

  final DateTime? createdAt;

  const ModelDetailModel({
    required this.id,
    required this.code,
    required this.categoryId,
    required this.categoryCode,
    required this.categoryName,
    required this.length,
    required this.width,
    required this.height,
    required this.standardPacking,
    required this.isActive,
    this.gtin,
    this.layerLimit,
    this.layerCount,
    this.stackingLength,
    this.stackingWidth,
    this.boxPerLayer,
    this.boxPerPallet,
    this.setPerPallet,
    this.cargoLength,
    this.cargoWidth,
    this.cargoHeight,
    this.suggestAreaId,
    this.suggestAreaCode,
    this.suggestAreaName,
    this.suggestRackRow,
    this.createdAt,
  });

  factory ModelDetailModel.fromJson(Map<String, dynamic> json) =>
      _$ModelDetailModelFromJson(json);

  ModelDetail toEntity() => ModelDetail(
    id: id,
    code: code,
    gtin: gtin,
    categoryId: categoryId,
    categoryCode: categoryCode,
    categoryName: categoryName,
    length: length,
    width: width,
    height: height,
    standardPacking: standardPacking,
    layerLimit: layerLimit,
    layerCount: layerCount,
    stackingLength: stackingLength,
    stackingWidth: stackingWidth,
    boxPerLayer: boxPerLayer,
    boxPerPallet: boxPerPallet,
    setPerPallet: setPerPallet,
    cargoLength: cargoLength,
    cargoWidth: cargoWidth,
    cargoHeight: cargoHeight,
    suggestAreaId: suggestAreaId,
    suggestAreaCode: suggestAreaCode,
    suggestAreaName: suggestAreaName,
    suggestRackRow: suggestRackRow ?? const [],
    isActive: isActive,
    createdAt: createdAt,
  );
}

/// Body cho `PATCH /api/models/{id}/suggestion`.
///
/// includeIfNull: true — null nghĩa là XOÁ gợi ý, phải gửi key lên chứ không
/// được bỏ qua. Luôn gửi đủ cả 2 field.
@JsonSerializable(createFactory: false, includeIfNull: true)
class ModelSuggestionPatchRequest {
  final int? suggestAreaId;
  final List<int>? suggestRackRow;

  const ModelSuggestionPatchRequest({
    required this.suggestAreaId,
    required this.suggestRackRow,
  });

  Map<String, dynamic> toJson() => _$ModelSuggestionPatchRequestToJson(this);
}

/// Body cho `PUT /api/models/{id}` — khớp `UpdateModelRequest`.
///
/// includeIfNull: true — PUT ghi đè toàn bộ, null nghĩa là XOÁ giá trị.
@JsonSerializable(createFactory: false, includeIfNull: true)
class ModelUpdateRequest {
  final String? gtin;
  final int length;
  final int width;
  final int height;
  final int standardPacking;
  final int? layerLimit;
  final int? layerCount;
  final int? stackingLength;
  final int? stackingWidth;
  final int? suggestAreaId;
  final List<int>? suggestRackRow;
  final bool isActive;

  const ModelUpdateRequest({
    required this.gtin,
    required this.length,
    required this.width,
    required this.height,
    required this.standardPacking,
    required this.layerLimit,
    required this.layerCount,
    required this.stackingLength,
    required this.stackingWidth,
    required this.suggestAreaId,
    required this.suggestRackRow,
    required this.isActive,
  });

  factory ModelUpdateRequest.fromEdit(ModelEdit e) {
    final gtin = (e.gtin ?? '').trim();
    final rows = e.suggestRackRow.toSet().toList()..sort();
    return ModelUpdateRequest(
      gtin: gtin.isEmpty ? null : gtin,
      length: e.length,
      width: e.width,
      height: e.height,
      standardPacking: e.standardPacking,
      layerLimit: e.layerLimit,
      layerCount: e.layerCount,
      stackingLength: e.stackingLength,
      stackingWidth: e.stackingWidth,
      suggestAreaId: e.suggestAreaId,
      suggestRackRow: rows.isEmpty ? null : rows,
      // PDA không cho tắt model — luôn gửi true.
      isActive: true,
    );
  }

  Map<String, dynamic> toJson() => _$ModelUpdateRequestToJson(this);
}