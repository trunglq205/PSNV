namespace Swms.FinishGoods.Web.Features.Inventory.Business.Models;

// ── Dòng tồn kho = 1 lot đang nằm trong kho ─────────────────────────
//
// TRƯỚC ĐÂY kế thừa AppPallet của feature Lots. Giờ tự chứa — Inventory không
// còn tham chiếu nào sang feature Pallet ở tầng Web.
public class AppInventoryItem
{
    public long Id { get; set; }
    public string LotNo { get; set; } = "";
    public string? StockyCode { get; set; }
    public int CategoryCode { get; set; }
    public string CategoryName { get; set; } = "";
    public string LotType { get; set; } = "pallet";       // pallet | stocky (giá trị DB)
    public long? LocatorId { get; set; }
    public string? LocatorCode { get; set; }
    public string? AreaCode { get; set; }
    public string DetailLevel { get; set; } = "serial";   // serial | box_line | box_count
    public string InspectionStatus { get; set; } = "not_required";
    public bool IsUrgent { get; set; }
    public bool IsEvenPallet { get; set; }
    public string? SiNo { get; set; }

    public int BoxCount { get; set; }
    public int LineCount { get; set; }
    public int TotalQty { get; set; }
    public string? Model { get; set; }

    public List<string> Models { get; set; } = new();     // DISTINCT model
    public List<string> Origins { get; set; } = new();    // DISTINCT origin_country

    public string ProductionDate { get; set; } = "—";
    public bool IsAging { get; set; }                     // quá ngưỡng aging kể từ ngày SX
    public string CreatedAt { get; set; } = "";
    public string CreatedBy { get; set; } = "";

    public int? SapStatus { get; set; }
    public string SapPushedAt { get; set; } = "—";
    public bool IsSapPushed => SapPushedAt != "—";

    public List<AppInventoryBox> Boxes { get; set; } = new();

    // ── Phần đặc thù tồn kho ──
    public string AreaKey { get; set; } = "";       // staging | storing | vanning | jupiter | borrowed
    public string? LocatorName { get; set; }        // vd "Stocky STK-005"
    public string? BorrowedFrom { get; set; }       // kho cho mượn vị trí (FA, MCS)
    public int? AgeDays { get; set; }               // số ngày kể từ ngày SX
    public bool HasSerial { get; set; }
}

public class AppInventoryBox
{
    public long Id { get; set; }
    public string BoxNo { get; set; } = "";
    public string? SpecCode { get; set; }
    public string Dimension { get; set; } = "—";          // L×W×H (cm)
    public decimal? GrossWeight { get; set; }
    public string? PsnvPo { get; set; }
    public string? CustomerPo { get; set; }
    public string? Line { get; set; }
    public int? OqcStatus { get; set; }
    public string? LotName { get; set; }
    public string? Payload { get; set; }
    public string ProductionDate { get; set; } = "—";
    public List<AppInventoryBoxLine> Lines { get; set; } = new();
}

public class AppInventoryBoxLine
{
    public long Id { get; set; }
    public string Model { get; set; } = "";
    public decimal Qty { get; set; }
    public string? SerialNo { get; set; }
    public string OriginCountry { get; set; } = "";
    public int? CartonQty { get; set; }
    public int? PcsPerCarton { get; set; }

    public bool HasSerial => !string.IsNullOrWhiteSpace(SerialNo);
    public bool HasCarton => CartonQty is > 0;
}

// ── Card khu vực (5 card đầu trang) ──
public class AppInventoryArea
{
    public string Key { get; set; } = "";
    public int PalletCount { get; set; }
    public int BoxCount { get; set; }
    public int TotalQty { get; set; }
    public int ModelCount { get; set; }
}

// ── Bucket aging (dialog Aging / FIFO) ──
public class AppAgingBucket
{
    public string Key { get; set; } = "";           // lt30 | d30_60 | d60_90 | gt90
    public int FromDays { get; set; }
    public int? ToDays { get; set; }
    public int PalletCount { get; set; }
    public int TotalQty { get; set; }
    public double Share { get; set; }               // 0..1 theo pallet
}

// ── Định nghĩa khu vực + helper hiển thị ──
public record InventoryAreaDef(string Key, string LabelKey, string HintKey, string Color, string Pill);

/// <summary>
/// Helper hiển thị của màn Tồn kho.
///
/// Đã GỘP các hàm trước đây nằm ở PalletDisplay (inspection / SAP / detail level /
/// lot type / OQC của box). Khoá resource giữ nguyên tiền tố "Lots.*" vì chúng nằm
/// trong SharedResource dùng chung cho cả ứng dụng, không thuộc feature nào — đổi
/// tên khoá là 20+ dòng x 4 file resx mà không đổi hành vi.
/// </summary>
public static class InventoryDisplay
{
    public const int AgingThresholdDays = 90;   // quá 3 tháng kể từ ngày SX = aging

    public static readonly IReadOnlyList<InventoryAreaDef> Areas = new List<InventoryAreaDef>
    {
        new("fa",        "Inventory.Area.FA",        "Inventory.Area.FA.Hint", "#D9701A", "warning"),
        new("receiving", "Inventory.Area.Receiving", "Inventory.Area.Receiving.Hint", "#0F6CBD", "info"),
        new("storing",   "Inventory.Area.Storing",   "Inventory.Area.Storing.Hint",   "#22A06B", "success"),
        new("vanning",   "Inventory.Area.Vanning",   "Inventory.Area.Vanning.Hint",   "#7C4DBE", "dim"),
        new("customer",  "Inventory.Area.Customer",  "Inventory.Area.Customer.Hint",   "#0E7C86", "dim"),
    };

    public static InventoryAreaDef? Area(string? key) => Areas.FirstOrDefault(a => a.Key == key);
    public static string AreaLabelKey(string? key) => Area(key)?.LabelKey ?? "Inventory.Area.Unknown";
    public static string AreaPill(string? key) => Area(key)?.Pill ?? "dim";

    // Fallback khi backend chỉ trả area_code kiểu RECEIVING/STORAGE/VANNING (chưa có AreaKey).
    public static string AreaFromCode(string? areaCode, string? borrowedFrom, bool isHeavy)
    {
        if (!string.IsNullOrEmpty(borrowedFrom)) return "borrowed";
        if (isHeavy) return "jupiter";
        return areaCode?.ToUpperInvariant() switch
        {
            "RECEIVING" => "receiving",
            "STORAGE" or "STORING" => "storing",
            "VANNING" => "vanning",
            "JUPITER" or "EXTERNAL" => "jupiter",
            "BORROWED" => "borrowed",
            _ => "",
        };
    }

    public static int? AgeDays(DateTime? productionDate)
        => productionDate is { } d ? Math.Max(0, (DateTime.Today - d.Date).Days) : null;

    public static string AgingBucketLabelKey(string key) => key switch
    {
        "lt30" => "Inventory.Aging.Lt30",
        "d30_60" => "Inventory.Aging.D30_60",
        "d60_90" => "Inventory.Aging.D60_90",
        "gt90" => "Inventory.Aging.Gt90",
        _ => key,
    };

    public static string AgingBucketColor(string key) => key switch
    {
        "lt30" => "var(--success)",
        "d30_60" => "var(--info)",
        "d60_90" => "var(--warning)",
        "gt90" => "var(--danger)",
        _ => "var(--border-2)",
    };

    // Khoảng tổng SL — dùng Select để tái dùng AdvancedFilterPanel sẵn có.
    public static (int? Min, int? Max) QtyRange(string? key) => key switch
    {
        "lt50" => (null, 49),
        "50_200" => (50, 200),
        "200_500" => (201, 500),
        "gt500" => (501, null),
        _ => (null, null),
    };

    // ══════════════════════════════════════════════════════════════
    //  Gộp từ PalletDisplay (feature Lots đã gỡ)
    // ══════════════════════════════════════════════════════════════

    public static string LevelLabelKey(string? key) => key switch
    {
        "serial" => "Lots.Level.Serial",
        "box_line" => "Lots.Level.BoxLine",
        "box_count" => "Lots.Level.BoxCount",
        _ => "Lots.Level.All",
    };

    public static string LevelPill(string? level) => level switch
    {
        "serial" => "info",
        "box_line" => "dim",
        "box_count" => "warning",
        _ => "dim",
    };

    public static string LocatorPill(string? locator) => locator switch
    {
        "RECEIVING" => "info",
        "STORAGE" => "success",
        "VANNING" => "warning",
        _ => "dim",
    };

    // inspection_status → khóa resource + màu pill
    public static string InspectionLabelKey(string s) => s switch
    {
        "not_inspected" => "Lots.Inspection.NotInspected",
        "under_inspection" => "Lots.Inspection.UnderInspection",
        "pending_result" => "Lots.Inspection.PendingResult",
        "pass" => "Lots.Inspection.Passed",
        "ng" => "Lots.Inspection.Ng",
        "inspection_exempt" => "Lots.Inspection.InspectionExempt",
        _ => "Lots.Inspection.Unknown",
    };

    private const string PillBase = "border:1px solid;";

    /// <summary>
    /// Màu OQC dạng inline style — đồng bộ với màu ô trạng thái trên bản đồ kho (SwStyle).
    /// Dùng thay cho class pill khi cần đúng mã màu.
    /// </summary>
    public static string InspectionStyle(string? status) => PillBase + ((status ?? "empty") switch
    {
        "pass" => "background:#3FBF6B;border-color:#2E9E52;color:#ffffff",
        "ng" => "background:#E53935;border-color:#B71C1C;color:#ffffff",
        "under_inspection" => "background:#F5A623;border-color:#D98A0B;color:#5c3d00",
        "pending_result" => "background:#8ECAE6;border-color:#5AA8CC;color:#0b3a4a",
        "inspection_exempt" => "background:#1565C0;border-color:#0D47A1;color:#ffffff",
        "not_inspected" => "background:#FFD54F;border-color:#D9AC0B;color:#4a3b00",
        _ => "background:#FFFFFF;border-color:#C7CDD6;color:#8a94a0",
    });

    /// <summary>
    /// Nhãn của lot_type. Giá trị DB là "pallet" | "stocky"; "stocky_cart" là
    /// chuỗi cũ chỉ tồn tại ở tầng Web — nhận cả hai để dữ liệu hay URL cũ
    /// không rơi vào nhánh mặc định và hiện ra mã thô.
    /// </summary>
    public static string LotTypeLabelKey(string t) => t switch
    {
        "pallet" => "Lots.LotType.Pallet",
        "stocky" or "stocky_cart" => "Lots.LotType.StockyCart",
        _ => t,
    };

    // sap_status → khóa resource + màu pill. null/0 = chưa đẩy.
    public static string SapLabelKey(int? s) => s switch
    {
        0 => "Lots.Sap.NotReady",
        1 => "Lots.Sap.Pushing",
        2 => "Lots.Sap.Pushed",
        3 => "Lots.Sap.Error",
        4 => "Lots.Sap.Completed",
        _ => "Lots.Sap.NotReady",   // NULL (bản ghi cũ) coi như chưa hoàn thành
    };

    /// <summary>
    /// Cùng bảng màu với OQC: xanh lá = xong, đỏ = lỗi, cam = đang chờ,
    /// xanh nhạt = đang chạy, trắng = chưa bắt đầu.
    /// </summary>
    public static string SapStyle(int? status) => PillBase + (status switch
    {
        1 => "background:#8ECAE6;border-color:#5AA8CC;color:#0b3a4a",   // đang đẩy
        2 => "background:#F5A623;border-color:#D98A0B;color:#5c3d00",   // chờ SAP nhận
        3 => "background:#E53935;border-color:#B71C1C;color:#ffffff",   // lỗi
        4 => "background:#3FBF6B;border-color:#2E9E52;color:#ffffff",   // SAP đã nhận
        _ => "background:#FFFFFF;border-color:#C7CDD6;color:#8a94a0",   // chưa đẩy / NULL
    });

    // oqc_status của BOX (2/3/4/5) -> inspection_status string, để tái dùng
    // InspectionLabelKey / InspectionPill của cấp lot (không cần resx mới).
    public static string? BoxOqcToInspection(int? s) => s switch
    {
        2 => "under_inspection",  // OQC Check
        3 => "pending_result",    // Chờ KQ
        4 => "ng",                // NG
        5 => "pass",              // Pass
        _ => null,                // 0/null: chưa qua OQC -> không hiện badge
    };
}
