import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/box_detail/data/models/box_detail_model.dart';
import 'package:swms_finish_goods/features/box_detail/data/models/box_history_model.dart';

part 'box_detail_remote_data_source.g.dart';

@RestApi()
abstract class BoxDetailRemoteDataSource {
  factory BoxDetailRemoteDataSource(Dio dio, {String baseUrl}) =
      _BoxDetailRemoteDataSource;

  /// Định danh duy nhất theo id.
  @GET('/api/boxes/{id}/detail')
  Future<BoxDetailModel> fetchBoxDetail(@Path('id') int id);

  /// Quét mã box. box_no KHÔNG duy nhất — truyền palletId đang quét để định danh.
  @GET('/api/boxes/by-box-no/{boxNo}/detail')
  Future<BoxDetailModel> fetchBoxDetailByBoxNo(
    @Path('boxNo') String boxNo, {
    @Query('palletId') String? palletId,
  });

  /// Cập nhật PO. null = xoá giá trị.
  @PATCH('/api/boxes/{id}')
  Future<BoxDetailModel> patchBox(
    @Path('id') int id,
    @Body() BoxPatchRequest body,
  );

  /// Lịch sử thùng: header + timeline.
  ///
  /// [ownOnly] = true thì bỏ phần KẾ THỪA từ pallet chứa thùng, chỉ còn thao
  /// tác trên chính thùng (tạo, đổi pallet, sửa PO, OQC). Lọc ở SERVER chứ
  /// không lọc ở client: pallet nằm kho lâu có thể kéo theo hàng trăm dòng kế
  /// thừa, tải hết về rồi vứt đi là lãng phí mạng kho.
  @GET('/api/boxes/{id}/history')
  Future<BoxHistoryModel> fetchBoxHistory(
    @Path('id') int id, {
    @Query('ownOnly') bool? ownOnly,
  });
}
