﻿namespace SWMS_WebTool.Models
{
    public class KittingList : AuditableEntity
    {
        public Int64 ID { get; set; }
        public string Plant { get; set; }
        public string SpecialPart { get; set; }
        public string Line { get; set; }
        public string Time { get; set; }
        public string Model { get; set; }
        public int ModelQuantity { get; set; }
        public DateTime? Deliverydate { get; set; }
        public string Category { get; set; }
        public string Barcode { get; set; }
        public string BarcodeLine { get; set; }
        public double Quantity { get; set; }
        public byte KittingType { get; set; }
        public string CodeTrolley { get; set; }
        public string KittingTimeType { get; set; }
        public string PositionFA { get; set; }
        public string Reason { get; set; }
        public bool IsUrgent { get; set; }
        public bool IsJIT { get; set; }
        public bool IsProcess { get; set; }
        public bool IsCommon { get; set; }
        public bool IsChecking { get; set; }
        public bool IsSupply { get; set; }
        public bool IsChecked { get; set; }
    }
}
