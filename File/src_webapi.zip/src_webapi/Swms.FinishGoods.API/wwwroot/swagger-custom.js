﻿window.addEventListener("load", function () {
    const t = setInterval(function () {
        if (window.ui && window.ui.preauthorizeApiKey) {
            const token = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJzdWIiOiIxIiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbmFtZWlkZW50aWZpZXIiOiIxIiwiZW1wbG95ZWVfY29kZSI6ImFkbWluIiwiaHR0cDovL3NjaGVtYXMueG1sc29hcC5vcmcvd3MvMjAwNS8wNS9pZGVudGl0eS9jbGFpbXMvbmFtZSI6IkFkbWluIiwianRpIjoiODAxNjZkMDItNzgxNS00NjMxLWJhMzYtZTQ1YzQxMTM0YjcwIiwiZXhwIjoxNzg3NTY1NDczLCJpc3MiOiJTV01TIiwiYXVkIjoiU1dNUyJ9.ppDqYF6ixDxvRjP0LWN93jRXO-GaHxLeGuV4o4HxywM"; // token mặc định
            window.ui.preauthorizeApiKey("Bearer", token);
            clearInterval(t);
        }
    }, 300);
});