﻿using Swms.FinishGoods.API.Shared.Business.Mail;

namespace Swms.FinishGoods.API.Features.AbnormalReports.DataAccess;

public interface INgReportRepository
{
    Task<IReadOnlyList<NgReport>> GetListAsync(string? status, string? ngType, DateTime? from, DateTime? to, string? keyword);
    Task<NgReportDetail?> GetAsync(long id);
    Task<NgReport?> GetHeaderAsync(long id);

    /// <summary>Tra pallet theo mã quét; null = không tìm thấy.</summary>
    Task<long?> FindPalletAsync(string palletCode);

    /// <summary>Tra pallet kèm thông tin tóm tắt để PDA xác nhận lúc quét.</summary>
    Task<NgPalletBrief?> FindPalletBriefAsync(string palletCode);

    Task<(long Id, string DocNo)> CreateAsync(NgReport header, IReadOnlyList<NgItem> items, string? user);

    /// <summary>Sửa phiếu nháp; false nếu phiếu không còn nháp.</summary>
    Task<bool> UpdateDraftAsync(long id, string ngType, string? description,
        IReadOnlyList<NgItem> items, string? user);

    /// <summary>Xoá mềm 1 ảnh của phiếu nháp.</summary>
    Task<bool> DeletePhotoAsync(long photoId, string? user);

    Task AddPhotoAsync(NgPhoto photo, string? user);
    Task<NgPhoto?> GetPhotoAsync(long photoId);
    Task<int> CountPhotosAsync(long ngId);

    /// <summary>Ghi 1 bước duyệt (leader | fa | oqc | finalize) + nhật ký.</summary>
    /// <param name="skipOqc">
    /// true ở bước leader/submit = model này không cần OQC: phiếu ghi
    /// oqc_status = 'skipped' và nhảy thẳng sang current_step = 'fa_confirm'.
    /// </param>
    Task ApplyStepAsync(long id, string step, string action, string? resolution, string? comment,
        string? user, string? userCode = null, bool skipOqc = false);

    /// <summary>
    /// Người nhận mail của 1 sự kiện, lấy từ master.email_config qua hàm
    /// master.fn_email_recipients. KHÔNG nhận danh sách từ client.
    ///
    /// Bộ phận nào được thông báo cũng lấy TỪ CẤU HÌNH, không liệt kê trong
    /// code: thêm bộ phận thứ ba vào màn Cấu hình email là nó tự nhận mail,
    /// không phải sửa và build lại.
    /// </summary>
    Task<List<MailRecipient>> GetMailRecipientsAsync(
        string eventCode, string? category = null, string? model = null);

    /// <summary>Loại lỗi đang dùng được, theo thứ tự hiện trên màn hình.</summary>
    Task<List<NgTypeRow>> GetTypesAsync();

    /// <summary>Danh mục cho màn quản trị: cả loại đang tắt, kèm số phiếu đang dùng.</summary>
    Task<List<NgTypeRow>> GetTypesForAdminAsync();

    Task<int> CountReportsOfTypeAsync(string code);

    /// <summary>Thêm hoặc sửa; mã đã xoá mềm thì hồi sinh.</summary>
    Task UpsertTypeAsync(NgTypeRow t, string? user);

    /// <summary>Xoá mềm. false = không có mã đó (hoặc đã xoá từ trước).</summary>
    Task<bool> SoftDeleteTypeAsync(string code, string? user);

    /// <summary>
    /// Loại lỗi này có phải qua OQC không, theo master.ng_types.requires_oqc.
    /// null = không có dòng nào mang mã đó; nơi gọi tự quyết mặc định.
    /// </summary>
    Task<bool?> GetRequiresOqcAsync(string? ngType);

    /// <summary>Email của một nhân viên, chỉ dùng để đặt Reply-To. null = chưa khai.</summary>
    Task<string?> GetUserEmailAsync(string? employeeCode);

    /// <summary>
    /// Mẫu tiêu đề/thân mail của sự kiện, lấy từ master.email_events. Để trong
    /// DB nên sửa được nội dung mail từ màn Cấu hình email, không cần deploy.
    /// null = chưa khai sự kiện.
    /// </summary>
    Task<MailTemplateRow?> GetMailTemplateAsync(string eventCode);
}

/// <summary>
/// Mẫu mail đọc từ master.email_events. Dùng class có property chứ không dùng
/// ValueTuple: Dapper map ValueTuple theo VỊ TRÍ cột, đổi thứ tự cột trong câu
/// SELECT là sai âm thầm; map theo tên property thì không.
/// </summary>
public class MailTemplateRow
{
    public string? Subject { get; set; }
    public string? Body { get; set; }
}
