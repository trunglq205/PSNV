﻿namespace SWMS_WebTool.Models
{
    public class LayoutCapacity
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string TypeSloc { get; set; }
        public int TotalSmallRackCurrent { get; set; } = 0;
        public int TotalBigRackCurrent { get; set; } = 0;
        public int TotalPalletCurrent { get; set; } = 0;
        public int TotalJITCurrent { get; set; } = 0;
        public int TotalSmallRack { get; set; } = 0;
        public int TotalBigRack { get; set; } = 0;
        public int TotalPallet { get; set; } = 0;
        public int TotalJIT { get; set; } = 0;

        public int TotalStorage { get; set; } = 0;

        public double ReceivedProcessSmall
        {
            get { return (double)TotalSmallRackCurrent / TotalSmallRack * 100; }
        }

        public double ReceivedProcessBig
        {
            get { return (double)TotalBigRackCurrent / TotalBigRack * 100; }
        }

        public double ReceivedProcessPallet
        {
            get { return (double)TotalPalletCurrent / TotalPallet * 100; }
        }

        public double ReceivedProcessJIT
        {
            get { return (double)TotalJITCurrent / TotalJIT * 100; }
        }
    }
}
