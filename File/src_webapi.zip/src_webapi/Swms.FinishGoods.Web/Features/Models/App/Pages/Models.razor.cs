using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web;
using Swms.FinishGoods.Web.Features.Models.Business;
using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Resources;
using Swms.FinishGoods.Web.Shared.App.Components;
using Swms.FinishGoods.Web.Shared.App.Layout;
using Swms.FinishGoods.Web.Shared.App.Model;
using Swms.FinishGoods.Web.Shared.App.Toast;

namespace Swms.FinishGoods.Web.Features.Models.App.Pages;

public partial class Models
{
    private RowActionMenu<AppModel>? _rowMenu;

    [Inject] private IModelBusiness ModelBusiness { get; set; } = default!;
    [Inject] private ToastService Toast { get; set; } = default!;

    private List<CategoryDto> _categoryOptions = new();
    private List<WarehouseAreaDto> _areaOptions = new();

    // ── Icons (copy style tu Users) ──────────────────────────
    private const string IcEye = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7z'/><circle cx='12' cy='12' r='3'/></svg>";
    private const string IcEdit = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M11 4H4a2 2 0 00-2 2v14a2 2 0 002 2h14a2 2 0 002-2v-7'/><path d='M18.5 2.5a2.12 2.12 0 013 3L12 15l-4 1 1-4z'/></svg>";
    private const string IcLock = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='3' y='11' width='18' height='11' rx='2'/><path d='M7 11V7a5 5 0 0110 0v4'/></svg>";
    private const string IcUnlock = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='3' y='11' width='18' height='11' rx='2'/><path d='M7 11V7a5 5 0 019.9-1'/></svg>";
    private const string IcTrash = "<svg viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M3 6h18M8 6V4a2 2 0 012-2h4a2 2 0 012 2v2M19 6l-1 14a2 2 0 01-2 2H8a2 2 0 01-2-2L5 6'/></svg>";
    private const string IcScopeGtin = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><path d='M3 5v14M7 5v14M11 5v14M14 5v14M18 5v14M21 5v14'/></svg>";

    private const string IcScopeCode = "<svg width='16' height='16' viewBox='0 0 24 24' fill='none' stroke='currentColor' stroke-width='2'><rect x='3' y='4' width='18' height='16' rx='2'/><path d='M7 8h4M7 12h2M15 8h2M15 12h2M7 16h10'/></svg>";

    // ── Khai bao search-suggest (build moi tu resource theo ngon ngu hien tai) ─
    protected override IReadOnlyList<SearchScope> SearchScopes => new List<SearchScope>
    {
        new("code", L["Models.Search.Code.Title"], L["Models.Search.Code.Hint"], IcScopeCode, L["Models.Search.Code.Short"]),
        new("gtin", L["Models.Search.Gtin.Title"], L["Models.Search.Gtin.Hint"], IcScopeGtin, L["Models.Search.Gtin.Short"]),  // ← thêm
    };

    // ── Khai bao filter nang cao (build moi tu resource) ─────
    protected override IReadOnlyList<ListFilterField> FilterFields => new List<ListFilterField>
    {
        new()
        {
            Key = "category", Label = L["Models.Filter.Category"], Kind = ListFilterKind.Select,
            Options = new[] { new ListFilterOption("", L["Models.Filter.Category.All"]) }
                .Concat(_categoryOptions.Select(c => new ListFilterOption(c.Code.ToString(), c.Name ?? "")))
                .ToArray(),
        },
        new()
        {
            Key = "origin", Label = L["Models.Filter.Origin"], Kind = ListFilterKind.Select,
            Options = new[] { new ListFilterOption("", L["Models.Filter.Origin.All"]) }
                .Concat(OriginRule.All.Select(o => new ListFilterOption(o.Code, o.DisplayText)))
                .ToArray(),
        },
        new()
        {
            Key = "area", Label = L["Models.Filter.Area"], Kind = ListFilterKind.Select,
            Options = new[] { new ListFilterOption("", L["Models.Filter.Area.All"]) }
                .Concat(_areaOptions.Select(a => new ListFilterOption(a.Id.ToString(), $"{a.AreaCode} - {a.AreaName}")))
                .ToArray(),
        },
        new()
        {
            Key = "status", Label = L["Models.Filter.Status"], Kind = ListFilterKind.Select,
            Options = new[]
            {
                new ListFilterOption("",  L["Models.Filter.Status.All"]),
                new ListFilterOption("1", L["Models.Filter.Status.Active"]),
                new ListFilterOption("0", L["Models.Filter.Status.Inactive"]),
            },
        },
        new() { Key = "created", Label = L["Models.Filter.Created"], Kind = ListFilterKind.DateRange },
    };

    // ── 4 cho truu tuong cua ListPageBase ────────────────────
    protected override ModelQuery BuildQuery()
    {
        var category = Applied("category").Value;
        var area = Applied("area").Value;
        var origin = Applied("origin").Value;
        var status = Applied("status").Value;
        var created = Applied("created");

        return new ModelQuery
        {
            Code = TryGetTerm("code", out var c) ? c : null,
            GTIN = TryGetTerm("gtin", out var g) ? g : null,
            CategoryCode = int.TryParse(category, out var catId) ? catId : null,
            SuggestAreaId = int.TryParse(area, out var areaId) ? areaId : null,
            Origin = OriginRule.Normalize(origin),
            IsActive = status switch { "1" => true, "0" => false, _ => (bool?)null },
            // created_at lưu bằng SYSUTCDATETIME() -> đổi giờ local sang UTC trước khi gửi
            CreatedFrom = ParseDate(created.FromValue)?.ToUniversalTime(),
            CreatedTo = ParseDateEndOfDay(created.ToValue)?.ToUniversalTime(),
            Page = Page,
            Size = PageSize,
        };
    }

    private IReadOnlyList<MenuAction> BuildRowActions(AppModel m) => new[]
    {
        MenuAction.Item(L["Models.Action.Detail"], IcEye,  Act(() => OpenDetail(m))),
        MenuAction.Item(L["Models.Action.Edit"],   IcEdit, Act(() => OpenEdit(m))),
        MenuAction.Separator(),
                MenuAction.Item(L["Models.Action.Delete"], IcTrash, Act(() => OpenDeleteConfirm(m)), danger: true),
    };

    protected override async Task<LoadOutcome<AppModel>> LoadPageAsync(ModelQuery query, CancellationToken ct)
    {
        var result = await ModelBusiness.GetPagedAsync(query);
        if (!result.IsSuccess || result.Value == null)
            return LoadOutcome<AppModel>.Fail(result.ErrorCode, result.ErrorMessage ?? L["Models.Load.ListFailed"]);

        return LoadOutcome<AppModel>.Ok(result.Value.Items.Select(ModelDto.ToViewModel).ToList(), result.Value.TotalCount);
    }

    protected override void ShowError(string message) => Toast.Error(message);

    protected override async Task OnFirstLoadAsync()
    {
        var r = await ModelBusiness.GetCategoriesAsync();
        if (r.IsSuccess && r.Value != null) _categoryOptions = r.Value;

        var a = await ModelBusiness.GetWarehouseAreasAsync();
        if (a.IsSuccess && a.Value != null) _areaOptions = a.Value;

        await ReloadAsync();
    }
}
