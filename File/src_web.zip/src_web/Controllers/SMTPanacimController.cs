﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.ImportModel;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;
using System.Data;

namespace SWMS_WebTool.Controllers
{
    public class SMTPanacimController : BaseController
    {
        private readonly ApiService _apiService;

        public SMTPanacimController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] SMTPanacimFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new SMTPanacimFilter();
                var response = await _apiService.SearchRCPanacim(_filter, pageNumber, _pageSize);

                var total = response.TotalRecord;
                var items = response.Records ?? new List<ReceivingCard>();

                var model = new SMTRCPanacimViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return View("Views/SMTPanacim/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }
        [HttpGet]
        public async Task<IActionResult> GetDetails(int receivingCardId, string date, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = new SMTPanacimFilter();
                var response = await _apiService.SearchSMTPanacim(receivingCardId, !string.IsNullOrEmpty(date) ? Convert.ToDateTime(date) : DateTime.Now);
                var total = 10;
                var items = response ?? new List<SMTPanacim>();
                var model = new SMTPanacimViewModel()
                {
                    Items = items,
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total,
                };
                return PartialView("Views/SMTPanacim/_SMTPanacimDetails.cshtml", model);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ImportNoPrintPanacim(IFormFile file)
        {
            try
            {
                if (file != null && file.Length > 0)
                {
                    var uploadDirectory = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "uploads");
                    if (!Directory.Exists(uploadDirectory))
                    {
                        Directory.CreateDirectory(uploadDirectory);
                    }
                    var fileextension = Path.GetExtension(file.FileName);
                    var filename = Guid.NewGuid().ToString() + fileextension;
                    var filepath = Path.Combine(uploadDirectory, filename);
                    using (FileStream fs = System.IO.File.Create(filepath))
                    {
                        await file.CopyToAsync(fs);
                    }
                    DataTable? dt = new DataTable();
                    if (fileextension == ".xlsx" || fileextension == ".xls")
                    {
                        dt = Function.GetDataTableFromExcel(filepath, "Sheet1", Constants.NoPrintPanacimHeader, Constants.IndexHeaderPanacim);
                        if (dt != null && dt.Columns.Count == Constants.NoPrintPanacimHeader.Count)
                        {

                            List<ImportNoPrintPanacim>? data = Function.DataTatbleToNoPrintPanacim(dt);
                            if (data != null && data.Count > 0)
                            {
                                return PartialView("~/Views/SMTPanacim/_ImportMasterNoPrintPanacim.cshtml", data);
                            }
                        }
                    }

                    return BadRequest(_loc.Get("Msg_FileFormatIncorect2"));
                }
                else
                {
                    return BadRequest(_loc.Get("Msg_NoFileSelected"));
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmImportInvoice([FromBody] List<ImportNoPrintPanacim> requests)
        {
            try
            {
                await _apiService.ImportNoPrintPanacim(requests);
                var countData = requests.Count;
                return Json(new { success = true, countData = countData });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpGet]
        public async Task<IActionResult> ViewReceivingCard(int id)
        {
            try
            {
                var receivingCard = await _apiService.GetReceivingCard(id);
                var listBoxes = receivingCard.ReceivingCardDetails.GroupBy(x => x.TotalQuantity).Select(x => new
                {
                    StandardPacking = x.Key,
                    BoxQuantity = x.Count(),
                }).OrderBy(x => x.StandardPacking).ToList();
                for (int i = 0;i < listBoxes.Count(); i++)
                {
                    receivingCard.BoxInfo += string.Format("({0}X{1}", listBoxes[i].BoxQuantity, listBoxes[i].StandardPacking);
                    if (i < listBoxes.Count - 1)
                    {
                        receivingCard.BoxInfo += ",";
                    }
                    else
                    {
                        receivingCard.BoxInfo += ")";
                    }
                }
                return PartialView("Views/Shared/_ReceivingCard.cshtml", receivingCard);
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }
    }
}

