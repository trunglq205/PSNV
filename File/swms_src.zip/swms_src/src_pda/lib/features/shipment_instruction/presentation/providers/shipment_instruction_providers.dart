import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/shipment_instruction/data/datasources/shipment_instruction_remote_data_source.dart';
import 'package:swms_finish_goods/features/shipment_instruction/data/repositories/shipment_instruction_repository_impl.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/repositories/shipment_instruction_repository.dart';

part 'shipment_instruction_providers.g.dart';

@riverpod
ShipmentInstructionRemoteDataSource shipmentInstructionRemoteDataSource(
  Ref ref,
) {
  return ShipmentInstructionRemoteDataSource(ref.watch(dioProvider));
}

@riverpod
ShipmentInstructionRepository shipmentInstructionRepository(Ref ref) {
  return ShipmentInstructionRepositoryImpl(
    ref.watch(shipmentInstructionRemoteDataSourceProvider),
  );
}
