﻿namespace Swms.FinishGoods.Web.Shared.Auth;

/// <summary>
/// Giữ quyền (permission keys) của user hiện tại trong phiên.
/// Đăng ký Scoped: builder.Services.AddScoped&lt;PermissionState&gt;();
/// Nạp dữ liệu bằng Set(...) sau khi gọi /api/auth/me.
/// </summary>
public class PermissionState
{
    private HashSet<string> _perms = new(StringComparer.OrdinalIgnoreCase);

    public string Username { get; private set; } = "";
    public bool IsLoaded { get; private set; }

    /// <summary>Bắn khi quyền thay đổi để UI (NavMenu) re-render.</summary>
    public event Action? OnChange;

    public void Set(string username, IEnumerable<string> perms)
    {
        Username = username;
        _perms = new HashSet<string>(perms ?? Enumerable.Empty<string>(), StringComparer.OrdinalIgnoreCase);
        IsLoaded = true;
        OnChange?.Invoke();
    }

    public void Clear()
    {
        Username = "";
        _perms.Clear();
        IsLoaded = false;
        OnChange?.Invoke();
    }

    /// <summary>Có đúng một quyền cụ thể.</summary>
    public bool Has(string key) => _perms.Contains(key);

    /// <summary>Có BẤT KỲ quyền nào trong danh sách (OR).</summary>
    public bool HasAny(params string[] keys) => keys.Length == 0 || keys.Any(_perms.Contains);

    /// <summary>Có TẤT CẢ quyền trong danh sách (AND).</summary>
    public bool HasAll(params string[] keys) => keys.All(_perms.Contains);

    /// <summary>
    /// Quy tắc hiển thị cho NavItem: không yêu cầu quyền => luôn hiện;
    /// ngược lại hiện nếu có bất kỳ quyền nào trong danh sách.
    /// </summary>
    public bool CanShow(params string[] required)
        => required.Length == 0 || required.Any(_perms.Contains);
}