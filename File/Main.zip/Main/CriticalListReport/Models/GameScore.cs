﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    /// <summary>
    /// Một lượt chơi mini game sau đăng nhập (ném ma Halloween / ném người tuyết Giáng sinh).
    /// Bảng: tblGameScore — tạo bằng script Sql/CreateGameScore.sql
    /// </summary>
    [Table("tblGameScore")]
    public class GameScore
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Username { get; set; } = string.Empty;

        [StringLength(200)]
        public string? FullName { get; set; }

        /// <summary>halloween | christmas</summary>
        [Required, StringLength(20)]
        public string Theme { get; set; } = "halloween";

        /// <summary>Thời gian từ quả ném đầu tiên tới lúc trúng đủ (mili giây). Càng nhỏ càng giỏi.</summary>
        public int DurationMs { get; set; }

        /// <summary>Tổng số lần ném.</summary>
        public int Throws { get; set; }

        /// <summary>Số lần ném trúng.</summary>
        public int Hits { get; set; }

        /// <summary>Có dùng phím Space (tự ngắm) không — lượt dùng Space không được xếp hạng.</summary>
        public bool UsedAuto { get; set; }

        public DateTime PlayedAt { get; set; } = DateTime.Now;
    }

    /// <summary>Dữ liệu trình duyệt gửi lên sau khi chơi xong.</summary>
    public class GameScoreSubmit
    {
        public string? Theme { get; set; }
        public int DurationMs { get; set; }
        public int Throws { get; set; }
        public int Hits { get; set; }
        public bool UsedAuto { get; set; }
    }
}
