import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';

/// Dòng nhắc vị trí kế tiếp trên tuyến.
class KittingNextHint extends StatelessWidget {
  final PickTask next;
  const KittingNextHint({super.key, required this.next});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
      decoration: BoxDecoration(
        color: swms.card2,
        border: Border.all(color: swms.border2),
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
      ),
      child: Row(
        children: [
          Icon(Icons.near_me_outlined, size: 14, color: swms.text3),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Text.rich(
              TextSpan(
                children: [
                  TextSpan(text: '${LocaleKeys.kitting_task_next.tr()}: '),
                  TextSpan(
                    text: next.locatorCode,
                    style: AppTextStyles.code.copyWith(
                      fontSize: 12,
                      letterSpacing: 0,
                      fontWeight: FontWeight.w700,
                      color: swms.text1,
                    ),
                  ),
                  TextSpan(text: ' · ${next.model}'),
                ],
              ),
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.caption.copyWith(
                fontSize: 12,
                color: swms.text3,
              ),
            ),
          ),
        ],
      ),
    );
  }
}
