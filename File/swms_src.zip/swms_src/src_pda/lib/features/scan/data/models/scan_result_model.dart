import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/scan/domain/entities/scan_result.dart';

part 'scan_result_model.g.dart';

/// Khớp `ScanResolveResponse` của API (GET /api/scan/resolve).
@JsonSerializable()
class ScanResultModel {
  final String code;
  final String type;
  final int? id;
  final String? areaCode;

  const ScanResultModel({
    required this.code,
    required this.type,
    this.id,
    this.areaCode,
  });

  factory ScanResultModel.fromJson(Map<String, dynamic> json) =>
      _$ScanResultModelFromJson(json);

  ScanResult toEntity() => ScanResult(
        code: code,
        type: ScanType.fromApi(type),
        id: id,
        areaCode: areaCode,
      );
}
