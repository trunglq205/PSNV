// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'historycheckocrmodel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

HistoryCheckOcrModel _$HistoryCheckOcrModelFromJson(
        Map<String, dynamic> json) =>
    HistoryCheckOcrModel(
      all: json['all'] as String?,
      checked: json['checked'] as String?,
    );

Map<String, dynamic> _$HistoryCheckOcrModelToJson(
        HistoryCheckOcrModel instance) =>
    <String, dynamic>{
      'all': instance.all,
      'checked': instance.checked,
    };
