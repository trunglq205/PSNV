import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/number_dial_dialog.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_text_field.dart';

/// Mở dialog chỉnh 1 giá trị số. Trả về null nếu huỷ.
///
/// Độ chính xác: 1 chữ số thập phân, hoặc số nguyên nếu [decimalDigits] = 0.
Future<double?> showAdjustValueDialog(
  BuildContext context, {
  required String label,
  required String unit,
  required double value,
  int decimalDigits = 1,
  double? maxValue,
}) async {
  final result = await showNumberDialDialog(
    context,
    title: label,
    unit: unit,
    value: value,
    decimalDigits: decimalDigits,
    maxValue: maxValue,
  );
  return result?.toDouble();
}

/// Mở dialog sửa 1 giá trị text (Origin...). Trả về null nếu huỷ.
Future<String?> showEditTextDialog(
  BuildContext context, {
  required String label,
  required String value,
}) {
  return showDialog<String>(
    context: context,
    builder: (_) => _EditTextDialog(label: label, initialValue: value),
  );
}

class _EditTextDialog extends StatefulWidget {
  const _EditTextDialog({required this.label, required this.initialValue});

  final String label;
  final String initialValue;

  @override
  State<_EditTextDialog> createState() => _EditTextDialogState();
}

class _EditTextDialogState extends State<_EditTextDialog> {
  late final TextEditingController _controller = TextEditingController(
    text: widget.initialValue,
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _submit() => Navigator.pop(context, _controller.text.trim());

  @override
  Widget build(BuildContext context) {
    return AppDialog(
      title: widget.label,
      actions: [
        AppDialogAction.cancel(context),
        AppDialogAction.confirm(onPressed: _submit),
      ],
      child: AppTextField(
        controller: _controller,
        dense: true,
        autofocus: true,
        clearable: true,
        textInputAction: TextInputAction.done,
        onSubmitted: (_) => _submit(),
      ),
    );
  }
}
