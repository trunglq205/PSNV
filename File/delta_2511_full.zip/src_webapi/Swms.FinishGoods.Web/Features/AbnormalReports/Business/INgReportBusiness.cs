﻿using Swms.FinishGoods.Web.Features.AbnormalReports.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.AbnormalReports.Business;

public interface INgReportBusiness
{
    Task<Result<List<NgReportSummaryDto>>> GetListAsync(string? status = null, string? ngType = null,
        DateTime? from = null, DateTime? to = null, string? keyword = null);
    Task<Result<NgReportDetailDto>> GetAsync(long id);

    /// <summary>
    /// Tải file Excel danh sách phiếu. Tên file do SERVER đặt (có mốc thời
    /// gian) và trả về trong header Content-Disposition — đọc từ đó chứ không
    /// tự đặt lại ở client, để chỉ có một nơi quyết định tên file.
    /// </summary>
    Task<Result<FileDownload>> DownloadListReportAsync(
        string? status, string? ngType, DateTime? from, DateTime? to, string? keyword,
        string? faRes, string? oqc, string? finalRes);

    /// <summary>Trả ảnh dạng data-uri để nhúng thẳng vào thẻ img.</summary>
    Task<Result<string>> GetPhotoDataUriAsync(long photoId, string size = "thumb");

    Task<Result> UpdateAsync(long id, UpdateNgReportRequestDto request);
    Task<Result> DeletePhotoAsync(long photoId);

    /// <summary>Danh mục loại lỗi, nhãn đã theo ngôn ngữ.</summary>
    Task<Result<List<NgTypeDto>>> GetTypesAsync();

    /// <summary>Duyệt xong sẽ gửi mail cho ai — hiện trong hộp xác nhận.</summary>
    Task<Result<MailPreviewDto>> GetMailPreviewAsync(long id);

    Task<Result> LeaderReviewAsync(long id, LeaderReviewRequestDto request);
    Task<Result> FaConfirmAsync(long id, FaConfirmRequestDto request);
    Task<Result> OqcConfirmAsync(long id, OqcConfirmRequestDto request);
    Task<Result> FaFixDoneAsync(long id, FaFixDoneRequestDto request);
    // ---- Quản trị danh mục loại lỗi ----
    Task<Result<List<NgTypeAdminDto>>> GetTypesForAdminAsync();
    Task<Result> SaveTypeAsync(NgTypeAdminDto type);
    Task<Result> DeleteTypeAsync(string code);
}
