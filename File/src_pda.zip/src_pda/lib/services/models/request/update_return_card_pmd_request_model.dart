import 'package:freezed_annotation/freezed_annotation.dart';

import 'base_request_model.dart';

part 'update_return_card_pmd_request_model.g.dart';

@JsonSerializable()
class UpdateReturnCardPmdRequestModel extends BaseRequestModel {
  UpdateReturnCardPmdRequestModel({
    required this.id,
    required this.quantity,
    required this.unit,
    required this.userIDUpdate,
    required this.statusRecycle,

  });
  factory UpdateReturnCardPmdRequestModel.fromJson(Map<String, dynamic> json) =>
      _$UpdateReturnCardPmdRequestModelFromJson(json);

  final int id;
  final double quantity;
  final String unit;
  final String userIDUpdate;
  final String statusRecycle;


  @override
  Map<String, dynamic> toJson() => _$UpdateReturnCardPmdRequestModelToJson(this);
}
