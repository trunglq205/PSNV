import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/barcode_scanner_widget.dart';
import 'package:swms_finish_goods/core/widgets/inputs/app_radio_card_group.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';

/// Bước 1: chọn phương thức nhận hàng + khung quét pallet.
class ReceivingScanBody extends StatelessWidget {
  const ReceivingScanBody({
    super.key,
    required this.mode,
    required this.onModeChanged,
  });

  final ReceivingMode mode;
  final ValueChanged<ReceivingMode> onModeChanged;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        // Nhãn nhóm
        Padding(
          padding: const EdgeInsets.only(bottom: AppDimens.sm),
          child: Text(
            LocaleKeys.receiving_choose_mode.tr(),
            style: AppTextStyles.label.copyWith(
              fontWeight: FontWeight.w700,
              color: swms.text3,
            ),
          ),
        ),

        // 3 lựa chọn phương thức
        AppRadioCardGroup<ReceivingMode>(
          value: mode,
          onChanged: onModeChanged,
          items: [
            RadioCardItem(
              value: ReceivingMode.box,
              title: LocaleKeys.receiving_mode_box_title.tr(),
              subtitle: LocaleKeys.receiving_mode_box_sub.tr(),
              icon: Icons.inventory_2,
            ),
            // RadioCardItem(
            //   value: ReceivingMode.model,
            //   title: LocaleKeys.receiving_mode_model_title.tr(),
            //   subtitle: LocaleKeys.receiving_mode_model_sub.tr(),
            //   icon: Icons.qr_code_scanner,
            // ),
            RadioCardItem(
              value: ReceivingMode.gtin,
              title: LocaleKeys.receiving_mode_gtin_title.tr(),
              subtitle: LocaleKeys.receiving_mode_gtin_sub.tr(),
              icon: Icons.barcode_reader,
            ),
          ],
        ),

        const SizedBox(height: AppDimens.md),

        // Khung quét minh hoạ
        BarcodeScannerButton(scanningLabel: LocaleKeys.receiving_scan_qr.tr()),
      ],
    );
  }
}
