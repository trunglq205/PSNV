import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/features/pallet/presentation/pages/pallet_flow_page.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow.dart';

/// Chuyển / Out vị trí — pallet đã lưu kho: move / release.
@RoutePage()
class WarehouseMoveScreen extends StatelessWidget {
  /// Nếu truyền sẵn (từ Pallet Detail) thì tự lookup, bỏ bước quét.
  final String? lotNo;

  const WarehouseMoveScreen({super.key, this.lotNo});

  @override
  Widget build(BuildContext context) =>
      PalletFlowPage(flow: PalletFlow.warehouseMove, lotNo: lotNo);
}
