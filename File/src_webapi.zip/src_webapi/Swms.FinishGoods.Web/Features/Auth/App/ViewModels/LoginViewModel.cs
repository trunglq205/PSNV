﻿using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.Web.Features.Auth.App.ViewModels
{
    public class LoginViewModel
    {
        [Required(ErrorMessage = "Vui lòng nhập tên đăng nhập.")]
        public string Username { get; set; } = string.Empty;

        [Required(ErrorMessage = "Vui lòng nhập mật khẩu.")]
        public string Password { get; set; } = string.Empty;

        public bool Remember { get; set; }
    }
}
