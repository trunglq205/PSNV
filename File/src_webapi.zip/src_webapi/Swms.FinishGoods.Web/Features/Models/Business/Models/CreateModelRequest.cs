using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.Web.Features.Models.Business.Models;

/// <summary>
/// Payload tạo mới model.
/// </summary>
public class CreateModelRequest
{
    [MaxLength(14, ErrorMessage = "GTIN tối đa 14 ký tự")]
    [RegularExpression(@"^(\d{8}|\d{12,14})?$", ErrorMessage = "GTIN phải là 8, 12, 13 hoặc 14 chữ số")]
    public string? GTIN { get; set; }
    [Required(ErrorMessage = "Mã model bắt buộc")]
    [MaxLength(30, ErrorMessage = "Mã model tối đa 30 ký tự")]
    public string Code { get; set; } = string.Empty;

    /// <summary>Mã xuất xứ 2 chữ cái, vd "VN". Null = không khai báo.</summary>
    [RegularExpression(OriginRule.Pattern, ErrorMessage = "Xuất xứ phải là 2 chữ cái (vd VN, JP)")]
    public string? Origin { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Danh mục bắt buộc")]
    public int CategoryId { get; set; }

    [Range(1, int.MaxValue, ErrorMessage = "Chiều dài phải > 0")]
    public int Length { get; set; }                  // mm

    [Range(1, int.MaxValue, ErrorMessage = "Chiều rộng phải > 0")]
    public int Width { get; set; }                   // mm

    [Range(1, int.MaxValue, ErrorMessage = "Chiều cao phải > 0")]
    public int Height { get; set; }                  // mm

    [Range(1, int.MaxValue, ErrorMessage = "Quy cách đóng gói phải > 0")]
    public int StandardPacking { get; set; }         // set / box

    // Quy cách xếp pallet — nhập đủ LayerCount/StackingLength/StackingWidth hoặc bỏ trống cả 3.
    [Range(1, StackingRule.MaxLayer, ErrorMessage = "Layer limit không hợp lệ")]
    public int? LayerLimit { get; set; }

    [Range(1, StackingRule.MaxLayer, ErrorMessage = "No of layer không hợp lệ")]
    public int? LayerCount { get; set; }

    [Range(1, StackingRule.MaxStacking, ErrorMessage = "Stacking length không hợp lệ")]
    public int? StackingLength { get; set; }

    [Range(1, StackingRule.MaxStacking, ErrorMessage = "Stacking width không hợp lệ")]
    public int? StackingWidth { get; set; }

    /// <summary>Khu vực gợi ý (FK warehouse_areas.id). Null = không cấu hình.</summary>
    [Range(1, int.MaxValue, ErrorMessage = "Khu vực gợi ý không hợp lệ")]
    public int? SuggestAreaId { get; set; }

    /// <summary>Tầng rack gợi ý, vd [2, 3]. Null/rỗng = không cấu hình.</summary>
    public List<int>? SuggestRackRow { get; set; }

    public bool IsActive { get; set; } = true;
}
