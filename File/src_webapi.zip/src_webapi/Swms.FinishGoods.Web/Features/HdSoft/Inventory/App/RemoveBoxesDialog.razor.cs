using Microsoft.AspNetCore.Components;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;
using Swms.FinishGoods.Web.Resources;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.App;

public partial class RemoveBoxesDialog
{
    /// <summary>Hành động "boxes" của dòng so. Null = đóng.</summary>
    [Parameter] public HdRowAction? Action { get; set; }

    /// <summary>Xoá xong — tham số là câu tóm tắt để dialog so đánh dấu dòng.</summary>
    [Parameter] public EventCallback<string> OnDone { get; set; }

    [Parameter] public EventCallback OnClose { get; set; }

    [Inject] private IHdSoftCompareBusiness Business { get; set; } = default!;
    [Inject] private IStringLocalizer<SharedResource> L { get; set; } = default!;

    /// <summary>Số thùng vẽ tối đa — tìm kiếm để thu hẹp khi pallet quá nhiều thùng.</summary>
    private const int MaxRows = 300;

    private HdRowAction? _for;
    private AppInventoryItem? _detail;
    private bool _loading;
    private string? _loadError;

    private string _q = "";
    private bool _onlyModel = true;
    private readonly HashSet<long> _selected = new();

    private bool _confirming;
    private bool _busy;
    private string? _error;

    // Mỗi lần mở cho 1 hành động khác thì tải lại chi tiết — không dùng dữ liệu cũ để xoá.
    protected override async Task OnParametersSetAsync()
    {
        if (ReferenceEquals(Action, _for)) return;
        _for = Action;

        _detail = null;
        _loadError = null;
        _error = null;
        _q = "";
        _onlyModel = true;
        _selected.Clear();
        _confirming = false;
        _busy = false;

        if (Action?.Lot is not { } lot) return;

        _loading = true;
        var r = await Business.GetPalletDetailAsync(lot.Id);
        if (!ReferenceEquals(Action, _for)) return;     // đã đóng / mở dòng khác trong lúc tải

        _loading = false;
        if (r.IsSuccess && r.Value is not null) _detail = r.Value;
        else _loadError = r.ErrorMessage ?? L["Lots.Load.DetailFailed"];
    }

    // ── Số liệu ──────────────────────────────────────────────

    /// <summary>Cần bớt bao nhiêu pcs của model dòng.</summary>
    private int Need => Action is { } a ? Math.Max(0, a.OldQty - a.Qty) : 0;

    private IReadOnlyList<AppInventoryBox> AllBoxes => _detail?.Boxes ?? (IReadOnlyList<AppInventoryBox>)Array.Empty<AppInventoryBox>();

    private IEnumerable<AppInventoryBox> SelectedBoxes => AllBoxes.Where(b => _selected.Contains(b.Id));

    private int SelectedQty => SelectedBoxes.Sum(QtyOf);

    /// <summary>Phần của model dòng trong các thùng đã chọn — đây mới là thứ so với Need.</summary>
    private int SelectedModelQty => SelectedBoxes.Sum(b => (int)b.Lines
        .Where(l => IsRowModel(l.Model))
        .Sum(l => l.Qty));

    /// <summary>Đủ -> xanh; chưa đủ -> vàng; quá tay -> đỏ.</summary>
    private string SelectedPill => _selected.Count == 0 ? "dim"
        : SelectedModelQty == Need ? "success"
        : SelectedModelQty < Need ? "warning"
        : "danger";

    // ── Lọc ──────────────────────────────────────────────────

    private List<AppInventoryBox> Filtered
    {
        get
        {
            IEnumerable<AppInventoryBox> q = AllBoxes;
            if (_onlyModel && Action is { Model.Length: > 0 })
                q = q.Where(b => b.Lines.Any(l => IsRowModel(l.Model)));

            var k = _q.Trim();
            if (k.Length > 0)
                q = q.Where(b => Has(b.BoxNo, k) || Has(b.Payload, k) || Has(b.LotName, k) || Has(b.Line, k)
                                 || b.Lines.Any(l => Has(l.SerialNo, k) || Has(l.Model, k)));
            return q.ToList();
        }
    }

    private List<AppInventoryBox> Shown => Filtered.Take(MaxRows).ToList();

    private bool AllShownSelected => Shown.Count > 0 && Shown.All(b => _selected.Contains(b.Id));

    private static bool Has(string? s, string k) => s?.Contains(k, StringComparison.OrdinalIgnoreCase) == true;

    private bool IsRowModel(string? m)
        => string.Equals((m ?? "").Trim(), (Action?.Model ?? "").Trim(), StringComparison.OrdinalIgnoreCase);

    // ── Hiển thị ─────────────────────────────────────────────

    private static int QtyOf(AppInventoryBox b) => (int)b.Lines.Sum(l => l.Qty);

    private static string ModelsOf(AppInventoryBox b)
    {
        var models = b.Lines.Select(l => l.Model).Where(m => !string.IsNullOrWhiteSpace(m))
                            .Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        return models.Count == 0 ? "—" : string.Join(", ", models);
    }

    private static string SerialText(AppInventoryBox b)
    {
        var serials = b.Lines.Where(l => l.HasSerial).Select(l => l.SerialNo!).ToList();
        return serials.Count switch
        {
            0 => "—",
            1 => serials[0],
            _ => $"{serials[0]} +{serials.Count - 1}",
        };
    }

    private static string Meta(AppInventoryBox b)
    {
        var parts = new List<string>();
        if (!string.IsNullOrWhiteSpace(b.LotName)) parts.Add(b.LotName!);
        if (!string.IsNullOrWhiteSpace(b.Line)) parts.Add($"Line {b.Line}");
        return string.Join(" · ", parts);
    }

    // ── Chặn xoá ─────────────────────────────────────────────

    /// <summary>Lý do không cho xoá (hiện ở chân dialog). Null = được xoá.</summary>
    private string? BlockReason =>
        _detail is not null && _selected.Count > 0 && _selected.Count >= AllBoxes.Count
            ? L["Inventory.Boxes.AllSelected"].Value
            : null;

    private bool CanDelete => !_busy && !_loading && _detail is not null && _selected.Count > 0 && BlockReason is null;

    // ── Thao tác ─────────────────────────────────────────────

    private void OnSearch(ChangeEventArgs e) => _q = e.Value?.ToString() ?? "";

    private void OnOnlyModelChanged(ChangeEventArgs e) => _onlyModel = e.Value is true;

    private void Toggle(AppInventoryBox b)
    {
        if (_busy) return;
        if (!_selected.Remove(b.Id)) _selected.Add(b.Id);
        _confirming = false;
        _error = null;
    }

    private void ToggleAllShown(ChangeEventArgs e)
    {
        if (_busy) return;
        if (e.Value is true) foreach (var b in Shown) _selected.Add(b.Id);
        else foreach (var b in Shown) _selected.Remove(b.Id);
        _confirming = false;
    }

    private void ClearSelection()
    {
        _selected.Clear();
        _confirming = false;
    }

    private async Task DeleteAsync()
    {
        if (!CanDelete || Action?.Lot is not { } lot) return;

        _busy = true;
        _error = null;
        StateHasChanged();

        var r = await Business.DeleteBoxesAsync(lot.Id, _selected.ToList());
        _busy = false;

        if (r.IsSuccess && r.Value is { } v)
        {
            await OnDone.InvokeAsync(L["Inventory.Boxes.Done",
                v.BoxesDeleted.ToString("N0"), v.QtyDeleted.ToString("N0"), v.BoxCountAfter.ToString("N0")]);
            return;
        }

        // 409: người khác vừa đổi pallet -> tải lại để chọn trên dữ liệu mới.
        _error = r.ErrorMessage ?? L["Inventory.Boxes.Failed"];
        _confirming = false;
    }

    private Task Close() => _busy ? Task.CompletedTask : OnClose.InvokeAsync();
}