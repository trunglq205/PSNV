# Mục 2c — Chỉ thị back hàng: nối dây vào source 09/11

**Giải nén lên source rồi build. KHÔNG có bước làm tay nào.**

Đó chính là chỗ lần trước vỡ: tôi gửi file feature kèm danh sách "các dòng cần
chèn tay" vào file dùng chung. Những dòng đó không được chèn (hoặc bị revert),
nên code của mục 2c tham chiếu quyền chưa tồn tại ⇒ **cả solution không build
được**, kéo theo mọi người. Lần này 6 file dùng chung nằm sẵn trong gói, đã
merge xong trên đúng bản source anh vừa gửi.

---

## 1. Tình trạng source 09/11 trước khi áp

File **feature** của mục 2c vẫn còn nguyên trong source của anh:

```
API: ReturnBackRequestModels.cs · ReturnBackRequestsController.cs
     IReturnBackRequestService.cs · ReturnBackRequestService.cs
     IReturnBackRequestRepository.cs · ReturnBackRequestRepository.cs
     ReturnBackRequestEntity.cs
Web: ReturnBackRequests.razor(.cs/.css) · IReturnBackRequestApi.cs
     IReturnBackRequestBusiness.cs · ReturnBackRequestBusiness.cs
     Business/Models/ReturnBackRequestModels.cs
```

Nhưng phần **nối dây** ở các file dùng chung thì đã bị revert về trước mục 2c.
Tôi dò bằng script, không bằng mắt — đây là danh sách đầy đủ những gì thiếu:

| Thiếu | Hậu quả |
|---|---|
| `Perms.Receiving.ReworkRefurbish.RequestBack / ApproveFa / ApproveScs / ProcessFa` | `ReturnBackRequestsController` + `ReturnFaPalletsController` tham chiếu 4 type không tồn tại ⇒ **CS0117, API không build** |
| `RequireAnyPermissionAttribute<T1, T2, T3>` | endpoint `cancel` dùng bản 3 quyền ⇒ **không build** |
| DI: `IReturnBackRequestService` · `IReturnBackRequestRepository` · `IReturnFaPalletService` | build được nhưng **chết lúc chạy** khi mở màn (không resolve được dependency) |
| Web enum `rework_refurbish_request_back / approve_fa / approve_scs` | `ReturnBackRequests.razor.cs` tham chiếu 3 member không có ⇒ **Web không build** |
| Web DI: `IReturnBackRequestApi` · `IReturnBackRequestBusiness` | **chết lúc chạy** khi mở màn |
| Menu `Nav.ReworkBack` | màn có nhưng **không có đường vào** |
| 25 khoá resx API + 43 khoá resx Web | lỗi và nhãn hiện ra **khoá thô** |

## 2. Gói này sửa đúng 14 file, không thêm không xoá file nào

### API — 3 file code

| File | Sửa ở đâu |
|---|---|
| `Features/Roles/Catalog/Perms.cs` | `ReworkRefurbish` từ 5 lá thành 9: thêm `RequestBack`, `ApproveFa`, `ApproveScs`, `ProcessFa` |
| `Features/Roles/Authorization/RequirePermissionAttribute.cs` | thêm `RequireAnyPermissionAttribute<T1, T2, T3>` |
| `Features/ReturnInstructions/ReturnInstructionModule.cs` | thêm 3 dòng `AddScoped` |

### Web — 3 file code

| File | Sửa ở đâu |
|---|---|
| `Shared/Auth/Perms.cs` | +3 enum member **và** +3 case tường minh trong `Key()` |
| `Shared/App/Model/NavModel.cs` | thêm `NavItem("Nav.ReworkBack", "rework-back", …)` |
| `Features/ReturnInstructions/ReturnInstructionModule.cs` | thêm 2 dòng đăng ký |

### resx — 8 file, **chỉ THÊM khoá**

API +25 khoá/file · Web +43 khoá/file, đồng đều cả 4 ngôn ngữ.
Tôi đã kiểm từng file: **0 khoá bị mất, 0 giá trị bị đổi.**

### SQL — 1 script

`return_back_request_schema.sql`

---

## 3. Hai chỗ tôi cố ý làm, cần anh biết

**a) Có thêm quyền `ProcessFa` — của mục 2d, không phải 2c.**
Vì file mục 2d (`ReturnFaPallet*`, 6 file) **đã nằm trong source** của anh và
chúng tham chiếu `ProcessFa`. Không thêm lá quyền đó thì API không build, nên
đây là phần tối thiểu để source biên dịch được, không phải thêm chức năng.

Nếu anh muốn **bỏ hẳn mục 2d**, xoá 6 file này:

```
API/Features/ReturnInstructions/Api/ReturnFaPalletModels.cs
API/Features/ReturnInstructions/Api/ReturnFaPalletsController.cs
API/Features/ReturnInstructions/ReturnFaPalletEntity.cs
API/Features/ReturnInstructions/Business/IReturnFaPalletService.cs
API/Features/ReturnInstructions/Business/ReturnFaPalletService.cs
API/Features/ReturnInstructions/Business/ReturnPalletRequestFactory.cs
```

rồi bỏ `ProcessFa` khỏi `Perms.cs` và bỏ dòng `AddScoped<IReturnFaPalletService…>`.
Nói tôi làm giúp cũng được, nhưng tôi không tự xoá file của anh.

**b) Mục 2d hiện KHÔNG có đường vào.** PDA trong source 09/11 đã về bản 2a sạch
(không còn file `return_fa_*`), nên các endpoint của 2d có đó mà không ai gọi.
Chúng nằm im, không ảnh hưởng gì. Chỉ lưu ý: nếu ai gọi thử bằng Postman thì sẽ
500, vì bảng `wms.return_serial_mismatches` cần script
`return_fa_pallet_schema.sql` mà gói này **không** kèm.

---

## 4. Thứ tự áp

1. **Chạy SQL** `return_back_request_schema.sql` trên DB.
   Chạy sau `return_instruction_schema.sql` → `return_receiving_schema.sql` →
   `return_actual_schema.sql`. Script tự kiểm tra, chạy lại nhiều lần không sao.
2. **Giải nén** gói này lên source (ghi đè 14 file).
3. **Build API → build Web.** Không có bước làm tay.
4. **Gán quyền** cho role — 4 bước là 4 người khác nhau:

| Role | Lá quyền cần thêm |
|---|---|
| FA | `rework_refurbish.view` + `rework_refurbish.request_back` |
| Quản lý FA | `rework_refurbish.view` + `rework_refurbish.approve_fa` |
| SCS WH | `rework_refurbish.view` + `rework_refurbish.process` (đã có) |
| Quản lý SCS | `rework_refurbish.view` + `rework_refurbish.approve_scs` |

Quyền bên API **cache 5 phút** (`IMemoryCache`, `perms:user:{userId}`) — sửa
role rồi phải chờ, đăng xuất đăng nhập lại cũng chưa chắc ra ngay.

---

## 5. Màn hình hoạt động thế nào

Menu **Chỉ thị back hàng** (`/rework-back`), gác bằng `rework_refurbish.view`:
cả bốn bên đều THẤY màn này, ai bấm được nút nào thì màn tự lọc theo
`quyền AND bước hiện tại`.

Bốn bước, mỗi bước một người:

```
B1 FA tạo yêu cầu          → req_status=fa_requested   current_step=fa_approve
B2 Quản lý FA duyệt        → fa_approved               scs_instruct
B3 SCS WH tạo chỉ thị back → scs_instructed            scs_approve
B4 Quản lý SCS duyệt       → scs_approved              done  ← serial đổi sang at_fa
```

Vài quyết định thiết kế đáng nhớ:

- **Hai cột trạng thái, không phải một**: `req_status` là *kết quả*,
  `current_step` là *việc đang chờ ai*. Gộp một cột thì không trả lời được câu
  "yêu cầu này đang nằm trên bàn ai".
- **Serial chỉ bị chọn ở B4**, không khoá trước. Yêu cầu back chỉ mang dòng
  `model + qty`; sổ serial của phiếu đã là mốc để so, không cần phiếu riêng.
- **B4 chọn FIFO** `WITH (UPDLOCK, READPAST)` theo `received_at, id`, đổi
  `status` sang `at_fa` và **xoá `pallet_id`** (hàng rời kho SCS).
  Nếu chọn được **ít hơn** số xin thì **ghi log, không throw** — hàng có thể vừa
  bị phiếu khác lấy, chặn ở đây là treo cả yêu cầu.
- **Điều kiện bước nằm TRONG câu UPDATE**, không SELECT-rồi-UPDATE: hai người
  duyệt cùng lúc thì người thứ hai cập nhật 0 dòng, không ghi đè.
- **6 tab hàng đợi**: 4 tab đầu theo `current_step`, 2 tab cuối theo
  `req_status`. Lọc ở client để con số trên tab còn đúng.

⚠ **Mục 2c chưa khai mail event nào.** Nếu cần mail ở các bước duyệt, nói tôi
thêm tab thứ 3 vào dialog bánh răng của màn Tái gia công.

---

## 6. Tôi đã kiểm những gì

Container không có .NET SDK nên **chưa build được** — tất cả là kiểm tĩnh, nhưng
lần này tôi kiểm đúng cái đã làm vỡ lần trước:

| Kiểm | Kết quả |
|---|---|
| Quét **toàn bộ API**: mọi `Perms.<Module>.<Screen>.<Action>` có tồn tại | **0 tham chiếu treo** |
| Quét **toàn bộ Web**: mọi `Perms.<x>` có trong enum | **0 tham chiếu treo** |
| Mọi interface của feature đã đăng ký DI | API 5/5 · Web 5/5 |
| `RequireAnyPermission` số tham số code dùng ⊆ số bản có | dùng {2,3} / có {2,3} |
| Enum Web có gạch dưới ⇒ có case tường minh trong `Key()` | 3/3 |
| **Gương quyền** controller ↔ nút trên màn | 6/6 khớp từng endpoint |
| Refit route ↔ route controller | **9/9 khớp**, không thừa không thiếu |
| Mọi khoá resx màn này dùng | có đủ ở **cả 4** ngôn ngữ |
| resx: 4 ngôn ngữ bằng nhau | API 745 = 745 = 745 = 745 ✔ |
| resx: chỉ thêm, không mất/không đổi giá trị cũ | **0 mất, 0 đổi** (8/8 file) |
| Số `{0}`/`{1}` khớp nhau giữa 4 ngôn ngữ | khớp |
| Cân `{}` `()` `[]` sau khi bỏ chuỗi + chú thích | 38 file, 0 lỗi |
| XML resx well-formed | 8/8 |
| CSS class màn 2c đều có định nghĩa | 40/40 |
| Business interface ↔ chỗ gọi trên màn | 8/8 |
| `@page "/rework-back"` ↔ href trong NavModel | khớp |
| Line ending + BOM từng file | **14/14 giữ nguyên CRLF/BOM như bản của anh** |
| Delta so với source anh gửi | **sửa 14, thêm 0, xoá 0** |

---

## 7. Một lỗi i18n CÓ TỪ TRƯỚC, không phải của gói này

`SharedResource.en.resx` bên Web đang **thiếu 14 khoá** mà 3 ngôn ngữ kia có —
y hệt trước và sau khi tôi sửa, nên không phải do gói này:

```
Inventory.Action.HdSync
Inventory.Cmp.Col.Locator · Col.Model · Col.QtyDiff · Col.Result
Inventory.Cmp.DetailFailed · Empty · LoadFailed · NotInHdSoft · NotInSwms
Inventory.Cmp.ShowMore · ShowingOf · Truncated
Nav.PdaLog
```

Hậu quả thật: **menu "PDA Log" hiện ra chữ `Nav.PdaLog`** khi dùng tiếng Anh, và
màn so sánh tồn kho hiện toàn khoá thô. Tôi **không** sửa vì ngoài phạm vi mục
2c — cần thì tôi làm một gói riêng.
