import 'package:freezed_annotation/freezed_annotation.dart';

import 'base_request_model.dart';

part 'returncardpmdrequestmodel.g.dart';

@JsonSerializable()
class ReturnCardPMDRequestModel extends BaseRequestModel {
  ReturnCardPMDRequestModel({
    required this.section,
    required this.material,
    required this.model,
    required this.machine,
    required this.typeCard,
    required this.statusRecycle,
    required this.sloc,
    required this.kittingCardID,
    required this.userIDInsert,

  });
  factory ReturnCardPMDRequestModel.fromJson(Map<String, dynamic> json) =>
      _$ReturnCardPMDRequestModelFromJson(json);

  final String section;
  final String material;
  final String model;
  final String machine;
  final String typeCard;
  final String statusRecycle;
  final String sloc;
  final int kittingCardID;
  final String userIDInsert;

  @override
  Map<String, dynamic> toJson() => _$ReturnCardPMDRequestModelToJson(this);
}
