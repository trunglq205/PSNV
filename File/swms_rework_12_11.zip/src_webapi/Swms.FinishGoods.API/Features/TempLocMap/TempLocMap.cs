﻿namespace Swms.FinishGoods.API.Features.TempLocMap;

/// <summary>Khu vực kho — khung lưới cho map (master.warehouse_areas).</summary>
public class WarehouseArea
{
    public long Id { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; } = 0.2m;
    public bool IsActive { get; set; } = true;
    public DateTime CreatedAt { get; set; }
    public DateTime? UpdatedAt { get; set; }
}

/// <summary>
/// Một ô trên map = 1 dòng master.locators (đã mở rộng cột toạ độ + trạng thái).
/// CellType: 'pallet' (có locator_code = mã QR) | 'zone' (khu chức năng, chỉ màu + nhãn).
/// </summary>
public class MapLocator
{
    public long Id { get; set; }                    // master.locators.id — dùng để ghép lot vào ô
    public long MapId { get; set; }                 // master.locator_map.id — id round-trip để lưu layout (keptIds/updMap)
    public string? LocatorCode { get; set; }        // 'PL14'… (pallet); mã kỹ thuật (zone)
    public long? AreaId { get; set; }
    public string CellType { get; set; } = "pallet"; // pallet | zone

    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; }
    public int GridH { get; set; }

    public string? Arrow { get; set; }              // up|down|left|right|null
    public string? Color { get; set; }              // '#E53935'… (zone)
    public string? Label { get; set; }              // nhãn zone / mô tả

    public string CurrentStatus { get; set; } = "empty"; // empty|urgent|noinsp|waiting|ok|ng|checking

    public int SortOrder { get; set; }
}

/// <summary>
/// Một lot đang nằm trên 1 pallet (locator). 1 pallet có thể chứa nhiều lot.
/// Dữ liệu từ wms.pallets (liên kết qua locator_id) + model gộp từ box_lines.
/// </summary>
public class PalletLot
{
    public long LotId { get; set; }
    public long LocatorId { get; set; }
    public string LotNo { get; set; } = string.Empty;
    public string InspectionStatus { get; set; } = string.Empty; // giá trị thô từ wms.pallets
    public bool IsUrgent { get; set; }
    public int? BoxCount { get; set; }
    public DateTime? ProductionDate { get; set; }
    public string? Models { get; set; }   // các model trong lot (gộp, phân tách bằng ", ")

    /// <summary>
    /// rework | refurbish | null (hàng thường) — vẽ dấu RW/RB cạnh Pallet ID.
    /// Lùi về <c>return_instructions.goods_type</c> khi cột chưa có dấu.
    /// </summary>
    public string? Disposition { get; set; }
}

/// <summary>Vị trí + khu chứa nó + các pallet đang nằm tại đó.</summary>
public class LocatorOccupancy
{
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = string.Empty;
    public string? AreaCode { get; set; }
    public string? AreaName { get; set; }
    public string? MapType { get; set; }          // receiving | storing | vanning
    public List<string> Pallets { get; set; } = new();
}