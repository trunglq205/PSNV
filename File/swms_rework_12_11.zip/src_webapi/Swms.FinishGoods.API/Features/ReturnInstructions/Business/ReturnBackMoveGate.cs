using System.Data;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

/// <summary>
/// Hiện thực cổng chặn đưa hàng tái gia công ra khu Nhận hàng.
///
/// Interface khai ở slice Pallets (<see cref="IReturnBackMoveGate"/>) chứ không
/// ở đây: chiều phụ thuộc giữa hai slice là ReturnInstructions → Pallets, cho
/// PalletService gọi thẳng vào slice này là thành vòng.
///
/// Quy tắc nghiệp vụ nó canh (chốt 11/11): quản lý SCS duyệt rồi thì hàng mới
/// được out kho sang vị trí nhận hàng; chưa duyệt thì chỉ chuyển nội bộ trong
/// kho. Và chính việc đặt pallet vào vị trí nhận hàng là hành động giao cho FA
/// — không có API giao hàng nào khác nữa, nên không có đường nào lọt cổng này.
/// </summary>
public class ReturnBackMoveGate : IReturnBackMoveGate
{
    private readonly IReturnBackFlowRepository _repo;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public ReturnBackMoveGate(
        IReturnBackFlowRepository repo,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _localizer = localizer;
    }

    public async Task<ReturnBackMove?> CheckDeliverableAsync(long palletId)
    {
        var target = await _repo.FindDeliverableByPalletAsync(palletId);

        // Pallet không giữ hàng chờ giao của phiếu nào: chuyển vị trí trong khu
        // nhận hàng là việc bình thường, không dính nghiệp vụ back hàng.
        if (target is null || target.ReceivedQty <= 0) return null;

        // Chưa qua quản lý SCS -> chặn, và nói rõ là vẫn chuyển nội bộ được:
        // người đứng quét PDA không phải người bấm duyệt, câu "không được chuyển"
        // trơ trọi sẽ thành một cuộc gọi điện lên office.
        if (target.BackStatus != ReturnBackStatus.ScsApproved)
            throw new BusinessRuleException(
                _localizer["Return.Back.Err.MoveNeedScsApprove", target.DocNo]);

        return new ReturnBackMove(target.DocId, target.DocNo, target.ReceivedQty);
    }

    public async Task MarkDeliveredAsync(
        IDbConnection conn,
        IDbTransaction tx,
        ReturnBackMove move,
        long palletId,
        string lotNo,
        string? user)
    {
        var result = await _repo.DeliverOnMoveAsync(
            conn, tx, move.DocId, palletId, lotNo, user);

        // Ném TRONG transaction đổi vị trí = pallet không bị chuyển. Đây là chỗ
        // duy nhất chặn được cú đua "quản lý SCS huỷ duyệt đúng lúc WH đang đẩy
        // pallet ra khu nhận hàng".
        if (result.DocGone)
            throw new ConflictException(
                _localizer["Return.Back.Err.MoveDocGone", move.DocNo]);

        if (result.WrongStep)
            throw new ConflictException(
                _localizer["Return.Back.Err.MoveNeedScsApprove", move.DocNo]);

        // Pallet nhiều hơn SL lần đề nghị này còn cần -> KHÔNG cho ra khu nhận
        // hàng (chốt 12/11). Phải tách pallet cho khớp rồi giao.
        //
        // Vì sao không cắt bớt cho vừa: pallet ra khu nhận hàng là ra khỏi kho
        // CẢ CON LẪN THÙNG. Đánh 20 con sang at_fa rồi để 480 con ở trạng thái
        // 'received' là sổ nói còn 480 con trong kho trong khi chúng đang ở
        // trên xe sang FA.
        //
        // Thông báo phải có đủ ba số: model nào, pallet đang có bao nhiêu, lần
        // này còn cần bao nhiêu — thiếu một số là người quét không biết phải
        // tách ra bao nhiêu.
        if (result.TooMany)
            throw new BusinessRuleException(_localizer[
                "Return.Back.Err.MovePalletTooMany",
                result.TooManyOnPallet,
                result.TooManyModel ?? "?",
                result.TooManyNeed,
                move.DocNo]);

        // KHÔNG gửi mail ở đây: nghiệp vụ đã bỏ lá mail xác nhận giao hàng
        // (chốt 10/11) vì cổng duyệt của quản lý SCS đã thay vai trò đó.
    }
}
