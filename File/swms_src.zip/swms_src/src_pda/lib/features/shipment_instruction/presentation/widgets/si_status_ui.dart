import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/widgets.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

/// Map trạng thái SI → nhãn đã dịch / tông [StatusPill].
/// Đặt ở presentation vì cần LocaleKeys + context (domain không phụ thuộc UI).
extension SiStatusUi on SiStatus? {
  /// Key lạ (null) → hiện nguyên key server trả.
  String label([String? rawKey]) => switch (this) {
    SiStatus.released => LocaleKeys.shipment_instruction_status_released.tr(),
    SiStatus.picking => LocaleKeys.shipment_instruction_status_picking.tr(),
    SiStatus.completed => LocaleKeys.shipment_instruction_status_completed.tr(),
    SiStatus.cancelled => LocaleKeys.shipment_instruction_status_cancelled.tr(),
    null => siOrDash(rawKey),
  };

  StatusPill pill(BuildContext context, {String? rawKey}) {
    final text = label(rawKey);
    return switch (this) {
      SiStatus.released => StatusPill.info(context, label: text),
      SiStatus.picking => StatusPill.warning(context, label: text),
      SiStatus.completed => StatusPill.success(context, label: text),
      SiStatus.cancelled || null => StatusPill.neutral(context, label: text),
    };
  }
}