﻿namespace Swms.FinishGoods.Web.Features.TempLocMap.Business.Models;

// Khớp với response/request của API (Swms.FinishGoods.API/Features/TempLocMap).

public class MapCellDto
{
    public long Id { get; set; }
    public string? Code { get; set; }
    public string CellType { get; set; } = "pallet";
    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; }
    public int GridH { get; set; }
    public string? Arrow { get; set; }
    public string? Color { get; set; }
    public string? Label { get; set; }
    public string Status { get; set; } = "empty";
    public string? Model { get; set; }
    public string? LotNo { get; set; }
    public int SortOrder { get; set; }
    public List<LotInfoDto>? Lots { get; set; }
    public bool IsUrgent { get; set; }
}

public class LotInfoDto
{
    public long LotId { get; set; }
    public string LotNo { get; set; } = string.Empty;
    public string InspectionStatus { get; set; } = string.Empty;
    public string MappedStatus { get; set; } = string.Empty;
    public bool IsUrgent { get; set; }
    public int? BoxCount { get; set; }
    public string? Models { get; set; }
    public DateTime? ProductionDate { get; set; }

    /// <summary>rework | refurbish | null — dấu RW/RB cạnh Pallet ID.</summary>
    public string? Disposition { get; set; }
}

public class MapLayoutDto
{
    public long AreaId { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public List<MapCellDto> Cells { get; set; } = new();
}

public class AreaSummaryDto
{
    public long Id { get; set; }
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public bool IsActive { get; set; }
}

// ---------- request ----------

public class SaveCellDto
{
    public long? Id { get; set; }
    public string? Code { get; set; }
    public string CellType { get; set; } = "pallet";
    public int GridX { get; set; }
    public int GridY { get; set; }
    public int GridW { get; set; }
    public int GridH { get; set; }
    public string? Arrow { get; set; }
    public string? Color { get; set; }
    public string? Label { get; set; }
    public string? Status { get; set; }
    public string? Model { get; set; }
    public string? LotNo { get; set; }
    public int SortOrder { get; set; }
}

public class SaveLayoutDto
{
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
    public List<SaveCellDto> Cells { get; set; } = new();
}

public class ChangeStatusDto
{
    public string Status { get; set; } = "empty";
    public string? Model { get; set; }
    public string? LotNo { get; set; }
}

public class CreateAreaDto
{
    public string AreaCode { get; set; } = string.Empty;
    public string AreaName { get; set; } = string.Empty;
    public int Cols { get; set; }
    public int Rows { get; set; }
    public decimal CellMeters { get; set; }
}