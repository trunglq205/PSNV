﻿namespace SWMS_WebTool.Models.Layout
{
    public class RobotLine : Widget
    {
        public RobotLine() { }
        public RobotLine(KonvaObject konvaObject) : base(konvaObject)
        {
            Data = konvaObject.Attrs.Data ?? "";
        }
        public override WidgetType Type => WidgetType.RobotLine;
        protected override KonvaClassType ClassName => KonvaClassType.Path;

        public string Data { get; set; }

        protected override KonvaAttr ToKonvaAttr()
        {
            var attrs = base.ToKonvaAttr();
            attrs.Data = Data;
            return attrs;
        }
    }
}
