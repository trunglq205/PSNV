// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_fa_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReturnSerialIndexModel _$ReturnSerialIndexModelFromJson(
  Map<String, dynamic> json,
) => ReturnSerialIndexModel(
  serial: json['serial'] as String,
  model: json['model'] as String,
  status: json['status'] as String,
);

Map<String, dynamic> _$FaPalletBoxRequestModelToJson(
  FaPalletBoxRequestModel instance,
) => <String, dynamic>{
  'boxNo': ?instance.boxNo,
  'serials': instance.serials,
};

Map<String, dynamic> _$CreateFaPalletRequestModelToJson(
  CreateFaPalletRequestModel instance,
) => <String, dynamic>{'boxes': instance.boxes};

CreateFaPalletResponseModel _$CreateFaPalletResponseModelFromJson(
  Map<String, dynamic> json,
) => CreateFaPalletResponseModel(
  palletId: (json['palletId'] as num).toInt(),
  lotNo: json['lotNo'] as String,
  categoryCode: (json['categoryCode'] as num?)?.toInt() ?? 0,
  boxCount: (json['boxCount'] as num?)?.toInt() ?? 0,
  serialCount: (json['serialCount'] as num?)?.toInt() ?? 0,
  mismatchCount: (json['mismatchCount'] as num?)?.toInt() ?? 0,
  doc: ReturnInstructionModel.fromJson(json['doc'] as Map<String, dynamic>),
);

Map<String, dynamic> _$ReceiveBackRequestModelToJson(
  ReceiveBackRequestModel instance,
) => <String, dynamic>{'lotNo': instance.lotNo};

ReceiveBackResponseModel _$ReceiveBackResponseModelFromJson(
  Map<String, dynamic> json,
) => ReceiveBackResponseModel(
  lotNo: json['lotNo'] as String,
  received: (json['received'] as num?)?.toInt() ?? 0,
  skipped: (json['skipped'] as num?)?.toInt() ?? 0,
  doc: ReturnInstructionModel.fromJson(json['doc'] as Map<String, dynamic>),
);
