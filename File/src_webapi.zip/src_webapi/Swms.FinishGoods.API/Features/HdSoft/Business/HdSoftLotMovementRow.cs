namespace Swms.FinishGoods.API.Features.HdSoft.Business
{
    public record HdSoftLotMovementRow(
        DateTime MovementDate,
        DateTime MovementTime,
        string MovementType,
        decimal MovementQty,
        string Model,
        string Locator,
        string? InOutDocumentNo,    // phiếu nhập/xuất
        string? MovementDocumentNo  // phiếu chuyển kho
    );

    public record HdSoftPalletStockRow(
        string PalletNo,          // asi.Lot
        string Model,             // p.Value
        string Locator,           // l.Value
        string Warehouse,         // w.Value
        decimal QtyOnHand,        // so.QtyOnHand
        DateTime? DateIn          // so.DateMaterialPolicy (ngày nhập kho)
    );

    public record HdSoftLastMovementRow(
        string PalletNo,
        string MovementType,
        string Locator,
        DateTime MovementTime,
        decimal? UpdateBy
    );
}
