using Dapper;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.DataAccess;

public class ShipmentTripRepository : IShipmentTripRepository
{
    private readonly IDbConnectionFactory _factory;

    public ShipmentTripRepository(IDbConnectionFactory factory)
    {
        _factory = factory;
    }

    private const string TripColumns = """
        t.id AS Id, t.trip_no AS TripNo, t.vehicle_type AS VehicleType, t.plate_no AS PlateNo,
        t.container_no AS ContainerNo, t.container_size AS ContainerSize, t.seal_no AS SealNo,
        t.driver_name AS DriverName, t.driver_phone AS DriverPhone,
        t.driver_id_type AS DriverIdType, t.driver_id_no AS DriverIdNo, t.driver_license_no AS DriverLicenseNo,
        t.forwarder_code AS ForwarderCode, t.planned_arrival_at AS PlannedArrivalAt,
        t.status AS Status,
        t.arrived_at AS ArrivedAt, t.arrived_by AS ArrivedBy,
        t.sealed_at AS SealedAt, t.sealed_by AS SealedBy,
        t.departed_at AS DepartedAt, t.departed_by AS DepartedBy,
        t.cancelled_at AS CancelledAt, t.cancelled_by AS CancelledBy, t.cancel_reason AS CancelReason,
        t.note AS Note,
        t.created_at AS CreatedAt, t.created_by AS CreatedBy, t.updated_at AS UpdatedAt, t.updated_by AS UpdatedBy
        """;

    // ═══════════════════════════════════════════════════════════════
    //  Đọc
    // ═══════════════════════════════════════════════════════════════

    public async Task<List<TripRow>> GetListAsync(DateTime? from, DateTime? toExclusive, string? status, string? q, int max)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT TOP (@max) {TripColumns}
            FROM wms.shipment_trips t
            WHERE t.is_deleted = 0
              AND (@status IS NULL OR t.status = @status)
              AND (@from IS NULL
                   OR (t.planned_arrival_at >= @from AND t.planned_arrival_at < @toExclusive)
                   OR EXISTS (SELECT 1
                              FROM wms.shipment_trip_sis ts
                              JOIN wms.shipment_instructions s ON s.id = ts.si_id
                              WHERE ts.trip_id = t.id
                                AND COALESCE(s.vanning_date, s.etd_date) >= @from
                                AND COALESCE(s.vanning_date, s.etd_date) <  @toExclusive))
              AND (@q IS NULL
                   OR t.trip_no LIKE N'%' + @q + N'%'
                   OR t.plate_no LIKE N'%' + @q + N'%'
                   OR t.container_no LIKE N'%' + @q + N'%'
                   OR t.seal_no LIKE N'%' + @q + N'%'
                   OR t.driver_name LIKE N'%' + @q + N'%'
                   OR EXISTS (SELECT 1
                              FROM wms.shipment_trip_sis ts
                              JOIN wms.shipment_instructions s ON s.id = ts.si_id
                              WHERE ts.trip_id = t.id AND s.si_no LIKE N'%' + @q + N'%'))
            ORDER BY CASE WHEN t.planned_arrival_at IS NULL THEN 1 ELSE 0 END,
                     t.planned_arrival_at, t.id DESC;
            """;
        return (await conn.QueryAsync<TripRow>(sql, new { max, status, from, toExclusive, q })).ToList();
    }

    public async Task<TripRow?> GetAsync(long id)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<TripRow>(
            $"SELECT {TripColumns} FROM wms.shipment_trips t WHERE t.id = @id AND t.is_deleted = 0;", new { id });
    }

    public async Task<List<TripRow>> GetByIdsAsync(IReadOnlyCollection<long> ids)
    {
        if (ids.Count == 0) return new();
        using var conn = _factory.Create();
        return (await conn.QueryAsync<TripRow>($"""
            SELECT {TripColumns} FROM wms.shipment_trips t
            WHERE t.id IN @ids AND t.is_deleted = 0
            ORDER BY t.id;
            """, new { ids })).ToList();
    }

    public async Task<List<long>> GetIdsBySiAsync(long siId)
    {
        using var conn = _factory.Create();
        return (await conn.QueryAsync<long>("""
            SELECT t.id
            FROM wms.shipment_trips t
            JOIN wms.shipment_trip_sis ts ON ts.trip_id = t.id
            WHERE ts.si_id = @siId AND t.is_deleted = 0
            ORDER BY t.id;
            """, new { siId })).ToList();
    }

    /*  SiPltTotal      = tổng package_plt các dòng SI
        SiPltPlannedAll = tổng plt_planned của SI trên mọi chuyến chưa huỷ / chưa xoá
                          (để báo "các xe đang chở 8/10 pallet").                      */
    public async Task<List<TripSiRow>> GetSisByTripIdsAsync(IReadOnlyCollection<long> tripIds)
    {
        if (tripIds.Count == 0) return new();
        using var conn = _factory.Create();
        const string sql = """
            SELECT ts.trip_id AS TripId, s.id AS SiId, s.si_no AS SiNo, s.doc_no AS DocNo,
                   s.doc_status AS DocStatus, s.ship_mode AS ShipMode,
                   COALESCE(s.vanning_date, s.etd_date) AS VanningDate,
                   ts.plt_planned AS PltPlanned,
                   ISNULL(p.plt, 0) AS SiPltTotal,
                   ISNULL(a.plt, 0) AS SiPltPlannedAll
            FROM wms.shipment_trip_sis ts
            JOIN wms.shipment_instructions s ON s.id = ts.si_id
            OUTER APPLY (SELECT SUM(ISNULL(l.package_plt, 0)) AS plt
                         FROM wms.shipment_instruction_lines l
                         WHERE l.si_id = s.id) p
            OUTER APPLY (SELECT SUM(ISNULL(x.plt_planned, 0)) AS plt
                         FROM wms.shipment_trip_sis x
                         JOIN wms.shipment_trips tt ON tt.id = x.trip_id
                         WHERE x.si_id = s.id AND tt.is_deleted = 0 AND tt.status <> N'cancelled') a
            WHERE ts.trip_id IN @tripIds
            ORDER BY ts.trip_id, s.si_no;
            """;
        return (await conn.QueryAsync<TripSiRow>(sql, new { tripIds })).ToList();
    }

    // ═══════════════════════════════════════════════════════════════
    //  Kiểm tra
    // ═══════════════════════════════════════════════════════════════

    public async Task<List<SiLinkInfo>> GetSiInfosAsync(IReadOnlyCollection<long> siIds)
    {
        if (siIds.Count == 0) return new();
        using var conn = _factory.Create();
        return (await conn.QueryAsync<SiLinkInfo>("""
            SELECT id AS SiId, si_no AS SiNo, doc_status AS DocStatus
            FROM wms.shipment_instructions
            WHERE id IN @siIds AND is_deleted = 0;
            """, new { siIds })).ToList();
    }

    // Chuyến đã xuất cổng vẫn tính: SI đã đi container thì không gắn thêm xe / container khác.
    public async Task<List<SiActiveTrip>> GetActiveTripsOfSisAsync(IReadOnlyCollection<long> siIds, long? excludeTripId)
    {
        if (siIds.Count == 0) return new();
        using var conn = _factory.Create();
        return (await conn.QueryAsync<SiActiveTrip>("""
            SELECT ts.si_id AS SiId, t.id AS TripId, t.vehicle_type AS VehicleType, t.status AS Status
            FROM wms.shipment_trip_sis ts
            JOIN wms.shipment_trips t ON t.id = ts.trip_id
            WHERE ts.si_id IN @siIds
              AND t.is_deleted = 0 AND t.status <> N'cancelled'
              AND (@excludeTripId IS NULL OR t.id <> @excludeTripId);
            """, new { siIds, excludeTripId })).ToList();
    }

    // Cùng điều kiện với UX_trips_active_container
    public async Task<bool> ContainerInUseAsync(string containerNo, long? excludeTripId)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<int>("""
            SELECT COUNT(1) FROM wms.shipment_trips
            WHERE container_no = @containerNo AND is_deleted = 0
              AND status <> N'departed' AND status <> N'cancelled'
              AND (@excludeTripId IS NULL OR id <> @excludeTripId);
            """, new { containerNo, excludeTripId }) > 0;
    }

    // ═══════════════════════════════════════════════════════════════
    //  Ghi
    // ═══════════════════════════════════════════════════════════════

    private const string InsertSiSql = """
        INSERT INTO wms.shipment_trip_sis (trip_id, si_id, plt_planned, created_at, created_by)
        VALUES (@TripId, @SiId, @PltPlanned, SYSDATETIME(), @Actor);
        """;

    public async Task<long> AddAsync(TripRow t, IReadOnlyList<TripSiLink> sis)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        // Ngày trong mã chuyến = ngày vanning sớm nhất của SI (không có thì ETD, không có SI thì ngày tạo)
        var siIds = sis.Select(s => s.SiId).ToList();
        var vanning = siIds.Count == 0 ? null : await conn.ExecuteScalarAsync<DateTime?>(
            "SELECT MIN(COALESCE(vanning_date, etd_date)) FROM wms.shipment_instructions WHERE id IN @siIds",
            new { siIds }, tx);

        var p = new DynamicParameters(t);
        p.Add("NoDate", (vanning ?? t.CreatedAt).Date);

        const string sql = """
            -- Mã chuyến TR{yyMMdd vanning}-{stt trong ngày}; khoá để 2 người tạo cùng lúc không trùng
            DECLARE @prefix nvarchar(10) = N'TR' + CONVERT(nchar(6), @NoDate, 12) + N'-';
            DECLARE @seq int = 1 + ISNULL((SELECT MAX(TRY_CAST(SUBSTRING(trip_no, LEN(@prefix) + 1, 10) AS int))
                                           FROM wms.shipment_trips WITH (UPDLOCK, HOLDLOCK)
                                           WHERE trip_no LIKE @prefix + N'%'), 0);
            DECLARE @newTripNo nvarchar(20) = @prefix
                + CASE WHEN @seq < 1000 THEN RIGHT(N'000' + CAST(@seq AS nvarchar(10)), 3) ELSE CAST(@seq AS nvarchar(10)) END;

            INSERT INTO wms.shipment_trips
                (trip_no, vehicle_type, plate_no, container_no, container_size, seal_no,
                 driver_name, driver_phone, driver_id_type, driver_id_no, driver_license_no,
                 forwarder_code, planned_arrival_at, status, note, is_deleted, created_at, created_by)
            VALUES
                (@newTripNo, @VehicleType, @PlateNo, @ContainerNo, @ContainerSize, @SealNo,
                 @DriverName, @DriverPhone, @DriverIdType, @DriverIdNo, @DriverLicenseNo,
                 @ForwarderCode, @PlannedArrivalAt, N'planned', @Note, 0, @CreatedAt, @CreatedBy);
            SELECT CAST(SCOPE_IDENTITY() AS bigint);
            """;
        var id = await conn.ExecuteScalarAsync<long>(sql, p, tx);

        foreach (var s in sis)
            await conn.ExecuteAsync(InsertSiSql, new { TripId = id, s.SiId, s.PltPlanned, Actor = t.CreatedBy }, tx);

        tx.Commit();
        return id;
    }

    public async Task<bool> UpdateAsync(TripRow t, IReadOnlyList<TripSiLink>? sis)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();

        const string sql = """
            UPDATE wms.shipment_trips
            SET vehicle_type = @VehicleType, plate_no = @PlateNo,
                container_no = @ContainerNo, container_size = @ContainerSize, seal_no = @SealNo,
                driver_name = @DriverName, driver_phone = @DriverPhone,
                driver_id_type = @DriverIdType, driver_id_no = @DriverIdNo, driver_license_no = @DriverLicenseNo,
                forwarder_code = @ForwarderCode, planned_arrival_at = @PlannedArrivalAt, note = @Note,
                updated_at = @UpdatedAt, updated_by = @UpdatedBy
            WHERE id = @Id AND is_deleted = 0 AND status NOT IN (N'departed', N'cancelled');
            """;
        if (await conn.ExecuteAsync(sql, t, tx) == 0)
        {
            tx.Rollback();
            return false;
        }

        if (sis is not null)
        {
            await conn.ExecuteAsync("DELETE FROM wms.shipment_trip_sis WHERE trip_id = @Id;", new { t.Id }, tx);
            foreach (var s in sis)
                await conn.ExecuteAsync(InsertSiSql, new { TripId = t.Id, s.SiId, s.PltPlanned, Actor = t.UpdatedBy }, tx);
        }

        tx.Commit();
        return true;
    }

    // Điều kiện trạng thái cũ nằm trong WHERE: 2 người bấm cùng lúc không ghi đè nhau.
    public async Task<bool> TransitionAsync(long id, IReadOnlyCollection<string> from, string to, string? reason, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.shipment_trips
            SET status        = @to,
                arrived_at    = CASE WHEN @to = N'arrived'   THEN SYSDATETIME() ELSE arrived_at   END,
                arrived_by    = CASE WHEN @to = N'arrived'   THEN @actor        ELSE arrived_by   END,
                sealed_at     = CASE WHEN @to = N'sealed'    THEN SYSDATETIME() ELSE sealed_at    END,
                sealed_by     = CASE WHEN @to = N'sealed'    THEN @actor        ELSE sealed_by    END,
                departed_at   = CASE WHEN @to = N'departed'  THEN SYSDATETIME() ELSE departed_at  END,
                departed_by   = CASE WHEN @to = N'departed'  THEN @actor        ELSE departed_by  END,
                cancelled_at  = CASE WHEN @to = N'cancelled' THEN SYSDATETIME() ELSE cancelled_at END,
                cancelled_by  = CASE WHEN @to = N'cancelled' THEN @actor        ELSE cancelled_by END,
                cancel_reason = CASE WHEN @to = N'cancelled' THEN @reason       ELSE cancel_reason END,
                updated_at    = SYSDATETIME(),
                updated_by    = @actor
            WHERE id = @id AND is_deleted = 0 AND status IN @from;
            """;
        return await conn.ExecuteAsync(sql, new { id, from, to, reason, actor }) > 0;
    }

    public async Task<bool> SoftDeleteAsync(long id, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE wms.shipment_trips
            SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @actor
            WHERE id = @id AND is_deleted = 0 AND status = N'planned';
            """;
        return await conn.ExecuteAsync(sql, new { id, actor }) > 0;
    }
}