using Swms.FinishGoods.API.Features.ReturnInstructions.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

/// <summary>
/// Sổ yêu cầu back hàng (mục 2c). Tách interface riêng khỏi
/// <see cref="IReturnInstructionRepository"/> cho khỏi phình, nhưng CÙNG slice
/// vì cả hai đọc ghi <c>wms.return_instruction_serials</c> — sổ serial phải có
/// MỘT chủ, không để hai slice cùng sửa trạng thái serial.
/// </summary>
public interface IReturnBackRequestRepository
{
    Task<IReadOnlyList<ReturnBackRequest>> GetListAsync(BackRequestQuery query);

    Task<ReturnBackRequest?> GetByIdAsync(long id);

    /// <summary>Tạo yêu cầu + dòng trong một transaction. Trả id.</summary>
    Task<long> AddAsync(ReturnBackRequest req, string? user);

    /// <summary>Thay toàn bộ dòng của yêu cầu (xoá mềm cũ, chèn mới).</summary>
    Task UpdateLinesAsync(long id, string? note, IReadOnlyList<ReturnBackRequestLine> lines, string? user);

    /// <summary>
    /// Chuyển bước. Điều kiện bước hiện tại nằm TRONG câu UPDATE, không kiểm
    /// trước rồi mới ghi: hai người bấm duyệt cùng lúc thì người sau phải
    /// không ăn gì, chứ không phải cả hai cùng ghi.
    /// </summary>
    /// <returns><c>false</c> khi không có dòng nào khớp (ai đó đã đi trước).</returns>
    Task<bool> ApplyStepAsync(
        long id, string fromStep, string toStep, string toStatus,
        string actorColumnPrefix, string? comment, string? user);

    Task<bool> CancelAsync(long id, string? reason, string? user);

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA.
    ///
    /// GIAO THEO PALLET: với mỗi mã pallet, chuyển MỌI serial của phiếu đang
    /// <c>received</c> nằm trên pallet đó sang <c>at_fa</c>, đóng dấu
    /// <c>back_request_id</c> + <c>sent_fa_at</c>, và ghi một dòng nhật ký vào
    /// <c>wms.return_back_deliveries</c>.
    ///
    /// KHÔNG gắp FIFO theo số lượng như bản 4 bước cũ: đã đề nghị lấy về là lấy
    /// hết, nên hàng đi theo cả pallet.
    ///
    /// KHÔNG xoá <c>pallet_id</c>: nó là thứ duy nhất nói con serial vừa đi ra
    /// trên pallet nào. Đến mục 2d, khi FA đóng lại pallet mới,
    /// <c>AttachFaPalletAsync</c> sẽ ghi đè con trỏ đó.
    ///
    /// Cả lượt nằm trong MỘT transaction: quét 5 pallet mà cái thứ 4 lỗi thì
    /// không được để 3 cái đã chuyển còn 2 cái thì không.
    /// </summary>
    Task<ReturnBackDeliverResult> DeliverPalletsAsync(
        long id, IReadOnlyList<string> lotNos, string? comment, string? user);

    /// <summary>Nhật ký pallet đã giao của một đề nghị, mới nhất trước.</summary>
    Task<IReadOnlyList<ReturnBackDelivery>> GetDeliveriesAsync(long requestId);

    /// <summary>SL còn gắp được theo model của một chỉ thị.</summary>
    Task<IReadOnlyList<BackAvailableModelResponse>> GetAvailableAsync(long docId);
}
