using Swms.FinishGoods.Web.Features.PartCard.Business.Models;

namespace Swms.FinishGoods.Web.Features.PartCard.App.Pages;

// Đánh dấu + lịch sử sửa / tách / gộp.
//
//   • Badge cạnh model: phiếu sinh ra từ tách / gộp → "Tách" / "Gộp"; có sửa → "Sửa ×n".
//     Dữ liệu tóm tắt đi kèm API danh sách (Changes) — không gọi thêm gì khi vẽ bảng.
//   • Bấm badge → GET /api/part-cards/{id}/lineage → dialog lịch sử 2 chiều.
public partial class PartCardHistory
{
    private AppPartCardHistory? _lineageCard;     // khác null = dialog đang mở
    private PartCardLineageDto? _lineage;
    private bool _lineageLoading;

    private async Task OpenLineage(AppPartCardHistory p)
    {
        _lineageCard = p;
        _lineage = null;
        _lineageLoading = true;
        StateHasChanged();
        try
        {
            var r = await Business.GetLineageAsync(p.Id);
            // Người dùng đã đóng / mở phiếu khác trong lúc chờ → bỏ kết quả cũ.
            if (_lineageCard?.Id != p.Id) return;
            if (!r.IsSuccess || r.Value is null)
            {
                Toast.Error(r.ErrorMessage ?? L["PartCardHistory.Lineage.LoadFailed"]);
                _lineageCard = null;
                return;
            }
            _lineage = r.Value;
        }
        finally { _lineageLoading = false; }
    }

    private void CloseLineage()
    {
        _lineageCard = null;
        _lineage = null;
    }

    // "Tách" | "Gộp" | "Sửa ×2" | "Tách · Sửa ×1"
    private string ChangeBadge(AppPartCardHistory p)
    {
        var parts = new List<string>(2);
        if (p.CreatedFrom is { } from) parts.Add(ActionText(from));
        if (p.EditCount > 0) parts.Add($"{L["PartCardHistory.Change.Edit"]} ×{p.EditCount}");
        return string.Join(" · ", parts);
    }

    private static string ChangeClass(AppPartCardHistory p)
        => p.CreatedFrom is not null ? "ph-chg-derived" : "";

    // Tooltip: "Thay đổi gần nhất: {giờ} — bấm để xem lịch sử"
    private string ChangeTitle(AppPartCardHistory p)
        => L["PartCardHistory.Change.Title", p.LastChangedAt];

    private string ActionText(string action) => action switch
    {
        "split" => L["PartCardHistory.Change.Split"],
        "merge" => L["PartCardHistory.Change.Merge"],
        "edit" => L["PartCardHistory.Change.Edit"],
        _ => action,
    };
}
