﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Microsoft.VisualBasic;
namespace DectShrinkV2
{
    public partial class frmShrink : Form
    {
        String employee_id, model, extension, s_pallet;
        WebService objService = new WebService();
        ConnectSQL objConnect = new ConnectSQL();
        Bussiness _obj = new Bussiness();

        public frmShrink(String id, String model, String extension, String sPalletNo, string Category)
        {

            InitializeComponent();
            this.employee_id = id;
            this.model = model;
            this.extension = extension;
            this.s_pallet = sPalletNo;
            txtPallet.Text = s_pallet;
            txtExtension.Text = extension;
            lblCategory.Text = Category;
            txtByHand.Text = model; this.KeyPreview = true;
            //txtQuantyStanddard.Text = totalBefore();
            txtPallet.Text = sPalletNo;
            string dt = sPalletNo.Substring(3, 6);
            string year = dt.Substring(0, 2);
            string month = dt.Substring(2, 2);
            string day = (dt.Substring(4, 2));

            string tt = sPalletNo.Substring(9, 3);
            lblYear.Text = "20" + year + "-" + month + "-" + day;

            lblSTT.Text = tt;
            txtQuantyStanddard.Text = totalBefore();

            object countFromPLT = objConnect.GetExcuteScalar("select count(*) from tblPalletCombine_" + lblCategory.Text.Trim() + " where [Status] <>88 and  Source_pallet='" + s_pallet + "'");
            if (countFromPLT != null)
            {
                txtScanned.Text = countFromPLT.ToString();
            }
            string mysql2 = "insert into  tblPalletCombine_DECT(sModelNo,sSerialNo,Source_pallet,dShrinkDate,dShrinkBy,sCategoryID) values ('" + txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim() + "','" + txtSerial.Text.Trim() + "','" + txtPallet.Text.Trim() + "'," + "GETDATE(),'" + employee_id + "',0)" +
                                              "update TBLPRODUCT_DECT set bShrinked =1 where STR_PROCESS_FACTORY = '" + txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim() + "' " + "and STR_SERIAL = '" + txtSerial.Text.Trim() + "'";


        }
        public string totalBefore()
        {
            return objService.count_model(txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim());
        }

        private void txtRescan_TextChanged(object sender, EventArgs e)
        {
            if (txtRescan.Text.Trim().Contains('%'))
            {
                txtRescan.Text = txtRescan.Text.Replace('%', ' ');
                txtRescan.Text = txtRescan.Text.Trim().ToUpper();
            }
            if (txtRescan.Text.Trim().Contains('*'))
            {
                txtRescan.Text = txtRescan.Text.Replace('*', ' ');
                txtRescan.Text = txtRescan.Text.Trim().ToUpper();
            }
        }

        private void txtSerial_TextChanged(object sender, EventArgs e)
        {
            if (chk_Outer_carton.Checked == false)
            {
                if (txtSerial.Text.Trim().Contains('%'))
                {
                    txtSerial.Text = txtSerial.Text.Replace('%', ' ');
                    txtSerial.Text = txtSerial.Text.Trim().ToUpper();
                }
                if (txtSerial.Text.Trim().Contains('*'))
                {
                    txtSerial.Text = txtSerial.Text.Replace('*', ' ');
                    txtSerial.Text = txtSerial.Text.Trim().ToUpper();
                }
            }
        }

        private void txtByHand_TextChanged(object sender, EventArgs e)
        {
            if (txtByHand.Text.Trim().Contains('%'))
            {
                txtByHand.Text = txtByHand.Text.Replace('%', ' ');
                txtByHand.Text = txtByHand.Text.Trim().ToUpper();
            }
            if (txtByHand.Text.Trim().Contains('*'))
            {
                txtByHand.Text = txtByHand.Text.Replace('*', ' ');
                txtByHand.Text = txtByHand.Text.Trim().ToUpper();
            }
        }

        private void btnResetText_Click_1(object sender, EventArgs e)
        {
            txtRescan.Text = "";
            txtSerial.Text = "";
            txtRescan.Focus();
        }
        public string STATUS = "";

        //design listview
        private void Design_list()
        {
            //SET LV PROPIETIES
            listView1.View = View.Details;
            listView1.FullRowSelect = true;

            //ADD COLUMNS
            listView1.Columns.Add("Serial", 200);
            listView1.Columns.Add("Status", 150);



            //display serialouter


            //listView1.Columns.Add("SerialOuter", 450);

        }
        //ADD ROW
        private void add_list(string Serial, string Status)
        {
            //ARRAY TO REP A ROW
            String[] row = { Serial, Status };

            ListViewItem item = new ListViewItem(row);

            //ADD ITEMS
            listView1.Items.Add(item);
        }

        private void txtSerial_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (chk_Outer_carton.Checked == false && lblCategory.Text.Trim() != "DECT")
                {
                    if (txtRescan.Text != (txtByHand.Text.Trim() + "-" + txtExtension.Text).ToUpper())
                    {
                        mdaShrink.URL = @"C:\audio\NG.wav";
                        lblStatus.Text = "NG";
                        return;
                    }
                }

                if (txtSerial.Text == String.Empty)
                {
                    txtSerial.Focus();
                    return;
                }

                int count = int.Parse(txtScanned.Text.Trim());
                if (txtQtyPalletFix.Text == "")
                {
                    txtQtyPalletFix.Text = txtQuantyStanddard.Text;

                }
                if (count == int.Parse(txtQtyPalletFix.Text))
                {

                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                    string[] para = { "@pallet" };
                    object[] obj = { txtPallet.Text };
                    DataTable dt = new DataTable();
                    dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet

                    mdaShrink.URL = @"C:\audio\OK.wav";
                    MessageBox.Show("Đã đủ số lượng trên Pallet");
                    btnClose_Click(sender, e);
                }
                else
                {
                    if (chk_Outer_carton.Checked == false)
                    {
                        if (lblCategory.Text.Trim() == "DECT")
                        {
                               
                               if (count >= int.Parse(txtQuantyStanddard.Text))
                                {
                                     lblStatus.BackColor = System.Drawing.Color.Yellow;
                                     lblStatus.ForeColor = System.Drawing.Color.Red;
                                     lblStatus.Text = "Pallet Full rồi";

                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                    string[] para = { "@pallet" };
                                    object[] obj = { txtPallet.Text };
                                    DataTable dt = new DataTable();
                                    dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                    mdaShrink.URL = @"C:\audio\NG.wav";

                                    txtSerial.Clear();
                                    txtRescan.Focus();
                                    txtRescan.SelectAll();
                                    this.Close();
                                    return;
                                }
                               else if (txtRescan.Text.Trim() != txtByHand.Text.Trim())
                               {
                                   lblStatus.BackColor = System.Drawing.Color.Yellow;
                                   lblStatus.ForeColor = System.Drawing.Color.Red;
                                   lblStatus.Text = "2 Model khong the cung tren 1 Pallet";
                                   InsertError("3", employee_id, txtSerial.Text.ToString().Trim(), lblCategory.Text.ToString(), model);
                                   //Fill data to SMS
                                   //DataConn2.ExecuteStore("sp_getContact5", CommandType.StoredProcedure, "QualityWarning", "QualityWarning", "Pallet:" + txtPallet.Text.ToString() + "ban 2 model:" + "...", "Shrink", "", "");
                                   txtSerial.Focus();
                                   mdaShrink.URL = @"C:\audio\NG.wav";
                                   txtSerial.Clear();
                                   txtRescan.Focus();
                                   txtRescan.SelectAll();
                                   listView1.ResetText();
                                   return;

                               }
                                else
                                {
                                     string mysql = "select 1 from TBLPRODUCT_DECT" + "(nolock) " + "where STR_PROCESS_FACTORY= '" + txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim() + "' " + "and " + "STR_SERIAL= '" + txtSerial.Text.Trim() + "'";
                                     DataTable mydt = objConnect.GetTableWithCommandText(mysql);
                                        if (mydt.Rows.Count == 0)
                                        {
                                            lblStatus.Text = "Không tồn tại trên hệ thống cân";
                                            InsertError("2", employee_id, txtSerial.Text.ToString().Trim(), lblCategory.Text.ToString(), model);
                                          
                                            lblStatus.ForeColor = Color.Red;
                                            lblStatus.BackColor = System.Drawing.Color.Yellow;
                                            txtSerial.Clear();
                                            txtRescan.Focus();
                                            txtRescan.SelectAll();
                                            return;
                                        }
                                        else if (txtSerial.Text.Trim().Contains("KX-"))   //minh fix loi băn nhầm tên model 15.08.2025 **** fix loi ban nham model
                                        {
                                            lblStatus.Text = "Bắn nhầm tên Model! bạn cần chú ý hơn!";
                                            lblStatus.ForeColor = Color.Red;
                                            lblStatus.BackColor = System.Drawing.Color.Yellow;
                                            txtSerial.Clear();
                                            txtRescan.Focus();
                                            txtRescan.SelectAll();
                                            return;
                                        }
                                        else
                                        {
                                             string mysql1 = "select 1 from tblPalletCombine_DECT" + "(nolock)" + "where sModelNo= '" + txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim() + "' " + "and " + "sSerialNo= '" + txtSerial.Text.Trim() + "'";
                                             DataTable mydt1 = objConnect.GetTableWithCommandText(mysql1);
                                            
                                            if (mydt1.Rows.Count > 0)
                                            {
                                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                                if (lblCategory.Text == "Scanner")
                                                {
                                                    lblSerialDouble.Text = txtSerial.Text;
                                                }

                                                lblStatus.Text = "Quét rồi";
                                                mdaShrink.URL = @"C:\audio\NG.wav";
                                                txtSerial.Clear();
                                                txtRescan.Focus();
                                                txtRescan.SelectAll();

                                                return;
                                            }
                                         
                                            else
                                            {
                                                string mysql2 = "insert into  tblPalletCombine_DECT(sModelNo,sSerialNo,Source_pallet,dShrinkDate,dShrinkBy,sCategoryID) values ('" + txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim() + "','" + txtSerial.Text.Trim() + "','" + txtPallet.Text.Trim() + "'," + "GETDATE(),'" + employee_id + "',0)" +
                                                "update TBLPRODUCT_DECT set bShrinked =1 where STR_PROCESS_FACTORY = '" + txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim() + "' " + "and STR_SERIAL = '" + txtSerial.Text.Trim() + "'";
                                                if (objConnect.exnon(mysql2) > 1)
                                                {
                                                    lblStatus.ForeColor = Color.White;
                                                    lblStatus.BackColor = Color.Green;
                                                    count = count + 1;
                                                    txtScanned.Text = count + "";
                                                    lblStatus.Text = "OK";
                                                    if (count == int.Parse(txtQtyPalletFix.Text))
                                                    {

                                                        // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                        string[] para = { "@pallet" };
                                                        object[] obj = { txtPallet.Text };
                                                        DataTable dt = new DataTable();
                                                        dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                                        // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                        mdaShrink.URL = @"C:\audio\OK.wav";
                                                        MessageBox.Show("Đã đủ số lượng trên Pallet");
                                                        btnClose_Click(sender, e);
                                                    }

                                                    txtRescan.Text = "";
                                                    txtSerial.Text = "";
                                                    txtRescan.Focus();

                                                }
                                            }

                                        }
                                
                                }
                               


                        }
                        else
                        {
                            //minh edit cho cate tivi 24.04.2024 => chuyen tu Dau TV->KV
                            string rs = "";
                            if (lblCategory.Text.Trim() == "TV")
                            {
                                rs = objService.InsertToPallet_PalletID_TV(txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim(), txtPallet.Text.Trim(), txtSerial.Text.Trim(), employee_id, lblCategory.Text.Trim());
                            }
                            else 
                            {
                                rs = objService.InsertToPallet_PalletID(txtByHand.Text.Trim() + "-" + txtExtension.Text.Trim(), txtPallet.Text.Trim(), txtSerial.Text.Trim(), employee_id, lblCategory.Text.Trim());
                            }
                            


                            if (rs == "1")
                            {
                                lblStatus.ForeColor = Color.White;
                                lblStatus.BackColor = Color.Green;
                                count = count + 1;
                                txtScanned.Text = count + "";
                                lblStatus.Text = "OK";

                                //============ minh remove 19-08-2020 ======// have to scan model and serial
                                if (count == int.Parse(txtQtyPalletFix.Text))
                                {

                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                    string[] para = { "@pallet" };
                                    object[] obj = { txtPallet.Text };
                                    DataTable dt = new DataTable();
                                    dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                    mdaShrink.URL = @"C:\audio\OK.wav";
                                    MessageBox.Show("Đã đủ số lượng trên Pallet");
                                    btnClose_Click(sender, e);
                                }

                                txtRescan.Text = "";
                                txtSerial.Text = "";
                                txtRescan.Focus();

                                //txtRescan.SelectAll();
                                //==== old ====//  doi dua request roi chay thu
                                //else
                                //{
                                //    if (lblCategory.Text == "Scanner" || lblCategory.Text == "PBX")
                                //    {
                                //        lblSerialDouble.Text = txtSerial.Text + " => OK ";
                                //    }
                                //    // txtSerial.Clear();
                                //    // them doan nay cho scanner và pbx de phai nhap tay model nhieu lan 
                                //    if (lblCategory.Text == "Scanner" || lblCategory.Text == "PBX")
                                //    {
                                //        txtSerial.Focus();
                                //        txtSerial.SelectAll();
                                //    }
                                //    else
                                //    {
                                //        txtRescan.Focus();
                                //        txtRescan.SelectAll();
                                //    }

                                //    //txtScanned.Text = count + "";
                                //    //lblStatus.BackColor = Color.Green;
                                //    //lblStatus.Text = "OK";
                                //    //txtRescan.Focus();
                                //    //txtRescan.SelectAll();
                                //    mdaShrink.URL = @"C:\audio\OK.wav";
                                //    return;
                                //}

                                //==== end old ====//

                            }
                            else if (rs == "2")
                            {

                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                lblStatus.Text = "QUET ROI";
                                InsertError("7", employee_id, txtSerial.Text.ToString().Trim(), lblCategory.Text.ToString(), model);
                                //Fill data to SMS
                                DataConn2.ExecuteStore("sp_getContact5", CommandType.StoredProcedure, "QualityWarning", "QualityWarning", "Palllet:" + this.txtPallet.Text + "da shink roi", "Shrink", "", "");
                                txtSerial.Clear();
                                txtRescan.Focus();
                                txtRescan.SelectAll();

                                mdaShrink.URL = @"C:\audio\NG.wav";
                                return;

                            }
                            else if (rs == "3")
                            {
                                lblStatus.Text = "Không tồn tại trên hệ thống cân";
                                InsertError("2", employee_id, txtSerial.Text.ToString().Trim(), lblCategory.Text.ToString(), model);
                                //Fill data to SMS
                                //DataConn2.ExecuteStore("sp_getContact5", CommandType.StoredProcedure, "QualityWarning", "QualityWarning", "Serial:" + txtSerial.Text + " không tồn tại trên hệ thống cân", "Shrink", "", "");
                                lblStatus.ForeColor = Color.Red;
                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                txtSerial.Clear();
                                txtRescan.Focus();
                                txtRescan.SelectAll();



                                //minh edit su loi fix cho DP chay cham khi scan serial outer 06.2023
                                return;

                                frmConfirm objConfirm = new frmConfirm(txtByHand.Text + "-" + txtExtension.Text, txtSerial.Text, txtPallet.Text, employee_id);
                                objConfirm.ShowDialog();
                                objConfirm.TopMost = true;


                                if (STATUS == "OK")
                                {
                                    count = int.Parse(txtScanned.Text.Trim());
                                    count = count + 1;
                                    txtScanned.Text = count + "";
                                    STATUS = String.Empty;
                                    mdaShrink.URL = @"C:\audio\NG.wav";
                                    // if (lblCategory.Text == "Scanner")
                                    if (lblCategory.Text == "Scanner" || lblCategory.Text == "PBX")
                                    {
                                        //lblSerialDouble.Text = txtSerial.Text;
                                        lblSerialDouble.Text = txtSerial.Text + " => OK ";
                                    }
                                    lblStatus.Text = "OK";
                                    lblStatus.BackColor = Color.Green;
                                    txtSerial.Clear();
                                    txtRescan.Focus();
                                    txtRescan.SelectAll();
                                    return;
                                }

                                txtSerial.Clear();
                                txtSerial.Focus();
                                txtSerial.SelectAll();
                                return;

                            }
                            else if (rs == "0")
                            {
                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                lblStatus.Text = "Pallet Full rồi";

                                // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                string[] para = { "@pallet" };
                                object[] obj = { txtPallet.Text };
                                DataTable dt = new DataTable();
                                dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                mdaShrink.URL = @"C:\audio\NG.wav";

                                txtSerial.Clear();
                                txtRescan.Focus();
                                txtRescan.SelectAll();
                                this.Close();
                                return;
                            }
                            else if (rs == "4")
                            {
                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                if (lblCategory.Text == "Scanner")
                                {
                                    lblSerialDouble.Text = txtSerial.Text;
                                }

                                lblStatus.Text = "Quét rồi";
                                mdaShrink.URL = @"C:\audio\NG.wav";
                                txtSerial.Clear();
                                txtRescan.Focus();
                                txtRescan.SelectAll();

                                return;
                            }
                            else if (rs == "5")
                            {
                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                lblStatus.Text = "2 Model khong the cung tren 1 Pallet";
                                InsertError("3", employee_id, txtSerial.Text.ToString().Trim(), lblCategory.Text.ToString(), model);
                                //Fill data to SMS
                                DataConn2.ExecuteStore("sp_getContact5", CommandType.StoredProcedure, "QualityWarning", "QualityWarning", "Pallet:" + txtPallet.Text.ToString() + "ban 2 model:" + "...", "Shrink", "", "");
                                txtSerial.Focus();
                                mdaShrink.URL = @"C:\audio\NG.wav";
                                txtSerial.Clear();
                                txtRescan.Focus();
                                txtRescan.SelectAll();
                                listView1.ResetText();
                                return;

                            }
                        
                        }
                       


                    }
                    else
                    {
                        //lay ra list serial theo outer serial   //stored: Get_All_Serial_Outercarton

                        //if exists(select * from #T2)
                        //        insert into  #temp1_product values(@STR_PROCESS_FACTORY,@STR_SERIAL,1)   -neu co trong bang: tblPalletCombine_'+@Category+'
                        //else
                        //        insert into  #temp1_product values(@STR_PROCESS_FACTORY,@STR_SERIAL,0)   - status = 0 -> insert vao bang combine
                        //drop table #T2

                        //Dao 23/11/2022 Sua phan Shink check bang verrify

                        //dt_serial = _obj.Get_All_Serial_Outercarton(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), lblCategory.Text.Trim());

                        //edit for cate sound 10.2021 => not scan outer, only scan serial outer.
                        DataTable dt_serial = new DataTable();

                        //****edit1
                        //dt_serial = _obj.Get_All_Serial_Outercarton_sound(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), lblCategory.Text.Trim());
                        string _STR_PROCESS_FACTORY = txtByHand.Text.Trim() + "-" + extension.ToString();
                        string _Outer_carton = txtRescan.Text.Trim();
                        //string _Serial_outer = txtSerial.Text.Trim();
                        string _Serial_outer = "";

                        //*** check 08.07.2023 edit1
                        string sql = "";  
                     
                        if (lblCategory.Text.Trim() == "HP")
                        {
                            _Serial_outer = txtSerial.Text.Trim();
                            sql = "select STR_PROCESS_FACTORY,STR_SERIAL,bShrinked as Status from TBLPRODUCT_" + lblCategory.Text.Trim() + " with (NOLOCK) where outer_carton is not null and STR_PROCESS_FACTORY ='" + _STR_PROCESS_FACTORY + "' " + "and SERIAL_OUTER ='" + _Serial_outer + "' and status=1";

                        }
                        else
                        {                            
                            //edit hang ecom  28.10.2023
                            string[] pa1 = { "@SerialOuter" };
                            object[] ob1 = { txtSerial.Text.Trim() };
                            DataTable dt_get_seriouter = new DataTable();
                            dt_get_seriouter = objConnect.TableWithParameter("SP_QSerialOuter_ecom2", pa1, ob1);

                            if (dt_get_seriouter.Rows[0][0].ToString() == "1")
                            {
                                string serial_outer_new = dt_get_seriouter.Rows[0][1].ToString();
                                _Serial_outer = serial_outer_new;
                                txtSerial.Text = serial_outer_new;
                                //hang model ecom
                                sql = "select STR_PROCESS_FACTORY,STR_SERIAL,bShrinked as Status from TBLPRODUCT_" + lblCategory.Text.Trim() + " with (NOLOCK) where outer_carton is not null and STR_PROCESS_FACTORY ='" + _STR_PROCESS_FACTORY + "' and OUTER_CARTON ='" + _Outer_carton + "' and SERIAL_OUTER ='" + serial_outer_new + "' and status=1";
                            }
                            else
                            {
                                _Serial_outer = txtSerial.Text.Trim();
                                sql = "select STR_PROCESS_FACTORY,STR_SERIAL,bShrinked as Status from TBLPRODUCT_" + lblCategory.Text.Trim() + " with (NOLOCK) where outer_carton is not null and STR_PROCESS_FACTORY ='" + _STR_PROCESS_FACTORY + "' and OUTER_CARTON ='" + _Outer_carton + "' and SERIAL_OUTER ='" + _Serial_outer + "' and status=1";
                            }
                            //sql = "select STR_PROCESS_FACTORY,STR_SERIAL,bShrinked as Status from TBLPRODUCT_" + lblCategory.Text.Trim() + " with (NOLOCK) where outer_carton is not null and STR_PROCESS_FACTORY ='" + _STR_PROCESS_FACTORY + "' and OUTER_CARTON ='" + _Outer_carton + "' and SERIAL_OUTER ='" + _Serial_outer + "' and status=1";
                        }

                        dt_serial = objConnect.GetTableWithCommandText(sql);
                        
                        if (dt_serial.Rows.Count > 0)
                        {
                            if (lblCategory.Text.Trim() == "DP")
                            {
                                DataTable dt_Checkverify = new DataTable();

                                //edit2
                                //dt_Checkverify = _obj.CheckVeryFile(txtSerial.Text.Trim(), lblCategory.Text.Trim());
                                  
                                //old
                                //string sql2 = "select top(10)* from [dbo].[tbl_VerifyProduct_DP] (nolock) where   OUTERCARTON like '%" + _Serial_outer + "%' and CATE = '" + lblCategory.Text.Trim() + "'";
                                
                                //sua loi cham 07.11.2024 minh edit loi bang nay
                                string sql2 = "select top(10)* from [dbo].[tbl_VerifyProduct_DP] (nolock) where   OUTERCARTON like '%" + _Serial_outer + "%' and CATE = '" + lblCategory.Text.Trim() + "' and MONTH(CREATE_DATE)=MONTH(GETDATE()) and YEAR(CREATE_DATE)=YEAR(GETDATE()) ";

                                dt_Checkverify = objConnect.GetTableWithCommandText(sql2);

                                if (dt_Checkverify.Rows.Count > 0) // Kiem tra ton tai ban ghi bangr verfify
                                {
                                    listView1.Clear();
                                    Design_list();
                                    for (int i = 0; i < dt_serial.Rows.Count; i++)
                                    {
                                        add_list(dt_serial.Rows[i]["STR_SERIAL"].ToString(), dt_serial.Rows[i]["Status"].ToString());
                                        if (dt_serial.Rows[i]["Status"].ToString() == "True")
                                        {
                                            listView1.Items[i].BackColor = Color.Red;
                                        }

                                    }

                                    Boolean kt_shrink = false;
                                    for (int i = 0; i < dt_serial.Rows.Count; i++)
                                    {
                                        //if (dt_serial.Rows[i]["Status"].ToString() == "1")
                                        if (dt_serial.Rows[i]["Status"].ToString() == "True")
                                        {
                                            kt_shrink = true;
                                        }
                                        //return;
                                    }


                                    if (kt_shrink == true)
                                    {
                                        lblStatus.BackColor = System.Drawing.Color.Yellow;
                                        lblStatus.ForeColor = System.Drawing.Color.Red;
                                        lblStatus.Text = "Serial trong outer đã được đóng vào Pallet";
                                        DataConn2.ExecuteStore("sp_getContact5", CommandType.StoredProcedure, "QualityWarning", "QualityWarning", "Serial("+ txtSerial.Text.Trim()+")shink roi.", "Shrink", "", "");
                                        txtSerial.Focus();
                                        mdaShrink.URL = @"C:\audio\NG.wav";
                                        txtSerial.Clear();
                                        txtRescan.Focus();
                                        txtRescan.SelectAll();
                                        listView1.ResetText();
                                        return;

                                    }
                                    else
                                    {
                                        // tinh toan xem du pallet chua, thua thi thong bao, du hoac thieu thi van chay bt
                                        if (int.Parse(txtQtyPalletFix.Text) < int.Parse(txtScanned.Text) + dt_serial.Rows.Count)
                                        {
                                            lblStatus.BackColor = System.Drawing.Color.Yellow;
                                            lblStatus.ForeColor = System.Drawing.Color.Red;
                                            lblStatus.Text = "So luong vuot qua Quantity Pallet Fix. Vui long kiem tra lai";
                                            InsertError("4", employee_id, txtSerial.Text.ToString().Trim(), lblCategory.Text.ToString(), model);
                                            txtSerial.Focus();
                                            mdaShrink.URL = @"C:\audio\NG.wav";
                                            txtSerial.Clear();
                                            txtRescan.Focus();
                                            txtRescan.SelectAll();
                                            listView1.ResetText();
                                            return;
                                        }
                                        else
                                        {

                                            if (dt_serial.Rows.Count != int.Parse(numericUpDown1.Value.ToString()))
                                            {
                                                if (MessageBox.Show("Số lượng sản phẩm không đủ?" + Environment.NewLine + " Bạn có muốn đóng vào Pallet?", "Số lượng OuterCarton",
                                                   MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
                                                {
                                                    lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                    lblStatus.ForeColor = System.Drawing.Color.Red;
                                                    lblStatus.Text = "Kiem tra lai so luong serial cua Outer Carton";
                                                    txtSerial.Focus();
                                                    mdaShrink.URL = @"C:\audio\NG.wav";
                                                    txtSerial.Clear();
                                                    txtRescan.Focus();
                                                    txtRescan.SelectAll();
                                                    return;
                                                }
                                                else
                                                {
                                                    // insert vao database vao bang combine truong hop khong du hop trong 1 carton
                                                    //if (_obj.InsertToPallet_OuterCarton(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)

                                                    //edit for sound beate 10.2021                                            
                                                    //if (_obj.InsertToPallet_OuterCarton_sound(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)
                                                    //edit loi scan cham ben DP  08.06.2023
                                                    if (_obj.InsertToPallet_OuterCarton_DP(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)
                                                    {
                                                        txtScanned.Text = (int.Parse(txtScanned.Text) + dt_serial.Rows.Count).ToString();
                                                        lblStatus.Text = "OK";
                                                        lblStatus.BackColor = Color.Green;
                                                        txtSerial.Clear();
                                                        txtRescan.Focus();
                                                        txtRescan.SelectAll();
                                                        mdaShrink.URL = @"C:\audio\OK.wav";
                                                    }
                                                    else
                                                    {
                                                        lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                        lblStatus.ForeColor = System.Drawing.Color.Red;
                                                        lblStatus.Text = "Da xay ra loi khong the them";
                                                        txtSerial.Focus();
                                                        mdaShrink.URL = @"C:\audio\NG.wav";
                                                    }

                                                    if (int.Parse(txtQtyPalletFix.Text) == int.Parse(txtScanned.Text))
                                                    {
                                                        lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                        lblStatus.ForeColor = System.Drawing.Color.Red;
                                                        lblStatus.Text = "Pallet Full rồi";
                                                        //mdaShrink.URL = @"C:\audio\NG.wav";
                                                        MessageBox.Show("Pallet Full rồi");

                                                        // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                        string[] para = { "@pallet" };
                                                        object[] obj = { txtPallet.Text };
                                                        DataTable dt = new DataTable();
                                                        dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                                        // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                        //sound 10.2021
                                                        if (lblCategory.Text.ToString() == "HP")
                                                        {
                                                            txtSerial.Clear();
                                                            txtSerial.Focus();
                                                            txtSerial.SelectAll();
                                                            this.Close();
                                                        }
                                                        else
                                                        {
                                                            txtSerial.Clear();
                                                            txtRescan.Focus();
                                                            txtRescan.SelectAll();
                                                            this.Close();
                                                        }

                                                    }
                                                }
                                            }

                                            else
                                            {
                                                // insert vao database vao bang combine truong hop du trong hop carton

                                                //if (_obj.InsertToPallet_OuterCarton(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)

                                                //edit for sound beate 10.2021
                                                //if (_obj.InsertToPallet_OuterCarton_sound(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)
                                                //fix loi scan cham ben DP 08.06.2023
                                                if (_obj.InsertToPallet_OuterCarton_DP(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)
                                                {
                                                    txtScanned.Text = (int.Parse(txtScanned.Text) + dt_serial.Rows.Count).ToString();
                                                    lblStatus.Text = "OK";
                                                    lblStatus.BackColor = Color.Green;
                                                    txtSerial.Clear();
                                                    txtRescan.Focus();
                                                    txtRescan.SelectAll();
                                                    mdaShrink.URL = @"C:\audio\OK.wav";
                                                }
                                                else
                                                {
                                                    lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                    lblStatus.ForeColor = System.Drawing.Color.Red;
                                                    lblStatus.Text = "Da xay ra loi khong the them";
                                                    txtSerial.Focus();
                                                    mdaShrink.URL = @"C:\audio\NG.wav";
                                                }

                                                if (int.Parse(txtQtyPalletFix.Text) == int.Parse(txtScanned.Text))
                                                {
                                                    lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                    lblStatus.ForeColor = System.Drawing.Color.Red;
                                                    lblStatus.Text = "Pallet Full rồi";
                                                    mdaShrink.URL = @"C:\audio\NG.wav";
                                                    MessageBox.Show("Pallet Full rồi");

                                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                    string[] para = { "@pallet" };
                                                    object[] obj = { txtPallet.Text };
                                                    DataTable dt = new DataTable();
                                                    dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                    //sound
                                                    if (lblCategory.Text.ToString() == "HP")
                                                    {
                                                        txtSerial.Clear();
                                                        txtSerial.Focus();
                                                        txtSerial.SelectAll();
                                                        this.Close();
                                                    }
                                                    else
                                                    {
                                                        txtSerial.Clear();
                                                        txtRescan.Focus();
                                                        txtRescan.SelectAll();
                                                        this.Close();
                                                    }


                                                }
                                            }

                                        }
                                    }
                                }
                                else
                                {
                                   
                                    lblStatus.Text = "SerialOuter chưa kiểm tra công đoạn Verify ";
                                    InsertError("1", employee_id,txtSerial.Text.ToString().Trim(), lblCategory.Text.ToString(), model);
                                    txtSerial.Text = "";
                                    txtRescan.Text = "";
                                    txtRescan.Focus();
                                    txtRescan.SelectAll();
                                    lblStatus.ForeColor = Color.Red;
                                    lblStatus.BackColor = Color.Yellow;
                                    mdaShrink.URL = @"C:\audio\NG.wav";
                                    return;
                                }
                            }

                            else // SHINK CỦA CATE KHÁC
                            {
                                listView1.Clear();
                                Design_list();
                                for (int i = 0; i < dt_serial.Rows.Count; i++)
                                {
                                    string a = dt_serial.Rows[i]["Status"].ToString();
                                    add_list(dt_serial.Rows[i]["STR_SERIAL"].ToString(), dt_serial.Rows[i]["Status"].ToString());
                                    if (dt_serial.Rows[i]["Status"].ToString() == "True")
                                    {
                                        listView1.Items[i].BackColor = Color.Red;
                                    }

                                }

                                Boolean kt_shrink = false;
                                for (int i = 0; i < dt_serial.Rows.Count; i++)
                                {
                                    if (dt_serial.Rows[i]["Status"].ToString() == "True")
                                    {
                                        kt_shrink = true;
                                    }
                                    //return;
                                }


                                if (kt_shrink == true)
                                {
                                    lblStatus.BackColor = System.Drawing.Color.Yellow;
                                    lblStatus.ForeColor = System.Drawing.Color.Red;
                                    lblStatus.Text = "Serial trong outer đã được đóng vào Pallet";
                                    txtSerial.Focus();
                                    mdaShrink.URL = @"C:\audio\NG.wav";
                                    txtSerial.Clear();
                                    txtRescan.Focus();
                                    txtRescan.SelectAll();
                                    listView1.ResetText();
                                    return;

                                }
                                else
                                {
                                    // tinh toan xem du pallet chua, thua thi thong bao, du hoac thieu thi van chay bt
                                    if (int.Parse(txtQtyPalletFix.Text) < int.Parse(txtScanned.Text) + dt_serial.Rows.Count)
                                    {
                                        lblStatus.BackColor = System.Drawing.Color.Yellow;
                                        lblStatus.ForeColor = System.Drawing.Color.Red;
                                        lblStatus.Text = "So luong vuot qua Quantity Pallet Fix. Vui long kiem tra lai";
                                        txtSerial.Focus();
                                        mdaShrink.URL = @"C:\audio\NG.wav";
                                        txtSerial.Clear();
                                        txtRescan.Focus();
                                        txtRescan.SelectAll();
                                        listView1.ResetText();
                                        return;
                                    }
                                    else
                                    {

                                        if (dt_serial.Rows.Count != int.Parse(numericUpDown1.Value.ToString()))
                                        {
                                            if (MessageBox.Show("Số lượng sản phẩm không đủ?" + Environment.NewLine + " Bạn có muốn đóng vào Pallet?", "Số lượng OuterCarton",
                                               MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.No)
                                            {
                                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                                lblStatus.Text = "Kiem tra lai so luong serial cua Outer Carton";
                                                txtSerial.Focus();
                                                mdaShrink.URL = @"C:\audio\NG.wav";
                                                txtSerial.Clear();
                                                txtRescan.Focus();
                                                txtRescan.SelectAll();
                                                return;
                                            }
                                            else
                                            {
                                                // insert vao database vao bang combine truong hop khong du hop trong 1 carton
                                                //if (_obj.InsertToPallet_OuterCarton(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)

                                                //edit for sound beate 10.2021                                            
                                                if (_obj.InsertToPallet_OuterCarton_sound(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)
                                                {
                                                    txtScanned.Text = (int.Parse(txtScanned.Text) + dt_serial.Rows.Count).ToString();
                                                    lblStatus.Text = "OK";
                                                    lblStatus.BackColor = Color.Green;
                                                    txtSerial.Clear();
                                                    txtRescan.Focus();
                                                    txtRescan.SelectAll();
                                                    mdaShrink.URL = @"C:\audio\OK.wav";
                                                }
                                                else
                                                {
                                                    lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                    lblStatus.ForeColor = System.Drawing.Color.Red;
                                                    lblStatus.Text = "Da xay ra loi khong the them";
                                                    txtSerial.Focus();
                                                    mdaShrink.URL = @"C:\audio\NG.wav";
                                                }

                                                if (int.Parse(txtQtyPalletFix.Text) == int.Parse(txtScanned.Text))
                                                {
                                                    lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                    lblStatus.ForeColor = System.Drawing.Color.Red;
                                                    lblStatus.Text = "Pallet Full rồi";
                                                    //mdaShrink.URL = @"C:\audio\NG.wav";
                                                    MessageBox.Show("Pallet Full rồi");

                                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                    string[] para = { "@pallet" };
                                                    object[] obj = { txtPallet.Text };
                                                    DataTable dt = new DataTable();
                                                    dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                                    // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                    //sound 10.2021
                                                    if (lblCategory.Text.ToString() == "HP")
                                                    {
                                                        txtSerial.Clear();
                                                        txtSerial.Focus();
                                                        txtSerial.SelectAll();
                                                        this.Close();
                                                    }
                                                    else
                                                    {
                                                        txtSerial.Clear();
                                                        txtRescan.Focus();
                                                        txtRescan.SelectAll();
                                                        this.Close();
                                                    }

                                                }
                                            }
                                        }

                                        else
                                        {
                                            // insert vao database vao bang combine truong hop du trong hop carton

                                            //if (_obj.InsertToPallet_OuterCarton(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)

                                            //edit for sound beate 10.2021
                                            if (_obj.InsertToPallet_OuterCarton_sound(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), txtSerial.Text.Trim(), txtPallet.Text.Trim(), employee_id, lblCategory.Text.Trim()) == true)
                                            {
                                                txtScanned.Text = (int.Parse(txtScanned.Text) + dt_serial.Rows.Count).ToString();
                                                lblStatus.Text = "OK";
                                                lblStatus.BackColor = Color.Green;
                                                txtSerial.Clear();
                                                txtRescan.Focus();
                                                txtRescan.SelectAll();
                                                mdaShrink.URL = @"C:\audio\OK.wav";
                                            }
                                            else
                                            {
                                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                                lblStatus.Text = "Da xay ra loi khong the them";
                                                txtSerial.Focus();
                                                mdaShrink.URL = @"C:\audio\NG.wav";
                                            }

                                            if (int.Parse(txtQtyPalletFix.Text) == int.Parse(txtScanned.Text))
                                            {
                                                lblStatus.BackColor = System.Drawing.Color.Yellow;
                                                lblStatus.ForeColor = System.Drawing.Color.Red;
                                                lblStatus.Text = "Pallet Full rồi";
                                                mdaShrink.URL = @"C:\audio\NG.wav";
                                                MessageBox.Show("Pallet Full rồi");

                                                // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                string[] para = { "@pallet" };
                                                object[] obj = { txtPallet.Text };
                                                DataTable dt = new DataTable();
                                                dt = objConnect.TableWithParameter("SP_InsertPalletFull", para, obj);


                                                // khong cho đóng thêm vào pallet khi đã đủ số lượng trên pallet
                                                //sound
                                                if (lblCategory.Text.ToString() == "HP")
                                                {
                                                    txtSerial.Clear();
                                                    txtSerial.Focus();
                                                    txtSerial.SelectAll();
                                                    this.Close();
                                                }
                                                else
                                                {
                                                    txtSerial.Clear();
                                                    txtRescan.Focus();
                                                    txtRescan.SelectAll();
                                                    this.Close();
                                                }


                                            }
                                        }

                                    }
                                }

                            }// Veryfile khac
                        }
                        else
                        {
                            lblStatus.BackColor = System.Drawing.Color.Yellow;
                            lblStatus.ForeColor = System.Drawing.Color.Red;
                            lblStatus.Text = "Khong tim thay Outer co serial nay";
                            txtSerial.Focus();
                            txtSerial.SelectAll();
                            listView1.ResetText();
                            mdaShrink.URL = @"C:\audio\NG.wav";
                        }


                    }
                }

            }
        }
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if (e.KeyChar == (char)Keys.Enter || e.KeyChar == (char)Keys.Escape)
            {
                e.Handled = true;   // stop annoying beep
            }

            // call base handler...
            base.OnKeyPress(e);
        }
        private void frmShrink_Load(object sender, EventArgs e)
        {
            
            
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;
            txtExtension.Text = this.extension;                      
            groupBox2.Enabled = false;
            numericUpDown1.Enabled = false;
            txtQtyPalletFix.Enabled = true;
            txtQtyPalletFix.Focus();
            txtQtyPalletFix.Select();
        }

        private void txtByHand_KeyUp(object sender, KeyEventArgs e)
        {

        }

        public void InsertError(string ErrorID, string UserScan , string SerialOUt, string Cate, string Model )
        {
            string[] para = { "@ErrorID","@UserScan","@SerialOut","@Cate","@Model" };
            object[] obj = { ErrorID, UserScan, SerialOUt, Cate, Model };
            DataTable dt = new DataTable();
            dt = objConnect.TableWithParameter("SP_InsertError_Detail", para, obj);

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            if (txtQtyPalletFix.Text == "" || int.Parse(txtScanned.Text) == int.Parse(txtQtyPalletFix.Text.Trim()))
            {
                try
                {
                    frmStep3cs frm = (frmStep3cs)(Application.OpenForms["frmStep3cs"]);
                    frm.txtModel1.Text = String.Empty;
                    frm.txtModel2.Text = String.Empty;
                    frm.txtPallet.Text = String.Empty;
                    frm.txtSerial1.Text = String.Empty;
                    frm.txtSerial2.Text = String.Empty;
                    frm.lblStatus.Text = String.Empty;
                    frm.txtPallet.Focus();
                    this.Close();
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
            else
            {
                if (int.Parse(txtScanned.Text) < int.Parse(txtQtyPalletFix.Text.Trim()))
                {
                    frm_ConfrimUser frm1 = new frm_ConfrimUser();
                    frm1.ShowDialog();

                    if (Untility._para.Pass_Admin == "Admin123")
                    {

                        try
                        {
                            frmStep3cs frm = (frmStep3cs)(Application.OpenForms["frmStep3cs"]);
                            frm.txtModel1.Text = String.Empty;
                            frm.txtModel2.Text = String.Empty;
                            frm.txtPallet.Text = String.Empty;
                            frm.txtSerial1.Text = String.Empty;
                            frm.txtSerial2.Text = String.Empty;
                            frm.lblStatus.Text = String.Empty;
                            frm.txtPallet.Focus();
                            this.Close();
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show(ex.Message);
                        }


                    }
                    else
                    {
                        lblStatus.Text = "KHÔNG ĐÚNG USER ADMIN";
                        lblStatus.ForeColor = Color.Red;
                        lblStatus.BackColor = Color.Yellow;
                        return;
                    }


                }
            }

        }

        private void txtRescan_KeyUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                listView1.Clear();
                string data = txtRescan.Text.Replace('*', ' ');

                if (data.Contains("-V4"))
                {
                    data = data.Replace("-V4", String.Empty);
                }
                //txtRescan.Text = data;
                data = data.Replace('%', ' ');
                data = data.Trim();
                txtRescan.Text = data;
                if (data == "")
                { return; }
                else
                {
                    if (chk_Outer_carton.Checked == false)
                    {
                        if (lblCategory.Text.Trim() == "DECT")
                        {
                            if (txtRescan.Text.Trim() != (txtByHand.Text.Trim()).ToUpper())
                            {

                                lblStatus.Text = "2 model khong khop nhau";

                                txtRescan.Clear();
                                txtRescan.Focus();
                                txtSerial.Clear();
                                lblStatus.ForeColor = Color.Red;
                                lblStatus.BackColor = Color.Yellow;
                                mdaShrink.URL = @"C:\audio\NG.wav";
                            }
                            else
                            {
                                txtSerial.Focus();
                            }

                        }
                        else
                        {
                            // thêm đoạn này vào check đối với nhưng thằng không có outer thì sẽ cho phep bắn model hoặc post code không phải nhập tay nữa
                            string[] arrParam = { "@Model", "@Category" };
                            object[] arrValue = { txtRescan.Text.Trim() + "-" + txtExtension.Text, lblCategory.Text.ToUpper().Trim() };
                            DataTable dt = objConnect.TableWithParameter("SP_QModelWeight", arrParam, arrValue);
                            if (dt.Rows.Count <= 0)
                            {
                                txtRescan.Text = "";
                            }
                            else
                            {
                                txtRescan.Text = dt.Rows[0][0].ToString();
                            }

                            // thêm đoạn này vào check đối với nhưng thằng không có outer thì sẽ cho phep bắn model hoặc post code không phải nhập tay nữa


                            if (txtRescan.Text.Trim() != (txtByHand.Text.Trim() + "-" + txtExtension.Text).ToUpper())
                            {

                                lblStatus.Text = "2 model khong khop nhau";

                                txtRescan.Clear();
                                txtRescan.Focus();
                                txtSerial.Clear();
                                lblStatus.ForeColor = Color.Red;
                                lblStatus.BackColor = Color.Yellow;
                                mdaShrink.URL = @"C:\audio\NG.wav";
                            }
                            else
                            {
                                txtSerial.Focus();
                            }
                        
                        
                        }


                        
                    }
                    else
                    {

                        //scan outer carton
                        //check model va outer carton co ton tai khong
                        if (_obj.Get_Outer_carton(txtByHand.Text.Trim() + "-" + extension.ToString(), txtRescan.Text.Trim(), lblCategory.Text.Trim()).Rows.Count > 0)
                        {
                            lblStatus.Text = "";
                            lblStatus.BackColor = Color.LightGray;
                            txtSerial.Focus();
                        }
                        else
                        {
                            lblStatus.Text = "Khong ton tai Model voi Outer carton nay";

                            txtRescan.Clear();
                            txtRescan.Focus();
                            txtSerial.Clear();
                            lblStatus.ForeColor = Color.Red;
                            lblStatus.BackColor = Color.Yellow;
                            mdaShrink.URL = @"C:\audio\NG.wav";
                        }


                    }
                }
            }
        }

        private void txtQtyPalletFix_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {

                if (txtScanned.Text == "")
                    txtScanned.Text = "0";
                if (txtQtyPalletFix.Text == "")
                {
                    MessageBox.Show("Ban chua nhap so luong Pallet!");
                    txtQtyPalletFix.Focus();
                    txtQtyPalletFix.Select();
                }
                else 
                {
                    if (int.Parse(txtQtyPalletFix.Text) == 0 || int.Parse(txtQtyPalletFix.Text) < int.Parse(txtScanned.Text))
                    {
                        MessageBox.Show("Vui lòng nhập lại số lượng trên Pallet");
                        txtQtyPalletFix.Focus();
                        txtQtyPalletFix.SelectAll();

                    }
                    else
                    {
                        if (MessageBox.Show("Bạn chắc chắn số lượng Pallet la " + txtQtyPalletFix.Text, "Số lượng Pallet",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                        {
                            groupBox2.Enabled = true;
                            //txtQtyPalletFix.Enabled = false;
                            txtRescan.Focus();
                            txtRescan.SelectAll();
                            btnEditQty.Enabled = true;
                        }
                        else
                        {
                            txtQtyPalletFix.Focus();
                            txtQtyPalletFix.SelectAll();
                        }
                    }
                }
                
            }
        }

        //phai nhap kieu so
        private void txtQtyPalletFix_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!Char.IsDigit(e.KeyChar) && !Char.IsControl(e.KeyChar))
                e.Handled = true;


        }


        private void btnEditQty_Click(object sender, EventArgs e)
        {

            frm_ConfrimUser frm = new frm_ConfrimUser();
            frm.ShowDialog();

            // myValue = Interaction.InputBox("Bạn muốn thay đổi số lượng trên Pallet", "Thông báo", "Nhập user admin", 100, 100);

            if (Untility._para.Pass_Admin == "Admin123")
            {
                txtQtyPalletFix.Enabled = true;
                txtQtyPalletFix.Focus();
                txtQtyPalletFix.SelectAll();
                groupBox2.Enabled = false;
            }
            else
            {
                lblStatus.Text = "KHÔNG ĐÚNG ADMIN";
                lblStatus.ForeColor = Color.Red;
                lblStatus.BackColor = Color.Yellow;
                groupBox2.Enabled = true;
                txtRescan.Focus();
            }
        }

        private void chk_Outer_carton_CheckedChanged(object sender, EventArgs e)
        {
            if (chk_Outer_carton.Checked == true)
            {
                numericUpDown1.Enabled = true;
                numericUpDown1.Focus();
                lbl_ScanModelAgain.Text = "Scan Outer Carton";
                lblSerial.Text = "Scan Serial Outer";
                groupBox2.Enabled = false;
                listView1.Visible = true;
                if (numericUpDown1.Value <= 0)
                {
                    MessageBox.Show("Vui long nhap so luong tieu chuan cua Outer Carton");
                }
            }
            else
            {
                numericUpDown1.Value = 0;
                listView1.Visible = false;
                groupBox2.Enabled = true;
                lbl_ScanModelAgain.Text = "Scan lại model";
                lblSerial.Text = "Số SERIAL";
                txtRescan.Focus();
            }
        }

        private void numericUpDown1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (numericUpDown1.Value <= 0)
                {
                    MessageBox.Show("Ban chua nhap so luong tieu chuan OuterCarton");
                    numericUpDown1.Focus();
                }
                else
                {
                    if (MessageBox.Show("Bạn chắc chắn số lượng Outer Carton la " + numericUpDown1.Value, "Số lượng OuterCarton",
                                    MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        //edit for cate sound beat 10.2021
                        if (lblCategory.Text.ToString() == "HP")
                        {
                            groupBox2.Enabled = true;
                            numericUpDown1.Enabled = false;
                            btnEditQty.Enabled = true;

                            //Chi scan serial outer not scan outer caton
                            txtRescan.Enabled=false;
                            txtSerial.Focus();
                            txtSerial.SelectAll();
                            
                            
                        }
                        else
                        {
                            groupBox2.Enabled = true;
                            numericUpDown1.Enabled = false;
                            txtRescan.Focus();
                            txtRescan.SelectAll();
                            btnEditQty.Enabled = true;
                        }
                        
                    }
                    else
                    {
                        numericUpDown1.Focus();
                    }
                }
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            frm_ConfrimUser frm = new frm_ConfrimUser();
            frm.ShowDialog();

            // myValue = Interaction.InputBox("Bạn muốn thay đổi số lượng trên Pallet", "Thông báo", "Nhập user admin", 100, 100);

            if (Untility._para.Pass_Admin == "Admin123")
            {
                numericUpDown1.Enabled = true;
                numericUpDown1.Focus();
                groupBox2.Enabled = false;
            }
            else
            {
                lblStatus.Text = "KHÔNG ĐÚNG ADMIN";
                lblStatus.ForeColor = Color.Red;
                lblStatus.BackColor = Color.Yellow;
                groupBox2.Enabled = true;
                txtRescan.Focus();
            }
        }




    }
}
