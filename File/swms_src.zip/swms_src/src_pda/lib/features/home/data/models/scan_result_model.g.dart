// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'scan_result_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ScanResultModel _$ScanResultModelFromJson(Map<String, dynamic> json) =>
    ScanResultModel(
      code: json['code'] as String,
      type: json['type'] as String,
      id: (json['id'] as num?)?.toInt(),
      areaCode: json['areaCode'] as String?,
      partCard: json['partCard'] == null
          ? null
          : PartCardScanInfoModel.fromJson(
              json['partCard'] as Map<String, dynamic>,
            ),
    );

Map<String, dynamic> _$ScanResultModelToJson(ScanResultModel instance) =>
    <String, dynamic>{
      'code': instance.code,
      'type': instance.type,
      'id': ?instance.id,
      'areaCode': ?instance.areaCode,
      'partCard': ?instance.partCard?.toJson(),
    };

PartCardScanInfoModel _$PartCardScanInfoModelFromJson(
  Map<String, dynamic> json,
) => PartCardScanInfoModel(
  cardId: json['cardId'] as String?,
  modelCount: (json['modelCount'] as num?)?.toInt(),
  boxCount: (json['boxCount'] as num?)?.toInt(),
  isLocked: json['isLocked'] as bool?,
  statusOqc: (json['statusOqc'] as num?)?.toInt(),
  canEdit: json['canEdit'] as bool?,
  canSplit: json['canSplit'] as bool?,
  canMerge: json['canMerge'] as bool?,
);

Map<String, dynamic> _$PartCardScanInfoModelToJson(
  PartCardScanInfoModel instance,
) => <String, dynamic>{
  'cardId': ?instance.cardId,
  'modelCount': ?instance.modelCount,
  'boxCount': ?instance.boxCount,
  'isLocked': ?instance.isLocked,
  'statusOqc': ?instance.statusOqc,
  'canEdit': ?instance.canEdit,
  'canSplit': ?instance.canSplit,
  'canMerge': ?instance.canMerge,
};
