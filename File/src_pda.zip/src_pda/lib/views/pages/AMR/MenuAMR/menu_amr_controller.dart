
import 'package:injectable/injectable.dart';
import 'package:smart_warehouse/shared/base/base_cubit.dart';
import 'menu_amr_state.dart';

@injectable
class MenuAmrController extends BaseCubit<MenuAmrState>
{
  MenuAmrController() : super(MenuAmrState());
  @override
  Future<void> initData() {
    return launch(() async {

    });
  }
}