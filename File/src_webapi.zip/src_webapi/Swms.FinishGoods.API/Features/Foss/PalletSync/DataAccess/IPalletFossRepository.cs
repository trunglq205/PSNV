using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;

namespace Swms.FinishGoods.API.Features.Foss.PalletSync.DataAccess
{
    /// <summary>Ghi / đọc wms.pallets phục vụ đồng bộ Foss. Phần SWMS thuần ở ILotRepository.</summary>
    public interface IPalletFossRepository
    {
        // ── Bổ sung thùng ──

        /// <summary>
        /// Chèn thùng / serial Foss thêm vào sau khi SWMS đã tạo pallet. Bỏ qua box_no / serial
        /// đã nằm trên pallet active bất kỳ, trả kèm lý do từng thùng bị bỏ qua.
        /// </summary>
        Task<FossAppendResult> AppendFossBoxesAsync(
            long lotId,
            IReadOnlyList<Box> newBoxes,
            IReadOnlyList<(long BoxId, BoxLine Line)> newLines,
            int? standardPallet,
            string user,
            StockEventContext ctx);

        /// <summary>Pallet Foss có thể còn thiếu thùng (chưa chẵn, tạo trong cửa sổ, chưa xuất).</summary>
        Task<List<string>> GetFossTopUpCandidatesAsync(DateTime createdSince);

        /// <summary>Số thùng / serial đang có trên SWMS cho cả nhóm — so với Foss để lọc ứng viên.</summary>
        Task<Dictionary<string, PalletContentCount>> GetContentCountsAsync(IReadOnlyCollection<string> lotNos);

        // ── OQC ──

        /// <summary>
        /// Ghi oqc_status theo box_id + inspection_status của pallet trong 1 transaction.
        /// Trả số thùng đã cập nhật.
        /// </summary>
        Task<int> UpdateOqcStatusAsync(
            long lotId,
            IReadOnlyDictionary<long, int> boxStatuses,
            string inspectionStatus,
            string? user,
            StockEventContext? ctx = null);

        /// <summary>Pallet còn tồn, có thùng, chưa có kết quả OQC cuối — cũ nhất trước.</summary>
        Task<List<string>> GetLotNosNeedingOqcAsync(IReadOnlyCollection<string> finalStatuses);
    }
}
