import 'package:injectable/injectable.dart';
import 'package:package_info_plus/package_info_plus.dart';

@singleton
class PackageInfoManager {
  Future<String> getVersion() async {
    final packageInfo = await PackageInfo.fromPlatform();

    return '${packageInfo.version}+${packageInfo.buildNumber}';
  }

}