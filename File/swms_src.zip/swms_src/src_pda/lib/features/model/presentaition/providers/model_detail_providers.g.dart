// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'model_detail_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(modelDetailRemoteDataSource)
final modelDetailRemoteDataSourceProvider =
    ModelDetailRemoteDataSourceProvider._();

final class ModelDetailRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ModelDetailRemoteDataSource,
          ModelDetailRemoteDataSource,
          ModelDetailRemoteDataSource
        >
    with $Provider<ModelDetailRemoteDataSource> {
  ModelDetailRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'modelDetailRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$modelDetailRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ModelDetailRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ModelDetailRemoteDataSource create(Ref ref) {
    return modelDetailRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ModelDetailRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ModelDetailRemoteDataSource>(value),
    );
  }
}

String _$modelDetailRemoteDataSourceHash() =>
    r'71d47fd10cce8dc38f6a6847fee1c968dfa54b4c';

@ProviderFor(modelDetailRepository)
final modelDetailRepositoryProvider = ModelDetailRepositoryProvider._();

final class ModelDetailRepositoryProvider
    extends
        $FunctionalProvider<
          ModelDetailRepository,
          ModelDetailRepository,
          ModelDetailRepository
        >
    with $Provider<ModelDetailRepository> {
  ModelDetailRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'modelDetailRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$modelDetailRepositoryHash();

  @$internal
  @override
  $ProviderElement<ModelDetailRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ModelDetailRepository create(Ref ref) {
    return modelDetailRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ModelDetailRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ModelDetailRepository>(value),
    );
  }
}

String _$modelDetailRepositoryHash() =>
    r'722fc3ef441ead8b99d12d56838355c60ce45c63';
