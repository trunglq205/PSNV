import 'dart:io';

import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';

import 'package:swms_finish_goods/features/vanning/data/models/merge_session_model.dart';
import 'package:swms_finish_goods/features/vanning/data/models/trip_evidence_model.dart';
import 'package:swms_finish_goods/features/vanning/data/models/trip_model.dart';
import 'package:swms_finish_goods/features/vanning/data/models/trip_stowage_model.dart';

part 'vanning_remote_data_source.g.dart';

/// Vanning theo chuyến xe — mọi endpoint nằm dưới /shipment-trips:
///   ShipmentTripsController  danh sách chuyến          Trip.View
///   TripPhotosController     ảnh minh chứng           Trip.View / Trip.PhotoUpload
///   TripVanningController    kiểm cont · gộp pallet   Trip.Inspect / Trip.Merge
@RestApi()
abstract class VanningRemoteDataSource {
  factory VanningRemoteDataSource(Dio dio, {String baseUrl}) =
  _VanningRemoteDataSource;

  // ── Chuyến ─────────────────────────────────────────────────
  /// from / to: yyyy-MM-dd. q: số cont / biển số / mã chuyến.
  @GET('/api/shipment-trips')
  Future<List<TripModel>> fetchTrips({
    @Query('from') String? from,
    @Query('to') String? to,
    @Query('q') String? q,
  });

  /// Màn Pallet List: quét pallet trước → chuyến còn mở có kế hoạch vanning chứa pallet
  /// (pallet → SI → chuyến → Stowage Plan). Không có → server báo lỗi.
  @GET('/api/shipment-trips/by-pallet/{code}')
  Future<List<TripModel>> fetchTripsByPallet(@Path('code') String code);

  // ── Ảnh minh chứng + kiểm cont ─────────────────────────────
  @GET('/api/shipment-trips/{id}/photos')
  Future<TripEvidenceModel> fetchEvidence(@Path('id') int tripId);

  /// 1 ảnh / lần: chụp xong gửi luôn, mạng chậm chỉ chậm đúng ô đó.
  /// Đơn vị: palletCode (ảnh theo pallet) hoặc unitNo (cọc / hàng); cả 2 null = theo chuyến.
  /// Retrofit bỏ part null.
  @POST('/api/shipment-trips/{id}/photos')
  @MultiPart()
  Future<TripPhotoModel> uploadPhoto(
      @Path('id') int tripId,
      @Part(name: 'file') File file,
      @Part(name: 'itemKey') String itemKey,
      @Part(name: 'unitNo') String? unitNo,
      @Part(name: 'palletCode') String? palletCode,
      @Part(name: 'slotNo') String slotNo,
      );

  @DELETE('/api/shipment-trips/photos/{photoId}')
  Future<void> deletePhoto(@Path('photoId') int photoId);

  @GET('/api/shipment-trips/photos/{photoId}')
  @DioResponseType(ResponseType.bytes)
  Future<List<int>> photoBytes(
      @Path('photoId') int photoId,
      @Query('size') String size,
      );

  @POST('/api/shipment-trips/{id}/inspection')
  Future<TripInspectionModel> submitInspection(
      @Path('id') int tripId,
      @Body() TripInspectionRequestModel body,
      );

  // ── Gộp pallet ─────────────────────────────────────────────
  @GET('/api/shipment-trips/{id}/merge/{baseCode}')
  Future<MergeSessionModel> openSession(
      @Path('id') int tripId,
      @Path('baseCode') String baseCode,
      );

  @GET('/api/shipment-trips/{id}/merge/{baseCode}/items/{code}')
  Future<MergeCandidateModel> lookupItem(
      @Path('id') int tripId,
      @Path('baseCode') String baseCode,
      @Path('code') String code,
      );

  @POST('/api/shipment-trips/{id}/merge')
  Future<MergeResultModel> merge(
      @Path('id') int tripId,
      @Body() MergeRequestModel body,
      );

  // ── Stowage Plan của chuyến: ghép cọc · xếp cont ───────────
  @GET('/api/shipment-trips/{id}/stowage')
  Future<TripStowageModel> fetchStowage(@Path('id') int tripId);

  @POST('/api/shipment-trips/{id}/stowage/columns/{code}/stack')
  Future<TripStowageModel> stackColumn(
      @Path('id') int tripId,
      @Path('code') String code,
      @Body() StowageCodesRequestModel body,
      );

  @POST('/api/shipment-trips/{id}/stowage/columns/{code}/place')
  Future<TripStowageModel> placeColumn(
      @Path('id') int tripId,
      @Path('code') String code,
      @Body() StowageCodesRequestModel body,
      );

  @DELETE('/api/shipment-trips/{id}/stowage/columns/{code}')
  Future<TripStowageModel> clearColumn(
      @Path('id') int tripId,
      @Path('code') String code,
      );
}