namespace Swms.FinishGoods.API.Features.Foss.DataAccess;

public interface IFossPalletRepository
{
    /// <summary>
    /// Query bảng combine của Foss theo category (repo tự dựng tên bảng) và barcode pallet.
    /// </summary>
    Task<IReadOnlyList<FossPalletRow>> GetByBarcodeAsync(FossCategory category, string barcode);

    Task<IReadOnlyList<string>> GetTodayPalletsAsync();

    Task<IReadOnlyList<FossPalletSummary>> GetPalletSummariesAsync(
        FossCategory category, IReadOnlyCollection<string> barcodes);
}
