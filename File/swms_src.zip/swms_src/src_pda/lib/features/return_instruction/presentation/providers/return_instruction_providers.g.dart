// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'return_instruction_providers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(returnInstructionRemoteDataSource)
final returnInstructionRemoteDataSourceProvider =
    ReturnInstructionRemoteDataSourceProvider._();

final class ReturnInstructionRemoteDataSourceProvider
    extends
        $FunctionalProvider<
          ReturnInstructionRemoteDataSource,
          ReturnInstructionRemoteDataSource,
          ReturnInstructionRemoteDataSource
        >
    with $Provider<ReturnInstructionRemoteDataSource> {
  ReturnInstructionRemoteDataSourceProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'returnInstructionRemoteDataSourceProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() =>
      _$returnInstructionRemoteDataSourceHash();

  @$internal
  @override
  $ProviderElement<ReturnInstructionRemoteDataSource> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ReturnInstructionRemoteDataSource create(Ref ref) {
    return returnInstructionRemoteDataSource(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReturnInstructionRemoteDataSource value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReturnInstructionRemoteDataSource>(
        value,
      ),
    );
  }
}

String _$returnInstructionRemoteDataSourceHash() =>
    r'793e531df34677d1a5ed9e0473ef115e67651441';

@ProviderFor(returnInstructionRepository)
final returnInstructionRepositoryProvider =
    ReturnInstructionRepositoryProvider._();

final class ReturnInstructionRepositoryProvider
    extends
        $FunctionalProvider<
          ReturnInstructionRepository,
          ReturnInstructionRepository,
          ReturnInstructionRepository
        >
    with $Provider<ReturnInstructionRepository> {
  ReturnInstructionRepositoryProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'returnInstructionRepositoryProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$returnInstructionRepositoryHash();

  @$internal
  @override
  $ProviderElement<ReturnInstructionRepository> $createElement(
    $ProviderPointer pointer,
  ) => $ProviderElement(pointer);

  @override
  ReturnInstructionRepository create(Ref ref) {
    return returnInstructionRepository(ref);
  }

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ReturnInstructionRepository value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ReturnInstructionRepository>(value),
    );
  }
}

String _$returnInstructionRepositoryHash() =>
    r'f0683a7448eac40d2d7f82cdf85b02b95dfa5e3d';

/// Danh sách chỉ thị theo bộ lọc.
///
/// [filterName] là `ReturnFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build — cùng
/// cái bẫy đã ghi ở `stocky_providers.dart`.

@ProviderFor(returnInstructionList)
final returnInstructionListProvider = ReturnInstructionListFamily._();

/// Danh sách chỉ thị theo bộ lọc.
///
/// [filterName] là `ReturnFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build — cùng
/// cái bẫy đã ghi ở `stocky_providers.dart`.

final class ReturnInstructionListProvider
    extends
        $FunctionalProvider<
          AsyncValue<List<ReturnInstruction>>,
          List<ReturnInstruction>,
          FutureOr<List<ReturnInstruction>>
        >
    with
        $FutureModifier<List<ReturnInstruction>>,
        $FutureProvider<List<ReturnInstruction>> {
  /// Danh sách chỉ thị theo bộ lọc.
  ///
  /// [filterName] là `ReturnFilter.name` chứ không phải chính enum: tham số
  /// family phải so sánh được bằng `==` và ổn định giữa các lần build — cùng
  /// cái bẫy đã ghi ở `stocky_providers.dart`.
  ReturnInstructionListProvider._({
    required ReturnInstructionListFamily super.from,
    required String super.argument,
  }) : super(
         retry: null,
         name: r'returnInstructionListProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$returnInstructionListHash();

  @override
  String toString() {
    return r'returnInstructionListProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<List<ReturnInstruction>> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<List<ReturnInstruction>> create(Ref ref) {
    final argument = this.argument as String;
    return returnInstructionList(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is ReturnInstructionListProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$returnInstructionListHash() =>
    r'b895d7d132bec33aaeebc293834114b3a15d7034';

/// Danh sách chỉ thị theo bộ lọc.
///
/// [filterName] là `ReturnFilter.name` chứ không phải chính enum: tham số
/// family phải so sánh được bằng `==` và ổn định giữa các lần build — cùng
/// cái bẫy đã ghi ở `stocky_providers.dart`.

final class ReturnInstructionListFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<List<ReturnInstruction>>, String> {
  ReturnInstructionListFamily._()
    : super(
        retry: null,
        name: r'returnInstructionListProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Danh sách chỉ thị theo bộ lọc.
  ///
  /// [filterName] là `ReturnFilter.name` chứ không phải chính enum: tham số
  /// family phải so sánh được bằng `==` và ổn định giữa các lần build — cùng
  /// cái bẫy đã ghi ở `stocky_providers.dart`.

  ReturnInstructionListProvider call(String filterName) =>
      ReturnInstructionListProvider._(argument: filterName, from: this);

  @override
  String toString() => r'returnInstructionListProvider';
}

/// Một phiếu, đọc lại khi mở màn Nhận hàng back.
///
/// Màn đó KHÔNG nhận phiếu qua tham số điều hướng: máy khác có thể vừa quét
/// thêm, mà "còn phải nhận bao nhiêu" phải tính từ số mới nhất.

@ProviderFor(returnInstructionDetail)
final returnInstructionDetailProvider = ReturnInstructionDetailFamily._();

/// Một phiếu, đọc lại khi mở màn Nhận hàng back.
///
/// Màn đó KHÔNG nhận phiếu qua tham số điều hướng: máy khác có thể vừa quét
/// thêm, mà "còn phải nhận bao nhiêu" phải tính từ số mới nhất.

final class ReturnInstructionDetailProvider
    extends
        $FunctionalProvider<
          AsyncValue<ReturnInstruction>,
          ReturnInstruction,
          FutureOr<ReturnInstruction>
        >
    with
        $FutureModifier<ReturnInstruction>,
        $FutureProvider<ReturnInstruction> {
  /// Một phiếu, đọc lại khi mở màn Nhận hàng back.
  ///
  /// Màn đó KHÔNG nhận phiếu qua tham số điều hướng: máy khác có thể vừa quét
  /// thêm, mà "còn phải nhận bao nhiêu" phải tính từ số mới nhất.
  ReturnInstructionDetailProvider._({
    required ReturnInstructionDetailFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'returnInstructionDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$returnInstructionDetailHash();

  @override
  String toString() {
    return r'returnInstructionDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  $FutureProviderElement<ReturnInstruction> $createElement(
    $ProviderPointer pointer,
  ) => $FutureProviderElement(pointer);

  @override
  FutureOr<ReturnInstruction> create(Ref ref) {
    final argument = this.argument as int;
    return returnInstructionDetail(ref, argument);
  }

  @override
  bool operator ==(Object other) {
    return other is ReturnInstructionDetailProvider &&
        other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$returnInstructionDetailHash() =>
    r'0000000000000000000000000000000000000000';

/// Một phiếu, đọc lại khi mở màn Nhận hàng back.
///
/// Màn đó KHÔNG nhận phiếu qua tham số điều hướng: máy khác có thể vừa quét
/// thêm, mà "còn phải nhận bao nhiêu" phải tính từ số mới nhất.

final class ReturnInstructionDetailFamily extends $Family
    with $FunctionalFamilyOverride<FutureOr<ReturnInstruction>, int> {
  ReturnInstructionDetailFamily._()
    : super(
        retry: null,
        name: r'returnInstructionDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Một phiếu, đọc lại khi mở màn Nhận hàng back.
  ///
  /// Màn đó KHÔNG nhận phiếu qua tham số điều hướng: máy khác có thể vừa quét
  /// thêm, mà "còn phải nhận bao nhiêu" phải tính từ số mới nhất.

  ReturnInstructionDetailProvider call(int docId) =>
      ReturnInstructionDetailProvider._(argument: docId, from: this);

  @override
  String toString() => r'returnInstructionDetailProvider';
}
