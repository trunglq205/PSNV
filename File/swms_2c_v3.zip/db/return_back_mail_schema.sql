/* =====================================================================
   return_back_mail_schema.sql
   Mục 2c — 2 sự kiện mail cho luồng "Chỉ thị back hàng" (3 bước).

   CHẠY SAU return_back_v2_schema.sql.
   Chạy lại nhiều lần không sao: chỉ INSERT khi chưa có, và chỉ cập nhật
   mẫu khi CHƯA AI SỬA TAY (updated_at còn NULL).

   ---------------------------------------------------------------------
   CHỈ HAI LÁ MAIL — đúng hai chỗ hàng đổi tay giữa hai bộ phận:

     RETURN_BACK_FA_APPROVED   quản lý FA xác nhận
                               -> TO: SCS Office   CC: FA
                               SCS Office tự thông báo cho SCS WH (ngoài
                               hệ thống), nên không có mail cho WH.

     RETURN_BACK_DELIVERED     SCS WH quét Pallet ID giao hàng xong
                               -> TO: FA           CC: SCS

   FA tạo yêu cầu (B1) KHÔNG gửi mail: quản lý FA ngồi cùng bộ phận, mở
   màn hình ra là thấy hàng đợi.

   Script này cũng DỌN 3 sự kiện của bản 4 bước trước đó
   (RETURN_BACK_REQUESTED / _INSTRUCTED / _APPROVED) nếu chúng còn, và
   chỉ dọn khi chưa ai khai người nhận lẫn sửa mẫu — xem mục 3.
   ---------------------------------------------------------------------
   MẪU VIẾT BẰNG MARKDOWN, KHÔNG PHẢI HTML: API dựng HTML lúc gửi
   (MarkdownMail.cs), web xem trước bằng cùng pipeline Markdig, cả hai
   đều bật DisableHtml ⇒ thẻ HTML nhét vào đây HIỆN RA THÀNH CHỮ.

   Bảng markdown phải có dòng trắng TRƯỚC và SAU. {LinesTable} và
   {PalletTable} do API dựng đã tự kèm hai dòng trắng đó.
   ===================================================================== */

SET NOCOUNT ON;
SET XACT_ABORT ON;

DECLARE @WhatIf bit = 0;

IF OBJECT_ID(N'master.email_events', N'U') IS NULL
BEGIN
    RAISERROR(N'Khong tim thay master.email_events.', 16, 1);
    RETURN;
END

SELECT N'0. Hien trang' AS section;
SELECT  ma         = v.code,
        can_dung   = v.con_dung,
        tinh_trang = IIF(e.code IS NULL, N'chua co', N'DA CO'),
        da_sua_tay = IIF(e.code IS NULL, N'', IIF(e.updated_at IS NULL, N'khong', N'CO')),
        nguoi_nhan = ISNULL((SELECT COUNT(*) FROM master.email_config c
                             WHERE c.event_code = v.code
                                   AND c.is_active = 1 AND c.is_deleted = 0), 0)
FROM   (VALUES (N'RETURN_BACK_FA_APPROVED', N'CO'),
               (N'RETURN_BACK_DELIVERED',   N'CO'),
               (N'RETURN_BACK_REQUESTED',   N'khong — ban 4 buoc'),
               (N'RETURN_BACK_INSTRUCTED',  N'khong — ban 4 buoc'),
               (N'RETURN_BACK_APPROVED',    N'khong — ban 4 buoc')) v(code, con_dung)
LEFT   JOIN master.email_events e ON e.code = v.code;

IF @WhatIf = 1
BEGIN
    SELECT N'WhatIf = 1 — chua ghi gi.' AS ket_qua;
    RETURN;
END

BEGIN TRAN;

/* =====================================================================
   1 — Quản lý FA xác nhận. TO: SCS Office, CC: FA.

   Lá mail này là lời ĐỀ NGHỊ gửi sang SCS: "FA cần lấy phiếu này về".
   Vì đã chốt là lấy TOÀN BỘ phiếu nên bảng dưới là toàn bộ model của
   phiếu, không còn chuyện xin một phần.
   ===================================================================== */
DECLARE @subj_fa NVARCHAR(500) =
    N'[SWMS] FA đề nghị nhận lại hàng {GoodsType} — chỉ thị {DocNo} ({TotalQty} con)';

DECLARE @body_fa NVARCHAR(MAX) = N'Kính gửi SCS Office,

Quản lý FA đã xác nhận đề nghị nhận lại hàng **{ReqNo}** cho chỉ thị **{DocNo}**.
Nhờ SCS thông báo kho chuẩn bị giao **toàn bộ** số hàng dưới đây.

| Thông tin | Nội dung |
|---|---|
| Chỉ thị nhận hàng | **{DocNo}** ({GoodsType}) |
| Số model | {ModelCount} |
| **Tổng số lượng** | **{TotalQty}** |
| Người đề nghị | {RequestedBy} — {RequestedAt} |
| Quản lý FA xác nhận | {FaApprovedBy} — {FaApprovedAt} |

**Chi tiết theo model:**
{LinesTable}
Ghi chú: {Note}

Ý kiến quản lý FA: {FaComment}

Xem trên hệ thống: {Link}

*Mail tự động từ SWMS Finish Goods — {Now}*';

/* =====================================================================
   2 — SCS WH giao hàng xong. TO: FA, CC: SCS.

   Gửi MỘT lá cho MỘT lượt xác nhận, không phải mỗi pallet một lá: WH
   quét nhiều pallet rồi bấm xác nhận một lần.

   {PalletTable} là danh sách pallet vừa giao trong LƯỢT NÀY — thứ FA cần
   để đi nhận đúng pallet. {RemainQty} nói còn bao nhiêu con chưa giao;
   bằng 0 là xong cả yêu cầu.
   ===================================================================== */
DECLARE @subj_dl NVARCHAR(500) =
    N'[SWMS] SCS đã giao {DeliveredQty} con hàng {GoodsType} cho FA — {DocNo}';

DECLARE @body_dl NVARCHAR(MAX) = N'Kính gửi FA,

SCS Warehouse vừa giao hàng của đề nghị **{ReqNo}** (chỉ thị **{DocNo}**).

| Thông tin | Nội dung |
|---|---|
| Chỉ thị nhận hàng | **{DocNo}** ({GoodsType}) |
| **Số lượng giao lượt này** | **{DeliveredQty}** |
| Số pallet giao lượt này | {PalletCount} |
| Đã giao / tổng đề nghị | {AtFaQty} / {TotalQty} |
| Còn chưa giao | **{RemainQty}** |
| Người giao | {DeliveredBy} — {DeliveredAt} |

**Pallet đã giao lượt này:**
{PalletTable}
Ghi chú của kho: {ScsComment}

Nhờ FA nhận hàng và khi rework xong thì đóng lại Pallet ID trên PDA.

Xem trên hệ thống: {Link}

*Mail tự động từ SWMS Finish Goods — {Now}*';

/* ---------- Ghi 2 sự kiện ---------- */
DECLARE @events TABLE
(
    code  nvarchar(100),
    descr nvarchar(400),
    subj  nvarchar(500),
    body  nvarchar(MAX),
    ord   int
);

INSERT INTO @events (code, descr, subj, body, ord)
VALUES
    (N'RETURN_BACK_FA_APPROVED',
     N'Mục 2c — quản lý FA xác nhận đề nghị nhận lại hàng. TO: SCS Office, CC: FA',
     @subj_fa, @body_fa, 1),
    (N'RETURN_BACK_DELIVERED',
     N'Mục 2c — SCS WH quét Pallet ID giao hàng cho FA xong. TO: FA, CC: SCS',
     @subj_dl, @body_dl, 2);

DECLARE @base int =
    (SELECT ISNULL(MAX(sort_order), 0) FROM master.email_events WHERE module = N'RECEIVING');

INSERT INTO master.email_events
    (code, module, name_key, description, subject_template, body_template,
     is_active, sort_order)
SELECT  e.code, N'RECEIVING', N'email.' + e.code, e.descr, e.subj, e.body,
        1, @base + e.ord
FROM    @events e
WHERE   NOT EXISTS (SELECT 1 FROM master.email_events x WHERE x.code = e.code);

PRINT CONCAT(N'Da them ', @@ROWCOUNT, N' su kien mail moi');

/* Đã có sẵn: chỉ đè mẫu khi CHƯA ai sửa tay — sửa tay rồi mà script đè lại thì
   công người ta khai mất sạch. */
UPDATE  t
SET     t.subject_template = e.subj,
        t.body_template    = e.body,
        t.description      = e.descr
FROM    master.email_events t
JOIN    @events e ON e.code = t.code
WHERE   t.updated_at IS NULL;

PRINT CONCAT(N'Da cap nhat mau cho ', @@ROWCOUNT, N' su kien (chua ai sua tay)');

/* =====================================================================
   3. Dọn 3 sự kiện của bản 4 bước

   CHỈ xoá khi vừa chưa ai khai người nhận, vừa chưa ai sửa mẫu — nếu đã
   có một trong hai thì đó là công người ta làm, chỉ TẮT (is_active = 0)
   để không gửi nữa mà vẫn giữ lại.
   ===================================================================== */
DECLARE @dead TABLE (code nvarchar(100));
INSERT INTO @dead (code)
VALUES (N'RETURN_BACK_REQUESTED'), (N'RETURN_BACK_INSTRUCTED'), (N'RETURN_BACK_APPROVED');

/* Tắt trước — áp cho mọi dòng còn lại, kể cả dòng sẽ bị xoá ngay dưới. */
UPDATE  e
SET     e.is_active = 0
FROM    master.email_events e
JOIN    @dead d ON d.code = e.code
WHERE   e.is_active = 1;

PRINT CONCAT(N'Da TAT ', @@ROWCOUNT, N' su kien cua ban 4 buoc');

DELETE  e
FROM    master.email_events e
JOIN    @dead d ON d.code = e.code
WHERE   e.updated_at IS NULL
        AND NOT EXISTS (SELECT 1 FROM master.email_config c
                        WHERE c.event_code = e.code AND c.is_deleted = 0);

PRINT CONCAT(N'Da XOA ', @@ROWCOUNT, N' su kien cua ban 4 buoc (chua ai dung)');

COMMIT;

/* ---------- 4. Kiểm lại ---------- */
SELECT N'1. Ket qua' AS section;
SELECT  ma           = e.code,
        mo_ta        = e.description,
        dang_bat     = IIF(e.is_active = 1, N'co', N'KHONG'),
        da_sua_tay   = IIF(e.updated_at IS NULL, N'khong', N'CO'),
        con_the_html = IIF(e.body_template LIKE N'%<p>%'
                           OR e.body_template LIKE N'%<table%'
                           OR e.body_template LIKE N'%<br%',
                           N'CON — sua lai bang markdown', N'khong'),
        so_nguoi_nhan = (SELECT COUNT(*) FROM master.email_config c
                         WHERE c.event_code = e.code
                               AND c.is_active = 1 AND c.is_deleted = 0)
FROM    master.email_events e
WHERE   e.code LIKE N'RETURN_BACK%'
ORDER BY e.sort_order;

SELECT N'2. Viec con phai lam tay' AS section;
SELECT N'Mo man Tai gia cong -> tab Yeu cau back hang -> banh rang, khai nguoi nhan:' AS ghi_chu
UNION ALL
SELECT N'  · RETURN_BACK_FA_APPROVED : TO = SCS Office, CC = FA'
UNION ALL
SELECT N'  · RETURN_BACK_DELIVERED   : TO = FA,         CC = SCS'
UNION ALL
SELECT N'Khong co dong TO nao dang bat thi KHONG gui — do la cach tat mail cua mot buoc.';
