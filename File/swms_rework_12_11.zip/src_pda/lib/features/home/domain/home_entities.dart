import 'package:flutter/material.dart';

// ─────────────────────────────────────────────────────────────
//  Entities cho feature Home.
//  Lưu ý i18n: các trường *Key là KEY dịch (LocaleKeys.*) — UI gọi
//  .tr() khi render. Giá trị động từ API (id, code, giờ) giữ nguyên.
// ─────────────────────────────────────────────────────────────

/// Một mục công việc đang chờ của nhân viên.
class AssignmentData {
  final String id; // định danh từ API, dùng để điều hướng
  final String labelKey; // LocaleKeys.home_task_picking
  final IconData icon;
  final String code; // "SI-2026-0506-018"
  final String subKey; // key mô tả; args truyền khi .tr()
  final List<String> subArgs;
  final String deadlineText; // "15:30 · còn 58′"
  final bool urgent;
  final int done;
  final int total;
  final String unitKey; // LocaleKeys.home_unit_box / _location
  final Color tone;
  final Color toneBg;

  const AssignmentData({
    required this.id,
    required this.labelKey,
    required this.icon,
    required this.code,
    required this.subKey,
    required this.deadlineText,
    required this.done,
    required this.total,
    required this.unitKey,
    required this.tone,
    required this.toneBg,
    this.subArgs = const [],
    this.urgent = false,
  });

  double get progress => total == 0 ? 0 : done / total;
}

/// Một thẻ chức năng nhỏ trong cụm.
class FeatureItem {
  final String key;
  final String nameKey;
  final IconData icon;
  final String? routeName;

  /// Bỏ qua lọc quyền — luôn hiện (viewer read-only như Sơ đồ kho).
  final bool alwaysVisible;

  /// Màn mở bằng `MaterialPageRoute` thay vì route sinh tự động.
  ///
  /// Vì sao cần: thêm một `@RoutePage` là phải sinh lại `app_router.gr.dart`,
  /// mà `build_runner` trong source hiện tại đang vỡ (hai file cùng khai
  /// `@RoutePage() class VanningPage`). Cả bộ mục 2c/2d vì vậy cố ý không thêm
  /// route mới. Trang chủ đọc cờ này rồi tự push màn tương ứng.
  ///
  /// KHÔNG dùng [key] làm cờ: [key] là MÃ QUYỀN, hai ô có thể trùng mã quyền.
  final String? localScreen;

  const FeatureItem({
    required this.key,
    required this.nameKey,
    required this.icon,
    this.routeName,
    this.alwaysVisible = false,
    this.localScreen,
  });
}

/// Mã các màn mở bằng `MaterialPageRoute` — xem [FeatureItem.localScreen].
///
/// Để thành hằng chứ không viết chuỗi trần ở hai nơi: gõ sai một chữ thì ô
/// chức năng bấm vào KHÔNG LÀM GÌ CẢ, và không có lỗi nào để lần ra.
class HomeLocalScreens {
  const HomeLocalScreens._();

  /// FA nhận hàng RW/RB (B5 của luồng back).
  static const String faPickup = 'fa_pickup';
}

/// Một cụm chức năng (Nhận hàng, Lưu kho, …).
class FeatureGroup {
  final String key;
  final String titleKey;
  final Color tone;
  final Color toneBg;
  final List<FeatureItem> items;

  const FeatureGroup({
    required this.key,
    required this.titleKey,
    required this.tone,
    required this.toneBg,
    required this.items,
  });

  FeatureGroup copyWith({
    String? key,
    String? titleKey,
    Color? tone,
    Color? toneBg,
    List<FeatureItem>? items,
  }) {
    return FeatureGroup(
      key: key ?? this.key,
      titleKey: titleKey ?? this.titleKey,
      tone: tone ?? this.tone,
      toneBg: toneBg ?? this.toneBg,
      items: items ?? this.items,
    );
  }
}

/// Cụm kèm số thứ tự gốc (để giữ số khi ghim nổi lên đầu).
class OrderedGroup {
  final int order;
  final FeatureGroup group;

  const OrderedGroup(this.order, this.group);
}
