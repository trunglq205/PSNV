import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/stocktake/data/datasources/stocktake_remote_data_source.dart';
import 'package:swms_finish_goods/features/stocktake/data/stocktake_repository_impl.dart';
import 'package:swms_finish_goods/features/stocktake/domain/entities/stocktake_entities.dart';
import 'package:swms_finish_goods/features/stocktake/domain/repositories/stocktake_repository.dart';

part 'stocktake_providers.g.dart';

@riverpod
StocktakeRepository stocktakeRepository(Ref ref) {
  final dio = ref.watch(dioProvider);
  final ds = StocktakeRemoteDataSource(dio);
  return StocktakeRepositoryImpl(ds);
}

/// Danh sách phiếu theo loại (morning | monthly | shipment).
@riverpod
Future<List<CountSummary>> stocktakeCounts(Ref ref, String type) async {
  final repo = ref.watch(stocktakeRepositoryProvider);
  return repo.fetchCounts(type: type);
}

/// Chi tiết 1 phiếu.
@riverpod
Future<CountDetail> stocktakeDetail(Ref ref, int id) async {
  final repo = ref.watch(stocktakeRepositoryProvider);
  return repo.fetchCount(id);
}
