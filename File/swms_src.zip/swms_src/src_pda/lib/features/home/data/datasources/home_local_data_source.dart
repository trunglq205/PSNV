import 'package:swms_finish_goods/core/utils/app_local_storage.dart';

/// Nguồn dữ liệu cục bộ cho Home — hiện chỉ lưu danh sách cụm đã ghim.
abstract interface class HomeLocalDataSource {
  Future<Set<String>> readPinned();

  Future<void> writePinned(Set<String> keys);
}

class HomeLocalDataSourceImpl implements HomeLocalDataSource {
  static const _kPinned = 'home.pinnedGroups';

  final AppLocalStorage _appLocalStorage;

  const HomeLocalDataSourceImpl(this._appLocalStorage);

  @override
  Future<Set<String>> readPinned() async {
    return (_appLocalStorage.readStringList(_kPinned) ?? const <String>[])
        .toSet();
  }

  @override
  Future<void> writePinned(Set<String> keys) async {
    await _appLocalStorage.writeStringList(_kPinned, keys.toList());
  }
}
