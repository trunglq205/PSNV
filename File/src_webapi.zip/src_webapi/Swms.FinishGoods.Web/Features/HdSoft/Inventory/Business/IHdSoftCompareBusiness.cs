using Swms.FinishGoods.Web.Features.Inventory.Business.Models;
using Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business;

/// <summary>So tồn SWMS ↔ HD soft theo (vị trí, model) và xử lý chênh lệch từng dòng.</summary>
public interface IHdSoftCompareBusiness
{
    /// <summary>Tải toàn bộ tồn SWMS (phân trang, + chi tiết pallet nhiều model) và tồn HD soft song song,
    /// rồi so theo (vị trí, model).</summary>
    Task<Result<AppStockCompareResult>> CompareWithHdSoftAsync(
        string? warehouse, IProgress<StockCompareProgress>? progress = null, CancellationToken ct = default);

    /// <summary>
    /// Thực hiện 1 hành động trên 1 dòng so (tạo / xoá / sửa SL / đồng bộ vị trí).
    /// <paramref name="packing"/>: quy cách pcs/thùng — bắt buộc cho create / qty, SL phải chia hết.
    /// Value = cảnh báo khi xong một phần (vd tạo được pallet nhưng gán vị trí lỗi), null nếu sạch.
    /// </summary>
    Task<Result<string?>> ApplyHdRowActionAsync(HdRowAction action, int? packing);

    // ── Dialog xoá thùng (hành động "boxes" — chọn tay, không chạy hàng loạt) ──

    /// <summary>Chi tiết pallet kèm thùng / line để chọn.</summary>
    Task<Result<AppInventoryItem>> GetPalletDetailAsync(long id);

    /// <summary>Xoá các thùng đã chọn. Reason ghi vào event để biết xoá từ màn so HD soft.</summary>
    Task<Result<DeleteBoxesResultDto>> DeleteBoxesAsync(long lotId, IReadOnlyList<long> boxIds);
}
