﻿import 'package:dio/dio.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/features/pallet/data/datasources/pallet_remote_data_source.dart';
import 'package:swms_finish_goods/features/pallet/data/models/locator_models.dart';
import 'package:swms_finish_goods/features/pallet/data/models/split_models.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/locator_occupancy.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/storage_suggestion.dart';
import 'package:swms_finish_goods/features/pallet/domain/repositories/pallet_repository.dart';

class PalletRepositoryImpl implements PalletRepository {
  final PalletRemoteDataSource _remote;

  const PalletRepositoryImpl(this._remote);

  @override
  Future<Pallet> getByLotNo(
    String lotNo, {
    Set<PalletInclude> include = const {},
    bool createIfMissing = true,
  }) async {
    final lot = lotNo.trim();
    final query = PalletInclude.toQuery(include);

    try {
      final res = await _remote.fetchPallet(lot, include: query);
      return res.toEntity();
    } catch (e) {
      // Lỗi khác 404, hoặc màn không được phép tạo lot -> để tầng trên xử lý.
      if (!createIfMissing || !_isNotFound(e)) rethrow;
    }

    // Lot chưa có trong SWMS -> dựng từ dữ liệu Foss.
    // Gọi ngoài khối catch để lỗi của bước này không bị lồng vào lỗi 404.
    final res = await _remote.createFromFoss(lot, include: query);
    return res.toEntity();
  }

  @override
  Future<StorageSuggestion> getStorageSuggestion(
    String lotNo, {
    int? palletHeightCm,
  }) async {
    // Không gửi giá trị vô nghĩa: 0 / âm để server hiểu là "không biết chiều cao"
    // thay vì ném 422 Lot.Suggestion.HeightInvalid.
    final height = (palletHeightCm != null && palletHeightCm > 0)
        ? palletHeightCm
        : null;

    final res = await _remote.fetchStorageSuggestion(
      lotNo.trim(),
      palletHeightCm: height,
    );
    return res.toEntity();
  }

  /// 404 tới dưới 2 dạng: [NotFoundException] do ErrorInterceptor bọc trong
  /// `DioException.error`, hoặc DioException thô nếu chưa qua interceptor.
  static bool _isNotFound(Object e) {
    if (e is NotFoundException) return true;
    if (e is DioException) {
      return e.error is NotFoundException || e.response?.statusCode == 404;
    }
    return false;
  }

  @override
  Future<SplitResult> split({
    required String sourceLotNo,
    required List<int> boxIds,
    required bool toNewLot,
    String? targetLotNo,
    int? boxQty,
    bool confirmModelMismatch = false,
  }) async {
    final res = await _remote.split(
      SplitPalletRequestModel(
        sourceLotNo: sourceLotNo.trim(),
        boxIds: boxIds,
        targetType: toNewLot
            ? SplitTargetType.newLot
            : SplitTargetType.existing,
        targetLotNo: toNewLot ? null : targetLotNo?.trim(),
        boxQty: boxQty,
        // Tách sang lot MỚI thì không có pallet đích để lệch model.
        confirmModelMismatch: !toNewLot && confirmModelMismatch,
      ),
    );
    return res.toEntity();
  }

  @override
  Future<LocatorChangeResult> assignLocator({
    required int lotId,
    required String locatorCode,
    String? allowedMapType,
  }) async {
    final res = await _remote.assignLocator(
      lotId,
      LocatorRequestModel(
        locatorCode: locatorCode.trim(),
        allowedMapType: allowedMapType,
      ),
    );
    return res.toEntity();
  }

  @override
  Future<LocatorChangeResult> store({
    required int lotId,
    required String locatorCode,
  }) async {
    final res = await _remote.store(
      lotId,
      LocatorRequestModel(locatorCode: locatorCode.trim()),
    );
    return res.toEntity();
  }

  @override
  Future<LocatorChangeResult> releaseLocator({required int lotId}) async {
    final res = await _remote.releaseLocator(lotId);
    return res.toEntity();
  }

  @override
  Future<LocatorOccupancy> getLocatorPallets(String locatorCode) async {
    final res = await _remote.fetchLocatorPallets(locatorCode.trim());
    return res.toEntity();
  }

  @override
  Future<Pallet> syncOqc(String lotNo) async {
    final res = await _remote.syncOqc(lotNo);
    return res.toEntity();
  }
}
