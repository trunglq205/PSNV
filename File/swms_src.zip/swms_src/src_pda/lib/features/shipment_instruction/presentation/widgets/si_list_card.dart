import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/extensions/datetime_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_progress_bar.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_status_ui.dart';

/// Thẻ một chỉ thị trong danh sách.
///
/// Góc phải: nút "Soạn hàng" khi còn soạn được và có [onStartPicking],
/// ngược lại là pill trạng thái.
class SiListCard extends StatelessWidget {
  final ShipmentInstructionSummary si;
  final VoidCallback? onTap;
  final VoidCallback? onStartPicking;

  const SiListCard({
    super.key,
    required this.si,
    this.onTap,
    this.onStartPicking,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final canPick = onStartPicking != null && (si.status?.canPick ?? false);
    final pct = (si.progress * 100).floor(); // floor: 99.6% không hiện 100%

    // Thiếu hàng chỉ có nghĩa khi đang soạn — chỉ thị mới ban hành thì
    // "thiếu" = toàn bộ số lượng, hiện ra chỉ gây nhiễu.
    final warnings = si.status == SiStatus.picking
        ? siJoin([
            if (si.qtyShort > 0)
              LocaleKeys.shipment_instruction_short_pcs.tr(
                args: ['${si.qtyShort}'],
              ),
            if (si.unmatchedBoxCount > 0)
              LocaleKeys.shipment_instruction_unmatched_boxes.tr(
                args: ['${si.unmatchedBoxCount}'],
              ),
          ])
        : '';

    return AppCard(
      onTap: onTap,
      padding: const EdgeInsets.all(12),
      borderRadius: AppDimens.rBtn,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // ── Mã SI + revision + action ──────────────────────────
          Row(
            children: [
              Expanded(
                child: Row(
                  children: [
                    Flexible(
                      child: Text(
                        si.siNo,
                        overflow: TextOverflow.ellipsis,
                        style: AppTextStyles.code.copyWith(
                          fontSize: 14.5,
                          letterSpacing: 0,
                          fontWeight: FontWeight.w800,
                          color: swms.text1,
                        ),
                      ),
                    ),
                    if ((si.revision ?? '').isNotEmpty) ...[
                      const SizedBox(width: 7),
                      Text(
                        si.revision!,
                        style: AppTextStyles.caption.copyWith(
                          fontWeight: FontWeight.w700,
                          color: swms.text3,
                        ),
                      ),
                    ],
                  ],
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              if (canPick)
                _PickButton(onPressed: onStartPicking!)
              else
                si.status.pill(context, rawKey: si.statusKey),
            ],
          ),

          // ── Nước đến · consignee · mode · ETD ──────────────────
          const SizedBox(height: AppDimens.xs),
          Text.rich(
            TextSpan(
              children: [
                TextSpan(
                  text: siOrDash(si.countryCode),
                  style: TextStyle(
                    color: swms.text1,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                TextSpan(
                  text: ' · ${siJoin([si.consigneeCode, si.shipMode])} · ETD ',
                ),
                TextSpan(
                  text: si.etdDate?.ddMMyyyy ?? kSiDash,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 12,
                    letterSpacing: 0,
                    color: swms.text2,
                  ),
                ),
              ],
            ),
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.body.copyWith(fontSize: 12, color: swms.text2),
          ),

          // ── Tiến độ ────────────────────────────────────────────
          if (si.qtyRequired > 0) ...[
            const SizedBox(height: 9),
            Row(
              children: [
                Expanded(child: AppProgressBar(value: si.progress)),
                const SizedBox(width: AppDimens.sm),
                Text(
                  '$pct%',
                  style: AppTextStyles.caption.copyWith(
                    fontSize: 11,
                    fontWeight: FontWeight.w700,
                    color: swms.text2,
                    fontFeatures: const [FontFeature.tabularFigures()],
                  ),
                ),
              ],
            ),
          ],

          if (warnings.isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              warnings,
              style: AppTextStyles.label.copyWith(color: swms.danger),
            ),
          ] else if ((si.modelsPreview ?? '').isNotEmpty) ...[
            const SizedBox(height: 6),
            Text(
              si.modelsPreview!,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
              style: AppTextStyles.caption.copyWith(
                fontSize: 11,
                color: swms.text3,
              ),
            ),
          ],
        ],
      ),
    );
  }
}

/// Nút "Soạn hàng" gọn trong thẻ.
///
/// KHÔNG dùng AppButton: FilledButton theme có minimumSize = Size.fromHeight(..)
/// (rộng tối thiểu = vô cực) → nằm trong Row là vỡ layout.
class _PickButton extends StatelessWidget {
  final VoidCallback onPressed;

  const _PickButton({required this.onPressed});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final radius = BorderRadius.circular(AppDimens.rInput - 2);

    return Material(
      color: swms.primary,
      borderRadius: radius,
      child: InkWell(
        onTap: onPressed,
        borderRadius: radius,
        child: ConstrainedBox(
          // Vùng chạm tối thiểu cho tay đeo găng.
          constraints: const BoxConstraints(minHeight: AppDimens.hitSm),
          child: Padding(
            padding: const EdgeInsets.symmetric(horizontal: 10),
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                const Icon(
                  Icons.pan_tool_alt_outlined,
                  size: 14,
                  color: Colors.white,
                ),
                const SizedBox(width: AppDimens.xs),
                Text(
                  LocaleKeys.shipment_instruction_start_picking.tr(),
                  style: AppTextStyles.label.copyWith(
                    color: Colors.white,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
