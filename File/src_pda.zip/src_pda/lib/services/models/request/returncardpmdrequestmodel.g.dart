// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'returncardpmdrequestmodel.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

ReturnCardPMDRequestModel _$ReturnCardPMDRequestModelFromJson(
        Map<String, dynamic> json) =>
    ReturnCardPMDRequestModel(
      section: json['section'] as String,
      material: json['material'] as String,
      model: json['model'] as String,
      machine: json['machine'] as String,
      typeCard: json['typeCard'] as String,
      statusRecycle: json['statusRecycle'] as String,
      sloc: json['sloc'] as String,
      kittingCardID: (json['kittingCardID'] as num).toInt(),
      userIDInsert: json['userIDInsert'] as String,
    );

Map<String, dynamic> _$ReturnCardPMDRequestModelToJson(
        ReturnCardPMDRequestModel instance) =>
    <String, dynamic>{
      'section': instance.section,
      'material': instance.material,
      'model': instance.model,
      'machine': instance.machine,
      'typeCard': instance.typeCard,
      'statusRecycle': instance.statusRecycle,
      'sloc': instance.sloc,
      'kittingCardID': instance.kittingCardID,
      'userIDInsert': instance.userIDInsert,
    };
