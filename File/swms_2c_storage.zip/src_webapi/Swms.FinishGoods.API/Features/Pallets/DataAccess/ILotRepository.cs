using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;

namespace Swms.FinishGoods.API.Features.Pallets.DataAccess
{
    /// <summary>
    /// Truy cập pallet cho nghiệp vụ SWMS. Phần chỉ luồng Foss dùng (bổ sung thùng,
    /// ghi OQC, chọn ứng viên job) ở IPalletFossRepository (Features/Foss/PalletSync/DataAccess).
    /// </summary>
    public interface ILotRepository
    {
        // ── Read ──
        Task<Pallet?> GetByIdAsync(long id);
        Task<Pallet?> GetByLotNoAsync(string lotNo);
        Task<PagedResult<Pallet>> GetPagedAsync(PalletQuery query);

        /// <summary>Client tự sinh pallet_id nên server chỉ kiểm tra trùng.</summary>
        Task<bool> ExistsLotNoAsync(string lotNo);
        /// <summary>
        /// Sequence lớn nhất (3 số cuối) của các lot có pallet_id bắt đầu bằng prefix
        /// &lt;category:3&gt;&lt;yymmdd:6&gt;. Tính cả lot đã xoá mềm để không tái sử dụng số.
        /// Trả 0 nếu chưa có lot nào trong ngày.
        /// </summary>
        Task<int> GetMaxSequenceAsync(string prefix);

        /// <summary>
        /// raw_payload nào trong danh sách đã nằm trên box active của pallet active.
        /// Trả payload -> pallet_id đang giữ thẻ đó; rỗng = chưa dùng.
        /// Dùng để pre-check trả lỗi đẹp — chốt chặn thật nằm trong
        /// <see cref="AddAsync"/> với rejectDuplicatePayload = true.
        /// </summary>
        Task<IReadOnlyDictionary<string, string>> GetActivePalletsByBoxPayloadAsync(
            IReadOnlyList<string> payloads);

        // ── Write ──

        /// <summary>
        /// Tạo lot + box + line trong 1 transaction, kèm PALLET_CREATED và
        /// BOX_CREATED cho từng box.
        /// </summary>
        /// <param name="origin">
        /// Nguồn tạo — ghi vào payload {"origin":"..."} của PALLET_CREATED.
        /// Xem <see cref="PalletOrigins"/>: manual | foss | split.
        /// </param>
        /// <param name="source">WEB | PDA | API | JOB | SAP.</param>
        /// <param name="rejectDuplicatePayload">
        /// true (luồng tạo tay BoxLine): check lại raw_payload trong transaction với
        /// UPDLOCK + HOLDLOCK; trùng thì ném <see cref="DuplicateBoxPayloadException"/>
        /// và rollback. Mặc định false để luồng Foss / Serial giữ nguyên hành vi.
        /// </param>
        /// <param name="onInserted">
        /// Chạy SAU khi pallet + box + line đã insert, TRƯỚC khi ghi event và
        /// commit — nhận (conn, tx, lotId) của chính transaction đang mở.
        ///
        /// Để feature khác ghi thêm dữ liệu của mình trong CÙNG transaction tạo
        /// pallet. Hiện dùng bởi Chỉ thị back hàng (mục 2a): đăng ký serial vào
        /// sổ của phiếu và đóng dấu disposition. Không có hook thì việc đó phải
        /// nằm ở transaction thứ hai, và hỏng ở giữa là pallet tồn tại nhưng
        /// không con serial nào được tính — đúng cái mà bước đối chiếu SL thực
        /// nhận dùng để so.
        ///
        /// Ném exception trong hook = rollback cả pallet. Mặc định null.
        /// </param>
        /// <exception cref="DuplicateBoxPayloadException">
        /// Khi <paramref name="rejectDuplicatePayload"/> = true và có thẻ đã nằm trên pallet active.
        /// </exception>
        Task<long> AddAsync(
            Pallet lot,
            string origin = PalletOrigins.Manual,
            string source = StockEventSources.Web,
            bool rejectDuplicatePayload = false,
            IntegrationSyncContext? sync = null,
            Func<System.Data.IDbConnection, System.Data.IDbTransaction, long, Task>? onInserted = null);

        /// <summary>
        /// Tra thẻ in theo payload. Trả dictionary thay vì gọi từng box: lot serial
        /// có thể vài chục thùng, mỗi thùng một query là N+1 ngay trong luồng tạo lot.
        /// Payload không khớp thẻ nào thì không có mặt trong kết quả.
        /// </summary>
        Task<IReadOnlyDictionary<string, PartCardInfo>> GetPartCardsByPayloadAsync(
            IReadOnlyList<string> payloads);

        /// <summary>Soft delete lot + box + line, kèm event PALLET_DELETED.</summary>
        Task SoftDeleteAsync(long id, string updatedBy, string source = StockEventSources.Web);

        /// <summary>
        /// Soft delete các thùng (+ line) của 1 pallet serial / box_line trong 1 transaction:
        /// tính lại box_count + production_date, mở khoá thẻ in, ghi 1 event cấp pallet.
        /// Null = dữ liệu đã đổi so với lúc kiểm tra (thùng không còn thuộc pallet / sẽ xoá hết thùng /
        /// pallet đã xoá hoặc là box_count) — không ghi gì.
        /// </summary>
        Task<BoxDeleteResult?> SoftDeleteBoxesAsync(
            long lotId, IReadOnlyList<long> boxIds, string user, StockEventContext ctx);

        // ── Vị trí tạm (PDA) ──
        Task<PalletLocationInfo?> GetLocationInfoByLotNoAsync(string lotNo);
        Task<PalletLocationInfo?> GetLocationInfoByIdAsync(long id);
        Task<LocatorBrief?> GetLocatorByCodeAsync(string locatorCode);

        /// <summary>
        /// Đổi vị trí lot + ghi event.
        ///
        /// <paramref name="ctx"/> mang event code do Service quyết định. Trước đây
        /// MoveIntent dừng ở tầng Service nên repository không phân biệt được gán
        /// tạm / lưu kho / vanning và lịch sử ghi giống hệt nhau.
        /// </summary>
        /// <param name="inspectionStatus">
        /// Khác null thì cập nhật luôn wms.pallets.inspection_status trong CÙNG
        /// câu UPDATE đổi vị trí. Dùng cho hàng tái gia công: đặt vào vị trí
        /// Nhận hàng là đã giao cho FA, pallet phải mang trạng thái NG ngay từ
        /// lúc đó — hai câu UPDATE rời nhau thì có khoảng thời gian pallet đã ở
        /// khu nhận hàng mà bản đồ còn vẽ trạng thái cũ.
        /// </param>
        /// <param name="onMoved">
        /// Chạy SAU khi đã cập nhật vị trí, TRƯỚC khi ghi event và commit — nhận
        /// (conn, tx, lotId) của chính transaction đang mở. Cùng khuôn với
        /// <see cref="AddAsync"/>.<c>onInserted</c>.
        ///
        /// Để feature khác ghi sổ của mình trong cùng transaction với việc đổi
        /// vị trí. Hiện dùng bởi Chỉ thị back hàng (mục 2c): chuyển pallet vào
        /// vị trí Nhận hàng CHÍNH LÀ hành động giao hàng cho FA, nên serial sang
        /// at_fa và nhật ký giao hàng phải cùng sống cùng chết với việc đổi vị
        /// trí. Tách ra hai transaction thì hỏng ở giữa để lại pallet đã nằm ở
        /// khu nhận hàng mà phiếu vẫn báo chưa giao — và không chuyển lại được
        /// vì đã đứng đúng vị trí đó.
        ///
        /// Ném exception trong hook = rollback cả việc đổi vị trí.
        /// </param>
        Task ChangeLocatorAsync(
            long lotId,
            long? toLocatorId,
            string? user,
            StockEventContext ctx,
            string? inspectionStatus = null,
            Func<System.Data.IDbConnection, System.Data.IDbTransaction, long, Task>? onMoved = null);

        // GetHistoryByLotNoAsync đã XOÁ cùng wms.locator_status_history.
        // Dùng IStockEventRepository.GetPalletEventsByLotNoAsync thay thế —
        // bản mới khớp CẢ pallet_id LẪN stocky_code (bản cũ chỉ so pallet_id nên
        // xe stocky luôn ra lịch sử rỗng).

        // ── Tách pallet ──
        Task<SplitLotInfo?> GetSplitLotInfoAsync(string lotNo);
        Task<int> CountBoxesInLotAsync(long lotId, IReadOnlyList<long> boxIds);
        Task<(int moved, int sourceRemaining)> ExecuteSplitAsync(SplitExecuteParams p);

        /// <summary>
        /// Tách theo SỐ LƯỢNG, cho pallet detail_level = 'box_count'. Cộng trừ
        /// thẳng cột box_count thay vì chuyển dòng trong wms.boxes — loại pallet
        /// này không có dòng box nào.
        /// </summary>
        Task<(int moved, int sourceRemaining)> ExecuteSplitByQtyAsync(SplitExecuteParams p);

        // ── Lưu kho (PDA) ──

        /// <summary>Tổng số lượng theo model của lot (gộp box_lines). Rỗng với lot box_count.</summary>
        Task<IReadOnlyList<PalletModelQty>> GetModelQtysByLotIdAsync(long lotId);

        /// <summary>Gợi ý 1 vị trí storage để lưu pallet (FR-STR-02). Null nếu hết chỗ.</summary>
        Task<LocatorSuggestion?> SuggestLocatorAsync(long lotId);

        /// <summary>
        /// Model khác biệt của lot đích và của các box sắp chuyển — để chặn gộp
        /// box khác model vào pallet đơn model.
        /// </summary>
        Task<SplitModelCheck> GetSplitModelCheckAsync(long targetLotId, IReadOnlyList<long> boxIds);

        // ── Luồng đồng bộ Foss / HD soft có gọi, nhưng là thao tác SWMS thuần ──

        /// <summary>Gán si_no. Chỉ ghi khi giá trị thật sự đổi; true = có cập nhật.</summary>
        Task<bool> UpdateSiNoAsync(
            long lotId,
            string? siNo,
            string? user,
            StockEventContext? ctx = null);

        /// <summary>Lot nào trong danh sách đã có trong SWMS (theo pallet_id hoặc stocky_code).</summary>
        Task<HashSet<string>> GetExistingLotNosAsync(IReadOnlyCollection<string> lotNos);

        /// <summary>Mọi pallet đang tồn trong SWMS (chưa xuất cho khách).</summary>
        Task<List<string>> GetLotNosInStockAsync();

        /// <summary>Như GetLocationInfoByLotNoAsync cho cả nhóm, 1 câu.</summary>
        Task<Dictionary<string, PalletLocationInfo>> GetLocationInfosByLotNosAsync(
            IReadOnlyCollection<string> lotNos);

        Task<BoxCountUpdateResult?> UpdateBoxCountAsync(
            long lotId, int boxCount, int standardPacking, int? expectedQty,
            string? user, StockEventContext ctx);
    }
}
