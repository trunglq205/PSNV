namespace Swms.FinishGoods.API.Features.ReturnInstructions;

/// <summary>
/// Một dòng trong sổ serial, dạng GỌN cho PDA kiểm trên máy (mục 2d).
///
/// Vì sao không dùng lại <c>ReturnSerialResponse</c>: PDA tải TOÀN BỘ serial của
/// phiếu một lần để kiểm ngay lúc quét, không chờ mạng từng con. Một phiếu vài
/// nghìn serial mà trả object đầy đủ là vài trăm KB; ba trường là đủ để kiểm.
/// </summary>
public sealed class ReturnSerialIndexRow
{
    public string SerialNo { get; set; } = default!;
    public string Model { get; set; } = default!;
    public string Status { get; set; } = default!;
}

/// <summary>
/// Kết quả tra một serial FA vừa quét: nó có phải hàng của phiếu này và đang ở
/// FA hay không.
/// </summary>
public sealed class ReturnSerialResolution
{
    public string SerialNo { get; set; } = default!;

    /// <summary>Null khi serial không có trong sổ nào.</summary>
    public long? DocId { get; set; }

    public string? DocNo { get; set; }
    public string? Model { get; set; }
    public string? Status { get; set; }
}

/// <summary>
/// Một serial ĐÃ KHỚP, kèm mã thùng FA vừa quét nó vào.
///
/// Class chứ không ValueTuple: Dapper nhận tham số theo TÊN property, còn
/// tuple thì chỉ khớp theo vị trí — đổi thứ tự hai trường là âm thầm gán sai
/// mã thùng vào serial. Cùng lý do đã ghi ở <c>MailTemplateRow</c>.
/// </summary>
public sealed class ReturnFaSerialRow
{
    public string SerialNo { get; set; } = default!;
    public string BoxNo { get; set; } = default!;
}

/// <summary>
/// Nhật ký serial FA quét ra mà không khớp sổ của phiếu (mục 2d).
///
/// Theo yêu cầu nghiệp vụ, serial lạ VẪN cho quét tiếp — chỉ cảnh báo ngay để
/// SCS WH đặt riêng ra. Nhưng nó KHÔNG được vào pallet và KHÔNG chèn vào sổ
/// serial (<c>ux_ris_serial_open</c> là unique trên serial_no toàn hệ thống).
/// </summary>
public sealed class ReturnSerialMismatch
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public long? PalletId { get; set; }

    /// <summary>Mã Pallet ID 12 số — tiện cho màn hình, đọc từ wms.pallets.</summary>
    public string? LotNo { get; set; }

    public string SerialNo { get; set; } = default!;
    public string? Model { get; set; }
    public string Reason { get; set; } = default!;
    public string? FoundStatus { get; set; }
    public string? OtherDocNo { get; set; }

    public DateTime ScannedAt { get; set; }
    public string? ScannedBy { get; set; }

    public DateTime? ResolvedAt { get; set; }
    public string? ResolvedBy { get; set; }
    public string? ResolveNote { get; set; }

    public bool IsResolved => ResolvedAt is not null;
}

/// <summary>
/// Lý do một serial bị loại. Khớp CHECK <c>ck_rsm_reason</c>.
///
/// Ba loại tách riêng vì cách xử lý khác nhau: con của phiếu khác thì trả về
/// đúng phiếu đó; con sai trạng thái thì phải tra lại lịch sử xem đã đi đâu.
/// </summary>
public static class ReturnMismatchReason
{
    /// <summary>Không có trong sổ của phiếu này, và cũng không thuộc phiếu nào.</summary>
    public const string NotInDoc = "not_in_doc";

    /// <summary>Có trong phiếu này nhưng không ở <c>at_fa</c>.</summary>
    public const string WrongStatus = "wrong_status";

    /// <summary>Đang thuộc một phiếu khác.</summary>
    public const string OtherDoc = "other_doc";
}
