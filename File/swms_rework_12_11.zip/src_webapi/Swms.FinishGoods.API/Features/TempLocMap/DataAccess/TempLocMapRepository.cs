﻿using System.Data;
using Dapper;
using Swms.FinishGoods.API.Features.TempLocMap.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.TempLocMap.DataAccess;

public class TempLocMapRepository : ITempLocMapRepository
{
    private readonly IDbConnectionFactory _factory;

    public TempLocMapRepository(IDbConnectionFactory factory) => _factory = factory;

    // ---------- Areas (không đổi) ----------

    public async Task<IReadOnlyList<WarehouseArea>> GetAreasAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT id AS Id, area_code AS AreaCode, area_name AS AreaName,
                   cols AS Cols, rows AS Rows, cell_meters AS CellMeters,
                   is_active AS IsActive, created_at AS CreatedAt, updated_at AS UpdatedAt
            FROM master.warehouse_areas
            WHERE is_deleted = 0
            ORDER BY area_code;
            """;
        return (await conn.QueryAsync<WarehouseArea>(sql)).ToList();
    }

    public async Task<WarehouseArea?> GetAreaByCodeAsync(string areaCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT id AS Id, area_code AS AreaCode, area_name AS AreaName,
                   cols AS Cols, rows AS Rows, cell_meters AS CellMeters,
                   is_active AS IsActive, created_at AS CreatedAt, updated_at AS UpdatedAt
            FROM master.warehouse_areas
            WHERE area_code = @areaCode AND is_deleted = 0;
            """;
        return await conn.QueryFirstOrDefaultAsync<WarehouseArea>(sql, new { areaCode });
    }

    public async Task<long> CreateAreaAsync(WarehouseArea area, string? createdBy)
    {
        using var conn = _factory.Create();
        const string sql = """
            INSERT INTO master.warehouse_areas
                (area_code, area_name, cols, rows, cell_meters, is_active, is_deleted, created_at, created_by)
            VALUES
                (@AreaCode, @AreaName, @Cols, @Rows, @CellMeters, 1, 0, SYSDATETIME(), @createdBy);
            SELECT CAST(SCOPE_IDENTITY() AS bigint);
            """;
        return await conn.ExecuteScalarAsync<long>(sql, new
        {
            area.AreaCode,
            area.AreaName,
            area.Cols,
            area.Rows,
            area.CellMeters,
            createdBy
        });
    }

    // ---------- Locators / layout ----------

    // Map object của 1 area = locator_map JOIN locators (cho ô locator)
    // + các dòng decor (locator_id NULL). cell_type cũ ↔ dùng target_type
    // hoặc bỏ hẳn; ở đây map: decor→'zone', locator thường→'pallet'.
    public async Task<IReadOnlyList<MapLocator>> GetLocatorsByAreaAsync(long areaId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT  l.id            AS Id,
                    m.id            AS MapId,
                    l.locator_code  AS LocatorCode,
                    m.parent_id     AS AreaId,
                    CASE m.target_type
                        WHEN N'zone'  THEN N'zone'
                        WHEN N'rack'  THEN N'rack'
                        ELSE N'pallet'
                    END             AS CellType,
                    m.grid_x        AS GridX,
                    m.grid_y        AS GridY,
                    m.grid_w        AS GridW,
                    m.grid_h        AS GridH,
                    m.arrow         AS Arrow,
                    m.color         AS Color,
                    m.label         AS Label,
                    l.current_status AS CurrentStatus,
                    m.sort_order    AS SortOrder
            FROM master.locator_map m
            LEFT JOIN master.locators l
                   ON l.id = m.locator_id AND l.is_deleted = 0
            WHERE m.parent_type = N'area'
              AND m.parent_id   = @areaId
              AND m.is_deleted  = 0
            ORDER BY m.sort_order, m.id;
            """;
        return (await conn.QueryAsync<MapLocator>(sql, new { areaId })).ToList();
    }

    /// <summary>
    /// Lot trên các pallet của 1 khu. pallets.locator_id → locators.
    /// </summary>
    public async Task<IReadOnlyList<PalletLot>> GetLotsByAreaAsync(long areaId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT  l.id            AS LotId,
                    l.locator_id    AS LocatorId,
                    l.pallet_id        AS LotNo,
                    l.inspection_status AS InspectionStatus,
                    l.is_urgent     AS IsUrgent,
                    l.box_count     AS BoxCount,
                    l.production_date AS ProductionDate,
                    -- Pallet box_count KHÔNG có dòng box_lines nào, model của nó
                    -- nằm ở cột pallets.model. Thiếu COALESCE thì loại này hiện
                    -- model trống trên bản đồ Receiving. Cùng quy ước với
                    -- LocationInfoSql: COALESCE(gộp từ box_lines, pallets.model).
                    COALESCE(m.models, l.model) AS Models,
                    -- Dấu RW/RB. Hàng tái gia công nằm ở khu Nhận hàng CHÍNH LÀ
                    -- hàng đang chờ giao cho FA (hoặc vừa giao xong), nên đây là
                    -- chỗ cần phân biệt nhất: nó mang inspection_status 'ng' như
                    -- một pallet OQC đánh fail, nhìn không ra khác nhau.
                    --
                    -- Lùi về goods_type của phiếu khi cột disposition chưa có
                    -- dấu — cùng lý do và cùng cách với LocationInfoSql.
                    COALESCE(l.disposition, rb.goods_type) AS Disposition
            FROM wms.pallets l
            INNER JOIN master.locators loc
                ON loc.id = l.locator_id AND loc.area_id = @areaId AND loc.is_deleted = 0
            OUTER APPLY (
                SELECT TOP 1 d.goods_type AS goods_type
                FROM   wms.return_instruction_serials ris
                JOIN   wms.return_instructions d
                       ON d.id = ris.doc_id AND d.is_deleted = 0
                WHERE  ris.pallet_id = l.id
                  AND  ris.is_deleted = 0
                ORDER BY ris.id DESC
            ) rb
            OUTER APPLY (
                SELECT STRING_AGG(x.model, ', ') AS models
                FROM (
                    SELECT DISTINCT bl.model
                    FROM wms.boxes lb
                    INNER JOIN wms.box_lines bl ON bl.box_id = lb.id AND bl.is_deleted = 0
                    -- lb.is_deleted: thiếu thì thùng đã xoá mềm vẫn góp model,
                    -- pallet báo model nó không còn giữ.
                    WHERE lb.lot_id = l.id AND lb.is_deleted = 0
                ) x
            ) m
            WHERE l.is_deleted = 0
            ORDER BY l.locator_id, l.pallet_id;
            """;
        return (await conn.QueryAsync<PalletLot>(sql, new { areaId })).ToList();
    }

    public async Task SaveLayoutAsync(long areaId, SaveLayoutRequest request, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // 1) cập nhật kích thước lưới của khu
            const string updArea = """
                UPDATE master.warehouse_areas
                SET cols = @Cols, rows = @Rows, cell_meters = @CellMeters,
                    updated_at = SYSDATETIME(), updated_by = @user
                WHERE id = @areaId;
                """;
            await conn.ExecuteAsync(updArea,
                new { request.Cols, request.Rows, request.CellMeters, areaId, user }, tx);

            // id map object cũ còn giữ lại
            var keptIds = request.Cells.Where(c => c.Id.HasValue).Select(c => c.Id!.Value).ToList();

            // 2) soft-delete map object KHÔNG còn gửi lên.
            //    Chỉ đụng locator_map; locators (business) KHÔNG xoá ở đây
            //    để không mất vị trí lot đang trỏ vào. Xem chú thích cuối.
            const string softDelMissing = """
                UPDATE master.locator_map
                SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @user
                WHERE parent_type = N'area' AND parent_id = @areaId AND is_deleted = 0
                  AND (@hasKept = 0 OR id NOT IN @keptIds);
                """;
            await conn.ExecuteAsync(softDelMissing,
                new
                {
                    areaId,
                    user,
                    hasKept = keptIds.Count > 0 ? 1 : 0,
                    keptIds = keptIds.Count > 0 ? keptIds : new List<long> { -1 }
                }, tx);

            // Helper SQL cho phần business (locators) — chỉ cho ô locator (không decor).
            // Tái dùng dòng đã tồn tại cùng locator_code (KỂ CẢ đã soft-delete) → GIỮ NGUYÊN id
            // (hồi sinh về is_deleted=0), chỉ INSERT khi locator_code chưa từng có.
            // Chọn đúng 1 dòng để cập nhật: ưu tiên dòng đang active, nếu chỉ còn dòng đã xoá
            // thì hồi sinh dòng mới nhất — tránh hồi sinh nhiều dòng gây trùng (ux_locators_new_code).
            const string upsertLocatorByCode = """
                UPDATE master.locators
                SET area = N'staging', area_id = @areaId,
                    current_status = @Status, sort_order = @SortOrder,
                    is_deleted = 0, updated_at = SYSDATETIME(), updated_by = @user
                WHERE id = (
                    SELECT TOP 1 id FROM master.locators
                    WHERE locator_code = @Code
                    ORDER BY is_deleted ASC, id DESC
                );

                IF @@ROWCOUNT = 0
                    INSERT INTO master.locators
                        (locator_code, area_id, current_status, sort_order,
                         is_active, is_deleted, created_at, created_by)
                    VALUES (@Code, @areaId, @Status, @SortOrder,
                            1, 0, SYSDATETIME(), @user);
                """;

            const string getLocatorIdByCode = """
                SELECT TOP 1 id FROM master.locators
                WHERE locator_code = @Code AND is_deleted = 0;
                """;

            // Map object: UPDATE theo id (ô cũ)
            const string updMap = """
                UPDATE master.locator_map
                SET target_type = @TargetType, locator_id = @LocatorId,
                    grid_x = @GridX, grid_y = @GridY, grid_w = @GridW, grid_h = @GridH,
                    arrow = @Arrow, color = @Color, label = @Label,
                    sort_order = @SortOrder, is_deleted = 0,
                    updated_at = SYSDATETIME(), updated_by = @user
                WHERE id = @Id AND parent_type = N'area' AND parent_id = @areaId;
                """;

            // Map object: INSERT ô mới
            const string insMap = """
                INSERT INTO master.locator_map
                    (parent_type, parent_id, target_type, locator_id,
                     grid_x, grid_y, grid_w, grid_h, arrow, color, label,
                     sort_order, is_active, is_deleted, created_at, created_by)
                VALUES
                    (N'area', @areaId, @TargetType, @LocatorId,
                     @GridX, @GridY, @GridW, @GridH, @Arrow, @Color, @Label,
                     @SortOrder, 1, 0, SYSDATETIME(), @user);
                """;

            foreach (var c in request.Cells)
            {
                var status = string.IsNullOrWhiteSpace(c.Status) ? "empty" : c.Status;

                // zone (cell không phải pallet) → không tạo locator business
                bool isZone = string.Equals(c.CellType, "zone", StringComparison.OrdinalIgnoreCase);
                string targetType = isZone ? "zone" : "locator";
                long? locatorId = null;

                if (!isZone && !string.IsNullOrWhiteSpace(c.Code))
                {
                    // upsert business rồi lấy id gắn vào map
                    await conn.ExecuteAsync(upsertLocatorByCode,
                        new { c.Code, areaId, Status = status, c.SortOrder, user }, tx);
                    locatorId = await conn.ExecuteScalarAsync<long?>(getLocatorIdByCode,
                        new { c.Code }, tx);
                }

                var p = new
                {
                    c.Id,
                    areaId,
                    TargetType = targetType,
                    LocatorId = locatorId,
                    c.GridX,
                    c.GridY,
                    c.GridW,
                    c.GridH,
                    c.Arrow,
                    c.Color,
                    c.Label,
                    c.SortOrder,
                    user
                };

                if (c.Id.HasValue)
                    await conn.ExecuteAsync(updMap, p, tx);      // map object cũ
                else
                    await conn.ExecuteAsync(insMap, p, tx);      // map object mới
            }

            tx.Commit();
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public async Task<bool> ChangeStatusAsync(string locatorCode, ChangeStatusRequest request, string? user)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            // status giờ nằm ở locators (business), không phải map.
            // Chỉ cần biết ô có tồn tại — trạng thái cũ không còn dùng nữa
            // (xem chú thích về lịch sử bên dưới).
            const string getCur = """
                SELECT TOP 1 1
                FROM master.locators
                WHERE locator_code = @locatorCode AND is_deleted = 0;
                """;
            var exists = await conn.ExecuteScalarAsync<int?>(getCur, new { locatorCode }, tx);
            if (exists is null) { tx.Rollback(); return false; }

            const string upd = """
                UPDATE master.locators
                SET current_status = @Status,
                    status_updated_at = SYSDATETIME(),
                    status_updated_by = @user,
                    updated_at = SYSDATETIME(),
                    updated_by = @user
                WHERE locator_code = @locatorCode AND is_deleted = 0;
                """;
            await conn.ExecuteAsync(upd, new { request.Status, locatorCode, user }, tx);

            // ĐÃ BỎ câu INSERT vào wms.locator_status_history: bảng đó không còn
            // trong DB, nên endpoint PATCH /api/temploc/locators/{code}/status
            // trước đây đổ "Invalid object name" và không đổi được trạng thái nào.
            //
            // KHÔNG chuyển sang wms.stock_events được: bảng đó buộc
            // subject_type IN ('pallet','box') kèm id tương ứng NOT NULL
            // (CHECK CK_stock_events_subject), mà đây là thao tác trên Ô VỊ TRÍ
            // và có thể không có pallet nào (vd. đánh dấu ô trống). Cũng không
            // có mã event nào cho trạng thái vị trí trong StockEventCodes.
            //
            // Hiện chỉ còn lưu trạng thái MỚI NHẤT trên master.locators
            // (current_status / status_updated_at / status_updated_by) — đủ cho
            // bản đồ, nhưng KHÔNG còn lịch sử thay đổi. Muốn có lịch sử thật thì
            // phải thêm bảng riêng; đó là quyết định thiết kế, không phải vá lỗi.
            //
            // Vì vậy request.Model và request.LotNo hiện KHÔNG được lưu ở đâu.

            tx.Commit();
            return true;
        }
        catch
        {
            tx.Rollback();
            throw;
        }
    }

    public async Task<LocatorOccupancy?> GetLocatorOccupancyAsync(string locatorCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            DECLARE @id bigint = (
                SELECT TOP 1 id FROM master.locators
                WHERE locator_code = @locatorCode AND is_deleted = 0
                ORDER BY id DESC);

            SELECT  l.id           AS LocatorId,
                    l.locator_code AS LocatorCode,
                    a.area_code    AS AreaCode,
                    a.area_name    AS AreaName,
                    a.map_type     AS MapType
            FROM master.locators l
            LEFT JOIN master.racks           r ON r.id = l.rack_id
            LEFT JOIN master.warehouse_areas a ON a.id = COALESCE(l.area_id, r.area_id)
            WHERE l.id = @id;

            SELECT p.pallet_id
            FROM wms.pallets p
            WHERE p.locator_id = @id AND p.is_deleted = 0
            ORDER BY p.pallet_id;
            """;

        using var multi = await conn.QueryMultipleAsync(sql, new { locatorCode });
        var loc = await multi.ReadSingleOrDefaultAsync<LocatorOccupancy>();
        if (loc is null) return null;

        loc.Pallets = (await multi.ReadAsync<string>()).ToList();
        return loc;
    }
}