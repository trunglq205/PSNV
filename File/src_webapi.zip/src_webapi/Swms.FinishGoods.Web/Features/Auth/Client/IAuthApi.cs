using Refit;
using Swms.FinishGoods.Web.Features.Auth.Business.Models;

namespace Swms.FinishGoods.Web.Features.Auth.Client;

public interface IAuthApi
{
    [Post("/api/auth/login")]
    Task<LoginResponse> LoginAsync([Body] LoginRequest request);
}