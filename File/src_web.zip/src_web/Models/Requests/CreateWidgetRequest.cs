﻿using SWMS_WebTool.Models.Layout;

namespace SWMS_WebTool.Models.Requests
{
    public class CreateWidgetRequest
    {
        public WidgetType Type;
        public Widget Widget;
    }
}
