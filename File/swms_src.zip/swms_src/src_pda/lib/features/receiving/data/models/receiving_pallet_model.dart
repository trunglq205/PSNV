import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/receiving_entities.dart';

part 'receiving_pallet_model.g.dart';

/// Model nhận từ API cho một pallet đối chiếu khi nhận hàng.
/// API trả dữ liệu thuần; entity dùng trực tiếp (không suy luận trình bày).
@JsonSerializable()
class ReceivingPalletModel {
  final String palletId;
  final String poCode;
  final String itemName;
  final int scanned;
  final int expected;

  const ReceivingPalletModel({
    required this.palletId,
    required this.poCode,
    required this.itemName,
    required this.expected,
    this.scanned = 0,
  });

  factory ReceivingPalletModel.fromJson(Map<String, dynamic> json) =>
      _$ReceivingPalletModelFromJson(json);

  Map<String, dynamic> toJson() => _$ReceivingPalletModelToJson(this);

  ReceivingPallet toEntity() => ReceivingPallet(
        palletId: palletId,
        poCode: poCode,
        itemName: itemName,
        scanned: scanned,
        expected: expected,
      );
}
