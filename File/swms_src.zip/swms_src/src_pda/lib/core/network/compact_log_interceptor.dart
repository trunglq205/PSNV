import 'package:dio/dio.dart';
import 'package:swms_finish_goods/core/logger/app_logger.dart';

class CompactLogInterceptor extends Interceptor {
  String _truncate(Object? data, [int max = 99999]) {
    final s = data?.toString() ?? '';
    return s.length > max ? '${s.substring(0, max)}…' : s;
  }

  @override
  void onRequest(RequestOptions options, RequestInterceptorHandler handler) {
    logger.i(
      '→ ${options.method} ${options.uri}\n'
      '  headers: ${options.headers}\n'
      '  body: ${_truncate(options.data)}',
    );
    handler.next(options);
  }

  @override
  void onResponse(
    Response<dynamic> response,
    ResponseInterceptorHandler handler,
  ) {
    logger.i(
      '← ${response.statusCode} ${response.requestOptions.method} '
      '${response.requestOptions.uri}\n'
      '  headers: ${response.headers.map}\n'
      '  body: ${_truncate(response.data)}',
    );
    handler.next(response);
  }

  @override
  void onError(DioException err, ErrorInterceptorHandler handler) {
    logger.e(
      '✗ ${err.response?.statusCode} ${err.requestOptions.method} '
      '${err.requestOptions.uri}\n'
      '  type: ${err.type}\n'
      '  headers: ${err.requestOptions.headers}\n'
      '  response: ${_truncate(err.response?.data)}',
      error: err,
    );
    handler.next(err);
  }
}
