﻿namespace SWMS_WebTool.Models.Requests
{
    public class DeleteVendorRequest
    {
    }
}
