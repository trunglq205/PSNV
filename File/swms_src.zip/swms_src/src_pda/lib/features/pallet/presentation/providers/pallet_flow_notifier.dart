import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/storage_suggestion.dart';
import 'package:swms_finish_goods/features/pallet/domain/repositories/pallet_repository.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/master_draft.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_flow_state.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_providers.dart';
import 'package:swms_finish_goods/shared/domain/model_repository.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';
import 'package:swms_finish_goods/shared/presentation/providers/model_provider.dart';

part 'pallet_flow_notifier.g.dart';

/// Notifier dùng chung cho Vị trí tạm / Lưu kho / Chuyển-Out.
/// Family theo [PalletFlow] nên mỗi màn có state riêng.
///
///   Bước 1: quét pallet → `by-lot-no/{lotNo}?include=<flow.include>`
///           (loading/error nằm trong `state.pallet` nhờ `executePartial`).
///           Riêng màn Lưu kho gọi thêm `.../storage-suggestion` ở nền.
///   Bước 2: chọn hành động (đã lọc theo màn) → quét vị trí nếu cần → xác nhận.
///   Xong  : về bước 1, giữ `lastResult` để UI hiện toast.
@riverpod
class PalletFlowNotifier extends _$PalletFlowNotifier
    with BaseNotifierMixin<PalletFlowState> {
  PalletRepository get _repo => ref.read(palletRepositoryProvider);

  ModelRepository get _modelRepo => ref.read(modelRepositoryProvider);

  @override
  PalletFlowState build(PalletFlow flow) => const PalletFlowState();

  // ── Điều hướng ───────────────────────────────────────────
  void goStep(int number) {
    final target = PalletFlowStep.fromNumber(number);
    if (target == PalletFlowStep.scanPallet) {
      state = state.copyWith(
        step: target,
        clearAction: true,
        clearLocatorCode: true,
      );
      return;
    }
    // Chỉ sang bước 2 khi đã có pallet.
    if (state.currentPallet != null) state = state.copyWith(step: target);
  }

  void reset() => state = const PalletFlowState();

  // ── Bước 1: quét mã pallet ───────────────────────────────
  Future<void> onPalletScanned(String lotNo) async {
    final code = lotNo.trim();
    if (code.isEmpty) return;

    // Chiều cao thuộc về TỪNG PALLET, không phải phiên làm việc: quét sang mã
    // khác là phải nhập lại. Giữ lại chỉ tiện khi hàng cùng quy cách, nhưng khác
    // quy cách thì gợi ý ra sai tầng mà màn hình không có dấu hiệu nào cho biết
    // chiều cao đang là của pallet trước — thao tác viên không thể phát hiện.
    //
    // Quét lại ĐÚNG mã cũ (nút thử lại, hoặc back rồi quét lại chính nó) thì
    // giữ, khỏi bắt quay số thêm lần nữa.
    final isNewPallet = code != state.lastLotNo;

    // Xoá pallet cũ TRƯỚC khi gọi: nếu mã mới lỗi, run() giữ nguyên state,
    // màn hình sẽ còn treo pallet trước đó ở bước 2 → rất dễ thao tác nhầm.
    // Gợi ý cũng phải xoá, nếu không thẻ gợi ý sẽ hiển thị vị trí của pallet cũ.
    state = state.copyWith(
      step: PalletFlowStep.scanPallet,
      lastLotNo: code,
      actions: const [],
      clearAction: true,
      clearLocatorCode: true,
      clearResult: true,
      clearSuggestion: true,
      clearHeight: isNewPallet,
      // Bản nháp master gắn với model, không gắn với pallet. Không xoá ở đây:
      // quét tiếp pallet cùng model là chuyện thường trong kho, xoá đi thì
      // thao tác viên phải chọn lại y hệt cho từng pallet. Việc đối chiếu
      // model do UI làm qua MasterDraft.matches.
    );

    final next = await ref.read(appActionProvider.notifier).run(() async {
      final pallet = await _repo.getByLotNo(code, include: flow.include);
      final actions = flow.actionsFor(pallet);

      var s = state.copyWith(
        pallet: AsyncData(pallet),
        step: PalletFlowStep.action,
        actions: actions,
      );
      // Chỉ 1 hành động khả dụng → chọn sẵn cho đỡ 1 thao tác.
      if (actions.length == 1) s = s.copyWith(action: actions.first);
      return s;
    });

    if (next == null) return;
    state = next;

    // Sang bước 2 rồi mới nạp gợi ý: thao tác viên thấy thẻ pallet ngay,
    // thẻ gợi ý tự hiện loading rồi có kết quả sau.
    await _loadSuggestion(code);
  }

  /// Thử lại lookup với mã vừa quét (khi bước 1 báo lỗi).
  Future<void> retry() async {
    final code = state.lastLotNo;
    if (code != null) await onPalletScanned(code);
  }

  // ── Gợi ý vị trí lưu kho (chỉ màn Storing) ───────────────

  /// Nạp `GET by-lot-no/{lotNo}/storage-suggestion?palletHeightCm=...`
  ///
  /// KHÔNG đi qua `appActionProvider`: gợi ý chỉ là tham khảo, hỏng thì không
  /// được bung overlay lỗi toàn màn và chặn thao tác lưu kho. Lỗi nằm gọn trong
  /// `state.suggestion` để thẻ gợi ý tự hiện và có nút thử lại.
  Future<void> _loadSuggestion(String lotNo) async {
    if (!flow.needsStorageSuggestion) return;

    // Không có hành động khả dụng (pallet đã lưu kho rồi, đang bị OQC giữ mẫu,
    // trạng thái không cho lưu...) thì chẳng có gì để đặt vào vị trí — gợi ý vô
    // nghĩa. Chặn ở đây thay vì ở UI để khỏi tốn một lượt gọi mạng trên PDA,
    // và để cả retry / đổi chiều cao cũng tuân theo.
    if (state.actions.isEmpty) return;

    state = state.copyWith(
      suggestion: const AsyncLoading<StorageSuggestion?>(),
    );

    try {
      final result = await _repo.getStorageSuggestion(
        lotNo,
        palletHeightCm: state.palletHeightCm,
      );
      // PDA quét rất nhanh: kết quả về muộn của pallet cũ không được ghi đè
      // gợi ý của pallet đang xem.
      if (state.lastLotNo != lotNo) return;
      state = state.copyWith(
        suggestion: AsyncData(result),
        masterDraft: result.model != null
            ? MasterDraft(
                modelCode: result.model!,
                areaId: result.master?.areaId,
                rackRows: result.master?.rackRows,
              )
            : null,
      );
    } catch (e, st) {
      if (state.lastLotNo != lotNo) return;
      state = state.copyWith(suggestion: AsyncError<StorageSuggestion?>(e, st));
    }
  }

  /// Nạp lại gợi ý cho pallet đang xem (nút thử lại trên thẻ gợi ý).
  Future<void> reloadSuggestion() async {
    final code = state.lastLotNo;
    if (code != null) await _loadSuggestion(code);
  }

  /// Thao tác viên vừa nhập chiều cao pallet ở dialog bổ sung thông tin.
  /// Giá trị <= 0 coi như "không biết" (gửi null, server trả cảnh báo).
  Future<void> setPalletHeight(int? heightCm) async {
    final value = (heightCm != null && heightCm > 0) ? heightCm : null;
    if (value == state.palletHeightCm) return;

    state = state.copyWith(palletHeightCm: value, clearHeight: value == null);
    await reloadSuggestion();
  }

  // ── Khai báo master cho model của pallet đang xem ─────────

  /// `PATCH /api/models/suggestion/by-code/{modelCode}`
  ///
  /// Đi qua `appActionProvider.run()` chứ KHÔNG như `_loadSuggestion`: đây là
  /// ghi dữ liệu master dùng chung cho mọi pallet cùng model về sau, hỏng thì
  /// thao tác viên phải biết ngay — không được nuốt lỗi vào một thẻ gợi ý.
  ///
  /// KHÔNG đụng `palletHeightCm`: chiều cao là của riêng pallet đang cầm, còn
  /// master là của cả model. Khai master xong mà xoá mất chiều cao vừa quay số
  /// thì gợi ý nhảy sang tầng khác ngay trước mắt người dùng.
  Future<void> saveMasterSuggestion({
    int? suggestAreaId,
    List<int>? suggestRackRow,
  }) async {
    if (state.currentPallet == null) return;

    // Lấy mã model từ GỢI Ý, không từ `pallet.models`.
    //
    // `pallet.models` là chuỗi tổng hợp: pallet trộn nhiều model ra "A123,
    // B456", PATCH by-code khi đó hoặc 404, hoặc tệ hơn là khớp trúng một mã
    // khác rồi ghi master sai cho model không liên quan.
    //
    // `suggestion.model` là EffectiveModel server đã chọn (lots.model, hoặc
    // model chiếm qty lớn nhất) — đúng bản ghi master mà chính server vừa tra
    // để ra gợi ý này. Ghi vào đó là ghi đúng chỗ.
    final modelCode = state.suggestion.value?.model?.trim() ?? '';
    if (modelCode.isEmpty) return;

    final lotNo = state.lastLotNo;

    final ok = await ref.read(appActionProvider.notifier).run(() async {
      await _modelRepo.updateSuggestion(
        modelCode: modelCode,
        suggestAreaId: suggestAreaId,
        suggestRackRow: suggestRackRow,
      );
      // run() coi giá trị trả về là thành công -> phải trả non-null.
      return true;
    });

    if (ok != true) return;

    // Giữ lại đúng thứ vừa gửi để mở lại dialog thấy nguyên lựa chọn cũ.
    // Không đọc ngược từ gợi ý: gợi ý trả `suggestedAreaCode` (mã, có thể suy
    // từ last lot), không trả id khu đã khai — dựng lại từ đó sẽ ra sai.
    state = state.copyWith(
      masterDraft: MasterDraft(
        modelCode: modelCode,
        areaId: suggestAreaId,
        rackRows: suggestRackRow,
      ),
    );

    // Master đổi thì thứ hạng locator server tính ra cũng đổi -> nạp lại.
    // Chỉ nạp khi vẫn đang ở đúng pallet đó: overlay có thể vừa tắt là thao tác
    // viên đã quét mã khác, nạp theo lotNo cũ sẽ ghi đè gợi ý của pallet mới.
    if (state.lastLotNo == lotNo) await reloadSuggestion();
  }

  // ── Bước 2: quét vị trí ─────────────────────────────────
  void selectAction(PalletAction action) {
    if (!state.actions.contains(action)) return;
    // Đổi hành động thì bỏ mã vị trí đã quét trước đó.
    state = state.copyWith(action: action, clearLocatorCode: true);
  }

  /// Kiểm tra vị trí vừa quét, trả về các pallet KHÁC đang nằm ở đó:
  ///   - null  → lỗi (404 đã hiện qua overlay) hoặc người dùng đã đổi pallet.
  ///   - rỗng  → vị trí trống, đã nhận mã.
  ///   - có mã → CHƯA nhận mã; UI hỏi xác nhận rồi gọi [confirmLocator].
  Future<List<String>?> checkLocator(String raw) async {
    final code = raw.trim();
    final pallet = state.currentPallet;
    if (code.isEmpty || pallet == null || state.step != PalletFlowStep.action) {
      return null;
    }

    state = state.copyWith(clearLocatorCode: true);

    final lotNo = pallet.lotNo.trim();
    final loc = await ref.read(appActionProvider.notifier).run(() async {
      final res = await _repo.getLocatorPallets(code);
      // Mỗi màn chỉ nhận vị trí thuộc đúng loại khu của nó.
      if (res.mapType != flow.mapType) {
        throw LocatorWrongAreaException(
          locatorCode: res.locatorCode,
          area: res.areaLabel,
        );
      }
      return res;
    });
    if (loc == null) return null;

    if (state.step != PalletFlowStep.action ||
        state.currentPallet?.lotNo.trim() != lotNo) {
      return null;
    }

    final others = loc.pallets
        .map((e) => e.trim())
        .where((e) => e.isNotEmpty && e != lotNo)
        .toList();

    if (others.isEmpty) state = state.copyWith(scannedLocatorCode: code);
    return others;
  }

  /// Người dùng đã đồng ý gán vào vị trí đang có pallet.
  void confirmLocator(String locatorCode) {
    if (state.step != PalletFlowStep.action || state.currentPallet == null) {
      return;
    }
    state = state.copyWith(scannedLocatorCode: locatorCode.trim());
  }

  void clearLocator() => state = state.copyWith(clearLocatorCode: true);

  // ── Xác nhận ─────────────────────────────────────────────
  /// Trả về kết quả nếu thành công (UI hiện toast), null nếu lỗi/chưa đủ điều kiện.
  Future<LocatorChangeResult?> submit() async {
    final pallet = state.currentPallet;
    final action = state.action;
    if (pallet == null || action == null || !state.canSubmit) return null;
    final code = state.scannedLocatorCode ?? '';

    final result = await ref.read(appActionProvider.notifier).run(() async {
      return switch (action) {
        PalletAction.assign ||
        PalletAction.moveReceiving ||
        PalletAction.moveStoring ||
        PalletAction.moveVanning => await _repo.assignLocator(
          lotId: pallet.id,
          locatorCode: code,
          allowedMapType: flow.mapType,
        ),
        PalletAction.store => await _repo.store(
          lotId: pallet.id,
          locatorCode: code,
        ),
        PalletAction.vanning => await _repo.assignLocator(
          lotId: pallet.id,
          locatorCode: code,
          allowedMapType: flow.mapType,
        ),
      };
    });

    if (result != null) {
      // Màn Detail (nếu đang cache) nạp lại vị trí / allowedActions mới.
      ref.invalidate(palletProvider(pallet.lotNo));
      // Xong 1 pallet -> về bước 1 chờ quét tiếp, state sạch hoàn toàn
      // (kể cả chiều cao — xem ghi chú ở onPalletScanned).
      state = PalletFlowState(lastResult: result);
    }
    return result;
  }

  // ── Router cho scan stream của PDA ───────────────────────
  /// Bước 1: mã là pallet. Bước 2: mã là vị trí → trả pallet khác đang ở đó.
  Future<List<String>?> onScan(String raw) async {
    final data = raw.trim();
    if (data.isEmpty) return null;

    switch (state.step) {
      case PalletFlowStep.scanPallet:
        await onPalletScanned(data);
        return null;
      case PalletFlowStep.action:
        return checkLocator(data);
    }
  }
}
