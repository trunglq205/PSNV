﻿namespace Swms.FinishGoods.Api.Features.Categories;

/// <summary>
/// Domain entity map bảng master.categories. Không lộ ra ngoài — chỉ trả CategoryResponse.
/// PK/business key là <c>code</c> (string, vd "DECT", "DP") — bảng không có cột id riêng.
/// </summary>
public class CategoryEntity
{
    public int Code { get; set; }
    public string? Name { get; set; }
    public string? Description { get; set; }
    public string? Bd { get; set; }
    public string? PlantCode { get; set; }
    public string? Product { get; set; }
    public string? SlockPmd { get; set; }
    public string? SlockFa { get; set; }
    public string? SlockScs { get; set; }
    public string? SlockJpt { get; set; }
    public string? SlockPort { get; set; }
    public string? ProductionVersion { get; set; }
    public bool IsDeleted { get; set; }
    public DateTime CreatedAt { get; set; }
    public string? CreatedBy { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}