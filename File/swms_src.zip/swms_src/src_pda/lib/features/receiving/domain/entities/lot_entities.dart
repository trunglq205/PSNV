/// Kết quả tạo pallet.
class CreatedLot {
  final int id;
  final String lotNo; // 310 + yymmdd + seq(3)
  final String detailLevel;
  final int boxCount;
  final int lineCount;

  const CreatedLot({
    required this.id,
    required this.lotNo,
    required this.detailLevel,
    required this.boxCount,
    required this.lineCount,
  });
}

/// Pallet đầy đủ (đọc lại sau khi quét barcode).
class Lot {
  final int id;
  final String lotNo;
  final String categoryCode;
  final String lotType;
  final int? locatorId;
  final String detailLevel;
  final int? boxCount;
  final String inspectionStatus;
  final bool isUrgent;
  final bool isEvenPallet;
  final DateTime? productionDate;
  final List<LotBox> boxes;

  const Lot({
    required this.id,
    required this.lotNo,
    required this.categoryCode,
    required this.lotType,
    required this.detailLevel,
    required this.inspectionStatus,
    required this.isUrgent,
    required this.isEvenPallet,
    this.locatorId,
    this.boxCount,
    this.productionDate,
    this.boxes = const [],
  });
}

class LotBox {
  final int id;
  final String boxNo;
  final String? psnvPo;
  final String? customerPo;
  final DateTime? productionDate;
  final List<BoxLine> lines;

  const LotBox({
    required this.id,
    required this.boxNo,
    this.psnvPo,
    this.customerPo,
    this.productionDate,
    this.lines = const [],
  });
}

class BoxLine {
  final int id;
  final String model;
  final double qty;
  final String? serialNo;
  final int? cartonQty;

  const BoxLine({
    required this.id,
    required this.model,
    required this.qty,
    this.serialNo,
    this.cartonQty,
  });
}

/// lotNo do server đề xuất cho một category, chưa persist.
/// Client dùng làm giá trị mặc định khi tạo lot; vẫn phải xử lý 409 khi POST.
class NextLotNo {
  final String lotNo;
  final int categoryCode;
  final String datePart;
  final int sequence;

  const NextLotNo({
    required this.lotNo,
    required this.categoryCode,
    required this.datePart,
    required this.sequence,
  });
}