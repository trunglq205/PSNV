import 'package:flutter/foundation.dart';

/// Phân loại sản phẩm — danh sách lấy từ `GET /api/categories/options`.
///
/// Giữ tên field cũ của enum để các chỗ dùng không phải đổi:
/// - [value]: mã số — lưu `wms.part_cards.category`, đưa vào payload QR.
/// - [key]: tên — in trên tem (vd `SP(MW-MS)`).
///
/// So sánh theo [value]: cùng mã là cùng cate, bất kể tên.
@immutable
class Category {
  const Category({required this.value, required this.key});

  final int value;
  final String key;

  @override
  bool operator ==(Object other) =>
      identical(this, other) || other is Category && other.value == value;

  @override
  int get hashCode => value.hashCode;

  @override
  String toString() => key;
}

/// Mã Cate mà NGHIỆP VỤ phụ thuộc cứng (không lấy từ danh mục được vì
/// logic rẽ nhánh theo đúng mã này).
abstract final class CategoryCodes {
  /// PAPVN — lot dạng stocky, lotNo lấy từ server.
  static const int pap = 912;
}

extension CategoryListX on List<Category> {
  /// Tìm theo mã; không có (null / mã đã bị xoá khỏi danh mục) → null.
  Category? byValue(int? value) {
    if (value == null) return null;
    for (final c in this) {
      if (c.value == value) return c;
    }
    return null;
  }

  /// Tìm theo tên — khớp tuyệt đối như `tryFromKey` cũ.
  Category? byKey(String? key) {
    if (key == null) return null;
    for (final c in this) {
      if (c.key == key) return c;
    }
    return null;
  }
}