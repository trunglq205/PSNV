import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/extensions/navigation_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_tab_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_list_notifier.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_list_card.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_list_skeleton.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_status_ui.dart';

// ─────────────────────────────────────────────────────────────
//  Danh sách Chỉ thị lấy hàng (Shipment Instruction).
// ─────────────────────────────────────────────────────────────

@RoutePage()
class ShipmentInstructionListScreen extends ConsumerWidget {
  const ShipmentInstructionListScreen({super.key});

  Future<void> _openDetail(BuildContext context, WidgetRef ref, int id) async {
    await context.router.pushPath('/shipment-instructions/$id');
    // Quay về có thể đã soạn thêm → cập nhật tiến độ, không nháy loading.
    if (context.mounted) {
      await ref
          .read(shipmentInstructionListProvider.notifier)
          .load(silent: true);
    }
  }

  /// Tab "Tất cả" (value null) + mỗi trạng thái một tab.
  /// counts null (server chưa trả) → ẩn badge.
  static List<AppTabItem<SiStatus?>> _tabs(Map<SiStatus, int>? counts) => [
    AppTabItem(
      value: null,
      label: LocaleKeys.shipment_instruction_filter_all.tr(),
      count: counts?.values.fold<int>(0, (a, b) => a + b),
    ),
    for (final s in SiStatus.values)
      AppTabItem(
        value: s,
        label: s.label(),
        count: counts == null ? null : (counts[s] ?? 0),
      ),
  ];

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(shipmentInstructionListProvider);
    final notifier = ref.read(shipmentInstructionListProvider.notifier);

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.shipment_instruction_title.tr(),
        subtitle: LocaleKeys.shipment_instruction_subtitle.tr(),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: () => notifier.load(),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
              AppDimens.md,
              AppDimens.sm,
              AppDimens.md,
              AppDimens.sm,
            ),
            child: AppTabBar<SiStatus?>(
              items: _tabs(state.statusCounts),
              selected: state.filter,
              onChanged: notifier.setFilter,
            ),
          ),
          Expanded(
            child: state.page.when(
              loading: () => const SiListSkeleton(),
              // Dùng .widget chứ không .page: .page có Scaffold + AppBar riêng,
              // lồng vào body sẽ ra hai thanh tiêu đề.
              error: (e, _) => Center(
                child: AppErrorView.widget(
                  message: LocaleKeys.shipment_instruction_load_error.tr(),
                  onRetry: notifier.load,
                ),
              ),
              data: (page) => _SiListView(
                page: page,
                loadMoreFailed: state.loadMoreFailed,
                onRefresh: () => notifier.load(silent: true),
                onLoadMore: notifier.loadMore,
                onOpen: (id) => _openDetail(context, ref, id),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _SiListView extends StatelessWidget {
  final ShipmentInstructionPage page;
  final bool loadMoreFailed;
  final Future<void> Function() onRefresh;
  final VoidCallback onLoadMore;
  final ValueChanged<int> onOpen;

  const _SiListView({
    required this.page,
    required this.loadMoreFailed,
    required this.onRefresh,
    required this.onLoadMore,
    required this.onOpen,
  });

  @override
  Widget build(BuildContext context) {
    final items = page.items;

    if (items.isEmpty) {
      // Vẫn phải cuộn được thì RefreshIndicator mới kéo được.
      return RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          physics: const AlwaysScrollableScrollPhysics(),
          children: [
            const SizedBox(height: 120),
            Center(
              child: Text(
                LocaleKeys.shipment_instruction_empty.tr(),
                style: AppTextStyles.body.copyWith(color: context.swms.text3),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.separated(
        physics: const AlwaysScrollableScrollPhysics(),
        padding: const EdgeInsets.fromLTRB(
          AppDimens.md,
          0,
          AppDimens.md,
          AppDimens.md,
        ),
        itemCount: items.length + (page.hasMore ? 1 : 0),
        separatorBuilder: (_, _) => const SizedBox(height: AppDimens.sm),
        itemBuilder: (context, i) {
          if (i == items.length) {
            return _LoadMoreFooter(
              // Key theo số trang: mỗi trang mới dựng footer mới → initState
              // chạy lại → tự tải tiếp nếu footer vẫn trong vùng hiển thị.
              key: ValueKey(page.page),
              failed: loadMoreFailed,
              onLoadMore: onLoadMore,
            );
          }
          final si = items[i];
          return SiListCard(
            si: si,
            onTap: () => onOpen(si.id),
            onStartPicking: () => context.openKitting(si.id),
          );
        },
      ),
    );
  }
}

/// Footer cuối list: vừa được dựng (tức đã cuộn tới gần) là tự gọi tải trang
/// kế — không cần ScrollController, và vẫn chạy khi trang đầu quá ngắn chưa
/// lấp đầy màn hình (lúc đó không có sự kiện cuộn nào).
class _LoadMoreFooter extends StatefulWidget {
  final bool failed;
  final VoidCallback onLoadMore;

  const _LoadMoreFooter({
    super.key,
    required this.failed,
    required this.onLoadMore,
  });

  @override
  State<_LoadMoreFooter> createState() => _LoadMoreFooterState();
}

class _LoadMoreFooterState extends State<_LoadMoreFooter> {
  @override
  void initState() {
    super.initState();
    // Không gọi thẳng trong initState: đổi state provider giữa lúc build sẽ lỗi.
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted && !widget.failed) widget.onLoadMore();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: AppDimens.md),
      child: Center(
        child: widget.failed
            ? AppErrorView.widget(
                message: LocaleKeys.shipment_instruction_load_more_error.tr(),
                onRetry: widget.onLoadMore,
              )
            : const SizedBox.square(
                dimension: 22,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
      ),
    );
  }
}
