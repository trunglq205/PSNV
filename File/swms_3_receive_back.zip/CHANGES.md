# Mục 3 — SCS WH nhận lại pallet từ FA

Vòng hàng đi–về đến đây đã đủ một chu kỳ:

```
2b  SCS WH quét nhận hàng từ khách        → serial = received
2c  FA xin back → SCS duyệt + chỉ thị     → serial = at_fa   (B4 chọn FIFO)
2d  FA rework xong, đóng Pallet ID        → serial giữ at_fa, gắn pallet mới
 3  SCS WH quét MỘT mã pallet để nhận lại → serial = returned ★ gói này
```

---

## 1. Tư tưởng: nhận lại bằng MỘT lần quét, không quét lại từng con

FA đã quét từng serial khi đóng pallet ở mục 2d — pallet đó là một danh sách
serial đã được server xác nhận. Bắt SCS quét lại 400 con nữa là làm hai lần
một việc, mà lần thứ hai không thêm thông tin gì: nếu FA quét sai thì mục 2d
đã ghi vào nhật ký lệch rồi.

Nên mục 3 chỉ cần **mã pallet**. Server tự chuyển mọi serial `at_fa` của phiếu
đang nằm trên pallet đó sang `returned`.

Hai con số trả về:

| | nghĩa |
|---|---|
| **Đã nhận** | số con chuyển được `at_fa` → `returned` |
| **Bỏ qua** | con nằm trên pallet nhưng không chuyển: đã về trước đó, hoặc thuộc phiếu khác |

“Bỏ qua” **không phải lỗi** — là con số để WH đối chiếu. Quét lại pallet đã
nhận thì `Đã nhận = 0` và server trả lỗi `NothingToReceive` thay vì âm thầm
ghi lại `returned_at`:

```sql
UPDATE ... WHERE pallet_id = @palletId AND doc_id = @docId
  AND status = N'at_fa'   -- ← điều kiện nằm TRONG WHERE
```

Lần quét thứ hai không khớp dòng nào, nên `returned_at` của lần nhận thật
không bị ghi đè — mốc thời gian giữ nguyên.

## 2. Nút “Nhận lại từ FA” KHÔNG gác theo phiếu còn mở

Đây là chỗ dễ làm sai nhất. “Đóng phiếu” ở mục 2b nói về **SL nhận từ KHÁCH** —
chốt xong là gửi mail bảng lệch cho FA. Vòng đi–về với FA xảy ra **sau** đó.

Một phiếu đã chốt vẫn có thể còn 300 con đang ở FA phải nhận về. Nếu gác nút
theo `doc.isOpen` như hai nút kia thì hàng ở FA không có đường về.

Điều kiện hiện nút: `rework_refurbish.process` **và** phiếu đã nhận được hàng
(`receivedQty > 0`). Không gác theo trạng thái phiếu.

## 3. Không có SQL mới

Hai cột `sent_fa_at` / `returned_at` đã thêm ở gói **2c**
(`return_back_request_schema.sql`). Mục 3 chỉ ghi vào `returned_at` + đổi
`status`, không thêm bảng hay cột nào. **Không phải chạy script nào cho gói
này** — nhưng phải chạy xong 2c và 2d trước.

---

## 4. File trong gói

### API — `webapi/src_webapi/Swms.FinishGoods.API/`

| File | Việc |
|---|---|
| `Features/ReturnInstructions/Api/ReturnFaPalletModels.cs` | + `ReceiveBackRequest` / `ReceiveBackResponse` / `BackReceiveMsg` |
| `Features/ReturnInstructions/Api/ReturnFaPalletsController.cs` | + `POST {docId}/receive-back` |
| `Features/ReturnInstructions/ReturnFaPalletEntity.cs` | + `ReturnReceiveBackResult` |
| `Features/ReturnInstructions/Business/IReturnFaPalletService.cs` | + `ReceiveBackAsync` |
| `Features/ReturnInstructions/Business/ReturnFaPalletService.cs` | + `ReceiveBackAsync` (3 lỗi phân biệt rõ) |
| `Features/ReturnInstructions/DataAccess/IReturnInstructionRepository.cs` | + `ReceiveBackPalletAsync` |
| `Features/ReturnInstructions/DataAccess/ReturnInstructionRepository.cs` | + `ReceiveBackPalletAsync` |
| `Resources/SharedResource.{vi,en,zh,ja}.resx` | + 3 khoá lỗi (748 khoá, 4 ngôn ngữ bằng nhau) |

Endpoint: `POST /api/return-instructions/{docId}/receive-back`
quyền `rework_refurbish.process` — việc của SCS WH.

Ba lỗi phân biệt, không gộp một câu chung chung:

| Lỗi | Khi nào | HTTP |
|---|---|---|
| `PalletNotFound` | không có pallet nào mang mã đó | 404 |
| `PalletNotOfDoc` | pallet có thật, nhưng không con nào thuộc phiếu này — gần như chắc là quét vào phiếu khác | 400 |
| `NothingToReceive` | pallet của phiếu này, nhưng không còn con nào ở FA — có thể đã nhận trước đó | 400 |

### PDA — `pda/src_pda/lib/features/return_instruction/`

| File | Mới? |
|---|---|
| `presentation/dialogs/return_receive_back_dialog.dart` | **MỚI** — dialog một lần quét |
| `presentation/return_instruction_list_page.dart` | sửa — nút “Nhận lại từ FA” |
| `domain/entities/return_fa_entities.dart` | sửa — + `ReceiveBackResult` |
| `domain/repositories/return_instruction_repository.dart` | sửa — + `receiveBack` |
| `data/models/return_fa_model.dart` (+ `.g.dart`) | sửa — + 2 model |
| `data/datasources/return_instruction_remote_data_source.dart` (+ `.g.dart`) | sửa — + `receiveBack` |
| `data/return_instruction_repository_impl.dart` | sửa — + `receiveBack` |

Làm **dialog** chứ không làm màn riêng: việc này đúng một thao tác. Dialog tự
giữ mở sau khi nhận xong để WH đọc hai con số rồi quét tiếp pallet kế tiếp —
đóng rồi phải mở lại là bắt họ đi hai bước thừa cho mỗi pallet.

Không cần route mới, nên **không phải sinh lại `app_router.gr.dart`**.

---

## 5. Việc phải làm tay — i18n PDA

Như các gói trước, **không** gửi kèm 4 file `assets/translations/*.json`,
`codegen_loader.g.dart`, `locale_keys.g.dart`: bản trong máy tôi thiếu khoá so
với bản của anh (`vanning`, `stocky`, …), ghi đè là **xoá bản dịch của anh**.

Chạy script, nó tự chèn vào đúng chỗ và **chạy lại nhiều lần không sao**:

```bash
cd <thu-muc-pda>        # chỗ có pubspec.yaml
python3 tools/pda_i18n_ns.py tools/recv_i18n.json .
```

Thêm namespace `return_recv` (9 khoá) vào:
- `assets/translations/{vi,en,zh,ja}.json`
- `lib/core/localization/generated/codegen_loader.g.dart` (cả 4 map)
- `lib/core/localization/generated/locale_keys.g.dart`

Script in ra từng chỗ nó sửa. Nếu namespace đã có thì nó bỏ qua và nói rõ.

---

## 6. Thứ tự áp

1. Giải nén lên source (ghi đè).
2. Chạy script i18n PDA ở mục 5.
3. Build API → build PDA. **Không phải chạy SQL.**
4. Gán quyền: `rework_refurbish.process` cho role SCS WH (đã có từ gói 2a/2b —
   không có gì mới cần gán cho mục 3).

---

## 7. Đã kiểm / chưa kiểm

**Đã kiểm tĩnh** (container không có .NET SDK, Flutter SDK, SQL Server nên
không build/chạy được):

- cân `{}` `()` `[]` toàn bộ slice API và các file PDA, sau khi bỏ chuỗi + chú thích
- 4 resx: well-formed, 748 khoá, **tập khoá 4 ngôn ngữ bằng nhau**, số `{0}`/`{1}`
  khớp số tham số ở từng chỗ gọi
- interface ↔ implementation: datasource 5/5, repository 7/7
- `LocaleKeys.return_recv_*`: khai báo đủ, có giá trị ở **cả 4** ngôn ngữ,
  `namedArgs: {'count': …}` khớp `{count}` trong câu
- `_DocList` / `_DocTile`: tham số khai báo ↔ truyền vào khớp hết
- line ending + BOM từng file giữ nguyên như bản anh đang dùng

**Chưa kiểm**: chưa build, chưa chạy. Cần anh build thử rồi báo lỗi nếu có.

---

## 8. Còn lại của 2d + 3 — màn Web

Hai thứ tôi hẹn gộp vào gói này nhưng **chưa làm**, vì sẽ lại là một màn Web
đầy đủ nữa:

1. **Màn xem nhật ký serial lệch** (`wms.return_serial_mismatches`) — SCS cần
   thấy FA quét ra con nào không khớp để đi tìm, và đánh dấu đã xử lý.
   API đã xong: `GET {docId}/mismatches`, `POST mismatches/{id}/resolve`.
2. **Cột “Còn ở FA” + khối “Đã giao lại”** trên màn Tái gia công — hiện giờ
   nhìn màn Web không biết còn bao nhiêu con đang ở FA.

Nói trước để anh chọn: làm tiếp hai thứ này, hay sang **mục 5** rồi quay lại.

## 9. Điểm còn mở (nhắc lại, chưa giải quyết)

- `POST /api/pallets/split` vẫn **chưa** cập nhật `return_instruction_serials.pallet_id`:
  tách pallet hàng RW/RB xong thì sổ serial còn trỏ pallet cũ.
- Toạ độ badge RW/RB trên tem TSPL (MJ8001) **chưa in thử thật**. Nhờ anh in
  một tem rồi gửi ảnh để tôi chỉnh.
- Luật xử lý hàng **NG tại FA** vẫn “chưa rõ” — chưa có đường đi cho con `ng`.
- Mục 2c **chưa khai mail event** nào. Nếu cần mail cho FA/SCS ở các bước duyệt,
  tôi thêm tab thứ 3 vào dialog bánh xe.
