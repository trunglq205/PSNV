using Swms.FinishGoods.API.Features.AbnormalReports.Business;
using Swms.FinishGoods.API.Features.AbnormalReports.DataAccess;

namespace Swms.FinishGoods.API.Features.AbnormalReports;

public static class AbnormalReportModule
{
    public static IServiceCollection AddAbnormalReportFeature(this IServiceCollection services)
    {
        services.AddScoped<INgReportService, NgReportService>();
        services.AddScoped<INgReportRepository, NgReportRepository>();
        return services;
    }
}
