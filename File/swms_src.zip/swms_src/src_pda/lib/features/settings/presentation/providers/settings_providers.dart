import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/settings/data/settings_local_data_source.dart';
import 'package:swms_finish_goods/features/settings/data/settings_repository_impl.dart';
import 'package:swms_finish_goods/features/settings/domain/settings_repository.dart';

part 'settings_providers.g.dart';

@riverpod
SettingsLocalDataSource settingsLocalDataSource(Ref ref) =>
    SettingsLocalDataSourceImpl(
      ref.watch(appLocalManagerProvider).requireValue,
    );

@riverpod
SettingsRepository settingsRepository(Ref ref) =>
    SettingsRepositoryImpl(ref.watch(settingsLocalDataSourceProvider));
