import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Chuyển JSON → entity cho mục 2c.
//
//  VIẾT TAY `fromJson`, KHÔNG dùng json_serializable như các model khác của
//  feature này. Lý do là cân nhắc, không phải lười: thêm một model có
//  @JsonSerializable là phải chạy lại build_runner, mà build_runner trong
//  source hiện tại đang vỡ (hai file cùng khai `@RoutePage() class
//  VanningPage`). Bộ mục 2c vì vậy làm sao để KHÔNG cần sinh mã: không
//  annotation, không retrofit, không @riverpod, không @RoutePage.
//
//  Khi nào build_runner chạy lại được thì chuyển sang @JsonSerializable cũng
//  không đổi gì ở lớp trên — entity và repository giữ nguyên.
// ─────────────────────────────────────────────────────────────

/// Đọc số nguyên chịu được cả `int`, `double` và chuỗi.
///
/// System.Text.Json trả `int` đúng kiểu, nhưng một cột `decimal` phía SQL hay
/// một tầng proxy có thể biến nó thành `420.0` — ép thẳng `as int` sẽ ném giữa
/// lúc WH đang quét.
int _int(Object? v, [int fallback = 0]) => switch (v) {
      int i => i,
      double d => d.round(),
      num n => n.round(),
      String s => int.tryParse(s) ?? fallback,
      _ => fallback,
    };

bool _bool(Object? v, [bool fallback = false]) => switch (v) {
      bool b => b,
      String s => s.toLowerCase() == 'true',
      _ => fallback,
    };

String? _str(Object? v) {
  if (v == null) return null;
  final s = v.toString().trim();
  return s.isEmpty ? null : s;
}

/// Mốc thời gian. Trả null khi thiếu hoặc không parse được, chứ KHÔNG trả
/// `DateTime.now()`: một mốc bịa ra trông y như mốc thật trên màn hình.
DateTime? _date(Object? v) {
  final s = _str(v);
  return s == null ? null : DateTime.tryParse(s);
}

// _rows / _strings đã XOÁ cùng backDeliverResultFromJson — chỉ lượt quét giao
// cần đọc danh sách lồng. Để lại là analyzer báo unused_element.

/// Khối `back` lồng trong response của phiếu.
///
/// Thiếu hẳn khối đó (phiếu từ API cũ) ⇒ trả một BackFlow rỗng, không ném:
/// màn danh sách phiếu phải mở được kể cả khi phần 2c chưa deploy.
BackFlow backFlowFromJson(Map<String, Object?>? j) {
  if (j == null) return const BackFlow();
  return BackFlow(
    status: BackStatus.from(_str(j['status'])),
    step: _str(j['step']),
    requested: _bool(j['requested']),
    isOpen: _bool(j['isOpen']),
    isDelivered: _bool(j['isDelivered']),
    isPartlyDelivered: _bool(j['isPartlyDelivered']),
    isCancelled: _bool(j['isCancelled']),
    remainQty: _int(j['remainQty']),
    sentQty: _int(j['sentQty']),
    atFaQty: _int(j['atFaQty']),
    returnedQty: _int(j['returnedQty']),
    note: _str(j['note']),
    requestedBy: _str(j['requestedBy']),
    requestedAt: _date(j['requestedAt']),
    approvedBy: _str(j['approvedBy']),
    approvedAt: _date(j['approvedAt']),
    faComment: _str(j['faComment']),
    scsComment: _str(j['scsComment']),
    scsApprovedBy: _str(j['scsApprovedBy']),
    scsApprovedAt: _date(j['scsApprovedAt']),
    // Khoá thiếu ⇒ false ⇒ ẩn nút giao. Xem ghi chú ở BackFlow.canDeliver.
    canDeliver: _bool(j['canDeliver']),
    lines: _reqLines(j['lines']),
  );
}

BackDelivery backDeliveryFromJson(Map<String, Object?> j) => BackDelivery(
      lotNo: _str(j['lotNo']) ?? '',
      serialCount: _int(j['serialCount']),
      deliveredAt: _date(j['deliveredAt']) ?? DateTime.now(),
      deliveredBy: _str(j['deliveredBy']),
    );

BackRemainModel backRemainModelFromJson(Map<String, Object?> j) =>
    BackRemainModel(
      model: _str(j['model']) ?? '',
      qty: _int(j['qty']),
    );

/// Dòng FA xin. API cũ không gửi khoá `lines` ⇒ rỗng ⇒ hiểu là xin trọn phần
/// còn ở kho, đúng nghĩa cũ.
List<BackReqLine> _reqLines(Object? v) => v is List
    ? v
        .whereType<Map>()
        .map((e) => e.cast<String, Object?>())
        .map((m) => BackReqLine(
              model: _str(m['model']) ?? '',
              reqQty: _int(m['reqQty']),
            ))
        .where((l) => l.model.isNotEmpty)
        .toList()
    : const [];

BackPallet backPalletFromJson(Map<String, Object?> j) => BackPallet(
      id: _int(j['id']),
      lotNo: _str(j['lotNo']) ?? '',
      locatorCode: _str(j['locatorCode']),
      serialCount: _int(j['serialCount']),
    );

// backDeliverResultFromJson đã XOÁ (11/11) cùng BackDeliverResult.
