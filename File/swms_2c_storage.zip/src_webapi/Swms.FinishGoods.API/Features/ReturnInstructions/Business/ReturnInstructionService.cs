using System.Net;
using System.Text;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

public class ReturnInstructionService : IReturnInstructionService
{
    /// <summary>
    /// Mã sự kiện mail báo FA. Dòng tương ứng nằm trong
    /// <c>master.email_events</c> (module <c>RECEIVING</c>) — xem
    /// <c>return_instruction_schema.sql</c>.
    ///
    /// Người nhận KHÔNG liệt kê ở đây: khai trong màn Cấu hình email với
    /// <c>department = 'FA'</c>. Thêm bộ phận khác vào cấu hình là họ tự nhận,
    /// không phải build lại.
    /// </summary>
    private const string MailEventCreated = "RETURN_INSTRUCTION_CREATED";

    /// <summary>
    /// Mã sự kiện mail báo FA SỐ THỰC NHẬN (mục 2b) — xem
    /// <c>return_actual_schema.sql</c>. Người nhận khai trong màn Cấu hình
    /// email, cùng cách với sự kiện tạo phiếu.
    /// </summary>
    private const string MailEventActual = "RETURN_ACTUAL_CONFIRMED";

    /// <summary>
    /// Trần số dòng một phiếu. Nhập tay trên màn hình nên thực tế vài chục;
    /// đặt trần để một request hỏng không ghi hàng nghìn dòng trong một
    /// transaction.
    /// </summary>
    private const int MaxLinesPerDoc = 200;

    /// <summary>
    /// Trần serial cho MỘT lần nhận (một pallet). Một pallet thực tế vài trăm
    /// con; đặt trần để một request hỏng không ghi hàng chục nghìn dòng trong
    /// một transaction, và để câu tra chủ serial không vượt giới hạn parameter.
    /// </summary>
    private const int MaxSerialsPerPallet = 500;

    /// <summary>
    /// Trần số thùng một pallet. Có trần serial rồi vẫn cần trần này: mỗi thùng
    /// chỉ cần một serial là hợp lệ, nên một request hỏng vẫn có thể đẻ ra hàng
    /// trăm dòng <c>wms.boxes</c> kèm event BOX_CREATED trong một transaction.
    /// </summary>
    private const int MaxBoxesPerPallet = 100;

    /// <summary>
    /// Độ dài tối đa của serial và model gửi xuống tầng pallet. Khớp hợp đồng
    /// <c>CreateBoxLineRequest</c> (<c>[MaxLength(50)]</c> cho cả hai) —
    /// DataAnnotations ở đó KHÔNG chạy cho đường này vì request được dựng trong
    /// code chứ không model-bind từ HTTP, nên phải tự kiểm. Không kiểm thì một
    /// serial dài 60 ký tự (quét dính hai mã) đi tới tận câu INSERT rồi ném lỗi
    /// truncation thô giữa transaction, WH chỉ thấy HTTP 500.
    /// </summary>
    private const int MaxSerialLength = 50;

    /// <summary>
    /// Số lần thử xin Pallet ID. <c>GenerateNextLotNoAsync</c> KHÔNG giữ chỗ —
    /// hai người bấm Lưu cùng lúc nhận cùng một số, người sau đâm vào unique
    /// index và nhận <see cref="ConflictException"/>. Xin số mới rồi thử lại.
    /// </summary>
    private const int LotNoAttempts = 3;

    private readonly IReturnInstructionRepository _repo;
    private readonly IPalletService _pallets;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly IMailSender _mail;
    private readonly ILogger<ReturnInstructionService> _logger;
    private readonly string? _webBaseUrl;

    public ReturnInstructionService(
        IReturnInstructionRepository repo,
        IPalletService pallets,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        IMailSender mail,
        ILogger<ReturnInstructionService> logger,
        IConfiguration config)
    {
        _repo = repo;
        _pallets = pallets;
        _currentUser = currentUser;
        _localizer = localizer;
        _mail = mail;
        _logger = logger;
        _webBaseUrl = config["Web:BaseUrl"]?.TrimEnd('/');
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    public async Task<IReadOnlyList<ReturnInstructionResponse>> GetListAsync(ReturnInstructionQuery query)
    {
        if (query.Status is { Length: > 0 } s && !ReturnDocStatus.IsValid(s.Trim().ToLowerInvariant()))
            throw new BusinessRuleException(_localizer[ReturnMsg.StatusInvalid]);
        if (query.GoodsType is { Length: > 0 } g && !ReturnGoodsType.IsValid(g.Trim().ToLowerInvariant()))
            throw new BusinessRuleException(_localizer[ReturnMsg.GoodsTypeInvalid]);

        var rows = await _repo.GetListAsync(query);
        return rows.Select(ReturnInstructionResponse.From).ToList();
    }

    public async Task<ReturnInstructionResponse> GetByIdAsync(long id)
    {
        var doc = await _repo.GetByIdAsync(id)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, id]);
        return ReturnInstructionResponse.From(doc);
    }

    public async Task<ReturnInstructionResponse> CreateAsync(ReturnInstructionRequest request)
    {
        var goodsType = CleanGoodsType(request.GoodsType);
        var lines = await CleanLinesAsync(request);

        var doc = new ReturnInstruction
        {
            GoodsType = goodsType,
            Customer = Trim(request.Customer),
            ExpectedDate = request.ExpectedDate?.Date,
            Note = Trim(request.Note),
            DocStatus = ReturnDocStatus.Open,
            Lines = lines,
        };

        var id = await _repo.CreateAsync(doc, Actor);

        // Đọc lại để lấy đúng dữ liệu đã ghi (doc_no, id dòng, created_at)
        // thay vì dựng response từ request — hai thứ đó lệch nhau là nguồn
        // của những lỗi "màn hình hiện khác DB".
        var saved = await _repo.GetByIdAsync(id)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, id]);

        await NotifyFaAsync(saved);

        // Đọc lại lần nữa để response mang luôn MailSentAt — người tạo thấy
        // ngay là FA đã được báo hay chưa, không phải F5.
        return ReturnInstructionResponse.From(await _repo.GetByIdAsync(id) ?? saved);
    }

    public async Task<ReturnInstructionResponse> UpdateAsync(long id, ReturnInstructionRequest request)
    {
        var current = await _repo.GetByIdAsync(id)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, id]);

        // Phiếu đã đóng / đã huỷ thì khoá. Mục 2 trở đi sẽ bám vào dòng chỉ
        // thị để đối chiếu SL thực nhận; sửa dòng sau khi hàng đã về là làm
        // sai lệch chính cái mốc dùng để so.
        if (current.DocStatus != ReturnDocStatus.Open)
            throw new ConflictException(_localizer[ReturnMsg.NotEditable, current.DocNo, current.DocStatus]);

        // Loại hàng KHOÁ sau khi tạo: tiền tố số phiếu (RW- / RB-) suy ra từ
        // nó, đổi loại là số phiếu nói sai một đằng dữ liệu một nẻo. Muốn đổi
        // thì xoá phiếu rồi tạo lại — FA cũng cần biết điều đó qua mail mới.
        var goodsType = CleanGoodsType(request.GoodsType);
        if (!string.Equals(goodsType, current.GoodsType, StringComparison.OrdinalIgnoreCase))
            throw new ConflictException(
                _localizer[ReturnMsg.GoodsTypeLocked, current.DocNo, current.GoodsType]);

        var lines = await CleanLinesAsync(request);

        // Model đã có serial trong sổ thì phải còn trong phiếu.
        //
        // SL thực nhận khớp theo MODEL (không theo id dòng, vì mỗi lần sửa
        // phiếu là xoá mềm toàn bộ dòng rồi chèn lại với id mới). Bỏ một model
        // đã nhận 150 serial ra khỏi phiếu là 150 con hàng đó thành vô hình:
        // tổng thực nhận tụt đi, mà serial vẫn chiếm chỗ trong sổ và không ai
        // quét lại được chúng vào đâu.
        var received = current.Lines.Where(l => l.ReceivedQty > 0).ToList();
        if (received.Count > 0)
        {
            var kept = lines.Select(l => l.Model).ToHashSet(StringComparer.OrdinalIgnoreCase);
            var dropped = received.Where(l => !kept.Contains(l.Model)).ToList();
            if (dropped.Count > 0)
                throw new ConflictException(_localizer[ReturnMsg.ModelHasSerials,
                    string.Join(", ", dropped.Select(l => $"{l.Model} ({l.ReceivedQty})"))]);
        }

        var ok = await _repo.UpdateAsync(new ReturnInstruction
        {
            Id = id,
            GoodsType = goodsType,
            Customer = Trim(request.Customer),
            ExpectedDate = request.ExpectedDate?.Date,
            Note = Trim(request.Note),
            Lines = lines,
        }, Actor);

        if (!ok) throw new NotFoundException(_localizer[ReturnMsg.NotFound, id]);

        return ReturnInstructionResponse.From(
            await _repo.GetByIdAsync(id) ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, id]));
    }

    public async Task DeleteAsync(long id)
    {
        var current = await _repo.GetByIdAsync(id)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, id]);

        if (current.DocStatus != ReturnDocStatus.Open)
            throw new ConflictException(_localizer[ReturnMsg.NotEditable, current.DocNo, current.DocStatus]);

        // Phiếu đã nhận hàng thì KHÔNG xoá được nữa.
        //
        // SoftDeleteAsync chỉ xoá mềm phiếu + dòng, không chạm sổ serial. Xoá
        // một phiếu đã nhận 300 serial là khoá vĩnh viễn 300 con hàng đó khỏi
        // mọi phiếu về sau: unique index ux_ris_serial_open giữ chúng trên phạm
        // vi toàn hệ thống và không có nút nào giải phóng. Muốn bỏ phiếu thì
        // huỷ từng pallet đã nhận trước (DELETE .../pallets/{palletId}).
        if (current.ReceivedQty > 0)
            throw new ConflictException(
                _localizer[ReturnMsg.DocHasSerials, current.DocNo, current.ReceivedQty]);

        if (!await _repo.SoftDeleteAsync(id, Actor))
            throw new NotFoundException(_localizer[ReturnMsg.NotFound, id]);
    }

    // ============ Mục 2a: WH nhận hàng vào phiếu ============

    public async Task<ReceiveReturnResponse> ReceiveAsync(long docId, ReceiveReturnRequest request)
    {
        var doc = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        // Phiếu đã đóng / đã huỷ thì không nhận thêm: SL thực nhận của một
        // phiếu đã chốt là con số mục 2b đã mail đi, không sửa sau lưng FA.
        if (doc.DocStatus != ReturnDocStatus.Open)
            throw new ConflictException(_localizer[ReturnMsg.DocNotOpen, doc.DocNo, doc.DocStatus]);

        var boxes = CleanBoxes(request, doc);

        // ── Category: Pallet ID nhúng mã category trong 12 số, nên một pallet
        //    không thể chứa model của hai category khác nhau.
        var models = boxes.Select(b => b.Model).Distinct(StringComparer.OrdinalIgnoreCase).ToList();
        var catOf = await _repo.GetCategoryByModelAsync(models);

        var noCategory = models.Where(m => !catOf.ContainsKey(m)).ToList();
        if (noCategory.Count > 0)
            throw new BusinessRuleException(
                _localizer[ReturnMsg.CategoryUnknown, string.Join(", ", noCategory)]);

        var categories = models.Select(m => catOf[m]).Distinct().ToList();
        if (categories.Count > 1)
            throw new BusinessRuleException(_localizer[ReturnMsg.CategoryMixed,
                string.Join(", ", models.Select(m => $"{m} ({catOf[m]:D3})"))]);

        var categoryCode = categories[0];

        // ── Serial đã có chủ: chặn quét trùng và chặn serial lạ. Kiểm trước để
        //    thông báo nói rõ con nào, phiếu nào; unique index vẫn là chốt cuối.
        var allSerials = boxes.SelectMany(b => b.Serials).ToList();
        var owners = await _repo.FindSerialOwnersAsync(allSerials);
        if (owners.Count > 0)
        {
            var mine = owners.FirstOrDefault(o => o.DocId == docId);
            if (mine is not null)
                throw new ConflictException(
                    _localizer[ReturnMsg.SerialAlreadyReceived, mine.SerialNo, doc.DocNo]);

            var other = owners[0];
            throw new ConflictException(
                _localizer[ReturnMsg.SerialOnOtherDoc, other.SerialNo, other.DocNo]);
        }

        CreatePalletResponse created;
        for (var attempt = 1; ; attempt++)
        {
            // Hàng khách trả về không có nhãn Pallet ID in sẵn, nên server cấp
            // số rồi PDA in nhãn. Xin số TRONG vòng lặp: thua race thì lần sau
            // phải là số khác.
            var lotNo = (await _pallets.GenerateNextLotNoAsync(categoryCode)).LotNo;

            // Thùng không quét được mã (hàng về rời) thì đặt tên theo Pallet ID,
            // tính ở đây để pallet và sổ serial dùng CÙNG một mã thùng.
            var named = boxes
                .Select((b, i) => (BoxNo: b.BoxNo ?? $"{lotNo}-{i + 1:D2}", b.Model, b.Serials))
                .ToList();

            var palletRequest = BuildPalletRequest(lotNo, categoryCode, named);

            var serialRows = named
                .SelectMany(b => b.Serials.Select(s => new ReturnSerial
                {
                    Model = b.Model,
                    SerialNo = s,
                    BoxNo = b.BoxNo,
                }))
                .ToList();

            try
            {
                // Hook chạy TRONG transaction tạo pallet: pallet và sổ serial
                // cùng sống cùng chết. Xem ILotRepository.AddAsync.
                created = await _pallets.CreateAsync(palletRequest,
                    onInserted: (conn, tx, palletDbId) => _repo.RegisterSerialsAsync(
                        conn, tx, docId, palletDbId, doc.GoodsType, serialRows, Actor));
                break;
            }
            // ── Pallet ID bị người khác lấy, phát hiện ở pre-check của
            //    PalletService (người kia đã commit xong trước ta) ──
            //
            // Nhận ra bằng cách tìm chính số vừa xin TRONG câu lỗi, chứ không
            // bắt mọi ConflictException: PalletService còn ném 409 cho mã thùng
            // trùng và serial trùng trong pallet, mà thử lại ba lần cho hai lỗi
            // đó là chạy trọn bộ insert ba lượt rồi mới báo điều đã biết ngay từ
            // đầu. Mọi bản dịch của Lot.LotNoDuplicated đều chèn lotNo vào câu,
            // nên phép so này không phụ thuộc ngôn ngữ đang chọn.
            catch (ConflictException ex)
                when (attempt < LotNoAttempts
                      && ex.Message.Contains(lotNo, StringComparison.Ordinal))
            {
                _logger.LogInformation(
                    "Pallet ID {LotNo} vua bi nguoi khac lay khi nhan hang phieu {DocNo} — xin so moi (lan {Attempt}).",
                    lotNo, doc.DocNo, attempt);
            }
            // ── Cùng chuyện trên, nhưng hai bên vào ĐÚNG cùng nhịp ──
            //
            // Lúc đó pre-check của cả hai đều sạch và người sau đâm thẳng vào
            // unique index của wms.pallets. LotRepository KHÔNG dịch lỗi đó
            // thành ConflictException — nó rollback rồi ném nguyên SqlException,
            // nên nhánh này mới là đường đi thật của một race Pallet ID.
            catch (Microsoft.Data.SqlClient.SqlException ex)
                when (attempt < LotNoAttempts && IsPalletIdCollision(ex))
            {
                _logger.LogInformation(
                    "Pallet ID {LotNo} trung ngay tai unique index khi nhan hang phieu {DocNo} — xin so moi (lan {Attempt}).",
                    lotNo, doc.DocNo, attempt);
            }
            catch (Microsoft.Data.SqlClient.SqlException ex) when (IsSerialCollision(ex))
            {
                // Hai máy quét cùng một serial trong cùng một nhịp: pre-check
                // của cả hai đều sạch, unique index của sổ chặn người sau.
                throw new ConflictException(_localizer[ReturnMsg.SerialRaceLost]);
            }
        }

        // Đọc lại phiếu để SL thực nhận đã tính cả pallet vừa nhận — PDA vẽ lại
        // tiến độ từ chính response này, không phải gọi thêm một vòng.
        var saved = await _repo.GetByIdAsync(docId) ?? doc;

        return new ReceiveReturnResponse(
            created.Id,
            created.LotNo,
            categoryCode,
            created.BoxCount,
            created.LineCount,
            saved.OverReceived,
            ReturnInstructionResponse.From(saved));
    }

    // ============ Mục 2b: chốt SL thực nhận, báo FA ============

    public async Task<ReturnInstructionResponse> CloseAsync(long docId)
    {
        var doc = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        if (doc.DocStatus != ReturnDocStatus.Open)
            throw new ConflictException(_localizer[ReturnMsg.DocNotOpen, doc.DocNo, doc.DocStatus]);

        // Chốt một phiếu chưa nhận được con nào là gửi cho FA bảng toàn số 0.
        // Hàng không về thì huỷ phiếu, không phải chốt nó.
        if (doc.ReceivedQty == 0)
            throw new BusinessRuleException(_localizer[ReturnMsg.NothingReceived, doc.DocNo]);

        // Điều kiện "đang mở" nằm trong chính câu UPDATE: hai người cùng bấm
        // Chốt thì người sau về false ở đây, FA không nhận hai lá mail.
        if (!await _repo.CloseAsync(docId, Actor))
            throw new ConflictException(_localizer[ReturnMsg.DocNotOpen, doc.DocNo, doc.DocStatus]);

        // Đọc lại để mail mang đúng closed_at / closed_by vừa ghi.
        var saved = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        await NotifyActualAsync(saved);

        // Đọc lần nữa để response mang luôn ActualMailSentAt — người bấm thấy
        // ngay FA đã được báo hay chưa, không phải F5.
        return ReturnInstructionResponse.From(await _repo.GetByIdAsync(docId) ?? saved);
    }

    public async Task<ReturnInstructionResponse> ReopenAsync(long docId)
    {
        var doc = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        if (doc.DocStatus != ReturnDocStatus.Completed)
            throw new ConflictException(_localizer[ReturnMsg.NotClosed, doc.DocNo, doc.DocStatus]);

        if (!await _repo.ReopenAsync(docId, Actor))
            throw new ConflictException(_localizer[ReturnMsg.NotClosed, doc.DocNo, doc.DocStatus]);

        return ReturnInstructionResponse.From(
            await _repo.GetByIdAsync(docId) ?? doc);
    }

    public async Task<IReadOnlyList<ReturnPalletResponse>> GetPalletsAsync(long docId)
    {
        _ = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        var rows = await _repo.GetPalletsByDocAsync(docId);
        return rows.Select(ReturnPalletResponse.From).ToList();
    }

    public async Task<ReturnInstructionResponse> ReleasePalletAsync(long docId, long palletId)
    {
        var doc = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        if (doc.DocStatus != ReturnDocStatus.Open)
            throw new ConflictException(_localizer[ReturnMsg.DocNotOpen, doc.DocNo, doc.DocStatus]);

        // KHÔNG còn SELECT "pallet có thuộc phiếu không" ở đây (bỏ 11/11):
        // repository kiểm trong chính transaction xoá. Kiểm ở đây là kiểm rồi
        // mới ghi ở một kết nối khác — giữa hai lượt đó một lượt out kho có thể
        // vừa đẩy serial sang at_fa.
        var r = await _repo.ReleasePalletAsync(docId, palletId, doc.DocNo, Actor);

        if (r.NotFound || r.NotOfDoc)
            throw new NotFoundException(_localizer[ReturnMsg.PalletNotInDoc, palletId, doc.DocNo]);

        // Hàng đã rời kho SCS ⇒ không phải quét sai nữa. Nói rõ trạng thái đang
        // chặn và SL: người bấm cần biết phải đi theo đường nào khác, chứ câu
        // "không huỷ được" trơ trọi là một cuộc gọi điện lên office.
        if (r.HasLeftWarehouse)
            throw new ConflictException(_localizer[
                ReturnMsg.PalletLeftWarehouse,
                palletId,
                r.BlockingQty,
                _localizer[$"Return.SerialStatus.{r.BlockingStatus}"]]);

        _logger.LogInformation(
            "Da huy lan nhan pallet {PalletId} cua phieu {DocNo}: giai phong {Freed} serial, "
            + "nha vi tri {Locator}.",
            palletId, doc.DocNo, r.FreedSerials, r.LocatorCode ?? "(khong co)");

        return ReturnInstructionResponse.From(
            await _repo.GetByIdAsync(docId) ?? doc);
    }

    public async Task<IReadOnlyList<ReturnSerialResponse>> GetSerialsAsync(long docId)
    {
        _ = await _repo.GetByIdAsync(docId)
            ?? throw new NotFoundException(_localizer[ReturnMsg.NotFound, docId]);

        var rows = await _repo.GetSerialsByDocAsync(docId);
        return rows.Select(ReturnSerialResponse.From).ToList();
    }

    /// <summary>
    /// Vi phạm unique là của Pallet ID (<c>wms.pallets</c>) chứ không phải của
    /// sổ serial.
    ///
    /// Phân biệt bằng TÊN INDEX trong câu lỗi của SQL Server. Cách này dựa vào
    /// chuỗi thông báo nên không đẹp, nhưng đổi lại tránh được điều tệ hơn
    /// nhiều: gộp mọi lỗi trùng vào một câu, để WH đi tìm một serial trùng
    /// không tồn tại trong khi việc phải làm chỉ là bấm Lưu lại.
    /// </summary>
    private static bool IsPalletIdCollision(Microsoft.Data.SqlClient.SqlException ex) =>
        IsUniqueViolation(ex)
        && ex.Message.Contains("pallet_id", StringComparison.OrdinalIgnoreCase);

    /// <summary>Vi phạm unique của sổ serial (<c>ux_ris_*</c>).</summary>
    private static bool IsSerialCollision(Microsoft.Data.SqlClient.SqlException ex) =>
        IsUniqueViolation(ex)
        && (ex.Message.Contains("ux_ris_", StringComparison.OrdinalIgnoreCase)
            || ex.Message.Contains("return_instruction_serials", StringComparison.OrdinalIgnoreCase));

    /// <summary>2627 = vi phạm PK/UNIQUE constraint, 2601 = vi phạm unique index.</summary>
    private static bool IsUniqueViolation(Microsoft.Data.SqlClient.SqlException ex) =>
        ex.Number is 2601 or 2627;

    /// <summary>Một thùng đã chuẩn hoá: mã thùng, model theo đúng cách viết trong phiếu, serial.</summary>
    private sealed record ReceiveBox(string? BoxNo, string Model, List<string> Serials);

    /// <summary>
    /// Chuẩn hoá + kiểm toàn bộ thùng/serial TRƯỚC khi chạm DB: kiểm hết rồi
    /// mới ghi, để không có pallet nửa vời phải đi dọn.
    /// </summary>
    private List<ReceiveBox> CleanBoxes(ReceiveReturnRequest request, ReturnInstruction doc)
    {
        var src = request.Boxes ?? [];
        if (src.Count == 0)
            throw new BusinessRuleException(_localizer[ReturnMsg.BoxesRequired]);
        if (src.Count > MaxBoxesPerPallet)
            throw new BusinessRuleException(
                _localizer[ReturnMsg.TooManyBoxes, MaxBoxesPerPallet]);

        // Lấy đúng cách viết model trong phiếu: PDA gửi lên chuỗi người dùng
        // chọn, so khớp không phân biệt hoa thường nhưng GHI theo danh mục, để
        // bước đếm SL thực nhận khớp chính xác với dòng chỉ thị.
        var docModels = doc.Lines.ToDictionary(
            l => l.Model, l => l.Model, StringComparer.OrdinalIgnoreCase);

        var seenSerial = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var seenBox = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var result = new List<ReceiveBox>(src.Count);
        var total = 0;

        foreach (var b in src)
        {
            var model = Trim(b.Model)
                ?? throw new BusinessRuleException(_localizer[ReturnMsg.ModelRequired]);

            if (!docModels.TryGetValue(model, out var canonical))
                throw new BusinessRuleException(
                    _localizer[ReturnMsg.ModelNotInDoc, model, doc.DocNo]);

            // Dòng chỉ thị cho model tới 100 ký tự, nhưng wms.box_lines.model
            // chỉ nhận 50 — chặn ở đây để câu lỗi nói rõ model nào, thay vì
            // lỗi truncation giữa transaction.
            if (canonical.Length > MaxSerialLength)
                throw new BusinessRuleException(
                    _localizer[ReturnMsg.ValueTooLong, canonical, MaxSerialLength]);

            var boxNo = Trim(b.BoxNo);
            if (boxNo is not null && !seenBox.Add(boxNo))
                throw new BusinessRuleException(_localizer[ReturnMsg.BoxNoDuplicated, boxNo]);

            var serials = new List<string>();
            foreach (var raw in b.Serials ?? [])
            {
                var sn = Trim(raw);
                if (sn is null) continue;

                if (sn.Length > MaxSerialLength)
                    throw new BusinessRuleException(
                        _localizer[ReturnMsg.ValueTooLong, sn, MaxSerialLength]);

                // Trùng trong CẢ request, không chỉ trong một thùng: cùng một
                // con hàng không thể nằm ở hai thùng trên cùng một pallet.
                if (!seenSerial.Add(sn))
                    throw new BusinessRuleException(
                        _localizer[ReturnMsg.SerialDuplicatedInRequest, sn]);

                serials.Add(sn);
            }

            if (serials.Count == 0)
                throw new BusinessRuleException(
                    _localizer[ReturnMsg.SerialRequired, boxNo ?? canonical]);

            total += serials.Count;
            if (total > MaxSerialsPerPallet)
                throw new BusinessRuleException(
                    _localizer[ReturnMsg.TooManySerials, MaxSerialsPerPallet]);

            result.Add(new ReceiveBox(boxNo, canonical, serials));
        }

        return result;
    }

    /// <summary>
    /// Dựng request tạo pallet mức SERIAL: mỗi serial một dòng, server ép qty = 1.
    ///
    /// <c>productionDate</c> lấy ngày nhận, KHÔNG để trống: ngày sản xuất thật
    /// của hàng khách trả về thì ở cầu cảng không ai biết, mà hai luồng tạo
    /// pallet sẵn có (quét mã hộp, quét GTIN) cũng đang đóng dấu
    /// <c>DateTime.Now</c> cho đúng tình huống đó.
    /// </summary>
    private static CreatePalletRequest BuildPalletRequest(
        string lotNo,
        int categoryCode,
        List<(string BoxNo, string Model, List<string> Serials)> boxes)
    {
        var now = DateTime.Now;

        return new CreatePalletRequest(
            DetailLevel: PalletDetailLevel.Serial,
            LotNo: lotNo,
            CategoryCode: categoryCode,
            LotType: PalletType.Pallet,
            StockyCode: null,
            Model: null,              // mức serial: model nằm ở từng dòng
            StandardPacking: null,
            ProductionDate: null,     // mức serial: server tính MIN từ box
            BoxCount: null,           // mức serial: server tự đếm
            Boxes: boxes.Select(b => new CreateBoxRequest(
                BoxNo: b.BoxNo,
                PsnvPo: null,
                CustomerPo: null,
                ProductionDate: now,
                RawPayload: null,
                Lines: b.Serials.Select(s => new CreateBoxLineRequest(
                    Model: b.Model,
                    Qty: null,        // mức serial: server ép = 1
                    SerialNo: s,
                    ProductionDate: now,
                    CartonCount: null)).ToList())).ToList());
    }

    // ===================== kiểm dữ liệu =====================

    /// <summary>
    /// Chuẩn hoá + kiểm loại hàng của PHIẾU. Sai loại là không suy ra được
    /// tiền tố số phiếu, nên phải chặn trước khi chạm DB.
    /// </summary>
    private string CleanGoodsType(string? raw)
    {
        var type = Trim(raw)?.ToLowerInvariant();
        if (!ReturnGoodsType.IsValid(type))
            throw new BusinessRuleException(_localizer[ReturnMsg.GoodsTypeInvalid]);
        return type!;
    }

    // ===================== kiểm dòng =====================

    /// <summary>
    /// Chuẩn hoá + kiểm toàn bộ dòng TRƯỚC khi chạm DB. Kiểm hết rồi mới ghi,
    /// không kiểm một dòng rồi ghi một dòng: phiếu nửa vời còn khó dọn hơn là
    /// bắt người dùng sửa lại ô sai.
    /// </summary>
    private async Task<List<ReturnInstructionLine>> CleanLinesAsync(ReturnInstructionRequest request)
    {
        var src = request.Lines ?? [];
        if (src.Count == 0)
            throw new BusinessRuleException(_localizer[ReturnMsg.LinesRequired]);
        if (src.Count > MaxLinesPerDoc)
            throw new BusinessRuleException(_localizer[ReturnMsg.TooManyLines, MaxLinesPerDoc]);

        var lines = new List<ReturnInstructionLine>(src.Count);
        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);

        foreach (var l in src)
        {
            var model = Trim(l.Model);
            if (model is null)
                throw new BusinessRuleException(_localizer[ReturnMsg.ModelRequired]);

            if (l.Qty <= 0)
                throw new BusinessRuleException(_localizer[ReturnMsg.QtyInvalid, model]);

            // Trùng model sẽ làm SL kỳ vọng cộng đôi, và bước đối chiếu SL
            // thực nhận ở mục 2 báo lệch mà không ai hiểu vì sao. Chặn ở đây
            // để thông báo nói rõ model nào, thay vì để unique index ném ra
            // lỗi SQL thô.
            if (!seen.Add(model))
                throw new BusinessRuleException(_localizer[ReturnMsg.DuplicateLine, model]);

            lines.Add(new ReturnInstructionLine
            {
                Model = model,
                Qty = l.Qty,
                Note = Trim(l.Note),
            });
        }

        // Model phải có trong danh mục: gõ sai một ký tự thì mọi bước đối
        // chiếu serial / SL phía sau đều lệch mà không chỗ nào báo.
        var unknown = await _repo.FindUnknownModelsAsync(lines.Select(l => l.Model).ToList());
        if (unknown.Count > 0)
            throw new BusinessRuleException(
                _localizer[ReturnMsg.ModelNotFound, string.Join(", ", unknown)]);

        return lines;
    }

    // ===================== mail báo FA =====================

    /// <summary>
    /// Báo FA. Nuốt mọi lỗi: phiếu ĐÃ ghi xong, mail hỏng không được phép làm
    /// đổ nghiệp vụ. Gửi được thì đóng dấu <c>mail_sent_at</c> để màn hình nói
    /// đúng sự thật là FA đã nhận hay chưa.
    /// </summary>
    private async Task NotifyFaAsync(ReturnInstruction doc)
    {
        try
        {
            var tpl = await _repo.GetMailTemplateAsync(MailEventCreated);
            if (tpl is null)
            {
                _logger.LogWarning(
                    "Chua khai su kien mail {Event} trong master.email_events — khong bao FA phieu {DocNo}.",
                    MailEventCreated, doc.DocNo);
                return;
            }

            var recipients = await _repo.GetMailRecipientsAsync(MailEventCreated);
            if (recipients.Count == 0)
            {
                _logger.LogWarning(
                    "Chua khai nguoi nhan cho su kien {Event} trong master.email_config — "
                    + "khong bao FA phieu {DocNo}.", MailEventCreated, doc.DocNo);
                return;
            }

            var replyTo = await _repo.GetUserEmailAsync(_currentUser.EmployeeCode);

            // Mẫu viết bằng MARKDOWN -> dựng HTML có khung (MarkdownMail, dùng
            // chung với mail hàng thiếu và hàng bất thường). Phải đi qua đây mới
            // khớp phần XEM TRƯỚC bên Web — xem trước cũng render markdown.
            var subject = Fill(tpl.Subject, doc, FillMode.Plain).Trim();
            var sent = await _mail.SendAsync(
                recipients, subject,
                MarkdownMail.Render(subject, Fill(tpl.Body, doc, FillMode.Markdown), MarkdownMail.Blue),
                Actor, replyTo);

            if (sent)
                await _repo.MarkMailSentAsync(doc.Id, Truncate(
                    string.Join(", ", recipients.Select(r => $"{r.Type}:{r.Email}")), 2000));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Loi khi bao FA phieu {DocNo} — phieu VAN da tao xong.", doc.DocNo);
        }
    }

    /// <summary>
    /// Báo FA SỐ THỰC NHẬN kèm bảng lệch so với chỉ thị (mục 2b).
    ///
    /// Nuốt mọi lỗi, cùng lý do với <see cref="NotifyFaAsync"/>: phiếu ĐÃ chốt
    /// xong, mail hỏng không được phép làm đổ nghiệp vụ. Gửi được thì đóng dấu
    /// <c>actual_mail_sent_at</c> để màn hình nói đúng sự thật.
    /// </summary>
    private async Task NotifyActualAsync(ReturnInstruction doc)
    {
        try
        {
            var tpl = await _repo.GetMailTemplateAsync(MailEventActual);
            if (tpl is null)
            {
                _logger.LogWarning(
                    "Chua khai su kien mail {Event} trong master.email_events — khong bao FA so thuc nhan phieu {DocNo}.",
                    MailEventActual, doc.DocNo);
                return;
            }

            var recipients = await _repo.GetMailRecipientsAsync(MailEventActual);
            if (recipients.Count == 0)
            {
                _logger.LogWarning(
                    "Chua khai nguoi nhan cho su kien {Event} trong master.email_config — "
                    + "khong bao FA so thuc nhan phieu {DocNo}.", MailEventActual, doc.DocNo);
                return;
            }

            var replyTo = await _repo.GetUserEmailAsync(_currentUser.EmployeeCode);

            // Dải tiêu đề đổi màu theo KẾT QUẢ: khớp chỉ thị thì xanh, có lệch
            // thì cam. FA mở hộp thư thấy ngay lá nào cần xem, chưa cần đọc chữ.
            // Cùng ý với màu badge trên màn hình, không phải trang trí.
            var subject = Fill(tpl.Subject, doc, FillMode.Plain).Trim();
            var sent = await _mail.SendAsync(
                recipients, subject,
                MarkdownMail.Render(subject, Fill(tpl.Body, doc, FillMode.Markdown),
                    doc.DiffQty == 0 ? MarkdownMail.Blue : MarkdownMail.Orange),
                Actor, replyTo);

            if (sent)
                await _repo.MarkActualMailSentAsync(doc.Id, Truncate(
                    string.Join(", ", recipients.Select(r => $"{r.Type}:{r.Email}")), 2000));
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Loi khi bao FA so thuc nhan phieu {DocNo} — phieu VAN da chot xong.", doc.DocNo);
        }
    }

    /// <summary>Cách thoát giá trị khi điền vào mẫu.</summary>
    private enum FillMode
    {
        /// <summary>Tiêu đề mail: chữ thuần, không thoát gì.</summary>
        Plain,

        /// <summary>
        /// Thân mail markdown: thoát ký tự markdown để "*" hay "#" trong ghi chú
        /// hiện y nguyên, và "|" trong ghi chú không cắt ô bảng làm hai.
        /// </summary>
        Markdown,
    }

    /// <summary>
    /// Điền mẫu mail. Mẫu viết bằng MARKDOWN — đúng quy ước của hệ thống (giống
    /// mail hàng thiếu và hàng bất thường), để màn Cấu hình email xem trước ra
    /// đúng lá mail sẽ gửi. Vì vậy chữ người dùng nhập (khách hàng, ghi chú,
    /// model) thoát bằng <see cref="MarkdownMail.Escape"/> chứ KHÔNG phải
    /// <see cref="WebUtility.HtmlEncode"/>: thân mail không còn là HTML gõ tay,
    /// mà HtmlEncode trong markdown sẽ hiện ra "&amp;amp;" cho người đọc thấy.
    ///
    /// Dùng CHUNG cho cả hai mẫu mail (tạo phiếu và chốt thực nhận):
    /// <c>Replace</c> một placeholder không có trong mẫu là không làm gì, nên
    /// mỗi mẫu chỉ nhận đúng phần nó khai.
    /// </summary>
    private string Fill(string? template, ReturnInstruction doc, FillMode mode)
    {
        if (string.IsNullOrWhiteSpace(template)) return string.Empty;

        var link = template.Contains("{Link}", StringComparison.Ordinal) ? BuildLink(doc) : string.Empty;
        var table = template.Contains("{LinesTable}", StringComparison.Ordinal) ? BuildLinesTable(doc) : string.Empty;
        var diff = template.Contains("{DiffTable}", StringComparison.Ordinal) ? BuildDiffTable(doc) : string.Empty;

        Func<string?, string> enc = mode == FillMode.Markdown ? MarkdownMail.Escape : v => v ?? "";

        // GIỮ KHỚP danh sách biến với ReturnMailConfigDialog bên Web
        // (CreatedVars / ActualVars). Link KHÔNG thoát markdown — thoát làm hỏng
        // địa chỉ.
        return template
            .Replace("{Link}", link)
            .Replace("{LinesTable}", table)
            .Replace("{DiffTable}", diff)
            .Replace("{PlanQty}", doc.TotalQty.ToString("N0"))
            .Replace("{ActualQty}", doc.ReceivedQty.ToString("N0"))
            .Replace("{DiffQty}", SignedQty(doc.DiffQty))
            // Nhãn ngắn gắn vào TIÊU ĐỀ mail: người nhận thấy ngay có lệch hay
            // không mà chưa cần mở thư.
            .Replace("{DiffLabel}", doc.DiffQty == 0 ? "" : $" (lệch {SignedQty(doc.DiffQty)})")
            .Replace("{ClosedAt}", doc.ClosedAt?.ToString("dd/MM/yyyy HH:mm") ?? "")
            .Replace("{ClosedBy}", enc(doc.ClosedBy))
            .Replace("{DocNo}", enc(doc.DocNo))
            .Replace("{GoodsType}", GoodsTypeLabel(doc.GoodsType))
            .Replace("{Customer}", enc(doc.Customer))
            .Replace("{ExpectedDate}", doc.ExpectedDate?.ToString("dd/MM/yyyy") ?? "")
            .Replace("{ModelCount}", doc.ModelCount.ToString())
            .Replace("{TotalQty}", doc.TotalQty.ToString("N0"))
            .Replace("{Note}", enc(doc.Note))
            .Replace("{CreatedBy}", enc(doc.CreatedBy))
            .Replace("{Now}", DateTime.Now.ToString("dd/MM/yyyy HH:mm"));
    }

    /// <summary>
    /// Bảng chi tiết dòng trong thân mail, dạng bảng pipe của markdown. Dựng ở
    /// code chứ không nhét vào mẫu: số dòng thay đổi theo từng phiếu, mẫu trong
    /// DB không lặp được.
    ///
    /// Mở đầu bằng một dòng trắng: mẫu do người dùng soạn, "Chi tiết:" rồi
    /// {LinesTable} ngay dòng dưới thì bảng nằm chung đoạn văn và markdown
    /// không nhận ra nó là bảng. Thừa một dòng trắng thì vô hại.
    /// </summary>
    private static string BuildLinesTable(ReturnInstruction doc)
    {
        var sb = new StringBuilder("\n\n");
        // Không còn cột Loại: cả phiếu một loại, đã ghi ở bảng tóm tắt phía
        // trên. Lặp lại cùng một giá trị ở mọi dòng chỉ làm bảng rộng ra.
        sb.Append("| # | Model | SL | Ghi chú |\n");
        sb.Append("|--:|---|--:|---|\n");
        foreach (var l in doc.Lines)
        {
            sb.Append("| ").Append(l.LineNo)
              .Append(" | ").Append(MarkdownMail.Escape(l.Model))
              .Append(" | ").Append(l.Qty.ToString("N0"))
              .Append(" | ").Append(MarkdownMail.Escape(l.Note))
              .Append(" |\n");
        }
        // Kết bằng một dòng trắng nữa: mẫu thường viết {LinesTable} rồi "Ghi
        // chú:" ngay dòng dưới, không có dòng trắng thì dòng chữ đó bị hút vào
        // bảng thành một ô.
        return sb.Append('\n').ToString();
    }

    /// <summary>
    /// Bảng đối chiếu chỉ thị vs thực nhận trong thân mail — thứ FA cần đọc ở
    /// mục 2b. Mỗi model một dòng kèm cột Lệch và một chữ nói rõ Đủ / Thiếu /
    /// Vượt, vì một cột số âm thì người đọc nhanh dễ bỏ qua dấu trừ.
    ///
    /// Bảng markdown không tô nền được từng dòng, nên dòng có lệch được in ĐẬM
    /// cả cột Lệch lẫn cột Tình trạng — vẫn để mắt nhảy đúng vào chỗ cần xem mà
    /// không phải quay lại nhét HTML vào mẫu.
    /// </summary>
    private static string BuildDiffTable(ReturnInstruction doc)
    {
        var sb = new StringBuilder("\n\n");
        sb.Append("| # | Model | SL chỉ thị | SL thực nhận | Lệch | Tình trạng |\n");
        sb.Append("|--:|---|--:|--:|--:|---|\n");

        foreach (var l in doc.Lines)
        {
            var state = l.DiffQty == 0 ? "Đủ" : l.DiffQty > 0 ? "Vượt" : "Thiếu";
            var em = l.DiffQty == 0 ? "" : "**";

            sb.Append("| ").Append(l.LineNo)
              .Append(" | ").Append(MarkdownMail.Escape(l.Model))
              .Append(" | ").Append(l.Qty.ToString("N0"))
              .Append(" | ").Append(l.ReceivedQty.ToString("N0"))
              .Append(" | ").Append(em).Append(SignedQty(l.DiffQty)).Append(em)
              .Append(" | ").Append(em).Append(state).Append(em)
              .Append(" |\n");
        }

        sb.Append("| | **Tổng** | **").Append(doc.TotalQty.ToString("N0"))
          .Append("** | **").Append(doc.ReceivedQty.ToString("N0"))
          .Append("** | **").Append(SignedQty(doc.DiffQty))
          .Append("** | |\n");

        // Dòng trắng kết bảng — cùng lý do như BuildLinesTable.
        return sb.Append('\n').ToString();
    }

    /// <summary>
    /// Số lệch kèm dấu: <c>+6</c> / <c>-6</c> / <c>0</c>. Có dấu cộng tường
    /// minh vì "6" và "+6" đọc khác nhau hẳn trong một bảng có cả số âm.
    /// </summary>
    private static string SignedQty(int qty) =>
        qty > 0 ? $"+{qty:N0}" : qty.ToString("N0");

    /// <summary>
    /// Nhãn loại hàng trong mail. Để nguyên tiếng Anh, KHÔNG qua localizer:
    /// mail gửi cho cả FA lẫn SCS và không có ngôn ngữ của người nhận — dịch
    /// theo ngôn ngữ của người BẤM TẠO là tuỳ tiện.
    /// </summary>
    private static string GoodsTypeLabel(string goodsType) =>
        goodsType == ReturnGoodsType.Rework ? "Rework" : "Refurbish";

    private string BuildLink(ReturnInstruction doc)
    {
        if (string.IsNullOrWhiteSpace(_webBaseUrl))
        {
            _logger.LogWarning(
                "Chua khai Web:BaseUrl trong appsettings — mail phieu {DocNo} se khong co link mo phieu.",
                doc.DocNo);
            return string.Empty;
        }
        // Dùng SỐ PHIẾU chứ không phải id, như mail phiếu bất thường: màn hình
        // điền nó vào ô tìm kiếm nên người nhận hiểu vì sao danh sách chỉ còn
        // một dòng, và số phiếu là thứ người ta nhắc lại cho nhau được.
        return $"{_webBaseUrl}/rework-refurbish?docNo={Uri.EscapeDataString(doc.DocNo)}";
    }

    private static string? Trim(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();

    private static string Truncate(string s, int max) => s.Length <= max ? s : s[..max];
}
