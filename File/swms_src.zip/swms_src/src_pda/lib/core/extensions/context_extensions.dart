import 'package:flutter/material.dart';

/// Tiện ích truy cập nhanh từ BuildContext.
extension ContextExtensions on BuildContext {
  ColorScheme get colors => Theme.of(this).colorScheme;
  TextTheme get textStyles => Theme.of(this).textTheme;
  Size get screenSize => MediaQuery.sizeOf(this);
  EdgeInsets get viewInsets => MediaQuery.viewInsetsOf(this);

  void hideKeyboard() => FocusScope.of(this).unfocus();
}
