﻿using Microsoft.AspNetCore.Mvc;
using Refit;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class KittingFilter : BaseFilter
    {
        [Display(Name = "Kitting Type")]
        public KittingType? Type { get; set; }
        public KittingTab Tab { get; set; }
        public string? Plant { get; set; }
        public string? ProDate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");
        public string? Cate { get; set; }
        public string? FromSloc { get; set; }
        public string? Sloc { get; set; }
        public string? PartNo { get; set; }
        public string? Material { get; set; }
        public string? Reservation { get; set; }
        public string? KittingDate { get; set; }
        public string? SubplyDate { get; set; }
        public string? FromTime { get; set; }
        public string? FinishTime { get; set; }
        public double? Quantity { get; set; }
        public KittingStatus? Status { get; set; }
        public string? Model { get; set; }
        public string? SpecialPart { get; set; }
        public string? SupplyDate { get; set; }
        public string LocationName { get; set; }
        public string UploadNo { get; set; }
        public string? Line { get; set; }
        public string? Time { get; set; }
        public string? PullID { get; set; }
        public bool Urgent { get; set; }
        public bool Prepare { get; set; }
        public bool Other { get; set; }
        public bool JIT { get; set; }
        public bool Process { get; set; }
        public bool CommonPart { get; set; }
        public KittingFrom KTFrom { get; set; }
    }
}
