﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class SapStockImport
    {
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }
        public double? StandardPrice { get; set; }
        public double? PerQuantity { get; set; }
        public double? SAPQuantity { get; set; }
    }
}
