using Microsoft.AspNetCore.Components;
using Microsoft.JSInterop;
using Swms.FinishGoods.Web.Features.PartCard.App.Csvlo;
using Swms.FinishGoods.Web.Features.PartCard.Business;
using Swms.FinishGoods.Web.Features.PartCard.Business.Models;
using Swms.FinishGoods.Web.Shared.App.CsvIo;

namespace Swms.FinishGoods.Web.Features.PartCard.App.Pages;

// Cụm thao tác: chi tiết + sửa kích thước, In lại, Export CSV.
public partial class PartCardHistory
{
    [Inject] private IJSRuntime JS { get; set; } = default!;
    [Inject] private PartCardReprintBuffer ReprintBuffer { get; set; } = default!;

    // ── Dialog chi tiết ──
    // API danh sách đã trả đủ rows nên KHÔNG gọi thêm GET /{id} khi mở.
    private AppPartCardHistory? _detail;
    private bool _savingDims;

    private void OpenDetail(AppPartCardHistory p) => _detail = p;
    private void CloseDetail() => _detail = null;

    // Sửa kích thước / cân nặng cấp phiếu (PUT .../dimensions).
    private async Task SaveDimensions(UpdateDimensionsRequest req)
    {
        if (_detail is not { } item || _savingDims) return;

        _savingDims = true;
        try
        {
            var r = await Business.UpdateDimensionsAsync(item.Id, req);
            if (!r.IsSuccess)
            {
                Toast.Error(r.ErrorMessage ?? L["PartCard.History.DimsFailed"]);
                return;
            }

            // Cập nhật ngay dòng đang hiển thị (bảng + dialog dùng chung object),
            // không cần tải lại cả trang. Ưu tiên giá trị server trả về.
            var v = r.Value;
            item.Length = v?.Length ?? req.Length;
            item.Width = v?.Width ?? req.Width;
            item.Height = v?.Height ?? req.Height;
            item.Weight = v?.Weight ?? req.Weight;
            item.Source.Length = item.Length;
            item.Source.Width = item.Width;
            item.Source.Height = item.Height;
            item.Source.Weight = item.Weight;

            Toast.Success(L["PartCard.History.DimsSaved"]);
        }
        finally { _savingDims = false; }
    }

    // ── In lại: đẩy vào hàng đợi rồi sang màn Part Card ──
    // Phiếu dựng lại qua PartCardDto.ToViewModel (Card_ID mới — giống luồng in lại cũ).
    private void Reprint(AppPartCardHistory p) => SendToPrint(new[] { p });

    // Đưa danh sách phiếu sang màn Part Card để in lại (giữ đúng thứ tự truyền vào).
    private void SendToPrint(IEnumerable<AppPartCardHistory> cards)
    {
        foreach (var c in cards)
            ReprintBuffer.AddReprint(PartCardDto.ToViewModel(c.Source));
        _detail = null;
        Nav.NavigateTo("/part-cards");
    }

    // ── Export: lấy toàn bộ theo filter → CSV → swmsSaveFile ──
    private bool _exporting;

    private async Task ExportAsync()
    {
        _exporting = true;
        StateHasChanged();
        try
        {
            var run = await ListExporter.FetchAllAsync<AppPartCardHistory>(
                fetchPageAsync: async (page, size, ct) =>
                {
                    var q = BuildQuery(); q.Page = page; q.Size = size;
                    var r = await Business.GetPrintHistoryAsync(q);
                    if (!r.IsSuccess || r.Value is null) return null;
                    return new ExportPage<AppPartCardHistory>(
                        (r.Value.Items ?? new List<PartCardDto>()).Select(AppPartCardHistory.From).ToList(),
                        r.Value.TotalCount);
                },
                // API kẹp Size tối đa 100 → PageSize 100 (200 sẽ bị ép về 20).
                options: new ExportOptions { PageSize = 100, MaxRows = 50_000 },
                ct: default);

            if (run.Items.Count == 0)
            {
                Toast.Error(L["PartCardHistory.Toast.ExportEmpty"]);
                return;
            }

            var schema = PartCardHistoryCsvSchema.BuildSchema(L, CategoryText);
            var bytes = schema.Export(PartCardHistoryCsvSchema.Flatten(run.Items));
            await JS.InvokeVoidAsync("swmsSaveFile", schema.ExportFileName(), "text/csv", Convert.ToBase64String(bytes));
            Toast.Success(L["PartCardHistory.Toast.Exported", run.Items.Count]);
        }
        finally { _exporting = false; StateHasChanged(); }
    }
}
