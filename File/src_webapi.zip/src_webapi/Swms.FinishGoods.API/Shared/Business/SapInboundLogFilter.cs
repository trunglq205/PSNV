﻿using System.Diagnostics;
using System.Text;
using System.Text.Json;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Business;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;
using Swms.FinishGoods.API.Shared.Business.Exceptions;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

/// <summary>
/// Ghi lại MỌI request SAP gửi tới (body thô + kết quả) vào wms.sap_inbound_logs.
/// Là resource filter nên bắt được cả request hỏng JSON / sai model (400 trước khi vào action)
/// lẫn exception nghiệp vụ. Không đổi response; lỗi khi ghi log chỉ ghi Serilog, không làm hỏng request.
/// Ai sửa / đổi gì trong SI: filter không tự biết — service để lại trong SapInboundAudit, ở đây chỉ lưu.
/// </summary>
public class SapInboundLogFilter : IAsyncResourceFilter
{
    private readonly ISapInboundLogRepository _logs;
    private readonly ILogger<SapInboundLogFilter> _logger;

    public SapInboundLogFilter(ISapInboundLogRepository logs, ILogger<SapInboundLogFilter> logger)
    {
        _logs = logs;
        _logger = logger;
    }

    public async Task OnResourceExecutionAsync(ResourceExecutingContext context, ResourceExecutionDelegate next)
    {
        var http = context.HttpContext;
        var receivedAt = DateTime.Now;
        var sw = Stopwatch.StartNew();

        // Đọc body thô trước khi model binding, rồi tua lại để binding đọc bình thường.
        http.Request.EnableBuffering();
        string body;
        using (var reader = new StreamReader(http.Request.Body, Encoding.UTF8, false, 4096, leaveOpen: true))
            body = await reader.ReadToEndAsync();
        http.Request.Body.Position = 0;

        var executed = await next();
        sw.Stop();

        try
        {
            var (docNo, siNo, pic) = ReadKeys(body);
            var (status, siId, error) = Outcome(executed);
            // Lấy từ scope của request (không inject qua constructor): chạy đúng dù filter đăng ký lifetime nào.
            var audit = http.RequestServices.GetService<SapInboundAudit>() ?? new SapInboundAudit();

            await _logs.AddAsync(new SapInboundLog
            {
                Endpoint = $"{http.Request.Method} {http.Request.Path}",
                DocNo = Cut(docNo, 60),
                SiNo = Cut(siNo, 30),
                RequestBody = body,
                HttpStatus = status,
                // 200 mà payload không khác gì phiếu đang có -> "unchanged", để lọc "updated" ra đúng lần sửa thật
                Result = status == 200 && audit.Action == SapInboundAudit.Unchanged
                    ? "unchanged"
                    : status switch { 201 => "created", 200 => "updated", >= 500 => "error", _ => "rejected" },
                SiId = siId ?? audit.SiId,   // bị từ chối sau khi đã tìm ra phiếu: vẫn gắn được vào phiếu đó
                ChangedBy = Cut(audit.ChangedBy ?? pic, 100),
                ChangeSummary = Cut(audit.ChangeSummary, 500),
                Changes = audit.ChangesJson,
                ErrorMessage = Cut(error, 2000),
                RemoteIp = http.Connection.RemoteIpAddress?.ToString(),
                DurationMs = (int)sw.ElapsedMilliseconds,
                ReceivedAt = receivedAt,
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Không ghi được sap_inbound_logs. Body: {Body}", body);
        }
    }

    private static (int Status, long? SiId, string? Error) Outcome(ResourceExecutedContext executed)
    {
        // Exception chưa được xử lý -> middleware lỗi chung sẽ trả response; ở đây chỉ suy ra mã tương ứng.
        if (executed.Exception is { } ex && !executed.ExceptionHandled)
        {
            var code = ex switch
            {
                BusinessRuleException => 400,
                NotFoundException => 404,
                ConflictException => 409,
                _ => 500,
            };
            return (code, null, ex.Message);
        }

        if (executed.Result is ObjectResult obj)
        {
            var status = obj.StatusCode ?? 200;
            if (status < 400)
                return (status, (obj.Value as SiDetailResponse)?.Id, null);

            // 400 do model binding: ValidationProblemDetails -> gom lỗi từng trường
            var error = obj.Value is ValidationProblemDetails v
                ? string.Join("; ", v.Errors.Select(e => $"{e.Key}: {string.Join(", ", e.Value)}"))
                : obj.Value is ProblemDetails p ? p.Detail ?? p.Title : obj.Value?.ToString();
            return (status, null, error);
        }

        return ((executed.Result as StatusCodeResult)?.StatusCode ?? executed.HttpContext.Response.StatusCode, null, null);
    }

    /// <summary>Lấy documentno / sino / pic từ body thô — độc lập với model binding để request lỗi vẫn tra được.</summary>
    private static (string? DocNo, string? SiNo, string? Pic) ReadKeys(string body)
    {
        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.ValueKind != JsonValueKind.Object) return (null, null, null);
            string? Get(string name)
                => doc.RootElement.TryGetProperty(name, out var e) && e.ValueKind == JsonValueKind.String
                    ? e.GetString()?.Trim() : null;
            return (Get("documentno"), Get("sino"), Get("pic"));
        }
        catch (JsonException)
        {
            return (null, null, null);
        }
    }

    private static string? Cut(string? v, int max)
        => string.IsNullOrEmpty(v) ? null : v.Length <= max ? v : v[..max];
}