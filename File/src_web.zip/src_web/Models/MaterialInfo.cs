﻿using System.Runtime.Serialization;

namespace SWMS_WebTool.Models
{
    public enum MaterialInfoType
    {
        [EnumMember(Value = "0")]
        QM,
        [EnumMember(Value = "1")]
        TypeAndFrequency,
        [EnumMember(Value = "2")]
        Urgent,
        [EnumMember(Value = "3")]
        RHCOCUL,
        [EnumMember(Value = "4")]
        StandardPacking
    }

    public abstract class MaterialInfo
    {
        public string? Material { get; set; }
    }

    public class QM : MaterialInfo
    {
        public string? VendorCode { get; set; }
        public string? Plant { get; set; }
        public byte SamplingCheck { get; set; }
        public byte RohsCheck { get; set; }
        public string? Iqcpl { get; set; }
        public string? Rohs { get; set; }
    }

    public class TypeFrequency : MaterialInfo
    {
        public string? Plant { get; set; }
        public string? Sloc { get; set; }
        public string? PositionJPT { get; set; }
        public string? PositionFA { get; set; }
        public string? KittingType { get; set; }
        public string? SpecialPart { get; set; }
        public string? Type { get; set; }
        public string? Frequency { get; set; }
        public string? Description { get; set; }
        public string? Category { get; set; }
    }

    public class UrgentULCOCRH : MaterialInfo
    {
        public string? Urgent { get; set; }
        public string? Ulcoc { get; set; }
    }

    public class StandardPacking : MaterialInfo
    {
        public int Quantity { get; set; }
    }
}
