using System.ComponentModel.DataAnnotations;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

// Request / response cho chuyến xe lấy hàng. Khớp IShipmentTripApi (Refit) bên Web.

// ── Query ───────────────────────────────────────────────────
/// <summary>From / To: lấy chuyến có giờ dự kiến đến trong khoảng HOẶC có SI vanning trong khoảng.
/// Cả 2 trống = mọi chuyến (tối đa 500).</summary>
public class TripQuery
{
    public DateTime? From { get; set; }
    public DateTime? To { get; set; }
    [MaxLength(20)] public string? Status { get; set; }
    [MaxLength(50)] public string? Q { get; set; }
}

// ── Request ─────────────────────────────────────────────────
public class TripSiRequest
{
    [Range(1, long.MaxValue)] public long SiId { get; set; }
    /// <summary>Số pallet của SI này trên xe này. Xe tải: bắt buộc. Container: trống = cả SI.</summary>
    [Range(1, 999)] public int? PltPlanned { get; set; }
}

public class TripSaveRequest
{
    [Required, MaxLength(10)] public string VehicleType { get; set; } = "";     // container | truck
    [MaxLength(20)] public string? PlateNo { get; set; }
    [MaxLength(20)] public string? ContainerNo { get; set; }
    [MaxLength(10)] public string? ContainerSize { get; set; }
    [MaxLength(30)] public string? SealNo { get; set; }
    [MaxLength(100)] public string? DriverName { get; set; }
    [MaxLength(20)] public string? DriverPhone { get; set; }
    [MaxLength(20)] public string? DriverIdNo { get; set; }                     // số CCCD
    [MaxLength(20)] public string? DriverLicenseNo { get; set; }                // số GPLX
    [MaxLength(50)] public string? ForwarderCode { get; set; }
    public DateTime? PlannedArrivalAt { get; set; }
    [MaxLength(500)] public string? Note { get; set; }

    /// <summary>Tạo: bắt buộc ít nhất 1 SI. Sửa: null = giữ nguyên danh sách SI, có giá trị = thay toàn bộ.</summary>
    public List<TripSiRequest>? Sis { get; set; }
}

/// <summary>Action: arrive | seal | depart | cancel. Reason bắt buộc khi cancel.</summary>
public record TripStatusRequest([Required, MaxLength(10)] string Action, [MaxLength(400)] string? Reason);

// ── Response ────────────────────────────────────────────────
public record TripSiResponse(
    long SiId, string SiNo, string DocNo, string DocStatus, string? ShipMode, DateTime VanningDate,
    int? PltPlanned, int SiPltTotal, int SiPltPlannedAll)
{
    public static TripSiResponse From(TripSiRow r) => new(
        r.SiId, r.SiNo, r.DocNo, r.DocStatus, r.ShipMode, r.VanningDate,
        r.PltPlanned, r.SiPltTotal, r.SiPltPlannedAll);
}

/// <summary>DriverIdNo (CCCD), DriverLicenseNo (GPLX): màn xem / danh sách chỉ còn 4 số cuối; GET {id}/edit (quyền sửa) trả đủ.
/// DriverIdType: giữ cho client cũ — "cccd" khi có số CCCD, không thì null.
/// Warnings: cảnh báo không chặn (số cont sai check digit, tổng pallet các xe ≠ pallet SI).</summary>
public record TripResponse(
    long Id, string TripNo, string VehicleType, string? PlateNo,
    string? ContainerNo, string? ContainerSize, string? SealNo,
    string? DriverName, string? DriverPhone, string? DriverIdType, string? DriverIdNo, string? DriverLicenseNo,
    string? ForwarderCode, DateTime? PlannedArrivalAt,
    string Status,
    DateTime? ArrivedAt, string? ArrivedBy,
    DateTime? SealedAt, string? SealedBy,
    DateTime? DepartedAt, string? DepartedBy,
    DateTime? CancelledAt, string? CancelledBy, string? CancelReason,
    string? Note,
    DateTime CreatedAt, string? CreatedBy, DateTime? UpdatedAt, string? UpdatedBy,
    List<TripSiResponse> Sis,
    List<string> Warnings)
{
    public static TripResponse From(TripRow t, List<TripSiResponse> sis, List<string> warnings, bool maskDriverId) => new(
        t.Id, t.TripNo, t.VehicleType, t.PlateNo,
        t.ContainerNo, t.ContainerSize, t.SealNo,
        t.DriverName, t.DriverPhone, t.DriverIdType,
        maskDriverId ? Mask(t.DriverIdNo) : t.DriverIdNo,
        maskDriverId ? Mask(t.DriverLicenseNo) : t.DriverLicenseNo,
        t.ForwarderCode, t.PlannedArrivalAt,
        t.Status,
        t.ArrivedAt, t.ArrivedBy,
        t.SealedAt, t.SealedBy,
        t.DepartedAt, t.DepartedBy,
        t.CancelledAt, t.CancelledBy, t.CancelReason,
        t.Note,
        t.CreatedAt, t.CreatedBy, t.UpdatedAt, t.UpdatedBy,
        sis, warnings);

    /// <summary>"079123455678" -> "••••••••5678".</summary>
    public static string? Mask(string? v)
    {
        if (string.IsNullOrEmpty(v)) return v;
        return v.Length <= 4 ? new string('•', v.Length) : new string('•', v.Length - 4) + v[^4..];
    }
}