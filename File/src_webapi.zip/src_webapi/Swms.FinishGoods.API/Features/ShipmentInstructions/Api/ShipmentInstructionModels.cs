using System.ComponentModel.DataAnnotations;
using System.Text.Json;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Business;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

// Request / response DTOs cho feature Shipment Instruction. Khớp IShipmentInstructionApi (Refit) bên Web.

// ── Query ───────────────────────────────────────────────────
public class SiQuery : PagedQuery
{
    public string? DocNo { get; set; }          // LIKE theo si_no
    public string? DocStatus { get; set; }      // released | picking | completed | cancelled
    public string? ShipMode { get; set; }
    public string? Model { get; set; }
    public string? PoNo { get; set; }
    /// <summary>Lọc theo vanning = COALESCE(vanning_date, etd_date) — cùng định nghĩa màn Hàng thiếu.</summary>
    public DateTime? VanningFrom { get; set; }
    public DateTime? VanningTo { get; set; }
    public bool? HasShortage { get; set; }

    // Lọc nâng cao
    public string? ConsigneeCode { get; set; }
    public string? CountryCode { get; set; }
    public string? ForwarderCode { get; set; }
    public string? CarrierCode { get; set; }
    public string? PackingListNo { get; set; }
    public string? InvoiceNo { get; set; }
    public string? PicName { get; set; }
    public string? Category { get; set; }
    public string? Revision { get; set; }       // first | rev
    public bool? IsSerialRequired { get; set; }
    public DateTime? CreatedFrom { get; set; }
    public DateTime? CreatedTo { get; set; }
}

// ── Request ─────────────────────────────────────────────────
public class SiLineRequest
{
    public long? Id { get; set; }               // null = dòng mới (dùng khi PUT cả phiếu)
    public int LineNo { get; set; }             // 0 = tự đánh số
    [Required, MaxLength(50)] public string Model { get; set; } = "";
    [MaxLength(50)] public string? CustomerMaterial { get; set; }
    [MaxLength(50)] public string? PoNo { get; set; }
    [MaxLength(30)] public string? PackingListNo { get; set; }
    [MaxLength(10)] public string? PackingItemNo { get; set; }
    [MaxLength(30)] public string? InvoiceNo { get; set; }
    [MaxLength(30)] public string? SoNo { get; set; }
    [MaxLength(10)] public string? SoItemNo { get; set; }
    [Range(0, int.MaxValue)] public int QtyRequired { get; set; }
    [MaxLength(10)] public string? Uom { get; set; }
    public int? PackagePlt { get; set; }
    public int? PackageCtn { get; set; }
}

public class SiHeaderRequest
{
    [MaxLength(50)] public string? Category { get; set; }
    [MaxLength(20)] public string? ShipMode { get; set; }
    [Required] public DateTime EtdDate { get; set; }
    public DateTime? EtaDate { get; set; }
    public DateTime? VanningDate { get; set; }
    public DateTime? CutOffAt { get; set; }

    [MaxLength(50)] public string? PortOfLoading { get; set; }
    [MaxLength(50)] public string? PortOfDischarge { get; set; }
    [MaxLength(50)] public string? CountryCode { get; set; }
    [MaxLength(50)] public string? ForwarderCode { get; set; }
    [MaxLength(50)] public string? CarrierCode { get; set; }
    [MaxLength(50)] public string? ConsigneeCode { get; set; }

    [MaxLength(50)] public string? PackingType { get; set; }
    public bool? IsWhiteFilm { get; set; }
    public bool? IsCaseMark { get; set; }
    public bool? IsSerialRequired { get; set; }

    [MaxLength(100)] public string? PicName { get; set; }
    public long? ToAreaId { get; set; }
    [MaxLength(500)] public string? Description { get; set; }

    /// <summary>Thông tin chứng từ phụ -> header_note (JSON).</summary>
    public Dictionary<string, string>? HeaderNote { get; set; }
}

public class CreateSiRequest : SiHeaderRequest
{
    [Required, MaxLength(30)] public string SiNo { get; set; } = "";
    [MaxLength(20)] public string? Revision { get; set; }
    [MinLength(1)] public List<SiLineRequest> Lines { get; set; } = new();
}

public class UpdateSiRequest : SiHeaderRequest
{
    /// <summary>null = chỉ sửa header. Có giá trị = đồng bộ dòng (dòng đã phân bổ giữ nguyên).</summary>
    public List<SiLineRequest>? Lines { get; set; }
}

public record CancelSiRequest([Required, MaxLength(400)] string Reason);

/// <summary>QtyCut = null: bỏ cắt.</summary>
public record CutLineRequest([Range(1, int.MaxValue)] int? QtyCut);

public record AllocateRequest(long? LineId, long? ToLocatorId, [MaxLength(100)] string? AssignedTo);

public record UpdateTaskRequest(long? ToLocatorId, [MaxLength(100)] string? AssignedTo);

public record DesignateBoxesRequest([MinLength(1)] List<string> BoxNos, bool Replace);

public record ResolveBoxRequest([Required] long BoxId);

/// <summary>Lấy nguyên pallet: Pallet ID vừa quét, server so lại với dòng kế hoạch.</summary>
public record ConfirmPalletRequest([Required, MaxLength(50)] string PalletCode);

/// <summary>Lấy theo thùng: mã thùng vừa quét (tìm trong pallet của dòng kế hoạch).</summary>
public record PickBoxRequest([Required, MaxLength(50)] string BoxNo);

/// <summary>Lưu pallet tại vị trí vanning. PalletCode = pallet gốc (nguyên pallet / lấy hết thùng)
/// hoặc pallet mới tách (chứa các thùng đã lấy của dòng kế hoạch).</summary>
public record StageVanningRequest(
    [Required, MaxLength(50)] string PalletCode,
    [Required, MaxLength(50)] string LocatorCode);

// ── Response ────────────────────────────────────────────────
public record SiListItemResponse(
    long Id, string DocNo, string SiNo, string? Revision,
    string? Category, string? ShipMode, string DocStatus,
    DateTime EtdDate, DateTime? EtaDate, DateTime? VanningDate, DateTime? CutOffAt,
    string? ConsigneeCode, string? CountryCode, string? ForwarderCode, string? PicName,
    bool IsSerialRequired,
    int LineCount, int PackingListCount, int ModelCount, string? ModelsPreview, string? PoNos,
    int QtyRequired, int QtyFulfilled, int QtyCut, int QtyShort,
    int TotalPlt, int TotalCtn, int UnmatchedBoxCount,
    int QtyPending, int QtyPicked,
    DateTime CreatedAt, string? CreatedBy)
{
    public static SiListItemResponse From(SiListRow r) => new(
        r.Id, r.DocNo, r.SiNo, r.Revision, r.Category, r.ShipMode, r.DocStatus,
        r.EtdDate, r.EtaDate, r.VanningDate, r.CutOffAt,
        r.ConsigneeCode, r.CountryCode, r.ForwarderCode, r.PicName,
        r.IsSerialRequired ?? false,
        r.LineCount, r.PackingListCount, r.ModelCount, r.ModelsPreview, r.PoNos,
        r.QtyRequired, r.QtyFulfilled, r.QtyCut, r.QtyShort,
        r.TotalPlt, r.TotalCtn, r.UnmatchedBoxCount,
        r.QtyPending, r.QtyPicked,
        r.CreatedAt, r.CreatedBy);
}

public record SiTaskResponse(
    long Id, long LineId, string PalletCode, string PickMode, string UnitType,
    int BoxPlanned, int BoxPicked, int QtyPlanned,
    string? LocatorCode, string? AreaCode, long? ToLocatorId, string? ToLocatorCode,
    string? AssignedTo, bool IsFifo, string ShipmentStatus,
    DateTime? PickedAt, string? PickedBy, string? SkipReason, DateTime? ProductionDate,
    string? StagedPalletCode, string? StagedLocatorCode)
{
    public static SiTaskResponse From(SiTask t) => new(
        t.Id, t.LineId, t.PalletCode.Trim(), t.PickMode, t.UnitType,
        t.BoxPlanned, t.BoxPicked, t.QtyPlanned,
        t.LocatorCode, t.AreaCode, t.ToLocatorId, t.ToLocatorCode,
        t.AssignedTo, t.IsFifo, t.ShipmentStatus,
        t.PickedAt, t.PickedBy, t.SkipReason, t.ProductionDate,
        t.StagedPalletCode?.Trim(), t.StagedLocatorCode);
}

public record SiBoxResponse(
    long Id, string BoxNo, long? BoxId, string? PalletCode, string MatchStatus,
    string? TakenBySi, long? SiPalletId, DateTime? PickedAt, string? PickedBy)
{
    public static SiBoxResponse From(SiBox b) => new(
        b.Id, b.BoxNo, b.BoxId, b.PalletCode?.Trim(), b.MatchStatus,
        b.TakenBySi, b.SiPalletId, b.PickedAt, b.PickedBy);
}

public record SiLineResponse(
    long Id, int LineNo, string Model, string? CustomerMaterial, string? PoNo,
    string? PackingListNo, string? PackingItemNo, string? InvoiceNo, string? SoNo, string? SoItemNo,
    int QtyRequired, string? Uom, int Plt, int Ctn,
    int? QtyCut, string? CutBy, DateTime? CutAt,
    int QtyPending, int QtyPicked, int QtyShort,
    List<SiTaskResponse> Tasks, List<SiBoxResponse> DesignatedBoxes)
{
    public static SiLineResponse From(SiLine l, IEnumerable<SiTask> tasks, IEnumerable<SiBox> boxes) => new(
        l.Id, l.LineNo, l.Model, l.CustomerMaterial, l.PoNo,
        l.PackingListNo, l.PackingItemNo, l.InvoiceNo, l.SoNo, l.SoItemNo,
        l.QtyRequired, l.Uom, l.PackagePlt ?? 0, l.PackageCtn ?? 0,
        l.QtyCut, l.CutBy, l.CutAt,
        l.QtyPending, l.QtyPicked, l.QtyShort,
        tasks.Select(SiTaskResponse.From).ToList(),
        boxes.Select(SiBoxResponse.From).ToList());
}

public record SiDetailResponse(
    long Id, string DocNo, string SiNo, string? Revision,
    string? Category, string? ShipMode, string DocStatus,
    DateTime EtdDate, DateTime? EtaDate, DateTime? VanningDate, DateTime? CutOffAt,
    string? PortOfLoading, string? PortOfDischarge, string? CountryCode,
    string? ForwarderCode, string? CarrierCode, string? ConsigneeCode,
    string? PackingType, bool IsWhiteFilm, bool IsCaseMark, bool IsSerialRequired,
    string? PicName, long? ToAreaId, string? Description,
    Dictionary<string, string> HeaderNote,
    DateTime CreatedAt, string? CreatedBy, DateTime? UpdatedAt, string? UpdatedBy,
    List<SiLineResponse> Lines)
{
    public static SiDetailResponse From(SiDetail d)
    {
        var h = d.Header;
        var tasksByLine = d.Tasks.ToLookup(t => t.LineId);
        var boxesByLine = d.Boxes.ToLookup(b => b.LineId);
        return new(
            h.Id, h.DocNo, h.SiNo, h.Revision, h.Category, h.ShipMode, h.DocStatus,
            h.EtdDate, h.EtaDate, h.VanningDate, h.CutOffAt,
            h.PortOfLoading, h.PortOfDischarge, h.CountryCode,
            h.ForwarderCode, h.CarrierCode, h.ConsigneeCode,
            h.PackingType, h.IsWhiteFilm ?? false, h.IsCaseMark ?? false, h.IsSerialRequired ?? false,
            h.PicName, h.ToAreaId, h.Description,
            HeaderNoteJson.Read(h.HeaderNote),
            h.CreatedAt, h.CreatedBy, h.UpdatedAt, h.UpdatedBy,
            d.Lines.Select(l => SiLineResponse.From(l, tasksByLine[l.Id], boxesByLine[l.Id])).ToList());
    }
}

// ── Lịch sử SAP gửi ─────────────────────────────────────────
/// <summary>Đổi gì trong 1 lần SAP gửi. Header: trường header (note.* = khoá header_note).
/// Lines: Action = added | removed | changed, Fields chỉ có ở changed. Notes: điều hệ thống tự xử lý (vd. bỏ dòng trùng).</summary>
public record SiHistoryChanges(List<SiFieldChange> Header, List<SiLineChange> Lines, List<string> Notes)
{
    private static readonly JsonSerializerOptions Options = new(JsonSerializerDefaults.Web);

    /// <summary>Đọc cột changes của sap_inbound_logs. Rỗng / hỏng -> null.</summary>
    public static SiHistoryChanges? Parse(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return null;
        try
        {
            var c = JsonSerializer.Deserialize<SiHistoryChanges>(json, Options);
            return c is null ? null : new(c.Header ?? new(), c.Lines ?? new(), c.Notes ?? new());
        }
        catch (JsonException)
        {
            return null;
        }
    }
}

/// <summary>1 lần SAP gửi SI. Result: created | updated | unchanged | rejected | error.
/// ChangedBy = pic của payload; ReceivedAt = thời điểm. Changes = null khi không đổi gì / bị từ chối.</summary>
public record SiHistoryItemResponse(
    DateTime ReceivedAt, string? ChangedBy, string Result, int HttpStatus, string? DocNo,
    string? ChangeSummary, SiHistoryChanges? Changes, string? ErrorMessage)
{
    public static SiHistoryItemResponse From(SapInboundLog l) => new(
        l.ReceivedAt, l.ChangedBy, l.Result, l.HttpStatus, l.DocNo,
        l.ChangeSummary, SiHistoryChanges.Parse(l.Changes), l.ErrorMessage);
}

/// <summary>State: eligible (được lấy ngay) | picked | locked (chưa tới lượt NSX).</summary>
public record PickBoxResponse(long BoxId, string BoxNo, DateTime? ProductionDate, int Qty, string State);

/// <summary>Màn lấy hàng tại 1 vị trí. Boxes rỗng với lấy nguyên pallet.</summary>
public record PickTaskDetailResponse(SiTaskResponse Task, int PcsPerBox, List<PickBoxResponse> Boxes);

/// <summary>Số SI theo trạng thái (tab lọc). Key "" = tổng.</summary>
public record SiStatusCountResponse(Dictionary<string, int> Counts);

/// <summary>Kết quả phân bổ: số dòng kế hoạch tạo mới + số pcs còn thiếu sau phân bổ.</summary>
public record AllocateResponse(int Created, int QtyShortAfter);

// ── header_note <-> Dictionary ──────────────────────────────
public static class HeaderNoteJson
{
    public static Dictionary<string, string> Read(string? json)
    {
        if (string.IsNullOrWhiteSpace(json)) return new();
        try
        {
            // Giá trị có thể là số / bool trong JSON -> đưa hết về chuỗi để FE hiển thị.
            var raw = JsonSerializer.Deserialize<Dictionary<string, JsonElement>>(json) ?? new();
            return raw.ToDictionary(
                kv => kv.Key,
                kv => kv.Value.ValueKind == JsonValueKind.String ? kv.Value.GetString() ?? "" : kv.Value.GetRawText());
        }
        catch (JsonException)
        {
            return new() { ["note_raw"] = json };
        }
    }

    public static string? Write(Dictionary<string, string>? note)
    {
        var clean = note?
            .Where(kv => !string.IsNullOrWhiteSpace(kv.Key) && !string.IsNullOrWhiteSpace(kv.Value))
            .ToDictionary(kv => kv.Key.Trim(), kv => kv.Value.Trim());
        return clean is null || clean.Count == 0 ? null : JsonSerializer.Serialize(clean);
    }
}