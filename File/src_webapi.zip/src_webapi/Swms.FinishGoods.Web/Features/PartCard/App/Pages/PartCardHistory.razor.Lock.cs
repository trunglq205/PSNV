using Swms.FinishGoods.Web.Features.PartCard.Business.Models;

namespace Swms.FinishGoods.Web.Features.PartCard.App.Pages;

// Khoá / mở khoá phiếu đã in. Phiếu đang khoá thì KHÔNG xoá được (API chặn).
//
//   • 1 phiếu (nút ở dòng / dialog chi tiết): POST .../{id}/lock | unlock → API trả lại phiếu
//     kèm quyền mới → chép thẳng vào object đang hiển thị, không tải lại bảng.
//   • Nhiều phiếu (thanh chọn): POST .../bulk-lock | bulk-unlock → bỏ chọn + tải lại bảng.
//
// Thao tác đảo ngược được nên KHÔNG hỏi xác nhận.
// Nút nào hiện là do cờ CanLock / CanUnlock / CanDelete của TỪNG phiếu (API tính sẵn theo
// quyền người dùng + trạng thái khoá) — ở đây không tự suy luận lại quyền.
public partial class PartCardHistory
{
    // ── Bộ lọc trạng thái khoá: select trên toolbar, đồng bộ URL (?lock=locked|unlocked) ──
    private string _lock = "";   // "" = tất cả | locked | unlocked

    private const string LockLocked = "locked";
    private const string LockUnlocked = "unlocked";
    private const string QLock = "lock";

    private void SetLock(string v) { _lock = v; CommitState(); }

    // Giá trị gửi API (isLocked): true / false / null = không lọc.
    private bool? LockFilterValue => _lock switch
    {
        LockLocked => true,
        LockUnlocked => false,
        _ => null,
    };

    private string LockLabel(string v) => v switch
    {
        LockLocked => L["PartCardHistory.Lock.Locked"],
        LockUnlocked => L["PartCardHistory.Lock.Unlocked"],
        _ => v,
    };

    // Tooltip icon ổ khoá ở dòng: "Khoá bởi {người} lúc {giờ}".
    private string LockTitle(AppPartCardHistory p)
        => L["PartCardHistory.Lock.By", string.IsNullOrWhiteSpace(p.LockedBy) ? "—" : p.LockedBy, p.LockedAt];

    // Đang gọi API khoá / mở khoá → vô hiệu các nút liên quan, chống bấm đúp.
    private bool _lockBusy;

    // ── 1 phiếu ──
    private Task LockOne(AppPartCardHistory p) => SetLockedOneAsync(p, true);
    private Task UnlockOne(AppPartCardHistory p) => SetLockedOneAsync(p, false);

    private async Task SetLockedOneAsync(AppPartCardHistory p, bool locked)
    {
        if (_lockBusy) return;

        _lockBusy = true;
        try
        {
            var r = locked
                ? await Business.LockPrintHistoryAsync(p.Id)
                : await Business.UnlockPrintHistoryAsync(p.Id);
            if (!r.IsSuccess || r.Value is null)
            {
                Toast.Error(r.ErrorMessage
                    ?? L[locked ? "PartCardHistory.Toast.LockFailed" : "PartCardHistory.Toast.UnlockFailed"]);
                return;
            }

            // Bảng + dialog + danh sách chọn dùng chung object → sửa tại chỗ là mọi nơi đổi theo,
            // kể cả việc nút Xoá biến mất / hiện lại.
            p.ApplyLockState(r.Value);
            Toast.Success(L[locked ? "PartCardHistory.Toast.Locked" : "PartCardHistory.Toast.Unlocked", 1]);

            // Đang lọc theo trạng thái khoá → dòng vừa đổi có thể không còn khớp bộ lọc.
            if (_lock != "") await ReloadAsync();
        }
        finally { _lockBusy = false; }
    }

    // ── Nhiều phiếu (thanh chọn) ──
    // Chỉ gửi những phiếu người dùng ĐƯỢC thao tác; nút hiện đúng con số đó, = 0 thì ẩn nút.
    private int SelectedLockableCount => _selected.Count(x => x.CanLock);
    private int SelectedUnlockableCount => _selected.Count(x => x.CanUnlock);

    private Task LockSelected() => SetLockedManyAsync(true);
    private Task UnlockSelected() => SetLockedManyAsync(false);

    private async Task SetLockedManyAsync(bool locked)
    {
        if (_lockBusy) return;

        var ids = _selected.Where(x => locked ? x.CanLock : x.CanUnlock).Select(x => x.Id).ToList();
        if (ids.Count == 0) return;

        _lockBusy = true;
        try
        {
            var r = locked
                ? await Business.LockPrintHistoryAsync(ids)
                : await Business.UnlockPrintHistoryAsync(ids);
            if (!r.IsSuccess)
            {
                Toast.Error(r.ErrorMessage
                    ?? L[locked ? "PartCardHistory.Toast.LockFailed" : "PartCardHistory.Toast.UnlockFailed"]);
                return;
            }

            Toast.Success(L[locked ? "PartCardHistory.Toast.Locked" : "PartCardHistory.Toast.Unlocked",
                r.Value?.Affected ?? ids.Count]);

            // API bulk chỉ trả id, không trả quyền mới. Phiếu đã chọn nằm ở TRANG KHÁC sẽ không
            // được tải lại → cờ quyền của chúng thành cũ. Bỏ chọn hết rồi tải lại trang hiện tại.
            ClearSelection();
            await ReloadAsync();
        }
        finally { _lockBusy = false; }
    }
}
