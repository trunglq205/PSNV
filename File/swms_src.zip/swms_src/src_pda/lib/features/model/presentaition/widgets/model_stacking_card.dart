import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';
import 'package:swms_finish_goods/features/model/presentaition/widgets/model_field_grid.dart';

/// Quy cách xếp pallet. Các số tổng (thùng/lớp, thùng/pallet, set/pallet,
/// kích thước kiện) do server tính — chưa cấu hình thì hiện dòng nhắc.
class ModelStackingCard extends StatelessWidget {
  const ModelStackingCard({super.key, required this.model});

  final ModelDetail model;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        ModelSectionLabel('model_detail.stacking'.tr()),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              if (!model.hasStacking) ...[
                Row(
                  children: [
                    Icon(Icons.info_outline, size: 14, color: swms.warning),
                    const SizedBox(width: 6),
                    Expanded(
                      child: Text(
                        'model_detail.stacking_not_configured'.tr(),
                        style: AppTextStyles.caption.copyWith(
                          color: swms.warning,
                        ),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: AppDimens.sm),
              ],
              ModelFieldGrid(
                columns: 4,
                fields: [
                  ModelField.number(
                    'model_detail.stacking_length'.tr(),
                    model.stackingLength,
                  ),
                  ModelField.number(
                    'model_detail.stacking_width'.tr(),
                    model.stackingWidth,
                  ),
                  ModelField.number(
                    'model_detail.layer_count'.tr(),
                    model.layerCount,
                  ),
                  ModelField.number(
                    'model_detail.layer_limit'.tr(),
                    model.layerLimit,
                  ),
                ],
              ),
              Padding(
                padding: const EdgeInsets.symmetric(vertical: AppDimens.sm),
                child: Divider(height: 1, color: swms.border),
              ),
              ModelFieldGrid(
                fields: [
                  ModelField.number(
                    'model_detail.box_per_layer'.tr(),
                    model.boxPerLayer,
                  ),
                  ModelField.number(
                    'model_detail.box_per_pallet'.tr(),
                    model.boxPerPallet,
                  ),
                  ModelField.number(
                    'model_detail.set_per_pallet'.tr(),
                    model.setPerPallet,
                    unit: 'pcs',
                  ),
                  ModelField.number(
                    'model_detail.cargo_length'.tr(),
                    model.cargoLength,
                    unit: 'mm',
                  ),
                  ModelField.number(
                    'model_detail.cargo_width'.tr(),
                    model.cargoWidth,
                    unit: 'mm',
                  ),
                  ModelField.number(
                    'model_detail.cargo_height'.tr(),
                    model.cargoHeight,
                    unit: 'mm',
                  ),
                ],
              ),
            ],
          ),
        ),
      ],
    );
  }
}
