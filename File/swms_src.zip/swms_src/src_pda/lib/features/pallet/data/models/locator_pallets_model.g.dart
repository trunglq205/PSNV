// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'locator_pallets_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

LocatorPalletsModel _$LocatorPalletsModelFromJson(Map<String, dynamic> json) =>
    LocatorPalletsModel(
      locatorId: (json['locatorId'] as num).toInt(),
      locatorCode: json['locatorCode'] as String,
      areaCode: json['areaCode'] as String?,
      areaName: json['areaName'] as String?,
      mapType: json['mapType'] as String?,
      pallets:
          (json['pallets'] as List<dynamic>?)
              ?.map((e) => e as String)
              .toList() ??
          const [],
    );

Map<String, dynamic> _$LocatorPalletsModelToJson(
  LocatorPalletsModel instance,
) => <String, dynamic>{
  'locatorId': instance.locatorId,
  'locatorCode': instance.locatorCode,
  'areaCode': ?instance.areaCode,
  'areaName': ?instance.areaName,
  'mapType': ?instance.mapType,
  'pallets': instance.pallets,
};
