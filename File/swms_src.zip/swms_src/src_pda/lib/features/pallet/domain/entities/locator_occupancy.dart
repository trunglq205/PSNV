/// Vị trí + khu chứa nó + các pallet đang nằm tại đó.
class LocatorOccupancy {
  final String locatorCode;
  final String? areaCode;
  final String? areaName;

  /// receiving | storing | vanning — null nếu vị trí chưa gắn khu.
  final String? mapType;

  final List<String> pallets;

  const LocatorOccupancy({
    required this.locatorCode,
    this.areaCode,
    this.areaName,
    this.mapType,
    this.pallets = const [],
  });

  String get areaLabel => areaName ?? areaCode ?? '-';
}