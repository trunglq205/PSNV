﻿namespace SWMS_WebTool.Models.Filters
{
    public class SMTPanacimFilter : BaseFilter
    {
        public DeliveryPlanType? Type { get; set; }
        public string? VendorCode { get; set; }
        public string? Sloc { get; set; }
        public string? Plant { get; set; }
        public string? Material { get; set; }
        public SMTPanacimStatus? Status { get; set; }
        public string? Time { get; set; }
        public DateTime? Date { get; set; } = DateTime.Now;

    }
}
