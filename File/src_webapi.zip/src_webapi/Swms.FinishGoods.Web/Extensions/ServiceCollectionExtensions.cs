﻿// Extensions/ServiceCollectionExtensions.cs
using Swms.FinishGoods.Web.Features.AbnormalReports;
using Swms.FinishGoods.Web.Features.Auth;
using Swms.FinishGoods.Web.Features.Balance;
using Swms.FinishGoods.Web.Features.HdSoft;
using Swms.FinishGoods.Web.Features.Inventory;
using Swms.FinishGoods.Web.Features.MapDesigner;
using Swms.FinishGoods.Web.Features.MapView;
using Swms.FinishGoods.Web.Features.Models;
using Swms.FinishGoods.Web.Features.PartCard;
using Swms.FinishGoods.Web.Features.Reports;
using Swms.FinishGoods.Web.Features.ReturnInstructions;
using Swms.FinishGoods.Web.Features.Roles;
using Swms.FinishGoods.Web.Features.Settings;
using Swms.FinishGoods.Web.Features.ShipmentInstructions;
using Swms.FinishGoods.Web.Features.ShipmentTrips;
using Swms.FinishGoods.Web.Features.Shortages;
using Swms.FinishGoods.Web.Features.Stocktake;
using Swms.FinishGoods.Web.Features.Stocky;
using Swms.FinishGoods.Web.Features.StorageMap;
using Swms.FinishGoods.Web.Features.StowagePlan;
using Swms.FinishGoods.Web.Features.Sync;
using Swms.FinishGoods.Web.Features.TempLocMap;
using Swms.FinishGoods.Web.Features.Users;
using Swms.FinishGoods.Web.Features.WarehouseAreas;
using Swms.FinishGoods.Web.Shared;
using Swms.FinishGoods.Web.Shared.Profile;

namespace Swms.FinishGoods.Web.Extensions;

public static class ServiceCollectionExtensions
{
    public static IServiceCollection AddFeatures(this IServiceCollection services, IConfiguration configuration, IHostEnvironment env)
    {
        var api = services.AddSharedInfrastructure(configuration, env);

        return services
            .AddAuthFeature(api)
            .AddProfileFeature(api)
            .AddUserFeature(api)
            .AddRoleFeature(api)
            .AddPartCardFeature(api)
            .AddModelFeature(api)
            .AddTempLocMapFeature(api)
            .AddStorageMapFeature(api)
            .AddStocktakeFeature(api)
            .AddAbnormalReportFeature(api)
            .AddWarehouseAreasFeature(api)
            .AddMapDesignerFeature(api)
            .AddMapViewFeature(api)
            .AddBalanceFeature(api)
            .AddInventoryFeature(api)
            .AddReturnInstructionFeature(api)
            .AddStockyFeature(api)
            .AddShipmentInstructionFeature(api)
            .AddShortageFeature(api)
            .AddShipmentTripFeature(api)
            .AddStowagePlanFeature(api)
            .AddHdSoftFeature(api)
            .AddReportFeature()
            .AddSyncFeature(api)
            .AddSettingsFeature(api);
    }
}