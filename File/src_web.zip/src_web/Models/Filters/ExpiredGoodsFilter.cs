﻿using Refit;
using System.ComponentModel.DataAnnotations;

namespace SWMS_WebTool.Models.Filters
{
    public class ExpiredGoodsFilter : BaseFilter
    {
        public string? Material { get; set; }
        public string? Plant { get; set; }
        public string? Sloc { get; set; }
        public string? Category { get; set; }
        [AliasAs("isOver")]
        public bool IsAll { get; set; }
        public string? Selectdate { get; set; } = DateTime.Now.ToString("yyyy-MM-dd");

    }
}
