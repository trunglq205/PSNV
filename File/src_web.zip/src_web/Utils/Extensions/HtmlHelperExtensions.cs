﻿using Microsoft.AspNetCore.Html;
using Microsoft.AspNetCore.Mvc.Rendering;
using System.Linq.Expressions;
using System.Text.Encodings.Web;
using SWMS_WebTool.Services;

namespace SWMS_WebTool.Utils.Extensions
{
    public static class HtmlHelperExtensions
    {
        /// <summary>
        /// Như Html.LabelFor nhưng dịch i18n.
        /// Tự động dùng key "Field_{PropertyName}".
        /// VD: @Html.LocLabelFor(_ => filter.Material) → key "Field_Material"
        /// </summary>
        public static IHtmlContent LocLabelFor<TModel, TValue>(
            this IHtmlHelper<TModel> html,
            Expression<Func<TModel, TValue>> expression,
            object? htmlAttributes = null)
        {
            var propertyName = GetPropertyName(expression);
            var key = $"Field_{propertyName}";
            return BuildLabel(html, expression, key, htmlAttributes);
        }

        /// <summary>
        /// LocLabelFor với KEY i18n tùy chỉnh.
        /// VD: @Html.LocLabelFor(_ => filter.Modal, "Field_Model", new { @class = "..." })
        /// </summary>
        public static IHtmlContent LocLabelFor<TModel, TValue>(
            this IHtmlHelper<TModel> html,
            Expression<Func<TModel, TValue>> expression,
            string labelKey,
            object? htmlAttributes = null)
        {
            return BuildLabel(html, expression, labelKey, htmlAttributes);
        }

        private static IHtmlContent BuildLabel<TModel, TValue>(
            IHtmlHelper<TModel> html,
            Expression<Func<TModel, TValue>> expression,
            string key,
            object? htmlAttributes)
        {
            var loc = html.ViewContext.HttpContext.RequestServices
                .GetService(typeof(ILocalizationService)) as ILocalizationService;
            var text = loc?.Get(key) ?? key;

            var fieldName = html.NameFor(expression);
            var encoder = HtmlEncoder.Default;
            var attrs = $"for=\"{encoder.Encode(fieldName)}\"";

            if (htmlAttributes != null)
            {
                foreach (var prop in htmlAttributes.GetType().GetProperties())
                {
                    var name = prop.Name.Replace('_', '-');
                    var value = prop.GetValue(htmlAttributes)?.ToString() ?? "";
                    attrs += $" {name}=\"{encoder.Encode(value)}\"";
                }
            }

            return new HtmlString($"<label {attrs}>{encoder.Encode(text)}</label>");
        }

        private static string GetPropertyName<TModel, TValue>(
            Expression<Func<TModel, TValue>> expression)
        {
            if (expression.Body is MemberExpression member)
                return member.Member.Name;
            if (expression.Body is UnaryExpression unary &&
                unary.Operand is MemberExpression unaryMember)
                return unaryMember.Member.Name;
            return "";
        }
    }
}