using Swms.FinishGoods.Web.Features.Models.Business.Models;
using Swms.FinishGoods.Web.Shared.App.CsvIo;
using Microsoft.Extensions.Localization;

namespace Swms.FinishGoods.Web.Features.Models.App.Csvlo;

// ─────────────────────────────────────────────────────────────
//  Khai bao CSV danh rieng cho Model.
//  Day la TAT CA nhung gi man nay can viet de co import/export —
//  phan con lai do ha tang CsvIo lo (giong UserCsvSchema).
// ─────────────────────────────────────────────────────────────
public static class ModelCsvSchema
{
    public static CsvSchema<AppModel> BuildSchema(IStringLocalizer L) => new()
    {
        FileBaseName = "swms_models",
        MaxImportRows = 9999,
        Columns = new List<CsvColumn<AppModel>>
        {
            // Chi "code" bat buoc: file co the chi gom vai cot (vd code + origin) de cap nhat rieng cac cot do
            // cho ma da ton tai. category_code / length / width / height / standard_packing chi bat buoc khi
            // TAO MOI — API kiem tra va bo qua dong thieu (BulkUpsertAsync).
            new() { Key = "id",               Description = L["ModelCsv.Col.Id"],           Get = m => m.Id.ToString(), IncludeInImport = false, Example = "" },
            new() { Key = "code",             Description = L["ModelCsv.Col.Code"],         Required = true,  Get = m => m.Code,                Example = "TV-55X80K" },
            new() { Key = "gtin",             Description = L["ModelCsv.Col.Gtin"],         Required = false, Get = m => m.GTIN ?? "",          Example = "8801643721558" },
            new() { Key = "origin",           Description = L["ModelCsv.Col.Origin"],       Required = false, Get = m => m.Origin,              Example = "VN" },
            new() { Key = "category_code",    Description = L["ModelCsv.Col.CategoryCode"], Required = false, Get = m => m.CategoryCode.ToString(),        Example = "311" },
            new() { Key = "length",           Description = L["ModelCsv.Col.Length"],       Required = false, Get = m => m.Length.ToString(),   Example = "1350" },
            new() { Key = "width",            Description = L["ModelCsv.Col.Width"],        Required = false, Get = m => m.Width.ToString(),    Example = "180" },
            new() { Key = "height",           Description = L["ModelCsv.Col.Height"],       Required = false, Get = m => m.Height.ToString(),   Example = "850" },
            new() { Key = "standard_packing", Description = L["ModelCsv.Col.StdPacking"],   Required = false, Get = m => m.StandardPacking.ToString(), Example = "2" },
            new() { Key = "layer_limit",      Description = L["ModelCsv.Col.LayerLimit"],   Required = false, Get = m => Opt(m.LayerLimit),     Example = "13" },
            new() { Key = "layer_count",      Description = L["ModelCsv.Col.LayerCount"],   Required = false, Get = m => Opt(m.LayerCount),     Example = "6" },
            new() { Key = "stacking_length",  Description = L["ModelCsv.Col.StackingLength"], Required = false, Get = m => Opt(m.StackingLength), Example = "4" },
            new() { Key = "stacking_width",   Description = L["ModelCsv.Col.StackingWidth"],  Required = false, Get = m => Opt(m.StackingWidth),  Example = "3" },
            // Chi xuat de doi chieu — gia tri tinh, khong doc khi import
            new() { Key = "set_per_pallet",   Description = L["ModelCsv.Col.SetPerPallet"], Get = m => Opt(m.SetPerPallet), IncludeInImport = false },
            new() { Key = "suggest_area",     Description = L["ModelCsv.Col.SuggestArea"],  Required = false, Get = m => m.SuggestAreaCode,     Example = "A01" },
            new() { Key = "suggest_rack_row", Description = L["ModelCsv.Col.SuggestRackRow"], Required = false, Get = m => RackRowRule.ToCsv(m.SuggestRackRow), Example = "2|3" },
            new() { Key = "active",           Description = L["ModelCsv.Col.Active"],       Required = false, Get = m => m.IsActive ? "1" : "0", Example = "1" },
            new() { Key = "created_at",       Description = L["ModelCsv.Col.CreatedAt"],    Get = m => m.CreatedAt, IncludeInImport = false },
        },
        TemplateExamples = new List<IReadOnlyList<string>>
        {
            // Theo thu tu ImportColumns: code, gtin, origin, category_code, length, width, height (mm),
            // standard_packing, layer_limit, layer_count, stacking_length, stacking_width,
            // suggest_area, suggest_rack_row, active
            new[] { "DC-G97MP9", "4549980733412", "VN", "311", "300", "280", "160", "2", "13", "6", "4", "3", "A01", "2|3", "1" },
            new[] { "AU-SC04",   "",              "",   "911", "420", "300", "260", "4", "",   "",  "",  "",  "",    "",    "1" },
        },
        FooterNote = L["ModelCsv.Footer"],
    };

    // Validate + dung AppModel tu 1 dong.
    //
    // O DE TRONG = "khong dien": khong bao loi va khong gui len API, nen ma da ton tai se giu nguyen
    // gia tri cu cua cot do. Cot nao co dien duoc ghi vao AppModel.CsvFilled, de buoc gui
    // (Models.razor.ImportExport.cs) phan biet gia tri that voi gia tri mac dinh cua AppModel (0 / true).
    public static CsvBindResult<AppModel> Bind(CsvRowAccessor row, IStringLocalizer L)
    {
        var errs = new List<string>();
        var filled = new HashSet<string>(StringComparer.Ordinal);

        // Doc 1 o va danh dau cot do co dien hay khong.
        string Cell(string key)
        {
            var raw = (row.Get(key) ?? "").Trim();
            if (raw.Length > 0) filled.Add(key);
            return raw;
        }

        var code = Cell("code");
        var gtin = Cell("gtin");
        var originRaw = Cell("origin");
        var categoryCode = Cell("category_code").ToUpperInvariant();
        var lengthRaw = Cell("length");
        var widthRaw = Cell("width");
        var heightRaw = Cell("height");
        var packingRaw = Cell("standard_packing");
        var areaRaw = Cell("suggest_area");
        var rackRowRaw = Cell("suggest_rack_row");
        var activeRaw = Cell("active");

        if (string.IsNullOrWhiteSpace(code)) errs.Add(L["ModelCsv.Err.CodeEmpty"]);
        else if (code.Length > 30) errs.Add(L["ModelCsv.Err.CodeTooLong"]);

        if (gtin.Length > 0 && !System.Text.RegularExpressions.Regex.IsMatch(gtin, @"^(\d{8}|\d{12,14})$"))
            errs.Add(L["ModelCsv.Err.GtinInvalid"]);

        // origin: de trong, hoac ma / ten nuoc nam trong OriginRule.All (cung danh sach voi dropdown o form).
        var origin = OriginRule.Find(originRaw);
        if (originRaw.Length > 0 && origin is null)
            errs.Add(string.Format(L["ModelCsv.Err.OriginInvalid"], originRaw));

        // category_code / kich thuoc / standard_packing: de trong thi bo qua (xem ghi chu dau ham);
        // co dien thi phai dung dinh dang.
        int ParsePositiveInt(string raw, string errKey)
        {
            if (raw.Length == 0) return 0;
            if (!int.TryParse(raw, out var v) || v < 0) { errs.Add(L[errKey]); return 0; }
            return v;
        }

        var length = ParsePositiveInt(lengthRaw, "ModelCsv.Err.LengthInvalid");
        var width = ParsePositiveInt(widthRaw, "ModelCsv.Err.WidthInvalid");
        var height = ParsePositiveInt(heightRaw, "ModelCsv.Err.HeightInvalid");
        var packing = ParsePositiveInt(packingRaw, "ModelCsv.Err.PackingInvalid");

        // Quy cach xep pallet: o trong = null; co gia tri thi phai la so nguyen trong [1..max].
        int? ParseOptionalInt(string key, int max, string errKey)
        {
            var raw = Cell(key);
            if (raw.Length == 0) return null;
            if (int.TryParse(raw, out var v) && v >= 1 && v <= max) return v;
            errs.Add(string.Format(L[errKey], raw, max));
            return null;
        }

        var layerLimit = ParseOptionalInt("layer_limit", StackingRule.MaxLayer, "ModelCsv.Err.LayerLimitInvalid");
        var layerCount = ParseOptionalInt("layer_count", StackingRule.MaxLayer, "ModelCsv.Err.LayerCountInvalid");
        var stackingLength = ParseOptionalInt("stacking_length", StackingRule.MaxStacking, "ModelCsv.Err.StackingLengthInvalid");
        var stackingWidth = ParseOptionalInt("stacking_width", StackingRule.MaxStacking, "ModelCsv.Err.StackingWidthInvalid");

        // KHONG con kiem tra "nhap du ca 3 o layer_count / stacking_length / stacking_width" o day:
        // voi ma da ton tai, o thieu duoc lay tu ban ghi hien co — chi API moi biet, va API se tu choi
        // (kem ma model) neu sau khi gop van thieu. Rieng layer_count > layer_limit thi ca 2 deu nam
        // trong file nen bao ngay o preview.
        if (layerCount > layerLimit) errs.Add(string.Format(L["ModelCsv.Err.LayerCountExceedsLimit"], layerCount, layerLimit));

        // suggest_area: chi validate do dai; ma co ton tai hay khong se resolve o Models.razor.ImportExport.cs
        // (can option list nap tu API, khong co trong pham vi Bind).
        if (areaRaw.Length > 30) errs.Add(L["ModelCsv.Err.SuggestAreaTooLong"]);

        // suggest_rack_row: chap nhan nhieu kieu phan cach ( , ; | / space ) vi file go tay.
        var rackRows = RackRowRule.Parse(rackRowRaw, out var badRackRows);
        if (badRackRows.Count > 0)
            errs.Add(string.Format(L["ModelCsv.Err.RackRowInvalid"],
                                   string.Join(", ", badRackRows), RackRowRule.Min, RackRowRule.Max));

        // active de trong = khong dien (ma moi thi API mac dinh la dang dung).
        var isActive = activeRaw is "" or "1";
        if (activeRaw is not ("" or "0" or "1")) errs.Add(L["ModelCsv.Err.ActiveInvalid"]);

        if (errs.Count > 0) return CsvBindResult<AppModel>.Invalid(errs);

        return CsvBindResult<AppModel>.Ok(new AppModel
        {
            Code = code,
            GTIN = gtin,
            Origin = origin?.Code ?? "",
            CategoryCode = int.TryParse(categoryCode, out var value) ? value : 310,
            Length = length,
            Width = width,
            Height = height,
            StandardPacking = packing,
            LayerLimit = layerLimit,
            LayerCount = layerCount,
            StackingLength = stackingLength,
            StackingWidth = stackingWidth,
            SuggestAreaCode = areaRaw,
            SuggestRackRow = rackRows,
            IsActive = isActive,
            CsvFilled = filled,
        });
    }

    // Cot hien trong bang preview cua dialog.
    public static IReadOnlyList<CsvPreviewColumn<AppModel>> BuildPreviewColumns(IStringLocalizer L) => new[]
    {
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.Code"],       Value = m => m.Code },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.Gtin"],       Value = m => m.GTIN ?? "" },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.Origin"],     Value = m => m.Origin },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.Category"],   Value = m => m.IsCsvFilled("category_code") ? m.CategoryCode.ToString() : "" },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.Dimensions"], Value = DimPreview },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.StdPacking"], Value = m => m.IsCsvFilled("standard_packing") ? m.StandardPacking.ToString() : "" },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.Layer"],      Value = m => m.LayerCount is null ? "" : $"{m.LayerCount}/{Opt(m.LayerLimit)}" },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.Stacking"],   Value = m => m.HasStacking ? $"{m.StackingLength} × {m.StackingWidth}" : "" },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.SetPerPallet"], Value = m => Opt(m.SetPerPallet) },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.SuggestArea"],    Value = m => m.SuggestAreaCode },
        new CsvPreviewColumn<AppModel> { Header = L["ModelCsv.Preview.SuggestRackRow"], Value = m => m.SuggestRackRowText },
    };

    private static string Opt(int? v) => v?.ToString() ?? "";

    // Kich thuoc o preview: canh nao khong dien thi hien "—"; ca 3 khong dien thi de trong.
    private static string DimPreview(AppModel m)
    {
        var dims = new[] { ("length", m.Length), ("width", m.Width), ("height", m.Height) };
        if (!dims.Any(d => m.IsCsvFilled(d.Item1))) return "";
        return string.Join(" × ", dims.Select(d => m.IsCsvFilled(d.Item1) ? StackingRule.Cm(d.Item2) : "—"));
    }

    // ── CheckDuplicates: trùng code giữa các dòng trong file ─
    public static IReadOnlyDictionary<int, List<string>> CheckDuplicates(
        IReadOnlyList<(int LineNo, AppModel Item)> rows, IStringLocalizer L)
    {
        var extra = new Dictionary<int, List<string>>();

        void Flag(int line, string msg)
        {
            if (!extra.TryGetValue(line, out var l)) extra[line] = l = new();
            l.Add(msg);
        }

        var groups = rows
            .GroupBy(r => (r.Item.Code ?? "").ToLowerInvariant())
            .Where(g => g.Key.Length > 0 && g.Count() > 1);
        foreach (var g in groups)
            foreach (var r in g)
                Flag(r.LineNo, string.Format(L["ModelCsv.Err.CodeDup"], r.Item.Code));

        var gtinGroups = rows
            .GroupBy(r => (r.Item.GTIN ?? "").Trim())
            .Where(g => g.Key.Length > 0 && g.Count() > 1);
        foreach (var g in gtinGroups)
            foreach (var r in g)
                Flag(r.LineNo, string.Format(L["ModelCsv.Err.GtinDup"], r.Item.GTIN));

        return extra;
    }
}