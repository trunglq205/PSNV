import 'package:flutter/material.dart';
import 'package:liquid_glass_widgets/liquid_glass_widgets.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';

class Feature {
  const Feature({required this.icon, required this.title, required this.sub});
  final IconData icon;
  final String title;
  final String sub;
}

class LiquidGlassFeatureCard extends StatelessWidget {
  const LiquidGlassFeatureCard({super.key, required this.feature});
  final Feature feature;

  @override
  Widget build(BuildContext context) {
    return GlassCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md - AppDimens.xs,
        vertical: AppDimens.sm,
      ),
      child: Row(
        children: [
          GlassContainer(
            width: 32,
            height: 32,
            alignment: Alignment.center,
            child: Icon(
              feature.icon,
              size: 16,
              color: Colors.white.withValues(alpha: 0.8),
            ),
          ),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  feature.title,
                  style: AppTextStyles.label.copyWith(color: Colors.white),
                  overflow: TextOverflow.clip,
                ),
                const SizedBox(height: 2),
                Text(
                  feature.sub,
                  overflow: TextOverflow.clip,
                  style: AppTextStyles.caption.copyWith(
                    color: Colors.white.withValues(alpha: 0.75),
                    height: 1.2,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}