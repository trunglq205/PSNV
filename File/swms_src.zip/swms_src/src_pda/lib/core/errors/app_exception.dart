/// Gốc của cây exception nghiệp vụ. Mọi lỗi (Dio, Hive, ...) được map về đây
/// để tầng pages phân loại và hiển thị message i18n phù hợp.
///
/// [code] là khóa i18n (khớp key trong file dịch, ví dụ `error.network`),
/// [message] là chuỗi tiếng Việt mặc định dùng khi chưa kịp map i18n / khi log.
///
/// Cây kế thừa chia theo nhóm:
/// - [InfraException]  : lỗi hạ tầng (mạng, server, cache, auth...).
/// - [ScanException]   : lỗi nghiệp vụ quét thùng / model.
/// - [LotException]    : lỗi nghiệp vụ tạo lot.
sealed class AppException implements Exception {
  final String message;
  final String code;
  final int? statusCode;

  const AppException(this.message, {required this.code, this.statusCode});

  /// Tham số động chèn vào chuỗi i18n (mặc định rỗng).
  Map<String, String> get namedArgs => const {};

  @override
  String toString() => '$runtimeType($code: $message)';
}