import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/di/providers.dart';
import 'package:swms_finish_goods/features/return_instruction/data/return_back_repository.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Provider của mục 2c — khai THỦ CÔNG, không dùng @riverpod.
//
//  Cùng lý do đã ghi ở return_back_model.dart: bộ mục 2c làm sao để không cần
//  chạy build_runner. @riverpod sinh `.g.dart`, provider thủ công thì không.
//  Đây là cách `errorHandlerProvider` và `pdaProvider` trong core vẫn đang
//  dùng, nên không phải lối đi lạ trong source này.
// ─────────────────────────────────────────────────────────────

final returnBackRepositoryProvider = Provider<ReturnBackRepository>(
  (ref) => ReturnBackRepository(ref.watch(dioProvider)),
);

/// Các đề nghị ĐANG CHỜ SCS WH GIAO HÀNG của một phiếu.
///
/// Lọc `step` ở SERVER chứ không tải hết rồi lọc ở máy: PDA mở màn này giữa
/// kho, và một danh sách vài trăm đề nghị kéo qua mạng kho là chờ thật.
///
/// `docId` là tham số family nên phải so sánh được bằng `==` — int thì được.
final backDeliverableListProvider =
    FutureProvider.family<List<BackRequest>, int>((ref, docId) async {
  final rows = await ref
      .watch(returnBackRepositoryProvider)
      .fetchList(docId: docId, step: BackStep.scsDeliver.code);
  // Lọc lại một lần ở máy: nếu ai đó đổi tên bước bên API thì thà danh sách
  // rỗng còn hơn hiện một đề nghị mà quét vào thì server trả 409.
  return rows.where((r) => r.isDeliverable).toList();
});

/// Nhật ký pallet đã giao của một đề nghị.
final backDeliveriesProvider =
    FutureProvider.family<List<BackDelivery>, int>((ref, id) =>
        ref.watch(returnBackRepositoryProvider).fetchDeliveries(id));
