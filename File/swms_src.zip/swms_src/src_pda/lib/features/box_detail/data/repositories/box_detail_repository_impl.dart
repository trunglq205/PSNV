import 'package:swms_finish_goods/features/box_detail/data/datasources/box_detail_remote_data_source.dart';
import 'package:swms_finish_goods/features/box_detail/data/models/box_detail_model.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_event.dart';
import 'package:swms_finish_goods/features/box_detail/domain/repositories/box_detail_repository.dart';

class BoxDetailRepositoryImpl implements BoxDetailRepository {
  final BoxDetailRemoteDataSource _remote;
  const BoxDetailRepositoryImpl(this._remote);

  @override
  Future<BoxDetail> getDetail(int id) async {
    final res = await _remote.fetchBoxDetail(id);
    return res.toEntity();
  }

  @override
  Future<BoxDetail> getDetailByBoxNo(String boxNo, {String? palletId}) async {
    final res = await _remote.fetchBoxDetailByBoxNo(
      boxNo.trim(),
      palletId: _norm(palletId),
    );
    return res.toEntity();
  }

  @override
  Future<BoxDetail> updatePo({
    required int id,
    required String? customerPo,
    required String? psnvPo,
  }) async {
    final res = await _remote.patchBox(
      id,
      BoxPatchRequest(customerPo: _norm(customerPo), psnvPo: _norm(psnvPo)),
    );
    return res.toEntity();
  }

  @override
  Future<BoxHistory> getHistory(int id, {bool ownOnly = false}) async {
    // Chỉ gửi query khi bật: mặc định của server đã là false, gửi thừa chỉ làm
    // URL dài ra.
    final res = await _remote.fetchBoxHistory(
      id,
      ownOnly: ownOnly ? true : null,
    );
    return res.toEntity();
  }

  // Rỗng => null (xoá giá trị)
  static String? _norm(String? v) {
    final s = (v ?? '').trim();
    return s.isEmpty ? null : s;
  }
}