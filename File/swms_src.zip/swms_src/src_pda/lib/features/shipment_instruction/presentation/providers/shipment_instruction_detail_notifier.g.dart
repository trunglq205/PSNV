// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'shipment_instruction_detail_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Notifier family theo siId.

@ProviderFor(ShipmentInstructionDetailNotifier)
final shipmentInstructionDetailProvider =
    ShipmentInstructionDetailNotifierFamily._();

/// Notifier family theo siId.
final class ShipmentInstructionDetailNotifierProvider
    extends
        $NotifierProvider<
          ShipmentInstructionDetailNotifier,
          ShipmentInstructionDetailState
        > {
  /// Notifier family theo siId.
  ShipmentInstructionDetailNotifierProvider._({
    required ShipmentInstructionDetailNotifierFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'shipmentInstructionDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() =>
      _$shipmentInstructionDetailNotifierHash();

  @override
  String toString() {
    return r'shipmentInstructionDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  ShipmentInstructionDetailNotifier create() =>
      ShipmentInstructionDetailNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ShipmentInstructionDetailState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ShipmentInstructionDetailState>(
        value,
      ),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is ShipmentInstructionDetailNotifierProvider &&
        other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$shipmentInstructionDetailNotifierHash() =>
    r'ccc9d4fe00094e655f767697e74a3a6baef1c66e';

/// Notifier family theo siId.

final class ShipmentInstructionDetailNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          ShipmentInstructionDetailNotifier,
          ShipmentInstructionDetailState,
          ShipmentInstructionDetailState,
          ShipmentInstructionDetailState,
          int
        > {
  ShipmentInstructionDetailNotifierFamily._()
    : super(
        retry: null,
        name: r'shipmentInstructionDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Notifier family theo siId.

  ShipmentInstructionDetailNotifierProvider call(int siId) =>
      ShipmentInstructionDetailNotifierProvider._(argument: siId, from: this);

  @override
  String toString() => r'shipmentInstructionDetailProvider';
}

/// Notifier family theo siId.

abstract class _$ShipmentInstructionDetailNotifier
    extends $Notifier<ShipmentInstructionDetailState> {
  late final _$args = ref.$arg as int;
  int get siId => _$args;

  ShipmentInstructionDetailState build(int siId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref =
        this.ref
            as $Ref<
              ShipmentInstructionDetailState,
              ShipmentInstructionDetailState
            >;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<
                ShipmentInstructionDetailState,
                ShipmentInstructionDetailState
              >,
              ShipmentInstructionDetailState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
