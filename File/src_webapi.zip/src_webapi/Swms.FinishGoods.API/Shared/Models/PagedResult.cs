﻿namespace Swms.FinishGoods.API.Common.Models
{
    public record PagedResult<T>(IReadOnlyList<T> Items, int TotalCount, int Page, int Size)
    {
        public int TotalPages => (int)Math.Ceiling((double)TotalCount / Size);
    }
}
