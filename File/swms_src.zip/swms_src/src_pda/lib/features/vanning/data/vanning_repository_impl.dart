import 'dart:io';
import 'dart:typed_data';

import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/features/vanning/data/datasources/vanning_remote_data_source.dart';
import 'package:swms_finish_goods/features/vanning/data/models/merge_session_model.dart';
import 'package:swms_finish_goods/features/vanning/data/models/trip_evidence_model.dart';
import 'package:swms_finish_goods/features/vanning/data/models/trip_stowage_model.dart';
import 'package:swms_finish_goods/features/vanning/domain/trip_entities.dart';
import 'package:swms_finish_goods/features/vanning/domain/trip_evidence.dart';
import 'package:swms_finish_goods/features/vanning/domain/trip_stowage.dart';
import 'package:swms_finish_goods/features/vanning/domain/vanning_entities.dart';
import 'package:swms_finish_goods/features/vanning/domain/vanning_repository.dart';

class VanningRepositoryImpl implements VanningRepository {
  final VanningRemoteDataSource _remote;
  const VanningRepositoryImpl(this._remote);

  // ── Chuyến ─────────────────────────────────────────────────
  @override
  Future<List<TripItem>> getTodayTrips() async {
    final today = _ymd(DateTime.now());
    final models = await _remote.fetchTrips(from: today, to: today);
    final trips = models
        .map((m) => m.toEntity())
        .where((t) => t.status.isOpen)
        .toList()
    // Xe đã đến lên đầu, rồi theo giờ dự kiến.
      ..sort((a, b) {
        final r = _rank(a.status).compareTo(_rank(b.status));
        if (r != 0) return r;
        final pa = a.plannedArrivalAt, pb = b.plannedArrivalAt;
        if (pa == null && pb == null) return 0;
        if (pa == null || pb == null) return pa == null ? 1 : -1;
        return pa.compareTo(pb);
      });
    return trips;
  }

  @override
  Future<TripItem> findTrip(String code) async {
    final models = await _remote.fetchTrips(q: code);
    final trips = models.map((m) => m.toEntity()).toList();
    // Ưu tiên khớp đúng mã + còn mở; server tìm "chứa" nên có thể ra nhiều chuyến.
    final exact = trips.where((t) => t.matches(code)).toList();
    final pool = exact.isNotEmpty ? exact : trips;
    if (pool.isEmpty) throw ContainerNotFoundException(code);
    return pool.firstWhere((t) => t.status.isOpen, orElse: () => pool.first);
  }

  @override
  Future<List<TripItem>> findTripsByPallet(String code) async =>
      (await _remote.fetchTripsByPallet(code)).map((m) => m.toEntity()).toList();

  // ── Ảnh minh chứng + kiểm cont ─────────────────────────────
  @override
  Future<TripEvidence> getEvidence(int tripId) async =>
      (await _remote.fetchEvidence(tripId)).toEntity();

  @override
  Future<TripPhoto> uploadPhoto({
    required int tripId,
    required String itemKey,
    required PhotoUnitRef unit,
    required int slotNo,
    required String path,
  }) async {
    final model = await _remote.uploadPhoto(
      tripId,
      File(path),
      itemKey,
      unit.unitNo?.toString(),
      unit.palletCode,
      slotNo.toString(),
    );
    return model.toEntity();
  }

  @override
  Future<void> deletePhoto(int photoId) => _remote.deletePhoto(photoId);

  @override
  Future<Uint8List> photoBytes(int photoId, {String size = 'thumb'}) async =>
      Uint8List.fromList(await _remote.photoBytes(photoId, size));

  @override
  Future<TripInspection> submitInspection({
    required int tripId,
    required InspectionResult result,
    required Set<ContainerCondition> passedConditions,
    String? note,
  }) async {
    final trimmed = note?.trim();
    final model = await _remote.submitInspection(
      tripId,
      TripInspectionRequestModel(
        result: result.code,
        passedConditions: passedConditions.map((c) => c.code).toList(),
        note: (trimmed == null || trimmed.isEmpty) ? null : trimmed,
      ),
    );
    return model.toEntity();
  }

  // ── Gộp pallet ─────────────────────────────────────────────
  @override
  Future<MergeSession> openSession(int tripId, String baseCode) async =>
      (await _remote.openSession(tripId, baseCode)).toEntity();

  @override
  Future<MergeCandidate> lookupItem({
    required int tripId,
    required String baseCode,
    required String code,
  }) async =>
      (await _remote.lookupItem(tripId, baseCode, code)).toEntity();

  @override
  Future<MergeResult> confirmMerge({
    required int tripId,
    required String baseCode,
    required List<MergeCandidate> items,
  }) async {
    final result = await _remote.merge(
      tripId,
      MergeRequestModel(
        baseCode: baseCode,
        palletCodes: [
          for (final i in items)
            if (i.type == MergeItemType.pallet) i.code,
        ],
        boxCodes: [
          for (final i in items)
            if (i.type == MergeItemType.box) i.code,
        ],
        doublePallet: false,
      ),
    );
    return result.toEntity();
  }

  // ── Stowage Plan ───────────────────────────────────────────
  @override
  Future<TripStowage> getStowage(int tripId) async =>
      (await _remote.fetchStowage(tripId)).toEntity();

  @override
  Future<TripStowage> stackColumn({
    required int tripId,
    required String code,
    required String bottomCode,
    String? topCode,
  }) async =>
      (await _remote.stackColumn(
        tripId,
        code,
        StowageCodesRequestModel(bottomCode: bottomCode, topCode: topCode),
      ))
          .toEntity();

  @override
  Future<TripStowage> placeColumn({
    required int tripId,
    required String code,
    String? bottomCode,
    String? topCode,
  }) async =>
      (await _remote.placeColumn(
        tripId,
        code,
        StowageCodesRequestModel(bottomCode: bottomCode, topCode: topCode),
      ))
          .toEntity();

  @override
  Future<TripStowage> clearColumn({required int tripId, required String code}) async =>
      (await _remote.clearColumn(tripId, code)).toEntity();

  static int _rank(TripStatus s) => switch (s) {
    TripStatus.arrived => 0,
    TripStatus.planned => 1,
    TripStatus.sealed => 2,
    _ => 3,
  };

  static String _ymd(DateTime d) =>
      '${d.year.toString().padLeft(4, '0')}-'
          '${d.month.toString().padLeft(2, '0')}-'
          '${d.day.toString().padLeft(2, '0')}';
}