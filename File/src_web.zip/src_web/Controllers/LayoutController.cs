using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Layout;
using SWMS_WebTool.Models.Requests;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;
using Wkhtmltopdf.NetCore;

namespace SWMS_WebTool.Controllers
{
    public class LayoutController : BaseController
    {
        private readonly ApiService _apiService; 
        readonly IGeneratePdf _generatePdf;

        private List<ActionViewModel> actions = new List<ActionViewModel>
        {
            new ActionViewModel(icon: "/img/pointer.png"),
            new ActionViewModel() {
                Children = new List<ActionViewModel>()
                {
                    new ActionViewModel(type: WidgetType.Rectangle),
                    new ActionViewModel(type: WidgetType.Circle),
                    new ActionViewModel(type: WidgetType.Line),
                    new ActionViewModel(type: WidgetType.Arrow),
                    new ActionViewModel(type: WidgetType.ArrowFill ),
                }
            },
            new ActionViewModel(type: WidgetType.Text),
            new ActionViewModel() {
                Children = new List<ActionViewModel>()
                {
                    new ActionViewModel(type: WidgetType.ZoneSingleDoor),
                    new ActionViewModel(type: WidgetType.ZoneDoubleDoor),
                    new ActionViewModel(type: WidgetType.ZoneNoDoor),
                 }
            },
            new ActionViewModel(type: WidgetType.Trolley),
            new ActionViewModel() {
                Children = new List<ActionViewModel>()
                {
                    new ActionViewModel(type: WidgetType.SingleDoor),
                    new ActionViewModel(type: WidgetType.DoubleDoor),
                }
            },
            new ActionViewModel()
            {
                Children = new List<ActionViewModel>()
                {
                    new ActionViewModel(type: WidgetType.Folklift),
                    new ActionViewModel(type: WidgetType.FolkliftWorking),
                    new ActionViewModel(type: WidgetType.Folklift2),
                    new ActionViewModel(type: WidgetType.Container),
                    new ActionViewModel(type: WidgetType.Container2),
                }
            },
        };

        private List<ActionViewModel> zoneActions = new List<ActionViewModel>
        {
            new ActionViewModel(icon: "/img/pointer.png"),
            new ActionViewModel() {
                Children = new List<ActionViewModel>()
                {
                    new ActionViewModel(type: WidgetType.Rectangle),
                    new ActionViewModel(type: WidgetType.Circle),
                    new ActionViewModel(type: WidgetType.Line),
                    new ActionViewModel(type: WidgetType.Arrow),
                    new ActionViewModel(type: WidgetType.ArrowFill ),
                }
            },
            new ActionViewModel(type: WidgetType.Text),
            new ActionViewModel(type: WidgetType.Rack),
            new ActionViewModel() {
                Children = new List<ActionViewModel>()
                {
                    new ActionViewModel(type: WidgetType.SingleDoor),
                    new ActionViewModel(type: WidgetType.DoubleDoor),
                }
            },
            new ActionViewModel()
            {
                Children = new List<ActionViewModel>()
                {
                    new ActionViewModel(type: WidgetType.Folklift),
                    new ActionViewModel(type: WidgetType.FolkliftWorking),
                    new ActionViewModel(type: WidgetType.Folklift2),
                    new ActionViewModel(type: WidgetType.Container),
                    new ActionViewModel(type: WidgetType.Container2),
                }
            },
        };

        public LayoutController(ApiService apiService, IGeneratePdf generatePdf)
        {
            _apiService = apiService;
            _generatePdf = generatePdf;
        }

        // GET: /<controller>/
        public async Task<IActionResult> Index([FromQuery] LayoutFilter filter, int SelectedFloor = 0)
        {
            try
            {
                var floors = await _apiService.GetFloors();



                if (floors.Count == 0)
                {
                    var modeldefault = new LayoutViewModel()
                    {
                        //Floors = floors,
                        //FloorLayout = null,
                        //SelectedFloor = 0,
                    };
                    ViewBag.Actions = actions;
                    return View("Views/Layout/Index.cshtml", modeldefault);
                }

                var selectedFloor = SelectedFloor >= floors.Count ? 0 : SelectedFloor;





                var floorId = floors.ElementAt(selectedFloor).FloorId;

                Floor floorDetail = await _apiService.GetLayoutDetail(floorId);




                var model = new LayoutViewModel()
                {
                    Floors = floors,
                    FloorLayout = floorDetail,
                    SelectedFloor = selectedFloor,
                };
                ViewBag.Actions = actions;
                return View("Views/Layout/Index.cshtml", model);
            }
            catch (Exception e)
            {
                return RedirectToAction("Error", "Home", new { Message = e.Message });
            }
        }


        [HttpPost]
        public IActionResult DrawLayout([FromBody] KonvaObject konvaObject)
        {
            try
            {
                var layout = WidgetFactory.BuildWidget(konvaObject);

                if (layout is Floor)
                {
                    return PartialView("Views/Layout/_Drawing.cshtml", layout);
                }
                else
                {
                    return PartialView("Views/Layout/_DrawingZone.cshtml", layout);
                }
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult GetActionList(WidgetType? type)
        {
            ActionViewModel? selectedAction = null;

            if (type != null)
            {
                actions.ForEach(action =>
                {
                    if (action.Type == type)
                    {
                        selectedAction = action;
                    }
                    else
                    {
                        action.Children?.ForEach(item =>
                        {
                            if (item.Type == type)
                            {
                                selectedAction = item;
                                action.SelectedItem = item;
                            }
                        });
                    }
                });
            }

            return PartialView("Views/Layout/_Action.cshtml", new Tuple<List<ActionViewModel>, ActionViewModel?>(actions, selectedAction));
        }

        [HttpPost]
        public IActionResult GetActionZoneList(WidgetType? type)
        {
            ActionViewModel? selectedAction = null;

            if (type != null)
            {
                zoneActions.ForEach(action =>
                {
                    if (action.Type == type)
                    {
                        selectedAction = action;
                    }
                    else
                    {
                        action.Children?.ForEach(item =>
                        {
                            if (item.Type == type)
                            {
                                selectedAction = item;
                                action.SelectedItem = item;
                            }
                        });
                    }
                });
            }

            return PartialView("Views/Layout/_ActionZone.cshtml", new Tuple<List<ActionViewModel>, ActionViewModel?>(zoneActions, selectedAction));
        }

        [HttpPost]
        public IActionResult ViewZoneDetail([FromBody] KonvaObject konvaObject)
        {
            var layout = WidgetFactory.BuildWidget(konvaObject);

            return PartialView("Views/Layout/_ZoneDetailModal.cshtml", layout);
        }

        [HttpPost]
        public IActionResult AddWidget(WidgetType type, double x, double y)
        {
            try
            {
                Widget widget;
                switch (type)
                {
                    case WidgetType.Rectangle:
                        widget = new Rectangle() { X = x, Y = y, Width = 120, Height = 80, Fill = "#993366", };
                        break;
                    case WidgetType.Circle:
                        widget = new Circle() { X = x, Y = y, Radius = 20, Fill = "#FF0000", };
                        break;
                    case WidgetType.Line:
                        widget = new Line() { X = x, Y = y, Points = new List<Point>() { new Point(0, 0), new Point(100, 0) }, Border = "#FF00FF", BorderWidth = 10, };
                        break;
                    case WidgetType.Text:
                        widget = new Text() { X = x, Y = y, Label = "Input here..." };
                        break;
                    case WidgetType.SingleDoor:
                        widget = new SingleDoor() { X = x, Y = y };
                        break;
                    case WidgetType.DoubleDoor:
                        widget = new DoubleDoor() { X = x, Y = y };
                        break;
                    case WidgetType.Arrow:
                        widget = new Arrow() { X = x, Y = y, Width = 153, Height = 74 };
                        break;
                    case WidgetType.ArrowFill:
                        widget = new ArrowFill() { X = x, Y = y, Width = 153, Height = 74 };
                        break;
                    case WidgetType.Folklift:
                        widget = new Folklift() { X = x, Y = y, Width = 68, Height = 82 };
                        break;
                    case WidgetType.FolkliftWorking:
                        widget = new FolkliftWorking() { X = x, Y = y, Width = 69, Height = 84 };
                        break;
                    case WidgetType.Folklift2:
                        widget = new Folklift2() { X = x, Y = y, Width = 217, Height = 168 };
                        break;
                    case WidgetType.Container:
                        widget = new Container() { X = x, Y = y, Width = 115, Height = 83 };
                        break;
                    case WidgetType.Container2:
                        widget = new Container2() { X = x, Y = y, Width = 277, Height = 127 };
                        break;
                    default:
                        throw new Exception("This type is not supported.");
                }

                return Json(widget.ToKonvaObject());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult ViewWidgetDetail([FromBody] KonvaObject konvaObject)
        {
            var widget = WidgetFactory.BuildWidget(konvaObject);

            return PartialView("Views/Layout/_WidgetInformation.cshtml", widget);
        }

        [HttpPost]
        public async Task<IActionResult> UpdateWidget([FromBody] KonvaObject konvaObject)
        {
            var widget = WidgetFactory.BuildWidget(konvaObject);

            return Json(widget.ToKonvaObject());
        }


        [HttpPost]
        public async Task<IActionResult> SaveChange([FromBody] KonvaObject konvaObject)
        {
            try
            {
                var widget = WidgetFactory.BuildWidget(konvaObject);
                var request = new CreateWidgetRequest()
                {
                    Type = WidgetType.Floor,
                    Widget = widget,
                };
                await _apiService.CreateWidget(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost]
        public async Task<IActionResult> SaveZoneChange([FromBody] KonvaObject konvaObject)
        {
            try
            {
                var widget = WidgetFactory.BuildWidget(konvaObject);
                var request = new CreateWidgetRequest()
                {
                    Type = WidgetType.Zone,
                    Widget = widget,
                };
                await _apiService.CreateWidget(request);
                return Json(widget.ToKonvaObject());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        #region Floor
        [HttpGet]
        public async Task<IActionResult> CreateFloor()
        {
            return PartialView("Views/Layout/_AddFloorModal.cshtml", new FloorViewModel());
        }

        [HttpPost]
        public async Task<IActionResult> CreateFloor(FloorViewModel floor)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var floorRequest = new CreateUpdateFloorRequest() { 
                    Name = floor.Name, 
                    Code = floor.Code,
                    Width = floor.Width, 
                    Height = floor.Height 
                };
                await _apiService.CreateFloor(floorRequest);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateFloor([FromBody] CreateUpdateFloorRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                await _apiService.UpdateFloorAsync(request);
                return Json(new { success = true });
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult DeleteFloor(string id)
        {
            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDeleteFloor",
                Controller = "Layout",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteFloor(long id)
        {
            try
            {
                await _apiService.DeleteFloor(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }
        #endregion

        #region Zone
        [HttpGet]
        public IActionResult CreateZoneView(ZoneViewModel model)
        {
            return PartialView("Views/Layout/_AddZoneModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> CreateZone(ZoneViewModel zone)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var zoneRequest = new CreateUpdateZoneRequest()
                {
                    FloorId = zone.FloorId,
                    ZoneName = zone.Name,
                    X = zone.X,
                    Y = zone.Y,
                    Width = zone.Width,
                    Height = zone.Height,
                };
                var response = await _apiService.CreateZone(zoneRequest);
                return Json(response.ToKonvaObject());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateZone([FromBody] UpdateZoneRequest request)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var response = await _apiService.UpdateZoneAsync(request);
                return Json(response.ToKonvaObject());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult DeleteZone(string id)
        {
            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDeleteZone",
                Controller = "Layout",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteZone(long id)
        {
            try
            {
                await _apiService.DeleteZone(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        #endregion

        #region Rack
        [HttpGet]
        public async Task<IActionResult> CreateRackView(RackViewModel model)
        {
            var usersRes = await _apiService.SearchUsers(new UserFilter(), 1, Constants.PageMaximum);
            var mcsUser = usersRes.Records?.ToList();

            var categories = await _apiService.SearchCategory(new CategoryFilter(), 1, Constants.PageMaximum);
            var mcsCategories = categories?.Records?.ToList();

            return PartialView("Views/Layout/_AddEditRackModal.cshtml", (model, mcsUser, mcsCategories));
        }

        [HttpPost]
        public async Task<IActionResult> CreateRack(RackViewModel rack)
        {
            // Xóa các lỗi liên quan đến JITs
            ModelState.Remove("JITs");

            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var rackRequest = new CreateUpdateRackRequest()
                {
                    ZoneID = rack.ZoneID,
                    RackCode = rack.RackDetailType.ToString()[0] + rack.RackCode,
                    X = rack.X,
                    Y = rack.Y,
                    Width = rack.Width * rack.NumberOfUnit,
                    Height = rack.Height,
                    NumberOfLayer = rack.NumberOfLayer,
                    NumberOfUnit = rack.NumberOfUnit,
                    Category = rack.Category,
                    RackDetailType = rack.RackDetailType.ToString(),
                    IsPL = rack.IsPL,
                    TypeSloc = rack.TypeSloc.GetString(),
                    PIC = rack.PIC,
                    RackType = rack.RackDetailType.GetRackType(),
                };
                var response = await _apiService.CreateRack(rackRequest);
                return Json(response.ToKonvaObject());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateRackView([FromBody] KonvaObject konvaObject)
        {
            try
            {
                Rack rack = WidgetFactory.BuildWidget(konvaObject) as Rack;
                var model = new RackViewModel()
                {
                    RackID = rack.RackId,
                    RackCode = rack.RackCode.Substring(1),
                    Width = (rack.Width ?? 0) / rack.NumberOfUnit,
                    Height = rack.Height ?? 0,
                    Category = rack.Category,
                    IsPL = rack.IsPL,
                    TypeSloc = rack.TypeSloc,
                    NumberOfLayer = rack.NumberOfLayer,
                    NumberOfUnit = rack.NumberOfUnit,
                    PIC = rack.PIC,
                    RackDetailType = rack.RackDetailType,
                    X = rack.X ?? 0,
                    Y = rack.Y ?? 0,
                    Rotation = rack.Rotation ?? 0,
                    JITs = Enumerable.Range(1, rack.NumberOfLayer).Select(index => rack.JIT.Split(",").ToList().Contains(index.ToString())).ToList()
                };

                var usersRes = await _apiService.SearchUsers(new UserFilter(), 1, Constants.PageMaximum);

                var mcsUser = usersRes.Records?.ToList();
                var categories = await _apiService.SearchCategory(new CategoryFilter(), 1, Constants.PageMaximum);
                var mcsCategories = categories?.Records?.ToList();

                return PartialView("Views/Layout/_AddEditRackModal.cshtml", (model, mcsUser, mcsCategories));
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public async Task<IActionResult> UpdateRack(RackViewModel rack)
        {
            // Xóa các lỗi liên quan đến JITs
            ModelState.Remove("JITs");

            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var rackRequest = new UpdateRackRequest()
                {
                    RackID = rack.RackID ?? 0,
                    RackCode = rack.RackDetailType.ToString()[0] + rack.RackCode,
                    Category = rack.Category,
                    RackDetailType = rack.RackDetailType.ToString(),
                    IsPL = rack.IsPL,
                    TypeSloc = rack.TypeSloc.GetString(),
                    PIC = rack.PIC,
                    RackType = rack.RackDetailType.GetRackType(),
                    NumberOfLayer = rack.NumberOfLayer,
                    NumberOfUnit = rack.NumberOfUnit,
                    Width = rack.Width * rack.NumberOfUnit,
                    Height = rack.Height,
                    X = rack.X,
                    Y = rack.Y,
                    Rotation = rack.Rotation,
                    JIT = string.Join(",", rack.JITs.Select((element, index) => element ? index + 1 : 0).Where(e => e != 0)),

                    //JIT = rack.JITs.Any(x => x)? string.Join(",", rack.JITs.Select((e, i) => e ? i + 1 : 0).Where(e => e != 0)): null
                };
                var response = await _apiService.UpdateRack(rackRequest);
                return Json(response.ToKonvaObject());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult DeleteRack(string id)
        {
            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDeleteRack",
                Controller = "Layout",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteRack(long id)
        {
            try
            {
                await _apiService.DeleteRack(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }
        #endregion

        #region GenQR 
        [HttpGet]
        public async Task<IActionResult> GenQRCodeLocation(long id, int isLocation)
        {
            var dataGenCode = new List<GenQRCodeLocation>();

            var datas = await _apiService.GetInfoLocationForGens(id, isLocation);

            foreach (var item in datas)
            {
                var qrCode = StringExtensions.GenerateQR(item.BarCode);
                dataGenCode.Add(new GenQRCodeLocation()
                {
                    Name = item.LocationName,
                    QRCode = qrCode
                });
            }
            byte[] bytesRC = await _generatePdf.GetByteArray("~/Views/Layout/_LayoutGenQrCodeModal.cshtml", dataGenCode);
            return File(bytesRC, "application/pdf", string.Format("QR_{0}.pdf", DateTime.Now.ToString("yyyyMMddHHmmss")));
            //return PartialView("~/Views/Layout/_LayoutGenQrCodeModal.cshtml", dataGenCode);
        }
        #endregion

        #region Trolley
        [HttpGet]
        public IActionResult CreateTrolleyView(TrolleyLayoutViewModel model)
        {
            return PartialView("Views/Layout/_AddTrolleyModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> CreateTrolley(TrolleyLayoutViewModel trolley)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                var trolleyRequest = new CreateTrolleyRequest()
                {
                    FloorId = trolley.FloorID,
                    Name = "Trolley" + trolley.Code,
                    Code = "TL" + trolley.Code,
                    Category = trolley.Category.GetString(),
                    X = trolley.X,
                    Y = trolley.Y,
                    Width = trolley.Width,
                    Height = trolley.Height,
                };
                var response = await _apiService.CreateTrolley(trolleyRequest);
                return Json(response.ToKonvaObject());
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }


        [HttpPost]
        public IActionResult DeleteTrolley(string id)
        {
            var model = new DeleteObject()
            {
                Id = id,
                Action = "ConfirmDeleteTrolley",
                Controller = "Layout",
            };
            return PartialView("~/Views/Shared/_DeleteModal.cshtml", model);
        }

        [HttpPost]
        public async Task<IActionResult> ConfirmDeleteTrolley(long id)
        {
            try
            {
                await _apiService.DeleteTrolley(id);
                return RedirectToAction("Index");
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }
        }
        #endregion
    }
}
