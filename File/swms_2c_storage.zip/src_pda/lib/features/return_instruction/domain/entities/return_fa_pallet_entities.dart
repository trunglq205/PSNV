// ─────────────────────────────────────────────────────────────
//  Mục 2d — FA quét serial đóng lại Pallet ID sau khi rework xong.
//
//  Entity THUẦN, không annotation: bộ mục 2d cố tình không cần build_runner
//  (source hiện tại có hai file cùng khai `@RoutePage() class VanningPage` nên
//  build_runner vỡ). Việc đọc JSON nằm ở data/models/return_fa_pallet_model.dart.
// ─────────────────────────────────────────────────────────────

/// Một dòng sổ serial, dạng gọn để kiểm NGAY TRÊN MÁY lúc FA quét.
///
/// PDA tải cả sổ của phiếu một lần rồi tra tại chỗ, không hỏi server từng con:
/// bàn rework quét liên tục, mỗi con một request là FA đứng chờ mạng kho.
class FaSerialIndexRow {
  final String serial;
  final String model;
  final String status;

  const FaSerialIndexRow({
    required this.serial,
    required this.model,
    required this.status,
  });
}

/// Sổ serial đã nạp, tra theo mã serial.
///
/// Bọc thành class thay vì trả thẳng `Map`: chỗ gọi chỉ cần hỏi "con này thế
/// nào", không cần biết sổ được tổ chức ra sao. Và tra KHÔNG phân biệt hoa
/// thường — súng quét có thể trả về chữ hoa.
class FaSerialIndex {
  final Map<String, FaSerialIndexRow> _byUpper;

  FaSerialIndex(List<FaSerialIndexRow> rows)
      : _byUpper = {for (final r in rows) r.serial.toUpperCase(): r};

  int get length => _byUpper.length;

  FaSerialIndexRow? lookup(String serial) => _byUpper[serial.trim().toUpperCase()];

  /// Số con đang ở FA — tức phần FA còn phải đóng pallet trả về.
  int get atFaCount =>
      _byUpper.values.where((r) => r.status == 'at_fa').length;
}

/// Kết luận của việc tra MỘT serial trên máy, trước khi gửi server.
///
/// Ba giá trị khớp ba `reason` của nhật ký bên server, trừ một điểm: sổ tải về
/// chỉ có serial CỦA PHIẾU NÀY, nên PDA không phân biệt được "thuộc phiếu khác"
/// với "lạ hoàn toàn" — cả hai ra [unknown]. Server mới chia đôi được, và nó
/// chính là bên ghi nhật ký.
enum FaScanVerdict {
  /// Có trong sổ và đang ở `at_fa` — vào được pallet.
  ok,

  /// Có trong sổ phiếu này nhưng trạng thái khác `at_fa` (chưa giao FA / đã về
  /// / đã xuất / đã đánh ng).
  wrongStatus,

  /// Không có trong sổ phiếu này.
  unknown;

  bool get isOk => this == FaScanVerdict.ok;
}

/// Một serial FA đã quét, kèm kết luận tra sổ tại máy.
class FaScannedSerial {
  final String serial;
  final FaScanVerdict verdict;

  /// Model suy TỪ SỔ, không do FA nhập. Null khi serial không có trong sổ.
  final String? model;

  /// Trạng thái con đó đang mang, khi tra được — để FA đọc được vì sao bị loại.
  final String? foundStatus;

  const FaScannedSerial({
    required this.serial,
    required this.verdict,
    this.model,
    this.foundStatus,
  });
}

/// Một thùng FA đang đóng.
class FaScanBox {
  /// Mã thùng FA quét. Null = thùng không có mã; server tự đặt `{lotNo}-nn`.
  final String? boxNo;

  final List<FaScannedSerial> serials;

  const FaScanBox({this.boxNo, required this.serials});

  int get okCount => serials.where((s) => s.verdict.isOk).length;
  int get badCount => serials.length - okCount;
}

/// Một dòng nhật ký serial lệch, do server trả về.
class FaMismatch {
  final int id;
  final int docId;
  final int? palletId;
  final String? lotNo;
  final String serial;
  final String? model;

  /// `not_in_doc` | `wrong_status` | `other_doc` — khớp `ck_rsm_reason`.
  final String reason;

  final String? foundStatus;
  final String? otherDocNo;
  final DateTime scannedAt;
  final String? scannedBy;
  final DateTime? resolvedAt;
  final String? resolvedBy;
  final String? resolveNote;
  final bool isResolved;

  const FaMismatch({
    required this.id,
    required this.docId,
    this.palletId,
    this.lotNo,
    required this.serial,
    this.model,
    required this.reason,
    this.foundStatus,
    this.otherDocNo,
    required this.scannedAt,
    this.scannedBy,
    this.resolvedAt,
    this.resolvedBy,
    this.resolveNote,
    required this.isResolved,
  });
}

/// Kết quả một lượt FA đóng pallet.
class FaPalletResult {
  final int palletId;
  final String lotNo;
  final int categoryCode;
  final int boxCount;

  /// Số serial ĐÃ vào pallet.
  final int serialCount;

  /// Số serial bị loại trong CHÍNH lượt này.
  final int mismatchCount;

  /// Nhật ký lệch CÒN MỞ của cả phiếu — không chỉ lượt này. FA rời bàn là SCS
  /// đọc màn này, nên họ cần cả những con lượt trước chưa ai đặt riêng ra.
  final List<FaMismatch> mismatches;

  const FaPalletResult({
    required this.palletId,
    required this.lotNo,
    required this.categoryCode,
    required this.boxCount,
    required this.serialCount,
    required this.mismatchCount,
    required this.mismatches,
  });
}
