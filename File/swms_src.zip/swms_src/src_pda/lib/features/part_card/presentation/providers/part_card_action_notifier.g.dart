// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'part_card_action_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Sửa / Tách / Gộp tem ĐÃ IN. Mở từ Home sau khi quét tem + chọn action.
///
/// THỨ TỰ NGƯỢC màn in mới: LƯU SERVER TRƯỚC, IN SAU.
/// Tách / gộp huỷ tem cũ — nếu in trước rồi server từ chối (tem nguồn đã bị
/// tách / gộp ở máy khác, đã xoá…) thì nhãn mới ra giấy là nhãn ma. Lưu trước
/// thì server là chốt chặn; in hỏng giữa chừng chỉ cần in nốt
/// [PartCardActionState.pendingPrint], không đụng server nữa.

@ProviderFor(PartCardActionNotifier)
final partCardActionProvider = PartCardActionNotifierFamily._();

/// Sửa / Tách / Gộp tem ĐÃ IN. Mở từ Home sau khi quét tem + chọn action.
///
/// THỨ TỰ NGƯỢC màn in mới: LƯU SERVER TRƯỚC, IN SAU.
/// Tách / gộp huỷ tem cũ — nếu in trước rồi server từ chối (tem nguồn đã bị
/// tách / gộp ở máy khác, đã xoá…) thì nhãn mới ra giấy là nhãn ma. Lưu trước
/// thì server là chốt chặn; in hỏng giữa chừng chỉ cần in nốt
/// [PartCardActionState.pendingPrint], không đụng server nữa.
final class PartCardActionNotifierProvider
    extends $NotifierProvider<PartCardActionNotifier, PartCardActionState> {
  /// Sửa / Tách / Gộp tem ĐÃ IN. Mở từ Home sau khi quét tem + chọn action.
  ///
  /// THỨ TỰ NGƯỢC màn in mới: LƯU SERVER TRƯỚC, IN SAU.
  /// Tách / gộp huỷ tem cũ — nếu in trước rồi server từ chối (tem nguồn đã bị
  /// tách / gộp ở máy khác, đã xoá…) thì nhãn mới ra giấy là nhãn ma. Lưu trước
  /// thì server là chốt chặn; in hỏng giữa chừng chỉ cần in nốt
  /// [PartCardActionState.pendingPrint], không đụng server nữa.
  PartCardActionNotifierProvider._({
    required PartCardActionNotifierFamily super.from,
    required (PartCardAction, String) super.argument,
  }) : super(
         retry: null,
         name: r'partCardActionProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$partCardActionNotifierHash();

  @override
  String toString() {
    return r'partCardActionProvider'
        ''
        '$argument';
  }

  @$internal
  @override
  PartCardActionNotifier create() => PartCardActionNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(PartCardActionState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<PartCardActionState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is PartCardActionNotifierProvider &&
        other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$partCardActionNotifierHash() =>
    r'7ec32c408d4d7c9f04230f219ae4c5de59d4acb2';

/// Sửa / Tách / Gộp tem ĐÃ IN. Mở từ Home sau khi quét tem + chọn action.
///
/// THỨ TỰ NGƯỢC màn in mới: LƯU SERVER TRƯỚC, IN SAU.
/// Tách / gộp huỷ tem cũ — nếu in trước rồi server từ chối (tem nguồn đã bị
/// tách / gộp ở máy khác, đã xoá…) thì nhãn mới ra giấy là nhãn ma. Lưu trước
/// thì server là chốt chặn; in hỏng giữa chừng chỉ cần in nốt
/// [PartCardActionState.pendingPrint], không đụng server nữa.

final class PartCardActionNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          PartCardActionNotifier,
          PartCardActionState,
          PartCardActionState,
          PartCardActionState,
          (PartCardAction, String)
        > {
  PartCardActionNotifierFamily._()
    : super(
        retry: null,
        name: r'partCardActionProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Sửa / Tách / Gộp tem ĐÃ IN. Mở từ Home sau khi quét tem + chọn action.
  ///
  /// THỨ TỰ NGƯỢC màn in mới: LƯU SERVER TRƯỚC, IN SAU.
  /// Tách / gộp huỷ tem cũ — nếu in trước rồi server từ chối (tem nguồn đã bị
  /// tách / gộp ở máy khác, đã xoá…) thì nhãn mới ra giấy là nhãn ma. Lưu trước
  /// thì server là chốt chặn; in hỏng giữa chừng chỉ cần in nốt
  /// [PartCardActionState.pendingPrint], không đụng server nữa.

  PartCardActionNotifierProvider call(PartCardAction action, String payload) =>
      PartCardActionNotifierProvider._(argument: (action, payload), from: this);

  @override
  String toString() => r'partCardActionProvider';
}

/// Sửa / Tách / Gộp tem ĐÃ IN. Mở từ Home sau khi quét tem + chọn action.
///
/// THỨ TỰ NGƯỢC màn in mới: LƯU SERVER TRƯỚC, IN SAU.
/// Tách / gộp huỷ tem cũ — nếu in trước rồi server từ chối (tem nguồn đã bị
/// tách / gộp ở máy khác, đã xoá…) thì nhãn mới ra giấy là nhãn ma. Lưu trước
/// thì server là chốt chặn; in hỏng giữa chừng chỉ cần in nốt
/// [PartCardActionState.pendingPrint], không đụng server nữa.

abstract class _$PartCardActionNotifier extends $Notifier<PartCardActionState> {
  late final _$args = ref.$arg as (PartCardAction, String);
  PartCardAction get action => _$args.$1;
  String get payload => _$args.$2;

  PartCardActionState build(PartCardAction action, String payload);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<PartCardActionState, PartCardActionState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<PartCardActionState, PartCardActionState>,
              PartCardActionState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args.$1, _$args.$2));
  }
}
