using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.StockEvents.Api;
using Swms.FinishGoods.API.Features.StockEvents.Business;

namespace Swms.FinishGoods.API.Features.Pallets.Api
{
    /// <summary>
    /// Pallet — nghiệp vụ thuần SWMS. Các endpoint đồng bộ cùng prefix api/pallets
    /// nằm ở controller riêng của từng nguồn:
    ///   PalletFossController   (Features/Foss/PalletSync)   from-foss · foss-top-up · oqc-sync
    ///   PalletHdSoftController (Features/HdSoft/PalletSync) hdsoft-sync · hdsoft-sync-batch
    /// </summary>
    [ApiController]
    [Route("api/pallets")]
    public class PalletController : ControllerBase
    {
        private readonly IPalletService _service;
        private readonly IStockEventService _history;

        public PalletController(IPalletService service, IStockEventService history)
        {
            _service = service;
            _history = history;
        }

        [HttpGet]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<PagedResult<PalletResponse>>> GetAll([FromQuery] PalletQuery query)
            => Ok(await _service.GetPagedAsync(query));

        [HttpGet("{id:long}")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<PalletResponse>> GetById(long id)
            => Ok(await _service.GetByIdAsync(id));

        /// <summary>
        /// Quét mã pallet (barcode trên handheld) — endpoint chung cho Vị trí tạm,
        /// Quick Scan và Lưu kho.
        ///
        /// Mặc định trả thông tin lot + vị trí + tổng hợp model + allowedActions.
        /// Nạp thêm bằng <c>?include=</c>:
        ///   <c>boxes</c> (danh sách thùng/line), <c>history</c> (timeline pallet), <c>all</c>.
        /// Gợi ý vị trí lưu kho: GET .../storage-suggestion (PalletStorageSuggestionController).
        ///
        /// BREAKING: <c>history</c> giờ trả StockEventResponse (wms.stock_events)
        /// thay cho LocatorHistoryResponse. Route và tên flag giữ nguyên.
        ///
        /// Thay cho 4 endpoint cũ:
        ///   by-lot-no/{lotNo}            -> by-lot-no/{lotNo}?include=boxes
        ///   by-lot-no/{lotNo}/location   -> by-lot-no/{lotNo}  (404 thì POST .../from-foss)
        ///   by-lot-no/{lotNo}/detail     -> by-lot-no/{lotNo}?include=boxes,history
        /// </summary>
        [HttpGet("by-lot-no/{lotNo}")]
        [RequireAnyPermission<Perms.Receiving.Temploc.View, Perms.Pda.PdaReceiving.TempLocation>]
        public async Task<ActionResult<PalletDetailResponse>> GetByLotNo(
            string lotNo, [FromQuery] string? include)
            => Ok(await _service.GetDetailByLotNoAsync(lotNo, PalletIncludeParser.Parse(include)));

        [HttpPost]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<CreatePalletResponse>> Create(CreatePalletRequest request)
        {
            var created = await _service.CreateAsync(request);
            return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
        }

        [HttpDelete("{id:long}")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<IActionResult> Delete(long id)
        {
            await _service.DeleteAsync(id);
            return NoContent();
        }

        /// <summary>
        /// Sửa số lượng pallet box_count (tổng = boxCount × standardPacking).
        /// Chỉ áp cho pallet box_count — pallet serial / box_line sửa theo từng thùng.
        /// expectedQty (tuỳ chọn): SL client đang thấy; SL hiện tại khác thì 409 để không đè thay đổi của người khác.
        /// Ghi event QTY_ADJUSTED, giữ nguyên ID + lịch sử pallet.
        /// </summary>
        [HttpPut("{id:long}/box-count")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<UpdateBoxCountResponse>> UpdateBoxCount(
            long id, [FromBody] UpdateBoxCountRequest request)
            => Ok(await _service.UpdateBoxCountAsync(id, request));

        /// <summary>
        /// Xoá thùng khỏi pallet serial / box_line — dùng khi thùng không còn bên HD soft
        /// (màn so tồn) hoặc quét nhầm. Không cho xoá hết thùng.
        /// Ghi event PALLET_BOXES_REMOVED (mã thùng ở Note), tính lại box_count + ngày SX,
        /// mở khoá thẻ in để dùng lại.
        /// </summary>
        /// <response code="409">Thùng / pallet vừa bị người khác đổi — tải lại rồi thử lại.</response>
        /// <response code="422">Pallet box_count / thùng không thuộc pallet / chọn hết thùng.</response>
        [HttpPost("{id:long}/boxes/delete")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<DeleteBoxesResponse>> DeleteBoxes(
            long id, [FromBody] DeleteBoxesRequest request)
            => Ok(await _service.DeleteBoxesAsync(id, request));

        /// <summary>
        /// Đề xuất pallet_id kế tiếp cho category theo ngày server.
        /// Không giữ chỗ: hai request gần nhau có thể nhận cùng số — client vẫn
        /// phải xử lý 409 Lot.LotNoDuplicated khi POST và xin số mới.
        /// </summary>
        [HttpGet("next-lot-no")]
        [RequirePermission<Perms.Pda.PdaReceiving.Receive>]
        public async Task<ActionResult<NextLotNoResponse>> GetNextLotNo([FromQuery] int categoryCode)
            => Ok(await _service.GenerateNextLotNoAsync(categoryCode));

        // ── Lịch sử pallet ──────────────────────────────────────────

        /// <summary>
        /// Lịch sử đầy đủ của pallet: header + timeline.
        ///
        /// Khác <c>?include=history</c> ở chỗ có header và bộ lọc — dùng cho MÀN
        /// lịch sử, còn include=history là timeline rút gọn kèm theo lúc quét.
        ///
        /// Lọc: <c>?from=&amp;to=&amp;codes=STORAGE_IN,STORAGE_MOVED&amp;groups=MOVE,OQC</c>
        /// </summary>
        [HttpGet("{id:long}/history")]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<PalletHistoryResponse>> GetHistory(
            long id, [FromQuery] StockEventQuery query)
            => Ok(await _history.GetPalletHistoryAsync(id, query));

        /// <summary>
        /// Như trên nhưng tra theo mã quét. Khớp CẢ pallet_id LẪN stocky_code —
        /// bản cũ chỉ so pallet_id nên xe stocky luôn ra lịch sử rỗng.
        /// </summary>
        [HttpGet("by-lot-no/{lotNo}/history")]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<PalletHistoryResponse>> GetHistoryByLotNo(
            string lotNo, [FromQuery] StockEventQuery query)
            => Ok(await _history.GetPalletHistoryByLotNoAsync(lotNo, query));

        // ── Vị trí tạm (PDA) #26 Rời · #27 Gán · #28 Chuyển ──

        /// <summary>
        /// Gán vị trí tạm (lot chưa có) hoặc chuyển vị trí (lot đã có).
        /// Cùng thao tác với PUT /{id}/storing, tách route vì khác quyền và
        /// khác tiền điều kiện (lưu kho đòi pallet đang ở khu vị trí tạm).
        /// </summary>
        [HttpPut("{id:long}/locator")]
        [RequirePermission<Perms.Receiving.Temploc.Assign>]
        public async Task<ActionResult<LocatorChangeResponse>> AssignLocator(
            long id, [FromBody] AssignLocatorRequest request)
            => Ok(await _service.AssignLocatorAsync(id, request.LocatorCode, request.AllowedMapType));

        /// <summary>Rời vị trí: gỡ lot khỏi vị trí đang đứng.</summary>
        [HttpDelete("{id:long}/locator")]
        [RequirePermission<Perms.Receiving.Temploc.Release>]
        public async Task<ActionResult<LocatorChangeResponse>> ReleaseLocator(long id)
            => Ok(await _service.ReleaseLocatorAsync(id));

        /// <summary>Tách pallet: chuyển 1 số thùng sang lot đích (có sẵn hoặc mới).</summary>
        [HttpPost("split")]
        [RequirePermission<Perms.Receiving.Temploc.View>]
        public async Task<ActionResult<SplitPalletResponse>> Split(
            [FromBody] SplitPalletRequest req)
            => Ok(await _service.SplitAsync(req));

        /// <summary>
        /// Lưu kho: đặt pallet vào vị trí đích (ghi nhận vị trí — FR-STR-04).
        /// Vị trí đích đã có pallet khác vẫn cho lưu, chỉ trả cảnh báo (Warning).
        /// Điều kiện khu vực (pallet phải đang ở khu vị trí tạm) được kiểm tại đây.
        /// </summary>
        [HttpPut("{id:long}/storing")]
        [RequirePermission<Perms.Pda.PdaStorage.Putaway>]
        public async Task<ActionResult<LocatorChangeResponse>> Store(
            long id, [FromBody] StoreRequest request)
            => Ok(await _service.StoreAsync(id, request.LocatorCode));
    }
}
