using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.Sync.Business;
using Swms.FinishGoods.API.Shared.DataAccess; // ICurrentUser — chỉnh lại namespace nếu khác

namespace Swms.FinishGoods.API.Features.Sync.Api;

/// <summary>
/// POST /api/sync/fa | oqc | hdsoft | all   (?full=true: HD soft quét toàn bộ)
/// POST /api/sync/cancel
/// GET  /api/sync/status
///
/// Job chạy nền trên server: POST trả về ngay (202), Web hỏi /status mỗi 2 giây.
/// </summary>
[ApiController]
[Route("api/sync")]
public sealed class SyncController : ControllerBase
{
    private readonly SyncRunner _runner;
    private readonly ICurrentUser _user;

    public SyncController(SyncRunner runner, ICurrentUser user)
    {
        _runner = runner;
        _user = user;
    }

    [HttpGet("status")]
    public ActionResult<SyncStatusResponse> Status() => Ok(_runner.Status);

    [HttpPost("cancel")]
    public IActionResult Cancel()
    {
        _runner.Cancel();
        return Ok(_runner.Status);
    }

    [HttpPost("{kind}")]
    public ActionResult<SyncStatusResponse> Start(SyncJobKind kind, [FromQuery] bool full = false)
    {
        // Lấy actor NGAY trong request — job nền không còn HttpContext.
        var actor = _user.FullName ?? "unknown";

        return _runner.TryStart(kind, actor, full)
            ? Accepted(_runner.Status)
            : Conflict(_runner.Status); // đang có job khác (người khác vừa bấm)
    }
}
