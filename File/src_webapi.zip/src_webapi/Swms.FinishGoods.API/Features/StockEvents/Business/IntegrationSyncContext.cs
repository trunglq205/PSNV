﻿using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using System.Diagnostics;
using System.Text.Json;

namespace Swms.FinishGoods.API.Features.StockEvents.Business
{
    /// <summary>
    /// Một lần gọi FOSS / HD soft. Tạo lúc bắt đầu xử lý; mọi event ghi ra
    /// trong lần gọi đó mang cùng source/actor và payload có startedAt + durationMs
    /// (tính tại lúc ghi event = thời gian từ đầu lần gọi tới khi dữ liệu được lưu).
    /// </summary>
    public sealed class IntegrationSyncContext
    {
        private readonly Stopwatch _sw = Stopwatch.StartNew();

        public string Source { get; }
        public string? Actor { get; }
        public DateTime StartedAt { get; } = DateTime.Now;

        /// <summary>Gom các pallet của cùng 1 lần gọi batch.</summary>
        public Guid? BatchId { get; init; }

        public IntegrationSyncContext(string source, string? actor)
        {
            Source = source;
            Actor = actor;
        }

        public string ToPayload(object? extra = null)
        {
            var dict = new Dictionary<string, object?>
            {
                ["startedAt"] = StartedAt,
                ["durationMs"] = _sw.ElapsedMilliseconds,
            };
            if (BatchId is not null) dict["batchId"] = BatchId;

            if (extra is not null)
                foreach (var p in JsonSerializer.SerializeToElement(extra).EnumerateObject())
                    dict[p.Name] = p.Value;

            return JsonSerializer.Serialize(dict);
        }

        public StockEventContext ToEventContext(string eventCode, object? extra = null)
            => new(eventCode, Actor) { Source = Source, Payload = ToPayload(extra) };
    }
}