using System.Text.Json.Serialization;

namespace Swms.FinishGoods.Web.Features.Inventory.HdSoftCompare.Business.Models;

// DTO của màn so tồn SWMS ↔ HD soft và các nút xử lý chênh lệch.
// Tách khỏi InventoryDto.cs: màn danh sách tồn kho không dùng tới.

/// <summary>Khớp GET /api/hdsoft/pallets/in-stock (snake_case).</summary>
public class HdSoftPalletStockDto
{
    [JsonPropertyName("pallet_no")] public string PalletNo { get; set; } = "";
    [JsonPropertyName("model")] public string? Model { get; set; }
    [JsonPropertyName("locator")] public string? Locator { get; set; }
    [JsonPropertyName("warehouse")] public string? Warehouse { get; set; }
    [JsonPropertyName("qty_on_hand")] public decimal QtyOnHand { get; set; }
}

/// <summary>Phần cần dùng của PalletDetailResponse (trả kèm trong HdSoftSyncResponse).</summary>
public class PalletBriefDto
{
    public long Id { get; set; }
    public string LotNo { get; set; } = "";
    public string InspectionStatus { get; set; } = "";
    public string? LocatorCode { get; set; }
}

/// <summary>Khớp HdSoftSyncResponse.</summary>
public class HdSoftSyncResultDto
{
    public PalletBriefDto Pallet { get; set; } = new();
    public string? LastMovementType { get; set; }
    public string? LastMovementLocator { get; set; }
    public List<string> Actions { get; set; } = new();
    public List<string> Warnings { get; set; } = new();
}

/// <summary>
/// Khớp CreatePalletRequest (POST /api/pallets) — chỉ phần dùng cho pallet box_count.
/// DetailLevel / LotType gửi snake_case, converter phía API nhận.
/// </summary>
public class CreatePalletRequestDto
{
    public string DetailLevel { get; set; } = "box_count";
    public string LotNo { get; set; } = "";
    public int CategoryCode { get; set; }
    public string LotType { get; set; } = "pallet";
    public string? StockyCode { get; set; }
    public string? Model { get; set; }
    public int? StandardPacking { get; set; }
    public DateTime? ProductionDate { get; set; }
    public int? BoxCount { get; set; }
}

/// <summary>Khớp CreatePalletResponse.</summary>
public class CreatePalletResultDto
{
    public long Id { get; set; }
    public string LotNo { get; set; } = "";
}

/// <summary>Khớp AssignLocatorRequest (PUT /api/pallets/{id}/locator).</summary>
public class AssignLocatorRequestDto
{
    public string LocatorCode { get; set; } = "";
    public string? AllowedMapType { get; set; }
}

/// <summary>Khớp UpdateBoxCountRequest (PUT /api/pallets/{id}/box-count).</summary>
public class UpdateBoxCountRequestDto
{
    public int BoxCount { get; set; }
    public int? StandardPacking { get; set; }
    public int? ExpectedQty { get; set; }
    public string? Reason { get; set; }
}

/// <summary>Khớp UpdateBoxCountResponse.</summary>
public class UpdateBoxCountResultDto
{
    public int QtyBefore { get; set; }
    public int QtyAfter { get; set; }
}

/// <summary>Khớp LocatorChangeResponse — Warning khi vị trí đích đã có pallet khác.</summary>
public class LocatorChangeResultDto
{
    public string? ToLocatorCode { get; set; }
    public string? Warning { get; set; }
}

/// <summary>Phần cần dùng của FossTopUpResponse (POST .../foss-top-up).</summary>
public class FossTopUpResultDto
{
    /// <summary>Câu tóm tắt đã dịch phía server (đã thêm bao nhiêu, bỏ qua thùng nào vì sao).</summary>
    public string Message { get; set; } = "";
    public int FossBoxCount { get; set; }
    public int BoxesAdded { get; set; }
    public int LinesAdded { get; set; }
    public int SkippedBoxes { get; set; }
    public bool OqcChanged { get; set; }
}

/// <summary>Khớp DeleteBoxesRequest (POST /api/pallets/{id}/boxes/delete).</summary>
public class DeleteBoxesRequestDto
{
    public List<long> BoxIds { get; set; } = new();
    public string? Reason { get; set; }
}

/// <summary>Khớp DeleteBoxesResponse.</summary>
public class DeleteBoxesResultDto
{
    public long LotId { get; set; }
    public string LotNo { get; set; } = "";
    public int BoxesDeleted { get; set; }
    public int LinesDeleted { get; set; }
    public int QtyDeleted { get; set; }
    public int BoxCountBefore { get; set; }
    public int BoxCountAfter { get; set; }
}
