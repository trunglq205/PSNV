import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_results.dart';

/// Mở dialog báo tách pallet thành công.
///
/// Trả `true` khi bấm "Xong" (màn gọi tự đóng về trước), `null` khi bấm ra
/// ngoài — giữ đúng hành vi cũ: bấm ra ngoài chỉ đóng dialog, ở lại màn.
///
/// [onReprint] != null ⇒ pallet đích là lot MỚI: hiện nút "In lại tem" và
/// cảnh báo khi [printed] = false. Callback trả `true` nếu in được.
Future<bool?> showSplitSuccessDialog(
  BuildContext context, {
  required SplitResult result,
  bool printed = true,
  Future<bool> Function()? onReprint,
}) {
  return showAppDialog<bool>(
    context,
    builder: (_) => SplitSuccessDialog(
      result: result,
      printed: printed,
      onReprint: onReprint,
    ),
  );
}

class SplitSuccessDialog extends StatefulWidget {
  const SplitSuccessDialog({
    super.key,
    required this.result,
    this.printed = true,
    this.onReprint,
  });

  final SplitResult result;

  /// Tem pallet mới đã in được ở lần đầu chưa.
  final bool printed;

  /// Null = tách vào lot đã có, không in tem.
  final Future<bool> Function()? onReprint;

  @override
  State<SplitSuccessDialog> createState() => _SplitSuccessDialogState();
}

class _SplitSuccessDialogState extends State<SplitSuccessDialog> {
  late bool _printed = widget.printed;
  bool _reprinting = false;

  bool get _canPrint => widget.onReprint != null;

  Future<void> _reprint() async {
    final onReprint = widget.onReprint;
    if (onReprint == null || _reprinting) return;

    setState(() => _reprinting = true);
    final ok = await onReprint();
    if (!mounted) return;
    setState(() {
      _reprinting = false;
      if (ok) _printed = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final r = widget.result;

    return AppDialog(
      hero: AppDialogHeroIcon(icon: Icons.check_circle, color: swms.success),
      title: LocaleKeys.pallet_split_success_title.tr(),
      message: LocaleKeys.pallet_split_success_body.tr(
        args: ['${r.movedBoxes}', r.targetLotNo, '${r.sourceRemainingBoxes}'],
      ),
      actions: [
        if (_canPrint)
          AppDialogAction(
            label: LocaleKeys.pallet_split_print_label_retry.tr(),
            icon: Icons.print,
            variant: AppButtonVariant.neutral,
            isLoading: _reprinting,
            onPressed: _reprinting ? null : _reprint,
          ),
        AppDialogAction.confirm(
          label: LocaleKeys.pallet_split_done.tr(),
          // Đang in dở thì không cho đóng — tránh setState sau khi dispose
          // và người dùng tưởng tem đã in.
          onPressed: _reprinting ? null : () => Navigator.pop(context, true),
        ),
      ],
      // Lot mới mà chưa in được tem → nhắc đỏ ngay dưới nội dung.
      child: _canPrint && !_printed
          ? Text(
              LocaleKeys.pallet_split_print_label_pending.tr(),
              textAlign: TextAlign.center,
              style: AppTextStyles.caption.copyWith(color: swms.danger),
            )
          : null,
    );
  }
}
