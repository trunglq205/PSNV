using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Features.ReturnInstructions.Business;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Api;

/// <summary>
/// Chỉ thị back hàng return / refurbish — mục 1 của quy trình.
///
/// SCS Office tạo phiếu (model + SL + ngày hàng về), hệ thống báo FA bằng
/// mail, SCS WH xem trên PDA. Web và PDA dùng CHUNG endpoint danh sách: hai
/// bên cùng nhìn một dữ liệu, tách ra là sớm muộn lệch nhau.
///
/// Quyền lấy từ nhánh <c>Perms.Receiving.ReworkRefurbish</c> đã khai sẵn:
/// <c>View</c> cho đọc (cả Office lẫn WH), <c>Create</c> cho ghi (chỉ Office).
/// </summary>
[ApiController]
[Route("api/return-instructions")]
public class ReturnInstructionsController : ControllerBase
{
    private readonly IReturnInstructionService _service;
    public ReturnInstructionsController(IReturnInstructionService service) => _service = service;

    /// <summary>Danh sách chỉ thị. Dùng cho cả màn Web và màn PDA.</summary>
    [HttpGet]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<ReturnInstructionResponse>>> GetList(
        [FromQuery] ReturnInstructionQuery query)
        => Ok(await _service.GetListAsync(query));

    /// <summary>Một phiếu kèm chi tiết dòng.</summary>
    [HttpGet("{id:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<ReturnInstructionResponse>> GetById(long id)
        => Ok(await _service.GetByIdAsync(id));

    /// <summary>SCS Office tạo chỉ thị. Tạo xong hệ thống tự gửi mail báo FA.</summary>
    [HttpPost]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<ActionResult<ReturnInstructionResponse>> Create(
        [FromBody] ReturnInstructionRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    /// <summary>
    /// Sửa phiếu còn mở. KHÔNG gửi lại mail cho FA — xem
    /// <see cref="IReturnInstructionService.UpdateAsync"/>.
    /// </summary>
    [HttpPut("{id:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<ActionResult<ReturnInstructionResponse>> Update(
        long id, [FromBody] ReturnInstructionRequest request)
        => Ok(await _service.UpdateAsync(id, request));

    /// <summary>Xoá mềm phiếu còn mở.</summary>
    [HttpDelete("{id:long}")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<IActionResult> Delete(long id)
    {
        await _service.DeleteAsync(id);
        return NoContent();
    }

    // ── Mục 2b: chốt SL thực nhận ───────────────────────────────

    /// <summary>
    /// WH quét xong thì chốt SL thực nhận: đóng phiếu và TỰ GỬI MAIL báo FA số
    /// thực tế kèm bảng lệch so với chỉ thị.
    ///
    /// Lệch thiếu / vượt đều không chặn. Chỉ chặn khi chưa nhận được con nào.
    /// </summary>
    /// <response code="400">Phiếu chưa nhận được serial nào.</response>
    /// <response code="409">Phiếu không còn ở trạng thái mở (có thể người khác vừa chốt).</response>
    [HttpPost("{id:long}/close")]
    // Process HOẶC Create: WH chốt ngay trên PDA sau khi quét xong, Office
    // cũng chốt được trên Web khi WH đã rời cầu cảng.
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.Process,
                          Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<ActionResult<ReturnInstructionResponse>> Close(long id)
        => Ok(await _service.CloseAsync(id));

    /// <summary>
    /// Office mở lại phiếu đã chốt để WH quét tiếp phần hàng về sau. Chốt lại
    /// sẽ gửi FA một mail mới.
    ///
    /// Chỉ Office (<c>Create</c>): mở lại một phiếu đã báo FA là nói với FA
    /// rằng số cũ chưa phải số cuối, đó là việc của bên lập phiếu.
    /// </summary>
    [HttpPost("{id:long}/reopen")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<ActionResult<ReturnInstructionResponse>> Reopen(long id)
        => Ok(await _service.ReopenAsync(id));

    // ── Mục 2a: SCS WH nhận hàng vào phiếu ──────────────────────

    /// <summary>
    /// WH nhận một pallet hàng return: quét từng thùng, quét serial trong
    /// thùng. Server cấp Pallet ID (hàng trả về không có nhãn in sẵn) và đăng
    /// ký toàn bộ serial vào sổ của phiếu trong cùng một transaction.
    ///
    /// Quyền <c>Process</c> chứ không phải <c>Create</c>: đây là việc của WH,
    /// còn <c>Create</c> là quyền của Office để lập phiếu.
    /// </summary>
    /// <response code="400">Model không thuộc phiếu, lẫn category, serial trùng trong request.</response>
    /// <response code="409">Phiếu đã đóng, hoặc serial đã thuộc một phiếu khác.</response>
    [HttpPost("{id:long}/pallets")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.Process>]
    public async Task<ActionResult<ReceiveReturnResponse>> Receive(
        long id, [FromBody] ReceiveReturnRequest request)
        => Ok(await _service.ReceiveAsync(id, request));

    /// <summary>Các pallet hàng return đã nhận vào phiếu.</summary>
    [HttpGet("{id:long}/pallets")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<ReturnPalletResponse>>> GetPallets(long id)
        => Ok(await _service.GetPalletsAsync(id));

    /// <summary>
    /// Huỷ một lần nhận: xoá mềm pallet và giải phóng serial khỏi sổ của phiếu.
    /// Dùng khi WH quét sai cả pallet.
    ///
    /// Không có đường này thì những serial đã quét sai bị khoá vĩnh viễn —
    /// unique index giữ chúng trên phạm vi toàn hệ thống.
    /// </summary>
    /// <response code="404">Pallet không thuộc phiếu này.</response>
    /// <response code="409">Phiếu đã đóng.</response>
    [HttpDelete("{id:long}/pallets/{palletId:long}")]
    // Process HOẶC Create: WH huỷ ngay trên PDA khi vừa quét sai, còn Office
    // huỷ trên Web khi WH đã rời cầu cảng mới phát hiện. Khoá riêng cho một
    // bên là bên kia phải gọi điện nhờ.
    [RequireAnyPermission<Perms.Receiving.ReworkRefurbish.Process,
                          Perms.Receiving.ReworkRefurbish.Create>]
    public async Task<ActionResult<ReturnInstructionResponse>> ReleasePallet(
        long id, long palletId)
        => Ok(await _service.ReleasePalletAsync(id, palletId));

    /// <summary>
    /// Toàn bộ serial trong sổ của phiếu. Mục 2d / 5 / 9 / 11 đối chiếu trên
    /// chính danh sách này.
    /// </summary>
    [HttpGet("{id:long}/serials")]
    [RequirePermission<Perms.Receiving.ReworkRefurbish.View>]
    public async Task<ActionResult<IReadOnlyList<ReturnSerialResponse>>> GetSerials(long id)
        => Ok(await _service.GetSerialsAsync(id));
}
