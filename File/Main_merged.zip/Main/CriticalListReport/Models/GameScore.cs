﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CriticalListReport.Models
{
    /// <summary>
    /// Một lượt chơi mini game sau đăng nhập. Bảng: tblGameScore (giữ nguyên cấu trúc, không cần sửa DB).
    /// Game Giáng sinh "Flappy Santa" (Theme = 'christmas') dùng các cột như sau:
    ///   Hits       = ĐIỂM (số cột người tuyết vượt qua) — do SERVER tự tính khi chơi lại lượt chơi
    ///   DurationMs = thời gian bay (ms)
    ///   Throws     = số lần bấm bay
    ///   UsedAuto   = 1 nếu lượt bị loại (dữ liệu không khớp / thời gian bất thường) → không xếp hạng
    /// Các dòng Theme = 'halloween' cũ vẫn còn trong bảng, không ảnh hưởng gì.
    /// </summary>
    [Table("tblGameScore")]
    public class GameScore
    {
        [Key]
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Username { get; set; } = string.Empty;

        [StringLength(200)]
        public string? FullName { get; set; }

        [Required, StringLength(20)]
        public string Theme { get; set; } = "christmas";

        public int DurationMs { get; set; }

        public int Throws { get; set; }

        public int Hits { get; set; }

        public bool UsedAuto { get; set; }

        public DateTime PlayedAt { get; set; } = DateTime.Now;
    }

    /// <summary>Trình duyệt xin bắt đầu / báo bắt đầu một lượt chơi.</summary>
    public class GameSessionRequest
    {
        public string? SessionId { get; set; }
    }

    /// <summary>
    /// Kết quả trình duyệt gửi lên: KHÔNG có điểm — chỉ có các tick bấm bay.
    /// Server tự chơi lại (Helpers/XmasFlappySim) để ra điểm.
    /// </summary>
    public class GameScoreSubmit
    {
        public string? SessionId { get; set; }
        public List<int>? Flaps { get; set; }
        public int EndTick { get; set; }
    }
}
