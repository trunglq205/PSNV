using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Shared.Application.Models;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business;

public interface IReturnBackRequestBusiness
{
    /// <summary>Danh sách. Mọi tham số null = không lọc.</summary>
    Task<Result<List<ReturnBackRequestDto>>> GetListAsync(
        long? docId = null, string? status = null, string? step = null, string? keyword = null);

    Task<Result<ReturnBackRequestDto>> GetByIdAsync(long id);

    /// <summary>
    /// SL kho còn gắp được theo model của một chỉ thị — màn soạn đề nghị gọi để
    /// CHO XEM phần hàng sẽ lấy về, không phải để nhập.
    /// </summary>
    Task<Result<List<BackAvailableModelDto>>> GetAvailableAsync(long docId);

    /// <summary>Nhật ký pallet đã giao, mới nhất trước.</summary>
    Task<Result<List<BackDeliveryDto>>> GetDeliveriesAsync(long id);

    Task<Result<ReturnBackRequestDto>> CreateAsync(CreateBackRequestRequestDto request);

    Task<Result<ReturnBackRequestDto>> UpdateAsync(long id, UpdateBackRequestRequestDto request);

    /// <summary>B2 — quản lý FA xác nhận. Mail sang SCS Office đi từ đây.</summary>
    Task<Result<ReturnBackRequestDto>> ApproveFaAsync(long id, string? comment);

    /// <summary>
    /// B3 — SCS WH quét Pallet ID giao hàng cho FA. Bước này chuyển serial sang
    /// <c>at_fa</c>; gọi được nhiều lần cho một đề nghị.
    /// </summary>
    Task<Result<BackDeliverResultDto>> DeliverAsync(
        long id, IEnumerable<string> lotNos, string? comment);

    Task<Result<ReturnBackRequestDto>> CancelAsync(long id, string? reason);
}
