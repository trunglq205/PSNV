﻿namespace SWMS_WebTool.Models.Filters
{
    public class SearchRuleKittingRequest
    {
        public string Category { get; set; }
        public string Kittingtype { get; set; }
    }
}
