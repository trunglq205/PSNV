import 'package:freezed_annotation/freezed_annotation.dart';
import 'base_request_model.dart';
part 'robot_outpallet_request_model.g.dart';

@JsonSerializable()
class RobotOutpalletRequestModel extends BaseRequestModel {
  RobotOutpalletRequestModel({
    required this.qrcode,
  });
  factory RobotOutpalletRequestModel.fromJson(Map<String, dynamic> json) =>
      _$RobotOutpalletRequestModelFromJson(json);
  final String qrcode;

  @override
  Map<String, dynamic> toJson() => _$RobotOutpalletRequestModelToJson(this);
}
