import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_entities.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_form.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_line.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_mapper.dart';
import 'package:swms_finish_goods/features/part_card/domain/entities/part_card_print_params.dart';
import 'package:swms_finish_goods/features/part_card/domain/repositories/part_card_repository.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_action_state.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_label_printer.dart';
import 'package:swms_finish_goods/features/part_card/presentation/providers/part_card_providers.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/part_card_entity.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/category_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'part_card_action_notifier.g.dart';

/// Sửa / Tách / Gộp tem ĐÃ IN. Mở từ Home sau khi quét tem + chọn action.
///
/// THỨ TỰ NGƯỢC màn in mới: LƯU SERVER TRƯỚC, IN SAU.
/// Tách / gộp huỷ tem cũ — nếu in trước rồi server từ chối (tem nguồn đã bị
/// tách / gộp ở máy khác, đã xoá…) thì nhãn mới ra giấy là nhãn ma. Lưu trước
/// thì server là chốt chặn; in hỏng giữa chừng chỉ cần in nốt
/// [PartCardActionState.pendingPrint], không đụng server nữa.
@riverpod
class PartCardActionNotifier extends _$PartCardActionNotifier
    with BaseNotifierMixin<PartCardActionState> {
  PartCardRepository get _repo => ref.read(partCardRepositoryProvider);

  List<Category> _categories = const [];

  /// Id server của tem đang sửa. Tra 1 lần rồi GIỮ: nếu PUT đã tới server mà
  /// mất response, payload trên server đã đổi → tra lại theo payload cũ sẽ
  /// không thấy và báo nhầm "không tìm thấy".
  int? _editServerId;

  /// Sửa mà tem cũ không còn: nhãn chờ user đồng ý lưu thành tem mới.
  List<PartCardPrintJob>? _orphanEdit;

  @override
  PartCardActionState build(PartCardAction action, String payload) =>
      PartCardActionState(action: action);

  // ── Khởi tạo ───────────────────────────────────────────────
  /// Đọc tem nguồn. `false` = tem không dùng được (lỗi đã báo) → page đóng.
  Future<bool> init() async {
    final next = await ref.read(appActionProvider.notifier).run(() async {
      _categories = await ref.readCategories();
      final src = _parse(payload);

      switch (action) {
        case PartCardAction.edit:
          final mode = PartCardMapper.modeOf(src.card);
          return state.copyWith(
            loading: false,
            mode: mode,
            form: PartCardMapper.formOf(src.card, mode),
            sources: [src],
          );

        case PartCardAction.split:
        // Chỉ tách tem 1 mã (1 hay nhiều thùng đều được). Tem đã vào OQC vẫn
        // tách được — server chép Status_OQC / LotName sang tem con.
          if (src.card.models.length > 1) {
            throw const PartCardSplitSingleOnlyException();
          }
          // Tách / gộp mặc định in tem NHIỀU MÃ (có ô PO, Box, Total).
          final form = PartCardMapper.formOf(src.card, PartCardMode.multi);
          return state.copyWith(
            loading: false,
            mode: PartCardMode.multi,
            form: form,
            sources: [src],
            splitParts: _defaultSplit(form),
          );

        case PartCardAction.merge:
          return state.copyWith(
            loading: false,
            mode: PartCardMode.multi,
            form: _mergeForm([src], null),
            sources: [src],
          );
      }
    });

    if (next == null) return false;
    state = next;
    return true;
  }

  PartCardSource _parse(String raw) {
    final p = raw.trim();
    final PartCard card;
    try {
      card = PartCard.fromPayload(p, _categories);
    } catch (_) {
      throw const PartCardInvalidException();
    }
    if (card.models.isEmpty || card.cardId.trim().isEmpty) {
      throw const PartCardInvalidException();
    }
    return PartCardSource(payload: p, card: card);
  }

  /// Gợi ý ban đầu: chia đôi. Tem 1 giữ PO của tem nguồn (nếu có), tem 2
  /// không PO. Chỉ là điểm xuất phát — user sửa tự do mọi field.
  ///
  /// - 1 thùng: chia đôi pcs, mỗi tem 1 thùng.
  /// - Nhiều thùng: chia đôi số thùng; pcs chia theo thùng nếu chia đều được
  ///   (vd 3 thùng 300 pcs → 2 thùng 200 + 1 thùng 100), không thì chia đôi pcs.
  List<PartCardForm> _defaultSplit(PartCardForm source) {
    final qty = source.totalPcs;
    final box = source.firstLine?.box ?? 1;

    var box1 = 1, box2 = 1;
    var qty1 = qty >= 2 ? qty - qty ~/ 2 : qty;
    if (box > 1) {
      box1 = box - box ~/ 2;
      box2 = box ~/ 2;
      if (qty % box == 0) qty1 = qty ~/ box * box1;
    }

    return [
      _childForm(source, qty: qty1, box: box1, keepPo: true),
      _childForm(source, qty: qty - qty1, box: box2),
    ];
  }

  /// Tem con dựng từ tem nguồn: chép Dim / Cate / MFD / Origin / OQC, đặt
  /// Box / Qty, Weight chia theo tỉ lệ pcs. Chỉ là GIÁ TRỊ BAN ĐẦU.
  PartCardForm _childForm(
      PartCardForm source, {
        required int qty,
        required int box,
        bool keepPo = false,
      }) {
    final line = source.lines.first.copyWith(
      box: box < 1 ? 1 : box,
      quantity: qty < 0 ? 0 : qty,
    );
    return source.updateLineAt(0, line).copyWith(
      weight: _scaledWeight(source, qty),
      psnvPo: keepPo ? source.psnvPo : '',
      cusPo: keepPo ? source.cusPo : '',
      mode: PartCardMode.multi,
    );
  }

  /// Cân nặng theo tỉ lệ pcs, làm tròn 3 số lẻ (đơn vị in trên tem là kg).
  /// Qty = 0 → Weight = 0 (ô báo thiếu, bắt user nhập).
  static double _scaledWeight(PartCardForm f, int qty) {
    if (qty <= 0) return 0;
    final total = f.totalPcs;
    if (total <= 0 || f.weight <= 0) return f.weight;
    final w = double.parse((f.weight * qty / total).toStringAsFixed(3));
    return w > 0 ? w : 0.001;
  }

  // ── Quét trên màn ──────────────────────────────────────────
  Future<void> onScan(String raw) async {
    if (state.loading || state.saved) return;
    if (state.step != PartCardActionStep.setup) return;

    final isCard = isPartCardPayload(raw);
    switch (action) {
      case PartCardAction.merge:
        if (isCard) {
          await addSource(raw);
        } else {
          await ref.read(appActionProvider.notifier).run<void>(() async {
            throw const PartCardNotACardException();
          });
        }
      case PartCardAction.edit:
      // Đang sửa 1 tem: quét model = thêm dòng (tem nhiều mã); quét tem
      // khác thì bỏ qua — muốn sửa tem khác thì quay về Home.
        if (!isCard && state.mode.isMulti) await addLine(raw);
      case PartCardAction.split:
        break;
    }
  }

  // ── Bước setup: sửa ────────────────────────────────────────
  void onFormChanged(PartCardForm form) {
    if (state.saved) return;
    state = state.copyWith(
      form: form,
      mode: action == PartCardAction.edit ? _editModeFor(form) : state.mode,
    );
  }

  /// Giống màn in mới: Cate gom mã ⇒ tự bật nhiều mã (một chiều).
  PartCardMode _editModeFor(PartCardForm form) =>
      partCardMultiCategories.contains(form.category?.value)
          ? PartCardMode.multi
          : state.mode;

  /// Chỉ màn Sửa. Nhiều → 1 mã giữ dòng đầu, `box = 1`; UI đã hỏi xác nhận.
  void setMode(PartCardMode mode) {
    if (action != PartCardAction.edit || state.saved) return;
    if (state.mode == mode) return;

    var form = state.form?.copyWith(mode: mode);
    if (mode.isSingle && form != null && form.lines.isNotEmpty) {
      form = form.singleLine(form.lines.first.copyWith(box: 1));
    }
    state = state.copyWith(mode: mode, form: form);
  }

  /// Màn Sửa, tem nhiều mã: thêm 1 mã (trùng thì +1 thùng).
  Future<void> addLine(String raw) async {
    final form = state.form;
    if (form == null || state.saved || state.mode.isSingle) return;

    final code = modelFromScan(raw);
    if (code == null || code.isEmpty) return;

    if (form.hasModel(code)) {
      state = state.copyWith(form: form.bumpBox(code));
      return;
    }
    if (!form.canAddLine) return;

    state = state.copyWith(
      form: form.addLine(
        PartCardLine.empty(code).copyWith(origin: form.lines.last.origin),
      ),
    );
  }

  // ── Bước setup: gộp ────────────────────────────────────────
  Future<void> addSource(String raw) async {
    if (action != PartCardAction.merge || state.saved) return;

    final next = await ref.read(appActionProvider.notifier).run(() async {
      final src = _parse(raw);
      if (state.sources.any((s) => s.cardId == src.cardId)) {
        throw PartCardMergeDuplicateException(src.cardId);
      }
      final sources = [...state.sources, src];
      return state.copyWith(
        sources: sources,
        form: _mergeForm(sources, state.form),
      );
    });
    if (next != null) state = next;
  }

  void removeSource(int index) {
    if (action != PartCardAction.merge || state.saved) return;
    if (state.sources.length <= 1) return;
    if (index < 0 || index >= state.sources.length) return;

    final sources = [...state.sources]..removeAt(index);
    // Bớt nguồn thì không thể vượt số dòng / xung đột qty → không ném.
    state = state.copyWith(
      sources: sources,
      form: _mergeForm(sources, state.form),
    );
  }

  /// Dựng phiếu gộp. Card-level (Cate / MFD / Dim / Weight / PO) giữ theo
  /// [base] nếu có (user đã sửa), không thì lấy tem đầu.
  ///
  /// Dòng mã dựng lại TỪ ĐẦU theo [sources] — sửa Origin / OQC trên dòng sẽ
  /// mất khi thêm / bớt nguồn. Trùng mã → CỘNG cả Box lẫn Qty vào 1 dòng
  /// (Qty trên dòng = tổng pcs của mã đó trên tem).
  PartCardForm _mergeForm(List<PartCardSource> sources, PartCardForm? base) {
    final form =
        base ?? PartCardMapper.formOf(sources.first.card, PartCardMode.multi);

    final lines = <PartCardLine>[];
    for (final s in sources) {
      for (final m in s.card.models) {
        final line = PartCardMapper.lineOf(m);
        final i = lines.indexWhere((l) => l.model == line.model);
        if (i >= 0) {
          lines[i] = lines[i].copyWith(
            box: lines[i].box + line.box,
            quantity: lines[i].quantity + line.quantity,
          );
        } else {
          if (lines.length >= PartCardForm.maxLines) {
            throw const PartCardMergeTooManyException(PartCardForm.maxLines);
          }
          lines.add(line);
        }
      }
    }
    return form.copyWith(lines: lines, mode: PartCardMode.multi);
  }

  // ── Bước setup: tách ───────────────────────────────────────
  static const int maxSplitParts = 99;

  /// Ghi đè tem con [index] bằng phiếu user vừa sửa. Không ràng buộc gì ở
  /// đây — tổng Qty kiểm ở [PartCardActionState.canSubmit].
  void updateSplitPart(int index, PartCardForm part) {
    if (state.saved || index < 0 || index >= state.splitParts.length) return;
    state = state.copyWith(
      splitParts: [...state.splitParts]
        ..[index] = part.copyWith(mode: PartCardMode.multi),
    );
  }

  /// Thêm 1 tem con từ tem nguồn, Qty = phần còn lại chưa chia, chưa có PO.
  void addSplitPart() {
    final source = state.form;
    if (source == null ||
        state.saved ||
        state.splitParts.length >= maxSplitParts) {
      return;
    }
    final rest = state.splitRemaining;
    final restBox = state.sourceBox - state.splitBoxTotal;
    state = state.copyWith(
      splitParts: [
        ...state.splitParts,
        _childForm(
          source,
          qty: rest > 0 ? rest : 0,
          box: restBox > 1 ? restBox : 1,
        ),
      ],
    );
  }

  void removeSplitPart(int index) {
    if (state.saved || state.splitParts.length <= 2) return;
    if (index < 0 || index >= state.splitParts.length) return;
    state = state.copyWith(
      splitParts: [...state.splitParts]..removeAt(index),
    );
  }

  // ── Điều hướng bước ────────────────────────────────────────
  void toPrint() {
    if (!state.canSubmit) return;
    state = state.copyWith(step: PartCardActionStep.print);
  }

  /// Đã lưu server thì không quay lại sửa được nữa.
  void backToSetup() {
    if (state.saved) return;
    state = state.copyWith(step: PartCardActionStep.setup);
  }

  // ── Lưu + in ───────────────────────────────────────────────
  /// Lần đầu: lưu server rồi in. Lần sau (in lỗi giữa chừng): chỉ in nốt.
  ///
  /// Trả `true` khi SỬA mà tem cũ không còn trên server → page hỏi user rồi
  /// gọi [saveEditAsNew]. Mọi trường hợp khác trả `false`.
  Future<bool> submit() async {
    if (!state.saved) {
      if (!state.canSubmit) return false;

      final jobs = _buildJobs();
      final ok = await ref.read(appActionProvider.notifier).run(() => _save(jobs));
      if (ok == null) return false; // lỗi (đã báo) → giữ nguyên để bấm lại
      if (!ok) {
        _orphanEdit = jobs;
        return true;
      }
      state = state.copyWith(saved: true, pendingPrint: jobs);
    }

    await _printPending();
    return false;
  }

  /// Sửa mà tem cũ đã bị xoá, user đồng ý: lưu nhãn đó (GIỮ Card_ID cũ)
  /// thành bản ghi mới rồi in.
  Future<void> saveEditAsNew() async {
    final jobs = _orphanEdit;
    if (jobs == null || state.saved) return;

    final ok = await ref.read(appActionProvider.notifier).run(
          () => _repo.savePrintHistory([for (final j in jobs) j.toParams()]),
    );
    if (ok == null) return;

    _orphanEdit = null;
    state = state.copyWith(saved: true, pendingPrint: jobs);
    await _printPending();
  }

  /// edit: GIỮ Card_ID cũ (in lại đúng tem đó). split / merge: Card_ID mới.
  List<PartCardPrintJob> _buildJobs() => [
    for (final form in state.printForms)
      PartCardPrintJob(
        form: form,
        cardId: action == PartCardAction.edit
            ? state.sources.first.cardId
            : PartCardId.generate(),
      ),
  ];

  /// `false` = sửa mà tem cũ không còn (không tra ra id, hoặc PUT 404).
  Future<bool> _save(List<PartCardPrintJob> jobs) async {
    final params = [for (final j in jobs) j.toParams()];

    switch (action) {
      case PartCardAction.edit:
        final id = _editServerId ??= await _repo.findIdByPayload(
          state.sources.first.payload,
        );
        if (id == null) return false;
        return _repo.updatePrintHistory(id, params.first);

      case PartCardAction.split:
        await _repo.splitPrintHistory(state.sources.first.payload, params);
        return true;

      case PartCardAction.merge:
        await _repo.mergePrintHistory(
          [for (final s in state.sources) s.payload],
          params.first,
        );
        return true;
    }
  }

  /// In [PartCardActionState.pendingPrint]; nhãn nào máy xác nhận thì bỏ khỏi
  /// danh sách — kể cả khi lỗi giữa chừng — để lần bấm sau chỉ in phần thiếu.
  Future<void> _printPending() async {
    final jobs = state.pendingPrint;
    if (jobs.isEmpty) return;

    final printed = <int>{};
    await ref.read(appActionProvider.notifier).run<void>(() async {
      try {
        await printPartCardJobs(ref, jobs, onPrinted: printed.add);
      } finally {
        state = state.copyWith(
          pendingPrint: [
            for (var i = 0; i < jobs.length; i++)
              if (!printed.contains(i)) jobs[i],
          ],
        );
      }
    });
  }
}