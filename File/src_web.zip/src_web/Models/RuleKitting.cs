﻿namespace SWMS_WebTool.Models
{
    public class RuleKitting : AuditableEntity
    {
        public string Category { get; set; }
        public string KittingType { get; set; }
        public int Priority { get; set; }
    }
}
