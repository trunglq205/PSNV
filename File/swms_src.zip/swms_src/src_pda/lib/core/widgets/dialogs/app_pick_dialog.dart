import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';

/// Dialog chọn 1 giá trị trong danh sách ngắn, cố định (Category, Origin…).
/// Chạm 1 dòng là chọn xong. Trả về `null` nếu huỷ.
///
/// ```dart
/// final origin = await showPickDialog<String>(
///   context,
///   title: 'Origin',
///   items: kOrigins,
///   labelOf: (o) => o,
///   selected: form.origin,
/// );
/// ```
///
/// Danh sách dài hoặc cần tìm kiếm thì làm màn riêng, đừng nhồi vào đây.
Future<T?> showPickDialog<T>(
    BuildContext context, {
      required String title,
      required List<T> items,
      required String Function(T item) labelOf,
      T? selected,
    }) {
  return showDialog<T>(
    context: context,
    builder: (_) => _PickDialog<T>(
      title: title,
      items: items,
      labelOf: labelOf,
      selected: selected,
    ),
  );
}

class _PickDialog<T> extends StatelessWidget {
  const _PickDialog({
    required this.title,
    required this.items,
    required this.labelOf,
    this.selected,
  });

  final String title;
  final List<T> items;
  final String Function(T item) labelOf;
  final T? selected;

  @override
  Widget build(BuildContext context) {
    return AppDialog(
      title: title,
      // Chỉ có nút Huỷ: chạm một dòng là đã chọn xong, không cần bước xác nhận.
      actions: [AppDialogAction.cancel(context)],
      child: ListView.separated(
        shrinkWrap: true,
        itemCount: items.length,
        separatorBuilder: (_, _) => const SizedBox(height: 4),
        itemBuilder: (_, i) => _PickTile(
          label: labelOf(items[i]),
          selected: items[i] == selected,
          onTap: () => Navigator.pop(context, items[i]),
        ),
      ),
    );
  }
}

class _PickTile extends StatelessWidget {
  const _PickTile({
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Material(
      color: selected ? swms.card2 : Colors.transparent,
      borderRadius: BorderRadius.circular(AppDimens.rInput),
      child: InkWell(
        borderRadius: BorderRadius.circular(AppDimens.rInput),
        onTap: onTap,
        child: Container(
          constraints: const BoxConstraints(minHeight: AppDimens.hitMd),
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
          child: Row(
            children: [
              Expanded(
                child: Text(
                  label,
                  style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                ),
              ),
              if (selected)
                Icon(Icons.check_rounded, size: 18, color: swms.success),
            ],
          ),
        ),
      ),
    );
  }
}