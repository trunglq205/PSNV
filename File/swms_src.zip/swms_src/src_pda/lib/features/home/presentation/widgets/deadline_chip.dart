import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';

/// Chip hạn chót — đỏ khi gấp, xám khi thường.
class DeadlineChip extends StatelessWidget {
  final String text;
  final bool urgent;

  const DeadlineChip({super.key, required this.text, required this.urgent});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final fg = urgent ? swms.danger : swms.text2;
    final bg = urgent
        ? swms.dangerBg
        : Theme.of(context).scaffoldBackgroundColor;
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.schedule, size: 11, color: fg),
          const SizedBox(width: 3),
          Text(
            text,
            maxLines: 1,
            softWrap: false,
            overflow: TextOverflow.fade,
            style: AppTextStyles.caption.copyWith(
              color: fg,
              fontSize: 10,
              fontWeight: FontWeight.w700,
            ),
          ),
        ],
      ),
    );
  }
}
