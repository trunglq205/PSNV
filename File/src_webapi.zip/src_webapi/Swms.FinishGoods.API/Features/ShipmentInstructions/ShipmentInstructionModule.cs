using Swms.FinishGoods.API.Features.ShipmentInstructions.Business;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions;

public static class ShipmentInstructionModule
{
    public static IServiceCollection AddShipmentInstructionFeature(this IServiceCollection services)
    {
        services.AddScoped<IShipmentInstructionService, ShipmentInstructionService>();
        services.AddScoped<IShipmentInstructionRepository, ShipmentInstructionRepository>();
        // 1 request SAP = 1 instance: service ghi kết quả, SapInboundLogFilter đọc để lưu log
        services.AddScoped<SapInboundAudit>();
        // So SI với HD soft — cần AddHdSoftFeature() đã đăng ký IHdSoftService
        services.AddScoped<ISiHdSoftCompareService, SiHdSoftCompareService>();
        return services;
    }
}
