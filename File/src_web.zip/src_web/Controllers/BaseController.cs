﻿using System.Reflection;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using SWMS_WebTool.Models;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils.Extensions;
using SWMS_WebTool.ViewModels;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace SWMS_WebTool.Controllers
{
    public abstract class BaseController : Controller
    {
        public byte[]? Token = null;
        public bool IsAuthenticated => User.Identity!.IsAuthenticated;
        // i18n: truy cập localization service trong mọi controller con
        protected ILocalizationService _loc =>
            HttpContext.RequestServices.GetRequiredService<ILocalizationService>();
        public override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            if (string.IsNullOrEmpty(HttpContext.Session.GetString("SWMSToken")))
            {
                HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            }

            // Lấy danh sách WebRole từ session
            var isAdmin = HttpContext.Session.GetObject<string>("IsAdmin") == "Admin";
            var webRoles = HttpContext.Session.GetObject<List<WebRole>>("WebRoles") ?? new List<WebRole>();
            var receivingPermisstion = isAdmin || webRoles.Contains(WebRole.Receiving);
            var storagePermisstion = isAdmin || webRoles.Contains(WebRole.Storage);
            var kittingPermisstion = isAdmin || webRoles.Contains(WebRole.Kitting);
            var inventoryPermisstion = isAdmin || webRoles.Contains(WebRole.Inventory);
            var managermentPermisstion = isAdmin || webRoles.Contains(WebRole.Managerment);
            var ortherSectionPermisstion = isAdmin || webRoles.Contains(WebRole.OrtherSection);

            // Ngoài ra, bạn cũng có thể đặt ViewBag nếu cần
            ViewBag.IsAdmin = isAdmin;
            ViewBag.HasReceivingPermisstion = receivingPermisstion;
            ViewBag.HasStoragePermisstion = storagePermisstion;
            ViewBag.HasKittingPermisstion = kittingPermisstion;
            ViewBag.HasInventoryPermisstion = inventoryPermisstion;
            ViewBag.HasManagermentPermisstion = managermentPermisstion;
            ViewBag.HasOtherSectionPermisstion = ortherSectionPermisstion;
            base.OnActionExecuting(filterContext);
        }
    }
}

