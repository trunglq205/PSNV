import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/router/router_provider.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/home/domain/scan_result.dart';
import 'package:swms_finish_goods/features/home/presentation/dialog/part_card_action_sheet.dart';
import 'package:swms_finish_goods/features/home/presentation/dialog/scan_code_guide_sheet.dart';
import 'package:swms_finish_goods/features/home/presentation/dialog/scan_result_sheet.dart';
import 'package:swms_finish_goods/features/home/presentation/providers/home_notifier.dart';
import 'package:swms_finish_goods/features/home/presentation/providers/home_providers.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/group_section.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/permissions_shimmer.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/pin_hint.dart';
import 'package:swms_finish_goods/features/home/presentation/widgets/scan_hero.dart';
import 'package:swms_finish_goods/gen/assets.gen.dart';
import 'package:swms_finish_goods/shared/presentation/pda_scan_route_aware.dart';

// ─────────────────────────────────────────────────────────────
//  Màn hình Home SWMS PDA
//  - Assignments load remote (AsyncValue) · cụm tĩnh · ghim lưu local.
//  - Quét mã ở Home → GET /api/scan/resolve → mở đúng màn theo loại mã.
//  - Tem Part Card đã in → server tra wms.part_cards theo payload, trả kèm
//    cờ được Sửa / Tách / Gộp → sheet chọn thao tác.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen>
    with PdaScanRouteAware {
  /// Thao tác trên tem đã in dùng chung quyền với màn in Part Card.
  static const _partCardPermission = 'pda_receiving.receive';

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final routeObserver = ref.watch(routeObserverProvider);
    routeObserver.subscribe(this, ModalRoute.of(context)! as ModalRoute<void>);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(homeProvider.notifier).initData();
    });
  }

  @override
  void onScan(String data) {
    if (!mounted) return;
    Navigator.of(
      context,
      rootNavigator: true,
    ).popUntil((route) => route is! PopupRoute);
    _onBarcodeScanned(data);
  }

  // Sheet hướng dẫn quét: quét trong sheet → sheet đóng, trả mã về đây
  // để đi chung đường phân loại + điều hướng với quét ngoài Home.
  Future<void> _openScanGuide() async {
    final code = await showScanCodeGuideSheet(context);
    if (code == null || !mounted) return;
    await _onBarcodeScanned(code);
  }

  // Scan barcode: gọi API phân loại rồi mở đúng màn theo loại mã.
  Future<void> _onBarcodeScanned(String barcode) async {
    final code = barcode.trim();
    if (code.isEmpty) return;

    // try CHỈ bọc lời gọi API phân loại. Lỗi điều hướng (route chưa đăng ký,
    // sai tham số…) KHÔNG được nuốt thành "mã không nhận dạng" — phải lộ ra
    // log để sửa, không thì user bấm Sửa / Tách / Gộp xong lại thấy sheet unknown.
    final ScanResult result;
    try {
      result = await ref.read(homeRepositoryProvider).resolveScan(code);
    } catch (e, st) {
      debugPrint('resolveScan failed: $e\n$st');
      if (!mounted) return;
      await showUnknownScanResultSheet(context, rawValue: barcode);
      return;
    }
    if (!mounted) return;

    switch (result.type) {
      case ScanType.pallet:
      // Pallet ID = lot_no → mở màn Pallet Detail.
        await context.router.pushPath('/pallet/${result.code}');
      case ScanType.model:
        await context.router.pushPath('/model/${result.id}');
      case ScanType.partCard:
        await _onPartCardScanned(result);
      case ScanType.box:
      case ScanType.serial:
      case ScanType.recvLocation:
      case ScanType.storageLocation:
      // Các loại này chưa có màn chi tiết — tạm hiện sheet thô.
      // (sẽ nối lần lượt khi triển khai từng nhóm)
        await showUnknownScanResultSheet(context, rawValue: barcode);
      case ScanType.notFound:
        await showUnknownScanResultSheet(context, rawValue: barcode);
    }
  }

  /// Tem Part Card đã in → chọn action → màn Sửa / Tách / Gộp.
  ///
  /// `result.code` = payload gốc trong DB — dùng làm khoá cho sửa / tách / gộp.
  Future<void> _onPartCardScanned(ScanResult result) async {
    final info = result.partCard;
    if (info == null) {
      await showUnknownScanResultSheet(context, rawValue: result.code);
      return;
    }

    if (!ref.read(homeProvider).can(_partCardPermission)) {
      AppToastHelper.toastInfo(
        context,
        LocaleKeys.part_card_actions_no_permission.tr(),
      );
      return;
    }

    final choice = await showPartCardActionSheet(context, info: info);
    if (choice == null || !mounted) return;

    final action = choice.action;
    await context.router.push(
      action == null
      // Nhân bản = in mới, form điền sẵn từ tem vừa quét.
          ? PartCardRoute(clonePayload: result.code)
          : PartCardActionRoute(action: action, payload: result.code),
    );
  }

  @override
  Widget build(BuildContext context) {
    final state = ref.watch(homeProvider);
    final notifier = ref.read(homeProvider.notifier);
    final display = state.displayGroups;

    return PopScope(
      canPop: false,
      child: Scaffold(
        appBar: AppTopBar(
          title: state.fullName,
          subtitle: 'ID: ${state.employeeCode}',
          leading: Padding(
            padding: const EdgeInsets.only(left: AppDimens.md),
            child: Assets.images.logo.image(width: 32),
          ),
          actions: [
            IconButton(
              onPressed: () => context.pushRoute(const SettingsRoute()),
              icon: const Icon(Icons.settings_outlined),
            ),
          ],
        ),
        body: RefreshIndicator(
          onRefresh: notifier.refreshAssignments,
          child: ListView(
            padding: const EdgeInsets.all(AppDimens.md),
            children: [
              ScanHero(onTap: _openScanGuide),
              const SizedBox(height: AppDimens.sm),
              // state.assignments.when(
              //   loading: () => const AssignmentsShimmer(),
              //   error: (e, _) => AppErrorView.widget(
              //     message: const ErrorHandler().getMessage(e),
              //     onRetry: notifier.refreshAssignments,
              //   ),
              //   data: (items) => items.isEmpty
              //       ? const SizedBox.shrink()
              //       : AssignmentsSection(
              //           items: items,
              //           onTapItem: (a) {
              //             // TODO: điều hướng theo a.id
              //           },
              //         ),
              // ),
              state.permissions.when(
                loading: () => const PermissionsShimmer(),
                error: (e, _) => AppErrorView.widget(
                  message: ref.read(errorHandlerProvider).getMessage(e),
                  onRetry: notifier.refreshPermissions,
                ),
                data: (_) => Column(
                  children: [
                    const PinHint(),
                    for (int i = 0; i < display.length; i++) ...[
                      GroupSection(
                        index: display[i].order,
                        group: display[i].group,
                        pinned: state.isPinned(display[i].group.key),
                        onTogglePin: () =>
                            notifier.togglePin(display[i].group.key),
                        onTapItem: (item) {
                          final routeName = item.routeName;
                          if (routeName != null) {
                            context.router.pushPath(routeName);
                          }
                        },
                      ),
                      if (i != display.length - 1)
                        const SizedBox(height: AppDimens.sm),
                    ],
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}