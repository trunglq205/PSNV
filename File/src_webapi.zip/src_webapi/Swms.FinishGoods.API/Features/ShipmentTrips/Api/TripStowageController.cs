using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

/// <summary>
/// PDA làm theo Stowage Plan của chuyến (plan do văn phòng lập ở màn Stowage Plan trên Web):
///   GET    {id}/stowage                          sơ đồ cọc trong cont + tình trạng ghép / xếp   Trip.View
///   POST   {id}/stowage/columns/{code}/stack     ghép Pallet List thật vào cọc (Pallet Stack)   Trip.Stow
///   POST   {id}/stowage/columns/{code}/place     xếp cọc vào cont (Stowage)                     Trip.Stow
///   DELETE {id}/stowage/columns/{code}           gỡ: đã xếp -> gỡ xếp; chưa xếp -> bỏ ghép      Trip.Stow
/// Mọi lệnh ghi trả lại cả sơ đồ.
/// </summary>
[ApiController]
[Route("api/shipment-trips")]
public class TripStowageController : ControllerBase
{
    private readonly ITripStowageService _service;
    public TripStowageController(ITripStowageService service) => _service = service;

    [HttpGet("{id:long}/stowage")]
    [RequirePermission<Perms.Outbound.Trip.View>]
    public async Task<ActionResult<TripStowageResponse>> Get(long id)
        => Ok(await _service.GetAsync(id));

    [HttpPost("{id:long}/stowage/columns/{code}/stack")]
    [RequirePermission<Perms.Outbound.Trip.Stow>]
    public async Task<ActionResult<TripStowageResponse>> Stack(long id, string code, TripStackRequest request)
        => Ok(await _service.StackAsync(id, code, request));

    [HttpPost("{id:long}/stowage/columns/{code}/place")]
    [RequirePermission<Perms.Outbound.Trip.Stow>]
    public async Task<ActionResult<TripStowageResponse>> Place(long id, string code, TripPlaceRequest request)
        => Ok(await _service.PlaceAsync(id, code, request));

    [HttpDelete("{id:long}/stowage/columns/{code}")]
    [RequirePermission<Perms.Outbound.Trip.Stow>]
    public async Task<ActionResult<TripStowageResponse>> Clear(long id, string code)
        => Ok(await _service.ClearAsync(id, code));
}
