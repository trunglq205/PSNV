﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class AbnormalReportViewModel : TableViewModel<AbnormalReport, AbnormalReportFilter>
    {
        public IEnumerable<AbnormalReport> Items { get; set; } = new List<AbnormalReport>();
        public AbnormalReportFilter Filter { get; set; } = new AbnormalReportFilter();
        public int PageNumber { get; set; } = 1;
        public int PageSize { get; set; } = 20;
        public int TotalPage { get; set; }
        public int Total { get; set; }
        public string UserSection { get; set; }

        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, AbnormalReportFilter? filter = null)
        {
            return new
            {
                userSection = UserSection,
                pageNumber = pageNumber ?? PageNumber,
                pageSize = pageSize ?? PageSize.ToString(),
                ManagementNumber = Filter.ManagementNumber,
                PartNumber = Filter.PartNumber,
                Supplier = Filter.Supplier,
                VendorCodes = Filter.VendorCodes,
                DiscoveryDate = Filter.DiscoveryDate?.ToString("yyyy-MM-dd"),
                ReportStatus = Filter.ReportStatus,
                IQCStatus = (byte)Filter.IQCStatus,
                PUSStatus = (byte)Filter.PUSStatus,
                MCSStatus = (byte)Filter.MCSStatus,
            };
        }
    }
}
