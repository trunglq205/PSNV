/* =========================================================
   CHỦ ĐỀ HALLOWEEN — hiệu ứng nền cho Login + Layout
   Drop-in: wwwroot/js/halloween.js  (đặt sau bootstrap.bundle)
   - Đàn dơi thỉnh thoảng bay ngang + đom đóm lập lòe (canvas, nằm sau nội dung)
   - Sương mù mỏng trôi ở đáy màn hình
   - Băng chúc mừng + đếm ngược tới 31/10 (chỉ trang có <main>)
   - Đánh dấu menu đang mở theo URL
   - Dơi/kẹo bung ra khi bấm nút chính
   ========================================================= */
(function () {
    "use strict";

    var REDUCED = window.matchMedia && window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    function el(tag, cls, css) {
        var n = document.createElement(tag);
        if (cls) n.className = cls;
        if (css) n.setAttribute("style", css);
        return n;
    }

    /* ---------- 1. Khung trang có menu cố định ---------- */
    function buildFrame() {
        if (document.querySelector(".navbar.fixed-top")) document.body.classList.add("hw-framed");
    }

    /* ---------- 2. Menu đang mở ---------- */
    function markActiveNav() {
        // Chuẩn hoá: bỏ "/" cuối, bỏ "/index", bỏ "/home" (trang chủ) — chạy được cả khi host trong virtual directory IIS
        function norm(p) {
            p = (p || "").split("?")[0].split("#")[0].toLowerCase().replace(/\/+$/, "");
            p = p.replace(/\/index$/, "").replace(/\/home$/, "");
            return p || "/";
        }
        var path = norm(location.pathname);
        document.querySelectorAll(".nav-group-item[href]").forEach(function (a) {
            if (norm(a.getAttribute("href")) === path) a.classList.add("active");
        });
    }

    /* ---------- 3. Băng chúc mừng + đếm ngược Halloween ---------- */
    function buildBanner() {
        var main = document.querySelector("main");
        if (!main || document.querySelector(".hw-banner")) return; // trang Login không có <main>

        var now = new Date();
        var today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        var hw = new Date(now.getFullYear(), 9, 31);
        if (today > hw) hw = new Date(now.getFullYear() + 1, 9, 31);
        var days = Math.round((hw - today) / 86400000);
        var chip = days === 0 ? "Hôm nay là Halloween! 🎃" : "Còn " + days + " ngày đến Halloween";

        var msg = "Happy Halloween! Chúc cả team nhiều kẹo, ít bug — số liệu không ma ám, báo cáo không hù dọa, deadline không đuổi theo sau lưng! 👻";

        var b = el("div", "hw-banner");
        var bells = el("div", "hw-banner-bells");
        bells.textContent = "🎃";
        var title = el("div", "hw-banner-title");
        title.textContent = "Happy Halloween";
        var mq = el("div", "hw-marquee");
        var inner = el("div");
        var msg2 = boardUrl() ? "🏆 Đua top BXH ném ma mùa Halloween — Top 1 nhận " + prize() + "! Bấm nút 🏆 để xem thể lệ." : "";
        for (var i = 0; i < 2; i++) {
            var sp = el("span");
            sp.textContent = msg;
            inner.appendChild(sp);
            if (msg2) {
                var sp2 = el("span", "hw-marquee-prize");
                sp2.textContent = msg2;
                inner.appendChild(sp2);
            }
        }
        mq.appendChild(inner);
        var c = el("div", "hw-chip");
        c.textContent = chip;

        b.appendChild(bells);
        b.appendChild(title);
        b.appendChild(mq);
        b.appendChild(c);
        if (boardUrl()) {
            var bb = el("button", "hw-board-btn");
            bb.type = "button";
            bb.innerHTML = "🏆 BXH ném ma";
            bb.title = "Bảng xếp hạng ném ma mùa Halloween";
            bb.addEventListener("click", function () { openBoard(); });
            var pb = el("button", "hw-play-btn");
            pb.type = "button";
            pb.innerHTML = "👻 Chơi ném ma";
            pb.title = "Mở lại màn ném ma để chơi tiếp (không cần đăng nhập lại)";
            pb.addEventListener("click", playAgain);
            b.appendChild(pb);
            b.appendChild(bb);
        }
        main.insertBefore(b, main.firstChild);
    }

    /* ---------- 3b. Bảng xếp hạng ném ma (GameScoreController.Leaderboard) ---------- */
    function boardUrl() {
        var m = document.querySelector('meta[name="game-board-url"]');
        return m ? m.getAttribute("content") : null;
    }

    function prize() {
        var m = document.querySelector('meta[name="game-prize"]');
        return (m && m.getAttribute("content")) || "200.000đ";
    }

    // mở lại màn ném ma: tải lại trang hiện tại kèm ?themegate=1 (server render màn chơi)
    function playAgain() {
        var u = new URL(location.href);
        u.searchParams.set("themegate", "1");
        location.href = u.pathname + u.search + u.hash;
    }

    function esc(t) {
        return String(t == null ? "" : t).replace(/[&<>"']/g, function (ch) {
            return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[ch];
        });
    }

    function secs(ms) { return (ms / 1000).toFixed(2) + "s"; }

    var boardEl = null;

    function openBoard() {
        var url = boardUrl();
        if (!url) return;
        if (!boardEl) {
            boardEl = el("div", "hw-board-overlay");
            boardEl.innerHTML =
                '<div class="hw-board" role="dialog" aria-modal="true" aria-labelledby="hwBoardTitle">' +
                '  <div class="hw-board-head">' +
                '    <h3 id="hwBoardTitle">🏆 Bảng xếp hạng ném ma</h3>' +
                '    <div class="hw-board-head-actions">' +
                '      <button type="button" class="hw-rules-btn hw-play-in-board">👻 Chơi ngay</button>' +
                '      <button type="button" class="hw-rules-btn">📜 Thể lệ</button>' +
                '      <button type="button" class="hw-board-close" aria-label="Đóng">×</button>' +
                '    </div>' +
                '  </div>' +
                '  <div class="hw-board-prize">🎁 Giải thưởng: <b>Top 1</b> khi chốt BXH nhận <b>' + esc(prize()) + '</b></div>' +
                '  <div class="hw-board-sub"></div>' +
                '  <div class="hw-board-body"></div>' +
                '  <div class="hw-board-note">Xếp theo <b>thời gian hoàn thành nhanh nhất</b> (từ quả ném đầu tiên tới lúc trúng đủ 3 con ma).<br />' +
                '  Mỗi người lấy lượt tốt nhất · bằng thời gian thì ít lần ném hơn xếp trên · lượt dùng phím <b>Space</b> (tự ngắm) không được tính.</div>' +
                '</div>';
            document.body.appendChild(boardEl);
            boardEl.addEventListener("click", function (e) { if (e.target === boardEl) closeBoard(); });
            boardEl.querySelector(".hw-board-close").addEventListener("click", closeBoard);
            boardEl.querySelector(".hw-rules-btn:not(.hw-play-in-board)").addEventListener("click", function () { openRules(); });
            boardEl.querySelector(".hw-play-in-board").addEventListener("click", playAgain);
            document.addEventListener("keydown", function (e) {
                if (e.key === "Escape" && boardEl && boardEl.classList.contains("open")
                    && !(rulesEl && rulesEl.classList.contains("open"))) closeBoard();
            });
        }
        boardEl.classList.add("open");
        loadBoard();
        boardEl.querySelector(".hw-board-close").focus();
    }

    function closeBoard() { if (boardEl) boardEl.classList.remove("open"); }

    function loadBoard() {
        var body = boardEl.querySelector(".hw-board-body");
        var sub = boardEl.querySelector(".hw-board-sub");
        body.innerHTML = '<div class="hw-board-empty">Đang tải… 👻</div>';
        sub.textContent = "";
        var url = boardUrl();
        url += (url.indexOf("?") < 0 ? "?" : "&") + "theme=halloween&top=20";
        fetch(url, { credentials: "same-origin", headers: { "Accept": "application/json" } })
            .then(function (r) { if (!r.ok) throw new Error(r.status); return r.json(); })
            .then(function (d) { renderBoard(d); })
            .catch(function () { body.innerHTML = '<div class="hw-board-empty">Không tải được bảng xếp hạng. Thử lại sau nhé.</div>'; });
    }

    function renderBoard(d) {
        season = { from: d.from, to: d.to, prize: d.prize || prize(), closed: d.closed };
        var body = boardEl.querySelector(".hw-board-body");
        var sub = boardEl.querySelector(".hw-board-sub");
        sub.innerHTML = "Mùa Halloween " + d.from + " – " + d.to + " · " + d.total + " người chơi · " +
            (d.closed ? '<span class="hw-closed">🔒 Đã chốt BXH</span>'
                      : !d.started ? "chưa bắt đầu"
                      : '<span class="hw-left">còn ' + d.daysLeft + " ngày</span>");
        var rows = d.rows || [];
        if (!rows.length) {
            body.innerHTML = '<div class="hw-board-empty">Chưa ai lên bảng.' +
                "<br />Bấm 👻 Chơi ném ma để làm người đầu tiên! 🎃</div>";
            return;
        }
        var myName = d.me ? d.me.username : null;
        var medal = ["🥇", "🥈", "🥉"];
        function row(r) {
            return '<tr class="' + (r.username === myName ? "me" : "") + (r.rank <= 3 ? " top" : "") + '">' +
                '<td class="rk">' + (medal[r.rank - 1] || "#" + r.rank) + "</td>" +
                '<td class="nm">' + esc(r.fullName) + (r.username === myName ? ' <span class="you">bạn</span>' : "") + "</td>" +
                '<td class="num">' + secs(r.durationMs) + "</td>" +
                '<td class="num">' + r.accuracy + "%</td></tr>";
        }
        var html = '<table><thead><tr><th>Hạng</th><th>Người chơi</th><th>Thời gian</th><th>Chính xác</th></tr></thead><tbody>';
        rows.forEach(function (r) { html += row(r); });
        if (d.me && !rows.some(function (r) { return r.username === myName; })) {
            html += '<tr class="gap"><td colspan="4">…</td></tr>' + row(d.me);
        }
        html += "</tbody></table>";
        if (!d.me) html += '<div class="hw-board-mine">Bạn chưa có lượt tự ném nào trong mùa này.</div>';
        body.innerHTML = html;
    }

    /* ---------- 4. Dơi bay + đom đóm + sương mù ---------- */
    function buildFx() {
        if (REDUCED || document.querySelector(".hw-fx")) return;
        var fog = el("div", "hw-fog");
        document.body.appendChild(fog);
        var cv = el("canvas", "hw-fx");
        document.body.appendChild(cv);
        var ctx = cv.getContext("2d"), W = 0, H = 0, DPR = Math.min(window.devicePixelRatio || 1, 2);
        var flies = [], bats = [], nextFlock = performance.now() + 2500;

        function resize() {
            W = cv.clientWidth; H = cv.clientHeight;
            cv.width = W * DPR; cv.height = H * DPR;
            ctx.setTransform(DPR, 0, 0, DPR, 0, 0);
            var target = Math.round(Math.min(40, (W * H) / 40000));
            while (flies.length < target) flies.push(makeFly(true));
            flies.length = target;
        }

        function makeFly(anyY) {
            return {
                x: Math.random() * W, y: anyY ? H * (0.3 + Math.random() * 0.7) : H + 5,
                vx: (Math.random() - 0.5) * 0.35, vy: -(0.08 + Math.random() * 0.25),
                r: 1 + Math.random() * 1.6, ph: Math.random() * 6.28,
                c: Math.random() < 0.7 ? "255,200,90" : "170,255,120"
            };
        }

        function spawnFlock() {
            var dir = Math.random() < 0.5 ? 1 : -1, n = 3 + Math.floor(Math.random() * 4);
            var y0 = H * (0.12 + Math.random() * 0.35);
            for (var i = 0; i < n; i++) {
                bats.push({
                    x: dir > 0 ? -40 - i * 50 - Math.random() * 40 : W + 40 + i * 50 + Math.random() * 40,
                    y: y0 + (Math.random() - 0.5) * 80, dir: dir,
                    v: 2.2 + Math.random() * 1.4, s: 0.7 + Math.random() * 0.6,
                    ph: Math.random() * 6.28, wob: Math.random() * 6.28
                });
            }
        }

        function drawBat(b) {
            var flap = Math.sin(b.ph);
            ctx.save();
            ctx.translate(b.x, b.y);
            ctx.scale(b.dir * b.s, b.s);
            ctx.fillStyle = "rgba(25, 12, 40, .85)";
            ctx.beginPath();
            ctx.ellipse(0, 0, 4, 6, 0, 0, 6.2832);
            ctx.fill();
            [-1, 1].forEach(function (sd) {
                ctx.beginPath();
                ctx.moveTo(0, -2);
                ctx.quadraticCurveTo(sd * 10, -10 * flap - 4, sd * 20, -6 * flap);
                ctx.quadraticCurveTo(sd * 15, -2 * flap + 2, sd * 12, 2);
                ctx.quadraticCurveTo(sd * 8, -1, sd * 6, 4);
                ctx.quadraticCurveTo(sd * 3, 1, 0, 3);
                ctx.fill();
            });
            ctx.beginPath(); ctx.moveTo(-3, -5); ctx.lineTo(-2, -10); ctx.lineTo(0, -6); ctx.lineTo(2, -10); ctx.lineTo(3, -5); ctx.fill();
            ctx.restore();
        }

        resize();
        window.addEventListener("resize", resize);

        var last = performance.now();
        function frame(t) {
            var dt = Math.min((t - last) / 16.67, 3);
            last = t;
            if (!document.hidden) {
                ctx.clearRect(0, 0, W, H);
                for (var i = 0; i < flies.length; i++) {
                    var f = flies[i];
                    f.x += f.vx * dt; f.y += f.vy * dt; f.ph += 0.04 * dt;
                    if (f.y < H * 0.2 || f.x < -10 || f.x > W + 10) { flies[i] = makeFly(false); continue; }
                    var al = 0.25 + 0.6 * Math.abs(Math.sin(f.ph));
                    ctx.fillStyle = "rgba(" + f.c + "," + (al * 0.22) + ")";
                    ctx.beginPath(); ctx.arc(f.x, f.y, f.r * 3, 0, 6.2832); ctx.fill();
                    ctx.fillStyle = "rgba(" + f.c + "," + al + ")";
                    ctx.beginPath(); ctx.arc(f.x, f.y, f.r, 0, 6.2832); ctx.fill();
                }
                if (t >= nextFlock && bats.length === 0) {
                    spawnFlock();
                    nextFlock = t + 9000 + Math.random() * 9000;
                }
                for (var k = bats.length - 1; k >= 0; k--) {
                    var b = bats[k];
                    b.x += b.dir * b.v * dt;
                    b.ph += 0.45 * dt;
                    b.wob += 0.05 * dt;
                    b.y += Math.sin(b.wob) * 0.6 * dt;
                    if ((b.dir > 0 && b.x > W + 60) || (b.dir < 0 && b.x < -60)) { bats.splice(k, 1); continue; }
                    drawBat(b);
                }
            }
            requestAnimationFrame(frame);
        }
        requestAnimationFrame(frame);
    }

    /* ---------- 5. Dơi / kẹo bung ra khi bấm nút chính ---------- */
    function sparkLayer() {
        var l = document.querySelector(".hw-spark-layer");
        if (!l) { l = el("div", "hw-spark-layer"); document.body.appendChild(l); }
        return l;
    }

    function burst(x, y, n) {
        if (REDUCED) return;
        var layer = sparkLayer();
        var glyphs = ["🦇", "🍬", "🎃", "✦", "👻"];
        for (var i = 0; i < (n || 14); i++) {
            var a = Math.random() * Math.PI * 2, r = 36 + Math.random() * 60;
            var p = el("div", "hw-spark",
                "left:" + x + "px;top:" + y + "px;font-size:" + (10 + Math.random() * 10) + "px" +
                ";--dx:" + Math.cos(a) * r + "px;--dy:" + (Math.sin(a) * r + 24) + "px" +
                ";animation-duration:" + (0.6 + Math.random() * 0.5) + "s");
            p.textContent = glyphs[i % glyphs.length];
            layer.appendChild(p);
            (function (node) { setTimeout(function () { node.remove(); }, 1200); })(p);
        }
    }

    function wireSparks() {
        var sel = ".btn-export, .btn-filter, .btn-apply, .btn-update, .btn-update-vendor, .btn-update-inbound, .btn-login";
        document.addEventListener("click", function (e) {
            var t = e.target.closest ? e.target.closest(sel) : null;
            if (!t) return;
            var r = t.getBoundingClientRect();
            burst(r.left + r.width / 2, r.top + r.height / 2, 16);
        }, true);
    }

    function init() {
        buildFrame();
        markActiveNav();
        buildFx();
        buildBanner();
        wireSparks();
    }

    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
    else init();

    /* ---------- 3c. Thể lệ "Ném ma săn quà" ---------- */
    var rulesEl = null, season = null;

    function rulesHtml(se) {
        var from = se ? se.from : "01/10", to = se ? se.to : "30/10", pz = esc((se && se.prize) || prize());
        return '' +
            '<div class="hw-rules-prize">🥇 Top 1 nhận <b>' + pz + '</b></div>' +
            '<ol class="hw-rules-list">' +
            '<li><b>Thời gian:</b> từ <b>' + from + '</b> đến ngày <b>' + to + '</b>. BXH chốt lúc 13:00 ngày ' + to + '.' +
            (se && se.closed ? ' <span class="hw-closed">🔒 Đã chốt</span>' : '') + '</li>' +
            '<li><b>Cách chơi:</b> mỗi lần đăng nhập, ném bí ngô trúng <b>3 con ma</b> để mở cổng vào hệ thống. ' +
            'Muốn chơi lại: bấm <b>🔁 Chơi lại</b> ở màn kết quả, hoặc nút <b>👻 Chơi ném ma</b> trên băng chúc mừng — chơi bao nhiêu lượt cũng được. ' +
            'Không muốn chơi thì bấm <b>Bỏ qua</b> (hoặc phím Esc).</li>' +
            '<li><b>Cách tính:</b> thời gian từ <b>quả bí ngô đầu tiên</b> đến khi trúng <b>con ma thứ 3</b>. ' +
            'Mỗi người chỉ lấy <b>lượt nhanh nhất</b> của mình.</li>' +
            '<li><b>Xếp hạng:</b> thời gian ngắn hơn xếp trên → nếu bằng nhau, ai ném <b>ít lần hơn</b> xếp trên → ' +
            'vẫn bằng nhau thì ai <b>đạt trước</b> xếp trên.</li>' +
            '<li><b>Không được tính:</b>' +
            '<ul>' +
            '<li>Lượt có dùng phím <b>Space</b> hoặc <b>Enter</b> (tự ngắm) — dù chỉ 1 lần trong lượt đó.</li>' +
            '<li>Lượt chơi sau thời gian chốt BXH.</li>' +
            '<li>Kết quả bất thường hoặc có dấu hiệu gian lận (can thiệp dữ liệu, dùng công cụ…) — Ban tổ chức có quyền huỷ.</li>' +
            '</ul></li>' +
            '<li><b>Giải thưởng:</b> người đứng <b>Top 1</b> trên BXH lúc chốt nhận <b>' + pz + '</b>. ' +
            'Ban tổ chức sẽ liên hệ người thắng để trao giải.</li>' +
            '</ol>';
    }

    function openRules() {
        if (!rulesEl) {
            rulesEl = el("div", "hw-rules-overlay");
            rulesEl.innerHTML =
                '<div class="hw-rules" role="dialog" aria-modal="true" aria-labelledby="hwRulesTitle">' +
                '  <div class="hw-board-head">' +
                '    <h3 id="hwRulesTitle">📜 Thể lệ "Ném ma săn quà"</h3>' +
                '    <button type="button" class="hw-board-close" aria-label="Đóng">×</button>' +
                '  </div>' +
                '  <div class="hw-rules-body"></div>' +
                '  <div class="hw-rules-foot"><button type="button" class="hw-rules-ok">Đã hiểu 👍</button></div>' +
                '</div>';
            document.body.appendChild(rulesEl);
            rulesEl.addEventListener("click", function (e) { if (e.target === rulesEl) closeRules(); });
            rulesEl.querySelector(".hw-board-close").addEventListener("click", closeRules);
            rulesEl.querySelector(".hw-rules-ok").addEventListener("click", closeRules);
            // chặn phím lọt xuống màn ném ma phía sau (Space/Enter)
            rulesEl.addEventListener("keydown", function (e) {
                e.stopPropagation();
                if (e.key === "Escape") closeRules();
            });
        }
        var body = rulesEl.querySelector(".hw-rules-body");
        body.innerHTML = rulesHtml(season);
        rulesEl.classList.add("open");
        rulesEl.querySelector(".hw-rules-ok").focus();
        // lấy ngày mùa giải mới nhất từ server (nếu chưa có)
        var url = boardUrl();
        if (!season && url && window.fetch) {
            fetch(url + (url.indexOf("?") < 0 ? "?" : "&") + "theme=halloween&top=3",
                { credentials: "same-origin", headers: { "Accept": "application/json" } })
                .then(function (r) { return r.ok ? r.json() : null; })
                .then(function (d) {
                    if (!d) return;
                    season = { from: d.from, to: d.to, prize: d.prize || prize(), closed: d.closed };
                    body.innerHTML = rulesHtml(season);
                })
                .catch(function () { });
        }
    }

    function closeRules() {
        if (!rulesEl) return;
        rulesEl.classList.remove("open");
        var g = document.querySelector(".hg-gate");
        if (g) g.focus({ preventScroll: true });   // trả focus về màn ném ma để chơi tiếp
    }

    window.Halloween = { burst: burst, openBoard: openBoard, openRules: openRules, prize: prize, playAgain: playAgain };
})();
