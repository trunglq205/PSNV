// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'model_detail_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning
/// Notifier family theo modelId.

@ProviderFor(ModelDetailNotifier)
final modelDetailProvider = ModelDetailNotifierFamily._();

/// Notifier family theo modelId.
final class ModelDetailNotifierProvider
    extends $NotifierProvider<ModelDetailNotifier, ModelDetailState> {
  /// Notifier family theo modelId.
  ModelDetailNotifierProvider._({
    required ModelDetailNotifierFamily super.from,
    required int super.argument,
  }) : super(
         retry: null,
         name: r'modelDetailProvider',
         isAutoDispose: true,
         dependencies: null,
         $allTransitiveDependencies: null,
       );

  @override
  String debugGetCreateSourceHash() => _$modelDetailNotifierHash();

  @override
  String toString() {
    return r'modelDetailProvider'
        ''
        '($argument)';
  }

  @$internal
  @override
  ModelDetailNotifier create() => ModelDetailNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(ModelDetailState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<ModelDetailState>(value),
    );
  }

  @override
  bool operator ==(Object other) {
    return other is ModelDetailNotifierProvider && other.argument == argument;
  }

  @override
  int get hashCode {
    return argument.hashCode;
  }
}

String _$modelDetailNotifierHash() =>
    r'f27424b5b483ff846544f68c43b322c6b63a079e';

/// Notifier family theo modelId.

final class ModelDetailNotifierFamily extends $Family
    with
        $ClassFamilyOverride<
          ModelDetailNotifier,
          ModelDetailState,
          ModelDetailState,
          ModelDetailState,
          int
        > {
  ModelDetailNotifierFamily._()
    : super(
        retry: null,
        name: r'modelDetailProvider',
        dependencies: null,
        $allTransitiveDependencies: null,
        isAutoDispose: true,
      );

  /// Notifier family theo modelId.

  ModelDetailNotifierProvider call(int modelId) =>
      ModelDetailNotifierProvider._(argument: modelId, from: this);

  @override
  String toString() => r'modelDetailProvider';
}

/// Notifier family theo modelId.

abstract class _$ModelDetailNotifier extends $Notifier<ModelDetailState> {
  late final _$args = ref.$arg as int;
  int get modelId => _$args;

  ModelDetailState build(int modelId);
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<ModelDetailState, ModelDetailState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<ModelDetailState, ModelDetailState>,
              ModelDetailState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, () => build(_$args));
  }
}
