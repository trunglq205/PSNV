import 'dart:async';

import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/utils/feedback/feedback_provider.dart';
import 'package:swms_finish_goods/core/utils/pda/pda_provider.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_fa_pickup_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_fa_pallet_providers.dart';

// ─────────────────────────────────────────────────────────────
//  B5 — FA ĐẾN LẤY HÀNG RW/RB (thêm 12/11)
//
//  Vì sao có màn này: trước đây SCS WH đặt pallet vào vị trí khu Nhận hàng là
//  serial sang luôn `at_fa`. Nhưng lúc đó hàng MỚI CHỈ nằm ở khu nhận hàng của
//  kho SCS — FA chưa đến lấy. Sổ nói "đang ở FA" trong khi hàng vẫn trong nhà
//  máy, và không ai đếm được còn bao nhiêu con đang nằm chờ FA.
//
//  Nay tách hai bước. Màn này là bước thứ hai: FA ra khu nhận hàng, quét Pallet
//  ID, hàng mới được tính là đã sang FA và pallet RỜI vị trí (không còn chiếm ô
//  trên bản đồ khu nhận hàng).
//
//  QUÉT MỘT MÃ PALLET, KHÔNG QUÉT TỪNG SERIAL: cả pallet đã được SCS WH tách
//  cho khớp SL đề nghị ở bước trước, FA chỉ xác nhận mang đi. Quét từng con ở
//  đây là bắt FA làm lại việc kho vừa làm.
//
//  ĐIỀU HƯỚNG BẰNG MaterialPageRoute, không khai route auto_route — build_runner
//  trong source hiện tại đang vỡ (hai file cùng khai `@RoutePage() class
//  VanningPage`), thêm một @RoutePage là phải sinh lại app_router.gr.dart.
//
//  QUYỀN: dùng lại `rework_refurbish.process_fa` (chốt 12/11) — cùng một người
//  của FA, cùng một ca; thêm một lá quyền nữa chỉ tạo thêm chỗ để quên gán.
// ─────────────────────────────────────────────────────────────

/// Mở màn FA nhận hàng. Trả `true` nếu đã nhận được pallet nào — chỗ gọi dùng
/// nó để tải lại danh sách phiếu.
Future<bool> openFaPickupPage(BuildContext context) async {
  final done = await Navigator.of(context).push<bool>(
    MaterialPageRoute(builder: (_) => const _FaPickupPage()),
  );
  return done ?? false;
}

class _FaPickupPage extends ConsumerStatefulWidget {
  const _FaPickupPage();

  @override
  ConsumerState<_FaPickupPage> createState() => _FaPickupPageState();
}

class _FaPickupPageState extends ConsumerState<_FaPickupPage> {
  final _ctrl = TextEditingController();
  final _focus = FocusNode();

  StreamSubscription<String>? _sub;
  bool _busy = false;

  /// Các lượt đã nhận TRONG PHIÊN này, mới nhất trước. Giữ lại để FA đối chiếu
  /// trước khi rời kho — chứ không phải lịch sử của phiếu.
  final List<FaPickupResult> _done = [];

  @override
  void initState() {
    super.initState();
    _listen();
  }

  @override
  void dispose() {
    _sub?.cancel();
    _ctrl.dispose();
    _focus.dispose();
    super.dispose();
  }

  Future<void> _listen() async {
    final pda = await ref.read(pdaProvider.future);
    // Page đã dispose trong lúc chờ -> không gán, tránh rò listener.
    if (!mounted || _sub != null) return;
    _sub = pda.scanStream.listen((data) {
      if (!mounted) return;
      _submit(data);
    });
  }

  // ── Nhận một mã pallet ────────────────────────────────────

  Future<void> _submit(String raw) async {
    final code = raw.trim();
    if (code.isEmpty || _busy) return;

    setState(() => _busy = true);
    try {
      final res =
          await ref.read(returnFaPalletRepositoryProvider).faPickup(code);

      if (!mounted) return;
      ref.read(appFeedbackProvider).success();
      setState(() {
        _done.insert(0, res);
        _ctrl.clear();
      });

      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_fa_pickup_ok.tr(
          namedArgs: {'qty': '${res.pickedQty}', 'lot': res.lotNo ?? code},
        ),
      );
    } catch (e) {
      if (!mounted) return;
      // ErrorHandler hiện NGUYÊN câu của server (và tự kêu feedback lỗi): ba lý
      // do không nhận được — chưa ra khu nhận hàng · không có gì chờ lấy ·
      // phiếu chưa được quản lý SCS duyệt — đều đã có câu riêng, bọc lại là
      // mất thông tin.
      await ref.read(errorHandlerProvider).handle(context, e);
    } finally {
      if (mounted) {
        setState(() => _busy = false);
        _focus.requestFocus();
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Scaffold(
      appBar: AppBar(title: Text(LocaleKeys.return_fa_pickup_title.tr())),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(AppDimens.md),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              AppCard(
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Icon(Icons.info_outline, size: 18, color: swms.text3),
                    const SizedBox(width: AppDimens.sm),
                    Expanded(
                      child: Text(
                        LocaleKeys.return_fa_pickup_hint.tr(),
                        style: AppTextStyles.caption.copyWith(color: swms.text2),
                      ),
                    ),
                  ],
                ),
              ),
              const SizedBox(height: AppDimens.md),

              AppTextField(
                controller: _ctrl,
                focusNode: _focus,
                autofocus: true,
                enabled: !_busy,
                label: LocaleKeys.return_fa_pickup_scan.tr(),
                hint: LocaleKeys.return_fa_pickup_scan_hint.tr(),
                prefixIcon: const Icon(Icons.qr_code_scanner),
                textInputAction: TextInputAction.done,
                onSubmitted: _submit,
              ),
              const SizedBox(height: AppDimens.md),

              AppButton(
                label: LocaleKeys.return_fa_pickup_submit.tr(),
                icon: Icons.local_shipping_outlined,
                isLoading: _busy,
                onPressed: _busy ? null : () => _submit(_ctrl.text),
              ),
              const SizedBox(height: AppDimens.md),

              Expanded(
                child: _done.isEmpty
                    ? Center(
                        child: Text(
                          LocaleKeys.return_fa_pickup_empty.tr(),
                          style:
                              AppTextStyles.caption.copyWith(color: swms.text3),
                        ),
                      )
                    : ListView.separated(
                        itemCount: _done.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: AppDimens.sm),
                        itemBuilder: (_, i) => _DoneRow(row: _done[i]),
                      ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

/// Một lượt đã nhận: mã pallet · SL · phiếu · ô vừa lấy đi.
class _DoneRow extends StatelessWidget {
  const _DoneRow({required this.row});

  final FaPickupResult row;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return AppCard(
      padding: const EdgeInsets.symmetric(
        horizontal: AppDimens.md,
        vertical: AppDimens.sm,
      ),
      child: Row(
        children: [
          Icon(Icons.check_circle, size: 20, color: swms.success),
          const SizedBox(width: AppDimens.sm),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  row.lotNo ?? '',
                  style: AppTextStyles.body.copyWith(
                    fontWeight: FontWeight.w800,
                    color: swms.text1,
                  ),
                ),
                Text(
                  LocaleKeys.return_fa_pickup_row.tr(namedArgs: {
                    'doc': row.docNo ?? '-',
                    'loc': row.locatorCode ?? '-',
                  }),
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ],
            ),
          ),
          StatusPill(
            label: '${row.pickedQty}',
            background: swms.successBg,
            foreground: swms.success,
          ),
        ],
      ),
    );
  }
}
