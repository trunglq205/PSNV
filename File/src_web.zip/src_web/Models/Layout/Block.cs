﻿namespace SWMS_WebTool.Models.Layout
{
    public class Block
    {
        public Block(string? blockName)
        {
            var arr = blockName?.Split('.');
            if (arr == null || arr.Length != 4 )
            {
                return;
            }

            FloorCode = arr[0];
            RackCode = arr[1];
            Layer = int.Parse(arr[2]);
            Unit = int.Parse(arr[3]);
        }

        public string FloorCode;
        public string RackCode;
        public int Layer;
        public int Unit;
    }
}
