namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;

/// <summary>
/// Đề nghị nhận lại hàng về FA (mục 2c). BA bước, MỘT cấp duyệt:
///   B1 FA tạo đề nghị · B2 quản lý FA xác nhận · B3 SCS WH quét pallet giao hàng
///
/// Mọi con số tiến độ (<see cref="AssignedQty"/>, <see cref="ReturnedQty"/>,
/// <see cref="AtFaQty"/>) do API đếm từ SỔ SERIAL — web không tự cộng lại từ
/// dòng, vì dòng chỉ ghi "đề nghị bao nhiêu".
/// </summary>
public class ReturnBackRequestDto
{
    public long Id { get; set; }
    public long DocId { get; set; }
    public string? DocNo { get; set; }
    public string? GoodsType { get; set; }
    public string ReqNo { get; set; } = "";
    public string ReqStatus { get; set; } = "";
    public string CurrentStep { get; set; } = "";
    public string? Note { get; set; }

    public int ModelCount { get; set; }
    public int TotalQty { get; set; }
    public int AssignedQty { get; set; }
    public int ReturnedQty { get; set; }
    public int AtFaQty { get; set; }

    /// <summary>Còn bao nhiêu con chưa giao. API tính, web không trừ lại.</summary>
    public int RemainQty { get; set; }

    public bool IsOpen { get; set; }

    /// <summary>Đã giao xong cả đề nghị.</summary>
    public bool IsDelivered { get; set; }

    /// <summary>Đã giao được pallet nào nhưng chưa hết.</summary>
    public bool IsPartlyDelivered { get; set; }

    public bool IsCancelled { get; set; }

    public string? RequestedBy { get; set; }
    public DateTime RequestedAt { get; set; }

    public string? FaApprovedBy { get; set; }
    public DateTime? FaApprovedAt { get; set; }
    public string? FaComment { get; set; }

    /// <summary>Ai bấm xác nhận giao hàng (B3) — SCS WH.</summary>
    public string? DeliveredBy { get; set; }

    /// <summary>Lúc giao XONG cả đề nghị; NULL khi còn hàng chưa giao.</summary>
    public DateTime? DeliveredAt { get; set; }

    /// <summary>Ghi chú của kho lúc giao hàng.</summary>
    public string? ScsComment { get; set; }

    public string? CancelledBy { get; set; }
    public DateTime? CancelledAt { get; set; }
    public string? CancelReason { get; set; }

    public List<ReturnBackRequestLineDto> Lines { get; set; } = new();

    /// <summary>Giao thiếu so với SL đề nghị ở ít nhất một model.</summary>
    public bool AnyShort => Lines.Any(l => l.Short);
}

public class ReturnBackRequestLineDto
{
    public long Id { get; set; }
    public int LineNo { get; set; }
    public string Model { get; set; } = "";
    public int Qty { get; set; }
    public int AssignedQty { get; set; }
    public int ReturnedQty { get; set; }
    public int AvailableQty { get; set; }
    public bool Short { get; set; }
    public string? Note { get; set; }
}

/// <summary>
/// B1 — tạo đề nghị. CHỈ CÓ số phiếu và ghi chú.
///
/// Không có <c>Lines</c>: lấy là lấy HẾT phần phiếu còn ở kho, nên API tự suy
/// dòng model + SL. Form chỉ cho XEM số đó — không ô nhập nào.
/// </summary>
public class CreateBackRequestRequestDto
{
    public long DocId { get; set; }
    public string? Note { get; set; }
}

/// <summary>Sửa — chỉ còn ghi chú, và chỉ khi còn chờ quản lý FA.</summary>
public class UpdateBackRequestRequestDto
{
    public string? Note { get; set; }
}

public class BackRequestDecisionRequestDto
{
    public string? Comment { get; set; }
}

/// <summary>B3 — một lượt quét pallet giao hàng cho FA.</summary>
public class DeliverBackRequestDto
{
    public List<string> LotNos { get; set; } = new();
    public string? Comment { get; set; }
}

/// <summary>Một pallet đã giao.</summary>
public class BackDeliveryDto
{
    public string LotNo { get; set; } = "";
    public int SerialCount { get; set; }
    public DateTime DeliveredAt { get; set; }
    public string? DeliveredBy { get; set; }
}

/// <summary>
/// Kết quả một lượt quét. <c>NotFoundLots</c> là mã không có trong hệ thống,
/// <c>EmptyLots</c> là pallet có thật nhưng không còn con nào của phiếu — hai
/// chuyện khác nhau nên màn hình nói khác nhau.
/// </summary>
public class BackDeliverResultDto
{
    public int DeliveredQty { get; set; }
    public int RemainQty { get; set; }
    public bool Completed { get; set; }
    public List<BackDeliveryDto> Pallets { get; set; } = new();
    public List<string> NotFoundLots { get; set; } = new();
    public List<string> EmptyLots { get; set; } = new();
    public ReturnBackRequestDto? Request { get; set; }
}

public class BackAvailableModelDto
{
    public string Model { get; set; } = "";
    public int AvailableQty { get; set; }
}

/// <summary>
/// Giá trị <c>current_step</c>. GIỮ KHỚP với <c>ReturnBackStep</c> bên API —
/// lệch một ký tự là tab hàng đợi rỗng mà không báo lỗi gì.
/// </summary>
public static class BackStep
{
    public const string FaApprove = "fa_approve";
    public const string ScsDeliver = "scs_deliver";
    public const string Done = "done";
}

/// <summary>Giá trị <c>req_status</c>. GIỮ KHỚP với <c>ReturnBackStatus</c>.</summary>
public static class BackStatus
{
    public const string FaRequested = "fa_requested";
    public const string FaApproved = "fa_approved";
    public const string Delivered = "delivered";
    public const string Cancelled = "cancelled";
}
