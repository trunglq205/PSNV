﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Models.Layout;

namespace SWMS_WebTool.ViewModels
{
    public class KittingEmapViewModel: TableViewModel<KittingListDetail, KittingEmapFilter>
    {
        public List<Floor> Floors = new List<Floor>();

        public Floor FloorLayout;
        
        public EmapGrid? EmapGrid;

        public Node StartPoint;

        public Node EndPoint;

        public List<Node> KittingPoint;

        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, KittingEmapFilter? filter = null)
        {
            return new
            {
                SelectedTab = filter?.SelectedTab ?? Filter.SelectedTab,
                PIC = filter?.PIC ?? Filter.PIC,
                Date = filter?.Date ?? Filter.Date,
                KittingType = filter?.KittingType ?? Filter.KittingType,
            };
        }
    }
}
