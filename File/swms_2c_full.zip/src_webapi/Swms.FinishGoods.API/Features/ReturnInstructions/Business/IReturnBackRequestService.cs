using Swms.FinishGoods.API.Features.ReturnInstructions.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

public interface IReturnBackRequestService
{
    Task<IReadOnlyList<BackRequestResponse>> GetListAsync(BackRequestQuery query);

    Task<BackRequestResponse> GetByIdAsync(long id);

    /// <summary>SL còn gắp được theo model — màn soạn yêu cầu dùng.</summary>
    Task<IReadOnlyList<BackAvailableModelResponse>> GetAvailableAsync(long docId);

    /// <summary>B1 — FA tạo yêu cầu back.</summary>
    Task<BackRequestResponse> CreateAsync(CreateBackRequestRequest request);

    /// <summary>Sửa khi còn ở bước FA duyệt hoặc SCS WH xác nhận.</summary>
    Task<BackRequestResponse> UpdateAsync(long id, UpdateBackRequestRequest request);

    /// <summary>B2 — quản lý FA duyệt.</summary>
    Task<BackRequestResponse> ApproveFaAsync(long id, BackRequestDecisionRequest request);

    /// <summary>B3 — SCS WH xác nhận thông tin và tạo chỉ thị back.</summary>
    Task<BackRequestResponse> InstructAsync(long id, BackRequestDecisionRequest request);

    /// <summary>
    /// B4 — quản lý SCS duyệt cho back. ĐÂY là bước gắp serial và chuyển
    /// <c>at_fa</c>; trước đó yêu cầu chỉ là model + SL.
    /// </summary>
    Task<BackRequestResponse> ApproveScsAsync(long id, BackRequestDecisionRequest request);

    /// <summary>Huỷ — chỉ khi chưa duyệt xong B4.</summary>
    Task<BackRequestResponse> CancelAsync(long id, BackRequestDecisionRequest request);
}
