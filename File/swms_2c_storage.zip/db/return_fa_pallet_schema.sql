/* ============================================================================
   MỤC 2d — FA quét tạo lại Pallet ID sau rework.

   Chạy SAU return_back_merge_schema.sql (bản gộp 2c, 09/11).

   Script chỉ tạo MỘT bảng: wms.return_serial_mismatches — nhật ký serial FA
   quét ra mà KHÔNG khớp sổ của phiếu.

   VÌ SAO CẦN BẢNG NÀY, VÀ VÌ SAO KHÔNG NHÉT VÀO SỔ SERIAL:
     Yêu cầu nghiệp vụ: FA quét serial lạ thì VẪN CHO QUÉT TIẾP, chỉ cảnh báo
     ngay để SCS WH biết mà đặt riêng những con đó ra. Nhưng serial lạ không
     chèn được vào wms.return_instruction_serials: `ux_ris_serial_open` là
     UNIQUE trên serial_no TOÀN HỆ THỐNG, nên một con đang thuộc phiếu khác mà
     chèn thêm dòng dưới doc_id này là vỡ index ngay.

     Và bảng này phải TỒN TẠI chứ không chỉ hiện trên màn PDA: người quét là FA,
     người đặt hàng riêng ra là SCS WH, hai người hai thời điểm. Không lưu thì
     SCS phụ thuộc vào việc FA có nhớ nói hay không.

   CHỈ GHI THÊM, không sửa: đây là nhật ký. Xoá mềm chỉ dùng khi ghi nhầm.
   ============================================================================ */
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ---------- 0. Tiền đề ---------- */
IF OBJECT_ID(N'wms.return_instructions', N'U') IS NULL
   OR OBJECT_ID(N'wms.return_instruction_serials', N'U') IS NULL
BEGIN
    RAISERROR(N'Thieu bang cua muc 2a — chay return_receiving_schema.sql truoc.', 16, 1);
    RETURN;
END;

/* Tiền đề của mục 2c, sau khi GỘP (09/11): luồng nhận lại hàng về FA nay nằm
   trên 13 cột back_* của chính wms.return_instructions, không còn bảng
   wms.return_back_requests lẫn cột return_instruction_serials.back_request_id.

   Trước đây chỗ này kiểm back_request_id; giữ nguyên là script 2d KHÔNG BAO GIỜ
   chạy được sau khi gộp, vì cột đó đã bị drop. Kiểm back_status thay thế: 2d chỉ
   có việc khi hàng đã sang FA, mà đưa hàng sang FA là việc của 2c. */
IF COL_LENGTH(N'wms.return_instructions', N'back_status') IS NULL
BEGIN
    RAISERROR(N'Thieu cot back_status — chay return_back_merge_schema.sql truoc.', 16, 1);
    RETURN;
END;

BEGIN TRAN;

/* ---------- 1. wms.return_serial_mismatches ---------- */
IF OBJECT_ID(N'wms.return_serial_mismatches', N'U') IS NULL
BEGIN
    CREATE TABLE wms.return_serial_mismatches
    (
        id        BIGINT IDENTITY(1,1) NOT NULL,

        /* Phiếu FA đang quét vào. */
        doc_id    BIGINT         NOT NULL,

        /* Pallet FA đang đóng lúc quét ra con lạ. NULL khi lần quét đó bị huỷ
           giữa đường (chưa sinh pallet) — vẫn giữ dòng, vì cái SCS cần biết là
           "có con lạ", không phải "con lạ nằm pallet nào". */
        pallet_id BIGINT         NULL,

        serial_no NVARCHAR(100)  NOT NULL,

        /* Model suy từ sổ serial nếu tra được; NULL với serial hoàn toàn lạ. */
        model     NVARCHAR(100)  NULL,

        /* not_in_doc    = không có trong sổ của phiếu này
           wrong_status  = có trong phiếu nhưng không ở at_fa (đã về / chưa giao
                           FA / đã xuất / đã đánh ng)
           other_doc     = đang thuộc phiếu khác
           Ba loại tách riêng vì FA xử lý khác nhau: con của phiếu khác thì trả
           về đúng phiếu đó, con sai trạng thái thì phải tra lại lịch sử. */
        reason    NVARCHAR(20)   NOT NULL,

        /* Trạng thái con serial đó ĐANG mang, khi tra được. Giúp SCS khỏi phải
           đi tra lại sổ chỉ để biết vì sao nó bị loại. */
        found_status NVARCHAR(20) NULL,

        /* Số phiếu đang giữ con đó, khi reason = other_doc. */
        other_doc_no NVARCHAR(30) NULL,

        scanned_at DATETIME2(0)  NOT NULL
            CONSTRAINT df_rsm_scanned_at DEFAULT (SYSDATETIME()),
        scanned_by NVARCHAR(100) NULL,

        /* Đã xử lý xong (SCS đã đặt riêng / đã trả về phiếu đúng). Để màn hình
           lọc ra việc CÒN PHẢI LÀM, chứ không phải đọc lại cả nhật ký. */
        resolved_at DATETIME2(0) NULL,
        resolved_by NVARCHAR(100) NULL,
        resolve_note NVARCHAR(500) NULL,

        is_deleted BIT           NOT NULL CONSTRAINT df_rsm_is_deleted DEFAULT (0),
        created_at DATETIME2(0)  NOT NULL CONSTRAINT df_rsm_created_at DEFAULT (SYSDATETIME()),
        created_by NVARCHAR(100) NULL,
        updated_at DATETIME2(0)  NULL,
        updated_by NVARCHAR(100) NULL,

        CONSTRAINT pk_return_serial_mismatches PRIMARY KEY CLUSTERED (id),

        CONSTRAINT ck_rsm_reason CHECK
            (reason IN (N'not_in_doc', N'wrong_status', N'other_doc')),

        CONSTRAINT fk_rsm_doc FOREIGN KEY (doc_id)
            REFERENCES wms.return_instructions (id)

        /* KHÔNG đặt FK sang wms.pallets: pallet có thể bị xoá mềm rồi xoá cứng
           khi huỷ lần nhận, mà nhật ký này phải sống lâu hơn pallet. */
    );
    PRINT N'+ Da tao bang wms.return_serial_mismatches.';
END
ELSE PRINT N'= wms.return_serial_mismatches da co.';

/* KHÔNG đặt unique trên (doc_id, serial_no): FA quét lại con lạ lần hai là một
   SỰ KIỆN khác, và đếm số lần quét sai cũng là thông tin. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_serial_mismatches')
                 AND name = N'ix_rsm_doc_open')
BEGIN
    /* Lọc resolved_at IS NULL: màn hình chỉ cần việc CÒN PHẢI LÀM, và nhật ký
       cũ thì càng ngày càng dài. */
    CREATE NONCLUSTERED INDEX ix_rsm_doc_open
        ON wms.return_serial_mismatches (doc_id, scanned_at DESC)
        INCLUDE (serial_no, model, reason, found_status, other_doc_no, pallet_id)
        WHERE is_deleted = 0 AND resolved_at IS NULL;
    PRINT N'+ ix_rsm_doc_open';
END;

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_serial_mismatches')
                 AND name = N'ix_rsm_serial')
BEGIN
    CREATE NONCLUSTERED INDEX ix_rsm_serial
        ON wms.return_serial_mismatches (serial_no)
        INCLUDE (doc_id, reason, scanned_at)
        WHERE is_deleted = 0;
    PRINT N'+ ix_rsm_serial';
END;

COMMIT;

/* ---------- 2. Kiểm lại ---------- */
SELECT N'2a. Bang moi' AS section;
SELECT bang = N'wms.return_serial_mismatches', so_dong = COUNT(*)
FROM   wms.return_serial_mismatches;

SELECT N'2b. Index' AS section;
SELECT i.name, i.has_filter
FROM   sys.indexes i
WHERE  i.object_id = OBJECT_ID(N'wms.return_serial_mismatches')
  AND  i.name IN (N'ix_rsm_doc_open', N'ix_rsm_serial')
ORDER BY i.name;

SELECT N'2c. San sang cho muc 2d chua' AS section;

/* Bọc EXEC vì nhắc các cột của mục 2c. */
EXEC(N'
    SELECT so_serial_dang_o_FA = SUM(IIF(status = N''at_fa'', 1, 0)),
           so_serial_da_ve     = SUM(IIF(status = N''returned'', 1, 0)),
           so_serial_dang_kho  = SUM(IIF(status = N''received'', 1, 0))
    FROM   wms.return_instruction_serials
    WHERE  is_deleted = 0');

/* ---------- 3. Việc còn phải làm bằng tay ---------- */
SELECT N'3. Con phai lam tay' AS section;
SELECT viec = N'Khai quyen cho role FA: rework_refurbish.process_fa (quet tao pallet) '
            + N'va pda_receiving.return_fa_pallet (tile tren PDA) — man Roles.'
UNION ALL
SELECT N'Quyen moi tu xuat hien trong matrix sau khi BUILD LAI API.';
