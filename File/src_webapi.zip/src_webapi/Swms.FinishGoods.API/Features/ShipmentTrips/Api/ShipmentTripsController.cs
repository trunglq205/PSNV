using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

/// <summary>Chuyến xe lấy hàng (xe container / xe tải) — văn phòng nhập theo thông tin FWD gửi.
/// Quyền riêng Perms.Outbound.Trip (trước dùng chung Si.View / Si.Update):
///   View        xem danh sách / chi tiết (số CCCD / GPLX đã che)
///   Create      tạo chuyến
///   Update      sửa chuyến + mở form sửa (số CCCD / GPLX đầy đủ)
///   ChangeStatus xe đến / đóng chì / xuất cổng / huỷ — thường là bảo vệ / kho ở cổng
///   Delete      xoá chuyến còn "đã đặt xe"
///   PhotoUpload PDA chụp ảnh minh chứng (TripPhotosController)</summary>
[ApiController]
[Route("api/shipment-trips")]
public class ShipmentTripsController : ControllerBase
{
    private readonly IShipmentTripService _service;
    public ShipmentTripsController(IShipmentTripService service) => _service = service;

    /// <summary>VD: GET /api/shipment-trips?from=2026-10-27&amp;to=2026-11-02&amp;status=planned</summary>
    [HttpGet]
    [RequirePermission<Perms.Outbound.Trip.View>]
    public async Task<ActionResult<List<TripResponse>>> GetList([FromQuery] TripQuery query)
        => Ok(await _service.GetListAsync(query));

    /// <summary>Số CCCD / GPLX chỉ còn 4 số cuối.</summary>
    [HttpGet("{id:long}")]
    [RequirePermission<Perms.Outbound.Trip.View>]
    public async Task<ActionResult<TripResponse>> Get(long id)
        => Ok(await _service.GetAsync(id, fullDriverId: false));

    /// <summary>Bản đầy đủ để mở form sửa (có số CCCD / GPLX đầy đủ).</summary>
    [HttpGet("{id:long}/edit")]
    [RequirePermission<Perms.Outbound.Trip.Update>]
    public async Task<ActionResult<TripResponse>> GetForEdit(long id)
        => Ok(await _service.GetAsync(id, fullDriverId: true));

    /// <summary>Các chuyến của 1 SI (khối "Chuyến xe" trong chi tiết SI).
    /// Người xem SI mà thiếu Trip.View sẽ nhận 403 ở khối này — gán Trip.View cho các role có Si.View.</summary>
    [HttpGet("/api/shipment-instructions/{siId:long}/trips")]
    [RequirePermission<Perms.Outbound.Trip.View>]
    public async Task<ActionResult<List<TripResponse>>> GetBySi(long siId)
        => Ok(await _service.GetBySiAsync(siId));

    [HttpPost]
    [RequirePermission<Perms.Outbound.Trip.Create>]
    public async Task<ActionResult<TripResponse>> Create(TripSaveRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(Get), new { id = created.Id }, created);
    }

    /// <summary>Sis = null: giữ nguyên SI; có giá trị: thay toàn bộ danh sách SI.</summary>
    [HttpPut("{id:long}")]
    [RequirePermission<Perms.Outbound.Trip.Update>]
    public async Task<ActionResult<TripResponse>> Update(long id, TripSaveRequest request)
        => Ok(await _service.UpdateAsync(id, request));

    /// <summary>Action: arrive | seal | depart | cancel (cancel cần Reason).</summary>
    [HttpPost("{id:long}/status")]
    [RequirePermission<Perms.Outbound.Trip.ChangeStatus>]
    public async Task<ActionResult<TripResponse>> ChangeStatus(long id, TripStatusRequest request)
        => Ok(await _service.ChangeStatusAsync(id, request));

    /// <summary>Chỉ chuyến còn "đã đặt xe".</summary>
    [HttpDelete("{id:long}")]
    [RequirePermission<Perms.Outbound.Trip.Delete>]
    public async Task<IActionResult> Delete(long id)
    {
        await _service.DeleteAsync(id);
        return NoContent();
    }
}