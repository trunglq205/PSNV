import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';

/// Lấy nguyên pallet: nội dung pallet (chỉ đọc) + xác nhận khi quét khớp.
class KittingPalletContentCard extends StatelessWidget {
  final PickTask task;

  /// Đã quét đúng Pallet ID.
  final bool matched;

  const KittingPalletContentCard({
    super.key,
    required this.task,
    required this.matched,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final perBox = task.boxPlanned <= 0
        ? 0
        : (task.qtyPlanned / task.boxPlanned).floor();

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  LocaleKeys.kitting_task_pallet_content.tr(),
                  style: AppTextStyles.title.copyWith(
                    fontSize: 14,
                    color: swms.text1,
                  ),
                ),
              ),
              if (matched)
                StatusPill.success(
                  context,
                  label: LocaleKeys.kitting_task_scanned.tr(),
                )
              else
                StatusPill.neutral(
                  context,
                  label: LocaleKeys.kitting_task_not_scanned.tr(),
                ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: _Tile(
                  value: '${task.boxPlanned}',
                  label: LocaleKeys.kitting_task_boxes.tr(),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Expanded(
                child: _Tile(value: '${task.qtyPlanned}', label: 'Pcs'),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Text(
                task.palletCode ?? '',
                style: AppTextStyles.code.copyWith(
                  fontSize: 12,
                  letterSpacing: 0,
                  color: swms.text3,
                ),
              ),
              const Spacer(),
              Text(
                LocaleKeys.kitting_task_pcs_per_box.tr(args: ['$perBox']),
                style: AppTextStyles.caption.copyWith(color: swms.text3),
              ),
            ],
          ),
          if (matched) ...[
            const SizedBox(height: 12),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 11),
              decoration: BoxDecoration(
                color: swms.successBg,
                border: Border.all(color: swms.success),
                borderRadius: BorderRadius.circular(AppDimens.rBtn),
              ),
              child: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: swms.success,
                      shape: BoxShape.circle,
                    ),
                    child: const Icon(Icons.check, size: 16, color: Colors.white),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          LocaleKeys.kitting_task_whole_pallet_ok.tr(
                            args: ['${task.qtyPlanned}'],
                          ),
                          style: AppTextStyles.bodyStrong.copyWith(
                            fontWeight: FontWeight.w700,
                            color: swms.success,
                          ),
                        ),
                        Text(
                          LocaleKeys.kitting_task_pallet_matches_si.tr(),
                          style: AppTextStyles.caption.copyWith(
                            color: swms.text3,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  final String value;
  final String label;
  const _Tile({required this.value, required this.label});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.symmetric(vertical: AppDimens.sm),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(AppDimens.rBtn),
      ),
      child: Column(
        children: [
          Text(value, style: AppTextStyles.h2.copyWith(color: swms.text1)),
          Text(label, style: AppTextStyles.caption.copyWith(color: swms.text3)),
        ],
      ),
    );
  }
}
