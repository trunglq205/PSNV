﻿using Microsoft.AspNetCore.Mvc;
using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;
using SWMS_WebTool.Services;
using SWMS_WebTool.Utils;
using SWMS_WebTool.ViewModels;

namespace SWMS_WebTool.Controllers
{
    public class BackFlushController : BaseController
    {
        private readonly ApiService _apiService;

        public BackFlushController(ApiService apiService)
        {
            _apiService = apiService;
        }

        [HttpGet]
        public async Task<IActionResult> Index([FromQuery] BackFlushFilter? filter, int pageNumber = 1, string? pageSize = null)
        {
            try
            {
                var _pageSize = pageSize?.ToLower() == "max" ? Constants.PageMaximum : int.Parse(pageSize ?? Constants.PageLimit.ToString());
                var _filter = filter ?? new BackFlushFilter();
                _filter.Material = _filter.Material?.Trim().ToUpper();
                var response = await _apiService.SearchBackFlush(_filter, pageNumber, _pageSize);
                var scheduleResponse = await _apiService.GetScheduleRC();
                var total = response.TotalRecord;
                var items = response.Records ?? new List<BackFlush>();

                var model = new BackFlushViewModel() 
                {
                  Items = items,
                    ReceivingSchedule = new ReceivingSchedule
                    {
                        IsBlock = false,
                        BlockDate = DateTime.Now,
                        DatePrint = DateTime.Now,
                    },
                    Filter = _filter,
                    PageNumber = pageNumber,
                    PageSize = _pageSize,
                    TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                    Total = total
                };

                if (scheduleResponse != null)
                {
                    var schedule = new ReceivingSchedule
                    {
                        IsBlock = scheduleResponse.IsBlock,
                        BlockDate = scheduleResponse.BlockDate,
                        DatePrint = scheduleResponse.DatePrint,
                    };

                    model = new BackFlushViewModel()
                    {
                        Items = items,
                        ReceivingSchedule = schedule,
                        Filter = _filter,
                        PageNumber = pageNumber,
                        PageSize = _pageSize,
                        TotalPage = (int)Math.Ceiling((double)total / _pageSize),
                        Total = total,

                    };
                }
               
                return View(model);
            }
            catch (Exception ex)
            {
                return RedirectToAction("Error", "Home", new
                {
                    Message = ex.Message
                });
            }
        }

        [HttpGet]
        public async Task<IActionResult> Detail(long receivingCardId)
        {
            try
            {
                var result = await _apiService.SearchBackFlushDetail(receivingCardId);
                return PartialView("~/Views/BackFlush/_GetBackFlushDetailModel.cshtml", result);
            }
            catch(Exception e)
            {
                return BadRequest(e.Message);
            }
        }

        [HttpPost]
        public IActionResult ConfirmBackFlush([FromBody] ConfirmBackflushRequest model)
        {
            try
            {
                return PartialView("~/Views/BackFlush/_ConfirmBackFlushModal.cshtml", model);
            }
            catch (Exception e)
            {
                return BadRequest(e.Message);
            }

        }

        [HttpPost]
        public async Task<IActionResult> ConfirmBackFlushSave(ConfirmBackflushRequest model)
        {
            if (!ModelState.IsValid)
            {
                var message = string.Join(" | ", ModelState.Values
                .SelectMany(v => v.Errors)
                .Select(e => e.ErrorMessage));
                return BadRequest(message);
            }

            try
            {
                await _apiService.ConfirmBackFlush(model);

                return Json(new { success = true });
            }
            catch (Exception ex)
            {
                return BadRequest(ex.Message);
            }
        }

    }
}
