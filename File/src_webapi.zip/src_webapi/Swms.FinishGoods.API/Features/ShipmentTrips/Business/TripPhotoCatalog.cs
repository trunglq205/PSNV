namespace Swms.FinishGoods.API.Features.ShipmentTrips.Business;

/*  Bộ ảnh bắt buộc theo quy định PLD ("Hướng dẫn các bước chụp ảnh hàng xuất").
    Chọn theo LOẠI XE của chuyến:
      - container          -> FCL
      - xe tải / xe máy    -> AIR / LCL

    GIỮ KHỚP với TripPhotoRules bên Web (Features/ShipmentTrips/Business/Models):
    cùng Key, cùng PerUnit, cùng Unit. Khoá ở đây là thứ API dùng để KIỂM ảnh PDA
    gửi lên — Web đổi khoá mà quên đổi ở đây thì PDA upload bị từ chối, còn đổi
    ở đây mà quên Web thì màn Chuyến xe đếm thiếu ảnh.

    Số cọc / hàng là ƯỚC TÍNH: cọc = 2 pallet, 1 hàng trong cont = 2 cọc
    (cùng công thức với Web). Khi có Stowage Plan đã lưu thì nên lấy số thật.   */

public enum TripPhotoUnit { Trip, Pallet, Coc, Row }

public sealed record TripPhotoItemDef(
    int Step, string StepTitle, string Key, string Label, int PerUnit, TripPhotoUnit Unit,
    string? Note = null, string[]? SlotLabels = null);

public static class TripPhotoCatalog
{
    public static readonly IReadOnlyList<TripPhotoItemDef> AirLcl = new List<TripPhotoItemDef>
    {
        new(1, "Trước khi quấn hàng", "air.before.side", "Mặt ngang pallet", 2, TripPhotoUnit.Pallet),
        new(1, "Trước khi quấn hàng", "air.before.end", "Mặt dọc pallet", 2, TripPhotoUnit.Pallet),
        new(1, "Trước khi quấn hàng", "air.before.top", "Nóc pallet", 1, TripPhotoUnit.Pallet),

        new(2, "Lót gậy & phủ slip sheet", "air.slip.stick", "Đặt gậy trước khi úp slip sheet", 1, TripPhotoUnit.Pallet, "Pallet quấn film trắng không cần"),
        new(2, "Lót gậy & phủ slip sheet", "air.slip.cover", "Slip sheet đã úp kín mặt pallet", 1, TripPhotoUnit.Pallet, "Pallet quấn film trắng không cần"),

        new(3, "Hoàn thiện & giao hàng", "air.done.side", "Mặt ngang pallet", 2, TripPhotoUnit.Pallet),
        new(3, "Hoàn thiện & giao hàng", "air.done.end", "Mặt dọc pallet", 2, TripPhotoUnit.Pallet),
        new(3, "Hoàn thiện & giao hàng", "air.done.scale", "Cân pallet", 1, TripPhotoUnit.Pallet, "Trọng lượng thực tế khớp khai báo"),
        new(3, "Hoàn thiện & giao hàng", "air.done.load", "Pallet lên xe", 1, TripPhotoUnit.Pallet),
    };

    public static readonly IReadOnlyList<TripPhotoItemDef> Fcl = new List<TripPhotoItemDef>
    {
        new(1, "Tình trạng container", "fcl.cont.all", "Toàn bộ container", 1, TripPhotoUnit.Trip),
        new(1, "Tình trạng container", "fcl.cont.corner", "4 góc trong cùng", 4, TripPhotoUnit.Trip, null, new[] { "Góc 1", "Góc 2", "Góc 3", "Góc 4" }),
        new(1, "Tình trạng container", "fcl.cont.roof", "Trần / nóc cont", 1, TripPhotoUnit.Trip),
        new(1, "Tình trạng container", "fcl.cont.floor", "Sàn cont", 1, TripPhotoUnit.Trip),
        new(1, "Tình trạng container", "fcl.cont.left", "Thành trái", 1, TripPhotoUnit.Trip),
        new(1, "Tình trạng container", "fcl.cont.right", "Thành phải", 1, TripPhotoUnit.Trip),
        new(1, "Tình trạng container", "fcl.cont.no", "Số cont + giấy màu", 1, TripPhotoUnit.Trip, "Đúng số cont thực tế"),

        new(2, "Hàng trước khi đóng cont", "fcl.pallet.coc", "Cọc pallet (thể hiện 4 mặt)", 2, TripPhotoUnit.Coc),
        new(2, "Hàng trước khi đóng cont", "fcl.pallet.film", "Độ dãn film quấn", 1, TripPhotoUnit.Pallet),

        new(3, "Hàng trong container", "fcl.load.row", "Từng hàng đã đóng vào cont", 1, TripPhotoUnit.Row),
        new(3, "Hàng trong container", "fcl.load.block", "Hoàn tất cont (khi chặn cont)", 1, TripPhotoUnit.Trip),
        new(3, "Hàng trong container", "fcl.load.gap", "Khoảng cách còn dư", 1, TripPhotoUnit.Trip, "Chặn cont đúng tiêu chuẩn"),

        new(4, "Kẹp chì trước khi ra cổng", "fcl.seal.docs", "Chì + giấy ra cổng, giấy màu, tally sheet", 1, TripPhotoUnit.Trip),
        new(4, "Kẹp chì trước khi ra cổng", "fcl.seal.pos", "Chì kẹp đúng vị trí", 1, TripPhotoUnit.Trip),
        new(4, "Kẹp chì trước khi ra cổng", "fcl.seal.door", "Cửa cont đã đóng sau khi kẹp chì", 1, TripPhotoUnit.Trip),
    };

    /// <summary>Bộ ảnh của 1 loại xe: container -> FCL, còn lại -> AIR / LCL.</summary>
    public static IReadOnlyList<TripPhotoItemDef> For(string vehicleType)
        => vehicleType == ShipmentTripService.Container ? Fcl : AirLcl;

    public static TripPhotoItemDef? Find(string vehicleType, string key)
        => For(vehicleType).FirstOrDefault(i => i.Key == key);

    /// <summary>(pallet, cọc, hàng) của chuyến — cùng công thức TripPhotoRules.Build bên Web.</summary>
    public static (int Pallets, int Cocs, int Rows) Units(int pallets)
    {
        var cocs = (pallets + 1) / 2;
        var rows = (cocs + 1) / 2;
        return (pallets, cocs, rows);
    }

    public static int UnitsOf(TripPhotoUnit unit, (int Pallets, int Cocs, int Rows) u) => unit switch
    {
        TripPhotoUnit.Trip => 1,
        TripPhotoUnit.Pallet => u.Pallets,
        TripPhotoUnit.Coc => u.Cocs,
        _ => u.Rows,
    };

    public static string UnitCode(TripPhotoUnit unit) => unit switch
    {
        TripPhotoUnit.Trip => "trip",
        TripPhotoUnit.Pallet => "pallet",
        TripPhotoUnit.Coc => "coc",
        _ => "row",
    };
}
