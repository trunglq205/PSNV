import 'dart:async';

import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/utils/printing/labels/qr_label.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/pallet/domain/entities/pallet_entities.dart';
import 'package:swms_finish_goods/features/pallet/presentation/providers/pallet_providers.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/detail/pallet_action_list.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/detail/pallet_box_list.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/detail/pallet_history_timeline.dart';
import 'package:swms_finish_goods/features/pallet/presentation/widgets/detail/pallet_info_card.dart';
import 'package:swms_finish_goods/shared/presentation/label_print_dialog.dart';
import 'package:swms_finish_goods/shared/presentation/pda_scan_route_aware.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Pallet Detail (Quick Scan → mã pallet).
//  Pallet ID = lot_no. Gồm: thẻ thông tin, hành động,
//  danh sách thùng, timeline lịch sử.
//  Là điểm vào của các màn con: Vị trí tạm · Lưu kho · Chuyển/Out ·
//  Tách pallet · Tìm thùng bị mất (chỉ truyền lotNo; các màn con
//  tự đọc thùng từ palletProvider).
//  "In lại tem" → dialog in tem pallet (chọn máy in + số bản).
//  App bar: "Cập nhật OQC" → đồng bộ OQC (part_cards / Foss) rồi nạp lại.
//
//  Quét tại màn này: mã trùng payload của dòng trong pallet.boxes
//  → mở thẳng Box Detail. Không trùng → toast báo.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class PalletDetailScreen extends ConsumerStatefulWidget {
  final String lotNo;

  const PalletDetailScreen({
    super.key,
    @PathParam('lotNo') required this.lotNo,
  });

  @override
  ConsumerState<PalletDetailScreen> createState() => _PalletDetailScreenState();
}

class _PalletDetailScreenState extends ConsumerState<PalletDetailScreen>
    with PdaScanRouteAware {
  bool _syncingOqc = false;

  @override
  Future<void> onScan(String data) async {
    final code = data.trim();
    if (code.isEmpty || !mounted) return;

    // Pallet chưa nạp xong (loading/error) → bỏ qua phát quét này.
    final pallet = ref.read(palletProvider(widget.lotNo)).value;
    if (pallet == null) return;

    final box = _findBoxByPayload(pallet, code);
    if (box == null) {
      return;
    }

    // Push → didPushNext tự ngưng nghe; pop về → didPopNext tự nghe lại.
    await context.router.push(BoxDetailRoute(boxId: box.id));
  }

  PalletBox? _findBoxByPayload(Pallet pallet, String code) {
    final key = code.toUpperCase();
    for (final box in pallet.boxes) {
      if (box.payload?.trim().toUpperCase() == key) return box;
    }
    return null;
  }

  /// Mã hiện dưới tiêu đề dialog in. Hàng back ghi kèm badge để người bấm In
  /// thấy trước là tem sắp ra có ký hiệu gì, trước khi tốn một tem để biết.
  String _labelSubtitle(Pallet pallet) {
    final badge = QrLabelData.badgeForDisposition(pallet.disposition);
    return badge == null ? pallet.lotNo : '${pallet.lotNo} · $badge';
  }

  Future<void> _onSyncOqc() async {
    setState(() => _syncingOqc = true);

    try {
      await ref.read(palletRepositoryProvider).syncOqc(widget.lotNo);
      ref.invalidate(palletProvider(widget.lotNo));

      if (mounted) {
        AppToastHelper.toastSuccess(
          context,
          LocaleKeys.pallet_oqc_success.tr(),
        );
      }
    } catch (_) {
      if (mounted) {
        AppToastHelper.toastError(context, LocaleKeys.pallet_oqc_error.tr());
      }
    } finally {
      if (mounted) setState(() => _syncingOqc = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final lotNo = widget.lotNo;
    final palletAsync = ref.watch(palletProvider(lotNo));

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.pallet_detail_title.tr(),
        subtitle: LocaleKeys.pallet_detail_subtitle.tr(),
        actions: [
          AppButton(
            label: LocaleKeys.pallet_oqc_title.tr(),
            isFullWidth: false,
            variant: AppButtonVariant.neutral,
            size: AppButtonSize.sm,
            onPressed: palletAsync.value == null || _syncingOqc
                ? null
                : _onSyncOqc,
          ),
        ],
      ),
      body: palletAsync.when(
        loading: () => const AppLoading(),
        error: (e, _) => AppErrorView.page(
          message: LocaleKeys.pallet_detail_load_error.tr(),
          onRetry: () => ref.invalidate(palletProvider(lotNo)),
        ),
        data: (pallet) => ListView(
          padding: const EdgeInsets.all(AppDimens.md),
          children: [
            PalletInfoCard(pallet: pallet),
            const SizedBox(height: AppDimens.md),
            PalletActionList(
              pallet: pallet,
              onMoveTemp: () =>
                  context.router.push(TempLocationRoute(lotNo: pallet.lotNo)),
              onSplit: () =>
                  context.router.push(SplitPalletRoute(lotNo: pallet.lotNo)),
              onStore: () =>
                  context.router.push(StoringRoute(lotNo: pallet.lotNo)),
              onWarehouseMove: () =>
                  context.router.push(WarehouseMoveRoute(lotNo: pallet.lotNo)),
              // Pallet hàng back phải in lại ĐÚNG badge RW / RB như tem gốc.
              // Thiếu badge thì tem in lại khác tem đang dán, và người đứng xa
              // không còn phân biệt được hàng back với hàng thường.
              onReprint: () => showLabelPrintDialog(
                context,
                title: LocaleKeys.label_print_title.tr(),
                subtitle: _labelSubtitle(pallet),
                label: QrLabelData.pallet(
                  pallet.lotNo,
                  badge: QrLabelData.badgeForDisposition(pallet.disposition),
                ),
              ),
            ),
            const SizedBox(height: AppDimens.md),
            PalletBoxList(
              boxes: pallet.boxes,
              onFindMissing: () =>
                  context.router.push(FindMissingBoxRoute(lotNo: pallet.lotNo)),
              onBoxTap: (box) =>
                  context.router.push(BoxDetailRoute(boxId: box.id)),
            ),
            const SizedBox(height: AppDimens.md),
            PalletHistoryTimeline(history: pallet.history),
          ],
        ),
      ),
    );
  }
}
