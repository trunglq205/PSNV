/// Xuất xứ hàng in trên Part Card.
///
/// - [code]: mã ISO 2 ký tự — chuỗi LƯU / in tem / gửi API (`Rows[].Origin`).
/// - [label]: tên đầy đủ — chỉ để hiển thị (dialog chọn, ô form).
/// - [aliases]: tên cũ còn gặp trong dữ liệu trước khi chuyển sang mã.
///
/// Thứ tự khai báo = thứ tự hiện trong dialog.
enum PartCardOrigin {
  china('CN', 'China'),
  germany('DE', 'Germany'),
  indonesia('ID', 'Indonesia'),
  japan('JP', 'Japan'),
  malaysia('MY', 'Malaysia'),
  philippines('PH', 'Philippines'),
  singapore('SG', 'Singapore'),
  southKorea('KR', 'South Korea', aliases: ['Korea']),
  taiwan('TW', 'Taiwan'),
  thailand('TH', 'Thailand'),
  usa('US', 'USA'),
  vietnam('VN', 'Vietnam');

  const PartCardOrigin(this.code, this.label, {this.aliases = const []});

  final String code;
  final String label;
  final List<String> aliases;

  static const PartCardOrigin defaultValue = PartCardOrigin.vietnam;

  /// Nhận mã (`vn`, `VN`), tên đầy đủ (`Vietnam`) hoặc alias (`Korea`).
  /// Không nhận ra → null.
  static PartCardOrigin? tryParse(String? value) {
    final v = value?.trim().toUpperCase();
    if (v == null || v.isEmpty) return null;

    for (final o in values) {
      if (o.code == v ||
          o.label.toUpperCase() == v ||
          o.aliases.any((a) => a.toUpperCase() == v)) {
        return o;
      }
    }
    return null;
  }

  /// Chuẩn hoá về mã 2 ký tự. Giá trị lạ → giữ nguyên (đã trim),
  /// không tự đoán để khỏi âm thầm sửa dữ liệu.
  static String normalize(String? value) =>
      tryParse(value)?.code ?? value?.trim() ?? '';

  /// Tên hiển thị cho một chuỗi origin đang lưu; lạ thì hiện nguyên.
  static String labelOf(String? value) =>
      tryParse(value)?.label ?? value?.trim() ?? '';
}