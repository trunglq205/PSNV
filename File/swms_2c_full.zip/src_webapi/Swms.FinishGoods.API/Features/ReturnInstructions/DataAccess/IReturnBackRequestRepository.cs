using Swms.FinishGoods.API.Features.ReturnInstructions.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

/// <summary>
/// Sổ yêu cầu back hàng (mục 2c). Tách interface riêng khỏi
/// <see cref="IReturnInstructionRepository"/> cho khỏi phình, nhưng CÙNG slice
/// vì cả hai đọc ghi <c>wms.return_instruction_serials</c> — sổ serial phải có
/// MỘT chủ, không để hai slice cùng sửa trạng thái serial.
/// </summary>
public interface IReturnBackRequestRepository
{
    Task<IReadOnlyList<ReturnBackRequest>> GetListAsync(BackRequestQuery query);

    Task<ReturnBackRequest?> GetByIdAsync(long id);

    /// <summary>Tạo yêu cầu + dòng trong một transaction. Trả id.</summary>
    Task<long> AddAsync(ReturnBackRequest req, string? user);

    /// <summary>Thay toàn bộ dòng của yêu cầu (xoá mềm cũ, chèn mới).</summary>
    Task UpdateLinesAsync(long id, string? note, IReadOnlyList<ReturnBackRequestLine> lines, string? user);

    /// <summary>
    /// Chuyển bước. Điều kiện bước hiện tại nằm TRONG câu UPDATE, không kiểm
    /// trước rồi mới ghi: hai người bấm duyệt cùng lúc thì người sau phải
    /// không ăn gì, chứ không phải cả hai cùng ghi.
    /// </summary>
    /// <returns><c>false</c> khi không có dòng nào khớp (ai đó đã đi trước).</returns>
    Task<bool> ApplyStepAsync(
        long id, string fromStep, string toStep, string toStatus,
        string actorColumnPrefix, string? comment, string? user);

    Task<bool> CancelAsync(long id, string? reason, string? user);

    /// <summary>
    /// B4 — gắp serial cho yêu cầu: với mỗi model lấy đủ <c>qty</c> con đang
    /// <c>received</c> và chưa thuộc lượt back nào, đóng dấu
    /// <c>back_request_id</c>, chuyển <c>at_fa</c>, đóng dấu <c>sent_fa_at</c>
    /// và XOÁ <c>pallet_id</c>.
    ///
    /// Vì sao xoá pallet_id: hàng rời kho SCS đi FA, pallet cũ không còn giữ
    /// nó. Để nguyên con trỏ cũ là bản đồ kho vẫn vẽ hàng ở chỗ không có hàng.
    ///
    /// Làm trong CÙNG transaction với bước duyệt: duyệt xong mà gắp hỏng thì
    /// yêu cầu ở trạng thái "đã cho back" nhưng không con serial nào đi — sai
    /// nguy hiểm hơn là không duyệt được.
    /// </summary>
    /// <returns>Số serial gắp được theo từng model.</returns>
    Task<IReadOnlyDictionary<string, int>> ApproveAndAssignAsync(
        long id, IReadOnlyList<ReturnBackRequestLine> lines, string? comment, string? user);

    /// <summary>SL còn gắp được theo model của một chỉ thị.</summary>
    Task<IReadOnlyList<BackAvailableModelResponse>> GetAvailableAsync(long docId);

    /// <summary>Model có thật trong chỉ thị (để chặn xin model lạ).</summary>
    Task<IReadOnlyList<string>> GetDocModelsAsync(long docId);
}
