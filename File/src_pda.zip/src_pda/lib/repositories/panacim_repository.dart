import 'package:injectable/injectable.dart';
import 'package:smart_warehouse/services/api_service.dart';
import '../services/models/request/ocr_check_request_model.dart';
import '../services/models/response/historycheckocrmodel.dart';

@injectable
class PanacimRepository{
  PanacimRepository(this._apiService);
  final ApiService _apiService;
  Future<String?> OCRCheck(OCRCheckRequestModel request) async {
    return _apiService.OCRCheck(request);
  }
  Future< List<HistoryCheckOcrModel> ?> GetHistoryCheck(String request) async {
    return _apiService.GetHistoryCheck( request: request);
  }

}