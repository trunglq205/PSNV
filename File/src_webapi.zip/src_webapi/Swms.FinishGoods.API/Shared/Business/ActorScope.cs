namespace Swms.FinishGoods.API.Common.Business;

/// <summary>
/// Người thực hiện cho code chạy NGOÀI request HTTP (job đồng bộ chạy nền).
///
/// Người dùng bấm nút -> API trả 202 ngay, job chạy tiếp sau khi request đã xong,
/// lúc đó không còn HttpContext -> ICurrentUser.FullName = null -> created_by,
/// updated_by, actor của stock event bị rỗng. SyncRunner lấy tên người bấm ngay
/// trong request rồi bọc job trong <c>using (ActorScope.Begin(actor)) { ... }</c>.
/// Sửa CurrentUser:
///
/// <code>
/// public string? FullName => ActorScope.Current ?? &lt;cách lấy từ HttpContext như cũ&gt;;
/// </code>
///
/// AsyncLocal đi theo await và Parallel.ForEachAsync nên mọi service tạo trong
/// job (kể cả scope con) đều thấy cùng actor.
/// </summary>
public static class ActorScope
{
    private static readonly AsyncLocal<string?> _actor = new();

    public static string? Current => _actor.Value;

    public static IDisposable Begin(string actor)
    {
        var previous = _actor.Value;
        _actor.Value = actor;
        return new Restore(previous);
    }

    private sealed class Restore(string? previous) : IDisposable
    {
        public void Dispose() => _actor.Value = previous;
    }
}
