import 'dart:io';

import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';

abstract class NgRepository {
  /// Danh sách phiếu. [day] lọc theo ngày phát hiện (null = mọi ngày).
  Future<List<NgReport>> fetchList({
    String? status,
    String? ngType,
    String? keyword,
    DateTime? day,
  });
  Future<NgDetail> fetchDetail(int id);

  /// Danh mục loại lỗi, nhãn đã theo ngôn ngữ đang chọn.
  Future<List<NgType>> fetchTypes();

  /// Tra pallet lúc quét. Ném lỗi nếu mã không có trong hệ thống.
  Future<NgPalletBrief> checkPallet(String code);

  /// Tạo phiếu nháp; trả id + số phiếu để tải ảnh lên ngay sau đó.
  Future<({int id, String docNo})> create({
    required String palletCode,
    required String ngType,
    required List<NgDraftItem> items,
    String? description,
  });

  Future<void> uploadPhoto(int id, File file);
}
