﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class MaterialDetailViewModel : TableViewModel<MaterialDetail, MaterialDetailFilter>
    {
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, MaterialDetailFilter? filter = null)
        {
            return new
            {
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }

    public class ImportMaterialDetailViewModel
    {
        public string Name { get; set; }
        public string Material { get; set; }
        public string Description { get; set; }
    }
}
