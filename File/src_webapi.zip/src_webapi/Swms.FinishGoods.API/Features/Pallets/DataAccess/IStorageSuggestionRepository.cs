using Swms.FinishGoods.API.Features.Pallets.Business.Entities;

namespace Swms.FinishGoods.API.Features.Pallets.DataAccess
{
    /// <summary>
    /// Truy vấn phục vụ gợi ý vị trí lưu kho. Tách khỏi ILotRepository vì đây là
    /// bài toán đọc thuần, đụng nhiều bảng master (locators / racks / locator_map)
    /// và sẽ còn được chỉnh riêng theo layout kho.
    /// </summary>
    public interface IStorageSuggestionRepository
    {
        /// <summary>Thông tin pallet + model đại diện. Null nếu không có / đã xoá.</summary>
        Task<PalletSuggestionContext?> GetPalletContextAsync(long palletId);

        /// <summary>Như trên nhưng tra theo mã quét (cột wms.pallets.pallet_id).</summary>
        Task<PalletSuggestionContext?> GetPalletContextByLotNoAsync(string lotNo);

        /// <summary>Cấu hình gợi ý của model trong master.models. Null nếu chưa khai báo model.</summary>
        Task<ModelStorageSuggestion?> GetModelSuggestionAsync(string modelCode);

        /// <summary>
        /// Lot gần nhất đã được lưu vào vị trí, khớp theo model (khi <paramref name="model"/> có giá trị)
        /// hoặc theo category. "Gần nhất" tính theo lần gán vị trí cuối cùng trong
        /// wms.locator_status_history, fallback về updated_at/created_at của pallet.
        /// </summary>
        Task<LastLotLocation?> FindLastLotAsync(
            long excludePalletId, string? model, int? categoryCode, long? areaId, string? areaCode);

        /// <summary>Các vị trí TRỐNG đã xếp hạng theo tiêu chí trong <paramref name="criteria"/>.</summary>
        Task<IReadOnlyList<LocatorCandidate>> FindFreeLocatorsAsync(LocatorSearchCriteria criteria);
    }
}
