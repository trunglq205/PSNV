import 'package:auto_route/auto_route.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/features/stocktake/presentation/pages/stocktake_list_page.dart';

/// Danh sách phiếu kiểm kê BUỔI SÁNG.
@RoutePage()
class StocktakeMorningPage extends StatelessWidget {
  const StocktakeMorningPage({super.key});
  @override
  Widget build(BuildContext context) => const StocktakeListPage(type: 'morning');
}

/// Danh sách phiếu kiểm kê CUỐI THÁNG.
@RoutePage()
class StocktakeMonthlyPage extends StatelessWidget {
  const StocktakeMonthlyPage({super.key});
  @override
  Widget build(BuildContext context) => const StocktakeListPage(type: 'monthly');
}

/// Danh sách phiếu kiểm kê SHIPMENT (chưa hỗ trợ — hiện màn placeholder).
@RoutePage()
class StocktakeShipmentPage extends StatelessWidget {
  const StocktakeShipmentPage({super.key});
  @override
  Widget build(BuildContext context) => const StocktakeListPage(type: 'shipment');
}
