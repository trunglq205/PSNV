using Swms.FinishGoods.Web.Features.ReturnInstructions.Business.Models;
using Swms.FinishGoods.Web.Features.ReturnInstructions.Client;
using Swms.FinishGoods.Web.Shared.Application.Models;
using Swms.FinishGoods.Web.Shared.Business.Base;

namespace Swms.FinishGoods.Web.Features.ReturnInstructions.Business;

public class ReturnBackRequestBusiness : BaseBusiness, IReturnBackRequestBusiness
{
    private readonly IReturnBackRequestApi _api;

    public ReturnBackRequestBusiness(IReturnBackRequestApi api,
        ILogger<ReturnBackRequestBusiness> logger, ErrorHandler errorHandler)
        : base(logger, errorHandler) => _api = api;

    public Task<Result<List<ReturnBackRequestDto>>> GetListAsync(
        long? docId = null, string? status = null, string? step = null, string? keyword = null)
        => ExecuteAsync(() => _api.GetListAsync(
            docId, Blank(status), Blank(step), Blank(keyword)));

    public Task<Result<ReturnBackRequestDto>> GetByIdAsync(long id)
        => ExecuteAsync(() => _api.GetByIdAsync(id));

    public Task<Result<List<BackAvailableModelDto>>> GetAvailableAsync(long docId)
        => ExecuteAsync(() => _api.GetAvailableAsync(docId));

    public Task<Result<List<BackDeliveryDto>>> GetDeliveriesAsync(long id)
        => ExecuteAsync(() => _api.GetDeliveriesAsync(id));

    public Task<Result<ReturnBackRequestDto>> CreateAsync(CreateBackRequestRequestDto request)
        => ExecuteAsync(() => _api.CreateAsync(request));

    public Task<Result<ReturnBackRequestDto>> UpdateAsync(
        long id, UpdateBackRequestRequestDto request)
        => ExecuteAsync(() => _api.UpdateAsync(id, request));

    public Task<Result<ReturnBackRequestDto>> ApproveFaAsync(long id, string? comment)
        => ExecuteAsync(() => _api.ApproveFaAsync(id, Decision(comment)));

    /// <summary>
    /// Chuẩn hoá danh sách mã NGAY TẠI ĐÂY: cắt khoảng trắng, bỏ ô rỗng, khử
    /// trùng không phân biệt hoa thường. Quét hai lần cùng một pallet là chuyện
    /// thường ở máy quét, và gửi trùng lên API thì nhật ký có hai dòng giống
    /// nhau với dòng thứ hai bằng 0 con.
    /// </summary>
    public Task<Result<BackDeliverResultDto>> DeliverAsync(
        long id, IEnumerable<string> lotNos, string? comment)
        => ExecuteAsync(() => _api.DeliverAsync(id, new DeliverBackRequestDto
        {
            LotNos = lotNos
                .Select(x => x?.Trim() ?? "")
                .Where(x => x.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList(),
            Comment = Blank(comment),
        }));

    public Task<Result<ReturnBackRequestDto>> CancelAsync(long id, string? reason)
        => ExecuteAsync(() => _api.CancelAsync(id, Decision(reason)));

    private static BackRequestDecisionRequestDto Decision(string? comment)
        => new() { Comment = Blank(comment) };

    /// <summary>
    /// Ô trống gửi lên thành NULL, không phải chuỗi rỗng: API phân biệt
    /// "không lọc" (null) với "lọc theo chuỗi rỗng" (không khớp gì).
    /// </summary>
    private static string? Blank(string? s) => string.IsNullOrWhiteSpace(s) ? null : s.Trim();
}
