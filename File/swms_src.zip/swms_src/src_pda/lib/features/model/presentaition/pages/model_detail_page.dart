import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/widgets/common/app_error_view.dart';
import 'package:swms_finish_goods/core/widgets/common/app_loading.dart';
import 'package:swms_finish_goods/core/widgets/common/app_top_bar.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_pick_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_toast_helper.dart';
import 'package:swms_finish_goods/features/model/presentaition/dialogs/model_edit_sheet.dart';
import 'package:swms_finish_goods/features/model/presentaition/dialogs/rack_row_pick_dialog.dart';
import 'package:swms_finish_goods/features/model/presentaition/providers/model_detail_notifier.dart';
import 'package:swms_finish_goods/features/model/presentaition/widgets/model_info_card.dart';
import 'package:swms_finish_goods/features/model/presentaition/widgets/model_stacking_card.dart';
import 'package:swms_finish_goods/features/model/presentaition/widgets/model_suggestion_card.dart';
import 'package:swms_finish_goods/features/storage_map/domain/entities/storage_map_entities.dart';
import 'package:swms_finish_goods/features/storage_map/presentation/providers/storage_map_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Model Detail. Định danh bằng modelId (master.models.id).
//  Quick Scan resolve code / GTIN → id trước khi điều hướng vào đây.
// ─────────────────────────────────────────────────────────────

@RoutePage()
class ModelDetailScreen extends ConsumerWidget {
  final int modelId;

  const ModelDetailScreen({
    super.key,
    @PathParam('modelId') required this.modelId,
  });

  Future<void> _edit(BuildContext context, WidgetRef ref) async {
    final model = ref.read(modelDetailProvider(modelId)).detail.value;
    if (model == null) return;

    final result = await showModelEditSheet(context, model: model);
    if (result == null) return;

    // Mutation → overlay toàn màn + error message tập trung.
    await ref
        .read(appActionProvider.notifier)
        .run(
          () => ref
          .read(modelDetailProvider(modelId).notifier)
          .updateModel(result),
    );
  }

  /// Chọn khu gợi ý từ danh sách khu lưu trữ (storageAreasProvider —
  /// dùng chung với màn Storage Map, type = 'storing').
  Future<void> _editArea(BuildContext context, WidgetRef ref) async {
    final model = ref.read(modelDetailProvider(modelId)).detail.value;
    if (model == null) return;

    final List<WarehouseArea> areas;
    try {
      areas = await ref.read(storageAreasProvider.future);
    } catch (_) {
      if (context.mounted) {
        AppToastHelper.toastError(
          context,
          'model_detail.areas_load_error'.tr(),
        );
      }
      return;
    }
    if (!context.mounted) return;

    final current = areas.where((a) => a.id == model.suggestAreaId);
    final picked = await showPickDialog<WarehouseArea>(
      context,
      title: 'model_detail.suggest_area'.tr(),
      items: areas,
      labelOf: (a) => '${a.areaCode} · ${a.areaName}',
      selected: current.isEmpty ? null : current.first,
    );
    if (picked == null) return;

    await ref
        .read(appActionProvider.notifier)
        .run(
          () => ref
          .read(modelDetailProvider(modelId).notifier)
          .updateSuggestArea(
        id: picked.id,
        code: picked.areaCode,
        name: picked.areaName,
      ),
    );
  }

  Future<void> _editRackRows(BuildContext context, WidgetRef ref) async {
    final model = ref.read(modelDetailProvider(modelId)).detail.value;
    if (model == null) return;

    final result = await showRackRowPickDialog(
      context,
      selected: model.suggestRackRow,
    );
    if (result == null) return;

    // Mutation → overlay toàn màn + error message tập trung.
    await ref
        .read(appActionProvider.notifier)
        .run(
          () => ref
          .read(modelDetailProvider(modelId).notifier)
          .updateRackRows(result),
    );
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(modelDetailProvider(modelId));
    final notifier = ref.read(modelDetailProvider(modelId).notifier);

    return Scaffold(
      appBar: AppTopBar(
        title: 'model_detail.title'.tr(),
        subtitle: 'model_detail.subtitle'.tr(),
        actions: [
          IconButton(
            icon: const Icon(Icons.edit_outlined),
            tooltip: 'model_detail.edit'.tr(),
            // Chưa tải xong / đang lỗi thì chưa có gì để sửa.
            onPressed: state.detail.hasValue
                ? () => _edit(context, ref)
                : null,
          ),
        ],
      ),
      body: state.detail.when(
        loading: () => const AppLoading(),
        error: (e, _) => AppErrorView.page(
          message: 'model_detail.load_error'.tr(),
          onRetry: notifier.load,
        ),
        data: (model) => ListView(
          padding: const EdgeInsets.all(AppDimens.md),
          children: [
            ModelInfoCard(model: model),
            const SizedBox(height: AppDimens.md),
            ModelStackingCard(model: model),
            const SizedBox(height: AppDimens.md),
            ModelSuggestionCard(
              model: model,
              onEditArea: () => _editArea(context, ref),
              onEditRackRows: () => _editRackRows(context, ref),
            ),
          ],
        ),
      ),
    );
  }
}