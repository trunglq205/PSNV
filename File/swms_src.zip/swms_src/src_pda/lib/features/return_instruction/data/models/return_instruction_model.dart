import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';

part 'return_instruction_model.g.dart';

/// KHÔNG dùng `fieldRename: FieldRename.snake` — API để nguyên chính sách đặt
/// tên mặc định của ASP.NET Core, tức camelCase. Khai snake thì code sinh ra
/// đọc `json['doc_no']` trong khi server gửi `docNo`, field luôn rỗng mà
/// không báo lỗi gì (đúng cái bẫy đã dính ở `stocky_cart_model.dart`).
@JsonSerializable()
class ReturnInstructionModel {
  final int id;
  final String docNo;
  final String? goodsType;
  final String? customer;
  final DateTime? expectedDate;
  final String? docStatus;
  final String? note;
  final int modelCount;
  final int totalQty;
  final int receivedQty;
  final bool overReceived;
  final bool shortReceived;
  final int diffQty;
  final DateTime? closedAt;
  final String? closedBy;
  final DateTime? actualMailSentAt;
  final DateTime? createdAt;
  final String? createdBy;
  final List<ReturnInstructionLineModel> lines;

  const ReturnInstructionModel({
    required this.id,
    required this.docNo,
    this.goodsType,
    this.customer,
    this.expectedDate,
    this.docStatus,
    this.note,
    this.modelCount = 0,
    this.totalQty = 0,
    this.receivedQty = 0,
    this.overReceived = false,
    this.shortReceived = false,
    this.diffQty = 0,
    this.closedAt,
    this.closedBy,
    this.actualMailSentAt,
    this.createdAt,
    this.createdBy,
    this.lines = const [],
  });

  factory ReturnInstructionModel.fromJson(Map<String, dynamic> json) =>
      _$ReturnInstructionModelFromJson(json);
  Map<String, dynamic> toJson() => _$ReturnInstructionModelToJson(this);

  ReturnInstruction toEntity() => ReturnInstruction(
        id: id,
        docNo: docNo,
        goodsType: ReturnGoodsType.fromCode(goodsType),
        customer: customer,
        expectedDate: expectedDate,
        status: ReturnDocStatus.fromCode(docStatus),
        note: note,
        modelCount: modelCount,
        totalQty: totalQty,
        receivedQty: receivedQty,
        overReceived: overReceived,
        shortReceived: shortReceived,
        diffQty: diffQty,
        closedAt: closedAt,
        closedBy: closedBy,
        actualMailSentAt: actualMailSentAt,
        createdAt: createdAt,
        createdBy: createdBy,
        lines: lines.map((e) => e.toEntity()).toList(),
      );
}

@JsonSerializable()
class ReturnInstructionLineModel {
  final int lineNo;
  final String model;
  final int qty;
  final int receivedQty;
  final int remainingQty;
  final int diffQty;
  final String? note;

  const ReturnInstructionLineModel({
    required this.lineNo,
    required this.model,
    this.qty = 0,
    this.receivedQty = 0,
    this.remainingQty = 0,
    this.diffQty = 0,
    this.note,
  });

  factory ReturnInstructionLineModel.fromJson(Map<String, dynamic> json) =>
      _$ReturnInstructionLineModelFromJson(json);
  Map<String, dynamic> toJson() => _$ReturnInstructionLineModelToJson(this);

  ReturnInstructionLine toEntity() => ReturnInstructionLine(
        lineNo: lineNo,
        model: model,
        qty: qty,
        receivedQty: receivedQty,
        remainingQty: remainingQty,
        diffQty: diffQty,
        note: note,
      );
}
