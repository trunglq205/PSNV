﻿namespace SWMS_WebTool.Models
{
    public class InventoryForm
    {
        public string Material { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public string Description { get; set; }
        public string PositionKitting { get; set; }
        public double QtySystem { get; set; }
        public double QtySWMS { get => QtyTemp + QtyStore +QtyKitting; }
        public double DiffQuantity { get => QtySystem - QtySWMS; }
        public double QtyReCheck { get; set; }
        public string ReMark { get; set; }
        public double QtyBalance { get; set; }
        public string TypeKitting { get; set; }
        public double StandardPrice { get; set; }
        public double Amount { get => Math.Round(QtySystem * StandardPrice, 2); }
        public bool IsConfirm { get; set; }
        public double QtyTemp { get; set; }
        public double QtyKitting { get; set; }
        public double QtyStore { get; set; }
        public double QtyInventoryPlant { get; set; }
        public DateTime DateUploadSap { get; set; }
        public List<BalanceBox> Details { get; set; }
    }
    public class BalanceBox
    {
        public Int64 ID { get; set; }
        public string Barcode { get; set; }
        public int? Qty { get; set; }
        public string Material { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public bool IsManual { get; set; }
    }
}
