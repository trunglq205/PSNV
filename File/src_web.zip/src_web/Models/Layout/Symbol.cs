﻿namespace SWMS_WebTool.Models.Layout
{
    public abstract class Symbol : Widget {
        public Symbol() { }

        protected Symbol(KonvaObject konvaObject) : base(konvaObject) { }
        protected override KonvaClassType ClassName => KonvaClassType.Image;

    }

    public class Arrow : Symbol
    {
        public Arrow() { }
        public Arrow(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type  => WidgetType.Arrow;
    }

    public class ArrowFill : Symbol
    {
        public ArrowFill() { }

        public ArrowFill(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type { get => WidgetType.ArrowFill; }
    }

    public class Folklift : Symbol
    {
        public Folklift() { }

        public Folklift(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type { get => WidgetType.Folklift; }
    }

    public class FolkliftWorking : Symbol
    {
        public FolkliftWorking() { }

        public FolkliftWorking(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type { get => WidgetType.FolkliftWorking; }
    }

    public class Container : Symbol
    {
        public Container() { }

        public Container(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type { get => WidgetType.Container; }
    }
    public class Folklift2 : Symbol
    {
        public Folklift2() { }

        public Folklift2(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type { get => WidgetType.Folklift2; }
    }

    public class Container2 : Symbol
    {
        public Container2() { }

        public Container2(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type { get => WidgetType.Container2; }
    }

    public class Pallet : Symbol
    {
        public Pallet() { }

        public Pallet(KonvaObject konvaObject) : base(konvaObject)
        {
        }

        public override WidgetType Type { get => WidgetType.Pallet; }
    }
}
