using Microsoft.Extensions.DependencyInjection.Extensions;
using Swms.FinishGoods.API.Features.Inventory.Business;
using Swms.FinishGoods.API.Features.Inventory.DataAccess;

namespace Swms.FinishGoods.API.Features.Inventory
{
    public static class InventoryModule
    {
        public static IServiceCollection AddInventoryFeature(this IServiceCollection services)
        {
            services.AddScoped<IInventoryService, InventoryService>();
            services.AddScoped<IInventoryRepository, InventoryRepository>();
            return services;
        }
    }
}
