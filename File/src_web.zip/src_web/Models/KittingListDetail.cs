﻿using System.ComponentModel;
using System.Runtime.Serialization;

namespace SWMS_WebTool.Models
{
    public enum KittingDetailStatus
    {
        [EnumMember(Value = "0")]
        Kitting = 0,
        [EnumMember(Value = "2")]
        Supplied = 2,
        [EnumMember(Value = "1")]
        Checked = 1
    }
    public class KittingListDetail
    {
        public Int64? ID { get; set; }
        public Int64? KittingListID { get; set; }
        public string? MaterialReplace { get; set; }
        public int? QuantityReplace { get; set; }
        public string? Material { get; set; }
        public double? Quantity { get; set; }
        public double? PickedQuantity { get; set; }
        public string? Unit { get; set; }
        public string? Sloc { get; set; }
        public string? Descriptions { get; set; }
        public string? LocationName { get; set; }
        public string? PicUser { get; set; }
        public string? Barcode { get; set; }
        public KittingDetailStatus? KittingStatus { get; set; }
        public byte? SupplyStatus { get; set; }
        public string? KittingTimeType { get; set; }
        public byte? KittingType { get; set; }
        public string? Model { get; set; }
        public string? Time { get; set; }
        public string? Line { get; set; }
        public string? Frequency { get; set; }
        public string? PositionFA { get; set; }
        public double? AssemblyQuantity { get; set; }
        public double? MaterialQuantity { get; set; }
        public string? ReceiptSloc { get; set; }
        public string? PSNVStock { get; set; }
        public string? KHFAN7 { get; set; }
        public string? VenderName { get; set; }
        public string? Tcode { get; set; }
        public string? Category { get; set; }
        public string? KittingFrom { get; set; }
        public string? PullID { get; set; }
        public string? PL { get; set; }
        public string? PositionJPT { get; set; }
        public string? MaterialType { get; set; }
        public string? Plant { get; set; }
        public string? Remark { get; set; }
        public int? CountQtyKittingEnough { get; set; }
        public DateTime? DeliveryDate { get; set; }
    }
    //Tuấn Anh thêm
    public class KittingListDetailForKitting
    {
        public Int64? ID { get; set; }
        public Int64? KittingListID { get; set; }
        public string? MaterialReplace { get; set; }
        public int? QuantityReplace { get; set; }
        public string? Material { get; set; }
        public double? Quantity { get; set; }
        public double? PickedQuantity { get; set; }
        public string? Unit { get; set; }
        public string? Sloc { get; set; }
        public string? Descriptions { get; set; }
        public string? LocationName { get; set; }
        public string? PicUser { get; set; }
        public string? Barcode { get; set; }
        public KittingDetailStatus? KittingStatus { get; set; }
        public byte? SupplyStatus { get; set; }
        public string? KittingTimeType { get; set; }
        public byte? KittingType { get; set; }
        public string? Model { get; set; }
        public string? Time { get; set; }
        public string? Line { get; set; }
        public string? Frequency { get; set; }
        public string? PositionFA { get; set; }
        public double? AssemblyQuantity { get; set; }
        public double? MaterialQuantity { get; set; }
        public string? ReceiptSloc { get; set; }
        public string? PSNVStock { get; set; }
        public string? KHFAN7 { get; set; }
        public string? VenderName { get; set; }
        public string? Tcode { get; set; }
        public string? Category { get; set; }
        public string? KittingFrom { get; set; }
        public string? PullID { get; set; }
        public string? PL { get; set; }
        public string? PositionJPT { get; set; }
        public string? MaterialType { get; set; }
        public string? Plant { get; set; }
        public string? Remark { get; set; }
        public int? CountQtyKittingEnough { get; set; }
        public DateTime? DeliveryDate { get; set; }
    }
}
