﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;

namespace SWMS_WebTool.Utils.Extensions
{
    public static class SessionExtensions
    {
        // Lưu đối tượng vào session dưới dạng JSON
        public static void SetObject(this ISession session, string key, object value)
        {
            var settings = new JsonSerializerSettings();
            settings.Converters.Add(new StringEnumConverter()); // Sử dụng StringEnumConverter
            var json = JsonConvert.SerializeObject(value, settings);
            session.SetString(key, json);
        }

        // Lấy đối tượng từ session và chuyển đổi từ JSON
        public static T GetObject<T>(this ISession session, string key)
        {
            var json = session.GetString(key);
            if (json == null)
                return default(T);

            var settings = new JsonSerializerSettings();
            settings.Converters.Add(new StringEnumConverter()); // Sử dụng StringEnumConverter
            return JsonConvert.DeserializeObject<T>(json, settings);
        }
    }
}
