// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'part_card_response_model.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

PartCardRowResponseModel _$PartCardRowResponseModelFromJson(
  Map<String, dynamic> json,
) => PartCardRowResponseModel(
  g21Part: json['g21Part'] as String?,
  model: json['model'] as String?,
  innerBox: json['innerBox'] as String?,
  qty: (json['qty'] as num?)?.toInt(),
  origin: json['origin'] as String?,
  oqcChecked: json['oqcChecked'] as bool?,
  innerLength: (json['innerLength'] as num?)?.toDouble(),
  innerWidth: (json['innerWidth'] as num?)?.toDouble(),
  innerHeight: (json['innerHeight'] as num?)?.toDouble(),
  innerWeight: (json['innerWeight'] as num?)?.toDouble(),
);

Map<String, dynamic> _$PartCardRowResponseModelToJson(
  PartCardRowResponseModel instance,
) => <String, dynamic>{
  'g21Part': ?instance.g21Part,
  'model': ?instance.model,
  'innerBox': ?instance.innerBox,
  'qty': ?instance.qty,
  'origin': ?instance.origin,
  'oqcChecked': ?instance.oqcChecked,
  'innerLength': ?instance.innerLength,
  'innerWidth': ?instance.innerWidth,
  'innerHeight': ?instance.innerHeight,
  'innerWeight': ?instance.innerWeight,
};

PartCardResponseModel _$PartCardResponseModelFromJson(
  Map<String, dynamic> json,
) => PartCardResponseModel(
  id: (json['id'] as num?)?.toInt(),
  poNo: json['poNo'] as String?,
  customerPoNo: json['customerPoNo'] as String?,
  productionDate: json['productionDate'] == null
      ? null
      : DateTime.parse(json['productionDate'] as String),
  packer: json['packer'] as String?,
  checker: json['checker'] as String?,
  category: (json['category'] as num?)?.toInt(),
  model: json['model'] as String?,
  qty: (json['qty'] as num?)?.toInt(),
  origin: json['origin'] as String?,
  length: (json['length'] as num?)?.toDouble(),
  width: (json['width'] as num?)?.toDouble(),
  height: (json['height'] as num?)?.toDouble(),
  weight: (json['weight'] as num?)?.toDouble(),
  isOverseaService: json['isOverseaService'] as bool?,
  rows: (json['rows'] as List<dynamic>?)
      ?.map((e) => PartCardRowResponseModel.fromJson(e as Map<String, dynamic>))
      .toList(),
  printedAt: json['printedAt'] == null
      ? null
      : DateTime.parse(json['printedAt'] as String),
  printedBy: json['printedBy'] as String?,
);

Map<String, dynamic> _$PartCardResponseModelToJson(
  PartCardResponseModel instance,
) => <String, dynamic>{
  'id': ?instance.id,
  'poNo': ?instance.poNo,
  'customerPoNo': ?instance.customerPoNo,
  'productionDate': ?instance.productionDate?.toIso8601String(),
  'packer': ?instance.packer,
  'checker': ?instance.checker,
  'category': ?instance.category,
  'model': ?instance.model,
  'qty': ?instance.qty,
  'origin': ?instance.origin,
  'length': ?instance.length,
  'width': ?instance.width,
  'height': ?instance.height,
  'weight': ?instance.weight,
  'isOverseaService': ?instance.isOverseaService,
  'rows': ?instance.rows,
  'printedAt': ?instance.printedAt?.toIso8601String(),
  'printedBy': ?instance.printedBy,
};

PartCardHistoryPageModel _$PartCardHistoryPageModelFromJson(
  Map<String, dynamic> json,
) => PartCardHistoryPageModel(
  items: (json['items'] as List<dynamic>?)
      ?.map((e) => PartCardResponseModel.fromJson(e as Map<String, dynamic>))
      .toList(),
  total: (json['total'] as num?)?.toInt(),
);

Map<String, dynamic> _$PartCardHistoryPageModelToJson(
  PartCardHistoryPageModel instance,
) => <String, dynamic>{'items': ?instance.items, 'total': ?instance.total};
