﻿namespace Swms.FinishGoods.API.Features.OqcSamples.Business.Entities
{
    /// <summary>
    /// Mã trạng thái OQC (part_cards.Status_OQC). Card 4/5 là kết quả cuối, không ghi đè.
    /// </summary>
    public static class OqcStatusCode
    {
        public const byte Initial = 0; // chưa kiểm (mặc định khi in card)
        public const byte Sampling = 2; // đang lấy mẫu
        public const byte PendingResult = 3; // đã trả, chờ kết quả
        public const byte Ng = 4; // fail (kết quả cuối)
        public const byte Pass = 5; // ok   (kết quả cuối)

        public static bool IsFinal(int s) => s is Ng or Pass;

        /// <summary>Map chuỗi 'status' (update-status) → mã. Null nếu không hợp lệ.</summary>
        public static byte? FromString(string? s) => (s ?? "").Trim().ToLowerInvariant() switch
        {
            "ok" or "pass" or "ok_lot" => Pass,
            "ng" or "ng_lot" => Ng,
            "sample" or "sampling" or "dang_kiem" => Sampling,
            "reset" or "not_inspected" => Initial,
            _ => null,
        };
    }

    /// <summary>Kết quả tra vị trí/pallet cho get-locations.</summary>
    public sealed record PalletLocationResult(string PalletId, string? Locator);
}