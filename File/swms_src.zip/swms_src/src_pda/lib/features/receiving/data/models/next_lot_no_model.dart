import 'package:json_annotation/json_annotation.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/lot_entities.dart';

part 'next_lot_no_model.g.dart';

/// Response của GET /api/pallets/next-lot-no.
/// Server trả lotNo = <category:3><yymmdd:6><seq:3> + các phần tách sẵn.
@JsonSerializable()
class NextLotNoModel {
  final String lotNo;
  final int categoryCode;
  final String datePart;
  final int sequence;

  const NextLotNoModel({
    required this.lotNo,
    required this.categoryCode,
    required this.datePart,
    required this.sequence,
  });

  factory NextLotNoModel.fromJson(Map<String, dynamic> json) =>
      _$NextLotNoModelFromJson(json);

  NextLotNo toEntity() => NextLotNo(
    lotNo: lotNo,
    categoryCode: categoryCode,
    datePart: datePart,
    sequence: sequence,
  );
}