using Microsoft.Extensions.Localization;
using Swms.FinishGoods.Api.Features.Roles.Api;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Business.Models;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.Api.Features.Roles.DataAccess;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess; // NotFound/Conflict/BusinessRule

namespace Swms.FinishGoods.Api.Features.Roles.Business;

public class RoleService : IRoleService
{
    private static readonly string[] ValidDots = { "danger", "warning", "info", "success", "dim" };

    private readonly IRoleRepository _repo;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;

    /// <summary>
    /// Vô hiệu bộ đệm quyền sau khi sửa. Thiếu nó thì quyền vừa cấp phải chờ
    /// tới 5 phút mới có tác dụng, trong khi MENU VÀ NÚT HIỆN RA NGAY (AuthController
    /// trả quyền đọc thẳng từ DB) — người dùng vào được màn hình rồi ăn 403.
    /// Đăng xuất đăng nhập lại không chữa được, vì khoá đệm theo user id.
    /// </summary>
    private readonly PermissionCacheVersion _permVersion;

    public RoleService(
        IRoleRepository repo,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        PermissionCacheVersion permVersion)
    {
        _repo = repo;
        _currentUser = currentUser;
        _localizer = localizer;
        _permVersion = permVersion;
    }

    // ─────────────────────────── Catalog ───────────────────────────
    // Nguồn cấu trúc = PermissionCatalog (C#). Tên = resx theo culture hiện tại.

    public Task<List<PermissionModuleResponse>> GetPermissionCatalogAsync()
    {
        var result = PermissionCatalog.Modules.Select(m =>
            new PermissionModuleResponse(
                m.Code,
                Localize(m.NameKey, m.Code),
                m.Screens.Select(s =>
                    new PermissionScreenResponse(
                        s.Code,
                        Localize(s.NameKey, s.Code),
                        s.Permissions.Select(p =>
                            new PermissionItemResponse(
                                p.Action,
                                p.Code,
                                Localize(p.NameKey, p.Action))
                        ).ToList())
                ).ToList())
        ).ToList();

        return Task.FromResult(result);
    }

    // ─────────────────────────── Roles ───────────────────────────

    public async Task<List<RoleResponse>> GetRolesAsync()
    {
        var roles = await _repo.GetAllAsync();

        // ★ Role hệ thống (IsSystem) ⟹ trả TẤT CẢ quyền theo catalog,
        //   không phụ thuộc role_permissions gán thủ công trong DB.
        foreach (var role in roles.Where(r => r.IsSystem))
        {
            role.Permissions = PermissionCatalog.AllCodes
                .OrderBy(c => c, StringComparer.OrdinalIgnoreCase)
                .ToList();
        }

        return roles.Select(RoleResponse.From).ToList();
    }

    public async Task<RoleResponse> CreateRoleAsync(CreateRoleRequest request)
    {
        var code = NormalizeCode(request.Code);
        var name = request.Name.Trim();
        var dot = NormalizeDot(request.Dot);
        if (await _repo.CodeExistsAsync(code))
            throw new ConflictException(_localizer["Role.CodeExists", code]);
        var permCodes = new List<string>();
        if (!string.IsNullOrWhiteSpace(request.CloneFromCode))
        {
            var src = await _repo.GetByCodeAsync(NormalizeCode(request.CloneFromCode))
                      ?? throw new NotFoundException(
                          _localizer["Role.NotFound", request.CloneFromCode!]);

            // Clone từ role hệ thống ⟹ quyền của nó là full catalog (DB không lưu),
            // nên phải lấy từ PermissionCatalog thay vì src.Permissions (sẽ rỗng).
            permCodes = src.IsSystem
                ? PermissionCatalog.AllCodes.ToList()
                : src.Permissions;
        }
        var permIds = await ResolvePermissionIdsAsync(permCodes);
        var entity = new Role
        {
            Code = code,
            Name = name,
            Description = request.Description?.Trim() ?? "",
            Dot = dot,
            IsSystem = false,
            Permissions = permCodes,
        };
        await _repo.AddAsync(entity, permIds, Actor);
        var created = await _repo.GetByCodeAsync(code);
        return RoleResponse.From(created!);
    }

    public async Task UpdateRoleAsync(UpdateRoleRequest request)
    {
        var currentCode = NormalizeCode(request.Code);
        var newCode = NormalizeCode(request.NewCode);

        var role = await _repo.GetByCodeAsync(currentCode)
                   ?? throw new NotFoundException(_localizer["Role.NotFound", request.Code]);

        if (role.IsSystem)
            throw new BusinessRuleException(_localizer["Role.SystemLocked", role.Code]);

        if (!string.Equals(currentCode, newCode, StringComparison.OrdinalIgnoreCase)
            && await _repo.CodeExistsAsync(newCode))
            throw new ConflictException(_localizer["Role.CodeExists", newCode]);

        role.Code = newCode;
        role.Name = request.Name.Trim();
        role.Description = request.Description?.Trim() ?? "";
        role.Dot = NormalizeDot(request.Dot);

        await _repo.UpdateAsync(currentCode, role, Actor);
    }

    public async Task UpdateRolePermsAsync(UpdateRolePermsRequest request)
    {
        var code = NormalizeCode(request.Code);
        var role = await _repo.GetByCodeAsync(code)
                   ?? throw new NotFoundException(_localizer["Role.NotFound", request.Code]);

        if (role.IsSystem)
            throw new BusinessRuleException(_localizer["Role.SystemLocked", role.Code]);

        var permIds = await ResolvePermissionIdsAsync(request.Permissions ?? new());
        await _repo.ReplacePermissionsAsync(code, permIds, Actor);

        // Quyền của role vừa đổi ⇒ bộ đệm của MỌI user mang role này đã sai.
        _permVersion.Bump();
    }

    public async Task DeleteRoleAsync(string code)
    {
        var normalized = NormalizeCode(code);
        var role = await _repo.GetByCodeAsync(normalized)
                   ?? throw new NotFoundException(_localizer["Role.NotFound", code]);

        if (role.IsSystem)
            throw new BusinessRuleException(_localizer["Role.SystemLocked", role.Code]);

        if (role.UserCount > 0)
            throw new BusinessRuleException(_localizer["Role.HasUsers", role.UserCount]);

        await _repo.SoftDeleteAsync(normalized);
    }

    // ─────────────────────────── /api/me ───────────────────────────

    public async Task<List<string>> GetMyPermissionsAsync()
    {
        var userId = _currentUser.UserId;

        if (userId == null) throw new UnauthorizedAccessException();

        long uid = userId.Value;

        // System role ⟹ toàn quyền theo catalog (nguồn sự thật C#)
        if (await _repo.UserHasSystemRoleAsync(uid))
            return PermissionCatalog.AllCodes.OrderBy(c => c).ToList();

        return (await _repo.GetEffectivePermissionsForUserAsync(uid))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .OrderBy(c => c)
            .ToList();
    }

    // ─────────────────────────── helpers ───────────────────────────

    private string Actor => _currentUser.FullName ?? "";

    /// <summary>Tra resx; nếu thiếu key thì fallback về <paramref name="fallback"/> (thường là code).</summary>
    private string Localize(string key, string fallback)
    {
        var s = _localizer[key];
        return s.ResourceNotFound ? fallback : s.Value;
    }

    private static string NormalizeCode(string code) =>
        code.Trim().ToLowerInvariant();

    private static string NormalizeDot(string? dot)
    {
        var d = (dot ?? "info").Trim().ToLowerInvariant();
        return ValidDots.Contains(d) ? d : "info";
    }

    /// <summary>
    /// Map code quyền → id. Validate 2 lớp:
    ///   1) code phải có trong PermissionCatalog (nguồn sự thật).
    ///   2) code phải tồn tại trong DB (đã sync) để lấy id gán FK.
    /// </summary>
    private async Task<List<long>> ResolvePermissionIdsAsync(List<string> permCodes)
    {
        var codes = permCodes
            .Where(c => !string.IsNullOrWhiteSpace(c))
            .Select(c => c.Trim())
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (codes.Count == 0) return new();

        // Lớp 1: đối chiếu catalog
        var notInCatalog = codes.Where(c => !PermissionCatalog.IsValid(c)).ToList();
        if (notInCatalog.Count > 0)
            throw new BusinessRuleException(
                _localizer["Role.UnknownPermissions", string.Join(", ", notInCatalog)]);

        // Lớp 2: lấy id từ DB
        var map = await _repo.GetPermissionIdsByCodesAsync(codes);
        var notInDb = codes.Where(c => !map.ContainsKey(c)).ToList();
        if (notInDb.Count > 0)
            throw new BusinessRuleException(
                _localizer["Role.PermissionNotSynced", string.Join(", ", notInDb)]);

        return map.Values.ToList();
    }
}
