﻿namespace SWMS_WebTool.Models.ImportModel
{
    public class DAImport
    {
        /// <summary>
        /// DANo
        /// </summary>
        public string? DANo { get; set; }
        /// <summary>
        /// LotNo
        /// </summary>
        public string? LotNo { get; set; }
        /// <summary>
        /// DADate
        /// </summary>
        public string? DADate { get; set; }
        /// <summary>
        /// VendorCode
        /// </summary>
        public string? VendorCode { get; set; }

        public List<DADetailImport>? DADetails { get; set; }

    }
}
