using Swms.FinishGoods.API.Features.ReturnInstructions.Api;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

/// <summary>
/// Luồng nhận lại hàng về FA (mục 2c) — BA bước trên chính phiếu chỉ thị:
///   B1 FA đề nghị              (không mail)
///   B2 quản lý FA xác nhận     → mail TO SCS Office, CC FA
///   B3 SCS WH quét pallet giao → mail TO FA, CC SCS
///
/// Mọi hàm trả về <see cref="BackFlowResponse"/> đã nạp lại từ DB, không phải
/// bản ghép từ tham số đầu vào: bốn con số đếm từ sổ serial nên chỉ có đọc lại
/// mới ra số đúng sau khi ghi.
/// </summary>
public interface IReturnBackFlowService
{
    /// <summary>
    /// SL còn ở kho theo model — màn đề nghị gọi để CHO XEM phần sẽ lấy về.
    /// Không phải để nhập: đã đề nghị là lấy hết.
    /// </summary>
    Task<IReadOnlyList<BackRemainModelResponse>> GetRemainAsync(long docId);

    /// <summary>Nhật ký pallet đã giao, mới nhất trước.</summary>
    Task<IReadOnlyList<BackDeliveryResponse>> GetDeliveriesAsync(long docId);

    /// <summary>B1 — FA đề nghị nhận lại hàng. KHÔNG gửi mail.</summary>
    Task<BackFlowResponse> RequestAsync(long docId, RequestBackRequest request);

    /// <summary>Sửa ghi chú, chỉ khi còn chờ quản lý FA xác nhận.</summary>
    Task<BackFlowResponse> UpdateNoteAsync(long docId, RequestBackRequest request);

    /// <summary>
    /// B2 — quản lý FA xác nhận. Gửi mail TO SCS Office, CC FA. Sau bước này
    /// SCS Office tự thông báo cho SCS WH ngoài hệ thống.
    /// </summary>
    Task<BackFlowResponse> ApproveAsync(long docId, BackDecisionRequest request);

    /// <summary>
    /// B3 — quản lý SCS xác nhận (thêm 10/11). Sau bước này SCS WH mới được
    /// tách Pallet ID và quét giao. Không gửi mail.
    /// </summary>
    Task<BackFlowResponse> ScsApproveAsync(long docId, BackDecisionRequest request);

    // B4 — giao hàng cho FA: KHÔNG CÒN HÀM NÀO Ở ĐÂY (bỏ 11/11).
    //
    // Mốc chuyển serial sang at_fa giờ nằm ở Business/ReturnBackMoveGate.cs,
    // chạy trong transaction đổi vị trí pallet: đặt pallet vào một vị trí thuộc
    // bản đồ Nhận hàng CHÍNH LÀ hành động giao. Không có hàm giao hàng nào ở
    // service này nữa, để không tồn tại đường giao hàng nào bỏ qua vị trí kho —
    // và do đó bỏ qua cổng duyệt của quản lý SCS.

    /// <summary>Huỷ — chỉ khi chưa giao con nào.</summary>
    Task<BackFlowResponse> CancelAsync(long docId, BackDecisionRequest request);
}
