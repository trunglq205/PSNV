import 'dart:io';
import 'dart:typed_data';

import 'package:dio/dio.dart';
import 'package:dio/io.dart';
import 'package:swms_finish_goods/core/network/auth_interceptor.dart';
import 'package:swms_finish_goods/core/network/compact_log_interceptor.dart';
import 'package:swms_finish_goods/core/network/error_interceptor.dart';
import 'package:swms_finish_goods/core/network/locale_interceptor.dart';
import 'package:swms_finish_goods/core/storage/secure_storage_service.dart';
import 'package:swms_finish_goods/core/utils/app_local_storage.dart';

/// Factory tạo Dio đã cấu hình interceptors.
/// Thường được gọi từ provider trong core/di/providers.dart.
class DioClient {
  static Dio create({
    required String baseUrl,
    required SecureStorageService storage,
    required AppLocalStorage appStorage,
    Uint8List? trustedCertificate,
  }) {
    final dio = Dio(
      BaseOptions(
        baseUrl: baseUrl,
        connectTimeout: const Duration(seconds: 15),
        receiveTimeout: const Duration(seconds: 15),
        contentType: 'application/json',
        // Để server ghi đúng wms.stock_events.source = 'PDA'. Thiếu header này
        // thì mọi thao tác từ PDA vẫn bị ghi là 'WEB' (mặc định cũ), và lịch sử
        // pallet nói sai nguồn.
        headers: const {'X-Client': 'PDA'},
      ),
    );

    dio.interceptors.addAll([
      CompactLogInterceptor(),
      LocaleInterceptor(appStorage),
      AuthInterceptor(storage),
      ErrorInterceptor(),
    ]);

    dio.httpClientAdapter = IOHttpClientAdapter(
      createHttpClient: () {
        final context = SecurityContext(withTrustedRoots: true);
        if (trustedCertificate != null) {
          context.setTrustedCertificatesBytes(trustedCertificate);
        }
        return HttpClient(context: context);
      },
    );

    return dio;
  }
}