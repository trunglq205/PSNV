﻿namespace SWMS_WebTool.Models.Requests
{
    public class CreateTrolleyRequest
    {
        public int FloorId { get; set; }
        public string Name { get; set; }
        public string Code { get; set; }
        public string Category { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
    }
}
