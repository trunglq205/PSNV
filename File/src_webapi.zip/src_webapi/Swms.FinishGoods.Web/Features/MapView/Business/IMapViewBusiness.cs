using Swms.FinishGoods.Web.Features.MapView.Business.Models;
using Swms.FinishGoods.Web.Shared.Business.Models;

namespace Swms.FinishGoods.Web.Features.MapView.Business;

public interface IMapViewBusiness
{
    Task<Result<MapViewLayoutDto>> GetAsync(string areaCode);
}
