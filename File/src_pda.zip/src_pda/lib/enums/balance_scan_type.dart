enum BalanceScanType {
  scanRc,
  scanBox,
}
