import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/abnormal_report/domain/entities/ng_entities.dart';
import 'package:swms_finish_goods/features/abnormal_report/presentation/pages/ng_list_page.dart'
    show ngStatusPill;
import 'package:swms_finish_goods/features/abnormal_report/presentation/providers/ng_providers.dart';

/// Chi tiết phiếu — CHỈ ĐỌC.
///
/// PDA không duyệt phiếu: công nhân SCS gửi báo cáo rồi theo dõi tiến trình ở
/// đây. Mọi thao tác duyệt (Leader, OQC, FA, chốt) làm trên Web.
@RoutePage()
class NgDetailPage extends ConsumerStatefulWidget {
  final int id;
  const NgDetailPage({super.key, @PathParam('id') required this.id});

  @override
  ConsumerState<NgDetailPage> createState() => _NgDetailPageState();
}

class _NgDetailPageState extends ConsumerState<NgDetailPage> {
  @override
  Widget build(BuildContext context) {
    final async = ref.watch(ngDetailProvider(widget.id));

    return Scaffold(
      appBar: AppBar(title: Text(LocaleKeys.ng_title.tr())),
      body: async.when(
        loading: () => const AppLoading(),
        error: (e, _) => AppErrorView.page(
          message: '$e',
          onRetry: () => ref.invalidate(ngDetailProvider(widget.id)),
        ),
        data: (d) => ListView(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 24),
          children: [
            _header(d),
            if (d.description != null && d.description!.isNotEmpty) ...[
              const SizedBox(height: 10),
              _descBox(d.description!),
            ],
            _section('${LocaleKeys.ng_items.tr()} (${d.items.length})'),
            ...d.items.map(_itemRow),
            if (d.header.photoCount > 0) ...[
              _section('${LocaleKeys.ng_photos.tr()} (${d.header.photoCount})'),
              _photoHint(d.header.photoCount),
            ],
            _section(LocaleKeys.ng_timeline.tr()),
            AppTimeline(items: _timeline(d), emphasizeFirst: false),
          ],
        ),
      ),
    );
  }

  Widget _header(NgDetail d) {
    final swms = context.swms;
    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  d.header.docNo,
                  style: TextStyle(
                    fontWeight: FontWeight.w900,
                    fontSize: 16,
                    color: swms.text1,
                  ),
                ),
              ),
              ngStatusPill(context, d.header.docStatus),
            ],
          ),
          const SizedBox(height: 6),
          // Lỗi cả pallet thì số lượng vô nghĩa (mỗi mục lưu 1), hiện "1 cái"
          // làm người đọc tưởng chỉ 1 sản phẩm bị lỗi. Tách ra biến chứ không
          // viết lồng trong chuỗi nội suy — lồng 3 tầng rất dễ vỡ khi sửa.
          Builder(builder: (_) {
            final qty = d.header.isWholePallet
                ? LocaleKeys.ng_whole_pallet.tr()
                : '${d.header.qtyAffected} ${LocaleKeys.ng_qty_word.tr()}';
            return Text(
              '${ngTypeName(ngTypesOf(ref.watch(ngTypesProvider)), d.header.ngType)} · '
              '${d.header.itemCount} ${LocaleKeys.ng_item_word.tr()} · '
              '$qty',
              style: TextStyle(fontSize: 12.5, color: swms.text2),
            );
          }),
          const SizedBox(height: 4),
          Text(
            '${d.header.palletCode ?? ''} · ${d.header.model ?? ''}',
            style: TextStyle(fontSize: 12, color: swms.text3),
          ),
        ],
      ),
    );
  }

  Widget _descBox(String text) {
    final swms = context.swms;
    return Container(
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Text(text, style: TextStyle(fontSize: 13, color: swms.text2)),
    );
  }

  /// Ảnh xem trên Web; PDA chỉ cho biết có bao nhiêu ảnh để người duyệt biết
  /// đã có bằng chứng kèm theo.
  Widget _photoHint(int count) {
    final swms = context.swms;
    return Row(
      children: [
        Icon(Icons.photo_library_outlined, size: 16, color: swms.text3),
        const SizedBox(width: 6),
        Text(
          LocaleKeys.ng_photo_count.tr(args: ['$count']),
          style: TextStyle(fontSize: 12.5, color: swms.text3),
        ),
      ],
    );
  }

  Widget _section(String text) {
    final swms = context.swms;
    return Padding(
      padding: const EdgeInsets.only(top: 18, bottom: 6),
      child: Text(
        text.toUpperCase(),
        style: TextStyle(
          fontSize: 11,
          fontWeight: FontWeight.w800,
          letterSpacing: .4,
          color: swms.text3,
        ),
      ),
    );
  }

  Widget _itemRow(NgItem it) {
    final swms = context.swms;
    return Container(
      margin: const EdgeInsets.only(bottom: 6),
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 7),
      decoration: BoxDecoration(
        color: swms.card2,
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Text(
            'ng.scope.${it.scope}'.tr(),
            style: TextStyle(
              fontSize: 10,
              fontWeight: FontWeight.w800,
              color: swms.text3,
            ),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  it.code ?? '—',
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: swms.text1,
                  ),
                ),
                if (it.note != null && it.note!.isNotEmpty)
                  Text(
                    it.note!,
                    style: TextStyle(fontSize: 11.5, color: swms.text3),
                  ),
              ],
            ),
          ),
          Text(
            it.scope == 'pallet'
                ? LocaleKeys.ng_whole_pallet.tr()
                : '${it.qtyAffected}',
            style: TextStyle(
              fontWeight: it.scope == 'pallet' ? FontWeight.w600 : FontWeight.w800,
              fontSize: it.scope == 'pallet' ? 11.5 : null,
              color: swms.text1,
            ),
          ),
        ],
      ),
    );
  }

  /// Tiến trình, đúng khuôn màn Web.
  ///
  /// Hai mốc đầu (SCS tạo, Leader duyệt) chỉ xảy ra một lần. Phần sau LẶP giữa
  /// OQC và FA tới khi hai bên cùng kết luận đạt, và MỖI LƯỢT LÀ MỘT MỐC
  /// RIÊNG — nên phải dựng từ NHẬT KÝ `d.approvals`, không dựng từ các cột
  /// `oqcBy` / `faBy`: mấy cột đó chỉ giữ LẦN CUỐI của mỗi bên, phiếu quay ba
  /// vòng vẫn trông như chỉ có một lượt.
  ///
  /// Bước "SCS supervisor chốt" đã BỎ 23/11: phiếu tự đóng khi OQC và FA cùng
  /// đạt, và lúc đó pallet chuyển `inspection_status` sang `pass`.
  List<AppTimelineItem> _timeline(NgDetail d) {
    final h = d.header;
    String meta(String? by, DateTime? at) => by == null
        ? LocaleKeys.ng_not_yet.tr()
        : '$by · ${DateFormat('dd/MM/yyyy HH:mm').format(at!)}';

    // Tên mốc kèm "lần n" từ lượt thứ hai trở đi.
    String title(String step, int nth) {
      final name = switch (step) {
        'oqc' => LocaleKeys.ng_step_oqc.tr(),
        'fa_fix' => LocaleKeys.ng_step_fa_fix.tr(),
        _ => LocaleKeys.ng_step_fa.tr(),
      };
      return nth <= 1
          ? name
          : '$name · ${LocaleKeys.ng_step_nth.tr(namedArgs: {'n': '$nth'})}';
    }

    // Chữ dưới một lượt. Lượt FA đánh không đạt thì thứ đáng đọc nhất là
    // HƯỚNG XỬ LÝ họ vừa nhập, nên nó đứng trước; ghi chú thêm nối sau.
    String? note(NgApproval a) {
      final plan = a.resolution;
      if (a.step != 'fa' || a.action != 'ng' || plan == null || plan.isEmpty) {
        return a.comment;
      }
      final c = a.comment;
      return (c == null || c.isEmpty) ? plan : '$plan — $c';
    }

    // Nhãn kết quả của một lượt. Phiếu CŨ ghi action = 'approve' (trước 23/11
    // FA không đánh đạt/không đạt, chỉ chọn hướng xử lý) — lúc đó không có
    // kết quả nào để hiện.
    String? code(NgApproval a) => switch (a.step) {
      'oqc' => a.action.toUpperCase(),
      'fa' when a.action == 'ok' => LocaleKeys.ng_fa_ok.tr(),
      'fa' when a.action == 'ng' => LocaleKeys.ng_fa_ng.tr(),
      _ => null,
    };

    final rounds = <AppTimelineItem>[];
    final nth = <String, int>{};

    final log = d.approvals
        .where((a) => a.step == 'oqc' || a.step == 'fa' || a.step == 'fa_fix')
        .toList()
      ..sort((a, b) => a.actedAt.compareTo(b.actedAt));

    for (final a in log) {
      nth[a.step] = (nth[a.step] ?? 0) + 1;
      rounds.add(AppTimelineItem(
        title: title(a.step, nth[a.step]!),
        code: code(a),
        meta: meta(a.actedBy, a.actedAt),
        description: note(a),
        tone: switch ((a.step, a.action)) {
          ('oqc', 'ok') => AppTimelineTone.success,
          ('oqc', 'ng') => AppTimelineTone.danger,
          ('fa', 'ng') => AppTimelineTone.danger,
          _ => AppTimelineTone.success,
        },
      ));
    }

    // Lượt ĐANG CHỜ chưa có dòng nhật ký nào nên phải dựng từ currentStep.
    final waiting = h.isClosed
        ? null
        : switch (h.currentStep) {
            'oqc_confirm' => 'oqc',
            'fa_confirm' => 'fa',
            'fa_fix' => 'fa_fix',
            _ => null,
          };
    if (waiting != null) {
      nth[waiting] = (nth[waiting] ?? 0) + 1;
      rounds.add(AppTimelineItem(
        title: title(waiting, nth[waiting]!),
        meta: LocaleKeys.ng_not_yet.tr(),
        tone: AppTimelineTone.neutral,
        muted: true,
      ));
    }

    return [
      AppTimelineItem(
        title: LocaleKeys.ng_step_created.tr(),
        meta: meta(h.createdBy, h.discoveredAt),
        tone: AppTimelineTone.success,
      ),
      AppTimelineItem(
        title: LocaleKeys.ng_step_leader.tr(),
        meta: meta(d.leaderBy, d.leaderAt),
        description: d.leaderComment,
        tone: switch (h.leaderStatus) {
          'submitted' => AppTimelineTone.success,
          'cancelled' => AppTimelineTone.danger,
          _ => AppTimelineTone.neutral,
        },
        muted: h.leaderStatus == 'pending',
      ),
      // Loại lỗi không phải qua OQC: nói thẳng ra một mốc, chứ để trống thì
      // người đọc tưởng phiếu đang treo chờ OQC.
      if (h.oqcStatus == 'skipped')
        AppTimelineItem(
          title: LocaleKeys.ng_step_oqc.tr(),
          code: LocaleKeys.ng_oqc_skipped.tr(),
          meta: '',
          tone: AppTimelineTone.neutral,
          muted: true,
        ),
      ...rounds,
      AppTimelineItem(
        title: LocaleKeys.ng_step_close.tr(),
        meta: h.docStatus == 'cancelled'
            ? meta(d.cancelledBy, d.cancelledAt)
            : meta(d.finalizedBy, d.finalizedAt),
        description: d.finalComment ?? d.cancelReason,
        tone: switch (h.docStatus) {
          'finalized' => AppTimelineTone.success,
          'cancelled' => AppTimelineTone.danger,
          _ => AppTimelineTone.neutral,
        },
        muted: !h.isClosed,
      ),
    ];
  }

}
