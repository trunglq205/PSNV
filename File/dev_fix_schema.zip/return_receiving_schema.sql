/* ============================================================================
   MỤC 2a — SCS WH nhận hàng back: sổ đăng ký serial của phiếu.

   Chạy MỘT LẦN trên DB SWMS. Script idempotent: chạy lại không hỏng, không
   mất dữ liệu đã có.

   Tạo ra:
     1. wms.pallets.disposition        — bảo đảm cột tồn tại (bản đồ kho đã đọc
                                         nó để vẽ badge RW/RE), + index để mục 11
                                         lọc tồn hàng rework cuối tháng.
     2. wms.return_instruction_serials — sổ serial của phiếu back hàng.

   VÌ SAO CẦN BẢNG SỔ SERIAL, trong khi serial đã nằm ở wms.box_lines.serial_no:
     box_lines chỉ trả lời được "serial này ĐANG ở pallet nào". Một serial hàng
     return sẽ đi qua NHIỀU Pallet ID — WH tạo pallet (2a) → FA đóng pallet mới
     sau rework (2d) → trả về (3, 5) → xuất (9, 10). Các bước đó cần danh sách
     VĨNH VIỄN "những con này thuộc phiếu RW-...-001" kèm trạng thái từng con.
     Thêm nữa, unique index serial của box_lines chỉ ràng buộc TRONG MỘT THÙNG,
     nên nó không chặn được serial lạ — chặn serial lạ (mục 2d) dựa vào unique
     của chính bảng này.

   KHÔNG lưu line_id trỏ về wms.return_instruction_lines: mỗi lần Office sửa
   phiếu, service xoá mềm toàn bộ dòng rồi chèn lại với id MỚI, nên line_id lưu
   ở đây sẽ trỏ vào dòng đã xoá. Khớp theo `model` — unique (doc_id, model) của
   bảng dòng bảo đảm một model chỉ có một dòng trong phiếu.
   ============================================================================ */
SET NOCOUNT ON;
SET XACT_ABORT ON;

/* ---------- 0. Tiền đề ---------- */
IF OBJECT_ID(N'wms.return_instructions', N'U') IS NULL
BEGIN
    RAISERROR(N'Chua co bang wms.return_instructions — chay return_instruction_schema.sql truoc.', 16, 1);
    RETURN;
END;

IF OBJECT_ID(N'wms.pallets', N'U') IS NULL
BEGIN
    RAISERROR(N'Khong tim thay wms.pallets — kiem tra lai dang ket noi dung DB SWMS chua.', 16, 1);
    RETURN;
END;

/* ---------- 1. wms.pallets.disposition ---------- */
/* Cột này đã được StorageMapRepository đọc, nên gần như chắc chắn đã có.
   Vẫn kiểm: thiếu thì mọi lần mở bản đồ kho đang lỗi, và bước 2a sẽ ghi vào nó. */
/* ⚠ MỌI câu nhắc tới cột `disposition` trong file này đều phải nằm trong
   EXEC(N'...'), kể cả câu SELECT đếm ở cuối.

   Cả file là MỘT batch (không có GO nào). SQL Server bind tên cột theo cấu
   trúc bảng tại lúc compile CẢ batch, không phải lúc chạy từng câu — nên trên
   một DB chưa có cột `disposition`, câu ALTER phía dưới chưa kịp chạy thì
   batch đã lỗi 207 "Invalid column name" và KHÔNG CÂU NÀO trong script được
   thực thi, kể cả CREATE TABLE. Đúng cùng một cái bẫy với temp table.

   EXEC compile chuỗi SQL ở thời điểm GỌI, nên nó thấy cột vừa được thêm. */
IF COL_LENGTH(N'wms.pallets', N'disposition') IS NULL
BEGIN
    EXEC(N'ALTER TABLE wms.pallets ADD disposition NVARCHAR(20) NULL');
    PRINT N'+ Da them cot wms.pallets.disposition.';
END
ELSE
    PRINT N'= wms.pallets.disposition da co.';

/* KHÔNG đặt CHECK trên cột này: dữ liệu cũ có thể đang mang giá trị khác, và
   một CHECK bị WITH NOCHECK thì chỉ gây hiểu nhầm là đã được bảo vệ.
   API chỉ ghi 'rework' | 'refurbish' — cùng từ vựng với return_instructions.goods_type. */

IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.pallets') AND name = N'ix_pallets_disposition')
BEGIN
    /* Lọc theo disposition IS NOT NULL: hàng return là thiểu số trong kho, index
       lọc nhỏ hơn hẳn index đầy đủ mà vẫn đủ cho mục 11 (list tồn rework).
       Bọc EXEC — xem ghi chú ở mục 1. */
    EXEC(N'
        CREATE NONCLUSTERED INDEX ix_pallets_disposition
            ON wms.pallets (disposition)
            INCLUDE (pallet_id, locator_id, model, box_count, production_date)
            WHERE is_deleted = 0 AND disposition IS NOT NULL');
    PRINT N'+ Da tao index ix_pallets_disposition.';
END;

/* ---------- 2. wms.return_instruction_serials ---------- */
IF OBJECT_ID(N'wms.return_instruction_serials', N'U') IS NULL
BEGIN
    CREATE TABLE wms.return_instruction_serials
    (
        id          BIGINT IDENTITY(1,1) NOT NULL,

        /* Phiếu back hàng mà serial này thuộc về. */
        doc_id      BIGINT         NOT NULL,

        /* Khớp master.models.code, và khớp model của một dòng trong phiếu.
           Xem ghi chú đầu file về việc không lưu line_id. */
        model       NVARCHAR(100)  NOT NULL,

        /* Serial in trên từng sản phẩm — thứ WH quét ở mục 2a. */
        serial_no   NVARCHAR(100)  NOT NULL,

        /* Mã thùng lúc nhận. Giữ để tra "con này nằm thùng nào khi về kho";
           NULL khi hàng về rời, không còn thùng để quét. */
        box_no      NVARCHAR(50)   NULL,

        /* Pallet ĐANG giữ serial. Mục 2d FA đóng pallet mới thì cột này đổi
           sang pallet mới; lịch sử đi lại nằm ở wms.stock_events. */
        pallet_id   BIGINT         NULL,

        /* received = WH đã nhận vào kho SCS (mục 2a sinh ra duy nhất giá trị này)
           at_fa    = đã giao FA         (mục 2c/3)
           returned = FA đã trả về SCS   (mục 5)
           shipped  = đã xuất cho khách  (mục 10)
           ng       = kiểm lại không đạt (nhánh NG mục 5)
           Khai đủ ngay trong CHECK để các mục sau không phải ALTER bảng. */
        status      NVARCHAR(20)   NOT NULL
            CONSTRAINT df_ris_status DEFAULT (N'received'),

        received_at DATETIME2(0)   NOT NULL
            CONSTRAINT df_ris_received_at DEFAULT (SYSDATETIME()),

        is_deleted  BIT            NOT NULL CONSTRAINT df_ris_is_deleted DEFAULT (0),
        created_at  DATETIME2(0)   NOT NULL CONSTRAINT df_ris_created_at DEFAULT (SYSDATETIME()),
        created_by  NVARCHAR(100)  NULL,
        updated_at  DATETIME2(0)   NULL,
        updated_by  NVARCHAR(100)  NULL,

        CONSTRAINT pk_return_instruction_serials PRIMARY KEY CLUSTERED (id),

        CONSTRAINT ck_ris_status CHECK
            (status IN (N'received', N'at_fa', N'returned', N'shipped', N'ng')),

        CONSTRAINT fk_ris_doc FOREIGN KEY (doc_id)
            REFERENCES wms.return_instructions (id),

        CONSTRAINT fk_ris_pallet FOREIGN KEY (pallet_id)
            REFERENCES wms.pallets (id)
    );
    PRINT N'+ Da tao bang wms.return_instruction_serials.';
END
ELSE
    PRINT N'= wms.return_instruction_serials da co.';

/* ---------- 3. Index ---------- */

/* Một serial chỉ được đăng ký MỘT LẦN trong một phiếu. Quét trùng trong cùng
   phiếu bị chặn ở đây, kể cả khi hai máy PDA quét cùng lúc. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_instruction_serials')
                 AND name = N'ux_ris_doc_serial')
    CREATE UNIQUE NONCLUSTERED INDEX ux_ris_doc_serial
        ON wms.return_instruction_serials (doc_id, serial_no)
        WHERE is_deleted = 0;

/* Một serial chỉ nằm trong MỘT phiếu đang chạy. Đây là cái chặn "serial lạ"
   của mục 2d và chặn quét một con hàng vào hai phiếu khác nhau.

   Loại trừ status = 'shipped': cùng một sản phẩm có thể bị trả về LẦN NỮA
   nhiều tháng sau — lúc đó nó phải đăng ký được vào phiếu mới. Ràng buộc chỉ
   giữ trong phạm vi "đang còn trong chu trình". */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_instruction_serials')
                 AND name = N'ux_ris_serial_open')
    CREATE UNIQUE NONCLUSTERED INDEX ux_ris_serial_open
        ON wms.return_instruction_serials (serial_no)
        WHERE is_deleted = 0 AND status <> N'shipped';

/* Đếm SL thực nhận theo model — câu chạy mỗi lần mở danh sách phiếu. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_instruction_serials')
                 AND name = N'ix_ris_doc_model')
    CREATE NONCLUSTERED INDEX ix_ris_doc_model
        ON wms.return_instruction_serials (doc_id, model)
        INCLUDE (status, serial_no)
        WHERE is_deleted = 0;

/* "Pallet này thuộc phiếu nào / gồm những serial nào" — thay cho một cột
   return_doc_id trên wms.pallets. Không thêm cột vào wms.pallets có chủ ý:
   mọi luồng tạo pallet (tay, Foss, HD soft, tách pallet) đều ghi bảng đó, thêm
   cột vào câu INSERT dùng chung là rủi ro cho cả bốn luồng chỉ để phục vụ một. */
IF NOT EXISTS (SELECT 1 FROM sys.indexes
               WHERE object_id = OBJECT_ID(N'wms.return_instruction_serials')
                 AND name = N'ix_ris_pallet')
    CREATE NONCLUSTERED INDEX ix_ris_pallet
        ON wms.return_instruction_serials (pallet_id)
        INCLUDE (doc_id, model, serial_no, status)
        WHERE is_deleted = 0 AND pallet_id IS NOT NULL;

PRINT N'= Index da day du.';

/* ---------- 4. Kiểm lại ---------- */
SELECT N'Cau truc' AS section;

SELECT c.column_id, c.name, t.name AS kieu, c.max_length, c.is_nullable
FROM   sys.columns c
JOIN   sys.types   t ON t.user_type_id = c.user_type_id
WHERE  c.object_id = OBJECT_ID(N'wms.return_instruction_serials')
ORDER BY c.column_id;

SELECT N'Index' AS section;

SELECT i.name, i.is_unique, i.filter_definition
FROM   sys.indexes i
WHERE  i.object_id = OBJECT_ID(N'wms.return_instruction_serials')
  AND  i.name IS NOT NULL
ORDER BY i.name;

SELECT N'So lieu' AS section;

/* Bọc EXEC vì có nhắc `disposition` — xem ghi chú ở mục 1. */
EXEC(N'
    SELECT so_serial_dang_ky = (SELECT COUNT(*) FROM wms.return_instruction_serials WHERE is_deleted = 0),
           so_pallet_hang_return = (SELECT COUNT(*) FROM wms.pallets
                                    WHERE is_deleted = 0 AND disposition IS NOT NULL)');
