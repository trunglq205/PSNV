import 'package:dio/dio.dart';
import 'package:retrofit/retrofit.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_instruction_model.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_receive_model.dart';

part 'return_instruction_remote_data_source.g.dart';

/// Đường dẫn PHẢI có tiền tố `/api`: BASE_URL trong `config/*.json` chỉ tới
/// host + port, không chứa `/api` (xem `app_config.dart`).
@RestApi()
abstract class ReturnInstructionRemoteDataSource {
  factory ReturnInstructionRemoteDataSource(Dio dio, {String baseUrl}) =
      _ReturnInstructionRemoteDataSource;

  /// Danh sách chỉ thị back hàng. Response ĐÃ kèm đủ dòng, nên màn PDA không
  /// phải gọi thêm một request cho mỗi phiếu khi người dùng bung chi tiết.
  ///
  /// Tên tham số query là camelCase (`goodsType`): ASP.NET model binding so
  /// tên KHÔNG phân biệt hoa thường nhưng CÓ phân biệt dấu gạch dưới.
  @GET('/api/return-instructions')
  Future<List<ReturnInstructionModel>> list({
    @Query('status') String? status,
    @Query('goodsType') String? goodsType,
    @Query('keyword') String? keyword,
  });

  /// Một phiếu kèm dòng và SL thực nhận mới nhất.
  ///
  /// Màn nhận hàng đọc lại phiếu khi mở chứ không nhận qua tham số điều hướng:
  /// máy khác có thể vừa quét thêm, mà màn này quyết định "còn phải nhận bao
  /// nhiêu" từ chính con số đó.
  @GET('/api/return-instructions/{id}')
  Future<ReturnInstructionModel> getById(@Path('id') int id);

  /// Nhận một pallet hàng return vào phiếu: gửi toàn bộ thùng + serial đã quét.
  /// Server cấp Pallet ID và trả lại phiếu đã cập nhật SL thực nhận.
  @POST('/api/return-instructions/{id}/pallets')
  Future<ReceiveReturnResponseModel> receive(
    @Path('id') int id,
    @Body() ReceiveReturnRequestModel body,
  );

  /// Chốt SL thực nhận: server đóng phiếu và TỰ GỬI MAIL báo FA số thực tế
  /// kèm bảng lệch so với chỉ thị.
  ///
  /// Không có thân request: SL thực nhận là số serial đã quét, server tự đếm.
  /// Gửi thêm con số từ máy là mở đường cho hai bên nói hai số khác nhau.
  @POST('/api/return-instructions/{id}/close')
  Future<ReturnInstructionModel> close(@Path('id') int id);
}
