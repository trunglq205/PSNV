import 'package:dio/dio.dart';
import 'package:swms_finish_goods/features/return_instruction/data/models/return_back_model.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';

// ─────────────────────────────────────────────────────────────
//  Mục 2c — truy cập API, gọi Dio TRỰC TIẾP thay vì qua retrofit.
//
//  Cùng lý do đã ghi ở return_back_model.dart: bộ mục 2c làm sao để KHÔNG cần
//  chạy build_runner, và @RestApi thì buộc phải sinh `.g.dart`.
//
//  Vẫn đi qua Dio CHUNG của app (`dioProvider`) nên giữ nguyên baseUrl, token
//  và ErrorInterceptor — câu thông báo lỗi của server vẫn tới được ErrorHandler
//  y như mọi màn khác.
//
//  Route treo trên PHIẾU (`/api/return-instructions/{id}/…`), không phải trên
//  một tài nguyên riêng: sau khi gộp thì luồng back là một mặt của phiếu.
//
//  Đường dẫn PHẢI có tiền tố `/api`: BASE_URL trong `config/*.json` chỉ tới
//  host + port (xem `app_config.dart`).
// ─────────────────────────────────────────────────────────────

class ReturnBackRepository {
  final Dio _dio;
  const ReturnBackRepository(this._dio);

  static String _base(int docId) => '/api/return-instructions/$docId';

  /// SL còn ở kho theo model — màn giao hàng hiện để WH soát đúng hàng.
  ///
  /// KHÔNG bắt DioException để bọc lại: ErrorInterceptor đã lấy câu thông báo
  /// của server và ErrorHandler hiện nguyên câu đó — bọc lại chỉ còn câu chung
  /// chung, mất thông tin.
  Future<List<BackRemainModel>> fetchRemain(int docId) async {
    final res = await _dio.get<Object?>('${_base(docId)}/back-remain');
    final data = res.data;
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => backRemainModelFromJson(e.cast<String, Object?>()))
        .toList();
  }

  /// Nhật ký pallet đã giao, mới nhất trước.
  Future<List<BackDelivery>> fetchDeliveries(int docId) async {
    final res = await _dio.get<Object?>('${_base(docId)}/back-deliveries');
    final data = res.data;
    if (data is! List) return const [];
    return data
        .whereType<Map>()
        .map((e) => backDeliveryFromJson(e.cast<String, Object?>()))
        .toList();
  }

  /// Giao hàng: gửi NHIỀU Pallet ID trong MỘT lượt.
  ///
  /// Gửi cả cụm chứ không mỗi pallet một request: FA phải nhận MỘT lá thư liệt
  /// kê đủ pallet, và server chỉ gửi thư ở lượt làm xong cả phiếu — bắn từng mã
  /// là FA nhận năm lá thư cho một chuyến xe.
  Future<BackDeliverResult> deliver({
    required int docId,
    required List<String> lotNos,
    String? comment,
  }) async {
    final res = await _dio.post<Map<String, Object?>>(
      '${_base(docId)}/deliver-back',
      data: <String, Object?>{
        'lotNos': lotNos,
        if (comment != null && comment.trim().isNotEmpty)
          'comment': comment.trim(),
      },
    );
    return backDeliverResultFromJson(res.data ?? const {});
  }
}
