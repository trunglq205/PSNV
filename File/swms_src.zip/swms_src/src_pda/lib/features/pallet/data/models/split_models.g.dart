// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'split_models.dart';

// **************************************************************************
// JsonSerializableGenerator
// **************************************************************************

SplitPalletRequestModel _$SplitPalletRequestModelFromJson(
  Map<String, dynamic> json,
) => SplitPalletRequestModel(
  sourceLotNo: json['sourceLotNo'] as String,
  boxIds: (json['boxIds'] as List<dynamic>)
      .map((e) => (e as num).toInt())
      .toList(),
  targetType: json['targetType'] as String,
  targetLotNo: json['targetLotNo'] as String?,
  boxQty: (json['boxQty'] as num?)?.toInt(),
  confirmModelMismatch: json['confirmModelMismatch'] as bool? ?? false,
);

Map<String, dynamic> _$SplitPalletRequestModelToJson(
  SplitPalletRequestModel instance,
) => <String, dynamic>{
  'sourceLotNo': instance.sourceLotNo,
  'boxIds': instance.boxIds,
  'targetType': instance.targetType,
  'targetLotNo': ?instance.targetLotNo,
  'boxQty': ?instance.boxQty,
  'confirmModelMismatch': instance.confirmModelMismatch,
};

SplitPalletResponseModel _$SplitPalletResponseModelFromJson(
  Map<String, dynamic> json,
) => SplitPalletResponseModel(
  sourceLotNo: json['sourceLotNo'] as String,
  sourceRemainingBoxes: (json['sourceRemainingBoxes'] as num).toInt(),
  targetLotNo: json['targetLotNo'] as String,
  targetIsNew: json['targetIsNew'] as bool,
  movedBoxes: (json['movedBoxes'] as num).toInt(),
);

Map<String, dynamic> _$SplitPalletResponseModelToJson(
  SplitPalletResponseModel instance,
) => <String, dynamic>{
  'sourceLotNo': instance.sourceLotNo,
  'sourceRemainingBoxes': instance.sourceRemainingBoxes,
  'targetLotNo': instance.targetLotNo,
  'targetIsNew': instance.targetIsNew,
  'movedBoxes': instance.movedBoxes,
};
