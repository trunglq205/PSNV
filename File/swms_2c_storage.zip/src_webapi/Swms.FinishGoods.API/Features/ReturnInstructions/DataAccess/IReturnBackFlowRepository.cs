namespace Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;

/// <summary>
/// Luồng nhận lại hàng về FA (mục 2c) — đọc / ghi 13 cột <c>back_*</c> trên
/// <c>wms.return_instructions</c> và bảng nhật ký giao hàng.
///
/// Slice RIÊNG dù ghi vào bảng của mục 2a: ba bước này có bộ quyền riêng, bộ
/// mail riêng và vòng đời riêng với việc nhận hàng. Nhồi vào
/// <see cref="IReturnInstructionRepository"/> là làm file đó phình ra gấp đôi
/// và mọi sửa đổi của hai nghiệp vụ dính vào nhau.
///
/// Đổi lại, mọi câu ĐỌC số liệu đi qua <see cref="IReturnInstructionRepository"/>
/// (đã nạp đủ 13 cột + bốn con số) — ở đây chỉ còn các câu GHI và nhật ký.
/// </summary>
public interface IReturnBackFlowRepository
{
    /// <summary>
    /// B1 — FA đề nghị. Điều kiện nằm TRONG câu UPDATE, không SELECT-rồi-UPDATE:
    /// hai người bấm cùng lúc thì người sau cập nhật 0 dòng và nhận 409, chứ
    /// không ghi đè.
    ///
    /// Cho đề nghị lại sau khi đã huỷ (<c>back_status = 'cancelled'</c>) — huỷ
    /// là đổi ý, không phải cấm vĩnh viễn. Lúc đó XOÁ SẠCH dấu của lượt huỷ
    /// trước, nếu không màn hình hiện một đề nghị mới kèm lý do huỷ cũ.
    /// </summary>
    /// <returns><c>false</c> khi phiếu không ở trạng thái đề nghị được.</returns>
    /// <param name="lines">
    /// SL xin lấy về theo model (từ 10/11 FA đề nghị được MỘT PHẦN). Ghi cùng
    /// transaction với header — header có mà dòng không là quản lý FA mở ra
    /// duyệt một đề nghị trống.
    /// </param>
    Task<bool> RequestAsync(
        long docId, string? note, IReadOnlyList<BackReqLine> lines, string? user);

    /// <summary>Sửa ghi chú, chỉ khi còn chờ quản lý FA xác nhận.</summary>
    Task<bool> UpdateNoteAsync(long docId, string? note, string? user);

    /// <summary>B2 — quản lý FA xác nhận. Lá mail sang SCS Office đi từ đây.</summary>
    Task<bool> ApproveAsync(long docId, string? comment, string? user);

    /// <summary>
    /// B3 — quản lý SCS xác nhận (thêm 10/11). Sau bước này SCS WH mới được
    /// tách pallet và quét giao. Không mail.
    /// </summary>
    Task<bool> ScsApproveAsync(long docId, string? comment, string? user);

    /// <summary>
    /// Huỷ luồng back. Chặn khi ĐÃ GIAO được con nào: điều kiện
    /// <c>NOT EXISTS (serial có sent_fa_at)</c> nằm trong chính câu UPDATE, nên
    /// không có khe nào để một lượt giao chen vào giữa lúc kiểm và lúc ghi.
    /// </summary>
    Task<bool> CancelAsync(long docId, string? reason, string? user);

    /// <summary>
    /// Pallet này đang giữ hàng chờ giao của phiếu nào?
    ///
    /// Gọi TRƯỚC khi chuyển pallet vào khu Nhận hàng, để biết lượt chuyển đó có
    /// phải là hành động giao hàng cho FA hay không. Trả null khi pallet không
    /// còn serial nào ở <c>received</c> — pallet thường, hoặc pallet đã giao rồi
    /// đang được xếp lại trong khu nhận hàng.
    ///
    /// Trả kèm <c>BackStatus</c> chứ không tự phán xét: quyết định chặn hay cho
    /// đi là việc của tầng nghiệp vụ, repository chỉ nói hiện trạng.
    /// </summary>
    Task<ReturnBackPalletTarget?> FindDeliverableByPalletAsync(long palletId);

    /// <summary>
    /// Ghi sổ giao hàng cho MỘT pallet, chạy TRONG transaction đổi vị trí pallet
    /// (hook <c>onMoved</c> của <c>ILotRepository.ChangeLocatorAsync</c>).
    ///
    /// Đặt pallet vào vị trí thuộc bản đồ Nhận hàng chính là giao cho FA, nên
    /// việc ghi sổ phải cùng sống cùng chết với việc đổi vị trí — nhận
    /// <paramref name="conn"/>/<paramref name="tx"/> từ bên ngoài, KHÔNG tự mở
    /// kết nối. Hai transaction rời nhau thì hỏng ở giữa để lại pallet đã nằm ở
    /// khu nhận hàng mà phiếu vẫn báo chưa giao, và không chuyển lại được vì
    /// pallet đã đứng đúng vị trí đó.
    ///
    /// Việc nó làm: chuyển serial của phiếu đang ở <c>received</c> trên pallet
    /// này sang <c>at_fa</c> + đóng <c>sent_fa_at</c>; ghi một dòng nhật ký
    /// giao hàng (GHI CẢ KHI 0 con chuyển được, để sau tra ra được là pallet đó
    /// đã ra khu nhận hàng mà rỗng); hết con nào ở <c>received</c> thì đóng
    /// luồng <c>back_status = 'delivered'</c> + mốc người giao.
    ///
    /// KHÔNG xoá <c>pallet_id</c> của serial: hàng sang FA vẫn nằm trên đúng
    /// pallet đó, và mục 2d cần biết con nào từ pallet nào về.
    ///
    /// Khoá phiếu bằng UPDLOCK/HOLDLOCK rồi kiểm lại <c>back_status</c>: giữa
    /// lúc <see cref="FindDeliverableByPalletAsync"/> đọc và transaction này
    /// chạy, quản lý SCS có thể đã huỷ duyệt.
    /// </summary>
    /// <returns>
    /// Số con giao được lượt này, số còn lại của phiếu, và phiếu đã xong chưa.
    /// Phiếu đã rời <c>scs_approved</c> thì trả cờ <c>WrongStep</c> / <c>DocGone</c>
    /// và KHÔNG ghi gì — việc ném lỗi (có dịch) là của tầng nghiệp vụ.
    /// </returns>
    Task<ReturnBackMoveDelivered> DeliverOnMoveAsync(
        System.Data.IDbConnection conn,
        System.Data.IDbTransaction tx,
        long docId,
        long palletId,
        string lotNo,
        string? user);

    /// <summary>Nhật ký pallet đã giao của một phiếu, mới nhất trước.</summary>
    Task<IReadOnlyList<ReturnBackDelivery>> GetDeliveriesAsync(long docId);

    /// <summary>
    /// SL còn ở kho theo model — màn đề nghị gọi để CHO XEM phần sẽ lấy về, và
    /// mail dùng đúng số này dựng bảng.
    ///
    /// Đếm serial đang <c>received</c>, KHÔNG đọc <c>return_instruction_lines</c>:
    /// dòng chỉ thị là số khách BÁO, còn đây phải là số thực còn trong kho.
    /// </summary>
    Task<IReadOnlyList<BackModelQty>> GetRemainByModelAsync(long docId);
}

