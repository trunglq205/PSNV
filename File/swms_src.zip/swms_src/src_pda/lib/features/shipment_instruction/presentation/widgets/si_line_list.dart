import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_expandable_list.dart';
import 'package:swms_finish_goods/core/widgets/common/app_progress_bar.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

/// Danh sách dòng hàng của chỉ thị.
class SiLineList extends StatelessWidget {
  final List<ShipmentInstructionLine> lines;
  final int collapsedCount;

  const SiLineList({super.key, required this.lines, this.collapsedCount = 10});

  @override
  Widget build(BuildContext context) {
    return AppExpandableList<ShipmentInstructionLine>(
      items: lines,
      collapsedCount: collapsedCount,
      title: LocaleKeys.shipment_instruction_lines.tr(args: ['${lines.length}']),
      showMoreLabel: (hidden) =>
          LocaleKeys.shipment_instruction_show_more_lines.tr(args: ['$hidden']),
      itemBuilder: (context, line, _) => _LineRow(line: line),
    );
  }
}

class _LineRow extends StatelessWidget {
  final ShipmentInstructionLine line;
  const _LineRow({required this.line});

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final cut = line.qtyCut ?? 0;
    final so = siJoin([line.soNo, line.soItemNo], sep: '/');

    final meta = siJoin([
      LocaleKeys.shipment_instruction_line_no.tr(args: ['${line.lineNo}']),
      if ((line.poNo ?? '').isNotEmpty) 'PO ${line.poNo}',
      if (so.isNotEmpty) 'SO $so',
    ]);

    return AppCard(
      padding: const EdgeInsets.all(12),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  line.model,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.code.copyWith(
                    fontSize: 13.5,
                    letterSpacing: 0,
                    fontWeight: FontWeight.w700,
                    color: swms.text1,
                  ),
                ),
              ),
              const SizedBox(width: AppDimens.sm),
              Text.rich(
                TextSpan(
                  children: [
                    TextSpan(text: '${line.qtyFulfilled}'),
                    TextSpan(
                      text: '/${line.qtyRequired}',
                      style: TextStyle(
                        color: swms.text3,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ],
                ),
                style: AppTextStyles.bodyStrong.copyWith(
                  color: swms.text1,
                  fontWeight: FontWeight.w700,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
            ],
          ),
          const SizedBox(height: 3),
          Text(
            meta,
            maxLines: 1,
            overflow: TextOverflow.ellipsis,
            style: AppTextStyles.caption.copyWith(
              fontSize: 11,
              color: swms.text3,
            ),
          ),
          const SizedBox(height: 7),
          AppProgressBar(value: line.progress, height: 4),
          if (line.qtyShort > 0 || cut > 0) ...[
            const SizedBox(height: 5),
            Text.rich(
              TextSpan(
                children: [
                  if (line.qtyShort > 0)
                    TextSpan(
                      text: LocaleKeys.shipment_instruction_short_qty
                          .tr(args: ['${line.qtyShort}']),
                      style: TextStyle(
                        color: swms.warning,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  if (line.qtyShort > 0 && cut > 0) const TextSpan(text: ' · '),
                  if (cut > 0)
                    TextSpan(
                      text: LocaleKeys.shipment_instruction_cut_qty
                          .tr(args: ['$cut']),
                    ),
                ],
              ),
              style: AppTextStyles.caption.copyWith(
                fontSize: 11.5,
                color: swms.text2,
              ),
            ),
          ],
        ],
      ),
    );
  }
}
