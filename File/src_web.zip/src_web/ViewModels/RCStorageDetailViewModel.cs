﻿
namespace SWMS_WebTool.ViewModels
{
    public record RCStorageDetailViewModel 
    {
        public string Plant { get; set; }
        public string Category { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }
        public string MaterialFrequency { get; set; }
        public string MaterialType { get; set; }
        public string Name { get; set; }
        public int CurrentQuantity { get; set; }
        public DateTime? CreatedDate { get; set; }
        public DateTime? StorageDate { get; set; }

    }
}
