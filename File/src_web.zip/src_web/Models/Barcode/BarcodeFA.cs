﻿namespace SWMS_WebTool.Models.Barcode
{
    public class BarcodeFA
    {
        public string Model { get; set; }
        public string Line { get; set; }
        public string RequirementDate { get; set; }
        public string Time { get; set; }
        public string TypeReport { get; set; }
        public string Plant { get; set; }
        public string Category { get; set; }
        public string CategoryJT { get; set; }
        public string R { get; set; } = "R";
        public string Kitting { get; set; } = "KittingList";
    }
}
