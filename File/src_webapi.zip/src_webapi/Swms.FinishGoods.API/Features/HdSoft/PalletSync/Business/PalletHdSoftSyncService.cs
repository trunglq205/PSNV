using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.HdSoft.Business;
using Swms.FinishGoods.API.Features.HdSoft.PalletSync.Api;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.Business;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.HdSoft.PalletSync.Business
{
    public sealed record HdSoftApplyResult(IReadOnlyList<string> Actions, IReadOnlyList<string> Warnings);

    /// <summary>
    /// Đồng bộ HD soft -> pallet SWMS (trước đây nằm trong PalletService).
    ///   - API hdsoft-sync / hdsoft-sync-batch: theo vị trí ĐANG TỒN bên HD soft.
    ///   - Job nền: theo giao dịch mới nhất (M- / C- -> si_no CUSTOMER + rời vị trí; V+ / M+ -> gán vị trí).
    ///
    /// Không tạo pallet, không đồng bộ OQC — đó là việc của PalletFossSyncService.
    /// Ghi vị trí đi qua IPalletService (AssignLocatorBySyncAsync / ReleaseLocatorBySyncAsync)
    /// để dùng chung kiểm tra và event của SWMS.
    /// </summary>
    public class PalletHdSoftSyncService : IPalletHdSoftSyncService
    {
        /// <summary>Số pallet tối đa mỗi lần gọi batch.</summary>
        private const int MaxHdSoftBatch = 200;

        private readonly IPalletService _pallets;
        private readonly ILotRepository _repo;
        private readonly IHdSoftService _hdSoftService;
        private readonly ICurrentUser _currentUser;
        private readonly IStringLocalizer<SharedResource> _localizer;

        public PalletHdSoftSyncService(
            IPalletService pallets,
            ILotRepository repo,
            IHdSoftService hdSoftService,
            ICurrentUser currentUser,
            IStringLocalizer<SharedResource> localizer)
        {
            _pallets = pallets;
            _repo = repo;
            _hdSoftService = hdSoftService;
            _currentUser = currentUser;
            _localizer = localizer;
        }

        /// <summary>Vị trí tạm trong SWMS.</summary>
        private const string TempLocatorCode = "SCS";

        /// <summary>si_no gán cho pallet đã xuất cho khách theo HD soft (M- / C-).</summary>
        private const string CustomerSiNo = "CUSTOMER";

        // ── API: theo vị trí đang tồn ─────────────────────────────────

        /// <summary>
        /// Đồng bộ vị trí của 1 pallet theo VỊ TRÍ ĐANG TỒN bên HD soft (M_StorageOnhand).
        /// Pallet phải có sẵn trong SWMS.
        ///   đang tồn ở L        -> chuyển về L (giữ nguyên mã, kể cả PSNV); đã đúng L thì thôi
        ///   tồn ở nhiều vị trí  -> lấy vị trí SL lớn nhất + cảnh báo
        ///   không còn tồn       -> xem giao dịch mới nhất: M- / C- thì si_no = CUSTOMER + rời vị trí
        ///                          (giữ hành vi cũ cho hàng đã xuất); còn lại không đổi + cảnh báo
        /// Không tạo pallet từ Foss, không đồng bộ OQC — dùng from-foss / oqc-sync riêng.
        ///
        /// TRƯỚC ĐÂY đọc giao dịch mới nhất (M_Transaction) cho mọi trường hợp: giao dịch cuối là
        /// kiểm kê (I+/I-) hay loại không mang vị trí đích thì pallet không được chuyển.
        /// Job nền (ApplyHdSoftAsync) vẫn chạy theo giao dịch — không đổi ở đây.
        /// </summary>
        public async Task<HdSoftSyncResponse> SyncFromHdSoftAsync(string lotNo, PalletInclude include)
        {
            lotNo = NormalizeLotNo(lotNo);
            var actions = new List<string>();
            var warnings = new List<string>();

            var info = await _repo.GetLocationInfoByLotNoAsync(lotNo)
                       ?? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"]);

            var stock = await _hdSoftService.GetCurrentLocationsAsync([lotNo]);
            stock.TryGetValue(lotNo, out var locs);

            // Chỉ tra lịch sử khi lot không còn tồn (để nhận ra hàng đã xuất M- / C-)
            HdSoftLastMovementRow? last = null;
            if (locs is not { Count: > 0 })
                (await _hdSoftService.GetLastMovementsAsync([lotNo])).TryGetValue(lotNo, out last);

            var sync = new IntegrationSyncContext(StockEventSources.HdSoft, _currentUser.FullName);

            var (type, hdLocator) = await ApplyHdSoftCurrentLocatorAsync(info, locs, last, actions, warnings, sync);

            var detail = await _pallets.GetDetailByLotNoAsync(lotNo, include);
            return new HdSoftSyncResponse(detail, type, hdLocator, actions, warnings);
        }

        /// <summary>
        /// Như SyncFromHdSoftAsync cho nhiều pallet: 1 câu M_StorageOnhand cho cả nhóm,
        /// 1 câu lịch sử chỉ cho các lot không còn tồn. Pallet chưa có trong SWMS -> cảnh báo, bỏ qua.
        /// Lỗi của 1 pallet không làm hỏng cả nhóm.
        /// </summary>
        public async Task<List<HdSoftSyncBatchItem>> SyncFromHdSoftBatchAsync(IReadOnlyList<string> lotNos)
        {
            var lots = lotNos
                .Select(x => (x ?? "").Trim())
                .Where(x => x.Length > 0)
                .Distinct(StringComparer.OrdinalIgnoreCase)
                .ToList();

            if (lots.Count > MaxHdSoftBatch)
                throw new BusinessRuleException(_localizer["HdSoft.BatchTooLarge", MaxHdSoftBatch]);

            var stock = await _hdSoftService.GetCurrentLocationsAsync(lots);
            var noStock = lots.Where(l => !stock.ContainsKey(l)).ToList();
            var lastByLot = noStock.Count > 0
                ? await _hdSoftService.GetLastMovementsAsync(noStock)
                : new Dictionary<string, HdSoftLastMovementRow>(StringComparer.OrdinalIgnoreCase);

            var result = new List<HdSoftSyncBatchItem>(lots.Count);
            var batchId = Guid.NewGuid();

            foreach (var lotNo in lots)
            {
                var actions = new List<string>();
                var warnings = new List<string>();
                stock.TryGetValue(lotNo, out var locs);
                lastByLot.TryGetValue(lotNo, out var last);

                var info = await _repo.GetLocationInfoByLotNoAsync(lotNo);
                if (info is null)
                {
                    warnings.Add(_localizer["Lot.Err.LotNotFound"]);
                    result.Add(new(lotNo, locs is { Count: > 0 } ? OnhandType : last?.MovementType,
                                   locs is { Count: > 0 } ? locs[0].Locator : last?.Locator, null, actions, warnings));
                    continue;
                }

                var sync = new IntegrationSyncContext(StockEventSources.HdSoft, _currentUser.FullName)
                {
                    BatchId = batchId,
                };

                var (type, hdLocator) = await ApplyHdSoftCurrentLocatorAsync(info, locs, last, actions, warnings, sync);

                // Chỉ đọc lại khi vị trí thật sự đổi.
                var locatorAfter = actions.Count == 0
                    ? info.LocatorCode
                    : (await _repo.GetLocationInfoByIdAsync(info.Id))?.LocatorCode;

                result.Add(new(lotNo, type, hdLocator, locatorAfter, actions, warnings));
            }

            return result;
        }

        /// <summary>Giá trị LastMovementType trả về khi vị trí lấy từ tồn hiện tại (không phải giao dịch).</summary>
        private const string OnhandType = "ONHAND";

        /// <summary>
        /// Áp vị trí theo tồn hiện tại. Trả (LastMovementType, LastMovementLocator) cho response —
        /// giữ shape cũ: "ONHAND" + vị trí tồn, hoặc loại/vị trí của giao dịch khi lot không còn tồn.
        /// </summary>
        private async Task<(string? Type, string? Locator)> ApplyHdSoftCurrentLocatorAsync(
            PalletLocationInfo info,
            IReadOnlyList<HdSoftLotLocationRow>? locs,
            HdSoftLastMovementRow? lastIfNoStock,
            List<string> actions,
            List<string> warnings,
            IntegrationSyncContext sync)
        {
            if (locs is not { Count: > 0 })
            {
                // Không còn tồn: đã xuất (M- / C-) thì giữ đúng hành vi cũ, còn lại không đụng vào
                if (lastIfNoStock?.MovementType is "M-" or "C-")
                    await ApplyHdSoftLocatorAsync(info, lastIfNoStock, actions, warnings, sync);
                else
                    warnings.Add(lastIfNoStock is null
                        ? _localizer["HdSoft.LotNotFound", info.LotNo]
                        : _localizer["HdSoft.LotNotInStock", info.LotNo]);

                return (lastIfNoStock?.MovementType, lastIfNoStock?.Locator);
            }

            // SQL đã sắp SL giảm dần -> dòng đầu là vị trí chính
            var top = locs[0];
            var places = locs.Select(x => (x.Locator ?? "").Trim())
                             .Where(x => x.Length > 0)
                             .Distinct(StringComparer.OrdinalIgnoreCase)
                             .ToList();
            if (places.Count > 1)
                warnings.Add(_localizer["HdSoft.LotMultiLocator", info.LotNo, string.Join(", ", places), top.Locator ?? ""]);

            var target = await ResolveOnhandLocatorAsync(top.Locator, top.Warehouse);

            if (!string.Equals(target, info.LocatorCode, StringComparison.OrdinalIgnoreCase))
            {
                var hd = new
                {
                    source = "onhand",
                    hdSoftLocator = top.Locator,
                    warehouse = top.Warehouse,
                    qtyOnHand = top.QtyOnHand,
                    locatorBefore = info.LocatorCode,
                };
                await TryLocatorActionAsync(
                    () => _pallets.AssignLocatorBySyncAsync(info.Id, target, sync, hd),
                    HdSoftSyncActions.LocatorAssigned, actions, warnings);
            }

            return (OnhandType, top.Locator);
        }

        /// <summary>
        /// Vị trí HD soft -> mã vị trí SWMS (giữ nguyên mã, rỗng -> SCS — như MapHdSoftLocator).
        /// Mã HD soft có thể mang tiền tố kho ("PSNV-A1-10-1A"): thử nguyên mã trước, không có trong
        /// master thì thử bỏ tiền tố "&lt;kho&gt;-" — cùng quy ước chuẩn hoá của màn so tồn.
        /// </summary>
        private async Task<string> ResolveOnhandLocatorAsync(string? hdLocator, string? warehouse)
        {
            var raw = MapHdSoftLocator(hdLocator);
            if (raw == TempLocatorCode || string.IsNullOrWhiteSpace(warehouse)) return raw;

            var prefix = warehouse.Trim() + "-";
            if (!raw.StartsWith(prefix, StringComparison.OrdinalIgnoreCase) || raw.Length <= prefix.Length)
                return raw;

            if (await _repo.GetLocatorByCodeAsync(raw) is not null) return raw;
            return MapHdSoftLocator(raw[prefix.Length..]);
        }

        private async Task ApplyHdSoftLocatorAsync(
            PalletLocationInfo info,
            HdSoftLastMovementRow? last,
            List<string> actions,
            List<string> warnings,
            IntegrationSyncContext sync
        )
        {
            // Không có lịch sử HD soft -> không đụng tới vị trí.
            if (last is null) return;

            // Thông tin HD soft đi kèm mọi event của lần đồng bộ này.
            var hd = new
            {
                movementType = last.MovementType,
                hdSoftLocator = last.Locator,
                locatorBefore = info.LocatorCode,
                updateBy = last.UpdateBy,
            };

            switch (last.MovementType)
            {
                // Đã rời kho / đã xuất cho khách:
                //   1) si_no = 'CUSTOMER'
                //   2) rời vị trí (nếu đang có)
                // Gán si_no TRƯỚC và độc lập với bước rời vị trí: HD soft đã xác nhận hàng
                // ra khỏi kho, nên kể cả khi rời vị trí bị chặn (đang kiểm OQC...) thì si_no
                // vẫn phải phản ánh đúng thực tế; lỗi rời vị trí chỉ thành cảnh báo.
                case "M-":
                case "C-":
                    if (!string.Equals(info.SiNo, CustomerSiNo, StringComparison.OrdinalIgnoreCase))
                    {
                        var changed = await _repo.UpdateSiNoAsync(
                            info.Id, CustomerSiNo, sync.Actor ?? "",
                            sync.ToEventContext(StockEventCodes.SiNoAssigned,
                                new { hd.movementType, hd.hdSoftLocator, siNoBefore = info.SiNo, siNoAfter = CustomerSiNo }));
                        if (changed) actions.Add(HdSoftSyncActions.SiNoAssigned);
                    }

                    if (info.LocatorId is not null)
                        await TryLocatorActionAsync(
                            () => _pallets.ReleaseLocatorBySyncAsync(info.Id, sync, hd),
                            HdSoftSyncActions.LocatorReleased, actions, warnings);
                    break;

                // Hàng vào vị trí: nhập từ NCC (V+) hoặc chuyển đến (M+).
                // Gán theo đúng vị trí của giao dịch (PSNV lưu là PSNV).
                case "V+":
                case "M+":
                    var target = MapHdSoftLocator(last.Locator);
                    if (!string.Equals(target, info.LocatorCode, StringComparison.OrdinalIgnoreCase))
                        await TryLocatorActionAsync(
                            () => _pallets.AssignLocatorBySyncAsync(info.Id, target, sync, hd),
                            HdSoftSyncActions.LocatorAssigned, actions, warnings);
                    break;

                // Loại khác (I+, I-, C+, V-...): chưa có vị trí thì đưa vào SCS.
                default:
                    if (info.LocatorId is null)
                        await TryLocatorActionAsync(
                            () => _pallets.AssignLocatorBySyncAsync(info.Id, TempLocatorCode, sync, hd),
                            HdSoftSyncActions.LocatorAssigned, actions, warnings);
                    break;
            }
        }

        /// <summary>Áp vị trí theo HD soft cho 1 pallet đã nạp sẵn thông tin vị trí.</summary>
        public async Task<HdSoftApplyResult> ApplyHdSoftAsync(
            PalletLocationInfo info, HdSoftLastMovementRow last, IntegrationSyncContext sync)
        {
            var actions = new List<string>();
            var warnings = new List<string>();
            await ApplyHdSoftLocatorAsync(info, last, actions, warnings, sync);
            return new HdSoftApplyResult(actions, warnings);
        }

        /// <summary>
        /// Vị trí HD soft -> mã vị trí SWMS: giữ nguyên mã (PSNV lưu là PSNV — đã bỏ quy tắc đổi
        /// PSNV -> SCS). Chỉ khi HD soft không có vị trí mới rơi về SCS.
        /// </summary>
        private static string MapHdSoftLocator(string? hdSoftLocator)
        {
            var code = (hdSoftLocator ?? "").Trim();
            return code.Length == 0 ? TempLocatorCode : code;
        }

        /// <summary>
        /// Lỗi nghiệp vụ khi gán/rời vị trí (vị trí không có trong master, sai map_type,
        /// đang kiểm OQC...) chỉ ghi cảnh báo — OQC và tạo pallet ở trên đã xong,
        /// không nên rollback cả luồng vì vị trí.
        /// </summary>
        private static async Task TryLocatorActionAsync(
            Func<Task<LocatorChangeResponse>> action,
            string actionCode,
            List<string> actions,
            List<string> warnings)
        {
            try
            {
                var result = await action();
                actions.Add(actionCode);
                if (result.Warning is not null) warnings.Add(result.Warning);
            }
            catch (BusinessRuleException ex)
            {
                warnings.Add(ex.Message);
            }
            catch (NotFoundException ex)
            {
                warnings.Add(ex.Message);
            }
        }


        private string NormalizeLotNo(string? lotNo) => PalletLotNo.Normalize(lotNo, _localizer);
    }
}
