import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';

/// "Danh sách xe Stocky" + bộ đếm. Danh sách dài thì thu gọn 5 xe, bấm
/// "hiện thêm" — xe mới quét luôn ở trên cùng nên vẫn thấy ngay.
class StockyCartListCard extends StatelessWidget {
  final List<StockyCart> carts;

  /// null = khoá nút bỏ (đang gửi).
  final ValueChanged<String>? onRemove;

  const StockyCartListCard({super.key, required this.carts, required this.onRemove});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return AppCard(
      padding: const EdgeInsets.all(AppDimens.sm + 4),
      child: AppExpandableList<StockyCart>(
        title: LocaleKeys.stocky_list_title.tr(),
        headerAction: Text(
          LocaleKeys.stocky_list_count.tr(namedArgs: {'count': '${carts.length}'}),
          style: AppTextStyles.caption.copyWith(color: c.text3),
        ),
        items: carts,
        spacing: 6,
        empty: Padding(
          padding: const EdgeInsets.symmetric(vertical: 18),
          child: Text(
            LocaleKeys.stocky_list_empty.tr(),
            textAlign: TextAlign.center,
            style: AppTextStyles.caption.copyWith(color: c.text3),
          ),
        ),
        itemBuilder: (context, cart, _) => _CartRow(
          cart: cart,
          onRemove: onRemove == null ? null : () => onRemove!(cart.code),
        ),
      ),
    );
  }
}

class _CartRow extends StatelessWidget {
  final StockyCart cart;
  final VoidCallback? onRemove;

  const _CartRow({required this.cart, this.onRemove});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return Container(
      padding: const EdgeInsets.only(left: 10, right: 2),
      decoration: BoxDecoration(
        color: c.card2,
        border: Border.all(color: c.border),
        borderRadius: BorderRadius.circular(9),
      ),
      child: Row(
        children: [
          Icon(Icons.local_shipping_outlined, size: 18, color: c.text3),
          const SizedBox(width: 10),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 7),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Flexible(
                        child: Text(
                          cart.code,
                          overflow: TextOverflow.ellipsis,
                          style: AppTextStyles.code.copyWith(
                            fontSize: 12,
                            letterSpacing: 0.3,
                            fontWeight: FontWeight.w700,
                            color: c.text1,
                          ),
                        ),
                      ),
                      // Quét ở tab "Nhập xe" mà xe đang ở FA nghĩa là đang
                      // NHẬN VỀ TỪ FA, không phải nhận xe mới. Hiện chip để
                      // người vận hành thấy mình đang làm đúng việc đó.
                      if (cart.atFa) ...[
                        const SizedBox(width: 6),
                        StatusPill.warning(
                          context,
                          label: LocaleKeys.stocky_at_fa.tr(),
                        ),
                      ],
                    ],
                  ),
                  Text(
                    cart.isEmpty
                        ? LocaleKeys.stocky_cart_empty.tr()
                        : LocaleKeys.stocky_cart_meta.tr(namedArgs: {
                            'model': cart.model ?? '-',
                            'lots': '${cart.lotCount}',
                            'qty': '${cart.qty}',
                          }),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: AppTextStyles.caption.copyWith(color: c.text3),
                  ),
                ],
              ),
            ),
          ),
          SizedBox.square(
            dimension: AppDimens.hitSm,
            child: IconButton(
              padding: EdgeInsets.zero,
              onPressed: onRemove,
              icon: Icon(Icons.close_rounded, size: 16, color: c.text3),
            ),
          ),
        ],
      ),
    );
  }
}
