﻿namespace SWMS_WebTool.Models.Requests
{
    public class CreateUpdateRackRequest
    {
        public double X { get; set; }
        public double Y { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public string PIC { get; set; }
        public int ZoneID { get; set; }
        public string RackCode { get; set; }
        public int NumberOfLayer { get; set; }
        public int NumberOfUnit { get; set; }
        public string RackType { get; set; }
        public string? Category { get; set; }
        public string? RackDetailType { get; set; }
        public bool? IsPL { get; set; }
        public string? TypeSloc { get; set; }
    }

    public class UpdateRackRequest
    {
        public long RackID { get; set; }
        public string RackCode { get; set; }
        public string Category { get; set; }
        public string RackDetailType { get; set; }
        public string RackType { get; set; }
        public bool IsPL { get; set; }
        public string TypeSloc { get; set; }
        public string JIT { get; set; }
        public string PIC { get; set; }
        public double X { get; set; }
        public double Y { get; set; }
        public double Width { get; set; }
        public double Height { get; set; }
        public double Rotation { get; set; }
        public int NumberOfLayer { get; set; }
        public int NumberOfUnit { get; set; }
    }
}
