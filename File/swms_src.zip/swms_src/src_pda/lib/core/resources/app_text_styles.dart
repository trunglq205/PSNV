import 'package:flutter/material.dart';

/// Kiểu chữ — Inter (sans) + JetBrains Mono (mã quét).
abstract final class AppTextStyles {
  const AppTextStyles._();

  static const String sans = 'Inter';
  static const String mono = 'JetBrainsMono';

  static const TextStyle h1 = TextStyle(
      fontFamily: sans, fontSize: 21, fontWeight: FontWeight.w800, height: 1.25);
  static const TextStyle h2 = TextStyle(
      fontFamily: sans, fontSize: 17, fontWeight: FontWeight.w700, height: 1.3);
  static const TextStyle title = TextStyle(
      fontFamily: sans, fontSize: 15, fontWeight: FontWeight.w600, height: 1.3);
  static const TextStyle body = TextStyle(
      fontFamily: sans, fontSize: 13, fontWeight: FontWeight.w400, height: 1.45);
  static const TextStyle bodyStrong = TextStyle(
      fontFamily: sans, fontSize: 13, fontWeight: FontWeight.w600, height: 1.45);
  static const TextStyle label = TextStyle(
      fontFamily: sans, fontSize: 12, fontWeight: FontWeight.w600, height: 1.2);
  static const TextStyle caption = TextStyle(
      fontFamily: sans, fontSize: 10, fontWeight: FontWeight.w500, height: 1.4);

  /// Mã vạch / mã pallet — mono, hoa, giãn chữ (scan-first).
  static const TextStyle code = TextStyle(
      fontFamily: mono, fontSize: 14, fontWeight: FontWeight.w500,
      letterSpacing: 1.2, height: 1.3);
}