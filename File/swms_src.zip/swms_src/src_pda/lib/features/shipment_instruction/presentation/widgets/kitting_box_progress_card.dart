import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/extensions/datetime_extensions.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/core/widgets/common/app_progress_bar.dart';
import 'package:swms_finish_goods/core/widgets/common/status_pill.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';

/// Lấy theo thùng: tiến độ + nhắc thùng NSX nào đang được lấy.
class KittingBoxProgressCard extends StatelessWidget {
  final PickTask task;
  final List<PickBox> boxes;
  final int picked;

  const KittingBoxProgressCard({
    super.key,
    required this.task,
    required this.boxes,
    required this.picked,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final planned = task.boxPlanned;
    final remaining = (planned - picked).clamp(0, planned);
    final perBox = planned <= 0 ? 0 : (task.qtyPlanned / planned).floor();
    final done = remaining == 0;

    // NSX của lượt đang được lấy = thùng eligible đầu tiên.
    final current = boxes
        .where((b) => b.state == PickBoxState.eligible)
        .firstOrNull;

    final isFifo = task.mode == PickMode.fifoBox;
    final title = isFifo
        ? LocaleKeys.kitting_task_box_fifo_title.tr()
        : LocaleKeys.kitting_task_box_designated_title.tr();
    final counter = LocaleKeys.kitting_task_box_counter.tr(
      args: ['$picked', '$planned'],
    );

    return AppCard(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Row(
            children: [
              Expanded(
                child: Text(
                  title,
                  style: AppTextStyles.title.copyWith(
                    fontSize: 14,
                    color: swms.text1,
                  ),
                ),
              ),
              if (done)
                StatusPill.success(context, label: counter)
              else
                StatusPill.warning(context, label: counter),
            ],
          ),
          const SizedBox(height: 10),
          AppProgressBar(
            value: planned <= 0 ? 0 : picked / planned,
            height: 8,
          ),
          const SizedBox(height: 6),
          Row(
            children: [
              Text(
                '= ${picked * perBox} / ${task.qtyPlanned} pcs',
                style: AppTextStyles.caption.copyWith(
                  color: swms.text3,
                  fontFeatures: const [FontFeature.tabularFigures()],
                ),
              ),
              const Spacer(),
              Text(
                LocaleKeys.kitting_task_pcs_per_box.tr(args: ['$perBox']),
                style: AppTextStyles.caption.copyWith(color: swms.text3),
              ),
            ],
          ),
          if (!done && current != null) ...[
            const SizedBox(height: 11),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 11, vertical: 9),
              decoration: BoxDecoration(
                color: swms.warningBg,
                border: Border.all(color: swms.warning),
                borderRadius: BorderRadius.circular(AppDimens.rInput),
              ),
              child: Row(
                children: [
                  Container(
                    width: 30,
                    height: 30,
                    decoration: BoxDecoration(
                      color: swms.warning,
                      borderRadius: BorderRadius.circular(AppDimens.sm),
                    ),
                    child: const Icon(
                      Icons.gps_fixed,
                      size: 16,
                      color: Colors.white,
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          LocaleKeys.kitting_task_scan_any_of_batch
                              .tr()
                              .toUpperCase(),
                          style: AppTextStyles.caption.copyWith(
                            fontWeight: FontWeight.w800,
                            letterSpacing: .4,
                            color: swms.warning,
                          ),
                        ),
                        Text(
                          LocaleKeys.kitting_task_boxes_left.tr(
                            args: ['$remaining'],
                          ),
                          style: AppTextStyles.bodyStrong.copyWith(
                            fontWeight: FontWeight.w700,
                            color: swms.text1,
                          ),
                        ),
                      ],
                    ),
                  ),
                  if (current.productionDate != null)
                    StatusPill.neutral(
                      context,
                      label: LocaleKeys.kitting_task_mfg.tr(
                        args: [current.productionDate!.mmYYYY],
                      ),
                    ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}
