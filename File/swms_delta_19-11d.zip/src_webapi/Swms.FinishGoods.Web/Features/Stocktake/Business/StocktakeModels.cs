namespace Swms.FinishGoods.Web.Features.Stocktake.Business.Models;

public class CountSummaryDto
{
    public long Id { get; set; }
    public string DocNo { get; set; } = "";
    public string? CountType { get; set; }
    public DateTime CountDate { get; set; }
    public string DocStatus { get; set; } = "draft";
    public string? SourceRef { get; set; }
    public string? Description { get; set; }
    public int TotalLines { get; set; }
    public int CountedLines { get; set; }
    public int DiscrepancyLines { get; set; }

    /// <summary>
    /// Số dòng PHẢI ĐẾM và số trong đó đã đếm. 0 = API bản cũ chưa trả —
    /// khi đó <see cref="Required"/> lùi về TotalLines, giữ nguyên hành vi cũ.
    /// </summary>
    public int RequiredLines { get; set; }
    public int CountedRequiredLines { get; set; }

    /// <summary>Mẫu số của tiến độ: dòng phải đếm, không phải mọi dòng.</summary>
    public int Required => RequiredLines > 0 ? RequiredLines : TotalLines;
    public int CountedRequired => RequiredLines > 0 ? CountedRequiredLines : CountedLines;
    public DateTime CreatedAt { get; set; }
}

public class CountLineDto
{
    /// <summary>Thứ tự đi kiểm kê theo bản đồ (API đã sắp sẵn).</summary>
    public int WalkSeq { get; set; }
    public string? AreaCode { get; set; }
    public string? AreaName { get; set; }

    public long Id { get; set; }
    public int LineNo { get; set; }
    public int ProductId { get; set; }
    public string? ProductName { get; set; }
    public long LocatorId { get; set; }
    public string LocatorCode { get; set; } = "";
    public long? LotId { get; set; }
    public string? PalletId { get; set; }
    public string? Model { get; set; }
    public int QtySystem { get; set; }
    public int? QtyCount { get; set; }
    public bool IsAdjusted { get; set; }
    public string? Note { get; set; }

    /// <summary>Số box theo hệ thống; số lượng = box x StandardPacking (số cái/box của model).</summary>
    public int? BoxCountSystem { get; set; }
    /// <summary>Số box người kiểm đếm được.</summary>
    public int? BoxCountCounted { get; set; }
    /// <summary>Quy cách đóng gói chụp lúc tạo phiếu (master.models.standard_packing).</summary>
    public int? StandardPacking { get; set; }

    /// <summary>Pallet phát sinh khi kiểm (tìm thấy ở ô này, hệ thống ghi ở SystemLocatorCode).</summary>
    public bool IsFound { get; set; }
    public string? SystemLocatorCode { get; set; }

    /// <summary>
    /// Dòng này có phải ĐẾM không — chốt lúc tạo phiếu, không tính lại.
    ///
    /// Phiếu sáng chọn theo Ô: ô nào động thì mọi pallet đang đứng ở đó đều
    /// thành dòng. Dòng không phải đếm vẫn hiện trên Web để người đọc thấy
    /// đủ bối cảnh của ô, nhưng không vào tiến độ và PDA không hiện.
    /// Luôn true ở phiếu cuối tháng (kiểm hết).
    /// </summary>
    public bool IsRequired { get; set; } = true;
}

public class CountDetailDto
{
    public CountSummaryDto Header { get; set; } = new();
    public List<CountLineDto> Lines { get; set; } = new();
}

public class CreateCountRequestDto
{
    public string CountType { get; set; } = "monthly";
    public string? Description { get; set; }

    /// <summary>Chỉ dùng cho phiếu cuối tháng: các bản đồ lưu kho được tích; rỗng = mọi bản đồ.</summary>
    public List<string>? AreaCodes { get; set; }
}

public class CreateCountResultDto
{
    public long Id { get; set; }
    public string DocNo { get; set; } = "";
    public int LineCount { get; set; }
}

public class CountPreviewDto
{
    public string CountType { get; set; } = "";
    public int LocatorCount { get; set; }
    public int LineCount { get; set; }
}

/// <summary>Ghi chú của 1 dòng kiểm kê — lý do lệch, tình trạng thực tế.</summary>
public class SetNoteRequestDto
{
    public string? Note { get; set; }
}
