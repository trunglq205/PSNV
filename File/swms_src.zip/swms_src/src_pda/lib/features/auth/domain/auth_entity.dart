class AuthEntity {
  final String accessToken;
  final DateTime expiresAtUtc;
  final String username;
  final String fullName;

  const AuthEntity({
    required this.accessToken,
    required this.expiresAtUtc,
    required this.username,
    required this.fullName,
  });
}