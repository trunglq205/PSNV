using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.HdSoft.Business;
using Swms.FinishGoods.API.Features.ShipmentInstructions.Api;
using Swms.FinishGoods.API.Features.ShipmentInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Exceptions;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Business;

/*  Chạy song song SWMS với HD soft: SAP gửi SI cho cả hai, nên 2 bên phải có cùng SI, cùng
    header, cùng dòng / số lượng. Service nạp dữ liệu 2 DB (SQL Server + PostgreSQL) đồng thời,
    phần so nằm ở SiHdSoftComparer.

    Khoảng ngày theo VANNING ở từng hệ thống, rồi gộp SI_No của cả hai — SI mà SAP chỉ gửi
    được sang 1 bên vẫn lọt vào danh sách (only_swms / only_hdsoft).
      SWMS    : COALESCE(vanning_date, etd_date)                     — cùng định nghĩa màn Hàng thiếu
      HD soft : "Loading date" trong headernote3, không có thì ETD   — SiHdSoftComparer.HdVanning
    Chỉ từ hôm nay trở đi: mục đích là kịp sửa trước khi xuất, không xem lại quá khứ.      */
public class SiHdSoftCompareService : ISiHdSoftCompareService
{
    private const int MaxRangeDays = 62;
    private const int MaxSi = 2000;   // giới hạn tham số IN của SQL Server (2100)

    // Vanning luôn trước ETD; ETD thường cách vanning vài ngày tới vài tuần (giống HdSoftService.GetShortagesAsync).
    // headernote3 là text tự do, SQL không lọc được -> lọc thô HD soft theo ETD rộng hơn, rồi lọc đúng ở đây.
    private const int EtdAfterVanningDays = 45;

    private readonly IShipmentInstructionRepository _repo;
    private readonly IHdSoftService _hdSoft;
    private readonly IStringLocalizer<SharedResource> _localizer;

    public SiHdSoftCompareService(
        IShipmentInstructionRepository repo,
        IHdSoftService hdSoft,
        IStringLocalizer<SharedResource> localizer)
    {
        _repo = repo;
        _hdSoft = hdSoft;
        _localizer = localizer;
    }

    public async Task<SiCompareDetailResponse> CompareAsync(string siNo)
    {
        var key = siNo?.Trim() ?? "";
        if (key.Length == 0)
            throw new BusinessRuleException(_localizer["SiCompare.SiNoRequired"]);

        var keys = new[] { key };
        var swmsTask = LoadSwmsAsync(keys);
        var hdTask = _hdSoft.GetSiOrdersAsync(keys);
        await Task.WhenAll(swmsTask, hdTask);

        var (headers, lines) = swmsTask.Result;
        var swms = headers.FirstOrDefault();
        var hd = hdTask.Result.FirstOrDefault();
        if (swms is null && hd is null)
            throw new NotFoundException(_localizer["SiCompare.NotFound", key]);

        var schema = await _hdSoft.GetSiSchemaAsync();   // đã cache khi đọc phiếu
        return SiHdSoftComparer.Compare(
            key, swms, swms is null ? new List<SiLine>() : lines[swms.Id].ToList(), hd, schema);
    }

    public async Task<SiCompareListResponse> CompareRangeAsync(SiCompareQuery query)
    {
        var from = query.From!.Value.Date;
        var to = query.To!.Value.Date;
        if (from < DateTime.Today)
            throw new BusinessRuleException(_localizer["SiCompare.PastNotAllowed"]);
        if (to < from)
            throw new BusinessRuleException(_localizer["SiCompare.RangeInvalid"]);
        if ((to - from).TotalDays + 1 > MaxRangeDays)
            throw new BusinessRuleException(_localizer["SiCompare.RangeTooWide", MaxRangeDays]);

        var toExclusive = to.AddDays(1);
        var warehouse = string.IsNullOrWhiteSpace(query.Warehouse) ? null : query.Warehouse.Trim();
        bool InRange(DateTime? d) => d is { } v && v.Date >= from && v.Date < toExclusive;

        // 1. SI_No có vanning trong khoảng ở mỗi bên.
        //    SWMS   : lọc thẳng trong SQL.
        //    HD soft: lọc thô theo ETD [from, to + 45 ngày), đọc phiếu, lọc đúng theo vanning.
        var swmsNosTask = _repo.GetSiNosByVanningAsync(from, toExclusive);
        var hdCoarseTask = _hdSoft.GetSiNosByEtdAsync(from, toExclusive.AddDays(EtdAfterVanningDays), warehouse);
        await Task.WhenAll(swmsNosTask, hdCoarseTask);

        var hdOrders = (await _hdSoft.GetSiOrdersAsync(hdCoarseTask.Result)).ToList();
        var hdNos = hdOrders
            .Where(o => !HdSoftDocStatus.IsCancelled(o.DocStatus) && InRange(SiHdSoftComparer.HdVanning(o)))
            .Select(o => o.SiNo);

        var siNos = swmsNosTask.Result.Concat(hdNos)
            .Select(x => x?.Trim() ?? "")
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();
        if (siNos.Count > MaxSi)
            throw new BusinessRuleException(_localizer["SiCompare.TooMany", siNos.Count, MaxSi]);

        // 2. Nạp SWMS cho các SI_No. Phía HD soft chỉ nạp thêm SI chưa có ở bước 1
        //    (vanning trong khoảng bên SWMS nhưng bên HD soft lệch ra ngoài — vẫn so, sẽ báo lệch).
        var loaded = hdOrders.Select(o => o.SiNo.Trim()).ToHashSet(StringComparer.OrdinalIgnoreCase);
        var missingHd = siNos.Where(x => !loaded.Contains(x)).ToList();

        var swmsTask = LoadSwmsAsync(siNos);
        var hdMoreTask = missingHd.Count == 0
            ? Task.FromResult<IReadOnlyList<HdSoftSiOrder>>(Array.Empty<HdSoftSiOrder>())
            : _hdSoft.GetSiOrdersAsync(missingHd);
        await Task.WhenAll(swmsTask, hdMoreTask);
        var schema = await _hdSoft.GetSiSchemaAsync();

        var (headers, lines) = swmsTask.Result;
        var swmsByNo = headers
            .GroupBy(h => h.SiNo.Trim(), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.First(), StringComparer.OrdinalIgnoreCase);
        var hdByNo = hdOrders.Concat(hdMoreTask.Result)
            .GroupBy(o => o.SiNo.Trim(), StringComparer.OrdinalIgnoreCase)
            .ToDictionary(g => g.Key, g => g.OrderByDescending(o => o.Created).First(), StringComparer.OrdinalIgnoreCase);

        // 3. So từng SI
        var all = new List<SiCompareSummaryResponse>(siNos.Count);
        foreach (var siNo in siNos)
        {
            swmsByNo.TryGetValue(siNo, out var swms);
            hdByNo.TryGetValue(siNo, out var hd);
            if (swms is null && hd is null) continue;   // vừa bị xoá giữa 2 bước

            var swmsLines = swms is null ? new List<SiLine>() : lines[swms.Id].ToList();
            var summary = SiHdSoftComparer.Compare(siNo, swms, swmsLines, hd, schema).Summary;

            // Lọc lại theo vanning thật (SWMS trước; chỉ có ở HD soft thì bên HD soft).
            // Bước 1 phía HD soft quét ETD rộng nên kéo cả SI vanning ngoài khoảng vào — bỏ ở đây.
            if (summary.VanningDate is not null && !InRange(summary.VanningDate)) continue;

            all.Add(summary);
        }

        // Có vấn đề lên trước, trong nhóm thì vanning gần nhất trước (sắp xuất -> cần sửa trước)
        var items = all
            .Where(x => !query.OnlyIssues || x.Result != SiHdSoftComparer.Match)
            .OrderBy(x => x.Result == SiHdSoftComparer.Match ? 1 : 0)
            .ThenBy(x => x.VanningDate ?? DateTime.MaxValue)
            .ThenBy(x => x.SiNo)
            .ToList();

        return new SiCompareListResponse(
            From: from,
            To: to,
            Warehouse: warehouse,
            Total: all.Count,
            Matched: all.Count(x => x.Result == SiHdSoftComparer.Match),
            Mismatched: all.Count(x => x.Result == SiHdSoftComparer.Mismatch),
            OnlySwms: all.Count(x => x.Result == SiHdSoftComparer.OnlySwms),
            OnlyHdSoft: all.Count(x => x.Result == SiHdSoftComparer.OnlyHdSoft),
            Items: items,
            ComparedAt: DateTime.Now);
    }

    private async Task<(List<SiHeader> Headers, ILookup<long, SiLine> Lines)> LoadSwmsAsync(
        IReadOnlyCollection<string> siNos)
    {
        var headers = await _repo.GetHeadersBySiNosAsync(siNos);
        var lines = headers.Count == 0
            ? new List<SiLine>()
            : await _repo.GetLinesBySiIdsAsync(headers.Select(h => h.Id).ToList());
        return (headers, lines.ToLookup(l => l.SiId));
    }
}