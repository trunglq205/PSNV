﻿namespace SWMS_WebTool.Models.Requests
{
    public class LoginRequest
    {
        public string? UserId { get; set; }
        public string? Password { get; set; }
    }

    public class ChangePasswordRequest
    {
        public string? PasswordOld { get; set; }
        public string? PasswordNew { get; set; }
    }
}
