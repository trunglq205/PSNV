using ShippingScs.Web.Services;

namespace ShippingScs.Tests;

public class WorkingCalendarTests
{
    // Lịch T2–T6 năm 2026, CN và T7 nghỉ, đánh dấu thêm 1 ngày lễ giả định.
    private static WorkingCalendarSnapshot Build2026(params DateOnly[] holidays)
    {
        var days = WorkingCalendarService.BuildYear("PSNV", 2026, saturdayIsWorking: false)
            .ToDictionary(d => DateOnly.FromDateTime(d.Date), d => d.IsWorking);
        foreach (var h in holidays) days[h] = false;
        return new WorkingCalendarSnapshot("PSNV", new DateOnly(2026, 1, 1), new DateOnly(2026, 12, 31), days);
    }

    [Fact]
    public void BuildYear_has_every_day_and_weekends_off()
    {
        var rows = WorkingCalendarService.BuildYear("PSNV", 2026, false);
        Assert.Equal(365, rows.Count);
        Assert.All(rows, r =>
        {
            var dow = r.Date.DayOfWeek;
            var expectedOff = dow == DayOfWeek.Saturday || dow == DayOfWeek.Sunday;
            Assert.Equal(!expectedOff, r.IsWorking);
        });
    }

    [Fact]
    public void BuildYear_saturday_working()
    {
        var rows = WorkingCalendarService.BuildYear("PSNV", 2026, true);
        Assert.All(rows.Where(r => r.Date.DayOfWeek == DayOfWeek.Saturday), r => Assert.True(r.IsWorking));
        Assert.All(rows.Where(r => r.Date.DayOfWeek == DayOfWeek.Sunday), r => Assert.False(r.IsWorking));
    }

    [Fact]
    public void Fifth_working_day_of_july_2026()
    {
        // 01/07/2026 là thứ Tư: T4 1, T5 2, T6 3, T2 6, T3 7
        Assert.Equal(new DateOnly(2026, 7, 7), Build2026().GetNthWorkingDayOfMonth(2026, 7, 5));
    }

    [Fact]
    public void Nth_working_day_skips_holiday()
    {
        var cal = Build2026(new DateOnly(2026, 7, 2));
        Assert.Equal(new DateOnly(2026, 7, 8), cal.GetNthWorkingDayOfMonth(2026, 7, 5));
    }

    [Fact]
    public void Nth_working_day_beyond_month_throws()
    {
        Assert.Throws<CalendarNotConfiguredException>(() => Build2026().GetNthWorkingDayOfMonth(2026, 7, 30));
    }

    [Fact]
    public void Minus_one_working_day_from_monday_is_friday()
    {
        // Ex-factory AIR = ETD - 1 ngày làm việc. ETD thứ Hai 06/07 -> thứ Sáu 03/07
        Assert.Equal(new DateOnly(2026, 7, 3), Build2026().AddWorkingDays(new DateOnly(2026, 7, 6), -1));
    }

    [Fact]
    public void Plus_five_working_days()
    {
        // Thứ Ba 07/07 + 5 ngày làm việc = thứ Ba 14/07
        Assert.Equal(new DateOnly(2026, 7, 14), Build2026().AddWorkingDays(new DateOnly(2026, 7, 7), 5));
    }

    [Fact]
    public void Zero_days_returns_same_date_even_if_weekend()
    {
        var sunday = new DateOnly(2026, 7, 5);
        Assert.Equal(sunday, Build2026().AddWorkingDays(sunday, 0));
    }

    [Fact]
    public void OnOrAfter_and_OnOrBefore_from_sunday()
    {
        var cal = Build2026();
        var sunday = new DateOnly(2026, 7, 5);
        Assert.Equal(new DateOnly(2026, 7, 6), cal.OnOrAfter(sunday));
        Assert.Equal(new DateOnly(2026, 7, 3), cal.OnOrBefore(sunday));
    }

    [Fact]
    public void Count_working_days_in_july_2026()
    {
        Assert.Equal(23, Build2026().CountWorkingDays(new DateOnly(2026, 7, 1), new DateOnly(2026, 7, 31)));
    }

    [Fact]
    public void Date_outside_loaded_range_throws()
    {
        // Không đoán: ngày chưa nạp phải báo lỗi
        Assert.Throws<CalendarNotConfiguredException>(() => Build2026().IsWorkingDay(new DateOnly(2027, 1, 4)));
    }

    [Fact]
    public void Missing_day_inside_range_throws()
    {
        var days = WorkingCalendarService.BuildYear("PSNV", 2026, false)
            .ToDictionary(d => DateOnly.FromDateTime(d.Date), d => d.IsWorking);
        days.Remove(new DateOnly(2026, 7, 7));
        var cal = new WorkingCalendarSnapshot("PSNV", new DateOnly(2026, 1, 1), new DateOnly(2026, 12, 31), days);

        Assert.Throws<CalendarNotConfiguredException>(() => cal.GetNthWorkingDayOfMonth(2026, 7, 5));
    }

    [Theory]
    [InlineData("X DUNG")]
    [InlineData("X.DUNG")]
    [InlineData("x.dung")]
    public void Pic_code_normalization(string raw)
    {
        Assert.Equal("XDUNG", UserService.NormalizePicCode(raw));
    }
}
