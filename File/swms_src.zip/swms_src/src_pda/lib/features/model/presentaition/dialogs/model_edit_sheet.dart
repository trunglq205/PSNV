import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_bottom_sheet.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/number_dial_dialog.dart';
import 'package:swms_finish_goods/features/model/domain/model_detail_entities.dart';
import 'package:swms_finish_goods/features/part_card/presentation/dialogs/adjust_value_dialog.dart';

/// Mở sheet chỉnh sửa model. Trả null nếu huỷ.
///
/// Mỗi ô chạm để mở dialog: số dùng dial (showNumberDialDialog), GTIN dùng
/// showEditTextDialog. Gợi ý lưu kho KHÔNG sửa ở đây, giữ nguyên từ [model].
Future<ModelEdit?> showModelEditSheet(
  BuildContext context, {
  required ModelDetail model,
}) {
  return showAppBottomSheet<ModelEdit>(
    context,
    builder: (_) => _ModelEditSheet(model: model),
  );
}

class _ModelEditSheet extends StatefulWidget {
  const _ModelEditSheet({required this.model});

  final ModelDetail model;

  @override
  State<_ModelEditSheet> createState() => _ModelEditSheetState();
}

class _ModelEditSheetState extends State<_ModelEditSheet> {
  ModelDetail get _m => widget.model;

  late String _gtin = (_m.gtin ?? '').trim();
  late int _length = _m.length;
  late int _width = _m.width;
  late int _height = _m.height;
  late int _packing = _m.standardPacking;
  late int? _stackLength = _m.stackingLength;
  late int? _stackWidth = _m.stackingWidth;
  late int? _layerCount = _m.layerCount;
  late int? _layerLimit = _m.layerLimit;

  bool get _gtinTooLong => _gtin.length > ModelEdit.maxGtinLength;

  /// Dial số nguyên 0..[max]. Trả null nếu huỷ.
  Future<int?> _pickNumber(
    String label,
    int value,
    int max, {
    String? unit,
  }) async {
    final result = await showNumberDialDialog(
      context,
      title: label,
      unit: unit,
      value: value,
      maxValue: max,
    );
    return result?.toInt();
  }

  /// Ô bắt buộc (kích thước, SL/thùng).
  Future<void> _editRequired(
    String label,
    int value,
    ValueChanged<int> apply, {
    String? unit,
  }) async {
    final v = await _pickNumber(
      label,
      value,
      ModelEdit.maxDimension,
      unit: unit,
    );
    if (v != null && mounted) setState(() => apply(v));
  }

  /// Ô tuỳ chọn (xếp / lớp): API nhận 1..max hoặc null.
  /// Dial không biểu diễn được "trống" nên quy ước 0 = xoá giá trị (null).
  Future<void> _editOptional(
    String label,
    int? value,
    int max,
    ValueChanged<int?> apply,
  ) async {
    final v = await _pickNumber(label, value ?? 0, max);
    if (v != null && mounted) setState(() => apply(v == 0 ? null : v));
  }

  Future<void> _editGtin(String label) async {
    final v = await showEditTextDialog(context, label: label, value: _gtin);
    // Rỗng = xoá GTIN (repository đổi '' -> null).
    if (v != null && mounted) setState(() => _gtin = v);
  }

  void _submit() {
    Navigator.pop(
      context,
      ModelEdit(
        gtin: _gtin,
        length: _length,
        width: _width,
        height: _height,
        standardPacking: _packing,
        stackingLength: _stackLength,
        stackingWidth: _stackWidth,
        layerCount: _layerCount,
        layerLimit: _layerLimit,
        // Không sửa ở sheet này — giữ nguyên để PUT không xoá mất gợi ý.
        suggestAreaId: _m.suggestAreaId,
        suggestRackRow: _m.suggestRackRow,
      ),
    );
  }

  Widget _requiredCell(
    String labelKey,
    int value,
    ValueChanged<int> apply, {
    String unit = 'mm',
  }) {
    final label = labelKey.tr();
    return Expanded(
      child: _EditCell(
        label: label,
        value: '$value',
        unit: unit,
        onTap: () => _editRequired(label, value, apply, unit: unit),
      ),
    );
  }

  Widget _optionalCell(
    String labelKey,
    int? value,
    int max,
    ValueChanged<int?> apply,
  ) {
    final label = labelKey.tr();
    return Expanded(
      child: _EditCell(
        label: label,
        value: value?.toString() ?? '',
        onTap: () => _editOptional(label, value, max, apply),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    const gap = SizedBox(width: AppDimens.sm);
    const vGap = SizedBox(height: AppDimens.sm);
    final gtinLabel = 'model_detail.gtin'.tr();

    return AppBottomSheet(
      icon: Icons.edit_outlined,
      title: 'model_detail.edit_title'.tr(),
      subtitle: _m.code,
      actions: [
        AppDialogAction.cancel(context),
        AppDialogAction.confirm(onPressed: _gtinTooLong ? null : _submit),
      ],
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        mainAxisSize: MainAxisSize.min,
        children: [
          _EditCell(
            label: gtinLabel,
            value: _gtin,
            error: _gtinTooLong,
            onTap: () => _editGtin(gtinLabel),
          ),
          if (_gtinTooLong) ...[
            const SizedBox(height: AppDimens.xs),
            Text(
              'model_detail.gtin_max_length'.tr(
                args: ['${ModelEdit.maxGtinLength}'],
              ),
              style: AppTextStyles.caption.copyWith(color: swms.danger),
            ),
          ],
          vGap,
          Row(
            children: [
              _requiredCell('model_detail.length', _length, (v) => _length = v),
              gap,
              _requiredCell('model_detail.width', _width, (v) => _width = v),
            ],
          ),
          vGap,
          Row(
            children: [
              _requiredCell('model_detail.height', _height, (v) => _height = v),
              gap,
              _requiredCell(
                'model_detail.standard_packing',
                _packing,
                (v) => _packing = v,
                unit: 'pcs',
              ),
            ],
          ),
          vGap,
          Row(
            children: [
              _optionalCell(
                'model_detail.stacking_length',
                _stackLength,
                ModelEdit.maxStacking,
                (v) => _stackLength = v,
              ),
              gap,
              _optionalCell(
                'model_detail.stacking_width',
                _stackWidth,
                ModelEdit.maxStacking,
                (v) => _stackWidth = v,
              ),
            ],
          ),
          vGap,
          Row(
            children: [
              _optionalCell(
                'model_detail.layer_count',
                _layerCount,
                ModelEdit.maxLayer,
                (v) => _layerCount = v,
              ),
              gap,
              _optionalCell(
                'model_detail.layer_limit',
                _layerLimit,
                ModelEdit.maxLayer,
                (v) => _layerLimit = v,
              ),
            ],
          ),
          const SizedBox(height: AppDimens.md),
          Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: const EdgeInsets.only(top: 1),
                child: Icon(
                  Icons.touch_app_outlined,
                  size: 12,
                  color: swms.primary,
                ),
              ),
              const SizedBox(width: 6),
              Expanded(
                child: Text(
                  'model_detail.edit_hint'.tr(),
                  style: AppTextStyles.caption.copyWith(color: swms.text3),
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

/// Ô hiển thị 1 trường của sheet — chạm để mở dialog sửa.
class _EditCell extends StatelessWidget {
  const _EditCell({
    required this.label,
    required this.value,
    required this.onTap,
    this.unit = '',
    this.error = false,
  });

  final String label;

  /// Rỗng → hiện "—".
  final String value;
  final String unit;
  final bool error;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    final empty = value.isEmpty;
    final radius = BorderRadius.circular(AppDimens.rInput);

    return Material(
      color: swms.card2,
      borderRadius: radius,
      child: InkWell(
        onTap: onTap,
        borderRadius: radius,
        child: Container(
          padding: const EdgeInsets.symmetric(
            horizontal: AppDimens.sm,
            vertical: AppDimens.sm,
          ),
          decoration: BoxDecoration(
            borderRadius: radius,
            border: Border.all(
              color: error ? swms.danger : swms.border,
              width: error ? 1.2 : 1,
            ),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                label,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.caption.copyWith(
                  color: error ? swms.danger : swms.text3,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                empty ? '—' : (unit.isEmpty ? value : '$value $unit'),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: AppTextStyles.code.copyWith(
                  fontWeight: FontWeight.w700,
                  color: error
                      ? swms.danger
                      : (empty ? swms.text4 : swms.text1),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
