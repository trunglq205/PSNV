using Swms.FinishGoods.API.Features.WeightSys.DataAccess;
using System.Text.Json.Serialization;

namespace Swms.FinishGoods.API.Features.WeightSys.Api;

public record WeightResponse(
    [property: JsonPropertyName("serial_no")] string SerialNo,
    [property: JsonPropertyName("model_no")] string ModelNo,
    [property: JsonPropertyName("weight")] decimal Weight,
    [property: JsonPropertyName("datetime")] DateTime TmrDate)
{
    public static WeightResponse From(
        WeightDto dto)
        => new(
            dto.Serial,
            dto.ProcessFactory,
            dto.Weight,
            dto.TmrDate);
}

public record GetBoxWeightsRequest(
    [property: JsonPropertyName("group_ids")]
    List<string> GroupIds);
