﻿using Dapper;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Shared.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;
using System.Data;

namespace Swms.FinishGoods.API.Features.StockEvents.DataAccess
{
    /// <summary>
    /// Ghi event vào wms.stock_events.
    ///
    /// Vì sao có overload nhận sẵn connection + transaction:
    /// ChangeLocatorAsync / ExecuteSplitAsync / AddAsync / SoftDeleteAsync TỰ MỞ
    /// connection và transaction bên trong repository. Nếu writer mở connection
    /// riêng thì event vẫn được ghi kể cả khi nghiệp vụ rollback — lịch sử sẽ nói
    /// dối. Luôn gọi overload có transaction khi caller đang mở một transaction,
    /// và gọi TRƯỚC tx.Commit().
    /// </summary>
    public interface IStockEventWriter
    {
        /// <summary>Ghi trong transaction đang mở của caller.</summary>
        Task WriteAsync(IDbConnection conn, IDbTransaction? tx, StockEvent e);

        /// <summary>Ghi nhiều event trong cùng transaction của caller.</summary>
        Task WriteManyAsync(IDbConnection conn, IDbTransaction? tx, IEnumerable<StockEvent> events);

        /// <summary>Tự mở connection — chỉ dùng khi KHÔNG có transaction bao ngoài.</summary>
        Task WriteAsync(StockEvent e);
    }

    public class StockEventWriter : IStockEventWriter
    {
        private const string Proc = "wms.usp_stock_event_add";

        private readonly IDbConnectionFactory _factory;
        private readonly IRequestSource _requestSource;

        public StockEventWriter(IDbConnectionFactory factory, IRequestSource requestSource)
        {
            _factory = factory;
            _requestSource = requestSource;
        }

        public Task WriteAsync(IDbConnection conn, IDbTransaction? tx, StockEvent e)
            => conn.ExecuteAsync(Proc, ToParams(e), tx, commandType: CommandType.StoredProcedure);

        public async Task WriteManyAsync(
            IDbConnection conn, IDbTransaction? tx, IEnumerable<StockEvent> events)
        {
            foreach (var e in events)
                await WriteAsync(conn, tx, e);
        }

        public async Task WriteAsync(StockEvent e)
        {
            using var conn = _factory.Create();
            await conn.ExecuteAsync(Proc, ToParams(e), commandType: CommandType.StoredProcedure);
        }

        /// <summary>
        /// Nguồn ghi vào DB.
        ///
        /// WEB là giá trị MẶC ĐỊNH của <see cref="StockEvent.Source"/>, tức là
        /// "caller không khai nguồn" — khi đó lấy nguồn thật của request
        /// (header X-Client). Caller khai tường minh một nguồn khác
        /// (FOSS / HDSOFT / SAP / JOB ở các luồng đồng bộ) thì giữ nguyên.
        ///
        /// Hệ quả: không có cách nào khai "WEB" một cách tường minh nữa. Chấp
        /// nhận được, vì WEB vốn chỉ là giá trị khi chưa biết, và request thật
        /// từ Web vẫn ra WEB (header thiếu hoặc X-Client: WEB).
        /// </summary>
        private string ResolveSource(StockEvent e)
            => e.Source == StockEventSources.Web ? _requestSource.Current : e.Source;

        // Tên tham số phải khớp đúng proc (snake_case).
        private DynamicParameters ToParams(StockEvent e)
        {
            var p = new DynamicParameters();
            p.Add("@event_code", e.EventCode);
            p.Add("@subject_type", e.SubjectType);
            p.Add("@pallet_id", e.PalletId);
            p.Add("@box_id", e.BoxId);
            p.Add("@actor", e.Actor);
            p.Add("@source", ResolveSource(e));
            p.Add("@from_locator_id", e.FromLocatorId);
            p.Add("@to_locator_id", e.ToLocatorId);
            p.Add("@ref_type", e.RefType);
            p.Add("@ref_id", e.RefId);
            p.Add("@ref_no", e.RefNo);
            p.Add("@related_pallet_id", e.RelatedPalletId);
            p.Add("@box_count_before", e.BoxCountBefore);
            p.Add("@box_count_after", e.BoxCountAfter);
            p.Add("@note", e.Note);
            p.Add("@payload", e.Payload);
            p.Add("@event_at", e.EventAt);
            return p;
        }
    }
}