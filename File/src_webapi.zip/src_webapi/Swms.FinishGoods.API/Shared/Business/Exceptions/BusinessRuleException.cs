namespace Swms.FinishGoods.API.Common.Business.Exceptions;

/// <summary>
/// Thrown when a business rule is violated (maps to HTTP 400).
/// </summary>
public class BusinessRuleException : Exception
{
    public BusinessRuleException(string message) : base(message) { }
}
