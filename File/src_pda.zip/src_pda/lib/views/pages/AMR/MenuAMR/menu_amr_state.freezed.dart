// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'menu_amr_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$MenuAmrState {
  PageStatus get pageStatus => throw _privateConstructorUsedError;
  bool get processing => throw _privateConstructorUsedError;
  ErrorEntity? get errorEntity => throw _privateConstructorUsedError;
  String? get Name => throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $MenuAmrStateCopyWith<MenuAmrState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $MenuAmrStateCopyWith<$Res> {
  factory $MenuAmrStateCopyWith(
          MenuAmrState value, $Res Function(MenuAmrState) then) =
      _$MenuAmrStateCopyWithImpl<$Res, MenuAmrState>;
  @useResult
  $Res call(
      {PageStatus pageStatus,
      bool processing,
      ErrorEntity? errorEntity,
      String? Name});
}

/// @nodoc
class _$MenuAmrStateCopyWithImpl<$Res, $Val extends MenuAmrState>
    implements $MenuAmrStateCopyWith<$Res> {
  _$MenuAmrStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pageStatus = null,
    Object? processing = null,
    Object? errorEntity = freezed,
    Object? Name = freezed,
  }) {
    return _then(_value.copyWith(
      pageStatus: null == pageStatus
          ? _value.pageStatus
          : pageStatus // ignore: cast_nullable_to_non_nullable
              as PageStatus,
      processing: null == processing
          ? _value.processing
          : processing // ignore: cast_nullable_to_non_nullable
              as bool,
      errorEntity: freezed == errorEntity
          ? _value.errorEntity
          : errorEntity // ignore: cast_nullable_to_non_nullable
              as ErrorEntity?,
      Name: freezed == Name
          ? _value.Name
          : Name // ignore: cast_nullable_to_non_nullable
              as String?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$MenuAmrStateImplCopyWith<$Res>
    implements $MenuAmrStateCopyWith<$Res> {
  factory _$$MenuAmrStateImplCopyWith(
          _$MenuAmrStateImpl value, $Res Function(_$MenuAmrStateImpl) then) =
      __$$MenuAmrStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {PageStatus pageStatus,
      bool processing,
      ErrorEntity? errorEntity,
      String? Name});
}

/// @nodoc
class __$$MenuAmrStateImplCopyWithImpl<$Res>
    extends _$MenuAmrStateCopyWithImpl<$Res, _$MenuAmrStateImpl>
    implements _$$MenuAmrStateImplCopyWith<$Res> {
  __$$MenuAmrStateImplCopyWithImpl(
      _$MenuAmrStateImpl _value, $Res Function(_$MenuAmrStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pageStatus = null,
    Object? processing = null,
    Object? errorEntity = freezed,
    Object? Name = freezed,
  }) {
    return _then(_$MenuAmrStateImpl(
      pageStatus: null == pageStatus
          ? _value.pageStatus
          : pageStatus // ignore: cast_nullable_to_non_nullable
              as PageStatus,
      processing: null == processing
          ? _value.processing
          : processing // ignore: cast_nullable_to_non_nullable
              as bool,
      errorEntity: freezed == errorEntity
          ? _value.errorEntity
          : errorEntity // ignore: cast_nullable_to_non_nullable
              as ErrorEntity?,
      Name: freezed == Name
          ? _value.Name
          : Name // ignore: cast_nullable_to_non_nullable
              as String?,
    ));
  }
}

/// @nodoc

class _$MenuAmrStateImpl implements _MenuAmrState {
  _$MenuAmrStateImpl(
      {this.pageStatus = PageStatus.initial,
      this.processing = false,
      this.errorEntity = null,
      this.Name = null});

  @override
  @JsonKey()
  final PageStatus pageStatus;
  @override
  @JsonKey()
  final bool processing;
  @override
  @JsonKey()
  final ErrorEntity? errorEntity;
  @override
  @JsonKey()
  final String? Name;

  @override
  String toString() {
    return 'MenuAmrState(pageStatus: $pageStatus, processing: $processing, errorEntity: $errorEntity, Name: $Name)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$MenuAmrStateImpl &&
            (identical(other.pageStatus, pageStatus) ||
                other.pageStatus == pageStatus) &&
            (identical(other.processing, processing) ||
                other.processing == processing) &&
            (identical(other.errorEntity, errorEntity) ||
                other.errorEntity == errorEntity) &&
            (identical(other.Name, Name) || other.Name == Name));
  }

  @override
  int get hashCode =>
      Object.hash(runtimeType, pageStatus, processing, errorEntity, Name);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$MenuAmrStateImplCopyWith<_$MenuAmrStateImpl> get copyWith =>
      __$$MenuAmrStateImplCopyWithImpl<_$MenuAmrStateImpl>(this, _$identity);
}

abstract class _MenuAmrState implements MenuAmrState {
  factory _MenuAmrState(
      {final PageStatus pageStatus,
      final bool processing,
      final ErrorEntity? errorEntity,
      final String? Name}) = _$MenuAmrStateImpl;

  @override
  PageStatus get pageStatus;
  @override
  bool get processing;
  @override
  ErrorEntity? get errorEntity;
  @override
  String? get Name;
  @override
  @JsonKey(ignore: true)
  _$$MenuAmrStateImplCopyWith<_$MenuAmrStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
