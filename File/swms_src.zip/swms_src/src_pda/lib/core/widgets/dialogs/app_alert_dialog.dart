import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/buttons/app_button.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';

enum AppAlertDialogType { confirm, success, error, info }

/// Dialog báo kết quả / hỏi xác nhận: icon tròn lớn + tiêu đề + mô tả.
/// Trả về true (confirm) / false (cancel) qua Navigator.pop.
///
/// Dựng trên [AppDialog] nên nền, viền, bóng và lớp phủ khớp với mọi dialog
/// khác — đổi màu vỏ thì sửa một chỗ ở AppDialog, không sửa ở đây.
class AppAlertDialog extends StatelessWidget {
  final AppAlertDialogType type;
  final String title;
  final String? message;
  final String confirmText;

  /// null => không có nút huỷ.
  final String? cancelText;

  const AppAlertDialog({
    super.key,
    required this.type,
    required this.title,
    this.message,
    this.confirmText = 'OK',
    this.cancelText,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    // `info` trước đây dùng scheme.error -> dialog thông báo hiện icon đỏ.
    // Giờ theo primary cho đúng ngữ nghĩa.
    final (IconData icon, Color color) = switch (type) {
      AppAlertDialogType.success => (Icons.check_circle_rounded, swms.success),
      AppAlertDialogType.error => (Icons.error_rounded, swms.danger),
      AppAlertDialogType.info => (Icons.info_rounded, swms.primary),
      AppAlertDialogType.confirm => (Icons.help_rounded, swms.warning),
    };

    final AppButtonVariant confirmVariant = switch (type) {
      AppAlertDialogType.success => AppButtonVariant.success,
      AppAlertDialogType.error => AppButtonVariant.danger,
      AppAlertDialogType.info => AppButtonVariant.primary,
      AppAlertDialogType.confirm => AppButtonVariant.warning,
    };

    final cancel = cancelText;

    return AppDialog(
      hero: AppDialogHeroIcon(icon: icon, color: color),
      title: title,
      message: message,
      actions: [
        if (cancel != null)
          AppDialogAction.cancel(context, label: cancel, result: false),
        AppDialogAction.confirm(
          label: confirmText,
          variant: confirmVariant,
          onPressed: () => Navigator.of(context).pop(true),
        ),
      ],
    );
  }
}