import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_dialog.dart';
import 'package:swms_finish_goods/core/widgets/dialogs/app_pick_dialog.dart';
import 'package:swms_finish_goods/features/receiving/domain/entities/category.dart';
import 'package:swms_finish_goods/features/receiving/presentation/providers/category_providers.dart';

/// Mở dialog chọn Category. Trả về null nếu huỷ hoặc không tải được danh mục.
///
/// API lỗi → dialog báo lỗi + "Thử lại"; KHÔNG cho chọn khi chưa có danh sách.
Future<Category?> showPickCategoryDialog(
  BuildContext context,
  WidgetRef ref, {
  Category? selected,
}) async {
  while (true) {
    final List<Category> items;
    try {
      items = await ref.readCategories();
    } catch (_) {
      if (!context.mounted) return null;
      final retry = await showAppDialog<bool>(
        context,
        builder: (ctx) => AppDialog(
          icon: Icons.cloud_off_rounded,
          title: LocaleKeys.category_load_failed_title.tr(),
          message: LocaleKeys.category_load_failed_body.tr(),
          actions: [
            AppDialogAction.close(ctx),
            AppDialogAction.confirm(
              label: LocaleKeys.category_retry.tr(),
              icon: Icons.refresh_rounded,
              onPressed: () => Navigator.of(ctx).pop(true),
            ),
          ],
        ),
      );
      if (retry != true) return null;
      continue; // readCategories() tự invalidate khi đang lỗi
    }

    if (!context.mounted) return null;
    return showPickDialog<Category>(
      context,
      title: 'Category',
      items: items,
      labelOf: (c) => '${c.value} - ${c.key}',
      selected: selected,
    );
  }
}
