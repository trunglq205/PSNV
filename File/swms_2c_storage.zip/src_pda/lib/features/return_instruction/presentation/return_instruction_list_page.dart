import 'package:auto_route/auto_route.dart';
import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:swms_finish_goods/core/errors/error_provider.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/resources.dart';
import 'package:swms_finish_goods/core/router/app_router.gr.dart';
import 'package:swms_finish_goods/core/widgets/common/app_tab_bar.dart';
import 'package:swms_finish_goods/core/widgets/widgets.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_back_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/domain/entities/return_instruction_entities.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/dialogs/return_diff_dialog.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/return_fa_pallet_page.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_back_providers.dart';
import 'package:swms_finish_goods/features/return_instruction/presentation/providers/return_instruction_providers.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';
import 'package:swms_finish_goods/shared/presentation/providers/permission_providers.dart';

// ─────────────────────────────────────────────────────────────
//  Màn Chỉ thị back hàng.
//  SCS Office nhập model / SL / ngày hàng về bên Web; SCS WH mở màn này để
//  biết sắp nhận gì, rồi quét nhận và chốt SL thực nhận.
//  Chạm vào một phiếu để bung chi tiết dòng. Kéo xuống để tải lại.
//
//  QUYỀN — giữ khớp từng dòng với controller bên API:
//    Tạo Pallet ID     → rework_refurbish.process
//                        (POST return-instructions/{id}/pallets)
//    Chốt thực nhận    → rework_refurbish.process HOẶC .create
//                        (POST return-instructions/{id}/close)
//    Giao hàng cho FA  → rework_refurbish.process
//                        (POST return-back-requests/{id}/deliver)
//  Không có quyền thì ẨN nút, không phải để bấm rồi ăn 403: giữa lúc quét
//  hàng thì một toast lỗi đỏ làm người dùng tưởng máy hỏng.
// ─────────────────────────────────────────────────────────────

/// Mã quyền — chép tay vì PDA không sinh hằng số quyền như bên Web.
/// Sai một ký tự là nút biến mất IM LẶNG, nên để một chỗ chứ đừng rải chuỗi.
const String _permProcess = 'rework_refurbish.process';
const String _permCreate = 'rework_refurbish.create';

/// Mục 2d — quyền của FA, KHÁC hẳn hai quyền trên của SCS. Khớp
/// `[RequirePermission<…ProcessFa>]` trên `POST {docId}/fa-pallets`.
const String _permProcessFa = 'rework_refurbish.process_fa';

@RoutePage()
class ReturnInstructionListPage extends ConsumerStatefulWidget {
  const ReturnInstructionListPage({super.key});

  @override
  ConsumerState<ReturnInstructionListPage> createState() =>
      _ReturnInstructionListPageState();
}

class _ReturnInstructionListPageState
    extends ConsumerState<ReturnInstructionListPage> {
  ReturnFilter _filter = ReturnFilter.open;

  /// Id phiếu đang bung chi tiết. Chỉ một phiếu mở tại một thời điểm —
  /// màn PDA hẹp, mở nhiều phiếu là phải cuộn rất xa mới thấy phiếu kế tiếp.
  int? _expanded;

  /// Mục 2b — chốt SL thực nhận.
  ///
  /// Cho người dùng xem BẢNG LỆCH trước khi xác nhận: bấm chốt là server gửi
  /// mail cho FA ngay, mà nội dung mail chính là bảng đó.
  Future<void> _close(ReturnInstruction doc) async {
    final ok = await showReturnDiffDialog(context, doc: doc);
    if (!ok || !mounted) return;

    // Lỗi API đã được appActionProvider bắt + toast → null.
    final saved = await ref.read(appActionProvider.notifier).run(
          () => ref.read(returnInstructionRepositoryProvider).close(doc.id),
        );
    if (!mounted || saved == null) return;

    ref.invalidate(returnInstructionListProvider);

    // Mail hỏng KHÔNG làm đổ việc chốt — nói ra để WH biết mà nhắc Office,
    // thay vì tưởng FA đã nhận được số.
    if (saved.actualMailSentAt == null) {
      AppToastHelper.toastWarning(
        context,
        LocaleKeys.return_receive_closed_mail_failed
            .tr(namedArgs: {'docNo': saved.docNo}),
      );
    } else {
      AppToastHelper.toastSuccess(
        context,
        LocaleKeys.return_receive_closed_ok
            .tr(namedArgs: {'docNo': saved.docNo}),
      );
    }
  }

  // _deliver + màn quét giao đã XOÁ (11/11).
  //
  // Giao hàng cho FA giờ là việc out hàng khỏi kho rồi đặt pallet vào một vị trí
  // thuộc bản đồ Nhận hàng — làm ở màn vị trí tạm (PalletFlow.tempLocation), và
  // chính việc đặt pallet vào đó được server tính là giao. Không còn màn quét mã
  // riêng, để không tồn tại đường giao hàng nào bỏ qua vị trí kho.

  /// Mục 2d — FA quét serial đóng lại Pallet ID sau khi rework xong.
  ///
  /// Vào THẲNG màn quét, không có bước chọn gì: phiếu đã biết, và model thì sổ
  /// serial biết. Nút chỉ hiện khi CÒN hàng ở FA — đóng pallet cho một phiếu
  /// không còn con nào ở FA thì server trả lỗi "không serial nào đang ở FA".
  Future<void> _faPallet(ReturnInstruction doc) async {
    final changed = await openFaPalletPage(
      context,
      docId: doc.id,
      docNo: doc.docNo,
      goodsType: doc.goodsType,
    );
    // Pallet mới gắn vào sổ serial → số liệu phiếu đổi, đọc lại danh sách.
    if (changed && mounted) ref.invalidate(returnInstructionListProvider);
  }

  /// Quyền quét nhận hàng — SCS WH. Dùng CHUNG cho cả nút Giao hàng cho FA:
  /// cả hai đều gác bằng rework_refurbish.process.
  bool get _mayReceive => ref.watch(myPermissionsProvider).can(_permProcess);

  /// Quyền chốt thực nhận — WH hoặc Office, khớp
  /// `RequireAnyPermission<Process, Create>` ở controller.
  bool get _mayClose {
    final perms = ref.watch(myPermissionsProvider);
    return perms.can(_permProcess) || perms.can(_permCreate);
  }

  /// Quyền đóng lại Pallet ID — FA. Một người SCS KHÔNG có quyền này, và ngược
  /// lại: mỗi bước một quyền, xem Perms.cs.
  bool get _mayFaPallet => ref.watch(myPermissionsProvider).can(_permProcessFa);

  @override
  Widget build(BuildContext context) {
    final async = ref.watch(returnInstructionListProvider(_filter.name));

    return Scaffold(
      appBar: AppTopBar(
        title: LocaleKeys.return_instruction_title.tr(),
        subtitle: LocaleKeys.return_instruction_subtitle.tr(),
        actions: [
          IconButton(
            tooltip: LocaleKeys.return_instruction_refresh.tr(),
            icon: const Icon(Icons.refresh_rounded),
            onPressed: () => ref.invalidate(returnInstructionListProvider),
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(
                AppDimens.md, AppDimens.md, AppDimens.md, AppDimens.sm),
            child: AppTabBar<ReturnFilter>(
              expanded: true,
              items: [
                for (final f in ReturnFilter.values)
                  AppTabItem(value: f, label: f.labelKey.tr()),
              ],
              selected: _filter,
              // Mỗi bộ lọc một provider family riêng nên dữ liệu đã tải của
              // bộ lọc cũ vẫn còn — đổi qua đổi lại không gọi lại API.
              onChanged: (f) => setState(() {
                _filter = f;
                _expanded = null;
              }),
            ),
          ),
          Expanded(
            child: switch (async) {
              AsyncLoading() => const AppLoading(),
              AsyncError(:final error) => AppErrorView.page(
                  message: ref.read(errorHandlerProvider).getMessage(error),
                  onRetry: () => ref.invalidate(returnInstructionListProvider),
                ),
              AsyncValue(:final value) => _DocList(
                  docs: value ?? const [],
                  expanded: _expanded,
                  mayReceive: _mayReceive,
                  mayClose: _mayClose,
                  mayFaPallet: _mayFaPallet,
                  onToggle: (id) =>
                      setState(() => _expanded = _expanded == id ? null : id),
                  onRefresh: () async =>
                      ref.invalidate(returnInstructionListProvider),
                  onClose: _close,
                  onFaPallet: _faPallet,
                ),
            },
          ),
        ],
      ),
    );
  }
}

class _DocList extends StatelessWidget {
  final List<ReturnInstruction> docs;
  final int? expanded;
  final ValueChanged<int> onToggle;
  final Future<void> Function() onRefresh;

  /// Chốt thực nhận một phiếu (mục 2b).
  final Future<void> Function(ReturnInstruction) onClose;

  /// Giao hàng RW/RB cho FA (mục 2c, bước cuối).

  /// FA đóng lại Pallet ID sau rework (mục 2d).
  final Future<void> Function(ReturnInstruction) onFaPallet;

  /// Có quyền quét nhận (`rework_refurbish.process`).
  final bool mayReceive;

  /// Có quyền chốt thực nhận (`process` hoặc `create`).
  final bool mayClose;

  /// Có quyền đóng lại Pallet ID (`rework_refurbish.process_fa`) — FA.
  final bool mayFaPallet;

  const _DocList({
    required this.docs,
    required this.expanded,
    required this.onToggle,
    required this.onRefresh,
    required this.onClose,
    required this.onFaPallet,
    required this.mayReceive,
    required this.mayClose,
    required this.mayFaPallet,
  });

  @override
  Widget build(BuildContext context) {
    final c = context.swms;

    if (docs.isEmpty) {
      // Vẫn bọc RefreshIndicator: danh sách rỗng là lúc người dùng hay muốn
      // tải lại nhất, mà không bọc thì kéo xuống không có tác dụng gì.
      return RefreshIndicator(
        onRefresh: onRefresh,
        child: ListView(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 80),
              child: Text(
                LocaleKeys.return_instruction_empty.tr(),
                textAlign: TextAlign.center,
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            ),
          ],
        ),
      );
    }

    return RefreshIndicator(
      onRefresh: onRefresh,
      child: ListView.separated(
        padding: const EdgeInsets.fromLTRB(
            AppDimens.md, 0, AppDimens.md, AppDimens.md),
        itemCount: docs.length + 1,
        separatorBuilder: (_, __) => const SizedBox(height: 6),
        itemBuilder: (context, i) {
          if (i == 0) {
            return Padding(
              padding: const EdgeInsets.only(bottom: 4),
              child: Text(
                LocaleKeys.return_instruction_count.tr(namedArgs: {'count': '${docs.length}'}),
                style: AppTextStyles.caption.copyWith(color: c.text3),
              ),
            );
          }
          final doc = docs[i - 1];
          return _DocTile(
            doc: doc,
            open: expanded == doc.id,
            mayReceive: mayReceive,
            mayClose: mayClose,
            mayFaPallet: mayFaPallet,
            onTap: () => onToggle(doc.id),
            // Quay lại từ màn nhận hàng thì SL thực nhận đã khác → tải lại.
            onReceive: () async {
              await context.router.push(ReturnReceiveRoute(docId: doc.id));
              await onRefresh();
            },
            onClose: () => onClose(doc),
            onFaPallet: () => onFaPallet(doc),
          );
        },
      ),
    );
  }
}

// ConsumerWidget, KHÔNG StatelessWidget: thẻ mở ra thì watch
// backPalletsProvider để hiện pallet đang nằm ở vị trí nào trong kho. Đẩy việc
// đó lên page cha là page phải giữ state cho từng phiếu một.
class _DocTile extends ConsumerWidget {
  final ReturnInstruction doc;
  final bool open;
  final VoidCallback onTap;
  final VoidCallback onReceive;
  final VoidCallback onClose;
  final VoidCallback onFaPallet;
  final bool mayReceive;
  final bool mayClose;
  final bool mayFaPallet;

  const _DocTile({
    required this.doc,
    required this.open,
    required this.onTap,
    required this.onReceive,
    required this.onClose,
    required this.onFaPallet,
    required this.mayReceive,
    required this.mayClose,
    required this.mayFaPallet,
  });

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final c = context.swms;

    return AppCard(
      padding: EdgeInsets.zero,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          InkWell(
            onTap: onTap,
            borderRadius: BorderRadius.circular(10),
            child: Padding(
              padding: const EdgeInsets.all(AppDimens.sm + 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          doc.docNo,
                          style: AppTextStyles.code.copyWith(
                            fontSize: 13,
                            fontWeight: FontWeight.w700,
                            color: c.text1,
                          ),
                        ),
                      ),
                      // Loại hàng của CẢ phiếu — số phiếu đã mang tiền tố
                      // RW-/RB- nhưng chip màu thì nhìn ra ngay từ xa.
                      _typePill(context, doc.goodsType),
                      const SizedBox(width: 4),
                      _statusPill(context, doc.status),
                      const SizedBox(width: 4),
                      Icon(
                        open ? Icons.expand_less : Icons.expand_more,
                        size: 18,
                        color: c.text3,
                      ),
                    ],
                  ),
                  if (doc.customer != null && doc.customer!.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(doc.customer!,
                        style: AppTextStyles.caption.copyWith(color: c.text2)),
                  ],
                  const SizedBox(height: 6),

                  // NGÀY HÀNG VỀ — thứ WH mở màn này để xem, nên đặt ngay
                  // dưới số phiếu.
                  Row(
                    children: [
                      Icon(Icons.event_outlined, size: 14, color: c.text3),
                      const SizedBox(width: 4),
                      Text(
                        doc.expectedDate == null
                            ? LocaleKeys.return_instruction_no_date.tr()
                            : DateFormat('dd/MM/yyyy').format(doc.expectedDate!),
                        style: AppTextStyles.label.copyWith(
                          color: doc.expectedDate == null ? c.text3 : c.text1,
                        ),
                      ),
                      const Spacer(),
                      Text(
                        LocaleKeys.return_instruction_meta.tr(namedArgs: {
                          'models': '${doc.modelCount}',
                          'qty': '${doc.totalQty}',
                        }),
                        style: AppTextStyles.caption.copyWith(color: c.text3),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),

          if (open) ...[
            Divider(height: 1, color: c.border),
            Padding(
              padding: const EdgeInsets.fromLTRB(
                  AppDimens.sm + 4, AppDimens.sm, AppDimens.sm + 4, AppDimens.sm + 4),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  for (final l in doc.lines) _LineRow(line: l),

                  // Pallet đã nhận + ĐANG Ở ĐÂU TRONG KHO.
                  //
                  // Chỉ gọi khi thẻ đã mở (widget này chỉ dựng phần dưới khi
                  // `open`), nên danh sách vài chục phiếu không thành vài chục
                  // request.
                  //
                  // riverpod 3: KHÔNG có `valueOrNull` — phải khớp AsyncData.
                  ...(() {
                    final pal = ref.watch(backPalletsProvider(doc.id));
                    final rows =
                        pal is AsyncData<List<BackPallet>> ? pal.value : null;
                    if (rows == null || rows.isEmpty) return <Widget>[];
                    return <Widget>[
                      const SizedBox(height: 8),
                      Text(
                        LocaleKeys.return_back_pallet_loc.tr(),
                        style: AppTextStyles.caption.copyWith(color: c.text3),
                      ),
                      const SizedBox(height: 2),
                      for (final r in rows) _PalletLocRow(pallet: r),
                    ];
                  })(),

                  if (doc.note != null && doc.note!.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text(
                      '${LocaleKeys.return_instruction_note.tr()}: ${doc.note!}',
                      style: AppTextStyles.caption.copyWith(color: c.text3),
                    ),
                  ],

                  // Đã chốt: nói rõ FA đã được báo số thực nhận hay chưa.
                  if (doc.isClosed) ...[
                    const SizedBox(height: 6),
                    Row(
                      children: [
                        Icon(Icons.verified_outlined, size: 13, color: c.text3),
                        const SizedBox(width: 4),
                        Expanded(
                          child: Text(
                            LocaleKeys.return_receive_closed_at.tr(namedArgs: {
                              'at': DateFormat('dd/MM HH:mm').format(doc.closedAt!),
                              'by': doc.closedBy ?? '—',
                            }),
                            style: AppTextStyles.caption.copyWith(color: c.text3),
                          ),
                        ),
                        if (doc.actualMailSentAt == null)
                          StatusPill.warning(
                            context,
                            label: LocaleKeys.return_receive_mail_not_sent.tr(),
                          ),
                      ],
                    ),
                  ],

                  // Cửa vào mục 2a + 2b. Chỉ hiện ở phiếu còn mở — phiếu đã
                  // đóng thì server cũng chặn nhận thêm.
                  //
                  // Hai nút hai quyền khác nhau nên xét riêng từng nút, và chỉ
                  // dựng cả hàng khi có ít nhất một nút: user chỉ có quyền XEM
                  // (SCS Office, FA) sẽ không thấy khoảng trống thừa dưới phiếu.
                  if (doc.isOpen && (mayReceive || (doc.hasReceipt && mayClose))) ...[
                    const SizedBox(height: AppDimens.sm),
                    Row(
                      children: [
                        if (mayReceive)
                          Expanded(
                            child: AppButton(
                              label: LocaleKeys.return_instruction_btn_receive.tr(),
                              variant: AppButtonVariant.primary,
                              size: AppButtonSize.sm,
                              icon: Icons.qr_code_scanner_rounded,
                              isFullWidth: false,
                              onPressed: onReceive,
                            ),
                          ),
                        // Chốt thực nhận chỉ hiện khi ĐÃ nhận được hàng: chốt
                        // một phiếu trống là gửi FA bảng toàn số 0.
                        if (doc.hasReceipt && mayClose) ...[
                          if (mayReceive) const SizedBox(width: AppDimens.sm),
                          Expanded(
                            child: AppButton(
                              label: LocaleKeys.return_receive_btn_close.tr(),
                              variant: AppButtonVariant.success,
                              size: AppButtonSize.sm,
                              icon: Icons.mark_email_read_outlined,
                              isFullWidth: false,
                              onPressed: onClose,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ],

                  // Mục 2c bước cuối — GIAO HÀNG RW/RB CHO FA.
                  //
                  // KHÔNG phải nút: chỉ một dòng nhắc việc.
                  //
                  // Hàng được phép out kho rồi, nhưng thao tác giao nằm ở màn vị
                  // trí tạm (đặt pallet vào vị trí thuộc bản đồ Nhận hàng), nên
                  // một nút ở đây sẽ dẫn đi đâu cũng sai. Vẫn hiện SL còn phải
                  // giao để WH biết phải đẩy mấy con.
                  if (doc.canDeliverBack && mayReceive) ...[
                    const SizedBox(height: AppDimens.sm),
                    Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Icon(Icons.local_shipping_outlined,
                            size: 16, color: c.warning),
                        const SizedBox(width: AppDimens.xs),
                        Expanded(
                          child: Text(
                            LocaleKeys.return_back_deliver_hint.tr(
                                namedArgs: {'qty': '${doc.back.remainQty}'}),
                            style: AppTextStyles.caption
                                .copyWith(color: c.warning),
                          ),
                        ),
                      ],
                    ),
                  ],

                  // Mục 2d — FA đóng lại Pallet ID.
                  //
                  // Gác theo SỐ CON ĐANG Ở FA, không theo trạng thái phiếu:
                  // `doc.isOpen` nói về SL nhận từ KHÁCH ở mục 2b, còn vòng với
                  // FA xảy ra SAU đó — gác theo trạng thái phiếu là hàng ở FA
                  // không có đường đóng pallet để về.
                  //
                  // Hiện cả SL còn ở FA ngay trên nhãn: FA biết luôn còn mấy
                  // con phải đóng mà không cần mở màn.
                  if (doc.back.atFaQty > 0 && mayFaPallet) ...[
                    const SizedBox(height: AppDimens.sm),
                    AppButton(
                      label: LocaleKeys.return_fa_btn_open
                          .tr(namedArgs: {'qty': '${doc.back.atFaQty}'}),
                      variant: AppButtonVariant.primary,
                      size: AppButtonSize.sm,
                      icon: Icons.inventory_2_outlined,
                      onPressed: onFaPallet,
                    ),
                  ],
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _statusPill(BuildContext context, ReturnDocStatus s) => switch (s) {
        ReturnDocStatus.open =>
          StatusPill.info(context, label: s.labelKey.tr()),
        ReturnDocStatus.completed =>
          StatusPill.success(context, label: s.labelKey.tr()),
        ReturnDocStatus.cancelled =>
          StatusPill.neutral(context, label: s.labelKey.tr()),
      };

  /// Hai loại hàng hai màu, cùng tinh thần badge RW/RE trên bản đồ kho:
  /// người dùng quét bằng mắt chứ không đọc chữ.
  Widget _typePill(BuildContext context, ReturnGoodsType t) => switch (t) {
        ReturnGoodsType.rework =>
          StatusPill.warning(context, label: t.labelKey.tr()),
        ReturnGoodsType.refurbish =>
          StatusPill.info(context, label: t.labelKey.tr()),
      };
}

/// Một dòng "Pallet ID — vị trí trong kho".
///
/// Chưa lưu kho thì nói thẳng "chưa lưu kho" chứ không để trống: ô trống đọc ra
/// thành "không biết", mà đây là thông tin WH dùng để đi tìm pallet.
class _PalletLocRow extends StatelessWidget {
  final BackPallet pallet;
  const _PalletLocRow({required this.pallet});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    final stored = pallet.stored;

    return Padding(
      padding: const EdgeInsets.only(top: 3),
      child: Row(
        children: [
          Icon(stored ? Icons.inventory_2_outlined : Icons.schedule,
              size: 13, color: stored ? c.text3 : c.warning),
          const SizedBox(width: 4),
          Text(pallet.lotNo, style: AppTextStyles.code),
          const SizedBox(width: 6),
          Expanded(
            child: Text(
              stored
                  ? pallet.locatorCode!
                  : LocaleKeys.return_back_pallet_not_stored.tr(),
              style: AppTextStyles.caption.copyWith(
                  color: stored ? c.text1 : c.warning),
              overflow: TextOverflow.ellipsis,
            ),
          ),
          Text('${pallet.serialCount}',
              style: AppTextStyles.caption.copyWith(color: c.text3)),
        ],
      ),
    );
  }
}

class _LineRow extends StatelessWidget {
  final ReturnInstructionLine line;
  const _LineRow({required this.line});

  @override
  Widget build(BuildContext context) {
    final c = context.swms;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          SizedBox(
            width: 20,
            child: Text('${line.lineNo}',
                style: AppTextStyles.caption.copyWith(color: c.text3)),
          ),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  line.model,
                  style: AppTextStyles.code.copyWith(fontSize: 12, color: c.text1),
                ),
                if (line.note != null && line.note!.isNotEmpty)
                  Text(line.note!,
                      style: AppTextStyles.caption.copyWith(color: c.text3)),
              ],
            ),
          ),
          Column(
            crossAxisAlignment: CrossAxisAlignment.end,
            children: [
              Text(
                LocaleKeys.return_instruction_qty_pcs
                    .tr(namedArgs: {'qty': '${line.qty}'}),
                style: AppTextStyles.label.copyWith(
                  fontWeight: FontWeight.w700,
                  color: c.text1,
                ),
              ),
              // SL thực nhận: xanh khi đã đủ, cam khi vượt, xám khi còn thiếu.
              Text(
                LocaleKeys.return_instruction_received
                    .tr(namedArgs: {'qty': '${line.receivedQty}'}),
                style: AppTextStyles.caption.copyWith(
                  fontSize: 10.5,
                  color: line.remainingQty < 0
                      ? c.warning
                      : line.isDone
                          ? c.success
                          : c.text3,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
