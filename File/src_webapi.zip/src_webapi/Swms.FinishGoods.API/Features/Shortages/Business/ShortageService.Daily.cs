using System.Globalization;
using System.Text;
using System.Text.RegularExpressions;
using Swms.FinishGoods.API.Features.Shortages.Api;

namespace Swms.FinishGoods.API.Features.Shortages.Business;

/*  BÁO CÁO HÀNG THIẾU HẰNG NGÀY — mẫu SHORTAGE_DAILY, worker gọi POST /api/shortages/daily-report.

    Khác mail đòi hàng / báo VP: KHÔNG có người bấm gửi, nên server tự làm hết, giống
    phiếu bất thường:
      - mẫu tiêu đề / nội dung đọc từ master.email_events (sửa ở màn Cấu hình email);
      - biến tự tính từ CÙNG bộ tính của màn Hàng thiếu (CalculateAsync + Filter), nên
        con số trong mail khớp con số trên màn hình lúc đó;
      - người nhận từ master.email_config của sự kiện, mọi bộ phận đã cấu hình;
      - render markdown -> HTML bằng ShortageMailLayout như các mail hàng thiếu khác.

    GIỮ KHỚP danh sách biến với EmailTemplate.DailyPlaceholders bên Web. */
public partial class ShortageService
{
    private const string DailyEvent = "SHORTAGE_DAILY";

    /// <summary>Số dòng tối đa của bảng mã gấp — mail dài quá thì không ai đọc hết.</summary>
    private const int UrgentTableMax = 30;

    /// <summary>Nhãn nguyên nhân cho mail. GIỮ KHỚP ShortageDisplay.Reasons bên Web.</summary>
    private static readonly Dictionary<string, string> ReasonLabels = new()
    {
        ["RECEIVING"] = "Khu nhận hàng",
        ["OQC"] = "OQC đang kiểm",
        ["FA_UNDELIVERED"] = "FA chưa giao",
        ["FA_PRODUCING"] = "FA đang sản xuất",
        ["NO_PLAN"] = "Không có kế hoạch",
    };

    private static readonly Regex Token = new(@"\{(\w+)\}", RegexOptions.Compiled);

    public async Task<DailyReportResponse> SendDailyReportAsync(bool dryRun, bool skipIfEmpty)
    {
        var now = DateTime.Now;

        // Cùng bộ tính + bộ lọc rỗng của màn Hàng thiếu: chỉ mã THẬT SỰ thiếu (QtyShort > 0)
        var calc = await CalculateAsync();
        var items = Filter(calc, new ShortageQuery(), applyReason: false)
            .OrderBy(x => x.VanningDate).ThenByDescending(x => x.QtyShort)
            .ToList();

        var urgent = items.Where(x => x.DaysLeft <= 2).ToList();
        var stats = (Models: items.Count, Qty: items.Sum(x => x.QtyShort),
                     Urgent: urgent.Count, Escalate: items.Count(NeedsEscalation));

        DailyReportResponse Result(bool sent, string? skipped, string? subject = null, string? body = null,
                                   List<RecipientResponse>? recipients = null)
            => new(sent, skipped, now, stats.Models, stats.Qty, stats.Urgent, stats.Escalate,
                   subject, body, recipients ?? new());

        if (items.Count == 0 && skipIfEmpty)
            return Result(false, "NoShortage");

        var tpl = await _repo.GetMailTemplateAsync(DailyEvent);
        if (tpl is null || string.IsNullOrWhiteSpace(tpl.Subject) || string.IsNullOrWhiteSpace(tpl.Body))
        {
            _logger.LogWarning(
                "Chua khai su kien {Event} hoac mau rong trong master.email_events — khong gui bao cao hang thieu.",
                DailyEvent);
            return Result(false, "NoTemplate");
        }

        var vars = new Dictionary<string, string>
        {
            ["report_date"] = now.ToString("dd/MM/yyyy", CultureInfo.InvariantCulture),
            ["report_time"] = now.ToString("HH:mm", CultureInfo.InvariantCulture),
            ["model_count"] = stats.Models.ToString("N0", CultureInfo.InvariantCulture),
            ["total_qty"] = stats.Qty.ToString("N0", CultureInfo.InvariantCulture),
            ["urgent_count"] = stats.Urgent.ToString(CultureInfo.InvariantCulture),
            ["escalate_count"] = stats.Escalate.ToString(CultureInfo.InvariantCulture),
            ["not_requested_count"] = items.Count(NotRequested).ToString(CultureInfo.InvariantCulture),
            ["by_reason"] = ByReasonList(calc, items),
            ["urgent_table"] = UrgentTable(urgent),
            ["link"] = DailyLink(),
        };

        var subject = Fill(tpl.Subject!, vars).Trim();
        var body = Fill(tpl.Body!, vars);

        var recipients = await _repo.GetEventRecipientsAsync(DailyEvent);
        var resp = recipients.Select(ToResponse).ToList();

        if (recipients.All(r => r.Type != "TO"))
            return Result(false, "NoRecipient", subject, body, resp);
        if (dryRun)
            return Result(false, "DryRun", subject, body, resp);
        if (!_mail.Enabled)
        {
            _logger.LogWarning("Mail:Enabled dang tat — khong gui bao cao hang thieu ngay {Date}.", vars["report_date"]);
            return Result(false, "MailDisabled", subject, body, resp);
        }

        // Không bắt lỗi ở đây: worker nhận 5xx và tự thử lại. Chưa ghi gì nên gửi lại an toàn.
        await _mail.SendAsync(recipients, subject, ShortageMailLayout.Render(subject, body, escalate: false),
                              "SWMS", null);
        return Result(true, null, subject, body, resp);
    }

    // ── Quy tắc — GIỮ KHỚP Filter (stage) bên trên và AppShortageItem bên Web ──

    /// <summary>Có nguyên nhân chưa đòi FA/OQC.</summary>
    private static bool NotRequested(ItemCalc it)
        => it.ByReason.Keys.Any(k => !it.FollowUps.ContainsKey(k));

    /// <summary>Còn ≤ 2 ngày và (có phần không kế hoạch hoặc có nguyên nhân chưa đòi).</summary>
    private static bool NeedsEscalation(ItemCalc it)
        => it.DaysLeft <= 2 && (it.ByReason.ContainsKey("NO_PLAN") || NotRequested(it));

    private static string StatusText(ItemCalc it)
        => NeedsEscalation(it) ? "**Cần báo VP**" : NotRequested(it) ? "Chưa đòi" : "Đã đòi";

    // ── Biến dựng sẵn ───────────────────────────────────────────────

    private static string ByReasonList(CalcResult calc, List<ItemCalc> items)
    {
        var lines = calc.Reasons
            .Select(r => (r.Code, Qty: items.Sum(x => x.ByReason.GetValueOrDefault(r.Code))))
            .Where(x => x.Qty > 0)
            .Select(x => $"- {ReasonLabels.GetValueOrDefault(x.Code, x.Code)}: {x.Qty.ToString("N0", CultureInfo.InvariantCulture)} pcs")
            .ToList();
        return lines.Count == 0 ? "Không có." : string.Join("\n", lines);
    }

    private static string UrgentTable(List<ItemCalc> urgent)
    {
        if (urgent.Count == 0) return "Không có mã nào vanning trong 2 ngày tới.";

        var sb = new StringBuilder();
        sb.Append("| Model | Thiếu | SI | Vanning | Nguyên nhân | Tình trạng |\n");
        sb.Append("|---|---:|---|---|---|---|\n");
        foreach (var it in urgent.Take(UrgentTableMax))
        {
            var sis = string.Join(", ", it.Lines.Select(l => l.Line.SiNo).Distinct());
            var reasons = string.Join(", ", it.ByReason.Keys.Select(k => ReasonLabels.GetValueOrDefault(k, k)));
            var van = it.DaysLeft < 0
                ? $"{it.VanningDate:dd/MM} (quá {-it.DaysLeft} ngày)"
                : $"{it.VanningDate:dd/MM}";
            sb.Append($"| {Cell(it.Model)} | {it.QtyShort.ToString("N0", CultureInfo.InvariantCulture)} | {Cell(sis)} | {van} | {Cell(reasons)} | {StatusText(it)} |\n");
        }
        if (urgent.Count > UrgentTableMax)
            sb.Append($"\n… và {urgent.Count - UrgentTableMax} mã khác — xem đầy đủ trên SWMS.");
        return sb.ToString().TrimEnd();
    }

    /// <summary>Dấu | trong giá trị làm vỡ bảng markdown.</summary>
    private static string Cell(string? s) => (s ?? "").Replace("|", "/");

    /// <summary>Link màn Hàng thiếu, bỏ lọc vanning mặc định (hôm nay) để thấy đủ.</summary>
    private string DailyLink()
    {
        if (string.IsNullOrWhiteSpace(_webBaseUrl))
        {
            _logger.LogWarning("Chua khai Web:BaseUrl trong appsettings — bao cao hang thieu se khong co link.");
            return "";
        }
        return $"{_webBaseUrl}/shortages?van=all";
    }

    /// <summary>Thay {key}. Biến lạ giữ nguyên để người soạn thấy gõ sai.</summary>
    private static string Fill(string template, IReadOnlyDictionary<string, string> vars)
        => Token.Replace(template, m => vars.TryGetValue(m.Groups[1].Value, out var v) ? v : m.Value);
}
