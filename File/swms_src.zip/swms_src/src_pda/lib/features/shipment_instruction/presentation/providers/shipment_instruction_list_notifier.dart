import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/shipment_instruction_entities.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/si_status.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/repositories/shipment_instruction_repository.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_list_state.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/providers/shipment_instruction_providers.dart';

part 'shipment_instruction_list_notifier.g.dart';

/// Danh sách chỉ thị lấy hàng.
@riverpod
class ShipmentInstructionListNotifier extends _$ShipmentInstructionListNotifier
    with BaseNotifierMixin<ShipmentInstructionListState> {

  /// Tăng mỗi lần tải lại từ đầu. Bấm đổi tab liên tục thì response tab cũ có
  /// thể về SAU tab mới — setField so seq để bỏ response lỗi thời.
  int _seq = 0;

  ShipmentInstructionRepository get _repo =>
      ref.read(shipmentInstructionRepositoryProvider);

  @override
  ShipmentInstructionListState build() {
    Future.microtask(load);
    return const ShipmentInstructionListState();
  }

  /// Tải trang 1 theo tab hiện tại.
  /// [silent] = true (kéo làm mới / quay về từ chi tiết): bỏ qua bước loading
  /// để list cũ vẫn trên màn trong lúc chờ.
  Future<void> load({bool silent = false}) {
    final seq = ++_seq;
    final filter = state.filter;

    return executePartial<ShipmentInstructionPage>(
      action: () => _repo.getList(status: filter),
      getField: (s) => s.page,
      setField: (s, f) {
        if (seq != _seq) return s; // response của lần tải cũ
        if (silent && f.isLoading) return s; // làm mới ngầm, không nháy
        return s.copyWith(
          page: f,
          statusCounts: f.value?.statusCounts,
          isLoadingMore: false,
          loadMoreFailed: false,
        );
      },
    );
  }

  Future<void> setFilter(SiStatus? filter) async {
    if (filter == state.filter) return;
    state = state.copyWith(filter: filter);
    await load();
  }

  /// Tải trang kế. Không qua executePartial: trang kế lỗi thì KHÔNG được
  /// biến cả `page` thành error (mất list đang xem) — chỉ bật cờ thử lại ở đáy.
  Future<void> loadMore() async {
    final current = state.page.value;
    if (current == null ||
        !current.hasMore ||
        state.isLoadingMore ||
        state.page.isLoading) {
      return;
    }

    final seq = _seq;
    state = state.copyWith(isLoadingMore: true, loadMoreFailed: false);

    try {
      final next = await _repo.getList(
        status: state.filter,
        page: current.page + 1,
      );
      if (seq != _seq) return;
      state = state.copyWith(
        page: AsyncValue.data(current.append(next)),
        statusCounts: next.statusCounts,
        isLoadingMore: false,
      );
    } catch (_) {
      if (seq != _seq) return;
      state = state.copyWith(isLoadingMore: false, loadMoreFailed: true);
    }
  }
}