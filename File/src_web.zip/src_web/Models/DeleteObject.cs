﻿namespace SWMS_WebTool.Models
{
    public class DeleteObject
    {
        public string Action { get; set; }
        public string Controller { get; set; }
        public string Id { get; set; }
    }

    public class DeletePlanObject
    {
        public string Action { get; set; }
        public string Controller { get; set; }
        public string Id { get; set; }
        public string Tab { get; set; }
    }
}
