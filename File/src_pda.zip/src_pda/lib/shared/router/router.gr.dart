// GENERATED CODE - DO NOT MODIFY BY HAND

// **************************************************************************
// AutoRouterGenerator
// **************************************************************************

// ignore_for_file: type=lint
// coverage:ignore-file

// ignore_for_file: no_leading_underscores_for_library_prefixes
import 'package:auto_route/auto_route.dart' as _i76;
import 'package:flutter/material.dart' as _i79;
import 'package:smart_warehouse/entities/barcode/barcode.dart' as _i77;
import 'package:smart_warehouse/entities/delivery_plan.dart' as _i78;
import 'package:smart_warehouse/entities/e_map/emap_zone.dart' as _i87;
import 'package:smart_warehouse/entities/e_map/order_block.dart' as _i83;
import 'package:smart_warehouse/entities/e_map/suggest_path.dart' as _i84;
import 'package:smart_warehouse/entities/kitting/kitting_detail.dart' as _i82;
import 'package:smart_warehouse/entities/receiving_card.dart' as _i80;
import 'package:smart_warehouse/entities/receiving_card_item.dart' as _i81;
import 'package:smart_warehouse/enums/delivery_type.dart' as _i89;
import 'package:smart_warehouse/enums/emap_navigate_funciton.dart' as _i85;
import 'package:smart_warehouse/enums/kitting_type.dart' as _i86;
import 'package:smart_warehouse/enums/rack_type.dart' as _i88;
import 'package:smart_warehouse/views/pages/AMR/CallAMR/callamr_page.dart'
    as _i4;
import 'package:smart_warehouse/views/pages/AMR/ConfirmAMR/outpallet_amr_page.dart'
    as _i49;
import 'package:smart_warehouse/views/pages/AMR/MenuAMR/menu_amr_page.dart'
    as _i38;
import 'package:smart_warehouse/views/pages/emap/floor_detail/floor_detail_page.dart'
    as _i20;
import 'package:smart_warehouse/views/pages/emap/new_map_floor/new_map_floor_page.dart'
    as _i41;
import 'package:smart_warehouse/views/pages/emap/new_map_zone/new_map_zone_page.dart'
    as _i42;
import 'package:smart_warehouse/views/pages/emap/pallet_detail/pallet_detail_page.dart'
    as _i50;
import 'package:smart_warehouse/views/pages/emap/rack_detail/rack_detail_page.dart'
    as _i53;
import 'package:smart_warehouse/views/pages/emap/trolley_map_html/trolley_map_html_page.dart'
    as _i71;
import 'package:smart_warehouse/views/pages/emap/zone_detail/zone_detail_page.dart'
    as _i75;
import 'package:smart_warehouse/views/pages/home/home_page.dart' as _i23;
import 'package:smart_warehouse/views/pages/inventory/balance_all/balance_all_page.dart'
    as _i1;
import 'package:smart_warehouse/views/pages/inventory/balance_rc/balance_rc_page.dart'
    as _i2;
import 'package:smart_warehouse/views/pages/inventory/check_rc_on_location/check_rc_on_location_page.dart'
    as _i13;
import 'package:smart_warehouse/views/pages/inventory/inventory_page.dart'
    as _i28;
import 'package:smart_warehouse/views/pages/iqc/iqc_menu_page.dart' as _i25;
import 'package:smart_warehouse/views/pages/kitting/check_list_kitting/components/check_list_kitting_detail_page.dart'
    as _i11;
import 'package:smart_warehouse/views/pages/kitting/components/barcode_scanned_page.dart'
    as _i3;
import 'package:smart_warehouse/views/pages/kitting/emap_kitting/emap_kitting_page.dart'
    as _i17;
import 'package:smart_warehouse/views/pages/kitting/find_kitting_list/find_kitting_list_page.dart'
    as _i19;
import 'package:smart_warehouse/views/pages/kitting/index/kitting_index_page.dart'
    as _i29;
import 'package:smart_warehouse/views/pages/kitting/kitting/kitting_page.dart'
    as _i31;
import 'package:smart_warehouse/views/pages/kitting/kitting_model/kitting_model_page.dart'
    as _i30;
import 'package:smart_warehouse/views/pages/kitting/kitting_trolley/change_trolley/change_trolley_page.dart'
    as _i7;
import 'package:smart_warehouse/views/pages/kitting/kitting_trolley/check_trolley/check_trolley_page.dart'
    as _i14;
import 'package:smart_warehouse/views/pages/kitting/kitting_trolley/input_trolley/input_trolley_page.dart'
    as _i27;
import 'package:smart_warehouse/views/pages/kitting/kitting_trolley/out_trolley/out_trolley_page.dart'
    as _i48;
import 'package:smart_warehouse/views/pages/kitting/return_kitting/return_kitting_page.dart'
    as _i59;
import 'package:smart_warehouse/views/pages/kitting/revert_kitting/revert_kitting_page.dart'
    as _i60;
import 'package:smart_warehouse/views/pages/kitting/supply_kitting/supply_kitting_page.dart'
    as _i69;
import 'package:smart_warehouse/views/pages/login/login_page.dart' as _i34;
import 'package:smart_warehouse/views/pages/one_for_all/one_for_all_page.dart'
    as _i44;
import 'package:smart_warehouse/views/pages/Panacim/OCR/ocr_checking_panacim_page.dart'
    as _i43;
import 'package:smart_warehouse/views/pages/PMD/index/menu_pmd_page.dart'
    as _i39;
import 'package:smart_warehouse/views/pages/PMD/PrintPurgingNGRunner/print_purging_ng_runner_page.dart'
    as _i51;
import 'package:smart_warehouse/views/pages/PMD/PrintReceivingCardPMD/print_receivingcard_pmd_page.dart'
    as _i52;
import 'package:smart_warehouse/views/pages/PMD/SupplyDryingChamber/supply_dryingchamber_page.dart'
    as _i68;
import 'package:smart_warehouse/views/pages/PMD/UpdateBoxCardPMD/update_boxcard_pmd_page.dart'
    as _i72;
import 'package:smart_warehouse/views/pages/PMD/UpdateQuantityPlan/update_quantity_plan_pmd_page.dart'
    as _i73;
import 'package:smart_warehouse/views/pages/PMD/UpdateQuantityPurgingNGRunner/update_quantity_purging_ng_runner_page.dart'
    as _i74;
import 'package:smart_warehouse/views/pages/receiving/check_barcode_lack/check_barcode_lack_page.dart'
    as _i8;
import 'package:smart_warehouse/views/pages/receiving/da_invoice/da_invoice_page.dart'
    as _i15;
import 'package:smart_warehouse/views/pages/receiving/have_barcode/gr_have_barcode_page.dart'
    as _i21;
import 'package:smart_warehouse/views/pages/receiving/index/receiving_page.dart'
    as _i56;
import 'package:smart_warehouse/views/pages/receiving/list_box_card/list_box_card_page.dart'
    as _i33;
import 'package:smart_warehouse/views/pages/receiving/no_barcode/gr_no_barcode_page.dart'
    as _i22;
import 'package:smart_warehouse/views/pages/receiving/open_good_receipt/open_good_receipt_page.dart'
    as _i45;
import 'package:smart_warehouse/views/pages/receiving/receiving_card_list/receiving_card_list_page.dart'
    as _i55;
import 'package:smart_warehouse/views/pages/receiving/reprint_barcode_ng/reprint_barcode_ng_page.dart'
    as _i57;
import 'package:smart_warehouse/views/pages/receiving/reprint_receiving_card/reprint_receiving_card_page.dart'
    as _i58;
import 'package:smart_warehouse/views/pages/receiving/select_da_invoice/select_da_invoice_page.dart'
    as _i61;
import 'package:smart_warehouse/views/pages/storing/change_store_location/change_store_location_page.dart'
    as _i6;
import 'package:smart_warehouse/views/pages/storing/check_block_data/check_block_data_page.dart'
    as _i9;
import 'package:smart_warehouse/views/pages/storing/check_last_lot/check_last_lot_page.dart'
    as _i10;
import 'package:smart_warehouse/views/pages/storing/check_material/check_material_in_store_page.dart'
    as _i12;
import 'package:smart_warehouse/views/pages/storing/find_barcode_lost/find_barcode_lost_page.dart'
    as _i18;
import 'package:smart_warehouse/views/pages/storing/iqc_borrow_receiving_card/iqc_borrow_receiving_card_page.dart'
    as _i24;
import 'package:smart_warehouse/views/pages/storing/list_borrow_item/list_borrow_item_page.dart'
    as _i32;
import 'package:smart_warehouse/views/pages/storing/material_history_transition/material_history_transition_page.dart'
    as _i35;
import 'package:smart_warehouse/views/pages/storing/out_storage/out_storage_page.dart'
    as _i47;
import 'package:smart_warehouse/views/pages/storing/position/material_position_page.dart'
    as _i36;
import 'package:smart_warehouse/views/pages/storing/reprint_rc_convert/reprint_rc_convert_page.dart'
    as _i54;
import 'package:smart_warehouse/views/pages/storing/sample/material_sample_page.dart'
    as _i37;
import 'package:smart_warehouse/views/pages/storing/split_receiving_card/split_receiving_card_page.dart'
    as _i62;
import 'package:smart_warehouse/views/pages/storing/stock_to_receiving_card/stock_to_receiving_card_page.dart'
    as _i63;
import 'package:smart_warehouse/views/pages/storing/storage/storage_rc_card_page.dart'
    as _i66;
import 'package:smart_warehouse/views/pages/storing/storage_borrow_item/storage_borrow_item_page.dart'
    as _i64;
import 'package:smart_warehouse/views/pages/storing/storage_jupiter/storage_jupiter_page.dart'
    as _i65;
import 'package:smart_warehouse/views/pages/storing/storing_page.dart' as _i67;
import 'package:smart_warehouse/views/pages/temporary_area/input_location/input_location_page.dart'
    as _i26;
import 'package:smart_warehouse/views/pages/temporary_area/move_receiving_card/move_receiving_card_page.dart'
    as _i40;
import 'package:smart_warehouse/views/pages/temporary_area/out_receiving_card/out_receiving_card_page.dart'
    as _i46;
import 'package:smart_warehouse/views/pages/temporary_area/temporary_area_page.dart'
    as _i70;
import 'package:smart_warehouse/views/sub_pages/camera_capture_page.dart'
    as _i5;
import 'package:smart_warehouse/views/sub_pages/display_text_picture_page.dart'
    as _i16;

abstract class $AppRouter extends _i76.RootStackRouter {
  $AppRouter({super.navigatorKey});

  @override
  final Map<String, _i76.PageFactory> pagesMap = {
    BalanceAllRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i1.BalanceAllPage()),
      );
    },
    BalanceRcRoute.name: (routeData) {
      final args = routeData.argsAs<BalanceRcRouteArgs>(
          orElse: () => const BalanceRcRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i2.BalanceRcPage(
          key: args.key,
          rcBarcode: args.rcBarcode,
        )),
      );
    },
    BarCodeScannedRoute.name: (routeData) {
      final args = routeData.argsAs<BarCodeScannedRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i3.BarCodeScannedPage(
          removeReceivingCardCallBack: args.removeReceivingCardCallBack,
          backToScreen: args.backToScreen,
          removePartCardCallBack: args.removePartCardCallBack,
          receivingCards: args.receivingCards,
          receivingCardItems: args.receivingCardItems,
          key: args.key,
        )),
      );
    },
    CallAMRRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i4.CallAMRPage()),
      );
    },
    CameraCaptureRoute.name: (routeData) {
      return _i76.AutoRoutePage<String>(
        routeData: routeData,
        child: const _i5.CameraCapturePage(),
      );
    },
    ChangeStoreLocationRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i6.ChangeStoreLocationPage()),
      );
    },
    ChangeTrolleyRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i7.ChangeTrolleyPage()),
      );
    },
    CheckBarcodeLackRoute.name: (routeData) {
      final args = routeData.argsAs<CheckBarcodeLackRouteArgs>(
          orElse: () => const CheckBarcodeLackRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i8.CheckBarcodeLackPage(
          key: args.key,
          barcode: args.barcode,
          scanningBarcode: args.scanningBarcode,
        )),
      );
    },
    CheckBlockDataRoute.name: (routeData) {
      final args = routeData.argsAs<CheckBlockDataRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i9.CheckBlockDataPage(
          key: args.key,
          blockName: args.blockName,
        )),
      );
    },
    CheckLastLotRoute.name: (routeData) {
      final args = routeData.argsAs<CheckLastLotRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i10.CheckLastLotPage(
          key: args.key,
          blockId: args.blockId,
        )),
      );
    },
    CheckListKittingDetailRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child:
            _i76.WrappedRoute(child: const _i11.CheckListKittingDetailPage()),
      );
    },
    CheckMaterialInStoreRoute.name: (routeData) {
      final args = routeData.argsAs<CheckMaterialInStoreRouteArgs>(
          orElse: () => const CheckMaterialInStoreRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i12.CheckMaterialInStorePage(
          key: args.key,
          positionOrRc: args.positionOrRc,
        )),
      );
    },
    CheckRcOnLocationRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i13.CheckRcOnLocationPage()),
      );
    },
    CheckTrolleyRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i14.CheckTrolleyPage()),
      );
    },
    DAInvoiceRoute.name: (routeData) {
      final args = routeData.argsAs<DAInvoiceRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i15.DAInvoicePage(
          key: args.key,
          deliveryPlan: args.deliveryPlan,
        )),
      );
    },
    DisplayTextPictureRoute.name: (routeData) {
      final args = routeData.argsAs<DisplayTextPictureRouteArgs>();
      return _i76.AutoRoutePage<String>(
        routeData: routeData,
        child: _i16.DisplayTextPicturePage(
          key: args.key,
          imagePath: args.imagePath,
        ),
      );
    },
    EmapKittingRoute.name: (routeData) {
      final args = routeData.argsAs<EmapKittingRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i17.EmapKittingPage(
          args.listKittingDetails,
          args.selectedLocations,
          orderBlocks: args.orderBlocks,
          suggestPaths: args.suggestPaths,
          key: args.key,
        )),
      );
    },
    FindBarcodeLostRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i18.FindBarcodeLostPage()),
      );
    },
    FindKittingListRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i19.FindKittingListPage()),
      );
    },
    FloorDetailRoute.name: (routeData) {
      final args = routeData.argsAs<FloorDetailRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i20.FloorDetailPage(
          key: args.key,
          receivingCardId: args.receivingCardId,
          eMapNavigateFunction: args.eMapNavigateFunction,
        )),
      );
    },
    GRHaveBarcodeRoute.name: (routeData) {
      final args = routeData.argsAs<GRHaveBarcodeRouteArgs>(
          orElse: () => const GRHaveBarcodeRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i21.GRHaveBarcodePage(
          key: args.key,
          receivingCard: args.receivingCard,
        )),
      );
    },
    GRNoBarcodeRoute.name: (routeData) {
      final args = routeData.argsAs<GRNoBarcodeRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i22.GRNoBarcodePage(
          key: args.key,
          receivingCard: args.receivingCard,
          material: args.material,
          deliveryPlan: args.deliveryPlan,
          isOffsetGoods: args.isOffsetGoods,
          isFuntionNG: args.isFuntionNG,
          isFuntionPMD: args.isFuntionPMD,
        )),
      );
    },
    HomeRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i23.HomePage()),
      );
    },
    IQCBorrowReceivingCardRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child:
            _i76.WrappedRoute(child: const _i24.IQCBorrowReceivingCardPage()),
      );
    },
    IQCMenuRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i25.IQCMenuPage(),
      );
    },
    InputLocationRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i26.InputLocationPage()),
      );
    },
    InputTrolleyRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i27.InputTrolleyPage()),
      );
    },
    InventoryRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i28.InventoryPage(),
      );
    },
    KittingIndexRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i29.KittingIndexPage(),
      );
    },
    KittingModelRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i30.KittingModelPage()),
      );
    },
    KittingRoute.name: (routeData) {
      final args = routeData.argsAs<KittingRouteArgs>(
          orElse: () => const KittingRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i31.KittingPage(
          key: args.key,
          kittingType: args.kittingType,
        )),
      );
    },
    ListBorrowItemRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i32.ListBorrowItemPage()),
      );
    },
    ListBoxCardRoute.name: (routeData) {
      final args = routeData.argsAs<ListBoxCardRouteArgs>();
      return _i76.AutoRoutePage<List<_i77.Barcode>>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i33.ListBoxCardPage(
          key: args.key,
          barcodes: args.barcodes,
          totalQuantity: args.totalQuantity,
        )),
      );
    },
    LoginRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i34.LoginPage()),
      );
    },
    MaterialHistoryTransitionRoute.name: (routeData) {
      final args = routeData.argsAs<MaterialHistoryTransitionRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i35.MaterialHistoryTransitionPage(
          key: args.key,
          material: args.material,
          sloc: args.sloc,
        )),
      );
    },
    MaterialPositionRoute.name: (routeData) {
      final args = routeData.argsAs<MaterialPositionRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i36.MaterialPositionPage(
          key: args.key,
          material: args.material,
          currentSloc: args.currentSloc,
        )),
      );
    },
    MaterialSampleRoute.name: (routeData) {
      final args = routeData.argsAs<MaterialSampleRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i37.MaterialSamplePage(
          key: args.key,
          material: args.material,
        )),
      );
    },
    MenuAmrRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i38.MenuAmrPage()),
      );
    },
    MenuPmdRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i39.MenuPmdPage(),
      );
    },
    MoveReceivingCardRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i40.MoveReceivingCardPage()),
      );
    },
    NewMapFloorRoute.name: (routeData) {
      final args = routeData.argsAs<NewMapFloorRouteArgs>(
          orElse: () => const NewMapFloorRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i41.NewMapFloorPage(
          key: args.key,
          receivingCardId: args.receivingCardId,
          material: args.material,
          eMapNavigateFunction: args.eMapNavigateFunction,
          plant: args.plant,
          sloc: args.sloc,
          category: args.category,
          startTime: args.startTime,
          endTime: args.endTime,
          qtyKitting: args.qtyKitting,
          blockLocations: args.blockLocations,
        )),
      );
    },
    NewMapZoneRoute.name: (routeData) {
      final args = routeData.argsAs<NewMapZoneRouteArgs>(
          orElse: () => const NewMapZoneRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i42.NewMapZonePage(
          key: args.key,
          receivingCardId: args.receivingCardId,
          eMapNavigateFunction: args.eMapNavigateFunction,
          zoneData: args.zoneData,
          totalTempQty: args.totalTempQty,
          totalStoreQty: args.totalStoreQty,
          lastLotName: args.lastLotName,
        )),
      );
    },
    OCRCheckingPanacimRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i43.OCRCheckingPanacimPage()),
      );
    },
    OneForAllRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i44.OneForAllPage()),
      );
    },
    OpenGoodReceiptRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i45.OpenGoodReceiptPage()),
      );
    },
    OutReceivingCardRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i46.OutReceivingCardPage()),
      );
    },
    OutStorageRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i47.OutStoragePage()),
      );
    },
    OutTrolleyRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i48.OutTrolleyPage()),
      );
    },
    OutpalletAmrRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i49.OutpalletAmrPage()),
      );
    },
    PalletDetailRoute.name: (routeData) {
      final args = routeData.argsAs<PalletDetailRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i50.PalletDetailPage(
          key: args.key,
          rackId: args.rackId,
          receivingCardId: args.receivingCardId,
          eMapNavigateFunction: args.eMapNavigateFunction,
        )),
      );
    },
    PrintPurgingNGRunneRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i51.PrintPurgingNGRunnePage()),
      );
    },
    PrintReceivingCardPmdRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i52.PrintReceivingCardPmdPage()),
      );
    },
    RackDetailRoute.name: (routeData) {
      final args = routeData.argsAs<RackDetailRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i53.RackDetailPage(
          key: args.key,
          rackId: args.rackId,
          receivingCardId: args.receivingCardId,
          eMapNavigateFunction: args.eMapNavigateFunction,
          lastNodeName: args.lastNodeName,
          rackType: args.rackType,
        )),
      );
    },
    RePrintRcConvertRoute.name: (routeData) {
      final args = routeData.argsAs<RePrintRcConvertRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i54.RePrintRcConvertPage(
          key: args.key,
          stockBarcode: args.stockBarcode,
        )),
      );
    },
    ReceivingCardListRoute.name: (routeData) {
      final args = routeData.argsAs<ReceivingCardListRouteArgs>(
          orElse: () => const ReceivingCardListRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i55.ReceivingCardListPage(
          key: args.key,
          deliveryPlan: args.deliveryPlan,
          material: args.material,
          parentId: args.parentId,
        )),
      );
    },
    ReceivingRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i56.ReceivingPage(),
      );
    },
    ReprintBarcodeNGRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i57.ReprintBarcodeNGPage()),
      );
    },
    ReprintReceivingCardRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i58.ReprintReceivingCardPage()),
      );
    },
    ReturnKittingRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i59.ReturnKittingPage()),
      );
    },
    RevertKittingRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i60.RevertKittingPage()),
      );
    },
    SelectDAInvoiceRoute.name: (routeData) {
      final args = routeData.argsAs<SelectDAInvoiceRouteArgs>();
      return _i76.AutoRoutePage<_i78.DeliveryPlan>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i61.SelectDAInvoicePage(
          key: args.key,
          material: args.material,
          po: args.po,
          poItem: args.poItem,
          deliveryPlanNo: args.deliveryPlanNo,
          deliveryPlanType: args.deliveryPlanType,
          quantity: args.quantity,
          includeGoodReceipt: args.includeGoodReceipt,
          IsFuntionNG: args.IsFuntionNG,
          IsFuntionPMD: args.IsFuntionPMD,
          onSelect: args.onSelect,
        )),
      );
    },
    SplitReceivingRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i62.SplitReceivingPage()),
      );
    },
    StockToReceivingCardRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i63.StockToReceivingCardPage()),
      );
    },
    StorageBorrowItemRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i64.StorageBorrowItemPage()),
      );
    },
    StorageJupiterRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i65.StorageJupiterPage()),
      );
    },
    StorageRCCardRoute.name: (routeData) {
      final args = routeData.argsAs<StorageRCCardRouteArgs>(
          orElse: () => const StorageRCCardRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i66.StorageRCCardPage(
          key: args.key,
          rcBarcode: args.rcBarcode,
        )),
      );
    },
    StoringRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i67.StoringPage(),
      );
    },
    SupplyDryingChamberRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i68.SupplyDryingChamberPage()),
      );
    },
    SupplyKittingRoute.name: (routeData) {
      final args = routeData.argsAs<SupplyKittingRouteArgs>(
          orElse: () => const SupplyKittingRouteArgs());
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i69.SupplyKittingPage(
          key: args.key,
          kittingType: args.kittingType,
        )),
      );
    },
    TemporaryAreaRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: const _i70.TemporaryAreaPage(),
      );
    },
    TrolleyMapHTMLRoute.name: (routeData) {
      final args = routeData.argsAs<TrolleyMapHTMLRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i71.TrolleyMapHTMLPage(
          key: args.key,
          trolleyCode: args.trolleyCode,
          kittingListId: args.kittingListId,
        )),
      );
    },
    UpdateBoxcardPMDRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(child: const _i72.UpdateBoxcardPMDPage()),
      );
    },
    UpdateQuantityPlanPMDRoute.name: (routeData) {
      final args = routeData.argsAs<UpdateQuantityPlanPMDRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i73.UpdateQuantityPlanPMDPage(
          args.detail,
          key: args.key,
        )),
      );
    },
    UpdateQuantityPurgingNGRunnerRoute.name: (routeData) {
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: const _i74.UpdateQuantityPurgingNGRunnerPage()),
      );
    },
    ZoneDetailRoute.name: (routeData) {
      final args = routeData.argsAs<ZoneDetailRouteArgs>();
      return _i76.AutoRoutePage<dynamic>(
        routeData: routeData,
        child: _i76.WrappedRoute(
            child: _i75.ZoneDetailPage(
          key: args.key,
          receivingCardId: args.receivingCardId,
          zoneId: args.zoneId,
          eMapNavigateFunction: args.eMapNavigateFunction,
        )),
      );
    },
  };
}

/// generated route for
/// [_i1.BalanceAllPage]
class BalanceAllRoute extends _i76.PageRouteInfo<void> {
  const BalanceAllRoute({List<_i76.PageRouteInfo>? children})
      : super(
          BalanceAllRoute.name,
          initialChildren: children,
        );

  static const String name = 'BalanceAllRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i2.BalanceRcPage]
class BalanceRcRoute extends _i76.PageRouteInfo<BalanceRcRouteArgs> {
  BalanceRcRoute({
    _i79.Key? key,
    String? rcBarcode,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          BalanceRcRoute.name,
          args: BalanceRcRouteArgs(
            key: key,
            rcBarcode: rcBarcode,
          ),
          initialChildren: children,
        );

  static const String name = 'BalanceRcRoute';

  static const _i76.PageInfo<BalanceRcRouteArgs> page =
      _i76.PageInfo<BalanceRcRouteArgs>(name);
}

class BalanceRcRouteArgs {
  const BalanceRcRouteArgs({
    this.key,
    this.rcBarcode,
  });

  final _i79.Key? key;

  final String? rcBarcode;

  @override
  String toString() {
    return 'BalanceRcRouteArgs{key: $key, rcBarcode: $rcBarcode}';
  }
}

/// generated route for
/// [_i3.BarCodeScannedPage]
class BarCodeScannedRoute extends _i76.PageRouteInfo<BarCodeScannedRouteArgs> {
  BarCodeScannedRoute({
    required void Function(_i80.ReceivingCard?) removeReceivingCardCallBack,
    required void Function() backToScreen,
    required void Function(_i81.ReceivingCardItem?) removePartCardCallBack,
    List<_i80.ReceivingCard>? receivingCards,
    List<_i81.ReceivingCardItem>? receivingCardItems,
    _i79.Key? key,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          BarCodeScannedRoute.name,
          args: BarCodeScannedRouteArgs(
            removeReceivingCardCallBack: removeReceivingCardCallBack,
            backToScreen: backToScreen,
            removePartCardCallBack: removePartCardCallBack,
            receivingCards: receivingCards,
            receivingCardItems: receivingCardItems,
            key: key,
          ),
          initialChildren: children,
        );

  static const String name = 'BarCodeScannedRoute';

  static const _i76.PageInfo<BarCodeScannedRouteArgs> page =
      _i76.PageInfo<BarCodeScannedRouteArgs>(name);
}

class BarCodeScannedRouteArgs {
  const BarCodeScannedRouteArgs({
    required this.removeReceivingCardCallBack,
    required this.backToScreen,
    required this.removePartCardCallBack,
    this.receivingCards,
    this.receivingCardItems,
    this.key,
  });

  final void Function(_i80.ReceivingCard?) removeReceivingCardCallBack;

  final void Function() backToScreen;

  final void Function(_i81.ReceivingCardItem?) removePartCardCallBack;

  final List<_i80.ReceivingCard>? receivingCards;

  final List<_i81.ReceivingCardItem>? receivingCardItems;

  final _i79.Key? key;

  @override
  String toString() {
    return 'BarCodeScannedRouteArgs{removeReceivingCardCallBack: $removeReceivingCardCallBack, backToScreen: $backToScreen, removePartCardCallBack: $removePartCardCallBack, receivingCards: $receivingCards, receivingCardItems: $receivingCardItems, key: $key}';
  }
}

/// generated route for
/// [_i4.CallAMRPage]
class CallAMRRoute extends _i76.PageRouteInfo<void> {
  const CallAMRRoute({List<_i76.PageRouteInfo>? children})
      : super(
          CallAMRRoute.name,
          initialChildren: children,
        );

  static const String name = 'CallAMRRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i5.CameraCapturePage]
class CameraCaptureRoute extends _i76.PageRouteInfo<void> {
  const CameraCaptureRoute({List<_i76.PageRouteInfo>? children})
      : super(
          CameraCaptureRoute.name,
          initialChildren: children,
        );

  static const String name = 'CameraCaptureRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i6.ChangeStoreLocationPage]
class ChangeStoreLocationRoute extends _i76.PageRouteInfo<void> {
  const ChangeStoreLocationRoute({List<_i76.PageRouteInfo>? children})
      : super(
          ChangeStoreLocationRoute.name,
          initialChildren: children,
        );

  static const String name = 'ChangeStoreLocationRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i7.ChangeTrolleyPage]
class ChangeTrolleyRoute extends _i76.PageRouteInfo<void> {
  const ChangeTrolleyRoute({List<_i76.PageRouteInfo>? children})
      : super(
          ChangeTrolleyRoute.name,
          initialChildren: children,
        );

  static const String name = 'ChangeTrolleyRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i8.CheckBarcodeLackPage]
class CheckBarcodeLackRoute
    extends _i76.PageRouteInfo<CheckBarcodeLackRouteArgs> {
  CheckBarcodeLackRoute({
    _i79.Key? key,
    _i77.Barcode? barcode,
    List<_i81.ReceivingCardItem>? scanningBarcode,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          CheckBarcodeLackRoute.name,
          args: CheckBarcodeLackRouteArgs(
            key: key,
            barcode: barcode,
            scanningBarcode: scanningBarcode,
          ),
          initialChildren: children,
        );

  static const String name = 'CheckBarcodeLackRoute';

  static const _i76.PageInfo<CheckBarcodeLackRouteArgs> page =
      _i76.PageInfo<CheckBarcodeLackRouteArgs>(name);
}

class CheckBarcodeLackRouteArgs {
  const CheckBarcodeLackRouteArgs({
    this.key,
    this.barcode,
    this.scanningBarcode,
  });

  final _i79.Key? key;

  final _i77.Barcode? barcode;

  final List<_i81.ReceivingCardItem>? scanningBarcode;

  @override
  String toString() {
    return 'CheckBarcodeLackRouteArgs{key: $key, barcode: $barcode, scanningBarcode: $scanningBarcode}';
  }
}

/// generated route for
/// [_i9.CheckBlockDataPage]
class CheckBlockDataRoute extends _i76.PageRouteInfo<CheckBlockDataRouteArgs> {
  CheckBlockDataRoute({
    _i79.Key? key,
    required String? blockName,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          CheckBlockDataRoute.name,
          args: CheckBlockDataRouteArgs(
            key: key,
            blockName: blockName,
          ),
          initialChildren: children,
        );

  static const String name = 'CheckBlockDataRoute';

  static const _i76.PageInfo<CheckBlockDataRouteArgs> page =
      _i76.PageInfo<CheckBlockDataRouteArgs>(name);
}

class CheckBlockDataRouteArgs {
  const CheckBlockDataRouteArgs({
    this.key,
    required this.blockName,
  });

  final _i79.Key? key;

  final String? blockName;

  @override
  String toString() {
    return 'CheckBlockDataRouteArgs{key: $key, blockName: $blockName}';
  }
}

/// generated route for
/// [_i10.CheckLastLotPage]
class CheckLastLotRoute extends _i76.PageRouteInfo<CheckLastLotRouteArgs> {
  CheckLastLotRoute({
    _i79.Key? key,
    required int blockId,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          CheckLastLotRoute.name,
          args: CheckLastLotRouteArgs(
            key: key,
            blockId: blockId,
          ),
          initialChildren: children,
        );

  static const String name = 'CheckLastLotRoute';

  static const _i76.PageInfo<CheckLastLotRouteArgs> page =
      _i76.PageInfo<CheckLastLotRouteArgs>(name);
}

class CheckLastLotRouteArgs {
  const CheckLastLotRouteArgs({
    this.key,
    required this.blockId,
  });

  final _i79.Key? key;

  final int blockId;

  @override
  String toString() {
    return 'CheckLastLotRouteArgs{key: $key, blockId: $blockId}';
  }
}

/// generated route for
/// [_i11.CheckListKittingDetailPage]
class CheckListKittingDetailRoute extends _i76.PageRouteInfo<void> {
  const CheckListKittingDetailRoute({List<_i76.PageRouteInfo>? children})
      : super(
          CheckListKittingDetailRoute.name,
          initialChildren: children,
        );

  static const String name = 'CheckListKittingDetailRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i12.CheckMaterialInStorePage]
class CheckMaterialInStoreRoute
    extends _i76.PageRouteInfo<CheckMaterialInStoreRouteArgs> {
  CheckMaterialInStoreRoute({
    _i79.Key? key,
    String? positionOrRc,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          CheckMaterialInStoreRoute.name,
          args: CheckMaterialInStoreRouteArgs(
            key: key,
            positionOrRc: positionOrRc,
          ),
          initialChildren: children,
        );

  static const String name = 'CheckMaterialInStoreRoute';

  static const _i76.PageInfo<CheckMaterialInStoreRouteArgs> page =
      _i76.PageInfo<CheckMaterialInStoreRouteArgs>(name);
}

class CheckMaterialInStoreRouteArgs {
  const CheckMaterialInStoreRouteArgs({
    this.key,
    this.positionOrRc,
  });

  final _i79.Key? key;

  final String? positionOrRc;

  @override
  String toString() {
    return 'CheckMaterialInStoreRouteArgs{key: $key, positionOrRc: $positionOrRc}';
  }
}

/// generated route for
/// [_i13.CheckRcOnLocationPage]
class CheckRcOnLocationRoute extends _i76.PageRouteInfo<void> {
  const CheckRcOnLocationRoute({List<_i76.PageRouteInfo>? children})
      : super(
          CheckRcOnLocationRoute.name,
          initialChildren: children,
        );

  static const String name = 'CheckRcOnLocationRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i14.CheckTrolleyPage]
class CheckTrolleyRoute extends _i76.PageRouteInfo<void> {
  const CheckTrolleyRoute({List<_i76.PageRouteInfo>? children})
      : super(
          CheckTrolleyRoute.name,
          initialChildren: children,
        );

  static const String name = 'CheckTrolleyRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i15.DAInvoicePage]
class DAInvoiceRoute extends _i76.PageRouteInfo<DAInvoiceRouteArgs> {
  DAInvoiceRoute({
    _i79.Key? key,
    required _i78.DeliveryPlan deliveryPlan,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          DAInvoiceRoute.name,
          args: DAInvoiceRouteArgs(
            key: key,
            deliveryPlan: deliveryPlan,
          ),
          initialChildren: children,
        );

  static const String name = 'DAInvoiceRoute';

  static const _i76.PageInfo<DAInvoiceRouteArgs> page =
      _i76.PageInfo<DAInvoiceRouteArgs>(name);
}

class DAInvoiceRouteArgs {
  const DAInvoiceRouteArgs({
    this.key,
    required this.deliveryPlan,
  });

  final _i79.Key? key;

  final _i78.DeliveryPlan deliveryPlan;

  @override
  String toString() {
    return 'DAInvoiceRouteArgs{key: $key, deliveryPlan: $deliveryPlan}';
  }
}

/// generated route for
/// [_i16.DisplayTextPicturePage]
class DisplayTextPictureRoute
    extends _i76.PageRouteInfo<DisplayTextPictureRouteArgs> {
  DisplayTextPictureRoute({
    _i79.Key? key,
    required String imagePath,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          DisplayTextPictureRoute.name,
          args: DisplayTextPictureRouteArgs(
            key: key,
            imagePath: imagePath,
          ),
          initialChildren: children,
        );

  static const String name = 'DisplayTextPictureRoute';

  static const _i76.PageInfo<DisplayTextPictureRouteArgs> page =
      _i76.PageInfo<DisplayTextPictureRouteArgs>(name);
}

class DisplayTextPictureRouteArgs {
  const DisplayTextPictureRouteArgs({
    this.key,
    required this.imagePath,
  });

  final _i79.Key? key;

  final String imagePath;

  @override
  String toString() {
    return 'DisplayTextPictureRouteArgs{key: $key, imagePath: $imagePath}';
  }
}

/// generated route for
/// [_i17.EmapKittingPage]
class EmapKittingRoute extends _i76.PageRouteInfo<EmapKittingRouteArgs> {
  EmapKittingRoute({
    required List<_i82.KittingDetail> listKittingDetails,
    required List<String> selectedLocations,
    List<_i83.OrderBlock> orderBlocks = const [],
    List<_i84.SuggestPath> suggestPaths = const [],
    _i79.Key? key,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          EmapKittingRoute.name,
          args: EmapKittingRouteArgs(
            listKittingDetails: listKittingDetails,
            selectedLocations: selectedLocations,
            orderBlocks: orderBlocks,
            suggestPaths: suggestPaths,
            key: key,
          ),
          initialChildren: children,
        );

  static const String name = 'EmapKittingRoute';

  static const _i76.PageInfo<EmapKittingRouteArgs> page =
      _i76.PageInfo<EmapKittingRouteArgs>(name);
}

class EmapKittingRouteArgs {
  const EmapKittingRouteArgs({
    required this.listKittingDetails,
    required this.selectedLocations,
    this.orderBlocks = const [],
    this.suggestPaths = const [],
    this.key,
  });

  final List<_i82.KittingDetail> listKittingDetails;

  final List<String> selectedLocations;

  final List<_i83.OrderBlock> orderBlocks;

  final List<_i84.SuggestPath> suggestPaths;

  final _i79.Key? key;

  @override
  String toString() {
    return 'EmapKittingRouteArgs{listKittingDetails: $listKittingDetails, selectedLocations: $selectedLocations, orderBlocks: $orderBlocks, suggestPaths: $suggestPaths, key: $key}';
  }
}

/// generated route for
/// [_i18.FindBarcodeLostPage]
class FindBarcodeLostRoute extends _i76.PageRouteInfo<void> {
  const FindBarcodeLostRoute({List<_i76.PageRouteInfo>? children})
      : super(
          FindBarcodeLostRoute.name,
          initialChildren: children,
        );

  static const String name = 'FindBarcodeLostRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i19.FindKittingListPage]
class FindKittingListRoute extends _i76.PageRouteInfo<void> {
  const FindKittingListRoute({List<_i76.PageRouteInfo>? children})
      : super(
          FindKittingListRoute.name,
          initialChildren: children,
        );

  static const String name = 'FindKittingListRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i20.FloorDetailPage]
class FloorDetailRoute extends _i76.PageRouteInfo<FloorDetailRouteArgs> {
  FloorDetailRoute({
    _i79.Key? key,
    required int receivingCardId,
    _i85.EMapNavigateFunction eMapNavigateFunction =
        _i85.EMapNavigateFunction.storing,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          FloorDetailRoute.name,
          args: FloorDetailRouteArgs(
            key: key,
            receivingCardId: receivingCardId,
            eMapNavigateFunction: eMapNavigateFunction,
          ),
          initialChildren: children,
        );

  static const String name = 'FloorDetailRoute';

  static const _i76.PageInfo<FloorDetailRouteArgs> page =
      _i76.PageInfo<FloorDetailRouteArgs>(name);
}

class FloorDetailRouteArgs {
  const FloorDetailRouteArgs({
    this.key,
    required this.receivingCardId,
    this.eMapNavigateFunction = _i85.EMapNavigateFunction.storing,
  });

  final _i79.Key? key;

  final int receivingCardId;

  final _i85.EMapNavigateFunction eMapNavigateFunction;

  @override
  String toString() {
    return 'FloorDetailRouteArgs{key: $key, receivingCardId: $receivingCardId, eMapNavigateFunction: $eMapNavigateFunction}';
  }
}

/// generated route for
/// [_i21.GRHaveBarcodePage]
class GRHaveBarcodeRoute extends _i76.PageRouteInfo<GRHaveBarcodeRouteArgs> {
  GRHaveBarcodeRoute({
    _i79.Key? key,
    _i80.ReceivingCard? receivingCard,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          GRHaveBarcodeRoute.name,
          args: GRHaveBarcodeRouteArgs(
            key: key,
            receivingCard: receivingCard,
          ),
          initialChildren: children,
        );

  static const String name = 'GRHaveBarcodeRoute';

  static const _i76.PageInfo<GRHaveBarcodeRouteArgs> page =
      _i76.PageInfo<GRHaveBarcodeRouteArgs>(name);
}

class GRHaveBarcodeRouteArgs {
  const GRHaveBarcodeRouteArgs({
    this.key,
    this.receivingCard,
  });

  final _i79.Key? key;

  final _i80.ReceivingCard? receivingCard;

  @override
  String toString() {
    return 'GRHaveBarcodeRouteArgs{key: $key, receivingCard: $receivingCard}';
  }
}

/// generated route for
/// [_i22.GRNoBarcodePage]
class GRNoBarcodeRoute extends _i76.PageRouteInfo<GRNoBarcodeRouteArgs> {
  GRNoBarcodeRoute({
    _i79.Key? key,
    _i80.ReceivingCard? receivingCard,
    String? material,
    required _i78.DeliveryPlan deliveryPlan,
    bool isOffsetGoods = false,
    bool isFuntionNG = false,
    bool isFuntionPMD = false,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          GRNoBarcodeRoute.name,
          args: GRNoBarcodeRouteArgs(
            key: key,
            receivingCard: receivingCard,
            material: material,
            deliveryPlan: deliveryPlan,
            isOffsetGoods: isOffsetGoods,
            isFuntionNG: isFuntionNG,
            isFuntionPMD: isFuntionPMD,
          ),
          initialChildren: children,
        );

  static const String name = 'GRNoBarcodeRoute';

  static const _i76.PageInfo<GRNoBarcodeRouteArgs> page =
      _i76.PageInfo<GRNoBarcodeRouteArgs>(name);
}

class GRNoBarcodeRouteArgs {
  const GRNoBarcodeRouteArgs({
    this.key,
    this.receivingCard,
    this.material,
    required this.deliveryPlan,
    this.isOffsetGoods = false,
    this.isFuntionNG = false,
    this.isFuntionPMD = false,
  });

  final _i79.Key? key;

  final _i80.ReceivingCard? receivingCard;

  final String? material;

  final _i78.DeliveryPlan deliveryPlan;

  final bool isOffsetGoods;

  final bool isFuntionNG;

  final bool isFuntionPMD;

  @override
  String toString() {
    return 'GRNoBarcodeRouteArgs{key: $key, receivingCard: $receivingCard, material: $material, deliveryPlan: $deliveryPlan, isOffsetGoods: $isOffsetGoods, isFuntionNG: $isFuntionNG, isFuntionPMD: $isFuntionPMD}';
  }
}

/// generated route for
/// [_i23.HomePage]
class HomeRoute extends _i76.PageRouteInfo<void> {
  const HomeRoute({List<_i76.PageRouteInfo>? children})
      : super(
          HomeRoute.name,
          initialChildren: children,
        );

  static const String name = 'HomeRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i24.IQCBorrowReceivingCardPage]
class IQCBorrowReceivingCardRoute extends _i76.PageRouteInfo<void> {
  const IQCBorrowReceivingCardRoute({List<_i76.PageRouteInfo>? children})
      : super(
          IQCBorrowReceivingCardRoute.name,
          initialChildren: children,
        );

  static const String name = 'IQCBorrowReceivingCardRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i25.IQCMenuPage]
class IQCMenuRoute extends _i76.PageRouteInfo<void> {
  const IQCMenuRoute({List<_i76.PageRouteInfo>? children})
      : super(
          IQCMenuRoute.name,
          initialChildren: children,
        );

  static const String name = 'IQCMenuRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i26.InputLocationPage]
class InputLocationRoute extends _i76.PageRouteInfo<void> {
  const InputLocationRoute({List<_i76.PageRouteInfo>? children})
      : super(
          InputLocationRoute.name,
          initialChildren: children,
        );

  static const String name = 'InputLocationRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i27.InputTrolleyPage]
class InputTrolleyRoute extends _i76.PageRouteInfo<void> {
  const InputTrolleyRoute({List<_i76.PageRouteInfo>? children})
      : super(
          InputTrolleyRoute.name,
          initialChildren: children,
        );

  static const String name = 'InputTrolleyRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i28.InventoryPage]
class InventoryRoute extends _i76.PageRouteInfo<void> {
  const InventoryRoute({List<_i76.PageRouteInfo>? children})
      : super(
          InventoryRoute.name,
          initialChildren: children,
        );

  static const String name = 'InventoryRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i29.KittingIndexPage]
class KittingIndexRoute extends _i76.PageRouteInfo<void> {
  const KittingIndexRoute({List<_i76.PageRouteInfo>? children})
      : super(
          KittingIndexRoute.name,
          initialChildren: children,
        );

  static const String name = 'KittingIndexRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i30.KittingModelPage]
class KittingModelRoute extends _i76.PageRouteInfo<void> {
  const KittingModelRoute({List<_i76.PageRouteInfo>? children})
      : super(
          KittingModelRoute.name,
          initialChildren: children,
        );

  static const String name = 'KittingModelRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i31.KittingPage]
class KittingRoute extends _i76.PageRouteInfo<KittingRouteArgs> {
  KittingRoute({
    _i79.Key? key,
    _i86.KittingType? kittingType,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          KittingRoute.name,
          args: KittingRouteArgs(
            key: key,
            kittingType: kittingType,
          ),
          initialChildren: children,
        );

  static const String name = 'KittingRoute';

  static const _i76.PageInfo<KittingRouteArgs> page =
      _i76.PageInfo<KittingRouteArgs>(name);
}

class KittingRouteArgs {
  const KittingRouteArgs({
    this.key,
    this.kittingType,
  });

  final _i79.Key? key;

  final _i86.KittingType? kittingType;

  @override
  String toString() {
    return 'KittingRouteArgs{key: $key, kittingType: $kittingType}';
  }
}

/// generated route for
/// [_i32.ListBorrowItemPage]
class ListBorrowItemRoute extends _i76.PageRouteInfo<void> {
  const ListBorrowItemRoute({List<_i76.PageRouteInfo>? children})
      : super(
          ListBorrowItemRoute.name,
          initialChildren: children,
        );

  static const String name = 'ListBorrowItemRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i33.ListBoxCardPage]
class ListBoxCardRoute extends _i76.PageRouteInfo<ListBoxCardRouteArgs> {
  ListBoxCardRoute({
    _i79.Key? key,
    required List<_i77.Barcode> barcodes,
    required dynamic totalQuantity,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          ListBoxCardRoute.name,
          args: ListBoxCardRouteArgs(
            key: key,
            barcodes: barcodes,
            totalQuantity: totalQuantity,
          ),
          initialChildren: children,
        );

  static const String name = 'ListBoxCardRoute';

  static const _i76.PageInfo<ListBoxCardRouteArgs> page =
      _i76.PageInfo<ListBoxCardRouteArgs>(name);
}

class ListBoxCardRouteArgs {
  const ListBoxCardRouteArgs({
    this.key,
    required this.barcodes,
    required this.totalQuantity,
  });

  final _i79.Key? key;

  final List<_i77.Barcode> barcodes;

  final dynamic totalQuantity;

  @override
  String toString() {
    return 'ListBoxCardRouteArgs{key: $key, barcodes: $barcodes, totalQuantity: $totalQuantity}';
  }
}

/// generated route for
/// [_i34.LoginPage]
class LoginRoute extends _i76.PageRouteInfo<void> {
  const LoginRoute({List<_i76.PageRouteInfo>? children})
      : super(
          LoginRoute.name,
          initialChildren: children,
        );

  static const String name = 'LoginRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i35.MaterialHistoryTransitionPage]
class MaterialHistoryTransitionRoute
    extends _i76.PageRouteInfo<MaterialHistoryTransitionRouteArgs> {
  MaterialHistoryTransitionRoute({
    _i79.Key? key,
    required String material,
    required String sloc,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          MaterialHistoryTransitionRoute.name,
          args: MaterialHistoryTransitionRouteArgs(
            key: key,
            material: material,
            sloc: sloc,
          ),
          initialChildren: children,
        );

  static const String name = 'MaterialHistoryTransitionRoute';

  static const _i76.PageInfo<MaterialHistoryTransitionRouteArgs> page =
      _i76.PageInfo<MaterialHistoryTransitionRouteArgs>(name);
}

class MaterialHistoryTransitionRouteArgs {
  const MaterialHistoryTransitionRouteArgs({
    this.key,
    required this.material,
    required this.sloc,
  });

  final _i79.Key? key;

  final String material;

  final String sloc;

  @override
  String toString() {
    return 'MaterialHistoryTransitionRouteArgs{key: $key, material: $material, sloc: $sloc}';
  }
}

/// generated route for
/// [_i36.MaterialPositionPage]
class MaterialPositionRoute
    extends _i76.PageRouteInfo<MaterialPositionRouteArgs> {
  MaterialPositionRoute({
    _i79.Key? key,
    required String material,
    required String currentSloc,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          MaterialPositionRoute.name,
          args: MaterialPositionRouteArgs(
            key: key,
            material: material,
            currentSloc: currentSloc,
          ),
          initialChildren: children,
        );

  static const String name = 'MaterialPositionRoute';

  static const _i76.PageInfo<MaterialPositionRouteArgs> page =
      _i76.PageInfo<MaterialPositionRouteArgs>(name);
}

class MaterialPositionRouteArgs {
  const MaterialPositionRouteArgs({
    this.key,
    required this.material,
    required this.currentSloc,
  });

  final _i79.Key? key;

  final String material;

  final String currentSloc;

  @override
  String toString() {
    return 'MaterialPositionRouteArgs{key: $key, material: $material, currentSloc: $currentSloc}';
  }
}

/// generated route for
/// [_i37.MaterialSamplePage]
class MaterialSampleRoute extends _i76.PageRouteInfo<MaterialSampleRouteArgs> {
  MaterialSampleRoute({
    _i79.Key? key,
    required String material,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          MaterialSampleRoute.name,
          args: MaterialSampleRouteArgs(
            key: key,
            material: material,
          ),
          initialChildren: children,
        );

  static const String name = 'MaterialSampleRoute';

  static const _i76.PageInfo<MaterialSampleRouteArgs> page =
      _i76.PageInfo<MaterialSampleRouteArgs>(name);
}

class MaterialSampleRouteArgs {
  const MaterialSampleRouteArgs({
    this.key,
    required this.material,
  });

  final _i79.Key? key;

  final String material;

  @override
  String toString() {
    return 'MaterialSampleRouteArgs{key: $key, material: $material}';
  }
}

/// generated route for
/// [_i38.MenuAmrPage]
class MenuAmrRoute extends _i76.PageRouteInfo<void> {
  const MenuAmrRoute({List<_i76.PageRouteInfo>? children})
      : super(
          MenuAmrRoute.name,
          initialChildren: children,
        );

  static const String name = 'MenuAmrRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i39.MenuPmdPage]
class MenuPmdRoute extends _i76.PageRouteInfo<void> {
  const MenuPmdRoute({List<_i76.PageRouteInfo>? children})
      : super(
          MenuPmdRoute.name,
          initialChildren: children,
        );

  static const String name = 'MenuPmdRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i40.MoveReceivingCardPage]
class MoveReceivingCardRoute extends _i76.PageRouteInfo<void> {
  const MoveReceivingCardRoute({List<_i76.PageRouteInfo>? children})
      : super(
          MoveReceivingCardRoute.name,
          initialChildren: children,
        );

  static const String name = 'MoveReceivingCardRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i41.NewMapFloorPage]
class NewMapFloorRoute extends _i76.PageRouteInfo<NewMapFloorRouteArgs> {
  NewMapFloorRoute({
    _i79.Key? key,
    int? receivingCardId,
    String? material,
    _i85.EMapNavigateFunction eMapNavigateFunction =
        _i85.EMapNavigateFunction.storing,
    String? plant,
    String? sloc,
    String? category,
    int? startTime,
    int? endTime,
    double? qtyKitting,
    List<String> blockLocations = const [],
    List<_i76.PageRouteInfo>? children,
  }) : super(
          NewMapFloorRoute.name,
          args: NewMapFloorRouteArgs(
            key: key,
            receivingCardId: receivingCardId,
            material: material,
            eMapNavigateFunction: eMapNavigateFunction,
            plant: plant,
            sloc: sloc,
            category: category,
            startTime: startTime,
            endTime: endTime,
            qtyKitting: qtyKitting,
            blockLocations: blockLocations,
          ),
          initialChildren: children,
        );

  static const String name = 'NewMapFloorRoute';

  static const _i76.PageInfo<NewMapFloorRouteArgs> page =
      _i76.PageInfo<NewMapFloorRouteArgs>(name);
}

class NewMapFloorRouteArgs {
  const NewMapFloorRouteArgs({
    this.key,
    this.receivingCardId,
    this.material,
    this.eMapNavigateFunction = _i85.EMapNavigateFunction.storing,
    this.plant,
    this.sloc,
    this.category,
    this.startTime,
    this.endTime,
    this.qtyKitting,
    this.blockLocations = const [],
  });

  final _i79.Key? key;

  final int? receivingCardId;

  final String? material;

  final _i85.EMapNavigateFunction eMapNavigateFunction;

  final String? plant;

  final String? sloc;

  final String? category;

  final int? startTime;

  final int? endTime;

  final double? qtyKitting;

  final List<String> blockLocations;

  @override
  String toString() {
    return 'NewMapFloorRouteArgs{key: $key, receivingCardId: $receivingCardId, material: $material, eMapNavigateFunction: $eMapNavigateFunction, plant: $plant, sloc: $sloc, category: $category, startTime: $startTime, endTime: $endTime, qtyKitting: $qtyKitting, blockLocations: $blockLocations}';
  }
}

/// generated route for
/// [_i42.NewMapZonePage]
class NewMapZoneRoute extends _i76.PageRouteInfo<NewMapZoneRouteArgs> {
  NewMapZoneRoute({
    _i79.Key? key,
    int? receivingCardId,
    _i85.EMapNavigateFunction eMapNavigateFunction =
        _i85.EMapNavigateFunction.storing,
    _i87.EMapZone? zoneData,
    int totalTempQty = 0,
    int totalStoreQty = 0,
    String lastLotName = '',
    List<_i76.PageRouteInfo>? children,
  }) : super(
          NewMapZoneRoute.name,
          args: NewMapZoneRouteArgs(
            key: key,
            receivingCardId: receivingCardId,
            eMapNavigateFunction: eMapNavigateFunction,
            zoneData: zoneData,
            totalTempQty: totalTempQty,
            totalStoreQty: totalStoreQty,
            lastLotName: lastLotName,
          ),
          initialChildren: children,
        );

  static const String name = 'NewMapZoneRoute';

  static const _i76.PageInfo<NewMapZoneRouteArgs> page =
      _i76.PageInfo<NewMapZoneRouteArgs>(name);
}

class NewMapZoneRouteArgs {
  const NewMapZoneRouteArgs({
    this.key,
    this.receivingCardId,
    this.eMapNavigateFunction = _i85.EMapNavigateFunction.storing,
    this.zoneData,
    this.totalTempQty = 0,
    this.totalStoreQty = 0,
    this.lastLotName = '',
  });

  final _i79.Key? key;

  final int? receivingCardId;

  final _i85.EMapNavigateFunction eMapNavigateFunction;

  final _i87.EMapZone? zoneData;

  final int totalTempQty;

  final int totalStoreQty;

  final String lastLotName;

  @override
  String toString() {
    return 'NewMapZoneRouteArgs{key: $key, receivingCardId: $receivingCardId, eMapNavigateFunction: $eMapNavigateFunction, zoneData: $zoneData, totalTempQty: $totalTempQty, totalStoreQty: $totalStoreQty, lastLotName: $lastLotName}';
  }
}

/// generated route for
/// [_i43.OCRCheckingPanacimPage]
class OCRCheckingPanacimRoute extends _i76.PageRouteInfo<void> {
  const OCRCheckingPanacimRoute({List<_i76.PageRouteInfo>? children})
      : super(
          OCRCheckingPanacimRoute.name,
          initialChildren: children,
        );

  static const String name = 'OCRCheckingPanacimRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i44.OneForAllPage]
class OneForAllRoute extends _i76.PageRouteInfo<void> {
  const OneForAllRoute({List<_i76.PageRouteInfo>? children})
      : super(
          OneForAllRoute.name,
          initialChildren: children,
        );

  static const String name = 'OneForAllRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i45.OpenGoodReceiptPage]
class OpenGoodReceiptRoute extends _i76.PageRouteInfo<void> {
  const OpenGoodReceiptRoute({List<_i76.PageRouteInfo>? children})
      : super(
          OpenGoodReceiptRoute.name,
          initialChildren: children,
        );

  static const String name = 'OpenGoodReceiptRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i46.OutReceivingCardPage]
class OutReceivingCardRoute extends _i76.PageRouteInfo<void> {
  const OutReceivingCardRoute({List<_i76.PageRouteInfo>? children})
      : super(
          OutReceivingCardRoute.name,
          initialChildren: children,
        );

  static const String name = 'OutReceivingCardRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i47.OutStoragePage]
class OutStorageRoute extends _i76.PageRouteInfo<void> {
  const OutStorageRoute({List<_i76.PageRouteInfo>? children})
      : super(
          OutStorageRoute.name,
          initialChildren: children,
        );

  static const String name = 'OutStorageRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i48.OutTrolleyPage]
class OutTrolleyRoute extends _i76.PageRouteInfo<void> {
  const OutTrolleyRoute({List<_i76.PageRouteInfo>? children})
      : super(
          OutTrolleyRoute.name,
          initialChildren: children,
        );

  static const String name = 'OutTrolleyRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i49.OutpalletAmrPage]
class OutpalletAmrRoute extends _i76.PageRouteInfo<void> {
  const OutpalletAmrRoute({List<_i76.PageRouteInfo>? children})
      : super(
          OutpalletAmrRoute.name,
          initialChildren: children,
        );

  static const String name = 'OutpalletAmrRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i50.PalletDetailPage]
class PalletDetailRoute extends _i76.PageRouteInfo<PalletDetailRouteArgs> {
  PalletDetailRoute({
    _i79.Key? key,
    required int rackId,
    required int receivingCardId,
    required _i85.EMapNavigateFunction eMapNavigateFunction,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          PalletDetailRoute.name,
          args: PalletDetailRouteArgs(
            key: key,
            rackId: rackId,
            receivingCardId: receivingCardId,
            eMapNavigateFunction: eMapNavigateFunction,
          ),
          initialChildren: children,
        );

  static const String name = 'PalletDetailRoute';

  static const _i76.PageInfo<PalletDetailRouteArgs> page =
      _i76.PageInfo<PalletDetailRouteArgs>(name);
}

class PalletDetailRouteArgs {
  const PalletDetailRouteArgs({
    this.key,
    required this.rackId,
    required this.receivingCardId,
    required this.eMapNavigateFunction,
  });

  final _i79.Key? key;

  final int rackId;

  final int receivingCardId;

  final _i85.EMapNavigateFunction eMapNavigateFunction;

  @override
  String toString() {
    return 'PalletDetailRouteArgs{key: $key, rackId: $rackId, receivingCardId: $receivingCardId, eMapNavigateFunction: $eMapNavigateFunction}';
  }
}

/// generated route for
/// [_i51.PrintPurgingNGRunnePage]
class PrintPurgingNGRunneRoute extends _i76.PageRouteInfo<void> {
  const PrintPurgingNGRunneRoute({List<_i76.PageRouteInfo>? children})
      : super(
          PrintPurgingNGRunneRoute.name,
          initialChildren: children,
        );

  static const String name = 'PrintPurgingNGRunneRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i52.PrintReceivingCardPmdPage]
class PrintReceivingCardPmdRoute extends _i76.PageRouteInfo<void> {
  const PrintReceivingCardPmdRoute({List<_i76.PageRouteInfo>? children})
      : super(
          PrintReceivingCardPmdRoute.name,
          initialChildren: children,
        );

  static const String name = 'PrintReceivingCardPmdRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i53.RackDetailPage]
class RackDetailRoute extends _i76.PageRouteInfo<RackDetailRouteArgs> {
  RackDetailRoute({
    _i79.Key? key,
    required int rackId,
    required int receivingCardId,
    required _i85.EMapNavigateFunction eMapNavigateFunction,
    String lastNodeName = '',
    _i88.RackType? rackType,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          RackDetailRoute.name,
          args: RackDetailRouteArgs(
            key: key,
            rackId: rackId,
            receivingCardId: receivingCardId,
            eMapNavigateFunction: eMapNavigateFunction,
            lastNodeName: lastNodeName,
            rackType: rackType,
          ),
          initialChildren: children,
        );

  static const String name = 'RackDetailRoute';

  static const _i76.PageInfo<RackDetailRouteArgs> page =
      _i76.PageInfo<RackDetailRouteArgs>(name);
}

class RackDetailRouteArgs {
  const RackDetailRouteArgs({
    this.key,
    required this.rackId,
    required this.receivingCardId,
    required this.eMapNavigateFunction,
    this.lastNodeName = '',
    this.rackType,
  });

  final _i79.Key? key;

  final int rackId;

  final int receivingCardId;

  final _i85.EMapNavigateFunction eMapNavigateFunction;

  final String lastNodeName;

  final _i88.RackType? rackType;

  @override
  String toString() {
    return 'RackDetailRouteArgs{key: $key, rackId: $rackId, receivingCardId: $receivingCardId, eMapNavigateFunction: $eMapNavigateFunction, lastNodeName: $lastNodeName, rackType: $rackType}';
  }
}

/// generated route for
/// [_i54.RePrintRcConvertPage]
class RePrintRcConvertRoute
    extends _i76.PageRouteInfo<RePrintRcConvertRouteArgs> {
  RePrintRcConvertRoute({
    _i79.Key? key,
    required String stockBarcode,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          RePrintRcConvertRoute.name,
          args: RePrintRcConvertRouteArgs(
            key: key,
            stockBarcode: stockBarcode,
          ),
          initialChildren: children,
        );

  static const String name = 'RePrintRcConvertRoute';

  static const _i76.PageInfo<RePrintRcConvertRouteArgs> page =
      _i76.PageInfo<RePrintRcConvertRouteArgs>(name);
}

class RePrintRcConvertRouteArgs {
  const RePrintRcConvertRouteArgs({
    this.key,
    required this.stockBarcode,
  });

  final _i79.Key? key;

  final String stockBarcode;

  @override
  String toString() {
    return 'RePrintRcConvertRouteArgs{key: $key, stockBarcode: $stockBarcode}';
  }
}

/// generated route for
/// [_i55.ReceivingCardListPage]
class ReceivingCardListRoute
    extends _i76.PageRouteInfo<ReceivingCardListRouteArgs> {
  ReceivingCardListRoute({
    _i79.Key? key,
    _i78.DeliveryPlan? deliveryPlan,
    String? material,
    int? parentId,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          ReceivingCardListRoute.name,
          args: ReceivingCardListRouteArgs(
            key: key,
            deliveryPlan: deliveryPlan,
            material: material,
            parentId: parentId,
          ),
          initialChildren: children,
        );

  static const String name = 'ReceivingCardListRoute';

  static const _i76.PageInfo<ReceivingCardListRouteArgs> page =
      _i76.PageInfo<ReceivingCardListRouteArgs>(name);
}

class ReceivingCardListRouteArgs {
  const ReceivingCardListRouteArgs({
    this.key,
    this.deliveryPlan,
    this.material,
    this.parentId,
  });

  final _i79.Key? key;

  final _i78.DeliveryPlan? deliveryPlan;

  final String? material;

  final int? parentId;

  @override
  String toString() {
    return 'ReceivingCardListRouteArgs{key: $key, deliveryPlan: $deliveryPlan, material: $material, parentId: $parentId}';
  }
}

/// generated route for
/// [_i56.ReceivingPage]
class ReceivingRoute extends _i76.PageRouteInfo<void> {
  const ReceivingRoute({List<_i76.PageRouteInfo>? children})
      : super(
          ReceivingRoute.name,
          initialChildren: children,
        );

  static const String name = 'ReceivingRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i57.ReprintBarcodeNGPage]
class ReprintBarcodeNGRoute extends _i76.PageRouteInfo<void> {
  const ReprintBarcodeNGRoute({List<_i76.PageRouteInfo>? children})
      : super(
          ReprintBarcodeNGRoute.name,
          initialChildren: children,
        );

  static const String name = 'ReprintBarcodeNGRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i58.ReprintReceivingCardPage]
class ReprintReceivingCardRoute extends _i76.PageRouteInfo<void> {
  const ReprintReceivingCardRoute({List<_i76.PageRouteInfo>? children})
      : super(
          ReprintReceivingCardRoute.name,
          initialChildren: children,
        );

  static const String name = 'ReprintReceivingCardRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i59.ReturnKittingPage]
class ReturnKittingRoute extends _i76.PageRouteInfo<void> {
  const ReturnKittingRoute({List<_i76.PageRouteInfo>? children})
      : super(
          ReturnKittingRoute.name,
          initialChildren: children,
        );

  static const String name = 'ReturnKittingRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i60.RevertKittingPage]
class RevertKittingRoute extends _i76.PageRouteInfo<void> {
  const RevertKittingRoute({List<_i76.PageRouteInfo>? children})
      : super(
          RevertKittingRoute.name,
          initialChildren: children,
        );

  static const String name = 'RevertKittingRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i61.SelectDAInvoicePage]
class SelectDAInvoiceRoute
    extends _i76.PageRouteInfo<SelectDAInvoiceRouteArgs> {
  SelectDAInvoiceRoute({
    _i79.Key? key,
    String? material,
    String? po,
    String? poItem,
    String? deliveryPlanNo,
    _i89.DeliveryPlanType? deliveryPlanType,
    double? quantity,
    bool includeGoodReceipt = false,
    required bool IsFuntionNG,
    required bool IsFuntionPMD,
    required void Function(
      _i78.DeliveryPlan?,
      String?,
    ) onSelect,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          SelectDAInvoiceRoute.name,
          args: SelectDAInvoiceRouteArgs(
            key: key,
            material: material,
            po: po,
            poItem: poItem,
            deliveryPlanNo: deliveryPlanNo,
            deliveryPlanType: deliveryPlanType,
            quantity: quantity,
            includeGoodReceipt: includeGoodReceipt,
            IsFuntionNG: IsFuntionNG,
            IsFuntionPMD: IsFuntionPMD,
            onSelect: onSelect,
          ),
          initialChildren: children,
        );

  static const String name = 'SelectDAInvoiceRoute';

  static const _i76.PageInfo<SelectDAInvoiceRouteArgs> page =
      _i76.PageInfo<SelectDAInvoiceRouteArgs>(name);
}

class SelectDAInvoiceRouteArgs {
  const SelectDAInvoiceRouteArgs({
    this.key,
    this.material,
    this.po,
    this.poItem,
    this.deliveryPlanNo,
    this.deliveryPlanType,
    this.quantity,
    this.includeGoodReceipt = false,
    required this.IsFuntionNG,
    required this.IsFuntionPMD,
    required this.onSelect,
  });

  final _i79.Key? key;

  final String? material;

  final String? po;

  final String? poItem;

  final String? deliveryPlanNo;

  final _i89.DeliveryPlanType? deliveryPlanType;

  final double? quantity;

  final bool includeGoodReceipt;

  final bool IsFuntionNG;

  final bool IsFuntionPMD;

  final void Function(
    _i78.DeliveryPlan?,
    String?,
  ) onSelect;

  @override
  String toString() {
    return 'SelectDAInvoiceRouteArgs{key: $key, material: $material, po: $po, poItem: $poItem, deliveryPlanNo: $deliveryPlanNo, deliveryPlanType: $deliveryPlanType, quantity: $quantity, includeGoodReceipt: $includeGoodReceipt, IsFuntionNG: $IsFuntionNG, IsFuntionPMD: $IsFuntionPMD, onSelect: $onSelect}';
  }
}

/// generated route for
/// [_i62.SplitReceivingPage]
class SplitReceivingRoute extends _i76.PageRouteInfo<void> {
  const SplitReceivingRoute({List<_i76.PageRouteInfo>? children})
      : super(
          SplitReceivingRoute.name,
          initialChildren: children,
        );

  static const String name = 'SplitReceivingRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i63.StockToReceivingCardPage]
class StockToReceivingCardRoute extends _i76.PageRouteInfo<void> {
  const StockToReceivingCardRoute({List<_i76.PageRouteInfo>? children})
      : super(
          StockToReceivingCardRoute.name,
          initialChildren: children,
        );

  static const String name = 'StockToReceivingCardRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i64.StorageBorrowItemPage]
class StorageBorrowItemRoute extends _i76.PageRouteInfo<void> {
  const StorageBorrowItemRoute({List<_i76.PageRouteInfo>? children})
      : super(
          StorageBorrowItemRoute.name,
          initialChildren: children,
        );

  static const String name = 'StorageBorrowItemRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i65.StorageJupiterPage]
class StorageJupiterRoute extends _i76.PageRouteInfo<void> {
  const StorageJupiterRoute({List<_i76.PageRouteInfo>? children})
      : super(
          StorageJupiterRoute.name,
          initialChildren: children,
        );

  static const String name = 'StorageJupiterRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i66.StorageRCCardPage]
class StorageRCCardRoute extends _i76.PageRouteInfo<StorageRCCardRouteArgs> {
  StorageRCCardRoute({
    _i79.Key? key,
    String? rcBarcode,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          StorageRCCardRoute.name,
          args: StorageRCCardRouteArgs(
            key: key,
            rcBarcode: rcBarcode,
          ),
          initialChildren: children,
        );

  static const String name = 'StorageRCCardRoute';

  static const _i76.PageInfo<StorageRCCardRouteArgs> page =
      _i76.PageInfo<StorageRCCardRouteArgs>(name);
}

class StorageRCCardRouteArgs {
  const StorageRCCardRouteArgs({
    this.key,
    this.rcBarcode,
  });

  final _i79.Key? key;

  final String? rcBarcode;

  @override
  String toString() {
    return 'StorageRCCardRouteArgs{key: $key, rcBarcode: $rcBarcode}';
  }
}

/// generated route for
/// [_i67.StoringPage]
class StoringRoute extends _i76.PageRouteInfo<void> {
  const StoringRoute({List<_i76.PageRouteInfo>? children})
      : super(
          StoringRoute.name,
          initialChildren: children,
        );

  static const String name = 'StoringRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i68.SupplyDryingChamberPage]
class SupplyDryingChamberRoute extends _i76.PageRouteInfo<void> {
  const SupplyDryingChamberRoute({List<_i76.PageRouteInfo>? children})
      : super(
          SupplyDryingChamberRoute.name,
          initialChildren: children,
        );

  static const String name = 'SupplyDryingChamberRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i69.SupplyKittingPage]
class SupplyKittingRoute extends _i76.PageRouteInfo<SupplyKittingRouteArgs> {
  SupplyKittingRoute({
    _i79.Key? key,
    _i86.KittingType? kittingType,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          SupplyKittingRoute.name,
          args: SupplyKittingRouteArgs(
            key: key,
            kittingType: kittingType,
          ),
          initialChildren: children,
        );

  static const String name = 'SupplyKittingRoute';

  static const _i76.PageInfo<SupplyKittingRouteArgs> page =
      _i76.PageInfo<SupplyKittingRouteArgs>(name);
}

class SupplyKittingRouteArgs {
  const SupplyKittingRouteArgs({
    this.key,
    this.kittingType,
  });

  final _i79.Key? key;

  final _i86.KittingType? kittingType;

  @override
  String toString() {
    return 'SupplyKittingRouteArgs{key: $key, kittingType: $kittingType}';
  }
}

/// generated route for
/// [_i70.TemporaryAreaPage]
class TemporaryAreaRoute extends _i76.PageRouteInfo<void> {
  const TemporaryAreaRoute({List<_i76.PageRouteInfo>? children})
      : super(
          TemporaryAreaRoute.name,
          initialChildren: children,
        );

  static const String name = 'TemporaryAreaRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i71.TrolleyMapHTMLPage]
class TrolleyMapHTMLRoute extends _i76.PageRouteInfo<TrolleyMapHTMLRouteArgs> {
  TrolleyMapHTMLRoute({
    _i79.Key? key,
    required String trolleyCode,
    required int kittingListId,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          TrolleyMapHTMLRoute.name,
          args: TrolleyMapHTMLRouteArgs(
            key: key,
            trolleyCode: trolleyCode,
            kittingListId: kittingListId,
          ),
          initialChildren: children,
        );

  static const String name = 'TrolleyMapHTMLRoute';

  static const _i76.PageInfo<TrolleyMapHTMLRouteArgs> page =
      _i76.PageInfo<TrolleyMapHTMLRouteArgs>(name);
}

class TrolleyMapHTMLRouteArgs {
  const TrolleyMapHTMLRouteArgs({
    this.key,
    required this.trolleyCode,
    required this.kittingListId,
  });

  final _i79.Key? key;

  final String trolleyCode;

  final int kittingListId;

  @override
  String toString() {
    return 'TrolleyMapHTMLRouteArgs{key: $key, trolleyCode: $trolleyCode, kittingListId: $kittingListId}';
  }
}

/// generated route for
/// [_i72.UpdateBoxcardPMDPage]
class UpdateBoxcardPMDRoute extends _i76.PageRouteInfo<void> {
  const UpdateBoxcardPMDRoute({List<_i76.PageRouteInfo>? children})
      : super(
          UpdateBoxcardPMDRoute.name,
          initialChildren: children,
        );

  static const String name = 'UpdateBoxcardPMDRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i73.UpdateQuantityPlanPMDPage]
class UpdateQuantityPlanPMDRoute
    extends _i76.PageRouteInfo<UpdateQuantityPlanPMDRouteArgs> {
  UpdateQuantityPlanPMDRoute({
    required _i82.KittingDetail detail,
    _i79.Key? key,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          UpdateQuantityPlanPMDRoute.name,
          args: UpdateQuantityPlanPMDRouteArgs(
            detail: detail,
            key: key,
          ),
          initialChildren: children,
        );

  static const String name = 'UpdateQuantityPlanPMDRoute';

  static const _i76.PageInfo<UpdateQuantityPlanPMDRouteArgs> page =
      _i76.PageInfo<UpdateQuantityPlanPMDRouteArgs>(name);
}

class UpdateQuantityPlanPMDRouteArgs {
  const UpdateQuantityPlanPMDRouteArgs({
    required this.detail,
    this.key,
  });

  final _i82.KittingDetail detail;

  final _i79.Key? key;

  @override
  String toString() {
    return 'UpdateQuantityPlanPMDRouteArgs{detail: $detail, key: $key}';
  }
}

/// generated route for
/// [_i74.UpdateQuantityPurgingNGRunnerPage]
class UpdateQuantityPurgingNGRunnerRoute extends _i76.PageRouteInfo<void> {
  const UpdateQuantityPurgingNGRunnerRoute({List<_i76.PageRouteInfo>? children})
      : super(
          UpdateQuantityPurgingNGRunnerRoute.name,
          initialChildren: children,
        );

  static const String name = 'UpdateQuantityPurgingNGRunnerRoute';

  static const _i76.PageInfo<void> page = _i76.PageInfo<void>(name);
}

/// generated route for
/// [_i75.ZoneDetailPage]
class ZoneDetailRoute extends _i76.PageRouteInfo<ZoneDetailRouteArgs> {
  ZoneDetailRoute({
    _i79.Key? key,
    required int receivingCardId,
    int? zoneId,
    _i85.EMapNavigateFunction eMapNavigateFunction =
        _i85.EMapNavigateFunction.storing,
    List<_i76.PageRouteInfo>? children,
  }) : super(
          ZoneDetailRoute.name,
          args: ZoneDetailRouteArgs(
            key: key,
            receivingCardId: receivingCardId,
            zoneId: zoneId,
            eMapNavigateFunction: eMapNavigateFunction,
          ),
          initialChildren: children,
        );

  static const String name = 'ZoneDetailRoute';

  static const _i76.PageInfo<ZoneDetailRouteArgs> page =
      _i76.PageInfo<ZoneDetailRouteArgs>(name);
}

class ZoneDetailRouteArgs {
  const ZoneDetailRouteArgs({
    this.key,
    required this.receivingCardId,
    this.zoneId,
    this.eMapNavigateFunction = _i85.EMapNavigateFunction.storing,
  });

  final _i79.Key? key;

  final int receivingCardId;

  final int? zoneId;

  final _i85.EMapNavigateFunction eMapNavigateFunction;

  @override
  String toString() {
    return 'ZoneDetailRouteArgs{key: $key, receivingCardId: $receivingCardId, zoneId: $zoneId, eMapNavigateFunction: $eMapNavigateFunction}';
  }
}
