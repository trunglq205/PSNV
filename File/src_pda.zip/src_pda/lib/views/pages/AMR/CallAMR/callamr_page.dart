import 'package:auto_route/annotations.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:smart_warehouse/shared/base/base_page.dart';
import 'package:smart_warehouse/shared/extensions/duration_extensions.dart';
import 'package:smart_warehouse/shared/extensions/widget_extensions.dart';
import '../../../../di/di.dart';
import '../../../../entities/Robot/robot_location_start.dart';
import '../../../../shared/utils/alert.dart';
import '../../../../shared/utils/logger.dart';
import '../../../../subsystem/pda/pda.dart';
import '../../../widgets/app_form_field.dart';
import 'callamr_controller.dart';
import 'callamr_state.dart';

@RoutePage()
class CallAMRPage extends BasePage<CallAMRController, CallAMRState> {
  const CallAMRPage({super.key});
  @override
  BasePageState createState() => _CallAMRPageState();
}
class _CallAMRPageState
    extends BasePageState<CallAMRController, CallAMRState>

{
  late TextEditingController _controller;
  bool IsUrgent = false;
  bool IsCancel = false;
  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    _controller = TextEditingController();


    getIt<PdaDevice>().listen(context, (data) async {logger.d('Barcode: $data');
      _controller.text = data;

    });
  }

  @override
  Widget builder(context, cubit, state) {
    return Scaffold(
       appBar: AppBar(title: const Text('Call Robot')),
      body:  Column(
        children: [
          Row(
            children: [
              const Text('Location: '),
              const SizedBox(width: 8),
              Expanded(
                child: AppFormField(
                  readOnly: true,
                  autoFocus: true,
                  controller: _controller,
                ),
              ),


            ],
          ).paddingSymmetric(horizontal: 16, vertical: 8),


          Row(
            children: [
              InkWell(
                onTap: () {
                  setState(() {
                    IsUrgent = !IsUrgent;   // toggle
                  });
                },
                child: Row(
                  children: [
                    Checkbox(
                      value: IsUrgent,
                      onChanged: (value) {
                        setState(() {
                          IsUrgent = value ?? false;
                        });
                      },
                    ),
                    const Text('Urgent'),

                  ],
                ),
              ),
              InkWell(
                onTap: () {
                  setState(() {
                    IsCancel = !IsCancel;   // toggle
                  });
                },
                child: Row(
                  children: [

                    Checkbox(
                      value: IsCancel,
                      onChanged: (value) {
                        setState(() {
                          IsCancel = value ?? false;
                        });
                      },
                    ),
                    const Text('Cancel'),
                  ],
                ),
              ),
            ],
          ),
          const Divider(),


        ],
      ),
      bottomNavigationBar: ElevatedButton(
        onPressed: () async {
          final cubit = context.read<CallAMRController>();
          await cubit.Robot_Call(_controller.text,IsUrgent,IsCancel);
          await Duration.zero.delay(() async {
            getIt<AppAlertDialog>().show(
              context,
              type: AppAlertType.success,
            );
          });
        },
        child:
        const Text('Confirm Call Robot'),
      ).paddingSymmetric(horizontal: 16, vertical: 8),
    );
  }

}