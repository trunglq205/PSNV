using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.EmailConfigs.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.EmailConfigs.Api;

[ApiController]
[Route("api/email-configs")]
public class EmailConfigsController : ControllerBase
{
    private readonly IEmailConfigService _service;
    public EmailConfigsController(IEmailConfigService service) => _service = service;

    // ── Loại mail + mẫu nội dung ────────────────────────────

    [HttpGet("events")]
    [RequirePermission<Perms.System.EmailConfig.View>]
    public async Task<ActionResult<List<EmailEventResponse>>> GetEvents([FromQuery] string? module)
        => Ok(await _service.GetEventsAsync(module));

    [HttpGet("events/{code}/subtypes")]
    [RequirePermission<Perms.System.EmailConfig.View>]
    public async Task<ActionResult<List<EmailSubtypeResponse>>> GetSubtypes(string code)
        => Ok(await _service.GetSubtypesAsync(code));

    [HttpPut("events/{code}/template")]
    [RequirePermission<Perms.System.EmailConfig.Update>]
    public async Task<IActionResult> SaveTemplate(string code, SaveTemplateRequest request)
    {
        await _service.SaveTemplateAsync(code, request);
        return NoContent();
    }

    // ── Người nhận ──────────────────────────────────────────

    [HttpGet("events/{code}/recipients")]
    [RequirePermission<Perms.System.EmailConfig.View>]
    public async Task<ActionResult<List<EmailConfigResponse>>> GetConfigs(string code)
        => Ok(await _service.GetConfigsAsync(code));

    [HttpPost("recipients")]
    [RequirePermission<Perms.System.EmailConfig.Update>]
    public async Task<ActionResult<EmailConfigResponse>> Create(SaveEmailConfigRequest request)
        => Ok(await _service.CreateAsync(request));

    [HttpPut("recipients/{id:long}")]
    [RequirePermission<Perms.System.EmailConfig.Update>]
    public async Task<IActionResult> Update(long id, SaveEmailConfigRequest request)
    {
        await _service.UpdateAsync(id, request);
        return NoContent();
    }

    [HttpDelete("recipients/{id:long}")]
    [RequirePermission<Perms.System.EmailConfig.Update>]
    public async Task<IActionResult> Delete(long id)
    {
        await _service.DeleteAsync(id);
        return NoContent();
    }

    /// <summary>Tình huống này gửi cho ai — gọi master.fn_email_recipients.</summary>
    [HttpGet("resolve")]
    [RequirePermission<Perms.System.EmailConfig.View>]
    public async Task<ActionResult<List<EmailRecipientResponse>>> Resolve(
        [FromQuery] string eventCode, [FromQuery] string? department, [FromQuery] string? subCode,
        [FromQuery] string? category, [FromQuery] string? model, [FromQuery] string? areaCode)
        => Ok(await _service.ResolveAsync(eventCode, department, subCode, category, model, areaCode));
}
