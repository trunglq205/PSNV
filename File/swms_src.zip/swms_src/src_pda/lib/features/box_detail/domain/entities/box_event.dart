import 'package:swms_finish_goods/shared/domain/entities/stock_event.dart';

/// Vị trí + khu trong một mốc lịch sử.
class EventLocator {
  final String locatorCode;
  final String? areaCode;

  const EventLocator({required this.locatorCode, this.areaCode});

  /// "FA · A-03-02-01" — khu đứng trước để đọc từ to đến nhỏ.
  String get display =>
      (areaCode == null || areaCode!.isEmpty)
          ? locatorCode
          : '$areaCode · $locatorCode';
}

/// Một mốc lịch sử của THÙNG — khớp `BoxEventResponse` của API
/// (`GET /api/boxes/{id}/history`).
///
/// Timeline thùng gồm HAI loại dòng, phân biệt bằng [inherited]:
///
///   false — thao tác trên chính thùng này (tạo, đổi pallet, sửa PO, OQC)
///   true  — KẾ THỪA từ pallet chứa nó (lưu kho, chuyển vị trí, vanning...)
///
/// Thùng không tự đi lưu kho: nó nằm trên pallet và pallet đi. Server không
/// nhân bản event vị trí cho từng thùng (pallet 40 thùng sẽ đẻ 40 dòng mỗi lần
/// quét) mà suy ra lúc đọc, dựa trên khoảng thời gian thùng thuộc pallet nào.
///
/// UI PHẢI phân biệt hai mức. Trộn phẳng thì người dùng tưởng có ai quét riêng
/// từng thùng.
class BoxEvent {
  final int id;
  final String eventCode;
  final DateTime eventAt;
  final String? actor;

  /// true = kế thừa từ pallet chứa thùng.
  final bool inherited;

  /// Pallet chứa thùng TẠI THỜI ĐIỂM đó — đổi sau mỗi lần tách.
  final String? palletCode;

  final EventLocator? fromLocator;
  final EventLocator? toLocator;

  /// Số phiếu tham chiếu (SI, container, pallet list...).
  final String? refNo;

  final String? note;

  /// JSON nguyên văn — hiện chưa parse. Vd BOX_PO_CHANGED trả
  /// `{"customer_po":{"from":...,"to":...}}`.
  final String? payload;

  const BoxEvent({
    required this.id,
    required this.eventCode,
    required this.eventAt,
    required this.inherited,
    this.actor,
    this.palletCode,
    this.fromLocator,
    this.toLocator,
    this.refNo,
    this.note,
    this.payload,
  });

  String get labelKey => StockEventCodes.labelKey(eventCode);

  StockEventTone get tone => StockEventTone.forCode(eventCode);

  /// Vị trí hiển thị cạnh tiêu đề: ưu tiên đích, không có thì lấy nguồn.
  EventLocator? get place => toLocator ?? fromLocator;

  /// Có cả nguồn lẫn đích -> hiện đường đi A → B.
  bool get hasMovePath => fromLocator != null && toLocator != null;
}

/// Header của màn lịch sử thùng — khớp `BoxHistoryHeaderResponse`.
///
/// Hiện màn Box Detail đã có [BoxDetail] nên chưa đọc tới, nhưng giữ để không
/// phải sửa model khi cần (vd mở lịch sử từ chỗ khác, chưa có sẵn detail).
class BoxHistoryHeader {
  final int boxId;
  final String boxNo;
  final String? palletCode;
  final String? model;
  final int lineCount;
  final int? totalQty;
  final int? oqcStatus;
  final EventLocator? currentLocator;
  final bool isDeleted;

  const BoxHistoryHeader({
    required this.boxId,
    required this.boxNo,
    required this.lineCount,
    required this.isDeleted,
    this.palletCode,
    this.model,
    this.totalQty,
    this.oqcStatus,
    this.currentLocator,
  });
}

class BoxHistory {
  final BoxHistoryHeader header;
  final List<BoxEvent> events;

  const BoxHistory({required this.header, this.events = const []});
}