import 'package:flutter/material.dart';

/// Loading toàn màn hình dùng chung.
class AppLoading extends StatelessWidget {
  const AppLoading({super.key});

  @override
  Widget build(BuildContext context) =>
      const Center(child: CircularProgressIndicator());
}
