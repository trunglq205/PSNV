﻿using System.ComponentModel;
using System.Reflection;
using System.Runtime.Serialization;
using Microsoft.AspNetCore.Mvc.Rendering;
using SWMS_WebTool.Services;

namespace SWMS_WebTool.Utils.Extensions
{
    /// <summary>
    /// uses extension methods to convert enums with hypens in their names to underscore and other variants
    /// I'm not sure this is a good idea. While it makes that section of the code much much nicer to maintain, it 
    /// also incurs a performance hit via reflection. To circumvent this, I've added a dictionary so all the lookup can be done once at 
    /// load time. It requires that all enums involved in this extension are in this assembly.
    /// </summary>
    public static class EnumExtensions
    {
        //To avoid collisions, every Enum type has its own hash table
        private static readonly Dictionary<Type, Dictionary<object, string>> enumToStringDictionary = new Dictionary<Type, Dictionary<object, string>>();
        private static readonly Dictionary<Type, Dictionary<string, object>> stringToEnumDictionary = new Dictionary<Type, Dictionary<string, object>>();

        static EnumExtensions()
        {
            //let's collect the enums we care about
            List<Type> enumTypeList = new List<Type>();

            //probe this assembly for all enums
            System.Reflection.Assembly assembly = System.Reflection.Assembly.GetExecutingAssembly();
            Type[] exportedTypes = assembly.GetExportedTypes();

            foreach (Type type in exportedTypes)
            {
                if (type.IsEnum)
                    enumTypeList.Add(type);
            }

            //for each enum in our list, populate the appropriate dictionaries
            foreach (Type type in enumTypeList)
            {
                //add dictionaries for this type
                EnumExtensions.enumToStringDictionary.Add(type, new Dictionary<object, string>());
                EnumExtensions.stringToEnumDictionary.Add(type, new Dictionary<string, object>());

                Array values = Enum.GetValues(type);

                //its ok to manipulate 'value' as object, since when we convert we're given the type to cast to
                foreach (object value in values)
                {
                    System.Reflection.FieldInfo fieldInfo = type.GetField(value.ToString());

                    //check for an attribute 
                    System.ComponentModel.DescriptionAttribute? attribute =
                           Attribute.GetCustomAttribute(fieldInfo,
                             typeof(System.ComponentModel.DescriptionAttribute)) as System.ComponentModel.DescriptionAttribute;

                    //populate our dictionaries
                    if (attribute != null)
                    {
                        EnumExtensions.enumToStringDictionary[type].Add(value, attribute.Description);
                        EnumExtensions.stringToEnumDictionary[type].Add(attribute.Description, value);
                    }
                    else
                    {
                        EnumExtensions.enumToStringDictionary[type].Add(value, value.ToString());
                        EnumExtensions.stringToEnumDictionary[type].Add(value.ToString(), value);
                    }
                }
            }
        }

        public static string GetString(this Enum value)
        {
            Type type = value.GetType();
            string aString = EnumExtensions.enumToStringDictionary[type][value];
            return aString;
        }

        public static T? ToEnum<T>(this string? value)
        {
            try
            {
                Type type = typeof(T);
                T theEnum = (T)EnumExtensions.stringToEnumDictionary[type][value];
                return theEnum;
            } catch
            {
                return default(T);
            }
        }

        public static string ToEnumMemberAttrValue(this Enum @enum)
        {
            var attr =
                @enum.GetType().GetMember(@enum.ToString()).FirstOrDefault()?.
                    GetCustomAttributes(false).OfType<EnumMemberAttribute>().
                    FirstOrDefault();
            if (attr == null)
                return @enum.ToString();
            return attr.Value;
        }

        public static string GetEnumDescription(this Enum value)
        {
            FieldInfo fi = value.GetType().GetField(value.ToString());

            DescriptionAttribute[] attributes = (DescriptionAttribute[])fi.GetCustomAttributes(typeof(DescriptionAttribute), false);

            return (attributes.Length > 0) ? attributes[0].Description : value.ToString();
        }

        /// <summary>
        /// Lấy Description của enum và dịch qua i18n.
        /// Quy ước: [Description("Status_KeyName")] - giá trị Description = KEY trong JSON.
        /// </summary>
        public static string GetStringLocalized(this Enum value, ILocalizationService loc)
        {
            Type type = value.GetType();
            string key = EnumExtensions.enumToStringDictionary[type][value];
            return loc?.Get(key) ?? key;
        }

        /// <summary>
        /// Convert enum thành SelectListItem list đã được i18n.
        /// </summary>
        public static IEnumerable<SelectListItem> ToLocalizedSelectList<TEnum>(
            this ILocalizationService loc,
            TEnum? selected = default) where TEnum : struct, Enum
        {
            return Enum.GetValues(typeof(TEnum)).Cast<TEnum>().Select(e => new SelectListItem
            {
                Text = (e as Enum).GetStringLocalized(loc),
                Value = e.ToString(),
                Selected = e.Equals(selected)
            });
        }

        /// <summary>
        /// Overload với filter để loại bớt 1 vài enum values (ví dụ: filter Ok khỏi danh sách).
        /// </summary>
        public static IEnumerable<SelectListItem> ToLocalizedSelectList<TEnum>(
            this ILocalizationService loc,
            TEnum? selected,
            Func<TEnum, bool> filter) where TEnum : struct, Enum
        {
            return Enum.GetValues(typeof(TEnum)).Cast<TEnum>()
                .Where(filter)
                .Select(e => new SelectListItem
                {
                    Text = (e as Enum).GetStringLocalized(loc),
                    Value = e.ToString(),
                    Selected = e.Equals(selected)
                });
        }
    }
}

