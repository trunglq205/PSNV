// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, deprecated_member_use, deprecated_member_use_from_same_package, use_function_type_syntax_for_parameters, unnecessary_const, avoid_init_to_null, invalid_override_different_default_values_named, prefer_expression_function_bodies, annotate_overrides, invalid_annotation_target, unnecessary_question_mark

part of 'outpallet_amr_state.dart';

// **************************************************************************
// FreezedGenerator
// **************************************************************************

T _$identity<T>(T value) => value;

final _privateConstructorUsedError = UnsupportedError(
    'It seems like you constructed your class using `MyClass._()`. This constructor is only meant to be used by freezed and you are not supposed to need it nor use it.\nPlease check the documentation here for more information: https://github.com/rrousselGit/freezed#adding-getters-and-methods-to-our-models');

/// @nodoc
mixin _$OutpalletAmrState {
  PageStatus get pageStatus => throw _privateConstructorUsedError;
  bool get processing => throw _privateConstructorUsedError;
  ErrorEntity? get errorEntity => throw _privateConstructorUsedError;
  Robotlocationtarget? get robotLocationStart =>
      throw _privateConstructorUsedError;

  @JsonKey(ignore: true)
  $OutpalletAmrStateCopyWith<OutpalletAmrState> get copyWith =>
      throw _privateConstructorUsedError;
}

/// @nodoc
abstract class $OutpalletAmrStateCopyWith<$Res> {
  factory $OutpalletAmrStateCopyWith(
          OutpalletAmrState value, $Res Function(OutpalletAmrState) then) =
      _$OutpalletAmrStateCopyWithImpl<$Res, OutpalletAmrState>;
  @useResult
  $Res call(
      {PageStatus pageStatus,
      bool processing,
      ErrorEntity? errorEntity,
      Robotlocationtarget? robotLocationStart});
}

/// @nodoc
class _$OutpalletAmrStateCopyWithImpl<$Res, $Val extends OutpalletAmrState>
    implements $OutpalletAmrStateCopyWith<$Res> {
  _$OutpalletAmrStateCopyWithImpl(this._value, this._then);

  // ignore: unused_field
  final $Val _value;
  // ignore: unused_field
  final $Res Function($Val) _then;

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pageStatus = null,
    Object? processing = null,
    Object? errorEntity = freezed,
    Object? robotLocationStart = freezed,
  }) {
    return _then(_value.copyWith(
      pageStatus: null == pageStatus
          ? _value.pageStatus
          : pageStatus // ignore: cast_nullable_to_non_nullable
              as PageStatus,
      processing: null == processing
          ? _value.processing
          : processing // ignore: cast_nullable_to_non_nullable
              as bool,
      errorEntity: freezed == errorEntity
          ? _value.errorEntity
          : errorEntity // ignore: cast_nullable_to_non_nullable
              as ErrorEntity?,
      robotLocationStart: freezed == robotLocationStart
          ? _value.robotLocationStart
          : robotLocationStart // ignore: cast_nullable_to_non_nullable
              as Robotlocationtarget?,
    ) as $Val);
  }
}

/// @nodoc
abstract class _$$OutpalletAmrStateImplCopyWith<$Res>
    implements $OutpalletAmrStateCopyWith<$Res> {
  factory _$$OutpalletAmrStateImplCopyWith(_$OutpalletAmrStateImpl value,
          $Res Function(_$OutpalletAmrStateImpl) then) =
      __$$OutpalletAmrStateImplCopyWithImpl<$Res>;
  @override
  @useResult
  $Res call(
      {PageStatus pageStatus,
      bool processing,
      ErrorEntity? errorEntity,
      Robotlocationtarget? robotLocationStart});
}

/// @nodoc
class __$$OutpalletAmrStateImplCopyWithImpl<$Res>
    extends _$OutpalletAmrStateCopyWithImpl<$Res, _$OutpalletAmrStateImpl>
    implements _$$OutpalletAmrStateImplCopyWith<$Res> {
  __$$OutpalletAmrStateImplCopyWithImpl(_$OutpalletAmrStateImpl _value,
      $Res Function(_$OutpalletAmrStateImpl) _then)
      : super(_value, _then);

  @pragma('vm:prefer-inline')
  @override
  $Res call({
    Object? pageStatus = null,
    Object? processing = null,
    Object? errorEntity = freezed,
    Object? robotLocationStart = freezed,
  }) {
    return _then(_$OutpalletAmrStateImpl(
      pageStatus: null == pageStatus
          ? _value.pageStatus
          : pageStatus // ignore: cast_nullable_to_non_nullable
              as PageStatus,
      processing: null == processing
          ? _value.processing
          : processing // ignore: cast_nullable_to_non_nullable
              as bool,
      errorEntity: freezed == errorEntity
          ? _value.errorEntity
          : errorEntity // ignore: cast_nullable_to_non_nullable
              as ErrorEntity?,
      robotLocationStart: freezed == robotLocationStart
          ? _value.robotLocationStart
          : robotLocationStart // ignore: cast_nullable_to_non_nullable
              as Robotlocationtarget?,
    ));
  }
}

/// @nodoc

class _$OutpalletAmrStateImpl implements _OutpalletAmrState {
  _$OutpalletAmrStateImpl(
      {this.pageStatus = PageStatus.initial,
      this.processing = false,
      this.errorEntity = null,
      this.robotLocationStart = null});

  @override
  @JsonKey()
  final PageStatus pageStatus;
  @override
  @JsonKey()
  final bool processing;
  @override
  @JsonKey()
  final ErrorEntity? errorEntity;
  @override
  @JsonKey()
  final Robotlocationtarget? robotLocationStart;

  @override
  String toString() {
    return 'OutpalletAmrState(pageStatus: $pageStatus, processing: $processing, errorEntity: $errorEntity, robotLocationStart: $robotLocationStart)';
  }

  @override
  bool operator ==(Object other) {
    return identical(this, other) ||
        (other.runtimeType == runtimeType &&
            other is _$OutpalletAmrStateImpl &&
            (identical(other.pageStatus, pageStatus) ||
                other.pageStatus == pageStatus) &&
            (identical(other.processing, processing) ||
                other.processing == processing) &&
            (identical(other.errorEntity, errorEntity) ||
                other.errorEntity == errorEntity) &&
            (identical(other.robotLocationStart, robotLocationStart) ||
                other.robotLocationStart == robotLocationStart));
  }

  @override
  int get hashCode => Object.hash(
      runtimeType, pageStatus, processing, errorEntity, robotLocationStart);

  @JsonKey(ignore: true)
  @override
  @pragma('vm:prefer-inline')
  _$$OutpalletAmrStateImplCopyWith<_$OutpalletAmrStateImpl> get copyWith =>
      __$$OutpalletAmrStateImplCopyWithImpl<_$OutpalletAmrStateImpl>(
          this, _$identity);
}

abstract class _OutpalletAmrState implements OutpalletAmrState {
  factory _OutpalletAmrState(
      {final PageStatus pageStatus,
      final bool processing,
      final ErrorEntity? errorEntity,
      final Robotlocationtarget? robotLocationStart}) = _$OutpalletAmrStateImpl;

  @override
  PageStatus get pageStatus;
  @override
  bool get processing;
  @override
  ErrorEntity? get errorEntity;
  @override
  Robotlocationtarget? get robotLocationStart;
  @override
  @JsonKey(ignore: true)
  _$$OutpalletAmrStateImplCopyWith<_$OutpalletAmrStateImpl> get copyWith =>
      throw _privateConstructorUsedError;
}
