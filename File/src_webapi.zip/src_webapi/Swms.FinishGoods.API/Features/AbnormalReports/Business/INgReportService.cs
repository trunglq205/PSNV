﻿using Swms.FinishGoods.API.Features.AbnormalReports.Api;

namespace Swms.FinishGoods.API.Features.AbnormalReports.Business;

public interface INgReportService
{
    Task<IReadOnlyList<NgReportSummaryResponse>> GetListAsync(
        string? status, string? ngType, DateTime? from, DateTime? to, string? keyword);
    Task<NgReportDetailResponse> GetAsync(long id);

    /// <summary>Loại lỗi cho danh sách thả xuống, nhãn theo ngôn ngữ người gọi.</summary>
    Task<IReadOnlyList<NgTypeResponse>> GetTypesAsync();

    /// <summary>Danh mục cho màn quản trị: cả loại đang tắt, thô 4 ngôn ngữ.</summary>
    /// <summary>
    /// Xuất danh sách phiếu ra Excel. Nhận ĐỦ CẢ 8 bộ lọc của màn danh sách để
    /// file xuất ra khớp với những gì người dùng đang xem.
    ///
    /// Màn danh sách lọc 4 tiêu chí cuối NGAY TẠI TRÌNH DUYỆT (nó tải danh sách
    /// không lọc trạng thái để đếm số trên từng tab). Nếu endpoint này chỉ nhận
    /// 4 tiêu chí mà server lọc thì file tải về sẽ chứa cả những dòng màn hình
    /// đang ẩn — sai âm thầm, người dùng không có cách nào biết.
    /// </summary>
    /// <param name="faRes">Hướng xử lý FA đề xuất; "pending" = FA chưa duyệt.</param>
    /// <param name="oqc">Kết luận OQC: pending | ok | ng | skipped.</param>
    /// <param name="finalRes">Hướng xử lý đã chốt.</param>
    Task<(byte[] Bytes, string FileName)> BuildListReportAsync(
        string? status, string? ngType, DateTime? from, DateTime? to, string? keyword,
        string? faRes = null, string? oqc = null, string? finalRes = null);

    Task<IReadOnlyList<NgTypeAdminResponse>> GetTypesForAdminAsync();

    /// <summary>Thêm hoặc sửa một loại lỗi.</summary>
    Task SaveTypeAsync(SaveNgTypeRequest request);

    /// <summary>Xoá mềm; chặn nếu còn phiếu đang dùng.</summary>
    Task DeleteTypeAsync(string code);

    /// <summary>Tra pallet lúc quét; ném NotFound nếu mã không có trong hệ thống.</summary>
    Task<NgPalletCheckResponse> CheckPalletAsync(string palletCode);

    Task<CreateNgReportResponse> CreateAsync(CreateNgReportRequest request);
    Task UpdateAsync(long id, UpdateNgReportRequest request);
    Task DeletePhotoAsync(long photoId);

    Task<long> AddPhotoAsync(long id, Stream content, string fileName, long length);
    Task<(Stream Content, string ContentType, string FileName)> GetPhotoAsync(long photoId, string size);

    /// <summary>Bước 2 sẽ gửi mail cho ai — tra trước khi Leader bấm duyệt.</summary>
    Task<MailPreviewResponse> GetMailPreviewAsync(long id);

    Task LeaderReviewAsync(long id, LeaderReviewRequest request);
    Task FaConfirmAsync(long id, FaConfirmRequest request);
    Task OqcConfirmAsync(long id, OqcConfirmRequest request);
    Task FinalizeAsync(long id, FinalizeRequest request);
}
