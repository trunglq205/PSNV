using System.ComponentModel.DataAnnotations;
using Swms.FinishGoods.API.Common.Models; // PagedQuery

namespace Swms.FinishGoods.Api.Features.Models.Api;

// ── RULE ─────────────────────────────────────────────────────────────────
/// <summary>
/// Quy tắc tầng rack + quy đổi giữa dạng lưu (chuỗi "2,3" ở cột suggest_rack_row)
/// và dạng phơi ra API (List&lt;int&gt; [2,3]).
///
/// Rack hiện có 4 tầng — đổi Max ở đây thì nhớ đổi luôn CK_models_suggest_rack_row
/// trong models_add_suggest_columns.sql.
///
/// Ở đây chỉ là hàm thuần, KHÔNG throw. Validate range + báo lỗi đa ngữ nằm ở ModelService.
/// </summary>
public static class RackRowRule
{
    public const int Min = 1;
    public const int Max = 4;

    /// <summary>Dạng DB -> API: "2,3" => [2, 3]. Rỗng/NULL => null.</summary>
    public static List<int>? Parse(string? raw)
    {
        if (string.IsNullOrWhiteSpace(raw)) return null;

        var rows = new List<int>();
        foreach (var part in raw.Split(',', StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries))
            if (int.TryParse(part, out var row))
                rows.Add(row);

        return rows.Count == 0 ? null : rows;
    }

    /// <summary>Dạng API -> DB: [3, 2, 3] => "2,3" (distinct + sắp tăng dần). Rỗng/NULL => null.</summary>
    public static string? ToStorage(IEnumerable<int>? rows)
    {
        if (rows is null) return null;

        var normalized = rows.Distinct().OrderBy(x => x).ToList();
        return normalized.Count == 0 ? null : string.Join(',', normalized);
    }
}

/// <summary>
/// Quy tắc mã xuất xứ (cột origin CHAR(2)): đúng 2 chữ cái, lưu dạng viết HOA — vd "VN", "JP".
/// Đổi quy tắc ở đây thì nhớ đổi luôn CK_models_origin trong models_add_origin_column.sql.
/// </summary>
public static class OriginRule
{
    public const int Length = 2;

    /// <summary>Rỗng/toàn khoảng trắng = hợp lệ (xoá xuất xứ). Cho phép khoảng trắng 2 đầu (dữ liệu import Excel).</summary>
    public const string Pattern = @"^\s*([A-Za-z]{2}\s*)?$";

    /// <summary>" vn " => "VN". Rỗng/NULL => null.</summary>
    public static string? Normalize(string? raw)
        => string.IsNullOrWhiteSpace(raw) ? null : raw.Trim().ToUpperInvariant();
}

/// <summary>
/// Cong thuc xep pallet — gia tri tinh ra, KHONG luu DB.
/// Tra null khi thieu du lieu dau vao (model chua cau hinh xep pallet).
/// </summary>
public static class StackingRule
{
    public const int MaxLayer = 100;
    public const int MaxStacking = 100;

    public static int? BoxPerLayer(int? stackingLength, int? stackingWidth)
        => stackingLength * stackingWidth;

    public static int? BoxPerPallet(int? layerCount, int? stackingLength, int? stackingWidth)
        => layerCount * stackingLength * stackingWidth;

    public static int? SetPerPallet(int? layerCount, int? stackingLength, int? stackingWidth, int standardPacking)
        => layerCount * stackingLength * stackingWidth * standardPacking;

    public static int? Multiply(int? count, int dimensionMm) => count * dimensionMm;
}

// ── QUERY ────────────────────────────────────────────────────────────────
public class ModelQuery : PagedQuery
{
    public string? GTIN { get; set; }
    public string? Code { get; set; }
    public int? CategoryCode { get; set; }
    public int? SuggestAreaId { get; set; }
    public string? Origin { get; set; }          // mã 2 chữ cái, vd "VN"
    public bool? IsActive { get; set; }
    public DateTime? CreatedFrom { get; set; }   // UTC
    public DateTime? CreatedTo { get; set; }     // UTC
}

// ── REQUEST (input) ──────────────────────────────────────────────────────
// SuggestRackRow nhận mảng số JSON: "suggestRackRow": [2, 3].
// Range [1..4] validate ở ModelService (DataAnnotations không áp Range lên List được).
public record CreateModelRequest(
    [Required, MaxLength(100)] string Code,
    [MaxLength(14)] string? GTIN,
    [RegularExpression(OriginRule.Pattern)] string? Origin,
    [Range(1, int.MaxValue)] int CategoryId,
    [Range(0, 100_000)] int Length,
    [Range(0, 100_000)] int Width,
    [Range(0, 100_000)] int Height,
    [Range(0, 100_000)] int StandardPacking,
    [Range(1, StackingRule.MaxLayer)] int? LayerLimit,
    [Range(1, StackingRule.MaxLayer)] int? LayerCount,
    [Range(1, StackingRule.MaxStacking)] int? StackingLength,
    [Range(1, StackingRule.MaxStacking)] int? StackingWidth,
    [Range(1, int.MaxValue)] int? SuggestAreaId,
                               List<int>? SuggestRackRow,
    bool IsActive);

public record UpdateModelRequest(
    [MaxLength(14)] string? GTIN,
    [RegularExpression(OriginRule.Pattern)] string? Origin,
    [Range(0, 100_000)] int Length,
    [Range(0, 100_000)] int Width,
    [Range(0, 100_000)] int Height,
    [Range(0, 100_000)] int StandardPacking,
    [Range(1, StackingRule.MaxLayer)] int? LayerLimit,
    [Range(1, StackingRule.MaxLayer)] int? LayerCount,
    [Range(1, StackingRule.MaxStacking)] int? StackingLength,
    [Range(1, StackingRule.MaxStacking)] int? StackingWidth,
    [Range(1, int.MaxValue)] int? SuggestAreaId,
                               List<int>? SuggestRackRow,
    bool IsActive);

// ── PATCH (partial — chỉ 2 cột gợi ý lưu kho) ────────────────────────────
/// <summary>
/// Body cho PATCH /api/models/{id}/suggestion.
/// CHỈ ghi 2 cột suggest_area + suggest_rack_row — không đụng GTIN, kích thước,
/// standard_packing, quy cách xếp pallet hay is_active.
///
/// Ngữ nghĩa null: null = XOÁ gợi ý (ghi NULL xuống DB), KHÔNG phải "bỏ qua field".
/// Client (PDA/Blazor) luôn gửi đủ cả 2 field theo trạng thái hiện tại của form.
/// </summary>
public record PatchModelSuggestionRequest(
    [Range(1, int.MaxValue)] int? SuggestAreaId,
                             List<int>? SuggestRackRow);

// ── RESPONSE (output) ────────────────────────────────────────────────────
/// <summary>
/// StandardPallet giữ lại trong response (= BoxPerPallet, tính ra) để client cũ
/// (PDA, báo cáo) đang đọc field này không bị vỡ. Không còn nhận ở request.
/// Cargo* tính bằng mm như Length/Width/Height.
/// </summary>
public record ModelResponse(
    int Id, string Code, string? GTIN, string? Origin, int CategoryId, int CategoryCode, string CategoryName,
    int Length, int Width, int Height, int StandardPacking,
    int? LayerLimit, int? LayerCount, int? StackingLength, int? StackingWidth,
    int? BoxPerLayer, int? BoxPerPallet, int? SetPerPallet, int? StandardPallet,
    int? CargoLength, int? CargoWidth, int? CargoHeight,
    int? SuggestAreaId, string? SuggestAreaCode, string? SuggestAreaName, List<int>? SuggestRackRow,
    bool IsActive, DateTime CreatedAt)
{
    public static ModelResponse From(ModelEntity m)
    {
        var boxPerPallet = StackingRule.BoxPerPallet(m.LayerCount, m.StackingLength, m.StackingWidth);

        return new(m.Id, m.Code, m.GTIN, m.Origin, m.CategoryId, m.CategoryCode, m.CategoryName,
               m.Length, m.Width, m.Height, m.StandardPacking,
               m.LayerLimit, m.LayerCount, m.StackingLength, m.StackingWidth,
               StackingRule.BoxPerLayer(m.StackingLength, m.StackingWidth),
               boxPerPallet,
               StackingRule.SetPerPallet(m.LayerCount, m.StackingLength, m.StackingWidth, m.StandardPacking),
               boxPerPallet,
               StackingRule.Multiply(m.StackingLength, m.Length),
               StackingRule.Multiply(m.StackingWidth, m.Width),
               StackingRule.Multiply(m.LayerCount, m.Height),
               m.SuggestAreaId, m.SuggestAreaCode, m.SuggestAreaName, RackRowRule.Parse(m.SuggestRackRow),
               m.IsActive, m.CreatedAt);
    }
}

public record CategoryOptionResponse(int Id, string Code, string Name)
{
    public static CategoryOptionResponse From(CategoryOption c) => new(c.Id, c.Code, c.Name);
}

/// <summary>Bản ghi trùng khi bulk create — đính kèm trong exception.</summary>
public sealed record DuplicateModelInfo(int? Id, string Code, string Reason);

// DTO cho import "upsert": mã đã tồn tại -> update; mã mới -> tạo mới.
// Code là khoá đối chiếu (không đổi khi update).
//
// Mọi field còn lại đều nullable — null / rỗng nghĩa là "ô không điền trong file":
//   - Mã đã tồn tại: CHỈ ghi các field có giá trị; field không điền GIỮ NGUYÊN giá trị trong DB.
//     (Hệ quả: import không xoá trắng 1 ô được — muốn xoá thì sửa ở form.)
//   - Mã mới: CategoryId, Length, Width, Height, StandardPacking là bắt buộc; thiếu thì dòng bị bỏ qua
//     và trả về trong BulkUpsertResult.SkippedCodes. IsActive không điền = true.
public record UpsertModelRequest
{
    [Required, MaxLength(30)]
    public string Code { get; init; } = "";

    public string? GTIN { get; init; }

    /// <summary>Mã xuất xứ 2 chữ cái, vd "VN".</summary>
    [RegularExpression(OriginRule.Pattern)]
    public string? Origin { get; init; }

    // Mang giá trị category_code (FE resolve category_code -> CategoryId trước khi gửi).
    public int? CategoryId { get; init; }

    public int? Length { get; init; }
    public int? Width { get; init; }
    public int? Height { get; init; }
    public int? StandardPacking { get; init; }

    [Range(1, StackingRule.MaxLayer)] public int? LayerLimit { get; init; }
    [Range(1, StackingRule.MaxLayer)] public int? LayerCount { get; init; }
    [Range(1, StackingRule.MaxStacking)] public int? StackingLength { get; init; }
    [Range(1, StackingRule.MaxStacking)] public int? StackingWidth { get; init; }

    /// <summary>FK -> master.warehouse_areas(id).</summary>
    [Range(1, int.MaxValue)]
    public int? SuggestAreaId { get; init; }

    /// <summary>Tầng rack, vd [2, 3]. Null/rỗng = không điền.</summary>
    public List<int>? SuggestRackRow { get; init; }

    public bool? IsActive { get; init; }
}

/// <summary>
/// Kết quả tổng kết trả về FE để hiển thị toast.
/// Skipped / SkippedCodes: dòng không ghi gì — mã mới nhưng thiếu field bắt buộc để tạo,
/// hoặc mã đã có mà không điền ô nào.
/// </summary>
public record BulkUpsertResult(int Created, int Updated, int Skipped, IReadOnlyList<string> SkippedCodes)
{
    public static BulkUpsertResult Empty { get; } = new(0, 0, 0, Array.Empty<string>());
}