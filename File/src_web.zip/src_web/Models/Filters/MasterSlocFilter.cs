﻿namespace SWMS_WebTool.Models.Filters
{
    public class MasterSlocFilter : BaseFilter
    {
        public string Category { get; set; }
        public string Plant { get; set; }
        public string Type { get; set; }
        public string Sloc { get; set; }
    }
}
