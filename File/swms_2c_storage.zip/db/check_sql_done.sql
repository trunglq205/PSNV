/* Script nào đã chạy rồi, script nào còn thiếu. CHỈ ĐỌC, không ghi gì. */
SET NOCOUNT ON;

SELECT N'return_back_merge_schema.sql'  AS script,
       CASE WHEN OBJECT_ID(N'wms.return_back_deliveries') IS NOT NULL
            THEN N'DA CHAY' ELSE N'>>> CAN CHAY' END AS trang_thai
UNION ALL
SELECT N'return_back_phase2_schema.sql',
       CASE WHEN OBJECT_ID(N'wms.return_back_lines') IS NOT NULL
             AND EXISTS (SELECT 1 FROM sys.columns
                         WHERE object_id = OBJECT_ID(N'wms.return_instructions')
                           AND name = N'back_scs_approved_by')
            THEN N'DA CHAY' ELSE N'>>> CAN CHAY' END
UNION ALL
SELECT N'return_fa_pallet_schema.sql',
       CASE WHEN OBJECT_ID(N'wms.return_serial_mismatches') IS NOT NULL
            THEN N'DA CHAY' ELSE N'>>> CAN CHAY' END
UNION ALL
SELECT N'return_rework_ng_migrate.sql',
       CASE WHEN NOT EXISTS (SELECT 1 FROM sys.columns
                             WHERE object_id = OBJECT_ID(N'wms.pallets')
                               AND name = N'disposition')
            THEN N'CHUA CHAY duoc — thieu cot disposition'
            WHEN EXISTS (SELECT 1 FROM wms.pallets
                         WHERE is_deleted = 0 AND disposition IS NOT NULL
                           AND inspection_status <> N'ng')
            THEN N'>>> CAN CHAY'
            ELSE N'DA CHAY (hoac chua co pallet RW/RB nao)' END;
