﻿using Swms.FinishGoods.API.Features.Boxes.Business;

namespace Swms.FinishGoods.API.Features.Boxes.Api
{
    /// <summary>
    /// Chi tiết box gộp cho màn Box Detail (1 lần gọi):
    /// thông tin box + model + serial + lot chứa + vị trí (theo lot).
    /// </summary>
    public record BoxDetailResponse(
        long Id,
        string BoxNo,
        // model đại diện (dòng đầu) + tổng qty + số serial
        string? PrimaryModel,
        int TotalQty,
        int SerialCount,
        string? CustomerPo,
        string? PsnvPo,
        DateTime? ProductionDate,
        // trạng thái OQC
        string? OqcStatus,
        // lot chứa (Pallet ID)
        long LotId,
        string LotNo,

        // string? chứ KHÔNG phải string (sửa 11/11): nguồn của nó là
        // `wms.boxes.raw_payload` vốn NULL được, và thùng của pallet hàng return
        // không có payload — serial do WH quét tay, không có tem QR gốc nào.
        //
        // Khai non-null ở đây không ngăn được null chui qua (nullable reference
        // type chỉ là chú thích lúc biên dịch), nó chỉ làm client tin nhầm rồi
        // khai non-null theo — PDA đã khai `String payload` và vỡ parse CẢ
        // response khi gặp thùng hàng return, màn hình báo "không tải được chi
        // tiết pallet" dù API trả 200 đầy đủ.
        string? Payload,
        // vị trí — ăn theo lot
        long? LocatorId,
        string? LocatorCode,
        string? AreaCode,
        string? AreaName,
        // danh sách serial
        IReadOnlyList<BoxSerialResponse> Serials)
    {
        public static BoxDetailResponse From(BoxDetailEntity b)
        {
            var totalQty = b.Lines.Sum(x => x.Qty);
            var serials = b.Lines
                .Where(x => !string.IsNullOrWhiteSpace(x.SerialNo))
                .Select(BoxSerialResponse.From)
                .ToList();

            return new BoxDetailResponse(
                b.Id,
                b.BoxNo,
                b.Lines.FirstOrDefault()?.Model,
                totalQty,
                serials.Count,
                b.CustomerPo,
                b.PsnvPo,
                b.ProductionDate,
                b.OqcStatus,
                b.LotId,
                b.LotNo,
                b.Payload,
                b.LocatorId,
                b.LocatorCode,
                b.AreaCode,
                b.AreaName,
                serials);
        }
    }

    /// <summary>Một serial trong box.</summary>
    public record BoxSerialResponse(
        long Id,
        string SerialNo,
        string Model)
    {
        public static BoxSerialResponse From(BoxLineEntity l) =>
            new(l.Id, l.SerialNo ?? "", l.Model);
    }

    /// <summary>
    /// PATCH box: cập nhật PO. Client luôn gửi đủ field (includeIfNull: true)
    /// — null/rỗng = xoá giá trị.
    /// </summary>
    public record BoxPatchRequest(
        string? CustomerPo,
        string? PsnvPo);
}