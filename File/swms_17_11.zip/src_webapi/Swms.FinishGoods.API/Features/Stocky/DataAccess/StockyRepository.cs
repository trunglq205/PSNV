﻿using Dapper;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.Stocky.DataAccess;

public class StockyRepository : IStockyRepository
{
    private readonly IDbConnectionFactory _factory;
    public StockyRepository(IDbConnectionFactory factory) => _factory = factory;

    /// <summary>
    /// Xe + hàng trên xe. Phần hàng lấy bằng OUTER APPLY sang wms.pallets theo
    /// stocky_code chứ KHÔNG lưu trong bảng xe — có một nguồn sự thật duy nhất,
    /// pallet đổi ô là danh sách xe đổi theo, không phải đồng bộ gì.
    ///
    /// Vì sao OUTER APPLY ... TOP 1 chứ không JOIN thẳng: một mã xe có thể ứng
    /// với nhiều dòng pallet (xe dùng lại nhiều lượt, dòng cũ vẫn chưa xoá),
    /// JOIN thẳng sẽ nhân dòng xe lên. Lấy dòng mới nhất theo id — đúng cách
    /// StorageMapRepository đang làm cho "pallet đang ở ô này".
    /// </summary>
    private const string SelectSql = """
        SELECT  c.id          AS [Id],
                c.code        AS [Code],
                c.name        AS [Name],
                c.vendor      AS [Vendor],
                c.status      AS [Status],
                c.received_at AS [ReceivedAt],
                c.received_by AS [ReceivedBy],
                c.returned_at AS [ReturnedAt],
                c.returned_by AS [ReturnedBy],
                c.note        AS [Note],

                -- VỊ TRÍ HIỆU LỰC: ô của pallet đang trên xe, xe rỗng thì ô đậu xe.
                COALESCE(p.LocatorId,   c.locator_id)    AS [LocatorId],
                COALESCE(p.LocatorCode, cl.locator_code) AS [LocatorCode],
                COALESCE(p.AreaCode,    cwa.area_code)   AS [AreaCode],

                -- Ô RIÊNG của xe, KHÔNG COALESCE sang pallet. Đây là thứ luồng
                -- xuất FA ghi vào, và là thứ duy nhất trả lời được "xe đang ở
                -- FA hay ở kho" khi trên xe còn hàng.
                -- ĐỌC TỪ cl_any (KHÔNG lọc is_deleted), không phải cl.
                -- Ô FA bị xoá mềm rồi tạo lại (script stocky_fa_locator.sql có
                -- hẳn nhánh hồi sinh) sẽ làm cl.locator_code = NULL, khi đó
                -- IsAtFa hoá false và xe đang ở FA trông như xe trong kho:
                -- nhận về thì 409, trả vendor thì LỌT — mất xe. Mã ô vẫn đúng
                -- dù dòng ô đã xoá mềm, nên đọc không lọc.
                c.locator_id        AS [CartLocatorId],
                cl_any.locator_code AS [CartLocatorCode],

                CAST(CASE WHEN p.Id IS NOT NULL THEN 1 ELSE 0 END AS bit) AS [HasGoods],
                p.PalletCode  AS [PalletCode],
                p.Model       AS [Model],
                ISNULL(agg.LotCount, 0) AS [LotCount],
                ISNULL(agg.Qty, 0)      AS [Qty],
                p.SiNo        AS [SiNo]
        FROM wms.stocky_carts c

        -- Ô ĐẬU XE của chính xe (dùng khi xe rỗng).
        LEFT JOIN master.locators        cl  ON cl.id  = c.locator_id AND cl.is_deleted = 0
        LEFT JOIN master.warehouse_areas cwa ON cwa.id = cl.area_id   AND cwa.is_deleted = 0

        -- Cùng ô đó nhưng KHÔNG lọc is_deleted — chỉ để lấy mã ô cho IsAtFa.
        -- Vị trí HIỂN THỊ vẫn đi qua cl: ô đã xoá thì coi như chưa gán.
        LEFT JOIN master.locators        cl_any ON cl_any.id = c.locator_id

        -- Pallet MỚI NHẤT trên xe, KÈM ô và khu của chính nó.
        --
        -- Tra ô/khu NGAY TRONG apply này, không LEFT JOIN ở ngoài: join đứng sau
        -- một APPLY rồi tham chiếu alias của APPLY đó là chỗ dễ sai, mà cũng
        -- không cần — pallet nào thì ô của pallet đó, gom lại một chỗ dễ đọc hơn.
        OUTER APPLY (
            SELECT TOP 1
                   x.id             AS Id,
                   x.pallet_id      AS PalletCode,
                   -- Xe Stocky chở pallet ở bất kỳ detail_level. Pallet
                   -- serial / box_line KHÔNG ghi cột pallets.model (model nằm ở
                   -- box_lines) nên đọc thẳng x.model làm danh sách xe trống cột
                   -- Model với hai loại đó. Cùng quy ước với LocationInfoSql.
                   COALESCE(
                       (SELECT STRING_AGG(z.model, ', ')
                        FROM (SELECT DISTINCT bl.model
                              FROM wms.boxes bx
                              JOIN wms.box_lines bl ON bl.box_id = bx.id AND bl.is_deleted = 0
                              WHERE bx.lot_id = x.id AND bx.is_deleted = 0) z),
                       x.model)     AS Model,
                   x.locator_id     AS LocatorId,
                   x.si_no          AS SiNo,
                   pl.locator_code  AS LocatorCode,
                   pwa.area_code    AS AreaCode
            FROM wms.pallets x
            LEFT JOIN master.locators        pl  ON pl.id  = x.locator_id AND pl.is_deleted = 0
            LEFT JOIN master.warehouse_areas pwa ON pwa.id = pl.area_id   AND pwa.is_deleted = 0
            WHERE x.stocky_code = c.code AND x.is_deleted = 0
            ORDER BY x.id DESC
        ) p

        -- Gộp TẤT CẢ pallet của xe: số lot và tổng pcs tính trên cả xe, không
        -- phải trên riêng dòng mới nhất.
        --
        -- ⚠ Số thùng gom trong OUTER APPLY `bx` rồi mới COALESCE, TUYỆT ĐỐI
        -- không viết subquery vào trong SUM(): T-SQL không cho đặt subquery bên
        -- trong hàm tổng hợp, SQL Server ném lỗi 130 "Cannot perform an
        -- aggregate function on an expression containing an aggregate or a
        -- subquery". Đây đúng cách màn Tồn kho đang làm cho cùng con số này.
        --
        -- Công thức pcs: mức box_count thì box_count x standard_packing, còn
        -- lại thì cộng qty của box_lines.
        OUTER APPLY (
            SELECT COUNT(*) AS LotCount,
                   SUM(CASE
                         WHEN y.detail_level = 'box_count'
                           THEN COALESCE(y.box_count, 0) * COALESCE(y.standard_packing, 0)
                         ELSE COALESCE(bx.SumQty, 0)
                       END) AS Qty
            FROM wms.pallets y
            OUTER APPLY (
                SELECT SUM(bl.qty) AS SumQty
                FROM   wms.boxes b
                JOIN   wms.box_lines bl ON bl.box_id = b.id AND bl.is_deleted = 0
                WHERE  b.lot_id = y.id AND b.is_deleted = 0
            ) bx
            WHERE y.stocky_code = c.code AND y.is_deleted = 0
        ) agg

        WHERE c.is_deleted = 0
        """;
    public async Task<IReadOnlyList<StockyCart>> GetListAsync(string? status, bool? hasGoods, string? keyword)
    {
        // hasGoods lọc trên biểu thức dẫn xuất nên không đặt được ở WHERE của
        // câu gốc (SQL Server không cho dùng alias của SELECT trong WHERE).
        // Lọc bằng chính điều kiện tồn tại pallet — rẻ hơn bọc thêm subquery.
        var sql = SelectSql + """

              AND (@status  IS NULL OR c.status = @status)
              AND (@kw      IS NULL OR c.code LIKE @kw OR c.name LIKE @kw
                                    OR p.PalletCode LIKE @kw OR p.Model LIKE @kw)
              AND (@hasGoods IS NULL
                   OR (@hasGoods = 1 AND p.Id IS NOT NULL)
                   OR (@hasGoods = 0 AND p.Id IS NULL))
            ORDER BY c.code;
            """;

        using var conn = _factory.Create();
        return (await conn.QueryAsync<StockyCart>(sql, new
        {
            status,
            hasGoods,
            kw = string.IsNullOrWhiteSpace(keyword) ? null : $"%{keyword.Trim()}%"
        })).ToList();
    }

    public async Task<StockyCart?> GetByCodeAsync(string code)
    {
        var sql = SelectSql + "\n  AND c.code = @code;";
        using var conn = _factory.Create();
        return await conn.QuerySingleOrDefaultAsync<StockyCart>(sql, new { code });
    }

    public async Task<long?> FindLocatorIdAsync(string locatorCode)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<long?>("""
            SELECT TOP 1 id FROM master.locators
            WHERE locator_code = @locatorCode AND is_deleted = 0;
            """, new { locatorCode });
    }

    public async Task<IReadOnlyList<long>> GetLotIdsOnCartAsync(string code)
    {
        using var conn = _factory.Create();

        // Không lọc theo locator_id: xe có thể đang chở pallet CHƯA xếp ô nào
        // (vừa quét tạo pallet, đặt luôn lên xe). Đẩy xe thì con đó cũng phải
        // theo xe vào ô mới.
        var rows = await conn.QueryAsync<long>("""
            SELECT id
            FROM   wms.pallets
            WHERE  stocky_code = @code AND is_deleted = 0
            ORDER BY id;
            """, new { code });

        return rows.AsList();
    }

    public async Task<int> PlaceAsync(string code, long locatorId)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteAsync("""
            UPDATE wms.stocky_carts
            SET    locator_id = @locatorId
            WHERE  code = @code
              AND  is_deleted = 0
              AND  status = N'in_warehouse';
            """, new { code, locatorId });
    }

    /// <summary>
    /// UPDATE trước, INSERT khi @@ROWCOUNT = 0 — đúng khuôn mẫu upsert của dự
    /// án. Mã đã xoá mềm hoặc đã trả về vendor thì được HỒI SINH chứ không chèn
    /// dòng thứ hai: index ux_stocky_carts_code chỉ chặn trùng trong số xe
    /// chưa xoá, nên chèn thêm sẽ lọt và thành hai dòng cùng mã.
    ///
    /// Mỗi mã một câu lệnh trong CÙNG MỘT transaction: quét 20 xe rồi chốt, nếu
    /// xe thứ 15 lỗi thì không để 14 xe đã vào kho còn 6 xe thì không.
    /// </summary>
    public async Task<int> ReceiveAsync(
        IReadOnlyList<string> codes, long? parkLocatorId, long? faLocatorId, string? user)
    {
        // Trong SET của UPDATE, mọi tham chiếu cột ở VẾ PHẢI đọc giá trị CŨ của
        // dòng, nên CASE dưới đây xét đúng trạng thái/ô trước khi ghi đè.
        const string sql = """
            UPDATE wms.stocky_carts
            SET    status      = N'in_warehouse',
                   -- Kéo xe về bãi đậu trong 3 trường hợp, ngoài ra giữ nguyên
                   -- ô cũ (xe đang có hàng nằm đâu thì để yên đó):
                   --   1. xe chưa từng có ô
                   --   2. xe vừa từ vendor quay lại (status cũ <> in_warehouse)
                   --   3. xe ĐANG Ở FA — đây chính là thao tác "nhận về từ FA".
                   --      Thiếu nhánh này thì xe về kho rồi mà hệ thống vẫn ghi
                   --      đang ở FA, vì ISNULL cũ chỉ điền khi ô còn trống.
                   locator_id  = CASE
                                   WHEN locator_id IS NULL              THEN @parkLocatorId
                                   WHEN status <> N'in_warehouse'       THEN @parkLocatorId
                                   WHEN @faLocatorId IS NOT NULL
                                        AND locator_id = @faLocatorId   THEN @parkLocatorId
                                   ELSE locator_id
                                 END,
                   -- received_at = LÚC XE VÀO HỆ THỐNG, không phải lúc đổi vị
                   -- trí. Xe từ FA về vẫn đang là in_warehouse nên giữ mốc cũ;
                   -- ghi đè sẽ làm mất chính con số mà cả tính năng này sinh ra
                   -- để theo dõi. Chỉ xe thực sự (tái) nhập mới lấy mốc mới.
                   received_at = CASE WHEN status = N'in_warehouse'
                                      THEN ISNULL(received_at, SYSDATETIME())
                                      ELSE SYSDATETIME() END,
                   received_by = CASE WHEN status = N'in_warehouse'
                                      THEN ISNULL(received_by, @user)
                                      ELSE @user END,
                   returned_at = NULL,
                   returned_by = NULL,
                   is_deleted  = 0,
                   updated_at  = SYSDATETIME(),
                   updated_by  = @user
            WHERE  code = @code;

            IF @@ROWCOUNT = 0
                INSERT INTO wms.stocky_carts
                    (code, status, locator_id, received_at, received_by,
                     is_deleted, created_at, created_by)
                VALUES
                    (@code, N'in_warehouse', @parkLocatorId, SYSDATETIME(), @user,
                     0, SYSDATETIME(), @user);
            """;

        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var n = 0;
            foreach (var code in codes)
                n += await conn.ExecuteAsync(sql, new { code, parkLocatorId, faLocatorId, user }, tx);
            tx.Commit();
            return n;
        }
        catch { tx.Rollback(); throw; }
    }

    /// <summary>
    /// Đẩy xe sang FA. CHỈ đổi ô — <c>status</c> giữ nguyên
    /// <c>in_warehouse</c>, vì xe vẫn thuộc hệ thống và vẫn phải nằm trong danh
    /// sách theo dõi. Đây là điểm khác cốt lõi so với
    /// <see cref="ReturnAsync"/> (trả vendor, xe rời hệ thống).
    ///
    /// Không ghi được vào <c>wms.stock_events</c>: CHECK của bảng đó buộc mỗi
    /// dòng phải có chủ thể pallet hoặc box, mà đây là sự kiện của XE. Dấu vết
    /// còn lại là <c>updated_at</c> / <c>updated_by</c> trên chính dòng xe.
    /// </summary>
    public async Task<int> ExportToFaAsync(IReadOnlyList<string> codes, long faLocatorId, string? user)
    {
        // MỌI điều kiện nằm trong WHERE, không chỉ điều kiện trạng thái.
        // Kiểm ở service rồi mới ghi là check-then-act trên hai connection khác
        // nhau: giữa hai bước đó người khác có thể trả xe về vendor HOẶC xếp
        // pallet lên xe. Xe có hàng mà đẩy sang FA thì pallet vẫn ghi ô trong
        // kho dù hàng đã rời kho — sai tồn kho một cách âm thầm.
        const string sql = """
            UPDATE wms.stocky_carts
            SET    locator_id = @faLocatorId,
                   updated_at = SYSDATETIME(),
                   updated_by = @user
            WHERE  code = @code
              AND  is_deleted = 0
              AND  status = N'in_warehouse'
              AND  (locator_id IS NULL OR locator_id <> @faLocatorId)
              AND  NOT EXISTS (SELECT 1 FROM wms.pallets p
                               WHERE p.stocky_code = @code AND p.is_deleted = 0);
            """;

        return await RunBatchAsync(sql, codes, c => new { code = c, faLocatorId, user });
    }

    public async Task<int> ReturnAsync(IReadOnlyList<string> codes, long? faLocatorId, string? user)
    {
        // MỌI điều kiện nằm trong WHERE chứ không kiểm trước rồi mới ghi: giữa
        // hai bước đó người khác có thể đã trả xe, đẩy xe sang FA, hoặc xếp
        // pallet lên xe.
        //
        // Điều kiện ô FA là điều kiện MỚI và dễ bỏ sót nhất: vendor nhận xe tại
        // kho. Thiếu nó thì hai thao tác "xuất FA" và "trả vendor" chạy song
        // song sẽ để lại dòng status = 'returned' nhưng locator_id = ô FA —
        // xe rơi khỏi mọi danh sách trong khi vẫn đang nằm ở FA.
        const string sql = """
            UPDATE wms.stocky_carts
            SET    status      = N'returned',
                   returned_at = SYSDATETIME(),
                   returned_by = @user,
                   updated_at  = SYSDATETIME(),
                   updated_by  = @user
            WHERE  code = @code
              AND  is_deleted = 0
              AND  status = N'in_warehouse'
              AND  (@faLocatorId IS NULL OR locator_id IS NULL
                    OR locator_id <> @faLocatorId)
              AND  NOT EXISTS (SELECT 1 FROM wms.pallets p
                               WHERE p.stocky_code = @code AND p.is_deleted = 0);
            """;

        return await RunBatchAsync(sql, codes, c => new { code = c, faLocatorId, user });
    }

    /// <summary>
    /// Chạy một câu UPDATE cho từng mã trong CÙNG MỘT transaction và đòi
    /// <b>mọi</b> mã đều khớp đúng 1 dòng.
    ///
    /// Vì sao phải đòi đủ: các câu UPDATE ở trên tự kiểm điều kiện trong WHERE,
    /// nên một mã không còn hợp lệ chỉ đơn giản là khớp 0 dòng. Nếu cứ commit
    /// rồi trả về số nhỏ hơn, PDA vẫn hiện toast THÀNH CÔNG ("đã xuất 0 xe") và
    /// người vận hành tưởng đã xong. Lệch là ném để service đổi thành 409, và
    /// cả lô cùng rollback — quét 20 xe thì hoặc cả 20 đi, hoặc không xe nào.
    /// </summary>
    /// <exception cref="StockyConcurrencyException">
    /// Khi số dòng thực sự đổi khác số mã gửi lên.
    /// </exception>
    private async Task<int> RunBatchAsync(
        string sql, IReadOnlyList<string> codes, Func<string, object> args)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var n = 0;
            foreach (var code in codes)
                n += await conn.ExecuteAsync(sql, args(code), tx);

            if (n != codes.Count)
                throw new StockyConcurrencyException(n, codes.Count);

            tx.Commit();
            return n;
        }
        catch { tx.Rollback(); throw; }
    }
}

/// <summary>
/// Giữa lúc kiểm và lúc ghi, trạng thái xe đã đổi ở nơi khác nên không phải mã
/// nào cũng ghi được. Lớp DataAccess không dịch được thông báo (không có
/// localizer), nên ném kiểu riêng rồi để service đổi sang
/// <c>ConflictException</c> kèm câu đã dịch.
/// </summary>
public sealed class StockyConcurrencyException : Exception
{
    public int Applied { get; }
    public int Requested { get; }

    public StockyConcurrencyException(int applied, int requested)
        : base($"Chi ghi duoc {applied}/{requested} xe Stocky.")
    {
        Applied = applied;
        Requested = requested;
    }
}
