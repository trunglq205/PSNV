﻿using System.Text.Json;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Authorization.Policy;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Resource;

namespace Swms.FinishGoods.Api.Features.Roles.Authorization;

/// <summary>
/// Tùy biến response khi authorization THẤT BẠI, để 403 (và 401) trả JSON
/// đúng format chung của hệ thống: { status, title, details, traceId }.
///
/// Đây là chỗ CHÍNH THỐNG của ASP.NET để can thiệp kết quả authorization —
/// KHÔNG ném exception trong AuthorizationHandler (sẽ bị pipeline nuốt).
///
/// Đăng ký: services.AddSingleton&lt;IAuthorizationMiddlewareResultHandler, PermissionAuthorizationResultHandler&gt;();
/// </summary>
public sealed class PermissionAuthorizationResultHandler
    : IAuthorizationMiddlewareResultHandler
{
    // Fallback nếu authorization mặc định cần xử lý phần khác
    private readonly AuthorizationMiddlewareResultHandler _default = new();
    private readonly IStringLocalizer<SharedResource> _localizer;

    public PermissionAuthorizationResultHandler(IStringLocalizer<SharedResource> localizer)
        => _localizer = localizer;

    public async Task HandleAsync(
        RequestDelegate next,
        HttpContext context,
        AuthorizationPolicy policy,
        PolicyAuthorizationResult authorizeResult)
    {
        if (authorizeResult.Forbidden)
        {
            await WriteJsonAsync(context, StatusCodes.Status403Forbidden,
                _localizer["Authz.Forbidden"]);   // "Bạn không có quyền thực hiện thao tác này."
            return;
        }

        if (authorizeResult.Challenged)
        {
            await WriteJsonAsync(context, StatusCodes.Status401Unauthorized,
                _localizer["Authz.Unauthorized"]); // "Bạn cần đăng nhập để tiếp tục."
            return;
        }

        // Các trường hợp còn lại (Succeeded...) → xử lý mặc định
        await _default.HandleAsync(next, context, policy, authorizeResult);
    }

    private static async Task WriteJsonAsync(HttpContext context, int status, string title)
    {
        // Khớp đúng format ExceptionHandlingMiddleware: { status, title, details, traceId }
        context.Response.StatusCode = status;
        context.Response.ContentType = "application/json";
        var payload = JsonSerializer.Serialize(new
        {
            status,
            title,
            details = (object?)null,
            traceId = context.TraceIdentifier
        });
        await context.Response.WriteAsync(payload);
    }
}