import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/material.dart';
import 'package:swms_finish_goods/core/resources/app_dimens.dart';
import 'package:swms_finish_goods/core/resources/app_text_styles.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/core/widgets/common/app_card.dart';
import 'package:swms_finish_goods/features/box_detail/domain/entities/box_detail_entities.dart';

/// Danh sách hành động cho box.
class BoxActionList extends StatelessWidget {
  final BoxDetail box;
  final VoidCallback? onViewPallet;
  final VoidCallback? onReprint;
  final VoidCallback? onReportNg;

  const BoxActionList({
    super.key,
    required this.box,
    this.onViewPallet,
    this.onReprint,
    this.onReportNg,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.only(left: AppDimens.xs, bottom: AppDimens.xs),
          child: Text(
            'box_detail.actions'.tr(),
            style: AppTextStyles.label.copyWith(color: swms.text3),
          ),
        ),
        _ActionRow(
          icon: Icons.inventory_2_outlined,
          iconColor: swms.primary,
          iconBg: swms.primaryTint,
          title: 'box_detail.act_view_pallet'.tr(),
          subtitle: 'box_detail.act_view_pallet_sub'.tr(args: [box.lotNo]),
          onTap: onViewPallet,
        ),
        _ActionRow(
          icon: Icons.print_outlined,
          iconColor: swms.text2,
          iconBg: swms.card2,
          title: 'box_detail.act_reprint'.tr(),
          subtitle: 'box_detail.act_reprint_sub'.tr(args: [box.boxNo]),
          onTap: onReprint,
        ),
        _ActionRow(
          icon: Icons.warning_amber_rounded,
          iconColor: swms.danger,
          iconBg: swms.dangerBg,
          title: 'box_detail.act_report_ng'.tr(),
          subtitle: 'box_detail.act_report_ng_sub'.tr(),
          onTap: onReportNg,
        ),
      ],
    );
  }
}

class _ActionRow extends StatelessWidget {
  final IconData icon;
  final Color iconColor;
  final Color iconBg;
  final String title;
  final String subtitle;
  final VoidCallback? onTap;

  const _ActionRow({
    required this.icon,
    required this.iconColor,
    required this.iconBg,
    required this.title,
    required this.subtitle,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final swms = context.swms;
    return Padding(
      padding: const EdgeInsets.only(bottom: AppDimens.xs),
      child: AppCard(
        onTap: onTap,
        child: Row(
          children: [
            Container(
              width: 40,
              height: 40,
              decoration: BoxDecoration(
                color: iconBg,
                borderRadius: BorderRadius.circular(AppDimens.rBtn),
              ),
              child: Icon(icon, color: iconColor, size: 20),
            ),
            const SizedBox(width: AppDimens.sm),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    title,
                    style: AppTextStyles.bodyStrong.copyWith(color: swms.text1),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    subtitle,
                    style: AppTextStyles.caption.copyWith(color: swms.text3),
                    overflow: TextOverflow.ellipsis,
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, color: swms.text4, size: 20),
          ],
        ),
      ),
    );
  }
}
