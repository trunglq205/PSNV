using System.Globalization;
using System.Text;
using System.Text.Json.Serialization;
using System.Text.RegularExpressions;

namespace Swms.FinishGoods.API.Features.ShipmentInstructions.Api;

// ═══════════════════════════════════════════════════════════════
//  Payload SAP / ERP — giữ NGUYÊN tên trường của hệ thống gửi.
//  Nhiều trường bị "mượn" sai nghĩa (driverphoneno = version, tripcount = cảng đến…),
//  ý nghĩa thật ghi ở comment; SapSiMapper chịu trách nhiệm dịch sang model của kho.
// ═══════════════════════════════════════════════════════════════

public class SapSiRequest
{
    [JsonPropertyName("org")] public string? Org { get; set; }
    [JsonPropertyName("warehouse")] public string? Warehouse { get; set; }
    [JsonPropertyName("documentno")] public string? DocumentNo { get; set; }      // PB202506J3-First
    [JsonPropertyName("dateordered")] public string? DateOrdered { get; set; }
    [JsonPropertyName("datepromised")] public string? DatePromised { get; set; }
    [JsonPropertyName("sino")] public string? SiNo { get; set; }
    [JsonPropertyName("destport")] public string? DestPort { get; set; }          // = cảng XUẤT (port of loading)
    [JsonPropertyName("drivername")] public string? DriverName { get; set; }
    [JsonPropertyName("driverphoneno")] public string? DriverPhoneNo { get; set; } // = "Ver: First"
    [JsonPropertyName("contactname")] public string? ContactName { get; set; }     // = consignee
    [JsonPropertyName("contactno")] public string? ContactNo { get; set; }         // = ship mode
    [JsonPropertyName("tripcount")] public string? TripCount { get; set; }         // = cảng đến (port of discharge)
    [JsonPropertyName("driverid")] public string? DriverId { get; set; }
    [JsonPropertyName("vehiclelicenseplate")] public string? VehicleLicensePlate { get; set; }
    [JsonPropertyName("promotioncode")] public string? PromotionCode { get; set; } // = nước đến
    [JsonPropertyName("bpartner")] public string? BPartner { get; set; }
    [JsonPropertyName("cuttime")] public string? CutTime { get; set; }
    [JsonPropertyName("packingtype")] public string? PackingType { get; set; }
    [JsonPropertyName("palletlist")] public string? PalletList { get; set; }
    [JsonPropertyName("estimatedtime")] public string? EstimatedTime { get; set; }
    [JsonPropertyName("m3")] public string? M3 { get; set; }
    [JsonPropertyName("headernote3")] public string? HeaderNote3 { get; set; }     // "key : value&key : value…"
    [JsonPropertyName("casemark")] public string? CaseMark { get; set; }
    [JsonPropertyName("palletcode")] public string? PalletCode { get; set; }
    [JsonPropertyName("qrinfor")] public string? QrInfor { get; set; }
    [JsonPropertyName("pic")] public string? Pic { get; set; }
    [JsonPropertyName("c_orderline")] public List<SapSiLine> OrderLines { get; set; } = new();
    [JsonPropertyName("etd")] public string? Etd { get; set; }
    [JsonPropertyName("eta")] public string? Eta { get; set; }
    [JsonPropertyName("po")] public string? Po { get; set; }                       // áp cho MỌI dòng
    [JsonPropertyName("invoiceno")] public string? InvoiceNo { get; set; }         // áp cho MỌI dòng
    // Không còn quyết định gì: phiếu đã có (theo sino) LUÔN được cập nhật. Giữ để đọc payload cũ.
    [JsonPropertyName("isupdatesi")] public string? IsUpdateSi { get; set; }
}

public class SapSiLine
{
    [JsonPropertyName("model")] public string? Model { get; set; }
    [JsonPropertyName("qtyentered")] public string? QtyEntered { get; set; }       // chuỗi, có thể "100 "
    [JsonPropertyName("uom")] public string? Uom { get; set; }
    [JsonPropertyName("packingno")] public string? PackingNo { get; set; }         // 0080005346
    [JsonPropertyName("packingitems")] public string? PackingItems { get; set; }   // 00001
    [JsonPropertyName("so")] public string? So { get; set; }
    [JsonPropertyName("soitem")] public string? SoItem { get; set; }
}

/// <summary>Kết quả dịch payload SAP. Errors rỗng = hợp lệ.</summary>
public class SapSiMapped
{
    public string SiNo { get; init; } = "";
    public string? Revision { get; init; }
    public string DocNo => Revision is null ? SiNo : $"{SiNo}-{Revision}";
    public bool IsUpdate { get; init; }
    public List<SiLineRequest> Lines { get; init; } = new();
    public List<string> Errors { get; } = new();
    /// <summary>Điều đã tự xử lý khi dịch (vd. bỏ dòng trùng) — không chặn, ghi vào lịch sử thay đổi.</summary>
    public List<string> Warnings { get; } = new();

    // Header đã dịch — đổ vào CreateSiRequest / UpdateSiRequest qua FillHeader
    internal Action<SiHeaderRequest> FillHeader { get; init; } = _ => { };

    public CreateSiRequest ToCreate()
    {
        var r = new CreateSiRequest { SiNo = SiNo, Revision = Revision, Lines = Lines };
        FillHeader(r);
        return r;
    }

    public UpdateSiRequest ToUpdate(List<SiLineRequest> lines)
    {
        var r = new UpdateSiRequest { Lines = lines };
        FillHeader(r);
        return r;
    }
}

public static class SapSiMapper
{
    private static readonly string[] ShipModes = { "AIR", "LCL", "FCL" };

    /// <summary>Khoá header_note do SAP ghi (xem các lệnh Put trong Map). Khi SAP cập nhật phiếu,
    /// chỉ các khoá này bị thay; khoá kho tự nhập trên web được giữ nguyên.</summary>
    public static readonly IReadOnlySet<string> NoteKeys = new HashSet<string>
    {
        "org_code", "warehouse_code", "bpartner_code", "order_date", "promised_date", "destination",
        "container_size", "total_volume_m3", "pallet_list", "bl_no", "revision_reason", "remark",
        "po_no", "invoice_no", "qr_raw", "note_raw",
    };

    public static SapSiMapped Map(SapSiRequest s)
    {
        var errors = new List<string>();
        var warnings = new List<string>();
        var n3 = ParseHeaderNote3(s.HeaderNote3);
        string? N3(string key) => n3.TryGetValue(key, out var v) ? v : null;

        // ── Định danh ───────────────────────────────────────
        var siNo = Clean(s.SiNo);
        if (siNo is null) errors.Add("sino trống");

        // "Ver: First" -> First; không có thì lấy phần sau "sino-" trong documentno
        var revision = StripVer(s.DriverPhoneNo) ?? RevisionFromDocNo(s.DocumentNo, siNo);

        var documentNo = Clean(s.DocumentNo);
        var docNo = revision is null ? siNo : $"{siNo}-{revision}";
        if (documentNo is not null && siNo is not null
            && !string.Equals(documentNo, docNo, StringComparison.OrdinalIgnoreCase))
            errors.Add($"documentno '{documentNo}' không khớp sino + version '{docNo}'");

        // ── Ngày ────────────────────────────────────────────
        var etd = ParseIso(s.Etd);
        if (etd is null) errors.Add($"etd không hợp lệ: '{s.Etd}'");
        var eta = ParseIso(s.Eta);
        var vanning = ParseDmy(N3("loadingdate"));

        // T/S deadline: ngày + giờ tách 2 khoá. Có ngày mà thiếu giờ -> tính hết ngày,
        // tránh báo "quá cut-off" ngay từ 00:00.
        DateTime? cutOff = null;
        if (ParseDmy(N3("tsdeadlinedate")) is { } cd)
            cutOff = ParseTime(N3("tsdeadlinetime") ?? Clean(s.CutTime)) is { } ct
                ? cd.Date + ct
                : cd.Date.AddDays(1).AddSeconds(-1);

        // ── Ship mode: "FCL 40H" -> FCL + container_size 40H ──
        var modeRaw = Clean(s.ContactNo) ?? N3("shipmode");
        string? shipMode = modeRaw, containerSize = null;
        if (modeRaw is not null)
        {
            var parts = modeRaw.Split(' ', 2, StringSplitOptions.RemoveEmptyEntries | StringSplitOptions.TrimEntries);
            if (ShipModes.Contains(parts[0].ToUpperInvariant()))
            {
                shipMode = parts[0].ToUpperInvariant();
                containerSize = parts.Length > 1 ? parts[1] : null;
            }
        }

        // ── Dòng ────────────────────────────────────────────
        var po = Clean(s.Po);
        var invoice = TrimZeros(Clean(s.InvoiceNo));
        var lines = new List<SiLineRequest>();
        // (packing list, packing item, model) -> dòng đã nhận + vị trí trong payload
        var seen = new Dictionary<string, (SiLineRequest Line, int Index)>(StringComparer.OrdinalIgnoreCase);
        for (var i = 0; i < s.OrderLines.Count; i++)
        {
            var l = s.OrderLines[i];
            var model = Clean(l.Model);
            var qty = ParseQty(l.QtyEntered);
            if (model is null) { errors.Add($"dòng {i + 1}: model trống"); continue; }
            if (qty is null or <= 0) { errors.Add($"dòng {i + 1} ({model}): qtyentered không hợp lệ '{l.QtyEntered}'"); continue; }

            var line = new SiLineRequest
            {
                LineNo = lines.Count + 1,   // packingitems lặp lại giữa các packing list -> không dùng làm số dòng
                Model = model,
                PoNo = po,
                InvoiceNo = invoice,
                PackingListNo = TrimZeros(Clean(l.PackingNo)),
                PackingItemNo = TrimZeros(Clean(l.PackingItems)),
                SoNo = TrimZeros(Clean(l.So)),
                SoItemNo = TrimZeros(Clean(l.SoItem)),
                QtyRequired = qty.Value,
                Uom = Clean(l.Uom)?.ToUpperInvariant(),
            };

            /*  SAP gửi lại cùng 1 SI có lúc lặp nguyên dòng (c_orderline nhân đôi, m3 / casemark cũng
                nhân đôi). 1 packing item chỉ là 1 dòng giao hàng, nên:
                  giống hệt dòng trước  -> bỏ, ghi cảnh báo (không cộng dồn số lượng)
                  cùng khoá, khác số    -> lỗi, không đoán dòng nào đúng
                Dòng không có packing no / item thì không đủ căn cứ, giữ nguyên.            */
            if (line.PackingListNo is not null && line.PackingItemNo is not null)
            {
                var key = $"{line.PackingListNo}|{line.PackingItemNo}|{line.Model}";
                if (seen.TryGetValue(key, out var first))
                {
                    var f = first.Line;
                    if (f.QtyRequired == line.QtyRequired && f.Uom == line.Uom
                        && f.SoNo == line.SoNo && f.SoItemNo == line.SoItemNo)
                        warnings.Add($"bỏ dòng {i + 1} vì trùng dòng {first.Index + 1} " +
                                     $"(packing {line.PackingListNo}/{line.PackingItemNo}, {model}, {qty})");
                    else
                        errors.Add($"dòng {i + 1} trùng packing {line.PackingListNo}/{line.PackingItemNo} ({model}) " +
                                   $"với dòng {first.Index + 1} nhưng khác số lượng / SO");
                    continue;
                }
                seen[key] = (line, i);
            }

            lines.Add(line);
        }
        if (s.OrderLines.Count == 0) errors.Add("c_orderline rỗng");

        // ── Thông tin chứng từ (không dùng cho vận hành) ────
        var note = new Dictionary<string, string>();
        void Put(string key, string? value) { if (Clean(value) is { } v) note[key] = v; }
        Put("org_code", s.Org);
        Put("warehouse_code", s.Warehouse);
        Put("bpartner_code", s.BPartner);
        Put("order_date", s.DateOrdered);
        Put("promised_date", s.DatePromised);
        Put("destination", N3("destination"));
        Put("container_size", containerSize);
        // Ưu tiên Volume trong headernote3: m3 bị nhân đôi khi SAP lặp dòng (xem phần khử trùng ở trên).
        Put("total_volume_m3", N3("volume") ?? s.M3);
        Put("pallet_list", s.PalletList);
        Put("bl_no", N3("blorhawb"));
        Put("revision_reason", N3("reason"));
        Put("remark", N3("remark"));
        Put("po_no", po);
        Put("invoice_no", invoice);
        Put("qr_raw", s.QrInfor);
        Put("note_raw", s.HeaderNote3);

        var mapped = new SapSiMapped
        {
            SiNo = siNo ?? "",
            Revision = revision,
            IsUpdate = IsTruthy(s.IsUpdateSi),
            Lines = lines,
            FillHeader = h =>
            {
                h.ShipMode = shipMode;
                h.EtdDate = etd ?? default;
                h.EtaDate = eta;
                h.VanningDate = vanning;
                h.CutOffAt = cutOff;
                h.PortOfLoading = Clean(s.DestPort);
                h.PortOfDischarge = Clean(s.TripCount) ?? N3("destination");
                h.CountryCode = Clean(s.PromotionCode) ?? N3("country");
                h.ForwarderCode = N3("forwarder");
                h.CarrierCode = N3("carrier");
                h.ConsigneeCode = Clean(s.ContactName) ?? N3("consignee");
                h.PackingType = Clean(s.PackingType) ?? N3("remark");
                h.IsSerialRequired = ParseYesNo(N3("serialno"));
                h.IsWhiteFilm = ParseYesNo(N3("whitefilmair"));
                h.IsCaseMark = ParseYesNo(N3("casemarkfcl"));
                h.PicName = Clean(s.Pic);
                h.HeaderNote = note;
            },
        };
        mapped.Errors.AddRange(errors);
        mapped.Warnings.AddRange(warnings);
        return mapped;
    }

    // ═══════════════════════════════════════════════════════════
    //  helpers
    // ═══════════════════════════════════════════════════════════

    /*  "Loading date : 05.06.2025&T/S deadline (Time) :10.00&Case mark( FCL): No&&…"
        -> khoá chuẩn hoá: chữ thường, chỉ giữ a-z0-9:
             loadingdate, tsdeadlinedate, tsdeadlinetime, serialno, remark, whitefilmair,
             casemarkfcl, blorhawb, reason, volume, forwarder, carrier, destination,
             country, consignee, shipmode
        Khoá trùng: giữ lần đầu. Giá trị rỗng / "......" bị bỏ.                         */
    public static Dictionary<string, string> ParseHeaderNote3(string? raw)
    {
        var result = new Dictionary<string, string>();
        if (string.IsNullOrWhiteSpace(raw)) return result;

        foreach (var seg in raw.Split('&', StringSplitOptions.RemoveEmptyEntries))
        {
            var idx = seg.IndexOf(':');
            if (idx <= 0) continue;
            var key = NormalizeKey(seg[..idx]);
            var value = Clean(seg[(idx + 1)..]);
            if (key.Length == 0 || value is null) continue;
            result.TryAdd(key, value);
        }
        return result;
    }

    private static string NormalizeKey(string k)
    {
        var sb = new StringBuilder(k.Length);
        foreach (var c in k.ToLowerInvariant())
            if (c is >= 'a' and <= 'z' or >= '0' and <= '9') sb.Append(c);
        return sb.ToString();
    }

    /// <summary>Trim; rỗng hoặc toàn dấu chấm / gạch ("......", "-") = null.
    /// internal: so sánh với HD soft chuẩn hoá dòng theo đúng quy tắc này.</summary>
    internal static string? Clean(string? v)
    {
        if (v is null) return null;
        var t = v.Trim();
        return t.Length == 0 || Regex.IsMatch(t, @"^[.\-_\s]+$") ? null : t;
    }

    /// <summary>"0080005346" -> "80005346"; "000" -> "0".</summary>
    internal static string? TrimZeros(string? v)
    {
        if (v is null) return null;
        var t = v.TrimStart('0');
        return t.Length == 0 ? "0" : t;
    }

    private static string? StripVer(string? v)
    {
        var t = Clean(v);
        if (t is null) return null;
        var m = Regex.Match(t, @"^\s*ver\s*:\s*(.+)$", RegexOptions.IgnoreCase);
        return Clean(m.Success ? m.Groups[1].Value : t);
    }

    private static string? RevisionFromDocNo(string? documentNo, string? siNo)
    {
        var d = Clean(documentNo);
        if (d is null || siNo is null || !d.StartsWith(siNo + "-", StringComparison.OrdinalIgnoreCase)) return null;
        return Clean(d[(siNo.Length + 1)..]);
    }

    private static DateTime? ParseIso(string? v)
        => DateTime.TryParseExact(Clean(v), new[] { "yyyy-MM-dd", "yyyyMMdd", "yyyy-MM-ddTHH:mm:ss" },
               CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d.Date : null;

    private static DateTime? ParseDmy(string? v)
        => DateTime.TryParseExact(Clean(v), new[] { "dd.MM.yyyy", "d.M.yyyy", "dd/MM/yyyy", "yyyy-MM-dd" },
               CultureInfo.InvariantCulture, DateTimeStyles.None, out var d) ? d.Date : null;

    /// <summary>"10.00" / "10:00" / "9:30" / "1000" -> TimeSpan.</summary>
    private static TimeSpan? ParseTime(string? v)
    {
        var t = Clean(v)?.Replace('.', ':');
        return TimeSpan.TryParseExact(t, new[] { @"h\:mm", @"hh\:mm", @"hhmm", "%h" },
                   CultureInfo.InvariantCulture, out var ts) && ts < TimeSpan.FromDays(1) ? ts : null;
    }

    /// <summary>"100 " / "100.000" -> 100. Số lẻ thật (100.5) -> null.</summary>
    private static int? ParseQty(string? v)
    {
        if (!decimal.TryParse(Clean(v), NumberStyles.Number, CultureInfo.InvariantCulture, out var d)) return null;
        return d == Math.Truncate(d) && d <= int.MaxValue ? (int)d : null;
    }

    private static bool? ParseYesNo(string? v) => Clean(v)?.ToUpperInvariant() switch
    {
        "YES" or "Y" or "TRUE" or "1" or "X" => true,
        "NO" or "N" or "FALSE" or "0" => false,
        _ => null,
    };

    private static bool IsTruthy(string? v) => ParseYesNo(v) == true;
}