using System.ComponentModel.DataAnnotations;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

// Cọc + xếp cont trên PDA theo Stowage Plan của chuyến. Khớp VanningRemoteDataSource bên PDA.

/// <summary>1 tầng theo plan: Tier 1 dưới / 2 trên; PlanPalletCode = mã pallet soạn trên sơ đồ.</summary>
public record TripStowageTierResponse(int Tier, string? PlanPalletCode, string? SiNo, string? PalletSize);

/// <summary>
/// 1 cọc của plan nằm trong container của chuyến. RowNo 0 = sát đầu cont; LaneNo 0 trái / 1 phải.
/// BottomCode / TopCode: Pallet List thật PDA đã ghép (null = chưa ghép). PlacedAt: đã xếp vào cont.
/// </summary>
public record TripStowageColumnResponse(
    string Code, int CocNo, int? RowNo, int? LaneNo,
    List<TripStowageTierResponse> Tiers,
    string? BottomCode, string? TopCode,
    DateTime? StackedAt, string? StackedBy,
    DateTime? PlacedAt, string? PlacedBy);

/// <summary>Sơ đồ xếp của chuyến. Rows = số hàng (row_no lớn nhất + 1). Stacked / Placed: đếm cọc.</summary>
public record TripStowageResponse(
    long TripId, string PlanNo, string PlanStatus, string ShipMode, string ContainerType,
    int Rows, int Lanes, int Stacked, int Placed, bool CanEdit,
    List<TripStowageColumnResponse> Columns);

/// <summary>Ghép cọc: Pallet List thật tầng dưới / trên. Cọc 1 tầng theo plan thì TopCode bỏ trống.</summary>
public class TripStackRequest
{
    [Required, MaxLength(30)] public string BottomCode { get; set; } = "";
    [MaxLength(30)] public string? TopCode { get; set; }
}

/// <summary>
/// Xếp cọc vào cont. Cọc đã ghép: BottomCode (nếu gửi) phải khớp — quét tem để chắc đặt đúng cọc.
/// Cọc chưa ghép: phải gửi BottomCode (+ TopCode nếu plan 2 tầng) — ghép và xếp luôn.
/// </summary>
public class TripPlaceRequest
{
    [MaxLength(30)] public string? BottomCode { get; set; }
    [MaxLength(30)] public string? TopCode { get; set; }
}
