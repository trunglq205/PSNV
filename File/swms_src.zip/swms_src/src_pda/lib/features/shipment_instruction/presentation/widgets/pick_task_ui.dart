import 'package:easy_localization/easy_localization.dart';
import 'package:flutter/widgets.dart';
import 'package:swms_finish_goods/core/localization/generated/locale_keys.g.dart';
import 'package:swms_finish_goods/core/resources/app_colors.dart';
import 'package:swms_finish_goods/core/resources/theme_extension.dart';
import 'package:swms_finish_goods/features/shipment_instruction/domain/entities/pick_task.dart';
import 'package:swms_finish_goods/features/shipment_instruction/presentation/widgets/si_formatters.dart';

/// Nhãn + màu của cách lấy hàng. Gom 1 chỗ để tuyến và màn lấy hàng dùng chung.
extension PickTaskUi on PickTask {
  String modeLabel() => switch (mode) {
    PickMode.wholePallet => LocaleKeys.kitting_mode_pallet.tr(),
    PickMode.fifoBox => LocaleKeys.kitting_mode_fifo.tr(args: ['$boxPlanned']),
    PickMode.designatedBox =>
      LocaleKeys.kitting_mode_designated.tr(args: ['$boxPlanned']),
    null => siOrDash(modeKey),
  };

  Color modeColor(BuildContext context) {
    final swms = context.swms;
    return switch (mode) {
      PickMode.wholePallet => swms.primary,
      PickMode.fifoBox => swms.warning,
      PickMode.designatedBox => AppColors.accentPurple,
      null => swms.text3,
    };
  }

  /// Mã hiển thị ở vị trí "địa chỉ": locator nếu có, không thì Pallet ID.
  String get locationLabel =>
      hasLocator ? locatorCode! : siOrDash(palletCode);
}
