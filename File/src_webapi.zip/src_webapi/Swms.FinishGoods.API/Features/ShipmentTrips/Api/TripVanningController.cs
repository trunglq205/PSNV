using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.ShipmentTrips.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.ShipmentTrips.Api;

/// <summary>
/// Vanning trên PDA, theo chuyến xe (gộp 3 màn cũ Container Check · Vanning · ảnh minh chứng):
///   - Kiểm container trước khi đóng hàng          Trip.Inspect
///   - Gộp pallet / thùng vào pallet gốc, pallet đôi   Trip.Merge
/// Ảnh minh chứng ở TripPhotosController (Trip.PhotoUpload). Danh sách chuyến ở ShipmentTripsController (Trip.View).
/// </summary>
[ApiController]
[Route("api/shipment-trips")]
public class TripVanningController : ControllerBase
{
    private readonly ITripInspectionService _inspection;
    private readonly ITripMergeService _merge;
    private readonly IShipmentTripService _trips;

    public TripVanningController(ITripInspectionService inspection, ITripMergeService merge, IShipmentTripService trips)
    {
        _inspection = inspection;
        _merge = merge;
        _trips = trips;
    }

    /// <summary>Màn Pallet List: quét pallet trước -> chuyến còn mở có kế hoạch vanning chứa pallet
    /// (pallet -> SI -> chuyến -> Stowage Plan). Thường 1 chuyến; nhiều thì PDA cho chọn.
    /// Không gắn chuyến nào / không có trong kế hoạch -> lỗi.</summary>
    [HttpGet("by-pallet/{code}")]
    [RequirePermission<Perms.Outbound.Trip.Merge>]
    public async Task<ActionResult<List<TripResponse>>> ByPallet(string code)
    {
        var list = new List<TripResponse>();
        foreach (var id in await _merge.FindTripsOfPalletAsync(code))
            list.Add(await _trips.GetAsync(id, fullDriverId: false));
        return Ok(list);
    }

    /// <summary>Chốt kiểm container: pass (đủ 4 hạng mục + đủ ảnh bước 1) | fail (kèm lý do).
    /// Kết quả mới nhất trả kèm GET {id}/photos (Inspection).</summary>
    [HttpPost("{id:long}/inspection")]
    [RequirePermission<Perms.Outbound.Trip.Inspect>]
    public async Task<ActionResult<TripInspectionResponse>> Inspect(long id, TripInspectionRequest request)
        => Ok(await _inspection.SubmitAsync(id, request));

    /// <summary>Quét pallet gốc -> phiên gộp (gợi ý pallet cùng chuyến + cọc đã ghép).</summary>
    [HttpGet("{id:long}/merge/{baseCode}")]
    [RequirePermission<Perms.Outbound.Trip.Merge>]
    public async Task<ActionResult<TripMergeSessionResponse>> OpenMerge(long id, string baseCode)
        => Ok(await _merge.OpenAsync(id, baseCode));

    /// <summary>Tra mã quét ngoài gợi ý: pallet (pallet_id) hoặc thùng (box_no).</summary>
    [HttpGet("{id:long}/merge/{baseCode}/items/{code}")]
    [RequirePermission<Perms.Outbound.Trip.Merge>]
    public async Task<ActionResult<TripMergeCandidateResponse>> LookupItem(long id, string baseCode, string code)
        => Ok(await _merge.LookupAsync(id, baseCode, code));

    /// <summary>Xác nhận gộp: Pallet List (chuyển thùng sang pallet gốc) hoặc Pallet đôi (ghi cọc).</summary>
    [HttpPost("{id:long}/merge")]
    [RequirePermission<Perms.Outbound.Trip.Merge>]
    public async Task<ActionResult<TripMergeResultResponse>> Merge(long id, TripMergeRequest request)
        => Ok(await _merge.MergeAsync(id, request));
}