﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.Api.Features.Models.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;

namespace Swms.FinishGoods.Api.Features.Models.Api;

[ApiController]
[Route("api/models")]
public class ModelsController : ControllerBase
{
    private readonly IModelService _service;
    public ModelsController(IModelService service) => _service = service;

    [HttpGet]
    [AllowAnonymous]
    public async Task<ActionResult<PagedResult<ModelResponse>>> GetAll([FromQuery] ModelQuery query)
        => Ok(await _service.GetPagedAsync(query));

    [HttpGet("{id:int}")]
    [RequirePermission<Perms.System.Models.View>]
    public async Task<ActionResult<ModelResponse>> GetById(int id)
        => Ok(await _service.GetByIdAsync(id));

    /// <summary>Lấy model theo mã (business key) — dùng cho quét mã / tra cứu nhanh.</summary>
    [HttpGet("by-code/{*code}")]
    [RequirePermission<Perms.System.Models.View>]
    public async Task<ActionResult<ModelResponse>> GetByCode(string code)
        => Ok(await _service.GetByCodeAsync(code));

    /// <summary>Lấy model theo GTIN (business key) — dùng cho quét mã GTIN / tra cứu nhanh.</summary>
    [HttpGet("by-gtin/{*gtin}")]
    [RequirePermission<Perms.System.Models.View>]
    public async Task<ActionResult<ModelResponse>> GetByGTIN(string gtin)
        => Ok(await _service.GetByGTINAsync(gtin));

    [HttpPost]
    [RequirePermission<Perms.System.Models.Create>]
    public async Task<ActionResult<ModelResponse>> Create(CreateModelRequest request)
    {
        var created = await _service.CreateAsync(request);
        return CreatedAtAction(nameof(GetById), new { id = created.Id }, created);
    }

    [HttpPost("bulk")]
    [RequirePermission<Perms.System.Models.Create>]
    public async Task<ActionResult<List<ModelResponse>>> BulkCreate(IReadOnlyList<CreateModelRequest> request)
        => Ok(await _service.BulkCreateAsync(request));

    /// <summary>
    /// Import "upsert": mã đã tồn tại thì cập nhật, mã mới thì tạo mới.
    /// Trả về số bản ghi đã tạo / đã cập nhật. Dùng quyền Create + Update.
    /// </summary>
    [HttpPost("bulk-upsert")]
    [RequirePermission<Perms.System.Models.Create>]
    public async Task<ActionResult<BulkUpsertResult>> BulkUpsert(IReadOnlyList<UpsertModelRequest> request)
        => Ok(await _service.BulkUpsertAsync(request));

    [HttpPut("{id:int}")]
    [RequirePermission<Perms.System.Models.Update>]
    public async Task<IActionResult> Update(int id, UpdateModelRequest request)
    {
        await _service.UpdateAsync(id, request);
        return NoContent();
    }

    /// <summary>
    /// Cập nhật RIÊNG gợi ý lưu kho (suggest_area + suggest_rack_row) của 1 model.
    /// Không đụng GTIN / kích thước / standard packing / is_active.
    /// Gửi null cho field nào là xoá gợi ý đó.
    /// </summary>
    [HttpPatch("{id:int}/suggestion")]
    [RequirePermission<Perms.System.Models.Update>]
    public async Task<ActionResult<ModelResponse>> PatchSuggestion(int id, PatchModelSuggestionRequest request)
        => Ok(await _service.PatchSuggestionAsync(id, request));

    /// <summary>
    /// Như trên nhưng tra theo mã model — PDA quét lot chỉ cầm code, không cầm id.
    /// Catch-all {*code} bắt buộc phải là segment cuối nên route đặt tiền tố "suggestion/by-code".
    /// </summary>
    [HttpPatch("suggestion/by-code/{*code}")]
    [RequirePermission<Perms.System.Models.Update>]
    public async Task<ActionResult<ModelResponse>> PatchSuggestionByCode(string code, PatchModelSuggestionRequest request)
        => Ok(await _service.PatchSuggestionByCodeAsync(code, request));

    [HttpDelete("{id:int}")]
    [RequirePermission<Perms.System.Models.Delete>]
    public async Task<IActionResult> Delete(int id)
    {
        await _service.DeleteAsync(id);
        return NoContent();
    }
}