﻿namespace DectShrinkV2
{
    partial class frmGhepHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtSerialOuter = new System.Windows.Forms.TextBox();
            this.listView1 = new System.Windows.Forms.ListView();
            this.label1 = new System.Windows.Forms.Label();
            this.txtSerialProduct = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.cmbCategory = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.lbluser = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtPostCodeOuter = new System.Windows.Forms.TextBox();
            this.txtOuterCarton = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtModelOuter = new System.Windows.Forms.TextBox();
            this.txtModeInser = new System.Windows.Forms.TextBox();
            this.txtPostCodeInser = new System.Windows.Forms.TextBox();
            this.lblModelOuter = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.lblPostCodeInner = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label8 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label9 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.bttReset = new System.Windows.Forms.Button();
            this.lblSLActual = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.lblThongbao = new System.Windows.Forms.Label();
            this.lblSLStand = new System.Windows.Forms.Label();
            this.txtChuan = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.ckModelSecom = new System.Windows.Forms.CheckBox();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.panel1.SuspendLayout();
            this.groupBox3.SuspendLayout();
            this.SuspendLayout();
            // 
            // txtSerialOuter
            // 
            this.txtSerialOuter.Location = new System.Drawing.Point(24, 172);
            this.txtSerialOuter.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.txtSerialOuter.Name = "txtSerialOuter";
            this.txtSerialOuter.Size = new System.Drawing.Size(417, 38);
            this.txtSerialOuter.TabIndex = 5;
            this.txtSerialOuter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSerialOuter_KeyDown);
            // 
            // listView1
            // 
            this.listView1.Location = new System.Drawing.Point(831, 140);
            this.listView1.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(424, 367);
            this.listView1.TabIndex = 1;
            this.listView1.UseCompatibleStateImageBehavior = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Black;
            this.label1.Location = new System.Drawing.Point(20, 133);
            this.label1.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(166, 31);
            this.label1.TabIndex = 2;
            this.label1.Text = "Serial Outter";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // txtSerialProduct
            // 
            this.txtSerialProduct.Location = new System.Drawing.Point(12, 178);
            this.txtSerialProduct.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.txtSerialProduct.Name = "txtSerialProduct";
            this.txtSerialProduct.Size = new System.Drawing.Size(417, 38);
            this.txtSerialProduct.TabIndex = 9;
            this.txtSerialProduct.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtSerialProduct_KeyDown);
            this.txtSerialProduct.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtSerialProduct_KeyUp);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(11, 139);
            this.label2.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(184, 31);
            this.label2.TabIndex = 4;
            this.label2.Text = "Serial Product";
            // 
            // cmbCategory
            // 
            this.cmbCategory.FormattingEnabled = true;
            this.cmbCategory.Items.AddRange(new object[] {
            "DP",
            "DECT",
            "HDC",
            "PBX",
            "HP"});
            this.cmbCategory.Location = new System.Drawing.Point(186, 88);
            this.cmbCategory.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.cmbCategory.Name = "cmbCategory";
            this.cmbCategory.Size = new System.Drawing.Size(336, 41);
            this.cmbCategory.TabIndex = 2;
            this.cmbCategory.SelectedIndexChanged += new System.EventHandler(this.cmbCategory_SelectedIndexChanged);
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.ForeColor = System.Drawing.Color.Black;
            this.button1.Location = new System.Drawing.Point(909, 609);
            this.button1.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(147, 58);
            this.button1.TabIndex = 6;
            this.button1.Text = "Quay lại";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(64)))), ((int)(((byte)(0)))));
            this.label3.Location = new System.Drawing.Point(828, 105);
            this.label3.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(153, 29);
            this.label3.TabIndex = 7;
            this.label3.Text = "LIST SERIAL";
            // 
            // lbluser
            // 
            this.lbluser.AutoSize = true;
            this.lbluser.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbluser.ForeColor = System.Drawing.Color.Red;
            this.lbluser.Location = new System.Drawing.Point(950, 29);
            this.lbluser.Name = "lbluser";
            this.lbluser.Size = new System.Drawing.Size(79, 29);
            this.lbluser.TabIndex = 8;
            this.lbluser.Text = "label4";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(23, 30);
            this.label4.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(216, 31);
            this.label4.TabIndex = 9;
            this.label4.Text = "Post Code Outer";
            this.label4.Click += new System.EventHandler(this.label4_Click);
            // 
            // txtPostCodeOuter
            // 
            this.txtPostCodeOuter.Location = new System.Drawing.Point(24, 69);
            this.txtPostCodeOuter.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.txtPostCodeOuter.Name = "txtPostCodeOuter";
            this.txtPostCodeOuter.Size = new System.Drawing.Size(413, 38);
            this.txtPostCodeOuter.TabIndex = 3;
            this.txtPostCodeOuter.TextChanged += new System.EventHandler(this.txtmodel_TextChanged);
            this.txtPostCodeOuter.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPostCodeOuter_KeyDown);
            // 
            // txtOuterCarton
            // 
            this.txtOuterCarton.Location = new System.Drawing.Point(24, 266);
            this.txtOuterCarton.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.txtOuterCarton.Name = "txtOuterCarton";
            this.txtOuterCarton.Size = new System.Drawing.Size(413, 38);
            this.txtOuterCarton.TabIndex = 6;
            this.txtOuterCarton.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtOuterCarton_KeyDown);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(23, 227);
            this.label5.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(164, 31);
            this.label5.TabIndex = 11;
            this.label5.Text = "OuterCarton";
            // 
            // txtModelOuter
            // 
            this.txtModelOuter.Location = new System.Drawing.Point(463, 69);
            this.txtModelOuter.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.txtModelOuter.Name = "txtModelOuter";
            this.txtModelOuter.ReadOnly = true;
            this.txtModelOuter.Size = new System.Drawing.Size(331, 38);
            this.txtModelOuter.TabIndex = 4;
            // 
            // txtModeInser
            // 
            this.txtModeInser.Location = new System.Drawing.Point(462, 79);
            this.txtModeInser.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.txtModeInser.Name = "txtModeInser";
            this.txtModeInser.ReadOnly = true;
            this.txtModeInser.Size = new System.Drawing.Size(322, 38);
            this.txtModeInser.TabIndex = 8;
            this.txtModeInser.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtModeInser_KeyPress);
            // 
            // txtPostCodeInser
            // 
            this.txtPostCodeInser.Location = new System.Drawing.Point(12, 79);
            this.txtPostCodeInser.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.txtPostCodeInser.Name = "txtPostCodeInser";
            this.txtPostCodeInser.Size = new System.Drawing.Size(413, 38);
            this.txtPostCodeInser.TabIndex = 7;
            this.txtPostCodeInser.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtPostCodeInser_KeyDown);
            // 
            // lblModelOuter
            // 
            this.lblModelOuter.AutoSize = true;
            this.lblModelOuter.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblModelOuter.ForeColor = System.Drawing.Color.Black;
            this.lblModelOuter.Location = new System.Drawing.Point(459, 26);
            this.lblModelOuter.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.lblModelOuter.Name = "lblModelOuter";
            this.lblModelOuter.Size = new System.Drawing.Size(162, 31);
            this.lblModelOuter.TabIndex = 16;
            this.lblModelOuter.Text = "Model Outer";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(12, 34);
            this.label7.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(210, 31);
            this.label7.TabIndex = 17;
            this.label7.Text = "Post Code Inner";
            // 
            // lblPostCodeInner
            // 
            this.lblPostCodeInner.AutoSize = true;
            this.lblPostCodeInner.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPostCodeInner.ForeColor = System.Drawing.Color.Black;
            this.lblPostCodeInner.Location = new System.Drawing.Point(465, 34);
            this.lblPostCodeInner.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.lblPostCodeInner.Name = "lblPostCodeInner";
            this.lblPostCodeInner.Size = new System.Drawing.Size(156, 31);
            this.lblPostCodeInner.TabIndex = 18;
            this.lblPostCodeInner.Text = "Model Inner";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 21F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(12, 86);
            this.label6.Margin = new System.Windows.Forms.Padding(9, 0, 9, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(139, 32);
            this.label6.TabIndex = 19;
            this.label6.Text = "Catergory";
            // 
            // groupBox1
            // 
            this.groupBox1.BackColor = System.Drawing.Color.Silver;
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.lblModelOuter);
            this.groupBox1.Controls.Add(this.txtModelOuter);
            this.groupBox1.Controls.Add(this.txtOuterCarton);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.txtPostCodeOuter);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtSerialOuter);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.Location = new System.Drawing.Point(19, 140);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(800, 338);
            this.groupBox1.TabIndex = 20;
            this.groupBox1.TabStop = false;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(699, 0);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(100, 24);
            this.label8.TabIndex = 17;
            this.label8.Text = "Out Carton";
            // 
            // groupBox2
            // 
            this.groupBox2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.groupBox2.Controls.Add(this.label9);
            this.groupBox2.Controls.Add(this.lblPostCodeInner);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.txtPostCodeInser);
            this.groupBox2.Controls.Add(this.txtModeInser);
            this.groupBox2.Controls.Add(this.label2);
            this.groupBox2.Controls.Add(this.txtSerialProduct);
            this.groupBox2.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox2.Location = new System.Drawing.Point(20, 497);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(798, 231);
            this.groupBox2.TabIndex = 21;
            this.groupBox2.TabStop = false;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label9.Location = new System.Drawing.Point(686, 0);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(113, 24);
            this.label9.TabIndex = 18;
            this.label9.Text = "Inner Carton";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.ForeColor = System.Drawing.Color.Red;
            this.label10.Location = new System.Drawing.Point(791, 26);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(142, 29);
            this.label10.TabIndex = 22;
            this.label10.Text = "User Login: ";
            // 
            // bttReset
            // 
            this.bttReset.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.bttReset.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.bttReset.Location = new System.Drawing.Point(1068, 609);
            this.bttReset.Name = "bttReset";
            this.bttReset.Size = new System.Drawing.Size(126, 58);
            this.bttReset.TabIndex = 23;
            this.bttReset.Text = "Reset";
            this.bttReset.UseVisualStyleBackColor = false;
            this.bttReset.Click += new System.EventHandler(this.bttReset_Click);
            // 
            // lblSLActual
            // 
            this.lblSLActual.AutoSize = true;
            this.lblSLActual.Location = new System.Drawing.Point(18, 5);
            this.lblSLActual.Name = "lblSLActual";
            this.lblSLActual.Size = new System.Drawing.Size(0, 33);
            this.lblSLActual.TabIndex = 24;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.panel1.Controls.Add(this.lblSLActual);
            this.panel1.Location = new System.Drawing.Point(1112, 518);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(143, 51);
            this.panel1.TabIndex = 25;
            // 
            // lblThongbao
            // 
            this.lblThongbao.AutoSize = true;
            this.lblThongbao.Font = new System.Drawing.Font("Microsoft Sans Serif", 26.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblThongbao.ForeColor = System.Drawing.Color.Yellow;
            this.lblThongbao.Location = new System.Drawing.Point(120, 779);
            this.lblThongbao.Name = "lblThongbao";
            this.lblThongbao.Size = new System.Drawing.Size(0, 39);
            this.lblThongbao.TabIndex = 26;
            // 
            // lblSLStand
            // 
            this.lblSLStand.AutoSize = true;
            this.lblSLStand.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSLStand.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.lblSLStand.Location = new System.Drawing.Point(8, 28);
            this.lblSLStand.Name = "lblSLStand";
            this.lblSLStand.Size = new System.Drawing.Size(143, 33);
            this.lblSLStand.TabIndex = 27;
            this.lblSLStand.Text = "SL Chuẩn";
            // 
            // txtChuan
            // 
            this.txtChuan.Location = new System.Drawing.Point(172, 21);
            this.txtChuan.Name = "txtChuan";
            this.txtChuan.Size = new System.Drawing.Size(111, 40);
            this.txtChuan.TabIndex = 0;
            this.txtChuan.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtChuan_KeyDown);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(289, 24);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(105, 33);
            this.label11.TabIndex = 29;
            this.label11.Text = "/Thùng";
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.label11);
            this.groupBox3.Controls.Add(this.txtChuan);
            this.groupBox3.Controls.Add(this.lblSLStand);
            this.groupBox3.Location = new System.Drawing.Point(10, 5);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(450, 72);
            this.groupBox3.TabIndex = 30;
            this.groupBox3.TabStop = false;
            // 
            // ckModelSecom
            // 
            this.ckModelSecom.AutoSize = true;
            this.ckModelSecom.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ckModelSecom.Location = new System.Drawing.Point(515, 28);
            this.ckModelSecom.Name = "ckModelSecom";
            this.ckModelSecom.Size = new System.Drawing.Size(256, 33);
            this.ckModelSecom.TabIndex = 31;
            this.ckModelSecom.Text = "Check Model Secom";
            this.ckModelSecom.UseVisualStyleBackColor = true;
            // 
            // frmGhepHang
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(17F, 33F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1344, 898);
            this.Controls.Add(this.ckModelSecom);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.lblThongbao);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.bttReset);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.lbluser);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbCategory);
            this.Controls.Add(this.listView1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 21.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.Margin = new System.Windows.Forms.Padding(9, 8, 9, 8);
            this.Name = "frmGhepHang";
            this.Text = "frmGhepHang (combine sound biz - 19.04.2022)";
            this.Load += new System.EventHandler(this.frmGhepHang_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtSerialOuter;
        private System.Windows.Forms.ListView listView1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtSerialProduct;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox cmbCategory;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lbluser;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtPostCodeOuter;
        private System.Windows.Forms.TextBox txtOuterCarton;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtModelOuter;
        private System.Windows.Forms.TextBox txtModeInser;
        private System.Windows.Forms.TextBox txtPostCodeInser;
        private System.Windows.Forms.Label lblModelOuter;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label lblPostCodeInner;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Button bttReset;
        private System.Windows.Forms.Label lblSLActual;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label lblThongbao;
        private System.Windows.Forms.Label lblSLStand;
        private System.Windows.Forms.TextBox txtChuan;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.CheckBox ckModelSecom;
    }
}