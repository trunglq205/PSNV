// ─────────────────────────────────────────────────────────────
//  Mục 2c — luồng nhận lại hàng về FA, phần PDA nhìn thấy.
//
//  Sau khi GỘP vào chính phiếu chỉ thị thì không còn "đề nghị" là một thực thể
//  riêng: mỗi phiếu có đúng một luồng back, và trạng thái của nó là mấy cột
//  back_* trên phiếu. PDA vì vậy không còn phải chọn đề nghị nào — chạm phiếu
//  là quét luôn.
//
//  PDA chỉ lo BƯỚC CUỐI: SCS WH quét Pallet ID giao hàng cho FA. Hai bước
//  trước (FA đề nghị, quản lý FA xác nhận) làm trên Web — không ai soạn một đề
//  nghị trên máy quét.
// ─────────────────────────────────────────────────────────────

/// Trạng thái luồng back. Khớp `ReturnBackStatus` bên API — lệch một ký tự là
/// nút Giao hàng không bao giờ hiện mà chẳng báo lỗi gì.
enum BackStatus {
  faRequested('fa_requested'),
  faApproved('fa_approved'),

  /// Quản lý SCS đã duyệt — SCS WH được tách pallet và giao (thêm 10/11).
  scsApproved('scs_approved'),

  delivered('delivered'),
  cancelled('cancelled');

  const BackStatus(this.code);
  final String code;

  /// null / mã lạ ⇒ null: "FA chưa đề nghị gì" là một trạng thái thật, không
  /// phải giá trị mặc định nào trong danh sách trên.
  static BackStatus? from(String? v) {
    for (final e in BackStatus.values) {
      if (e.code == v) return e;
    }
    return null;
  }
}

/// Trạng thái luồng nhận lại hàng của một phiếu.
///
/// Mọi cờ và con số do API tính rồi trả xuống — PDA KHÔNG tự suy lại:
/// `remainQty` đếm từ sổ serial, tính lại bằng phép trừ ở máy là sớm muộn ra số
/// khác (con đã đánh `ng` không còn chờ giao).
class BackFlow {
  /// null = FA chưa đề nghị nhận lại hàng.
  final BackStatus? status;

  /// Bước đang chờ: `fa_approve` | `scs_deliver` | `done`. null = chưa đề nghị.
  final String? step;

  final bool requested;
  final bool isOpen;
  final bool isDelivered;

  /// Đã giao được con nào nhưng chưa xong.
  final bool isPartlyDelivered;

  final bool isCancelled;

  /// Còn ở kho SCS, chưa giao lần nào — con số WH đọc để biết phải đẩy mấy
  /// pallet nữa.
  final int remainQty;

  /// Đã TỪNG giao sang FA (kể cả sau đó FA đã trả lại).
  final int sentQty;

  /// Đang ở FA lúc này.
  final int atFaQty;

  /// FA đã trả về SCS.
  final int returnedQty;

  final String? note;
  final String? requestedBy;
  final DateTime? requestedAt;
  final String? approvedBy;
  final DateTime? approvedAt;
  final String? faComment;
  final String? scsComment;

  /// Quản lý SCS xác nhận (thêm 10/11).
  final String? scsApprovedBy;
  final DateTime? scsApprovedAt;

  /// SCS WH được tách pallet và quét giao chưa.
  ///
  /// LẤY THẲNG TỪ SERVER, không tự suy từ [status] ở đây. Trước 10/11 chỗ này
  /// là `status == faApproved`, và khi luồng thêm bước quản lý SCS duyệt thì
  /// đúng kiểu quên sửa một trong ba nơi gác nút (controller, màn Web, màn này)
  /// — hoặc thấy nút rồi ăn 403, hoặc có quyền mà không thấy nút.
  ///
  /// API cũ không gửi khoá này ⇒ false ⇒ ẩn nút. Ẩn nhầm thì WH hỏi, còn hiện
  /// nhầm thì WH quét cả xe hàng rồi mới ăn lỗi.
  final bool canDeliver;

  /// Các dòng FA xin: model + SL. RỖNG nghĩa là xin trọn phần còn ở kho — giữ
  /// đúng nghĩa của server, và mọi phiếu đề nghị trước 10/11 đều rỗng.
  final List<BackReqLine> lines;

  /// SL FA XIN — con số phải hiện cho WH, KHÁC [remainQty] là SL còn ở kho.
  ///
  /// Không khai dòng nào thì trả về chính [remainQty], KHÔNG trả 0: 0 làm WH
  /// tưởng đề nghị trống.
  int get askedQty => lines.isEmpty
      ? remainQty
      : lines.fold(0, (s, l) => s + l.reqQty);

  const BackFlow({
    this.status,
    this.step,
    this.requested = false,
    this.isOpen = false,
    this.isDelivered = false,
    this.isPartlyDelivered = false,
    this.isCancelled = false,
    this.remainQty = 0,
    this.sentQty = 0,
    this.atFaQty = 0,
    this.returnedQty = 0,
    this.note,
    this.requestedBy,
    this.requestedAt,
    this.approvedBy,
    this.approvedAt,
    this.faComment,
    this.scsComment,
    this.scsApprovedBy,
    this.scsApprovedAt,
    this.canDeliver = false,
    this.lines = const [],
  });
}

/// Một dòng FA xin lấy về.
class BackReqLine {
  final String model;
  final int reqQty;

  const BackReqLine({required this.model, required this.reqQty});
}

/// Một pallet đã giao (`wms.return_back_deliveries`).
class BackDelivery {
  final String lotNo;
  final int serialCount;
  final DateTime deliveredAt;
  final String? deliveredBy;

  const BackDelivery({
    required this.lotNo,
    required this.serialCount,
    required this.deliveredAt,
    required this.deliveredBy,
  });
}

/// Một pallet hàng return của phiếu, KÈM vị trí đang nằm trong kho.
///
/// Nằm ở bộ mục 2c dù pallet do mục 2a tạo ra: câu "pallet này đang ở đâu" là
/// câu của bước out kho — WH phải tìm được pallet trên kệ trước khi đẩy nó ra
/// vị trí nhận hàng. Hiện ở màn danh sách phiếu để khỏi phải mở bản đồ kho ra
/// dò từng ô.
class BackPallet {
  final int id;
  final String lotNo;

  /// Mã vị trí đang nằm. null = chưa lưu kho (còn ở khu nhận hàng, hoặc chưa
  /// gán vị trí nào). KHÔNG quy về chuỗi rỗng: màn hình phải phân biệt được
  /// "chưa lưu kho" với một mã vị trí.
  final String? locatorCode;

  final int serialCount;

  const BackPallet({
    required this.id,
    required this.lotNo,
    required this.locatorCode,
    required this.serialCount,
  });

  bool get stored => locatorCode != null && locatorCode!.isNotEmpty;
}

// BackDeliverResult đã XOÁ (11/11): không còn "một lượt quét giao" nào.
// BackDelivery ở trên GIỮ LẠI — nhật ký pallet đã giao vẫn đọc được.

/// SL còn ở kho của một model trong phiếu — màn giao hàng hiện để WH soát
/// "đúng hàng này không" trước khi đẩy pallet.
class BackRemainModel {
  final String model;
  final int qty;
  const BackRemainModel({required this.model, required this.qty});
}
