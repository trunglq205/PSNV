using Swms.FinishGoods.API.Features.WeightSys.PalletSync.DataAccess;

public interface IPalletWeightRepository
{
    Task<IReadOnlyList<SerialItem>> GetSerialForWeightSyncAsync(string palletId);

    Task<int> UpdateBoxWeightAsync(long boxId, decimal weight, string? user);

    Task<int> UpdateBoxWeightsAsync(IReadOnlyDictionary<long, decimal> weights, string? user);
}