using System.Text.Json.Serialization;

namespace Swms.FinishGoods.Web.Features.HdSoft.Shortage.Business.Models;

// ── DTO khớp API (HdSoftSiModels.cs bên server — tên trường snake_case) ──

public class HdSoftShortageLineDto
{
    [JsonPropertyName("vanning_date")] public DateTime VanningDate { get; set; }
    [JsonPropertyName("etd")] public DateTime? Etd { get; set; }
    [JsonPropertyName("si_no")] public string SiNo { get; set; } = "";
    [JsonPropertyName("document_no")] public string DocumentNo { get; set; } = "";
    [JsonPropertyName("line_no")] public int LineNo { get; set; }
    [JsonPropertyName("model")] public string Model { get; set; } = "";
    [JsonPropertyName("packing_no")] public string? PackingNo { get; set; }
    [JsonPropertyName("qty_open")] public decimal QtyOpen { get; set; }
    [JsonPropertyName("qty_available")] public decimal QtyAvailable { get; set; }
    [JsonPropertyName("qty_allocated")] public decimal QtyAllocated { get; set; }
    [JsonPropertyName("qty_short")] public decimal QtyShort { get; set; }
}

public class HdSoftShortageModelDto
{
    [JsonPropertyName("model")] public string Model { get; set; } = "";
    [JsonPropertyName("qty_on_hand")] public decimal QtyOnHand { get; set; }
    [JsonPropertyName("qty_open")] public decimal QtyOpen { get; set; }
    [JsonPropertyName("qty_short")] public decimal QtyShort { get; set; }
    [JsonPropertyName("first_short_vanning")] public DateTime? FirstShortVanning { get; set; }
    [JsonPropertyName("si_count")] public int SiCount { get; set; }
}

public class HdSoftShortageDayDto
{
    [JsonPropertyName("vanning_date")] public DateTime VanningDate { get; set; }
    [JsonPropertyName("si_count")] public int SiCount { get; set; }
    [JsonPropertyName("qty_open")] public decimal QtyOpen { get; set; }
    [JsonPropertyName("qty_short")] public decimal QtyShort { get; set; }
    [JsonPropertyName("short_line_count")] public int ShortLineCount { get; set; }
}

public class HdSoftShortageDto
{
    [JsonPropertyName("from")] public DateTime From { get; set; }
    [JsonPropertyName("to")] public DateTime To { get; set; }
    [JsonPropertyName("warehouse")] public string? Warehouse { get; set; }
    [JsonPropertyName("si_count")] public int SiCount { get; set; }
    [JsonPropertyName("qty_open")] public decimal QtyOpen { get; set; }
    [JsonPropertyName("qty_short")] public decimal QtyShort { get; set; }
    [JsonPropertyName("days")] public List<HdSoftShortageDayDto>? Days { get; set; }
    [JsonPropertyName("models")] public List<HdSoftShortageModelDto>? Models { get; set; }
    [JsonPropertyName("lines")] public List<HdSoftShortageLineDto>? Lines { get; set; }
    [JsonPropertyName("generated_at")] public DateTime GeneratedAt { get; set; }

    public AppHdSoftShortage ToViewModel() => new()
    {
        From = From,
        To = To,
        Warehouse = Warehouse,
        SiCount = SiCount,
        QtyOpen = QtyOpen,
        QtyShort = QtyShort,
        Days = Days ?? new(),
        Models = Models ?? new(),
        Lines = Lines ?? new(),
        GeneratedAt = GeneratedAt,
    };
}

// ── View model ──────────────────────────────────────────────

/// <summary>Hàng thiếu trên HD soft: nhu cầu còn mở của SI (đặt − đã giao) so với tồn kho HD soft,
/// tồn được chia theo ngày vanning sớm trước. Dữ liệu chỉ đọc — không có thao tác đòi hàng như hàng thiếu SWMS.</summary>
public class AppHdSoftShortage
{
    public DateTime From { get; set; }
    public DateTime To { get; set; }
    public string? Warehouse { get; set; }
    public int SiCount { get; set; }
    public decimal QtyOpen { get; set; }
    public decimal QtyShort { get; set; }
    public List<HdSoftShortageDayDto> Days { get; set; } = new();
    public List<HdSoftShortageModelDto> Models { get; set; } = new();
    public List<HdSoftShortageLineDto> Lines { get; set; } = new();
    public DateTime GeneratedAt { get; set; }

    public int ShortModelCount => Models.Count(m => m.QtyShort > 0);
    public int ShortLineCount => Lines.Count(l => l.QtyShort > 0);
}
