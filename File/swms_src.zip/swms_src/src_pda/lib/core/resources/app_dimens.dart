/// Khoảng cách, bo góc, vùng chạm — từ tokens.css (surface PDA).
abstract final class AppDimens {
  const AppDimens._();

  // Spacing
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 16;
  static const double lg = 24;
  static const double xl = 32;

  // Radius (PDA · bo góc lớn, mềm)
  static const double rCard = 14;   // --r-card
  static const double rBtn = 12;    // --r-btn
  static const double rInput = 10;  // --r-input

  // Touch targets — TC25 glove-friendly
  static const double hitSm = 36;   // --hit-sm
  static const double hitMd = 44;   // --hit-md (mục bấm tối thiểu)
  static const double hitLg = 52;   // --hit-lg (CTA chính cuối màn)

  // Density
  static const double rowH = 44;
  static const double rowHCompact = 36; // --row-h khi data-density="compact"
}
