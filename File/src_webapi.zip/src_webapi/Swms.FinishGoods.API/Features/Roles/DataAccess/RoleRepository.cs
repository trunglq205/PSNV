using System.Data;
using Dapper;
using Swms.FinishGoods.Api.Features.Roles.Business.Models;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.Api.Features.Roles.DataAccess;

public class RoleRepository : IRoleRepository
{
    private readonly IDbConnectionFactory _factory;
    public RoleRepository(IDbConnectionFactory factory) => _factory = factory;

    private const string RoleColumns = """
        r.id          AS Id,
        r.code        AS Code,
        r.name        AS Name,
        r.description AS Description,
        r.dot         AS Dot,
        r.is_system   AS IsSystem
        """;

    // ─────────────────────────── Roles (đọc) ───────────────────────────

    public async Task<List<Role>> GetAllAsync()
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {RoleColumns},
                   (SELECT COUNT(*) FROM master.user_roles ur WHERE ur.role_id = r.id) AS UserCount
            FROM master.roles r
            WHERE r.is_deleted = 0
            ORDER BY r.is_system DESC, r.name;

            SELECT rp.role_id, p.code
            FROM master.role_permissions rp
            JOIN master.permissions p ON p.id = rp.permission_id AND p.is_deleted = 0
            JOIN master.roles r ON r.id = rp.role_id AND r.is_deleted = 0;
            """;
        using var multi = await conn.QueryMultipleAsync(sql);
        var roles = (await multi.ReadAsync<Role>()).ToList();
        var perms = (await multi.ReadAsync<(long RoleId, string Code)>()).ToList();

        var byRole = perms.GroupBy(x => x.RoleId)
                          .ToDictionary(g => g.Key, g => g.Select(x => x.Code).ToList());
        foreach (var role in roles)
            role.Permissions = byRole.TryGetValue(role.Id, out var p) ? p : new();
        return roles;
    }

    public async Task<Role?> GetByCodeAsync(string code)
    {
        using var conn = _factory.Create();
        var sql = $"""
            SELECT {RoleColumns},
                   (SELECT COUNT(*) FROM master.user_roles ur WHERE ur.role_id = r.id) AS UserCount
            FROM master.roles r
            WHERE r.code = @code AND r.is_deleted = 0;

            SELECT p.code
            FROM master.role_permissions rp
            JOIN master.roles r ON r.id = rp.role_id AND r.code = @code AND r.is_deleted = 0
            JOIN master.permissions p ON p.id = rp.permission_id AND p.is_deleted = 0;
            """;
        using var multi = await conn.QueryMultipleAsync(sql, new { code });
        var role = await multi.ReadFirstOrDefaultAsync<Role>();
        if (role is null) return null;
        role.Permissions = (await multi.ReadAsync<string>()).ToList();
        return role;
    }

    public async Task<bool> CodeExistsAsync(string code)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM master.roles WHERE code = @code AND is_deleted = 0;",
            new { code }) > 0;
    }

    public async Task<Dictionary<string, long>> GetPermissionIdsByCodesAsync(IEnumerable<string> codes)
    {
        var list = codes.Distinct().ToList();
        if (list.Count == 0) return new();
        using var conn = _factory.Create();
        var rows = await conn.QueryAsync<(string Code, long Id)>(
            "SELECT code, id FROM master.permissions WHERE is_deleted = 0 AND code IN @codes;",
            new { codes = list });
        return rows.ToDictionary(x => x.Code, x => x.Id, StringComparer.OrdinalIgnoreCase);
    }

    // ─────────────────────────── Roles (ghi) ───────────────────────────

    public async Task<long> AddAsync(Role role, IEnumerable<long> permissionIds, string actor)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            const string insert = """
                INSERT INTO master.roles (code, name, description, dot, is_system, created_by)
                VALUES (@Code, @Name, @Description, @Dot, 0, @actor);
                SELECT CAST(SCOPE_IDENTITY() AS bigint);
                """;
            var id = await conn.ExecuteScalarAsync<long>(insert,
                new { role.Code, role.Name, role.Description, role.Dot, actor }, tx);

            await InsertPermissionsAsync(conn, tx, id, permissionIds, actor);
            tx.Commit();
            return id;
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task UpdateAsync(string currentCode, Role role, string actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.roles
            SET code = @NewCode, name = @Name, description = @Description, dot = @Dot,
                updated_at = SYSDATETIME(), updated_by = @actor
            WHERE code = @currentCode AND is_deleted = 0;
            """;
        await conn.ExecuteAsync(sql, new
        {
            NewCode = role.Code, role.Name, role.Description, role.Dot, currentCode, actor
        });
    }

    public async Task ReplacePermissionsAsync(string code, IEnumerable<long> permissionIds, string actor)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var roleId = await conn.ExecuteScalarAsync<long?>(
                "SELECT id FROM master.roles WHERE code = @code AND is_deleted = 0;",
                new { code }, tx);
            if (roleId is null) { tx.Rollback(); return; }

            await conn.ExecuteAsync(
                "DELETE FROM master.role_permissions WHERE role_id = @roleId;",
                new { roleId }, tx);
            await InsertPermissionsAsync(conn, tx, roleId.Value, permissionIds, actor);
            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    public async Task SoftDeleteAsync(string code)
    {
        using var conn = _factory.Create();
        conn.Open();
        using var tx = conn.BeginTransaction();
        try
        {
            var roleId = await conn.ExecuteScalarAsync<long?>(
                "SELECT id FROM master.roles WHERE code = @code AND is_deleted = 0;",
                new { code }, tx);
            if (roleId is null) { tx.Rollback(); return; }

            await conn.ExecuteAsync(
                "DELETE FROM master.role_permissions WHERE role_id = @roleId;",
                new { roleId }, tx);
            await conn.ExecuteAsync(
                "UPDATE master.roles SET is_deleted = 1 WHERE id = @roleId;",
                new { roleId }, tx);
            tx.Commit();
        }
        catch { tx.Rollback(); throw; }
    }

    // ─────────────────────────── /api/me ───────────────────────────

    public async Task<List<string>> GetEffectivePermissionsForUserAsync(long userId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT DISTINCT p.code
            FROM master.user_roles ur
            JOIN master.roles r ON r.id = ur.role_id AND r.is_deleted = 0
            JOIN master.role_permissions rp ON rp.role_id = r.id
            JOIN master.permissions p ON p.id = rp.permission_id AND p.is_deleted = 0
            WHERE ur.user_id = @userId;
            """;
        return (await conn.QueryAsync<string>(sql, new { userId })).ToList();
    }

    public async Task<bool> UserHasSystemRoleAsync(long userId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT COUNT(1)
            FROM master.user_roles ur
            JOIN master.roles r ON r.id = ur.role_id AND r.is_deleted = 0
            WHERE ur.user_id = @userId AND r.is_system = 1;
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new { userId }) > 0;
    }

    // ─────────────────────────── helper ───────────────────────────

    private static async Task InsertPermissionsAsync(
        IDbConnection conn, IDbTransaction tx, long roleId,
        IEnumerable<long> permissionIds, string actor)
    {
        var ids = permissionIds.Distinct().ToList();
        if (ids.Count == 0) return;
        const string sql = """
            INSERT INTO master.role_permissions (role_id, permission_id, created_by)
            VALUES (@roleId, @permissionId, @actor);
            """;
        var rows = ids.Select(pid => new { roleId, permissionId = pid, actor });
        await conn.ExecuteAsync(sql, rows, tx);
    }
}
