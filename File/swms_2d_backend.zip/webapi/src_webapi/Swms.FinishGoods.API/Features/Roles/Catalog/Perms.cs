﻿using System.Security;

namespace Swms.FinishGoods.Api.Features.Roles.Catalog;

/// <summary>
/// ★ NGUỒN SỰ THẬT DUY NHẤT của toàn bộ phân quyền hệ thống. ★
///
/// Cấu trúc 3 tầng record lồng nhau:  Module → Screen → Permission(action).
/// PermissionCatalog đọc cây này bằng reflection — KHÔNG generator, KHÔNG file sinh ra.
///
/// Quy ước tên → code (PascalCase → snake_case):
///   • Module   record "Receiving"   → module code  "receiving"
///   • Screen   record "RecvPallet"  → screen code   "recv_pallet"
///   • Action   record "View"        → action "view", permission code "recv_pallet.view"
///
/// ⚠ Vì convert tách theo chữ HOA: muốn ra "abnormal-report" thì đặt tên "Cartonng"
///   (KHÔNG "CartonNg" — cái đó ra "abnormal-report"). Đặt tên nhất quán PascalCase.
///
/// Thêm/bớt quyền: CHỈ sửa cây này. Dùng để enforce:
///   [RequirePermission&lt;Perms.Receiving.Asn.Create&gt;]   ← strongly-typed, gõ sai compiler báo.
///
/// Tên hiển thị KHÔNG đặt ở đây — tra resx theo convention key từ code:
///   module → "Perm.Module.{code}" · screen → "Perm.Screen.{code}" · perm → "Perm.Item.{code}"
/// </summary>
public static class Perms
{
    public static class Pda
    {
        /// <summary>
        /// <c>ReturnReceive</c> = tile "Chỉ thị back hàng" trên Home của PDA —
        /// SCS WH quét thùng → serial lúc nhận hàng khách trả (mục 2a).
        ///
        /// <c>ReturnFaPallet</c> = tile "Tạo pallet sau rework" — FA quét serial
        /// đóng pallet mới sau khi làm xong (mục 2d). Tách riêng vì NGƯỜI DÙNG
        /// khác hẳn: FA chỉ cần tile này, không được thấy tile nhận hàng của WH.
        ///
        /// Cả hai tách khỏi <c>Receive</c> của nhận hàng thường.
        /// </summary>
        public static class PdaReceiving { public sealed class Receive;public sealed class AbnormalReport; public sealed class TempLocation; public sealed class ReturnReceive; public sealed class ReturnFaPallet; }
        public static class PdaStorage { public sealed class Putaway; public sealed class Move; public sealed class StocktakeMorning; public sealed class StocktakeShipment; public sealed class StocktakeMonthly { } }
        public static class PdaOutbound { public sealed class ShippingInstructions; public sealed class Pick; public sealed class Tally; public sealed class EmapKitting; }
        public static class PdaShipping { public sealed class Vanning; public sealed class Container; public sealed class Stowage; }
    }

    public static class Receiving
    {
        public static class PartCard { public sealed class View; public sealed class Print; public sealed class Delete; public sealed class Lock; public sealed class Unlock; }
        public static class RecvPallet { public sealed class View; public sealed class Scan; public sealed class Undo; public sealed class Force; }
        public static class Temploc { public sealed class View; public sealed class Assign; public sealed class Release; public sealed class Edit; }
        public static class OQC { public sealed class Sample; public sealed class Return; }
        public static class Stocky { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Delete; public sealed class Transfer; }
        /// <summary>
        /// Hàng bất thường — luồng 5 bước, MỖI BƯỚC MỘT QUYỀN RIÊNG để một người
        /// không gánh được hai bước liền nhau:
        ///   B1 SCS tạo phiếu            → create
        ///   B2 Leader SCS duyệt/huỷ     → leader_review
        ///   B3 OQC kết luận             → oqc_confirm
        ///   B4 FA chọn hướng xử lý      → fa_confirm
        ///   B5 SCS Supervisor chốt      → finalize
        /// ⚠ Tên lớp viết PascalCase TỪNG CHỮ: Snake() chèn '_' trước mọi chữ hoa,
        ///   nên "OqcConfirm" ra oqc_confirm, còn "OQCConfirm" ra o_q_c_confirm.
        /// ⚠ Hai quyền gộp cũ (process, approve) đã BỎ — xem db/ng_perms_split.sql.
        ///   Đừng khai lại đúng tên cũ: seeder MERGE theo code sẽ bật is_deleted về 0
        ///   và làm sống lại quyền của mọi role từng được gán.
        /// </summary>
        public static class AbnormalReport
        {
            public sealed class View;
            public sealed class Create;
            public sealed class LeaderReview;
            public sealed class OqcConfirm;
            public sealed class FaConfirm;
            public sealed class Finalize;
            public sealed class Print;

            /// <summary>
            /// Quản trị danh mục loại lỗi (master.ng_types). Tách riêng khỏi 5
            /// quyền duyệt: người duyệt phiếu không đương nhiên được sửa danh mục,
            /// vì đổi cờ requires_oqc là đổi luồng duyệt của mọi phiếu sau đó.
            /// </summary>
            public sealed class ManageTypes;
        }
        /// <summary>
        /// Hàng back rework / refurbish. Luồng đi qua NĂM bên, nên theo đúng
        /// cách của AbnormalReport ở trên: MỖI BƯỚC MỘT QUYỀN, bộ phận được mã
        /// hoá vào TÊN QUYỀN chứ không đi so với <c>master.users.department</c>
        /// (department chỉ dùng để định tuyến mail, và <c>ICurrentUser</c> còn
        /// không mang nó).
        ///
        /// Đang dùng:
        ///   B1    SCS Office tạo / sửa / xoá / mở lại phiếu  → create
        ///   B2.1  SCS WH quét thùng + serial                 → process
        ///         chốt thực nhận, huỷ lần nhận               → process HOẶC create
        ///         (Office cũng phải chốt được — quyết định nghiệp vụ 03/11)
        ///
        /// Mục 2c — yêu cầu back sang FA, bốn bước mỗi bước một quyền:
        ///   B1  FA tạo yêu cầu                               → request_back
        ///   B2  quản lý FA duyệt                             → approve_fa
        ///   B3  SCS WH xác nhận + tạo chỉ thị back           → process
        ///   B4  quản lý SCS duyệt cho back                   → approve_scs
        ///       ⇒ serial chuyển at_fa tại bước này
        ///
        /// Mục 2d:
        ///   B2.4  FA quét tạo lại pallet sau rework          → process_fa
        ///
        /// ⚠ <c>Approve</c> và <c>Print</c> khai sẵn nhưng KHÔNG gác endpoint
        ///   nào. Cần hai cấp duyệt KHÁC BÊN nên dùng approve_fa /
        ///   approve_scs, không dùng Approve. ĐỪNG xoá dòng Approve bằng cách
        ///   sửa code: seeder MERGE theo code, xoá rồi khai lại đúng tên cũ sẽ
        ///   bật is_deleted về 0 và làm SỐNG LẠI quyền của mọi role từng được
        ///   gán — phải xử lý bằng script như db/ng_perms_split.sql.
        /// </summary>
        public static class ReworkRefurbish
        {
            public sealed class View;
            public sealed class Create;
            public sealed class Process;
            public sealed class Approve;
            public sealed class Print;

            /// <summary>B1 — FA tạo yêu cầu back.</summary>
            public sealed class RequestBack;

            /// <summary>B2 — quản lý FA duyệt yêu cầu back.</summary>
            public sealed class ApproveFa;

            /// <summary>B4 — quản lý SCS duyệt cho hàng đi FA.</summary>
            public sealed class ApproveScs;

            /// <summary>
            /// Mục 2d — FA quét serial tạo lại pallet sau rework. Tách khỏi
            /// <c>Process</c> (của SCS WH) vì hai bên quét hai loại hàng ở hai
            /// thời điểm khác nhau, và màn quét cũng khác.
            /// </summary>
            public sealed class ProcessFa;
        }
    }

    public static class Storage
    {
        public static class Putaway { public sealed class View; public sealed class Execute; public sealed class Override; }
        public static class Map { public sealed class View; public sealed class Detail; public sealed class Edit; }
        public static class Inventory { public sealed class View; public sealed class Value; public sealed class Export; }
        public static class Stocktake { public sealed class View; public sealed class Create; public sealed class Assign; public sealed class Count; public sealed class Recount; public sealed class Approve; public sealed class Cancel; }
        public static class Balance { public sealed class View; public sealed class Create; public sealed class Approve; }
    }

    public static class Outbound
    {
        public static class Si { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Completed; public sealed class Delete; public sealed class Cancel;  public sealed class Cut; public sealed class Allocate; public sealed class Print; public sealed class Pick;  }
        public static class Trip { public sealed class View; public sealed class Create; public sealed class Update; public sealed class ChangeStatus; public sealed class Delete; public sealed class PhotoUpload; public sealed class Inspect; public sealed class Merge; public sealed class Stow; }
        public static class Picking { public sealed class View; public sealed class Execute; public sealed class Reassign; public sealed class Confirm; }
        public static class Shortage { public sealed class View; public sealed class Request; public sealed class ConfirmEta; }
        public static class Serial { public sealed class View; public sealed class Scan; public sealed class Remove; }
    }

    public static class Shipping
    {
        public static class Vanning { public sealed class View; public sealed class Execute; public sealed class Update; }
        public static class Container { public sealed class View; public sealed class Inspect; public sealed class Seal; public sealed class Gateout; }
        public static class Stowage { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Approve; }
    }

    public static class Analytics
    {
        public static class Reports { public sealed class View; public sealed class Export; public sealed class Schedule; }
        public static class Audit { public sealed class View; public sealed class Export; }
    }

    public static class System
    {
        public static class Models { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Delete; public sealed class Import; }
        public static class Master { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Delete; public sealed class Import; }
        public static class Users { public sealed class View; public sealed class Create; public sealed class Update; public sealed class Lock; public sealed class ResetPwd; public sealed class Delete; }
        public static class Roles { public sealed class View; public sealed class Create; public sealed class Update; public sealed class AssignUser; public sealed class Delete; }
        public static class Settings { public sealed class View; public sealed class Update; public sealed class Integration; }
        public static class PdaApp { public sealed class View; public sealed class Publish; }
        public static class EmailConfig { public sealed class View;  public sealed class Update;  }
    }
}