using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Common.Models;
using Swms.FinishGoods.API.Features.Pallets.Api;
using Swms.FinishGoods.API.Features.Pallets.DataAccess;
using Swms.FinishGoods.API.Features.Pallets.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.Business;
using Swms.FinishGoods.API.Features.StockEvents.Business.Entities;
using Swms.FinishGoods.API.Features.StockEvents.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.Pallets.Business
{
    /// <summary>
    /// Nghiệp vụ pallet THUẦN SWMS: tạo / xoá / sửa SL, quét, gán – rời – chuyển vị trí,
    /// lưu kho, tách pallet.
    ///
    /// File này KHÔNG biết Foss hay HD soft tồn tại. Luồng đồng bộ nằm ở:
    ///   Features/Foss/Pallets   — PalletFossSyncService   (tạo từ Foss, bổ sung thùng, OQC)
    ///   Features/HdSoft/Pallets — PalletHdSoftSyncService (vị trí, si_no theo HD soft)
    /// Hai service đó gọi ngược vào đây qua <see cref="BuildDetailAsync"/>,
    /// <see cref="AssignLocatorBySyncAsync"/>, <see cref="ReleaseLocatorBySyncAsync"/>.
    /// </summary>
    public class PalletService : IPalletService
    {
        /// <summary>
        /// Số dòng lịch sử trả kèm khi quét (?include=history). Đây là phần liếc
        /// nhanh trên PDA, không phải màn lịch sử — cần đầy đủ thì gọi /history.
        /// </summary>
        private const int BriefHistoryCount = 10;

        private readonly ILotRepository _repo;
        private readonly ICategoryRepository _categoryRepo;
        private readonly IStockEventRepository _eventRepo;
        private readonly ICurrentUser _currentUser;
        private readonly IStringLocalizer<SharedResource> _localizer;

        /// <summary>
        /// Cổng chặn đưa hàng tái gia công ra khu Nhận hàng. Hiện thực nằm ở
        /// slice ReturnInstructions — xem <see cref="IReturnBackMoveGate"/> về lý
        /// do phải là interface khai ở đây chứ không gọi thẳng service bên đó.
        /// </summary>
        private readonly IReturnBackMoveGate _backGate;

        public PalletService(
            ILotRepository repo,
            ICategoryRepository categoryRepo,
            IStockEventRepository eventRepo,
            ICurrentUser currentUser,
            IStringLocalizer<SharedResource> localizer,
            IReturnBackMoveGate backGate)
        {
            _repo = repo;
            _categoryRepo = categoryRepo;
            _eventRepo = eventRepo;
            _currentUser = currentUser;
            _localizer = localizer;
            _backGate = backGate;
        }

        // ── Read ──────────────────────────────────────────────────────
        public async Task<PagedResult<PalletResponse>> GetPagedAsync(PalletQuery query)
        {
            if (query.Page < 1) query.Page = 1;
            if (query.Size < 1 || query.Size > 100) query.Size = 20;

            var paged = await _repo.GetPagedAsync(query);

            return new PagedResult<PalletResponse>(
                paged.Items.Select(PalletResponse.From).ToList(),
                paged.TotalCount,
                paged.Page,
                paged.Size);
        }

        public async Task<PalletResponse> GetByIdAsync(long id)
        {
            var lot = await _repo.GetByIdAsync(id)
                ?? throw new NotFoundException(_localizer["Lot.NotFound", id]);
            return PalletResponse.From(lot);
        }

        public async Task DeleteAsync(long id)
        {
            _ = await _repo.GetByIdAsync(id)
                ?? throw new NotFoundException(_localizer["Lot.NotFound", id]);

            // Event PALLET_DELETED ghi bên trong transaction của SoftDeleteAsync.
            await _repo.SoftDeleteAsync(id, _currentUser.FullName ?? "");
        }

        // ── Sửa SL pallet box_count ──────────────────────────────────

        public async Task<UpdateBoxCountResponse> UpdateBoxCountAsync(long id, UpdateBoxCountRequest request)
        {
            var info = await _repo.GetLocationInfoByIdAsync(id)
                ?? throw new NotFoundException(_localizer["Lot.NotFound", id]);

            // Pallet serial / box_line: SL là tổng box_lines — sửa theo từng thùng, không qua đây.
            if (!string.Equals(info.DetailLevel, DetailLevelBoxCount, StringComparison.OrdinalIgnoreCase))
                throw new BusinessRuleException(_localizer["Lot.BoxCount.NotBoxCount", info.LotNo, info.DetailLevel]);

            var packing = request.StandardPacking ?? info.StandardPacking ?? 0;
            if (packing < 1)
                throw new BusinessRuleException(_localizer["Lot.BoxCount.PackingRequired", info.LotNo]);

            var qtyAfter = (long)request.BoxCount * packing;
            if (qtyAfter > int.MaxValue)
                throw new BusinessRuleException(_localizer["Lot.BoxCount.QtyTooLarge", qtyAfter]);

            var user = _currentUser.FullName ?? "";
            var ctx = new IntegrationSyncContext(StockEventSources.Web, user)
                .ToEventContext(StockEventCodes.QtyAdjusted, new
                {
                    reason = request.Reason,
                    expectedQty = request.ExpectedQty,
                    boxCountAfter = request.BoxCount,
                    standardPackingAfter = packing,
                    qtyAfter,
                });

            // Kiểm ExpectedQty nằm trong câu UPDATE (cùng cách ExecuteSplitByQtyAsync):
            // kiểm trước rồi mới ghi thì 2 người sửa cùng lúc vẫn lọt.
            var before = await _repo.UpdateBoxCountAsync(
                id, request.BoxCount, packing, request.ExpectedQty, user, ctx);

            if (before is null)
                throw new ConflictException(_localizer["Lot.BoxCount.QtyChanged", info.LotNo, request.ExpectedQty ?? 0]);

            return new UpdateBoxCountResponse(
                info.Id, info.LotNo,
                before.BoxCountBefore, request.BoxCount,
                before.StandardPackingBefore, packing,
                before.BoxCountBefore * before.StandardPackingBefore, (int)qtyAfter);
        }

        // ── Xoá thùng ────────────────────────────────────────────────

        public async Task<DeleteBoxesResponse> DeleteBoxesAsync(long id, DeleteBoxesRequest request)
        {
            var info = await _repo.GetLocationInfoByIdAsync(id)
                ?? throw new NotFoundException(_localizer["Lot.NotFound", id]);

            // box_count không có dòng thùng nào để xoá — sửa SL qua PUT .../box-count.
            if (string.Equals(info.DetailLevel, DetailLevelBoxCount, StringComparison.OrdinalIgnoreCase))
                throw new BusinessRuleException(_localizer["Lot.BoxDelete.NotSupported", info.LotNo]);

            var ids = (request.BoxIds ?? []).Distinct().ToList();
            if (ids.Count == 0)
                throw new BusinessRuleException(_localizer["Lot.BoxDelete.NoBoxSelected"]);

            // Kiểm trước để trả lỗi rõ; repo kiểm lại trong khoá.
            var valid = await _repo.CountBoxesInLotAsync(id, ids);
            if (valid != ids.Count)
                throw new BusinessRuleException(_localizer["Lot.BoxDelete.BoxNotInLot", info.LotNo]);
            if (info.BoxCount is int total && valid >= total)
                throw new BusinessRuleException(_localizer["Lot.BoxDelete.AllBoxes", info.LotNo]);

            var user = _currentUser.FullName ?? "";
            var ctx = new IntegrationSyncContext(StockEventSources.Web, user)
                .ToEventContext(StockEventCodes.PalletBoxesRemoved, new
                {
                    reason = request.Reason,
                    boxIds = ids,
                });

            var r = await _repo.SoftDeleteBoxesAsync(id, ids, user, ctx)
                ?? throw new ConflictException(_localizer["Lot.BoxDelete.Changed", info.LotNo]);

            return new DeleteBoxesResponse(
                id, r.LotNo, r.BoxesDeleted, r.LinesDeleted, r.QtyDeleted, r.BoxCountBefore, r.BoxCountAfter);
        }

        // ── Sinh pallet_id: <category:3><yymmdd:6><seq:3> ────────────────
        // KHÔNG persist: chỉ đề xuất số kế tiếp. Client vẫn gửi pallet_id khi
        // POST /api/lots, và validate + unique index ở đó mới là chốt chặn thật.
        public async Task<NextLotNoResponse> GenerateNextLotNoAsync(int categoryCode)
        {
            // categoryCode phải có thật để đồng nhất với ràng buộc lúc tạo lot.
            var category = await _categoryRepo.GetByCodeAsync(categoryCode)
                ?? throw new NotFoundException(_localizer["Lot.CategoryNotFound", categoryCode]);

            if (category.Code < 0 || category.Code > 999)
                throw new BusinessRuleException(_localizer["Lot.CategoryCodeOutOfRange", category.Code]);

            // Ngày server. Dùng DateTime.Now để khớp múi giờ nhà máy;
            // đổi sang UtcNow nếu toàn hệ thống chuẩn hoá theo UTC.
            var datePart = DateTime.Now.ToString("yyMMdd");
            var prefix = $"{category.Code:D3}{datePart}";

            var maxSeq = await _repo.GetMaxSequenceAsync(prefix);
            var nextSeq = maxSeq + 1;

            // 3 chữ số -> tối đa 999 lot / category / ngày.
            if (nextSeq > 999)
                throw new BusinessRuleException(_localizer["Lot.SequenceExhausted", prefix]);

            var lotNo = $"{prefix}{nextSeq:D3}";
            return new NextLotNoResponse(lotNo, category.Code, datePart, nextSeq);
        }

        // ── Create ────────────────────────────────────────────────────
        // Lot tạo ra là active ngay (không còn luồng draft/confirm).
        // pallet_id do CLIENT sinh — server chỉ validate format + chống trùng.
        public async Task<CreatePalletResponse> CreateAsync(
            CreatePalletRequest request,
            Func<System.Data.IDbConnection, System.Data.IDbTransaction, long, Task>? onInserted = null)
        {
            var category = await _categoryRepo.GetByCodeAsync(request.CategoryCode)
                ?? throw new NotFoundException(_localizer["Lot.CategoryNotFound", request.CategoryCode]);

            var lotNo = await ValidateLotNoAsync(request.LotNo, category.Code);

            // DataAnnotations đã chặn null, unwrap an toàn.
            var level = request.DetailLevel!.Value;
            var lotType = request.LotType!.Value;

            ValidateShape(request, level, lotType);

            var boxes = level == PalletDetailLevel.BoxCount
                ? []
                : BuildBoxes(request, level);

            // BoxLine: 1 thẻ (raw_payload) chỉ được nằm trên 1 pallet đang active.
            // Check sớm ở đây để trả lỗi đẹp; AddAsync check lại trong transaction
            // (có khoá) để chặn 2 request quét cùng thẻ vào cùng lúc.
            var rejectDuplicatePayload = level == PalletDetailLevel.BoxLine;
            if (rejectDuplicatePayload)
                await EnsurePayloadsNotUsedAsync(boxes);

            // Bổ sung từ thẻ in — phải chạy TRƯỚC khi dựng Pallet: nó đổi
            // box.CreatedAt, mà AddAsync dùng giá trị đó làm EventAt của BOX_CREATED.
            await ApplyPartCardsAsync(boxes);

            var lot = new Pallet
            {
                LotNo = lotNo,
                CategoryCode = category.Code,
                LotType = lotType.ToDbValue(),
                StockyCode = lotType == PalletType.Stocky
                    ? request.StockyCode!.Trim()
                    : null,
                DetailLevel = level.ToDbValue(),

                // Serial|BoxLine: server tự tính, bỏ qua BoxCount client gửi.
                BoxCount = level == PalletDetailLevel.BoxCount
                    ? request.BoxCount
                    : boxes.Count,

                // BoxCount không có line để suy ra -> lấy thẳng từ request.
                Model = request.Model?.Trim(),
                StandardPacking = level == PalletDetailLevel.BoxCount
                    ? request.StandardPacking
                    : null,

                // MIN(box.production_date) — oldest wins cho FIFO.
                // Min() trên IEnumerable<DateTime?> bỏ qua null, rỗng -> null.
                ProductionDate = level == PalletDetailLevel.BoxCount
                    ? request.ProductionDate ?? DateTime.Now
                    : boxes.Min(b => b.ProductionDate),

                InspectionStatus = level == PalletDetailLevel.BoxCount
                    ? InspectionStatus.Pass : InspectionStatus.NotInspected,

                Boxes = boxes,
                CreatedBy = _currentUser.FullName
            };

            long id;
            try
            {
                id = await _repo.AddAsync(lot, PalletOrigins.Manual,
                    rejectDuplicatePayload: rejectDuplicatePayload,
                    onInserted: onInserted);
            }
            catch (DuplicateBoxPayloadException ex)
            {
                // Thua race với request khác trong khoảng giữa pre-check và insert.
                throw PayloadExistsError(ex.Existing);
            }
            lot.Id = id;
            return CreatePalletResponse.From(lot, boxes.Sum(b => b.Lines.Count));
        }

        /// <summary>
        /// Gán CreatedAt / LotName / OQCStatus cho box từ thẻ in, khớp qua
        /// boxes.raw_payload = part_cards.payload.
        ///
        /// Vì sao CreatedAt lấy từ thẻ: thùng được đóng lúc in thẻ, còn
        /// POST /api/pallets chỉ là lúc gom chúng lên pallet — có thể sau đó nhiều giờ.
        /// Mốc in mới đúng với thực tế xưởng.
        ///
        /// Payload không khớp thẻ nào -> để nguyên default(DateTime) và NULL;
        /// AddAsync hiểu default là "không biết" và rơi về SYSDATETIME().
        ///
        /// CHỈ áp cho luồng tạo tay. Luồng Foss đi qua CreateFromFossAsync ->
        /// FossPalletMapper, lấy DATEINSERT của TBLPRODUCT_* và KHÔNG gọi hàm này —
        /// ở đó raw_payload đang bằng SERIAL_OUTER nên tra part_cards sẽ khớp nhầm.
        /// </summary>
        private async Task ApplyPartCardsAsync(List<Box> boxes)
        {
            var payloads = boxes
                .Select(b => b.RawPayload)
                .Where(p => !string.IsNullOrWhiteSpace(p))
                .Select(p => p!)
                .Distinct(StringComparer.Ordinal)
                .ToList();

            if (payloads.Count == 0) return;

            var cards = await _repo.GetPartCardsByPayloadAsync(payloads);
            if (cards.Count == 0) return;

            foreach (var box in boxes)
            {
                if (box.RawPayload is null) continue;
                if (!cards.TryGetValue(box.RawPayload, out var card)) continue;

                box.CreatedAt = card.CreatedAt;
                box.LotName = card.LotName;
                box.OQCStatus = card.OqcStatus;

                // Line cùng thẻ -> cùng mốc. Đồng bộ với luồng Foss, nơi line lấy
                // DATEINSERT của chính serial đó.
                foreach (var line in box.Lines) line.CreatedAt = card.CreatedAt;
            }
        }

        // ── pallet_id: <category:3><yymmdd:6><seq:3> ─────────────────────
        private async Task<string> ValidateLotNoAsync(string lotNo, int categoryCode)
        {
            lotNo = (lotNo ?? "").Trim();

            if (lotNo.Length != 12 || !lotNo.All(char.IsAsciiDigit))
                throw new BusinessRuleException(_localizer["Lot.LotNoInvalidFormat", lotNo]);

            // 3 ký tự đầu phải trùng categoryCode để mã không mâu thuẫn với dữ liệu.
            if (lotNo[..3] != categoryCode.ToString("D3"))
                throw new BusinessRuleException(
                    _localizer["Lot.LotNoCategoryMismatch", lotNo[..3], categoryCode]);

            // Chống trùng ở tầng app cho thông báo đẹp; DB vẫn có unique index
            // ux_lots_pallet_id_active làm chốt chặn cuối khi 2 request vào cùng lúc.
            if (await _repo.ExistsLotNoAsync(lotNo))
                throw new ConflictException(_localizer["Lot.LotNoDuplicated", lotNo]);

            return lotNo;
        }

        // ── Validate hình dạng theo detail_level ──────────────────────
        private void ValidateShape(CreatePalletRequest r, PalletDetailLevel level, PalletType lotType)
        {
            ValidateStockyCode(r, lotType);

            switch (level)
            {
                // Chỉ biết số box
                case PalletDetailLevel.BoxCount:
                    if (r.BoxCount is null or < 1)
                        throw new BusinessRuleException(_localizer["Lot.BoxCountRequired"]);
                    if (r.Boxes is { Count: > 0 })
                        throw new BusinessRuleException(_localizer["Lot.BoxesNotAllowedForBoxCount"]);
                    break;

                // Pallet → box → serial
                case PalletDetailLevel.Serial:
                    RequireBoxes(r);
                    foreach (var line in r.Boxes!.SelectMany(b => b.Lines))
                    {
                        if (string.IsNullOrWhiteSpace(line.SerialNo))
                            throw new BusinessRuleException(_localizer["Lot.SerialNoRequired"]);
                    }
                    // Qty không validate: server ép = 1 khi build.
                    EnsureSerialsUnique(r.Boxes!);
                    break;

                // Pallet → box → model (có/không inner carton), không serial
                case PalletDetailLevel.BoxLine:
                    RequireBoxes(r);
                    EnsurePayloadsUniqueInRequest(r.Boxes!);
                    foreach (var line in r.Boxes!.SelectMany(b => b.Lines))
                    {
                        if (!string.IsNullOrWhiteSpace(line.SerialNo))
                            throw new BusinessRuleException(_localizer["Lot.SerialNotAllowed"]);

                        if (line.Qty is null or < 1)
                            throw new BusinessRuleException(_localizer["Lot.QtyRequired"]);

                        // Inner carton chỉ để khai hải quan, không tạo entity.
                        // cartonCount = SỐ LƯỢNG carton -> qty phải chia hết cho nó.
                        if (line.CartonCount is int cc && line.Qty.Value % cc != 0)
                            throw new BusinessRuleException(
                                _localizer["Lot.QtyNotDivisibleByCartonCount", line.Qty.Value, cc]);
                    }
                    break;

                default:
                    throw new BusinessRuleException(_localizer["Lot.DetailLevelInvalid", level]);
            }
        }

        private static readonly string[] ValidInspectionStatuses =
            ["not_required", "pending", "in_progress", "passed", "failed"];

        private void ValidateStockyCode(CreatePalletRequest r, PalletType lotType)
        {
            // Giá trị lotType đã được LotTypeConverter chặn từ lúc deserialize,
            // ở đây chỉ còn kiểm tra ràng buộc đi kèm.
            var hasStockyCode = !string.IsNullOrWhiteSpace(r.StockyCode);

            if (lotType == PalletType.Stocky && !hasStockyCode)
                throw new BusinessRuleException(_localizer["Lot.StockyCodeRequired"]);

            if (lotType != PalletType.Stocky && hasStockyCode)
                throw new BusinessRuleException(
                    _localizer["Lot.StockyCodeNotAllowed", lotType.ToDbValue()]);
        }

        private void ValidateInspectionStatus(string? status)
        {
            if (status is not null && !ValidInspectionStatuses.Contains(status))
                throw new BusinessRuleException(_localizer["Lot.InspectionStatusInvalid", status]);
        }

        private void RequireBoxes(CreatePalletRequest r)
        {
            if (r.Boxes is null || r.Boxes.Count == 0)
                throw new BusinessRuleException(_localizer["Lot.BoxesRequired"]);

            var dupBoxNo = r.Boxes.GroupBy(b => b.BoxNo.Trim(), StringComparer.OrdinalIgnoreCase)
                                  .FirstOrDefault(g => g.Count() > 1);
            if (dupBoxNo is not null)
                throw new ConflictException(_localizer["Lot.BoxNoDuplicated", dupBoxNo.Key]);

            // PartCard.models rỗng → reject
            if (r.Boxes.Any(b => b.Lines.Count == 0))
                throw new BusinessRuleException(_localizer["Lot.BoxLinesRequired"]);
        }

        private void EnsureSerialsUnique(List<CreateBoxRequest> boxes)
        {
            // Kiểm tra trong phạm vi CẢ LOT: cùng 1 serial không thể nằm ở 2 thùng
            // trên cùng pallet. (Unique index của DB chỉ ràng buộc trong 1 box.)
            var dup = boxes.SelectMany(b => b.Lines)
                           .GroupBy(l => l.SerialNo!.Trim(), StringComparer.OrdinalIgnoreCase)
                           .FirstOrDefault(g => g.Count() > 1);
            if (dup is not null)
                throw new ConflictException(_localizer["Lot.SerialDuplicated", dup.Key]);
        }

        // ── Chống trùng raw_payload (BoxLine) ────────────────────────
        // So khớp Ordinal, nguyên văn — cùng quy ước với ApplyPartCardsAsync
        // (raw_payload lưu nguyên văn, không parse). Box không có payload thì bỏ qua.
        private void EnsurePayloadsUniqueInRequest(List<CreateBoxRequest> boxes)
        {
            var dup = boxes
                .Where(b => !string.IsNullOrWhiteSpace(b.RawPayload))
                .GroupBy(b => b.RawPayload!, StringComparer.Ordinal)
                .FirstOrDefault(g => g.Count() > 1);

            if (dup is not null)
                throw new ConflictException(_localizer["Lot.BoxPayloadDuplicated", dup.Key]);
        }

        private async Task EnsurePayloadsNotUsedAsync(List<Box> boxes)
        {
            var payloads = boxes
                .Select(b => b.RawPayload)
                .Where(p => !string.IsNullOrWhiteSpace(p))
                .Select(p => p!)
                .Distinct(StringComparer.Ordinal)
                .ToList();

            if (payloads.Count == 0) return;

            var existing = await _repo.GetActivePalletsByBoxPayloadAsync(payloads);
            if (existing.Count > 0)
                throw PayloadExistsError(existing);
        }

        /// <summary>Báo thẻ đầu tiên bị trùng kèm pallet đang giữ nó.</summary>
        private ConflictException PayloadExistsError(IReadOnlyDictionary<string, string> existing)
        {
            var (payload, palletId) = existing.First();
            return new ConflictException(
                _localizer["Lot.BoxPayloadExists", payload, palletId, existing.Count]);
        }

        // ── Build ─────────────────────────────────────────────────────
        private List<Box> BuildBoxes(CreatePalletRequest r, PalletDetailLevel level)
        {
            if (r.Boxes is null || r.Boxes.Count == 0) return [];

            var isSerial = level == PalletDetailLevel.Serial;

            return r.Boxes.Select(b =>
            {
                // Client gửi productionDate cho box thì tôn trọng;
                // không gửi thì lấy MIN của các line (FIFO).
                var boxDate = b.ProductionDate ?? b.Lines.Min(l => l.ProductionDate);

                return new Box
                {
                    BoxNo = b.BoxNo.Trim(),
                    PsnvPo = b.PsnvPo?.Trim(),
                    CustomerPo = b.CustomerPo?.Trim(),
                    ProductionDate = boxDate,
                    RawPayload = b.RawPayload,          // lưu nguyên văn, không parse
                    CreatedBy = _currentUser.FullName,
                    Lines = b.Lines.Select(l => new BoxLine
                    {
                        Model = l.Model.Trim(),
                        Qty = isSerial ? 1 : l.Qty!.Value,   // serial: server ép = 1
                        SerialNo = l.SerialNo?.Trim(),
                        ProductionDate = l.ProductionDate ?? boxDate,
                        CartonCount = isSerial ? null : l.CartonCount,
                        CreatedBy = _currentUser.FullName
                    }).ToList()
                };
            }).ToList();
        }

        // ── Vị trí tạm (PDA): quét lot → gán / rời / chuyển ──────────

        // Trạng thái kiểm KHÔNG cho phép rời/out vị trí (đang trong quá trình kiểm OQC).
        // Trùng ý nghĩa với ReturnableStatuses ở vùng OQC, tách riêng để luồng vị trí
        // không phụ thuộc thứ tự khai báo / vùng code khác.
        private static readonly string[] UnderInspectionStatuses =
        [
            InspectionStatus.UnderInspection,
            InspectionStatus.PendingResult,
        ];

        /// <summary>
        /// Quét mã pallet. Thông tin lot + vị trí + tổng hợp model luôn được nạp;
        /// thùng / lịch sử chỉ nạp khi client yêu cầu qua include.
        /// </summary>
        public async Task<PalletDetailResponse> GetDetailByLotNoAsync(string lotNo, PalletInclude include)
        {
            lotNo = NormalizeLotNo(lotNo);

            var info = await _repo.GetLocationInfoByLotNoAsync(lotNo)
                       ?? throw new NotFoundException(_localizer["Lot.Err.LotNotFound"]);

            return await BuildDetailAsync(info, include);
        }

        /// <summary>
        /// Dựng response quét từ thông tin vị trí đã nạp sẵn. Public để các luồng đồng bộ
        /// (Foss / HD soft) trả đúng shape GET by-lot-no mà không phải đọc lại pallet.
        /// </summary>
        public async Task<PalletDetailResponse> BuildDetailAsync(
            PalletLocationInfo info, PalletInclude include)
        {
            // Tổng hợp model gộp bằng SQL — rẻ và dùng chung cho mọi màn,
            // không cần nạp toàn bộ box/line chỉ để cộng qty.
            var modelQtys = await _repo.GetModelQtysByLotIdAsync(info.Id);

            var full = include.HasFlag(PalletInclude.Boxes)
                ? await _repo.GetByLotNoAsync(info.LotNo)
                : null;

            // Lịch sử RÚT GỌN: 4 trường, 10 dòng gần nhất. Đây là phần kèm khi quét
            // trên PDA chứ không phải màn lịch sử — pallet nằm kho 6 tháng mà trả
            // hết event thì vừa nặng vừa không ai đọc. Đầy đủ: /history.
            IReadOnlyList<PalletEventBrief>? history = include.HasFlag(PalletInclude.History)
                ? await _eventRepo.GetPalletEventsBriefAsync(info.LotNo, BriefHistoryCount)
                : null;

            return PalletDetailResponse.From(info, modelQtys, full, history);
        }

        private string NormalizeLotNo(string? lotNo) => PalletLotNo.Normalize(lotNo, _localizer);

        /// <summary>
        /// Mục đích của thao tác đặt pallet vào vị trí. Quyết định tiền điều kiện
        /// và mã lỗi; phần ghi dữ liệu là như nhau.
        ///
        /// LƯU Ý: MoveIntent KHÔNG còn tham gia quyết định event code. Event suy
        /// từ map_type nguồn/đích (ResolveMoveEvent) vì kết quả vật lý mới là thứ
        /// lịch sử phải ghi: pallet gán vào khu storing qua màn Chuyển vị trí
        /// (AssignLocatorAsync, allowedMapType = null) giống hệt lưu kho, chỉ
        /// khác đường vào.
        /// </summary>
        private enum MoveIntent
        {
            /// <summary>Gán / chuyển vị trí tạm (#27 · #28).</summary>
            TempLocation,
            /// <summary>Lưu kho — putaway (FR-STR-04).</summary>
            Storing,
        }

        public Task<LocatorChangeResponse> AssignLocatorAsync(
            long lotId, string locatorCode, string? allowedMapType = null)
            => MoveToLocatorAsync(lotId, locatorCode, MoveIntent.TempLocation, allowedMapType);

        public Task<LocatorChangeResponse> StoreAsync(long lotId, string locatorCode)
            => MoveToLocatorAsync(lotId, locatorCode, MoveIntent.Storing, MapTypes.Storing);

        /// <summary>
        /// Đặt pallet vào vị trí <paramref name="locatorCode"/>.
        /// Gán vị trí tạm và lưu kho dùng chung thân này — chỉ khác tiền điều kiện
        /// và mã lỗi. Giữ hai endpoint riêng vì hai màn PDA dùng hai quyền khác nhau.
        /// </summary>
        private async Task<LocatorChangeResponse> MoveToLocatorAsync(
            long lotId, string locatorCode, MoveIntent intent, string? allowedMapType = null,
            IntegrationSyncContext? sync = null, object? extra = null)
        {
            var storing = intent == MoveIntent.Storing;

            locatorCode = (locatorCode ?? "").Trim();
            if (locatorCode.Length == 0)
                throw new BusinessRuleException(_localizer[
                    storing ? "Lot.Storing.LocatorCodeRequired" : "Lot.LocatorCodeRequired"]);

            var lot = await _repo.GetLocationInfoByIdAsync(lotId)
                      ?? throw new NotFoundException(_localizer["Lot.NotFound"]);

            // Lưu kho đòi pallet đang ở khu vị trí tạm; gán/chuyển vị trí tạm thì không.
            if (storing) EnsureStorable(lot);

            var locator = await _repo.GetLocatorByCodeAsync(locatorCode)
                          ?? throw new NotFoundException(_localizer["Lot.LocatorNotFound"]);

            // Màn nào chỉ được gán vào loại bản đồ của màn đó (null = không giới hạn).
            EnsureLocatorMapType(locator, allowedMapType);

            // Đã đứng đúng vị trí đó rồi -> vô nghĩa.
            if (lot.LocatorId == locator.Id)
                throw new BusinessRuleException(_localizer[
                    storing ? "Lot.Storing.AlreadyAtLocator" : "Lot.SameLocator"]);

            var fromId = lot.LocatorId;
            var fromCode = lot.LocatorCode;

            // ── Hàng tái gia công ra khỏi kho = giao cho FA ───────────────
            //
            // Out hàng khỏi kho rồi đặt pallet vào một vị trí thuộc bản đồ Nhận
            // hàng CHÍNH LÀ hành động giao hàng cho FA (nghiệp vụ chốt 11/11).
            // Nên cổng duyệt của quản lý SCS phải đứng ở đây, trong luồng chuyển
            // vị trí, chứ không ở một API giao hàng riêng — còn API riêng thì
            // còn đường giao hàng không đi qua vị trí kho và lọt cổng duyệt.
            //
            // ĐIỀU KIỆN LÀ "OUT KHO", tức TỪ khu lưu trữ SANG khu nhận hàng —
            // không phải mọi lượt chuyển vào khu nhận hàng. Khác biệt này quan
            // trọng, bắt sai là chặn đúng những bước không liên quan:
            //
            //   • Mục 2a: WH tạo pallet xong GÁN nó vào một vị trí ở khu nhận
            //     hàng (from = null). Bắt theo đích thì bước này bị chặn vì
            //     phiếu chưa ai duyệt — nhận hàng của khách đứng luôn.
            //   • Xếp lại trong khu nhận hàng (receiving → receiving) chỉ là dồn
            //     chỗ, không ai giao gì cho ai.
            //
            // Cả hai trường hợp đó pallet KHÔNG rời kho, nên không phải giao hàng.
            //
            // VÀ CHỈ KHI NGƯỜI THẬT BẤM (sync == null). Job đồng bộ HD soft cũng
            // đi qua hàm này (AssignLocatorBySyncAsync) và có thể đẩy pallet về
            // vị trí tạm theo số tồn bên HD soft. Đó là HD soft kể lại vị trí nó
            // đang thấy, KHÔNG phải WH quyết định giao hàng cho FA — tính nó là
            // giao hàng thì serial sang at_fa và phiếu tự đóng vì một lượt đồng
            // bộ. Đổi lại, một lượt đồng bộ như vậy không ghi sổ giao hàng; đây
            // là đánh đổi có chủ ý.
            var outOfStorage =
                sync is null
                && string.Equals(lot.MapType, MapTypes.Storing, StringComparison.OrdinalIgnoreCase)
                && string.Equals(locator.MapType, MapTypes.Receiving, StringComparison.OrdinalIgnoreCase);

            // Pallet thường và pallet đã giao rồi: gate trả null, mọi thứ y như cũ.
            ReturnBackMove? back = outOfStorage
                ? await _backGate.CheckDeliverableAsync(lotId)
                : null;

            var eventCode = ResolveMoveEvent(
                lot.MapType, lot.AreaCode, locator.MapType, locator.AreaCode);

            var ctx = sync?.ToEventContext(eventCode, extra)
                ?? new StockEventContext(eventCode, _currentUser.FullName);

            var actor = ctx.Actor ?? "";

            // Giao cho FA thì pallet mang trạng thái NG ngay tại vị trí nhận
            // hàng — cùng một câu UPDATE với việc đổi vị trí.
            //
            // Pallet hàng return vốn đã được đóng dấu 'ng' từ lúc tạo, nên dòng
            // này gần như luôn ghi lại đúng giá trị cũ. Giữ lại có chủ ý: dữ
            // liệu tạo TRƯỚC 11/11 đang mang 'inspection_exempt', và đây là chỗ
            // duy nhất chắc chắn đi qua trước khi hàng ra khỏi kho.
            string? newInspection = null;
            Func<System.Data.IDbConnection, System.Data.IDbTransaction, long, Task>? onMoved = null;

            // `is { } deliver` để biến bắt vào lambda là non-null: truyền thẳng
            // `back` vào tham số ReturnBackMove sẽ là CS8604.
            if (back is { } deliver)
            {
                newInspection = InspectionStatus.Ng;
                onMoved = (conn, tx, id) => _backGate.MarkDeliveredAsync(
                    conn, tx, deliver, id, lot.LotNo, actor);
            }

            await _repo.ChangeLocatorAsync(
                lotId, locator.Id, actor, ctx, newInspection, onMoved);

            // Vị trí đích đã có lot khác -> VẪN CHO, chỉ cảnh báo.
            string? warning = locator.CurrentLotCount > 0
                ? string.Format(_localizer["Lot.LocatorOccupied"],
                                locator.LocatorCode, locator.CurrentLotCount)
                : null;

            return new LocatorChangeResponse(
                lot.Id, lot.LotNo,
                fromId, fromCode,
                locator.Id, locator.LocatorCode,
                warning);
        }

        public Task<LocatorChangeResponse> ReleaseLocatorAsync(long lotId)
          => ReleaseLocatorCoreAsync(lotId, null, null);

        // ── Vị trí — gọi từ luồng đồng bộ (Foss / HD soft) ───────────

        /// <summary>
        /// Gán / chuyển vị trí theo hệ thống ngoài: không giới hạn map_type, không đòi điều kiện
        /// lưu kho. Event mang source / actor của lần đồng bộ, payload kèm <paramref name="extra"/>.
        /// </summary>
        public Task<LocatorChangeResponse> AssignLocatorBySyncAsync(
            long lotId, string locatorCode, IntegrationSyncContext sync, object? extra = null)
            => MoveToLocatorAsync(lotId, locatorCode, MoveIntent.TempLocation, null, sync, extra);

        /// <summary>Rời vị trí theo hệ thống ngoài. Vẫn chặn khi đang kiểm OQC như thao tác tay.</summary>
        public Task<LocatorChangeResponse> ReleaseLocatorBySyncAsync(
            long lotId, IntegrationSyncContext sync, object? extra = null)
            => ReleaseLocatorCoreAsync(lotId, sync, extra);


        /// <summary>
        /// Rời vị trí. <paramref name="sync"/> != null khi gọi từ luồng đồng bộ (HD soft):
        /// event mang source/actor của lần đồng bộ và payload có startedAt + durationMs
        /// + <paramref name="extra"/>. Null = thao tác tay từ Web/PDA, giữ hành vi cũ.
        /// </summary>
        private async Task<LocatorChangeResponse> ReleaseLocatorCoreAsync(
            long lotId, IntegrationSyncContext? sync, object? extra)
        {
            var lot = await _repo.GetLocationInfoByIdAsync(lotId)
                      ?? throw new NotFoundException(_localizer["Lot.NotFound"]);

            if (lot.LocatorId is null)
                throw new BusinessRuleException(_localizer["Lot.HasNoLocator"]);

            // "Out vị trí" gỡ pallet khỏi kho — không được rời khi lot đang trong
            // quá trình kiểm OQC (đang giữ mẫu chưa trả), tránh mất dấu vị trí của
            // hàng còn phải trả mẫu. Chặn theo cả trạng thái kiểm lẫn số mẫu đang giữ.
            // Cho phép Out ở mọi khu (RECEIVING / STORAGE / VANNING) — không lọc theo AreaCode.
            if (UnderInspectionStatuses.Contains(lot.InspectionStatus))
                throw new BusinessRuleException(
                    _localizer["Lot.Locator.UnderInspection", lot.LotNo, lot.InspectionStatus]);

            var fromId = lot.LocatorId;
            var fromCode = lot.LocatorCode;

            // Rời vị trí -> event gọi tên theo khu NGUỒN.
            var eventCode = ResolveMoveEvent(lot.MapType, lot.AreaCode, null, null);

            var ctx = sync?.ToEventContext(eventCode, extra)
                      ?? new StockEventContext(eventCode, _currentUser.FullName);

            await _repo.ChangeLocatorAsync(
                lotId, null, ctx.Actor ?? _currentUser.FullName ?? "", ctx);

            return new LocatorChangeResponse(
                lot.Id, lot.LotNo,
                fromId, fromCode,
                null, null,
                null);
        }

        /// <summary>
        /// Suy event code từ map_type nguồn/đích. <paramref name="toMapType"/> null
        /// nghĩa là rời vị trí.
        ///
        /// Quy tắc đặt tên: IN/MOVED gọi theo khu ĐÍCH, OUT gọi theo khu NGUỒN —
        /// nhìn nhãn là biết pallet đang ở đâu, không phải đọc thêm locatorCode.
        ///
        /// Dùng map_type chứ KHÔNG dùng AreaCode: một map_type có nhiều khu
        /// (storing: STORAGE, FA, JUPITER, MCS...) — xem EnsureLocatorMapType và
        /// EnsureStorable. AreaCode chỉ để phân biệt chuyển kho với chuyển vị trí
        /// trong cùng kho.
        /// </summary>
        private static string ResolveMoveEvent(
            string? fromMapType, string? fromAreaCode,
            string? toMapType, string? toAreaCode)
        {
            var from = (fromMapType ?? "").Trim().ToLowerInvariant();
            var to = (toMapType ?? "").Trim().ToLowerInvariant();

            // Rời vị trí -> gọi tên theo khu NGUỒN.
            if (to.Length == 0)
                return from switch
                {
                    MapTypes.Receiving => StockEventCodes.ReceivingOut,
                    MapTypes.Storing => StockEventCodes.StorageOut,
                    MapTypes.Vanning => StockEventCodes.VanningOut,
                    _ => StockEventCodes.ReceivingOut,
                };

            // Cùng loại bản đồ -> di chuyển nội bộ.
            if (from == to)
                return to switch
                {
                    MapTypes.Receiving => StockEventCodes.ReceivingMoved,
                    MapTypes.Vanning => StockEventCodes.VanningMoved,
                    // Cùng map_type storing nhưng khác kho (STORAGE -> FA) = chuyển kho.
                    MapTypes.Storing => string.Equals(fromAreaCode, toAreaCode, StringComparison.OrdinalIgnoreCase)
                                            ? StockEventCodes.StorageMoved
                                            : StockEventCodes.StorageTransferred,
                    _ => StockEventCodes.StorageMoved,
                };

            // Khác loại -> gọi tên theo khu ĐÍCH.
            return to switch
            {
                MapTypes.Receiving => StockEventCodes.ReceivingIn,
                MapTypes.Storing => StockEventCodes.StorageIn,
                MapTypes.Vanning => StockEventCodes.VanningIn,
                _ => StockEventCodes.StorageIn,
            };
        }

        // ── Tách pallet ──────────────────────────────────────────────

        public Task<SplitPalletResponse> SplitAsync(SplitPalletRequest req)
            => SplitInternalAsync(req);
        // Block catch(Exception) cũ bọc "[SPLIT] {detail}" ĐÃ GỠ (comment trong code
        // gốc ghi "TẠM: gỡ sau khi xong"). Nó nuốt mọi lỗi kỹ thuật vào
        // BusinessRuleException — kể cả lỗi ghi event trong transaction — khiến lỗi
        // hạ tầng trông như lỗi nghiệp vụ. Lỗi thật giờ đi lên middleware xử lý lỗi
        // chung và được Serilog ghi đầy đủ stack trace.

        /// <summary>
        /// Giá trị detail_level của pallet "chỉ biết số thùng". Lấy từ chính bảng
        /// quy đổi của enum thay vì gõ chuỗi, để đổi một chỗ là đổi cả hệ.
        /// </summary>
        private static readonly string DetailLevelBoxCount =
            PalletDetailLevel.BoxCount.ToDbValue();

        private async Task<SplitPalletResponse> SplitInternalAsync(SplitPalletRequest req)
        {
            var user = _currentUser.FullName ?? "";

            // Validate đầu vào.
            var sourceLotNo = (req.SourceLotNo ?? "").Trim();
            if (sourceLotNo.Length == 0)
                throw new BusinessRuleException(_localizer["Split.SourceRequired"]);

            // Lot gốc. Phải đọc TRƯỚC khi kiểm BoxIds: cách tách do detail_level
            // của chính pallet quyết định, không phải do client gửi gì lên.
            var source = await _repo.GetSplitLotInfoAsync(sourceLotNo)
                ?? throw new NotFoundException(_localizer["Lot.NotFound", sourceLotNo]);
            if (source.IsDeleted)
                throw new BusinessRuleException(_localizer["Split.SourceDeleted"]);

            // Pallet box_count chỉ biết CÓ BAO NHIÊU thùng, không có dòng nào
            // trong wms.boxes — không thể quét, nên tách theo số lượng.
            var byQty = string.Equals(source.DetailLevel, DetailLevelBoxCount,
                                      StringComparison.OrdinalIgnoreCase);

            var qty = 0;
            if (byQty)
            {
                qty = req.BoxQty ?? 0;
                if (qty <= 0)
                    throw new BusinessRuleException(_localizer["Split.QtyRequired"]);
                if (qty > source.BoxCount)
                    throw new BusinessRuleException(
                        _localizer["Split.QtyExceeds", source.BoxCount]);
                if (qty == source.BoxCount)
                    throw new BusinessRuleException(_localizer["Split.QtyAll"]);
            }
            else
            {
                if (req.BoxIds is null || req.BoxIds.Count == 0)
                    throw new BusinessRuleException(_localizer["Split.NoBoxSelected"]);

                // Box phải thuộc đúng lot gốc.
                var validCount = await _repo.CountBoxesInLotAsync(source.Id, req.BoxIds);
                if (validCount != req.BoxIds.Count)
                    throw new BusinessRuleException(_localizer["Split.BoxNotInSource"]);
            }

            if (req.TargetType == SplitTargetType.Existing)
            {
                // Tách sang lot đã có.
                var targetLotNoInput = (req.TargetLotNo ?? "").Trim();
                if (targetLotNoInput.Length == 0)
                    throw new BusinessRuleException(_localizer["Split.TargetRequired"]);
                if (string.Equals(targetLotNoInput, sourceLotNo, StringComparison.OrdinalIgnoreCase))
                    throw new BusinessRuleException(_localizer["Split.TargetSameAsSource"]);

                var target = await _repo.GetSplitLotInfoAsync(targetLotNoInput)
                    ?? throw new NotFoundException(_localizer["Lot.NotFound", targetLotNoInput]);
                if (target.IsDeleted)
                    throw new BusinessRuleException(_localizer["Split.TargetDeleted"]);
                if (target.CategoryId != source.CategoryId)
                    throw new BusinessRuleException(_localizer["Split.CategoryMismatch"]);

                // Chỉ gộp vào pallet cùng cấp chi tiết: box serial sang pallet box_line
                // (hoặc ngược lại) làm pallet đích lẫn 2 kiểu dữ liệu, tổng qty / hiển thị
                // thùng tính theo detail_level sẽ sai.
                if (!string.Equals(target.DetailLevel, source.DetailLevel, StringComparison.OrdinalIgnoreCase))
                    throw new BusinessRuleException(_localizer[
                        "Split.DetailLevelMismatch",
                        target.LotNo,
                        target.DetailLevel ?? "?",
                        source.DetailLevel ?? "?"]);

                // Pallet đích đơn model → chỉ nhận box cùng model đó. Đích rỗng hoặc
                // đã đa model thì cho gộp.
                //
                // Pallet box_count không có dòng box nào để tra model, nên so
                // model ghi thẳng trên pallet. Dùng GetSplitModelCheckAsync với
                // danh sách box rỗng sẽ ra "không có model lạ" và lọt hết.
                //
                // Khác model KHÔNG còn là chặn cứng: PDA hiện cảnh báo cho người
                // vận hành xác nhận rồi gửi lại với ConfirmModelMismatch = true.
                // Chưa xác nhận thì vẫn ném Split.ModelMismatch y như trước, nên
                // client cũ và mọi caller khác không đổi hành vi.
                // Khác CATEGORY vẫn chặn cứng ở trên, không có đường bỏ qua.
                IReadOnlyList<string> movedModels = [];
                IReadOnlyList<string> targetModels = [];

                if (byQty)
                {
                    // box_count: CHỈ cho gộp khi CÙNG model.
                    //
                    // Trước đây chỉ chặn khi cả hai bên đều có model và khác nhau,
                    // nên một bên để trống là lọt. Với box_count thì cột
                    // pallets.model là bản ghi model DUY NHẤT (không có box_lines),
                    // nên gộp vào pallet không rõ model đúng là trường hợp làm sai
                    // dữ liệu lặng lẽ nhất. Trống coi như bằng trống: hai pallet
                    // đều chưa khai model thì gộp không làm mất thêm thông tin nào.
                    var sm = (source.Model ?? "").Trim();
                    var tm = (target.Model ?? "").Trim();
                    if (!string.Equals(sm, tm, StringComparison.OrdinalIgnoreCase))
                    {
                        // Thay rỗng bằng gạch ngang để câu lỗi còn đọc được.
                        movedModels = [sm.Length > 0 ? sm : "—"];
                        targetModels = [tm.Length > 0 ? tm : "—"];
                    }
                }
                else
                {
                    var modelCheck = await _repo.GetSplitModelCheckAsync(target.Id, req.BoxIds);
                    if (modelCheck.ForeignModels.Count > 0)
                    {
                        // ForeignModels chỉ khác rỗng khi TargetModels có đúng 1 phần tử.
                        movedModels = modelCheck.ForeignModels;
                        targetModels = modelCheck.TargetModels;
                    }
                }

                // CHỈ pallet serial / box_line được phép xác nhận gộp khác model.
                //
                // box_count KHÔNG được, dù client có gửi cờ: model của loại này
                // chỉ nằm ở cột wms.pallets.model và KHÔNG có gì cập nhật nó khi
                // gộp (SplitExecuteParams.NewModel chưa từng được repository đọc,
                // và không có câu UPDATE ... SET model nào ở nhánh gộp). Thêm nữa
                // TotalQty của box_count = box_count * standard_packing của ĐÍCH.
                // Cho qua sẽ ra pallet khai sai model VÀ sai tổng số lượng — sai
                // lặng lẽ, không ai thấy. Thà chặn.
                var canConfirmMismatch = !byQty;

                string? splitNote = null;
                string? splitPayload = null;

                if (movedModels.Count > 0)
                {
                    var movedText = string.Join(", ", movedModels);
                    var targetText = string.Join(", ", targetModels);

                    if (!req.ConfirmModelMismatch || !canConfirmMismatch)
                        throw new BusinessRuleException(_localizer[
                            "Split.ModelMismatch",
                            target.LotNo,
                            targetModels.Count > 0 ? targetModels[0] : "?",
                            movedText]);

                    // Đã xác nhận -> cho gộp, nhưng phải để lại dấu vết: ai xác
                    // nhận (actor của event) và model nào đã trộn vào pallet nào.
                    splitNote = Truncate(
                        _localizer["Split.ModelOverrideNote", movedText, target.LotNo, targetText].Value,
                        EventNoteMaxLength);
                    splitPayload = BuildModelOverridePayload(movedModels, targetModels);
                }

                var execExisting = new SplitExecuteParams
                {
                    SourceLotId = source.Id,
                    BoxIds = byQty ? [] : req.BoxIds,
                    BoxQty = qty,
                    TargetLotId = target.Id,
                    CreateNew = false,
                    NewModel = source.Model,
                    User = user,
                    EventNote = splitNote,
                    EventPayload = splitPayload,
                };
                var (moved, remaining) = byQty
                    ? await _repo.ExecuteSplitByQtyAsync(execExisting)
                    : await _repo.ExecuteSplitAsync(execExisting);
                return new SplitPalletResponse(source.LotNo, remaining, target.LotNo, false, moved);
            }
            else
            {
                // Tách sang lot mới: sinh pallet_id cùng category + ngày SX lot gốc, unit +1.
                var prodDate = source.ProductionDate ?? DateTime.Today;
                var prefix = $"{source.CategoryId:D3}{prodDate:yyMMdd}";
                var maxSeq = await _repo.GetMaxSequenceAsync(prefix);
                var newLotNo = $"{prefix}{(maxSeq + 1):D3}";

                var execNew = new SplitExecuteParams
                {
                    SourceLotId = source.Id,
                    BoxIds = byQty ? [] : req.BoxIds,
                    BoxQty = qty,
                    CreateNew = true,
                    NewLotNo = newLotNo,
                    NewCategoryId = source.CategoryId,
                    NewModel = source.Model,
                    NewProductionDate = prodDate,
                    InspectionStatus = source.InspectionStatus,
                    User = user,
                };
                var (moved, remaining) = byQty
                    ? await _repo.ExecuteSplitByQtyAsync(execNew)
                    : await _repo.ExecuteSplitAsync(execNew);
                return new SplitPalletResponse(source.LotNo, remaining, newLotNo, true, moved);
            }
        }

        /// <summary>Độ dài cột wms.stock_events.note.</summary>
        private const int EventNoteMaxLength = 500;

        private static string? Truncate(string? value, int max)
            => value is null || value.Length <= max ? value : value[..max];

        /// <summary>
        /// JSON kèm event khi người dùng xác nhận tách khác model. Dùng
        /// JsonSerializer chứ không nội suy chuỗi: mã model do dữ liệu quyết
        /// định, có ký tự cần escape là payload hỏng và vỡ CHECK ISJSON.
        ///
        /// Lọc được bằng:
        ///   WHERE JSON_VALUE(payload, '$.modelOverride') = 'true'
        /// </summary>
        private static string BuildModelOverridePayload(
            IReadOnlyList<string> movedModels, IReadOnlyList<string> targetModels)
            => System.Text.Json.JsonSerializer.Serialize(new
            {
                modelOverride = true,
                movedModels,
                targetModels,
            });

        /// <summary>Chặn gán vào vị trí thuộc loại bản đồ khác với màn đang thao tác.</summary>
        private void EnsureLocatorMapType(LocatorBrief locator, string? allowedMapType)
        {
            if (string.IsNullOrWhiteSpace(allowedMapType)) return;

            var actual = (locator.MapType ?? "").Trim().ToLowerInvariant();
            if (actual == allowedMapType.Trim().ToLowerInvariant()) return;

            throw new BusinessRuleException(string.Format(
                _localizer["Lot.LocatorWrongMapType"],
                locator.LocatorCode,
                locator.AreaName ?? locator.AreaCode ?? "?"));
        }

        /// <summary>
        /// Điều kiện để được lưu kho. So theo LOẠI bản đồ (map_type) chứ không theo mã khu,
        /// vì mỗi loại có thể có nhiều bản đồ (storing: STORAGE, FA, JUPITER, MCS...).
        /// </summary>
        private void EnsureStorable(PalletLocationInfo lot)
        {
            // Pallet chưa qua khu vực nhận hàng.
            if (lot.AreaCode is null)
                throw new BusinessRuleException(_localizer["Lot.Storing.PalletNotInTemporaryArea"]);

            var mapType = (lot.MapType ?? "").Trim().ToLowerInvariant();

            // Đã nằm trong một kho lưu trữ bất kỳ -> dùng chức năng chuyển vị trí.
            if (mapType == MapTypes.Storing)
                throw new BusinessRuleException(_localizer["Lot.Storing.PalletAlreadyStored"]);

            // Đã sang khu đóng container -> dùng chức năng hoàn hàng.
            if (mapType == MapTypes.Vanning)
                throw new BusinessRuleException(_localizer["Lot.Storing.PalletAlreadyInVanning"]);
        }
    }
}
