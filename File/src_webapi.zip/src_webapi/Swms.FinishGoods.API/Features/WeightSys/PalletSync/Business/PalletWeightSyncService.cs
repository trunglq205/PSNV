using Swms.FinishGoods.API.Features.Foss.DataAccess;
using Swms.FinishGoods.API.Features.WeightSys.Business;
using Swms.FinishGoods.API.Features.WeightSys.PalletSync.DataAccess;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.WeightSys.PalletSync.Business;

public class PalletWeightSyncService : IPalletWeightSyncService
{
    private readonly IPalletWeightRepository _repo;
    private readonly IWeightSysService _weightSysService;
    private readonly ICurrentUser _currentUser;

    public PalletWeightSyncService(
        IPalletWeightRepository repo,
        IWeightSysService weightSysService,
        ICurrentUser currentUser)
    {
        _repo = repo;
        _weightSysService = weightSysService;
        _currentUser = currentUser;
    }

    public async Task<int> SyncBoxWeightAsync(string palletId)
    {
        var serialsResponse = await _repo.GetSerialForWeightSyncAsync(palletId);

        if (serialsResponse.Count == 0)
            return 0;

        var model = serialsResponse.First().Model;

        var serials = serialsResponse
            .Select(x => x.Serial)
            .Where(x => !string.IsNullOrWhiteSpace(x))
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (palletId.Length < 3 || !int.TryParse(palletId[..3], out var categoryCode) || !Enum.IsDefined(typeof(FossCategory), categoryCode))
        {
            throw new ArgumentException($"Unsupported pallet id: {palletId}");
        }

        var category = (FossCategory)categoryCode;

        var weights = await _weightSysService.GetSerialWeightAsync(category, model, serials);

        var weightByBox = serialsResponse
            .Join(
                weights,
                x => x.Serial,
                x => x.Serial,
                (box, weight) => new
                {
                    box.BoxId,
                    Weight = weight.Weight
                })
            .GroupBy(x => x.BoxId)
            .ToDictionary(
                g => g.Key,
                g => g.Sum(x => x.Weight) / 1000m);

        if (weightByBox.Count == 0)
            return 0;

        return await _repo.UpdateBoxWeightsAsync(
            weightByBox,
            _currentUser.FullName);
    }
}