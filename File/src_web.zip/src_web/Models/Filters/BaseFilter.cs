﻿namespace SWMS_WebTool.Models
{
    public abstract class BaseFilter
	{
		public BaseFilter()
		{
		}
	}
}

