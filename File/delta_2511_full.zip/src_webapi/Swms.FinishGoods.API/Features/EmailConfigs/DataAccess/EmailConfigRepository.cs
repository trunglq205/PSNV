using Dapper;
using Swms.FinishGoods.API.Features.EmailConfigs.Api;
using Swms.FinishGoods.API.Shared.DataAccess.ConnectionFactory;

namespace Swms.FinishGoods.API.Features.EmailConfigs.DataAccess;

public class EmailEventRow
{
    public string Code { get; set; } = "";
    public string Module { get; set; } = "";
    public string NameKey { get; set; } = "";
    public string? Description { get; set; }
    public string? SubjectTemplate { get; set; }
    public string? BodyTemplate { get; set; }
    public DateTime? UpdatedAt { get; set; }
    public string? UpdatedBy { get; set; }
}

public class EmailSubtypeRow
{
    public string EventCode { get; set; } = "";
    public string SubCode { get; set; } = "";
    public string NameKey { get; set; } = "";
    public string Severity { get; set; } = "info";
}

public class EmailConfigRow
{
    public long Id { get; set; }
    public string EventCode { get; set; } = "";
    public string? Department { get; set; }
    public string? SubCode { get; set; }
    public string? Category { get; set; }
    public string? Model { get; set; }
    public string? AreaCode { get; set; }
    public string RecipientType { get; set; } = "TO";
    public long? UserId { get; set; }
    public string? Email { get; set; }          // user_id: lấy từ master.users
    public string? DisplayName { get; set; }
    public bool IsActive { get; set; }
}

public interface IEmailConfigRepository
{
    Task<List<EmailEventRow>> GetEventsAsync(string? module);
    Task<EmailEventRow?> GetEventAsync(string code);
    Task<List<EmailSubtypeRow>> GetSubtypesAsync(string eventCode);
    Task<List<string>> GetUsedDepartmentsAsync();
    Task<List<EmailCategoryOption>> GetCategoryOptionsAsync();
    Task<bool> SaveTemplateAsync(string code, string subject, string? body, string? actor);

    Task<List<EmailConfigRow>> GetConfigsAsync(string eventCode);
    Task<EmailConfigRow?> GetConfigAsync(long id);
    Task<bool> ScopeExistsAsync(SaveEmailConfigRequest r, long? excludeId);
    Task<bool> UserExistsAsync(long userId);
    Task<long> AddConfigAsync(SaveEmailConfigRequest r, string? actor);
    Task<bool> UpdateConfigAsync(long id, SaveEmailConfigRequest r, string? actor);
    Task<bool> SoftDeleteConfigAsync(long id, string? actor);

    Task<List<EmailRecipientResponse>> ResolveAsync(
        string eventCode, string? department, string? subCode, string? category, string? model, string? areaCode);
}

public class EmailConfigRepository : IEmailConfigRepository
{
    private readonly IDbConnectionFactory _factory;
    public EmailConfigRepository(IDbConnectionFactory factory) => _factory = factory;

    public async Task<List<EmailEventRow>> GetEventsAsync(string? module)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT code AS Code, module AS Module, name_key AS NameKey, description AS Description,
                   subject_template AS SubjectTemplate, body_template AS BodyTemplate,
                   updated_at AS UpdatedAt, updated_by AS UpdatedBy
            FROM master.email_events
            WHERE is_active = 1 AND (@module IS NULL OR module = @module)
            ORDER BY sort_order, code;
            """;
        return (await conn.QueryAsync<EmailEventRow>(sql, new { module })).ToList();
    }

    public async Task<EmailEventRow?> GetEventAsync(string code)
        => (await GetEventsAsync(null)).FirstOrDefault(e => e.Code == code);

    public async Task<List<EmailSubtypeRow>> GetSubtypesAsync(string eventCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT event_code AS EventCode, sub_code AS SubCode, name_key AS NameKey, severity AS Severity
            FROM master.email_event_subtypes
            WHERE event_code = @eventCode AND is_active = 1
            ORDER BY sort_order, sub_code;
            """;
        return (await conn.QueryAsync<EmailSubtypeRow>(sql, new { eventCode })).ToList();
    }

    /// <summary>
    /// Bộ phận ĐANG ĐƯỢC DÙNG, đọc từ chính dữ liệu cấu hình chứ không từ một
    /// danh sách trong code. Cùng nguồn với câu tra người nhận, nên thứ màn
    /// hình gợi ý đúng bằng thứ hệ thống thật sự định tuyến theo.
    /// </summary>
    public async Task<List<string>> GetUsedDepartmentsAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT DISTINCT department
            FROM   master.email_config
            WHERE  is_deleted = 0
              AND  department IS NOT NULL
              AND  LTRIM(RTRIM(department)) <> N''
            ORDER  BY department;
            """;
        return (await conn.QueryAsync<string>(sql)).ToList();
    }

    /// <summary>Danh mục hàng để gợi ý cho ô Danh mục.</summary>
    public async Task<List<EmailCategoryOption>> GetCategoryOptionsAsync()
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT CAST(code AS nvarchar(20)) AS Code, name AS Name
            FROM   master.categories
            WHERE  is_deleted = 0
            ORDER  BY code;
            """;
        return (await conn.QueryAsync<EmailCategoryOption>(sql)).ToList();
    }

    public async Task<bool> SaveTemplateAsync(string code, string subject, string? body, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.email_events
            SET subject_template = @subject, body_template = @body,
                updated_at = SYSDATETIME(), updated_by = @actor
            WHERE code = @code;
            """;
        return await conn.ExecuteAsync(sql, new { code, subject, body, actor }) > 0;
    }

    private const string ConfigSelect = """
        SELECT c.id AS Id, c.event_code AS EventCode, c.department AS Department, c.sub_code AS SubCode,
               c.category AS Category, c.model AS Model, c.area_code AS AreaCode,
               c.recipient_type AS RecipientType, c.user_id AS UserId,
               COALESCE(c.email, u.email) AS Email,
               COALESCE(c.display_name, u.full_name) AS DisplayName,
               c.is_active AS IsActive
        FROM master.email_config c
        LEFT JOIN master.users u ON u.id = c.user_id
        WHERE c.is_deleted = 0
        """;

    public async Task<List<EmailConfigRow>> GetConfigsAsync(string eventCode)
    {
        using var conn = _factory.Create();
        // TO trước, rồi cấu hình hẹp trước rộng — cùng thứ tự người đọc cần
        var sql = $"""
            {ConfigSelect} AND c.event_code = @eventCode
            ORDER BY CASE c.recipient_type WHEN N'TO' THEN 0 WHEN N'CC' THEN 1 ELSE 2 END,
                     CASE WHEN c.model IS NOT NULL THEN 16 ELSE 0 END + CASE WHEN c.sub_code IS NOT NULL THEN 8 ELSE 0 END
                   + CASE WHEN c.category IS NOT NULL THEN 4 ELSE 0 END + CASE WHEN c.area_code IS NOT NULL THEN 2 ELSE 0 END
                   + CASE WHEN c.department IS NOT NULL THEN 1 ELSE 0 END DESC,
                     c.id;
            """;
        return (await conn.QueryAsync<EmailConfigRow>(sql, new { eventCode })).ToList();
    }

    public async Task<EmailConfigRow?> GetConfigAsync(long id)
    {
        using var conn = _factory.Create();
        return await conn.QueryFirstOrDefaultAsync<EmailConfigRow>($"{ConfigSelect} AND c.id = @id;", new { id });
    }

    // Khớp UX_email_config_scope — báo trùng rõ ràng thay vì để SQL ném lỗi unique
    public async Task<bool> ScopeExistsAsync(SaveEmailConfigRequest r, long? excludeId)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT COUNT(1) FROM master.email_config
            WHERE is_deleted = 0 AND event_code = @EventCode AND recipient_type = @RecipientType
              AND ISNULL(department, N'') = ISNULL(@Department, N'')
              AND ISNULL(sub_code,   N'') = ISNULL(@SubCode, N'')
              AND ISNULL(category,   N'') = ISNULL(@Category, N'')
              AND ISNULL(model,      N'') = ISNULL(@Model, N'')
              AND ISNULL(area_code,  N'') = ISNULL(@AreaCode, N'')
              AND ((@UserId IS NOT NULL AND user_id = @UserId)
                OR (@UserId IS NULL AND email = @Email))
              AND (@excludeId IS NULL OR id <> @excludeId);
            """;
        return await conn.ExecuteScalarAsync<int>(sql, new
        {
            r.EventCode, r.RecipientType, r.Department, r.SubCode, r.Category, r.Model, r.AreaCode,
            r.UserId, r.Email, excludeId,
        }) > 0;
    }

    public async Task<bool> UserExistsAsync(long userId)
    {
        using var conn = _factory.Create();
        return await conn.ExecuteScalarAsync<int>(
            "SELECT COUNT(1) FROM master.users WHERE id = @userId AND is_deleted = 0;", new { userId }) > 0;
    }

    public async Task<long> AddConfigAsync(SaveEmailConfigRequest r, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            INSERT INTO master.email_config
                (event_code, department, sub_code, category, model, area_code, recipient_type,
                 user_id, email, display_name, is_active, is_deleted, created_at, created_by)
            VALUES
                (@EventCode, @Department, @SubCode, @Category, @Model, @AreaCode, @RecipientType,
                 @UserId, @Email, @DisplayName, @IsActive, 0, SYSDATETIME(), @actor);
            SELECT CAST(SCOPE_IDENTITY() AS bigint);
            """;
        return await conn.ExecuteScalarAsync<long>(sql, new
        {
            r.EventCode, r.Department, r.SubCode, r.Category, r.Model, r.AreaCode, r.RecipientType,
            r.UserId, Email = r.UserId is null ? r.Email : null, r.DisplayName, r.IsActive, actor,
        });
    }

    public async Task<bool> UpdateConfigAsync(long id, SaveEmailConfigRequest r, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.email_config
            SET department = @Department, sub_code = @SubCode, category = @Category, model = @Model,
                area_code = @AreaCode, recipient_type = @RecipientType,
                user_id = @UserId, email = @Email, display_name = @DisplayName, is_active = @IsActive,
                updated_at = SYSDATETIME(), updated_by = @actor
            WHERE id = @id AND is_deleted = 0;
            """;
        return await conn.ExecuteAsync(sql, new
        {
            id, r.Department, r.SubCode, r.Category, r.Model, r.AreaCode, r.RecipientType,
            r.UserId, Email = r.UserId is null ? r.Email : null, r.DisplayName, r.IsActive, actor,
        }) > 0;
    }

    public async Task<bool> SoftDeleteConfigAsync(long id, string? actor)
    {
        using var conn = _factory.Create();
        const string sql = """
            UPDATE master.email_config
            SET is_deleted = 1, updated_at = SYSDATETIME(), updated_by = @actor
            WHERE id = @id AND is_deleted = 0;
            """;
        return await conn.ExecuteAsync(sql, new { id, actor }) > 0;
    }

    public async Task<List<EmailRecipientResponse>> ResolveAsync(
        string eventCode, string? department, string? subCode, string? category, string? model, string? areaCode)
    {
        using var conn = _factory.Create();
        const string sql = """
            SELECT recipient_type AS Type, email AS Email, display_name AS DisplayName
            FROM master.fn_email_recipients(@eventCode, @department, @subCode, @category, @model, @areaCode)
            ORDER BY CASE recipient_type WHEN N'TO' THEN 0 WHEN N'CC' THEN 1 ELSE 2 END, email;
            """;
        var rows = await conn.QueryAsync<(string Type, string Email, string? DisplayName)>(
            sql, new { eventCode, department, subCode, category, model, areaCode });
        return rows.Select(r => new EmailRecipientResponse(r.Type, r.Email, r.DisplayName)).ToList();
    }
}
