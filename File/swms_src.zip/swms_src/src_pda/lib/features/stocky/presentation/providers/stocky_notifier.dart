import 'package:riverpod_annotation/riverpod_annotation.dart';
import 'package:swms_finish_goods/core/errors/exceptions.dart';
import 'package:swms_finish_goods/core/notifier/base_notifier_mixin.dart';
import 'package:swms_finish_goods/features/stocky/domain/entities/stocky_entities.dart';
import 'package:swms_finish_goods/features/stocky/domain/repositories/stocky_repository.dart';
import 'package:swms_finish_goods/features/stocky/presentation/providers/stocky_providers.dart';
import 'package:swms_finish_goods/features/stocky/presentation/providers/stocky_state.dart';
import 'package:swms_finish_goods/shared/presentation/providers/app_action_provider.dart';

part 'stocky_notifier.g.dart';

@riverpod
class StockyNotifier extends _$StockyNotifier with BaseNotifierMixin<StockyState> {
  StockyRepository get _repo => ref.read(stockyRepositoryProvider);

  /// Tăng mỗi lần đổi tab / gửi xong → kết quả tra về muộn của tab cũ bị bỏ,
  /// không lọt xe "nhập" sang danh sách "xuất".
  int _seq = 0;

  @override
  StockyState build() => const StockyState();

  /// Đổi tab = đổi chiều nhập / xuất → bỏ danh sách. UI hỏi trước nếu có xe.
  void setMode(StockyMode mode) {
    if (state.mode == mode || state.submitting) return;
    _seq++;
    state = StockyState(mode: mode);
  }

  // ── Quét ───────────────────────────────────────────────────
  Future<void> onScan(String raw) async {
    final code = raw.trim().toUpperCase();
    if (code.isEmpty || state.busy) return;

    final seq = _seq;
    state = state.copyWith(lookingUp: true);

    final cart = await ref.read(appActionProvider.notifier).run(() async {
      if (state.contains(code)) throw StockyDuplicateException(code);
      return _repo.lookup(code: code, mode: state.mode);
    });

    if (seq != _seq) return;
    state = state.copyWith(
      lookingUp: false,
      // Kiểm trùng lần nữa sau await: server có thể chuẩn hoá mã.
      carts: cart == null || state.contains(cart.code)
          ? null
          : [cart, ...state.carts],
    );
  }

  void remove(String code) {
    if (state.submitting) return;
    state = state.copyWith(
      carts: state.carts.where((c) => c.code != code).toList(),
    );
  }

  // ── Chốt ───────────────────────────────────────────────────
  /// Trả kết quả khi xong (đã xoá danh sách, giữ tab); `null` khi lỗi —
  /// appActionProvider đã báo, danh sách được GIỮ để bấm lại.
  Future<StockySubmitResult?> submit() async {
    if (!state.canSubmit) return null;

    state = state.copyWith(submitting: true);
    final result = await ref.read(appActionProvider.notifier).run(
          () => _repo.submit(
            mode: state.mode,
            codes: state.carts.map((c) => c.code).toList(),
          ),
        );

    if (result == null) {
      state = state.copyWith(submitting: false);
      return null;
    }
    _seq++;
    state = StockyState(mode: state.mode);
    return result;
  }
}
