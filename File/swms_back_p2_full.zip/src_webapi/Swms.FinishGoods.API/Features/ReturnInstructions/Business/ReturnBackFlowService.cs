using System.Text;
using Microsoft.Extensions.Localization;
using Swms.FinishGoods.API.Common.Business.Exceptions;
using Swms.FinishGoods.API.Features.ReturnInstructions.Api;
using Swms.FinishGoods.API.Features.ReturnInstructions.DataAccess;
using Swms.FinishGoods.API.Resource;
using Swms.FinishGoods.API.Shared.Business.Mail;
using Swms.FinishGoods.API.Shared.DataAccess;

namespace Swms.FinishGoods.API.Features.ReturnInstructions.Business;

/// <summary>
/// Mục 2c — luồng nhận lại hàng về FA, treo trên chính phiếu chỉ thị.
///
/// Vì sao điều kiện bước nằm ở DB chứ không kiểm trong code rồi mới ghi: mọi
/// câu UPDATE của repository đã mang theo điều kiện "đang ở đúng bước", nên hai
/// người bấm cùng lúc thì người sau cập nhật 0 dòng và nhận
/// <see cref="ConflictException"/>, chứ không phải cả hai cùng ghi. Service chỉ
/// dịch "0 dòng" thành câu thông báo đúng cho người dùng.
/// </summary>
public class ReturnBackFlowService : IReturnBackFlowService
{
    // ─────────────────────────────────────────────────────────────
    //  ĐÚNG HAI LÁ MAIL — đúng hai chỗ hàng đổi tay giữa hai bộ phận.
    //
    //  B1 (FA đề nghị) KHÔNG gửi mail: quản lý FA ngồi cùng bộ phận, mở màn
    //  hình ra là thấy hàng đợi. Giữa B2 và B3 cũng không có mail cho SCS WH —
    //  SCS Office tự thông báo cho kho.
    //
    //  Người nhận khai riêng từng sự kiện trong master.email_config; sự kiện
    //  nào không có dòng TO đang bật thì SmtpMailSender coi là không có người
    //  nhận và không gửi. Muốn tắt một lá thì để trống người nhận, không phải
    //  sửa code.
    //
    //  Giữ KHỚP với return_back_merge_schema.sql và với ReturnMailConfigDialog
    //  bên Web (ReturnMailEvents.BackFaApproved).
    //
    //  CÒN ĐÚNG MỘT lá (10/11). RETURN_BACK_DELIVERED đã bỏ cùng lúc với việc
    //  thêm bước quản lý SCS xác nhận: duyệt xong là hai bên đã biết, nên lá
    //  thư lúc hàng rời kho không nói thêm được gì. Sự kiện cũng bị xoá khỏi
    //  master.email_events trong return_back_phase2_schema.sql — khai lại hằng
    //  ở đây là dựng lại một lá thư không có mẫu để gửi.
    // ─────────────────────────────────────────────────────────────
    private const string MailBackApproved = "RETURN_BACK_FA_APPROVED";

    /// <summary>
    /// Trần số pallet một lượt quét. Thực tế một chuyến xe vài pallet; đặt trần
    /// để một request hỏng không mở hàng nghìn vòng lặp trong một transaction.
    /// </summary>
    private const int MaxLotsPerDelivery = 100;

    /// <summary>Pallet ID là 12 ký tự; để rộng cho mã tay và mã cũ.</summary>
    private const int MaxLotLength = 30;

    private const int MaxNoteLength = 500;

    /// <summary>Bằng <c>wms.return_back_lines.model NVARCHAR(100)</c>.</summary>
    private const int MaxModelLength = 100;

    private readonly IReturnBackFlowRepository _repo;
    private readonly IReturnInstructionRepository _docs;
    private readonly ICurrentUser _currentUser;
    private readonly IStringLocalizer<SharedResource> _localizer;
    private readonly IMailSender _mail;
    private readonly ILogger<ReturnBackFlowService> _logger;
    private readonly string? _webBaseUrl;

    public ReturnBackFlowService(
        IReturnBackFlowRepository repo,
        IReturnInstructionRepository docs,
        ICurrentUser currentUser,
        IStringLocalizer<SharedResource> localizer,
        IMailSender mail,
        ILogger<ReturnBackFlowService> logger,
        IConfiguration config)
    {
        _repo = repo;
        _docs = docs;
        _currentUser = currentUser;
        _localizer = localizer;
        _mail = mail;
        _logger = logger;
        _webBaseUrl = config["Web:BaseUrl"]?.TrimEnd('/');
    }

    private string? Actor => _currentUser.FullName ?? _currentUser.EmployeeCode;

    // ───────────────────────────── Đọc ─────────────────────────────

    public async Task<IReadOnlyList<BackRemainModelResponse>> GetRemainAsync(long docId)
    {
        await RequireDocAsync(docId);
        return (await _repo.GetRemainByModelAsync(docId))
            .Select(BackRemainModelResponse.From).ToList();
    }

    public async Task<IReadOnlyList<BackDeliveryResponse>> GetDeliveriesAsync(long docId)
    {
        await RequireDocAsync(docId);
        return (await _repo.GetDeliveriesAsync(docId))
            .Select(BackDeliveryResponse.From).ToList();
    }

    // ───────────────────────────── Ghi ─────────────────────────────

    public async Task<BackFlowResponse> RequestAsync(long docId, RequestBackRequest request)
    {
        var doc = await RequireDocAsync(docId);

        // Kiểm trước CHỈ để chọn câu thông báo đúng. Chốt thật nằm trong câu
        // UPDATE của repository — ở đây mà quyết thì hai người bấm cùng lúc sẽ
        // cùng đi qua.
        if (doc.DocStatus == ReturnDocStatus.Cancelled)
            throw new BusinessRuleException(_localizer[BackMsg.DocCancelled, doc.DocNo]);

        if (doc.BackRemainQty == 0)
            throw new BusinessRuleException(_localizer[BackMsg.NothingAvailable, doc.DocNo]);

        if (doc.BackRequested && !doc.BackIsCancelled)
            throw new BusinessRuleException(_localizer[BackMsg.AlreadyRequested, doc.DocNo]);

        var lines = await BuildRequestLinesAsync(doc, request);

        if (!await _repo.RequestAsync(
                docId, Trim(request.Note, MaxNoteLength), lines, Actor))
            throw new ConflictException(_localizer[BackMsg.WrongStep]);

        // KHÔNG gửi mail ở bước này — quản lý FA cùng bộ phận, mở màn hình là thấy.
        return BackFlowResponse.From(await RequireDocAsync(docId));
    }

    /// <summary>
    /// Dựng và KIỂM dòng đề nghị (từ 10/11 FA xin được một phần).
    ///
    /// Trần của mỗi model là SL ĐANG CÒN Ở KHO, đếm từ sổ serial — không phải
    /// <c>return_instruction_lines.qty</c>: qty là số khách BÁO, còn thứ FA lấy
    /// được chỉ có thể là thứ thực sự đang nằm trong kho.
    ///
    /// Không gửi dòng nào = xin TOÀN BỘ phần còn ở kho. Giữ nghĩa này để màn
    /// hình cũ và mọi phiếu đề nghị trước 10/11 vẫn hiểu được, và vì "lấy hết"
    /// vẫn là trường hợp thường gặp nhất.
    /// </summary>
    private async Task<List<BackReqLine>> BuildRequestLinesAsync(
        ReturnInstruction doc, RequestBackRequest request)
    {
        if (request.Lines is null || request.Lines.Count == 0)
            return [];

        // SL CÒN Ở KHO theo model — đếm serial đang 'received'.
        //
        // KHÔNG dùng doc.Lines[].ReceivedQty: đó là tổng đã TỪNG nhận, nên sau
        // một lượt giao nó vẫn giữ nguyên và FA sẽ xin được cả phần đã đi khỏi
        // kho. Cũng không dùng return_instruction_lines.qty: đó là số khách BÁO.
        var remain = (await _repo.GetRemainByModelAsync(doc.Id))
            .ToDictionary(r => r.Model, r => r.Qty, StringComparer.OrdinalIgnoreCase);

        var seen = new HashSet<string>(StringComparer.OrdinalIgnoreCase);
        var outp = new List<BackReqLine>();

        foreach (var l in request.Lines)
        {
            var model = Trim(l.Model, MaxModelLength);
            if (string.IsNullOrWhiteSpace(model)) continue;

            // Bỏ hẳn dòng SL 0: FA không xin model đó, khác với "xin 0 con".
            if (l.ReqQty <= 0) continue;

            if (!seen.Add(model))
                throw new BusinessRuleException(_localizer[BackMsg.ModelDuplicated, model]);

            // Model không có trong phiếu thì không thể lấy về từ phiếu này.
            if (!remain.TryGetValue(model, out var max))
                throw new BusinessRuleException(
                    _localizer[BackMsg.ModelNotInDoc, model, doc.DocNo]);

            if (l.ReqQty > max)
                throw new BusinessRuleException(
                    _localizer[BackMsg.QtyOverRemain, model, l.ReqQty, max]);

            outp.Add(new BackReqLine { Model = model, ReqQty = l.ReqQty });
        }

        return outp;
    }

    public async Task<BackFlowResponse> ScsApproveAsync(
        long docId, BackDecisionRequest request)
    {
        var doc = await RequireDocAsync(docId);

        if (!doc.BackRequested)
            throw new BusinessRuleException(_localizer[BackMsg.NotRequested, doc.DocNo]);

        if (doc.BackStatus != ReturnBackStatus.FaApproved)
            throw new BusinessRuleException(_localizer[BackMsg.WrongStep]);

        if (!await _repo.ScsApproveAsync(docId, Trim(request.Comment, MaxNoteLength), Actor))
            throw new ConflictException(_localizer[BackMsg.WrongStep]);

        // KHÔNG mail. Lá mail lúc giao hàng đã bỏ (10/11) chính vì có bước này:
        // quản lý SCS duyệt xong thì SCS WH và FA đều đã biết qua màn hình, thêm
        // một lá thư nữa chỉ là thư không ai mở.
        return BackFlowResponse.From(await RequireDocAsync(docId));
    }

    public async Task<BackFlowResponse> UpdateNoteAsync(long docId, RequestBackRequest request)
    {
        var doc = await RequireDocAsync(docId);

        if (doc.BackStatus != ReturnBackStatus.FaRequested)
            throw new BusinessRuleException(_localizer[BackMsg.NotEditable, doc.DocNo]);

        if (!await _repo.UpdateNoteAsync(docId, Trim(request.Note, MaxNoteLength), Actor))
            throw new ConflictException(_localizer[BackMsg.WrongStep]);

        return BackFlowResponse.From(await RequireDocAsync(docId));
    }

    public async Task<BackFlowResponse> ApproveAsync(long docId, BackDecisionRequest request)
    {
        var doc = await RequireDocAsync(docId);

        if (!doc.BackRequested)
            throw new BusinessRuleException(_localizer[BackMsg.NotRequested, doc.DocNo]);

        if (doc.BackStatus != ReturnBackStatus.FaRequested)
            throw new BusinessRuleException(_localizer[BackMsg.WrongStep]);

        if (!await _repo.ApproveAsync(docId, Trim(request.Comment, MaxNoteLength), Actor))
            throw new ConflictException(_localizer[BackMsg.WrongStep]);

        // Đọc lại TRƯỚC khi gửi mail: lá thư mang mốc xác nhận và SL còn ở kho,
        // mà cả hai chỉ đúng sau khi đã ghi.
        var saved = await RequireDocAsync(docId);
        await NotifyAsync(MailBackApproved, saved, MarkdownMail.Blue);
        return BackFlowResponse.From(saved);
    }

    public async Task<BackDeliverResponse> DeliverAsync(long docId, DeliverBackRequest request)
    {
        var doc = await RequireDocAsync(docId);

        if (!doc.BackRequested)
            throw new BusinessRuleException(_localizer[BackMsg.NotRequested, doc.DocNo]);

        if (doc.BackIsDelivered)
            throw new BusinessRuleException(_localizer[BackMsg.AlreadyDelivered, doc.DocNo]);

        if (doc.BackStatus != ReturnBackStatus.FaApproved)
            throw new BusinessRuleException(_localizer[BackMsg.WrongStep]);

        // Chuẩn hoá ngay đầu vào: cắt khoảng trắng, bỏ ô rỗng, khử trùng không
        // phân biệt hoa thường. Quét hai lần cùng một pallet là chuyện thường ở
        // máy quét, và để trùng đi xuống thì nhật ký có hai dòng cho một pallet
        // với dòng thứ hai bằng 0 con.
        var lots = (request.LotNos ?? [])
            .Select(x => x?.Trim() ?? string.Empty)
            .Where(x => x.Length > 0)
            .Distinct(StringComparer.OrdinalIgnoreCase)
            .ToList();

        if (lots.Count == 0)
            throw new BusinessRuleException(_localizer[BackMsg.LotsRequired]);

        if (lots.Count > MaxLotsPerDelivery)
            throw new BusinessRuleException(_localizer[BackMsg.TooManyLots, MaxLotsPerDelivery]);

        foreach (var lot in lots)
            if (lot.Length > MaxLotLength)
                throw new BusinessRuleException(
                    _localizer[BackMsg.ValueTooLong, lot, MaxLotLength]);

        var result = await _repo.DeliverAsync(
            docId, lots, Trim(request.Comment, MaxNoteLength), Actor);

        if (result.NotFound)
            throw new NotFoundException(_localizer[BackMsg.DocNotFound, docId]);

        if (result.WrongStep)
            throw new ConflictException(_localizer[BackMsg.WrongStep]);

        // KHÔNG chuyển được con nào, VÀ mọi mã đều không tìm thấy ⇒ quét sai
        // hết, báo lỗi để WH quét lại. Còn nếu mã có thật mà pallet rỗng thì
        // KHÔNG lỗi: đó là thông tin, và nhật ký đã ghi lượt quét đó.
        if (!result.AnyMoved && result.NotFoundLots.Count == lots.Count)
            throw new BusinessRuleException(
                _localizer[BackMsg.LotNotFound, string.Join(", ", result.NotFoundLots)]);

        if (!result.AnyMoved && result.NotFoundLots.Count == 0)
            throw new BusinessRuleException(_localizer[BackMsg.NothingToDeliver, doc.DocNo]);

        var saved = await RequireDocAsync(docId);

        // KHÔNG mail ở bước này (bỏ 10/11).
        //
        // Trước đây lượt giao làm xong cả phiếu sẽ bắn một lá báo FA. Nay luồng
        // có thêm bước quản lý SCS xác nhận ở TRƯỚC khi giao, nên lúc hàng rời
        // kho thì cả FA lẫn SCS đều đã biết qua màn hình — lá thư này không nói
        // thêm được gì. Sự kiện RETURN_BACK_DELIVERED bị xoá khỏi
        // master.email_events trong return_back_phase2_schema.sql, nên để lại
        // lời gọi ở đây cũng chỉ là một lượt tra bảng rỗng mỗi lượt giao.
        return BackDeliverResponse.From(result, saved);
    }

    public async Task<BackFlowResponse> CancelAsync(long docId, BackDecisionRequest request)
    {
        var doc = await RequireDocAsync(docId);

        if (!doc.BackRequested)
            throw new BusinessRuleException(_localizer[BackMsg.NotRequested, doc.DocNo]);

        if (doc.BackIsDelivered)
            throw new BusinessRuleException(_localizer[BackMsg.AlreadyDelivered, doc.DocNo]);

        if (doc.BackIsCancelled)
            throw new BusinessRuleException(_localizer[BackMsg.WrongStep]);

        // Đã giao được con nào thì KHÔNG huỷ: hàng ở FA rồi, huỷ là để lại một
        // lô hàng ở FA mà không có đề nghị nào đứng tên. Muốn đóng thì giao hết
        // rồi cho FA trả lại theo luồng nhận lại hàng.
        if (doc.BackIsPartlyDelivered)
            throw new BusinessRuleException(
                _localizer[BackMsg.PartlyDelivered, doc.DocNo, doc.BackSentQty]);

        if (!await _repo.CancelAsync(docId, Trim(request.Comment, MaxNoteLength), Actor))
            throw new ConflictException(_localizer[BackMsg.WrongStep]);

        return BackFlowResponse.From(await RequireDocAsync(docId));
    }

    // ───────────────────────────── Dùng chung ─────────────────────────────

    /// <summary>
    /// Nạp phiếu kèm bốn con số của luồng back, hoặc 404.
    ///
    /// Đi qua <see cref="IReturnInstructionRepository"/> chứ không tự truy vấn:
    /// ở đó mới có đủ dòng model + bốn con số đếm từ sổ serial, và hai chỗ cùng
    /// đếm một thứ là hai chỗ sớm muộn đếm khác nhau.
    /// </summary>
    private async Task<ReturnInstruction> RequireDocAsync(long docId)
        => await _docs.GetByIdAsync(docId)
           ?? throw new NotFoundException(_localizer[BackMsg.DocNotFound, docId]);

    private static string? Trim(string? s, int max)
    {
        if (string.IsNullOrWhiteSpace(s)) return null;
        var t = s.Trim();
        return t.Length <= max ? t : t[..max];
    }

    // ───────────────────────────── Mail ─────────────────────────────

    /// <summary>
    /// Gửi một lá mail của luồng 2c.
    ///
    /// NUỐT MỌI LỖI: việc nghiệp vụ ĐÃ ghi xong trước khi gọi tới đây, mail
    /// hỏng không được phép làm đổ nó — người dùng đã bấm xác nhận, bắt họ bấm
    /// lại vì SMTP chết là ghi hai lần.
    ///
    /// KHÔNG đóng dấu "đã gửi" vào DB như mục 2a/2b: hai mốc đã có
    /// (<c>back_approved_at</c>, <c>back_delivered_at</c>) đã trả lời được "đến
    /// bước này chưa". Thêm cột chỉ để ghi một việc không ai tra là nợ.
    /// </summary>
    private async Task NotifyAsync(
        string eventCode, ReturnInstruction doc, string accent,
        ReturnBackDeliverResult? justDelivered = null)
    {
        try
        {
            var tpl = await _docs.GetMailTemplateAsync(eventCode);
            if (tpl is null)
            {
                _logger.LogWarning(
                    "Chua khai su kien mail {Event} trong master.email_events — "
                    + "khong gui mail cho phieu {DocNo}.", eventCode, doc.DocNo);
                return;
            }

            var recipients = await _docs.GetMailRecipientsAsync(eventCode);
            if (recipients.Count == 0)
            {
                // Không phải lỗi: để trống người nhận CHÍNH LÀ cách tắt một lá
                // mail mà không sửa code. Vẫn ghi log để người ta tra ra vì sao
                // thư không tới.
                _logger.LogInformation(
                    "Su kien {Event} chua khai nguoi nhan trong master.email_config — "
                    + "bo qua mail cho phieu {DocNo}.", eventCode, doc.DocNo);
                return;
            }

            // Bảng model chỉ nạp khi mẫu thật sự dùng tới: lá B3 không có
            // {LinesTable}, nạp sẵn là một câu SQL cho không ai đọc.
            var needLines =
                (tpl.Subject?.Contains("{LinesTable}", StringComparison.Ordinal) ?? false)
                || (tpl.Body?.Contains("{LinesTable}", StringComparison.Ordinal) ?? false);
            var remain = needLines
                ? await _repo.GetRemainByModelAsync(doc.Id)
                : (IReadOnlyList<BackModelQty>)[];

            var replyTo = await _docs.GetUserEmailAsync(_currentUser.EmployeeCode);

            // Mẫu viết bằng MARKDOWN -> dựng HTML có khung (MarkdownMail, dùng
            // chung cả hệ thống). Phải đi qua đây mới khớp phần XEM TRƯỚC bên
            // Web — xem trước cũng render markdown.
            var subject = Fill(tpl.Subject, doc, FillMode.Plain, justDelivered, remain).Trim();
            await _mail.SendAsync(
                recipients, subject,
                MarkdownMail.Render(
                    subject,
                    Fill(tpl.Body, doc, FillMode.Markdown, justDelivered, remain),
                    accent),
                Actor, replyTo);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex,
                "Loi khi gui mail {Event} cho phieu {DocNo} — viec nghiep vu VAN da ghi xong.",
                eventCode, doc.DocNo);
        }
    }

    /// <summary>Cách thoát giá trị khi điền vào mẫu.</summary>
    private enum FillMode
    {
        /// <summary>Tiêu đề mail: chữ thuần, không thoát gì.</summary>
        Plain,

        /// <summary>
        /// Thân mail markdown: thoát ký tự markdown để "*" hay "#" trong ghi chú
        /// hiện y nguyên, và "|" trong ghi chú không cắt ô bảng làm hai.
        /// </summary>
        Markdown,
    }

    /// <summary>
    /// Điền mẫu mail. Mẫu viết bằng MARKDOWN — đúng quy ước của hệ thống, để màn
    /// Cấu hình email xem trước ra đúng lá mail sẽ gửi. Vì vậy chữ người dùng
    /// nhập thoát bằng <see cref="MarkdownMail.Escape"/> chứ KHÔNG phải
    /// HtmlEncode: thân mail không còn là HTML gõ tay, mà HtmlEncode trong
    /// markdown sẽ hiện ra "&amp;amp;" cho người đọc thấy.
    ///
    /// Dùng CHUNG cho cả hai mẫu: <c>Replace</c> một placeholder không có trong
    /// mẫu là không làm gì, nên mỗi mẫu chỉ nhận đúng phần nó khai.
    ///
    /// <paramref name="dl"/> là kết quả LƯỢT GIAO vừa xong, chỉ có ở lá
    /// RETURN_BACK_DELIVERED. Không có nó thì biến của lượt giao lấy số của cả
    /// phiếu — mẫu khai sai chỗ vẫn ra số đọc được, không ra chuỗi rỗng.
    /// </summary>
    private string Fill(string? template, ReturnInstruction doc, FillMode mode,
                        ReturnBackDeliverResult? dl = null,
                        IReadOnlyList<BackModelQty>? remain = null)
    {
        if (string.IsNullOrWhiteSpace(template)) return string.Empty;

        var link = template.Contains("{Link}", StringComparison.Ordinal)
            ? BuildLink(doc) : string.Empty;
        var table = template.Contains("{LinesTable}", StringComparison.Ordinal)
            ? BuildLinesTable(remain) : string.Empty;
        var pallets = template.Contains("{PalletTable}", StringComparison.Ordinal)
            ? BuildPalletTable(dl) : string.Empty;

        Func<string?, string> enc = mode == FillMode.Markdown
            ? MarkdownMail.Escape
            : v => v ?? string.Empty;

        // GIỮ KHỚP danh sách biến với ReturnMailConfigDialog bên Web (BackVars).
        // Link KHÔNG thoát markdown — thoát làm hỏng địa chỉ.
        return template
            .Replace("{Link}", link)
            .Replace("{LinesTable}", table)
            .Replace("{PalletTable}", pallets)
            .Replace("{DocNo}", enc(doc.DocNo))
            .Replace("{GoodsType}", GoodsTypeLabel(doc.GoodsType))
            .Replace("{Customer}", enc(doc.Customer))
            .Replace("{ModelCount}", doc.ModelCount.ToString())
            .Replace("{TotalQty}", doc.TotalQty.ToString("N0"))
            .Replace("{ReceivedQty}", doc.ReceivedQty.ToString("N0"))
            // SL giao LƯỢT NÀY. Khác {SentQty} là tổng đã từng giao của cả phiếu.
            .Replace("{DeliveredQty}", (dl?.DeliveredQty ?? doc.BackSentQty).ToString("N0"))
            .Replace("{PalletCount}",
                     (dl?.Pallets.Count(p => p.SerialCount > 0) ?? 0).ToString())
            .Replace("{SentQty}", doc.BackSentQty.ToString("N0"))
            .Replace("{AtFaQty}", doc.AtFaQty.ToString("N0"))
            .Replace("{RemainQty}", (dl?.RemainQty ?? doc.BackRemainQty).ToString("N0"))
            .Replace("{BackNote}", enc(doc.BackNote))
            .Replace("{RequestedBy}", enc(doc.BackRequestedBy))
            .Replace("{RequestedAt}", Dt(doc.BackRequestedAt))
            .Replace("{ApprovedBy}", enc(doc.BackApprovedBy))
            .Replace("{ApprovedAt}", Dt(doc.BackApprovedAt))
            .Replace("{FaComment}", enc(doc.BackFaComment))
            .Replace("{DeliveredBy}", enc(doc.BackDeliveredBy ?? Actor))
            .Replace("{DeliveredAt}", Dt(doc.BackDeliveredAt ?? DateTime.Now))
            .Replace("{ScsComment}", enc(doc.BackScsComment))
            .Replace("{Now}", Dt(DateTime.Now));
    }

    /// <summary>
    /// Bảng model + SL trong thân mail, dạng bảng pipe của markdown. Dựng ở code
    /// chứ không nhét vào mẫu: số dòng thay đổi theo từng phiếu, mẫu trong DB
    /// không lặp được.
    ///
    /// Mở đầu VÀ kết thúc bằng một dòng trắng: mẫu do người dùng soạn, viết
    /// "Chi tiết:" rồi {LinesTable} ngay dòng dưới thì bảng nằm chung đoạn văn
    /// và markdown không nhận ra nó là bảng; thiếu dòng trắng ở cuối thì dòng
    /// chữ ngay sau bị hút vào bảng thành một ô.
    ///
    /// Cột SL là SỐ CÒN Ở KHO, đếm từ sổ serial theo model — không phải SL
    /// khách báo trên dòng chỉ thị. Lá thư này nói về phần hàng SCS phải đẩy
    /// sang FA, mà số khách báo thì không trả lời được câu đó.
    /// </summary>
    private static string BuildLinesTable(IReadOnlyList<BackModelQty>? remain)
    {
        var rows = remain ?? [];
        if (rows.Count == 0) return "\n\n";

        var sb = new StringBuilder("\n\n");
        sb.Append("| # | Model | SL còn ở kho |\n|--:|---|--:|\n");

        var i = 0;
        foreach (var r in rows)
            sb.Append("| ").Append(++i)
              .Append(" | ").Append(MarkdownMail.Escape(r.Model))
              .Append(" | ").Append(r.Qty.ToString("N0"))
              .Append(" |\n");

        sb.Append("| | **Tổng** | **")
          .Append(rows.Sum(x => x.Qty).ToString("N0")).Append("** |\n");

        return sb.Append('\n').ToString();
    }

    /// <summary>
    /// Bảng pallet đã giao trong LƯỢT NÀY — thứ FA cần để đi nhận đúng pallet.
    ///
    /// Bỏ qua pallet chuyển được 0 con: nhật ký vẫn ghi để tra, nhưng in vào mail
    /// một dòng "pallet này không có gì" chỉ làm FA đi tìm vô ích.
    ///
    /// Không có dòng nào thì trả hai dòng trắng, KHÔNG trả chuỗi rỗng: mẫu viết
    /// {PalletTable} giữa hai đoạn văn, cắt sạch đi thì hai đoạn dính thành một.
    /// </summary>
    private static string BuildPalletTable(ReturnBackDeliverResult? dl)
    {
        var rows = dl?.Pallets.Where(p => p.SerialCount > 0).ToList() ?? [];
        if (rows.Count == 0) return "\n\n";

        var sb = new StringBuilder("\n\n");
        sb.Append("| # | Pallet ID | SL |\n|--:|---|--:|\n");

        var i = 0;
        foreach (var r in rows)
            sb.Append("| ").Append(++i)
              .Append(" | ").Append(MarkdownMail.Escape(r.LotNo))
              .Append(" | ").Append(r.SerialCount.ToString("N0"))
              .Append(" |\n");

        return sb.Append('\n').ToString();
    }

    private static string Dt(DateTime? v) => v?.ToString("dd/MM/yyyy HH:mm") ?? string.Empty;

    /// <summary>
    /// Nhãn loại hàng trong mail. Để nguyên tiếng Anh, KHÔNG qua localizer: mail
    /// gửi cho cả FA lẫn SCS và không có ngôn ngữ của người nhận — dịch theo
    /// ngôn ngữ của người BẤM là tuỳ tiện.
    /// </summary>
    private static string GoodsTypeLabel(string? goodsType) =>
        goodsType == ReturnGoodsType.Rework ? "Rework"
        : goodsType == ReturnGoodsType.Refurbish ? "Refurbish"
        : string.Empty;

    /// <summary>
    /// Link mở màn Tái gia công, lọc sẵn theo SỐ PHIẾU: người nhận hiểu vì sao
    /// danh sách chỉ còn một dòng, và số phiếu là thứ người ta nhắc lại cho nhau
    /// được qua điện thoại.
    /// </summary>
    private string BuildLink(ReturnInstruction doc)
    {
        if (string.IsNullOrWhiteSpace(_webBaseUrl))
        {
            _logger.LogWarning(
                "Chua khai Web:BaseUrl trong appsettings — mail phieu {DocNo} se khong co link.",
                doc.DocNo);
            return string.Empty;
        }
        return $"{_webBaseUrl}/rework-refurbish?docNo={Uri.EscapeDataString(doc.DocNo)}";
    }
}
