using Microsoft.AspNetCore.Mvc;
using Swms.FinishGoods.API.Features.MapDesigner.Business;
using Swms.FinishGoods.Api.Features.Roles.Authorization;
using Swms.FinishGoods.Api.Features.Roles.Catalog;

namespace Swms.FinishGoods.API.Features.MapDesigner.Api;

/// <summary>Thiết kế bản đồ — dùng chung cho mọi map (storing/receiving/vanning).</summary>
[ApiController]
[Route("api/map-designer")]
public class MapDesignerController : ControllerBase
{
    private readonly IMapDesignerService _service;
    public MapDesignerController(IMapDesignerService service) => _service = service;

    /// <summary>Layout đầy đủ 1 bản đồ (rack + pallet + zone) để vẽ.</summary>
    [HttpGet("{areaCode}/layout")]
    [RequirePermission<Perms.Storage.Map.View>]
    public async Task<ActionResult<MapLayout>> GetLayout(string areaCode)
        => Ok(await _service.GetLayoutAsync(areaCode));

    /// <summary>Lưu toàn bộ layout (block nào không gửi lên sẽ bị gỡ khỏi bản đồ).</summary>
    [HttpPut("{areaCode}/layout")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> SaveLayout(string areaCode, [FromBody] List<MapBlock> blocks)
    {
        await _service.SaveLayoutAsync(areaCode, blocks, User.Identity?.Name);
        return NoContent();
    }

    /// <summary>Tạo kệ mới (tự sinh locator con theo tầng × vị trí) và đặt lên bản đồ.</summary>
    [HttpPost("{areaCode}/racks")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<ActionResult<long>> CreateRack(string areaCode, [FromBody] CreateRackInput input)
        => Ok(await _service.CreateRackAsync(areaCode, input, User.Identity?.Name));

    /// <summary>Xoá kệ khỏi hệ thống (chỉ khi kệ trống hàng).</summary>
    [HttpDelete("{areaCode}/racks/{rackCode}")]
    [RequirePermission<Perms.Storage.Map.Edit>]
    public async Task<IActionResult> DeleteRack(string areaCode, string rackCode)
    {
        await _service.DeleteRackAsync(areaCode, rackCode, User.Identity?.Name);
        return NoContent();
    }
}
