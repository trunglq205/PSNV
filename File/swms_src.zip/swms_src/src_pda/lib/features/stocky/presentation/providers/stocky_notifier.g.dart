// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'stocky_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint, type=warning

@ProviderFor(StockyNotifier)
final stockyProvider = StockyNotifierProvider._();

final class StockyNotifierProvider
    extends $NotifierProvider<StockyNotifier, StockyState> {
  StockyNotifierProvider._()
    : super(
        from: null,
        argument: null,
        retry: null,
        name: r'stockyProvider',
        isAutoDispose: true,
        dependencies: null,
        $allTransitiveDependencies: null,
      );

  @override
  String debugGetCreateSourceHash() => _$stockyNotifierHash();

  @$internal
  @override
  StockyNotifier create() => StockyNotifier();

  /// {@macro riverpod.override_with_value}
  Override overrideWithValue(StockyState value) {
    return $ProviderOverride(
      origin: this,
      providerOverride: $SyncValueProvider<StockyState>(value),
    );
  }
}

String _$stockyNotifierHash() => r'43241fb2df0c8b12c48122ad47fa8c78148bb9b4';

abstract class _$StockyNotifier extends $Notifier<StockyState> {
  StockyState build();
  @$mustCallSuper
  @override
  WhenComplete runBuild() {
    final ref = this.ref as $Ref<StockyState, StockyState>;
    final element =
        ref.element
            as $ClassProviderElement<
              AnyNotifier<StockyState, StockyState>,
              StockyState,
              Object?,
              Object?
            >;
    return element.handleCreate(ref, build);
  }
}
