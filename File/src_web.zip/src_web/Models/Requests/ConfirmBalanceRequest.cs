﻿namespace SWMS_WebTool.Models.Requests
{
    public class ConfirmBalanceRequest
    {
        public string Plant { get; set; }
        public string Sloc { get; set; }
        public string Material { get; set; }
        public double Quantity { get; set; }
    }
    public class AutoBalanceRequest
    {
        public string Material { get; set; }
        public string Plant { get; set; }
        public string Sloc { get; set; }
    }
}
