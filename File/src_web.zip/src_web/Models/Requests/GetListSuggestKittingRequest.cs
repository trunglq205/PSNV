﻿namespace SWMS_WebTool.Models.Requests
{
    public class GetListSuggestKittingRequest
    {
        public string PicUser { get; set; }
        public long? ParentId { get; set; }
        public string Barcode { get; set; }
        public string KittingTimeType { get; set; }
        public string Material { get; set; }
        public int? StartTime { get; set; }
        public int? EndTime { get; set; }
        public bool? IsOnTheHour { get; set; }
        public bool? IsJIT { get; set; }
        public bool IsKittingEnough { get; set; }
        public string Model { get; set; }
        public string Category { get; set; }
        public string Reason { get; set; }
        public string UploadNo { get; set; }
        public string DeliveryDate { get; set; }
        public int? KittingType { get; set; }
        public bool? IsUrgent { get; set; }
        public bool IsDay { get; set; }
        public string Location { get; set; }
        public string StartLocation { get; set; }
        public int PageNumber { get; set; }
        public int PageSize { get; set; }
    }
}
