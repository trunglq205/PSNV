using Swms.FinishGoods.API.Features.HdSoft.Business;

namespace Swms.FinishGoods.API.Features.HdSoft.DataAccess
{
    public interface IHdSoftLotRepository
    {
        Task<IReadOnlyList<HdSoftLotMovementRow>> GetLotHistoryAsync(string lot);

        Task<IReadOnlyList<HdSoftPalletStockRow>> GetPalletsInStockAsync(string? warehouse);

        Task<IReadOnlyDictionary<string, HdSoftLastMovementRow>> GetLastMovementsAsync(IReadOnlyList<string> lots);

        Task<IReadOnlyDictionary<string, IReadOnlyList<HdSoftLotLocationRow>>> GetCurrentLocationsAsync(
            IReadOnlyList<string> lots);

        Task<IReadOnlyDictionary<string, HdSoftLastMovementRow>> GetLastMovementsSinceAsync(
            DateTime since);
    }
}
