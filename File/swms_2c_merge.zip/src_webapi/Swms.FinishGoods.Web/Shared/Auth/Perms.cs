﻿namespace Swms.FinishGoods.Web.Shared.Auth;

/// <summary>
/// Toàn bộ permission keys từ server (/api/auth/me).
/// Nhóm theo module, thứ tự khớp với NavMenu.
/// Dùng Perms.recv_pallet_view.Key() để lấy string "recv_pallet.view".
/// </summary>
public enum Perms
{
    // -------------------------------------------------------------------------
    // NHẬN HÀNG (Receiving) — Cluster 1
    // -------------------------------------------------------------------------
    part_card_view,
    recv_pallet_force,
    recv_pallet_scan,
    recv_pallet_undo,
    recv_pallet_view,

    temploc_assign,
    temploc_release,
    temploc_view,

    stocky_create,
    stocky_delete,
    stocky_transfer,
    stocky_update,
    stocky_view,

    // Hàng bất thường: 5 bước = 5 quyền riêng (xem Perms.cs của API).
    // KHÔNG còn abnormal_report_process / _approve — đã tách thành 4 quyền dưới.
    abnormal_report_create,
    abnormal_report_fa_confirm,
    abnormal_report_finalize,
    abnormal_report_leader_review,
    abnormal_report_oqc_confirm,
    abnormal_report_manage_types,
    abnormal_report_print,
    abnormal_report_view,

    rework_refurbish_approve,
    rework_refurbish_create,
    rework_refurbish_print,
    rework_refurbish_process,
    rework_refurbish_view,

    // Mục 2c. Tên có gạch dưới nên BẮT BUỘC khai case tường minh trong Key()
    // ở dưới: fallback Replace('_','.') sẽ băm thành
    // "rework.refurbish.request.back".
    //
    // approve_scs KHÔNG còn màn nào dùng (luồng bỏ bước duyệt của quản lý SCS),
    // nhưng vẫn khai để gương đúng catalog bên API — ở đó nó buộc phải còn vì
    // PermissionCatalogSeeder MERGE theo code và set lại is_deleted = 0: xoá
    // khỏi Perms.cs rồi khai lại đúng tên cũ sẽ làm SỐNG LẠI quyền của mọi role
    // từng được gán. Đừng gán quyền này cho role nào.
    rework_refurbish_request_back,
    rework_refurbish_approve_fa,
    rework_refurbish_approve_scs,

    putaway_execute,
    putaway_override,
    putaway_view,

    asn_confirm,
    asn_create,
    asn_delete,
    asn_export,
    asn_print,
    asn_update,
    asn_view,

    serial_remove,
    serial_scan,
    serial_view,

    // -------------------------------------------------------------------------
    // LƯU KHO (Storage) — Cluster 2
    // -------------------------------------------------------------------------
    inventory_export,
    inventory_value,
    inventory_view,

    map_detail,
    map_view,
    map_edit,

    stocktake_approve,
    stocktake_assign,
    stocktake_cancel,
    stocktake_count,
    stocktake_create,
    stocktake_recount,
    stocktake_view,

    balance_approve,
    balance_create,
    balance_view,

    // -------------------------------------------------------------------------
    // LẬP KẾ HOẠCH (Planning) — Cluster 3
    // -------------------------------------------------------------------------
    demand_view,
    orders_view,
    expected_lot_view,
    vanning_plan_view,

    // -------------------------------------------------------------------------
    // XUẤT HÀNG (Shipping) — Cluster 3
    // -------------------------------------------------------------------------
    shortage_approve,
    shortage_reallocate,
    shortage_resolve,
    shortage_view,

    si_approve,
    si_create,
    si_delete,
    si_print,
    si_release,
    si_unapprove,
    si_update,
    si_view,

    picking_confirm,
    picking_execute,
    picking_reassign,
    picking_view,

    // -------------------------------------------------------------------------
    // VẬN CHUYỂN (Transport) — Cluster 4
    // -------------------------------------------------------------------------
    vanning_execute,
    vanning_update,
    vanning_view,

    container_gateout,
    container_inspect,
    container_seal,
    container_view,

    stowage_approve,
    stowage_create,
    stowage_update,
    stowage_view,

    // -------------------------------------------------------------------------
    // BÁO CÁO (Analytics)
    // -------------------------------------------------------------------------
    reports_export,
    reports_schedule,
    reports_view,

    audit_export,
    audit_view,

    // -------------------------------------------------------------------------
    // CẤU HÌNH (Config)
    // -------------------------------------------------------------------------
    master_create,
    master_delete,
    master_import,
    master_update,
    master_view,

    models_create,
    models_delete,
    models_import,
    models_update,
    models_view,

    users_create,
    users_delete,
    users_lock,
    users_reset_pwd,
    users_update,
    users_view,

    roles_assign_user,
    roles_create,
    roles_delete,
    roles_update,
    roles_view,

    settings_integration,
    settings_update,
    settings_view,

    // Cấu hình email dùng chung cho mọi module (hàng thiếu, hàng bất thường…).
    // Server sinh khoá từ Perms.System.EmailConfig -> "email_config.view/update".
    email_config_update,
    email_config_view,
}

public static class PermsExtensions
{
    /// <summary>
    /// Chuyển enum thành permission key string khớp với server.
    /// Ví dụ: Perms.recv_pallet_view.Key() => "recv_pallet.view"
    /// </summary>
    public static string Key(this Perms perm) => perm switch
    {
        // Resource có underscore trong tên => xử lý tường minh
        Perms.part_card_view => "part_card.view",
        Perms.recv_pallet_force => "recv_pallet.force",
        Perms.recv_pallet_scan => "recv_pallet.scan",
        Perms.recv_pallet_undo => "recv_pallet.undo",
        Perms.recv_pallet_view => "recv_pallet.view",
        // Cả resource LẪN action có underscore => BẮT BUỘC khai tường minh.
        // Nhánh fallback dưới cùng dùng Replace('_','.') đổi MỌI gạch dưới, nên
        // abnormal_report_leader_review sẽ ra "abnormal.report.leader.review" —
        // sai, và sai im lặng: Has() chỉ trả false, nút biến mất không báo lỗi.
        Perms.abnormal_report_create => "abnormal_report.create",
        Perms.abnormal_report_fa_confirm => "abnormal_report.fa_confirm",
        Perms.abnormal_report_finalize => "abnormal_report.finalize",
        Perms.abnormal_report_leader_review => "abnormal_report.leader_review",
        Perms.abnormal_report_oqc_confirm => "abnormal_report.oqc_confirm",
        Perms.abnormal_report_manage_types => "abnormal_report.manage_types",
        Perms.abnormal_report_print => "abnormal_report.print",
        Perms.abnormal_report_view => "abnormal_report.view",
        Perms.rework_refurbish_approve => "rework_refurbish.approve",
        Perms.rework_refurbish_create => "rework_refurbish.create",
        Perms.rework_refurbish_print => "rework_refurbish.print",
        Perms.rework_refurbish_process => "rework_refurbish.process",
        Perms.rework_refurbish_view => "rework_refurbish.view",

        // Action có underscore => xử lý tường minh
        Perms.rework_refurbish_request_back => "rework_refurbish.request_back",
        Perms.rework_refurbish_approve_fa => "rework_refurbish.approve_fa",
        Perms.rework_refurbish_approve_scs => "rework_refurbish.approve_scs",
        Perms.users_reset_pwd => "users.reset_pwd",
        Perms.roles_assign_user => "roles.assign_user",
        Perms.reports_schedule => "reports.schedule",  // không cần nhưng rõ ràng hơn
        Perms.settings_integration => "settings.integration",

        // Resource có underscore => cũng phải khai tường minh, nếu không nhánh
        // mặc định bên dưới đổi CẢ HAI dấu _ và ra "email.config.view".
        Perms.email_config_view => "email_config.view",
        Perms.email_config_update => "email_config.update",

        // Còn lại: resource_action => resource.action (1 dấu _ duy nhất)
        _ => perm.ToString().Replace('_', '.'),
    };

    /// <summary>Chuyển nhiều enum thành string[] để truyền vào NavItem Perms.</summary>
    public static string[] Keys(params Perms[] perms) => perms.Select(p => p.Key()).ToArray();
}