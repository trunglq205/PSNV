﻿using SWMS_WebTool.Models;
using SWMS_WebTool.Models.Filters;

namespace SWMS_WebTool.ViewModels
{
    public class ReceivingCardStorageViewModel : TableViewModel<ReceivingCardStorage, ReceivingCardStorageFilter>
    {        
        public override object getQueryConditions(int? pageNumber = null, string? pageSize = null, ReceivingCardStorageFilter? filter = null)
        {
            return new
            {
                IsInspection = filter?.IsInspection ?? Filter.IsInspection,
                IsJIT = filter?.IsJIT ?? Filter.IsJIT,
                VendorCode = filter?.VendorCode ?? Filter.VendorCode,
                DANo = filter?.DANo ?? Filter.DANo,
                StatusStorage = filter?.StatusStorage ?? Filter.StatusStorage,
                Plant = filter?.Plant ?? Filter.Plant,
                Category = filter?.Category ?? Filter.Category,
                Sloc = filter?.Sloc ?? Filter.Sloc,
                Material = filter?.Material ?? Filter.Material,
                PageNumber = filter != null || pageSize != null ? 1 : pageNumber ?? PageNumber,
                PageSize = pageSize ?? PageSize.ToString(),
            };
        }
    }
}
